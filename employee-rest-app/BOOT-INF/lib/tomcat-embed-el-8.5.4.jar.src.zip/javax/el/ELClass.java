/*    */ package javax.el;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ELClass
/*    */ {
/*    */   private final Class<?> clazz;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ELClass(Class<?> clazz)
/*    */   {
/* 27 */     this.clazz = clazz;
/*    */   }
/*    */   
/*    */   public Class<?> getKlass() {
/* 31 */     return this.clazz;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-el-8.5.4.jar!\javax\el\ELClass.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */