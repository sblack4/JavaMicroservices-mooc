/*     */ package javax.el;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ExpressionFactory
/*     */ {
/*  48 */   private static final boolean IS_SECURITY_ENABLED = System.getSecurityManager() != null;
/*     */   
/*     */ 
/*     */   private static final String SERVICE_RESOURCE_NAME = "META-INF/services/javax.el.ExpressionFactory";
/*     */   
/*     */ 
/*     */   private static final String PROPERTY_NAME = "javax.el.ExpressionFactory";
/*     */   
/*     */   private static final String PROPERTY_FILE;
/*     */   
/*  58 */   private static final CacheValue nullTcclFactory = new CacheValue();
/*  59 */   private static final ConcurrentMap<CacheKey, CacheValue> factoryCache = new ConcurrentHashMap();
/*     */   
/*     */   static
/*     */   {
/*  63 */     if (IS_SECURITY_ENABLED) {
/*  64 */       PROPERTY_FILE = (String)AccessController.doPrivileged(new PrivilegedAction()
/*     */       {
/*     */         public String run()
/*     */         {
/*  68 */           return System.getProperty("java.home") + File.separator + "lib" + File.separator + "el.properties";
/*     */         }
/*     */         
/*     */ 
/*     */       });
/*     */     }
/*     */     else {
/*  75 */       PROPERTY_FILE = System.getProperty("java.home") + File.separator + "lib" + File.separator + "el.properties";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ExpressionFactory newInstance()
/*     */   {
/*  93 */     return newInstance(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ExpressionFactory newInstance(Properties properties)
/*     */   {
/* 104 */     ExpressionFactory result = null;
/*     */     
/* 106 */     ClassLoader tccl = Thread.currentThread().getContextClassLoader();
/*     */     
/*     */     CacheValue cacheValue;
/*     */     
/*     */     CacheValue cacheValue;
/* 111 */     if (tccl == null) {
/* 112 */       cacheValue = nullTcclFactory;
/*     */     } else {
/* 114 */       CacheKey key = new CacheKey(tccl);
/* 115 */       cacheValue = (CacheValue)factoryCache.get(key);
/* 116 */       if (cacheValue == null) {
/* 117 */         CacheValue newCacheValue = new CacheValue();
/* 118 */         cacheValue = (CacheValue)factoryCache.putIfAbsent(key, newCacheValue);
/* 119 */         if (cacheValue == null) {
/* 120 */           cacheValue = newCacheValue;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 125 */     Lock readLock = cacheValue.getLock().readLock();
/* 126 */     readLock.lock();
/*     */     try {
/* 128 */       clazz = cacheValue.getFactoryClass();
/*     */     } finally { Class<?> clazz;
/* 130 */       readLock.unlock();
/*     */     }
/*     */     Class<?> clazz;
/* 133 */     if (clazz == null) {
/* 134 */       String className = null;
/*     */       try {
/* 136 */         Lock writeLock = cacheValue.getLock().writeLock();
/* 137 */         writeLock.lock();
/*     */         try {
/* 139 */           className = cacheValue.getFactoryClassName();
/* 140 */           if (className == null) {
/* 141 */             className = discoverClassName(tccl);
/* 142 */             cacheValue.setFactoryClassName(className);
/*     */           }
/* 144 */           if (tccl == null) {
/* 145 */             clazz = Class.forName(className);
/*     */           } else {
/* 147 */             clazz = tccl.loadClass(className);
/*     */           }
/* 149 */           cacheValue.setFactoryClass(clazz);
/*     */         } finally {
/* 151 */           writeLock.unlock();
/*     */         }
/*     */       } catch (ClassNotFoundException e) {
/* 154 */         throw new ELException("Unable to find ExpressionFactory of type: " + className, e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 161 */       Constructor<?> constructor = null;
/*     */       
/* 163 */       if (properties != null) {
/*     */         try {
/* 165 */           constructor = clazz.getConstructor(new Class[] { Properties.class });
/*     */         } catch (SecurityException se) {
/* 167 */           throw new ELException(se);
/*     */         }
/*     */         catch (NoSuchMethodException localNoSuchMethodException1) {}
/*     */       }
/*     */       
/*     */ 
/* 173 */       if (constructor == null) {
/* 174 */         result = (ExpressionFactory)clazz.newInstance();
/*     */       } else {
/* 176 */         result = (ExpressionFactory)constructor.newInstance(new Object[] { properties });
/*     */       }
/*     */     }
/*     */     catch (InstantiationException|IllegalAccessException|IllegalArgumentException e)
/*     */     {
/* 181 */       throw new ELException("Unable to create ExpressionFactory of type: " + clazz.getName(), e);
/*     */     }
/*     */     catch (InvocationTargetException e)
/*     */     {
/* 185 */       Throwable cause = e.getCause();
/* 186 */       Util.handleThrowable(cause);
/* 187 */       throw new ELException("Unable to create ExpressionFactory of type: " + clazz.getName(), e);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 192 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ELResolver getStreamELResolver()
/*     */   {
/* 256 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, Method> getInitFunctionMap()
/*     */   {
/* 265 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   private static class CacheKey
/*     */   {
/*     */     private final int hash;
/*     */     
/*     */     private final WeakReference<ClassLoader> ref;
/*     */     
/*     */ 
/*     */     public CacheKey(ClassLoader cl)
/*     */     {
/* 278 */       this.hash = cl.hashCode();
/* 279 */       this.ref = new WeakReference(cl);
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 284 */       return this.hash;
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/* 289 */       if (obj == this) {
/* 290 */         return true;
/*     */       }
/* 292 */       if (!(obj instanceof CacheKey)) {
/* 293 */         return false;
/*     */       }
/* 295 */       ClassLoader thisCl = (ClassLoader)this.ref.get();
/* 296 */       if (thisCl == null) {
/* 297 */         return false;
/*     */       }
/* 299 */       return thisCl == ((CacheKey)obj).ref.get();
/*     */     }
/*     */   }
/*     */   
/*     */   private static class CacheValue {
/* 304 */     private final ReadWriteLock lock = new ReentrantReadWriteLock();
/*     */     
/*     */     private String className;
/*     */     
/*     */     private WeakReference<Class<?>> ref;
/*     */     
/*     */     public ReadWriteLock getLock()
/*     */     {
/* 312 */       return this.lock;
/*     */     }
/*     */     
/*     */     public String getFactoryClassName() {
/* 316 */       return this.className;
/*     */     }
/*     */     
/*     */     public void setFactoryClassName(String className) {
/* 320 */       this.className = className;
/*     */     }
/*     */     
/*     */     public Class<?> getFactoryClass() {
/* 324 */       return this.ref != null ? (Class)this.ref.get() : null;
/*     */     }
/*     */     
/*     */     public void setFactoryClass(Class<?> clazz) {
/* 328 */       this.ref = new WeakReference(clazz);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String discoverClassName(ClassLoader tccl)
/*     */   {
/* 340 */     String className = null;
/*     */     
/*     */ 
/* 343 */     className = getClassNameServices(tccl);
/* 344 */     if (className == null) {
/* 345 */       if (IS_SECURITY_ENABLED) {
/* 346 */         className = (String)AccessController.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public String run()
/*     */           {
/* 350 */             return ExpressionFactory.access$000();
/*     */           }
/*     */           
/*     */ 
/*     */         });
/*     */       } else {
/* 356 */         className = getClassNameJreDir();
/*     */       }
/*     */     }
/* 359 */     if (className == null) {
/* 360 */       if (IS_SECURITY_ENABLED) {
/* 361 */         className = (String)AccessController.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public String run()
/*     */           {
/* 365 */             return ExpressionFactory.access$100();
/*     */           }
/*     */           
/*     */ 
/*     */         });
/*     */       } else {
/* 371 */         className = getClassNameSysProp();
/*     */       }
/*     */     }
/* 374 */     if (className == null)
/*     */     {
/* 376 */       className = "org.apache.el.ExpressionFactoryImpl";
/*     */     }
/* 378 */     return className;
/*     */   }
/*     */   
/*     */   private static String getClassNameServices(ClassLoader tccl) {
/* 382 */     InputStream is = null;
/*     */     
/* 384 */     if (tccl == null) {
/* 385 */       is = ClassLoader.getSystemResourceAsStream("META-INF/services/javax.el.ExpressionFactory");
/*     */     } else {
/* 387 */       is = tccl.getResourceAsStream("META-INF/services/javax.el.ExpressionFactory");
/*     */     }
/*     */     
/* 390 */     if (is != null) {
/* 391 */       String line = null;
/* 392 */       try { InputStreamReader isr = new InputStreamReader(is, "UTF-8");Throwable localThrowable3 = null;
/* 393 */         try { BufferedReader br = new BufferedReader(isr);Throwable localThrowable4 = null;
/* 394 */           try { line = br.readLine();
/* 395 */             if ((line != null) && (line.trim().length() > 0)) {
/* 396 */               String str1 = line.trim();
/*     */               
/* 398 */               if (br != null) if (localThrowable4 != null) try { br.close(); } catch (Throwable x2) { localThrowable4.addSuppressed(x2); } else br.close(); if (isr != null) { if (localThrowable3 != null) try { isr.close(); } catch (Throwable x2) { localThrowable3.addSuppressed(x2); } else { isr.close();
/*     */                 }
/*     */               }
/*     */               
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 407 */               return str1;
/*     */             }
/*     */           }
/*     */           catch (Throwable localThrowable5)
/*     */           {
/* 392 */             localThrowable4 = localThrowable5;throw localThrowable5; } finally {} } catch (Throwable localThrowable2) { localThrowable3 = localThrowable2;throw localThrowable2;
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/*     */ 
/* 398 */           if (isr != null) { if (localThrowable3 != null) try { isr.close(); } catch (Throwable x2) { localThrowable3.addSuppressed(x2); } else { isr.close();
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 411 */         return null;
/*     */       }
/*     */       catch (UnsupportedEncodingException localUnsupportedEncodingException) {}catch (IOException e)
/*     */       {
/* 402 */         throw new ELException("Failed to read META-INF/services/javax.el.ExpressionFactory", e);
/*     */       }
/*     */       finally {
/*     */         try {
/* 406 */           is.close();
/*     */         }
/*     */         catch (IOException localIOException4) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static String getClassNameJreDir()
/*     */   {
/* 415 */     File file = new File(PROPERTY_FILE);
/* 416 */     if (file.canRead()) {
/* 417 */       try { InputStream is = new FileInputStream(file);Throwable localThrowable2 = null;
/* 418 */         try { Properties props = new Properties();
/* 419 */           props.load(is);
/* 420 */           String value = props.getProperty("javax.el.ExpressionFactory");
/* 421 */           if ((value != null) && (value.trim().length() > 0)) {
/* 422 */             return value.trim();
/*     */           }
/*     */         }
/*     */         catch (Throwable localThrowable1)
/*     */         {
/* 417 */           localThrowable2 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/*     */ 
/* 424 */           if (is != null) if (localThrowable2 != null) try { is.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else is.close();
/*     */         }
/*     */       } catch (FileNotFoundException localFileNotFoundException) {}catch (IOException e) {
/* 427 */         throw new ELException("Failed to read " + PROPERTY_FILE, e);
/*     */       }
/*     */     }
/* 430 */     return null;
/*     */   }
/*     */   
/*     */   private static final String getClassNameSysProp() {
/* 434 */     String value = System.getProperty("javax.el.ExpressionFactory");
/* 435 */     if ((value != null) && (value.trim().length() > 0)) {
/* 436 */       return value.trim();
/*     */     }
/* 438 */     return null;
/*     */   }
/*     */   
/*     */   public abstract ValueExpression createValueExpression(ELContext paramELContext, String paramString, Class<?> paramClass);
/*     */   
/*     */   public abstract ValueExpression createValueExpression(Object paramObject, Class<?> paramClass);
/*     */   
/*     */   public abstract MethodExpression createMethodExpression(ELContext paramELContext, String paramString, Class<?> paramClass, Class<?>[] paramArrayOfClass);
/*     */   
/*     */   public abstract Object coerceToType(Object paramObject, Class<?> paramClass);
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-el-8.5.4.jar!\javax\el\ExpressionFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */