/*     */ package javax.el;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Util
/*     */ {
/*     */   static void handleThrowable(Throwable t)
/*     */   {
/*  47 */     if ((t instanceof ThreadDeath)) {
/*  48 */       throw ((ThreadDeath)t);
/*     */     }
/*  50 */     if ((t instanceof VirtualMachineError)) {
/*  51 */       throw ((VirtualMachineError)t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static String message(ELContext context, String name, Object... props)
/*     */   {
/*  58 */     Locale locale = null;
/*  59 */     if (context != null) {
/*  60 */       locale = context.getLocale();
/*     */     }
/*  62 */     if (locale == null) {
/*  63 */       locale = Locale.getDefault();
/*  64 */       if (locale == null) {
/*  65 */         return "";
/*     */       }
/*     */     }
/*  68 */     ResourceBundle bundle = ResourceBundle.getBundle("javax.el.LocalStrings", locale);
/*     */     try
/*     */     {
/*  71 */       String template = bundle.getString(name);
/*  72 */       if (props != null) {}
/*  73 */       return MessageFormat.format(template, props);
/*     */     }
/*     */     catch (MissingResourceException e) {}
/*     */     
/*  77 */     return "Missing Resource: '" + name + "' for Locale " + locale.getDisplayName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*  82 */   private static final CacheValue nullTcclFactory = new CacheValue();
/*  83 */   private static final ConcurrentMap<CacheKey, CacheValue> factoryCache = new ConcurrentHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static ExpressionFactory getExpressionFactory()
/*     */   {
/*  92 */     ClassLoader tccl = Thread.currentThread().getContextClassLoader();
/*  93 */     CacheValue cacheValue = null;
/*  94 */     ExpressionFactory factory = null;
/*     */     
/*  96 */     if (tccl == null) {
/*  97 */       cacheValue = nullTcclFactory;
/*     */     } else {
/*  99 */       CacheKey key = new CacheKey(tccl);
/* 100 */       cacheValue = (CacheValue)factoryCache.get(key);
/* 101 */       if (cacheValue == null) {
/* 102 */         CacheValue newCacheValue = new CacheValue();
/* 103 */         cacheValue = (CacheValue)factoryCache.putIfAbsent(key, newCacheValue);
/* 104 */         if (cacheValue == null) {
/* 105 */           cacheValue = newCacheValue;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 110 */     Lock readLock = cacheValue.getLock().readLock();
/* 111 */     readLock.lock();
/*     */     try {
/* 113 */       factory = cacheValue.getExpressionFactory();
/*     */     } finally {
/* 115 */       readLock.unlock();
/*     */     }
/*     */     
/* 118 */     if (factory == null) {
/* 119 */       Lock writeLock = cacheValue.getLock().writeLock();
/* 120 */       writeLock.lock();
/*     */       try {
/* 122 */         factory = cacheValue.getExpressionFactory();
/* 123 */         if (factory == null) {
/* 124 */           factory = ExpressionFactory.newInstance();
/* 125 */           cacheValue.setExpressionFactory(factory);
/*     */         }
/*     */       } finally {
/* 128 */         writeLock.unlock();
/*     */       }
/*     */     }
/*     */     
/* 132 */     return factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class CacheKey
/*     */   {
/*     */     private final int hash;
/*     */     
/*     */     private final WeakReference<ClassLoader> ref;
/*     */     
/*     */ 
/*     */     public CacheKey(ClassLoader key)
/*     */     {
/* 146 */       this.hash = key.hashCode();
/* 147 */       this.ref = new WeakReference(key);
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 152 */       return this.hash;
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/* 157 */       if (obj == this) {
/* 158 */         return true;
/*     */       }
/* 160 */       if (!(obj instanceof CacheKey)) {
/* 161 */         return false;
/*     */       }
/* 163 */       ClassLoader thisKey = (ClassLoader)this.ref.get();
/* 164 */       if (thisKey == null) {
/* 165 */         return false;
/*     */       }
/* 167 */       return thisKey == ((CacheKey)obj).ref.get();
/*     */     }
/*     */   }
/*     */   
/*     */   private static class CacheValue {
/* 172 */     private final ReadWriteLock lock = new ReentrantReadWriteLock();
/*     */     
/*     */     private WeakReference<ExpressionFactory> ref;
/*     */     
/*     */ 
/*     */     public ReadWriteLock getLock()
/*     */     {
/* 179 */       return this.lock;
/*     */     }
/*     */     
/*     */     public ExpressionFactory getExpressionFactory() {
/* 183 */       return this.ref != null ? (ExpressionFactory)this.ref.get() : null;
/*     */     }
/*     */     
/*     */     public void setExpressionFactory(ExpressionFactory factory) {
/* 187 */       this.ref = new WeakReference(factory);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Method findMethod(Class<?> clazz, String methodName, Class<?>[] paramTypes, Object[] paramValues)
/*     */   {
/* 199 */     if ((clazz == null) || (methodName == null)) {
/* 200 */       throw new MethodNotFoundException(message(null, "util.method.notfound", new Object[] { clazz, methodName, paramString(paramTypes) }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 205 */     if (paramTypes == null) {
/* 206 */       paramTypes = getTypesFromValues(paramValues);
/*     */     }
/*     */     
/* 209 */     Method[] methods = clazz.getMethods();
/*     */     
/* 211 */     List<Wrapper> wrappers = Wrapper.wrap(methods, methodName);
/*     */     
/* 213 */     Wrapper result = findWrapper(clazz, wrappers, methodName, paramTypes, paramValues);
/*     */     
/*     */ 
/* 216 */     if (result == null) {
/* 217 */       return null;
/*     */     }
/* 219 */     return getMethod(clazz, (Method)result.unWrap());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Wrapper findWrapper(Class<?> clazz, List<Wrapper> wrappers, String name, Class<?>[] paramTypes, Object[] paramValues)
/*     */   {
/* 230 */     Map<Wrapper, MatchResult> candidates = new HashMap();
/*     */     int paramCount;
/*     */     int paramCount;
/* 233 */     if (paramTypes == null) {
/* 234 */       paramCount = 0;
/*     */     } else {
/* 236 */       paramCount = paramTypes.length;
/*     */     }
/*     */     
/* 239 */     for (Wrapper w : wrappers) {
/* 240 */       Class<?>[] mParamTypes = w.getParameterTypes();
/*     */       int mParamCount;
/* 242 */       int mParamCount; if (mParamTypes == null) {
/* 243 */         mParamCount = 0;
/*     */       } else {
/* 245 */         mParamCount = mParamTypes.length;
/*     */       }
/*     */       
/*     */ 
/* 249 */       if ((paramCount == mParamCount) || ((w.isVarArgs()) && (paramCount >= mParamCount)))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 256 */         int exactMatch = 0;
/* 257 */         int assignableMatch = 0;
/* 258 */         int coercibleMatch = 0;
/* 259 */         boolean noMatch = false;
/* 260 */         for (int i = 0; i < mParamCount; i++)
/*     */         {
/* 262 */           if (mParamTypes[i].equals(paramTypes[i])) {
/* 263 */             exactMatch++;
/* 264 */           } else if ((i == mParamCount - 1) && (w.isVarArgs())) {
/* 265 */             Class<?> varType = mParamTypes[i].getComponentType();
/* 266 */             for (int j = i; j < paramCount; j++) {
/* 267 */               if (isAssignableFrom(paramTypes[j], varType)) {
/* 268 */                 assignableMatch++;
/*     */               } else {
/* 270 */                 if (paramValues == null) {
/* 271 */                   noMatch = true;
/* 272 */                   break;
/*     */                 }
/* 274 */                 if (isCoercibleFrom(paramValues[j], varType)) {
/* 275 */                   coercibleMatch++;
/*     */                 } else {
/* 277 */                   noMatch = true;
/* 278 */                   break;
/*     */                 }
/*     */                 
/*     */               }
/*     */               
/*     */             }
/*     */             
/*     */           }
/* 286 */           else if (isAssignableFrom(paramTypes[i], mParamTypes[i])) {
/* 287 */             assignableMatch++;
/*     */           } else {
/* 289 */             if (paramValues == null) {
/* 290 */               noMatch = true;
/* 291 */               break;
/*     */             }
/* 293 */             if (isCoercibleFrom(paramValues[i], mParamTypes[i])) {
/* 294 */               coercibleMatch++;
/*     */             } else {
/* 296 */               noMatch = true;
/* 297 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 302 */         if (!noMatch)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 308 */           if (exactMatch == paramCount) {
/* 309 */             return w;
/*     */           }
/*     */           
/* 312 */           candidates.put(w, new MatchResult(exactMatch, assignableMatch, coercibleMatch, w.isBridge()));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 318 */     MatchResult bestMatch = new MatchResult(0, 0, 0, false);
/* 319 */     Wrapper match = null;
/* 320 */     boolean multiple = false;
/* 321 */     for (Map.Entry<Wrapper, MatchResult> entry : candidates.entrySet()) {
/* 322 */       int cmp = ((MatchResult)entry.getValue()).compareTo(bestMatch);
/* 323 */       if ((cmp > 0) || (match == null)) {
/* 324 */         bestMatch = (MatchResult)entry.getValue();
/* 325 */         match = (Wrapper)entry.getKey();
/* 326 */         multiple = false;
/* 327 */       } else if (cmp == 0) {
/* 328 */         multiple = true;
/*     */       }
/*     */     }
/* 331 */     if (multiple) {
/* 332 */       if (bestMatch.getExact() == paramCount - 1)
/*     */       {
/*     */ 
/* 335 */         match = resolveAmbiguousWrapper(candidates.keySet(), paramTypes);
/*     */       } else {
/* 337 */         match = null;
/*     */       }
/*     */       
/* 340 */       if (match == null)
/*     */       {
/*     */ 
/* 343 */         throw new MethodNotFoundException(message(null, "util.method.ambiguous", new Object[] { clazz, name, paramString(paramTypes) }));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 350 */     if (match == null) {
/* 351 */       throw new MethodNotFoundException(message(null, "util.method.notfound", new Object[] { clazz, name, paramString(paramTypes) }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 356 */     return match;
/*     */   }
/*     */   
/*     */   private static final String paramString(Class<?>[] types)
/*     */   {
/* 361 */     if (types != null) {
/* 362 */       StringBuilder sb = new StringBuilder();
/* 363 */       for (int i = 0; i < types.length; i++) {
/* 364 */         if (types[i] == null) {
/* 365 */           sb.append("null, ");
/*     */         } else {
/* 367 */           sb.append(types[i].getName()).append(", ");
/*     */         }
/*     */       }
/* 370 */       if (sb.length() > 2) {
/* 371 */         sb.setLength(sb.length() - 2);
/*     */       }
/* 373 */       return sb.toString();
/*     */     }
/* 375 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Wrapper resolveAmbiguousWrapper(Set<Wrapper> candidates, Class<?>[] paramTypes)
/*     */   {
/* 386 */     Wrapper w = (Wrapper)candidates.iterator().next();
/*     */     
/* 388 */     int nonMatchIndex = 0;
/* 389 */     Class<?> nonMatchClass = null;
/*     */     
/* 391 */     for (int i = 0; i < paramTypes.length; i++) {
/* 392 */       if (w.getParameterTypes()[i] != paramTypes[i]) {
/* 393 */         nonMatchIndex = i;
/* 394 */         nonMatchClass = paramTypes[i];
/* 395 */         break;
/*     */       }
/*     */     }
/*     */     
/* 399 */     if (nonMatchClass == null)
/*     */     {
/* 401 */       return null;
/*     */     }
/*     */     
/* 404 */     for (Wrapper c : candidates) {
/* 405 */       if (c.getParameterTypes()[nonMatchIndex] == paramTypes[nonMatchIndex])
/*     */       {
/*     */ 
/*     */ 
/* 409 */         return null;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 414 */     Class<?> superClass = nonMatchClass.getSuperclass();
/* 415 */     while (superClass != null) {
/* 416 */       for (Wrapper c : candidates) {
/* 417 */         if (c.getParameterTypes()[nonMatchIndex].equals(superClass))
/*     */         {
/* 419 */           return c;
/*     */         }
/*     */       }
/* 422 */       superClass = superClass.getSuperclass();
/*     */     }
/*     */     
/*     */ 
/* 426 */     Wrapper match = null;
/* 427 */     if (Number.class.isAssignableFrom(nonMatchClass)) {
/* 428 */       for (Wrapper c : candidates) {
/* 429 */         Class<?> candidateType = c.getParameterTypes()[nonMatchIndex];
/* 430 */         if ((Number.class.isAssignableFrom(candidateType)) || (candidateType.isPrimitive()))
/*     */         {
/* 432 */           if (match == null) {
/* 433 */             match = c;
/*     */           }
/*     */           else {
/* 436 */             match = null;
/* 437 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 443 */     return match;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean isAssignableFrom(Class<?> src, Class<?> target)
/*     */   {
/* 455 */     if (src == null) {
/* 456 */       return true;
/*     */     }
/*     */     Class<?> targetClass;
/*     */     Class<?> targetClass;
/* 460 */     if (target.isPrimitive()) { Class<?> targetClass;
/* 461 */       if (target == Boolean.TYPE) {
/* 462 */         targetClass = Boolean.class; } else { Class<?> targetClass;
/* 463 */         if (target == Character.TYPE) {
/* 464 */           targetClass = Character.class; } else { Class<?> targetClass;
/* 465 */           if (target == Byte.TYPE) {
/* 466 */             targetClass = Byte.class; } else { Class<?> targetClass;
/* 467 */             if (target == Short.TYPE) {
/* 468 */               targetClass = Short.class; } else { Class<?> targetClass;
/* 469 */               if (target == Integer.TYPE) {
/* 470 */                 targetClass = Integer.class; } else { Class<?> targetClass;
/* 471 */                 if (target == Long.TYPE) {
/* 472 */                   targetClass = Long.class; } else { Class<?> targetClass;
/* 473 */                   if (target == Float.TYPE) {
/* 474 */                     targetClass = Float.class;
/*     */                   } else
/* 476 */                     targetClass = Double.class;
/*     */                 }
/*     */               }
/* 479 */             } } } } } else { targetClass = target;
/*     */     }
/* 481 */     return targetClass.isAssignableFrom(src);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isCoercibleFrom(Object src, Class<?> target)
/*     */   {
/*     */     try
/*     */     {
/* 493 */       getExpressionFactory().coerceToType(src, target);
/*     */     } catch (ELException e) {
/* 495 */       return false;
/*     */     }
/* 497 */     return true;
/*     */   }
/*     */   
/*     */   private static Class<?>[] getTypesFromValues(Object[] values)
/*     */   {
/* 502 */     if (values == null) {
/* 503 */       return null;
/*     */     }
/*     */     
/* 506 */     Class<?>[] result = new Class[values.length];
/* 507 */     for (int i = 0; i < values.length; i++) {
/* 508 */       if (values[i] == null) {
/* 509 */         result[i] = null;
/*     */       } else {
/* 511 */         result[i] = values[i].getClass();
/*     */       }
/*     */     }
/* 514 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Method getMethod(Class<?> type, Method m)
/*     */   {
/* 523 */     if ((m == null) || (Modifier.isPublic(type.getModifiers()))) {
/* 524 */       return m;
/*     */     }
/* 526 */     Class<?>[] inf = type.getInterfaces();
/* 527 */     Method mp = null;
/* 528 */     for (int i = 0; i < inf.length; i++) {
/*     */       try {
/* 530 */         mp = inf[i].getMethod(m.getName(), m.getParameterTypes());
/* 531 */         mp = getMethod(mp.getDeclaringClass(), mp);
/* 532 */         if (mp != null) {
/* 533 */           return mp;
/*     */         }
/*     */       }
/*     */       catch (NoSuchMethodException localNoSuchMethodException) {}
/*     */     }
/*     */     
/* 539 */     Class<?> sup = type.getSuperclass();
/* 540 */     if (sup != null) {
/*     */       try {
/* 542 */         mp = sup.getMethod(m.getName(), m.getParameterTypes());
/* 543 */         mp = getMethod(mp.getDeclaringClass(), mp);
/* 544 */         if (mp != null) {
/* 545 */           return mp;
/*     */         }
/*     */       }
/*     */       catch (NoSuchMethodException localNoSuchMethodException1) {}
/*     */     }
/*     */     
/* 551 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static Constructor<?> findConstructor(Class<?> clazz, Class<?>[] paramTypes, Object[] paramValues)
/*     */   {
/* 558 */     String methodName = "<init>";
/*     */     
/* 560 */     if (clazz == null) {
/* 561 */       throw new MethodNotFoundException(message(null, "util.method.notfound", new Object[] { clazz, methodName, paramString(paramTypes) }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 566 */     if (paramTypes == null) {
/* 567 */       paramTypes = getTypesFromValues(paramValues);
/*     */     }
/*     */     
/* 570 */     Constructor<?>[] constructors = clazz.getConstructors();
/*     */     
/* 572 */     List<Wrapper> wrappers = Wrapper.wrap(constructors);
/*     */     
/* 574 */     Wrapper result = findWrapper(clazz, wrappers, methodName, paramTypes, paramValues);
/*     */     
/*     */ 
/* 577 */     if (result == null) {
/* 578 */       return null;
/*     */     }
/* 580 */     return getConstructor(clazz, (Constructor)result.unWrap());
/*     */   }
/*     */   
/*     */   static Constructor<?> getConstructor(Class<?> type, Constructor<?> c)
/*     */   {
/* 585 */     if ((c == null) || (Modifier.isPublic(type.getModifiers()))) {
/* 586 */       return c;
/*     */     }
/* 588 */     Constructor<?> cp = null;
/* 589 */     Class<?> sup = type.getSuperclass();
/* 590 */     if (sup != null) {
/*     */       try {
/* 592 */         cp = sup.getConstructor(c.getParameterTypes());
/* 593 */         cp = getConstructor(cp.getDeclaringClass(), cp);
/* 594 */         if (cp != null) {
/* 595 */           return cp;
/*     */         }
/*     */       }
/*     */       catch (NoSuchMethodException localNoSuchMethodException) {}
/*     */     }
/*     */     
/* 601 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   static Object[] buildParameters(Class<?>[] parameterTypes, boolean isVarArgs, Object[] params)
/*     */   {
/* 607 */     ExpressionFactory factory = getExpressionFactory();
/* 608 */     Object[] parameters = null;
/* 609 */     if (parameterTypes.length > 0) {
/* 610 */       parameters = new Object[parameterTypes.length];
/* 611 */       int paramCount = params.length;
/* 612 */       if (isVarArgs) {
/* 613 */         int varArgIndex = parameterTypes.length - 1;
/*     */         
/* 615 */         for (int i = 0; i < varArgIndex; i++) {
/* 616 */           parameters[i] = factory.coerceToType(params[i], parameterTypes[i]);
/*     */         }
/*     */         
/*     */ 
/* 620 */         Class<?> varArgClass = parameterTypes[varArgIndex].getComponentType();
/*     */         
/* 622 */         Object varargs = Array.newInstance(varArgClass, paramCount - varArgIndex);
/*     */         
/*     */ 
/* 625 */         for (int i = varArgIndex; i < paramCount; i++) {
/* 626 */           Array.set(varargs, i - varArgIndex, factory.coerceToType(params[i], varArgClass));
/*     */         }
/*     */         
/* 629 */         parameters[varArgIndex] = varargs;
/*     */       } else {
/* 631 */         parameters = new Object[parameterTypes.length];
/* 632 */         for (int i = 0; i < parameterTypes.length; i++) {
/* 633 */           parameters[i] = factory.coerceToType(params[i], parameterTypes[i]);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 638 */     return parameters;
/*     */   }
/*     */   
/*     */   private static abstract class Wrapper
/*     */   {
/*     */     public static List<Wrapper> wrap(Method[] methods, String name)
/*     */     {
/* 645 */       List<Wrapper> result = new ArrayList();
/* 646 */       for (Method method : methods) {
/* 647 */         if (method.getName().equals(name)) {
/* 648 */           result.add(new Util.MethodWrapper(method));
/*     */         }
/*     */       }
/* 651 */       return result;
/*     */     }
/*     */     
/*     */     public static List<Wrapper> wrap(Constructor<?>[] constructors) {
/* 655 */       List<Wrapper> result = new ArrayList();
/* 656 */       for (Constructor<?> constructor : constructors) {
/* 657 */         result.add(new Util.ConstructorWrapper(constructor));
/*     */       }
/* 659 */       return result;
/*     */     }
/*     */     
/*     */     public abstract Object unWrap();
/*     */     
/*     */     public abstract Class<?>[] getParameterTypes();
/*     */     
/*     */     public abstract boolean isVarArgs();
/*     */     
/*     */     public abstract boolean isBridge(); }
/*     */   
/*     */   private static class MethodWrapper extends Util.Wrapper { private final Method m;
/*     */     
/* 672 */     public MethodWrapper(Method m) { super();
/* 673 */       this.m = m;
/*     */     }
/*     */     
/*     */     public Object unWrap()
/*     */     {
/* 678 */       return this.m;
/*     */     }
/*     */     
/*     */     public Class<?>[] getParameterTypes()
/*     */     {
/* 683 */       return this.m.getParameterTypes();
/*     */     }
/*     */     
/*     */     public boolean isVarArgs()
/*     */     {
/* 688 */       return this.m.isVarArgs();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 693 */     public boolean isBridge() { return this.m.isBridge(); }
/*     */   }
/*     */   
/*     */   private static class ConstructorWrapper extends Util.Wrapper {
/*     */     private final Constructor<?> c;
/*     */     
/*     */     public ConstructorWrapper(Constructor<?> c) {
/* 700 */       super();
/* 701 */       this.c = c;
/*     */     }
/*     */     
/*     */     public Object unWrap()
/*     */     {
/* 706 */       return this.c;
/*     */     }
/*     */     
/*     */     public Class<?>[] getParameterTypes()
/*     */     {
/* 711 */       return this.c.getParameterTypes();
/*     */     }
/*     */     
/*     */     public boolean isVarArgs()
/*     */     {
/* 716 */       return this.c.isVarArgs();
/*     */     }
/*     */     
/*     */     public boolean isBridge()
/*     */     {
/* 721 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class MatchResult
/*     */     implements Comparable<MatchResult>
/*     */   {
/*     */     private final int exact;
/*     */     
/*     */     private final int assignable;
/*     */     private final int coercible;
/*     */     private final boolean bridge;
/*     */     
/*     */     public MatchResult(int exact, int assignable, int coercible, boolean bridge)
/*     */     {
/* 737 */       this.exact = exact;
/* 738 */       this.assignable = assignable;
/* 739 */       this.coercible = coercible;
/* 740 */       this.bridge = bridge;
/*     */     }
/*     */     
/*     */     public int getExact() {
/* 744 */       return this.exact;
/*     */     }
/*     */     
/*     */     public int getAssignable() {
/* 748 */       return this.assignable;
/*     */     }
/*     */     
/*     */     public int getCoercible() {
/* 752 */       return this.coercible;
/*     */     }
/*     */     
/*     */     public boolean isBridge() {
/* 756 */       return this.bridge;
/*     */     }
/*     */     
/*     */     public int compareTo(MatchResult o)
/*     */     {
/* 761 */       int cmp = Integer.compare(getExact(), o.getExact());
/* 762 */       if (cmp == 0) {
/* 763 */         cmp = Integer.compare(getAssignable(), o.getAssignable());
/* 764 */         if (cmp == 0) {
/* 765 */           cmp = Integer.compare(getCoercible(), o.getCoercible());
/* 766 */           if (cmp == 0)
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/* 771 */             cmp = Boolean.compare(o.isBridge(), isBridge());
/*     */           }
/*     */         }
/*     */       }
/* 775 */       return cmp;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-el-8.5.4.jar!\javax\el\Util.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */