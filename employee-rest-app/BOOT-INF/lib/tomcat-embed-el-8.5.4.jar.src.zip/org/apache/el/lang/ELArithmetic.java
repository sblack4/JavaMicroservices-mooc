/*     */ package org.apache.el.lang;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import org.apache.el.util.MessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ELArithmetic
/*     */ {
/*     */   public static final class BigDecimalDelegate
/*     */     extends ELArithmetic
/*     */   {
/*     */     protected Number add(Number num0, Number num1)
/*     */     {
/*  36 */       return ((BigDecimal)num0).add((BigDecimal)num1);
/*     */     }
/*     */     
/*     */     protected Number coerce(Number num)
/*     */     {
/*  41 */       if ((num instanceof BigDecimal))
/*  42 */         return num;
/*  43 */       if ((num instanceof BigInteger))
/*  44 */         return new BigDecimal((BigInteger)num);
/*  45 */       return new BigDecimal(num.doubleValue());
/*     */     }
/*     */     
/*     */     protected Number coerce(String str)
/*     */     {
/*  50 */       return new BigDecimal(str);
/*     */     }
/*     */     
/*     */     protected Number divide(Number num0, Number num1)
/*     */     {
/*  55 */       return ((BigDecimal)num0).divide((BigDecimal)num1, 4);
/*     */     }
/*     */     
/*     */ 
/*     */     protected Number subtract(Number num0, Number num1)
/*     */     {
/*  61 */       return ((BigDecimal)num0).subtract((BigDecimal)num1);
/*     */     }
/*     */     
/*     */     protected Number mod(Number num0, Number num1)
/*     */     {
/*  66 */       return Double.valueOf(num0.doubleValue() % num1.doubleValue());
/*     */     }
/*     */     
/*     */     protected Number multiply(Number num0, Number num1)
/*     */     {
/*  71 */       return ((BigDecimal)num0).multiply((BigDecimal)num1);
/*     */     }
/*     */     
/*     */     public boolean matches(Object obj0, Object obj1)
/*     */     {
/*  76 */       return ((obj0 instanceof BigDecimal)) || ((obj1 instanceof BigDecimal));
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class BigIntegerDelegate extends ELArithmetic
/*     */   {
/*     */     protected Number add(Number num0, Number num1)
/*     */     {
/*  84 */       return ((BigInteger)num0).add((BigInteger)num1);
/*     */     }
/*     */     
/*     */     protected Number coerce(Number num)
/*     */     {
/*  89 */       if ((num instanceof BigInteger))
/*  90 */         return num;
/*  91 */       return new BigInteger(num.toString());
/*     */     }
/*     */     
/*     */     protected Number coerce(String str)
/*     */     {
/*  96 */       return new BigInteger(str);
/*     */     }
/*     */     
/*     */     protected Number divide(Number num0, Number num1)
/*     */     {
/* 101 */       return new BigDecimal((BigInteger)num0).divide(new BigDecimal((BigInteger)num1), 4);
/*     */     }
/*     */     
/*     */     protected Number multiply(Number num0, Number num1)
/*     */     {
/* 106 */       return ((BigInteger)num0).multiply((BigInteger)num1);
/*     */     }
/*     */     
/*     */     protected Number mod(Number num0, Number num1)
/*     */     {
/* 111 */       return ((BigInteger)num0).mod((BigInteger)num1);
/*     */     }
/*     */     
/*     */     protected Number subtract(Number num0, Number num1)
/*     */     {
/* 116 */       return ((BigInteger)num0).subtract((BigInteger)num1);
/*     */     }
/*     */     
/*     */     public boolean matches(Object obj0, Object obj1)
/*     */     {
/* 121 */       return ((obj0 instanceof BigInteger)) || ((obj1 instanceof BigInteger));
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class DoubleDelegate
/*     */     extends ELArithmetic
/*     */   {
/*     */     protected Number add(Number num0, Number num1)
/*     */     {
/* 130 */       if ((num0 instanceof BigDecimal))
/* 131 */         return ((BigDecimal)num0).add(new BigDecimal(num1.doubleValue()));
/* 132 */       if ((num1 instanceof BigDecimal)) {
/* 133 */         return new BigDecimal(num0.doubleValue()).add((BigDecimal)num1);
/*     */       }
/* 135 */       return Double.valueOf(num0.doubleValue() + num1.doubleValue());
/*     */     }
/*     */     
/*     */     protected Number coerce(Number num)
/*     */     {
/* 140 */       if ((num instanceof Double))
/* 141 */         return num;
/* 142 */       if ((num instanceof BigInteger))
/* 143 */         return new BigDecimal((BigInteger)num);
/* 144 */       return Double.valueOf(num.doubleValue());
/*     */     }
/*     */     
/*     */     protected Number coerce(String str)
/*     */     {
/* 149 */       return Double.valueOf(str);
/*     */     }
/*     */     
/*     */     protected Number divide(Number num0, Number num1)
/*     */     {
/* 154 */       return Double.valueOf(num0.doubleValue() / num1.doubleValue());
/*     */     }
/*     */     
/*     */     protected Number mod(Number num0, Number num1)
/*     */     {
/* 159 */       return Double.valueOf(num0.doubleValue() % num1.doubleValue());
/*     */     }
/*     */     
/*     */ 
/*     */     protected Number subtract(Number num0, Number num1)
/*     */     {
/* 165 */       if ((num0 instanceof BigDecimal))
/* 166 */         return ((BigDecimal)num0).subtract(new BigDecimal(num1.doubleValue()));
/* 167 */       if ((num1 instanceof BigDecimal)) {
/* 168 */         return new BigDecimal(num0.doubleValue()).subtract((BigDecimal)num1);
/*     */       }
/* 170 */       return Double.valueOf(num0.doubleValue() - num1.doubleValue());
/*     */     }
/*     */     
/*     */ 
/*     */     protected Number multiply(Number num0, Number num1)
/*     */     {
/* 176 */       if ((num0 instanceof BigDecimal))
/* 177 */         return ((BigDecimal)num0).multiply(new BigDecimal(num1.doubleValue()));
/* 178 */       if ((num1 instanceof BigDecimal)) {
/* 179 */         return new BigDecimal(num0.doubleValue()).multiply((BigDecimal)num1);
/*     */       }
/* 181 */       return Double.valueOf(num0.doubleValue() * num1.doubleValue());
/*     */     }
/*     */     
/*     */     public boolean matches(Object obj0, Object obj1)
/*     */     {
/* 186 */       return ((obj0 instanceof Double)) || ((obj1 instanceof Double)) || ((obj0 instanceof Float)) || ((obj1 instanceof Float)) || (((obj0 instanceof String)) && (ELSupport.isStringFloat((String)obj0))) || (((obj1 instanceof String)) && (ELSupport.isStringFloat((String)obj1)));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final class LongDelegate
/*     */     extends ELArithmetic
/*     */   {
/*     */     protected Number add(Number num0, Number num1)
/*     */     {
/* 200 */       return Long.valueOf(num0.longValue() + num1.longValue());
/*     */     }
/*     */     
/*     */     protected Number coerce(Number num)
/*     */     {
/* 205 */       if ((num instanceof Long))
/* 206 */         return num;
/* 207 */       return Long.valueOf(num.longValue());
/*     */     }
/*     */     
/*     */     protected Number coerce(String str)
/*     */     {
/* 212 */       return Long.valueOf(str);
/*     */     }
/*     */     
/*     */     protected Number divide(Number num0, Number num1)
/*     */     {
/* 217 */       return Long.valueOf(num0.longValue() / num1.longValue());
/*     */     }
/*     */     
/*     */     protected Number mod(Number num0, Number num1)
/*     */     {
/* 222 */       return Long.valueOf(num0.longValue() % num1.longValue());
/*     */     }
/*     */     
/*     */     protected Number subtract(Number num0, Number num1)
/*     */     {
/* 227 */       return Long.valueOf(num0.longValue() - num1.longValue());
/*     */     }
/*     */     
/*     */     protected Number multiply(Number num0, Number num1)
/*     */     {
/* 232 */       return Long.valueOf(num0.longValue() * num1.longValue());
/*     */     }
/*     */     
/*     */     public boolean matches(Object obj0, Object obj1)
/*     */     {
/* 237 */       return ((obj0 instanceof Long)) || ((obj1 instanceof Long));
/*     */     }
/*     */   }
/*     */   
/* 241 */   public static final BigDecimalDelegate BIGDECIMAL = new BigDecimalDelegate();
/*     */   
/* 243 */   public static final BigIntegerDelegate BIGINTEGER = new BigIntegerDelegate();
/*     */   
/* 245 */   public static final DoubleDelegate DOUBLE = new DoubleDelegate();
/*     */   
/* 247 */   public static final LongDelegate LONG = new LongDelegate();
/*     */   
/* 249 */   private static final Long ZERO = Long.valueOf(0L);
/*     */   
/*     */   public static final Number add(Object obj0, Object obj1) {
/* 252 */     ELArithmetic delegate = findDelegate(obj0, obj1);
/* 253 */     if (delegate == null) {
/* 254 */       return Long.valueOf(0L);
/*     */     }
/*     */     
/* 257 */     Number num0 = delegate.coerce(obj0);
/* 258 */     Number num1 = delegate.coerce(obj1);
/*     */     
/* 260 */     return delegate.add(num0, num1);
/*     */   }
/*     */   
/*     */   public static final Number mod(Object obj0, Object obj1) {
/* 264 */     if ((obj0 == null) && (obj1 == null)) {
/* 265 */       return Long.valueOf(0L);
/*     */     }
/*     */     ELArithmetic delegate;
/*     */     ELArithmetic delegate;
/* 269 */     if (BIGDECIMAL.matches(obj0, obj1)) {
/* 270 */       delegate = DOUBLE; } else { ELArithmetic delegate;
/* 271 */       if (DOUBLE.matches(obj0, obj1)) {
/* 272 */         delegate = DOUBLE; } else { ELArithmetic delegate;
/* 273 */         if (BIGINTEGER.matches(obj0, obj1)) {
/* 274 */           delegate = BIGINTEGER;
/*     */         } else
/* 276 */           delegate = LONG;
/*     */       } }
/* 278 */     Number num0 = delegate.coerce(obj0);
/* 279 */     Number num1 = delegate.coerce(obj1);
/*     */     
/* 281 */     return delegate.mod(num0, num1);
/*     */   }
/*     */   
/*     */   public static final Number subtract(Object obj0, Object obj1) {
/* 285 */     ELArithmetic delegate = findDelegate(obj0, obj1);
/* 286 */     if (delegate == null) {
/* 287 */       return Long.valueOf(0L);
/*     */     }
/*     */     
/* 290 */     Number num0 = delegate.coerce(obj0);
/* 291 */     Number num1 = delegate.coerce(obj1);
/*     */     
/* 293 */     return delegate.subtract(num0, num1);
/*     */   }
/*     */   
/*     */   public static final Number divide(Object obj0, Object obj1) {
/* 297 */     if ((obj0 == null) && (obj1 == null)) {
/* 298 */       return ZERO;
/*     */     }
/*     */     ELArithmetic delegate;
/*     */     ELArithmetic delegate;
/* 302 */     if (BIGDECIMAL.matches(obj0, obj1)) {
/* 303 */       delegate = BIGDECIMAL; } else { ELArithmetic delegate;
/* 304 */       if (BIGINTEGER.matches(obj0, obj1)) {
/* 305 */         delegate = BIGDECIMAL;
/*     */       } else
/* 307 */         delegate = DOUBLE;
/*     */     }
/* 309 */     Number num0 = delegate.coerce(obj0);
/* 310 */     Number num1 = delegate.coerce(obj1);
/*     */     
/* 312 */     return delegate.divide(num0, num1);
/*     */   }
/*     */   
/*     */   public static final Number multiply(Object obj0, Object obj1) {
/* 316 */     ELArithmetic delegate = findDelegate(obj0, obj1);
/* 317 */     if (delegate == null) {
/* 318 */       return Long.valueOf(0L);
/*     */     }
/*     */     
/* 321 */     Number num0 = delegate.coerce(obj0);
/* 322 */     Number num1 = delegate.coerce(obj1);
/*     */     
/* 324 */     return delegate.multiply(num0, num1);
/*     */   }
/*     */   
/*     */   private static ELArithmetic findDelegate(Object obj0, Object obj1) {
/* 328 */     if ((obj0 == null) && (obj1 == null)) {
/* 329 */       return null;
/*     */     }
/*     */     
/* 332 */     if (BIGDECIMAL.matches(obj0, obj1))
/* 333 */       return BIGDECIMAL;
/* 334 */     if (DOUBLE.matches(obj0, obj1)) {
/* 335 */       if (BIGINTEGER.matches(obj0, obj1)) {
/* 336 */         return BIGDECIMAL;
/*     */       }
/* 338 */       return DOUBLE;
/*     */     }
/* 340 */     if (BIGINTEGER.matches(obj0, obj1)) {
/* 341 */       return BIGINTEGER;
/*     */     }
/* 343 */     return LONG;
/*     */   }
/*     */   
/*     */   public static final boolean isNumber(Object obj)
/*     */   {
/* 348 */     return (obj != null) && (isNumberType(obj.getClass()));
/*     */   }
/*     */   
/*     */   public static final boolean isNumberType(Class<?> type) {
/* 352 */     return (type == Long.TYPE) || (type == Double.TYPE) || (type == Byte.TYPE) || (type == Short.TYPE) || (type == Integer.TYPE) || (type == Float.TYPE) || (Number.class.isAssignableFrom(type));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract Number add(Number paramNumber1, Number paramNumber2);
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract Number multiply(Number paramNumber1, Number paramNumber2);
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract Number subtract(Number paramNumber1, Number paramNumber2);
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract Number mod(Number paramNumber1, Number paramNumber2);
/*     */   
/*     */ 
/*     */   protected abstract Number coerce(Number paramNumber);
/*     */   
/*     */ 
/*     */   protected final Number coerce(Object obj)
/*     */   {
/* 377 */     if (isNumber(obj)) {
/* 378 */       return coerce((Number)obj);
/*     */     }
/* 380 */     if ((obj == null) || ("".equals(obj))) {
/* 381 */       return coerce(ZERO);
/*     */     }
/* 383 */     if ((obj instanceof String)) {
/* 384 */       return coerce((String)obj);
/*     */     }
/* 386 */     if ((obj instanceof Character)) {
/* 387 */       return coerce(Short.valueOf((short)((Character)obj).charValue()));
/*     */     }
/*     */     
/* 390 */     throw new IllegalArgumentException(MessageFactory.get("error.convert", new Object[] { obj, obj.getClass(), "Number" }));
/*     */   }
/*     */   
/*     */   protected abstract Number coerce(String paramString);
/*     */   
/*     */   protected abstract Number divide(Number paramNumber1, Number paramNumber2);
/*     */   
/*     */   protected abstract boolean matches(Object paramObject1, Object paramObject2);
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-el-8.5.4.jar!\org\apache\el\lang\ELArithmetic.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */