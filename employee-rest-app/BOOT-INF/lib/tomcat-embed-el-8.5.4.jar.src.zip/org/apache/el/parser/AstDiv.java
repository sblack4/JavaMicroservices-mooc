/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import javax.el.ELException;
/*    */ import org.apache.el.lang.ELArithmetic;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstDiv
/*    */   extends ArithmeticNode
/*    */ {
/*    */   public AstDiv(int id)
/*    */   {
/* 32 */     super(id);
/*    */   }
/*    */   
/*    */   public Object getValue(EvaluationContext ctx)
/*    */     throws ELException
/*    */   {
/* 38 */     Object obj0 = this.children[0].getValue(ctx);
/* 39 */     Object obj1 = this.children[1].getValue(ctx);
/* 40 */     return ELArithmetic.divide(obj0, obj1);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-el-8.5.4.jar!\org\apache\el\parser\AstDiv.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */