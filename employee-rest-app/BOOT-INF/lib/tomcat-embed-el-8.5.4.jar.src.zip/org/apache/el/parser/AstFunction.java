/*     */ package org.apache.el.parser;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.el.ELClass;
/*     */ import javax.el.ELException;
/*     */ import javax.el.ELResolver;
/*     */ import javax.el.FunctionMapper;
/*     */ import javax.el.ImportHandler;
/*     */ import javax.el.LambdaExpression;
/*     */ import javax.el.ValueExpression;
/*     */ import javax.el.VariableMapper;
/*     */ import org.apache.el.lang.EvaluationContext;
/*     */ import org.apache.el.util.MessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AstFunction
/*     */   extends SimpleNode
/*     */ {
/*  40 */   protected String localName = "";
/*     */   
/*  42 */   protected String prefix = "";
/*     */   
/*     */   public AstFunction(int id) {
/*  45 */     super(id);
/*     */   }
/*     */   
/*     */   public String getLocalName() {
/*  49 */     return this.localName;
/*     */   }
/*     */   
/*     */   public String getOutputName() {
/*  53 */     if (this.prefix == null) {
/*  54 */       return this.localName;
/*     */     }
/*  56 */     return this.prefix + ":" + this.localName;
/*     */   }
/*     */   
/*     */   public String getPrefix()
/*     */   {
/*  61 */     return this.prefix;
/*     */   }
/*     */   
/*     */ 
/*     */   public Class<?> getType(EvaluationContext ctx)
/*     */     throws ELException
/*     */   {
/*  68 */     FunctionMapper fnMapper = ctx.getFunctionMapper();
/*     */     
/*     */ 
/*  71 */     if (fnMapper == null) {
/*  72 */       throw new ELException(MessageFactory.get("error.fnMapper.null"));
/*     */     }
/*  74 */     Method m = fnMapper.resolveFunction(this.prefix, this.localName);
/*  75 */     if (m == null) {
/*  76 */       throw new ELException(MessageFactory.get("error.fnMapper.method", new Object[] { getOutputName() }));
/*     */     }
/*     */     
/*  79 */     return m.getReturnType();
/*     */   }
/*     */   
/*     */ 
/*     */   public Object getValue(EvaluationContext ctx)
/*     */     throws ELException
/*     */   {
/*  86 */     FunctionMapper fnMapper = ctx.getFunctionMapper();
/*     */     
/*     */ 
/*  89 */     if (fnMapper == null) {
/*  90 */       throw new ELException(MessageFactory.get("error.fnMapper.null"));
/*     */     }
/*  92 */     Method m = fnMapper.resolveFunction(this.prefix, this.localName);
/*     */     
/*  94 */     if ((m == null) && (this.prefix.length() == 0))
/*     */     {
/*     */ 
/*     */ 
/*  98 */       Object obj = null;
/*  99 */       if (ctx.isLambdaArgument(this.localName)) {
/* 100 */         obj = ctx.getLambdaArgument(this.localName);
/*     */       }
/* 102 */       if (obj == null) {
/* 103 */         VariableMapper varMapper = ctx.getVariableMapper();
/* 104 */         if (varMapper != null) {
/* 105 */           obj = varMapper.resolveVariable(this.localName);
/* 106 */           if ((obj instanceof ValueExpression))
/*     */           {
/* 108 */             obj = ((ValueExpression)obj).getValue(ctx);
/*     */           }
/*     */         }
/*     */       }
/* 112 */       if (obj == null) {
/* 113 */         obj = ctx.getELResolver().getValue(ctx, null, this.localName);
/*     */       }
/* 115 */       if ((obj instanceof LambdaExpression))
/*     */       {
/* 117 */         int i = 0;
/* 118 */         while (((obj instanceof LambdaExpression)) && (i < jjtGetNumChildren()))
/*     */         {
/* 120 */           Node args = jjtGetChild(i);
/* 121 */           obj = ((LambdaExpression)obj).invoke(((AstMethodParameters)args).getParameters(ctx));
/*     */           
/* 123 */           i++;
/*     */         }
/* 125 */         if (i < jjtGetNumChildren())
/*     */         {
/*     */ 
/* 128 */           throw new ELException(MessageFactory.get("error.lambda.tooManyMethodParameterSets"));
/*     */         }
/*     */         
/* 131 */         return obj;
/*     */       }
/*     */       
/*     */ 
/* 135 */       obj = ctx.getImportHandler().resolveClass(this.localName);
/* 136 */       if (obj != null) {
/* 137 */         return ctx.getELResolver().invoke(ctx, new ELClass((Class)obj), "<init>", null, ((AstMethodParameters)this.children[0]).getParameters(ctx));
/*     */       }
/*     */       
/* 140 */       obj = ctx.getImportHandler().resolveStatic(this.localName);
/* 141 */       if (obj != null) {
/* 142 */         return ctx.getELResolver().invoke(ctx, new ELClass((Class)obj), this.localName, null, ((AstMethodParameters)this.children[0]).getParameters(ctx));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 147 */     if (m == null) {
/* 148 */       throw new ELException(MessageFactory.get("error.fnMapper.method", new Object[] { getOutputName() }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 154 */     if (jjtGetNumChildren() != 1) {
/* 155 */       throw new ELException(MessageFactory.get("error.funciton.tooManyMethodParameterSets", new Object[] { getOutputName() }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 160 */     Node parameters = jjtGetChild(0);
/* 161 */     Class<?>[] paramTypes = m.getParameterTypes();
/* 162 */     Object[] params = null;
/* 163 */     Object result = null;
/* 164 */     int inputParameterCount = parameters.jjtGetNumChildren();
/* 165 */     int methodParameterCount = paramTypes.length;
/* 166 */     if (inputParameterCount > 0) {
/* 167 */       params = new Object[methodParameterCount];
/*     */       try {
/* 169 */         for (int i = 0; i < methodParameterCount; i++) {
/* 170 */           if ((m.isVarArgs()) && (i == methodParameterCount - 1)) {
/* 171 */             if (inputParameterCount < methodParameterCount) {
/* 172 */               params[i] = null;
/*     */             } else {
/* 174 */               Object[] varargs = new Object[inputParameterCount - methodParameterCount + 1];
/*     */               
/* 176 */               Class<?> target = paramTypes[i].getComponentType();
/* 177 */               for (int j = i; j < inputParameterCount; j++) {
/* 178 */                 varargs[(j - i)] = parameters.jjtGetChild(j).getValue(ctx);
/* 179 */                 varargs[(j - i)] = coerceToType(ctx, varargs[(j - i)], target);
/*     */               }
/*     */             }
/*     */           } else {
/* 183 */             params[i] = parameters.jjtGetChild(i).getValue(ctx);
/* 184 */             params[i] = coerceToType(ctx, params[i], paramTypes[i]);
/*     */           }
/*     */         }
/*     */       } catch (ELException ele) {
/* 188 */         throw new ELException(MessageFactory.get("error.function", new Object[] { getOutputName() }), ele);
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 193 */       result = m.invoke(null, params);
/*     */     } catch (IllegalAccessException iae) {
/* 195 */       throw new ELException(MessageFactory.get("error.function", new Object[] { getOutputName() }), iae);
/*     */     }
/*     */     catch (InvocationTargetException ite) {
/* 198 */       Throwable cause = ite.getCause();
/* 199 */       if ((cause instanceof ThreadDeath)) {
/* 200 */         throw ((ThreadDeath)cause);
/*     */       }
/* 202 */       if ((cause instanceof VirtualMachineError)) {
/* 203 */         throw ((VirtualMachineError)cause);
/*     */       }
/* 205 */       throw new ELException(MessageFactory.get("error.function", new Object[] { getOutputName() }), cause);
/*     */     }
/*     */     
/* 208 */     return result;
/*     */   }
/*     */   
/*     */   public void setLocalName(String localName) {
/* 212 */     this.localName = localName;
/*     */   }
/*     */   
/*     */   public void setPrefix(String prefix) {
/* 216 */     this.prefix = prefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 223 */     return ELParserTreeConstants.jjtNodeName[this.id] + "[" + getOutputName() + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-el-8.5.4.jar!\org\apache\el\parser\AstFunction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */