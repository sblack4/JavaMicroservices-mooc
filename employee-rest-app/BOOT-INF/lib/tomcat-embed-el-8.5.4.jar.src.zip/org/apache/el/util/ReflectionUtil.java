/*     */ package org.apache.el.util;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.el.ELException;
/*     */ import javax.el.MethodNotFoundException;
/*     */ import org.apache.el.lang.ELSupport;
/*     */ import org.apache.el.lang.EvaluationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectionUtil
/*     */ {
/*  41 */   protected static final String[] PRIMITIVE_NAMES = { "boolean", "byte", "char", "double", "float", "int", "long", "short", "void" };
/*     */   
/*     */ 
/*  44 */   protected static final Class<?>[] PRIMITIVES = { Boolean.TYPE, Byte.TYPE, Character.TYPE, Double.TYPE, Float.TYPE, Integer.TYPE, Long.TYPE, Short.TYPE, Void.TYPE };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> forName(String name)
/*     */     throws ClassNotFoundException
/*     */   {
/*  53 */     if ((null == name) || ("".equals(name))) {
/*  54 */       return null;
/*     */     }
/*  56 */     Class<?> c = forNamePrimitive(name);
/*  57 */     if (c == null) {
/*  58 */       if (name.endsWith("[]")) {
/*  59 */         String nc = name.substring(0, name.length() - 2);
/*  60 */         c = Class.forName(nc, true, Thread.currentThread().getContextClassLoader());
/*  61 */         c = Array.newInstance(c, 0).getClass();
/*     */       } else {
/*  63 */         c = Class.forName(name, true, Thread.currentThread().getContextClassLoader());
/*     */       }
/*     */     }
/*  66 */     return c;
/*     */   }
/*     */   
/*     */   protected static Class<?> forNamePrimitive(String name) {
/*  70 */     if (name.length() <= 8) {
/*  71 */       int p = Arrays.binarySearch(PRIMITIVE_NAMES, name);
/*  72 */       if (p >= 0) {
/*  73 */         return PRIMITIVES[p];
/*     */       }
/*     */     }
/*  76 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?>[] toTypeArray(String[] s)
/*     */     throws ClassNotFoundException
/*     */   {
/*  88 */     if (s == null)
/*  89 */       return null;
/*  90 */     Class<?>[] c = new Class[s.length];
/*  91 */     for (int i = 0; i < s.length; i++) {
/*  92 */       c[i] = forName(s[i]);
/*     */     }
/*  94 */     return c;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String[] toTypeNameArray(Class<?>[] c)
/*     */   {
/* 104 */     if (c == null)
/* 105 */       return null;
/* 106 */     String[] s = new String[c.length];
/* 107 */     for (int i = 0; i < c.length; i++) {
/* 108 */       s[i] = c[i].getName();
/*     */     }
/* 110 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Method getMethod(EvaluationContext ctx, Object base, Object property, Class<?>[] paramTypes, Object[] paramValues)
/*     */     throws MethodNotFoundException
/*     */   {
/* 132 */     if ((base == null) || (property == null)) {
/* 133 */       throw new MethodNotFoundException(MessageFactory.get("error.method.notfound", new Object[] { base, property, paramString(paramTypes) }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 138 */     String methodName = (property instanceof String) ? (String)property : property.toString();
/*     */     
/*     */     int paramCount;
/*     */     int paramCount;
/* 142 */     if (paramTypes == null) {
/* 143 */       paramCount = 0;
/*     */     } else {
/* 145 */       paramCount = paramTypes.length;
/*     */     }
/*     */     
/* 148 */     Method[] methods = base.getClass().getMethods();
/* 149 */     Map<Method, MatchResult> candidates = new HashMap();
/*     */     
/* 151 */     for (Method m : methods) {
/* 152 */       if (m.getName().equals(methodName))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 157 */         Class<?>[] mParamTypes = m.getParameterTypes();
/*     */         int mParamCount;
/* 159 */         int mParamCount; if (mParamTypes == null) {
/* 160 */           mParamCount = 0;
/*     */         } else {
/* 162 */           mParamCount = mParamTypes.length;
/*     */         }
/*     */         
/*     */ 
/* 166 */         if ((paramCount == mParamCount) || ((m.isVarArgs()) && (paramCount >= mParamCount)))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 173 */           int exactMatch = 0;
/* 174 */           int assignableMatch = 0;
/* 175 */           int coercibleMatch = 0;
/* 176 */           boolean noMatch = false;
/* 177 */           for (int i = 0; i < mParamCount; i++)
/*     */           {
/* 179 */             if (mParamTypes[i].equals(paramTypes[i])) {
/* 180 */               exactMatch++;
/* 181 */             } else if ((i == mParamCount - 1) && (m.isVarArgs())) {
/* 182 */               Class<?> varType = mParamTypes[i].getComponentType();
/* 183 */               for (int j = i; j < paramCount; j++) {
/* 184 */                 if (isAssignableFrom(paramTypes[j], varType)) {
/* 185 */                   assignableMatch++;
/*     */                 } else {
/* 187 */                   if (paramValues == null) {
/* 188 */                     noMatch = true;
/* 189 */                     break;
/*     */                   }
/* 191 */                   if (isCoercibleFrom(ctx, paramValues[j], varType)) {
/* 192 */                     coercibleMatch++;
/*     */                   } else {
/* 194 */                     noMatch = true;
/* 195 */                     break;
/*     */                   }
/*     */                   
/*     */                 }
/*     */                 
/*     */               }
/*     */               
/*     */             }
/* 203 */             else if (isAssignableFrom(paramTypes[i], mParamTypes[i])) {
/* 204 */               assignableMatch++;
/*     */             } else {
/* 206 */               if (paramValues == null) {
/* 207 */                 noMatch = true;
/* 208 */                 break;
/*     */               }
/* 210 */               if (isCoercibleFrom(ctx, paramValues[i], mParamTypes[i])) {
/* 211 */                 coercibleMatch++;
/*     */               } else {
/* 213 */                 noMatch = true;
/* 214 */                 break;
/*     */               }
/*     */             }
/*     */           }
/*     */           
/* 219 */           if (!noMatch)
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 225 */             if (exactMatch == paramCount) {
/* 226 */               return getMethod(base.getClass(), m);
/*     */             }
/*     */             
/* 229 */             candidates.put(m, new MatchResult(exactMatch, assignableMatch, coercibleMatch, m.isBridge()));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 235 */     MatchResult bestMatch = new MatchResult(0, 0, 0, false);
/* 236 */     Method match = null;
/* 237 */     boolean multiple = false;
/* 238 */     for (Map.Entry<Method, MatchResult> entry : candidates.entrySet()) {
/* 239 */       int cmp = ((MatchResult)entry.getValue()).compareTo(bestMatch);
/* 240 */       if ((cmp > 0) || (match == null)) {
/* 241 */         bestMatch = (MatchResult)entry.getValue();
/* 242 */         match = (Method)entry.getKey();
/* 243 */         multiple = false;
/* 244 */       } else if (cmp == 0) {
/* 245 */         multiple = true;
/*     */       }
/*     */     }
/* 248 */     if (multiple) {
/* 249 */       if (bestMatch.getExact() == paramCount - 1)
/*     */       {
/*     */ 
/* 252 */         match = resolveAmbiguousMethod(candidates.keySet(), paramTypes);
/*     */       } else {
/* 254 */         match = null;
/*     */       }
/*     */       
/* 257 */       if (match == null)
/*     */       {
/*     */ 
/* 260 */         throw new MethodNotFoundException(MessageFactory.get("error.method.ambiguous", new Object[] { base, property, paramString(paramTypes) }));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 267 */     if (match == null) {
/* 268 */       throw new MethodNotFoundException(MessageFactory.get("error.method.notfound", new Object[] { base, property, paramString(paramTypes) }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 273 */     return getMethod(base.getClass(), match);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Method resolveAmbiguousMethod(Set<Method> candidates, Class<?>[] paramTypes)
/*     */   {
/* 283 */     Method m = (Method)candidates.iterator().next();
/*     */     
/* 285 */     int nonMatchIndex = 0;
/* 286 */     Class<?> nonMatchClass = null;
/*     */     
/* 288 */     for (int i = 0; i < paramTypes.length; i++) {
/* 289 */       if (m.getParameterTypes()[i] != paramTypes[i]) {
/* 290 */         nonMatchIndex = i;
/* 291 */         nonMatchClass = paramTypes[i];
/* 292 */         break;
/*     */       }
/*     */     }
/*     */     
/* 296 */     if (nonMatchClass == null)
/*     */     {
/* 298 */       return null;
/*     */     }
/*     */     
/* 301 */     for (Method c : candidates) {
/* 302 */       if (c.getParameterTypes()[nonMatchIndex] == paramTypes[nonMatchIndex])
/*     */       {
/*     */ 
/*     */ 
/* 306 */         return null;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 311 */     Class<?> superClass = nonMatchClass.getSuperclass();
/* 312 */     while (superClass != null) {
/* 313 */       for (Method c : candidates) {
/* 314 */         if (c.getParameterTypes()[nonMatchIndex].equals(superClass))
/*     */         {
/* 316 */           return c;
/*     */         }
/*     */       }
/* 319 */       superClass = superClass.getSuperclass();
/*     */     }
/*     */     
/*     */ 
/* 323 */     Method match = null;
/* 324 */     if (Number.class.isAssignableFrom(nonMatchClass)) {
/* 325 */       for (Method c : candidates) {
/* 326 */         Class<?> candidateType = c.getParameterTypes()[nonMatchIndex];
/* 327 */         if ((Number.class.isAssignableFrom(candidateType)) || (candidateType.isPrimitive()))
/*     */         {
/* 329 */           if (match == null) {
/* 330 */             match = c;
/*     */           }
/*     */           else {
/* 333 */             match = null;
/* 334 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 340 */     return match;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isAssignableFrom(Class<?> src, Class<?> target)
/*     */   {
/* 352 */     if (src == null) {
/* 353 */       return true;
/*     */     }
/*     */     Class<?> targetClass;
/*     */     Class<?> targetClass;
/* 357 */     if (target.isPrimitive()) { Class<?> targetClass;
/* 358 */       if (target == Boolean.TYPE) {
/* 359 */         targetClass = Boolean.class; } else { Class<?> targetClass;
/* 360 */         if (target == Character.TYPE) {
/* 361 */           targetClass = Character.class; } else { Class<?> targetClass;
/* 362 */           if (target == Byte.TYPE) {
/* 363 */             targetClass = Byte.class; } else { Class<?> targetClass;
/* 364 */             if (target == Short.TYPE) {
/* 365 */               targetClass = Short.class; } else { Class<?> targetClass;
/* 366 */               if (target == Integer.TYPE) {
/* 367 */                 targetClass = Integer.class; } else { Class<?> targetClass;
/* 368 */                 if (target == Long.TYPE) {
/* 369 */                   targetClass = Long.class; } else { Class<?> targetClass;
/* 370 */                   if (target == Float.TYPE) {
/* 371 */                     targetClass = Float.class;
/*     */                   } else
/* 373 */                     targetClass = Double.class;
/*     */                 }
/*     */               }
/* 376 */             } } } } } else { targetClass = target;
/*     */     }
/* 378 */     return targetClass.isAssignableFrom(src);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isCoercibleFrom(EvaluationContext ctx, Object src, Class<?> target)
/*     */   {
/*     */     try
/*     */     {
/* 390 */       ELSupport.coerceToType(ctx, src, target);
/*     */     } catch (ELException e) {
/* 392 */       return false;
/*     */     }
/* 394 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Method getMethod(Class<?> type, Method m)
/*     */   {
/* 403 */     if ((m == null) || (Modifier.isPublic(type.getModifiers()))) {
/* 404 */       return m;
/*     */     }
/* 406 */     Class<?>[] inf = type.getInterfaces();
/* 407 */     Method mp = null;
/* 408 */     for (int i = 0; i < inf.length; i++) {
/*     */       try {
/* 410 */         mp = inf[i].getMethod(m.getName(), m.getParameterTypes());
/* 411 */         mp = getMethod(mp.getDeclaringClass(), mp);
/* 412 */         if (mp != null) {
/* 413 */           return mp;
/*     */         }
/*     */       }
/*     */       catch (NoSuchMethodException localNoSuchMethodException) {}
/*     */     }
/*     */     
/* 419 */     Class<?> sup = type.getSuperclass();
/* 420 */     if (sup != null) {
/*     */       try {
/* 422 */         mp = sup.getMethod(m.getName(), m.getParameterTypes());
/* 423 */         mp = getMethod(mp.getDeclaringClass(), mp);
/* 424 */         if (mp != null) {
/* 425 */           return mp;
/*     */         }
/*     */       }
/*     */       catch (NoSuchMethodException localNoSuchMethodException1) {}
/*     */     }
/*     */     
/* 431 */     return null;
/*     */   }
/*     */   
/*     */   private static final String paramString(Class<?>[] types)
/*     */   {
/* 436 */     if (types != null) {
/* 437 */       StringBuilder sb = new StringBuilder();
/* 438 */       for (int i = 0; i < types.length; i++) {
/* 439 */         if (types[i] == null) {
/* 440 */           sb.append("null, ");
/*     */         } else {
/* 442 */           sb.append(types[i].getName()).append(", ");
/*     */         }
/*     */       }
/* 445 */       if (sb.length() > 2) {
/* 446 */         sb.setLength(sb.length() - 2);
/*     */       }
/* 448 */       return sb.toString();
/*     */     }
/* 450 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   private static class MatchResult
/*     */     implements Comparable<MatchResult>
/*     */   {
/*     */     private final int exact;
/*     */     
/*     */     private final int assignable;
/*     */     private final int coercible;
/*     */     private final boolean bridge;
/*     */     
/*     */     public MatchResult(int exact, int assignable, int coercible, boolean bridge)
/*     */     {
/* 465 */       this.exact = exact;
/* 466 */       this.assignable = assignable;
/* 467 */       this.coercible = coercible;
/* 468 */       this.bridge = bridge;
/*     */     }
/*     */     
/*     */     public int getExact() {
/* 472 */       return this.exact;
/*     */     }
/*     */     
/*     */     public int getAssignable() {
/* 476 */       return this.assignable;
/*     */     }
/*     */     
/*     */     public int getCoercible() {
/* 480 */       return this.coercible;
/*     */     }
/*     */     
/*     */     public boolean isBridge() {
/* 484 */       return this.bridge;
/*     */     }
/*     */     
/*     */     public int compareTo(MatchResult o)
/*     */     {
/* 489 */       int cmp = Integer.compare(getExact(), o.getExact());
/* 490 */       if (cmp == 0) {
/* 491 */         cmp = Integer.compare(getAssignable(), o.getAssignable());
/* 492 */         if (cmp == 0) {
/* 493 */           cmp = Integer.compare(getCoercible(), o.getCoercible());
/* 494 */           if (cmp == 0)
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/* 499 */             cmp = Boolean.compare(o.isBridge(), isBridge());
/*     */           }
/*     */         }
/*     */       }
/* 503 */       return cmp;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-el-8.5.4.jar!\org\apache\el\util\ReflectionUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */