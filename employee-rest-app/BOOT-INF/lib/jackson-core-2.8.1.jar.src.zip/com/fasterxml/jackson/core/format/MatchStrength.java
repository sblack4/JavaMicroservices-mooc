package com.fasterxml.jackson.core.format;

public enum MatchStrength
{
  NO_MATCH,  INCONCLUSIVE,  WEAK_MATCH,  SOLID_MATCH,  FULL_MATCH;
  
  private MatchStrength() {}
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\jackson-core-2.8.1.jar!\com\fasterxml\jackson\core\format\MatchStrength.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */