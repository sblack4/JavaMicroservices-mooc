package com.fasterxml.jackson.core.util;

public abstract interface Instantiatable<T>
{
  public abstract T createInstance();
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\jackson-core-2.8.1.jar!\com\fasterxml\jackson\core\util\Instantiatable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */