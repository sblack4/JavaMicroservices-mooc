/*     */ package org.springframework.expression;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpressionException
/*     */   extends RuntimeException
/*     */ {
/*     */   protected String expressionString;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int position;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExpressionException(String expressionString, String message)
/*     */   {
/*  39 */     super(message);
/*  40 */     this.position = -1;
/*  41 */     this.expressionString = expressionString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExpressionException(String expressionString, int position, String message)
/*     */   {
/*  51 */     super(message);
/*  52 */     this.position = position;
/*  53 */     this.expressionString = expressionString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExpressionException(int position, String message)
/*     */   {
/*  62 */     super(message);
/*  63 */     this.position = position;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExpressionException(int position, String message, Throwable cause)
/*     */   {
/*  73 */     super(message, cause);
/*  74 */     this.position = position;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExpressionException(String message)
/*     */   {
/*  82 */     super(message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExpressionException(String message, Throwable cause)
/*     */   {
/*  91 */     super(message, cause);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getExpressionString()
/*     */   {
/*  99 */     return this.expressionString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final int getPosition()
/*     */   {
/* 106 */     return this.position;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage()
/*     */   {
/* 116 */     return toDetailedString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toDetailedString()
/*     */   {
/* 124 */     if (this.expressionString != null) {
/* 125 */       StringBuilder output = new StringBuilder();
/* 126 */       output.append("Expression '");
/* 127 */       output.append(this.expressionString);
/* 128 */       output.append("'");
/* 129 */       if (this.position != -1) {
/* 130 */         output.append(" @ ");
/* 131 */         output.append(this.position);
/*     */       }
/* 133 */       output.append(": ");
/* 134 */       output.append(getSimpleMessage());
/* 135 */       return output.toString();
/*     */     }
/*     */     
/* 138 */     return getSimpleMessage();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSimpleMessage()
/*     */   {
/* 147 */     return super.getMessage();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\ExpressionException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */