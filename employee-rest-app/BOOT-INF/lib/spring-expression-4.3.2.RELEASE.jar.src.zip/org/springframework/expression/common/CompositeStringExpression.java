/*     */ package org.springframework.expression.common;
/*     */ 
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.TypedValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompositeStringExpression
/*     */   implements Expression
/*     */ {
/*     */   private final String expressionString;
/*     */   private final Expression[] expressions;
/*     */   
/*     */   public CompositeStringExpression(String expressionString, Expression[] expressions)
/*     */   {
/*  51 */     this.expressionString = expressionString;
/*  52 */     this.expressions = expressions;
/*     */   }
/*     */   
/*     */ 
/*     */   public final String getExpressionString()
/*     */   {
/*  58 */     return this.expressionString;
/*     */   }
/*     */   
/*     */   public String getValue() throws EvaluationException
/*     */   {
/*  63 */     StringBuilder sb = new StringBuilder();
/*  64 */     for (Expression expression : this.expressions) {
/*  65 */       String value = (String)expression.getValue(String.class);
/*  66 */       if (value != null) {
/*  67 */         sb.append(value);
/*     */       }
/*     */     }
/*  70 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public String getValue(Object rootObject) throws EvaluationException
/*     */   {
/*  75 */     StringBuilder sb = new StringBuilder();
/*  76 */     for (Expression expression : this.expressions) {
/*  77 */       String value = (String)expression.getValue(rootObject, String.class);
/*  78 */       if (value != null) {
/*  79 */         sb.append(value);
/*     */       }
/*     */     }
/*  82 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public String getValue(EvaluationContext context) throws EvaluationException
/*     */   {
/*  87 */     StringBuilder sb = new StringBuilder();
/*  88 */     for (Expression expression : this.expressions) {
/*  89 */       String value = (String)expression.getValue(context, String.class);
/*  90 */       if (value != null) {
/*  91 */         sb.append(value);
/*     */       }
/*     */     }
/*  94 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public String getValue(EvaluationContext context, Object rootObject) throws EvaluationException
/*     */   {
/*  99 */     StringBuilder sb = new StringBuilder();
/* 100 */     for (Expression expression : this.expressions) {
/* 101 */       String value = (String)expression.getValue(context, rootObject, String.class);
/* 102 */       if (value != null) {
/* 103 */         sb.append(value);
/*     */       }
/*     */     }
/* 106 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public Class<?> getValueType(EvaluationContext context)
/*     */   {
/* 111 */     return String.class;
/*     */   }
/*     */   
/*     */   public Class<?> getValueType()
/*     */   {
/* 116 */     return String.class;
/*     */   }
/*     */   
/*     */   public TypeDescriptor getValueTypeDescriptor(EvaluationContext context)
/*     */   {
/* 121 */     return TypeDescriptor.valueOf(String.class);
/*     */   }
/*     */   
/*     */   public TypeDescriptor getValueTypeDescriptor()
/*     */   {
/* 126 */     return TypeDescriptor.valueOf(String.class);
/*     */   }
/*     */   
/*     */   public void setValue(EvaluationContext context, Object value) throws EvaluationException
/*     */   {
/* 131 */     throw new EvaluationException(this.expressionString, "Cannot call setValue on a composite expression");
/*     */   }
/*     */   
/*     */   public <T> T getValue(EvaluationContext context, Class<T> expectedResultType) throws EvaluationException
/*     */   {
/* 136 */     Object value = getValue(context);
/* 137 */     return (T)ExpressionUtils.convertTypedValue(context, new TypedValue(value), expectedResultType);
/*     */   }
/*     */   
/*     */   public <T> T getValue(Class<T> expectedResultType) throws EvaluationException
/*     */   {
/* 142 */     Object value = getValue();
/* 143 */     return (T)ExpressionUtils.convertTypedValue(null, new TypedValue(value), expectedResultType);
/*     */   }
/*     */   
/*     */   public boolean isWritable(EvaluationContext context)
/*     */   {
/* 148 */     return false;
/*     */   }
/*     */   
/*     */   public Expression[] getExpressions() {
/* 152 */     return this.expressions;
/*     */   }
/*     */   
/*     */   public <T> T getValue(Object rootObject, Class<T> desiredResultType)
/*     */     throws EvaluationException
/*     */   {
/* 158 */     Object value = getValue(rootObject);
/* 159 */     return (T)ExpressionUtils.convertTypedValue(null, new TypedValue(value), desiredResultType);
/*     */   }
/*     */   
/*     */   public <T> T getValue(EvaluationContext context, Object rootObject, Class<T> desiredResultType)
/*     */     throws EvaluationException
/*     */   {
/* 165 */     Object value = getValue(context, rootObject);
/* 166 */     return (T)ExpressionUtils.convertTypedValue(context, new TypedValue(value), desiredResultType);
/*     */   }
/*     */   
/*     */   public Class<?> getValueType(Object rootObject) throws EvaluationException
/*     */   {
/* 171 */     return String.class;
/*     */   }
/*     */   
/*     */   public Class<?> getValueType(EvaluationContext context, Object rootObject) throws EvaluationException
/*     */   {
/* 176 */     return String.class;
/*     */   }
/*     */   
/*     */   public TypeDescriptor getValueTypeDescriptor(Object rootObject) throws EvaluationException
/*     */   {
/* 181 */     return TypeDescriptor.valueOf(String.class);
/*     */   }
/*     */   
/*     */   public TypeDescriptor getValueTypeDescriptor(EvaluationContext context, Object rootObject) throws EvaluationException
/*     */   {
/* 186 */     return TypeDescriptor.valueOf(String.class);
/*     */   }
/*     */   
/*     */   public boolean isWritable(EvaluationContext context, Object rootObject) throws EvaluationException
/*     */   {
/* 191 */     return false;
/*     */   }
/*     */   
/*     */   public void setValue(EvaluationContext context, Object rootObject, Object value) throws EvaluationException
/*     */   {
/* 196 */     throw new EvaluationException(this.expressionString, "Cannot call setValue on a composite expression");
/*     */   }
/*     */   
/*     */   public boolean isWritable(Object rootObject) throws EvaluationException
/*     */   {
/* 201 */     return false;
/*     */   }
/*     */   
/*     */   public void setValue(Object rootObject, Object value) throws EvaluationException
/*     */   {
/* 206 */     throw new EvaluationException(this.expressionString, "Cannot call setValue on a composite expression");
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\common\CompositeStringExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */