/*     */ package org.springframework.expression.common;
/*     */ 
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.TypedValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LiteralExpression
/*     */   implements Expression
/*     */ {
/*     */   private final String literalValue;
/*     */   
/*     */   public LiteralExpression(String literalValue)
/*     */   {
/*  41 */     this.literalValue = literalValue;
/*     */   }
/*     */   
/*     */ 
/*     */   public final String getExpressionString()
/*     */   {
/*  47 */     return this.literalValue;
/*     */   }
/*     */   
/*     */   public String getValue()
/*     */   {
/*  52 */     return this.literalValue;
/*     */   }
/*     */   
/*     */   public String getValue(EvaluationContext context)
/*     */   {
/*  57 */     return this.literalValue;
/*     */   }
/*     */   
/*     */   public String getValue(Object rootObject)
/*     */   {
/*  62 */     return this.literalValue;
/*     */   }
/*     */   
/*     */   public Class<?> getValueType(EvaluationContext context)
/*     */   {
/*  67 */     return String.class;
/*     */   }
/*     */   
/*     */   public TypeDescriptor getValueTypeDescriptor(EvaluationContext context)
/*     */   {
/*  72 */     return TypeDescriptor.valueOf(String.class);
/*     */   }
/*     */   
/*     */   public TypeDescriptor getValueTypeDescriptor()
/*     */   {
/*  77 */     return TypeDescriptor.valueOf(String.class);
/*     */   }
/*     */   
/*     */   public void setValue(EvaluationContext context, Object value) throws EvaluationException
/*     */   {
/*  82 */     throw new EvaluationException(this.literalValue, "Cannot call setValue() on a LiteralExpression");
/*     */   }
/*     */   
/*     */   public <T> T getValue(EvaluationContext context, Class<T> expectedResultType) throws EvaluationException
/*     */   {
/*  87 */     Object value = getValue(context);
/*  88 */     return (T)ExpressionUtils.convertTypedValue(context, new TypedValue(value), expectedResultType);
/*     */   }
/*     */   
/*     */   public <T> T getValue(Class<T> expectedResultType) throws EvaluationException
/*     */   {
/*  93 */     Object value = getValue();
/*  94 */     return (T)ExpressionUtils.convertTypedValue(null, new TypedValue(value), expectedResultType);
/*     */   }
/*     */   
/*     */   public boolean isWritable(EvaluationContext context)
/*     */   {
/*  99 */     return false;
/*     */   }
/*     */   
/*     */   public Class<?> getValueType()
/*     */   {
/* 104 */     return String.class;
/*     */   }
/*     */   
/*     */   public <T> T getValue(Object rootObject, Class<T> desiredResultType) throws EvaluationException
/*     */   {
/* 109 */     Object value = getValue(rootObject);
/* 110 */     return (T)ExpressionUtils.convertTypedValue(null, new TypedValue(value), desiredResultType);
/*     */   }
/*     */   
/*     */   public String getValue(EvaluationContext context, Object rootObject) throws EvaluationException
/*     */   {
/* 115 */     return this.literalValue;
/*     */   }
/*     */   
/*     */   public <T> T getValue(EvaluationContext context, Object rootObject, Class<T> desiredResultType) throws EvaluationException
/*     */   {
/* 120 */     Object value = getValue(context, rootObject);
/* 121 */     return (T)ExpressionUtils.convertTypedValue(context, new TypedValue(value), desiredResultType);
/*     */   }
/*     */   
/*     */   public Class<?> getValueType(Object rootObject) throws EvaluationException
/*     */   {
/* 126 */     return String.class;
/*     */   }
/*     */   
/*     */   public Class<?> getValueType(EvaluationContext context, Object rootObject) throws EvaluationException
/*     */   {
/* 131 */     return String.class;
/*     */   }
/*     */   
/*     */   public TypeDescriptor getValueTypeDescriptor(Object rootObject) throws EvaluationException
/*     */   {
/* 136 */     return TypeDescriptor.valueOf(String.class);
/*     */   }
/*     */   
/*     */   public TypeDescriptor getValueTypeDescriptor(EvaluationContext context, Object rootObject) throws EvaluationException
/*     */   {
/* 141 */     return TypeDescriptor.valueOf(String.class);
/*     */   }
/*     */   
/*     */   public boolean isWritable(EvaluationContext context, Object rootObject) throws EvaluationException
/*     */   {
/* 146 */     return false;
/*     */   }
/*     */   
/*     */   public void setValue(EvaluationContext context, Object rootObject, Object value) throws EvaluationException
/*     */   {
/* 151 */     throw new EvaluationException(this.literalValue, "Cannot call setValue() on a LiteralExpression");
/*     */   }
/*     */   
/*     */   public boolean isWritable(Object rootObject) throws EvaluationException
/*     */   {
/* 156 */     return false;
/*     */   }
/*     */   
/*     */   public void setValue(Object rootObject, Object value) throws EvaluationException
/*     */   {
/* 161 */     throw new EvaluationException(this.literalValue, "Cannot call setValue() on a LiteralExpression");
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\common\LiteralExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */