/*     */ package org.springframework.expression.common;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Stack;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.ExpressionParser;
/*     */ import org.springframework.expression.ParseException;
/*     */ import org.springframework.expression.ParserContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TemplateAwareExpressionParser
/*     */   implements ExpressionParser
/*     */ {
/*  42 */   private static final ParserContext NON_TEMPLATE_PARSER_CONTEXT = new ParserContext()
/*     */   {
/*     */     public String getExpressionPrefix()
/*     */     {
/*  46 */       return null;
/*     */     }
/*     */     
/*     */     public String getExpressionSuffix()
/*     */     {
/*  51 */       return null;
/*     */     }
/*     */     
/*     */     public boolean isTemplate()
/*     */     {
/*  56 */       return false;
/*     */     }
/*     */   };
/*     */   
/*     */   public Expression parseExpression(String expressionString) throws ParseException
/*     */   {
/*  62 */     return parseExpression(expressionString, NON_TEMPLATE_PARSER_CONTEXT);
/*     */   }
/*     */   
/*     */   public Expression parseExpression(String expressionString, ParserContext context)
/*     */     throws ParseException
/*     */   {
/*  68 */     if (context == null) {
/*  69 */       context = NON_TEMPLATE_PARSER_CONTEXT;
/*     */     }
/*     */     
/*  72 */     if (context.isTemplate()) {
/*  73 */       return parseTemplate(expressionString, context);
/*     */     }
/*     */     
/*  76 */     return doParseExpression(expressionString, context);
/*     */   }
/*     */   
/*     */   private Expression parseTemplate(String expressionString, ParserContext context)
/*     */     throws ParseException
/*     */   {
/*  82 */     if (expressionString.length() == 0) {
/*  83 */       return new LiteralExpression("");
/*     */     }
/*  85 */     Expression[] expressions = parseExpressions(expressionString, context);
/*  86 */     if (expressions.length == 1) {
/*  87 */       return expressions[0];
/*     */     }
/*     */     
/*  90 */     return new CompositeStringExpression(expressionString, expressions);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Expression[] parseExpressions(String expressionString, ParserContext context)
/*     */     throws ParseException
/*     */   {
/* 114 */     List<Expression> expressions = new LinkedList();
/* 115 */     String prefix = context.getExpressionPrefix();
/* 116 */     String suffix = context.getExpressionSuffix();
/* 117 */     int startIdx = 0;
/* 118 */     while (startIdx < expressionString.length()) {
/* 119 */       int prefixIndex = expressionString.indexOf(prefix, startIdx);
/* 120 */       if (prefixIndex >= startIdx)
/*     */       {
/* 122 */         if (prefixIndex > startIdx) {
/* 123 */           expressions.add(createLiteralExpression(context, expressionString
/* 124 */             .substring(startIdx, prefixIndex)));
/*     */         }
/* 126 */         int afterPrefixIndex = prefixIndex + prefix.length();
/* 127 */         int suffixIndex = skipToCorrectEndSuffix(prefix, suffix, expressionString, afterPrefixIndex);
/*     */         
/*     */ 
/* 130 */         if (suffixIndex == -1)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 135 */           throw new ParseException(expressionString, prefixIndex, "No ending suffix '" + suffix + "' for expression starting at character " + prefixIndex + ": " + expressionString.substring(prefixIndex));
/*     */         }
/*     */         
/* 138 */         if (suffixIndex == afterPrefixIndex) {
/* 139 */           throw new ParseException(expressionString, prefixIndex, "No expression defined within delimiter '" + prefix + suffix + "' at character " + prefixIndex);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 144 */         String expr = expressionString.substring(prefixIndex + prefix.length(), suffixIndex);
/*     */         
/* 146 */         expr = expr.trim();
/*     */         
/* 148 */         if (expr.length() == 0) {
/* 149 */           throw new ParseException(expressionString, prefixIndex, "No expression defined within delimiter '" + prefix + suffix + "' at character " + prefixIndex);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 154 */         expressions.add(doParseExpression(expr, context));
/* 155 */         startIdx = suffixIndex + suffix.length();
/*     */       }
/*     */       else
/*     */       {
/* 159 */         expressions.add(createLiteralExpression(context, expressionString
/* 160 */           .substring(startIdx)));
/* 161 */         startIdx = expressionString.length();
/*     */       }
/*     */     }
/* 164 */     return (Expression[])expressions.toArray(new Expression[expressions.size()]);
/*     */   }
/*     */   
/*     */   private Expression createLiteralExpression(ParserContext context, String text) {
/* 168 */     return new LiteralExpression(text);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isSuffixHere(String expressionString, int pos, String suffix)
/*     */   {
/* 179 */     int suffixPosition = 0;
/* 180 */     for (int i = 0; (i < suffix.length()) && (pos < expressionString.length()); i++) {
/* 181 */       if (expressionString.charAt(pos++) != suffix.charAt(suffixPosition++)) {
/* 182 */         return false;
/*     */       }
/*     */     }
/* 185 */     if (suffixPosition != suffix.length())
/*     */     {
/* 187 */       return false;
/*     */     }
/* 189 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int skipToCorrectEndSuffix(String prefix, String suffix, String expressionString, int afterPrefixIndex)
/*     */     throws ParseException
/*     */   {
/* 207 */     int pos = afterPrefixIndex;
/* 208 */     int maxlen = expressionString.length();
/* 209 */     int nextSuffix = expressionString.indexOf(suffix, afterPrefixIndex);
/* 210 */     if (nextSuffix == -1) {
/* 211 */       return -1;
/*     */     }
/* 213 */     Stack<Bracket> stack = new Stack();
/* 214 */     while ((pos < maxlen) && (
/* 215 */       (!isSuffixHere(expressionString, pos, suffix)) || (!stack.isEmpty())))
/*     */     {
/*     */ 
/* 218 */       char ch = expressionString.charAt(pos);
/* 219 */       switch (ch) {
/*     */       case '(': 
/*     */       case '[': 
/*     */       case '{': 
/* 223 */         stack.push(new Bracket(ch, pos));
/* 224 */         break;
/*     */       case ')': 
/*     */       case ']': 
/*     */       case '}': 
/* 228 */         if (stack.isEmpty())
/*     */         {
/*     */ 
/* 231 */           throw new ParseException(expressionString, pos, "Found closing '" + ch + "' at position " + pos + " without an opening '" + Bracket.theOpenBracketFor(ch) + "'");
/*     */         }
/* 233 */         Bracket p = (Bracket)stack.pop();
/* 234 */         if (!p.compatibleWithCloseBracket(ch)) {
/* 235 */           throw new ParseException(expressionString, pos, "Found closing '" + ch + "' at position " + pos + " but most recent opening is '" + p.bracket + "' at position " + p.pos);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */         break;
/*     */       case '"': 
/*     */       case '\'': 
/* 244 */         int endLiteral = expressionString.indexOf(ch, pos + 1);
/* 245 */         if (endLiteral == -1) {
/* 246 */           throw new ParseException(expressionString, pos, "Found non terminating string literal starting at position " + pos);
/*     */         }
/*     */         
/*     */ 
/* 250 */         pos = endLiteral;
/*     */       }
/*     */       
/* 253 */       pos++;
/*     */     }
/* 255 */     if (!stack.isEmpty()) {
/* 256 */       Bracket p = (Bracket)stack.pop();
/*     */       
/* 258 */       throw new ParseException(expressionString, p.pos, "Missing closing '" + Bracket.theCloseBracketFor(p.bracket) + "' for '" + p.bracket + "' at position " + p.pos);
/*     */     }
/*     */     
/* 261 */     if (!isSuffixHere(expressionString, pos, suffix)) {
/* 262 */       return -1;
/*     */     }
/* 264 */     return pos;
/*     */   }
/*     */   
/*     */ 
/*     */   protected abstract Expression doParseExpression(String paramString, ParserContext paramParserContext)
/*     */     throws ParseException;
/*     */   
/*     */ 
/*     */   private static class Bracket
/*     */   {
/*     */     char bracket;
/*     */     
/*     */     int pos;
/*     */     
/*     */ 
/*     */     Bracket(char bracket, int pos)
/*     */     {
/* 281 */       this.bracket = bracket;
/* 282 */       this.pos = pos;
/*     */     }
/*     */     
/*     */     boolean compatibleWithCloseBracket(char closeBracket) {
/* 286 */       if (this.bracket == '{') {
/* 287 */         return closeBracket == '}';
/*     */       }
/* 289 */       if (this.bracket == '[') {
/* 290 */         return closeBracket == ']';
/*     */       }
/* 292 */       return closeBracket == ')';
/*     */     }
/*     */     
/*     */     static char theOpenBracketFor(char closeBracket) {
/* 296 */       if (closeBracket == '}') {
/* 297 */         return '{';
/*     */       }
/* 299 */       if (closeBracket == ']') {
/* 300 */         return '[';
/*     */       }
/* 302 */       return '(';
/*     */     }
/*     */     
/*     */     static char theCloseBracketFor(char openBracket) {
/* 306 */       if (openBracket == '{') {
/* 307 */         return '}';
/*     */       }
/* 309 */       if (openBracket == '[') {
/* 310 */         return ']';
/*     */       }
/* 312 */       return ')';
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\common\TemplateAwareExpressionParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */