/*     */ package org.springframework.expression.spel.standard;
/*     */ 
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.common.ExpressionUtils;
/*     */ import org.springframework.expression.spel.CompiledExpression;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelCompilerMode;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.expression.spel.SpelNode;
/*     */ import org.springframework.expression.spel.SpelParserConfiguration;
/*     */ import org.springframework.expression.spel.ast.SpelNodeImpl;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpelExpression
/*     */   implements Expression
/*     */ {
/*     */   private static final int INTERPRETED_COUNT_THRESHOLD = 100;
/*     */   private static final int FAILED_ATTEMPTS_THRESHOLD = 100;
/*     */   private final String expression;
/*     */   private final SpelNodeImpl ast;
/*     */   private final SpelParserConfiguration configuration;
/*     */   private EvaluationContext evaluationContext;
/*     */   private CompiledExpression compiledAst;
/*  68 */   private volatile int interpretedCount = 0;
/*     */   
/*     */ 
/*     */ 
/*  72 */   private volatile int failedAttempts = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpelExpression(String expression, SpelNodeImpl ast, SpelParserConfiguration configuration)
/*     */   {
/*  79 */     this.expression = expression;
/*  80 */     this.ast = ast;
/*  81 */     this.configuration = configuration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEvaluationContext(EvaluationContext evaluationContext)
/*     */   {
/*  90 */     this.evaluationContext = evaluationContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public EvaluationContext getEvaluationContext()
/*     */   {
/*  98 */     if (this.evaluationContext == null) {
/*  99 */       this.evaluationContext = new StandardEvaluationContext();
/*     */     }
/* 101 */     return this.evaluationContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getValue()
/*     */     throws EvaluationException
/*     */   {
/* 110 */     if (this.compiledAst != null) {
/*     */       try {
/* 112 */         TypedValue contextRoot = this.evaluationContext == null ? null : this.evaluationContext.getRootObject();
/* 113 */         return this.compiledAst.getValue(contextRoot == null ? null : contextRoot.getValue(), this.evaluationContext);
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 117 */         if (this.configuration.getCompilerMode() == SpelCompilerMode.MIXED) {
/* 118 */           this.interpretedCount = 0;
/* 119 */           this.compiledAst = null;
/*     */         }
/*     */         else
/*     */         {
/* 123 */           throw new SpelEvaluationException(ex, SpelMessage.EXCEPTION_RUNNING_COMPILED_EXPRESSION, new Object[0]);
/*     */         }
/*     */       }
/*     */     }
/* 127 */     ExpressionState expressionState = new ExpressionState(getEvaluationContext(), this.configuration);
/* 128 */     Object result = this.ast.getValue(expressionState);
/* 129 */     checkCompile(expressionState);
/* 130 */     return result;
/*     */   }
/*     */   
/*     */   public Object getValue(Object rootObject)
/*     */     throws EvaluationException
/*     */   {
/* 136 */     if (this.compiledAst != null) {
/*     */       try {
/* 138 */         return this.compiledAst.getValue(rootObject, this.evaluationContext);
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 142 */         if (this.configuration.getCompilerMode() == SpelCompilerMode.MIXED) {
/* 143 */           this.interpretedCount = 0;
/* 144 */           this.compiledAst = null;
/*     */         }
/*     */         else
/*     */         {
/* 148 */           throw new SpelEvaluationException(ex, SpelMessage.EXCEPTION_RUNNING_COMPILED_EXPRESSION, new Object[0]);
/*     */         }
/*     */       }
/*     */     }
/* 152 */     ExpressionState expressionState = new ExpressionState(getEvaluationContext(), toTypedValue(rootObject), this.configuration);
/* 153 */     Object result = this.ast.getValue(expressionState);
/* 154 */     checkCompile(expressionState);
/* 155 */     return result;
/*     */   }
/*     */   
/*     */   public <T> T getValue(Class<T> expectedResultType)
/*     */     throws EvaluationException
/*     */   {
/* 161 */     if (this.compiledAst != null) {
/*     */       try {
/* 163 */         TypedValue contextRoot = this.evaluationContext == null ? null : this.evaluationContext.getRootObject();
/* 164 */         Object result = this.compiledAst.getValue(contextRoot == null ? null : contextRoot.getValue(), this.evaluationContext);
/* 165 */         if (expectedResultType == null) {
/* 166 */           return (T)result;
/*     */         }
/*     */         
/* 169 */         return (T)ExpressionUtils.convertTypedValue(getEvaluationContext(), new TypedValue(result), expectedResultType);
/*     */ 
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 174 */         if (this.configuration.getCompilerMode() == SpelCompilerMode.MIXED) {
/* 175 */           this.interpretedCount = 0;
/* 176 */           this.compiledAst = null;
/*     */         }
/*     */         else
/*     */         {
/* 180 */           throw new SpelEvaluationException(ex, SpelMessage.EXCEPTION_RUNNING_COMPILED_EXPRESSION, new Object[0]);
/*     */         }
/*     */       }
/*     */     }
/* 184 */     ExpressionState expressionState = new ExpressionState(getEvaluationContext(), this.configuration);
/* 185 */     TypedValue typedResultValue = this.ast.getTypedValue(expressionState);
/* 186 */     checkCompile(expressionState);
/* 187 */     return (T)ExpressionUtils.convertTypedValue(expressionState.getEvaluationContext(), typedResultValue, expectedResultType);
/*     */   }
/*     */   
/*     */   public <T> T getValue(Object rootObject, Class<T> expectedResultType)
/*     */     throws EvaluationException
/*     */   {
/* 193 */     if (this.compiledAst != null) {
/*     */       try {
/* 195 */         Object result = this.compiledAst.getValue(rootObject, null);
/* 196 */         if (expectedResultType == null) {
/* 197 */           return (T)result;
/*     */         }
/*     */         
/* 200 */         return (T)ExpressionUtils.convertTypedValue(getEvaluationContext(), new TypedValue(result), expectedResultType);
/*     */ 
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 205 */         if (this.configuration.getCompilerMode() == SpelCompilerMode.MIXED) {
/* 206 */           this.interpretedCount = 0;
/* 207 */           this.compiledAst = null;
/*     */         }
/*     */         else
/*     */         {
/* 211 */           throw new SpelEvaluationException(ex, SpelMessage.EXCEPTION_RUNNING_COMPILED_EXPRESSION, new Object[0]);
/*     */         }
/*     */       }
/*     */     }
/* 215 */     ExpressionState expressionState = new ExpressionState(getEvaluationContext(), toTypedValue(rootObject), this.configuration);
/* 216 */     TypedValue typedResultValue = this.ast.getTypedValue(expressionState);
/* 217 */     checkCompile(expressionState);
/* 218 */     return (T)ExpressionUtils.convertTypedValue(expressionState.getEvaluationContext(), typedResultValue, expectedResultType);
/*     */   }
/*     */   
/*     */   public Object getValue(EvaluationContext context) throws EvaluationException
/*     */   {
/* 223 */     Assert.notNull(context, "EvaluationContext is required");
/* 224 */     if (this.compiledAst != null) {
/*     */       try {
/* 226 */         TypedValue contextRoot = context == null ? null : context.getRootObject();
/* 227 */         return this.compiledAst.getValue(contextRoot != null ? contextRoot.getValue() : null, context);
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 231 */         if (this.configuration.getCompilerMode() == SpelCompilerMode.MIXED) {
/* 232 */           this.interpretedCount = 0;
/* 233 */           this.compiledAst = null;
/*     */         }
/*     */         else
/*     */         {
/* 237 */           throw new SpelEvaluationException(ex, SpelMessage.EXCEPTION_RUNNING_COMPILED_EXPRESSION, new Object[0]);
/*     */         }
/*     */       }
/*     */     }
/* 241 */     ExpressionState expressionState = new ExpressionState(context, this.configuration);
/* 242 */     Object result = this.ast.getValue(expressionState);
/* 243 */     checkCompile(expressionState);
/* 244 */     return result;
/*     */   }
/*     */   
/*     */   public Object getValue(EvaluationContext context, Object rootObject) throws EvaluationException
/*     */   {
/* 249 */     Assert.notNull(context, "EvaluationContext is required");
/* 250 */     if (this.compiledAst != null) {
/*     */       try {
/* 252 */         return this.compiledAst.getValue(rootObject, context);
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 256 */         if (this.configuration.getCompilerMode() == SpelCompilerMode.MIXED) {
/* 257 */           this.interpretedCount = 0;
/* 258 */           this.compiledAst = null;
/*     */         }
/*     */         else
/*     */         {
/* 262 */           throw new SpelEvaluationException(ex, SpelMessage.EXCEPTION_RUNNING_COMPILED_EXPRESSION, new Object[0]);
/*     */         }
/*     */       }
/*     */     }
/* 266 */     ExpressionState expressionState = new ExpressionState(context, toTypedValue(rootObject), this.configuration);
/* 267 */     Object result = this.ast.getValue(expressionState);
/* 268 */     checkCompile(expressionState);
/* 269 */     return result;
/*     */   }
/*     */   
/*     */   public <T> T getValue(EvaluationContext context, Class<T> expectedResultType)
/*     */     throws EvaluationException
/*     */   {
/* 275 */     if (this.compiledAst != null) {
/*     */       try {
/* 277 */         TypedValue contextRoot = context == null ? null : context.getRootObject();
/* 278 */         Object result = this.compiledAst.getValue(contextRoot == null ? null : contextRoot.getValue(), context);
/* 279 */         if (expectedResultType != null) {
/* 280 */           return (T)ExpressionUtils.convertTypedValue(context, new TypedValue(result), expectedResultType);
/*     */         }
/*     */         
/* 283 */         return (T)result;
/*     */ 
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 288 */         if (this.configuration.getCompilerMode() == SpelCompilerMode.MIXED) {
/* 289 */           this.interpretedCount = 0;
/* 290 */           this.compiledAst = null;
/*     */         }
/*     */         else
/*     */         {
/* 294 */           throw new SpelEvaluationException(ex, SpelMessage.EXCEPTION_RUNNING_COMPILED_EXPRESSION, new Object[0]);
/*     */         }
/*     */       }
/*     */     }
/* 298 */     ExpressionState expressionState = new ExpressionState(context, this.configuration);
/* 299 */     TypedValue typedResultValue = this.ast.getTypedValue(expressionState);
/* 300 */     checkCompile(expressionState);
/* 301 */     return (T)ExpressionUtils.convertTypedValue(context, typedResultValue, expectedResultType);
/*     */   }
/*     */   
/*     */   public <T> T getValue(EvaluationContext context, Object rootObject, Class<T> expectedResultType)
/*     */     throws EvaluationException
/*     */   {
/* 307 */     if (this.compiledAst != null) {
/*     */       try {
/* 309 */         Object result = this.compiledAst.getValue(rootObject, context);
/* 310 */         if (expectedResultType != null) {
/* 311 */           return (T)ExpressionUtils.convertTypedValue(context, new TypedValue(result), expectedResultType);
/*     */         }
/*     */         
/* 314 */         return (T)result;
/*     */ 
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 319 */         if (this.configuration.getCompilerMode() == SpelCompilerMode.MIXED) {
/* 320 */           this.interpretedCount = 0;
/* 321 */           this.compiledAst = null;
/*     */         }
/*     */         else
/*     */         {
/* 325 */           throw new SpelEvaluationException(ex, SpelMessage.EXCEPTION_RUNNING_COMPILED_EXPRESSION, new Object[0]);
/*     */         }
/*     */       }
/*     */     }
/* 329 */     ExpressionState expressionState = new ExpressionState(context, toTypedValue(rootObject), this.configuration);
/* 330 */     TypedValue typedResultValue = this.ast.getTypedValue(expressionState);
/* 331 */     checkCompile(expressionState);
/* 332 */     return (T)ExpressionUtils.convertTypedValue(context, typedResultValue, expectedResultType);
/*     */   }
/*     */   
/*     */   public Class<?> getValueType() throws EvaluationException
/*     */   {
/* 337 */     return getValueType(getEvaluationContext());
/*     */   }
/*     */   
/*     */   public Class<?> getValueType(Object rootObject) throws EvaluationException
/*     */   {
/* 342 */     return getValueType(getEvaluationContext(), rootObject);
/*     */   }
/*     */   
/*     */   public Class<?> getValueType(EvaluationContext context) throws EvaluationException
/*     */   {
/* 347 */     Assert.notNull(context, "EvaluationContext is required");
/* 348 */     ExpressionState expressionState = new ExpressionState(context, this.configuration);
/* 349 */     TypeDescriptor typeDescriptor = this.ast.getValueInternal(expressionState).getTypeDescriptor();
/* 350 */     return typeDescriptor != null ? typeDescriptor.getType() : null;
/*     */   }
/*     */   
/*     */   public Class<?> getValueType(EvaluationContext context, Object rootObject) throws EvaluationException
/*     */   {
/* 355 */     ExpressionState expressionState = new ExpressionState(context, toTypedValue(rootObject), this.configuration);
/* 356 */     TypeDescriptor typeDescriptor = this.ast.getValueInternal(expressionState).getTypeDescriptor();
/* 357 */     return typeDescriptor != null ? typeDescriptor.getType() : null;
/*     */   }
/*     */   
/*     */   public TypeDescriptor getValueTypeDescriptor() throws EvaluationException
/*     */   {
/* 362 */     return getValueTypeDescriptor(getEvaluationContext());
/*     */   }
/*     */   
/*     */   public TypeDescriptor getValueTypeDescriptor(Object rootObject)
/*     */     throws EvaluationException
/*     */   {
/* 368 */     ExpressionState expressionState = new ExpressionState(getEvaluationContext(), toTypedValue(rootObject), this.configuration);
/* 369 */     return this.ast.getValueInternal(expressionState).getTypeDescriptor();
/*     */   }
/*     */   
/*     */   public TypeDescriptor getValueTypeDescriptor(EvaluationContext context) throws EvaluationException
/*     */   {
/* 374 */     Assert.notNull(context, "EvaluationContext is required");
/* 375 */     ExpressionState expressionState = new ExpressionState(context, this.configuration);
/* 376 */     return this.ast.getValueInternal(expressionState).getTypeDescriptor();
/*     */   }
/*     */   
/*     */   public TypeDescriptor getValueTypeDescriptor(EvaluationContext context, Object rootObject) throws EvaluationException
/*     */   {
/* 381 */     Assert.notNull(context, "EvaluationContext is required");
/* 382 */     ExpressionState expressionState = new ExpressionState(context, toTypedValue(rootObject), this.configuration);
/* 383 */     return this.ast.getValueInternal(expressionState).getTypeDescriptor();
/*     */   }
/*     */   
/*     */   public String getExpressionString()
/*     */   {
/* 388 */     return this.expression;
/*     */   }
/*     */   
/*     */   public boolean isWritable(EvaluationContext context) throws EvaluationException
/*     */   {
/* 393 */     Assert.notNull(context, "EvaluationContext is required");
/* 394 */     return this.ast.isWritable(new ExpressionState(context, this.configuration));
/*     */   }
/*     */   
/*     */   public boolean isWritable(Object rootObject) throws EvaluationException
/*     */   {
/* 399 */     return this.ast.isWritable(new ExpressionState(getEvaluationContext(), toTypedValue(rootObject), this.configuration));
/*     */   }
/*     */   
/*     */   public boolean isWritable(EvaluationContext context, Object rootObject) throws EvaluationException
/*     */   {
/* 404 */     Assert.notNull(context, "EvaluationContext is required");
/* 405 */     return this.ast.isWritable(new ExpressionState(context, toTypedValue(rootObject), this.configuration));
/*     */   }
/*     */   
/*     */   public void setValue(EvaluationContext context, Object value) throws EvaluationException
/*     */   {
/* 410 */     Assert.notNull(context, "EvaluationContext is required");
/* 411 */     this.ast.setValue(new ExpressionState(context, this.configuration), value);
/*     */   }
/*     */   
/*     */   public void setValue(Object rootObject, Object value) throws EvaluationException
/*     */   {
/* 416 */     this.ast.setValue(new ExpressionState(getEvaluationContext(), toTypedValue(rootObject), this.configuration), value);
/*     */   }
/*     */   
/*     */   public void setValue(EvaluationContext context, Object rootObject, Object value) throws EvaluationException
/*     */   {
/* 421 */     Assert.notNull(context, "EvaluationContext is required");
/* 422 */     this.ast.setValue(new ExpressionState(context, toTypedValue(rootObject), this.configuration), value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkCompile(ExpressionState expressionState)
/*     */   {
/* 432 */     this.interpretedCount += 1;
/* 433 */     SpelCompilerMode compilerMode = expressionState.getConfiguration().getCompilerMode();
/* 434 */     if (compilerMode != SpelCompilerMode.OFF) {
/* 435 */       if (compilerMode == SpelCompilerMode.IMMEDIATE) {
/* 436 */         if (this.interpretedCount > 1) {
/* 437 */           compileExpression();
/*     */         }
/*     */         
/*     */ 
/*     */       }
/* 442 */       else if (this.interpretedCount > 100) {
/* 443 */         compileExpression();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean compileExpression()
/*     */   {
/* 456 */     if (this.failedAttempts > 100)
/*     */     {
/* 458 */       return false;
/*     */     }
/* 460 */     if (this.compiledAst == null) {
/* 461 */       synchronized (this.expression)
/*     */       {
/* 463 */         if (this.compiledAst != null) {
/* 464 */           return true;
/*     */         }
/* 466 */         SpelCompiler compiler = SpelCompiler.getCompiler(this.configuration.getCompilerClassLoader());
/* 467 */         this.compiledAst = compiler.compile(this.ast);
/* 468 */         if (this.compiledAst == null) {
/* 469 */           this.failedAttempts += 1;
/*     */         }
/*     */       }
/*     */     }
/* 473 */     return this.compiledAst != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void revertToInterpreted()
/*     */   {
/* 482 */     this.compiledAst = null;
/* 483 */     this.interpretedCount = 0;
/* 484 */     this.failedAttempts = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public SpelNode getAST()
/*     */   {
/* 491 */     return this.ast;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toStringAST()
/*     */   {
/* 501 */     return this.ast.toStringAST();
/*     */   }
/*     */   
/*     */   private TypedValue toTypedValue(Object object) {
/* 505 */     if (object == null) {
/* 506 */       return TypedValue.NULL;
/*     */     }
/*     */     
/* 509 */     return new TypedValue(object);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\spel\standard\SpelExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */