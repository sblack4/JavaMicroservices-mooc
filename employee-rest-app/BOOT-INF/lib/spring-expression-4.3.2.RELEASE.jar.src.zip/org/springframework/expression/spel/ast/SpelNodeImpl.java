/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.asm.Opcodes;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.common.ExpressionUtils;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.expression.spel.SpelNode;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SpelNodeImpl
/*     */   implements SpelNode, Opcodes
/*     */ {
/*  46 */   private static SpelNodeImpl[] NO_CHILDREN = new SpelNodeImpl[0];
/*     */   
/*     */ 
/*     */   protected int pos;
/*     */   
/*  51 */   protected SpelNodeImpl[] children = NO_CHILDREN;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private SpelNodeImpl parent;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected volatile String exitTypeDescriptor;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpelNodeImpl(int pos, SpelNodeImpl... operands)
/*     */   {
/*  68 */     this.pos = pos;
/*     */     
/*  70 */     Assert.isTrue(pos != 0, "Pos must not be 0");
/*  71 */     if (!ObjectUtils.isEmpty(operands)) {
/*  72 */       this.children = operands;
/*  73 */       for (SpelNodeImpl childNode : operands) {
/*  74 */         childNode.parent = this;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected SpelNodeImpl getPreviousChild()
/*     */   {
/*  81 */     SpelNodeImpl result = null;
/*  82 */     if (this.parent != null) {
/*  83 */       for (SpelNodeImpl child : this.parent.children) {
/*  84 */         if (this == child) {
/*     */           break;
/*     */         }
/*  87 */         result = child;
/*     */       }
/*     */     }
/*  90 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean nextChildIs(Class<?>... clazzes)
/*     */   {
/*  97 */     if (this.parent != null) {
/*  98 */       SpelNodeImpl[] peers = this.parent.children;
/*  99 */       int i = 0; for (int max = peers.length; i < max; i++) {
/* 100 */         if (this == peers[i]) {
/* 101 */           if (i + 1 >= max) {
/* 102 */             return false;
/*     */           }
/* 104 */           Class<?> clazz = peers[(i + 1)].getClass();
/* 105 */           for (Class<?> desiredClazz : clazzes) {
/* 106 */             if (clazz.equals(desiredClazz)) {
/* 107 */               return true;
/*     */             }
/*     */           }
/* 110 */           return false;
/*     */         }
/*     */       }
/*     */     }
/* 114 */     return false;
/*     */   }
/*     */   
/*     */   public final Object getValue(ExpressionState expressionState) throws EvaluationException
/*     */   {
/* 119 */     if (expressionState != null) {
/* 120 */       return getValueInternal(expressionState).getValue();
/*     */     }
/*     */     
/*     */ 
/* 124 */     return getValue(new ExpressionState(new StandardEvaluationContext()));
/*     */   }
/*     */   
/*     */   public final TypedValue getTypedValue(ExpressionState expressionState)
/*     */     throws EvaluationException
/*     */   {
/* 130 */     if (expressionState != null) {
/* 131 */       return getValueInternal(expressionState);
/*     */     }
/*     */     
/*     */ 
/* 135 */     return getTypedValue(new ExpressionState(new StandardEvaluationContext()));
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isWritable(ExpressionState expressionState)
/*     */     throws EvaluationException
/*     */   {
/* 142 */     return false;
/*     */   }
/*     */   
/*     */   public void setValue(ExpressionState expressionState, Object newValue)
/*     */     throws EvaluationException
/*     */   {
/* 148 */     throw new SpelEvaluationException(getStartPosition(), SpelMessage.SETVALUE_NOT_SUPPORTED, new Object[] {getClass() });
/*     */   }
/*     */   
/*     */   public SpelNode getChild(int index)
/*     */   {
/* 153 */     return this.children[index];
/*     */   }
/*     */   
/*     */   public int getChildCount()
/*     */   {
/* 158 */     return this.children.length;
/*     */   }
/*     */   
/*     */   public Class<?> getObjectClass(Object obj)
/*     */   {
/* 163 */     if (obj == null) {
/* 164 */       return null;
/*     */     }
/* 166 */     return (obj instanceof Class) ? (Class)obj : obj.getClass();
/*     */   }
/*     */   
/*     */   protected final <T> T getValue(ExpressionState state, Class<T> desiredReturnType) throws EvaluationException {
/* 170 */     return (T)ExpressionUtils.convertTypedValue(state.getEvaluationContext(), getValueInternal(state), desiredReturnType);
/*     */   }
/*     */   
/*     */   public int getStartPosition()
/*     */   {
/* 175 */     return this.pos >> 16;
/*     */   }
/*     */   
/*     */   public int getEndPosition()
/*     */   {
/* 180 */     return this.pos & 0xFFFF;
/*     */   }
/*     */   
/*     */   protected ValueRef getValueRef(ExpressionState state) throws EvaluationException {
/* 184 */     throw new SpelEvaluationException(this.pos, SpelMessage.NOT_ASSIGNABLE, new Object[] { toStringAST() });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCompilable()
/*     */   {
/* 194 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf)
/*     */   {
/* 206 */     throw new IllegalStateException(getClass().getName() + " has no generateCode(..) method");
/*     */   }
/*     */   
/*     */   public String getExitDescriptor() {
/* 210 */     return this.exitTypeDescriptor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract TypedValue getValueInternal(ExpressionState paramExpressionState)
/*     */     throws EvaluationException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void generateCodeForArguments(MethodVisitor mv, CodeFlow cf, Member member, SpelNodeImpl[] arguments)
/*     */   {
/* 226 */     String[] paramDescriptors = null;
/* 227 */     boolean isVarargs = false;
/* 228 */     if ((member instanceof Constructor)) {
/* 229 */       Constructor<?> ctor = (Constructor)member;
/* 230 */       paramDescriptors = CodeFlow.toDescriptors(ctor.getParameterTypes());
/* 231 */       isVarargs = ctor.isVarArgs();
/*     */     }
/*     */     else {
/* 234 */       Method method = (Method)member;
/* 235 */       paramDescriptors = CodeFlow.toDescriptors(method.getParameterTypes());
/* 236 */       isVarargs = method.isVarArgs();
/*     */     }
/* 238 */     if (isVarargs)
/*     */     {
/*     */ 
/* 241 */       int p = 0;
/* 242 */       int childCount = arguments.length;
/*     */       
/*     */ 
/* 245 */       for (p = 0; p < paramDescriptors.length - 1; p++) {
/* 246 */         generateCodeForArgument(mv, cf, arguments[p], paramDescriptors[p]);
/*     */       }
/*     */       
/* 249 */       SpelNodeImpl lastchild = childCount == 0 ? null : arguments[(childCount - 1)];
/* 250 */       String arraytype = paramDescriptors[(paramDescriptors.length - 1)];
/*     */       
/*     */ 
/* 253 */       if ((lastchild != null) && (lastchild.getExitDescriptor().equals(arraytype))) {
/* 254 */         generateCodeForArgument(mv, cf, lastchild, paramDescriptors[p]);
/*     */       }
/*     */       else {
/* 257 */         arraytype = arraytype.substring(1);
/*     */         
/* 259 */         CodeFlow.insertNewArrayCode(mv, childCount - p, arraytype);
/*     */         
/* 261 */         int arrayindex = 0;
/* 262 */         while (p < childCount) {
/* 263 */           SpelNodeImpl child = arguments[p];
/* 264 */           mv.visitInsn(89);
/* 265 */           CodeFlow.insertOptimalLoad(mv, arrayindex++);
/* 266 */           generateCodeForArgument(mv, cf, child, arraytype);
/* 267 */           CodeFlow.insertArrayStore(mv, arraytype);
/* 268 */           p++;
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 273 */       for (int i = 0; i < paramDescriptors.length; i++) {
/* 274 */         generateCodeForArgument(mv, cf, arguments[i], paramDescriptors[i]);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void generateCodeForArgument(MethodVisitor mv, CodeFlow cf, SpelNodeImpl argument, String paramDesc)
/*     */   {
/* 284 */     cf.enterCompilationScope();
/* 285 */     argument.generateCode(mv, cf);
/* 286 */     boolean primitiveOnStack = CodeFlow.isPrimitive(cf.lastDescriptor());
/*     */     
/* 288 */     if ((primitiveOnStack) && (paramDesc.charAt(0) == 'L')) {
/* 289 */       CodeFlow.insertBoxIfNecessary(mv, cf.lastDescriptor().charAt(0));
/*     */     }
/* 291 */     else if ((paramDesc.length() == 1) && (!primitiveOnStack)) {
/* 292 */       CodeFlow.insertUnboxInsns(mv, paramDesc.charAt(0), cf.lastDescriptor());
/*     */     }
/* 294 */     else if (!cf.lastDescriptor().equals(paramDesc))
/*     */     {
/* 296 */       CodeFlow.insertCheckCast(mv, paramDesc);
/*     */     }
/* 298 */     cf.exitCompilationScope();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\spel\ast\SpelNodeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */