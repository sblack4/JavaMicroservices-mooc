/*    */ package org.springframework.expression.spel;
/*    */ 
/*    */ import org.springframework.expression.ParseException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpelParseException
/*    */   extends ParseException
/*    */ {
/*    */   private final SpelMessage message;
/*    */   private final Object[] inserts;
/*    */   
/*    */   public SpelParseException(String expressionString, int position, SpelMessage message, Object... inserts)
/*    */   {
/* 37 */     super(expressionString, position, message.formatMessage(position, inserts));
/* 38 */     this.position = position;
/* 39 */     this.message = message;
/* 40 */     this.inserts = inserts;
/*    */   }
/*    */   
/*    */   public SpelParseException(int position, SpelMessage message, Object... inserts) {
/* 44 */     super(position, message.formatMessage(position, inserts));
/* 45 */     this.position = position;
/* 46 */     this.message = message;
/* 47 */     this.inserts = inserts;
/*    */   }
/*    */   
/*    */   public SpelParseException(int position, Throwable cause, SpelMessage message, Object... inserts) {
/* 51 */     super(position, message.formatMessage(position, inserts), cause);
/* 52 */     this.position = position;
/* 53 */     this.message = message;
/* 54 */     this.inserts = inserts;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 64 */     return this.message != null ? this.message.formatMessage(this.position, this.inserts) : super.getMessage();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public SpelMessage getMessageCode()
/*    */   {
/* 71 */     return this.message;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Object[] getInserts()
/*    */   {
/* 78 */     return this.inserts;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\spel\SpelParseException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */