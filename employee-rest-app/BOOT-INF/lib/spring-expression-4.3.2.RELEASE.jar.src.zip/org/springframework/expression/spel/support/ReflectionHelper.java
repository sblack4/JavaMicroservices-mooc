/*     */ package org.springframework.expression.spel.support;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypeConverter;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectionHelper
/*     */ {
/*     */   static ArgumentsMatchInfo compareArguments(List<TypeDescriptor> expectedArgTypes, List<TypeDescriptor> suppliedArgTypes, TypeConverter typeConverter)
/*     */   {
/*  55 */     Assert.isTrue(expectedArgTypes.size() == suppliedArgTypes.size(), "Expected argument types and supplied argument types should be arrays of same length");
/*     */     
/*     */ 
/*  58 */     ArgumentsMatchKind match = ArgumentsMatchKind.EXACT;
/*  59 */     for (int i = 0; (i < expectedArgTypes.size()) && (match != null); i++) {
/*  60 */       TypeDescriptor suppliedArg = (TypeDescriptor)suppliedArgTypes.get(i);
/*  61 */       TypeDescriptor expectedArg = (TypeDescriptor)expectedArgTypes.get(i);
/*  62 */       if (!expectedArg.equals(suppliedArg))
/*     */       {
/*  64 */         if (suppliedArg == null) {
/*  65 */           if (expectedArg.isPrimitive()) {
/*  66 */             match = null;
/*     */           }
/*     */           
/*     */         }
/*  70 */         else if (suppliedArg.isAssignableTo(expectedArg)) {
/*  71 */           if (match != ArgumentsMatchKind.REQUIRES_CONVERSION) {
/*  72 */             match = ArgumentsMatchKind.CLOSE;
/*     */           }
/*     */         }
/*  75 */         else if (typeConverter.canConvert(suppliedArg, expectedArg)) {
/*  76 */           match = ArgumentsMatchKind.REQUIRES_CONVERSION;
/*     */         }
/*     */         else {
/*  79 */           match = null;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  84 */     return match != null ? new ArgumentsMatchInfo(match) : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static int getTypeDifferenceWeight(List<TypeDescriptor> paramTypes, List<TypeDescriptor> argTypes)
/*     */   {
/*  91 */     int result = 0;
/*  92 */     for (int i = 0; i < paramTypes.size(); i++) {
/*  93 */       TypeDescriptor paramType = (TypeDescriptor)paramTypes.get(i);
/*  94 */       TypeDescriptor argType = i < argTypes.size() ? (TypeDescriptor)argTypes.get(i) : null;
/*  95 */       if (argType == null) {
/*  96 */         if (paramType.isPrimitive()) {
/*  97 */           return Integer.MAX_VALUE;
/*     */         }
/*     */       }
/*     */       else {
/* 101 */         Class<?> paramTypeClazz = paramType.getType();
/* 102 */         if (!ClassUtils.isAssignable(paramTypeClazz, argType.getType())) {
/* 103 */           return Integer.MAX_VALUE;
/*     */         }
/* 105 */         if (paramTypeClazz.isPrimitive()) {
/* 106 */           paramTypeClazz = Object.class;
/*     */         }
/* 108 */         Class<?> superClass = argType.getType().getSuperclass();
/* 109 */         while (superClass != null) {
/* 110 */           if (paramTypeClazz.equals(superClass)) {
/* 111 */             result += 2;
/* 112 */             superClass = null;
/*     */           }
/* 114 */           else if (ClassUtils.isAssignable(paramTypeClazz, superClass)) {
/* 115 */             result += 2;
/* 116 */             superClass = superClass.getSuperclass();
/*     */           }
/*     */           else {
/* 119 */             superClass = null;
/*     */           }
/*     */         }
/* 122 */         if (paramTypeClazz.isInterface()) {
/* 123 */           result += 1;
/*     */         }
/*     */       }
/*     */     }
/* 127 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static ArgumentsMatchInfo compareArgumentsVarargs(List<TypeDescriptor> expectedArgTypes, List<TypeDescriptor> suppliedArgTypes, TypeConverter typeConverter)
/*     */   {
/* 144 */     Assert.isTrue((expectedArgTypes != null) && (expectedArgTypes.size() > 0), "Expected arguments must at least include one array (the vargargs parameter)");
/*     */     
/* 146 */     Assert.isTrue(((TypeDescriptor)expectedArgTypes.get(expectedArgTypes.size() - 1)).isArray(), "Final expected argument should be array type (the varargs parameter)");
/*     */     
/*     */ 
/* 149 */     ArgumentsMatchKind match = ArgumentsMatchKind.EXACT;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 154 */     int argCountUpToVarargs = expectedArgTypes.size() - 1;
/* 155 */     for (int i = 0; (i < argCountUpToVarargs) && (match != null); i++) {
/* 156 */       TypeDescriptor suppliedArg = (TypeDescriptor)suppliedArgTypes.get(i);
/* 157 */       TypeDescriptor expectedArg = (TypeDescriptor)expectedArgTypes.get(i);
/* 158 */       if (suppliedArg == null) {
/* 159 */         if (expectedArg.isPrimitive()) {
/* 160 */           match = null;
/*     */         }
/*     */         
/*     */       }
/* 164 */       else if (!expectedArg.equals(suppliedArg)) {
/* 165 */         if (suppliedArg.isAssignableTo(expectedArg)) {
/* 166 */           if (match != ArgumentsMatchKind.REQUIRES_CONVERSION) {
/* 167 */             match = ArgumentsMatchKind.CLOSE;
/*     */           }
/*     */         }
/* 170 */         else if (typeConverter.canConvert(suppliedArg, expectedArg)) {
/* 171 */           match = ArgumentsMatchKind.REQUIRES_CONVERSION;
/*     */         }
/*     */         else {
/* 174 */           match = null;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 181 */     if (match == null) {
/* 182 */       return null;
/*     */     }
/*     */     
/* 185 */     if ((suppliedArgTypes.size() != expectedArgTypes.size()) || 
/* 186 */       (!((TypeDescriptor)expectedArgTypes.get(expectedArgTypes.size() - 1)).equals(suppliedArgTypes
/* 187 */       .get(suppliedArgTypes.size() - 1))))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 194 */       TypeDescriptor varargsDesc = (TypeDescriptor)expectedArgTypes.get(expectedArgTypes.size() - 1);
/* 195 */       Class<?> varargsParamType = varargsDesc.getElementTypeDescriptor().getType();
/*     */       
/*     */ 
/* 198 */       for (int i = expectedArgTypes.size() - 1; i < suppliedArgTypes.size(); i++) {
/* 199 */         TypeDescriptor suppliedArg = (TypeDescriptor)suppliedArgTypes.get(i);
/* 200 */         if (suppliedArg == null) {
/* 201 */           if (varargsParamType.isPrimitive()) {
/* 202 */             match = null;
/*     */           }
/*     */           
/*     */         }
/* 206 */         else if (varargsParamType != suppliedArg.getType()) {
/* 207 */           if (ClassUtils.isAssignable(varargsParamType, suppliedArg.getType())) {
/* 208 */             if (match != ArgumentsMatchKind.REQUIRES_CONVERSION) {
/* 209 */               match = ArgumentsMatchKind.CLOSE;
/*     */             }
/*     */           }
/* 212 */           else if (typeConverter.canConvert(suppliedArg, TypeDescriptor.valueOf(varargsParamType))) {
/* 213 */             match = ArgumentsMatchKind.REQUIRES_CONVERSION;
/*     */           }
/*     */           else {
/* 216 */             match = null;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 223 */     return match != null ? new ArgumentsMatchInfo(match) : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean convertAllArguments(TypeConverter converter, Object[] arguments, Method method)
/*     */     throws SpelEvaluationException
/*     */   {
/* 244 */     Integer varargsPosition = method.isVarArgs() ? Integer.valueOf(method.getParameterTypes().length - 1) : null;
/* 245 */     return convertArguments(converter, arguments, method, varargsPosition);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean convertArguments(TypeConverter converter, Object[] arguments, Object methodOrCtor, Integer varargsPosition)
/*     */     throws EvaluationException
/*     */   {
/* 262 */     boolean conversionOccurred = false;
/* 263 */     if (varargsPosition == null) {
/* 264 */       for (int i = 0; i < arguments.length; i++) {
/* 265 */         TypeDescriptor targetType = new TypeDescriptor(MethodParameter.forMethodOrConstructor(methodOrCtor, i));
/* 266 */         Object argument = arguments[i];
/* 267 */         arguments[i] = converter.convertValue(argument, TypeDescriptor.forObject(argument), targetType);
/* 268 */         conversionOccurred |= argument != arguments[i];
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 273 */       for (int i = 0; i < varargsPosition.intValue(); i++) {
/* 274 */         TypeDescriptor targetType = new TypeDescriptor(MethodParameter.forMethodOrConstructor(methodOrCtor, i));
/* 275 */         Object argument = arguments[i];
/* 276 */         arguments[i] = converter.convertValue(argument, TypeDescriptor.forObject(argument), targetType);
/* 277 */         conversionOccurred |= argument != arguments[i];
/*     */       }
/* 279 */       MethodParameter methodParam = MethodParameter.forMethodOrConstructor(methodOrCtor, varargsPosition.intValue());
/* 280 */       if (varargsPosition.intValue() == arguments.length - 1)
/*     */       {
/*     */ 
/* 283 */         TypeDescriptor targetType = new TypeDescriptor(methodParam);
/* 284 */         Object argument = arguments[varargsPosition.intValue()];
/* 285 */         TypeDescriptor sourceType = TypeDescriptor.forObject(argument);
/* 286 */         arguments[varargsPosition.intValue()] = converter.convertValue(argument, sourceType, targetType);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 291 */         if ((argument != arguments[varargsPosition.intValue()]) && 
/* 292 */           (!isFirstEntryInArray(argument, arguments[varargsPosition.intValue()]))) {
/* 293 */           conversionOccurred = true;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 298 */         TypeDescriptor targetType = new TypeDescriptor(methodParam).getElementTypeDescriptor();
/* 299 */         for (int i = varargsPosition.intValue(); i < arguments.length; i++) {
/* 300 */           Object argument = arguments[i];
/* 301 */           arguments[i] = converter.convertValue(argument, TypeDescriptor.forObject(argument), targetType);
/* 302 */           conversionOccurred |= argument != arguments[i];
/*     */         }
/*     */       }
/*     */     }
/* 306 */     return conversionOccurred;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isFirstEntryInArray(Object value, Object possibleArray)
/*     */   {
/* 316 */     if (possibleArray == null) {
/* 317 */       return false;
/*     */     }
/* 319 */     Class<?> type = possibleArray.getClass();
/* 320 */     if ((!type.isArray()) || (Array.getLength(possibleArray) == 0) || 
/* 321 */       (!ClassUtils.isAssignableValue(type.getComponentType(), value))) {
/* 322 */       return false;
/*     */     }
/* 324 */     Object arrayValue = Array.get(possibleArray, 0);
/* 325 */     return arrayValue == value ? true : type.getComponentType().isPrimitive() ? arrayValue.equals(value) : false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object[] setupArgumentsForVarargsInvocation(Class<?>[] requiredParameterTypes, Object... args)
/*     */   {
/* 339 */     int parameterCount = requiredParameterTypes.length;
/* 340 */     int argumentCount = args.length;
/*     */     
/*     */ 
/* 343 */     if (parameterCount == args.length)
/*     */     {
/* 345 */       if (requiredParameterTypes[(parameterCount - 1)] == (args[(argumentCount - 1)] != null ? args[(argumentCount - 1)].getClass() : null)) {}
/*     */     } else {
/* 347 */       int arraySize = 0;
/* 348 */       if (argumentCount >= parameterCount) {
/* 349 */         arraySize = argumentCount - (parameterCount - 1);
/*     */       }
/*     */       
/*     */ 
/* 353 */       Object[] newArgs = new Object[parameterCount];
/* 354 */       System.arraycopy(args, 0, newArgs, 0, newArgs.length - 1);
/*     */       
/*     */ 
/*     */ 
/* 358 */       Class<?> componentType = requiredParameterTypes[(parameterCount - 1)].getComponentType();
/* 359 */       Object repackagedArgs = Array.newInstance(componentType, arraySize);
/* 360 */       for (int i = 0; i < arraySize; i++) {
/* 361 */         Array.set(repackagedArgs, i, args[(parameterCount - 1 + i)]);
/*     */       }
/* 363 */       newArgs[(newArgs.length - 1)] = repackagedArgs;
/* 364 */       return newArgs;
/*     */     }
/* 366 */     return args;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static enum ArgumentsMatchKind
/*     */   {
/* 373 */     EXACT, 
/*     */     
/*     */ 
/* 376 */     CLOSE, 
/*     */     
/*     */ 
/* 379 */     REQUIRES_CONVERSION;
/*     */     
/*     */ 
/*     */ 
/*     */     private ArgumentsMatchKind() {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static class ArgumentsMatchInfo
/*     */   {
/*     */     private final ReflectionHelper.ArgumentsMatchKind kind;
/*     */     
/*     */ 
/*     */     ArgumentsMatchInfo(ReflectionHelper.ArgumentsMatchKind kind)
/*     */     {
/* 395 */       this.kind = kind;
/*     */     }
/*     */     
/*     */     public boolean isExactMatch() {
/* 399 */       return this.kind == ReflectionHelper.ArgumentsMatchKind.EXACT;
/*     */     }
/*     */     
/*     */     public boolean isCloseMatch() {
/* 403 */       return this.kind == ReflectionHelper.ArgumentsMatchKind.CLOSE;
/*     */     }
/*     */     
/*     */     public boolean isMatchRequiringConversion() {
/* 407 */       return this.kind == ReflectionHelper.ArgumentsMatchKind.REQUIRES_CONVERSION;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 412 */       return "ArgumentMatchInfo: " + this.kind;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\spel\support\ReflectionHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */