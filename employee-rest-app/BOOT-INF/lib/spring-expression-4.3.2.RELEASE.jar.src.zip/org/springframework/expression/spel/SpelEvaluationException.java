/*    */ package org.springframework.expression.spel;
/*    */ 
/*    */ import org.springframework.expression.EvaluationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpelEvaluationException
/*    */   extends EvaluationException
/*    */ {
/*    */   private final SpelMessage message;
/*    */   private final Object[] inserts;
/*    */   
/*    */   public SpelEvaluationException(SpelMessage message, Object... inserts)
/*    */   {
/* 37 */     super(message.formatMessage(0, inserts));
/* 38 */     this.message = message;
/* 39 */     this.inserts = inserts;
/*    */   }
/*    */   
/*    */   public SpelEvaluationException(int position, SpelMessage message, Object... inserts) {
/* 43 */     super(position, message.formatMessage(position, inserts));
/* 44 */     this.message = message;
/* 45 */     this.inserts = inserts;
/*    */   }
/*    */   
/*    */   public SpelEvaluationException(int position, Throwable cause, SpelMessage message, Object... inserts)
/*    */   {
/* 50 */     super(position, message.formatMessage(position, inserts), cause);
/* 51 */     this.message = message;
/* 52 */     this.inserts = inserts;
/*    */   }
/*    */   
/*    */   public SpelEvaluationException(Throwable cause, SpelMessage message, Object... inserts) {
/* 56 */     super(message.formatMessage(0, inserts), cause);
/* 57 */     this.message = message;
/* 58 */     this.inserts = inserts;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 67 */     if (this.message != null) {
/* 68 */       return this.message.formatMessage(this.position, this.inserts);
/*    */     }
/*    */     
/* 71 */     return super.getMessage();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public SpelMessage getMessageCode()
/*    */   {
/* 79 */     return this.message;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setPosition(int position)
/*    */   {
/* 88 */     this.position = position;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Object[] getInserts()
/*    */   {
/* 95 */     return this.inserts;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\spel\SpelEvaluationException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */