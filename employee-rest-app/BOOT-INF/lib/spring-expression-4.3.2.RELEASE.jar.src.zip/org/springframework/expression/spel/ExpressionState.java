/*     */ package org.springframework.expression.spel;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Stack;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.Operation;
/*     */ import org.springframework.expression.OperatorOverloader;
/*     */ import org.springframework.expression.PropertyAccessor;
/*     */ import org.springframework.expression.TypeComparator;
/*     */ import org.springframework.expression.TypeConverter;
/*     */ import org.springframework.expression.TypeLocator;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpressionState
/*     */ {
/*     */   private final EvaluationContext relatedContext;
/*     */   private final TypedValue rootObject;
/*     */   private Stack<TypedValue> scopeRootObjects;
/*     */   private final SpelParserConfiguration configuration;
/*     */   private Stack<VariableScope> variableScopes;
/*     */   private Stack<TypedValue> contextObjects;
/*     */   
/*     */   public ExpressionState(EvaluationContext context)
/*     */   {
/*  73 */     this(context, context.getRootObject(), new SpelParserConfiguration(false, false));
/*     */   }
/*     */   
/*     */   public ExpressionState(EvaluationContext context, SpelParserConfiguration configuration) {
/*  77 */     this(context, context.getRootObject(), configuration);
/*     */   }
/*     */   
/*     */   public ExpressionState(EvaluationContext context, TypedValue rootObject) {
/*  81 */     this(context, rootObject, new SpelParserConfiguration(false, false));
/*     */   }
/*     */   
/*     */   public ExpressionState(EvaluationContext context, TypedValue rootObject, SpelParserConfiguration configuration) {
/*  85 */     Assert.notNull(context, "EvaluationContext must not be null");
/*  86 */     Assert.notNull(configuration, "SpelParserConfiguration must not be null");
/*  87 */     this.relatedContext = context;
/*  88 */     this.rootObject = rootObject;
/*  89 */     this.configuration = configuration;
/*     */   }
/*     */   
/*     */   private void ensureVariableScopesInitialized()
/*     */   {
/*  94 */     if (this.variableScopes == null) {
/*  95 */       this.variableScopes = new Stack();
/*     */       
/*  97 */       this.variableScopes.add(new VariableScope());
/*     */     }
/*  99 */     if (this.scopeRootObjects == null) {
/* 100 */       this.scopeRootObjects = new Stack();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TypedValue getActiveContextObject()
/*     */   {
/* 108 */     if ((this.contextObjects == null) || (this.contextObjects.isEmpty())) {
/* 109 */       return this.rootObject;
/*     */     }
/* 111 */     return (TypedValue)this.contextObjects.peek();
/*     */   }
/*     */   
/*     */   public void pushActiveContextObject(TypedValue obj) {
/* 115 */     if (this.contextObjects == null) {
/* 116 */       this.contextObjects = new Stack();
/*     */     }
/* 118 */     this.contextObjects.push(obj);
/*     */   }
/*     */   
/*     */   public void popActiveContextObject() {
/* 122 */     if (this.contextObjects == null) {
/* 123 */       this.contextObjects = new Stack();
/*     */     }
/* 125 */     this.contextObjects.pop();
/*     */   }
/*     */   
/*     */   public TypedValue getRootContextObject() {
/* 129 */     return this.rootObject;
/*     */   }
/*     */   
/*     */   public TypedValue getScopeRootContextObject() {
/* 133 */     if ((this.scopeRootObjects == null) || (this.scopeRootObjects.isEmpty())) {
/* 134 */       return this.rootObject;
/*     */     }
/* 136 */     return (TypedValue)this.scopeRootObjects.peek();
/*     */   }
/*     */   
/*     */   public void setVariable(String name, Object value) {
/* 140 */     this.relatedContext.setVariable(name, value);
/*     */   }
/*     */   
/*     */   public TypedValue lookupVariable(String name) {
/* 144 */     Object value = this.relatedContext.lookupVariable(name);
/* 145 */     if (value == null) {
/* 146 */       return TypedValue.NULL;
/*     */     }
/*     */     
/* 149 */     return new TypedValue(value);
/*     */   }
/*     */   
/*     */   public TypeComparator getTypeComparator()
/*     */   {
/* 154 */     return this.relatedContext.getTypeComparator();
/*     */   }
/*     */   
/*     */   public Class<?> findType(String type) throws EvaluationException {
/* 158 */     return this.relatedContext.getTypeLocator().findType(type);
/*     */   }
/*     */   
/*     */   public Object convertValue(Object value, TypeDescriptor targetTypeDescriptor) throws EvaluationException {
/* 162 */     return this.relatedContext.getTypeConverter().convertValue(value, 
/* 163 */       TypeDescriptor.forObject(value), targetTypeDescriptor);
/*     */   }
/*     */   
/*     */   public TypeConverter getTypeConverter() {
/* 167 */     return this.relatedContext.getTypeConverter();
/*     */   }
/*     */   
/*     */   public Object convertValue(TypedValue value, TypeDescriptor targetTypeDescriptor) throws EvaluationException {
/* 171 */     Object val = value.getValue();
/* 172 */     return this.relatedContext.getTypeConverter().convertValue(val, TypeDescriptor.forObject(val), targetTypeDescriptor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void enterScope(Map<String, Object> argMap)
/*     */   {
/* 179 */     ensureVariableScopesInitialized();
/* 180 */     this.variableScopes.push(new VariableScope(argMap));
/* 181 */     this.scopeRootObjects.push(getActiveContextObject());
/*     */   }
/*     */   
/*     */   public void enterScope() {
/* 185 */     ensureVariableScopesInitialized();
/* 186 */     this.variableScopes.push(new VariableScope(Collections.emptyMap()));
/* 187 */     this.scopeRootObjects.push(getActiveContextObject());
/*     */   }
/*     */   
/*     */   public void enterScope(String name, Object value) {
/* 191 */     ensureVariableScopesInitialized();
/* 192 */     this.variableScopes.push(new VariableScope(name, value));
/* 193 */     this.scopeRootObjects.push(getActiveContextObject());
/*     */   }
/*     */   
/*     */   public void exitScope() {
/* 197 */     ensureVariableScopesInitialized();
/* 198 */     this.variableScopes.pop();
/* 199 */     this.scopeRootObjects.pop();
/*     */   }
/*     */   
/*     */   public void setLocalVariable(String name, Object value) {
/* 203 */     ensureVariableScopesInitialized();
/* 204 */     ((VariableScope)this.variableScopes.peek()).setVariable(name, value);
/*     */   }
/*     */   
/*     */   public Object lookupLocalVariable(String name) {
/* 208 */     ensureVariableScopesInitialized();
/* 209 */     int scopeNumber = this.variableScopes.size() - 1;
/* 210 */     for (int i = scopeNumber; i >= 0; i--) {
/* 211 */       if (((VariableScope)this.variableScopes.get(i)).definesVariable(name)) {
/* 212 */         return ((VariableScope)this.variableScopes.get(i)).lookupVariable(name);
/*     */       }
/*     */     }
/* 215 */     return null;
/*     */   }
/*     */   
/*     */   public TypedValue operate(Operation op, Object left, Object right) throws EvaluationException {
/* 219 */     OperatorOverloader overloader = this.relatedContext.getOperatorOverloader();
/* 220 */     if (overloader.overridesOperation(op, left, right)) {
/* 221 */       Object returnValue = overloader.operate(op, left, right);
/* 222 */       return new TypedValue(returnValue);
/*     */     }
/*     */     
/* 225 */     String leftType = left == null ? "null" : left.getClass().getName();
/* 226 */     String rightType = right == null ? "null" : right.getClass().getName();
/* 227 */     throw new SpelEvaluationException(SpelMessage.OPERATOR_NOT_SUPPORTED_BETWEEN_TYPES, new Object[] { op, leftType, rightType });
/*     */   }
/*     */   
/*     */   public List<PropertyAccessor> getPropertyAccessors()
/*     */   {
/* 232 */     return this.relatedContext.getPropertyAccessors();
/*     */   }
/*     */   
/*     */   public EvaluationContext getEvaluationContext() {
/* 236 */     return this.relatedContext;
/*     */   }
/*     */   
/*     */   public SpelParserConfiguration getConfiguration() {
/* 240 */     return this.configuration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class VariableScope
/*     */   {
/* 253 */     private final Map<String, Object> vars = new HashMap();
/*     */     
/*     */     public VariableScope() {}
/*     */     
/*     */     public VariableScope(Map<String, Object> arguments)
/*     */     {
/* 259 */       if (arguments != null) {
/* 260 */         this.vars.putAll(arguments);
/*     */       }
/*     */     }
/*     */     
/*     */     public VariableScope(String name, Object value) {
/* 265 */       this.vars.put(name, value);
/*     */     }
/*     */     
/*     */     public Object lookupVariable(String name) {
/* 269 */       return this.vars.get(name);
/*     */     }
/*     */     
/*     */     public void setVariable(String name, Object value) {
/* 273 */       this.vars.put(name, value);
/*     */     }
/*     */     
/*     */     public boolean definesVariable(String name) {
/* 277 */       return this.vars.containsKey(name);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\spel\ExpressionState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */