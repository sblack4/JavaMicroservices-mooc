/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.expression.TypeComparator;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelNode;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.NumberUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Operator
/*     */   extends SpelNodeImpl
/*     */ {
/*     */   private final String operatorName;
/*     */   protected String leftActualDescriptor;
/*     */   protected String rightActualDescriptor;
/*     */   
/*     */   public Operator(String payload, int pos, SpelNodeImpl... operands)
/*     */   {
/*  55 */     super(pos, operands);
/*  56 */     this.operatorName = payload;
/*     */   }
/*     */   
/*     */   public SpelNodeImpl getLeftOperand()
/*     */   {
/*  61 */     return this.children[0];
/*     */   }
/*     */   
/*     */   public SpelNodeImpl getRightOperand() {
/*  65 */     return this.children[1];
/*     */   }
/*     */   
/*     */   public final String getOperatorName() {
/*  69 */     return this.operatorName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toStringAST()
/*     */   {
/*  77 */     StringBuilder sb = new StringBuilder("(");
/*  78 */     sb.append(getChild(0).toStringAST());
/*  79 */     for (int i = 1; i < getChildCount(); i++) {
/*  80 */       sb.append(" ").append(getOperatorName()).append(" ");
/*  81 */       sb.append(getChild(i).toStringAST());
/*     */     }
/*  83 */     sb.append(")");
/*  84 */     return sb.toString();
/*     */   }
/*     */   
/*     */   protected boolean isCompilableOperatorUsingNumerics() {
/*  88 */     SpelNodeImpl left = getLeftOperand();
/*  89 */     SpelNodeImpl right = getRightOperand();
/*  90 */     if ((!left.isCompilable()) || (!right.isCompilable())) {
/*  91 */       return false;
/*     */     }
/*     */     
/*     */ 
/*  95 */     String leftDesc = left.exitTypeDescriptor;
/*  96 */     String rightDesc = right.exitTypeDescriptor;
/*  97 */     DescriptorComparison dc = DescriptorComparison.checkNumericCompatibility(leftDesc, rightDesc, this.leftActualDescriptor, this.rightActualDescriptor);
/*     */     
/*  99 */     return (dc.areNumbers) && (dc.areCompatible);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void generateComparisonCode(MethodVisitor mv, CodeFlow cf, int compInstruction1, int compInstruction2)
/*     */   {
/* 107 */     String leftDesc = getLeftOperand().exitTypeDescriptor;
/* 108 */     String rightDesc = getRightOperand().exitTypeDescriptor;
/*     */     
/* 110 */     boolean unboxLeft = !CodeFlow.isPrimitive(leftDesc);
/* 111 */     boolean unboxRight = !CodeFlow.isPrimitive(rightDesc);
/* 112 */     DescriptorComparison dc = DescriptorComparison.checkNumericCompatibility(leftDesc, rightDesc, this.leftActualDescriptor, this.rightActualDescriptor);
/*     */     
/* 114 */     char targetType = dc.compatibleType;
/*     */     
/* 116 */     getLeftOperand().generateCode(mv, cf);
/* 117 */     if (unboxLeft) {
/* 118 */       CodeFlow.insertUnboxInsns(mv, targetType, leftDesc);
/*     */     }
/*     */     
/* 121 */     cf.enterCompilationScope();
/* 122 */     getRightOperand().generateCode(mv, cf);
/* 123 */     cf.exitCompilationScope();
/* 124 */     if (unboxRight) {
/* 125 */       CodeFlow.insertUnboxInsns(mv, targetType, rightDesc);
/*     */     }
/*     */     
/*     */ 
/* 129 */     Label elseTarget = new Label();
/* 130 */     Label endOfIf = new Label();
/* 131 */     if (targetType == 'D') {
/* 132 */       mv.visitInsn(152);
/* 133 */       mv.visitJumpInsn(compInstruction1, elseTarget);
/*     */     }
/* 135 */     else if (targetType == 'F') {
/* 136 */       mv.visitInsn(150);
/* 137 */       mv.visitJumpInsn(compInstruction1, elseTarget);
/*     */     }
/* 139 */     else if (targetType == 'J') {
/* 140 */       mv.visitInsn(148);
/* 141 */       mv.visitJumpInsn(compInstruction1, elseTarget);
/*     */     }
/* 143 */     else if (targetType == 'I') {
/* 144 */       mv.visitJumpInsn(compInstruction2, elseTarget);
/*     */     }
/*     */     else {
/* 147 */       throw new IllegalStateException("Unexpected descriptor " + leftDesc);
/*     */     }
/*     */     
/*     */ 
/* 151 */     mv.visitInsn(4);
/* 152 */     mv.visitJumpInsn(167, endOfIf);
/* 153 */     mv.visitLabel(elseTarget);
/* 154 */     mv.visitInsn(3);
/* 155 */     mv.visitLabel(endOfIf);
/* 156 */     cf.pushDescriptor("Z");
/*     */   }
/*     */   
/*     */   protected boolean equalityCheck(ExpressionState state, Object left, Object right) {
/* 160 */     if (((left instanceof Number)) && ((right instanceof Number))) {
/* 161 */       Number leftNumber = (Number)left;
/* 162 */       Number rightNumber = (Number)right;
/*     */       
/* 164 */       if (((leftNumber instanceof BigDecimal)) || ((rightNumber instanceof BigDecimal))) {
/* 165 */         BigDecimal leftBigDecimal = (BigDecimal)NumberUtils.convertNumberToTargetClass(leftNumber, BigDecimal.class);
/* 166 */         BigDecimal rightBigDecimal = (BigDecimal)NumberUtils.convertNumberToTargetClass(rightNumber, BigDecimal.class);
/* 167 */         return rightBigDecimal == null;
/*     */       }
/* 169 */       if (((leftNumber instanceof Double)) || ((rightNumber instanceof Double))) {
/* 170 */         return leftNumber.doubleValue() == rightNumber.doubleValue();
/*     */       }
/* 172 */       if (((leftNumber instanceof Float)) || ((rightNumber instanceof Float))) {
/* 173 */         return leftNumber.floatValue() == rightNumber.floatValue();
/*     */       }
/* 175 */       if (((leftNumber instanceof BigInteger)) || ((rightNumber instanceof BigInteger))) {
/* 176 */         BigInteger leftBigInteger = (BigInteger)NumberUtils.convertNumberToTargetClass(leftNumber, BigInteger.class);
/* 177 */         BigInteger rightBigInteger = (BigInteger)NumberUtils.convertNumberToTargetClass(rightNumber, BigInteger.class);
/* 178 */         return rightBigInteger == null;
/*     */       }
/* 180 */       if (((leftNumber instanceof Long)) || ((rightNumber instanceof Long))) {
/* 181 */         return leftNumber.longValue() == rightNumber.longValue();
/*     */       }
/* 183 */       if (((leftNumber instanceof Integer)) || ((rightNumber instanceof Integer))) {
/* 184 */         return leftNumber.intValue() == rightNumber.intValue();
/*     */       }
/* 186 */       if (((leftNumber instanceof Short)) || ((rightNumber instanceof Short))) {
/* 187 */         return leftNumber.shortValue() == rightNumber.shortValue();
/*     */       }
/* 189 */       if (((leftNumber instanceof Byte)) || ((rightNumber instanceof Byte))) {
/* 190 */         return leftNumber.byteValue() == rightNumber.byteValue();
/*     */       }
/*     */       
/*     */ 
/* 194 */       return leftNumber.doubleValue() == rightNumber.doubleValue();
/*     */     }
/*     */     
/*     */ 
/* 198 */     if (((left instanceof CharSequence)) && ((right instanceof CharSequence))) {
/* 199 */       return left.toString().equals(right.toString());
/*     */     }
/*     */     
/* 202 */     if (ObjectUtils.nullSafeEquals(left, right)) {
/* 203 */       return true;
/*     */     }
/*     */     
/* 206 */     if (((left instanceof Comparable)) && ((right instanceof Comparable))) {
/* 207 */       Class<?> ancestor = ClassUtils.determineCommonAncestor(left.getClass(), right.getClass());
/* 208 */       if ((ancestor != null) && (Comparable.class.isAssignableFrom(ancestor))) {
/* 209 */         return state.getTypeComparator().compare(left, right) == 0;
/*     */       }
/*     */     }
/*     */     
/* 213 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static class DescriptorComparison
/*     */   {
/* 223 */     static DescriptorComparison NOT_NUMBERS = new DescriptorComparison(false, false, ' ');
/*     */     
/* 225 */     static DescriptorComparison INCOMPATIBLE_NUMBERS = new DescriptorComparison(true, false, ' ');
/*     */     
/*     */     final boolean areNumbers;
/*     */     
/*     */     final boolean areCompatible;
/*     */     final char compatibleType;
/*     */     
/*     */     private DescriptorComparison(boolean areNumbers, boolean areCompatible, char compatibleType)
/*     */     {
/* 234 */       this.areNumbers = areNumbers;
/* 235 */       this.areCompatible = areCompatible;
/* 236 */       this.compatibleType = compatibleType;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static DescriptorComparison checkNumericCompatibility(String leftDeclaredDescriptor, String rightDeclaredDescriptor, String leftActualDescriptor, String rightActualDescriptor)
/*     */     {
/* 255 */       String ld = leftDeclaredDescriptor;
/* 256 */       String rd = rightDeclaredDescriptor;
/*     */       
/* 258 */       boolean leftNumeric = CodeFlow.isPrimitiveOrUnboxableSupportedNumberOrBoolean(ld);
/* 259 */       boolean rightNumeric = CodeFlow.isPrimitiveOrUnboxableSupportedNumberOrBoolean(rd);
/*     */       
/*     */ 
/* 262 */       if ((!leftNumeric) && (!ld.equals(leftActualDescriptor))) {
/* 263 */         ld = leftActualDescriptor;
/* 264 */         leftNumeric = CodeFlow.isPrimitiveOrUnboxableSupportedNumberOrBoolean(ld);
/*     */       }
/* 266 */       if ((!rightNumeric) && (!rd.equals(rightActualDescriptor))) {
/* 267 */         rd = rightActualDescriptor;
/* 268 */         rightNumeric = CodeFlow.isPrimitiveOrUnboxableSupportedNumberOrBoolean(rd);
/*     */       }
/*     */       
/* 271 */       if ((leftNumeric) && (rightNumeric)) {
/* 272 */         if (CodeFlow.areBoxingCompatible(ld, rd)) {
/* 273 */           return new DescriptorComparison(true, true, CodeFlow.toPrimitiveTargetDesc(ld));
/*     */         }
/*     */         
/* 276 */         return INCOMPATIBLE_NUMBERS;
/*     */       }
/*     */       
/*     */ 
/* 280 */       return NOT_NUMBERS;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\spel\ast\Operator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */