/*    */ package org.springframework.expression.spel.ast;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FormatHelper
/*    */ {
/*    */   public static String formatMethodForMessage(String name, List<TypeDescriptor> argumentTypes)
/*    */   {
/* 37 */     StringBuilder sb = new StringBuilder(name);
/* 38 */     sb.append("(");
/* 39 */     for (int i = 0; i < argumentTypes.size(); i++) {
/* 40 */       if (i > 0) {
/* 41 */         sb.append(",");
/*    */       }
/* 43 */       TypeDescriptor typeDescriptor = (TypeDescriptor)argumentTypes.get(i);
/* 44 */       if (typeDescriptor != null) {
/* 45 */         sb.append(formatClassNameForMessage(typeDescriptor.getType()));
/*    */       }
/*    */       else {
/* 48 */         sb.append(formatClassNameForMessage(null));
/*    */       }
/*    */     }
/* 51 */     sb.append(")");
/* 52 */     return sb.toString();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String formatClassNameForMessage(Class<?> clazz)
/*    */   {
/* 62 */     if (clazz == null) {
/* 63 */       return "null";
/*    */     }
/* 65 */     if (clazz.isArray()) {
/* 66 */       StringBuilder sb = new StringBuilder();
/* 67 */       int dims = 1;
/* 68 */       Class<?> baseClass = clazz.getComponentType();
/* 69 */       while (baseClass.isArray()) {
/* 70 */         baseClass = baseClass.getComponentType();
/* 71 */         dims++;
/*    */       }
/* 73 */       sb.append(baseClass.getName());
/* 74 */       for (int i = 0; i < dims; i++) {
/* 75 */         sb.append("[]");
/*    */       }
/* 77 */       return sb.toString();
/*    */     }
/*    */     
/* 80 */     return clazz.getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\spel\ast\FormatHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */