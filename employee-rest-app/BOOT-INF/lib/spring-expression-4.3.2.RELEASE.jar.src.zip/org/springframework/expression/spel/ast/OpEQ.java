/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.support.BooleanTypedValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpEQ
/*     */   extends Operator
/*     */ {
/*     */   public OpEQ(int pos, SpelNodeImpl... operands)
/*     */   {
/*  35 */     super("==", pos, operands);
/*  36 */     this.exitTypeDescriptor = "Z";
/*     */   }
/*     */   
/*     */   public BooleanTypedValue getValueInternal(ExpressionState state)
/*     */     throws EvaluationException
/*     */   {
/*  42 */     Object left = getLeftOperand().getValueInternal(state).getValue();
/*  43 */     Object right = getRightOperand().getValueInternal(state).getValue();
/*  44 */     this.leftActualDescriptor = CodeFlow.toDescriptorFromObject(left);
/*  45 */     this.rightActualDescriptor = CodeFlow.toDescriptorFromObject(right);
/*  46 */     return BooleanTypedValue.forValue(equalityCheck(state, left, right));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isCompilable()
/*     */   {
/*  53 */     SpelNodeImpl left = getLeftOperand();
/*  54 */     SpelNodeImpl right = getRightOperand();
/*  55 */     if ((!left.isCompilable()) || (!right.isCompilable())) {
/*  56 */       return false;
/*     */     }
/*     */     
/*  59 */     String leftDesc = left.exitTypeDescriptor;
/*  60 */     String rightDesc = right.exitTypeDescriptor;
/*  61 */     Operator.DescriptorComparison dc = Operator.DescriptorComparison.checkNumericCompatibility(leftDesc, rightDesc, this.leftActualDescriptor, this.rightActualDescriptor);
/*     */     
/*  63 */     return (!dc.areNumbers) || (dc.areCompatible);
/*     */   }
/*     */   
/*     */ 
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf)
/*     */   {
/*  69 */     String leftDesc = getLeftOperand().exitTypeDescriptor;
/*  70 */     String rightDesc = getRightOperand().exitTypeDescriptor;
/*  71 */     Label elseTarget = new Label();
/*  72 */     Label endOfIf = new Label();
/*  73 */     boolean leftPrim = CodeFlow.isPrimitive(leftDesc);
/*  74 */     boolean rightPrim = CodeFlow.isPrimitive(rightDesc);
/*     */     
/*  76 */     Operator.DescriptorComparison dc = Operator.DescriptorComparison.checkNumericCompatibility(leftDesc, rightDesc, this.leftActualDescriptor, this.rightActualDescriptor);
/*     */     
/*     */ 
/*  79 */     if ((dc.areNumbers) && (dc.areCompatible)) {
/*  80 */       char targetType = dc.compatibleType;
/*     */       
/*  82 */       getLeftOperand().generateCode(mv, cf);
/*  83 */       if (!leftPrim) {
/*  84 */         CodeFlow.insertUnboxInsns(mv, targetType, leftDesc);
/*     */       }
/*     */       
/*  87 */       cf.enterCompilationScope();
/*  88 */       getRightOperand().generateCode(mv, cf);
/*  89 */       cf.exitCompilationScope();
/*  90 */       if (!rightPrim) {
/*  91 */         CodeFlow.insertUnboxInsns(mv, targetType, rightDesc);
/*     */       }
/*     */       
/*  94 */       if (targetType == 'D') {
/*  95 */         mv.visitInsn(151);
/*  96 */         mv.visitJumpInsn(154, elseTarget);
/*     */       }
/*  98 */       else if (targetType == 'F') {
/*  99 */         mv.visitInsn(149);
/* 100 */         mv.visitJumpInsn(154, elseTarget);
/*     */       }
/* 102 */       else if (targetType == 'J') {
/* 103 */         mv.visitInsn(148);
/* 104 */         mv.visitJumpInsn(154, elseTarget);
/*     */       }
/* 106 */       else if ((targetType == 'I') || (targetType == 'Z')) {
/* 107 */         mv.visitJumpInsn(160, elseTarget);
/*     */       }
/*     */       else {
/* 110 */         throw new IllegalStateException("Unexpected descriptor " + leftDesc);
/*     */       }
/*     */     }
/*     */     else {
/* 114 */       getLeftOperand().generateCode(mv, cf);
/* 115 */       if (leftPrim) {
/* 116 */         CodeFlow.insertBoxIfNecessary(mv, leftDesc.charAt(0));
/*     */       }
/* 118 */       getRightOperand().generateCode(mv, cf);
/* 119 */       if (rightPrim) {
/* 120 */         CodeFlow.insertBoxIfNecessary(mv, rightDesc.charAt(0));
/*     */       }
/* 122 */       Label leftNotNull = new Label();
/* 123 */       mv.visitInsn(90);
/* 124 */       mv.visitJumpInsn(199, leftNotNull);
/*     */       
/* 126 */       mv.visitInsn(95);
/* 127 */       mv.visitInsn(87);
/* 128 */       Label rightNotNull = new Label();
/* 129 */       mv.visitJumpInsn(199, rightNotNull);
/*     */       
/* 131 */       mv.visitInsn(4);
/* 132 */       mv.visitJumpInsn(167, endOfIf);
/* 133 */       mv.visitLabel(rightNotNull);
/* 134 */       mv.visitInsn(3);
/* 135 */       mv.visitJumpInsn(167, endOfIf);
/* 136 */       mv.visitLabel(leftNotNull);
/* 137 */       mv.visitMethodInsn(182, "java/lang/Object", "equals", "(Ljava/lang/Object;)Z", false);
/* 138 */       mv.visitLabel(endOfIf);
/* 139 */       cf.pushDescriptor("Z");
/* 140 */       return;
/*     */     }
/* 142 */     mv.visitInsn(4);
/* 143 */     mv.visitJumpInsn(167, endOfIf);
/* 144 */     mv.visitLabel(elseTarget);
/* 145 */     mv.visitInsn(3);
/* 146 */     mv.visitLabel(endOfIf);
/* 147 */     cf.pushDescriptor("Z");
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\spel\ast\OpEQ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */