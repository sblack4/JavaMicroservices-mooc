/*     */ package org.springframework.expression.spel.support;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.BeanResolver;
/*     */ import org.springframework.expression.ConstructorResolver;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.MethodFilter;
/*     */ import org.springframework.expression.MethodResolver;
/*     */ import org.springframework.expression.OperatorOverloader;
/*     */ import org.springframework.expression.PropertyAccessor;
/*     */ import org.springframework.expression.TypeComparator;
/*     */ import org.springframework.expression.TypeConverter;
/*     */ import org.springframework.expression.TypeLocator;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardEvaluationContext
/*     */   implements EvaluationContext
/*     */ {
/*     */   private TypedValue rootObject;
/*     */   private List<ConstructorResolver> constructorResolvers;
/*     */   private List<MethodResolver> methodResolvers;
/*     */   private BeanResolver beanResolver;
/*     */   private ReflectiveMethodResolver reflectiveMethodResolver;
/*     */   private List<PropertyAccessor> propertyAccessors;
/*     */   private TypeLocator typeLocator;
/*     */   private TypeConverter typeConverter;
/*  67 */   private TypeComparator typeComparator = new StandardTypeComparator();
/*     */   
/*  69 */   private OperatorOverloader operatorOverloader = new StandardOperatorOverloader();
/*     */   
/*  71 */   private final Map<String, Object> variables = new HashMap();
/*     */   
/*     */   public StandardEvaluationContext()
/*     */   {
/*  75 */     setRootObject(null);
/*     */   }
/*     */   
/*     */   public StandardEvaluationContext(Object rootObject) {
/*  79 */     setRootObject(rootObject);
/*     */   }
/*     */   
/*     */   public void setRootObject(Object rootObject, TypeDescriptor typeDescriptor)
/*     */   {
/*  84 */     this.rootObject = new TypedValue(rootObject, typeDescriptor);
/*     */   }
/*     */   
/*     */   public void setRootObject(Object rootObject) {
/*  88 */     this.rootObject = (rootObject != null ? new TypedValue(rootObject) : TypedValue.NULL);
/*     */   }
/*     */   
/*     */   public TypedValue getRootObject()
/*     */   {
/*  93 */     return this.rootObject;
/*     */   }
/*     */   
/*     */   public void addConstructorResolver(ConstructorResolver resolver) {
/*  97 */     ensureConstructorResolversInitialized();
/*  98 */     this.constructorResolvers.add(this.constructorResolvers.size() - 1, resolver);
/*     */   }
/*     */   
/*     */   public boolean removeConstructorResolver(ConstructorResolver resolver) {
/* 102 */     ensureConstructorResolversInitialized();
/* 103 */     return this.constructorResolvers.remove(resolver);
/*     */   }
/*     */   
/*     */   public void setConstructorResolvers(List<ConstructorResolver> constructorResolvers) {
/* 107 */     this.constructorResolvers = constructorResolvers;
/*     */   }
/*     */   
/*     */   public List<ConstructorResolver> getConstructorResolvers()
/*     */   {
/* 112 */     ensureConstructorResolversInitialized();
/* 113 */     return this.constructorResolvers;
/*     */   }
/*     */   
/*     */   public void addMethodResolver(MethodResolver resolver) {
/* 117 */     ensureMethodResolversInitialized();
/* 118 */     this.methodResolvers.add(this.methodResolvers.size() - 1, resolver);
/*     */   }
/*     */   
/*     */   public boolean removeMethodResolver(MethodResolver methodResolver) {
/* 122 */     ensureMethodResolversInitialized();
/* 123 */     return this.methodResolvers.remove(methodResolver);
/*     */   }
/*     */   
/*     */   public void setMethodResolvers(List<MethodResolver> methodResolvers) {
/* 127 */     this.methodResolvers = methodResolvers;
/*     */   }
/*     */   
/*     */   public List<MethodResolver> getMethodResolvers()
/*     */   {
/* 132 */     ensureMethodResolversInitialized();
/* 133 */     return this.methodResolvers;
/*     */   }
/*     */   
/*     */   public void setBeanResolver(BeanResolver beanResolver) {
/* 137 */     this.beanResolver = beanResolver;
/*     */   }
/*     */   
/*     */   public BeanResolver getBeanResolver()
/*     */   {
/* 142 */     return this.beanResolver;
/*     */   }
/*     */   
/*     */   public void addPropertyAccessor(PropertyAccessor accessor) {
/* 146 */     ensurePropertyAccessorsInitialized();
/* 147 */     this.propertyAccessors.add(this.propertyAccessors.size() - 1, accessor);
/*     */   }
/*     */   
/*     */   public boolean removePropertyAccessor(PropertyAccessor accessor) {
/* 151 */     return this.propertyAccessors.remove(accessor);
/*     */   }
/*     */   
/*     */   public void setPropertyAccessors(List<PropertyAccessor> propertyAccessors) {
/* 155 */     this.propertyAccessors = propertyAccessors;
/*     */   }
/*     */   
/*     */   public List<PropertyAccessor> getPropertyAccessors()
/*     */   {
/* 160 */     ensurePropertyAccessorsInitialized();
/* 161 */     return this.propertyAccessors;
/*     */   }
/*     */   
/*     */   public void setTypeLocator(TypeLocator typeLocator) {
/* 165 */     Assert.notNull(typeLocator, "TypeLocator must not be null");
/* 166 */     this.typeLocator = typeLocator;
/*     */   }
/*     */   
/*     */   public TypeLocator getTypeLocator()
/*     */   {
/* 171 */     if (this.typeLocator == null) {
/* 172 */       this.typeLocator = new StandardTypeLocator();
/*     */     }
/* 174 */     return this.typeLocator;
/*     */   }
/*     */   
/*     */   public void setTypeConverter(TypeConverter typeConverter) {
/* 178 */     Assert.notNull(typeConverter, "TypeConverter must not be null");
/* 179 */     this.typeConverter = typeConverter;
/*     */   }
/*     */   
/*     */   public TypeConverter getTypeConverter()
/*     */   {
/* 184 */     if (this.typeConverter == null) {
/* 185 */       this.typeConverter = new StandardTypeConverter();
/*     */     }
/* 187 */     return this.typeConverter;
/*     */   }
/*     */   
/*     */   public void setTypeComparator(TypeComparator typeComparator) {
/* 191 */     Assert.notNull(typeComparator, "TypeComparator must not be null");
/* 192 */     this.typeComparator = typeComparator;
/*     */   }
/*     */   
/*     */   public TypeComparator getTypeComparator()
/*     */   {
/* 197 */     return this.typeComparator;
/*     */   }
/*     */   
/*     */   public void setOperatorOverloader(OperatorOverloader operatorOverloader) {
/* 201 */     Assert.notNull(operatorOverloader, "OperatorOverloader must not be null");
/* 202 */     this.operatorOverloader = operatorOverloader;
/*     */   }
/*     */   
/*     */   public OperatorOverloader getOperatorOverloader()
/*     */   {
/* 207 */     return this.operatorOverloader;
/*     */   }
/*     */   
/*     */   public void setVariable(String name, Object value)
/*     */   {
/* 212 */     this.variables.put(name, value);
/*     */   }
/*     */   
/*     */   public void setVariables(Map<String, Object> variables) {
/* 216 */     this.variables.putAll(variables);
/*     */   }
/*     */   
/*     */   public void registerFunction(String name, Method method) {
/* 220 */     this.variables.put(name, method);
/*     */   }
/*     */   
/*     */   public Object lookupVariable(String name)
/*     */   {
/* 225 */     return this.variables.get(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerMethodFilter(Class<?> type, MethodFilter filter)
/*     */     throws IllegalStateException
/*     */   {
/* 238 */     ensureMethodResolversInitialized();
/* 239 */     if (this.reflectiveMethodResolver != null) {
/* 240 */       this.reflectiveMethodResolver.registerMethodFilter(type, filter);
/*     */     }
/*     */     else {
/* 243 */       throw new IllegalStateException("Method filter cannot be set as the reflective method resolver is not in use");
/*     */     }
/*     */   }
/*     */   
/*     */   private void ensurePropertyAccessorsInitialized() {
/* 248 */     if (this.propertyAccessors == null) {
/* 249 */       initializePropertyAccessors();
/*     */     }
/*     */   }
/*     */   
/*     */   private synchronized void initializePropertyAccessors() {
/* 254 */     if (this.propertyAccessors == null) {
/* 255 */       List<PropertyAccessor> defaultAccessors = new ArrayList();
/* 256 */       defaultAccessors.add(new ReflectivePropertyAccessor());
/* 257 */       this.propertyAccessors = defaultAccessors;
/*     */     }
/*     */   }
/*     */   
/*     */   private void ensureMethodResolversInitialized() {
/* 262 */     if (this.methodResolvers == null) {
/* 263 */       initializeMethodResolvers();
/*     */     }
/*     */   }
/*     */   
/*     */   private synchronized void initializeMethodResolvers() {
/* 268 */     if (this.methodResolvers == null) {
/* 269 */       List<MethodResolver> defaultResolvers = new ArrayList();
/* 270 */       this.reflectiveMethodResolver = new ReflectiveMethodResolver();
/* 271 */       defaultResolvers.add(this.reflectiveMethodResolver);
/* 272 */       this.methodResolvers = defaultResolvers;
/*     */     }
/*     */   }
/*     */   
/*     */   private void ensureConstructorResolversInitialized() {
/* 277 */     if (this.constructorResolvers == null) {
/* 278 */       initializeConstructorResolvers();
/*     */     }
/*     */   }
/*     */   
/*     */   private synchronized void initializeConstructorResolvers() {
/* 283 */     if (this.constructorResolvers == null) {
/* 284 */       List<ConstructorResolver> defaultResolvers = new ArrayList();
/* 285 */       defaultResolvers.add(new ReflectiveConstructorResolver());
/* 286 */       this.constructorResolvers = defaultResolvers;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\spel\support\StandardEvaluationContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */