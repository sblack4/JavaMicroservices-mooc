/*     */ package org.springframework.expression.spel.support;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.AccessException;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.MethodExecutor;
/*     */ import org.springframework.expression.MethodFilter;
/*     */ import org.springframework.expression.MethodResolver;
/*     */ import org.springframework.expression.TypeConverter;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectiveMethodResolver
/*     */   implements MethodResolver
/*     */ {
/*     */   private final boolean useDistance;
/*     */   private Map<Class<?>, MethodFilter> filters;
/*     */   
/*     */   public ReflectiveMethodResolver()
/*     */   {
/*  65 */     this.useDistance = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReflectiveMethodResolver(boolean useDistance)
/*     */   {
/*  79 */     this.useDistance = useDistance;
/*     */   }
/*     */   
/*     */   public void registerMethodFilter(Class<?> type, MethodFilter filter)
/*     */   {
/*  84 */     if (this.filters == null) {
/*  85 */       this.filters = new HashMap();
/*     */     }
/*  87 */     if (filter != null) {
/*  88 */       this.filters.put(type, filter);
/*     */     }
/*     */     else {
/*  91 */       this.filters.remove(type);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MethodExecutor resolve(EvaluationContext context, Object targetObject, String name, List<TypeDescriptor> argumentTypes)
/*     */     throws AccessException
/*     */   {
/*     */     try
/*     */     {
/* 110 */       TypeConverter typeConverter = context.getTypeConverter();
/* 111 */       Class<?> type = (targetObject instanceof Class) ? (Class)targetObject : targetObject.getClass();
/* 112 */       List<Method> methods = new ArrayList(getMethods(type, targetObject));
/*     */       
/*     */ 
/* 115 */       MethodFilter filter = this.filters != null ? (MethodFilter)this.filters.get(type) : null;
/* 116 */       if (filter != null) {
/* 117 */         List<Method> filtered = filter.filter(methods);
/* 118 */         methods = (filtered instanceof ArrayList) ? filtered : new ArrayList(filtered);
/*     */       }
/*     */       
/*     */ 
/* 122 */       if (methods.size() > 1) {
/* 123 */         Collections.sort(methods, new Comparator()
/*     */         {
/*     */           public int compare(Method m1, Method m2) {
/* 126 */             int m1pl = m1.getParameterTypes().length;
/* 127 */             int m2pl = m2.getParameterTypes().length;
/*     */             
/* 129 */             if (m1pl == m2pl) {
/* 130 */               if ((!m1.isVarArgs()) && (m2.isVarArgs())) {
/* 131 */                 return -1;
/*     */               }
/* 133 */               if ((m1.isVarArgs()) && (!m2.isVarArgs())) {
/* 134 */                 return 1;
/*     */               }
/*     */               
/* 137 */               return 0;
/*     */             }
/*     */             
/* 140 */             return m1pl > m2pl ? 1 : m1pl < m2pl ? -1 : 0;
/*     */           }
/*     */         });
/*     */       }
/*     */       
/*     */ 
/* 146 */       for (int i = 0; i < methods.size(); i++) {
/* 147 */         methods.set(i, BridgeMethodResolver.findBridgedMethod((Method)methods.get(i)));
/*     */       }
/*     */       
/*     */ 
/* 151 */       Set<Method> methodsToIterate = new LinkedHashSet(methods);
/*     */       
/* 153 */       Method closeMatch = null;
/* 154 */       int closeMatchDistance = Integer.MAX_VALUE;
/* 155 */       Method matchRequiringConversion = null;
/* 156 */       boolean multipleOptions = false;
/*     */       
/* 158 */       for (Method method : methodsToIterate) {
/* 159 */         if (method.getName().equals(name)) {
/* 160 */           Class<?>[] paramTypes = method.getParameterTypes();
/* 161 */           List<TypeDescriptor> paramDescriptors = new ArrayList(paramTypes.length);
/* 162 */           for (int i = 0; i < paramTypes.length; i++) {
/* 163 */             paramDescriptors.add(new TypeDescriptor(new MethodParameter(method, i)));
/*     */           }
/* 165 */           ReflectionHelper.ArgumentsMatchInfo matchInfo = null;
/* 166 */           if ((method.isVarArgs()) && (argumentTypes.size() >= paramTypes.length - 1))
/*     */           {
/* 168 */             matchInfo = ReflectionHelper.compareArgumentsVarargs(paramDescriptors, argumentTypes, typeConverter);
/*     */           }
/* 170 */           else if (paramTypes.length == argumentTypes.size())
/*     */           {
/* 172 */             matchInfo = ReflectionHelper.compareArguments(paramDescriptors, argumentTypes, typeConverter);
/*     */           }
/* 174 */           if (matchInfo != null) {
/* 175 */             if (matchInfo.isExactMatch()) {
/* 176 */               return new ReflectiveMethodExecutor(method);
/*     */             }
/* 178 */             if (matchInfo.isCloseMatch()) {
/* 179 */               if (this.useDistance) {
/* 180 */                 int matchDistance = ReflectionHelper.getTypeDifferenceWeight(paramDescriptors, argumentTypes);
/* 181 */                 if ((closeMatch == null) || (matchDistance < closeMatchDistance))
/*     */                 {
/* 183 */                   closeMatch = method;
/* 184 */                   closeMatchDistance = matchDistance;
/*     */                 }
/*     */                 
/*     */ 
/*     */               }
/* 189 */               else if (closeMatch == null) {
/* 190 */                 closeMatch = method;
/*     */               }
/*     */               
/*     */             }
/* 194 */             else if (matchInfo.isMatchRequiringConversion()) {
/* 195 */               if (matchRequiringConversion != null) {
/* 196 */                 multipleOptions = true;
/*     */               }
/* 198 */               matchRequiringConversion = method;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 203 */       if (closeMatch != null) {
/* 204 */         return new ReflectiveMethodExecutor(closeMatch);
/*     */       }
/* 206 */       if (matchRequiringConversion != null) {
/* 207 */         if (multipleOptions) {
/* 208 */           throw new SpelEvaluationException(SpelMessage.MULTIPLE_POSSIBLE_METHODS, new Object[] { name });
/*     */         }
/* 210 */         return new ReflectiveMethodExecutor(matchRequiringConversion);
/*     */       }
/*     */       
/* 213 */       return null;
/*     */     }
/*     */     catch (EvaluationException ex)
/*     */     {
/* 217 */       throw new AccessException("Failed to resolve method", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private Collection<Method> getMethods(Class<?> type, Object targetObject) {
/* 222 */     if ((targetObject instanceof Class)) {
/* 223 */       Set<Method> result = new LinkedHashSet();
/*     */       
/* 225 */       Method[] methods = getMethods(type);
/* 226 */       for (Method method : methods) {
/* 227 */         if (Modifier.isStatic(method.getModifiers())) {
/* 228 */           result.add(method);
/*     */         }
/*     */       }
/*     */       
/* 232 */       result.addAll(Arrays.asList(getMethods(Class.class)));
/* 233 */       return result;
/*     */     }
/*     */     
/* 236 */     return Arrays.asList(getMethods(type));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Method[] getMethods(Class<?> type)
/*     */   {
/* 249 */     return type.getMethods();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\spel\support\ReflectiveMethodResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */