/*     */ package org.springframework.expression.spel.standard;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.asm.ClassWriter;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.asm.Opcodes;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.CompiledExpression;
/*     */ import org.springframework.expression.spel.ast.SpelNodeImpl;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpelCompiler
/*     */   implements Opcodes
/*     */ {
/*  70 */   private static final Log logger = LogFactory.getLog(SpelCompiler.class);
/*     */   
/*     */ 
/*     */ 
/*  74 */   private static final Map<ClassLoader, SpelCompiler> compilers = new ConcurrentReferenceHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */   private final ChildClassLoader ccl;
/*     */   
/*     */ 
/*     */ 
/*  82 */   private final AtomicInteger suffixId = new AtomicInteger(1);
/*     */   
/*     */   private SpelCompiler(ClassLoader classloader)
/*     */   {
/*  86 */     this.ccl = new ChildClassLoader(classloader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CompiledExpression compile(SpelNodeImpl expression)
/*     */   {
/* 101 */     if (expression.isCompilable()) {
/* 102 */       if (logger.isDebugEnabled()) {
/* 103 */         logger.debug("SpEL: compiling " + expression.toStringAST());
/*     */       }
/* 105 */       Class<? extends CompiledExpression> clazz = createExpressionClass(expression);
/* 106 */       if (clazz != null) {
/*     */         try {
/* 108 */           return (CompiledExpression)clazz.newInstance();
/*     */         }
/*     */         catch (Throwable ex) {
/* 111 */           throw new IllegalStateException("Failed to instantiate CompiledExpression", ex);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 116 */     if (logger.isDebugEnabled()) {
/* 117 */       logger.debug("SpEL: unable to compile " + expression.toStringAST());
/*     */     }
/* 119 */     return null;
/*     */   }
/*     */   
/*     */   private int getNextSuffix() {
/* 123 */     return this.suffixId.incrementAndGet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Class<? extends CompiledExpression> createExpressionClass(SpelNodeImpl expressionToCompile)
/*     */   {
/* 136 */     String clazzName = "spel/Ex" + getNextSuffix();
/* 137 */     ClassWriter cw = new ExpressionClassWriter();
/* 138 */     cw.visit(49, 1, clazzName, null, "org/springframework/expression/spel/CompiledExpression", null);
/*     */     
/*     */ 
/* 141 */     MethodVisitor mv = cw.visitMethod(1, "<init>", "()V", null, null);
/* 142 */     mv.visitCode();
/* 143 */     mv.visitVarInsn(25, 0);
/* 144 */     mv.visitMethodInsn(183, "org/springframework/expression/spel/CompiledExpression", "<init>", "()V", false);
/*     */     
/* 146 */     mv.visitInsn(177);
/* 147 */     mv.visitMaxs(1, 1);
/* 148 */     mv.visitEnd();
/*     */     
/*     */ 
/* 151 */     mv = cw.visitMethod(1, "getValue", "(Ljava/lang/Object;Lorg/springframework/expression/EvaluationContext;)Ljava/lang/Object;", null, new String[] { "org/springframework/expression/EvaluationException" });
/*     */     
/*     */ 
/* 154 */     mv.visitCode();
/*     */     
/* 156 */     CodeFlow cf = new CodeFlow(clazzName, cw);
/*     */     
/*     */     try
/*     */     {
/* 160 */       expressionToCompile.generateCode(mv, cf);
/*     */     }
/*     */     catch (IllegalStateException ex) {
/* 163 */       if (logger.isDebugEnabled()) {
/* 164 */         logger.debug(expressionToCompile.getClass().getSimpleName() + ".generateCode opted out of compilation: " + ex
/* 165 */           .getMessage());
/*     */       }
/* 167 */       return null;
/*     */     }
/*     */     
/* 170 */     CodeFlow.insertBoxIfNecessary(mv, cf.lastDescriptor());
/* 171 */     if ("V".equals(cf.lastDescriptor())) {
/* 172 */       mv.visitInsn(1);
/*     */     }
/* 174 */     mv.visitInsn(176);
/*     */     
/* 176 */     mv.visitMaxs(0, 0);
/* 177 */     mv.visitEnd();
/* 178 */     cw.visitEnd();
/*     */     
/* 180 */     cf.finish();
/*     */     
/* 182 */     byte[] data = cw.toByteArray();
/*     */     
/*     */ 
/* 185 */     return this.ccl.defineClass(clazzName.replaceAll("/", "."), data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SpelCompiler getCompiler(ClassLoader classLoader)
/*     */   {
/* 197 */     ClassLoader clToUse = classLoader != null ? classLoader : ClassUtils.getDefaultClassLoader();
/* 198 */     synchronized (compilers) {
/* 199 */       SpelCompiler compiler = (SpelCompiler)compilers.get(clToUse);
/* 200 */       if (compiler == null) {
/* 201 */         compiler = new SpelCompiler(clToUse);
/* 202 */         compilers.put(clToUse, compiler);
/*     */       }
/* 204 */       return compiler;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean compile(Expression expression)
/*     */   {
/* 215 */     return ((expression instanceof SpelExpression)) && (((SpelExpression)expression).compileExpression());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void revertToInterpreted(Expression expression)
/*     */   {
/* 224 */     if ((expression instanceof SpelExpression)) {
/* 225 */       ((SpelExpression)expression).revertToInterpreted();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void dump(String expressionText, String name, byte[] bytecode)
/*     */   {
/* 238 */     String nameToUse = name.replace('.', '/');
/* 239 */     String dir = nameToUse.indexOf('/') != -1 ? nameToUse.substring(0, nameToUse.lastIndexOf('/')) : "";
/* 240 */     String dumpLocation = null;
/*     */     try {
/* 242 */       File tempFile = File.createTempFile("tmp", null);
/* 243 */       dumpLocation = tempFile + File.separator + nameToUse + ".class";
/* 244 */       tempFile.delete();
/* 245 */       File f = new File(tempFile, dir);
/* 246 */       f.mkdirs();
/*     */       
/* 248 */       if (logger.isDebugEnabled()) {
/* 249 */         logger.debug("Expression '" + expressionText + "' compiled code dumped to " + dumpLocation);
/*     */       }
/* 251 */       f = new File(dumpLocation);
/* 252 */       FileOutputStream fos = new FileOutputStream(f);
/* 253 */       fos.write(bytecode);
/* 254 */       fos.flush();
/* 255 */       fos.close();
/*     */     }
/*     */     catch (IOException ex) {
/* 258 */       throw new IllegalStateException("Unexpected problem dumping class '" + nameToUse + "' into " + dumpLocation, ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class ChildClassLoader
/*     */     extends URLClassLoader
/*     */   {
/* 269 */     private static final URL[] NO_URLS = new URL[0];
/*     */     
/*     */     public ChildClassLoader(ClassLoader classLoader) {
/* 272 */       super(classLoader);
/*     */     }
/*     */     
/*     */     public Class<?> defineClass(String name, byte[] bytes) {
/* 276 */       return super.defineClass(name, bytes, 0, bytes.length);
/*     */     }
/*     */   }
/*     */   
/*     */   private class ExpressionClassWriter extends ClassWriter
/*     */   {
/*     */     public ExpressionClassWriter()
/*     */     {
/* 284 */       super();
/*     */     }
/*     */     
/*     */     protected ClassLoader getClassLoader()
/*     */     {
/* 289 */       return SpelCompiler.this.ccl;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\spel\standard\SpelCompiler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */