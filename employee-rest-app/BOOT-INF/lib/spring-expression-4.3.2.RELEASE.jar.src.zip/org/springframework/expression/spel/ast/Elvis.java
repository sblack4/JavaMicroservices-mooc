/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelNode;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Elvis
/*     */   extends SpelNodeImpl
/*     */ {
/*     */   public Elvis(int pos, SpelNodeImpl... args)
/*     */   {
/*  38 */     super(pos, args);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TypedValue getValueInternal(ExpressionState state)
/*     */     throws EvaluationException
/*     */   {
/*  51 */     TypedValue value = this.children[0].getValueInternal(state);
/*  52 */     if (!StringUtils.isEmpty(value.getValue())) {
/*  53 */       return value;
/*     */     }
/*     */     
/*  56 */     TypedValue result = this.children[1].getValueInternal(state);
/*  57 */     computeExitTypeDescriptor();
/*  58 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toStringAST()
/*     */   {
/*  64 */     return getChild(0).toStringAST() + " ?: " + getChild(1).toStringAST();
/*     */   }
/*     */   
/*     */   public boolean isCompilable()
/*     */   {
/*  69 */     SpelNodeImpl condition = this.children[0];
/*  70 */     SpelNodeImpl ifNullValue = this.children[1];
/*  71 */     return (condition.isCompilable()) && (ifNullValue.isCompilable()) && (condition.exitTypeDescriptor != null) && (ifNullValue.exitTypeDescriptor != null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf)
/*     */   {
/*  78 */     computeExitTypeDescriptor();
/*  79 */     this.children[0].generateCode(mv, cf);
/*  80 */     Label elseTarget = new Label();
/*  81 */     Label endOfIf = new Label();
/*  82 */     mv.visitInsn(89);
/*  83 */     mv.visitJumpInsn(198, elseTarget);
/*  84 */     mv.visitJumpInsn(167, endOfIf);
/*  85 */     mv.visitLabel(elseTarget);
/*  86 */     mv.visitInsn(87);
/*  87 */     this.children[1].generateCode(mv, cf);
/*  88 */     if (!CodeFlow.isPrimitive(this.exitTypeDescriptor)) {
/*  89 */       CodeFlow.insertBoxIfNecessary(mv, cf.lastDescriptor().charAt(0));
/*     */     }
/*  91 */     mv.visitLabel(endOfIf);
/*  92 */     cf.pushDescriptor(this.exitTypeDescriptor);
/*     */   }
/*     */   
/*     */   private void computeExitTypeDescriptor() {
/*  96 */     if ((this.exitTypeDescriptor == null) && (this.children[0].exitTypeDescriptor != null) && (this.children[1].exitTypeDescriptor != null))
/*     */     {
/*  98 */       String conditionDescriptor = this.children[0].exitTypeDescriptor;
/*  99 */       String ifNullValueDescriptor = this.children[1].exitTypeDescriptor;
/* 100 */       if (conditionDescriptor.equals(ifNullValueDescriptor)) {
/* 101 */         this.exitTypeDescriptor = conditionDescriptor;
/*     */       }
/* 103 */       else if ((conditionDescriptor.equals("Ljava/lang/Object")) && (!CodeFlow.isPrimitive(ifNullValueDescriptor))) {
/* 104 */         this.exitTypeDescriptor = ifNullValueDescriptor;
/*     */       }
/* 106 */       else if ((ifNullValueDescriptor.equals("Ljava/lang/Object")) && (!CodeFlow.isPrimitive(conditionDescriptor))) {
/* 107 */         this.exitTypeDescriptor = conditionDescriptor;
/*     */       }
/*     */       else
/*     */       {
/* 111 */         this.exitTypeDescriptor = "Ljava/lang/Object";
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\spel\ast\Elvis.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */