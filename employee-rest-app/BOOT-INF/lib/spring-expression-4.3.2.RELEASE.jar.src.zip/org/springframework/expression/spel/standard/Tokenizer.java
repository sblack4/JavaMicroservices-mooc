/*     */ package org.springframework.expression.spel.standard;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.expression.spel.InternalParseException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.expression.spel.SpelParseException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Tokenizer
/*     */ {
/*  38 */   private static final String[] ALTERNATIVE_OPERATOR_NAMES = { "DIV", "EQ", "GE", "GT", "LE", "LT", "MOD", "NE", "NOT" };
/*     */   
/*     */ 
/*  41 */   private static final byte[] FLAGS = new byte['Ā'];
/*     */   private static final byte IS_DIGIT = 1;
/*     */   private static final byte IS_HEXDIGIT = 2;
/*     */   private static final byte IS_ALPHA = 4;
/*     */   String expressionString;
/*     */   char[] toProcess;
/*     */   int pos;
/*     */   int max;
/*     */   
/*  50 */   static { for (int ch = 48; ch <= 57; ch++) {
/*  51 */       int tmp77_76 = ch; byte[] tmp77_73 = FLAGS;tmp77_73[tmp77_76] = ((byte)(tmp77_73[tmp77_76] | 0x3));
/*     */     }
/*  53 */     for (int ch = 65; ch <= 70; ch++) {
/*  54 */       int tmp102_101 = ch; byte[] tmp102_98 = FLAGS;tmp102_98[tmp102_101] = ((byte)(tmp102_98[tmp102_101] | 0x2));
/*     */     }
/*  56 */     for (int ch = 97; ch <= 102; ch++) {
/*  57 */       int tmp127_126 = ch; byte[] tmp127_123 = FLAGS;tmp127_123[tmp127_126] = ((byte)(tmp127_123[tmp127_126] | 0x2));
/*     */     }
/*  59 */     for (int ch = 65; ch <= 90; ch++) {
/*  60 */       int tmp152_151 = ch; byte[] tmp152_148 = FLAGS;tmp152_148[tmp152_151] = ((byte)(tmp152_148[tmp152_151] | 0x4));
/*     */     }
/*  62 */     for (int ch = 97; ch <= 122; ch++) {
/*  63 */       int tmp177_176 = ch; byte[] tmp177_173 = FLAGS;tmp177_173[tmp177_176] = ((byte)(tmp177_173[tmp177_176] | 0x4));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  76 */   List<Token> tokens = new ArrayList();
/*     */   
/*     */   public Tokenizer(String inputData)
/*     */   {
/*  80 */     this.expressionString = inputData;
/*  81 */     this.toProcess = (inputData + "\000").toCharArray();
/*  82 */     this.max = this.toProcess.length;
/*  83 */     this.pos = 0;
/*  84 */     process();
/*     */   }
/*     */   
/*     */   public void process()
/*     */   {
/*  89 */     while (this.pos < this.max) {
/*  90 */       char ch = this.toProcess[this.pos];
/*  91 */       if (isAlphabetic(ch)) {
/*  92 */         lexIdentifier();
/*     */       }
/*     */       else {
/*  95 */         switch (ch) {
/*     */         case '+': 
/*  97 */           if (isTwoCharToken(TokenKind.INC)) {
/*  98 */             pushPairToken(TokenKind.INC);
/*     */           }
/*     */           else {
/* 101 */             pushCharToken(TokenKind.PLUS);
/*     */           }
/* 103 */           break;
/*     */         case '_': 
/* 105 */           lexIdentifier();
/* 106 */           break;
/*     */         case '-': 
/* 108 */           if (isTwoCharToken(TokenKind.DEC)) {
/* 109 */             pushPairToken(TokenKind.DEC);
/*     */           }
/*     */           else {
/* 112 */             pushCharToken(TokenKind.MINUS);
/*     */           }
/* 114 */           break;
/*     */         case ':': 
/* 116 */           pushCharToken(TokenKind.COLON);
/* 117 */           break;
/*     */         case '.': 
/* 119 */           pushCharToken(TokenKind.DOT);
/* 120 */           break;
/*     */         case ',': 
/* 122 */           pushCharToken(TokenKind.COMMA);
/* 123 */           break;
/*     */         case '*': 
/* 125 */           pushCharToken(TokenKind.STAR);
/* 126 */           break;
/*     */         case '/': 
/* 128 */           pushCharToken(TokenKind.DIV);
/* 129 */           break;
/*     */         case '%': 
/* 131 */           pushCharToken(TokenKind.MOD);
/* 132 */           break;
/*     */         case '(': 
/* 134 */           pushCharToken(TokenKind.LPAREN);
/* 135 */           break;
/*     */         case ')': 
/* 137 */           pushCharToken(TokenKind.RPAREN);
/* 138 */           break;
/*     */         case '[': 
/* 140 */           pushCharToken(TokenKind.LSQUARE);
/* 141 */           break;
/*     */         case '#': 
/* 143 */           pushCharToken(TokenKind.HASH);
/* 144 */           break;
/*     */         case ']': 
/* 146 */           pushCharToken(TokenKind.RSQUARE);
/* 147 */           break;
/*     */         case '{': 
/* 149 */           pushCharToken(TokenKind.LCURLY);
/* 150 */           break;
/*     */         case '}': 
/* 152 */           pushCharToken(TokenKind.RCURLY);
/* 153 */           break;
/*     */         case '@': 
/* 155 */           pushCharToken(TokenKind.BEAN_REF);
/* 156 */           break;
/*     */         case '^': 
/* 158 */           if (isTwoCharToken(TokenKind.SELECT_FIRST)) {
/* 159 */             pushPairToken(TokenKind.SELECT_FIRST);
/*     */           }
/*     */           else {
/* 162 */             pushCharToken(TokenKind.POWER);
/*     */           }
/* 164 */           break;
/*     */         case '!': 
/* 166 */           if (isTwoCharToken(TokenKind.NE)) {
/* 167 */             pushPairToken(TokenKind.NE);
/*     */           }
/* 169 */           else if (isTwoCharToken(TokenKind.PROJECT)) {
/* 170 */             pushPairToken(TokenKind.PROJECT);
/*     */           }
/*     */           else {
/* 173 */             pushCharToken(TokenKind.NOT);
/*     */           }
/* 175 */           break;
/*     */         case '=': 
/* 177 */           if (isTwoCharToken(TokenKind.EQ)) {
/* 178 */             pushPairToken(TokenKind.EQ);
/*     */           }
/*     */           else {
/* 181 */             pushCharToken(TokenKind.ASSIGN);
/*     */           }
/* 183 */           break;
/*     */         case '&': 
/* 185 */           if (isTwoCharToken(TokenKind.SYMBOLIC_AND)) {
/* 186 */             pushPairToken(TokenKind.SYMBOLIC_AND);
/*     */           }
/*     */           else {
/* 189 */             pushCharToken(TokenKind.FACTORY_BEAN_REF);
/*     */           }
/* 191 */           break;
/*     */         case '|': 
/* 193 */           if (!isTwoCharToken(TokenKind.SYMBOLIC_OR)) {
/* 194 */             throw new InternalParseException(new SpelParseException(this.expressionString, this.pos, SpelMessage.MISSING_CHARACTER, new Object[] { "|" }));
/*     */           }
/*     */           
/*     */ 
/* 198 */           pushPairToken(TokenKind.SYMBOLIC_OR);
/* 199 */           break;
/*     */         case '?': 
/* 201 */           if (isTwoCharToken(TokenKind.SELECT)) {
/* 202 */             pushPairToken(TokenKind.SELECT);
/*     */           }
/* 204 */           else if (isTwoCharToken(TokenKind.ELVIS)) {
/* 205 */             pushPairToken(TokenKind.ELVIS);
/*     */           }
/* 207 */           else if (isTwoCharToken(TokenKind.SAFE_NAVI)) {
/* 208 */             pushPairToken(TokenKind.SAFE_NAVI);
/*     */           }
/*     */           else {
/* 211 */             pushCharToken(TokenKind.QMARK);
/*     */           }
/* 213 */           break;
/*     */         case '$': 
/* 215 */           if (isTwoCharToken(TokenKind.SELECT_LAST)) {
/* 216 */             pushPairToken(TokenKind.SELECT_LAST);
/*     */           }
/*     */           else {
/* 219 */             lexIdentifier();
/*     */           }
/* 221 */           break;
/*     */         case '>': 
/* 223 */           if (isTwoCharToken(TokenKind.GE)) {
/* 224 */             pushPairToken(TokenKind.GE);
/*     */           }
/*     */           else {
/* 227 */             pushCharToken(TokenKind.GT);
/*     */           }
/* 229 */           break;
/*     */         case '<': 
/* 231 */           if (isTwoCharToken(TokenKind.LE)) {
/* 232 */             pushPairToken(TokenKind.LE);
/*     */           }
/*     */           else {
/* 235 */             pushCharToken(TokenKind.LT);
/*     */           }
/* 237 */           break;
/*     */         case '0': 
/*     */         case '1': 
/*     */         case '2': 
/*     */         case '3': 
/*     */         case '4': 
/*     */         case '5': 
/*     */         case '6': 
/*     */         case '7': 
/*     */         case '8': 
/*     */         case '9': 
/* 248 */           lexNumericLiteral(ch == '0');
/* 249 */           break;
/*     */         
/*     */         case '\t': 
/*     */         case '\n': 
/*     */         case '\r': 
/*     */         case ' ': 
/* 255 */           this.pos += 1;
/* 256 */           break;
/*     */         case '\'': 
/* 258 */           lexQuotedStringLiteral();
/* 259 */           break;
/*     */         case '"': 
/* 261 */           lexDoubleQuotedStringLiteral();
/* 262 */           break;
/*     */         
/*     */         case '\000': 
/* 265 */           this.pos += 1;
/* 266 */           break;
/*     */         case '\\': 
/* 268 */           throw new InternalParseException(new SpelParseException(this.expressionString, this.pos, SpelMessage.UNEXPECTED_ESCAPE_CHAR, new Object[0]));
/*     */         case '\001': case '\002': case '\003': case '\004': case '\005': case '\006': case '\007': case '\b': case '\013': case '\f': case '\016': case '\017': case '\020': case '\021': case '\022': case '\023': case '\024': case '\025': case '\026': case '\027': case '\030': case '\031': case '\032': case '\033': case '\034': case '\035': case '\036': case '\037': case ';': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': 
/*     */         case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '`': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': case 'n': case 'o': case 'p': case 'q': case 'r': case 's': case 't': case 'u': case 'v': case 'w': case 'x': case 'y': case 'z': default: 
/* 271 */           throw new IllegalStateException("Cannot handle (" + Integer.valueOf(ch) + ") '" + ch + "'");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public List<Token> getTokens() {
/* 278 */     return this.tokens;
/*     */   }
/*     */   
/*     */   private void lexQuotedStringLiteral()
/*     */   {
/* 283 */     int start = this.pos;
/* 284 */     boolean terminated = false;
/* 285 */     while (!terminated) {
/* 286 */       this.pos += 1;
/* 287 */       char ch = this.toProcess[this.pos];
/* 288 */       if (ch == '\'')
/*     */       {
/* 290 */         if (this.toProcess[(this.pos + 1)] == '\'') {
/* 291 */           this.pos += 1;
/*     */         }
/*     */         else {
/* 294 */           terminated = true;
/*     */         }
/*     */       }
/* 297 */       if (ch == 0) {
/* 298 */         throw new InternalParseException(new SpelParseException(this.expressionString, start, SpelMessage.NON_TERMINATING_QUOTED_STRING, new Object[0]));
/*     */       }
/*     */     }
/*     */     
/* 302 */     this.pos += 1;
/* 303 */     this.tokens.add(new Token(TokenKind.LITERAL_STRING, subarray(start, this.pos), start, this.pos));
/*     */   }
/*     */   
/*     */   private void lexDoubleQuotedStringLiteral()
/*     */   {
/* 308 */     int start = this.pos;
/* 309 */     boolean terminated = false;
/* 310 */     while (!terminated) {
/* 311 */       this.pos += 1;
/* 312 */       char ch = this.toProcess[this.pos];
/* 313 */       if (ch == '"')
/*     */       {
/* 315 */         if (this.toProcess[(this.pos + 1)] == '"') {
/* 316 */           this.pos += 1;
/*     */         }
/*     */         else {
/* 319 */           terminated = true;
/*     */         }
/*     */       }
/* 322 */       if (ch == 0) {
/* 323 */         throw new InternalParseException(new SpelParseException(this.expressionString, start, SpelMessage.NON_TERMINATING_DOUBLE_QUOTED_STRING, new Object[0]));
/*     */       }
/*     */     }
/*     */     
/* 327 */     this.pos += 1;
/* 328 */     this.tokens.add(new Token(TokenKind.LITERAL_STRING, subarray(start, this.pos), start, this.pos));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void lexNumericLiteral(boolean firstCharIsZero)
/*     */   {
/* 348 */     boolean isReal = false;
/* 349 */     int start = this.pos;
/* 350 */     char ch = this.toProcess[(this.pos + 1)];
/* 351 */     boolean isHex = (ch == 'x') || (ch == 'X');
/*     */     
/*     */ 
/* 354 */     if ((firstCharIsZero) && (isHex)) {
/* 355 */       this.pos += 1;
/*     */       do {
/* 357 */         this.pos += 1;
/*     */       }
/* 359 */       while (isHexadecimalDigit(this.toProcess[this.pos]));
/* 360 */       if (isChar('L', 'l')) {
/* 361 */         pushHexIntToken(subarray(start + 2, this.pos), true, start, this.pos);
/* 362 */         this.pos += 1;
/*     */       }
/*     */       else {
/* 365 */         pushHexIntToken(subarray(start + 2, this.pos), false, start, this.pos);
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */       do
/*     */       {
/* 374 */         this.pos += 1;
/*     */       }
/* 376 */       while (isDigit(this.toProcess[this.pos]));
/*     */       
/*     */ 
/* 379 */       ch = this.toProcess[this.pos];
/* 380 */       if (ch == '.') {
/* 381 */         isReal = true;
/* 382 */         int dotpos = this.pos;
/*     */         do
/*     */         {
/* 385 */           this.pos += 1;
/*     */         }
/* 387 */         while (isDigit(this.toProcess[this.pos]));
/* 388 */         if (this.pos == dotpos + 1)
/*     */         {
/*     */ 
/*     */ 
/* 392 */           this.pos = dotpos;
/* 393 */           pushIntToken(subarray(start, this.pos), false, start, this.pos);
/* 394 */           return;
/*     */         }
/*     */       }
/*     */       
/* 398 */       int endOfNumber = this.pos;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 403 */       if (isChar('L', 'l')) {
/* 404 */         if (isReal) {
/* 405 */           throw new InternalParseException(new SpelParseException(this.expressionString, start, SpelMessage.REAL_CANNOT_BE_LONG, new Object[0]));
/*     */         }
/*     */         
/* 408 */         pushIntToken(subarray(start, endOfNumber), true, start, endOfNumber);
/* 409 */         this.pos += 1;
/*     */       }
/* 411 */       else if (isExponentChar(this.toProcess[this.pos])) {
/* 412 */         isReal = true;
/* 413 */         this.pos += 1;
/* 414 */         char possibleSign = this.toProcess[this.pos];
/* 415 */         if (isSign(possibleSign)) {
/* 416 */           this.pos += 1;
/*     */         }
/*     */         
/*     */         do
/*     */         {
/* 421 */           this.pos += 1;
/*     */         }
/* 423 */         while (isDigit(this.toProcess[this.pos]));
/* 424 */         boolean isFloat = false;
/* 425 */         if (isFloatSuffix(this.toProcess[this.pos])) {
/* 426 */           isFloat = true;
/* 427 */           endOfNumber = ++this.pos;
/*     */         }
/* 429 */         else if (isDoubleSuffix(this.toProcess[this.pos])) {
/* 430 */           endOfNumber = ++this.pos;
/*     */         }
/* 432 */         pushRealToken(subarray(start, this.pos), isFloat, start, this.pos);
/*     */       }
/*     */       else {
/* 435 */         ch = this.toProcess[this.pos];
/* 436 */         boolean isFloat = false;
/* 437 */         if (isFloatSuffix(ch)) {
/* 438 */           isReal = true;
/* 439 */           isFloat = true;
/* 440 */           endOfNumber = ++this.pos;
/*     */         }
/* 442 */         else if (isDoubleSuffix(ch)) {
/* 443 */           isReal = true;
/* 444 */           endOfNumber = ++this.pos;
/*     */         }
/* 446 */         if (isReal) {
/* 447 */           pushRealToken(subarray(start, endOfNumber), isFloat, start, endOfNumber);
/*     */         }
/*     */         else
/* 450 */           pushIntToken(subarray(start, endOfNumber), false, start, endOfNumber);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void lexIdentifier() {
/* 456 */     int start = this.pos;
/*     */     do {
/* 458 */       this.pos += 1;
/*     */     }
/* 460 */     while (isIdentifier(this.toProcess[this.pos]));
/* 461 */     char[] subarray = subarray(start, this.pos);
/*     */     
/*     */ 
/*     */ 
/* 465 */     if ((this.pos - start == 2) || (this.pos - start == 3)) {
/* 466 */       String asString = new String(subarray).toUpperCase();
/* 467 */       int idx = Arrays.binarySearch(ALTERNATIVE_OPERATOR_NAMES, asString);
/* 468 */       if (idx >= 0) {
/* 469 */         pushOneCharOrTwoCharToken(TokenKind.valueOf(asString), start, subarray);
/* 470 */         return;
/*     */       }
/*     */     }
/* 473 */     this.tokens.add(new Token(TokenKind.IDENTIFIER, subarray, start, this.pos));
/*     */   }
/*     */   
/*     */   private void pushIntToken(char[] data, boolean isLong, int start, int end) {
/* 477 */     if (isLong) {
/* 478 */       this.tokens.add(new Token(TokenKind.LITERAL_LONG, data, start, end));
/*     */     }
/*     */     else {
/* 481 */       this.tokens.add(new Token(TokenKind.LITERAL_INT, data, start, end));
/*     */     }
/*     */   }
/*     */   
/*     */   private void pushHexIntToken(char[] data, boolean isLong, int start, int end) {
/* 486 */     if (data.length == 0) {
/* 487 */       if (isLong)
/*     */       {
/* 489 */         throw new InternalParseException(new SpelParseException(this.expressionString, start, SpelMessage.NOT_A_LONG, new Object[] {this.expressionString.substring(start, end + 1) }));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 494 */       throw new InternalParseException(new SpelParseException(this.expressionString, start, SpelMessage.NOT_AN_INTEGER, new Object[] {this.expressionString.substring(start, end) }));
/*     */     }
/*     */     
/*     */ 
/* 498 */     if (isLong) {
/* 499 */       this.tokens.add(new Token(TokenKind.LITERAL_HEXLONG, data, start, end));
/*     */     }
/*     */     else {
/* 502 */       this.tokens.add(new Token(TokenKind.LITERAL_HEXINT, data, start, end));
/*     */     }
/*     */   }
/*     */   
/*     */   private void pushRealToken(char[] data, boolean isFloat, int start, int end) {
/* 507 */     if (isFloat) {
/* 508 */       this.tokens.add(new Token(TokenKind.LITERAL_REAL_FLOAT, data, start, end));
/*     */     }
/*     */     else {
/* 511 */       this.tokens.add(new Token(TokenKind.LITERAL_REAL, data, start, end));
/*     */     }
/*     */   }
/*     */   
/*     */   private char[] subarray(int start, int end) {
/* 516 */     char[] result = new char[end - start];
/* 517 */     System.arraycopy(this.toProcess, start, result, 0, end - start);
/* 518 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean isTwoCharToken(TokenKind kind)
/*     */   {
/* 525 */     Assert.isTrue(kind.tokenChars.length == 2);
/* 526 */     Assert.isTrue(this.toProcess[this.pos] == kind.tokenChars[0]);
/* 527 */     return this.toProcess[(this.pos + 1)] == kind.tokenChars[1];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void pushCharToken(TokenKind kind)
/*     */   {
/* 534 */     this.tokens.add(new Token(kind, this.pos, this.pos + 1));
/* 535 */     this.pos += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void pushPairToken(TokenKind kind)
/*     */   {
/* 542 */     this.tokens.add(new Token(kind, this.pos, this.pos + 2));
/* 543 */     this.pos += 2;
/*     */   }
/*     */   
/*     */   private void pushOneCharOrTwoCharToken(TokenKind kind, int pos, char[] data) {
/* 547 */     this.tokens.add(new Token(kind, data, pos, pos + kind.getLength()));
/*     */   }
/*     */   
/*     */   private boolean isIdentifier(char ch)
/*     */   {
/* 552 */     return (isAlphabetic(ch)) || (isDigit(ch)) || (ch == '_') || (ch == '$');
/*     */   }
/*     */   
/*     */   private boolean isChar(char a, char b) {
/* 556 */     char ch = this.toProcess[this.pos];
/* 557 */     return (ch == a) || (ch == b);
/*     */   }
/*     */   
/*     */   private boolean isExponentChar(char ch) {
/* 561 */     return (ch == 'e') || (ch == 'E');
/*     */   }
/*     */   
/*     */   private boolean isFloatSuffix(char ch) {
/* 565 */     return (ch == 'f') || (ch == 'F');
/*     */   }
/*     */   
/*     */   private boolean isDoubleSuffix(char ch) {
/* 569 */     return (ch == 'd') || (ch == 'D');
/*     */   }
/*     */   
/*     */   private boolean isSign(char ch) {
/* 573 */     return (ch == '+') || (ch == '-');
/*     */   }
/*     */   
/*     */   private boolean isDigit(char ch) {
/* 577 */     if (ch > 'ÿ') {
/* 578 */       return false;
/*     */     }
/* 580 */     return (FLAGS[ch] & 0x1) != 0;
/*     */   }
/*     */   
/*     */   private boolean isAlphabetic(char ch) {
/* 584 */     if (ch > 'ÿ') {
/* 585 */       return false;
/*     */     }
/* 587 */     return (FLAGS[ch] & 0x4) != 0;
/*     */   }
/*     */   
/*     */   private boolean isHexadecimalDigit(char ch) {
/* 591 */     if (ch > 'ÿ') {
/* 592 */       return false;
/*     */     }
/* 594 */     return (FLAGS[ch] & 0x2) != 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\spel\standard\Tokenizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */