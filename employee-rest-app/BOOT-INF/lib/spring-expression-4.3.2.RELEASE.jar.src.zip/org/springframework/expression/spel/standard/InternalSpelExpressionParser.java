/*      */ package org.springframework.expression.spel.standard;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Stack;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import org.springframework.expression.ParseException;
/*      */ import org.springframework.expression.ParserContext;
/*      */ import org.springframework.expression.common.TemplateAwareExpressionParser;
/*      */ import org.springframework.expression.spel.InternalParseException;
/*      */ import org.springframework.expression.spel.SpelMessage;
/*      */ import org.springframework.expression.spel.SpelParseException;
/*      */ import org.springframework.expression.spel.SpelParserConfiguration;
/*      */ import org.springframework.expression.spel.ast.Assign;
/*      */ import org.springframework.expression.spel.ast.BeanReference;
/*      */ import org.springframework.expression.spel.ast.BooleanLiteral;
/*      */ import org.springframework.expression.spel.ast.CompoundExpression;
/*      */ import org.springframework.expression.spel.ast.ConstructorReference;
/*      */ import org.springframework.expression.spel.ast.Elvis;
/*      */ import org.springframework.expression.spel.ast.FunctionReference;
/*      */ import org.springframework.expression.spel.ast.Identifier;
/*      */ import org.springframework.expression.spel.ast.Indexer;
/*      */ import org.springframework.expression.spel.ast.InlineList;
/*      */ import org.springframework.expression.spel.ast.InlineMap;
/*      */ import org.springframework.expression.spel.ast.Literal;
/*      */ import org.springframework.expression.spel.ast.MethodReference;
/*      */ import org.springframework.expression.spel.ast.NullLiteral;
/*      */ import org.springframework.expression.spel.ast.OpAnd;
/*      */ import org.springframework.expression.spel.ast.OpDec;
/*      */ import org.springframework.expression.spel.ast.OpDivide;
/*      */ import org.springframework.expression.spel.ast.OpEQ;
/*      */ import org.springframework.expression.spel.ast.OpGE;
/*      */ import org.springframework.expression.spel.ast.OpGT;
/*      */ import org.springframework.expression.spel.ast.OpInc;
/*      */ import org.springframework.expression.spel.ast.OpLE;
/*      */ import org.springframework.expression.spel.ast.OpLT;
/*      */ import org.springframework.expression.spel.ast.OpMinus;
/*      */ import org.springframework.expression.spel.ast.OpModulus;
/*      */ import org.springframework.expression.spel.ast.OpMultiply;
/*      */ import org.springframework.expression.spel.ast.OpNE;
/*      */ import org.springframework.expression.spel.ast.OpOr;
/*      */ import org.springframework.expression.spel.ast.OpPlus;
/*      */ import org.springframework.expression.spel.ast.OperatorBetween;
/*      */ import org.springframework.expression.spel.ast.OperatorInstanceof;
/*      */ import org.springframework.expression.spel.ast.OperatorMatches;
/*      */ import org.springframework.expression.spel.ast.OperatorNot;
/*      */ import org.springframework.expression.spel.ast.OperatorPower;
/*      */ import org.springframework.expression.spel.ast.Projection;
/*      */ import org.springframework.expression.spel.ast.PropertyOrFieldReference;
/*      */ import org.springframework.expression.spel.ast.QualifiedIdentifier;
/*      */ import org.springframework.expression.spel.ast.Selection;
/*      */ import org.springframework.expression.spel.ast.SpelNodeImpl;
/*      */ import org.springframework.expression.spel.ast.StringLiteral;
/*      */ import org.springframework.expression.spel.ast.Ternary;
/*      */ import org.springframework.expression.spel.ast.TypeReference;
/*      */ import org.springframework.expression.spel.ast.VariableReference;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class InternalSpelExpressionParser
/*      */   extends TemplateAwareExpressionParser
/*      */ {
/*   87 */   private static final Pattern VALID_QUALIFIED_ID_PATTERN = Pattern.compile("[\\p{L}\\p{N}_$]+");
/*      */   
/*      */ 
/*      */   private final SpelParserConfiguration configuration;
/*      */   
/*      */ 
/*   93 */   private final Stack<SpelNodeImpl> constructedNodes = new Stack();
/*      */   
/*      */ 
/*      */ 
/*      */   private String expressionString;
/*      */   
/*      */ 
/*      */ 
/*      */   private List<Token> tokenStream;
/*      */   
/*      */ 
/*      */   private int tokenStreamLength;
/*      */   
/*      */ 
/*      */   private int tokenStreamPointer;
/*      */   
/*      */ 
/*      */ 
/*      */   public InternalSpelExpressionParser(SpelParserConfiguration configuration)
/*      */   {
/*  113 */     this.configuration = configuration;
/*      */   }
/*      */   
/*      */   protected SpelExpression doParseExpression(String expressionString, ParserContext context) throws ParseException
/*      */   {
/*      */     try
/*      */     {
/*  120 */       this.expressionString = expressionString;
/*  121 */       Tokenizer tokenizer = new Tokenizer(expressionString);
/*  122 */       tokenizer.process();
/*  123 */       this.tokenStream = tokenizer.getTokens();
/*  124 */       this.tokenStreamLength = this.tokenStream.size();
/*  125 */       this.tokenStreamPointer = 0;
/*  126 */       this.constructedNodes.clear();
/*  127 */       SpelNodeImpl ast = eatExpression();
/*  128 */       if (moreTokens()) {
/*  129 */         throw new SpelParseException(peekToken().startPos, SpelMessage.MORE_INPUT, new Object[] { toString(nextToken()) });
/*      */       }
/*  131 */       Assert.isTrue(this.constructedNodes.isEmpty());
/*  132 */       return new SpelExpression(expressionString, ast, this.configuration);
/*      */     }
/*      */     catch (InternalParseException ex) {
/*  135 */       throw ex.getCause();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private SpelNodeImpl eatExpression()
/*      */   {
/*  146 */     SpelNodeImpl expr = eatLogicalOrExpression();
/*  147 */     if (moreTokens()) {
/*  148 */       Token t = peekToken();
/*  149 */       if (t.kind == TokenKind.ASSIGN) {
/*  150 */         if (expr == null) {
/*  151 */           expr = new NullLiteral(toPos(t.startPos - 1, t.endPos - 1));
/*      */         }
/*  153 */         nextToken();
/*  154 */         SpelNodeImpl assignedValue = eatLogicalOrExpression();
/*  155 */         return new Assign(toPos(t), new SpelNodeImpl[] { expr, assignedValue });
/*      */       }
/*      */       
/*  158 */       if (t.kind == TokenKind.ELVIS) {
/*  159 */         if (expr == null) {
/*  160 */           expr = new NullLiteral(toPos(t.startPos - 1, t.endPos - 2));
/*      */         }
/*  162 */         nextToken();
/*  163 */         SpelNodeImpl valueIfNull = eatExpression();
/*  164 */         if (valueIfNull == null) {
/*  165 */           valueIfNull = new NullLiteral(toPos(t.startPos + 1, t.endPos + 1));
/*      */         }
/*  167 */         return new Elvis(toPos(t), new SpelNodeImpl[] { expr, valueIfNull });
/*      */       }
/*      */       
/*  170 */       if (t.kind == TokenKind.QMARK) {
/*  171 */         if (expr == null) {
/*  172 */           expr = new NullLiteral(toPos(t.startPos - 1, t.endPos - 1));
/*      */         }
/*  174 */         nextToken();
/*  175 */         SpelNodeImpl ifTrueExprValue = eatExpression();
/*  176 */         eatToken(TokenKind.COLON);
/*  177 */         SpelNodeImpl ifFalseExprValue = eatExpression();
/*  178 */         return new Ternary(toPos(t), new SpelNodeImpl[] { expr, ifTrueExprValue, ifFalseExprValue });
/*      */       }
/*      */     }
/*  181 */     return expr;
/*      */   }
/*      */   
/*      */   private SpelNodeImpl eatLogicalOrExpression()
/*      */   {
/*  186 */     SpelNodeImpl expr = eatLogicalAndExpression();
/*  187 */     while ((peekIdentifierToken("or")) || (peekToken(TokenKind.SYMBOLIC_OR))) {
/*  188 */       Token t = nextToken();
/*  189 */       SpelNodeImpl rhExpr = eatLogicalAndExpression();
/*  190 */       checkOperands(t, expr, rhExpr);
/*  191 */       expr = new OpOr(toPos(t), new SpelNodeImpl[] { expr, rhExpr });
/*      */     }
/*  193 */     return expr;
/*      */   }
/*      */   
/*      */   private SpelNodeImpl eatLogicalAndExpression()
/*      */   {
/*  198 */     SpelNodeImpl expr = eatRelationalExpression();
/*  199 */     while ((peekIdentifierToken("and")) || (peekToken(TokenKind.SYMBOLIC_AND))) {
/*  200 */       Token t = nextToken();
/*  201 */       SpelNodeImpl rhExpr = eatRelationalExpression();
/*  202 */       checkOperands(t, expr, rhExpr);
/*  203 */       expr = new OpAnd(toPos(t), new SpelNodeImpl[] { expr, rhExpr });
/*      */     }
/*  205 */     return expr;
/*      */   }
/*      */   
/*      */   private SpelNodeImpl eatRelationalExpression()
/*      */   {
/*  210 */     SpelNodeImpl expr = eatSumExpression();
/*  211 */     Token relationalOperatorToken = maybeEatRelationalOperator();
/*  212 */     if (relationalOperatorToken != null) {
/*  213 */       Token t = nextToken();
/*  214 */       SpelNodeImpl rhExpr = eatSumExpression();
/*  215 */       checkOperands(t, expr, rhExpr);
/*  216 */       TokenKind tk = relationalOperatorToken.kind;
/*      */       
/*  218 */       if (relationalOperatorToken.isNumericRelationalOperator()) {
/*  219 */         int pos = toPos(t);
/*  220 */         if (tk == TokenKind.GT) {
/*  221 */           return new OpGT(pos, new SpelNodeImpl[] { expr, rhExpr });
/*      */         }
/*  223 */         if (tk == TokenKind.LT) {
/*  224 */           return new OpLT(pos, new SpelNodeImpl[] { expr, rhExpr });
/*      */         }
/*  226 */         if (tk == TokenKind.LE) {
/*  227 */           return new OpLE(pos, new SpelNodeImpl[] { expr, rhExpr });
/*      */         }
/*  229 */         if (tk == TokenKind.GE) {
/*  230 */           return new OpGE(pos, new SpelNodeImpl[] { expr, rhExpr });
/*      */         }
/*  232 */         if (tk == TokenKind.EQ) {
/*  233 */           return new OpEQ(pos, new SpelNodeImpl[] { expr, rhExpr });
/*      */         }
/*  235 */         Assert.isTrue(tk == TokenKind.NE);
/*  236 */         return new OpNE(pos, new SpelNodeImpl[] { expr, rhExpr });
/*      */       }
/*      */       
/*  239 */       if (tk == TokenKind.INSTANCEOF) {
/*  240 */         return new OperatorInstanceof(toPos(t), new SpelNodeImpl[] { expr, rhExpr });
/*      */       }
/*      */       
/*  243 */       if (tk == TokenKind.MATCHES) {
/*  244 */         return new OperatorMatches(toPos(t), new SpelNodeImpl[] { expr, rhExpr });
/*      */       }
/*      */       
/*  247 */       Assert.isTrue(tk == TokenKind.BETWEEN);
/*  248 */       return new OperatorBetween(toPos(t), new SpelNodeImpl[] { expr, rhExpr });
/*      */     }
/*  250 */     return expr;
/*      */   }
/*      */   
/*      */   private SpelNodeImpl eatSumExpression()
/*      */   {
/*  255 */     SpelNodeImpl expr = eatProductExpression();
/*  256 */     while (peekToken(TokenKind.PLUS, TokenKind.MINUS, TokenKind.INC)) {
/*  257 */       Token t = nextToken();
/*  258 */       SpelNodeImpl rhExpr = eatProductExpression();
/*  259 */       checkRightOperand(t, rhExpr);
/*  260 */       if (t.kind == TokenKind.PLUS) {
/*  261 */         expr = new OpPlus(toPos(t), new SpelNodeImpl[] { expr, rhExpr });
/*      */       }
/*  263 */       else if (t.kind == TokenKind.MINUS) {
/*  264 */         expr = new OpMinus(toPos(t), new SpelNodeImpl[] { expr, rhExpr });
/*      */       }
/*      */     }
/*  267 */     return expr;
/*      */   }
/*      */   
/*      */   private SpelNodeImpl eatProductExpression()
/*      */   {
/*  272 */     SpelNodeImpl expr = eatPowerIncDecExpression();
/*  273 */     while (peekToken(TokenKind.STAR, TokenKind.DIV, TokenKind.MOD)) {
/*  274 */       Token t = nextToken();
/*  275 */       SpelNodeImpl rhExpr = eatPowerIncDecExpression();
/*  276 */       checkOperands(t, expr, rhExpr);
/*  277 */       if (t.kind == TokenKind.STAR) {
/*  278 */         expr = new OpMultiply(toPos(t), new SpelNodeImpl[] { expr, rhExpr });
/*      */       }
/*  280 */       else if (t.kind == TokenKind.DIV) {
/*  281 */         expr = new OpDivide(toPos(t), new SpelNodeImpl[] { expr, rhExpr });
/*      */       }
/*      */       else {
/*  284 */         Assert.isTrue(t.kind == TokenKind.MOD);
/*  285 */         expr = new OpModulus(toPos(t), new SpelNodeImpl[] { expr, rhExpr });
/*      */       }
/*      */     }
/*  288 */     return expr;
/*      */   }
/*      */   
/*      */   private SpelNodeImpl eatPowerIncDecExpression()
/*      */   {
/*  293 */     SpelNodeImpl expr = eatUnaryExpression();
/*  294 */     if (peekToken(TokenKind.POWER)) {
/*  295 */       Token t = nextToken();
/*  296 */       SpelNodeImpl rhExpr = eatUnaryExpression();
/*  297 */       checkRightOperand(t, rhExpr);
/*  298 */       return new OperatorPower(toPos(t), new SpelNodeImpl[] { expr, rhExpr });
/*      */     }
/*      */     
/*  301 */     if ((expr != null) && (peekToken(TokenKind.INC, TokenKind.DEC))) {
/*  302 */       Token t = nextToken();
/*  303 */       if (t.getKind() == TokenKind.INC) {
/*  304 */         return new OpInc(toPos(t), true, new SpelNodeImpl[] { expr });
/*      */       }
/*  306 */       return new OpDec(toPos(t), true, new SpelNodeImpl[] { expr });
/*      */     }
/*      */     
/*  309 */     return expr;
/*      */   }
/*      */   
/*      */   private SpelNodeImpl eatUnaryExpression()
/*      */   {
/*  314 */     if (peekToken(TokenKind.PLUS, TokenKind.MINUS, TokenKind.NOT)) {
/*  315 */       Token t = nextToken();
/*  316 */       SpelNodeImpl expr = eatUnaryExpression();
/*  317 */       if (t.kind == TokenKind.NOT) {
/*  318 */         return new OperatorNot(toPos(t), expr);
/*      */       }
/*      */       
/*  321 */       if (t.kind == TokenKind.PLUS) {
/*  322 */         return new OpPlus(toPos(t), new SpelNodeImpl[] { expr });
/*      */       }
/*  324 */       Assert.isTrue(t.kind == TokenKind.MINUS);
/*  325 */       return new OpMinus(toPos(t), new SpelNodeImpl[] { expr });
/*      */     }
/*      */     
/*  328 */     if (peekToken(TokenKind.INC, TokenKind.DEC)) {
/*  329 */       Token t = nextToken();
/*  330 */       SpelNodeImpl expr = eatUnaryExpression();
/*  331 */       if (t.getKind() == TokenKind.INC) {
/*  332 */         return new OpInc(toPos(t), false, new SpelNodeImpl[] { expr });
/*      */       }
/*  334 */       return new OpDec(toPos(t), false, new SpelNodeImpl[] { expr });
/*      */     }
/*      */     
/*  337 */     return eatPrimaryExpression();
/*      */   }
/*      */   
/*      */   private SpelNodeImpl eatPrimaryExpression()
/*      */   {
/*  342 */     List<SpelNodeImpl> nodes = new ArrayList();
/*  343 */     SpelNodeImpl start = eatStartNode();
/*  344 */     nodes.add(start);
/*  345 */     while (maybeEatNode()) {
/*  346 */       nodes.add(pop());
/*      */     }
/*  348 */     if (nodes.size() == 1) {
/*  349 */       return (SpelNodeImpl)nodes.get(0);
/*      */     }
/*      */     
/*      */ 
/*  353 */     return new CompoundExpression(toPos(start.getStartPosition(), ((SpelNodeImpl)nodes.get(nodes.size() - 1)).getEndPosition()), (SpelNodeImpl[])nodes.toArray(new SpelNodeImpl[nodes.size()]));
/*      */   }
/*      */   
/*      */   private boolean maybeEatNode()
/*      */   {
/*  358 */     SpelNodeImpl expr = null;
/*  359 */     if (peekToken(TokenKind.DOT, TokenKind.SAFE_NAVI)) {
/*  360 */       expr = eatDottedNode();
/*      */     }
/*      */     else {
/*  363 */       expr = maybeEatNonDottedNode();
/*      */     }
/*      */     
/*  366 */     if (expr == null) {
/*  367 */       return false;
/*      */     }
/*      */     
/*  370 */     push(expr);
/*  371 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */   private SpelNodeImpl maybeEatNonDottedNode()
/*      */   {
/*  377 */     if ((peekToken(TokenKind.LSQUARE)) && 
/*  378 */       (maybeEatIndexer())) {
/*  379 */       return pop();
/*      */     }
/*      */     
/*  382 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private SpelNodeImpl eatDottedNode()
/*      */   {
/*  395 */     Token t = nextToken();
/*  396 */     boolean nullSafeNavigation = t.kind == TokenKind.SAFE_NAVI;
/*  397 */     if ((maybeEatMethodOrProperty(nullSafeNavigation)) || (maybeEatFunctionOrVar()) || 
/*  398 */       (maybeEatProjection(nullSafeNavigation)) || 
/*  399 */       (maybeEatSelection(nullSafeNavigation))) {
/*  400 */       return pop();
/*      */     }
/*  402 */     if (peekToken() == null)
/*      */     {
/*  404 */       raiseInternalException(t.startPos, SpelMessage.OOD, new Object[0]);
/*      */     }
/*      */     else {
/*  407 */       raiseInternalException(t.startPos, SpelMessage.UNEXPECTED_DATA_AFTER_DOT, new Object[] {
/*  408 */         toString(peekToken()) });
/*      */     }
/*  410 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean maybeEatFunctionOrVar()
/*      */   {
/*  420 */     if (!peekToken(TokenKind.HASH)) {
/*  421 */       return false;
/*      */     }
/*  423 */     Token t = nextToken();
/*  424 */     Token functionOrVariableName = eatToken(TokenKind.IDENTIFIER);
/*  425 */     SpelNodeImpl[] args = maybeEatMethodArgs();
/*  426 */     if (args == null) {
/*  427 */       push(new VariableReference(functionOrVariableName.data, toPos(t.startPos, functionOrVariableName.endPos)));
/*      */       
/*  429 */       return true;
/*      */     }
/*      */     
/*  432 */     push(new FunctionReference(functionOrVariableName.data, toPos(t.startPos, functionOrVariableName.endPos), args));
/*      */     
/*  434 */     return true;
/*      */   }
/*      */   
/*      */   private SpelNodeImpl[] maybeEatMethodArgs()
/*      */   {
/*  439 */     if (!peekToken(TokenKind.LPAREN)) {
/*  440 */       return null;
/*      */     }
/*  442 */     List<SpelNodeImpl> args = new ArrayList();
/*  443 */     consumeArguments(args);
/*  444 */     eatToken(TokenKind.RPAREN);
/*  445 */     return (SpelNodeImpl[])args.toArray(new SpelNodeImpl[args.size()]);
/*      */   }
/*      */   
/*      */   private void eatConstructorArgs(List<SpelNodeImpl> accumulatedArguments) {
/*  449 */     if (!peekToken(TokenKind.LPAREN)) {
/*  450 */       throw new InternalParseException(new SpelParseException(this.expressionString, positionOf(peekToken()), SpelMessage.MISSING_CONSTRUCTOR_ARGS, new Object[0]));
/*      */     }
/*  452 */     consumeArguments(accumulatedArguments);
/*  453 */     eatToken(TokenKind.RPAREN);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void consumeArguments(List<SpelNodeImpl> accumulatedArguments)
/*      */   {
/*  460 */     int pos = peekToken().startPos;
/*      */     Token next;
/*      */     do {
/*  463 */       nextToken();
/*  464 */       Token t = peekToken();
/*  465 */       if (t == null) {
/*  466 */         raiseInternalException(pos, SpelMessage.RUN_OUT_OF_ARGUMENTS, new Object[0]);
/*      */       }
/*  468 */       if (t.kind != TokenKind.RPAREN) {
/*  469 */         accumulatedArguments.add(eatExpression());
/*      */       }
/*  471 */       next = peekToken();
/*      */     }
/*  473 */     while ((next != null) && (next.kind == TokenKind.COMMA));
/*      */     
/*  475 */     if (next == null) {
/*  476 */       raiseInternalException(pos, SpelMessage.RUN_OUT_OF_ARGUMENTS, new Object[0]);
/*      */     }
/*      */   }
/*      */   
/*      */   private int positionOf(Token t) {
/*  481 */     if (t == null)
/*      */     {
/*      */ 
/*  484 */       return this.expressionString.length();
/*      */     }
/*  486 */     return t.startPos;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private SpelNodeImpl eatStartNode()
/*      */   {
/*  501 */     if (maybeEatLiteral()) {
/*  502 */       return pop();
/*      */     }
/*  504 */     if (maybeEatParenExpression()) {
/*  505 */       return pop();
/*      */     }
/*  507 */     if ((maybeEatTypeReference()) || (maybeEatNullReference()) || (maybeEatConstructorReference()) || 
/*  508 */       (maybeEatMethodOrProperty(false)) || (maybeEatFunctionOrVar())) {
/*  509 */       return pop();
/*      */     }
/*  511 */     if (maybeEatBeanReference()) {
/*  512 */       return pop();
/*      */     }
/*  514 */     if ((maybeEatProjection(false)) || (maybeEatSelection(false)) || (maybeEatIndexer())) {
/*  515 */       return pop();
/*      */     }
/*  517 */     if (maybeEatInlineListOrMap()) {
/*  518 */       return pop();
/*      */     }
/*      */     
/*  521 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean maybeEatBeanReference()
/*      */   {
/*  528 */     if ((peekToken(TokenKind.BEAN_REF)) || (peekToken(TokenKind.FACTORY_BEAN_REF))) {
/*  529 */       Token beanRefToken = nextToken();
/*  530 */       Token beanNameToken = null;
/*  531 */       String beanName = null;
/*  532 */       if (peekToken(TokenKind.IDENTIFIER)) {
/*  533 */         beanNameToken = eatToken(TokenKind.IDENTIFIER);
/*  534 */         beanName = beanNameToken.data;
/*      */       }
/*  536 */       else if (peekToken(TokenKind.LITERAL_STRING)) {
/*  537 */         beanNameToken = eatToken(TokenKind.LITERAL_STRING);
/*  538 */         beanName = beanNameToken.stringValue();
/*  539 */         beanName = beanName.substring(1, beanName.length() - 1);
/*      */       }
/*      */       else {
/*  542 */         raiseInternalException(beanRefToken.startPos, SpelMessage.INVALID_BEAN_REFERENCE, new Object[0]);
/*      */       }
/*      */       
/*      */ 
/*  546 */       BeanReference beanReference = null;
/*  547 */       if (beanRefToken.getKind() == TokenKind.FACTORY_BEAN_REF) {
/*  548 */         String beanNameString = TokenKind.FACTORY_BEAN_REF.tokenChars + beanName;
/*  549 */         beanReference = new BeanReference(toPos(beanRefToken.startPos, beanNameToken.endPos), beanNameString);
/*      */       }
/*      */       else {
/*  552 */         beanReference = new BeanReference(toPos(beanNameToken), beanName);
/*      */       }
/*  554 */       this.constructedNodes.push(beanReference);
/*  555 */       return true;
/*      */     }
/*  557 */     return false;
/*      */   }
/*      */   
/*      */   private boolean maybeEatTypeReference() {
/*  561 */     if (peekToken(TokenKind.IDENTIFIER)) {
/*  562 */       Token typeName = peekToken();
/*  563 */       if (!typeName.stringValue().equals("T")) {
/*  564 */         return false;
/*      */       }
/*      */       
/*  567 */       Token t = nextToken();
/*  568 */       if (peekToken(TokenKind.RSQUARE))
/*      */       {
/*  570 */         push(new PropertyOrFieldReference(false, t.data, toPos(t)));
/*  571 */         return true;
/*      */       }
/*  573 */       eatToken(TokenKind.LPAREN);
/*  574 */       SpelNodeImpl node = eatPossiblyQualifiedId();
/*      */       
/*      */ 
/*  577 */       int dims = 0;
/*  578 */       while (peekToken(TokenKind.LSQUARE, true)) {
/*  579 */         eatToken(TokenKind.RSQUARE);
/*  580 */         dims++;
/*      */       }
/*  582 */       eatToken(TokenKind.RPAREN);
/*  583 */       this.constructedNodes.push(new TypeReference(toPos(typeName), node, dims));
/*  584 */       return true;
/*      */     }
/*  586 */     return false;
/*      */   }
/*      */   
/*      */   private boolean maybeEatNullReference() {
/*  590 */     if (peekToken(TokenKind.IDENTIFIER)) {
/*  591 */       Token nullToken = peekToken();
/*  592 */       if (!nullToken.stringValue().equalsIgnoreCase("null")) {
/*  593 */         return false;
/*      */       }
/*  595 */       nextToken();
/*  596 */       this.constructedNodes.push(new NullLiteral(toPos(nullToken)));
/*  597 */       return true;
/*      */     }
/*  599 */     return false;
/*      */   }
/*      */   
/*      */   private boolean maybeEatProjection(boolean nullSafeNavigation)
/*      */   {
/*  604 */     Token t = peekToken();
/*  605 */     if (!peekToken(TokenKind.PROJECT, true)) {
/*  606 */       return false;
/*      */     }
/*  608 */     SpelNodeImpl expr = eatExpression();
/*  609 */     eatToken(TokenKind.RSQUARE);
/*  610 */     this.constructedNodes.push(new Projection(nullSafeNavigation, toPos(t), expr));
/*  611 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean maybeEatInlineListOrMap()
/*      */   {
/*  617 */     Token t = peekToken();
/*  618 */     if (!peekToken(TokenKind.LCURLY, true)) {
/*  619 */       return false;
/*      */     }
/*  621 */     SpelNodeImpl expr = null;
/*  622 */     Token closingCurly = peekToken();
/*  623 */     if (peekToken(TokenKind.RCURLY, true))
/*      */     {
/*  625 */       expr = new InlineList(toPos(t.startPos, closingCurly.endPos), new SpelNodeImpl[0]);
/*      */     }
/*  627 */     else if (peekToken(TokenKind.COLON, true)) {
/*  628 */       closingCurly = eatToken(TokenKind.RCURLY);
/*      */       
/*  630 */       expr = new InlineMap(toPos(t.startPos, closingCurly.endPos), new SpelNodeImpl[0]);
/*      */     }
/*      */     else {
/*  633 */       SpelNodeImpl firstExpression = eatExpression();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  639 */       if (peekToken(TokenKind.RCURLY)) {
/*  640 */         List<SpelNodeImpl> listElements = new ArrayList();
/*  641 */         listElements.add(firstExpression);
/*  642 */         closingCurly = eatToken(TokenKind.RCURLY);
/*  643 */         expr = new InlineList(toPos(t.startPos, closingCurly.endPos), (SpelNodeImpl[])listElements.toArray(new SpelNodeImpl[listElements.size()]));
/*      */       }
/*  645 */       else if (peekToken(TokenKind.COMMA, true)) {
/*  646 */         List<SpelNodeImpl> listElements = new ArrayList();
/*  647 */         listElements.add(firstExpression);
/*      */         do {
/*  649 */           listElements.add(eatExpression());
/*      */         }
/*  651 */         while (peekToken(TokenKind.COMMA, true));
/*  652 */         closingCurly = eatToken(TokenKind.RCURLY);
/*  653 */         expr = new InlineList(toPos(t.startPos, closingCurly.endPos), (SpelNodeImpl[])listElements.toArray(new SpelNodeImpl[listElements.size()]));
/*      */ 
/*      */       }
/*  656 */       else if (peekToken(TokenKind.COLON, true)) {
/*  657 */         List<SpelNodeImpl> mapElements = new ArrayList();
/*  658 */         mapElements.add(firstExpression);
/*  659 */         mapElements.add(eatExpression());
/*  660 */         while (peekToken(TokenKind.COMMA, true)) {
/*  661 */           mapElements.add(eatExpression());
/*  662 */           eatToken(TokenKind.COLON);
/*  663 */           mapElements.add(eatExpression());
/*      */         }
/*  665 */         closingCurly = eatToken(TokenKind.RCURLY);
/*  666 */         expr = new InlineMap(toPos(t.startPos, closingCurly.endPos), (SpelNodeImpl[])mapElements.toArray(new SpelNodeImpl[mapElements.size()]));
/*      */       }
/*      */       else {
/*  669 */         raiseInternalException(t.startPos, SpelMessage.OOD, new Object[0]);
/*      */       }
/*      */     }
/*  672 */     this.constructedNodes.push(expr);
/*  673 */     return true;
/*      */   }
/*      */   
/*      */   private boolean maybeEatIndexer() {
/*  677 */     Token t = peekToken();
/*  678 */     if (!peekToken(TokenKind.LSQUARE, true)) {
/*  679 */       return false;
/*      */     }
/*  681 */     SpelNodeImpl expr = eatExpression();
/*  682 */     eatToken(TokenKind.RSQUARE);
/*  683 */     this.constructedNodes.push(new Indexer(toPos(t), expr));
/*  684 */     return true;
/*      */   }
/*      */   
/*      */   private boolean maybeEatSelection(boolean nullSafeNavigation) {
/*  688 */     Token t = peekToken();
/*  689 */     if (!peekSelectToken()) {
/*  690 */       return false;
/*      */     }
/*  692 */     nextToken();
/*  693 */     SpelNodeImpl expr = eatExpression();
/*  694 */     if (expr == null) {
/*  695 */       raiseInternalException(toPos(t), SpelMessage.MISSING_SELECTION_EXPRESSION, new Object[0]);
/*      */     }
/*  697 */     eatToken(TokenKind.RSQUARE);
/*  698 */     if (t.kind == TokenKind.SELECT_FIRST) {
/*  699 */       this.constructedNodes.push(new Selection(nullSafeNavigation, 1, toPos(t), expr));
/*      */     }
/*  701 */     else if (t.kind == TokenKind.SELECT_LAST) {
/*  702 */       this.constructedNodes.push(new Selection(nullSafeNavigation, 2, toPos(t), expr));
/*      */     }
/*      */     else {
/*  705 */       this.constructedNodes.push(new Selection(nullSafeNavigation, 0, toPos(t), expr));
/*      */     }
/*  707 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private SpelNodeImpl eatPossiblyQualifiedId()
/*      */   {
/*  715 */     LinkedList<SpelNodeImpl> qualifiedIdPieces = new LinkedList();
/*  716 */     Token node = peekToken();
/*  717 */     while (isValidQualifiedId(node)) {
/*  718 */       nextToken();
/*  719 */       if (node.kind != TokenKind.DOT) {
/*  720 */         qualifiedIdPieces.add(new Identifier(node.stringValue(), toPos(node)));
/*      */       }
/*  722 */       node = peekToken();
/*      */     }
/*  724 */     if (qualifiedIdPieces.isEmpty()) {
/*  725 */       if (node == null) {
/*  726 */         raiseInternalException(this.expressionString.length(), SpelMessage.OOD, new Object[0]);
/*      */       }
/*  728 */       raiseInternalException(node.startPos, SpelMessage.NOT_EXPECTED_TOKEN, new Object[] { "qualified ID", node
/*  729 */         .getKind().toString().toLowerCase() });
/*      */     }
/*  731 */     int pos = toPos(((SpelNodeImpl)qualifiedIdPieces.getFirst()).getStartPosition(), ((SpelNodeImpl)qualifiedIdPieces.getLast()).getEndPosition());
/*  732 */     return new QualifiedIdentifier(pos, (SpelNodeImpl[])qualifiedIdPieces.toArray(new SpelNodeImpl[qualifiedIdPieces.size()]));
/*      */   }
/*      */   
/*      */   private boolean isValidQualifiedId(Token node) {
/*  736 */     if ((node == null) || (node.kind == TokenKind.LITERAL_STRING)) {
/*  737 */       return false;
/*      */     }
/*  739 */     if ((node.kind == TokenKind.DOT) || (node.kind == TokenKind.IDENTIFIER)) {
/*  740 */       return true;
/*      */     }
/*  742 */     String value = node.stringValue();
/*  743 */     return (StringUtils.hasLength(value)) && (VALID_QUALIFIED_ID_PATTERN.matcher(value).matches());
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean maybeEatMethodOrProperty(boolean nullSafeNavigation)
/*      */   {
/*  749 */     if (peekToken(TokenKind.IDENTIFIER)) {
/*  750 */       Token methodOrPropertyName = nextToken();
/*  751 */       SpelNodeImpl[] args = maybeEatMethodArgs();
/*  752 */       if (args == null)
/*      */       {
/*  754 */         push(new PropertyOrFieldReference(nullSafeNavigation, methodOrPropertyName.data, toPos(methodOrPropertyName)));
/*  755 */         return true;
/*      */       }
/*      */       
/*  758 */       push(new MethodReference(nullSafeNavigation, methodOrPropertyName.data, toPos(methodOrPropertyName), args));
/*      */       
/*  760 */       return true;
/*      */     }
/*  762 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean maybeEatConstructorReference()
/*      */   {
/*  768 */     if (peekIdentifierToken("new")) {
/*  769 */       Token newToken = nextToken();
/*      */       
/*  771 */       if (peekToken(TokenKind.RSQUARE))
/*      */       {
/*  773 */         push(new PropertyOrFieldReference(false, newToken.data, toPos(newToken)));
/*  774 */         return true;
/*      */       }
/*  776 */       SpelNodeImpl possiblyQualifiedConstructorName = eatPossiblyQualifiedId();
/*  777 */       List<SpelNodeImpl> nodes = new ArrayList();
/*  778 */       nodes.add(possiblyQualifiedConstructorName);
/*  779 */       if (peekToken(TokenKind.LSQUARE))
/*      */       {
/*  781 */         List<SpelNodeImpl> dimensions = new ArrayList();
/*  782 */         while (peekToken(TokenKind.LSQUARE, true)) {
/*  783 */           if (!peekToken(TokenKind.RSQUARE)) {
/*  784 */             dimensions.add(eatExpression());
/*      */           }
/*      */           else {
/*  787 */             dimensions.add(null);
/*      */           }
/*  789 */           eatToken(TokenKind.RSQUARE);
/*      */         }
/*  791 */         if (maybeEatInlineListOrMap()) {
/*  792 */           nodes.add(pop());
/*      */         }
/*  794 */         push(new ConstructorReference(toPos(newToken), (SpelNodeImpl[])dimensions.toArray(new SpelNodeImpl[dimensions.size()]), 
/*  795 */           (SpelNodeImpl[])nodes.toArray(new SpelNodeImpl[nodes.size()])));
/*      */       }
/*      */       else
/*      */       {
/*  799 */         eatConstructorArgs(nodes);
/*      */         
/*  801 */         push(new ConstructorReference(toPos(newToken), 
/*  802 */           (SpelNodeImpl[])nodes.toArray(new SpelNodeImpl[nodes.size()])));
/*      */       }
/*  804 */       return true;
/*      */     }
/*  806 */     return false;
/*      */   }
/*      */   
/*      */   private void push(SpelNodeImpl newNode) {
/*  810 */     this.constructedNodes.push(newNode);
/*      */   }
/*      */   
/*      */   private SpelNodeImpl pop() {
/*  814 */     return (SpelNodeImpl)this.constructedNodes.pop();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean maybeEatLiteral()
/*      */   {
/*  826 */     Token t = peekToken();
/*  827 */     if (t == null) {
/*  828 */       return false;
/*      */     }
/*  830 */     if (t.kind == TokenKind.LITERAL_INT) {
/*  831 */       push(Literal.getIntLiteral(t.data, toPos(t), 10));
/*      */     }
/*  833 */     else if (t.kind == TokenKind.LITERAL_LONG) {
/*  834 */       push(Literal.getLongLiteral(t.data, toPos(t), 10));
/*      */     }
/*  836 */     else if (t.kind == TokenKind.LITERAL_HEXINT) {
/*  837 */       push(Literal.getIntLiteral(t.data, toPos(t), 16));
/*      */     }
/*  839 */     else if (t.kind == TokenKind.LITERAL_HEXLONG) {
/*  840 */       push(Literal.getLongLiteral(t.data, toPos(t), 16));
/*      */     }
/*  842 */     else if (t.kind == TokenKind.LITERAL_REAL) {
/*  843 */       push(Literal.getRealLiteral(t.data, toPos(t), false));
/*      */     }
/*  845 */     else if (t.kind == TokenKind.LITERAL_REAL_FLOAT) {
/*  846 */       push(Literal.getRealLiteral(t.data, toPos(t), true));
/*      */     }
/*  848 */     else if (peekIdentifierToken("true")) {
/*  849 */       push(new BooleanLiteral(t.data, toPos(t), true));
/*      */     }
/*  851 */     else if (peekIdentifierToken("false")) {
/*  852 */       push(new BooleanLiteral(t.data, toPos(t), false));
/*      */     }
/*  854 */     else if (t.kind == TokenKind.LITERAL_STRING) {
/*  855 */       push(new StringLiteral(t.data, toPos(t), t.data));
/*      */     }
/*      */     else {
/*  858 */       return false;
/*      */     }
/*  860 */     nextToken();
/*  861 */     return true;
/*      */   }
/*      */   
/*      */   private boolean maybeEatParenExpression()
/*      */   {
/*  866 */     if (peekToken(TokenKind.LPAREN)) {
/*  867 */       nextToken();
/*  868 */       SpelNodeImpl expr = eatExpression();
/*  869 */       eatToken(TokenKind.RPAREN);
/*  870 */       push(expr);
/*  871 */       return true;
/*      */     }
/*      */     
/*  874 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Token maybeEatRelationalOperator()
/*      */   {
/*  882 */     Token t = peekToken();
/*  883 */     if (t == null) {
/*  884 */       return null;
/*      */     }
/*  886 */     if (t.isNumericRelationalOperator()) {
/*  887 */       return t;
/*      */     }
/*  889 */     if (t.isIdentifier()) {
/*  890 */       String idString = t.stringValue();
/*  891 */       if (idString.equalsIgnoreCase("instanceof")) {
/*  892 */         return t.asInstanceOfToken();
/*      */       }
/*  894 */       if (idString.equalsIgnoreCase("matches")) {
/*  895 */         return t.asMatchesToken();
/*      */       }
/*  897 */       if (idString.equalsIgnoreCase("between")) {
/*  898 */         return t.asBetweenToken();
/*      */       }
/*      */     }
/*  901 */     return null;
/*      */   }
/*      */   
/*      */   private Token eatToken(TokenKind expectedKind) {
/*  905 */     Token t = nextToken();
/*  906 */     if (t == null) {
/*  907 */       raiseInternalException(this.expressionString.length(), SpelMessage.OOD, new Object[0]);
/*      */     }
/*  909 */     if (t.kind != expectedKind) {
/*  910 */       raiseInternalException(t.startPos, SpelMessage.NOT_EXPECTED_TOKEN, new Object[] {expectedKind
/*  911 */         .toString().toLowerCase(), t.getKind().toString().toLowerCase() });
/*      */     }
/*  913 */     return t;
/*      */   }
/*      */   
/*      */   private boolean peekToken(TokenKind desiredTokenKind) {
/*  917 */     return peekToken(desiredTokenKind, false);
/*      */   }
/*      */   
/*      */   private boolean peekToken(TokenKind desiredTokenKind, boolean consumeIfMatched) {
/*  921 */     if (!moreTokens()) {
/*  922 */       return false;
/*      */     }
/*  924 */     Token t = peekToken();
/*  925 */     if (t.kind == desiredTokenKind) {
/*  926 */       if (consumeIfMatched) {
/*  927 */         this.tokenStreamPointer += 1;
/*      */       }
/*  929 */       return true;
/*      */     }
/*      */     
/*  932 */     if (desiredTokenKind == TokenKind.IDENTIFIER)
/*      */     {
/*      */ 
/*  935 */       if ((t.kind.ordinal() >= TokenKind.DIV.ordinal()) && (t.kind.ordinal() <= TokenKind.NOT.ordinal()) && (t.data != null))
/*      */       {
/*  937 */         return true;
/*      */       }
/*      */     }
/*  940 */     return false;
/*      */   }
/*      */   
/*      */   private boolean peekToken(TokenKind possible1, TokenKind possible2) {
/*  944 */     if (!moreTokens()) {
/*  945 */       return false;
/*      */     }
/*  947 */     Token t = peekToken();
/*  948 */     return (t.kind == possible1) || (t.kind == possible2);
/*      */   }
/*      */   
/*      */   private boolean peekToken(TokenKind possible1, TokenKind possible2, TokenKind possible3) {
/*  952 */     if (!moreTokens()) {
/*  953 */       return false;
/*      */     }
/*  955 */     Token t = peekToken();
/*  956 */     return (t.kind == possible1) || (t.kind == possible2) || (t.kind == possible3);
/*      */   }
/*      */   
/*      */   private boolean peekIdentifierToken(String identifierString) {
/*  960 */     if (!moreTokens()) {
/*  961 */       return false;
/*      */     }
/*  963 */     Token t = peekToken();
/*  964 */     return (t.kind == TokenKind.IDENTIFIER) && (t.stringValue().equalsIgnoreCase(identifierString));
/*      */   }
/*      */   
/*      */   private boolean peekSelectToken() {
/*  968 */     if (!moreTokens()) {
/*  969 */       return false;
/*      */     }
/*  971 */     Token t = peekToken();
/*  972 */     return (t.kind == TokenKind.SELECT) || (t.kind == TokenKind.SELECT_FIRST) || (t.kind == TokenKind.SELECT_LAST);
/*      */   }
/*      */   
/*      */   private boolean moreTokens()
/*      */   {
/*  977 */     return this.tokenStreamPointer < this.tokenStream.size();
/*      */   }
/*      */   
/*      */   private Token nextToken() {
/*  981 */     if (this.tokenStreamPointer >= this.tokenStreamLength) {
/*  982 */       return null;
/*      */     }
/*  984 */     return (Token)this.tokenStream.get(this.tokenStreamPointer++);
/*      */   }
/*      */   
/*      */   private Token peekToken() {
/*  988 */     if (this.tokenStreamPointer >= this.tokenStreamLength) {
/*  989 */       return null;
/*      */     }
/*  991 */     return (Token)this.tokenStream.get(this.tokenStreamPointer);
/*      */   }
/*      */   
/*      */   private void raiseInternalException(int pos, SpelMessage message, Object... inserts) {
/*  995 */     throw new InternalParseException(new SpelParseException(this.expressionString, pos, message, inserts));
/*      */   }
/*      */   
/*      */   public String toString(Token t) {
/*  999 */     if (t.getKind().hasPayload()) {
/* 1000 */       return t.stringValue();
/*      */     }
/* 1002 */     return t.kind.toString().toLowerCase();
/*      */   }
/*      */   
/*      */   private void checkOperands(Token token, SpelNodeImpl left, SpelNodeImpl right) {
/* 1006 */     checkLeftOperand(token, left);
/* 1007 */     checkRightOperand(token, right);
/*      */   }
/*      */   
/*      */   private void checkLeftOperand(Token token, SpelNodeImpl operandExpression) {
/* 1011 */     if (operandExpression == null) {
/* 1012 */       raiseInternalException(token.startPos, SpelMessage.LEFT_OPERAND_PROBLEM, new Object[0]);
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkRightOperand(Token token, SpelNodeImpl operandExpression) {
/* 1017 */     if (operandExpression == null) {
/* 1018 */       raiseInternalException(token.startPos, SpelMessage.RIGHT_OPERAND_PROBLEM, new Object[0]);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int toPos(Token t)
/*      */   {
/* 1026 */     return (t.startPos << 16) + t.endPos;
/*      */   }
/*      */   
/*      */   private int toPos(int start, int end) {
/* 1030 */     return (start << 16) + end;
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\spel\standard\InternalSpelExpressionParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */