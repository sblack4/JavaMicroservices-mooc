/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypeConverter;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.expression.spel.SpelNode;
/*     */ import org.springframework.expression.spel.support.ReflectionHelper;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunctionReference
/*     */   extends SpelNodeImpl
/*     */ {
/*     */   private final String name;
/*     */   private Method method;
/*     */   private boolean argumentConversionOccurred;
/*     */   
/*     */   public FunctionReference(String functionName, int pos, SpelNodeImpl... arguments)
/*     */   {
/*  61 */     super(pos, arguments);
/*  62 */     this.name = functionName;
/*     */   }
/*     */   
/*     */   public TypedValue getValueInternal(ExpressionState state)
/*     */     throws EvaluationException
/*     */   {
/*  68 */     TypedValue value = state.lookupVariable(this.name);
/*  69 */     if (value == null) {
/*  70 */       throw new SpelEvaluationException(getStartPosition(), SpelMessage.FUNCTION_NOT_DEFINED, new Object[] { this.name });
/*     */     }
/*     */     
/*     */ 
/*  74 */     if (!(value.getValue() instanceof Method))
/*     */     {
/*  76 */       throw new SpelEvaluationException(SpelMessage.FUNCTION_REFERENCE_CANNOT_BE_INVOKED, new Object[] { this.name, value.getClass() });
/*     */     }
/*     */     try
/*     */     {
/*  80 */       return executeFunctionJLRMethod(state, (Method)value.getValue());
/*     */     }
/*     */     catch (SpelEvaluationException ex) {
/*  83 */       ex.setPosition(getStartPosition());
/*  84 */       throw ex;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private TypedValue executeFunctionJLRMethod(ExpressionState state, Method method)
/*     */     throws EvaluationException
/*     */   {
/*  96 */     this.method = null;
/*  97 */     Object[] functionArgs = getArguments(state);
/*     */     
/*  99 */     if ((!method.isVarArgs()) && (method.getParameterTypes().length != functionArgs.length))
/*     */     {
/* 101 */       throw new SpelEvaluationException(SpelMessage.INCORRECT_NUMBER_OF_ARGUMENTS_TO_FUNCTION, new Object[] {Integer.valueOf(functionArgs.length), Integer.valueOf(method.getParameterTypes().length) });
/*     */     }
/*     */     
/* 104 */     if (!Modifier.isStatic(method.getModifiers()))
/*     */     {
/*     */ 
/* 107 */       throw new SpelEvaluationException(getStartPosition(), SpelMessage.FUNCTION_MUST_BE_STATIC, new Object[] {method.getDeclaringClass().getName() + "." + method.getName(), this.name });
/*     */     }
/*     */     
/* 110 */     this.argumentConversionOccurred = false;
/*     */     
/* 112 */     if (functionArgs != null) {
/* 113 */       TypeConverter converter = state.getEvaluationContext().getTypeConverter();
/* 114 */       this.argumentConversionOccurred = ReflectionHelper.convertAllArguments(converter, functionArgs, method);
/*     */     }
/* 116 */     if (method.isVarArgs())
/*     */     {
/* 118 */       functionArgs = ReflectionHelper.setupArgumentsForVarargsInvocation(method.getParameterTypes(), functionArgs);
/*     */     }
/*     */     try
/*     */     {
/* 122 */       ReflectionUtils.makeAccessible(method);
/* 123 */       Object result = method.invoke(method.getClass(), functionArgs);
/* 124 */       if (!this.argumentConversionOccurred) {
/* 125 */         this.method = method;
/* 126 */         this.exitTypeDescriptor = CodeFlow.toDescriptor(method.getReturnType());
/*     */       }
/* 128 */       return new TypedValue(result, new TypeDescriptor(new MethodParameter(method, -1)).narrow(result));
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 132 */       throw new SpelEvaluationException(getStartPosition(), ex, SpelMessage.EXCEPTION_DURING_FUNCTION_CALL, new Object[] { this.name, ex.getMessage() });
/*     */     }
/*     */   }
/*     */   
/*     */   public String toStringAST()
/*     */   {
/* 138 */     StringBuilder sb = new StringBuilder("#").append(this.name);
/* 139 */     sb.append("(");
/* 140 */     for (int i = 0; i < getChildCount(); i++) {
/* 141 */       if (i > 0) {
/* 142 */         sb.append(",");
/*     */       }
/* 144 */       sb.append(getChild(i).toStringAST());
/*     */     }
/* 146 */     sb.append(")");
/* 147 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object[] getArguments(ExpressionState state)
/*     */     throws EvaluationException
/*     */   {
/* 156 */     Object[] arguments = new Object[getChildCount()];
/* 157 */     for (int i = 0; i < arguments.length; i++) {
/* 158 */       arguments[i] = this.children[i].getValueInternal(state).getValue();
/*     */     }
/* 160 */     return arguments;
/*     */   }
/*     */   
/*     */   public boolean isCompilable()
/*     */   {
/* 165 */     if ((this.method == null) || (this.argumentConversionOccurred)) {
/* 166 */       return false;
/*     */     }
/* 168 */     int methodModifiers = this.method.getModifiers();
/* 169 */     if ((!Modifier.isStatic(methodModifiers)) || (!Modifier.isPublic(methodModifiers)) || 
/* 170 */       (!Modifier.isPublic(this.method.getDeclaringClass().getModifiers()))) {
/* 171 */       return false;
/*     */     }
/* 173 */     for (SpelNodeImpl child : this.children) {
/* 174 */       if (!child.isCompilable()) {
/* 175 */         return false;
/*     */       }
/*     */     }
/* 178 */     return true;
/*     */   }
/*     */   
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf)
/*     */   {
/* 183 */     String classDesc = this.method.getDeclaringClass().getName().replace('.', '/');
/* 184 */     generateCodeForArguments(mv, cf, this.method, this.children);
/* 185 */     mv.visitMethodInsn(184, classDesc, this.method.getName(), 
/* 186 */       CodeFlow.createSignatureDescriptor(this.method), false);
/* 187 */     cf.pushDescriptor(this.exitTypeDescriptor);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\spel\ast\FunctionReference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */