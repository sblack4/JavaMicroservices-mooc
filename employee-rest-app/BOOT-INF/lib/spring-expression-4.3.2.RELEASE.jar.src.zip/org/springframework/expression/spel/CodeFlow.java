/*     */ package org.springframework.expression.spel;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Stack;
/*     */ import org.springframework.asm.ClassWriter;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.asm.Opcodes;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CodeFlow
/*     */   implements Opcodes
/*     */ {
/*     */   private final Stack<ArrayList<String>> compilationScopes;
/*     */   private ClassWriter cw;
/*  58 */   private List<FieldAdder> fieldAdders = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  66 */   private List<ClinitAdder> clinitAdders = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String clazzName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  78 */   private int nextFieldId = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  84 */   private int nextFreeVariableId = 1;
/*     */   
/*     */   public CodeFlow(String clazzName, ClassWriter cw) {
/*  87 */     this.compilationScopes = new Stack();
/*  88 */     this.compilationScopes.add(new ArrayList());
/*  89 */     this.cw = cw;
/*  90 */     this.clazzName = clazzName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void loadTarget(MethodVisitor mv)
/*     */   {
/*  99 */     mv.visitVarInsn(25, 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void pushDescriptor(String descriptor)
/*     */   {
/* 107 */     Assert.notNull(descriptor, "Descriptor must not be null");
/* 108 */     ((ArrayList)this.compilationScopes.peek()).add(descriptor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void enterCompilationScope()
/*     */   {
/* 117 */     this.compilationScopes.push(new ArrayList());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void exitCompilationScope()
/*     */   {
/* 126 */     this.compilationScopes.pop();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String lastDescriptor()
/*     */   {
/* 133 */     if (((ArrayList)this.compilationScopes.peek()).isEmpty()) {
/* 134 */       return null;
/*     */     }
/* 136 */     return (String)((ArrayList)this.compilationScopes.peek()).get(((ArrayList)this.compilationScopes.peek()).size() - 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void unboxBooleanIfNecessary(MethodVisitor mv)
/*     */   {
/* 145 */     if (lastDescriptor().equals("Ljava/lang/Boolean")) {
/* 146 */       mv.visitMethodInsn(182, "java/lang/Boolean", "booleanValue", "()Z", false);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void finish()
/*     */   {
/*     */     Iterator localIterator;
/*     */     
/* 156 */     if (this.fieldAdders != null)
/* 157 */       for (localIterator = this.fieldAdders.iterator(); localIterator.hasNext();) { fieldAdder = (FieldAdder)localIterator.next();
/* 158 */         fieldAdder.generateField(this.cw, this);
/*     */       }
/*     */     FieldAdder fieldAdder;
/* 161 */     if (this.clinitAdders != null) {
/* 162 */       MethodVisitor mv = this.cw.visitMethod(9, "<clinit>", "()V", null, null);
/* 163 */       mv.visitCode();
/* 164 */       this.nextFreeVariableId = 0;
/* 165 */       for (ClinitAdder clinitAdder : this.clinitAdders) {
/* 166 */         clinitAdder.generateCode(mv, this);
/*     */       }
/* 168 */       mv.visitInsn(177);
/* 169 */       mv.visitMaxs(0, 0);
/* 170 */       mv.visitEnd();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerNewField(FieldAdder fieldAdder)
/*     */   {
/* 180 */     if (this.fieldAdders == null) {
/* 181 */       this.fieldAdders = new ArrayList();
/*     */     }
/* 183 */     this.fieldAdders.add(fieldAdder);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerNewClinit(ClinitAdder clinitAdder)
/*     */   {
/* 192 */     if (this.clinitAdders == null) {
/* 193 */       this.clinitAdders = new ArrayList();
/*     */     }
/* 195 */     this.clinitAdders.add(clinitAdder);
/*     */   }
/*     */   
/*     */   public int nextFieldId() {
/* 199 */     return this.nextFieldId++;
/*     */   }
/*     */   
/*     */   public int nextFreeVariableId() {
/* 203 */     return this.nextFreeVariableId++;
/*     */   }
/*     */   
/*     */   public String getClassName() {
/* 207 */     return this.clazzName;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public String getClassname() {
/* 212 */     return this.clazzName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void insertUnboxInsns(MethodVisitor mv, char ch, String stackDescriptor)
/*     */   {
/* 224 */     switch (ch) {
/*     */     case 'Z': 
/* 226 */       if (!stackDescriptor.equals("Ljava/lang/Boolean")) {
/* 227 */         mv.visitTypeInsn(192, "java/lang/Boolean");
/*     */       }
/* 229 */       mv.visitMethodInsn(182, "java/lang/Boolean", "booleanValue", "()Z", false);
/* 230 */       break;
/*     */     case 'B': 
/* 232 */       if (!stackDescriptor.equals("Ljava/lang/Byte")) {
/* 233 */         mv.visitTypeInsn(192, "java/lang/Byte");
/*     */       }
/* 235 */       mv.visitMethodInsn(182, "java/lang/Byte", "byteValue", "()B", false);
/* 236 */       break;
/*     */     case 'C': 
/* 238 */       if (!stackDescriptor.equals("Ljava/lang/Character")) {
/* 239 */         mv.visitTypeInsn(192, "java/lang/Character");
/*     */       }
/* 241 */       mv.visitMethodInsn(182, "java/lang/Character", "charValue", "()C", false);
/* 242 */       break;
/*     */     case 'D': 
/* 244 */       if (!stackDescriptor.equals("Ljava/lang/Double")) {
/* 245 */         mv.visitTypeInsn(192, "java/lang/Double");
/*     */       }
/* 247 */       mv.visitMethodInsn(182, "java/lang/Double", "doubleValue", "()D", false);
/* 248 */       break;
/*     */     case 'F': 
/* 250 */       if (!stackDescriptor.equals("Ljava/lang/Float")) {
/* 251 */         mv.visitTypeInsn(192, "java/lang/Float");
/*     */       }
/* 253 */       mv.visitMethodInsn(182, "java/lang/Float", "floatValue", "()F", false);
/* 254 */       break;
/*     */     case 'I': 
/* 256 */       if (!stackDescriptor.equals("Ljava/lang/Integer")) {
/* 257 */         mv.visitTypeInsn(192, "java/lang/Integer");
/*     */       }
/* 259 */       mv.visitMethodInsn(182, "java/lang/Integer", "intValue", "()I", false);
/* 260 */       break;
/*     */     case 'J': 
/* 262 */       if (!stackDescriptor.equals("Ljava/lang/Long")) {
/* 263 */         mv.visitTypeInsn(192, "java/lang/Long");
/*     */       }
/* 265 */       mv.visitMethodInsn(182, "java/lang/Long", "longValue", "()J", false);
/* 266 */       break;
/*     */     case 'S': 
/* 268 */       if (!stackDescriptor.equals("Ljava/lang/Short")) {
/* 269 */         mv.visitTypeInsn(192, "java/lang/Short");
/*     */       }
/* 271 */       mv.visitMethodInsn(182, "java/lang/Short", "shortValue", "()S", false);
/* 272 */       break;
/*     */     case 'E': case 'G': case 'H': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': default: 
/* 274 */       throw new IllegalArgumentException("Unboxing should not be attempted for descriptor '" + ch + "'");
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void insertUnboxNumberInsns(MethodVisitor mv, char targetDescriptor, String stackDescriptor)
/*     */   {
/* 285 */     switch (targetDescriptor) {
/*     */     case 'D': 
/* 287 */       if (stackDescriptor.equals("Ljava/lang/Object")) {
/* 288 */         mv.visitTypeInsn(192, "java/lang/Number");
/*     */       }
/* 290 */       mv.visitMethodInsn(182, "java/lang/Number", "doubleValue", "()D", false);
/* 291 */       break;
/*     */     case 'F': 
/* 293 */       if (stackDescriptor.equals("Ljava/lang/Object")) {
/* 294 */         mv.visitTypeInsn(192, "java/lang/Number");
/*     */       }
/* 296 */       mv.visitMethodInsn(182, "java/lang/Number", "floatValue", "()F", false);
/* 297 */       break;
/*     */     case 'J': 
/* 299 */       if (stackDescriptor.equals("Ljava/lang/Object")) {
/* 300 */         mv.visitTypeInsn(192, "java/lang/Number");
/*     */       }
/* 302 */       mv.visitMethodInsn(182, "java/lang/Number", "longValue", "()J", false);
/* 303 */       break;
/*     */     case 'I': 
/* 305 */       if (stackDescriptor.equals("Ljava/lang/Object")) {
/* 306 */         mv.visitTypeInsn(192, "java/lang/Number");
/*     */       }
/* 308 */       mv.visitMethodInsn(182, "java/lang/Number", "intValue", "()I", false);
/* 309 */       break;
/*     */     case 'E': case 'G': 
/*     */     case 'H': default: 
/* 312 */       throw new IllegalArgumentException("Unboxing should not be attempted for descriptor '" + targetDescriptor + "'");
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void insertAnyNecessaryTypeConversionBytecodes(MethodVisitor mv, char targetDescriptor, String stackDescriptor)
/*     */   {
/* 323 */     if (isPrimitive(stackDescriptor)) {
/* 324 */       char stackTop = stackDescriptor.charAt(0);
/* 325 */       if ((stackTop == 'I') || (stackTop == 'B') || (stackTop == 'S') || (stackTop == 'C')) {
/* 326 */         if (targetDescriptor == 'D') {
/* 327 */           mv.visitInsn(135);
/*     */         }
/* 329 */         else if (targetDescriptor == 'F') {
/* 330 */           mv.visitInsn(134);
/*     */         }
/* 332 */         else if (targetDescriptor == 'J') {
/* 333 */           mv.visitInsn(133);
/*     */         }
/* 335 */         else if (targetDescriptor != 'I')
/*     */         {
/*     */ 
/*     */ 
/* 339 */           throw new IllegalStateException("cannot get from " + stackTop + " to " + targetDescriptor);
/*     */         }
/*     */       }
/* 342 */       else if (stackTop == 'J') {
/* 343 */         if (targetDescriptor == 'D') {
/* 344 */           mv.visitInsn(138);
/*     */         }
/* 346 */         else if (targetDescriptor == 'F') {
/* 347 */           mv.visitInsn(137);
/*     */         }
/* 349 */         else if (targetDescriptor != 'J')
/*     */         {
/*     */ 
/* 352 */           if (targetDescriptor == 'I') {
/* 353 */             mv.visitInsn(136);
/*     */           }
/*     */           else {
/* 356 */             throw new IllegalStateException("cannot get from " + stackTop + " to " + targetDescriptor);
/*     */           }
/*     */         }
/* 359 */       } else if (stackTop == 'F') {
/* 360 */         if (targetDescriptor == 'D') {
/* 361 */           mv.visitInsn(141);
/*     */         }
/* 363 */         else if (targetDescriptor != 'F')
/*     */         {
/*     */ 
/* 366 */           if (targetDescriptor == 'J') {
/* 367 */             mv.visitInsn(140);
/*     */           }
/* 369 */           else if (targetDescriptor == 'I') {
/* 370 */             mv.visitInsn(139);
/*     */           }
/*     */           else {
/* 373 */             throw new IllegalStateException("cannot get from " + stackTop + " to " + targetDescriptor);
/*     */           }
/*     */         }
/* 376 */       } else if ((stackTop == 'D') && 
/* 377 */         (targetDescriptor != 'D'))
/*     */       {
/*     */ 
/* 380 */         if (targetDescriptor == 'F') {
/* 381 */           mv.visitInsn(144);
/*     */         }
/* 383 */         else if (targetDescriptor == 'J') {
/* 384 */           mv.visitInsn(143);
/*     */         }
/* 386 */         else if (targetDescriptor == 'I') {
/* 387 */           mv.visitInsn(142);
/*     */         }
/*     */         else {
/* 390 */           throw new IllegalStateException("cannot get from " + stackDescriptor + " to " + targetDescriptor);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String createSignatureDescriptor(Method method)
/*     */   {
/* 407 */     Class<?>[] params = method.getParameterTypes();
/* 408 */     StringBuilder sb = new StringBuilder();
/* 409 */     sb.append("(");
/* 410 */     for (Class<?> param : params) {
/* 411 */       sb.append(toJvmDescriptor(param));
/*     */     }
/* 413 */     sb.append(")");
/* 414 */     sb.append(toJvmDescriptor(method.getReturnType()));
/* 415 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String createSignatureDescriptor(Constructor<?> ctor)
/*     */   {
/* 428 */     Class<?>[] params = ctor.getParameterTypes();
/* 429 */     StringBuilder sb = new StringBuilder();
/* 430 */     sb.append("(");
/* 431 */     for (Class<?> param : params) {
/* 432 */       sb.append(toJvmDescriptor(param));
/*     */     }
/* 434 */     sb.append(")V");
/* 435 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toJvmDescriptor(Class<?> clazz)
/*     */   {
/* 447 */     StringBuilder sb = new StringBuilder();
/* 448 */     if (clazz.isArray()) {
/* 449 */       while (clazz.isArray()) {
/* 450 */         sb.append("[");
/* 451 */         clazz = clazz.getComponentType();
/*     */       }
/*     */     }
/* 454 */     if (clazz.isPrimitive()) {
/* 455 */       if (clazz == Void.TYPE) {
/* 456 */         sb.append('V');
/*     */       }
/* 458 */       else if (clazz == Integer.TYPE) {
/* 459 */         sb.append('I');
/*     */       }
/* 461 */       else if (clazz == Boolean.TYPE) {
/* 462 */         sb.append('Z');
/*     */       }
/* 464 */       else if (clazz == Character.TYPE) {
/* 465 */         sb.append('C');
/*     */       }
/* 467 */       else if (clazz == Long.TYPE) {
/* 468 */         sb.append('J');
/*     */       }
/* 470 */       else if (clazz == Double.TYPE) {
/* 471 */         sb.append('D');
/*     */       }
/* 473 */       else if (clazz == Float.TYPE) {
/* 474 */         sb.append('F');
/*     */       }
/* 476 */       else if (clazz == Byte.TYPE) {
/* 477 */         sb.append('B');
/*     */       }
/* 479 */       else if (clazz == Short.TYPE) {
/* 480 */         sb.append('S');
/*     */       }
/*     */     }
/*     */     else {
/* 484 */       sb.append("L");
/* 485 */       sb.append(clazz.getName().replace('.', '/'));
/* 486 */       sb.append(";");
/*     */     }
/* 488 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toDescriptorFromObject(Object value)
/*     */   {
/* 498 */     if (value == null) {
/* 499 */       return "Ljava/lang/Object";
/*     */     }
/*     */     
/* 502 */     return toDescriptor(value.getClass());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isBooleanCompatible(String descriptor)
/*     */   {
/* 511 */     return (descriptor != null) && ((descriptor.equals("Z")) || (descriptor.equals("Ljava/lang/Boolean")));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isPrimitive(String descriptor)
/*     */   {
/* 519 */     return (descriptor != null) && (descriptor.length() == 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isPrimitiveArray(String descriptor)
/*     */   {
/* 527 */     boolean primitive = true;
/* 528 */     int i = 0; for (int max = descriptor.length(); i < max; i++) {
/* 529 */       char ch = descriptor.charAt(i);
/* 530 */       if (ch != '[')
/*     */       {
/*     */ 
/* 533 */         primitive = ch != 'L';
/* 534 */         break;
/*     */       } }
/* 536 */     return primitive;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean areBoxingCompatible(String desc1, String desc2)
/*     */   {
/* 545 */     if (desc1.equals(desc2)) {
/* 546 */       return true;
/*     */     }
/* 548 */     if (desc1.length() == 1) {
/* 549 */       if (desc1.equals("Z")) {
/* 550 */         return desc2.equals("Ljava/lang/Boolean");
/*     */       }
/* 552 */       if (desc1.equals("D")) {
/* 553 */         return desc2.equals("Ljava/lang/Double");
/*     */       }
/* 555 */       if (desc1.equals("F")) {
/* 556 */         return desc2.equals("Ljava/lang/Float");
/*     */       }
/* 558 */       if (desc1.equals("I")) {
/* 559 */         return desc2.equals("Ljava/lang/Integer");
/*     */       }
/* 561 */       if (desc1.equals("J")) {
/* 562 */         return desc2.equals("Ljava/lang/Long");
/*     */       }
/*     */     }
/* 565 */     else if (desc2.length() == 1) {
/* 566 */       if (desc2.equals("Z")) {
/* 567 */         return desc1.equals("Ljava/lang/Boolean");
/*     */       }
/* 569 */       if (desc2.equals("D")) {
/* 570 */         return desc1.equals("Ljava/lang/Double");
/*     */       }
/* 572 */       if (desc2.equals("F")) {
/* 573 */         return desc1.equals("Ljava/lang/Float");
/*     */       }
/* 575 */       if (desc2.equals("I")) {
/* 576 */         return desc1.equals("Ljava/lang/Integer");
/*     */       }
/* 578 */       if (desc2.equals("J")) {
/* 579 */         return desc1.equals("Ljava/lang/Long");
/*     */       }
/*     */     }
/* 582 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isPrimitiveOrUnboxableSupportedNumberOrBoolean(String descriptor)
/*     */   {
/* 593 */     if (descriptor == null) {
/* 594 */       return false;
/*     */     }
/* 596 */     if (isPrimitiveOrUnboxableSupportedNumber(descriptor)) {
/* 597 */       return true;
/*     */     }
/* 599 */     return ("Z".equals(descriptor)) || (descriptor.equals("Ljava/lang/Boolean"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isPrimitiveOrUnboxableSupportedNumber(String descriptor)
/*     */   {
/* 610 */     if (descriptor == null) {
/* 611 */       return false;
/*     */     }
/* 613 */     if (descriptor.length() == 1) {
/* 614 */       return "DFIJ".contains(descriptor);
/*     */     }
/* 616 */     if (descriptor.startsWith("Ljava/lang/")) {
/* 617 */       String name = descriptor.substring("Ljava/lang/".length());
/* 618 */       if ((name.equals("Double")) || (name.equals("Float")) || (name.equals("Integer")) || (name.equals("Long"))) {
/* 619 */         return true;
/*     */       }
/*     */     }
/* 622 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isIntegerForNumericOp(Number number)
/*     */   {
/* 632 */     return ((number instanceof Integer)) || ((number instanceof Short)) || ((number instanceof Byte));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static char toPrimitiveTargetDesc(String descriptor)
/*     */   {
/* 640 */     if (descriptor.length() == 1) {
/* 641 */       return descriptor.charAt(0);
/*     */     }
/* 643 */     if (descriptor.equals("Ljava/lang/Boolean")) {
/* 644 */       return 'Z';
/*     */     }
/* 646 */     if (descriptor.equals("Ljava/lang/Byte")) {
/* 647 */       return 'B';
/*     */     }
/* 649 */     if (descriptor.equals("Ljava/lang/Character")) {
/* 650 */       return 'C';
/*     */     }
/* 652 */     if (descriptor.equals("Ljava/lang/Double")) {
/* 653 */       return 'D';
/*     */     }
/* 655 */     if (descriptor.equals("Ljava/lang/Float")) {
/* 656 */       return 'F';
/*     */     }
/* 658 */     if (descriptor.equals("Ljava/lang/Integer")) {
/* 659 */       return 'I';
/*     */     }
/* 661 */     if (descriptor.equals("Ljava/lang/Long")) {
/* 662 */       return 'J';
/*     */     }
/* 664 */     if (descriptor.equals("Ljava/lang/Short")) {
/* 665 */       return 'S';
/*     */     }
/*     */     
/* 668 */     throw new IllegalStateException("No primitive for '" + descriptor + "'");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void insertCheckCast(MethodVisitor mv, String descriptor)
/*     */   {
/* 678 */     if (descriptor.length() != 1) {
/* 679 */       if (descriptor.charAt(0) == '[') {
/* 680 */         if (isPrimitiveArray(descriptor)) {
/* 681 */           mv.visitTypeInsn(192, descriptor);
/*     */         }
/*     */         else {
/* 684 */           mv.visitTypeInsn(192, descriptor + ";");
/*     */         }
/*     */         
/*     */       }
/* 688 */       else if (!descriptor.equals("Ljava/lang/Object"))
/*     */       {
/* 690 */         mv.visitTypeInsn(192, descriptor.substring(1));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void insertBoxIfNecessary(MethodVisitor mv, String descriptor)
/*     */   {
/* 703 */     if (descriptor.length() == 1) {
/* 704 */       insertBoxIfNecessary(mv, descriptor.charAt(0));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void insertBoxIfNecessary(MethodVisitor mv, char ch)
/*     */   {
/* 715 */     switch (ch) {
/*     */     case 'Z': 
/* 717 */       mv.visitMethodInsn(184, "java/lang/Boolean", "valueOf", "(Z)Ljava/lang/Boolean;", false);
/* 718 */       break;
/*     */     case 'B': 
/* 720 */       mv.visitMethodInsn(184, "java/lang/Byte", "valueOf", "(B)Ljava/lang/Byte;", false);
/* 721 */       break;
/*     */     case 'C': 
/* 723 */       mv.visitMethodInsn(184, "java/lang/Character", "valueOf", "(C)Ljava/lang/Character;", false);
/* 724 */       break;
/*     */     case 'D': 
/* 726 */       mv.visitMethodInsn(184, "java/lang/Double", "valueOf", "(D)Ljava/lang/Double;", false);
/* 727 */       break;
/*     */     case 'F': 
/* 729 */       mv.visitMethodInsn(184, "java/lang/Float", "valueOf", "(F)Ljava/lang/Float;", false);
/* 730 */       break;
/*     */     case 'I': 
/* 732 */       mv.visitMethodInsn(184, "java/lang/Integer", "valueOf", "(I)Ljava/lang/Integer;", false);
/* 733 */       break;
/*     */     case 'J': 
/* 735 */       mv.visitMethodInsn(184, "java/lang/Long", "valueOf", "(J)Ljava/lang/Long;", false);
/* 736 */       break;
/*     */     case 'S': 
/* 738 */       mv.visitMethodInsn(184, "java/lang/Short", "valueOf", "(S)Ljava/lang/Short;", false);
/* 739 */       break;
/*     */     case 'L': case 'V': case '[': 
/*     */       break;
/*     */     case 'E': case 'G': case 'H': case 'K': 
/*     */     case 'M': case 'N': case 'O': case 'P': 
/*     */     case 'Q': case 'R': case 'T': case 'U': 
/*     */     case 'W': case 'X': case 'Y': default: 
/* 746 */       throw new IllegalArgumentException("Boxing should not be attempted for descriptor '" + ch + "'");
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toDescriptor(Class<?> type)
/*     */   {
/* 758 */     String name = type.getName();
/* 759 */     if (type.isPrimitive()) {
/* 760 */       switch (name.length()) {
/*     */       case 3: 
/* 762 */         return "I";
/*     */       case 4: 
/* 764 */         if (name.equals("byte")) {
/* 765 */           return "B";
/*     */         }
/* 767 */         if (name.equals("char")) {
/* 768 */           return "C";
/*     */         }
/* 770 */         if (name.equals("long")) {
/* 771 */           return "J";
/*     */         }
/* 773 */         if (name.equals("void")) {
/* 774 */           return "V";
/*     */         }
/*     */         break;
/*     */       case 5: 
/* 778 */         if (name.equals("float")) {
/* 779 */           return "F";
/*     */         }
/* 781 */         if (name.equals("short")) {
/* 782 */           return "S";
/*     */         }
/*     */         break;
/*     */       case 6: 
/* 786 */         if (name.equals("double")) {
/* 787 */           return "D";
/*     */         }
/*     */         break;
/*     */       case 7: 
/* 791 */         if (name.equals("boolean")) {
/* 792 */           return "Z";
/*     */         }
/*     */         break;
/*     */       }
/*     */     }
/*     */     else {
/* 798 */       if (name.charAt(0) != '[') {
/* 799 */         return "L" + type.getName().replace('.', '/');
/*     */       }
/*     */       
/* 802 */       if (name.endsWith(";")) {
/* 803 */         return name.substring(0, name.length() - 1).replace('.', '/');
/*     */       }
/*     */       
/* 806 */       return name;
/*     */     }
/*     */     
/*     */ 
/* 810 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String[] toParamDescriptors(Method method)
/*     */   {
/* 820 */     return toDescriptors(method.getParameterTypes());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String[] toParamDescriptors(Constructor<?> ctor)
/*     */   {
/* 830 */     return toDescriptors(ctor.getParameterTypes());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String[] toDescriptors(Class<?>[] types)
/*     */   {
/* 839 */     int typesCount = types.length;
/* 840 */     String[] descriptors = new String[typesCount];
/* 841 */     for (int p = 0; p < typesCount; p++) {
/* 842 */       descriptors[p] = toDescriptor(types[p]);
/*     */     }
/* 844 */     return descriptors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void insertOptimalLoad(MethodVisitor mv, int value)
/*     */   {
/* 853 */     if (value < 6) {
/* 854 */       mv.visitInsn(3 + value);
/*     */     }
/* 856 */     else if (value < 127) {
/* 857 */       mv.visitIntInsn(16, value);
/*     */     }
/* 859 */     else if (value < 32767) {
/* 860 */       mv.visitIntInsn(17, value);
/*     */     }
/*     */     else {
/* 863 */       mv.visitLdcInsn(Integer.valueOf(value));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void insertArrayStore(MethodVisitor mv, String arrayElementType)
/*     */   {
/* 875 */     if (arrayElementType.length() == 1) {
/* 876 */       switch (arrayElementType.charAt(0)) {
/* 877 */       case 'I':  mv.visitInsn(79); break;
/* 878 */       case 'J':  mv.visitInsn(80); break;
/* 879 */       case 'F':  mv.visitInsn(81); break;
/* 880 */       case 'D':  mv.visitInsn(82); break;
/* 881 */       case 'B':  mv.visitInsn(84); break;
/* 882 */       case 'C':  mv.visitInsn(85); break;
/* 883 */       case 'S':  mv.visitInsn(86); break;
/* 884 */       case 'Z':  mv.visitInsn(84); break;
/*     */       case 'E': case 'G': case 'H': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': default: 
/* 886 */         throw new IllegalArgumentException("Unexpected arraytype " + arrayElementType.charAt(0));
/*     */       }
/*     */       
/*     */     } else {
/* 890 */       mv.visitInsn(83);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int arrayCodeFor(String arraytype)
/*     */   {
/* 900 */     switch (arraytype.charAt(0)) {
/* 901 */     case 'I':  return 10;
/* 902 */     case 'J':  return 11;
/* 903 */     case 'F':  return 6;
/* 904 */     case 'D':  return 7;
/* 905 */     case 'B':  return 8;
/* 906 */     case 'C':  return 5;
/* 907 */     case 'S':  return 9;
/* 908 */     case 'Z':  return 4;
/*     */     }
/* 910 */     throw new IllegalArgumentException("Unexpected arraytype " + arraytype.charAt(0));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isReferenceTypeArray(String arraytype)
/*     */   {
/* 918 */     int length = arraytype.length();
/* 919 */     for (int i = 0; i < length; i++) {
/* 920 */       char ch = arraytype.charAt(i);
/* 921 */       if (ch != '[')
/* 922 */         return ch == 'L';
/*     */     }
/* 924 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void insertNewArrayCode(MethodVisitor mv, int size, String arraytype)
/*     */   {
/* 936 */     insertOptimalLoad(mv, size);
/* 937 */     if (arraytype.length() == 1) {
/* 938 */       mv.visitIntInsn(188, arrayCodeFor(arraytype));
/*     */ 
/*     */     }
/* 941 */     else if (arraytype.charAt(0) == '[')
/*     */     {
/*     */ 
/* 944 */       if (isReferenceTypeArray(arraytype)) {
/* 945 */         mv.visitTypeInsn(189, arraytype + ";");
/*     */       }
/*     */       else {
/* 948 */         mv.visitTypeInsn(189, arraytype);
/*     */       }
/*     */     }
/*     */     else {
/* 952 */       mv.visitTypeInsn(189, arraytype.substring(1));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void insertNumericUnboxOrPrimitiveTypeCoercion(MethodVisitor mv, String stackDescriptor, char targetDescriptor)
/*     */   {
/* 969 */     if (!isPrimitive(stackDescriptor)) {
/* 970 */       insertUnboxNumberInsns(mv, targetDescriptor, stackDescriptor);
/*     */     }
/*     */     else {
/* 973 */       insertAnyNecessaryTypeConversionBytecodes(mv, targetDescriptor, stackDescriptor);
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract interface ClinitAdder
/*     */   {
/*     */     public abstract void generateCode(MethodVisitor paramMethodVisitor, CodeFlow paramCodeFlow);
/*     */   }
/*     */   
/*     */   public static abstract interface FieldAdder
/*     */   {
/*     */     public abstract void generateField(ClassWriter paramClassWriter, CodeFlow paramCodeFlow);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\spel\CodeFlow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */