/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.AccessException;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.ExpressionInvocationTargetException;
/*     */ import org.springframework.expression.MethodExecutor;
/*     */ import org.springframework.expression.MethodResolver;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.expression.spel.SpelNode;
/*     */ import org.springframework.expression.spel.support.ReflectiveMethodExecutor;
/*     */ import org.springframework.expression.spel.support.ReflectiveMethodResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodReference
/*     */   extends SpelNodeImpl
/*     */ {
/*     */   private final String name;
/*     */   private final boolean nullSafe;
/*     */   private volatile CachedMethodExecutor cachedExecutor;
/*     */   
/*     */   public MethodReference(boolean nullSafe, String methodName, int pos, SpelNodeImpl... arguments)
/*     */   {
/*  59 */     super(pos, arguments);
/*  60 */     this.name = methodName;
/*  61 */     this.nullSafe = nullSafe;
/*     */   }
/*     */   
/*     */   public final String getName()
/*     */   {
/*  66 */     return this.name;
/*     */   }
/*     */   
/*     */   protected ValueRef getValueRef(ExpressionState state) throws EvaluationException
/*     */   {
/*  71 */     Object[] arguments = getArguments(state);
/*  72 */     if (state.getActiveContextObject().getValue() == null) {
/*  73 */       throwIfNotNullSafe(getArgumentTypes(arguments));
/*  74 */       return ValueRef.NullValueRef.INSTANCE;
/*     */     }
/*  76 */     return new MethodValueRef(state, arguments);
/*     */   }
/*     */   
/*     */   public TypedValue getValueInternal(ExpressionState state) throws EvaluationException
/*     */   {
/*  81 */     EvaluationContext evaluationContext = state.getEvaluationContext();
/*  82 */     Object value = state.getActiveContextObject().getValue();
/*  83 */     TypeDescriptor targetType = state.getActiveContextObject().getTypeDescriptor();
/*  84 */     Object[] arguments = getArguments(state);
/*  85 */     TypedValue result = getValueInternal(evaluationContext, value, targetType, arguments);
/*  86 */     updateExitTypeDescriptor();
/*  87 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   private TypedValue getValueInternal(EvaluationContext evaluationContext, Object value, TypeDescriptor targetType, Object[] arguments)
/*     */   {
/*  93 */     List<TypeDescriptor> argumentTypes = getArgumentTypes(arguments);
/*  94 */     if (value == null) {
/*  95 */       throwIfNotNullSafe(argumentTypes);
/*  96 */       return TypedValue.NULL;
/*     */     }
/*     */     
/*  99 */     MethodExecutor executorToUse = getCachedExecutor(evaluationContext, value, targetType, argumentTypes);
/* 100 */     if (executorToUse != null) {
/*     */       try {
/* 102 */         return executorToUse.execute(evaluationContext, value, arguments);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (AccessException ex)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 116 */         throwSimpleExceptionIfPossible(value, ex);
/*     */         
/*     */ 
/*     */ 
/* 120 */         this.cachedExecutor = null;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 125 */     executorToUse = findAccessorForMethod(this.name, argumentTypes, value, evaluationContext);
/* 126 */     this.cachedExecutor = new CachedMethodExecutor(executorToUse, (value instanceof Class) ? (Class)value : null, targetType, argumentTypes);
/*     */     try
/*     */     {
/* 129 */       return executorToUse.execute(evaluationContext, value, arguments);
/*     */     }
/*     */     catch (AccessException ex)
/*     */     {
/* 133 */       throwSimpleExceptionIfPossible(value, ex);
/*     */       
/*     */ 
/* 136 */       throw new SpelEvaluationException(getStartPosition(), ex, SpelMessage.EXCEPTION_DURING_METHOD_INVOCATION, new Object[] { this.name, value.getClass().getName(), ex.getMessage() });
/*     */     }
/*     */   }
/*     */   
/*     */   private void throwIfNotNullSafe(List<TypeDescriptor> argumentTypes) {
/* 141 */     if (!this.nullSafe)
/*     */     {
/*     */ 
/* 144 */       throw new SpelEvaluationException(getStartPosition(), SpelMessage.METHOD_CALL_ON_NULL_OBJECT_NOT_ALLOWED, new Object[] {FormatHelper.formatMethodForMessage(this.name, argumentTypes) });
/*     */     }
/*     */   }
/*     */   
/*     */   private Object[] getArguments(ExpressionState state) {
/* 149 */     Object[] arguments = new Object[getChildCount()];
/* 150 */     for (int i = 0; i < arguments.length; i++) {
/*     */       try
/*     */       {
/* 153 */         state.pushActiveContextObject(state.getScopeRootContextObject());
/* 154 */         arguments[i] = this.children[i].getValueInternal(state).getValue();
/*     */       }
/*     */       finally {
/* 157 */         state.popActiveContextObject();
/*     */       }
/*     */     }
/* 160 */     return arguments;
/*     */   }
/*     */   
/*     */   private List<TypeDescriptor> getArgumentTypes(Object... arguments) {
/* 164 */     List<TypeDescriptor> descriptors = new ArrayList(arguments.length);
/* 165 */     for (Object argument : arguments) {
/* 166 */       descriptors.add(TypeDescriptor.forObject(argument));
/*     */     }
/* 168 */     return Collections.unmodifiableList(descriptors);
/*     */   }
/*     */   
/*     */ 
/*     */   private MethodExecutor getCachedExecutor(EvaluationContext evaluationContext, Object value, TypeDescriptor target, List<TypeDescriptor> argumentTypes)
/*     */   {
/* 174 */     List<MethodResolver> methodResolvers = evaluationContext.getMethodResolvers();
/* 175 */     if ((methodResolvers == null) || (methodResolvers.size() != 1) || 
/* 176 */       (!(methodResolvers.get(0) instanceof ReflectiveMethodResolver)))
/*     */     {
/* 178 */       return null;
/*     */     }
/*     */     
/* 181 */     CachedMethodExecutor executorToCheck = this.cachedExecutor;
/* 182 */     if ((executorToCheck != null) && (executorToCheck.isSuitable(value, target, argumentTypes))) {
/* 183 */       return executorToCheck.get();
/*     */     }
/* 185 */     this.cachedExecutor = null;
/* 186 */     return null;
/*     */   }
/*     */   
/*     */   private MethodExecutor findAccessorForMethod(String name, List<TypeDescriptor> argumentTypes, Object targetObject, EvaluationContext evaluationContext)
/*     */     throws SpelEvaluationException
/*     */   {
/* 192 */     List<MethodResolver> methodResolvers = evaluationContext.getMethodResolvers();
/* 193 */     if (methodResolvers != null) {
/* 194 */       for (MethodResolver methodResolver : methodResolvers) {
/*     */         try {
/* 196 */           MethodExecutor methodExecutor = methodResolver.resolve(evaluationContext, targetObject, name, argumentTypes);
/*     */           
/* 198 */           if (methodExecutor != null) {
/* 199 */             return methodExecutor;
/*     */           }
/*     */         }
/*     */         catch (AccessException ex)
/*     */         {
/* 204 */           throw new SpelEvaluationException(getStartPosition(), ex, SpelMessage.PROBLEM_LOCATING_METHOD, new Object[] { name, targetObject.getClass() });
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 211 */     throw new SpelEvaluationException(getStartPosition(), SpelMessage.METHOD_NOT_FOUND, new Object[] {FormatHelper.formatMethodForMessage(name, argumentTypes), FormatHelper.formatClassNameForMessage((targetObject instanceof Class) ? (Class)targetObject : targetObject
/* 212 */       .getClass()) });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void throwSimpleExceptionIfPossible(Object value, AccessException ex)
/*     */   {
/* 220 */     if ((ex.getCause() instanceof InvocationTargetException)) {
/* 221 */       Throwable rootCause = ex.getCause().getCause();
/* 222 */       if ((rootCause instanceof RuntimeException)) {
/* 223 */         throw ((RuntimeException)rootCause);
/*     */       }
/*     */       
/*     */ 
/* 227 */       throw new ExpressionInvocationTargetException(getStartPosition(), "A problem occurred when trying to execute method '" + this.name + "' on object of type [" + value.getClass().getName() + "]", rootCause);
/*     */     }
/*     */   }
/*     */   
/*     */   private void updateExitTypeDescriptor() {
/* 232 */     CachedMethodExecutor executorToCheck = this.cachedExecutor;
/* 233 */     if ((executorToCheck != null) && ((executorToCheck.get() instanceof ReflectiveMethodExecutor))) {
/* 234 */       Method method = ((ReflectiveMethodExecutor)executorToCheck.get()).getMethod();
/* 235 */       this.exitTypeDescriptor = CodeFlow.toDescriptor(method.getReturnType());
/*     */     }
/*     */   }
/*     */   
/*     */   public String toStringAST()
/*     */   {
/* 241 */     StringBuilder sb = new StringBuilder(this.name);
/* 242 */     sb.append("(");
/* 243 */     for (int i = 0; i < getChildCount(); i++) {
/* 244 */       if (i > 0) {
/* 245 */         sb.append(",");
/*     */       }
/* 247 */       sb.append(getChild(i).toStringAST());
/*     */     }
/* 249 */     sb.append(")");
/* 250 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCompilable()
/*     */   {
/* 259 */     CachedMethodExecutor executorToCheck = this.cachedExecutor;
/* 260 */     if ((executorToCheck == null) || (!(executorToCheck.get() instanceof ReflectiveMethodExecutor))) {
/* 261 */       return false;
/*     */     }
/*     */     
/* 264 */     for (SpelNodeImpl child : this.children) {
/* 265 */       if (!child.isCompilable()) {
/* 266 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 270 */     ReflectiveMethodExecutor executor = (ReflectiveMethodExecutor)executorToCheck.get();
/* 271 */     if (executor.didArgumentConversionOccur()) {
/* 272 */       return false;
/*     */     }
/* 274 */     Method method = executor.getMethod();
/* 275 */     Object clazz = method.getDeclaringClass();
/* 276 */     if ((!Modifier.isPublic(((Class)clazz).getModifiers())) && (executor.getPublicDeclaringClass() == null)) {
/* 277 */       return false;
/*     */     }
/*     */     
/* 280 */     return true;
/*     */   }
/*     */   
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf)
/*     */   {
/* 285 */     CachedMethodExecutor executorToCheck = this.cachedExecutor;
/* 286 */     if ((executorToCheck == null) || (!(executorToCheck.get() instanceof ReflectiveMethodExecutor))) {
/* 287 */       throw new IllegalStateException("No applicable cached executor found: " + executorToCheck);
/*     */     }
/*     */     
/* 290 */     ReflectiveMethodExecutor methodExecutor = (ReflectiveMethodExecutor)executorToCheck.get();
/* 291 */     Method method = methodExecutor.getMethod();
/* 292 */     boolean isStaticMethod = Modifier.isStatic(method.getModifiers());
/* 293 */     String descriptor = cf.lastDescriptor();
/*     */     
/* 295 */     if (descriptor == null) {
/* 296 */       if (!isStaticMethod)
/*     */       {
/* 298 */         cf.loadTarget(mv);
/*     */       }
/*     */       
/*     */     }
/* 302 */     else if (isStaticMethod)
/*     */     {
/* 304 */       mv.visitInsn(87);
/*     */     }
/*     */     
/*     */ 
/* 308 */     if (CodeFlow.isPrimitive(descriptor)) {
/* 309 */       CodeFlow.insertBoxIfNecessary(mv, descriptor.charAt(0));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 314 */     String classDesc = Modifier.isPublic(method.getDeclaringClass().getModifiers()) ? method.getDeclaringClass().getName().replace('.', '/') : methodExecutor.getPublicDeclaringClass().getName().replace('.', '/');
/* 315 */     if ((!isStaticMethod) && (
/* 316 */       (descriptor == null) || (!descriptor.substring(1).equals(classDesc)))) {
/* 317 */       CodeFlow.insertCheckCast(mv, "L" + classDesc);
/*     */     }
/*     */     
/*     */ 
/* 321 */     generateCodeForArguments(mv, cf, method, this.children);
/* 322 */     mv.visitMethodInsn(isStaticMethod ? 184 : 182, classDesc, method.getName(), 
/* 323 */       CodeFlow.createSignatureDescriptor(method), method.getDeclaringClass().isInterface());
/* 324 */     cf.pushDescriptor(this.exitTypeDescriptor);
/*     */   }
/*     */   
/*     */ 
/*     */   private class MethodValueRef
/*     */     implements ValueRef
/*     */   {
/*     */     private final EvaluationContext evaluationContext;
/*     */     
/*     */     private final Object value;
/*     */     private final TypeDescriptor targetType;
/*     */     private final Object[] arguments;
/*     */     
/*     */     public MethodValueRef(ExpressionState state, Object[] arguments)
/*     */     {
/* 339 */       this.evaluationContext = state.getEvaluationContext();
/* 340 */       this.value = state.getActiveContextObject().getValue();
/* 341 */       this.targetType = state.getActiveContextObject().getTypeDescriptor();
/* 342 */       this.arguments = arguments;
/*     */     }
/*     */     
/*     */     public TypedValue getValue()
/*     */     {
/* 347 */       TypedValue result = MethodReference.this.getValueInternal(this.evaluationContext, this.value, this.targetType, this.arguments);
/*     */       
/* 349 */       MethodReference.this.updateExitTypeDescriptor();
/* 350 */       return result;
/*     */     }
/*     */     
/*     */     public void setValue(Object newValue)
/*     */     {
/* 355 */       throw new IllegalAccessError();
/*     */     }
/*     */     
/*     */     public boolean isWritable()
/*     */     {
/* 360 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class CachedMethodExecutor
/*     */   {
/*     */     private final MethodExecutor methodExecutor;
/*     */     
/*     */     private final Class<?> staticClass;
/*     */     
/*     */     private final TypeDescriptor target;
/*     */     
/*     */     private final List<TypeDescriptor> argumentTypes;
/*     */     
/*     */     public CachedMethodExecutor(MethodExecutor methodExecutor, Class<?> staticClass, TypeDescriptor target, List<TypeDescriptor> argumentTypes)
/*     */     {
/* 377 */       this.methodExecutor = methodExecutor;
/* 378 */       this.staticClass = staticClass;
/* 379 */       this.target = target;
/* 380 */       this.argumentTypes = argumentTypes;
/*     */     }
/*     */     
/*     */     public boolean isSuitable(Object value, TypeDescriptor target, List<TypeDescriptor> argumentTypes)
/*     */     {
/* 385 */       return ((this.staticClass == null) || (this.staticClass == value)) && (this.target.equals(target)) && (this.argumentTypes.equals(argumentTypes));
/*     */     }
/*     */     
/*     */     public MethodExecutor get() {
/* 389 */       return this.methodExecutor;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\spel\ast\MethodReference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */