/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.SpelEvaluationException;
/*     */ import org.springframework.expression.spel.SpelMessage;
/*     */ import org.springframework.expression.spel.SpelNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Ternary
/*     */   extends SpelNodeImpl
/*     */ {
/*     */   public Ternary(int pos, SpelNodeImpl... args)
/*     */   {
/*  38 */     super(pos, args);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TypedValue getValueInternal(ExpressionState state)
/*     */     throws EvaluationException
/*     */   {
/*  51 */     Boolean value = (Boolean)this.children[0].getValue(state, Boolean.class);
/*  52 */     if (value == null) {
/*  53 */       throw new SpelEvaluationException(getChild(0).getStartPosition(), SpelMessage.TYPE_CONVERSION_ERROR, new Object[] { "null", "boolean" });
/*     */     }
/*     */     
/*  56 */     TypedValue result = this.children[2].getValueInternal(state);
/*  57 */     computeExitTypeDescriptor();
/*  58 */     return result;
/*     */   }
/*     */   
/*     */   public String toStringAST()
/*     */   {
/*  63 */     return getChild(0).toStringAST() + " ? " + getChild(1).toStringAST() + " : " + getChild(2).toStringAST();
/*     */   }
/*     */   
/*     */   private void computeExitTypeDescriptor() {
/*  67 */     if ((this.exitTypeDescriptor == null) && (this.children[1].exitTypeDescriptor != null) && (this.children[2].exitTypeDescriptor != null))
/*     */     {
/*  69 */       String leftDescriptor = this.children[1].exitTypeDescriptor;
/*  70 */       String rightDescriptor = this.children[2].exitTypeDescriptor;
/*  71 */       if (leftDescriptor.equals(rightDescriptor)) {
/*  72 */         this.exitTypeDescriptor = leftDescriptor;
/*     */       }
/*  74 */       else if ((leftDescriptor.equals("Ljava/lang/Object")) && (!CodeFlow.isPrimitive(rightDescriptor))) {
/*  75 */         this.exitTypeDescriptor = rightDescriptor;
/*     */       }
/*  77 */       else if ((rightDescriptor.equals("Ljava/lang/Object")) && (!CodeFlow.isPrimitive(leftDescriptor))) {
/*  78 */         this.exitTypeDescriptor = leftDescriptor;
/*     */       }
/*     */       else
/*     */       {
/*  82 */         this.exitTypeDescriptor = "Ljava/lang/Object";
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isCompilable()
/*     */   {
/*  89 */     SpelNodeImpl condition = this.children[0];
/*  90 */     SpelNodeImpl left = this.children[1];
/*  91 */     SpelNodeImpl right = this.children[2];
/*     */     
/*  93 */     return (condition.isCompilable()) && (left.isCompilable()) && (right.isCompilable()) && (CodeFlow.isBooleanCompatible(condition.exitTypeDescriptor)) && (left.exitTypeDescriptor != null) && (right.exitTypeDescriptor != null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf)
/*     */   {
/* 100 */     computeExitTypeDescriptor();
/* 101 */     cf.enterCompilationScope();
/* 102 */     this.children[0].generateCode(mv, cf);
/* 103 */     if (!CodeFlow.isPrimitive(cf.lastDescriptor())) {
/* 104 */       CodeFlow.insertUnboxInsns(mv, 'Z', cf.lastDescriptor());
/*     */     }
/* 106 */     cf.exitCompilationScope();
/* 107 */     Label elseTarget = new Label();
/* 108 */     Label endOfIf = new Label();
/* 109 */     mv.visitJumpInsn(153, elseTarget);
/* 110 */     cf.enterCompilationScope();
/* 111 */     this.children[1].generateCode(mv, cf);
/* 112 */     if (!CodeFlow.isPrimitive(this.exitTypeDescriptor)) {
/* 113 */       CodeFlow.insertBoxIfNecessary(mv, cf.lastDescriptor().charAt(0));
/*     */     }
/* 115 */     cf.exitCompilationScope();
/* 116 */     mv.visitJumpInsn(167, endOfIf);
/* 117 */     mv.visitLabel(elseTarget);
/* 118 */     cf.enterCompilationScope();
/* 119 */     this.children[2].generateCode(mv, cf);
/* 120 */     if (!CodeFlow.isPrimitive(this.exitTypeDescriptor)) {
/* 121 */       CodeFlow.insertBoxIfNecessary(mv, cf.lastDescriptor().charAt(0));
/*     */     }
/* 123 */     cf.exitCompilationScope();
/* 124 */     mv.visitLabel(endOfIf);
/* 125 */     cf.pushDescriptor(this.exitTypeDescriptor);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\spel\ast\Ternary.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */