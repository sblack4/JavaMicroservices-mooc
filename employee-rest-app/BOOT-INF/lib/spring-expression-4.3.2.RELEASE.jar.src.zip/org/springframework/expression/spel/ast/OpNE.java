/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.CodeFlow;
/*     */ import org.springframework.expression.spel.ExpressionState;
/*     */ import org.springframework.expression.spel.support.BooleanTypedValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpNE
/*     */   extends Operator
/*     */ {
/*     */   public OpNE(int pos, SpelNodeImpl... operands)
/*     */   {
/*  35 */     super("!=", pos, operands);
/*  36 */     this.exitTypeDescriptor = "Z";
/*     */   }
/*     */   
/*     */   public BooleanTypedValue getValueInternal(ExpressionState state) throws EvaluationException
/*     */   {
/*  41 */     Object left = getLeftOperand().getValueInternal(state).getValue();
/*  42 */     Object right = getRightOperand().getValueInternal(state).getValue();
/*  43 */     this.leftActualDescriptor = CodeFlow.toDescriptorFromObject(left);
/*  44 */     this.rightActualDescriptor = CodeFlow.toDescriptorFromObject(right);
/*  45 */     return BooleanTypedValue.forValue(!equalityCheck(state, left, right));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isCompilable()
/*     */   {
/*  52 */     SpelNodeImpl left = getLeftOperand();
/*  53 */     SpelNodeImpl right = getRightOperand();
/*  54 */     if ((!left.isCompilable()) || (!right.isCompilable())) {
/*  55 */       return false;
/*     */     }
/*     */     
/*  58 */     String leftDesc = left.exitTypeDescriptor;
/*  59 */     String rightDesc = right.exitTypeDescriptor;
/*  60 */     Operator.DescriptorComparison dc = Operator.DescriptorComparison.checkNumericCompatibility(leftDesc, rightDesc, this.leftActualDescriptor, this.rightActualDescriptor);
/*  61 */     return (!dc.areNumbers) || (dc.areCompatible);
/*     */   }
/*     */   
/*     */   public void generateCode(MethodVisitor mv, CodeFlow cf)
/*     */   {
/*  66 */     String leftDesc = getLeftOperand().exitTypeDescriptor;
/*  67 */     String rightDesc = getRightOperand().exitTypeDescriptor;
/*  68 */     Label elseTarget = new Label();
/*  69 */     Label endOfIf = new Label();
/*  70 */     boolean leftPrim = CodeFlow.isPrimitive(leftDesc);
/*  71 */     boolean rightPrim = CodeFlow.isPrimitive(rightDesc);
/*     */     
/*  73 */     Operator.DescriptorComparison dc = Operator.DescriptorComparison.checkNumericCompatibility(leftDesc, rightDesc, this.leftActualDescriptor, this.rightActualDescriptor);
/*     */     
/*  75 */     if ((dc.areNumbers) && (dc.areCompatible)) {
/*  76 */       char targetType = dc.compatibleType;
/*     */       
/*  78 */       getLeftOperand().generateCode(mv, cf);
/*  79 */       if (!leftPrim) {
/*  80 */         CodeFlow.insertUnboxInsns(mv, targetType, leftDesc);
/*     */       }
/*     */       
/*  83 */       cf.enterCompilationScope();
/*  84 */       getRightOperand().generateCode(mv, cf);
/*  85 */       cf.exitCompilationScope();
/*  86 */       if (!rightPrim) {
/*  87 */         CodeFlow.insertUnboxInsns(mv, targetType, rightDesc);
/*     */       }
/*     */       
/*  90 */       if (targetType == 'D') {
/*  91 */         mv.visitInsn(151);
/*  92 */         mv.visitJumpInsn(153, elseTarget);
/*     */       }
/*  94 */       else if (targetType == 'F') {
/*  95 */         mv.visitInsn(149);
/*  96 */         mv.visitJumpInsn(153, elseTarget);
/*     */       }
/*  98 */       else if (targetType == 'J') {
/*  99 */         mv.visitInsn(148);
/* 100 */         mv.visitJumpInsn(153, elseTarget);
/*     */       }
/* 102 */       else if ((targetType == 'I') || (targetType == 'Z')) {
/* 103 */         mv.visitJumpInsn(159, elseTarget);
/*     */       }
/*     */       else {
/* 106 */         throw new IllegalStateException("Unexpected descriptor " + leftDesc);
/*     */       }
/*     */     }
/*     */     else {
/* 110 */       getLeftOperand().generateCode(mv, cf);
/* 111 */       getRightOperand().generateCode(mv, cf);
/* 112 */       mv.visitJumpInsn(165, elseTarget);
/*     */     }
/* 114 */     mv.visitInsn(4);
/* 115 */     mv.visitJumpInsn(167, endOfIf);
/* 116 */     mv.visitLabel(elseTarget);
/* 117 */     mv.visitInsn(3);
/* 118 */     mv.visitLabel(endOfIf);
/* 119 */     cf.pushDescriptor("Z");
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\spel\ast\OpNE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */