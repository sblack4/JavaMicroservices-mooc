/*     */ package org.springframework.expression.spel.support;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.AccessException;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.MethodExecutor;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectiveMethodExecutor
/*     */   implements MethodExecutor
/*     */ {
/*     */   private final Method method;
/*     */   private final Integer varargsPosition;
/*  41 */   private boolean computedPublicDeclaringClass = false;
/*     */   
/*     */   private Class<?> publicDeclaringClass;
/*     */   
/*  45 */   private boolean argumentConversionOccurred = false;
/*     */   
/*     */   public ReflectiveMethodExecutor(Method method) {
/*  48 */     this.method = method;
/*  49 */     if (method.isVarArgs()) {
/*  50 */       Class<?>[] paramTypes = method.getParameterTypes();
/*  51 */       this.varargsPosition = Integer.valueOf(paramTypes.length - 1);
/*     */     }
/*     */     else {
/*  54 */       this.varargsPosition = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public Method getMethod() {
/*  59 */     return this.method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getPublicDeclaringClass()
/*     */   {
/*  71 */     if (!this.computedPublicDeclaringClass) {
/*  72 */       this.publicDeclaringClass = discoverPublicClass(this.method, this.method.getDeclaringClass());
/*  73 */       this.computedPublicDeclaringClass = true;
/*     */     }
/*  75 */     return this.publicDeclaringClass;
/*     */   }
/*     */   
/*     */   private Class<?> discoverPublicClass(Method method, Class<?> clazz) {
/*  79 */     if (Modifier.isPublic(clazz.getModifiers())) {
/*     */       try {
/*  81 */         clazz.getDeclaredMethod(method.getName(), method.getParameterTypes());
/*  82 */         return clazz;
/*     */       }
/*     */       catch (NoSuchMethodException localNoSuchMethodException) {}
/*     */     }
/*     */     
/*     */ 
/*  88 */     Class<?>[] ifcs = clazz.getInterfaces();
/*  89 */     for (Class<?> ifc : ifcs) {
/*  90 */       discoverPublicClass(method, ifc);
/*     */     }
/*  92 */     if (clazz.getSuperclass() != null) {
/*  93 */       return discoverPublicClass(method, clazz.getSuperclass());
/*     */     }
/*  95 */     return null;
/*     */   }
/*     */   
/*     */   public boolean didArgumentConversionOccur() {
/*  99 */     return this.argumentConversionOccurred;
/*     */   }
/*     */   
/*     */   public TypedValue execute(EvaluationContext context, Object target, Object... arguments) throws AccessException
/*     */   {
/*     */     try
/*     */     {
/* 106 */       if (arguments != null) {
/* 107 */         this.argumentConversionOccurred = ReflectionHelper.convertArguments(context.getTypeConverter(), arguments, this.method, this.varargsPosition);
/*     */       }
/* 109 */       if (this.method.isVarArgs()) {
/* 110 */         arguments = ReflectionHelper.setupArgumentsForVarargsInvocation(this.method.getParameterTypes(), arguments);
/*     */       }
/* 112 */       ReflectionUtils.makeAccessible(this.method);
/* 113 */       Object value = this.method.invoke(target, arguments);
/* 114 */       return new TypedValue(value, new TypeDescriptor(new MethodParameter(this.method, -1)).narrow(value));
/*     */     }
/*     */     catch (Exception ex) {
/* 117 */       throw new AccessException("Problem invoking method: " + this.method, ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\spel\support\ReflectiveMethodExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */