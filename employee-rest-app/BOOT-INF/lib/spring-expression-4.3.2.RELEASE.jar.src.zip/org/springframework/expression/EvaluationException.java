/*    */ package org.springframework.expression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EvaluationException
/*    */   extends ExpressionException
/*    */ {
/*    */   public EvaluationException(int position, String message)
/*    */   {
/* 34 */     super(position, message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public EvaluationException(String expressionString, String message)
/*    */   {
/* 43 */     super(expressionString, message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public EvaluationException(int position, String message, Throwable cause)
/*    */   {
/* 53 */     super(position, message, cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public EvaluationException(String message)
/*    */   {
/* 61 */     super(message);
/*    */   }
/*    */   
/*    */   public EvaluationException(String message, Throwable cause) {
/* 65 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-expression-4.3.2.RELEASE.jar!\org\springframework\expression\EvaluationException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */