package org.apache.log4j;

public class BasicConfigurator
{
  public static void configure() {}
  
  public static void configure(Appender appender) {}
  
  public static void resetConfiguration() {}
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\log4j-over-slf4j-1.7.21.jar!\org\apache\log4j\BasicConfigurator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */