/*      */ package org.springframework.asm;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ClassWriter
/*      */   extends ClassVisitor
/*      */ {
/*      */   public static final int COMPUTE_MAXS = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int COMPUTE_FRAMES = 2;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int ACC_SYNTHETIC_ATTRIBUTE = 262144;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int TO_ACC_SYNTHETIC = 64;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int NOARG_INSN = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int SBYTE_INSN = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int SHORT_INSN = 2;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int VAR_INSN = 3;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int IMPLVAR_INSN = 4;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int TYPE_INSN = 5;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int FIELDORMETH_INSN = 6;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int ITFMETH_INSN = 7;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int INDYMETH_INSN = 8;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int LABEL_INSN = 9;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int LABELW_INSN = 10;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int LDC_INSN = 11;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int LDCW_INSN = 12;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int IINC_INSN = 13;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int TABL_INSN = 14;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int LOOK_INSN = 15;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int MANA_INSN = 16;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int WIDE_INSN = 17;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final byte[] TYPE;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int CLASS = 7;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int FIELD = 9;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int METH = 10;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int IMETH = 11;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int STR = 8;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int INT = 3;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int FLOAT = 4;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int LONG = 5;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int DOUBLE = 6;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int NAME_TYPE = 12;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int UTF8 = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int MTYPE = 16;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int HANDLE = 15;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int INDY = 18;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int HANDLE_BASE = 20;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int TYPE_NORMAL = 30;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int TYPE_UNINIT = 31;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int TYPE_MERGED = 32;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int BSM = 33;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   ClassReader cr;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int version;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int index;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final ByteVector pool;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item[] items;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int threshold;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final Item key;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final Item key2;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final Item key3;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final Item key4;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item[] typeTable;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private short typeCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int access;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int name;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String thisName;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int signature;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int superName;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int interfaceCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int[] interfaces;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int sourceFile;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ByteVector sourceDebug;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int enclosingMethodOwner;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int enclosingMethod;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AnnotationWriter anns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AnnotationWriter ianns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AnnotationWriter tanns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AnnotationWriter itanns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Attribute attrs;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int innerClassesCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ByteVector innerClasses;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int bootstrapMethodsCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   ByteVector bootstrapMethods;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   FieldWriter firstField;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   FieldWriter lastField;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   MethodWriter firstMethod;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   MethodWriter lastMethod;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean computeMaxs;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean computeFrames;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean invalidFrames;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static
/*      */   {
/*  516 */     byte[] b = new byte['Ü'];
/*  517 */     String s = "AAAAAAAAAAAAAAAABCLMMDDDDDEEEEEEEEEEEEEEEEEEEEAAAAAAAADDDDDEEEEEEEEEEEEEEEEEEEEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANAAAAAAAAAAAAAAAAAAAAJJJJJJJJJJJJJJJJDOPAAAAAAGGGGGGGHIFBFAAFFAARQJJKKJJJJJJJJJJJJJJJJJJ";
/*      */     
/*      */ 
/*      */ 
/*  521 */     for (int i = 0; i < b.length; i++) {
/*  522 */       b[i] = ((byte)(s.charAt(i) - 'A'));
/*      */     }
/*  524 */     TYPE = b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClassWriter(int flags)
/*      */   {
/*  608 */     super(327680);
/*  609 */     this.index = 1;
/*  610 */     this.pool = new ByteVector();
/*  611 */     this.items = new Item['Ā'];
/*  612 */     this.threshold = ((int)(0.75D * this.items.length));
/*  613 */     this.key = new Item();
/*  614 */     this.key2 = new Item();
/*  615 */     this.key3 = new Item();
/*  616 */     this.key4 = new Item();
/*  617 */     this.computeMaxs = ((flags & 0x1) != 0);
/*  618 */     this.computeFrames = ((flags & 0x2) != 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClassWriter(ClassReader classReader, int flags)
/*      */   {
/*  654 */     this(flags);
/*  655 */     classReader.copyPool(this);
/*  656 */     this.cr = classReader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void visit(int version, int access, String name, String signature, String superName, String[] interfaces)
/*      */   {
/*  667 */     this.version = version;
/*  668 */     this.access = access;
/*  669 */     this.name = newClass(name);
/*  670 */     this.thisName = name;
/*  671 */     if (signature != null) {
/*  672 */       this.signature = newUTF8(signature);
/*      */     }
/*  674 */     this.superName = (superName == null ? 0 : newClass(superName));
/*  675 */     if ((interfaces != null) && (interfaces.length > 0)) {
/*  676 */       this.interfaceCount = interfaces.length;
/*  677 */       this.interfaces = new int[this.interfaceCount];
/*  678 */       for (int i = 0; i < this.interfaceCount; i++) {
/*  679 */         this.interfaces[i] = newClass(interfaces[i]);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public final void visitSource(String file, String debug)
/*      */   {
/*  686 */     if (file != null) {
/*  687 */       this.sourceFile = newUTF8(file);
/*      */     }
/*  689 */     if (debug != null) {
/*  690 */       this.sourceDebug = new ByteVector().encodeUTF8(debug, 0, Integer.MAX_VALUE);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public final void visitOuterClass(String owner, String name, String desc)
/*      */   {
/*  698 */     this.enclosingMethodOwner = newClass(owner);
/*  699 */     if ((name != null) && (desc != null)) {
/*  700 */       this.enclosingMethod = newNameType(name, desc);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final AnnotationVisitor visitAnnotation(String desc, boolean visible)
/*      */   {
/*  710 */     ByteVector bv = new ByteVector();
/*      */     
/*  712 */     bv.putShort(newUTF8(desc)).putShort(0);
/*  713 */     AnnotationWriter aw = new AnnotationWriter(this, true, bv, bv, 2);
/*  714 */     if (visible) {
/*  715 */       aw.next = this.anns;
/*  716 */       this.anns = aw;
/*      */     } else {
/*  718 */       aw.next = this.ianns;
/*  719 */       this.ianns = aw;
/*      */     }
/*  721 */     return aw;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final AnnotationVisitor visitTypeAnnotation(int typeRef, TypePath typePath, String desc, boolean visible)
/*      */   {
/*  730 */     ByteVector bv = new ByteVector();
/*      */     
/*  732 */     AnnotationWriter.putTarget(typeRef, typePath, bv);
/*      */     
/*  734 */     bv.putShort(newUTF8(desc)).putShort(0);
/*  735 */     AnnotationWriter aw = new AnnotationWriter(this, true, bv, bv, bv.length - 2);
/*      */     
/*  737 */     if (visible) {
/*  738 */       aw.next = this.tanns;
/*  739 */       this.tanns = aw;
/*      */     } else {
/*  741 */       aw.next = this.itanns;
/*  742 */       this.itanns = aw;
/*      */     }
/*  744 */     return aw;
/*      */   }
/*      */   
/*      */   public final void visitAttribute(Attribute attr)
/*      */   {
/*  749 */     attr.next = this.attrs;
/*  750 */     this.attrs = attr;
/*      */   }
/*      */   
/*      */ 
/*      */   public final void visitInnerClass(String name, String outerName, String innerName, int access)
/*      */   {
/*  756 */     if (this.innerClasses == null) {
/*  757 */       this.innerClasses = new ByteVector();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  769 */     Item nameItem = newClassItem(name);
/*  770 */     if (nameItem.intVal == 0) {
/*  771 */       this.innerClassesCount += 1;
/*  772 */       this.innerClasses.putShort(nameItem.index);
/*  773 */       this.innerClasses.putShort(outerName == null ? 0 : newClass(outerName));
/*  774 */       this.innerClasses.putShort(innerName == null ? 0 : newUTF8(innerName));
/*  775 */       this.innerClasses.putShort(access);
/*  776 */       nameItem.intVal = this.innerClassesCount;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final FieldVisitor visitField(int access, String name, String desc, String signature, Object value)
/*      */   {
/*  787 */     return new FieldWriter(this, access, name, desc, signature, value);
/*      */   }
/*      */   
/*      */ 
/*      */   public final MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions)
/*      */   {
/*  793 */     return new MethodWriter(this, access, name, desc, signature, exceptions, this.computeMaxs, this.computeFrames);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] toByteArray()
/*      */   {
/*  811 */     if (this.index > 65535) {
/*  812 */       throw new RuntimeException("Class file too large!");
/*      */     }
/*      */     
/*  815 */     int size = 24 + 2 * this.interfaceCount;
/*  816 */     int nbFields = 0;
/*  817 */     FieldWriter fb = this.firstField;
/*  818 */     while (fb != null) {
/*  819 */       nbFields++;
/*  820 */       size += fb.getSize();
/*  821 */       fb = (FieldWriter)fb.fv;
/*      */     }
/*  823 */     int nbMethods = 0;
/*  824 */     MethodWriter mb = this.firstMethod;
/*  825 */     while (mb != null) {
/*  826 */       nbMethods++;
/*  827 */       size += mb.getSize();
/*  828 */       mb = (MethodWriter)mb.mv;
/*      */     }
/*  830 */     int attributeCount = 0;
/*  831 */     if (this.bootstrapMethods != null)
/*      */     {
/*      */ 
/*  834 */       attributeCount++;
/*  835 */       size += 8 + this.bootstrapMethods.length;
/*  836 */       newUTF8("BootstrapMethods");
/*      */     }
/*  838 */     if (this.signature != 0) {
/*  839 */       attributeCount++;
/*  840 */       size += 8;
/*  841 */       newUTF8("Signature");
/*      */     }
/*  843 */     if (this.sourceFile != 0) {
/*  844 */       attributeCount++;
/*  845 */       size += 8;
/*  846 */       newUTF8("SourceFile");
/*      */     }
/*  848 */     if (this.sourceDebug != null) {
/*  849 */       attributeCount++;
/*  850 */       size += this.sourceDebug.length + 6;
/*  851 */       newUTF8("SourceDebugExtension");
/*      */     }
/*  853 */     if (this.enclosingMethodOwner != 0) {
/*  854 */       attributeCount++;
/*  855 */       size += 10;
/*  856 */       newUTF8("EnclosingMethod");
/*      */     }
/*  858 */     if ((this.access & 0x20000) != 0) {
/*  859 */       attributeCount++;
/*  860 */       size += 6;
/*  861 */       newUTF8("Deprecated");
/*      */     }
/*  863 */     if (((this.access & 0x1000) != 0) && (
/*  864 */       ((this.version & 0xFFFF) < 49) || ((this.access & 0x40000) != 0)))
/*      */     {
/*  866 */       attributeCount++;
/*  867 */       size += 6;
/*  868 */       newUTF8("Synthetic");
/*      */     }
/*      */     
/*  871 */     if (this.innerClasses != null) {
/*  872 */       attributeCount++;
/*  873 */       size += 8 + this.innerClasses.length;
/*  874 */       newUTF8("InnerClasses");
/*      */     }
/*  876 */     if (this.anns != null) {
/*  877 */       attributeCount++;
/*  878 */       size += 8 + this.anns.getSize();
/*  879 */       newUTF8("RuntimeVisibleAnnotations");
/*      */     }
/*  881 */     if (this.ianns != null) {
/*  882 */       attributeCount++;
/*  883 */       size += 8 + this.ianns.getSize();
/*  884 */       newUTF8("RuntimeInvisibleAnnotations");
/*      */     }
/*  886 */     if (this.tanns != null) {
/*  887 */       attributeCount++;
/*  888 */       size += 8 + this.tanns.getSize();
/*  889 */       newUTF8("RuntimeVisibleTypeAnnotations");
/*      */     }
/*  891 */     if (this.itanns != null) {
/*  892 */       attributeCount++;
/*  893 */       size += 8 + this.itanns.getSize();
/*  894 */       newUTF8("RuntimeInvisibleTypeAnnotations");
/*      */     }
/*  896 */     if (this.attrs != null) {
/*  897 */       attributeCount += this.attrs.getCount();
/*  898 */       size += this.attrs.getSize(this, null, 0, -1, -1);
/*      */     }
/*  900 */     size += this.pool.length;
/*      */     
/*      */ 
/*  903 */     ByteVector out = new ByteVector(size);
/*  904 */     out.putInt(-889275714).putInt(this.version);
/*  905 */     out.putShort(this.index).putByteArray(this.pool.data, 0, this.pool.length);
/*  906 */     int mask = 0x60000 | (this.access & 0x40000) / 64;
/*      */     
/*  908 */     out.putShort(this.access & (mask ^ 0xFFFFFFFF)).putShort(this.name).putShort(this.superName);
/*  909 */     out.putShort(this.interfaceCount);
/*  910 */     for (int i = 0; i < this.interfaceCount; i++) {
/*  911 */       out.putShort(this.interfaces[i]);
/*      */     }
/*  913 */     out.putShort(nbFields);
/*  914 */     fb = this.firstField;
/*  915 */     while (fb != null) {
/*  916 */       fb.put(out);
/*  917 */       fb = (FieldWriter)fb.fv;
/*      */     }
/*  919 */     out.putShort(nbMethods);
/*  920 */     mb = this.firstMethod;
/*  921 */     while (mb != null) {
/*  922 */       mb.put(out);
/*  923 */       mb = (MethodWriter)mb.mv;
/*      */     }
/*  925 */     out.putShort(attributeCount);
/*  926 */     if (this.bootstrapMethods != null) {
/*  927 */       out.putShort(newUTF8("BootstrapMethods"));
/*  928 */       out.putInt(this.bootstrapMethods.length + 2).putShort(this.bootstrapMethodsCount);
/*      */       
/*  930 */       out.putByteArray(this.bootstrapMethods.data, 0, this.bootstrapMethods.length);
/*      */     }
/*  932 */     if (this.signature != 0) {
/*  933 */       out.putShort(newUTF8("Signature")).putInt(2).putShort(this.signature);
/*      */     }
/*  935 */     if (this.sourceFile != 0) {
/*  936 */       out.putShort(newUTF8("SourceFile")).putInt(2).putShort(this.sourceFile);
/*      */     }
/*  938 */     if (this.sourceDebug != null) {
/*  939 */       int len = this.sourceDebug.length;
/*  940 */       out.putShort(newUTF8("SourceDebugExtension")).putInt(len);
/*  941 */       out.putByteArray(this.sourceDebug.data, 0, len);
/*      */     }
/*  943 */     if (this.enclosingMethodOwner != 0) {
/*  944 */       out.putShort(newUTF8("EnclosingMethod")).putInt(4);
/*  945 */       out.putShort(this.enclosingMethodOwner).putShort(this.enclosingMethod);
/*      */     }
/*  947 */     if ((this.access & 0x20000) != 0) {
/*  948 */       out.putShort(newUTF8("Deprecated")).putInt(0);
/*      */     }
/*  950 */     if (((this.access & 0x1000) != 0) && (
/*  951 */       ((this.version & 0xFFFF) < 49) || ((this.access & 0x40000) != 0)))
/*      */     {
/*  953 */       out.putShort(newUTF8("Synthetic")).putInt(0);
/*      */     }
/*      */     
/*  956 */     if (this.innerClasses != null) {
/*  957 */       out.putShort(newUTF8("InnerClasses"));
/*  958 */       out.putInt(this.innerClasses.length + 2).putShort(this.innerClassesCount);
/*  959 */       out.putByteArray(this.innerClasses.data, 0, this.innerClasses.length);
/*      */     }
/*  961 */     if (this.anns != null) {
/*  962 */       out.putShort(newUTF8("RuntimeVisibleAnnotations"));
/*  963 */       this.anns.put(out);
/*      */     }
/*  965 */     if (this.ianns != null) {
/*  966 */       out.putShort(newUTF8("RuntimeInvisibleAnnotations"));
/*  967 */       this.ianns.put(out);
/*      */     }
/*  969 */     if (this.tanns != null) {
/*  970 */       out.putShort(newUTF8("RuntimeVisibleTypeAnnotations"));
/*  971 */       this.tanns.put(out);
/*      */     }
/*  973 */     if (this.itanns != null) {
/*  974 */       out.putShort(newUTF8("RuntimeInvisibleTypeAnnotations"));
/*  975 */       this.itanns.put(out);
/*      */     }
/*  977 */     if (this.attrs != null) {
/*  978 */       this.attrs.put(this, null, 0, -1, -1, out);
/*      */     }
/*  980 */     if (this.invalidFrames) {
/*  981 */       this.anns = null;
/*  982 */       this.ianns = null;
/*  983 */       this.attrs = null;
/*  984 */       this.innerClassesCount = 0;
/*  985 */       this.innerClasses = null;
/*  986 */       this.bootstrapMethodsCount = 0;
/*  987 */       this.bootstrapMethods = null;
/*  988 */       this.firstField = null;
/*  989 */       this.lastField = null;
/*  990 */       this.firstMethod = null;
/*  991 */       this.lastMethod = null;
/*  992 */       this.computeMaxs = false;
/*  993 */       this.computeFrames = true;
/*  994 */       this.invalidFrames = false;
/*  995 */       new ClassReader(out.data).accept(this, 4);
/*  996 */       return toByteArray();
/*      */     }
/*  998 */     return out.data;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newConstItem(Object cst)
/*      */   {
/* 1017 */     if ((cst instanceof Integer)) {
/* 1018 */       int val = ((Integer)cst).intValue();
/* 1019 */       return newInteger(val); }
/* 1020 */     if ((cst instanceof Byte)) {
/* 1021 */       int val = ((Byte)cst).intValue();
/* 1022 */       return newInteger(val); }
/* 1023 */     if ((cst instanceof Character)) {
/* 1024 */       int val = ((Character)cst).charValue();
/* 1025 */       return newInteger(val); }
/* 1026 */     if ((cst instanceof Short)) {
/* 1027 */       int val = ((Short)cst).intValue();
/* 1028 */       return newInteger(val); }
/* 1029 */     if ((cst instanceof Boolean)) {
/* 1030 */       int val = ((Boolean)cst).booleanValue() ? 1 : 0;
/* 1031 */       return newInteger(val); }
/* 1032 */     if ((cst instanceof Float)) {
/* 1033 */       float val = ((Float)cst).floatValue();
/* 1034 */       return newFloat(val); }
/* 1035 */     if ((cst instanceof Long)) {
/* 1036 */       long val = ((Long)cst).longValue();
/* 1037 */       return newLong(val); }
/* 1038 */     if ((cst instanceof Double)) {
/* 1039 */       double val = ((Double)cst).doubleValue();
/* 1040 */       return newDouble(val); }
/* 1041 */     if ((cst instanceof String))
/* 1042 */       return newString((String)cst);
/* 1043 */     if ((cst instanceof Type)) {
/* 1044 */       Type t = (Type)cst;
/* 1045 */       int s = t.getSort();
/* 1046 */       if (s == 10)
/* 1047 */         return newClassItem(t.getInternalName());
/* 1048 */       if (s == 11) {
/* 1049 */         return newMethodTypeItem(t.getDescriptor());
/*      */       }
/* 1051 */       return newClassItem(t.getDescriptor());
/*      */     }
/* 1053 */     if ((cst instanceof Handle)) {
/* 1054 */       Handle h = (Handle)cst;
/* 1055 */       return newHandleItem(h.tag, h.owner, h.name, h.desc, h.itf);
/*      */     }
/* 1057 */     throw new IllegalArgumentException("value " + cst);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int newConst(Object cst)
/*      */   {
/* 1075 */     return newConstItem(cst).index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int newUTF8(String value)
/*      */   {
/* 1089 */     this.key.set(1, value, null, null);
/* 1090 */     Item result = get(this.key);
/* 1091 */     if (result == null) {
/* 1092 */       this.pool.putByte(1).putUTF8(value);
/* 1093 */       result = new Item(this.index++, this.key);
/* 1094 */       put(result);
/*      */     }
/* 1096 */     return result.index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newClassItem(String value)
/*      */   {
/* 1110 */     this.key2.set(7, value, null, null);
/* 1111 */     Item result = get(this.key2);
/* 1112 */     if (result == null) {
/* 1113 */       this.pool.put12(7, newUTF8(value));
/* 1114 */       result = new Item(this.index++, this.key2);
/* 1115 */       put(result);
/*      */     }
/* 1117 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int newClass(String value)
/*      */   {
/* 1131 */     return newClassItem(value).index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newMethodTypeItem(String methodDesc)
/*      */   {
/* 1145 */     this.key2.set(16, methodDesc, null, null);
/* 1146 */     Item result = get(this.key2);
/* 1147 */     if (result == null) {
/* 1148 */       this.pool.put12(16, newUTF8(methodDesc));
/* 1149 */       result = new Item(this.index++, this.key2);
/* 1150 */       put(result);
/*      */     }
/* 1152 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int newMethodType(String methodDesc)
/*      */   {
/* 1167 */     return newMethodTypeItem(methodDesc).index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newHandleItem(int tag, String owner, String name, String desc, boolean itf)
/*      */   {
/* 1196 */     this.key4.set(20 + tag, owner, name, desc);
/* 1197 */     Item result = get(this.key4);
/* 1198 */     if (result == null) {
/* 1199 */       if (tag <= 4) {
/* 1200 */         put112(15, tag, newField(owner, name, desc));
/*      */       } else {
/* 1202 */         put112(15, tag, 
/*      */         
/* 1204 */           newMethod(owner, name, desc, itf));
/*      */       }
/* 1206 */       result = new Item(this.index++, this.key4);
/* 1207 */       put(result);
/*      */     }
/* 1209 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public int newHandle(int tag, String owner, String name, String desc)
/*      */   {
/* 1241 */     return newHandle(tag, owner, name, desc, tag == 9);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int newHandle(int tag, String owner, String name, String desc, boolean itf)
/*      */   {
/* 1271 */     return newHandleItem(tag, owner, name, desc, itf).index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newInvokeDynamicItem(String name, String desc, Handle bsm, Object... bsmArgs)
/*      */   {
/* 1294 */     ByteVector bootstrapMethods = this.bootstrapMethods;
/* 1295 */     if (bootstrapMethods == null) {
/* 1296 */       bootstrapMethods = this.bootstrapMethods = new ByteVector();
/*      */     }
/*      */     
/* 1299 */     int position = bootstrapMethods.length;
/*      */     
/* 1301 */     int hashCode = bsm.hashCode();
/* 1302 */     bootstrapMethods.putShort(newHandle(bsm.tag, bsm.owner, bsm.name, bsm.desc, bsm
/* 1303 */       .isInterface()));
/*      */     
/* 1305 */     int argsLength = bsmArgs.length;
/* 1306 */     bootstrapMethods.putShort(argsLength);
/*      */     
/* 1308 */     for (int i = 0; i < argsLength; i++) {
/* 1309 */       Object bsmArg = bsmArgs[i];
/* 1310 */       hashCode ^= bsmArg.hashCode();
/* 1311 */       bootstrapMethods.putShort(newConst(bsmArg));
/*      */     }
/*      */     
/* 1314 */     byte[] data = bootstrapMethods.data;
/* 1315 */     int length = 2 + argsLength << 1;
/* 1316 */     hashCode &= 0x7FFFFFFF;
/* 1317 */     Item result = this.items[(hashCode % this.items.length)];
/* 1318 */     label250: while (result != null) {
/* 1319 */       if ((result.type != 33) || (result.hashCode != hashCode)) {
/* 1320 */         result = result.next;
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 1326 */         int resultPosition = result.intVal;
/* 1327 */         for (int p = 0;; p++) { if (p >= length) break label250;
/* 1328 */           if (data[(position + p)] != data[(resultPosition + p)]) {
/* 1329 */             result = result.next;
/* 1330 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     int bootstrapMethodIndex;
/* 1337 */     if (result != null) {
/* 1338 */       int bootstrapMethodIndex = result.index;
/* 1339 */       bootstrapMethods.length = position;
/*      */     } else {
/* 1341 */       bootstrapMethodIndex = this.bootstrapMethodsCount++;
/* 1342 */       result = new Item(bootstrapMethodIndex);
/* 1343 */       result.set(position, hashCode);
/* 1344 */       put(result);
/*      */     }
/*      */     
/*      */ 
/* 1348 */     this.key3.set(name, desc, bootstrapMethodIndex);
/* 1349 */     result = get(this.key3);
/* 1350 */     if (result == null) {
/* 1351 */       put122(18, bootstrapMethodIndex, newNameType(name, desc));
/* 1352 */       result = new Item(this.index++, this.key3);
/* 1353 */       put(result);
/*      */     }
/* 1355 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int newInvokeDynamic(String name, String desc, Handle bsm, Object... bsmArgs)
/*      */   {
/* 1378 */     return newInvokeDynamicItem(name, desc, bsm, bsmArgs).index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newFieldItem(String owner, String name, String desc)
/*      */   {
/* 1394 */     this.key3.set(9, owner, name, desc);
/* 1395 */     Item result = get(this.key3);
/* 1396 */     if (result == null) {
/* 1397 */       put122(9, newClass(owner), newNameType(name, desc));
/* 1398 */       result = new Item(this.index++, this.key3);
/* 1399 */       put(result);
/*      */     }
/* 1401 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int newField(String owner, String name, String desc)
/*      */   {
/* 1419 */     return newFieldItem(owner, name, desc).index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newMethodItem(String owner, String name, String desc, boolean itf)
/*      */   {
/* 1438 */     int type = itf ? 11 : 10;
/* 1439 */     this.key3.set(type, owner, name, desc);
/* 1440 */     Item result = get(this.key3);
/* 1441 */     if (result == null) {
/* 1442 */       put122(type, newClass(owner), newNameType(name, desc));
/* 1443 */       result = new Item(this.index++, this.key3);
/* 1444 */       put(result);
/*      */     }
/* 1446 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int newMethod(String owner, String name, String desc, boolean itf)
/*      */   {
/* 1467 */     return newMethodItem(owner, name, desc, itf).index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newInteger(int value)
/*      */   {
/* 1479 */     this.key.set(value);
/* 1480 */     Item result = get(this.key);
/* 1481 */     if (result == null) {
/* 1482 */       this.pool.putByte(3).putInt(value);
/* 1483 */       result = new Item(this.index++, this.key);
/* 1484 */       put(result);
/*      */     }
/* 1486 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newFloat(float value)
/*      */   {
/* 1498 */     this.key.set(value);
/* 1499 */     Item result = get(this.key);
/* 1500 */     if (result == null) {
/* 1501 */       this.pool.putByte(4).putInt(this.key.intVal);
/* 1502 */       result = new Item(this.index++, this.key);
/* 1503 */       put(result);
/*      */     }
/* 1505 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newLong(long value)
/*      */   {
/* 1517 */     this.key.set(value);
/* 1518 */     Item result = get(this.key);
/* 1519 */     if (result == null) {
/* 1520 */       this.pool.putByte(5).putLong(value);
/* 1521 */       result = new Item(this.index, this.key);
/* 1522 */       this.index += 2;
/* 1523 */       put(result);
/*      */     }
/* 1525 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newDouble(double value)
/*      */   {
/* 1537 */     this.key.set(value);
/* 1538 */     Item result = get(this.key);
/* 1539 */     if (result == null) {
/* 1540 */       this.pool.putByte(6).putLong(this.key.longVal);
/* 1541 */       result = new Item(this.index, this.key);
/* 1542 */       this.index += 2;
/* 1543 */       put(result);
/*      */     }
/* 1545 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Item newString(String value)
/*      */   {
/* 1557 */     this.key2.set(8, value, null, null);
/* 1558 */     Item result = get(this.key2);
/* 1559 */     if (result == null) {
/* 1560 */       this.pool.put12(8, newUTF8(value));
/* 1561 */       result = new Item(this.index++, this.key2);
/* 1562 */       put(result);
/*      */     }
/* 1564 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int newNameType(String name, String desc)
/*      */   {
/* 1580 */     return newNameTypeItem(name, desc).index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newNameTypeItem(String name, String desc)
/*      */   {
/* 1594 */     this.key2.set(12, name, desc, null);
/* 1595 */     Item result = get(this.key2);
/* 1596 */     if (result == null) {
/* 1597 */       put122(12, newUTF8(name), newUTF8(desc));
/* 1598 */       result = new Item(this.index++, this.key2);
/* 1599 */       put(result);
/*      */     }
/* 1601 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int addType(String type)
/*      */   {
/* 1613 */     this.key.set(30, type, null, null);
/* 1614 */     Item result = get(this.key);
/* 1615 */     if (result == null) {
/* 1616 */       result = addType(this.key);
/*      */     }
/* 1618 */     return result.index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int addUninitializedType(String type, int offset)
/*      */   {
/* 1634 */     this.key.type = 31;
/* 1635 */     this.key.intVal = offset;
/* 1636 */     this.key.strVal1 = type;
/* 1637 */     this.key.hashCode = (0x7FFFFFFF & 31 + type.hashCode() + offset);
/* 1638 */     Item result = get(this.key);
/* 1639 */     if (result == null) {
/* 1640 */       result = addType(this.key);
/*      */     }
/* 1642 */     return result.index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Item addType(Item item)
/*      */   {
/* 1654 */     this.typeCount = ((short)(this.typeCount + 1));
/* 1655 */     Item result = new Item(this.typeCount, this.key);
/* 1656 */     put(result);
/* 1657 */     if (this.typeTable == null) {
/* 1658 */       this.typeTable = new Item[16];
/*      */     }
/* 1660 */     if (this.typeCount == this.typeTable.length) {
/* 1661 */       Item[] newTable = new Item[2 * this.typeTable.length];
/* 1662 */       System.arraycopy(this.typeTable, 0, newTable, 0, this.typeTable.length);
/* 1663 */       this.typeTable = newTable;
/*      */     }
/* 1665 */     this.typeTable[this.typeCount] = result;
/* 1666 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int getMergedType(int type1, int type2)
/*      */   {
/* 1682 */     this.key2.type = 32;
/* 1683 */     this.key2.longVal = (type1 | type2 << 32);
/* 1684 */     this.key2.hashCode = (0x7FFFFFFF & 32 + type1 + type2);
/* 1685 */     Item result = get(this.key2);
/* 1686 */     if (result == null) {
/* 1687 */       String t = this.typeTable[type1].strVal1;
/* 1688 */       String u = this.typeTable[type2].strVal1;
/* 1689 */       this.key2.intVal = addType(getCommonSuperClass(t, u));
/* 1690 */       result = new Item(0, this.key2);
/* 1691 */       put(result);
/*      */     }
/* 1693 */     return result.intVal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getCommonSuperClass(String type1, String type2)
/*      */   {
/* 1715 */     ClassLoader classLoader = getClassLoader();
/*      */     try {
/* 1717 */       Class<?> c = Class.forName(type1.replace('/', '.'), false, classLoader);
/* 1718 */       d = Class.forName(type2.replace('/', '.'), false, classLoader);
/*      */     } catch (Exception e) { Class<?> d;
/* 1720 */       throw new RuntimeException(e.toString()); }
/*      */     Class<?> d;
/* 1722 */     Class<?> c; if (c.isAssignableFrom(d)) {
/* 1723 */       return type1;
/*      */     }
/* 1725 */     if (d.isAssignableFrom(c)) {
/* 1726 */       return type2;
/*      */     }
/* 1728 */     if ((c.isInterface()) || (d.isInterface())) {
/* 1729 */       return "java/lang/Object";
/*      */     }
/*      */     do {
/* 1732 */       c = c.getSuperclass();
/* 1733 */     } while (!c.isAssignableFrom(d));
/* 1734 */     return c.getName().replace('.', '/');
/*      */   }
/*      */   
/*      */ 
/*      */   protected ClassLoader getClassLoader()
/*      */   {
/* 1740 */     ClassLoader classLoader = null;
/*      */     try {
/* 1742 */       classLoader = Thread.currentThread().getContextClassLoader();
/*      */     }
/*      */     catch (Throwable localThrowable) {}
/*      */     
/* 1746 */     return classLoader != null ? classLoader : getClass().getClassLoader();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Item get(Item key)
/*      */   {
/* 1759 */     Item i = this.items[(key.hashCode % this.items.length)];
/* 1760 */     while ((i != null) && ((i.type != key.type) || (!key.isEqualTo(i)))) {
/* 1761 */       i = i.next;
/*      */     }
/* 1763 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void put(Item i)
/*      */   {
/* 1774 */     if (this.index + this.typeCount > this.threshold) {
/* 1775 */       int ll = this.items.length;
/* 1776 */       int nl = ll * 2 + 1;
/* 1777 */       Item[] newItems = new Item[nl];
/* 1778 */       for (int l = ll - 1; l >= 0; l--) {
/* 1779 */         Item j = this.items[l];
/* 1780 */         while (j != null) {
/* 1781 */           int index = j.hashCode % newItems.length;
/* 1782 */           Item k = j.next;
/* 1783 */           j.next = newItems[index];
/* 1784 */           newItems[index] = j;
/* 1785 */           j = k;
/*      */         }
/*      */       }
/* 1788 */       this.items = newItems;
/* 1789 */       this.threshold = ((int)(nl * 0.75D));
/*      */     }
/* 1791 */     int index = i.hashCode % this.items.length;
/* 1792 */     i.next = this.items[index];
/* 1793 */     this.items[index] = i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void put122(int b, int s1, int s2)
/*      */   {
/* 1807 */     this.pool.put12(b, s1).putShort(s2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void put112(int b1, int b2, int s)
/*      */   {
/* 1821 */     this.pool.put11(b1, b2).putShort(s);
/*      */   }
/*      */   
/*      */   public final void visitEnd() {}
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\asm\ClassWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */