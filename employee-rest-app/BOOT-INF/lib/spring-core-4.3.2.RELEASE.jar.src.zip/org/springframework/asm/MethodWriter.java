/*      */ package org.springframework.asm;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class MethodWriter
/*      */   extends MethodVisitor
/*      */ {
/*      */   static final int ACC_CONSTRUCTOR = 524288;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int SAME_FRAME = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int SAME_LOCALS_1_STACK_ITEM_FRAME = 64;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int RESERVED = 128;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int SAME_LOCALS_1_STACK_ITEM_FRAME_EXTENDED = 247;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int CHOP_FRAME = 248;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int SAME_FRAME_EXTENDED = 251;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int APPEND_FRAME = 252;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int FULL_FRAME = 255;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int FRAMES = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int MAXS = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int NOTHING = 2;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final ClassWriter cw;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int access;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int name;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int desc;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final String descriptor;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String signature;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int classReaderOffset;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int classReaderLength;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int exceptionCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int[] exceptions;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ByteVector annd;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AnnotationWriter anns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AnnotationWriter ianns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AnnotationWriter tanns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AnnotationWriter itanns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AnnotationWriter[] panns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AnnotationWriter[] ipanns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int synthetics;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Attribute attrs;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  231 */   private ByteVector code = new ByteVector();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int maxStack;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int maxLocals;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int currentLocals;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int frameCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ByteVector stackMap;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int previousFrameOffset;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int[] previousFrame;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int[] frame;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int handlerCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Handler firstHandler;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Handler lastHandler;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int methodParametersCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ByteVector methodParameters;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int localVarCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ByteVector localVar;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int localVarTypeCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ByteVector localVarType;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int lineNumberCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ByteVector lineNumber;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int lastCodeOffset;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AnnotationWriter ctanns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AnnotationWriter ictanns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Attribute cattrs;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean resize;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int subroutines;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int compute;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Label labels;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Label previousBlock;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Label currentBlock;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int stackSize;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int maxStackSize;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   MethodWriter(ClassWriter cw, int access, String name, String desc, String signature, String[] exceptions, boolean computeMaxs, boolean computeFrames)
/*      */   {
/*  456 */     super(327680);
/*  457 */     if (cw.firstMethod == null) {
/*  458 */       cw.firstMethod = this;
/*      */     } else {
/*  460 */       cw.lastMethod.mv = this;
/*      */     }
/*  462 */     cw.lastMethod = this;
/*  463 */     this.cw = cw;
/*  464 */     this.access = access;
/*  465 */     if ("<init>".equals(name)) {
/*  466 */       this.access |= 0x80000;
/*      */     }
/*  468 */     this.name = cw.newUTF8(name);
/*  469 */     this.desc = cw.newUTF8(desc);
/*  470 */     this.descriptor = desc;
/*      */     
/*  472 */     this.signature = signature;
/*      */     
/*  474 */     if ((exceptions != null) && (exceptions.length > 0)) {
/*  475 */       this.exceptionCount = exceptions.length;
/*  476 */       this.exceptions = new int[this.exceptionCount];
/*  477 */       for (int i = 0; i < this.exceptionCount; i++) {
/*  478 */         this.exceptions[i] = cw.newClass(exceptions[i]);
/*      */       }
/*      */     }
/*  481 */     this.compute = (computeMaxs ? 1 : computeFrames ? 0 : 2);
/*  482 */     if ((computeMaxs) || (computeFrames))
/*      */     {
/*  484 */       int size = Type.getArgumentsAndReturnSizes(this.descriptor) >> 2;
/*  485 */       if ((access & 0x8) != 0) {
/*  486 */         size--;
/*      */       }
/*  488 */       this.maxLocals = size;
/*  489 */       this.currentLocals = size;
/*      */       
/*  491 */       this.labels = new Label();
/*  492 */       this.labels.status |= 0x8;
/*  493 */       visitLabel(this.labels);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void visitParameter(String name, int access)
/*      */   {
/*  503 */     if (this.methodParameters == null) {
/*  504 */       this.methodParameters = new ByteVector();
/*      */     }
/*  506 */     this.methodParametersCount += 1;
/*  507 */     this.methodParameters.putShort(name == null ? 0 : this.cw.newUTF8(name))
/*  508 */       .putShort(access);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public AnnotationVisitor visitAnnotationDefault()
/*      */   {
/*  516 */     this.annd = new ByteVector();
/*  517 */     return new AnnotationWriter(this.cw, false, this.annd, null, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AnnotationVisitor visitAnnotation(String desc, boolean visible)
/*      */   {
/*  526 */     ByteVector bv = new ByteVector();
/*      */     
/*  528 */     bv.putShort(this.cw.newUTF8(desc)).putShort(0);
/*  529 */     AnnotationWriter aw = new AnnotationWriter(this.cw, true, bv, bv, 2);
/*  530 */     if (visible) {
/*  531 */       aw.next = this.anns;
/*  532 */       this.anns = aw;
/*      */     } else {
/*  534 */       aw.next = this.ianns;
/*  535 */       this.ianns = aw;
/*      */     }
/*  537 */     return aw;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AnnotationVisitor visitTypeAnnotation(int typeRef, TypePath typePath, String desc, boolean visible)
/*      */   {
/*  546 */     ByteVector bv = new ByteVector();
/*      */     
/*  548 */     AnnotationWriter.putTarget(typeRef, typePath, bv);
/*      */     
/*  550 */     bv.putShort(this.cw.newUTF8(desc)).putShort(0);
/*  551 */     AnnotationWriter aw = new AnnotationWriter(this.cw, true, bv, bv, bv.length - 2);
/*      */     
/*  553 */     if (visible) {
/*  554 */       aw.next = this.tanns;
/*  555 */       this.tanns = aw;
/*      */     } else {
/*  557 */       aw.next = this.itanns;
/*  558 */       this.itanns = aw;
/*      */     }
/*  560 */     return aw;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AnnotationVisitor visitParameterAnnotation(int parameter, String desc, boolean visible)
/*      */   {
/*  569 */     ByteVector bv = new ByteVector();
/*  570 */     if ("Ljava/lang/Synthetic;".equals(desc))
/*      */     {
/*      */ 
/*  573 */       this.synthetics = Math.max(this.synthetics, parameter + 1);
/*  574 */       return new AnnotationWriter(this.cw, false, bv, null, 0);
/*      */     }
/*      */     
/*  577 */     bv.putShort(this.cw.newUTF8(desc)).putShort(0);
/*  578 */     AnnotationWriter aw = new AnnotationWriter(this.cw, true, bv, bv, 2);
/*  579 */     if (visible) {
/*  580 */       if (this.panns == null) {
/*  581 */         this.panns = new AnnotationWriter[Type.getArgumentTypes(this.descriptor).length];
/*      */       }
/*  583 */       aw.next = this.panns[parameter];
/*  584 */       this.panns[parameter] = aw;
/*      */     } else {
/*  586 */       if (this.ipanns == null) {
/*  587 */         this.ipanns = new AnnotationWriter[Type.getArgumentTypes(this.descriptor).length];
/*      */       }
/*  589 */       aw.next = this.ipanns[parameter];
/*  590 */       this.ipanns[parameter] = aw;
/*      */     }
/*  592 */     return aw;
/*      */   }
/*      */   
/*      */   public void visitAttribute(Attribute attr)
/*      */   {
/*  597 */     if (attr.isCodeAttribute()) {
/*  598 */       attr.next = this.cattrs;
/*  599 */       this.cattrs = attr;
/*      */     } else {
/*  601 */       attr.next = this.attrs;
/*  602 */       this.attrs = attr;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void visitCode() {}
/*      */   
/*      */ 
/*      */   public void visitFrame(int type, int nLocal, Object[] local, int nStack, Object[] stack)
/*      */   {
/*  613 */     if (this.compute == 0) {
/*  614 */       return;
/*      */     }
/*      */     
/*  617 */     if (type == -1) {
/*  618 */       if (this.previousFrame == null) {
/*  619 */         visitImplicitFirstFrame();
/*      */       }
/*  621 */       this.currentLocals = nLocal;
/*  622 */       int frameIndex = startFrame(this.code.length, nLocal, nStack);
/*  623 */       for (int i = 0; i < nLocal; i++) {
/*  624 */         if ((local[i] instanceof String))
/*      */         {
/*  626 */           this.frame[(frameIndex++)] = (0x1700000 | this.cw.addType((String)local[i]));
/*  627 */         } else if ((local[i] instanceof Integer)) {
/*  628 */           this.frame[(frameIndex++)] = ((Integer)local[i]).intValue();
/*      */         }
/*      */         else {
/*  631 */           this.frame[(frameIndex++)] = (0x1800000 | this.cw.addUninitializedType("", ((Label)local[i]).position));
/*      */         }
/*      */       }
/*      */       
/*  635 */       for (int i = 0; i < nStack; i++) {
/*  636 */         if ((stack[i] instanceof String))
/*      */         {
/*  638 */           this.frame[(frameIndex++)] = (0x1700000 | this.cw.addType((String)stack[i]));
/*  639 */         } else if ((stack[i] instanceof Integer)) {
/*  640 */           this.frame[(frameIndex++)] = ((Integer)stack[i]).intValue();
/*      */         }
/*      */         else {
/*  643 */           this.frame[(frameIndex++)] = (0x1800000 | this.cw.addUninitializedType("", ((Label)stack[i]).position));
/*      */         }
/*      */       }
/*      */       
/*  647 */       endFrame();
/*      */     } else { int delta;
/*      */       int delta;
/*  650 */       if (this.stackMap == null) {
/*  651 */         this.stackMap = new ByteVector();
/*  652 */         delta = this.code.length;
/*      */       } else {
/*  654 */         delta = this.code.length - this.previousFrameOffset - 1;
/*  655 */         if (delta < 0) {
/*  656 */           if (type == 3) {
/*  657 */             return;
/*      */           }
/*  659 */           throw new IllegalStateException();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  664 */       switch (type) {
/*      */       case 0: 
/*  666 */         this.currentLocals = nLocal;
/*  667 */         this.stackMap.putByte(255).putShort(delta).putShort(nLocal);
/*  668 */         for (int i = 0; i < nLocal; i++) {
/*  669 */           writeFrameType(local[i]);
/*      */         }
/*  671 */         this.stackMap.putShort(nStack);
/*  672 */         for (int i = 0; i < nStack; i++) {
/*  673 */           writeFrameType(stack[i]);
/*      */         }
/*  675 */         break;
/*      */       case 1: 
/*  677 */         this.currentLocals += nLocal;
/*  678 */         this.stackMap.putByte(251 + nLocal).putShort(delta);
/*  679 */         for (int i = 0; i < nLocal; i++) {
/*  680 */           writeFrameType(local[i]);
/*      */         }
/*  682 */         break;
/*      */       case 2: 
/*  684 */         this.currentLocals -= nLocal;
/*  685 */         this.stackMap.putByte(251 - nLocal).putShort(delta);
/*  686 */         break;
/*      */       case 3: 
/*  688 */         if (delta < 64) {
/*  689 */           this.stackMap.putByte(delta);
/*      */         } else {
/*  691 */           this.stackMap.putByte(251).putShort(delta);
/*      */         }
/*  693 */         break;
/*      */       case 4: 
/*  695 */         if (delta < 64) {
/*  696 */           this.stackMap.putByte(64 + delta);
/*      */         }
/*      */         else {
/*  699 */           this.stackMap.putByte(247).putShort(delta);
/*      */         }
/*  701 */         writeFrameType(stack[0]);
/*      */       }
/*      */       
/*      */       
/*  705 */       this.previousFrameOffset = this.code.length;
/*  706 */       this.frameCount += 1;
/*      */     }
/*      */     
/*  709 */     this.maxStack = Math.max(this.maxStack, nStack);
/*  710 */     this.maxLocals = Math.max(this.maxLocals, this.currentLocals);
/*      */   }
/*      */   
/*      */   public void visitInsn(int opcode)
/*      */   {
/*  715 */     this.lastCodeOffset = this.code.length;
/*      */     
/*  717 */     this.code.putByte(opcode);
/*      */     
/*      */ 
/*  720 */     if (this.currentBlock != null) {
/*  721 */       if (this.compute == 0) {
/*  722 */         this.currentBlock.frame.execute(opcode, 0, null, null);
/*      */       }
/*      */       else {
/*  725 */         int size = this.stackSize + Frame.SIZE[opcode];
/*  726 */         if (size > this.maxStackSize) {
/*  727 */           this.maxStackSize = size;
/*      */         }
/*  729 */         this.stackSize = size;
/*      */       }
/*      */       
/*  732 */       if (((opcode >= 172) && (opcode <= 177)) || (opcode == 191))
/*      */       {
/*  734 */         noSuccessor();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void visitIntInsn(int opcode, int operand)
/*      */   {
/*  741 */     this.lastCodeOffset = this.code.length;
/*      */     
/*  743 */     if (this.currentBlock != null) {
/*  744 */       if (this.compute == 0) {
/*  745 */         this.currentBlock.frame.execute(opcode, operand, null, null);
/*  746 */       } else if (opcode != 188)
/*      */       {
/*      */ 
/*  749 */         int size = this.stackSize + 1;
/*  750 */         if (size > this.maxStackSize) {
/*  751 */           this.maxStackSize = size;
/*      */         }
/*  753 */         this.stackSize = size;
/*      */       }
/*      */     }
/*      */     
/*  757 */     if (opcode == 17) {
/*  758 */       this.code.put12(opcode, operand);
/*      */     } else {
/*  760 */       this.code.put11(opcode, operand);
/*      */     }
/*      */   }
/*      */   
/*      */   public void visitVarInsn(int opcode, int var)
/*      */   {
/*  766 */     this.lastCodeOffset = this.code.length;
/*      */     
/*  768 */     if (this.currentBlock != null) {
/*  769 */       if (this.compute == 0) {
/*  770 */         this.currentBlock.frame.execute(opcode, var, null, null);
/*      */ 
/*      */       }
/*  773 */       else if (opcode == 169)
/*      */       {
/*  775 */         this.currentBlock.status |= 0x100;
/*      */         
/*      */ 
/*  778 */         this.currentBlock.inputStackTop = this.stackSize;
/*  779 */         noSuccessor();
/*      */       } else {
/*  781 */         int size = this.stackSize + Frame.SIZE[opcode];
/*  782 */         if (size > this.maxStackSize) {
/*  783 */           this.maxStackSize = size;
/*      */         }
/*  785 */         this.stackSize = size;
/*      */       }
/*      */     }
/*      */     
/*  789 */     if (this.compute != 2) {
/*      */       int n;
/*      */       int n;
/*  792 */       if ((opcode == 22) || (opcode == 24) || (opcode == 55) || (opcode == 57))
/*      */       {
/*  794 */         n = var + 2;
/*      */       } else {
/*  796 */         n = var + 1;
/*      */       }
/*  798 */       if (n > this.maxLocals) {
/*  799 */         this.maxLocals = n;
/*      */       }
/*      */     }
/*      */     
/*  803 */     if ((var < 4) && (opcode != 169)) { int opt;
/*      */       int opt;
/*  805 */       if (opcode < 54)
/*      */       {
/*  807 */         opt = 26 + (opcode - 21 << 2) + var;
/*      */       }
/*      */       else {
/*  810 */         opt = 59 + (opcode - 54 << 2) + var;
/*      */       }
/*  812 */       this.code.putByte(opt);
/*  813 */     } else if (var >= 256) {
/*  814 */       this.code.putByte(196).put12(opcode, var);
/*      */     } else {
/*  816 */       this.code.put11(opcode, var);
/*      */     }
/*  818 */     if ((opcode >= 54) && (this.compute == 0) && (this.handlerCount > 0)) {
/*  819 */       visitLabel(new Label());
/*      */     }
/*      */   }
/*      */   
/*      */   public void visitTypeInsn(int opcode, String type)
/*      */   {
/*  825 */     this.lastCodeOffset = this.code.length;
/*  826 */     Item i = this.cw.newClassItem(type);
/*      */     
/*  828 */     if (this.currentBlock != null) {
/*  829 */       if (this.compute == 0) {
/*  830 */         this.currentBlock.frame.execute(opcode, this.code.length, this.cw, i);
/*  831 */       } else if (opcode == 187)
/*      */       {
/*      */ 
/*  834 */         int size = this.stackSize + 1;
/*  835 */         if (size > this.maxStackSize) {
/*  836 */           this.maxStackSize = size;
/*      */         }
/*  838 */         this.stackSize = size;
/*      */       }
/*      */     }
/*      */     
/*  842 */     this.code.put12(opcode, i.index);
/*      */   }
/*      */   
/*      */ 
/*      */   public void visitFieldInsn(int opcode, String owner, String name, String desc)
/*      */   {
/*  848 */     this.lastCodeOffset = this.code.length;
/*  849 */     Item i = this.cw.newFieldItem(owner, name, desc);
/*      */     
/*  851 */     if (this.currentBlock != null) {
/*  852 */       if (this.compute == 0) {
/*  853 */         this.currentBlock.frame.execute(opcode, 0, this.cw, i);
/*      */       }
/*      */       else
/*      */       {
/*  857 */         char c = desc.charAt(0);
/*  858 */         int size; int size; int size; int size; switch (opcode) {
/*      */         case 178: 
/*  860 */           size = this.stackSize + ((c == 'D') || (c == 'J') ? 2 : 1);
/*  861 */           break;
/*      */         case 179: 
/*  863 */           size = this.stackSize + ((c == 'D') || (c == 'J') ? -2 : -1);
/*  864 */           break;
/*      */         case 180: 
/*  866 */           size = this.stackSize + ((c == 'D') || (c == 'J') ? 1 : 0);
/*  867 */           break;
/*      */         
/*      */         default: 
/*  870 */           size = this.stackSize + ((c == 'D') || (c == 'J') ? -3 : -2);
/*      */         }
/*      */         
/*      */         
/*  874 */         if (size > this.maxStackSize) {
/*  875 */           this.maxStackSize = size;
/*      */         }
/*  877 */         this.stackSize = size;
/*      */       }
/*      */     }
/*      */     
/*  881 */     this.code.put12(opcode, i.index);
/*      */   }
/*      */   
/*      */ 
/*      */   public void visitMethodInsn(int opcode, String owner, String name, String desc, boolean itf)
/*      */   {
/*  887 */     this.lastCodeOffset = this.code.length;
/*  888 */     Item i = this.cw.newMethodItem(owner, name, desc, itf);
/*  889 */     int argSize = i.intVal;
/*      */     
/*  891 */     if (this.currentBlock != null) {
/*  892 */       if (this.compute == 0) {
/*  893 */         this.currentBlock.frame.execute(opcode, 0, this.cw, i);
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  903 */         if (argSize == 0)
/*      */         {
/*      */ 
/*  906 */           argSize = Type.getArgumentsAndReturnSizes(desc);
/*      */           
/*      */ 
/*  909 */           i.intVal = argSize; }
/*      */         int size;
/*      */         int size;
/*  912 */         if (opcode == 184) {
/*  913 */           size = this.stackSize - (argSize >> 2) + (argSize & 0x3) + 1;
/*      */         } else {
/*  915 */           size = this.stackSize - (argSize >> 2) + (argSize & 0x3);
/*      */         }
/*      */         
/*  918 */         if (size > this.maxStackSize) {
/*  919 */           this.maxStackSize = size;
/*      */         }
/*  921 */         this.stackSize = size;
/*      */       }
/*      */     }
/*      */     
/*  925 */     if (opcode == 185) {
/*  926 */       if (argSize == 0) {
/*  927 */         argSize = Type.getArgumentsAndReturnSizes(desc);
/*  928 */         i.intVal = argSize;
/*      */       }
/*  930 */       this.code.put12(185, i.index).put11(argSize >> 2, 0);
/*      */     } else {
/*  932 */       this.code.put12(opcode, i.index);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void visitInvokeDynamicInsn(String name, String desc, Handle bsm, Object... bsmArgs)
/*      */   {
/*  939 */     this.lastCodeOffset = this.code.length;
/*  940 */     Item i = this.cw.newInvokeDynamicItem(name, desc, bsm, bsmArgs);
/*  941 */     int argSize = i.intVal;
/*      */     
/*  943 */     if (this.currentBlock != null) {
/*  944 */       if (this.compute == 0) {
/*  945 */         this.currentBlock.frame.execute(186, 0, this.cw, i);
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  955 */         if (argSize == 0)
/*      */         {
/*      */ 
/*  958 */           argSize = Type.getArgumentsAndReturnSizes(desc);
/*      */           
/*      */ 
/*  961 */           i.intVal = argSize;
/*      */         }
/*  963 */         int size = this.stackSize - (argSize >> 2) + (argSize & 0x3) + 1;
/*      */         
/*      */ 
/*  966 */         if (size > this.maxStackSize) {
/*  967 */           this.maxStackSize = size;
/*      */         }
/*  969 */         this.stackSize = size;
/*      */       }
/*      */     }
/*      */     
/*  973 */     this.code.put12(186, i.index);
/*  974 */     this.code.putShort(0);
/*      */   }
/*      */   
/*      */   public void visitJumpInsn(int opcode, Label label)
/*      */   {
/*  979 */     this.lastCodeOffset = this.code.length;
/*  980 */     Label nextInsn = null;
/*      */     
/*  982 */     if (this.currentBlock != null) {
/*  983 */       if (this.compute == 0) {
/*  984 */         this.currentBlock.frame.execute(opcode, 0, null, null);
/*      */         
/*  986 */         label.getFirst().status |= 0x10;
/*      */         
/*  988 */         addSuccessor(0, label);
/*  989 */         if (opcode != 167)
/*      */         {
/*  991 */           nextInsn = new Label();
/*      */         }
/*      */       }
/*  994 */       else if (opcode == 168) {
/*  995 */         if ((label.status & 0x200) == 0) {
/*  996 */           label.status |= 0x200;
/*  997 */           this.subroutines += 1;
/*      */         }
/*  999 */         this.currentBlock.status |= 0x80;
/* 1000 */         addSuccessor(this.stackSize + 1, label);
/*      */         
/* 1002 */         nextInsn = new Label();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1013 */         this.stackSize += Frame.SIZE[opcode];
/* 1014 */         addSuccessor(this.stackSize, label);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1019 */     if (((label.status & 0x2) != 0) && (label.position - this.code.length < 32768))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1028 */       if (opcode == 167) {
/* 1029 */         this.code.putByte(200);
/* 1030 */       } else if (opcode == 168) {
/* 1031 */         this.code.putByte(201);
/*      */       }
/*      */       else
/*      */       {
/* 1035 */         if (nextInsn != null) {
/* 1036 */           nextInsn.status |= 0x10;
/*      */         }
/* 1038 */         this.code.putByte(opcode <= 166 ? (opcode + 1 ^ 0x1) - 1 : opcode ^ 0x1);
/*      */         
/* 1040 */         this.code.putShort(8);
/* 1041 */         this.code.putByte(200);
/*      */       }
/* 1043 */       label.put(this, this.code, this.code.length - 1, true);
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/* 1051 */       this.code.putByte(opcode);
/* 1052 */       label.put(this, this.code, this.code.length - 1, false);
/*      */     }
/* 1054 */     if (this.currentBlock != null) {
/* 1055 */       if (nextInsn != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1060 */         visitLabel(nextInsn);
/*      */       }
/* 1062 */       if (opcode == 167) {
/* 1063 */         noSuccessor();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void visitLabel(Label label)
/*      */   {
/* 1071 */     this.resize |= label.resolve(this, this.code.length, this.code.data);
/*      */     
/* 1073 */     if ((label.status & 0x1) != 0) {
/* 1074 */       return;
/*      */     }
/* 1076 */     if (this.compute == 0) {
/* 1077 */       if (this.currentBlock != null) {
/* 1078 */         if (label.position == this.currentBlock.position)
/*      */         {
/* 1080 */           this.currentBlock.status |= label.status & 0x10;
/* 1081 */           label.frame = this.currentBlock.frame;
/* 1082 */           return;
/*      */         }
/*      */         
/* 1085 */         addSuccessor(0, label);
/*      */       }
/*      */       
/* 1088 */       this.currentBlock = label;
/* 1089 */       if (label.frame == null) {
/* 1090 */         label.frame = new Frame();
/* 1091 */         label.frame.owner = label;
/*      */       }
/*      */       
/* 1094 */       if (this.previousBlock != null) {
/* 1095 */         if (label.position == this.previousBlock.position) {
/* 1096 */           this.previousBlock.status |= label.status & 0x10;
/* 1097 */           label.frame = this.previousBlock.frame;
/* 1098 */           this.currentBlock = this.previousBlock;
/* 1099 */           return;
/*      */         }
/* 1101 */         this.previousBlock.successor = label;
/*      */       }
/* 1103 */       this.previousBlock = label;
/* 1104 */     } else if (this.compute == 1) {
/* 1105 */       if (this.currentBlock != null)
/*      */       {
/* 1107 */         this.currentBlock.outputStackMax = this.maxStackSize;
/* 1108 */         addSuccessor(this.stackSize, label);
/*      */       }
/*      */       
/* 1111 */       this.currentBlock = label;
/*      */       
/* 1113 */       this.stackSize = 0;
/* 1114 */       this.maxStackSize = 0;
/*      */       
/* 1116 */       if (this.previousBlock != null) {
/* 1117 */         this.previousBlock.successor = label;
/*      */       }
/* 1119 */       this.previousBlock = label;
/*      */     }
/*      */   }
/*      */   
/*      */   public void visitLdcInsn(Object cst)
/*      */   {
/* 1125 */     this.lastCodeOffset = this.code.length;
/* 1126 */     Item i = this.cw.newConstItem(cst);
/*      */     
/* 1128 */     if (this.currentBlock != null) {
/* 1129 */       if (this.compute == 0) {
/* 1130 */         this.currentBlock.frame.execute(18, 0, this.cw, i);
/*      */       } else {
/*      */         int size;
/*      */         int size;
/* 1134 */         if ((i.type == 5) || (i.type == 6)) {
/* 1135 */           size = this.stackSize + 2;
/*      */         } else {
/* 1137 */           size = this.stackSize + 1;
/*      */         }
/*      */         
/* 1140 */         if (size > this.maxStackSize) {
/* 1141 */           this.maxStackSize = size;
/*      */         }
/* 1143 */         this.stackSize = size;
/*      */       }
/*      */     }
/*      */     
/* 1147 */     int index = i.index;
/* 1148 */     if ((i.type == 5) || (i.type == 6)) {
/* 1149 */       this.code.put12(20, index);
/* 1150 */     } else if (index >= 256) {
/* 1151 */       this.code.put12(19, index);
/*      */     } else {
/* 1153 */       this.code.put11(18, index);
/*      */     }
/*      */   }
/*      */   
/*      */   public void visitIincInsn(int var, int increment)
/*      */   {
/* 1159 */     this.lastCodeOffset = this.code.length;
/* 1160 */     if ((this.currentBlock != null) && 
/* 1161 */       (this.compute == 0)) {
/* 1162 */       this.currentBlock.frame.execute(132, var, null, null);
/*      */     }
/*      */     
/* 1165 */     if (this.compute != 2)
/*      */     {
/* 1167 */       int n = var + 1;
/* 1168 */       if (n > this.maxLocals) {
/* 1169 */         this.maxLocals = n;
/*      */       }
/*      */     }
/*      */     
/* 1173 */     if ((var > 255) || (increment > 127) || (increment < -128))
/*      */     {
/* 1175 */       this.code.putByte(196).put12(132, var).putShort(increment);
/*      */     } else {
/* 1177 */       this.code.putByte(132).put11(var, increment);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void visitTableSwitchInsn(int min, int max, Label dflt, Label... labels)
/*      */   {
/* 1184 */     this.lastCodeOffset = this.code.length;
/*      */     
/* 1186 */     int source = this.code.length;
/* 1187 */     this.code.putByte(170);
/* 1188 */     this.code.putByteArray(null, 0, (4 - this.code.length % 4) % 4);
/* 1189 */     dflt.put(this, this.code, source, true);
/* 1190 */     this.code.putInt(min).putInt(max);
/* 1191 */     for (int i = 0; i < labels.length; i++) {
/* 1192 */       labels[i].put(this, this.code, source, true);
/*      */     }
/*      */     
/* 1195 */     visitSwitchInsn(dflt, labels);
/*      */   }
/*      */   
/*      */ 
/*      */   public void visitLookupSwitchInsn(Label dflt, int[] keys, Label[] labels)
/*      */   {
/* 1201 */     this.lastCodeOffset = this.code.length;
/*      */     
/* 1203 */     int source = this.code.length;
/* 1204 */     this.code.putByte(171);
/* 1205 */     this.code.putByteArray(null, 0, (4 - this.code.length % 4) % 4);
/* 1206 */     dflt.put(this, this.code, source, true);
/* 1207 */     this.code.putInt(labels.length);
/* 1208 */     for (int i = 0; i < labels.length; i++) {
/* 1209 */       this.code.putInt(keys[i]);
/* 1210 */       labels[i].put(this, this.code, source, true);
/*      */     }
/*      */     
/* 1213 */     visitSwitchInsn(dflt, labels);
/*      */   }
/*      */   
/*      */   private void visitSwitchInsn(Label dflt, Label[] labels)
/*      */   {
/* 1218 */     if (this.currentBlock != null) {
/* 1219 */       if (this.compute == 0) {
/* 1220 */         this.currentBlock.frame.execute(171, 0, null, null);
/*      */         
/* 1222 */         addSuccessor(0, dflt);
/* 1223 */         dflt.getFirst().status |= 0x10;
/* 1224 */         for (int i = 0; i < labels.length; i++) {
/* 1225 */           addSuccessor(0, labels[i]);
/* 1226 */           labels[i].getFirst().status |= 0x10;
/*      */         }
/*      */       }
/*      */       else {
/* 1230 */         this.stackSize -= 1;
/*      */         
/* 1232 */         addSuccessor(this.stackSize, dflt);
/* 1233 */         for (int i = 0; i < labels.length; i++) {
/* 1234 */           addSuccessor(this.stackSize, labels[i]);
/*      */         }
/*      */       }
/*      */       
/* 1238 */       noSuccessor();
/*      */     }
/*      */   }
/*      */   
/*      */   public void visitMultiANewArrayInsn(String desc, int dims)
/*      */   {
/* 1244 */     this.lastCodeOffset = this.code.length;
/* 1245 */     Item i = this.cw.newClassItem(desc);
/*      */     
/* 1247 */     if (this.currentBlock != null) {
/* 1248 */       if (this.compute == 0) {
/* 1249 */         this.currentBlock.frame.execute(197, dims, this.cw, i);
/*      */       }
/*      */       else
/*      */       {
/* 1253 */         this.stackSize += 1 - dims;
/*      */       }
/*      */     }
/*      */     
/* 1257 */     this.code.put12(197, i.index).putByte(dims);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AnnotationVisitor visitInsnAnnotation(int typeRef, TypePath typePath, String desc, boolean visible)
/*      */   {
/* 1266 */     ByteVector bv = new ByteVector();
/*      */     
/* 1268 */     typeRef = typeRef & 0xFF0000FF | this.lastCodeOffset << 8;
/* 1269 */     AnnotationWriter.putTarget(typeRef, typePath, bv);
/*      */     
/* 1271 */     bv.putShort(this.cw.newUTF8(desc)).putShort(0);
/* 1272 */     AnnotationWriter aw = new AnnotationWriter(this.cw, true, bv, bv, bv.length - 2);
/*      */     
/* 1274 */     if (visible) {
/* 1275 */       aw.next = this.ctanns;
/* 1276 */       this.ctanns = aw;
/*      */     } else {
/* 1278 */       aw.next = this.ictanns;
/* 1279 */       this.ictanns = aw;
/*      */     }
/* 1281 */     return aw;
/*      */   }
/*      */   
/*      */ 
/*      */   public void visitTryCatchBlock(Label start, Label end, Label handler, String type)
/*      */   {
/* 1287 */     this.handlerCount += 1;
/* 1288 */     Handler h = new Handler();
/* 1289 */     h.start = start;
/* 1290 */     h.end = end;
/* 1291 */     h.handler = handler;
/* 1292 */     h.desc = type;
/* 1293 */     h.type = (type != null ? this.cw.newClass(type) : 0);
/* 1294 */     if (this.lastHandler == null) {
/* 1295 */       this.firstHandler = h;
/*      */     } else {
/* 1297 */       this.lastHandler.next = h;
/*      */     }
/* 1299 */     this.lastHandler = h;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AnnotationVisitor visitTryCatchAnnotation(int typeRef, TypePath typePath, String desc, boolean visible)
/*      */   {
/* 1308 */     ByteVector bv = new ByteVector();
/*      */     
/* 1310 */     AnnotationWriter.putTarget(typeRef, typePath, bv);
/*      */     
/* 1312 */     bv.putShort(this.cw.newUTF8(desc)).putShort(0);
/* 1313 */     AnnotationWriter aw = new AnnotationWriter(this.cw, true, bv, bv, bv.length - 2);
/*      */     
/* 1315 */     if (visible) {
/* 1316 */       aw.next = this.ctanns;
/* 1317 */       this.ctanns = aw;
/*      */     } else {
/* 1319 */       aw.next = this.ictanns;
/* 1320 */       this.ictanns = aw;
/*      */     }
/* 1322 */     return aw;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void visitLocalVariable(String name, String desc, String signature, Label start, Label end, int index)
/*      */   {
/* 1329 */     if (signature != null) {
/* 1330 */       if (this.localVarType == null) {
/* 1331 */         this.localVarType = new ByteVector();
/*      */       }
/* 1333 */       this.localVarTypeCount += 1;
/* 1334 */       this.localVarType.putShort(start.position)
/* 1335 */         .putShort(end.position - start.position)
/* 1336 */         .putShort(this.cw.newUTF8(name)).putShort(this.cw.newUTF8(signature))
/* 1337 */         .putShort(index);
/*      */     }
/* 1339 */     if (this.localVar == null) {
/* 1340 */       this.localVar = new ByteVector();
/*      */     }
/* 1342 */     this.localVarCount += 1;
/* 1343 */     this.localVar.putShort(start.position)
/* 1344 */       .putShort(end.position - start.position)
/* 1345 */       .putShort(this.cw.newUTF8(name)).putShort(this.cw.newUTF8(desc))
/* 1346 */       .putShort(index);
/* 1347 */     if (this.compute != 2)
/*      */     {
/* 1349 */       char c = desc.charAt(0);
/* 1350 */       int n = index + ((c == 'J') || (c == 'D') ? 2 : 1);
/* 1351 */       if (n > this.maxLocals) {
/* 1352 */         this.maxLocals = n;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AnnotationVisitor visitLocalVariableAnnotation(int typeRef, TypePath typePath, Label[] start, Label[] end, int[] index, String desc, boolean visible)
/*      */   {
/* 1364 */     ByteVector bv = new ByteVector();
/*      */     
/* 1366 */     bv.putByte(typeRef >>> 24).putShort(start.length);
/* 1367 */     for (int i = 0; i < start.length; i++)
/*      */     {
/*      */ 
/* 1370 */       bv.putShort(start[i].position).putShort(end[i].position - start[i].position).putShort(index[i]);
/*      */     }
/* 1372 */     if (typePath == null) {
/* 1373 */       bv.putByte(0);
/*      */     } else {
/* 1375 */       int length = typePath.b[typePath.offset] * 2 + 1;
/* 1376 */       bv.putByteArray(typePath.b, typePath.offset, length);
/*      */     }
/*      */     
/* 1379 */     bv.putShort(this.cw.newUTF8(desc)).putShort(0);
/* 1380 */     AnnotationWriter aw = new AnnotationWriter(this.cw, true, bv, bv, bv.length - 2);
/*      */     
/* 1382 */     if (visible) {
/* 1383 */       aw.next = this.ctanns;
/* 1384 */       this.ctanns = aw;
/*      */     } else {
/* 1386 */       aw.next = this.ictanns;
/* 1387 */       this.ictanns = aw;
/*      */     }
/* 1389 */     return aw;
/*      */   }
/*      */   
/*      */   public void visitLineNumber(int line, Label start)
/*      */   {
/* 1394 */     if (this.lineNumber == null) {
/* 1395 */       this.lineNumber = new ByteVector();
/*      */     }
/* 1397 */     this.lineNumberCount += 1;
/* 1398 */     this.lineNumber.putShort(start.position);
/* 1399 */     this.lineNumber.putShort(line);
/*      */   }
/*      */   
/*      */   public void visitMaxs(int maxStack, int maxLocals)
/*      */   {
/* 1404 */     if (this.resize)
/*      */     {
/*      */ 
/* 1407 */       resizeInstructions();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1412 */     if (this.compute == 0)
/*      */     {
/* 1414 */       Handler handler = this.firstHandler;
/* 1415 */       while (handler != null) {
/* 1416 */         Label l = handler.start.getFirst();
/* 1417 */         Label h = handler.handler.getFirst();
/* 1418 */         Label e = handler.end.getFirst();
/*      */         
/* 1420 */         String t = handler.desc == null ? "java/lang/Throwable" : handler.desc;
/*      */         
/* 1422 */         int kind = 0x1700000 | this.cw.addType(t);
/*      */         
/* 1424 */         h.status |= 0x10;
/*      */         
/* 1426 */         while (l != e)
/*      */         {
/* 1428 */           Edge b = new Edge();
/* 1429 */           b.info = kind;
/* 1430 */           b.successor = h;
/*      */           
/* 1432 */           b.next = l.successors;
/* 1433 */           l.successors = b;
/*      */           
/* 1435 */           l = l.successor;
/*      */         }
/* 1437 */         handler = handler.next;
/*      */       }
/*      */       
/*      */ 
/* 1441 */       Frame f = this.labels.frame;
/* 1442 */       Type[] args = Type.getArgumentTypes(this.descriptor);
/* 1443 */       f.initInputFrame(this.cw, this.access, args, this.maxLocals);
/* 1444 */       visitFrame(f);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1452 */       int max = 0;
/* 1453 */       Label changed = this.labels;
/* 1454 */       while (changed != null)
/*      */       {
/* 1456 */         Label l = changed;
/* 1457 */         changed = changed.next;
/* 1458 */         l.next = null;
/* 1459 */         f = l.frame;
/*      */         
/* 1461 */         if ((l.status & 0x10) != 0) {
/* 1462 */           l.status |= 0x20;
/*      */         }
/*      */         
/* 1465 */         l.status |= 0x40;
/*      */         
/* 1467 */         int blockMax = f.inputStack.length + l.outputStackMax;
/* 1468 */         if (blockMax > max) {
/* 1469 */           max = blockMax;
/*      */         }
/*      */         
/* 1472 */         Edge e = l.successors;
/* 1473 */         while (e != null) {
/* 1474 */           Label n = e.successor.getFirst();
/* 1475 */           boolean change = f.merge(this.cw, n.frame, e.info);
/* 1476 */           if ((change) && (n.next == null))
/*      */           {
/*      */ 
/* 1479 */             n.next = changed;
/* 1480 */             changed = n;
/*      */           }
/* 1482 */           e = e.next;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1487 */       Label l = this.labels;
/* 1488 */       while (l != null) {
/* 1489 */         f = l.frame;
/* 1490 */         if ((l.status & 0x20) != 0) {
/* 1491 */           visitFrame(f);
/*      */         }
/* 1493 */         if ((l.status & 0x40) == 0)
/*      */         {
/* 1495 */           Label k = l.successor;
/* 1496 */           int start = l.position;
/* 1497 */           int end = (k == null ? this.code.length : k.position) - 1;
/*      */           
/* 1499 */           if (end >= start) {
/* 1500 */             max = Math.max(max, 1);
/*      */             
/* 1502 */             for (int i = start; i < end; i++) {
/* 1503 */               this.code.data[i] = 0;
/*      */             }
/* 1505 */             this.code.data[end] = -65;
/*      */             
/* 1507 */             int frameIndex = startFrame(start, 0, 1);
/* 1508 */             this.frame[frameIndex] = 
/* 1509 */               (0x1700000 | this.cw.addType("java/lang/Throwable"));
/* 1510 */             endFrame();
/*      */             
/*      */ 
/* 1513 */             this.firstHandler = Handler.remove(this.firstHandler, l, k);
/*      */           }
/*      */         }
/* 1516 */         l = l.successor;
/*      */       }
/*      */       
/* 1519 */       handler = this.firstHandler;
/* 1520 */       this.handlerCount = 0;
/* 1521 */       while (handler != null) {
/* 1522 */         this.handlerCount += 1;
/* 1523 */         handler = handler.next;
/*      */       }
/*      */       
/* 1526 */       this.maxStack = max;
/* 1527 */     } else if (this.compute == 1)
/*      */     {
/* 1529 */       Handler handler = this.firstHandler;
/* 1530 */       while (handler != null) {
/* 1531 */         Label l = handler.start;
/* 1532 */         Label h = handler.handler;
/* 1533 */         Label e = handler.end;
/*      */         
/* 1535 */         while (l != e)
/*      */         {
/* 1537 */           Edge b = new Edge();
/* 1538 */           b.info = Integer.MAX_VALUE;
/* 1539 */           b.successor = h;
/*      */           
/* 1541 */           if ((l.status & 0x80) == 0) {
/* 1542 */             b.next = l.successors;
/* 1543 */             l.successors = b;
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/* 1548 */             b.next = l.successors.next.next;
/* 1549 */             l.successors.next.next = b;
/*      */           }
/*      */           
/* 1552 */           l = l.successor;
/*      */         }
/* 1554 */         handler = handler.next;
/*      */       }
/*      */       
/* 1557 */       if (this.subroutines > 0)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1564 */         int id = 0;
/* 1565 */         this.labels.visitSubroutine(null, 1L, this.subroutines);
/*      */         
/* 1567 */         Label l = this.labels;
/* 1568 */         while (l != null) {
/* 1569 */           if ((l.status & 0x80) != 0)
/*      */           {
/* 1571 */             Label subroutine = l.successors.next.successor;
/*      */             
/* 1573 */             if ((subroutine.status & 0x400) == 0)
/*      */             {
/* 1575 */               id++;
/* 1576 */               subroutine.visitSubroutine(null, id / 32L << 32 | 1L << id % 32, this.subroutines);
/*      */             }
/*      */           }
/*      */           
/* 1580 */           l = l.successor;
/*      */         }
/*      */         
/* 1583 */         l = this.labels;
/* 1584 */         while (l != null) {
/* 1585 */           if ((l.status & 0x80) != 0) {
/* 1586 */             Label L = this.labels;
/* 1587 */             while (L != null) {
/* 1588 */               L.status &= 0xF7FF;
/* 1589 */               L = L.successor;
/*      */             }
/*      */             
/* 1592 */             Label subroutine = l.successors.next.successor;
/* 1593 */             subroutine.visitSubroutine(l, 0L, this.subroutines);
/*      */           }
/* 1595 */           l = l.successor;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1609 */       int max = 0;
/* 1610 */       Label stack = this.labels;
/* 1611 */       while (stack != null)
/*      */       {
/* 1613 */         Label l = stack;
/* 1614 */         stack = stack.next;
/*      */         
/* 1616 */         int start = l.inputStackTop;
/* 1617 */         int blockMax = start + l.outputStackMax;
/*      */         
/* 1619 */         if (blockMax > max) {
/* 1620 */           max = blockMax;
/*      */         }
/*      */         
/* 1623 */         Edge b = l.successors;
/* 1624 */         if ((l.status & 0x80) != 0)
/*      */         {
/* 1626 */           b = b.next;
/*      */         }
/* 1628 */         while (b != null) {
/* 1629 */           l = b.successor;
/*      */           
/* 1631 */           if ((l.status & 0x8) == 0)
/*      */           {
/* 1633 */             l.inputStackTop = (b.info == Integer.MAX_VALUE ? 1 : start + b.info);
/*      */             
/*      */ 
/* 1636 */             l.status |= 0x8;
/* 1637 */             l.next = stack;
/* 1638 */             stack = l;
/*      */           }
/* 1640 */           b = b.next;
/*      */         }
/*      */       }
/* 1643 */       this.maxStack = Math.max(maxStack, max);
/*      */     } else {
/* 1645 */       this.maxStack = maxStack;
/* 1646 */       this.maxLocals = maxLocals;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void visitEnd() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addSuccessor(int info, Label successor)
/*      */   {
/* 1668 */     Edge b = new Edge();
/* 1669 */     b.info = info;
/* 1670 */     b.successor = successor;
/*      */     
/* 1672 */     b.next = this.currentBlock.successors;
/* 1673 */     this.currentBlock.successors = b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void noSuccessor()
/*      */   {
/* 1681 */     if (this.compute == 0) {
/* 1682 */       Label l = new Label();
/* 1683 */       l.frame = new Frame();
/* 1684 */       l.frame.owner = l;
/* 1685 */       l.resolve(this, this.code.length, this.code.data);
/* 1686 */       this.previousBlock.successor = l;
/* 1687 */       this.previousBlock = l;
/*      */     } else {
/* 1689 */       this.currentBlock.outputStackMax = this.maxStackSize;
/*      */     }
/* 1691 */     this.currentBlock = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void visitFrame(Frame f)
/*      */   {
/* 1706 */     int nTop = 0;
/* 1707 */     int nLocal = 0;
/* 1708 */     int nStack = 0;
/* 1709 */     int[] locals = f.inputLocals;
/* 1710 */     int[] stacks = f.inputStack;
/*      */     
/*      */ 
/* 1713 */     for (int i = 0; i < locals.length; i++) {
/* 1714 */       int t = locals[i];
/* 1715 */       if (t == 16777216) {
/* 1716 */         nTop++;
/*      */       } else {
/* 1718 */         nLocal += nTop + 1;
/* 1719 */         nTop = 0;
/*      */       }
/* 1721 */       if ((t == 16777220) || (t == 16777219)) {
/* 1722 */         i++;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1727 */     for (i = 0; i < stacks.length; i++) {
/* 1728 */       int t = stacks[i];
/* 1729 */       nStack++;
/* 1730 */       if ((t == 16777220) || (t == 16777219)) {
/* 1731 */         i++;
/*      */       }
/*      */     }
/*      */     
/* 1735 */     int frameIndex = startFrame(f.owner.position, nLocal, nStack);
/* 1736 */     for (i = 0; nLocal > 0; nLocal--) {
/* 1737 */       int t = locals[i];
/* 1738 */       this.frame[(frameIndex++)] = t;
/* 1739 */       if ((t == 16777220) || (t == 16777219)) {
/* 1740 */         i++;
/*      */       }
/* 1736 */       i++;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1743 */     for (i = 0; i < stacks.length; i++) {
/* 1744 */       int t = stacks[i];
/* 1745 */       this.frame[(frameIndex++)] = t;
/* 1746 */       if ((t == 16777220) || (t == 16777219)) {
/* 1747 */         i++;
/*      */       }
/*      */     }
/* 1750 */     endFrame();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void visitImplicitFirstFrame()
/*      */   {
/* 1758 */     int frameIndex = startFrame(0, this.descriptor.length() + 1, 0);
/* 1759 */     if ((this.access & 0x8) == 0) {
/* 1760 */       if ((this.access & 0x80000) == 0) {
/* 1761 */         this.frame[(frameIndex++)] = (0x1700000 | this.cw.addType(this.cw.thisName));
/*      */       } else {
/* 1763 */         this.frame[(frameIndex++)] = 6;
/*      */       }
/*      */     }
/* 1766 */     int i = 1;
/*      */     for (;;) {
/* 1768 */       int j = i;
/* 1769 */       switch (this.descriptor.charAt(i++)) {
/*      */       case 'B': 
/*      */       case 'C': 
/*      */       case 'I': 
/*      */       case 'S': 
/*      */       case 'Z': 
/* 1775 */         this.frame[(frameIndex++)] = 1;
/* 1776 */         break;
/*      */       case 'F': 
/* 1778 */         this.frame[(frameIndex++)] = 2;
/* 1779 */         break;
/*      */       case 'J': 
/* 1781 */         this.frame[(frameIndex++)] = 4;
/* 1782 */         break;
/*      */       case 'D': 
/* 1784 */         this.frame[(frameIndex++)] = 3;
/* 1785 */         break;
/*      */       case '[': 
/* 1787 */         while (this.descriptor.charAt(i) == '[') {
/* 1788 */           i++;
/*      */         }
/* 1790 */         if (this.descriptor.charAt(i) == 'L') {
/* 1791 */           i++;
/* 1792 */           while (this.descriptor.charAt(i) != ';') {
/* 1793 */             i++;
/*      */           }
/*      */         }
/*      */         
/* 1797 */         this.frame[(frameIndex++)] = (0x1700000 | this.cw.addType(this.descriptor.substring(j, ++i)));
/* 1798 */         break;
/*      */       case 'L': 
/* 1800 */         while (this.descriptor.charAt(i) != ';') {
/* 1801 */           i++;
/*      */         }
/*      */         
/* 1804 */         this.frame[(frameIndex++)] = (0x1700000 | this.cw.addType(this.descriptor.substring(j + 1, i++)));
/* 1805 */         break;
/*      */       case 'E': case 'G': case 'H': case 'K': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': default: 
/*      */         break label409; }
/*      */     }
/*      */     label409:
/* 1810 */     this.frame[1] = (frameIndex - 3);
/* 1811 */     endFrame();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int startFrame(int offset, int nLocal, int nStack)
/*      */   {
/* 1826 */     int n = 3 + nLocal + nStack;
/* 1827 */     if ((this.frame == null) || (this.frame.length < n)) {
/* 1828 */       this.frame = new int[n];
/*      */     }
/* 1830 */     this.frame[0] = offset;
/* 1831 */     this.frame[1] = nLocal;
/* 1832 */     this.frame[2] = nStack;
/* 1833 */     return 3;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void endFrame()
/*      */   {
/* 1841 */     if (this.previousFrame != null) {
/* 1842 */       if (this.stackMap == null) {
/* 1843 */         this.stackMap = new ByteVector();
/*      */       }
/* 1845 */       writeFrame();
/* 1846 */       this.frameCount += 1;
/*      */     }
/* 1848 */     this.previousFrame = this.frame;
/* 1849 */     this.frame = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeFrame()
/*      */   {
/* 1857 */     int clocalsSize = this.frame[1];
/* 1858 */     int cstackSize = this.frame[2];
/* 1859 */     if ((this.cw.version & 0xFFFF) < 50) {
/* 1860 */       this.stackMap.putShort(this.frame[0]).putShort(clocalsSize);
/* 1861 */       writeFrameTypes(3, 3 + clocalsSize);
/* 1862 */       this.stackMap.putShort(cstackSize);
/* 1863 */       writeFrameTypes(3 + clocalsSize, 3 + clocalsSize + cstackSize);
/* 1864 */       return;
/*      */     }
/* 1866 */     int localsSize = this.previousFrame[1];
/* 1867 */     int type = 255;
/* 1868 */     int k = 0;
/*      */     int delta;
/* 1870 */     int delta; if (this.frameCount == 0) {
/* 1871 */       delta = this.frame[0];
/*      */     } else {
/* 1873 */       delta = this.frame[0] - this.previousFrame[0] - 1;
/*      */     }
/* 1875 */     if (cstackSize == 0) {
/* 1876 */       k = clocalsSize - localsSize;
/* 1877 */       switch (k) {
/*      */       case -3: 
/*      */       case -2: 
/*      */       case -1: 
/* 1881 */         type = 248;
/* 1882 */         localsSize = clocalsSize;
/* 1883 */         break;
/*      */       case 0: 
/* 1885 */         type = delta < 64 ? 0 : 251;
/* 1886 */         break;
/*      */       case 1: 
/*      */       case 2: 
/*      */       case 3: 
/* 1890 */         type = 252;
/*      */       }
/*      */     }
/* 1893 */     else if ((clocalsSize == localsSize) && (cstackSize == 1)) {
/* 1894 */       type = delta < 63 ? 64 : 247;
/*      */     }
/*      */     
/* 1897 */     if (type != 255)
/*      */     {
/* 1899 */       int l = 3;
/* 1900 */       for (int j = 0; j < localsSize; j++) {
/* 1901 */         if (this.frame[l] != this.previousFrame[l]) {
/* 1902 */           type = 255;
/* 1903 */           break;
/*      */         }
/* 1905 */         l++;
/*      */       }
/*      */     }
/* 1908 */     switch (type) {
/*      */     case 0: 
/* 1910 */       this.stackMap.putByte(delta);
/* 1911 */       break;
/*      */     case 64: 
/* 1913 */       this.stackMap.putByte(64 + delta);
/* 1914 */       writeFrameTypes(3 + clocalsSize, 4 + clocalsSize);
/* 1915 */       break;
/*      */     case 247: 
/* 1917 */       this.stackMap.putByte(247).putShort(delta);
/*      */       
/* 1919 */       writeFrameTypes(3 + clocalsSize, 4 + clocalsSize);
/* 1920 */       break;
/*      */     case 251: 
/* 1922 */       this.stackMap.putByte(251).putShort(delta);
/* 1923 */       break;
/*      */     case 248: 
/* 1925 */       this.stackMap.putByte(251 + k).putShort(delta);
/* 1926 */       break;
/*      */     case 252: 
/* 1928 */       this.stackMap.putByte(251 + k).putShort(delta);
/* 1929 */       writeFrameTypes(3 + localsSize, 3 + clocalsSize);
/* 1930 */       break;
/*      */     
/*      */     default: 
/* 1933 */       this.stackMap.putByte(255).putShort(delta).putShort(clocalsSize);
/* 1934 */       writeFrameTypes(3, 3 + clocalsSize);
/* 1935 */       this.stackMap.putShort(cstackSize);
/* 1936 */       writeFrameTypes(3 + clocalsSize, 3 + clocalsSize + cstackSize);
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeFrameTypes(int start, int end)
/*      */   {
/* 1952 */     for (int i = start; i < end; i++) {
/* 1953 */       int t = this.frame[i];
/* 1954 */       int d = t & 0xF0000000;
/* 1955 */       if (d == 0) {
/* 1956 */         int v = t & 0xFFFFF;
/* 1957 */         switch (t & 0xFF00000) {
/*      */         case 24117248: 
/* 1959 */           this.stackMap.putByte(7).putShort(this.cw
/* 1960 */             .newClass(this.cw.typeTable[v].strVal1));
/* 1961 */           break;
/*      */         case 25165824: 
/* 1963 */           this.stackMap.putByte(8).putShort(this.cw.typeTable[v].intVal);
/* 1964 */           break;
/*      */         default: 
/* 1966 */           this.stackMap.putByte(v);
/*      */         }
/*      */       } else {
/* 1969 */         StringBuilder sb = new StringBuilder();
/* 1970 */         d >>= 28;
/* 1971 */         while (d-- > 0) {
/* 1972 */           sb.append('[');
/*      */         }
/* 1974 */         if ((t & 0xFF00000) == 24117248) {
/* 1975 */           sb.append('L');
/* 1976 */           sb.append(this.cw.typeTable[(t & 0xFFFFF)].strVal1);
/* 1977 */           sb.append(';');
/*      */         } else {
/* 1979 */           switch (t & 0xF) {
/*      */           case 1: 
/* 1981 */             sb.append('I');
/* 1982 */             break;
/*      */           case 2: 
/* 1984 */             sb.append('F');
/* 1985 */             break;
/*      */           case 3: 
/* 1987 */             sb.append('D');
/* 1988 */             break;
/*      */           case 9: 
/* 1990 */             sb.append('Z');
/* 1991 */             break;
/*      */           case 10: 
/* 1993 */             sb.append('B');
/* 1994 */             break;
/*      */           case 11: 
/* 1996 */             sb.append('C');
/* 1997 */             break;
/*      */           case 12: 
/* 1999 */             sb.append('S');
/* 2000 */             break;
/*      */           case 4: case 5: case 6: case 7: case 8: default: 
/* 2002 */             sb.append('J');
/*      */           }
/*      */         }
/* 2005 */         this.stackMap.putByte(7).putShort(this.cw.newClass(sb.toString()));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void writeFrameType(Object type) {
/* 2011 */     if ((type instanceof String)) {
/* 2012 */       this.stackMap.putByte(7).putShort(this.cw.newClass((String)type));
/* 2013 */     } else if ((type instanceof Integer)) {
/* 2014 */       this.stackMap.putByte(((Integer)type).intValue());
/*      */     } else {
/* 2016 */       this.stackMap.putByte(8).putShort(((Label)type).position);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final int getSize()
/*      */   {
/* 2030 */     if (this.classReaderOffset != 0) {
/* 2031 */       return 6 + this.classReaderLength;
/*      */     }
/* 2033 */     int size = 8;
/* 2034 */     if (this.code.length > 0) {
/* 2035 */       if (this.code.length > 65535) {
/* 2036 */         throw new RuntimeException("Method code too large!");
/*      */       }
/* 2038 */       this.cw.newUTF8("Code");
/* 2039 */       size += 18 + this.code.length + 8 * this.handlerCount;
/* 2040 */       if (this.localVar != null) {
/* 2041 */         this.cw.newUTF8("LocalVariableTable");
/* 2042 */         size += 8 + this.localVar.length;
/*      */       }
/* 2044 */       if (this.localVarType != null) {
/* 2045 */         this.cw.newUTF8("LocalVariableTypeTable");
/* 2046 */         size += 8 + this.localVarType.length;
/*      */       }
/* 2048 */       if (this.lineNumber != null) {
/* 2049 */         this.cw.newUTF8("LineNumberTable");
/* 2050 */         size += 8 + this.lineNumber.length;
/*      */       }
/* 2052 */       if (this.stackMap != null) {
/* 2053 */         boolean zip = (this.cw.version & 0xFFFF) >= 50;
/* 2054 */         this.cw.newUTF8(zip ? "StackMapTable" : "StackMap");
/* 2055 */         size += 8 + this.stackMap.length;
/*      */       }
/* 2057 */       if (this.ctanns != null) {
/* 2058 */         this.cw.newUTF8("RuntimeVisibleTypeAnnotations");
/* 2059 */         size += 8 + this.ctanns.getSize();
/*      */       }
/* 2061 */       if (this.ictanns != null) {
/* 2062 */         this.cw.newUTF8("RuntimeInvisibleTypeAnnotations");
/* 2063 */         size += 8 + this.ictanns.getSize();
/*      */       }
/* 2065 */       if (this.cattrs != null) {
/* 2066 */         size += this.cattrs.getSize(this.cw, this.code.data, this.code.length, this.maxStack, this.maxLocals);
/*      */       }
/*      */     }
/*      */     
/* 2070 */     if (this.exceptionCount > 0) {
/* 2071 */       this.cw.newUTF8("Exceptions");
/* 2072 */       size += 8 + 2 * this.exceptionCount;
/*      */     }
/* 2074 */     if (((this.access & 0x1000) != 0) && (
/* 2075 */       ((this.cw.version & 0xFFFF) < 49) || ((this.access & 0x40000) != 0)))
/*      */     {
/* 2077 */       this.cw.newUTF8("Synthetic");
/* 2078 */       size += 6;
/*      */     }
/*      */     
/* 2081 */     if ((this.access & 0x20000) != 0) {
/* 2082 */       this.cw.newUTF8("Deprecated");
/* 2083 */       size += 6;
/*      */     }
/* 2085 */     if (this.signature != null) {
/* 2086 */       this.cw.newUTF8("Signature");
/* 2087 */       this.cw.newUTF8(this.signature);
/* 2088 */       size += 8;
/*      */     }
/* 2090 */     if (this.methodParameters != null) {
/* 2091 */       this.cw.newUTF8("MethodParameters");
/* 2092 */       size += 7 + this.methodParameters.length;
/*      */     }
/* 2094 */     if (this.annd != null) {
/* 2095 */       this.cw.newUTF8("AnnotationDefault");
/* 2096 */       size += 6 + this.annd.length;
/*      */     }
/* 2098 */     if (this.anns != null) {
/* 2099 */       this.cw.newUTF8("RuntimeVisibleAnnotations");
/* 2100 */       size += 8 + this.anns.getSize();
/*      */     }
/* 2102 */     if (this.ianns != null) {
/* 2103 */       this.cw.newUTF8("RuntimeInvisibleAnnotations");
/* 2104 */       size += 8 + this.ianns.getSize();
/*      */     }
/* 2106 */     if (this.tanns != null) {
/* 2107 */       this.cw.newUTF8("RuntimeVisibleTypeAnnotations");
/* 2108 */       size += 8 + this.tanns.getSize();
/*      */     }
/* 2110 */     if (this.itanns != null) {
/* 2111 */       this.cw.newUTF8("RuntimeInvisibleTypeAnnotations");
/* 2112 */       size += 8 + this.itanns.getSize();
/*      */     }
/* 2114 */     if (this.panns != null) {
/* 2115 */       this.cw.newUTF8("RuntimeVisibleParameterAnnotations");
/* 2116 */       size += 7 + 2 * (this.panns.length - this.synthetics);
/* 2117 */       for (int i = this.panns.length - 1; i >= this.synthetics; i--) {
/* 2118 */         size += (this.panns[i] == null ? 0 : this.panns[i].getSize());
/*      */       }
/*      */     }
/* 2121 */     if (this.ipanns != null) {
/* 2122 */       this.cw.newUTF8("RuntimeInvisibleParameterAnnotations");
/* 2123 */       size += 7 + 2 * (this.ipanns.length - this.synthetics);
/* 2124 */       for (int i = this.ipanns.length - 1; i >= this.synthetics; i--) {
/* 2125 */         size += (this.ipanns[i] == null ? 0 : this.ipanns[i].getSize());
/*      */       }
/*      */     }
/* 2128 */     if (this.attrs != null) {
/* 2129 */       size += this.attrs.getSize(this.cw, null, 0, -1, -1);
/*      */     }
/* 2131 */     return size;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final void put(ByteVector out)
/*      */   {
/* 2142 */     int FACTOR = 64;
/* 2143 */     int mask = 0xE0000 | (this.access & 0x40000) / 64;
/*      */     
/*      */ 
/* 2146 */     out.putShort(this.access & (mask ^ 0xFFFFFFFF)).putShort(this.name).putShort(this.desc);
/* 2147 */     if (this.classReaderOffset != 0) {
/* 2148 */       out.putByteArray(this.cw.cr.b, this.classReaderOffset, this.classReaderLength);
/* 2149 */       return;
/*      */     }
/* 2151 */     int attributeCount = 0;
/* 2152 */     if (this.code.length > 0) {
/* 2153 */       attributeCount++;
/*      */     }
/* 2155 */     if (this.exceptionCount > 0) {
/* 2156 */       attributeCount++;
/*      */     }
/* 2158 */     if (((this.access & 0x1000) != 0) && (
/* 2159 */       ((this.cw.version & 0xFFFF) < 49) || ((this.access & 0x40000) != 0)))
/*      */     {
/* 2161 */       attributeCount++;
/*      */     }
/*      */     
/* 2164 */     if ((this.access & 0x20000) != 0) {
/* 2165 */       attributeCount++;
/*      */     }
/* 2167 */     if (this.signature != null) {
/* 2168 */       attributeCount++;
/*      */     }
/* 2170 */     if (this.methodParameters != null) {
/* 2171 */       attributeCount++;
/*      */     }
/* 2173 */     if (this.annd != null) {
/* 2174 */       attributeCount++;
/*      */     }
/* 2176 */     if (this.anns != null) {
/* 2177 */       attributeCount++;
/*      */     }
/* 2179 */     if (this.ianns != null) {
/* 2180 */       attributeCount++;
/*      */     }
/* 2182 */     if (this.tanns != null) {
/* 2183 */       attributeCount++;
/*      */     }
/* 2185 */     if (this.itanns != null) {
/* 2186 */       attributeCount++;
/*      */     }
/* 2188 */     if (this.panns != null) {
/* 2189 */       attributeCount++;
/*      */     }
/* 2191 */     if (this.ipanns != null) {
/* 2192 */       attributeCount++;
/*      */     }
/* 2194 */     if (this.attrs != null) {
/* 2195 */       attributeCount += this.attrs.getCount();
/*      */     }
/* 2197 */     out.putShort(attributeCount);
/* 2198 */     if (this.code.length > 0) {
/* 2199 */       int size = 12 + this.code.length + 8 * this.handlerCount;
/* 2200 */       if (this.localVar != null) {
/* 2201 */         size += 8 + this.localVar.length;
/*      */       }
/* 2203 */       if (this.localVarType != null) {
/* 2204 */         size += 8 + this.localVarType.length;
/*      */       }
/* 2206 */       if (this.lineNumber != null) {
/* 2207 */         size += 8 + this.lineNumber.length;
/*      */       }
/* 2209 */       if (this.stackMap != null) {
/* 2210 */         size += 8 + this.stackMap.length;
/*      */       }
/* 2212 */       if (this.ctanns != null) {
/* 2213 */         size += 8 + this.ctanns.getSize();
/*      */       }
/* 2215 */       if (this.ictanns != null) {
/* 2216 */         size += 8 + this.ictanns.getSize();
/*      */       }
/* 2218 */       if (this.cattrs != null) {
/* 2219 */         size += this.cattrs.getSize(this.cw, this.code.data, this.code.length, this.maxStack, this.maxLocals);
/*      */       }
/*      */       
/* 2222 */       out.putShort(this.cw.newUTF8("Code")).putInt(size);
/* 2223 */       out.putShort(this.maxStack).putShort(this.maxLocals);
/* 2224 */       out.putInt(this.code.length).putByteArray(this.code.data, 0, this.code.length);
/* 2225 */       out.putShort(this.handlerCount);
/* 2226 */       if (this.handlerCount > 0) {
/* 2227 */         Handler h = this.firstHandler;
/* 2228 */         while (h != null)
/*      */         {
/* 2230 */           out.putShort(h.start.position).putShort(h.end.position).putShort(h.handler.position).putShort(h.type);
/* 2231 */           h = h.next;
/*      */         }
/*      */       }
/* 2234 */       attributeCount = 0;
/* 2235 */       if (this.localVar != null) {
/* 2236 */         attributeCount++;
/*      */       }
/* 2238 */       if (this.localVarType != null) {
/* 2239 */         attributeCount++;
/*      */       }
/* 2241 */       if (this.lineNumber != null) {
/* 2242 */         attributeCount++;
/*      */       }
/* 2244 */       if (this.stackMap != null) {
/* 2245 */         attributeCount++;
/*      */       }
/* 2247 */       if (this.ctanns != null) {
/* 2248 */         attributeCount++;
/*      */       }
/* 2250 */       if (this.ictanns != null) {
/* 2251 */         attributeCount++;
/*      */       }
/* 2253 */       if (this.cattrs != null) {
/* 2254 */         attributeCount += this.cattrs.getCount();
/*      */       }
/* 2256 */       out.putShort(attributeCount);
/* 2257 */       if (this.localVar != null) {
/* 2258 */         out.putShort(this.cw.newUTF8("LocalVariableTable"));
/* 2259 */         out.putInt(this.localVar.length + 2).putShort(this.localVarCount);
/* 2260 */         out.putByteArray(this.localVar.data, 0, this.localVar.length);
/*      */       }
/* 2262 */       if (this.localVarType != null) {
/* 2263 */         out.putShort(this.cw.newUTF8("LocalVariableTypeTable"));
/* 2264 */         out.putInt(this.localVarType.length + 2).putShort(this.localVarTypeCount);
/* 2265 */         out.putByteArray(this.localVarType.data, 0, this.localVarType.length);
/*      */       }
/* 2267 */       if (this.lineNumber != null) {
/* 2268 */         out.putShort(this.cw.newUTF8("LineNumberTable"));
/* 2269 */         out.putInt(this.lineNumber.length + 2).putShort(this.lineNumberCount);
/* 2270 */         out.putByteArray(this.lineNumber.data, 0, this.lineNumber.length);
/*      */       }
/* 2272 */       if (this.stackMap != null) {
/* 2273 */         boolean zip = (this.cw.version & 0xFFFF) >= 50;
/* 2274 */         out.putShort(this.cw.newUTF8(zip ? "StackMapTable" : "StackMap"));
/* 2275 */         out.putInt(this.stackMap.length + 2).putShort(this.frameCount);
/* 2276 */         out.putByteArray(this.stackMap.data, 0, this.stackMap.length);
/*      */       }
/* 2278 */       if (this.ctanns != null) {
/* 2279 */         out.putShort(this.cw.newUTF8("RuntimeVisibleTypeAnnotations"));
/* 2280 */         this.ctanns.put(out);
/*      */       }
/* 2282 */       if (this.ictanns != null) {
/* 2283 */         out.putShort(this.cw.newUTF8("RuntimeInvisibleTypeAnnotations"));
/* 2284 */         this.ictanns.put(out);
/*      */       }
/* 2286 */       if (this.cattrs != null) {
/* 2287 */         this.cattrs.put(this.cw, this.code.data, this.code.length, this.maxLocals, this.maxStack, out);
/*      */       }
/*      */     }
/* 2290 */     if (this.exceptionCount > 0) {
/* 2291 */       out.putShort(this.cw.newUTF8("Exceptions")).putInt(2 * this.exceptionCount + 2);
/*      */       
/* 2293 */       out.putShort(this.exceptionCount);
/* 2294 */       for (int i = 0; i < this.exceptionCount; i++) {
/* 2295 */         out.putShort(this.exceptions[i]);
/*      */       }
/*      */     }
/* 2298 */     if (((this.access & 0x1000) != 0) && (
/* 2299 */       ((this.cw.version & 0xFFFF) < 49) || ((this.access & 0x40000) != 0)))
/*      */     {
/* 2301 */       out.putShort(this.cw.newUTF8("Synthetic")).putInt(0);
/*      */     }
/*      */     
/* 2304 */     if ((this.access & 0x20000) != 0) {
/* 2305 */       out.putShort(this.cw.newUTF8("Deprecated")).putInt(0);
/*      */     }
/* 2307 */     if (this.signature != null)
/*      */     {
/* 2309 */       out.putShort(this.cw.newUTF8("Signature")).putInt(2).putShort(this.cw.newUTF8(this.signature));
/*      */     }
/* 2311 */     if (this.methodParameters != null) {
/* 2312 */       out.putShort(this.cw.newUTF8("MethodParameters"));
/* 2313 */       out.putInt(this.methodParameters.length + 1).putByte(this.methodParametersCount);
/*      */       
/* 2315 */       out.putByteArray(this.methodParameters.data, 0, this.methodParameters.length);
/*      */     }
/* 2317 */     if (this.annd != null) {
/* 2318 */       out.putShort(this.cw.newUTF8("AnnotationDefault"));
/* 2319 */       out.putInt(this.annd.length);
/* 2320 */       out.putByteArray(this.annd.data, 0, this.annd.length);
/*      */     }
/* 2322 */     if (this.anns != null) {
/* 2323 */       out.putShort(this.cw.newUTF8("RuntimeVisibleAnnotations"));
/* 2324 */       this.anns.put(out);
/*      */     }
/* 2326 */     if (this.ianns != null) {
/* 2327 */       out.putShort(this.cw.newUTF8("RuntimeInvisibleAnnotations"));
/* 2328 */       this.ianns.put(out);
/*      */     }
/* 2330 */     if (this.tanns != null) {
/* 2331 */       out.putShort(this.cw.newUTF8("RuntimeVisibleTypeAnnotations"));
/* 2332 */       this.tanns.put(out);
/*      */     }
/* 2334 */     if (this.itanns != null) {
/* 2335 */       out.putShort(this.cw.newUTF8("RuntimeInvisibleTypeAnnotations"));
/* 2336 */       this.itanns.put(out);
/*      */     }
/* 2338 */     if (this.panns != null) {
/* 2339 */       out.putShort(this.cw.newUTF8("RuntimeVisibleParameterAnnotations"));
/* 2340 */       AnnotationWriter.put(this.panns, this.synthetics, out);
/*      */     }
/* 2342 */     if (this.ipanns != null) {
/* 2343 */       out.putShort(this.cw.newUTF8("RuntimeInvisibleParameterAnnotations"));
/* 2344 */       AnnotationWriter.put(this.ipanns, this.synthetics, out);
/*      */     }
/* 2346 */     if (this.attrs != null) {
/* 2347 */       this.attrs.put(this.cw, null, 0, -1, -1, out);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void resizeInstructions()
/*      */   {
/* 2373 */     byte[] b = this.code.data;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2401 */     int[] allIndexes = new int[0];
/* 2402 */     int[] allSizes = new int[0];
/*      */     
/*      */ 
/*      */ 
/* 2406 */     boolean[] resize = new boolean[this.code.length];
/*      */     
/*      */ 
/* 2409 */     int state = 3;
/*      */     do {
/* 2411 */       if (state == 3) {
/* 2412 */         state = 2;
/*      */       }
/* 2414 */       u = 0;
/* 2415 */       while (u < b.length) {
/* 2416 */         int opcode = b[u] & 0xFF;
/* 2417 */         int insert = 0;
/*      */         
/* 2419 */         switch (ClassWriter.TYPE[opcode]) {
/*      */         case 0: 
/*      */         case 4: 
/* 2422 */           u++;
/* 2423 */           break; case 9:  int label;
/*      */           int label;
/* 2425 */           if (opcode > 201)
/*      */           {
/*      */ 
/*      */ 
/* 2429 */             opcode = opcode < 218 ? opcode - 49 : opcode - 20;
/* 2430 */             label = u + readUnsignedShort(b, u + 1);
/*      */           } else {
/* 2432 */             label = u + readShort(b, u + 1);
/*      */           }
/* 2434 */           int newOffset = getNewOffset(allIndexes, allSizes, u, label);
/* 2435 */           if ((newOffset < 32768) || (newOffset > 32767))
/*      */           {
/* 2437 */             if (resize[u] == 0) {
/* 2438 */               if ((opcode == 167) || (opcode == 168))
/*      */               {
/*      */ 
/*      */ 
/* 2442 */                 insert = 2;
/*      */ 
/*      */ 
/*      */               }
/*      */               else
/*      */               {
/*      */ 
/*      */ 
/* 2450 */                 insert = 5;
/*      */               }
/* 2452 */               resize[u] = true;
/*      */             }
/*      */           }
/* 2455 */           u += 3;
/* 2456 */           break;
/*      */         case 10: 
/* 2458 */           u += 5;
/* 2459 */           break;
/*      */         case 14: 
/* 2461 */           if (state == 1)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2469 */             int newOffset = getNewOffset(allIndexes, allSizes, 0, u);
/* 2470 */             insert = -(newOffset & 0x3);
/* 2471 */           } else if (resize[u] == 0)
/*      */           {
/*      */ 
/*      */ 
/* 2475 */             insert = u & 0x3;
/* 2476 */             resize[u] = true;
/*      */           }
/*      */           
/* 2479 */           u = u + 4 - (u & 0x3);
/* 2480 */           u += 4 * (readInt(b, u + 8) - readInt(b, u + 4) + 1) + 12;
/* 2481 */           break;
/*      */         case 15: 
/* 2483 */           if (state == 1)
/*      */           {
/* 2485 */             int newOffset = getNewOffset(allIndexes, allSizes, 0, u);
/* 2486 */             insert = -(newOffset & 0x3);
/* 2487 */           } else if (resize[u] == 0)
/*      */           {
/* 2489 */             insert = u & 0x3;
/* 2490 */             resize[u] = true;
/*      */           }
/*      */           
/* 2493 */           u = u + 4 - (u & 0x3);
/* 2494 */           u += 8 * readInt(b, u + 4) + 8;
/* 2495 */           break;
/*      */         case 17: 
/* 2497 */           opcode = b[(u + 1)] & 0xFF;
/* 2498 */           if (opcode == 132) {
/* 2499 */             u += 6;
/*      */           } else {
/* 2501 */             u += 4;
/*      */           }
/* 2503 */           break;
/*      */         case 1: 
/*      */         case 3: 
/*      */         case 11: 
/* 2507 */           u += 2;
/* 2508 */           break;
/*      */         case 2: 
/*      */         case 5: 
/*      */         case 6: 
/*      */         case 12: 
/*      */         case 13: 
/* 2514 */           u += 3;
/* 2515 */           break;
/*      */         case 7: 
/*      */         case 8: 
/* 2518 */           u += 5;
/* 2519 */           break;
/*      */         case 16: 
/*      */         default: 
/* 2522 */           u += 4;
/*      */         }
/*      */         
/* 2525 */         if (insert != 0)
/*      */         {
/*      */ 
/* 2528 */           int[] newIndexes = new int[allIndexes.length + 1];
/* 2529 */           int[] newSizes = new int[allSizes.length + 1];
/* 2530 */           System.arraycopy(allIndexes, 0, newIndexes, 0, allIndexes.length);
/*      */           
/* 2532 */           System.arraycopy(allSizes, 0, newSizes, 0, allSizes.length);
/* 2533 */           newIndexes[allIndexes.length] = u;
/* 2534 */           newSizes[allSizes.length] = insert;
/* 2535 */           allIndexes = newIndexes;
/* 2536 */           allSizes = newSizes;
/* 2537 */           if (insert > 0) {
/* 2538 */             state = 3;
/*      */           }
/*      */         }
/*      */       }
/* 2542 */       if (state < 3) {
/* 2543 */         state--;
/*      */       }
/* 2545 */     } while (state != 0);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2551 */     ByteVector newCode = new ByteVector(this.code.length);
/*      */     
/* 2553 */     int u = 0;
/* 2554 */     while (u < this.code.length) {
/* 2555 */       int opcode = b[u] & 0xFF;
/* 2556 */       int v; int label; int newOffset; int j; switch (ClassWriter.TYPE[opcode]) {
/*      */       case 0: 
/*      */       case 4: 
/* 2559 */         newCode.putByte(opcode);
/* 2560 */         u++;
/* 2561 */         break; case 9:  int label;
/*      */         int label;
/* 2563 */         if (opcode > 201)
/*      */         {
/*      */ 
/*      */ 
/* 2567 */           opcode = opcode < 218 ? opcode - 49 : opcode - 20;
/* 2568 */           label = u + readUnsignedShort(b, u + 1);
/*      */         } else {
/* 2570 */           label = u + readShort(b, u + 1);
/*      */         }
/* 2572 */         int newOffset = getNewOffset(allIndexes, allSizes, u, label);
/* 2573 */         if (resize[u] != 0)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2579 */           if (opcode == 167) {
/* 2580 */             newCode.putByte(200);
/* 2581 */           } else if (opcode == 168) {
/* 2582 */             newCode.putByte(201);
/*      */           } else {
/* 2584 */             newCode.putByte(opcode <= 166 ? (opcode + 1 ^ 0x1) - 1 : opcode ^ 0x1);
/*      */             
/* 2586 */             newCode.putShort(8);
/* 2587 */             newCode.putByte(200);
/*      */             
/* 2589 */             newOffset -= 3;
/*      */           }
/* 2591 */           newCode.putInt(newOffset);
/*      */         } else {
/* 2593 */           newCode.putByte(opcode);
/* 2594 */           newCode.putShort(newOffset);
/*      */         }
/* 2596 */         u += 3;
/* 2597 */         break;
/*      */       case 10: 
/* 2599 */         int label = u + readInt(b, u + 1);
/* 2600 */         int newOffset = getNewOffset(allIndexes, allSizes, u, label);
/* 2601 */         newCode.putByte(opcode);
/* 2602 */         newCode.putInt(newOffset);
/* 2603 */         u += 5;
/* 2604 */         break;
/*      */       
/*      */       case 14: 
/* 2607 */         v = u;
/* 2608 */         u = u + 4 - (v & 0x3);
/*      */         
/* 2610 */         newCode.putByte(170);
/* 2611 */         newCode.putByteArray(null, 0, (4 - newCode.length % 4) % 4);
/* 2612 */         label = v + readInt(b, u);
/* 2613 */         u += 4;
/* 2614 */         newOffset = getNewOffset(allIndexes, allSizes, v, label);
/* 2615 */         newCode.putInt(newOffset);
/* 2616 */         j = readInt(b, u);
/* 2617 */         u += 4;
/* 2618 */         newCode.putInt(j);
/* 2619 */         j = readInt(b, u) - j + 1;
/* 2620 */         u += 4;
/* 2621 */         newCode.putInt(readInt(b, u - 4));
/* 2622 */       case 15: case 17: case 1: case 3: case 11: case 2: case 5: case 6: case 12: case 13: case 7: case 8: case 16: default:  while (j > 0) {
/* 2623 */           label = v + readInt(b, u);
/* 2624 */           u += 4;
/* 2625 */           newOffset = getNewOffset(allIndexes, allSizes, v, label);
/* 2626 */           newCode.putInt(newOffset);j--; continue;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 2631 */           int v = u;
/* 2632 */           u = u + 4 - (v & 0x3);
/*      */           
/* 2634 */           newCode.putByte(171);
/* 2635 */           newCode.putByteArray(null, 0, (4 - newCode.length % 4) % 4);
/* 2636 */           int label = v + readInt(b, u);
/* 2637 */           u += 4;
/* 2638 */           int newOffset = getNewOffset(allIndexes, allSizes, v, label);
/* 2639 */           newCode.putInt(newOffset);
/* 2640 */           int j = readInt(b, u);
/* 2641 */           u += 4;
/* 2642 */           newCode.putInt(j);
/* 2643 */           while (j > 0) {
/* 2644 */             newCode.putInt(readInt(b, u));
/* 2645 */             u += 4;
/* 2646 */             label = v + readInt(b, u);
/* 2647 */             u += 4;
/* 2648 */             newOffset = getNewOffset(allIndexes, allSizes, v, label);
/* 2649 */             newCode.putInt(newOffset);j--; continue;
/*      */             
/*      */ 
/*      */ 
/* 2653 */             opcode = b[(u + 1)] & 0xFF;
/* 2654 */             if (opcode == 132) {
/* 2655 */               newCode.putByteArray(b, u, 6);
/* 2656 */               u += 6;
/*      */             } else {
/* 2658 */               newCode.putByteArray(b, u, 4);
/* 2659 */               u += 4;
/*      */               
/* 2661 */               break;
/*      */               
/*      */ 
/*      */ 
/* 2665 */               newCode.putByteArray(b, u, 2);
/* 2666 */               u += 2;
/* 2667 */               break;
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2673 */               newCode.putByteArray(b, u, 3);
/* 2674 */               u += 3;
/* 2675 */               break;
/*      */               
/*      */ 
/* 2678 */               newCode.putByteArray(b, u, 5);
/* 2679 */               u += 5;
/* 2680 */               break;
/*      */               
/*      */ 
/* 2683 */               newCode.putByteArray(b, u, 4);
/* 2684 */               u += 4;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 2690 */     if (this.compute == 0) {
/* 2691 */       Label l = this.labels;
/* 2692 */       while (l != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2701 */         u = l.position - 3;
/* 2702 */         if ((u >= 0) && (resize[u] != 0)) {
/* 2703 */           l.status |= 0x10;
/*      */         }
/* 2705 */         getNewOffset(allIndexes, allSizes, l);
/* 2706 */         l = l.successor;
/*      */       }
/*      */       
/* 2709 */       if (this.cw.typeTable != null) {
/* 2710 */         for (int i = 0; i < this.cw.typeTable.length; i++) {
/* 2711 */           Item item = this.cw.typeTable[i];
/* 2712 */           if ((item != null) && (item.type == 31)) {
/* 2713 */             item.intVal = getNewOffset(allIndexes, allSizes, 0, item.intVal);
/*      */           }
/*      */           
/*      */         }
/*      */         
/*      */       }
/*      */     }
/* 2720 */     else if (this.frameCount > 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2734 */       this.cw.invalidFrames = true;
/*      */     }
/*      */     
/* 2737 */     Handler h = this.firstHandler;
/* 2738 */     while (h != null) {
/* 2739 */       getNewOffset(allIndexes, allSizes, h.start);
/* 2740 */       getNewOffset(allIndexes, allSizes, h.end);
/* 2741 */       getNewOffset(allIndexes, allSizes, h.handler);
/* 2742 */       h = h.next;
/*      */     }
/*      */     
/*      */ 
/* 2746 */     for (int i = 0; i < 2; i++) {
/* 2747 */       ByteVector bv = i == 0 ? this.localVar : this.localVarType;
/* 2748 */       if (bv != null) {
/* 2749 */         b = bv.data;
/* 2750 */         u = 0;
/* 2751 */         while (u < bv.length) {
/* 2752 */           int label = readUnsignedShort(b, u);
/* 2753 */           int newOffset = getNewOffset(allIndexes, allSizes, 0, label);
/* 2754 */           writeShort(b, u, newOffset);
/* 2755 */           label += readUnsignedShort(b, u + 2);
/* 2756 */           newOffset = getNewOffset(allIndexes, allSizes, 0, label) - newOffset;
/*      */           
/* 2758 */           writeShort(b, u + 2, newOffset);
/* 2759 */           u += 10;
/*      */         }
/*      */       }
/*      */     }
/* 2763 */     if (this.lineNumber != null) {
/* 2764 */       b = this.lineNumber.data;
/* 2765 */       u = 0;
/* 2766 */       while (u < this.lineNumber.length) {
/* 2767 */         writeShort(b, u, 
/*      */         
/*      */ 
/* 2770 */           getNewOffset(allIndexes, allSizes, 0, 
/* 2771 */           readUnsignedShort(b, u)));
/* 2772 */         u += 4;
/*      */       }
/*      */     }
/*      */     
/* 2776 */     Attribute attr = this.cattrs;
/* 2777 */     while (attr != null) {
/* 2778 */       Label[] labels = attr.getLabels();
/* 2779 */       if (labels != null) {
/* 2780 */         for (i = labels.length - 1; i >= 0; i--) {
/* 2781 */           getNewOffset(allIndexes, allSizes, labels[i]);
/*      */         }
/*      */       }
/* 2784 */       attr = attr.next;
/*      */     }
/*      */     
/*      */ 
/* 2788 */     this.code = newCode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static int readUnsignedShort(byte[] b, int index)
/*      */   {
/* 2801 */     return (b[index] & 0xFF) << 8 | b[(index + 1)] & 0xFF;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static short readShort(byte[] b, int index)
/*      */   {
/* 2814 */     return (short)((b[index] & 0xFF) << 8 | b[(index + 1)] & 0xFF);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static int readInt(byte[] b, int index)
/*      */   {
/* 2827 */     return (b[index] & 0xFF) << 24 | (b[(index + 1)] & 0xFF) << 16 | (b[(index + 2)] & 0xFF) << 8 | b[(index + 3)] & 0xFF;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void writeShort(byte[] b, int index, int s)
/*      */   {
/* 2842 */     b[index] = ((byte)(s >>> 8));
/* 2843 */     b[(index + 1)] = ((byte)s);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static int getNewOffset(int[] indexes, int[] sizes, int begin, int end)
/*      */   {
/* 2875 */     int offset = end - begin;
/* 2876 */     for (int i = 0; i < indexes.length; i++) {
/* 2877 */       if ((begin < indexes[i]) && (indexes[i] <= end))
/*      */       {
/* 2879 */         offset += sizes[i];
/* 2880 */       } else if ((end < indexes[i]) && (indexes[i] <= begin))
/*      */       {
/* 2882 */         offset -= sizes[i];
/*      */       }
/*      */     }
/* 2885 */     return offset;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void getNewOffset(int[] indexes, int[] sizes, Label label)
/*      */   {
/* 2910 */     if ((label.status & 0x4) == 0) {
/* 2911 */       label.position = getNewOffset(indexes, sizes, 0, label.position);
/* 2912 */       label.status |= 0x4;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\asm\MethodWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */