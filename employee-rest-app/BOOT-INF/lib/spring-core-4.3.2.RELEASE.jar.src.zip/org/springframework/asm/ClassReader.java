/*      */ package org.springframework.asm;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ClassReader
/*      */ {
/*      */   static final boolean SIGNATURES = true;
/*      */   static final boolean ANNOTATIONS = true;
/*      */   static final boolean FRAMES = true;
/*      */   static final boolean WRITER = true;
/*      */   static final boolean RESIZE = true;
/*      */   public static final int SKIP_CODE = 1;
/*      */   public static final int SKIP_DEBUG = 2;
/*      */   public static final int SKIP_FRAMES = 4;
/*      */   public static final int EXPAND_FRAMES = 8;
/*      */   public final byte[] b;
/*      */   private final int[] items;
/*      */   private final String[] strings;
/*      */   private final int maxStringLength;
/*      */   public final int header;
/*      */   
/*      */   public ClassReader(byte[] b)
/*      */   {
/*  153 */     this(b, 0, b.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClassReader(byte[] b, int off, int len)
/*      */   {
/*  167 */     this.b = b;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  175 */     this.items = new int[readUnsignedShort(off + 8)];
/*  176 */     int n = this.items.length;
/*  177 */     this.strings = new String[n];
/*  178 */     int max = 0;
/*  179 */     int index = off + 10;
/*  180 */     for (int i = 1; i < n; i++) {
/*  181 */       this.items[i] = (index + 1);
/*      */       int size;
/*  183 */       int size; int size; switch (b[index]) {
/*      */       case 3: 
/*      */       case 4: 
/*      */       case 9: 
/*      */       case 10: 
/*      */       case 11: 
/*      */       case 12: 
/*      */       case 18: 
/*  191 */         size = 5;
/*  192 */         break;
/*      */       case 5: 
/*      */       case 6: 
/*  195 */         int size = 9;
/*  196 */         i++;
/*  197 */         break;
/*      */       case 1: 
/*  199 */         int size = 3 + readUnsignedShort(index + 1);
/*  200 */         if (size > max) {
/*  201 */           max = size;
/*      */         }
/*      */         break;
/*      */       case 15: 
/*  205 */         size = 4;
/*  206 */         break;
/*      */       case 2: case 7: 
/*      */       case 8: case 13: 
/*      */       case 14: case 16: 
/*      */       case 17: default: 
/*  211 */         size = 3;
/*      */       }
/*      */       
/*  214 */       index += size;
/*      */     }
/*  216 */     this.maxStringLength = max;
/*      */     
/*  218 */     this.header = index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getAccess()
/*      */   {
/*  231 */     return readUnsignedShort(this.header);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getClassName()
/*      */   {
/*  243 */     return readClass(this.header + 2, new char[this.maxStringLength]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSuperName()
/*      */   {
/*  257 */     return readClass(this.header + 4, new char[this.maxStringLength]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getInterfaces()
/*      */   {
/*  270 */     int index = this.header + 6;
/*  271 */     int n = readUnsignedShort(index);
/*  272 */     String[] interfaces = new String[n];
/*  273 */     if (n > 0) {
/*  274 */       char[] buf = new char[this.maxStringLength];
/*  275 */       for (int i = 0; i < n; i++) {
/*  276 */         index += 2;
/*  277 */         interfaces[i] = readClass(index, buf);
/*      */       }
/*      */     }
/*  280 */     return interfaces;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void copyPool(ClassWriter classWriter)
/*      */   {
/*  291 */     char[] buf = new char[this.maxStringLength];
/*  292 */     int ll = this.items.length;
/*  293 */     Item[] items2 = new Item[ll];
/*  294 */     for (int i = 1; i < ll; i++) {
/*  295 */       int index = this.items[i];
/*  296 */       int tag = this.b[(index - 1)];
/*  297 */       Item item = new Item(i);
/*      */       
/*  299 */       switch (tag) {
/*      */       case 9: 
/*      */       case 10: 
/*      */       case 11: 
/*  303 */         int nameType = this.items[readUnsignedShort(index + 2)];
/*  304 */         item.set(tag, readClass(index, buf), readUTF8(nameType, buf), 
/*  305 */           readUTF8(nameType + 2, buf));
/*  306 */         break;
/*      */       case 3: 
/*  308 */         item.set(readInt(index));
/*  309 */         break;
/*      */       case 4: 
/*  311 */         item.set(Float.intBitsToFloat(readInt(index)));
/*  312 */         break;
/*      */       case 12: 
/*  314 */         item.set(tag, readUTF8(index, buf), readUTF8(index + 2, buf), null);
/*      */         
/*  316 */         break;
/*      */       case 5: 
/*  318 */         item.set(readLong(index));
/*  319 */         i++;
/*  320 */         break;
/*      */       case 6: 
/*  322 */         item.set(Double.longBitsToDouble(readLong(index)));
/*  323 */         i++;
/*  324 */         break;
/*      */       case 1: 
/*  326 */         String s = this.strings[i];
/*  327 */         if (s == null) {
/*  328 */           index = this.items[i];
/*  329 */           s = this.strings[i] = readUTF(index + 2, 
/*  330 */             readUnsignedShort(index), buf);
/*      */         }
/*  332 */         item.set(tag, s, null, null);
/*  333 */         break;
/*      */       
/*      */       case 15: 
/*  336 */         int fieldOrMethodRef = this.items[readUnsignedShort(index + 1)];
/*  337 */         int nameType = this.items[readUnsignedShort(fieldOrMethodRef + 2)];
/*  338 */         item.set(20 + readByte(index), 
/*  339 */           readClass(fieldOrMethodRef, buf), 
/*  340 */           readUTF8(nameType, buf), readUTF8(nameType + 2, buf));
/*  341 */         break;
/*      */       
/*      */       case 18: 
/*  344 */         if (classWriter.bootstrapMethods == null) {
/*  345 */           copyBootstrapMethods(classWriter, items2, buf);
/*      */         }
/*  347 */         int nameType = this.items[readUnsignedShort(index + 2)];
/*  348 */         item.set(readUTF8(nameType, buf), readUTF8(nameType + 2, buf), 
/*  349 */           readUnsignedShort(index));
/*  350 */         break;
/*      */       case 2: case 7: 
/*      */       case 8: case 13: 
/*      */       case 14: case 16: 
/*      */       case 17: default: 
/*  355 */         item.set(tag, readUTF8(index, buf), null, null);
/*      */       }
/*      */       
/*      */       
/*  359 */       int index2 = item.hashCode % items2.length;
/*  360 */       item.next = items2[index2];
/*  361 */       items2[index2] = item;
/*      */     }
/*      */     
/*  364 */     int off = this.items[1] - 1;
/*  365 */     classWriter.pool.putByteArray(this.b, off, this.header - off);
/*  366 */     classWriter.items = items2;
/*  367 */     classWriter.threshold = ((int)(0.75D * ll));
/*  368 */     classWriter.index = ll;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void copyBootstrapMethods(ClassWriter classWriter, Item[] items, char[] c)
/*      */   {
/*  381 */     int u = getAttributes();
/*  382 */     boolean found = false;
/*  383 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/*  384 */       String attrName = readUTF8(u + 2, c);
/*  385 */       if ("BootstrapMethods".equals(attrName)) {
/*  386 */         found = true;
/*  387 */         break;
/*      */       }
/*  389 */       u += 6 + readInt(u + 4);
/*      */     }
/*  391 */     if (!found) {
/*  392 */       return;
/*      */     }
/*      */     
/*  395 */     int boostrapMethodCount = readUnsignedShort(u + 8);
/*  396 */     int j = 0; for (int v = u + 10; j < boostrapMethodCount; j++) {
/*  397 */       int position = v - u - 10;
/*  398 */       int hashCode = readConst(readUnsignedShort(v), c).hashCode();
/*  399 */       for (int k = readUnsignedShort(v + 2); k > 0; k--) {
/*  400 */         hashCode ^= readConst(readUnsignedShort(v + 4), c).hashCode();
/*  401 */         v += 2;
/*      */       }
/*  403 */       v += 4;
/*  404 */       Item item = new Item(j);
/*  405 */       item.set(position, hashCode & 0x7FFFFFFF);
/*  406 */       int index = item.hashCode % items.length;
/*  407 */       item.next = items[index];
/*  408 */       items[index] = item;
/*      */     }
/*  410 */     int attrSize = readInt(u + 4);
/*  411 */     ByteVector bootstrapMethods = new ByteVector(attrSize + 62);
/*  412 */     bootstrapMethods.putByteArray(this.b, u + 10, attrSize - 2);
/*  413 */     classWriter.bootstrapMethodsCount = boostrapMethodCount;
/*  414 */     classWriter.bootstrapMethods = bootstrapMethods;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClassReader(InputStream is)
/*      */     throws IOException
/*      */   {
/*  426 */     this(readClass(is, false));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClassReader(String name)
/*      */     throws IOException
/*      */   {
/*  438 */     this(readClass(
/*  439 */       ClassLoader.getSystemResourceAsStream(name.replace('.', '/') + ".class"), true));
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   private static byte[] readClass(InputStream is, boolean close)
/*      */     throws IOException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: ifnonnull +13 -> 14
/*      */     //   4: new 57	java/io/IOException
/*      */     //   7: dup
/*      */     //   8: ldc 58
/*      */     //   10: invokespecial 59	java/io/IOException:<init>	(Ljava/lang/String;)V
/*      */     //   13: athrow
/*      */     //   14: aload_0
/*      */     //   15: invokevirtual 60	java/io/InputStream:available	()I
/*      */     //   18: newarray <illegal type>
/*      */     //   20: astore_2
/*      */     //   21: iconst_0
/*      */     //   22: istore_3
/*      */     //   23: aload_0
/*      */     //   24: aload_2
/*      */     //   25: iload_3
/*      */     //   26: aload_2
/*      */     //   27: arraylength
/*      */     //   28: iload_3
/*      */     //   29: isub
/*      */     //   30: invokevirtual 61	java/io/InputStream:read	([BII)I
/*      */     //   33: istore 4
/*      */     //   35: iload 4
/*      */     //   37: iconst_m1
/*      */     //   38: if_icmpne +40 -> 78
/*      */     //   41: iload_3
/*      */     //   42: aload_2
/*      */     //   43: arraylength
/*      */     //   44: if_icmpge +20 -> 64
/*      */     //   47: iload_3
/*      */     //   48: newarray <illegal type>
/*      */     //   50: astore 5
/*      */     //   52: aload_2
/*      */     //   53: iconst_0
/*      */     //   54: aload 5
/*      */     //   56: iconst_0
/*      */     //   57: iload_3
/*      */     //   58: invokestatic 62	java/lang/System:arraycopy	(Ljava/lang/Object;ILjava/lang/Object;II)V
/*      */     //   61: aload 5
/*      */     //   63: astore_2
/*      */     //   64: aload_2
/*      */     //   65: astore 5
/*      */     //   67: iload_1
/*      */     //   68: ifeq +7 -> 75
/*      */     //   71: aload_0
/*      */     //   72: invokevirtual 63	java/io/InputStream:close	()V
/*      */     //   75: aload 5
/*      */     //   77: areturn
/*      */     //   78: iload_3
/*      */     //   79: iload 4
/*      */     //   81: iadd
/*      */     //   82: istore_3
/*      */     //   83: iload_3
/*      */     //   84: aload_2
/*      */     //   85: arraylength
/*      */     //   86: if_icmpne +60 -> 146
/*      */     //   89: aload_0
/*      */     //   90: invokevirtual 64	java/io/InputStream:read	()I
/*      */     //   93: istore 5
/*      */     //   95: iload 5
/*      */     //   97: ifge +17 -> 114
/*      */     //   100: aload_2
/*      */     //   101: astore 6
/*      */     //   103: iload_1
/*      */     //   104: ifeq +7 -> 111
/*      */     //   107: aload_0
/*      */     //   108: invokevirtual 63	java/io/InputStream:close	()V
/*      */     //   111: aload 6
/*      */     //   113: areturn
/*      */     //   114: aload_2
/*      */     //   115: arraylength
/*      */     //   116: sipush 1000
/*      */     //   119: iadd
/*      */     //   120: newarray <illegal type>
/*      */     //   122: astore 6
/*      */     //   124: aload_2
/*      */     //   125: iconst_0
/*      */     //   126: aload 6
/*      */     //   128: iconst_0
/*      */     //   129: iload_3
/*      */     //   130: invokestatic 62	java/lang/System:arraycopy	(Ljava/lang/Object;ILjava/lang/Object;II)V
/*      */     //   133: aload 6
/*      */     //   135: iload_3
/*      */     //   136: iinc 3 1
/*      */     //   139: iload 5
/*      */     //   141: i2b
/*      */     //   142: bastore
/*      */     //   143: aload 6
/*      */     //   145: astore_2
/*      */     //   146: goto -123 -> 23
/*      */     //   149: astore 7
/*      */     //   151: iload_1
/*      */     //   152: ifeq +7 -> 159
/*      */     //   155: aload_0
/*      */     //   156: invokevirtual 63	java/io/InputStream:close	()V
/*      */     //   159: aload 7
/*      */     //   161: athrow
/*      */     // Line number table:
/*      */     //   Java source line #456	-> byte code offset #0
/*      */     //   Java source line #457	-> byte code offset #4
/*      */     //   Java source line #460	-> byte code offset #14
/*      */     //   Java source line #461	-> byte code offset #21
/*      */     //   Java source line #463	-> byte code offset #23
/*      */     //   Java source line #464	-> byte code offset #35
/*      */     //   Java source line #465	-> byte code offset #41
/*      */     //   Java source line #466	-> byte code offset #47
/*      */     //   Java source line #467	-> byte code offset #52
/*      */     //   Java source line #468	-> byte code offset #61
/*      */     //   Java source line #470	-> byte code offset #64
/*      */     //   Java source line #485	-> byte code offset #67
/*      */     //   Java source line #486	-> byte code offset #71
/*      */     //   Java source line #472	-> byte code offset #78
/*      */     //   Java source line #473	-> byte code offset #83
/*      */     //   Java source line #474	-> byte code offset #89
/*      */     //   Java source line #475	-> byte code offset #95
/*      */     //   Java source line #476	-> byte code offset #100
/*      */     //   Java source line #485	-> byte code offset #103
/*      */     //   Java source line #486	-> byte code offset #107
/*      */     //   Java source line #478	-> byte code offset #114
/*      */     //   Java source line #479	-> byte code offset #124
/*      */     //   Java source line #480	-> byte code offset #133
/*      */     //   Java source line #481	-> byte code offset #143
/*      */     //   Java source line #483	-> byte code offset #146
/*      */     //   Java source line #485	-> byte code offset #149
/*      */     //   Java source line #486	-> byte code offset #155
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	162	0	is	InputStream
/*      */     //   0	162	1	close	boolean
/*      */     //   20	126	2	b	byte[]
/*      */     //   22	114	3	len	int
/*      */     //   33	47	4	n	int
/*      */     //   50	26	5	c	byte[]
/*      */     //   93	47	5	last	int
/*      */     //   101	11	6	arrayOfByte1	byte[]
/*      */     //   122	22	6	c	byte[]
/*      */     //   149	11	7	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   14	67	149	finally
/*      */     //   78	103	149	finally
/*      */     //   114	151	149	finally
/*      */   }
/*      */   
/*      */   public void accept(ClassVisitor classVisitor, int flags)
/*      */   {
/*  508 */     accept(classVisitor, new Attribute[0], flags);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void accept(ClassVisitor classVisitor, Attribute[] attrs, int flags)
/*      */   {
/*  534 */     int u = this.header;
/*  535 */     char[] c = new char[this.maxStringLength];
/*      */     
/*  537 */     Context context = new Context();
/*  538 */     context.attrs = attrs;
/*  539 */     context.flags = flags;
/*  540 */     context.buffer = c;
/*      */     
/*      */ 
/*  543 */     int access = readUnsignedShort(u);
/*  544 */     String name = readClass(u + 2, c);
/*  545 */     String superClass = readClass(u + 4, c);
/*  546 */     String[] interfaces = new String[readUnsignedShort(u + 6)];
/*  547 */     u += 8;
/*  548 */     for (int i = 0; i < interfaces.length; i++) {
/*  549 */       interfaces[i] = readClass(u, c);
/*  550 */       u += 2;
/*      */     }
/*      */     
/*      */ 
/*  554 */     String signature = null;
/*  555 */     String sourceFile = null;
/*  556 */     String sourceDebug = null;
/*  557 */     String enclosingOwner = null;
/*  558 */     String enclosingName = null;
/*  559 */     String enclosingDesc = null;
/*  560 */     int anns = 0;
/*  561 */     int ianns = 0;
/*  562 */     int tanns = 0;
/*  563 */     int itanns = 0;
/*  564 */     int innerClasses = 0;
/*  565 */     Attribute attributes = null;
/*      */     
/*  567 */     u = getAttributes();
/*  568 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/*  569 */       String attrName = readUTF8(u + 2, c);
/*      */       
/*      */ 
/*  572 */       if ("SourceFile".equals(attrName)) {
/*  573 */         sourceFile = readUTF8(u + 8, c);
/*  574 */       } else if ("InnerClasses".equals(attrName)) {
/*  575 */         innerClasses = u + 8;
/*  576 */       } else if ("EnclosingMethod".equals(attrName)) {
/*  577 */         enclosingOwner = readClass(u + 8, c);
/*  578 */         int item = readUnsignedShort(u + 10);
/*  579 */         if (item != 0) {
/*  580 */           enclosingName = readUTF8(this.items[item], c);
/*  581 */           enclosingDesc = readUTF8(this.items[item] + 2, c);
/*      */         }
/*  583 */       } else if ("Signature".equals(attrName)) {
/*  584 */         signature = readUTF8(u + 8, c);
/*      */       }
/*  586 */       else if ("RuntimeVisibleAnnotations".equals(attrName)) {
/*  587 */         anns = u + 8;
/*      */       }
/*  589 */       else if ("RuntimeVisibleTypeAnnotations".equals(attrName)) {
/*  590 */         tanns = u + 8;
/*  591 */       } else if ("Deprecated".equals(attrName)) {
/*  592 */         access |= 0x20000;
/*  593 */       } else if ("Synthetic".equals(attrName)) {
/*  594 */         access |= 0x41000;
/*      */       }
/*  596 */       else if ("SourceDebugExtension".equals(attrName)) {
/*  597 */         int len = readInt(u + 4);
/*  598 */         sourceDebug = readUTF(u + 8, len, new char[len]);
/*      */       }
/*  600 */       else if ("RuntimeInvisibleAnnotations".equals(attrName)) {
/*  601 */         ianns = u + 8;
/*      */       }
/*  603 */       else if ("RuntimeInvisibleTypeAnnotations".equals(attrName)) {
/*  604 */         itanns = u + 8;
/*  605 */       } else if ("BootstrapMethods".equals(attrName)) {
/*  606 */         int[] bootstrapMethods = new int[readUnsignedShort(u + 8)];
/*  607 */         int j = 0; for (int v = u + 10; j < bootstrapMethods.length; j++) {
/*  608 */           bootstrapMethods[j] = v;
/*  609 */           v += (2 + readUnsignedShort(v + 2) << 1);
/*      */         }
/*  611 */         context.bootstrapMethods = bootstrapMethods;
/*      */       } else {
/*  613 */         Attribute attr = readAttribute(attrs, attrName, u + 8, 
/*  614 */           readInt(u + 4), c, -1, null);
/*  615 */         if (attr != null) {
/*  616 */           attr.next = attributes;
/*  617 */           attributes = attr;
/*      */         }
/*      */       }
/*  620 */       u += 6 + readInt(u + 4);
/*      */     }
/*      */     
/*      */ 
/*  624 */     classVisitor.visit(readInt(this.items[1] - 7), access, name, signature, superClass, interfaces);
/*      */     
/*      */ 
/*      */ 
/*  628 */     if (((flags & 0x2) == 0) && ((sourceFile != null) || (sourceDebug != null)))
/*      */     {
/*  630 */       classVisitor.visitSource(sourceFile, sourceDebug);
/*      */     }
/*      */     
/*      */ 
/*  634 */     if (enclosingOwner != null) {
/*  635 */       classVisitor.visitOuterClass(enclosingOwner, enclosingName, enclosingDesc);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  640 */     if (anns != 0) {
/*  641 */       int i = readUnsignedShort(anns); for (int v = anns + 2; i > 0; i--) {
/*  642 */         v = readAnnotationValues(v + 2, c, true, classVisitor
/*  643 */           .visitAnnotation(readUTF8(v, c), true));
/*      */       }
/*      */     }
/*  646 */     if (ianns != 0) {
/*  647 */       int i = readUnsignedShort(ianns); for (int v = ianns + 2; i > 0; i--) {
/*  648 */         v = readAnnotationValues(v + 2, c, true, classVisitor
/*  649 */           .visitAnnotation(readUTF8(v, c), false));
/*      */       }
/*      */     }
/*  652 */     if (tanns != 0) {
/*  653 */       int i = readUnsignedShort(tanns); for (int v = tanns + 2; i > 0; i--) {
/*  654 */         v = readAnnotationTarget(context, v);
/*  655 */         v = readAnnotationValues(v + 2, c, true, classVisitor
/*  656 */           .visitTypeAnnotation(context.typeRef, context.typePath, 
/*  657 */           readUTF8(v, c), true));
/*      */       }
/*      */     }
/*  660 */     if (itanns != 0) {
/*  661 */       int i = readUnsignedShort(itanns); for (int v = itanns + 2; i > 0; i--) {
/*  662 */         v = readAnnotationTarget(context, v);
/*  663 */         v = readAnnotationValues(v + 2, c, true, classVisitor
/*  664 */           .visitTypeAnnotation(context.typeRef, context.typePath, 
/*  665 */           readUTF8(v, c), false));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  670 */     while (attributes != null) {
/*  671 */       Attribute attr = attributes.next;
/*  672 */       attributes.next = null;
/*  673 */       classVisitor.visitAttribute(attributes);
/*  674 */       attributes = attr;
/*      */     }
/*      */     
/*      */ 
/*  678 */     if (innerClasses != 0) {
/*  679 */       int v = innerClasses + 2;
/*  680 */       for (int i = readUnsignedShort(innerClasses); i > 0; i--) {
/*  681 */         classVisitor.visitInnerClass(readClass(v, c), 
/*  682 */           readClass(v + 2, c), readUTF8(v + 4, c), 
/*  683 */           readUnsignedShort(v + 6));
/*  684 */         v += 8;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  689 */     u = this.header + 10 + 2 * interfaces.length;
/*  690 */     for (int i = readUnsignedShort(u - 2); i > 0; i--) {
/*  691 */       u = readField(classVisitor, context, u);
/*      */     }
/*  693 */     u += 2;
/*  694 */     for (int i = readUnsignedShort(u - 2); i > 0; i--) {
/*  695 */       u = readMethod(classVisitor, context, u);
/*      */     }
/*      */     
/*      */ 
/*  699 */     classVisitor.visitEnd();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int readField(ClassVisitor classVisitor, Context context, int u)
/*      */   {
/*  716 */     char[] c = context.buffer;
/*  717 */     int access = readUnsignedShort(u);
/*  718 */     String name = readUTF8(u + 2, c);
/*  719 */     String desc = readUTF8(u + 4, c);
/*  720 */     u += 6;
/*      */     
/*      */ 
/*  723 */     String signature = null;
/*  724 */     int anns = 0;
/*  725 */     int ianns = 0;
/*  726 */     int tanns = 0;
/*  727 */     int itanns = 0;
/*  728 */     Object value = null;
/*  729 */     Attribute attributes = null;
/*      */     
/*  731 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/*  732 */       String attrName = readUTF8(u + 2, c);
/*      */       
/*      */ 
/*  735 */       if ("ConstantValue".equals(attrName)) {
/*  736 */         int item = readUnsignedShort(u + 8);
/*  737 */         value = item == 0 ? null : readConst(item, c);
/*  738 */       } else if ("Signature".equals(attrName)) {
/*  739 */         signature = readUTF8(u + 8, c);
/*  740 */       } else if ("Deprecated".equals(attrName)) {
/*  741 */         access |= 0x20000;
/*  742 */       } else if ("Synthetic".equals(attrName)) {
/*  743 */         access |= 0x41000;
/*      */ 
/*      */       }
/*  746 */       else if ("RuntimeVisibleAnnotations".equals(attrName)) {
/*  747 */         anns = u + 8;
/*      */       }
/*  749 */       else if ("RuntimeVisibleTypeAnnotations".equals(attrName)) {
/*  750 */         tanns = u + 8;
/*      */       }
/*  752 */       else if ("RuntimeInvisibleAnnotations".equals(attrName)) {
/*  753 */         ianns = u + 8;
/*      */       }
/*  755 */       else if ("RuntimeInvisibleTypeAnnotations".equals(attrName)) {
/*  756 */         itanns = u + 8;
/*      */       } else {
/*  758 */         Attribute attr = readAttribute(context.attrs, attrName, u + 8, 
/*  759 */           readInt(u + 4), c, -1, null);
/*  760 */         if (attr != null) {
/*  761 */           attr.next = attributes;
/*  762 */           attributes = attr;
/*      */         }
/*      */       }
/*  765 */       u += 6 + readInt(u + 4);
/*      */     }
/*  767 */     u += 2;
/*      */     
/*      */ 
/*  770 */     FieldVisitor fv = classVisitor.visitField(access, name, desc, signature, value);
/*      */     
/*  772 */     if (fv == null) {
/*  773 */       return u;
/*      */     }
/*      */     
/*      */ 
/*  777 */     if (anns != 0) {
/*  778 */       int i = readUnsignedShort(anns); for (int v = anns + 2; i > 0; i--) {
/*  779 */         v = readAnnotationValues(v + 2, c, true, fv
/*  780 */           .visitAnnotation(readUTF8(v, c), true));
/*      */       }
/*      */     }
/*  783 */     if (ianns != 0) {
/*  784 */       int i = readUnsignedShort(ianns); for (int v = ianns + 2; i > 0; i--) {
/*  785 */         v = readAnnotationValues(v + 2, c, true, fv
/*  786 */           .visitAnnotation(readUTF8(v, c), false));
/*      */       }
/*      */     }
/*  789 */     if (tanns != 0) {
/*  790 */       int i = readUnsignedShort(tanns); for (int v = tanns + 2; i > 0; i--) {
/*  791 */         v = readAnnotationTarget(context, v);
/*  792 */         v = readAnnotationValues(v + 2, c, true, fv
/*  793 */           .visitTypeAnnotation(context.typeRef, context.typePath, 
/*  794 */           readUTF8(v, c), true));
/*      */       }
/*      */     }
/*  797 */     if (itanns != 0) {
/*  798 */       int i = readUnsignedShort(itanns); for (int v = itanns + 2; i > 0; i--) {
/*  799 */         v = readAnnotationTarget(context, v);
/*  800 */         v = readAnnotationValues(v + 2, c, true, fv
/*  801 */           .visitTypeAnnotation(context.typeRef, context.typePath, 
/*  802 */           readUTF8(v, c), false));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  807 */     while (attributes != null) {
/*  808 */       Attribute attr = attributes.next;
/*  809 */       attributes.next = null;
/*  810 */       fv.visitAttribute(attributes);
/*  811 */       attributes = attr;
/*      */     }
/*      */     
/*      */ 
/*  815 */     fv.visitEnd();
/*      */     
/*  817 */     return u;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int readMethod(ClassVisitor classVisitor, Context context, int u)
/*      */   {
/*  834 */     char[] c = context.buffer;
/*  835 */     context.access = readUnsignedShort(u);
/*  836 */     context.name = readUTF8(u + 2, c);
/*  837 */     context.desc = readUTF8(u + 4, c);
/*  838 */     u += 6;
/*      */     
/*      */ 
/*  841 */     int code = 0;
/*  842 */     int exception = 0;
/*  843 */     String[] exceptions = null;
/*  844 */     String signature = null;
/*  845 */     int methodParameters = 0;
/*  846 */     int anns = 0;
/*  847 */     int ianns = 0;
/*  848 */     int tanns = 0;
/*  849 */     int itanns = 0;
/*  850 */     int dann = 0;
/*  851 */     int mpanns = 0;
/*  852 */     int impanns = 0;
/*  853 */     int firstAttribute = u;
/*  854 */     Attribute attributes = null;
/*      */     
/*  856 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/*  857 */       String attrName = readUTF8(u + 2, c);
/*      */       
/*      */ 
/*  860 */       if ("Code".equals(attrName)) {
/*  861 */         if ((context.flags & 0x1) == 0) {
/*  862 */           code = u + 8;
/*      */         }
/*  864 */       } else if ("Exceptions".equals(attrName)) {
/*  865 */         exceptions = new String[readUnsignedShort(u + 8)];
/*  866 */         exception = u + 10;
/*  867 */         for (int j = 0; j < exceptions.length; j++) {
/*  868 */           exceptions[j] = readClass(exception, c);
/*  869 */           exception += 2;
/*      */         }
/*  871 */       } else if ("Signature".equals(attrName)) {
/*  872 */         signature = readUTF8(u + 8, c);
/*  873 */       } else if ("Deprecated".equals(attrName)) {
/*  874 */         context.access |= 0x20000;
/*      */       }
/*  876 */       else if ("RuntimeVisibleAnnotations".equals(attrName)) {
/*  877 */         anns = u + 8;
/*      */       }
/*  879 */       else if ("RuntimeVisibleTypeAnnotations".equals(attrName)) {
/*  880 */         tanns = u + 8;
/*  881 */       } else if ("AnnotationDefault".equals(attrName)) {
/*  882 */         dann = u + 8;
/*  883 */       } else if ("Synthetic".equals(attrName)) {
/*  884 */         context.access |= 0x41000;
/*      */ 
/*      */       }
/*  887 */       else if ("RuntimeInvisibleAnnotations".equals(attrName)) {
/*  888 */         ianns = u + 8;
/*      */       }
/*  890 */       else if ("RuntimeInvisibleTypeAnnotations".equals(attrName)) {
/*  891 */         itanns = u + 8;
/*      */       }
/*  893 */       else if ("RuntimeVisibleParameterAnnotations".equals(attrName)) {
/*  894 */         mpanns = u + 8;
/*      */       }
/*  896 */       else if ("RuntimeInvisibleParameterAnnotations".equals(attrName)) {
/*  897 */         impanns = u + 8;
/*  898 */       } else if ("MethodParameters".equals(attrName)) {
/*  899 */         methodParameters = u + 8;
/*      */       } else {
/*  901 */         Attribute attr = readAttribute(context.attrs, attrName, u + 8, 
/*  902 */           readInt(u + 4), c, -1, null);
/*  903 */         if (attr != null) {
/*  904 */           attr.next = attributes;
/*  905 */           attributes = attr;
/*      */         }
/*      */       }
/*  908 */       u += 6 + readInt(u + 4);
/*      */     }
/*  910 */     u += 2;
/*      */     
/*      */ 
/*  913 */     MethodVisitor mv = classVisitor.visitMethod(context.access, context.name, context.desc, signature, exceptions);
/*      */     
/*  915 */     if (mv == null) {
/*  916 */       return u;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  929 */     if ((mv instanceof MethodWriter)) {
/*  930 */       MethodWriter mw = (MethodWriter)mv;
/*  931 */       if ((mw.cw.cr == this) && (signature != null ? signature
/*  932 */         .equals(mw.signature) : mw.signature == null)) {
/*  933 */         boolean sameExceptions = false;
/*  934 */         if (exceptions == null) {
/*  935 */           sameExceptions = mw.exceptionCount == 0;
/*  936 */         } else if (exceptions.length == mw.exceptionCount) {
/*  937 */           sameExceptions = true;
/*  938 */           for (int j = exceptions.length - 1; j >= 0; j--) {
/*  939 */             exception -= 2;
/*  940 */             if (mw.exceptions[j] != readUnsignedShort(exception)) {
/*  941 */               sameExceptions = false;
/*  942 */               break;
/*      */             }
/*      */           }
/*      */         }
/*  946 */         if (sameExceptions)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  952 */           mw.classReaderOffset = firstAttribute;
/*  953 */           mw.classReaderLength = (u - firstAttribute);
/*  954 */           return u;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  960 */     if (methodParameters != 0) {
/*  961 */       int i = this.b[methodParameters] & 0xFF; for (int v = methodParameters + 1; i > 0; v += 4) {
/*  962 */         mv.visitParameter(readUTF8(v, c), readUnsignedShort(v + 2));i--;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  967 */     if (dann != 0) {
/*  968 */       AnnotationVisitor dv = mv.visitAnnotationDefault();
/*  969 */       readAnnotationValue(dann, c, null, dv);
/*  970 */       if (dv != null) {
/*  971 */         dv.visitEnd();
/*      */       }
/*      */     }
/*  974 */     if (anns != 0) {
/*  975 */       int i = readUnsignedShort(anns); for (int v = anns + 2; i > 0; i--) {
/*  976 */         v = readAnnotationValues(v + 2, c, true, mv
/*  977 */           .visitAnnotation(readUTF8(v, c), true));
/*      */       }
/*      */     }
/*  980 */     if (ianns != 0) {
/*  981 */       int i = readUnsignedShort(ianns); for (int v = ianns + 2; i > 0; i--) {
/*  982 */         v = readAnnotationValues(v + 2, c, true, mv
/*  983 */           .visitAnnotation(readUTF8(v, c), false));
/*      */       }
/*      */     }
/*  986 */     if (tanns != 0) {
/*  987 */       int i = readUnsignedShort(tanns); for (int v = tanns + 2; i > 0; i--) {
/*  988 */         v = readAnnotationTarget(context, v);
/*  989 */         v = readAnnotationValues(v + 2, c, true, mv
/*  990 */           .visitTypeAnnotation(context.typeRef, context.typePath, 
/*  991 */           readUTF8(v, c), true));
/*      */       }
/*      */     }
/*  994 */     if (itanns != 0) {
/*  995 */       int i = readUnsignedShort(itanns); for (int v = itanns + 2; i > 0; i--) {
/*  996 */         v = readAnnotationTarget(context, v);
/*  997 */         v = readAnnotationValues(v + 2, c, true, mv
/*  998 */           .visitTypeAnnotation(context.typeRef, context.typePath, 
/*  999 */           readUTF8(v, c), false));
/*      */       }
/*      */     }
/* 1002 */     if (mpanns != 0) {
/* 1003 */       readParameterAnnotations(mv, context, mpanns, true);
/*      */     }
/* 1005 */     if (impanns != 0) {
/* 1006 */       readParameterAnnotations(mv, context, impanns, false);
/*      */     }
/*      */     
/*      */ 
/* 1010 */     while (attributes != null) {
/* 1011 */       Attribute attr = attributes.next;
/* 1012 */       attributes.next = null;
/* 1013 */       mv.visitAttribute(attributes);
/* 1014 */       attributes = attr;
/*      */     }
/*      */     
/*      */ 
/* 1018 */     if (code != 0) {
/* 1019 */       mv.visitCode();
/* 1020 */       readCode(mv, context, code);
/*      */     }
/*      */     
/*      */ 
/* 1024 */     mv.visitEnd();
/*      */     
/* 1026 */     return u;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readCode(MethodVisitor mv, Context context, int u)
/*      */   {
/* 1041 */     byte[] b = this.b;
/* 1042 */     char[] c = context.buffer;
/* 1043 */     int maxStack = readUnsignedShort(u);
/* 1044 */     int maxLocals = readUnsignedShort(u + 2);
/* 1045 */     int codeLength = readInt(u + 4);
/* 1046 */     u += 8;
/*      */     
/*      */ 
/* 1049 */     int codeStart = u;
/* 1050 */     int codeEnd = u + codeLength;
/* 1051 */     Label[] labels = context.labels = new Label[codeLength + 2];
/* 1052 */     readLabel(codeLength + 1, labels);
/* 1053 */     while (u < codeEnd) {
/* 1054 */       int offset = u - codeStart;
/* 1055 */       int opcode = b[u] & 0xFF;
/* 1056 */       switch (ClassWriter.TYPE[opcode]) {
/*      */       case 0: 
/*      */       case 4: 
/* 1059 */         u++;
/* 1060 */         break;
/*      */       case 9: 
/* 1062 */         readLabel(offset + readShort(u + 1), labels);
/* 1063 */         u += 3;
/* 1064 */         break;
/*      */       case 10: 
/* 1066 */         readLabel(offset + readInt(u + 1), labels);
/* 1067 */         u += 5;
/* 1068 */         break;
/*      */       case 17: 
/* 1070 */         opcode = b[(u + 1)] & 0xFF;
/* 1071 */         if (opcode == 132) {
/* 1072 */           u += 6;
/*      */         } else {
/* 1074 */           u += 4;
/*      */         }
/* 1076 */         break;
/*      */       
/*      */       case 14: 
/* 1079 */         u = u + 4 - (offset & 0x3);
/*      */         
/* 1081 */         readLabel(offset + readInt(u), labels);
/* 1082 */         for (int i = readInt(u + 8) - readInt(u + 4) + 1; i > 0; i--) {
/* 1083 */           readLabel(offset + readInt(u + 12), labels);
/* 1084 */           u += 4;
/*      */         }
/* 1086 */         u += 12;
/* 1087 */         break;
/*      */       
/*      */       case 15: 
/* 1090 */         u = u + 4 - (offset & 0x3);
/*      */         
/* 1092 */         readLabel(offset + readInt(u), labels);
/* 1093 */         for (int i = readInt(u + 4); i > 0; i--) {
/* 1094 */           readLabel(offset + readInt(u + 12), labels);
/* 1095 */           u += 8;
/*      */         }
/* 1097 */         u += 8;
/* 1098 */         break;
/*      */       case 1: 
/*      */       case 3: 
/*      */       case 11: 
/* 1102 */         u += 2;
/* 1103 */         break;
/*      */       case 2: 
/*      */       case 5: 
/*      */       case 6: 
/*      */       case 12: 
/*      */       case 13: 
/* 1109 */         u += 3;
/* 1110 */         break;
/*      */       case 7: 
/*      */       case 8: 
/* 1113 */         u += 5;
/* 1114 */         break;
/*      */       case 16: 
/*      */       default: 
/* 1117 */         u += 4;
/*      */       }
/*      */       
/*      */     }
/*      */     
/*      */ 
/* 1123 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/* 1124 */       Label start = readLabel(readUnsignedShort(u + 2), labels);
/* 1125 */       Label end = readLabel(readUnsignedShort(u + 4), labels);
/* 1126 */       Label handler = readLabel(readUnsignedShort(u + 6), labels);
/* 1127 */       String type = readUTF8(this.items[readUnsignedShort(u + 8)], c);
/* 1128 */       mv.visitTryCatchBlock(start, end, handler, type);
/* 1129 */       u += 8;
/*      */     }
/* 1131 */     u += 2;
/*      */     
/*      */ 
/* 1134 */     int[] tanns = null;
/* 1135 */     int[] itanns = null;
/* 1136 */     int tann = 0;
/* 1137 */     int itann = 0;
/* 1138 */     int ntoff = -1;
/* 1139 */     int nitoff = -1;
/* 1140 */     int varTable = 0;
/* 1141 */     int varTypeTable = 0;
/* 1142 */     boolean zip = true;
/* 1143 */     boolean unzip = (context.flags & 0x8) != 0;
/* 1144 */     int stackMap = 0;
/* 1145 */     int stackMapSize = 0;
/* 1146 */     int frameCount = 0;
/* 1147 */     Context frame = null;
/* 1148 */     Attribute attributes = null;
/*      */     
/* 1150 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/* 1151 */       String attrName = readUTF8(u + 2, c);
/* 1152 */       if ("LocalVariableTable".equals(attrName)) {
/* 1153 */         if ((context.flags & 0x2) == 0) {
/* 1154 */           varTable = u + 8;
/* 1155 */           int j = readUnsignedShort(u + 8); for (int v = u; j > 0; j--) {
/* 1156 */             int label = readUnsignedShort(v + 10);
/* 1157 */             if (labels[label] == null) {
/* 1158 */               readLabel(label, labels).status |= 0x1;
/*      */             }
/* 1160 */             label += readUnsignedShort(v + 12);
/* 1161 */             if (labels[label] == null) {
/* 1162 */               readLabel(label, labels).status |= 0x1;
/*      */             }
/* 1164 */             v += 10;
/*      */           }
/*      */         }
/* 1167 */       } else if ("LocalVariableTypeTable".equals(attrName)) {
/* 1168 */         varTypeTable = u + 8;
/* 1169 */       } else if ("LineNumberTable".equals(attrName)) {
/* 1170 */         if ((context.flags & 0x2) == 0) {
/* 1171 */           int j = readUnsignedShort(u + 8); for (int v = u; j > 0; j--) {
/* 1172 */             int label = readUnsignedShort(v + 10);
/* 1173 */             if (labels[label] == null) {
/* 1174 */               readLabel(label, labels).status |= 0x1;
/*      */             }
/* 1176 */             Label l = labels[label];
/* 1177 */             while (l.line > 0) {
/* 1178 */               if (l.next == null) {
/* 1179 */                 l.next = new Label();
/*      */               }
/* 1181 */               l = l.next;
/*      */             }
/* 1183 */             l.line = readUnsignedShort(v + 12);
/* 1184 */             v += 4;
/*      */           }
/*      */         }
/*      */       }
/* 1188 */       else if ("RuntimeVisibleTypeAnnotations".equals(attrName)) {
/* 1189 */         tanns = readTypeAnnotations(mv, context, u + 8, true);
/*      */         
/* 1191 */         ntoff = (tanns.length == 0) || (readByte(tanns[0]) < 67) ? -1 : readUnsignedShort(tanns[0] + 1);
/*      */       }
/* 1193 */       else if ("RuntimeInvisibleTypeAnnotations".equals(attrName)) {
/* 1194 */         itanns = readTypeAnnotations(mv, context, u + 8, false);
/*      */         
/* 1196 */         nitoff = (itanns.length == 0) || (readByte(itanns[0]) < 67) ? -1 : readUnsignedShort(itanns[0] + 1);
/* 1197 */       } else if ("StackMapTable".equals(attrName)) {
/* 1198 */         if ((context.flags & 0x4) == 0) {
/* 1199 */           stackMap = u + 10;
/* 1200 */           stackMapSize = readInt(u + 4);
/* 1201 */           frameCount = readUnsignedShort(u + 8);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/* 1221 */       else if ("StackMap".equals(attrName)) {
/* 1222 */         if ((context.flags & 0x4) == 0) {
/* 1223 */           zip = false;
/* 1224 */           stackMap = u + 10;
/* 1225 */           stackMapSize = readInt(u + 4);
/* 1226 */           frameCount = readUnsignedShort(u + 8);
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 1234 */         for (int j = 0; j < context.attrs.length; j++) {
/* 1235 */           if (context.attrs[j].type.equals(attrName)) {
/* 1236 */             Attribute attr = context.attrs[j].read(this, u + 8, 
/* 1237 */               readInt(u + 4), c, codeStart - 8, labels);
/* 1238 */             if (attr != null) {
/* 1239 */               attr.next = attributes;
/* 1240 */               attributes = attr;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1245 */       u += 6 + readInt(u + 4);
/*      */     }
/* 1247 */     u += 2;
/*      */     
/*      */ 
/* 1250 */     if (stackMap != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1256 */       frame = context;
/* 1257 */       frame.offset = -1;
/* 1258 */       frame.mode = 0;
/* 1259 */       frame.localCount = 0;
/* 1260 */       frame.localDiff = 0;
/* 1261 */       frame.stackCount = 0;
/* 1262 */       frame.local = new Object[maxLocals];
/* 1263 */       frame.stack = new Object[maxStack];
/* 1264 */       if (unzip) {
/* 1265 */         getImplicitFrame(context);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1278 */       for (int i = stackMap; i < stackMap + stackMapSize - 2; i++) {
/* 1279 */         if (b[i] == 8) {
/* 1280 */           int v = readUnsignedShort(i + 1);
/* 1281 */           if ((v >= 0) && (v < codeLength) && 
/* 1282 */             ((b[(codeStart + v)] & 0xFF) == 187)) {
/* 1283 */             readLabel(v, labels);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1291 */     u = codeStart;
/* 1292 */     for (; u < codeEnd; 
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1494 */         goto 2720)
/*      */     {
/* 1293 */       int offset = u - codeStart;
/*      */       
/*      */ 
/* 1296 */       Label l = labels[offset];
/* 1297 */       if (l != null) {
/* 1298 */         Label next = l.next;
/* 1299 */         l.next = null;
/* 1300 */         mv.visitLabel(l);
/* 1301 */         if (((context.flags & 0x2) == 0) && (l.line > 0)) {
/* 1302 */           mv.visitLineNumber(l.line, l);
/* 1303 */           while (next != null) {
/* 1304 */             mv.visitLineNumber(next.line, l);
/* 1305 */             next = next.next;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1311 */       while ((frame != null) && ((frame.offset == offset) || (frame.offset == -1)))
/*      */       {
/*      */ 
/*      */ 
/* 1315 */         if (frame.offset != -1) {
/* 1316 */           if ((!zip) || (unzip)) {
/* 1317 */             mv.visitFrame(-1, frame.localCount, frame.local, frame.stackCount, frame.stack);
/*      */           }
/*      */           else {
/* 1320 */             mv.visitFrame(frame.mode, frame.localDiff, frame.local, frame.stackCount, frame.stack);
/*      */           }
/*      */         }
/*      */         
/* 1324 */         if (frameCount > 0) {
/* 1325 */           stackMap = readFrame(stackMap, zip, unzip, frame);
/* 1326 */           frameCount--;
/*      */         } else {
/* 1328 */           frame = null;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1333 */       int opcode = b[u] & 0xFF;
/* 1334 */       switch (ClassWriter.TYPE[opcode]) {
/*      */       case 0: 
/* 1336 */         mv.visitInsn(opcode);
/* 1337 */         u++;
/* 1338 */         break;
/*      */       case 4: 
/* 1340 */         if (opcode > 54) {
/* 1341 */           opcode -= 59;
/* 1342 */           mv.visitVarInsn(54 + (opcode >> 2), opcode & 0x3);
/*      */         }
/*      */         else {
/* 1345 */           opcode -= 26;
/* 1346 */           mv.visitVarInsn(21 + (opcode >> 2), opcode & 0x3);
/*      */         }
/* 1348 */         u++;
/* 1349 */         break;
/*      */       case 9: 
/* 1351 */         mv.visitJumpInsn(opcode, labels[(offset + readShort(u + 1))]);
/* 1352 */         u += 3;
/* 1353 */         break;
/*      */       case 10: 
/* 1355 */         mv.visitJumpInsn(opcode - 33, labels[(offset + readInt(u + 1))]);
/* 1356 */         u += 5;
/* 1357 */         break;
/*      */       case 17: 
/* 1359 */         opcode = b[(u + 1)] & 0xFF;
/* 1360 */         if (opcode == 132) {
/* 1361 */           mv.visitIincInsn(readUnsignedShort(u + 2), readShort(u + 4));
/* 1362 */           u += 6;
/*      */         } else {
/* 1364 */           mv.visitVarInsn(opcode, readUnsignedShort(u + 2));
/* 1365 */           u += 4;
/*      */         }
/* 1367 */         break;
/*      */       
/*      */       case 14: 
/* 1370 */         u = u + 4 - (offset & 0x3);
/*      */         
/* 1372 */         int label = offset + readInt(u);
/* 1373 */         int min = readInt(u + 4);
/* 1374 */         int max = readInt(u + 8);
/* 1375 */         Label[] table = new Label[max - min + 1];
/* 1376 */         u += 12;
/* 1377 */         for (int i = 0; i < table.length; i++) {
/* 1378 */           table[i] = labels[(offset + readInt(u))];
/* 1379 */           u += 4;
/*      */         }
/* 1381 */         mv.visitTableSwitchInsn(min, max, labels[label], table);
/* 1382 */         break;
/*      */       
/*      */ 
/*      */       case 15: 
/* 1386 */         u = u + 4 - (offset & 0x3);
/*      */         
/* 1388 */         int label = offset + readInt(u);
/* 1389 */         int len = readInt(u + 4);
/* 1390 */         int[] keys = new int[len];
/* 1391 */         Label[] values = new Label[len];
/* 1392 */         u += 8;
/* 1393 */         for (int i = 0; i < len; i++) {
/* 1394 */           keys[i] = readInt(u);
/* 1395 */           values[i] = labels[(offset + readInt(u + 4))];
/* 1396 */           u += 8;
/*      */         }
/* 1398 */         mv.visitLookupSwitchInsn(labels[label], keys, values);
/* 1399 */         break;
/*      */       
/*      */       case 3: 
/* 1402 */         mv.visitVarInsn(opcode, b[(u + 1)] & 0xFF);
/* 1403 */         u += 2;
/* 1404 */         break;
/*      */       case 1: 
/* 1406 */         mv.visitIntInsn(opcode, b[(u + 1)]);
/* 1407 */         u += 2;
/* 1408 */         break;
/*      */       case 2: 
/* 1410 */         mv.visitIntInsn(opcode, readShort(u + 1));
/* 1411 */         u += 3;
/* 1412 */         break;
/*      */       case 11: 
/* 1414 */         mv.visitLdcInsn(readConst(b[(u + 1)] & 0xFF, c));
/* 1415 */         u += 2;
/* 1416 */         break;
/*      */       case 12: 
/* 1418 */         mv.visitLdcInsn(readConst(readUnsignedShort(u + 1), c));
/* 1419 */         u += 3;
/* 1420 */         break;
/*      */       case 6: 
/*      */       case 7: 
/* 1423 */         int cpIndex = this.items[readUnsignedShort(u + 1)];
/* 1424 */         boolean itf = b[(cpIndex - 1)] == 11;
/* 1425 */         String iowner = readClass(cpIndex, c);
/* 1426 */         cpIndex = this.items[readUnsignedShort(cpIndex + 2)];
/* 1427 */         String iname = readUTF8(cpIndex, c);
/* 1428 */         String idesc = readUTF8(cpIndex + 2, c);
/* 1429 */         if (opcode < 182) {
/* 1430 */           mv.visitFieldInsn(opcode, iowner, iname, idesc);
/*      */         } else {
/* 1432 */           mv.visitMethodInsn(opcode, iowner, iname, idesc, itf);
/*      */         }
/* 1434 */         if (opcode == 185) {
/* 1435 */           u += 5;
/*      */         } else {
/* 1437 */           u += 3;
/*      */         }
/* 1439 */         break;
/*      */       
/*      */       case 8: 
/* 1442 */         int cpIndex = this.items[readUnsignedShort(u + 1)];
/* 1443 */         int bsmIndex = context.bootstrapMethods[readUnsignedShort(cpIndex)];
/* 1444 */         Handle bsm = (Handle)readConst(readUnsignedShort(bsmIndex), c);
/* 1445 */         int bsmArgCount = readUnsignedShort(bsmIndex + 2);
/* 1446 */         Object[] bsmArgs = new Object[bsmArgCount];
/* 1447 */         bsmIndex += 4;
/* 1448 */         for (int i = 0; i < bsmArgCount; i++) {
/* 1449 */           bsmArgs[i] = readConst(readUnsignedShort(bsmIndex), c);
/* 1450 */           bsmIndex += 2;
/*      */         }
/* 1452 */         cpIndex = this.items[readUnsignedShort(cpIndex + 2)];
/* 1453 */         String iname = readUTF8(cpIndex, c);
/* 1454 */         String idesc = readUTF8(cpIndex + 2, c);
/* 1455 */         mv.visitInvokeDynamicInsn(iname, idesc, bsm, bsmArgs);
/* 1456 */         u += 5;
/* 1457 */         break;
/*      */       
/*      */       case 5: 
/* 1460 */         mv.visitTypeInsn(opcode, readClass(u + 1, c));
/* 1461 */         u += 3;
/* 1462 */         break;
/*      */       case 13: 
/* 1464 */         mv.visitIincInsn(b[(u + 1)] & 0xFF, b[(u + 2)]);
/* 1465 */         u += 3;
/* 1466 */         break;
/*      */       case 16: 
/*      */       default: 
/* 1469 */         mv.visitMultiANewArrayInsn(readClass(u + 1, c), b[(u + 3)] & 0xFF);
/* 1470 */         u += 4;
/*      */       }
/*      */       
/*      */       
/*      */ 
/* 1475 */       while ((tanns != null) && (tann < tanns.length) && (ntoff <= offset)) {
/* 1476 */         if (ntoff == offset) {
/* 1477 */           int v = readAnnotationTarget(context, tanns[tann]);
/* 1478 */           readAnnotationValues(v + 2, c, true, mv
/* 1479 */             .visitInsnAnnotation(context.typeRef, context.typePath, 
/* 1480 */             readUTF8(v, c), true));
/*      */         }
/* 1482 */         tann++;
/* 1483 */         ntoff = (tann >= tanns.length) || (readByte(tanns[tann]) < 67) ? -1 : readUnsignedShort(tanns[tann] + 1);
/*      */       }
/* 1485 */       if ((itanns != null) && (itann < itanns.length) && (nitoff <= offset)) {
/* 1486 */         if (nitoff == offset) {
/* 1487 */           int v = readAnnotationTarget(context, itanns[itann]);
/* 1488 */           readAnnotationValues(v + 2, c, true, mv
/* 1489 */             .visitInsnAnnotation(context.typeRef, context.typePath, 
/* 1490 */             readUTF8(v, c), false));
/*      */         }
/* 1492 */         itann++;
/*      */         
/* 1494 */         nitoff = (itann >= itanns.length) || (readByte(itanns[itann]) < 67) ? -1 : readUnsignedShort(itanns[itann] + 1);
/*      */       }
/*      */     }
/* 1497 */     if (labels[codeLength] != null) {
/* 1498 */       mv.visitLabel(labels[codeLength]);
/*      */     }
/*      */     
/*      */ 
/* 1502 */     if (((context.flags & 0x2) == 0) && (varTable != 0)) {
/* 1503 */       int[] typeTable = null;
/* 1504 */       int i; if (varTypeTable != 0) {
/* 1505 */         u = varTypeTable + 2;
/* 1506 */         typeTable = new int[readUnsignedShort(varTypeTable) * 3];
/* 1507 */         for (i = typeTable.length; i > 0;) {
/* 1508 */           typeTable[(--i)] = (u + 6);
/* 1509 */           typeTable[(--i)] = readUnsignedShort(u + 8);
/* 1510 */           typeTable[(--i)] = readUnsignedShort(u);
/* 1511 */           u += 10;
/*      */         }
/*      */       }
/* 1514 */       u = varTable + 2;
/* 1515 */       for (int i = readUnsignedShort(varTable); i > 0; i--) {
/* 1516 */         int start = readUnsignedShort(u);
/* 1517 */         int length = readUnsignedShort(u + 2);
/* 1518 */         int index = readUnsignedShort(u + 8);
/* 1519 */         String vsignature = null;
/* 1520 */         if (typeTable != null) {
/* 1521 */           for (int j = 0; j < typeTable.length; j += 3) {
/* 1522 */             if ((typeTable[j] == start) && (typeTable[(j + 1)] == index)) {
/* 1523 */               vsignature = readUTF8(typeTable[(j + 2)], c);
/* 1524 */               break;
/*      */             }
/*      */           }
/*      */         }
/* 1528 */         mv.visitLocalVariable(readUTF8(u + 4, c), readUTF8(u + 6, c), vsignature, labels[start], labels[(start + length)], index);
/*      */         
/*      */ 
/* 1531 */         u += 10;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1536 */     if (tanns != null) {
/* 1537 */       for (int i = 0; i < tanns.length; i++) {
/* 1538 */         if (readByte(tanns[i]) >> 1 == 32) {
/* 1539 */           int v = readAnnotationTarget(context, tanns[i]);
/* 1540 */           v = readAnnotationValues(v + 2, c, true, mv
/* 1541 */             .visitLocalVariableAnnotation(context.typeRef, context.typePath, context.start, context.end, context.index, 
/*      */             
/* 1543 */             readUTF8(v, c), true));
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1548 */     if (itanns != null) {
/* 1549 */       for (int i = 0; i < itanns.length; i++) {
/* 1550 */         if (readByte(itanns[i]) >> 1 == 32) {
/* 1551 */           int v = readAnnotationTarget(context, itanns[i]);
/* 1552 */           v = readAnnotationValues(v + 2, c, true, mv
/* 1553 */             .visitLocalVariableAnnotation(context.typeRef, context.typePath, context.start, context.end, context.index, 
/*      */             
/* 1555 */             readUTF8(v, c), false));
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1562 */     while (attributes != null) {
/* 1563 */       Attribute attr = attributes.next;
/* 1564 */       attributes.next = null;
/* 1565 */       mv.visitAttribute(attributes);
/* 1566 */       attributes = attr;
/*      */     }
/*      */     
/*      */ 
/* 1570 */     mv.visitMaxs(maxStack, maxLocals);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int[] readTypeAnnotations(MethodVisitor mv, Context context, int u, boolean visible)
/*      */   {
/* 1591 */     char[] c = context.buffer;
/* 1592 */     int[] offsets = new int[readUnsignedShort(u)];
/* 1593 */     u += 2;
/* 1594 */     for (int i = 0; i < offsets.length; i++) {
/* 1595 */       offsets[i] = u;
/* 1596 */       int target = readInt(u);
/* 1597 */       switch (target >>> 24) {
/*      */       case 0: 
/*      */       case 1: 
/*      */       case 22: 
/* 1601 */         u += 2;
/* 1602 */         break;
/*      */       case 19: 
/*      */       case 20: 
/*      */       case 21: 
/* 1606 */         u++;
/* 1607 */         break;
/*      */       case 64: 
/*      */       case 65: 
/* 1610 */         for (int j = readUnsignedShort(u + 1); j > 0; j--) {
/* 1611 */           int start = readUnsignedShort(u + 3);
/* 1612 */           int length = readUnsignedShort(u + 5);
/* 1613 */           readLabel(start, context.labels);
/* 1614 */           readLabel(start + length, context.labels);
/* 1615 */           u += 6;
/*      */         }
/* 1617 */         u += 3;
/* 1618 */         break;
/*      */       case 71: 
/*      */       case 72: 
/*      */       case 73: 
/*      */       case 74: 
/*      */       case 75: 
/* 1624 */         u += 4;
/* 1625 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       default: 
/* 1636 */         u += 3;
/*      */       }
/*      */       
/* 1639 */       int pathLength = readByte(u);
/* 1640 */       if (target >>> 24 == 66) {
/* 1641 */         TypePath path = pathLength == 0 ? null : new TypePath(this.b, u);
/* 1642 */         u += 1 + 2 * pathLength;
/* 1643 */         u = readAnnotationValues(u + 2, c, true, mv
/* 1644 */           .visitTryCatchAnnotation(target, path, 
/* 1645 */           readUTF8(u, c), visible));
/*      */       } else {
/* 1647 */         u = readAnnotationValues(u + 3 + 2 * pathLength, c, true, null);
/*      */       }
/*      */     }
/* 1650 */     return offsets;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int readAnnotationTarget(Context context, int u)
/*      */   {
/* 1668 */     int target = readInt(u);
/* 1669 */     switch (target >>> 24) {
/*      */     case 0: 
/*      */     case 1: 
/*      */     case 22: 
/* 1673 */       target &= 0xFFFF0000;
/* 1674 */       u += 2;
/* 1675 */       break;
/*      */     case 19: 
/*      */     case 20: 
/*      */     case 21: 
/* 1679 */       target &= 0xFF000000;
/* 1680 */       u++;
/* 1681 */       break;
/*      */     case 64: 
/*      */     case 65: 
/* 1684 */       target &= 0xFF000000;
/* 1685 */       int n = readUnsignedShort(u + 1);
/* 1686 */       context.start = new Label[n];
/* 1687 */       context.end = new Label[n];
/* 1688 */       context.index = new int[n];
/* 1689 */       u += 3;
/* 1690 */       for (int i = 0; i < n; i++) {
/* 1691 */         int start = readUnsignedShort(u);
/* 1692 */         int length = readUnsignedShort(u + 2);
/* 1693 */         context.start[i] = readLabel(start, context.labels);
/* 1694 */         context.end[i] = readLabel(start + length, context.labels);
/* 1695 */         context.index[i] = readUnsignedShort(u + 4);
/* 1696 */         u += 6;
/*      */       }
/* 1698 */       break;
/*      */     
/*      */     case 71: 
/*      */     case 72: 
/*      */     case 73: 
/*      */     case 74: 
/*      */     case 75: 
/* 1705 */       target &= 0xFF0000FF;
/* 1706 */       u += 4;
/* 1707 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     default: 
/* 1718 */       target &= (target >>> 24 < 67 ? 65280 : -16777216);
/* 1719 */       u += 3;
/*      */     }
/*      */     
/* 1722 */     int pathLength = readByte(u);
/* 1723 */     context.typeRef = target;
/* 1724 */     context.typePath = (pathLength == 0 ? null : new TypePath(this.b, u));
/* 1725 */     return u + 1 + 2 * pathLength;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readParameterAnnotations(MethodVisitor mv, Context context, int v, boolean visible)
/*      */   {
/* 1744 */     int n = this.b[(v++)] & 0xFF;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1751 */     int synthetics = Type.getArgumentTypes(context.desc).length - n;
/*      */     
/* 1753 */     for (int i = 0; i < synthetics; i++)
/*      */     {
/* 1755 */       AnnotationVisitor av = mv.visitParameterAnnotation(i, "Ljava/lang/Synthetic;", false);
/* 1756 */       if (av != null) {
/* 1757 */         av.visitEnd();
/*      */       }
/*      */     }
/* 1760 */     char[] c = context.buffer;
/* 1761 */     for (; i < n + synthetics; i++) {
/* 1762 */       int j = readUnsignedShort(v);
/* 1763 */       v += 2;
/* 1764 */       for (; j > 0; j--) {
/* 1765 */         AnnotationVisitor av = mv.visitParameterAnnotation(i, readUTF8(v, c), visible);
/* 1766 */         v = readAnnotationValues(v + 2, c, true, av);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int readAnnotationValues(int v, char[] buf, boolean named, AnnotationVisitor av)
/*      */   {
/* 1790 */     int i = readUnsignedShort(v);
/* 1791 */     v += 2;
/* 1792 */     if (named) {
/* 1793 */       for (; i > 0; i--) {
/* 1794 */         v = readAnnotationValue(v + 2, buf, readUTF8(v, buf), av);
/*      */       }
/*      */     }
/* 1797 */     for (; i > 0; i--) {
/* 1798 */       v = readAnnotationValue(v, buf, null, av);
/*      */     }
/*      */     
/* 1801 */     if (av != null) {
/* 1802 */       av.visitEnd();
/*      */     }
/* 1804 */     return v;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int readAnnotationValue(int v, char[] buf, String name, AnnotationVisitor av)
/*      */   {
/* 1826 */     if (av == null) {
/* 1827 */       switch (this.b[v] & 0xFF) {
/*      */       case 101: 
/* 1829 */         return v + 5;
/*      */       case 64: 
/* 1831 */         return readAnnotationValues(v + 3, buf, true, null);
/*      */       case 91: 
/* 1833 */         return readAnnotationValues(v + 1, buf, false, null);
/*      */       }
/* 1835 */       return v + 3;
/*      */     }
/*      */     
/* 1838 */     switch (this.b[(v++)] & 0xFF) {
/*      */     case 68: 
/*      */     case 70: 
/*      */     case 73: 
/*      */     case 74: 
/* 1843 */       av.visit(name, readConst(readUnsignedShort(v), buf));
/* 1844 */       v += 2;
/* 1845 */       break;
/*      */     case 66: 
/* 1847 */       av.visit(name, Byte.valueOf((byte)readInt(this.items[readUnsignedShort(v)])));
/* 1848 */       v += 2;
/* 1849 */       break;
/*      */     case 90: 
/* 1851 */       av.visit(name, readInt(this.items[readUnsignedShort(v)]) == 0 ? Boolean.FALSE : Boolean.TRUE);
/* 1852 */       v += 2;
/* 1853 */       break;
/*      */     case 83: 
/* 1855 */       av.visit(name, Short.valueOf((short)readInt(this.items[readUnsignedShort(v)])));
/* 1856 */       v += 2;
/* 1857 */       break;
/*      */     case 67: 
/* 1859 */       av.visit(name, Character.valueOf((char)readInt(this.items[readUnsignedShort(v)])));
/* 1860 */       v += 2;
/* 1861 */       break;
/*      */     case 115: 
/* 1863 */       av.visit(name, readUTF8(v, buf));
/* 1864 */       v += 2;
/* 1865 */       break;
/*      */     case 101: 
/* 1867 */       av.visitEnum(name, readUTF8(v, buf), readUTF8(v + 2, buf));
/* 1868 */       v += 4;
/* 1869 */       break;
/*      */     case 99: 
/* 1871 */       av.visit(name, Type.getType(readUTF8(v, buf)));
/* 1872 */       v += 2;
/* 1873 */       break;
/*      */     case 64: 
/* 1875 */       v = readAnnotationValues(v + 2, buf, true, av
/* 1876 */         .visitAnnotation(name, readUTF8(v, buf)));
/* 1877 */       break;
/*      */     case 91: 
/* 1879 */       int size = readUnsignedShort(v);
/* 1880 */       v += 2;
/* 1881 */       if (size == 0) {
/* 1882 */         return readAnnotationValues(v - 2, buf, false, av
/* 1883 */           .visitArray(name));
/*      */       }
/* 1885 */       switch (this.b[(v++)] & 0xFF) {
/*      */       case 66: 
/* 1887 */         byte[] bv = new byte[size];
/* 1888 */         for (int i = 0; i < size; i++) {
/* 1889 */           bv[i] = ((byte)readInt(this.items[readUnsignedShort(v)]));
/* 1890 */           v += 3;
/*      */         }
/* 1892 */         av.visit(name, bv);
/* 1893 */         v--;
/* 1894 */         break;
/*      */       case 90: 
/* 1896 */         boolean[] zv = new boolean[size];
/* 1897 */         for (int i = 0; i < size; i++) {
/* 1898 */           zv[i] = (readInt(this.items[readUnsignedShort(v)]) != 0 ? 1 : false);
/* 1899 */           v += 3;
/*      */         }
/* 1901 */         av.visit(name, zv);
/* 1902 */         v--;
/* 1903 */         break;
/*      */       case 83: 
/* 1905 */         short[] sv = new short[size];
/* 1906 */         for (int i = 0; i < size; i++) {
/* 1907 */           sv[i] = ((short)readInt(this.items[readUnsignedShort(v)]));
/* 1908 */           v += 3;
/*      */         }
/* 1910 */         av.visit(name, sv);
/* 1911 */         v--;
/* 1912 */         break;
/*      */       case 67: 
/* 1914 */         char[] cv = new char[size];
/* 1915 */         for (int i = 0; i < size; i++) {
/* 1916 */           cv[i] = ((char)readInt(this.items[readUnsignedShort(v)]));
/* 1917 */           v += 3;
/*      */         }
/* 1919 */         av.visit(name, cv);
/* 1920 */         v--;
/* 1921 */         break;
/*      */       case 73: 
/* 1923 */         int[] iv = new int[size];
/* 1924 */         for (int i = 0; i < size; i++) {
/* 1925 */           iv[i] = readInt(this.items[readUnsignedShort(v)]);
/* 1926 */           v += 3;
/*      */         }
/* 1928 */         av.visit(name, iv);
/* 1929 */         v--;
/* 1930 */         break;
/*      */       case 74: 
/* 1932 */         long[] lv = new long[size];
/* 1933 */         for (int i = 0; i < size; i++) {
/* 1934 */           lv[i] = readLong(this.items[readUnsignedShort(v)]);
/* 1935 */           v += 3;
/*      */         }
/* 1937 */         av.visit(name, lv);
/* 1938 */         v--;
/* 1939 */         break;
/*      */       case 70: 
/* 1941 */         float[] fv = new float[size];
/* 1942 */         for (int i = 0; i < size; i++)
/*      */         {
/* 1944 */           fv[i] = Float.intBitsToFloat(readInt(this.items[readUnsignedShort(v)]));
/* 1945 */           v += 3;
/*      */         }
/* 1947 */         av.visit(name, fv);
/* 1948 */         v--;
/* 1949 */         break;
/*      */       case 68: 
/* 1951 */         double[] dv = new double[size];
/* 1952 */         for (int i = 0; i < size; i++)
/*      */         {
/* 1954 */           dv[i] = Double.longBitsToDouble(readLong(this.items[readUnsignedShort(v)]));
/* 1955 */           v += 3;
/*      */         }
/* 1957 */         av.visit(name, dv);
/* 1958 */         v--;
/* 1959 */         break;
/*      */       case 69: case 71: case 72: case 75: case 76: case 77: case 78: case 79: case 80: case 81: case 82: case 84: case 85: case 86: case 87: case 88: case 89: default: 
/* 1961 */         v = readAnnotationValues(v - 3, buf, false, av.visitArray(name));
/*      */       }
/*      */       break; }
/* 1964 */     return v;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void getImplicitFrame(Context frame)
/*      */   {
/* 1975 */     String desc = frame.desc;
/* 1976 */     Object[] locals = frame.local;
/* 1977 */     int local = 0;
/* 1978 */     if ((frame.access & 0x8) == 0) {
/* 1979 */       if ("<init>".equals(frame.name)) {
/* 1980 */         locals[(local++)] = Opcodes.UNINITIALIZED_THIS;
/*      */       } else {
/* 1982 */         locals[(local++)] = readClass(this.header + 2, frame.buffer);
/*      */       }
/*      */     }
/* 1985 */     int i = 1;
/*      */     for (;;) {
/* 1987 */       int j = i;
/* 1988 */       switch (desc.charAt(i++)) {
/*      */       case 'B': 
/*      */       case 'C': 
/*      */       case 'I': 
/*      */       case 'S': 
/*      */       case 'Z': 
/* 1994 */         locals[(local++)] = Opcodes.INTEGER;
/* 1995 */         break;
/*      */       case 'F': 
/* 1997 */         locals[(local++)] = Opcodes.FLOAT;
/* 1998 */         break;
/*      */       case 'J': 
/* 2000 */         locals[(local++)] = Opcodes.LONG;
/* 2001 */         break;
/*      */       case 'D': 
/* 2003 */         locals[(local++)] = Opcodes.DOUBLE;
/* 2004 */         break;
/*      */       case '[': 
/* 2006 */         while (desc.charAt(i) == '[') {
/* 2007 */           i++;
/*      */         }
/* 2009 */         if (desc.charAt(i) == 'L') {
/* 2010 */           i++;
/* 2011 */           while (desc.charAt(i) != ';') {
/* 2012 */             i++;
/*      */           }
/*      */         }
/* 2015 */         locals[(local++)] = desc.substring(j, ++i);
/* 2016 */         break;
/*      */       case 'L': 
/* 2018 */         while (desc.charAt(i) != ';') {
/* 2019 */           i++;
/*      */         }
/* 2021 */         locals[(local++)] = desc.substring(j + 1, i++);
/* 2022 */         break;
/*      */       case 'E': case 'G': case 'H': case 'K': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': default: 
/*      */         break label371; }
/*      */     }
/*      */     label371:
/* 2027 */     frame.localCount = local;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int readFrame(int stackMap, boolean zip, boolean unzip, Context frame)
/*      */   {
/* 2046 */     char[] c = frame.buffer;
/* 2047 */     Label[] labels = frame.labels;
/*      */     int tag;
/*      */     int tag;
/* 2050 */     if (zip) {
/* 2051 */       tag = this.b[(stackMap++)] & 0xFF;
/*      */     } else {
/* 2053 */       tag = 255;
/* 2054 */       frame.offset = -1;
/*      */     }
/* 2056 */     frame.localDiff = 0;
/* 2057 */     int delta; if (tag < 64) {
/* 2058 */       int delta = tag;
/* 2059 */       frame.mode = 3;
/* 2060 */       frame.stackCount = 0;
/* 2061 */     } else if (tag < 128) {
/* 2062 */       int delta = tag - 64;
/* 2063 */       stackMap = readFrameType(frame.stack, 0, stackMap, c, labels);
/* 2064 */       frame.mode = 4;
/* 2065 */       frame.stackCount = 1;
/*      */     } else {
/* 2067 */       delta = readUnsignedShort(stackMap);
/* 2068 */       stackMap += 2;
/* 2069 */       if (tag == 247) {
/* 2070 */         stackMap = readFrameType(frame.stack, 0, stackMap, c, labels);
/* 2071 */         frame.mode = 4;
/* 2072 */         frame.stackCount = 1;
/* 2073 */       } else if ((tag >= 248) && (tag < 251))
/*      */       {
/* 2075 */         frame.mode = 2;
/* 2076 */         frame.localDiff = (251 - tag);
/* 2077 */         frame.localCount -= frame.localDiff;
/* 2078 */         frame.stackCount = 0;
/* 2079 */       } else if (tag == 251) {
/* 2080 */         frame.mode = 3;
/* 2081 */         frame.stackCount = 0;
/* 2082 */       } else if (tag < 255) {
/* 2083 */         int local = unzip ? frame.localCount : 0;
/* 2084 */         for (int i = tag - 251; i > 0; i--) {
/* 2085 */           stackMap = readFrameType(frame.local, local++, stackMap, c, labels);
/*      */         }
/*      */         
/* 2088 */         frame.mode = 1;
/* 2089 */         frame.localDiff = (tag - 251);
/* 2090 */         frame.localCount += frame.localDiff;
/* 2091 */         frame.stackCount = 0;
/*      */       } else {
/* 2093 */         frame.mode = 0;
/* 2094 */         int n = readUnsignedShort(stackMap);
/* 2095 */         stackMap += 2;
/* 2096 */         frame.localDiff = n;
/* 2097 */         frame.localCount = n;
/* 2098 */         for (int local = 0; n > 0; n--) {
/* 2099 */           stackMap = readFrameType(frame.local, local++, stackMap, c, labels);
/*      */         }
/*      */         
/* 2102 */         n = readUnsignedShort(stackMap);
/* 2103 */         stackMap += 2;
/* 2104 */         frame.stackCount = n;
/* 2105 */         for (int stack = 0; n > 0; n--) {
/* 2106 */           stackMap = readFrameType(frame.stack, stack++, stackMap, c, labels);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2111 */     frame.offset += delta + 1;
/* 2112 */     readLabel(frame.offset, labels);
/* 2113 */     return stackMap;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int readFrameType(Object[] frame, int index, int v, char[] buf, Label[] labels)
/*      */   {
/* 2137 */     int type = this.b[(v++)] & 0xFF;
/* 2138 */     switch (type) {
/*      */     case 0: 
/* 2140 */       frame[index] = Opcodes.TOP;
/* 2141 */       break;
/*      */     case 1: 
/* 2143 */       frame[index] = Opcodes.INTEGER;
/* 2144 */       break;
/*      */     case 2: 
/* 2146 */       frame[index] = Opcodes.FLOAT;
/* 2147 */       break;
/*      */     case 3: 
/* 2149 */       frame[index] = Opcodes.DOUBLE;
/* 2150 */       break;
/*      */     case 4: 
/* 2152 */       frame[index] = Opcodes.LONG;
/* 2153 */       break;
/*      */     case 5: 
/* 2155 */       frame[index] = Opcodes.NULL;
/* 2156 */       break;
/*      */     case 6: 
/* 2158 */       frame[index] = Opcodes.UNINITIALIZED_THIS;
/* 2159 */       break;
/*      */     case 7: 
/* 2161 */       frame[index] = readClass(v, buf);
/* 2162 */       v += 2;
/* 2163 */       break;
/*      */     default: 
/* 2165 */       frame[index] = readLabel(readUnsignedShort(v), labels);
/* 2166 */       v += 2;
/*      */     }
/* 2168 */     return v;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Label readLabel(int offset, Label[] labels)
/*      */   {
/* 2186 */     if (offset >= labels.length) {
/* 2187 */       return new Label();
/*      */     }
/*      */     
/* 2190 */     if (labels[offset] == null) {
/* 2191 */       labels[offset] = new Label();
/*      */     }
/* 2193 */     return labels[offset];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAttributes()
/*      */   {
/* 2203 */     int u = this.header + 8 + readUnsignedShort(this.header + 6) * 2;
/*      */     
/* 2205 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/* 2206 */       for (int j = readUnsignedShort(u + 8); j > 0; j--) {
/* 2207 */         u += 6 + readInt(u + 12);
/*      */       }
/* 2209 */       u += 8;
/*      */     }
/* 2211 */     u += 2;
/* 2212 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/* 2213 */       for (int j = readUnsignedShort(u + 8); j > 0; j--) {
/* 2214 */         u += 6 + readInt(u + 12);
/*      */       }
/* 2216 */       u += 8;
/*      */     }
/*      */     
/* 2219 */     return u + 2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Attribute readAttribute(Attribute[] attrs, String type, int off, int len, char[] buf, int codeOff, Label[] labels)
/*      */   {
/* 2258 */     for (int i = 0; i < attrs.length; i++) {
/* 2259 */       if (attrs[i].type.equals(type)) {
/* 2260 */         return attrs[i].read(this, off, len, buf, codeOff, labels);
/*      */       }
/*      */     }
/* 2263 */     return new Attribute(type).read(this, off, len, null, -1, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getItemCount()
/*      */   {
/* 2276 */     return this.items.length;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getItem(int item)
/*      */   {
/* 2290 */     return this.items[item];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxStringLength()
/*      */   {
/* 2301 */     return this.maxStringLength;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int readByte(int index)
/*      */   {
/* 2314 */     return this.b[index] & 0xFF;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int readUnsignedShort(int index)
/*      */   {
/* 2327 */     byte[] b = this.b;
/* 2328 */     return (b[index] & 0xFF) << 8 | b[(index + 1)] & 0xFF;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short readShort(int index)
/*      */   {
/* 2341 */     byte[] b = this.b;
/* 2342 */     return (short)((b[index] & 0xFF) << 8 | b[(index + 1)] & 0xFF);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int readInt(int index)
/*      */   {
/* 2355 */     byte[] b = this.b;
/* 2356 */     return (b[index] & 0xFF) << 24 | (b[(index + 1)] & 0xFF) << 16 | (b[(index + 2)] & 0xFF) << 8 | b[(index + 3)] & 0xFF;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long readLong(int index)
/*      */   {
/* 2370 */     long l1 = readInt(index);
/* 2371 */     long l0 = readInt(index + 4) & 0xFFFFFFFF;
/* 2372 */     return l1 << 32 | l0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String readUTF8(int index, char[] buf)
/*      */   {
/* 2389 */     int item = readUnsignedShort(index);
/* 2390 */     if ((index == 0) || (item == 0)) {
/* 2391 */       return null;
/*      */     }
/* 2393 */     String s = this.strings[item];
/* 2394 */     if (s != null) {
/* 2395 */       return s;
/*      */     }
/* 2397 */     index = this.items[item];
/* 2398 */     return this.strings[item] = readUTF(index + 2, readUnsignedShort(index), buf);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String readUTF(int index, int utfLen, char[] buf)
/*      */   {
/* 2414 */     int endIndex = index + utfLen;
/* 2415 */     byte[] b = this.b;
/* 2416 */     int strLen = 0;
/*      */     
/* 2418 */     int st = 0;
/* 2419 */     char cc = '\000';
/* 2420 */     while (index < endIndex) {
/* 2421 */       int c = b[(index++)];
/* 2422 */       switch (st) {
/*      */       case 0: 
/* 2424 */         c &= 0xFF;
/* 2425 */         if (c < 128) {
/* 2426 */           buf[(strLen++)] = ((char)c);
/* 2427 */         } else if ((c < 224) && (c > 191)) {
/* 2428 */           cc = (char)(c & 0x1F);
/* 2429 */           st = 1;
/*      */         } else {
/* 2431 */           cc = (char)(c & 0xF);
/* 2432 */           st = 2;
/*      */         }
/* 2434 */         break;
/*      */       
/*      */       case 1: 
/* 2437 */         buf[(strLen++)] = ((char)(cc << '\006' | c & 0x3F));
/* 2438 */         st = 0;
/* 2439 */         break;
/*      */       
/*      */       case 2: 
/* 2442 */         cc = (char)(cc << '\006' | c & 0x3F);
/* 2443 */         st = 1;
/*      */       }
/*      */       
/*      */     }
/* 2447 */     return new String(buf, 0, strLen);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String readClass(int index, char[] buf)
/*      */   {
/* 2467 */     return readUTF8(this.items[readUnsignedShort(index)], buf);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object readConst(int item, char[] buf)
/*      */   {
/* 2485 */     int index = this.items[item];
/* 2486 */     switch (this.b[(index - 1)]) {
/*      */     case 3: 
/* 2488 */       return Integer.valueOf(readInt(index));
/*      */     case 4: 
/* 2490 */       return Float.valueOf(Float.intBitsToFloat(readInt(index)));
/*      */     case 5: 
/* 2492 */       return Long.valueOf(readLong(index));
/*      */     case 6: 
/* 2494 */       return Double.valueOf(Double.longBitsToDouble(readLong(index)));
/*      */     case 7: 
/* 2496 */       return Type.getObjectType(readUTF8(index, buf));
/*      */     case 8: 
/* 2498 */       return readUTF8(index, buf);
/*      */     case 16: 
/* 2500 */       return Type.getMethodType(readUTF8(index, buf));
/*      */     }
/* 2502 */     int tag = readByte(index);
/* 2503 */     int[] items = this.items;
/* 2504 */     int cpIndex = items[readUnsignedShort(index + 1)];
/* 2505 */     boolean itf = this.b[(cpIndex - 1)] == 11;
/* 2506 */     String owner = readClass(cpIndex, buf);
/* 2507 */     cpIndex = items[readUnsignedShort(cpIndex + 2)];
/* 2508 */     String name = readUTF8(cpIndex, buf);
/* 2509 */     String desc = readUTF8(cpIndex + 2, buf);
/* 2510 */     return new Handle(tag, owner, name, desc, itf);
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\asm\ClassReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */