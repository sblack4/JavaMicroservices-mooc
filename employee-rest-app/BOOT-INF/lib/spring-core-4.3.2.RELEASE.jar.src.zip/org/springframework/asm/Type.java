/*     */ package org.springframework.asm;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Type
/*     */ {
/*     */   public static final int VOID = 0;
/*     */   public static final int BOOLEAN = 1;
/*     */   public static final int CHAR = 2;
/*     */   public static final int BYTE = 3;
/*     */   public static final int SHORT = 4;
/*     */   public static final int INT = 5;
/*     */   public static final int FLOAT = 6;
/*     */   public static final int LONG = 7;
/*     */   public static final int DOUBLE = 8;
/*     */   public static final int ARRAY = 9;
/*     */   public static final int OBJECT = 10;
/*     */   public static final int METHOD = 11;
/* 107 */   public static final Type VOID_TYPE = new Type(0, null, 1443168256, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 113 */   public static final Type BOOLEAN_TYPE = new Type(1, null, 1509950721, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 119 */   public static final Type CHAR_TYPE = new Type(2, null, 1124075009, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */   public static final Type BYTE_TYPE = new Type(3, null, 1107297537, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 131 */   public static final Type SHORT_TYPE = new Type(4, null, 1392510721, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 137 */   public static final Type INT_TYPE = new Type(5, null, 1224736769, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 143 */   public static final Type FLOAT_TYPE = new Type(6, null, 1174536705, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 149 */   public static final Type LONG_TYPE = new Type(7, null, 1241579778, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 155 */   public static final Type DOUBLE_TYPE = new Type(8, null, 1141048066, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int sort;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final char[] buf;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int off;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int len;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Type(int sort, char[] buf, int off, int len)
/*     */   {
/* 203 */     this.sort = sort;
/* 204 */     this.buf = buf;
/* 205 */     this.off = off;
/* 206 */     this.len = len;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type getType(String typeDescriptor)
/*     */   {
/* 217 */     return getType(typeDescriptor.toCharArray(), 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type getObjectType(String internalName)
/*     */   {
/* 228 */     char[] buf = internalName.toCharArray();
/* 229 */     return new Type(buf[0] == '[' ? 9 : 10, buf, 0, buf.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type getMethodType(String methodDescriptor)
/*     */   {
/* 241 */     return getType(methodDescriptor.toCharArray(), 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type getMethodType(Type returnType, Type... argumentTypes)
/*     */   {
/* 257 */     return getType(getMethodDescriptor(returnType, argumentTypes));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type getType(Class<?> c)
/*     */   {
/* 268 */     if (c.isPrimitive()) {
/* 269 */       if (c == Integer.TYPE)
/* 270 */         return INT_TYPE;
/* 271 */       if (c == Void.TYPE)
/* 272 */         return VOID_TYPE;
/* 273 */       if (c == Boolean.TYPE)
/* 274 */         return BOOLEAN_TYPE;
/* 275 */       if (c == Byte.TYPE)
/* 276 */         return BYTE_TYPE;
/* 277 */       if (c == Character.TYPE)
/* 278 */         return CHAR_TYPE;
/* 279 */       if (c == Short.TYPE)
/* 280 */         return SHORT_TYPE;
/* 281 */       if (c == Double.TYPE)
/* 282 */         return DOUBLE_TYPE;
/* 283 */       if (c == Float.TYPE) {
/* 284 */         return FLOAT_TYPE;
/*     */       }
/* 286 */       return LONG_TYPE;
/*     */     }
/*     */     
/* 289 */     return getType(getDescriptor(c));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type getType(Constructor<?> c)
/*     */   {
/* 301 */     return getType(getConstructorDescriptor(c));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type getType(Method m)
/*     */   {
/* 312 */     return getType(getMethodDescriptor(m));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type[] getArgumentTypes(String methodDescriptor)
/*     */   {
/* 325 */     char[] buf = methodDescriptor.toCharArray();
/* 326 */     int off = 1;
/* 327 */     int size = 0;
/*     */     for (;;) {
/* 329 */       char car = buf[(off++)];
/* 330 */       if (car == ')')
/*     */         break;
/* 332 */       if (car == 'L') {
/* 333 */         while (buf[(off++)] != ';') {}
/*     */         
/* 335 */         size++;
/* 336 */       } else if (car != '[') {
/* 337 */         size++;
/*     */       }
/*     */     }
/* 340 */     Type[] args = new Type[size];
/* 341 */     off = 1;
/* 342 */     size = 0;
/* 343 */     while (buf[off] != ')') {
/* 344 */       args[size] = getType(buf, off);
/* 345 */       off += args[size].len + (args[size].sort == 10 ? 2 : 0);
/* 346 */       size++;
/*     */     }
/* 348 */     return args;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type[] getArgumentTypes(Method method)
/*     */   {
/* 361 */     Class<?>[] classes = method.getParameterTypes();
/* 362 */     Type[] types = new Type[classes.length];
/* 363 */     for (int i = classes.length - 1; i >= 0; i--) {
/* 364 */       types[i] = getType(classes[i]);
/*     */     }
/* 366 */     return types;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type getReturnType(String methodDescriptor)
/*     */   {
/* 379 */     char[] buf = methodDescriptor.toCharArray();
/* 380 */     return getType(buf, methodDescriptor.indexOf(')') + 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type getReturnType(Method method)
/*     */   {
/* 393 */     return getType(method.getReturnType());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getArgumentsAndReturnSizes(String desc)
/*     */   {
/* 408 */     int n = 1;
/* 409 */     int c = 1;
/*     */     for (;;) {
/* 411 */       char car = desc.charAt(c++);
/* 412 */       if (car == ')') {
/* 413 */         car = desc.charAt(c);
/* 414 */         return n << 2 | ((car == 'D') || (car == 'J') ? 2 : car == 'V' ? 0 : 1);
/*     */       }
/* 416 */       if (car == 'L') {
/* 417 */         while (desc.charAt(c++) != ';') {}
/*     */         
/* 419 */         n++;
/* 420 */       } else if (car == '[') {
/* 421 */         while ((car = desc.charAt(c)) == '[') {
/* 422 */           c++;
/*     */         }
/* 424 */         if ((car == 'D') || (car == 'J')) {
/* 425 */           n--;
/*     */         }
/* 427 */       } else if ((car == 'D') || (car == 'J')) {
/* 428 */         n += 2;
/*     */       } else {
/* 430 */         n++;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Type getType(char[] buf, int off)
/*     */   {
/* 448 */     switch (buf[off]) {
/*     */     case 'V': 
/* 450 */       return VOID_TYPE;
/*     */     case 'Z': 
/* 452 */       return BOOLEAN_TYPE;
/*     */     case 'C': 
/* 454 */       return CHAR_TYPE;
/*     */     case 'B': 
/* 456 */       return BYTE_TYPE;
/*     */     case 'S': 
/* 458 */       return SHORT_TYPE;
/*     */     case 'I': 
/* 460 */       return INT_TYPE;
/*     */     case 'F': 
/* 462 */       return FLOAT_TYPE;
/*     */     case 'J': 
/* 464 */       return LONG_TYPE;
/*     */     case 'D': 
/* 466 */       return DOUBLE_TYPE;
/*     */     case '[': 
/* 468 */       int len = 1;
/* 469 */       while (buf[(off + len)] == '[') {
/* 470 */         len++;
/*     */       }
/* 472 */       if (buf[(off + len)] == 'L') {
/* 473 */         len++;
/* 474 */         while (buf[(off + len)] != ';') {
/* 475 */           len++;
/*     */         }
/*     */       }
/* 478 */       return new Type(9, buf, off, len + 1);
/*     */     case 'L': 
/* 480 */       int len = 1;
/* 481 */       while (buf[(off + len)] != ';') {
/* 482 */         len++;
/*     */       }
/* 484 */       return new Type(10, buf, off + 1, len - 1);
/*     */     }
/*     */     
/* 487 */     return new Type(11, buf, off, buf.length - off);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSort()
/*     */   {
/* 505 */     return this.sort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDimensions()
/*     */   {
/* 515 */     int i = 1;
/* 516 */     while (this.buf[(this.off + i)] == '[') {
/* 517 */       i++;
/*     */     }
/* 519 */     return i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Type getElementType()
/*     */   {
/* 529 */     return getType(this.buf, this.off + getDimensions());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getClassName()
/*     */   {
/* 539 */     switch (this.sort) {
/*     */     case 0: 
/* 541 */       return "void";
/*     */     case 1: 
/* 543 */       return "boolean";
/*     */     case 2: 
/* 545 */       return "char";
/*     */     case 3: 
/* 547 */       return "byte";
/*     */     case 4: 
/* 549 */       return "short";
/*     */     case 5: 
/* 551 */       return "int";
/*     */     case 6: 
/* 553 */       return "float";
/*     */     case 7: 
/* 555 */       return "long";
/*     */     case 8: 
/* 557 */       return "double";
/*     */     case 9: 
/* 559 */       StringBuilder sb = new StringBuilder(getElementType().getClassName());
/* 560 */       for (int i = getDimensions(); i > 0; i--) {
/* 561 */         sb.append("[]");
/*     */       }
/* 563 */       return sb.toString();
/*     */     case 10: 
/* 565 */       return new String(this.buf, this.off, this.len).replace('/', '.');
/*     */     }
/* 567 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getInternalName()
/*     */   {
/* 580 */     return new String(this.buf, this.off, this.len);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Type[] getArgumentTypes()
/*     */   {
/* 590 */     return getArgumentTypes(getDescriptor());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Type getReturnType()
/*     */   {
/* 600 */     return getReturnType(getDescriptor());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getArgumentsAndReturnSizes()
/*     */   {
/* 615 */     return getArgumentsAndReturnSizes(getDescriptor());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDescriptor()
/*     */   {
/* 628 */     StringBuilder sb = new StringBuilder();
/* 629 */     getDescriptor(sb);
/* 630 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getMethodDescriptor(Type returnType, Type... argumentTypes)
/*     */   {
/* 646 */     StringBuilder sb = new StringBuilder();
/* 647 */     sb.append('(');
/* 648 */     for (int i = 0; i < argumentTypes.length; i++) {
/* 649 */       argumentTypes[i].getDescriptor(sb);
/*     */     }
/* 651 */     sb.append(')');
/* 652 */     returnType.getDescriptor(sb);
/* 653 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void getDescriptor(StringBuilder sb)
/*     */   {
/* 664 */     if (this.buf == null)
/*     */     {
/*     */ 
/* 667 */       sb.append((char)((this.off & 0xFF000000) >>> 24));
/* 668 */     } else if (this.sort == 10) {
/* 669 */       sb.append('L');
/* 670 */       sb.append(this.buf, this.off, this.len);
/* 671 */       sb.append(';');
/*     */     } else {
/* 673 */       sb.append(this.buf, this.off, this.len);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getInternalName(Class<?> c)
/*     */   {
/* 692 */     return c.getName().replace('.', '/');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getDescriptor(Class<?> c)
/*     */   {
/* 703 */     StringBuilder sb = new StringBuilder();
/* 704 */     getDescriptor(sb, c);
/* 705 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getConstructorDescriptor(Constructor<?> c)
/*     */   {
/* 716 */     Class<?>[] parameters = c.getParameterTypes();
/* 717 */     StringBuilder sb = new StringBuilder();
/* 718 */     sb.append('(');
/* 719 */     for (int i = 0; i < parameters.length; i++) {
/* 720 */       getDescriptor(sb, parameters[i]);
/*     */     }
/* 722 */     return ")V";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getMethodDescriptor(Method m)
/*     */   {
/* 733 */     Class<?>[] parameters = m.getParameterTypes();
/* 734 */     StringBuilder sb = new StringBuilder();
/* 735 */     sb.append('(');
/* 736 */     for (int i = 0; i < parameters.length; i++) {
/* 737 */       getDescriptor(sb, parameters[i]);
/*     */     }
/* 739 */     sb.append(')');
/* 740 */     getDescriptor(sb, m.getReturnType());
/* 741 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void getDescriptor(StringBuilder sb, Class<?> c)
/*     */   {
/* 753 */     Class<?> d = c;
/*     */     for (;;) {
/* 755 */       if (d.isPrimitive()) { char car;
/*     */         char car;
/* 757 */         if (d == Integer.TYPE) {
/* 758 */           car = 'I'; } else { char car;
/* 759 */           if (d == Void.TYPE) {
/* 760 */             car = 'V'; } else { char car;
/* 761 */             if (d == Boolean.TYPE) {
/* 762 */               car = 'Z'; } else { char car;
/* 763 */               if (d == Byte.TYPE) {
/* 764 */                 car = 'B'; } else { char car;
/* 765 */                 if (d == Character.TYPE) {
/* 766 */                   car = 'C'; } else { char car;
/* 767 */                   if (d == Short.TYPE) {
/* 768 */                     car = 'S'; } else { char car;
/* 769 */                     if (d == Double.TYPE) {
/* 770 */                       car = 'D'; } else { char car;
/* 771 */                       if (d == Float.TYPE) {
/* 772 */                         car = 'F';
/*     */                       } else
/* 774 */                         car = 'J';
/*     */                     } } } } } } }
/* 776 */         sb.append(car);
/* 777 */         return; }
/* 778 */       if (!d.isArray()) break;
/* 779 */       sb.append('[');
/* 780 */       d = d.getComponentType();
/*     */     }
/* 782 */     sb.append('L');
/* 783 */     String name = d.getName();
/* 784 */     int len = name.length();
/* 785 */     for (int i = 0; i < len; i++) {
/* 786 */       char car = name.charAt(i);
/* 787 */       sb.append(car == '.' ? '/' : car);
/*     */     }
/* 789 */     sb.append(';');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSize()
/*     */   {
/* 808 */     return this.buf == null ? this.off & 0xFF : 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOpcode(int opcode)
/*     */   {
/* 824 */     if ((opcode == 46) || (opcode == 79))
/*     */     {
/*     */ 
/* 827 */       return opcode + (this.buf == null ? (this.off & 0xFF00) >> 8 : 4);
/*     */     }
/*     */     
/*     */ 
/* 831 */     return opcode + (this.buf == null ? (this.off & 0xFF0000) >> 16 : 4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 848 */     if (this == o) {
/* 849 */       return true;
/*     */     }
/* 851 */     if (!(o instanceof Type)) {
/* 852 */       return false;
/*     */     }
/* 854 */     Type t = (Type)o;
/* 855 */     if (this.sort != t.sort) {
/* 856 */       return false;
/*     */     }
/* 858 */     if (this.sort >= 9) {
/* 859 */       if (this.len != t.len) {
/* 860 */         return false;
/*     */       }
/* 862 */       int i = this.off;int j = t.off; for (int end = i + this.len; i < end; j++) {
/* 863 */         if (this.buf[i] != t.buf[j]) {
/* 864 */           return false;
/*     */         }
/* 862 */         i++;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 868 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 878 */     int hc = 13 * this.sort;
/* 879 */     if (this.sort >= 9) {
/* 880 */       int i = this.off; for (int end = i + this.len; i < end; i++) {
/* 881 */         hc = 17 * (hc + this.buf[i]);
/*     */       }
/*     */     }
/* 884 */     return hc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 894 */     return getDescriptor();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\asm\Type.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */