/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.UnsupportedCharsetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MimeTypeUtils
/*     */ {
/*  42 */   private static final byte[] BOUNDARY_CHARS = { 45, 95, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  48 */   private static final Random RND = new Random();
/*     */   
/*  50 */   private static Charset US_ASCII = Charset.forName("US-ASCII");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 195 */   public static final MimeType ALL = MimeType.valueOf("*/*");
/* 196 */   public static final String ALL_VALUE = "*/*"; public static final MimeType APPLICATION_ATOM_XML = MimeType.valueOf("application/atom+xml");
/* 197 */   public static final String APPLICATION_ATOM_XML_VALUE = "application/atom+xml"; public static final MimeType APPLICATION_FORM_URLENCODED = MimeType.valueOf("application/x-www-form-urlencoded");
/* 198 */   public static final String APPLICATION_FORM_URLENCODED_VALUE = "application/x-www-form-urlencoded"; public static final MimeType APPLICATION_JSON = MimeType.valueOf("application/json");
/* 199 */   public static final String APPLICATION_JSON_VALUE = "application/json"; public static final MimeType APPLICATION_OCTET_STREAM = MimeType.valueOf("application/octet-stream");
/* 200 */   public static final String APPLICATION_OCTET_STREAM_VALUE = "application/octet-stream"; public static final MimeType APPLICATION_XHTML_XML = MimeType.valueOf("application/xhtml+xml");
/* 201 */   public static final String APPLICATION_XHTML_XML_VALUE = "application/xhtml+xml"; public static final MimeType APPLICATION_XML = MimeType.valueOf("application/xml");
/* 202 */   public static final String APPLICATION_XML_VALUE = "application/xml"; public static final MimeType IMAGE_GIF = MimeType.valueOf("image/gif");
/* 203 */   public static final String IMAGE_GIF_VALUE = "image/gif"; public static final MimeType IMAGE_JPEG = MimeType.valueOf("image/jpeg");
/* 204 */   public static final String IMAGE_JPEG_VALUE = "image/jpeg"; public static final MimeType IMAGE_PNG = MimeType.valueOf("image/png");
/* 205 */   public static final String IMAGE_PNG_VALUE = "image/png"; public static final MimeType MULTIPART_FORM_DATA = MimeType.valueOf("multipart/form-data");
/* 206 */   public static final String MULTIPART_FORM_DATA_VALUE = "multipart/form-data"; public static final MimeType TEXT_HTML = MimeType.valueOf("text/html");
/* 207 */   public static final String TEXT_HTML_VALUE = "text/html"; public static final MimeType TEXT_PLAIN = MimeType.valueOf("text/plain");
/* 208 */   public static final String TEXT_PLAIN_VALUE = "text/plain"; public static final MimeType TEXT_XML = MimeType.valueOf("text/xml");
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String TEXT_XML_VALUE = "text/xml";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MimeType parseMimeType(String mimeType)
/*     */   {
/* 219 */     if (!StringUtils.hasLength(mimeType)) {
/* 220 */       throw new InvalidMimeTypeException(mimeType, "'mimeType' must not be empty");
/*     */     }
/* 222 */     String[] parts = StringUtils.tokenizeToStringArray(mimeType, ";");
/* 223 */     if (parts.length == 0) {
/* 224 */       throw new InvalidMimeTypeException(mimeType, "'mimeType' must not be empty");
/*     */     }
/*     */     
/* 227 */     String fullType = parts[0].trim();
/*     */     
/* 229 */     if ("*".equals(fullType)) {
/* 230 */       fullType = "*/*";
/*     */     }
/* 232 */     int subIndex = fullType.indexOf('/');
/* 233 */     if (subIndex == -1) {
/* 234 */       throw new InvalidMimeTypeException(mimeType, "does not contain '/'");
/*     */     }
/* 236 */     if (subIndex == fullType.length() - 1) {
/* 237 */       throw new InvalidMimeTypeException(mimeType, "does not contain subtype after '/'");
/*     */     }
/* 239 */     String type = fullType.substring(0, subIndex);
/* 240 */     String subtype = fullType.substring(subIndex + 1, fullType.length());
/* 241 */     if (("*".equals(type)) && (!"*".equals(subtype))) {
/* 242 */       throw new InvalidMimeTypeException(mimeType, "wildcard type is legal only in '*/*' (all mime types)");
/*     */     }
/*     */     
/* 245 */     Map<String, String> parameters = null;
/* 246 */     if (parts.length > 1) {
/* 247 */       parameters = new LinkedHashMap(parts.length - 1);
/* 248 */       for (int i = 1; i < parts.length; i++) {
/* 249 */         String parameter = parts[i];
/* 250 */         int eqIndex = parameter.indexOf('=');
/* 251 */         if (eqIndex != -1) {
/* 252 */           String attribute = parameter.substring(0, eqIndex);
/* 253 */           String value = parameter.substring(eqIndex + 1, parameter.length());
/* 254 */           parameters.put(attribute, value);
/*     */         }
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 260 */       return new MimeType(type, subtype, parameters);
/*     */     }
/*     */     catch (UnsupportedCharsetException ex) {
/* 263 */       throw new InvalidMimeTypeException(mimeType, "unsupported charset '" + ex.getCharsetName() + "'");
/*     */     }
/*     */     catch (IllegalArgumentException ex) {
/* 266 */       throw new InvalidMimeTypeException(mimeType, ex.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<MimeType> parseMimeTypes(String mimeTypes)
/*     */   {
/* 277 */     if (!StringUtils.hasLength(mimeTypes)) {
/* 278 */       return Collections.emptyList();
/*     */     }
/* 280 */     String[] tokens = mimeTypes.split(",\\s*");
/* 281 */     List<MimeType> result = new ArrayList(tokens.length);
/* 282 */     for (String token : tokens) {
/* 283 */       result.add(parseMimeType(token));
/*     */     }
/* 285 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toString(Collection<? extends MimeType> mimeTypes)
/*     */   {
/* 295 */     StringBuilder builder = new StringBuilder();
/* 296 */     for (Iterator<? extends MimeType> iterator = mimeTypes.iterator(); iterator.hasNext();) {
/* 297 */       MimeType mimeType = (MimeType)iterator.next();
/* 298 */       mimeType.appendTo(builder);
/* 299 */       if (iterator.hasNext()) {
/* 300 */         builder.append(", ");
/*     */       }
/*     */     }
/* 303 */     return builder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void sortBySpecificity(List<MimeType> mimeTypes)
/*     */   {
/* 332 */     Assert.notNull(mimeTypes, "'mimeTypes' must not be null");
/* 333 */     if (mimeTypes.size() > 1) {
/* 334 */       Collections.sort(mimeTypes, SPECIFICITY_COMPARATOR);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static byte[] generateMultipartBoundary()
/*     */   {
/* 342 */     byte[] boundary = new byte[RND.nextInt(11) + 30];
/* 343 */     for (int i = 0; i < boundary.length; i++) {
/* 344 */       boundary[i] = BOUNDARY_CHARS[RND.nextInt(BOUNDARY_CHARS.length)];
/*     */     }
/* 346 */     return boundary;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String generateMultipartBoundaryString()
/*     */   {
/* 353 */     return new String(generateMultipartBoundary(), US_ASCII);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 361 */   public static final Comparator<MimeType> SPECIFICITY_COMPARATOR = new MimeType.SpecificityComparator();
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\util\MimeTypeUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */