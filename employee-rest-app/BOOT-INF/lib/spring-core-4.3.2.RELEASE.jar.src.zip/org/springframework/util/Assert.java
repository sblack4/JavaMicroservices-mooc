/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Assert
/*     */ {
/*     */   public static void isTrue(boolean expression, String message)
/*     */   {
/*  67 */     if (!expression) {
/*  68 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void isTrue(boolean expression)
/*     */   {
/*  80 */     isTrue(expression, "[Assertion failed] - this expression must be true");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void isNull(Object object, String message)
/*     */   {
/*  91 */     if (object != null) {
/*  92 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void isNull(Object object)
/*     */   {
/* 103 */     isNull(object, "[Assertion failed] - the object argument must be null");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void notNull(Object object, String message)
/*     */   {
/* 114 */     if (object == null) {
/* 115 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void notNull(Object object)
/*     */   {
/* 126 */     notNull(object, "[Assertion failed] - this argument is required; it must not be null");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void hasLength(String text, String message)
/*     */   {
/* 139 */     if (!StringUtils.hasLength(text)) {
/* 140 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void hasLength(String text)
/*     */   {
/* 153 */     hasLength(text, "[Assertion failed] - this String argument must have length; it must not be null or empty");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void hasText(String text, String message)
/*     */   {
/* 167 */     if (!StringUtils.hasText(text)) {
/* 168 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void hasText(String text)
/*     */   {
/* 181 */     hasText(text, "[Assertion failed] - this String argument must have text; it must not be null, empty, or blank");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void doesNotContain(String textToSearch, String substring, String message)
/*     */   {
/* 194 */     if ((StringUtils.hasLength(textToSearch)) && (StringUtils.hasLength(substring)) && 
/* 195 */       (textToSearch.contains(substring))) {
/* 196 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void doesNotContain(String textToSearch, String substring)
/*     */   {
/* 208 */     doesNotContain(textToSearch, substring, "[Assertion failed] - this String argument must not contain the substring [" + substring + "]");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void notEmpty(Object[] array, String message)
/*     */   {
/* 221 */     if (ObjectUtils.isEmpty(array)) {
/* 222 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void notEmpty(Object[] array)
/*     */   {
/* 234 */     notEmpty(array, "[Assertion failed] - this array must not be empty: it must contain at least 1 element");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void noNullElements(Object[] array, String message)
/*     */   {
/* 246 */     if (array != null) {
/* 247 */       for (Object element : array) {
/* 248 */         if (element == null) {
/* 249 */           throw new IllegalArgumentException(message);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void noNullElements(Object[] array)
/*     */   {
/* 263 */     noNullElements(array, "[Assertion failed] - this array must not contain any null elements");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void notEmpty(Collection<?> collection, String message)
/*     */   {
/* 275 */     if (CollectionUtils.isEmpty(collection)) {
/* 276 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void notEmpty(Collection<?> collection)
/*     */   {
/* 288 */     notEmpty(collection, "[Assertion failed] - this collection must not be empty: it must contain at least 1 element");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void notEmpty(Map<?, ?> map, String message)
/*     */   {
/* 301 */     if (CollectionUtils.isEmpty(map)) {
/* 302 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void notEmpty(Map<?, ?> map)
/*     */   {
/* 314 */     notEmpty(map, "[Assertion failed] - this map must not be empty; it must contain at least one entry");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void isInstanceOf(Class<?> clazz, Object obj)
/*     */   {
/* 326 */     isInstanceOf(clazz, obj, "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void isInstanceOf(Class<?> type, Object obj, String message)
/*     */   {
/* 342 */     notNull(type, "Type to check against must not be null");
/* 343 */     if (!type.isInstance(obj))
/*     */     {
/*     */ 
/* 346 */       throw new IllegalArgumentException((StringUtils.hasLength(message) ? message + " " : "") + "Object of class [" + (obj != null ? obj.getClass().getName() : "null") + "] must be an instance of " + type);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void isAssignable(Class<?> superType, Class<?> subType)
/*     */   {
/* 359 */     isAssignable(superType, subType, "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void isAssignable(Class<?> superType, Class<?> subType, String message)
/*     */   {
/* 374 */     notNull(superType, "Type to check against must not be null");
/* 375 */     if ((subType == null) || (!superType.isAssignableFrom(subType))) {
/* 376 */       throw new IllegalArgumentException((StringUtils.hasLength(message) ? message + " " : "") + subType + " is not assignable to " + superType);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void state(boolean expression, String message)
/*     */   {
/* 391 */     if (!expression) {
/* 392 */       throw new IllegalStateException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void state(boolean expression)
/*     */   {
/* 406 */     state(expression, "[Assertion failed] - this state invariant must be true");
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\util\Assert.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */