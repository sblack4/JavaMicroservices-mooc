/*     */ package org.springframework.util.xml;
/*     */ 
/*     */ import javax.xml.stream.XMLEventWriter;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.transform.sax.SAXResult;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.ext.LexicalHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StaxResult
/*     */   extends SAXResult
/*     */ {
/*     */   private XMLEventWriter eventWriter;
/*     */   private XMLStreamWriter streamWriter;
/*     */   
/*     */   public StaxResult(XMLStreamWriter streamWriter)
/*     */   {
/*  59 */     StaxStreamHandler handler = new StaxStreamHandler(streamWriter);
/*  60 */     super.setHandler(handler);
/*  61 */     super.setLexicalHandler(handler);
/*  62 */     this.streamWriter = streamWriter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public StaxResult(XMLEventWriter eventWriter)
/*     */   {
/*  70 */     StaxEventHandler handler = new StaxEventHandler(eventWriter);
/*  71 */     super.setHandler(handler);
/*  72 */     super.setLexicalHandler(handler);
/*  73 */     this.eventWriter = eventWriter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLEventWriter getXMLEventWriter()
/*     */   {
/*  84 */     return this.eventWriter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLStreamWriter getXMLStreamWriter()
/*     */   {
/*  94 */     return this.streamWriter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHandler(ContentHandler handler)
/*     */   {
/* 104 */     throw new UnsupportedOperationException("setHandler is not supported");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLexicalHandler(LexicalHandler handler)
/*     */   {
/* 113 */     throw new UnsupportedOperationException("setLexicalHandler is not supported");
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\util\xml\StaxResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */