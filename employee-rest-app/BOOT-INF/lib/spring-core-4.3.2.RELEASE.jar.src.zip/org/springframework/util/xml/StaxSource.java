/*     */ package org.springframework.util.xml;
/*     */ 
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.XMLReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StaxSource
/*     */   extends SAXSource
/*     */ {
/*     */   private XMLEventReader eventReader;
/*     */   private XMLStreamReader streamReader;
/*     */   
/*     */   StaxSource(XMLStreamReader streamReader)
/*     */   {
/*  61 */     super(new StaxStreamXMLReader(streamReader), new InputSource());
/*  62 */     this.streamReader = streamReader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   StaxSource(XMLEventReader eventReader)
/*     */   {
/*  73 */     super(new StaxEventXMLReader(eventReader), new InputSource());
/*  74 */     this.eventReader = eventReader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   XMLEventReader getXMLEventReader()
/*     */   {
/*  85 */     return this.eventReader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   XMLStreamReader getXMLStreamReader()
/*     */   {
/*  95 */     return this.streamReader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInputSource(InputSource inputSource)
/*     */   {
/* 105 */     throw new UnsupportedOperationException("setInputSource is not supported");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXMLReader(XMLReader reader)
/*     */   {
/* 114 */     throw new UnsupportedOperationException("setXMLReader is not supported");
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\util\xml\StaxSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */