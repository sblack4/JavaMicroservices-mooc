/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodInvoker
/*     */ {
/*     */   private Class<?> targetClass;
/*     */   private Object targetObject;
/*     */   private String targetMethod;
/*     */   private String staticMethod;
/*  47 */   private Object[] arguments = new Object[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Method methodObject;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTargetClass(Class<?> targetClass)
/*     */   {
/*  61 */     this.targetClass = targetClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Class<?> getTargetClass()
/*     */   {
/*  68 */     return this.targetClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTargetObject(Object targetObject)
/*     */   {
/*  79 */     this.targetObject = targetObject;
/*  80 */     if (targetObject != null) {
/*  81 */       this.targetClass = targetObject.getClass();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getTargetObject()
/*     */   {
/*  89 */     return this.targetObject;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTargetMethod(String targetMethod)
/*     */   {
/* 100 */     this.targetMethod = targetMethod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getTargetMethod()
/*     */   {
/* 107 */     return this.targetMethod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStaticMethod(String staticMethod)
/*     */   {
/* 118 */     this.staticMethod = staticMethod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setArguments(Object[] arguments)
/*     */   {
/* 126 */     this.arguments = (arguments != null ? arguments : new Object[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object[] getArguments()
/*     */   {
/* 133 */     return this.arguments;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prepare()
/*     */     throws ClassNotFoundException, NoSuchMethodException
/*     */   {
/* 144 */     if (this.staticMethod != null) {
/* 145 */       int lastDotIndex = this.staticMethod.lastIndexOf('.');
/* 146 */       if ((lastDotIndex == -1) || (lastDotIndex == this.staticMethod.length())) {
/* 147 */         throw new IllegalArgumentException("staticMethod must be a fully qualified class plus method name: e.g. 'example.MyExampleClass.myExampleMethod'");
/*     */       }
/*     */       
/*     */ 
/* 151 */       String className = this.staticMethod.substring(0, lastDotIndex);
/* 152 */       String methodName = this.staticMethod.substring(lastDotIndex + 1);
/* 153 */       this.targetClass = resolveClassName(className);
/* 154 */       this.targetMethod = methodName;
/*     */     }
/*     */     
/* 157 */     Class<?> targetClass = getTargetClass();
/* 158 */     String targetMethod = getTargetMethod();
/* 159 */     if (targetClass == null) {
/* 160 */       throw new IllegalArgumentException("Either 'targetClass' or 'targetObject' is required");
/*     */     }
/* 162 */     if (targetMethod == null) {
/* 163 */       throw new IllegalArgumentException("Property 'targetMethod' is required");
/*     */     }
/*     */     
/* 166 */     Object[] arguments = getArguments();
/* 167 */     Class<?>[] argTypes = new Class[arguments.length];
/* 168 */     for (int i = 0; i < arguments.length; i++) {
/* 169 */       argTypes[i] = (arguments[i] != null ? arguments[i].getClass() : Object.class);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 174 */       this.methodObject = targetClass.getMethod(targetMethod, argTypes);
/*     */     }
/*     */     catch (NoSuchMethodException ex)
/*     */     {
/* 178 */       this.methodObject = findMatchingMethod();
/* 179 */       if (this.methodObject == null) {
/* 180 */         throw ex;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Class<?> resolveClassName(String className)
/*     */     throws ClassNotFoundException
/*     */   {
/* 194 */     return ClassUtils.forName(className, ClassUtils.getDefaultClassLoader());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Method findMatchingMethod()
/*     */   {
/* 205 */     String targetMethod = getTargetMethod();
/* 206 */     Object[] arguments = getArguments();
/* 207 */     int argCount = arguments.length;
/*     */     
/* 209 */     Method[] candidates = ReflectionUtils.getAllDeclaredMethods(getTargetClass());
/* 210 */     int minTypeDiffWeight = Integer.MAX_VALUE;
/* 211 */     Method matchingMethod = null;
/*     */     
/* 213 */     for (Method candidate : candidates) {
/* 214 */       if (candidate.getName().equals(targetMethod)) {
/* 215 */         Class<?>[] paramTypes = candidate.getParameterTypes();
/* 216 */         if (paramTypes.length == argCount) {
/* 217 */           int typeDiffWeight = getTypeDifferenceWeight(paramTypes, arguments);
/* 218 */           if (typeDiffWeight < minTypeDiffWeight) {
/* 219 */             minTypeDiffWeight = typeDiffWeight;
/* 220 */             matchingMethod = candidate;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 226 */     return matchingMethod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Method getPreparedMethod()
/*     */     throws IllegalStateException
/*     */   {
/* 238 */     if (this.methodObject == null) {
/* 239 */       throw new IllegalStateException("prepare() must be called prior to invoke() on MethodInvoker");
/*     */     }
/* 241 */     return this.methodObject;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPrepared()
/*     */   {
/* 249 */     return this.methodObject != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke()
/*     */     throws InvocationTargetException, IllegalAccessException
/*     */   {
/* 263 */     Object targetObject = getTargetObject();
/* 264 */     Method preparedMethod = getPreparedMethod();
/* 265 */     if ((targetObject == null) && (!Modifier.isStatic(preparedMethod.getModifiers()))) {
/* 266 */       throw new IllegalArgumentException("Target method must not be non-static without a target");
/*     */     }
/* 268 */     ReflectionUtils.makeAccessible(preparedMethod);
/* 269 */     return preparedMethod.invoke(targetObject, getArguments());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getTypeDifferenceWeight(Class<?>[] paramTypes, Object[] args)
/*     */   {
/* 294 */     int result = 0;
/* 295 */     for (int i = 0; i < paramTypes.length; i++) {
/* 296 */       if (!ClassUtils.isAssignableValue(paramTypes[i], args[i])) {
/* 297 */         return Integer.MAX_VALUE;
/*     */       }
/* 299 */       if (args[i] != null) {
/* 300 */         Class<?> paramType = paramTypes[i];
/* 301 */         Class<?> superClass = args[i].getClass().getSuperclass();
/* 302 */         while (superClass != null) {
/* 303 */           if (paramType.equals(superClass)) {
/* 304 */             result += 2;
/* 305 */             superClass = null;
/*     */           }
/* 307 */           else if (ClassUtils.isAssignable(paramType, superClass)) {
/* 308 */             result += 2;
/* 309 */             superClass = superClass.getSuperclass();
/*     */           }
/*     */           else {
/* 312 */             superClass = null;
/*     */           }
/*     */         }
/* 315 */         if (paramType.isInterface()) {
/* 316 */           result += 1;
/*     */         }
/*     */       }
/*     */     }
/* 320 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\util\MethodInvoker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */