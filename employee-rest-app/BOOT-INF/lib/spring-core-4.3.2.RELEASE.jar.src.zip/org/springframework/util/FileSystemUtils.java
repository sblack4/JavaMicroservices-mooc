/*    */ package org.springframework.util;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FileSystemUtils
/*    */ {
/*    */   public static boolean deleteRecursively(File root)
/*    */   {
/* 39 */     if ((root != null) && (root.exists())) {
/* 40 */       if (root.isDirectory()) {
/* 41 */         File[] children = root.listFiles();
/* 42 */         if (children != null) {
/* 43 */           for (File child : children) {
/* 44 */             deleteRecursively(child);
/*    */           }
/*    */         }
/*    */       }
/* 48 */       return root.delete();
/*    */     }
/* 50 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void copyRecursively(File src, File dest)
/*    */     throws IOException
/*    */   {
/* 61 */     Assert.isTrue((src != null) && ((src.isDirectory()) || (src.isFile())), "Source File must denote a directory or file");
/* 62 */     Assert.notNull(dest, "Destination File must not be null");
/* 63 */     doCopyRecursively(src, dest);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static void doCopyRecursively(File src, File dest)
/*    */     throws IOException
/*    */   {
/* 74 */     if (src.isDirectory()) {
/* 75 */       dest.mkdir();
/* 76 */       File[] entries = src.listFiles();
/* 77 */       if (entries == null) {
/* 78 */         throw new IOException("Could not list files in directory: " + src);
/*    */       }
/* 80 */       for (File entry : entries) {
/* 81 */         doCopyRecursively(entry, new File(dest, entry.getName()));
/*    */       }
/*    */     }
/* 84 */     else if (src.isFile()) {
/*    */       try {
/* 86 */         dest.createNewFile();
/*    */       }
/*    */       catch (IOException ex) {
/* 89 */         IOException ioex = new IOException("Failed to create file: " + dest);
/* 90 */         ioex.initCause(ex);
/* 91 */         throw ioex;
/*    */       }
/* 93 */       FileCopyUtils.copy(src, dest);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\util\FileSystemUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */