/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstanceFilter<T>
/*     */ {
/*     */   private final Collection<? extends T> includes;
/*     */   private final Collection<? extends T> excludes;
/*     */   private final boolean matchIfEmpty;
/*     */   
/*     */   public InstanceFilter(Collection<? extends T> includes, Collection<? extends T> excludes, boolean matchIfEmpty)
/*     */   {
/*  57 */     this.includes = (includes != null ? includes : Collections.emptyList());
/*  58 */     this.excludes = (excludes != null ? excludes : Collections.emptyList());
/*  59 */     this.matchIfEmpty = matchIfEmpty;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean match(T instance)
/*     */   {
/*  67 */     Assert.notNull(instance, "The instance to match is mandatory");
/*     */     
/*  69 */     boolean includesSet = !this.includes.isEmpty();
/*  70 */     boolean excludesSet = !this.excludes.isEmpty();
/*  71 */     if ((!includesSet) && (!excludesSet)) {
/*  72 */       return this.matchIfEmpty;
/*     */     }
/*     */     
/*  75 */     boolean matchIncludes = match(instance, this.includes);
/*  76 */     boolean matchExcludes = match(instance, this.excludes);
/*     */     
/*  78 */     if (!includesSet) {
/*  79 */       return !matchExcludes;
/*     */     }
/*     */     
/*  82 */     if (!excludesSet) {
/*  83 */       return matchIncludes;
/*     */     }
/*  85 */     return (matchIncludes) && (!matchExcludes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean match(T instance, T candidate)
/*     */   {
/*  96 */     return instance.equals(candidate);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean match(T instance, Collection<? extends T> candidates)
/*     */   {
/* 107 */     for (T candidate : candidates) {
/* 108 */       if (match(instance, candidate)) {
/* 109 */         return true;
/*     */       }
/*     */     }
/* 112 */     return false;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 117 */     StringBuilder sb = new StringBuilder(getClass().getSimpleName());
/* 118 */     sb.append(": includes=").append(this.includes);
/* 119 */     sb.append(", excludes=").append(this.excludes);
/* 120 */     sb.append(", matchIfEmpty=").append(this.matchIfEmpty);
/* 121 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\util\InstanceFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */