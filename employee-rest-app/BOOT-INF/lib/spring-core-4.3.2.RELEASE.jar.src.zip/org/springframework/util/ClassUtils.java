/*      */ package org.springframework.util;
/*      */ 
/*      */ import java.beans.Introspector;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.lang.reflect.Proxy;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.IdentityHashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class ClassUtils
/*      */ {
/*      */   public static final String ARRAY_SUFFIX = "[]";
/*      */   private static final String INTERNAL_ARRAY_PREFIX = "[";
/*      */   private static final String NON_PRIMITIVE_ARRAY_PREFIX = "[L";
/*      */   private static final char PACKAGE_SEPARATOR = '.';
/*      */   private static final char PATH_SEPARATOR = '/';
/*      */   private static final char INNER_CLASS_SEPARATOR = '$';
/*      */   public static final String CGLIB_CLASS_SEPARATOR = "$$";
/*      */   public static final String CLASS_FILE_SUFFIX = ".class";
/*   79 */   private static final Map<Class<?>, Class<?>> primitiveWrapperTypeMap = new IdentityHashMap(8);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   85 */   private static final Map<Class<?>, Class<?>> primitiveTypeToWrapperMap = new IdentityHashMap(8);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   91 */   private static final Map<String, Class<?>> primitiveTypeNameMap = new HashMap(32);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   97 */   private static final Map<String, Class<?>> commonClassCache = new HashMap(32);
/*      */   
/*      */   static
/*      */   {
/*  101 */     primitiveWrapperTypeMap.put(Boolean.class, Boolean.TYPE);
/*  102 */     primitiveWrapperTypeMap.put(Byte.class, Byte.TYPE);
/*  103 */     primitiveWrapperTypeMap.put(Character.class, Character.TYPE);
/*  104 */     primitiveWrapperTypeMap.put(Double.class, Double.TYPE);
/*  105 */     primitiveWrapperTypeMap.put(Float.class, Float.TYPE);
/*  106 */     primitiveWrapperTypeMap.put(Integer.class, Integer.TYPE);
/*  107 */     primitiveWrapperTypeMap.put(Long.class, Long.TYPE);
/*  108 */     primitiveWrapperTypeMap.put(Short.class, Short.TYPE);
/*      */     
/*  110 */     for (Iterator localIterator = primitiveWrapperTypeMap.entrySet().iterator(); localIterator.hasNext();) { entry = (Map.Entry)localIterator.next();
/*  111 */       primitiveTypeToWrapperMap.put(entry.getValue(), entry.getKey());
/*  112 */       registerCommonClasses(new Class[] { (Class)entry.getKey() });
/*      */     }
/*      */     Map.Entry<Class<?>, Class<?>> entry;
/*  115 */     Object primitiveTypes = new HashSet(32);
/*  116 */     ((Set)primitiveTypes).addAll(primitiveWrapperTypeMap.values());
/*  117 */     ((Set)primitiveTypes).addAll(Arrays.asList(new Class[] { boolean[].class, byte[].class, char[].class, double[].class, float[].class, int[].class, long[].class, short[].class }));
/*      */     
/*      */ 
/*  120 */     ((Set)primitiveTypes).add(Void.TYPE);
/*  121 */     for (Class<?> primitiveType : (Set)primitiveTypes) {
/*  122 */       primitiveTypeNameMap.put(primitiveType.getName(), primitiveType);
/*      */     }
/*      */     
/*  125 */     registerCommonClasses(new Class[] { Boolean[].class, Byte[].class, Character[].class, Double[].class, Float[].class, Integer[].class, Long[].class, Short[].class });
/*      */     
/*  127 */     registerCommonClasses(new Class[] { Number.class, Number[].class, String.class, String[].class, Object.class, Object[].class, Class.class, Class[].class });
/*      */     
/*  129 */     registerCommonClasses(new Class[] { Throwable.class, Exception.class, RuntimeException.class, Error.class, StackTraceElement.class, StackTraceElement[].class });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void registerCommonClasses(Class<?>... commonClasses)
/*      */   {
/*  138 */     for (Class<?> clazz : commonClasses) {
/*  139 */       commonClassCache.put(clazz.getName(), clazz);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ClassLoader getDefaultClassLoader()
/*      */   {
/*  158 */     ClassLoader cl = null;
/*      */     try {
/*  160 */       cl = Thread.currentThread().getContextClassLoader();
/*      */     }
/*      */     catch (Throwable localThrowable) {}
/*      */     
/*      */ 
/*  165 */     if (cl == null)
/*      */     {
/*  167 */       cl = ClassUtils.class.getClassLoader();
/*  168 */       if (cl == null) {
/*      */         try
/*      */         {
/*  171 */           cl = ClassLoader.getSystemClassLoader();
/*      */         }
/*      */         catch (Throwable localThrowable1) {}
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  178 */     return cl;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ClassLoader overrideThreadContextClassLoader(ClassLoader classLoaderToUse)
/*      */   {
/*  189 */     Thread currentThread = Thread.currentThread();
/*  190 */     ClassLoader threadContextClassLoader = currentThread.getContextClassLoader();
/*  191 */     if ((classLoaderToUse != null) && (!classLoaderToUse.equals(threadContextClassLoader))) {
/*  192 */       currentThread.setContextClassLoader(classLoaderToUse);
/*  193 */       return threadContextClassLoader;
/*      */     }
/*      */     
/*  196 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<?> forName(String name, ClassLoader classLoader)
/*      */     throws ClassNotFoundException, LinkageError
/*      */   {
/*  214 */     Assert.notNull(name, "Name must not be null");
/*      */     
/*  216 */     Class<?> clazz = resolvePrimitiveClassName(name);
/*  217 */     if (clazz == null) {
/*  218 */       clazz = (Class)commonClassCache.get(name);
/*      */     }
/*  220 */     if (clazz != null) {
/*  221 */       return clazz;
/*      */     }
/*      */     
/*      */ 
/*  225 */     if (name.endsWith("[]")) {
/*  226 */       String elementClassName = name.substring(0, name.length() - "[]".length());
/*  227 */       Class<?> elementClass = forName(elementClassName, classLoader);
/*  228 */       return Array.newInstance(elementClass, 0).getClass();
/*      */     }
/*      */     
/*      */ 
/*  232 */     if ((name.startsWith("[L")) && (name.endsWith(";"))) {
/*  233 */       String elementName = name.substring("[L".length(), name.length() - 1);
/*  234 */       Class<?> elementClass = forName(elementName, classLoader);
/*  235 */       return Array.newInstance(elementClass, 0).getClass();
/*      */     }
/*      */     
/*      */ 
/*  239 */     if (name.startsWith("[")) {
/*  240 */       String elementName = name.substring("[".length());
/*  241 */       Class<?> elementClass = forName(elementName, classLoader);
/*  242 */       return Array.newInstance(elementClass, 0).getClass();
/*      */     }
/*      */     
/*  245 */     ClassLoader clToUse = classLoader;
/*  246 */     if (clToUse == null) {
/*  247 */       clToUse = getDefaultClassLoader();
/*      */     }
/*      */     try {
/*  250 */       return clToUse != null ? clToUse.loadClass(name) : Class.forName(name);
/*      */     }
/*      */     catch (ClassNotFoundException ex) {
/*  253 */       int lastDotIndex = name.lastIndexOf('.');
/*  254 */       if (lastDotIndex != -1)
/*      */       {
/*  256 */         String innerClassName = name.substring(0, lastDotIndex) + '$' + name.substring(lastDotIndex + 1);
/*      */         try {
/*  258 */           return clToUse != null ? clToUse.loadClass(innerClassName) : Class.forName(innerClassName);
/*      */         }
/*      */         catch (ClassNotFoundException localClassNotFoundException1) {}
/*      */       }
/*      */       
/*      */ 
/*  264 */       throw ex;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<?> resolveClassName(String className, ClassLoader classLoader)
/*      */     throws IllegalArgumentException
/*      */   {
/*      */     try
/*      */     {
/*  284 */       return forName(className, classLoader);
/*      */     }
/*      */     catch (ClassNotFoundException ex) {
/*  287 */       throw new IllegalArgumentException("Cannot find class [" + className + "]", ex);
/*      */     }
/*      */     catch (LinkageError ex) {
/*  290 */       throw new IllegalArgumentException("Error loading class [" + className + "]: problem with class file or dependent class.", ex);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<?> resolvePrimitiveClassName(String name)
/*      */   {
/*  306 */     Class<?> result = null;
/*      */     
/*      */ 
/*  309 */     if ((name != null) && (name.length() <= 8))
/*      */     {
/*  311 */       result = (Class)primitiveTypeNameMap.get(name);
/*      */     }
/*  313 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isPresent(String className, ClassLoader classLoader)
/*      */   {
/*      */     try
/*      */     {
/*  327 */       forName(className, classLoader);
/*  328 */       return true;
/*      */     }
/*      */     catch (Throwable ex) {}
/*      */     
/*  332 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<?> getUserClass(Object instance)
/*      */   {
/*  344 */     Assert.notNull(instance, "Instance must not be null");
/*  345 */     return getUserClass(instance.getClass());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<?> getUserClass(Class<?> clazz)
/*      */   {
/*  355 */     if ((clazz != null) && (clazz.getName().contains("$$"))) {
/*  356 */       Class<?> superclass = clazz.getSuperclass();
/*  357 */       if ((superclass != null) && (Object.class != superclass)) {
/*  358 */         return superclass;
/*      */       }
/*      */     }
/*  361 */     return clazz;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isCacheSafe(Class<?> clazz, ClassLoader classLoader)
/*      */   {
/*  371 */     Assert.notNull(clazz, "Class must not be null");
/*      */     try {
/*  373 */       ClassLoader target = clazz.getClassLoader();
/*  374 */       if (target == null) {
/*  375 */         return true;
/*      */       }
/*  377 */       ClassLoader cur = classLoader;
/*  378 */       if (cur == target) {
/*  379 */         return true;
/*      */       }
/*  381 */       while (cur != null) {
/*  382 */         cur = cur.getParent();
/*  383 */         if (cur == target) {
/*  384 */           return true;
/*      */         }
/*      */       }
/*  387 */       return false;
/*      */     }
/*      */     catch (SecurityException ex) {}
/*      */     
/*  391 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getShortName(String className)
/*      */   {
/*  403 */     Assert.hasLength(className, "Class name must not be empty");
/*  404 */     int lastDotIndex = className.lastIndexOf('.');
/*  405 */     int nameEndIndex = className.indexOf("$$");
/*  406 */     if (nameEndIndex == -1) {
/*  407 */       nameEndIndex = className.length();
/*      */     }
/*  409 */     String shortName = className.substring(lastDotIndex + 1, nameEndIndex);
/*  410 */     shortName = shortName.replace('$', '.');
/*  411 */     return shortName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getShortName(Class<?> clazz)
/*      */   {
/*  420 */     return getShortName(getQualifiedName(clazz));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getShortNameAsProperty(Class<?> clazz)
/*      */   {
/*  431 */     String shortName = getShortName(clazz);
/*  432 */     int dotIndex = shortName.lastIndexOf('.');
/*  433 */     shortName = dotIndex != -1 ? shortName.substring(dotIndex + 1) : shortName;
/*  434 */     return Introspector.decapitalize(shortName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getClassFileName(Class<?> clazz)
/*      */   {
/*  444 */     Assert.notNull(clazz, "Class must not be null");
/*  445 */     String className = clazz.getName();
/*  446 */     int lastDotIndex = className.lastIndexOf('.');
/*  447 */     return className.substring(lastDotIndex + 1) + ".class";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getPackageName(Class<?> clazz)
/*      */   {
/*  458 */     Assert.notNull(clazz, "Class must not be null");
/*  459 */     return getPackageName(clazz.getName());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getPackageName(String fqClassName)
/*      */   {
/*  470 */     Assert.notNull(fqClassName, "Class name must not be null");
/*  471 */     int lastDotIndex = fqClassName.lastIndexOf('.');
/*  472 */     return lastDotIndex != -1 ? fqClassName.substring(0, lastDotIndex) : "";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getQualifiedName(Class<?> clazz)
/*      */   {
/*  482 */     Assert.notNull(clazz, "Class must not be null");
/*  483 */     if (clazz.isArray()) {
/*  484 */       return getQualifiedNameForArray(clazz);
/*      */     }
/*      */     
/*  487 */     return clazz.getName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String getQualifiedNameForArray(Class<?> clazz)
/*      */   {
/*  498 */     StringBuilder result = new StringBuilder();
/*  499 */     while (clazz.isArray()) {
/*  500 */       clazz = clazz.getComponentType();
/*  501 */       result.append("[]");
/*      */     }
/*  503 */     result.insert(0, clazz.getName());
/*  504 */     return result.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getQualifiedMethodName(Method method)
/*      */   {
/*  514 */     Assert.notNull(method, "Method must not be null");
/*  515 */     return method.getDeclaringClass().getName() + "." + method.getName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getDescriptiveType(Object value)
/*      */   {
/*  526 */     if (value == null) {
/*  527 */       return null;
/*      */     }
/*  529 */     Class<?> clazz = value.getClass();
/*  530 */     if (Proxy.isProxyClass(clazz)) {
/*  531 */       StringBuilder result = new StringBuilder(clazz.getName());
/*  532 */       result.append(" implementing ");
/*  533 */       Class<?>[] ifcs = clazz.getInterfaces();
/*  534 */       for (int i = 0; i < ifcs.length; i++) {
/*  535 */         result.append(ifcs[i].getName());
/*  536 */         if (i < ifcs.length - 1) {
/*  537 */           result.append(',');
/*      */         }
/*      */       }
/*  540 */       return result.toString();
/*      */     }
/*  542 */     if (clazz.isArray()) {
/*  543 */       return getQualifiedNameForArray(clazz);
/*      */     }
/*      */     
/*  546 */     return clazz.getName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean matchesTypeName(Class<?> clazz, String typeName)
/*      */   {
/*  558 */     return (typeName != null) && ((typeName.equals(clazz.getName())) || (typeName.equals(clazz.getSimpleName())) || ((clazz.isArray()) && (typeName.equals(getQualifiedNameForArray(clazz)))));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean hasConstructor(Class<?> clazz, Class<?>... paramTypes)
/*      */   {
/*  571 */     return getConstructorIfAvailable(clazz, paramTypes) != null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <T> Constructor<T> getConstructorIfAvailable(Class<T> clazz, Class<?>... paramTypes)
/*      */   {
/*  584 */     Assert.notNull(clazz, "Class must not be null");
/*      */     try {
/*  586 */       return clazz.getConstructor(paramTypes);
/*      */     }
/*      */     catch (NoSuchMethodException ex) {}
/*  589 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean hasMethod(Class<?> clazz, String methodName, Class<?>... paramTypes)
/*      */   {
/*  603 */     return getMethodIfAvailable(clazz, methodName, paramTypes) != null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Method getMethod(Class<?> clazz, String methodName, Class<?>... paramTypes)
/*      */   {
/*  621 */     Assert.notNull(clazz, "Class must not be null");
/*  622 */     Assert.notNull(methodName, "Method name must not be null");
/*  623 */     if (paramTypes != null) {
/*      */       try {
/*  625 */         return clazz.getMethod(methodName, paramTypes);
/*      */       }
/*      */       catch (NoSuchMethodException ex) {
/*  628 */         throw new IllegalStateException("Expected method not found: " + ex);
/*      */       }
/*      */     }
/*      */     
/*  632 */     Set<Method> candidates = new HashSet(1);
/*  633 */     Method[] methods = clazz.getMethods();
/*  634 */     for (Method method : methods) {
/*  635 */       if (methodName.equals(method.getName())) {
/*  636 */         candidates.add(method);
/*      */       }
/*      */     }
/*  639 */     if (candidates.size() == 1) {
/*  640 */       return (Method)candidates.iterator().next();
/*      */     }
/*  642 */     if (candidates.isEmpty()) {
/*  643 */       throw new IllegalStateException("Expected method not found: " + clazz + "." + methodName);
/*      */     }
/*      */     
/*  646 */     throw new IllegalStateException("No unique method found: " + clazz + "." + methodName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Method getMethodIfAvailable(Class<?> clazz, String methodName, Class<?>... paramTypes)
/*      */   {
/*  665 */     Assert.notNull(clazz, "Class must not be null");
/*  666 */     Assert.notNull(methodName, "Method name must not be null");
/*  667 */     if (paramTypes != null) {
/*      */       try {
/*  669 */         return clazz.getMethod(methodName, paramTypes);
/*      */       }
/*      */       catch (NoSuchMethodException ex) {
/*  672 */         return null;
/*      */       }
/*      */     }
/*      */     
/*  676 */     Set<Method> candidates = new HashSet(1);
/*  677 */     Method[] methods = clazz.getMethods();
/*  678 */     for (Method method : methods) {
/*  679 */       if (methodName.equals(method.getName())) {
/*  680 */         candidates.add(method);
/*      */       }
/*      */     }
/*  683 */     if (candidates.size() == 1) {
/*  684 */       return (Method)candidates.iterator().next();
/*      */     }
/*  686 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int getMethodCountForName(Class<?> clazz, String methodName)
/*      */   {
/*  698 */     Assert.notNull(clazz, "Class must not be null");
/*  699 */     Assert.notNull(methodName, "Method name must not be null");
/*  700 */     int count = 0;
/*  701 */     Method[] declaredMethods = clazz.getDeclaredMethods();
/*  702 */     Method[] arrayOfMethod1 = declaredMethods;int i = arrayOfMethod1.length; for (Method localMethod1 = 0; localMethod1 < i; localMethod1++) { method = arrayOfMethod1[localMethod1];
/*  703 */       if (methodName.equals(method.getName())) {
/*  704 */         count++;
/*      */       }
/*      */     }
/*  707 */     Object ifcs = clazz.getInterfaces();
/*  708 */     Object localObject1 = ifcs;localMethod1 = localObject1.length; for (Method method = 0; method < localMethod1; method++) { Class<?> ifc = localObject1[method];
/*  709 */       count += getMethodCountForName(ifc, methodName);
/*      */     }
/*  711 */     if (clazz.getSuperclass() != null) {
/*  712 */       count += getMethodCountForName(clazz.getSuperclass(), methodName);
/*      */     }
/*  714 */     return count;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean hasAtLeastOneMethodWithName(Class<?> clazz, String methodName)
/*      */   {
/*  726 */     Assert.notNull(clazz, "Class must not be null");
/*  727 */     Assert.notNull(methodName, "Method name must not be null");
/*  728 */     Method[] declaredMethods = clazz.getDeclaredMethods();
/*  729 */     Method[] arrayOfMethod1 = declaredMethods;int i = arrayOfMethod1.length; for (Method localMethod1 = 0; localMethod1 < i; localMethod1++) { method = arrayOfMethod1[localMethod1];
/*  730 */       if (method.getName().equals(methodName)) {
/*  731 */         return true;
/*      */       }
/*      */     }
/*  734 */     Object ifcs = clazz.getInterfaces();
/*  735 */     Object localObject1 = ifcs;localMethod1 = localObject1.length; for (Method method = 0; method < localMethod1; method++) { Class<?> ifc = localObject1[method];
/*  736 */       if (hasAtLeastOneMethodWithName(ifc, methodName)) {
/*  737 */         return true;
/*      */       }
/*      */     }
/*  740 */     return (clazz.getSuperclass() != null) && (hasAtLeastOneMethodWithName(clazz.getSuperclass(), methodName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Method getMostSpecificMethod(Method method, Class<?> targetClass)
/*      */   {
/*  764 */     if ((method != null) && (isOverridable(method, targetClass)) && (targetClass != null) && 
/*  765 */       (targetClass != method.getDeclaringClass())) {
/*      */       try {
/*  767 */         if (Modifier.isPublic(method.getModifiers())) {
/*      */           try {
/*  769 */             return targetClass.getMethod(method.getName(), method.getParameterTypes());
/*      */           }
/*      */           catch (NoSuchMethodException ex) {
/*  772 */             return method;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*  777 */         Method specificMethod = ReflectionUtils.findMethod(targetClass, method.getName(), method.getParameterTypes());
/*  778 */         return specificMethod != null ? specificMethod : method;
/*      */       }
/*      */       catch (SecurityException localSecurityException) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  785 */     return method;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isUserLevelMethod(Method method)
/*      */   {
/*  800 */     Assert.notNull(method, "Method must not be null");
/*  801 */     return (method.isBridge()) || ((!method.isSynthetic()) && (!isGroovyObjectMethod(method)));
/*      */   }
/*      */   
/*      */   private static boolean isGroovyObjectMethod(Method method) {
/*  805 */     return method.getDeclaringClass().getName().equals("groovy.lang.GroovyObject");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static boolean isOverridable(Method method, Class<?> targetClass)
/*      */   {
/*  814 */     if (Modifier.isPrivate(method.getModifiers())) {
/*  815 */       return false;
/*      */     }
/*  817 */     if ((Modifier.isPublic(method.getModifiers())) || (Modifier.isProtected(method.getModifiers()))) {
/*  818 */       return true;
/*      */     }
/*  820 */     return getPackageName(method.getDeclaringClass()).equals(getPackageName(targetClass));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Method getStaticMethod(Class<?> clazz, String methodName, Class<?>... args)
/*      */   {
/*  832 */     Assert.notNull(clazz, "Class must not be null");
/*  833 */     Assert.notNull(methodName, "Method name must not be null");
/*      */     try {
/*  835 */       Method method = clazz.getMethod(methodName, args);
/*  836 */       return Modifier.isStatic(method.getModifiers()) ? method : null;
/*      */     }
/*      */     catch (NoSuchMethodException ex) {}
/*  839 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isPrimitiveWrapper(Class<?> clazz)
/*      */   {
/*  851 */     Assert.notNull(clazz, "Class must not be null");
/*  852 */     return primitiveWrapperTypeMap.containsKey(clazz);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isPrimitiveOrWrapper(Class<?> clazz)
/*      */   {
/*  863 */     Assert.notNull(clazz, "Class must not be null");
/*  864 */     return (clazz.isPrimitive()) || (isPrimitiveWrapper(clazz));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isPrimitiveArray(Class<?> clazz)
/*      */   {
/*  874 */     Assert.notNull(clazz, "Class must not be null");
/*  875 */     return (clazz.isArray()) && (clazz.getComponentType().isPrimitive());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isPrimitiveWrapperArray(Class<?> clazz)
/*      */   {
/*  885 */     Assert.notNull(clazz, "Class must not be null");
/*  886 */     return (clazz.isArray()) && (isPrimitiveWrapper(clazz.getComponentType()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<?> resolvePrimitiveIfNecessary(Class<?> clazz)
/*      */   {
/*  896 */     Assert.notNull(clazz, "Class must not be null");
/*  897 */     return (clazz.isPrimitive()) && (clazz != Void.TYPE) ? (Class)primitiveTypeToWrapperMap.get(clazz) : clazz;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isAssignable(Class<?> lhsType, Class<?> rhsType)
/*      */   {
/*  910 */     Assert.notNull(lhsType, "Left-hand side type must not be null");
/*  911 */     Assert.notNull(rhsType, "Right-hand side type must not be null");
/*  912 */     if (lhsType.isAssignableFrom(rhsType)) {
/*  913 */       return true;
/*      */     }
/*  915 */     if (lhsType.isPrimitive()) {
/*  916 */       Class<?> resolvedPrimitive = (Class)primitiveWrapperTypeMap.get(rhsType);
/*  917 */       if (lhsType == resolvedPrimitive) {
/*  918 */         return true;
/*      */       }
/*      */     }
/*      */     else {
/*  922 */       Class<?> resolvedWrapper = (Class)primitiveTypeToWrapperMap.get(rhsType);
/*  923 */       if ((resolvedWrapper != null) && (lhsType.isAssignableFrom(resolvedWrapper))) {
/*  924 */         return true;
/*      */       }
/*      */     }
/*  927 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isAssignableValue(Class<?> type, Object value)
/*      */   {
/*  939 */     Assert.notNull(type, "Type must not be null");
/*  940 */     return !type.isPrimitive() ? true : value != null ? isAssignable(type, value.getClass()) : false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String convertResourcePathToClassName(String resourcePath)
/*      */   {
/*  950 */     Assert.notNull(resourcePath, "Resource path must not be null");
/*  951 */     return resourcePath.replace('/', '.');
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String convertClassNameToResourcePath(String className)
/*      */   {
/*  960 */     Assert.notNull(className, "Class name must not be null");
/*  961 */     return className.replace('.', '/');
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String addResourcePathToPackagePath(Class<?> clazz, String resourceName)
/*      */   {
/*  981 */     Assert.notNull(resourceName, "Resource name must not be null");
/*  982 */     if (!resourceName.startsWith("/")) {
/*  983 */       return classPackageAsResourcePath(clazz) + "/" + resourceName;
/*      */     }
/*  985 */     return classPackageAsResourcePath(clazz) + resourceName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String classPackageAsResourcePath(Class<?> clazz)
/*      */   {
/* 1003 */     if (clazz == null) {
/* 1004 */       return "";
/*      */     }
/* 1006 */     String className = clazz.getName();
/* 1007 */     int packageEndIndex = className.lastIndexOf('.');
/* 1008 */     if (packageEndIndex == -1) {
/* 1009 */       return "";
/*      */     }
/* 1011 */     String packageName = className.substring(0, packageEndIndex);
/* 1012 */     return packageName.replace('.', '/');
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String classNamesToString(Class<?>... classes)
/*      */   {
/* 1025 */     return classNamesToString(Arrays.asList(classes));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String classNamesToString(Collection<Class<?>> classes)
/*      */   {
/* 1038 */     if (CollectionUtils.isEmpty(classes)) {
/* 1039 */       return "[]";
/*      */     }
/* 1041 */     StringBuilder sb = new StringBuilder("[");
/* 1042 */     for (Iterator<Class<?>> it = classes.iterator(); it.hasNext();) {
/* 1043 */       Class<?> clazz = (Class)it.next();
/* 1044 */       sb.append(clazz.getName());
/* 1045 */       if (it.hasNext()) {
/* 1046 */         sb.append(", ");
/*      */       }
/*      */     }
/* 1049 */     sb.append("]");
/* 1050 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<?>[] toClassArray(Collection<Class<?>> collection)
/*      */   {
/* 1061 */     if (collection == null) {
/* 1062 */       return null;
/*      */     }
/* 1064 */     return (Class[])collection.toArray(new Class[collection.size()]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<?>[] getAllInterfaces(Object instance)
/*      */   {
/* 1074 */     Assert.notNull(instance, "Instance must not be null");
/* 1075 */     return getAllInterfacesForClass(instance.getClass());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<?>[] getAllInterfacesForClass(Class<?> clazz)
/*      */   {
/* 1086 */     return getAllInterfacesForClass(clazz, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<?>[] getAllInterfacesForClass(Class<?> clazz, ClassLoader classLoader)
/*      */   {
/* 1099 */     Set<Class<?>> ifcs = getAllInterfacesForClassAsSet(clazz, classLoader);
/* 1100 */     return (Class[])ifcs.toArray(new Class[ifcs.size()]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Set<Class<?>> getAllInterfacesAsSet(Object instance)
/*      */   {
/* 1110 */     Assert.notNull(instance, "Instance must not be null");
/* 1111 */     return getAllInterfacesForClassAsSet(instance.getClass());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Set<Class<?>> getAllInterfacesForClassAsSet(Class<?> clazz)
/*      */   {
/* 1122 */     return getAllInterfacesForClassAsSet(clazz, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Set<Class<?>> getAllInterfacesForClassAsSet(Class<?> clazz, ClassLoader classLoader)
/*      */   {
/* 1135 */     Assert.notNull(clazz, "Class must not be null");
/* 1136 */     if ((clazz.isInterface()) && (isVisible(clazz, classLoader))) {
/* 1137 */       return Collections.singleton(clazz);
/*      */     }
/* 1139 */     Set<Class<?>> interfaces = new LinkedHashSet();
/* 1140 */     while (clazz != null) {
/* 1141 */       Class<?>[] ifcs = clazz.getInterfaces();
/* 1142 */       for (Class<?> ifc : ifcs) {
/* 1143 */         interfaces.addAll(getAllInterfacesForClassAsSet(ifc, classLoader));
/*      */       }
/* 1145 */       clazz = clazz.getSuperclass();
/*      */     }
/* 1147 */     return interfaces;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<?> createCompositeInterface(Class<?>[] interfaces, ClassLoader classLoader)
/*      */   {
/* 1160 */     Assert.notEmpty(interfaces, "Interfaces must not be empty");
/* 1161 */     return Proxy.getProxyClass(classLoader, interfaces);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<?> determineCommonAncestor(Class<?> clazz1, Class<?> clazz2)
/*      */   {
/* 1174 */     if (clazz1 == null) {
/* 1175 */       return clazz2;
/*      */     }
/* 1177 */     if (clazz2 == null) {
/* 1178 */       return clazz1;
/*      */     }
/* 1180 */     if (clazz1.isAssignableFrom(clazz2)) {
/* 1181 */       return clazz1;
/*      */     }
/* 1183 */     if (clazz2.isAssignableFrom(clazz1)) {
/* 1184 */       return clazz2;
/*      */     }
/* 1186 */     Class<?> ancestor = clazz1;
/*      */     do {
/* 1188 */       ancestor = ancestor.getSuperclass();
/* 1189 */       if ((ancestor == null) || (Object.class == ancestor)) {
/* 1190 */         return null;
/*      */       }
/*      */       
/* 1193 */     } while (!ancestor.isAssignableFrom(clazz2));
/* 1194 */     return ancestor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isVisible(Class<?> clazz, ClassLoader classLoader)
/*      */   {
/* 1204 */     if (classLoader == null) {
/* 1205 */       return true;
/*      */     }
/*      */     try {
/* 1208 */       Class<?> actualClass = classLoader.loadClass(clazz.getName());
/* 1209 */       return clazz == actualClass;
/*      */     }
/*      */     catch (ClassNotFoundException ex) {}
/*      */     
/*      */ 
/* 1214 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isCglibProxy(Object object)
/*      */   {
/* 1224 */     return isCglibProxyClass(object.getClass());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isCglibProxyClass(Class<?> clazz)
/*      */   {
/* 1232 */     return (clazz != null) && (isCglibProxyClassName(clazz.getName()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isCglibProxyClassName(String className)
/*      */   {
/* 1240 */     return (className != null) && (className.contains("$$"));
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\util\ClassUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */