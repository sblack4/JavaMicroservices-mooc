/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LinkedCaseInsensitiveMap<V>
/*     */   extends LinkedHashMap<String, V>
/*     */ {
/*     */   private Map<String, String> caseInsensitiveKeys;
/*     */   private final Locale locale;
/*     */   
/*     */   public LinkedCaseInsensitiveMap()
/*     */   {
/*  49 */     this(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LinkedCaseInsensitiveMap(Locale locale)
/*     */   {
/*  60 */     this.caseInsensitiveKeys = new HashMap();
/*  61 */     this.locale = (locale != null ? locale : Locale.getDefault());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LinkedCaseInsensitiveMap(int initialCapacity)
/*     */   {
/*  72 */     this(initialCapacity, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LinkedCaseInsensitiveMap(int initialCapacity, Locale locale)
/*     */   {
/*  84 */     super(initialCapacity);
/*  85 */     this.caseInsensitiveKeys = new HashMap(initialCapacity);
/*  86 */     this.locale = (locale != null ? locale : Locale.getDefault());
/*     */   }
/*     */   
/*     */ 
/*     */   public V put(String key, V value)
/*     */   {
/*  92 */     String oldKey = (String)this.caseInsensitiveKeys.put(convertKey(key), key);
/*  93 */     if ((oldKey != null) && (!oldKey.equals(key))) {
/*  94 */       super.remove(oldKey);
/*     */     }
/*  96 */     return (V)super.put(key, value);
/*     */   }
/*     */   
/*     */   public void putAll(Map<? extends String, ? extends V> map)
/*     */   {
/* 101 */     if (map.isEmpty()) {
/* 102 */       return;
/*     */     }
/* 104 */     for (Map.Entry<? extends String, ? extends V> entry : map.entrySet()) {
/* 105 */       put((String)entry.getKey(), entry.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean containsKey(Object key)
/*     */   {
/* 111 */     return ((key instanceof String)) && (this.caseInsensitiveKeys.containsKey(convertKey((String)key)));
/*     */   }
/*     */   
/*     */   public V get(Object key)
/*     */   {
/* 116 */     if ((key instanceof String)) {
/* 117 */       String caseInsensitiveKey = (String)this.caseInsensitiveKeys.get(convertKey((String)key));
/* 118 */       if (caseInsensitiveKey != null) {
/* 119 */         return (V)super.get(caseInsensitiveKey);
/*     */       }
/*     */     }
/* 122 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public V getOrDefault(Object key, V defaultValue)
/*     */   {
/* 128 */     if ((key instanceof String)) {
/* 129 */       String caseInsensitiveKey = (String)this.caseInsensitiveKeys.get(convertKey((String)key));
/* 130 */       if (caseInsensitiveKey != null) {
/* 131 */         return (V)super.get(caseInsensitiveKey);
/*     */       }
/*     */     }
/* 134 */     return defaultValue;
/*     */   }
/*     */   
/*     */   public V remove(Object key)
/*     */   {
/* 139 */     if ((key instanceof String)) {
/* 140 */       String caseInsensitiveKey = (String)this.caseInsensitiveKeys.remove(convertKey((String)key));
/* 141 */       if (caseInsensitiveKey != null) {
/* 142 */         return (V)super.remove(caseInsensitiveKey);
/*     */       }
/*     */     }
/* 145 */     return null;
/*     */   }
/*     */   
/*     */   public void clear()
/*     */   {
/* 150 */     this.caseInsensitiveKeys.clear();
/* 151 */     super.clear();
/*     */   }
/*     */   
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 157 */     LinkedCaseInsensitiveMap<V> copy = (LinkedCaseInsensitiveMap)super.clone();
/* 158 */     copy.caseInsensitiveKeys = new HashMap(this.caseInsensitiveKeys);
/* 159 */     return copy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String convertKey(String key)
/*     */   {
/* 172 */     return key.toLowerCase(this.locale);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\util\LinkedCaseInsensitiveMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */