/*    */ package org.springframework.util.concurrent;
/*    */ 
/*    */ import java.util.concurrent.CompletableFuture;
/*    */ import java.util.concurrent.ExecutionException;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import java.util.concurrent.TimeoutException;
/*    */ import java.util.function.BiFunction;
/*    */ import org.springframework.lang.UsesJava8;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @UsesJava8
/*    */ public class CompletableToListenableFutureAdapter<T>
/*    */   implements ListenableFuture<T>
/*    */ {
/*    */   private final CompletableFuture<T> completableFuture;
/* 38 */   private final ListenableFutureCallbackRegistry<T> callbacks = new ListenableFutureCallbackRegistry();
/*    */   
/*    */   public CompletableToListenableFutureAdapter(CompletableFuture<T> completableFuture)
/*    */   {
/* 42 */     this.completableFuture = completableFuture;
/* 43 */     this.completableFuture.handle(new BiFunction()
/*    */     {
/*    */       public Object apply(T result, Throwable ex) {
/* 46 */         if (ex != null) {
/* 47 */           CompletableToListenableFutureAdapter.this.callbacks.failure(ex);
/*    */         }
/*    */         else {
/* 50 */           CompletableToListenableFutureAdapter.this.callbacks.success(result);
/*    */         }
/* 52 */         return null;
/*    */       }
/*    */     });
/*    */   }
/*    */   
/*    */ 
/*    */   public void addCallback(ListenableFutureCallback<? super T> callback)
/*    */   {
/* 60 */     this.callbacks.addCallback(callback);
/*    */   }
/*    */   
/*    */   public void addCallback(SuccessCallback<? super T> successCallback, FailureCallback failureCallback)
/*    */   {
/* 65 */     this.callbacks.addSuccessCallback(successCallback);
/* 66 */     this.callbacks.addFailureCallback(failureCallback);
/*    */   }
/*    */   
/*    */   public boolean cancel(boolean mayInterruptIfRunning)
/*    */   {
/* 71 */     return this.completableFuture.cancel(mayInterruptIfRunning);
/*    */   }
/*    */   
/*    */   public boolean isCancelled()
/*    */   {
/* 76 */     return this.completableFuture.isCancelled();
/*    */   }
/*    */   
/*    */   public boolean isDone()
/*    */   {
/* 81 */     return this.completableFuture.isDone();
/*    */   }
/*    */   
/*    */   public T get() throws InterruptedException, ExecutionException
/*    */   {
/* 86 */     return (T)this.completableFuture.get();
/*    */   }
/*    */   
/*    */   public T get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException
/*    */   {
/* 91 */     return (T)this.completableFuture.get(timeout, unit);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\util\concurrent\CompletableToListenableFutureAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */