/*    */ package org.springframework.util.concurrent;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.ExecutionException;
/*    */ import java.util.concurrent.FutureTask;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ListenableFutureTask<T>
/*    */   extends FutureTask<T>
/*    */   implements ListenableFuture<T>
/*    */ {
/* 31 */   private final ListenableFutureCallbackRegistry<T> callbacks = new ListenableFutureCallbackRegistry();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ListenableFutureTask(Callable<T> callable)
/*    */   {
/* 40 */     super(callable);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ListenableFutureTask(Runnable runnable, T result)
/*    */   {
/* 51 */     super(runnable, result);
/*    */   }
/*    */   
/*    */ 
/*    */   public void addCallback(ListenableFutureCallback<? super T> callback)
/*    */   {
/* 57 */     this.callbacks.addCallback(callback);
/*    */   }
/*    */   
/*    */   public void addCallback(SuccessCallback<? super T> successCallback, FailureCallback failureCallback)
/*    */   {
/* 62 */     this.callbacks.addSuccessCallback(successCallback);
/* 63 */     this.callbacks.addFailureCallback(failureCallback);
/*    */   }
/*    */   
/*    */   protected final void done()
/*    */   {
/*    */     Throwable cause;
/*    */     try {
/* 70 */       T result = get();
/* 71 */       this.callbacks.success(result);
/* 72 */       return;
/*    */     }
/*    */     catch (InterruptedException ex) {
/* 75 */       Thread.currentThread().interrupt();
/* 76 */       return;
/*    */     }
/*    */     catch (ExecutionException ex) {
/* 79 */       Throwable cause = ex.getCause();
/* 80 */       if (cause == null) {
/* 81 */         cause = ex;
/*    */       }
/*    */     }
/*    */     catch (Throwable ex) {
/* 85 */       cause = ex;
/*    */     }
/* 87 */     this.callbacks.failure(cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\util\concurrent\ListenableFutureTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */