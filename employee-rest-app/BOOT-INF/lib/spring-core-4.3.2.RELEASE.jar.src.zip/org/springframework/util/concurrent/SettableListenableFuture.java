/*     */ package org.springframework.util.concurrent;
/*     */ 
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SettableListenableFuture<T>
/*     */   implements ListenableFuture<T>
/*     */ {
/*     */   private final SettableTask<T> settableTask;
/*     */   private final ListenableFutureTask<T> listenableFuture;
/*     */   
/*     */   public SettableListenableFuture()
/*     */   {
/*  47 */     this.settableTask = new SettableTask(null);
/*  48 */     this.listenableFuture = new ListenableFutureTask(this.settableTask);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean set(T value)
/*     */   {
/*  60 */     boolean success = this.settableTask.setValue(value);
/*  61 */     if (success) {
/*  62 */       this.listenableFuture.run();
/*     */     }
/*  64 */     return success;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean setException(Throwable exception)
/*     */   {
/*  75 */     Assert.notNull(exception, "Exception must not be null");
/*  76 */     boolean success = this.settableTask.setException(exception);
/*  77 */     if (success) {
/*  78 */       this.listenableFuture.run();
/*     */     }
/*  80 */     return success;
/*     */   }
/*     */   
/*     */   public void addCallback(ListenableFutureCallback<? super T> callback)
/*     */   {
/*  85 */     this.listenableFuture.addCallback(callback);
/*     */   }
/*     */   
/*     */   public void addCallback(SuccessCallback<? super T> successCallback, FailureCallback failureCallback)
/*     */   {
/*  90 */     this.listenableFuture.addCallback(successCallback, failureCallback);
/*     */   }
/*     */   
/*     */   public boolean cancel(boolean mayInterruptIfRunning)
/*     */   {
/*  95 */     this.settableTask.setCancelled();
/*  96 */     boolean cancelled = this.listenableFuture.cancel(mayInterruptIfRunning);
/*  97 */     if ((cancelled) && (mayInterruptIfRunning)) {
/*  98 */       interruptTask();
/*     */     }
/* 100 */     return cancelled;
/*     */   }
/*     */   
/*     */   public boolean isCancelled()
/*     */   {
/* 105 */     return this.listenableFuture.isCancelled();
/*     */   }
/*     */   
/*     */   public boolean isDone()
/*     */   {
/* 110 */     return this.listenableFuture.isDone();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public T get()
/*     */     throws InterruptedException, ExecutionException
/*     */   {
/* 123 */     return (T)this.listenableFuture.get();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public T get(long timeout, TimeUnit unit)
/*     */     throws InterruptedException, ExecutionException, TimeoutException
/*     */   {
/* 138 */     return (T)this.listenableFuture.get(timeout, unit);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void interruptTask() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class SettableTask<T>
/*     */     implements Callable<T>
/*     */   {
/* 153 */     private static final Object NO_VALUE = new Object();
/*     */     
/* 155 */     private final AtomicReference<Object> value = new AtomicReference(NO_VALUE);
/*     */     
/* 157 */     private volatile boolean cancelled = false;
/*     */     
/*     */     public boolean setValue(T value) {
/* 160 */       if (this.cancelled) {
/* 161 */         return false;
/*     */       }
/* 163 */       return this.value.compareAndSet(NO_VALUE, value);
/*     */     }
/*     */     
/*     */     public boolean setException(Throwable exception) {
/* 167 */       if (this.cancelled) {
/* 168 */         return false;
/*     */       }
/* 170 */       return this.value.compareAndSet(NO_VALUE, exception);
/*     */     }
/*     */     
/*     */     public void setCancelled() {
/* 174 */       this.cancelled = true;
/*     */     }
/*     */     
/*     */     public T call()
/*     */       throws Exception
/*     */     {
/* 180 */       Object val = this.value.get();
/* 181 */       if ((val instanceof Throwable)) {
/* 182 */         ReflectionUtils.rethrowException((Throwable)val);
/*     */       }
/* 184 */       return (T)val;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\util\concurrent\SettableListenableFuture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */