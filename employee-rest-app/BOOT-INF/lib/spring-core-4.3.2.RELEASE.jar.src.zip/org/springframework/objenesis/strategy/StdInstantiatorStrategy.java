/*    */ package org.springframework.objenesis.strategy;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ import org.springframework.objenesis.instantiator.android.Android10Instantiator;
/*    */ import org.springframework.objenesis.instantiator.android.Android17Instantiator;
/*    */ import org.springframework.objenesis.instantiator.android.Android18Instantiator;
/*    */ import org.springframework.objenesis.instantiator.basic.AccessibleInstantiator;
/*    */ import org.springframework.objenesis.instantiator.basic.ObjectInputStreamInstantiator;
/*    */ import org.springframework.objenesis.instantiator.gcj.GCJInstantiator;
/*    */ import org.springframework.objenesis.instantiator.perc.PercInstantiator;
/*    */ import org.springframework.objenesis.instantiator.sun.SunReflectionFactoryInstantiator;
/*    */ import org.springframework.objenesis.instantiator.sun.UnsafeFactoryInstantiator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StdInstantiatorStrategy
/*    */   extends BaseInstantiatorStrategy
/*    */ {
/*    */   public <T> ObjectInstantiator<T> newInstantiatorOf(Class<T> type)
/*    */   {
/* 58 */     if ((PlatformDescription.isThisJVM("Java HotSpot")) || (PlatformDescription.isThisJVM("OpenJDK"))) {
/* 59 */       if (PlatformDescription.isGoogleAppEngine()) {
/* 60 */         if (Serializable.class.isAssignableFrom(type)) {
/* 61 */           return new ObjectInputStreamInstantiator(type);
/*    */         }
/* 63 */         return new AccessibleInstantiator(type);
/*    */       }
/*    */       
/*    */ 
/* 67 */       return new SunReflectionFactoryInstantiator(type);
/*    */     }
/* 69 */     if (PlatformDescription.isThisJVM("Dalvik")) {
/* 70 */       if (PlatformDescription.isAndroidOpenJDK())
/*    */       {
/* 72 */         return new UnsafeFactoryInstantiator(type);
/*    */       }
/* 74 */       if (PlatformDescription.ANDROID_VERSION <= 10)
/*    */       {
/* 76 */         return new Android10Instantiator(type);
/*    */       }
/* 78 */       if (PlatformDescription.ANDROID_VERSION <= 17)
/*    */       {
/* 80 */         return new Android17Instantiator(type);
/*    */       }
/*    */       
/* 83 */       return new Android18Instantiator(type);
/*    */     }
/* 85 */     if (PlatformDescription.isThisJVM("BEA"))
/*    */     {
/* 87 */       return new SunReflectionFactoryInstantiator(type);
/*    */     }
/* 89 */     if (PlatformDescription.isThisJVM("GNU libgcj")) {
/* 90 */       return new GCJInstantiator(type);
/*    */     }
/* 92 */     if (PlatformDescription.isThisJVM("PERC")) {
/* 93 */       return new PercInstantiator(type);
/*    */     }
/*    */     
/*    */ 
/* 97 */     return new UnsafeFactoryInstantiator(type);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\objenesis\strategy\StdInstantiatorStrategy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */