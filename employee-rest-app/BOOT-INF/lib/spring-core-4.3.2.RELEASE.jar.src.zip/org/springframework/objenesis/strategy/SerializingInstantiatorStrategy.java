/*    */ package org.springframework.objenesis.strategy;
/*    */ 
/*    */ import java.io.NotSerializableException;
/*    */ import java.io.Serializable;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ import org.springframework.objenesis.instantiator.android.AndroidSerializationInstantiator;
/*    */ import org.springframework.objenesis.instantiator.basic.ObjectInputStreamInstantiator;
/*    */ import org.springframework.objenesis.instantiator.basic.ObjectStreamClassInstantiator;
/*    */ import org.springframework.objenesis.instantiator.gcj.GCJSerializationInstantiator;
/*    */ import org.springframework.objenesis.instantiator.perc.PercSerializationInstantiator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SerializingInstantiatorStrategy
/*    */   extends BaseInstantiatorStrategy
/*    */ {
/*    */   public <T> ObjectInstantiator<T> newInstantiatorOf(Class<T> type)
/*    */   {
/* 56 */     if (!Serializable.class.isAssignableFrom(type)) {
/* 57 */       throw new ObjenesisException(new NotSerializableException(type + " not serializable"));
/*    */     }
/* 59 */     if ((PlatformDescription.JVM_NAME.startsWith("Java HotSpot")) || (PlatformDescription.isThisJVM("OpenJDK"))) {
/* 60 */       if (PlatformDescription.isGoogleAppEngine()) {
/* 61 */         return new ObjectInputStreamInstantiator(type);
/*    */       }
/* 63 */       return new ObjectStreamClassInstantiator(type);
/*    */     }
/* 65 */     if (PlatformDescription.JVM_NAME.startsWith("Dalvik")) {
/* 66 */       if (PlatformDescription.isAndroidOpenJDK()) {
/* 67 */         return new ObjectStreamClassInstantiator(type);
/*    */       }
/* 69 */       return new AndroidSerializationInstantiator(type);
/*    */     }
/* 71 */     if (PlatformDescription.JVM_NAME.startsWith("GNU libgcj")) {
/* 72 */       return new GCJSerializationInstantiator(type);
/*    */     }
/* 74 */     if (PlatformDescription.JVM_NAME.startsWith("PERC")) {
/* 75 */       return new PercSerializationInstantiator(type);
/*    */     }
/*    */     
/* 78 */     return new ObjectStreamClassInstantiator(type);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\objenesis\strategy\SerializingInstantiatorStrategy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */