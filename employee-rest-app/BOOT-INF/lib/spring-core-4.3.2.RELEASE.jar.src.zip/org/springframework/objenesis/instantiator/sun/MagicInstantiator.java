/*     */ package org.springframework.objenesis.instantiator.sun;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.springframework.objenesis.ObjenesisException;
/*     */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*     */ import org.springframework.objenesis.instantiator.basic.ClassDefinitionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MagicInstantiator<T>
/*     */   implements ObjectInstantiator<T>
/*     */ {
/*     */   private static final int INDEX_CLASS_THIS = 1;
/*     */   private static final int INDEX_CLASS_SUPERCLASS = 2;
/*     */   private static final int INDEX_UTF8_CONSTRUCTOR_NAME = 3;
/*     */   private static final int INDEX_UTF8_CONSTRUCTOR_DESC = 4;
/*     */   private static final int INDEX_UTF8_CODE_ATTRIBUTE = 5;
/*     */   private static final int INDEX_UTF8_INSTANTIATOR_CLASS = 7;
/*     */   private static final int INDEX_UTF8_SUPERCLASS = 8;
/*     */   private static final int INDEX_CLASS_INTERFACE = 9;
/*     */   private static final int INDEX_UTF8_INTERFACE = 10;
/*     */   private static final int INDEX_UTF8_NEWINSTANCE_NAME = 11;
/*     */   private static final int INDEX_UTF8_NEWINSTANCE_DESC = 12;
/*     */   private static final int INDEX_METHODREF_OBJECT_CONSTRUCTOR = 13;
/*     */   private static final int INDEX_CLASS_OBJECT = 14;
/*     */   private static final int INDEX_UTF8_OBJECT = 15;
/*     */   private static final int INDEX_NAMEANDTYPE_DEFAULT_CONSTRUCTOR = 16;
/*     */   private static final int INDEX_CLASS_TYPE = 17;
/*     */   private static final int INDEX_UTF8_TYPE = 18;
/*  55 */   private static int CONSTANT_POOL_COUNT = 19;
/*     */   
/*  57 */   private static final byte[] CONSTRUCTOR_CODE = { 42, -73, 0, 13, -79 };
/*  58 */   private static final int CONSTRUCTOR_CODE_ATTRIBUTE_LENGTH = 12 + CONSTRUCTOR_CODE.length;
/*     */   
/*  60 */   private static final byte[] NEWINSTANCE_CODE = { -69, 0, 17, 89, -73, 0, 13, -80 };
/*  61 */   private static final int NEWINSTANCE_CODE_ATTRIBUTE_LENGTH = 12 + NEWINSTANCE_CODE.length;
/*     */   
/*     */   private static final String CONSTRUCTOR_NAME = "<init>";
/*     */   private static final String CONSTRUCTOR_DESC = "()V";
/*     */   private ObjectInstantiator<T> instantiator;
/*     */   
/*     */   public MagicInstantiator(Class<T> type)
/*     */   {
/*  69 */     this.instantiator = newInstantiatorOf(type);
/*     */   }
/*     */   
/*     */   private <T> ObjectInstantiator<T> newInstantiatorOf(Class<T> type) {
/*  73 */     String suffix = type.getSimpleName();
/*  74 */     String className = getClass().getName() + "$$$" + suffix;
/*     */     
/*  76 */     Class<ObjectInstantiator<T>> clazz = ClassDefinitionUtils.getExistingClass(getClass().getClassLoader(), className);
/*     */     
/*  78 */     if (clazz == null) {
/*  79 */       byte[] classBytes = writeExtendingClass(type, className);
/*     */       try
/*     */       {
/*  82 */         clazz = ClassDefinitionUtils.defineClass(className, classBytes, getClass().getClassLoader());
/*     */       } catch (Exception e) {
/*  84 */         throw new ObjenesisException(e);
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/*  89 */       return (ObjectInstantiator)clazz.newInstance();
/*     */     } catch (InstantiationException e) {
/*  91 */       throw new ObjenesisException(e);
/*     */     } catch (IllegalAccessException e) {
/*  93 */       throw new ObjenesisException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] writeExtendingClass(Class<?> type, String className)
/*     */   {
/* 107 */     String clazz = ClassDefinitionUtils.classNameToInternalClassName(className);
/*     */     
/* 109 */     DataOutputStream in = null;
/* 110 */     bIn = new ByteArrayOutputStream(1000);
/*     */     try {
/* 112 */       in = new DataOutputStream(bIn);
/*     */       
/* 114 */       in.write(ClassDefinitionUtils.MAGIC);
/* 115 */       in.write(ClassDefinitionUtils.VERSION);
/* 116 */       in.writeShort(CONSTANT_POOL_COUNT);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 121 */       in.writeByte(7);
/* 122 */       in.writeShort(7);
/*     */       
/*     */ 
/* 125 */       in.writeByte(7);
/* 126 */       in.writeShort(8);
/*     */       
/*     */ 
/* 129 */       in.writeByte(1);
/* 130 */       in.writeUTF("<init>");
/*     */       
/*     */ 
/* 133 */       in.writeByte(1);
/* 134 */       in.writeUTF("()V");
/*     */       
/*     */ 
/* 137 */       in.writeByte(1);
/* 138 */       in.writeUTF("Code");
/*     */       
/*     */ 
/* 141 */       in.writeByte(1);
/* 142 */       in.writeUTF("L" + clazz + ";");
/*     */       
/*     */ 
/* 145 */       in.writeByte(1);
/* 146 */       in.writeUTF(clazz);
/*     */       
/*     */ 
/* 149 */       in.writeByte(1);
/*     */       
/* 151 */       in.writeUTF("sun/reflect/MagicAccessorImpl");
/*     */       
/*     */ 
/* 154 */       in.writeByte(7);
/* 155 */       in.writeShort(10);
/*     */       
/*     */ 
/* 158 */       in.writeByte(1);
/* 159 */       in.writeUTF(ObjectInstantiator.class.getName().replace('.', '/'));
/*     */       
/*     */ 
/* 162 */       in.writeByte(1);
/* 163 */       in.writeUTF("newInstance");
/*     */       
/*     */ 
/* 166 */       in.writeByte(1);
/* 167 */       in.writeUTF("()Ljava/lang/Object;");
/*     */       
/*     */ 
/* 170 */       in.writeByte(10);
/* 171 */       in.writeShort(14);
/* 172 */       in.writeShort(16);
/*     */       
/*     */ 
/* 175 */       in.writeByte(7);
/* 176 */       in.writeShort(15);
/*     */       
/*     */ 
/* 179 */       in.writeByte(1);
/* 180 */       in.writeUTF("java/lang/Object");
/*     */       
/*     */ 
/* 183 */       in.writeByte(12);
/* 184 */       in.writeShort(3);
/* 185 */       in.writeShort(4);
/*     */       
/*     */ 
/* 188 */       in.writeByte(7);
/* 189 */       in.writeShort(18);
/*     */       
/*     */ 
/* 192 */       in.writeByte(1);
/* 193 */       in.writeUTF(ClassDefinitionUtils.classNameToInternalClassName(type.getName()));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 198 */       in.writeShort(49);
/*     */       
/*     */ 
/* 201 */       in.writeShort(1);
/*     */       
/*     */ 
/* 204 */       in.writeShort(2);
/*     */       
/*     */ 
/* 207 */       in.writeShort(1);
/* 208 */       in.writeShort(9);
/*     */       
/*     */ 
/* 211 */       in.writeShort(0);
/*     */       
/*     */ 
/* 214 */       in.writeShort(2);
/*     */       
/*     */ 
/* 217 */       in.writeShort(1);
/* 218 */       in.writeShort(3);
/* 219 */       in.writeShort(4);
/* 220 */       in.writeShort(1);
/*     */       
/*     */ 
/* 223 */       in.writeShort(5);
/* 224 */       in.writeInt(CONSTRUCTOR_CODE_ATTRIBUTE_LENGTH);
/* 225 */       in.writeShort(0);
/* 226 */       in.writeShort(1);
/* 227 */       in.writeInt(CONSTRUCTOR_CODE.length);
/* 228 */       in.write(CONSTRUCTOR_CODE);
/* 229 */       in.writeShort(0);
/* 230 */       in.writeShort(0);
/*     */       
/*     */ 
/* 233 */       in.writeShort(1);
/* 234 */       in.writeShort(11);
/* 235 */       in.writeShort(12);
/* 236 */       in.writeShort(1);
/*     */       
/*     */ 
/* 239 */       in.writeShort(5);
/* 240 */       in.writeInt(NEWINSTANCE_CODE_ATTRIBUTE_LENGTH);
/* 241 */       in.writeShort(2);
/* 242 */       in.writeShort(1);
/* 243 */       in.writeInt(NEWINSTANCE_CODE.length);
/* 244 */       in.write(NEWINSTANCE_CODE);
/* 245 */       in.writeShort(0);
/* 246 */       in.writeShort(0);
/*     */       
/*     */ 
/* 249 */       in.writeShort(0);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 263 */       return bIn.toByteArray();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 252 */       throw new ObjenesisException(e);
/*     */     } finally {
/* 254 */       if (in != null) {
/*     */         try {
/* 256 */           in.close();
/*     */         } catch (IOException e) {
/* 258 */           throw new ObjenesisException(e);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public T newInstance()
/*     */   {
/* 267 */     return (T)this.instantiator.newInstance();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\objenesis\instantiator\sun\MagicInstantiator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */