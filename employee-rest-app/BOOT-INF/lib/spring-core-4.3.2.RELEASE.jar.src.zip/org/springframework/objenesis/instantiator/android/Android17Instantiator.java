/*    */ package org.springframework.objenesis.instantiator.android;
/*    */ 
/*    */ import java.io.ObjectStreamClass;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Android17Instantiator<T>
/*    */   implements ObjectInstantiator<T>
/*    */ {
/*    */   private final Class<T> type;
/*    */   private final Method newInstanceMethod;
/*    */   private final Integer objectConstructorId;
/*    */   
/*    */   public Android17Instantiator(Class<T> type)
/*    */   {
/* 37 */     this.type = type;
/* 38 */     this.newInstanceMethod = getNewInstanceMethod();
/* 39 */     this.objectConstructorId = findConstructorIdForJavaLangObjectConstructor();
/*    */   }
/*    */   
/*    */   public T newInstance() {
/*    */     try {
/* 44 */       return (T)this.type.cast(this.newInstanceMethod.invoke(null, new Object[] { this.type, this.objectConstructorId }));
/*    */     }
/*    */     catch (Exception e) {
/* 47 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */   
/*    */   private static Method getNewInstanceMethod() {
/*    */     try {
/* 53 */       Method newInstanceMethod = ObjectStreamClass.class.getDeclaredMethod("newInstance", new Class[] { Class.class, Integer.TYPE });
/*    */       
/* 55 */       newInstanceMethod.setAccessible(true);
/* 56 */       return newInstanceMethod;
/*    */     }
/*    */     catch (RuntimeException e) {
/* 59 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (NoSuchMethodException e) {
/* 62 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */   
/*    */   private static Integer findConstructorIdForJavaLangObjectConstructor() {
/*    */     try {
/* 68 */       Method newInstanceMethod = ObjectStreamClass.class.getDeclaredMethod("getConstructorId", new Class[] { Class.class });
/*    */       
/* 70 */       newInstanceMethod.setAccessible(true);
/*    */       
/* 72 */       return (Integer)newInstanceMethod.invoke(null, new Object[] { Object.class });
/*    */     }
/*    */     catch (RuntimeException e) {
/* 75 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (NoSuchMethodException e) {
/* 78 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (IllegalAccessException e) {
/* 81 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (InvocationTargetException e) {
/* 84 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\objenesis\instantiator\android\Android17Instantiator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */