/*     */ package org.springframework.objenesis.instantiator.basic;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.NotSerializableException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectStreamClass;
/*     */ import java.io.Serializable;
/*     */ import org.springframework.objenesis.ObjenesisException;
/*     */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectInputStreamInstantiator<T>
/*     */   implements ObjectInstantiator<T>
/*     */ {
/*     */   private ObjectInputStream inputStream;
/*     */   
/*     */   private static class MockStream
/*     */     extends InputStream
/*     */   {
/*     */     private int pointer;
/*     */     private byte[] data;
/*     */     private int sequence;
/*  39 */     private static final int[] NEXT = { 1, 2, 2 };
/*     */     private byte[][] buffers;
/*     */     private final byte[] FIRST_DATA;
/*     */     private static byte[] HEADER;
/*     */     private static byte[] REPEATING_DATA;
/*     */     
/*     */     static
/*     */     {
/*  47 */       initialize();
/*     */     }
/*     */     
/*     */     private static void initialize() {
/*     */       try {
/*  52 */         ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
/*  53 */         DataOutputStream dout = new DataOutputStream(byteOut);
/*  54 */         dout.writeShort(44269);
/*  55 */         dout.writeShort(5);
/*  56 */         HEADER = byteOut.toByteArray();
/*     */         
/*  58 */         byteOut = new ByteArrayOutputStream();
/*  59 */         dout = new DataOutputStream(byteOut);
/*     */         
/*  61 */         dout.writeByte(115);
/*  62 */         dout.writeByte(113);
/*  63 */         dout.writeInt(8257536);
/*  64 */         REPEATING_DATA = byteOut.toByteArray();
/*     */       }
/*     */       catch (IOException e) {
/*  67 */         throw new Error("IOException: " + e.getMessage());
/*     */       }
/*     */     }
/*     */     
/*     */     public MockStream(Class<?> clazz)
/*     */     {
/*  73 */       this.pointer = 0;
/*  74 */       this.sequence = 0;
/*  75 */       this.data = HEADER;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  86 */       ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
/*  87 */       DataOutputStream dout = new DataOutputStream(byteOut);
/*     */       try {
/*  89 */         dout.writeByte(115);
/*  90 */         dout.writeByte(114);
/*  91 */         dout.writeUTF(clazz.getName());
/*  92 */         dout.writeLong(ObjectStreamClass.lookup(clazz).getSerialVersionUID());
/*  93 */         dout.writeByte(2);
/*  94 */         dout.writeShort(0);
/*  95 */         dout.writeByte(120);
/*  96 */         dout.writeByte(112);
/*     */       }
/*     */       catch (IOException e) {
/*  99 */         throw new Error("IOException: " + e.getMessage());
/*     */       }
/* 101 */       this.FIRST_DATA = byteOut.toByteArray();
/* 102 */       this.buffers = new byte[][] { HEADER, this.FIRST_DATA, REPEATING_DATA };
/*     */     }
/*     */     
/*     */     private void advanceBuffer() {
/* 106 */       this.pointer = 0;
/* 107 */       this.sequence = NEXT[this.sequence];
/* 108 */       this.data = this.buffers[this.sequence];
/*     */     }
/*     */     
/*     */     public int read() throws IOException
/*     */     {
/* 113 */       int result = this.data[(this.pointer++)];
/* 114 */       if (this.pointer >= this.data.length) {
/* 115 */         advanceBuffer();
/*     */       }
/*     */       
/* 118 */       return result;
/*     */     }
/*     */     
/*     */     public int available() throws IOException
/*     */     {
/* 123 */       return Integer.MAX_VALUE;
/*     */     }
/*     */     
/*     */     public int read(byte[] b, int off, int len) throws IOException
/*     */     {
/* 128 */       int left = len;
/* 129 */       int remaining = this.data.length - this.pointer;
/*     */       
/* 131 */       while (remaining <= left) {
/* 132 */         System.arraycopy(this.data, this.pointer, b, off, remaining);
/* 133 */         off += remaining;
/* 134 */         left -= remaining;
/* 135 */         advanceBuffer();
/* 136 */         remaining = this.data.length - this.pointer;
/*     */       }
/* 138 */       if (left > 0) {
/* 139 */         System.arraycopy(this.data, this.pointer, b, off, left);
/* 140 */         this.pointer += left;
/*     */       }
/*     */       
/* 143 */       return len;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public ObjectInputStreamInstantiator(Class<T> clazz)
/*     */   {
/* 150 */     if (Serializable.class.isAssignableFrom(clazz)) {
/*     */       try {
/* 152 */         this.inputStream = new ObjectInputStream(new MockStream(clazz));
/*     */       }
/*     */       catch (IOException e) {
/* 155 */         throw new Error("IOException: " + e.getMessage());
/*     */       }
/*     */       
/*     */     } else {
/* 159 */       throw new ObjenesisException(new NotSerializableException(clazz + " not serializable"));
/*     */     }
/*     */   }
/*     */   
/*     */   public T newInstance()
/*     */   {
/*     */     try {
/* 166 */       return (T)this.inputStream.readObject();
/*     */     }
/*     */     catch (ClassNotFoundException e) {
/* 169 */       throw new Error("ClassNotFoundException: " + e.getMessage());
/*     */     }
/*     */     catch (Exception e) {
/* 172 */       throw new ObjenesisException(e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\objenesis\instantiator\basic\ObjectInputStreamInstantiator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */