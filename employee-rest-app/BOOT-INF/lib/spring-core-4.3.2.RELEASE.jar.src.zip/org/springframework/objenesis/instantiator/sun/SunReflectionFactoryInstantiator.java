/*    */ package org.springframework.objenesis.instantiator.sun;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SunReflectionFactoryInstantiator<T>
/*    */   implements ObjectInstantiator<T>
/*    */ {
/*    */   private final Constructor<T> mungedConstructor;
/*    */   
/*    */   public SunReflectionFactoryInstantiator(Class<T> type)
/*    */   {
/* 37 */     Constructor<Object> javaLangObjectConstructor = getJavaLangObjectConstructor();
/* 38 */     this.mungedConstructor = SunReflectionFactoryHelper.newConstructorForSerialization(type, javaLangObjectConstructor);
/*    */     
/* 40 */     this.mungedConstructor.setAccessible(true);
/*    */   }
/*    */   
/*    */   public T newInstance() {
/*    */     try {
/* 45 */       return (T)this.mungedConstructor.newInstance((Object[])null);
/*    */     }
/*    */     catch (Exception e) {
/* 48 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */   
/*    */   private static Constructor<Object> getJavaLangObjectConstructor() {
/*    */     try {
/* 54 */       return Object.class.getConstructor((Class[])null);
/*    */     }
/*    */     catch (NoSuchMethodException e) {
/* 57 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\objenesis\instantiator\sun\SunReflectionFactoryInstantiator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */