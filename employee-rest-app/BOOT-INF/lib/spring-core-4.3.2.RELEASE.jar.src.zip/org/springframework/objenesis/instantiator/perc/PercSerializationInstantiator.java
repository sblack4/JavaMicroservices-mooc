/*    */ package org.springframework.objenesis.instantiator.perc;
/*    */ 
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PercSerializationInstantiator<T>
/*    */   implements ObjectInstantiator<T>
/*    */ {
/*    */   private Object[] typeArgs;
/*    */   private final Method newInstanceMethod;
/*    */   
/*    */   public PercSerializationInstantiator(Class<T> type)
/*    */   {
/* 45 */     Class<? super T> unserializableType = type;
/*    */     
/* 47 */     while (Serializable.class.isAssignableFrom(unserializableType)) {
/* 48 */       unserializableType = unserializableType.getSuperclass();
/*    */     }
/*    */     
/*    */     try
/*    */     {
/* 53 */       Class<?> percMethodClass = Class.forName("COM.newmonics.PercClassLoader.Method");
/*    */       
/* 55 */       this.newInstanceMethod = ObjectInputStream.class.getDeclaredMethod("noArgConstruct", new Class[] { Class.class, Object.class, percMethodClass });
/*    */       
/* 57 */       this.newInstanceMethod.setAccessible(true);
/*    */       
/*    */ 
/* 60 */       Class<?> percClassClass = Class.forName("COM.newmonics.PercClassLoader.PercClass");
/* 61 */       Method getPercClassMethod = percClassClass.getDeclaredMethod("getPercClass", new Class[] { Class.class });
/* 62 */       Object someObject = getPercClassMethod.invoke(null, new Object[] { unserializableType });
/* 63 */       Method findMethodMethod = someObject.getClass().getDeclaredMethod("findMethod", new Class[] { String.class });
/*    */       
/* 65 */       Object percMethod = findMethodMethod.invoke(someObject, new Object[] { "<init>()V" });
/*    */       
/* 67 */       this.typeArgs = new Object[] { unserializableType, type, percMethod };
/*    */     }
/*    */     catch (ClassNotFoundException e)
/*    */     {
/* 71 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (NoSuchMethodException e) {
/* 74 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (InvocationTargetException e) {
/* 77 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (IllegalAccessException e) {
/* 80 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */   
/*    */   public T newInstance()
/*    */   {
/*    */     try {
/* 87 */       return (T)this.newInstanceMethod.invoke(null, this.typeArgs);
/*    */     }
/*    */     catch (IllegalAccessException e) {
/* 90 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (InvocationTargetException e) {
/* 93 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\objenesis\instantiator\perc\PercSerializationInstantiator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */