/*     */ package org.springframework.objenesis.instantiator.basic;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.springframework.objenesis.ObjenesisException;
/*     */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProxyingInstantiator<T>
/*     */   implements ObjectInstantiator<T>
/*     */ {
/*     */   private static final int INDEX_CLASS_THIS = 1;
/*     */   private static final int INDEX_CLASS_SUPERCLASS = 2;
/*     */   private static final int INDEX_UTF8_CONSTRUCTOR_NAME = 3;
/*     */   private static final int INDEX_UTF8_CONSTRUCTOR_DESC = 4;
/*     */   private static final int INDEX_UTF8_CODE_ATTRIBUTE = 5;
/*     */   private static final int INDEX_UTF8_CLASS = 7;
/*     */   private static final int INDEX_UTF8_SUPERCLASS = 8;
/*  45 */   private static int CONSTANT_POOL_COUNT = 9;
/*     */   
/*  47 */   private static final byte[] CODE = { 42, -79 };
/*  48 */   private static final int CODE_ATTRIBUTE_LENGTH = 12 + CODE.length;
/*     */   
/*     */   private static final String SUFFIX = "$$$Objenesis";
/*     */   
/*     */   private static final String CONSTRUCTOR_NAME = "<init>";
/*     */   
/*     */   private static final String CONSTRUCTOR_DESC = "()V";
/*     */   private final Class<?> newType;
/*     */   
/*     */   public ProxyingInstantiator(Class<T> type)
/*     */   {
/*  59 */     byte[] classBytes = writeExtendingClass(type, "$$$Objenesis");
/*     */     try
/*     */     {
/*  62 */       this.newType = ClassDefinitionUtils.defineClass(type.getName() + "$$$Objenesis", classBytes, type.getClassLoader());
/*     */     } catch (Exception e) {
/*  64 */       throw new ObjenesisException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public T newInstance()
/*     */   {
/*     */     try {
/*  71 */       return (T)this.newType.newInstance();
/*     */     } catch (InstantiationException e) {
/*  73 */       throw new ObjenesisException(e);
/*     */     } catch (IllegalAccessException e) {
/*  75 */       throw new ObjenesisException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static byte[] writeExtendingClass(Class<?> type, String suffix)
/*     */   {
/*  89 */     String parentClazz = ClassDefinitionUtils.classNameToInternalClassName(type.getName());
/*  90 */     String clazz = parentClazz + suffix;
/*     */     
/*  92 */     DataOutputStream in = null;
/*  93 */     bIn = new ByteArrayOutputStream(1000);
/*     */     try {
/*  95 */       in = new DataOutputStream(bIn);
/*     */       
/*  97 */       in.write(ClassDefinitionUtils.MAGIC);
/*  98 */       in.write(ClassDefinitionUtils.VERSION);
/*  99 */       in.writeShort(CONSTANT_POOL_COUNT);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 104 */       in.writeByte(7);
/* 105 */       in.writeShort(7);
/*     */       
/*     */ 
/* 108 */       in.writeByte(7);
/* 109 */       in.writeShort(8);
/*     */       
/*     */ 
/* 112 */       in.writeByte(1);
/* 113 */       in.writeUTF("<init>");
/*     */       
/*     */ 
/* 116 */       in.writeByte(1);
/* 117 */       in.writeUTF("()V");
/*     */       
/*     */ 
/* 120 */       in.writeByte(1);
/* 121 */       in.writeUTF("Code");
/*     */       
/*     */ 
/* 124 */       in.writeByte(1);
/* 125 */       in.writeUTF("L" + clazz + ";");
/*     */       
/*     */ 
/* 128 */       in.writeByte(1);
/* 129 */       in.writeUTF(clazz);
/*     */       
/*     */ 
/* 132 */       in.writeByte(1);
/* 133 */       in.writeUTF(parentClazz);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 138 */       in.writeShort(33);
/*     */       
/*     */ 
/* 141 */       in.writeShort(1);
/*     */       
/*     */ 
/* 144 */       in.writeShort(2);
/*     */       
/*     */ 
/* 147 */       in.writeShort(0);
/*     */       
/*     */ 
/* 150 */       in.writeShort(0);
/*     */       
/*     */ 
/* 153 */       in.writeShort(1);
/*     */       
/*     */ 
/* 156 */       in.writeShort(1);
/* 157 */       in.writeShort(3);
/* 158 */       in.writeShort(4);
/* 159 */       in.writeShort(1);
/*     */       
/*     */ 
/* 162 */       in.writeShort(5);
/* 163 */       in.writeInt(CODE_ATTRIBUTE_LENGTH);
/* 164 */       in.writeShort(1);
/* 165 */       in.writeShort(1);
/* 166 */       in.writeInt(CODE.length);
/* 167 */       in.write(CODE);
/* 168 */       in.writeShort(0);
/* 169 */       in.writeShort(0);
/*     */       
/*     */ 
/* 172 */       in.writeShort(0);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 187 */       return bIn.toByteArray();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 176 */       throw new ObjenesisException(e);
/*     */     } finally {
/* 178 */       if (in != null) {
/*     */         try {
/* 180 */           in.close();
/*     */         } catch (IOException e) {
/* 182 */           throw new ObjenesisException(e);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\objenesis\instantiator\basic\ProxyingInstantiator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */