/*    */ package org.springframework.objenesis.instantiator.perc;
/*    */ 
/*    */ import java.io.ObjectInputStream;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PercInstantiator<T>
/*    */   implements ObjectInstantiator<T>
/*    */ {
/*    */   private final Method newInstanceMethod;
/* 36 */   private final Object[] typeArgs = { null, Boolean.FALSE };
/*    */   
/*    */   public PercInstantiator(Class<T> type)
/*    */   {
/* 40 */     this.typeArgs[0] = type;
/*    */     try
/*    */     {
/* 43 */       this.newInstanceMethod = ObjectInputStream.class.getDeclaredMethod("newInstance", new Class[] { Class.class, Boolean.TYPE });
/*    */       
/* 45 */       this.newInstanceMethod.setAccessible(true);
/*    */     }
/*    */     catch (RuntimeException e) {
/* 48 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (NoSuchMethodException e) {
/* 51 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */   
/*    */   public T newInstance()
/*    */   {
/*    */     try {
/* 58 */       return (T)this.newInstanceMethod.invoke(null, this.typeArgs);
/*    */     } catch (Exception e) {
/* 60 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\objenesis\instantiator\perc\PercInstantiator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */