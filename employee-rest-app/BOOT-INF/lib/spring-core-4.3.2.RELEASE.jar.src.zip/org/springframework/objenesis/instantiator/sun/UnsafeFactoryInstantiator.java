/*    */ package org.springframework.objenesis.instantiator.sun;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ import sun.misc.Unsafe;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsafeFactoryInstantiator<T>
/*    */   implements ObjectInstantiator<T>
/*    */ {
/*    */   private static Unsafe unsafe;
/*    */   private final Class<T> type;
/*    */   
/*    */   public UnsafeFactoryInstantiator(Class<T> type)
/*    */   {
/* 39 */     if (unsafe == null)
/*    */     {
/*    */       try {
/* 42 */         f = Unsafe.class.getDeclaredField("theUnsafe");
/*    */       } catch (NoSuchFieldException e) { Field f;
/* 44 */         throw new ObjenesisException(e); }
/*    */       Field f;
/* 46 */       f.setAccessible(true);
/*    */       try {
/* 48 */         unsafe = (Unsafe)f.get(null);
/*    */       } catch (IllegalAccessException e) {
/* 50 */         throw new ObjenesisException(e);
/*    */       }
/*    */     }
/* 53 */     this.type = type;
/*    */   }
/*    */   
/*    */   public T newInstance() {
/*    */     try {
/* 58 */       return (T)this.type.cast(unsafe.allocateInstance(this.type));
/*    */     } catch (InstantiationException e) {
/* 60 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\objenesis\instantiator\sun\UnsafeFactoryInstantiator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */