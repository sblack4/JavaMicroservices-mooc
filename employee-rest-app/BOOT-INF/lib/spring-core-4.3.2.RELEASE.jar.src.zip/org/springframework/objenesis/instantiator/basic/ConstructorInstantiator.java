/*    */ package org.springframework.objenesis.instantiator.basic;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstructorInstantiator<T>
/*    */   implements ObjectInstantiator<T>
/*    */ {
/*    */   protected Constructor<T> constructor;
/*    */   
/*    */   public ConstructorInstantiator(Class<T> type)
/*    */   {
/*    */     try
/*    */     {
/* 37 */       this.constructor = type.getDeclaredConstructor((Class[])null);
/*    */     }
/*    */     catch (Exception e) {
/* 40 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */   
/*    */   public T newInstance() {
/*    */     try {
/* 46 */       return (T)this.constructor.newInstance((Object[])null);
/*    */     }
/*    */     catch (Exception e) {
/* 49 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\objenesis\instantiator\basic\ConstructorInstantiator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */