/*    */ package org.springframework.objenesis.instantiator.gcj;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.SerializationInstantiatorHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GCJSerializationInstantiator<T>
/*    */   extends GCJInstantiatorBase<T>
/*    */ {
/*    */   private Class<? super T> superType;
/*    */   
/*    */   public GCJSerializationInstantiator(Class<T> type)
/*    */   {
/* 33 */     super(type);
/* 34 */     this.superType = SerializationInstantiatorHelper.getNonSerializableSuperClass(type);
/*    */   }
/*    */   
/*    */   public T newInstance()
/*    */   {
/*    */     try {
/* 40 */       return (T)this.type.cast(newObjectMethod.invoke(dummyStream, new Object[] { this.type, this.superType }));
/*    */     }
/*    */     catch (Exception e) {
/* 43 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\objenesis\instantiator\gcj\GCJSerializationInstantiator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */