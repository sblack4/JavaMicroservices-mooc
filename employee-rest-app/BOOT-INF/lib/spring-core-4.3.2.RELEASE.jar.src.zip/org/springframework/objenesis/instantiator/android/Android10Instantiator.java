/*    */ package org.springframework.objenesis.instantiator.android;
/*    */ 
/*    */ import java.io.ObjectInputStream;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Android10Instantiator<T>
/*    */   implements ObjectInstantiator<T>
/*    */ {
/*    */   private final Class<T> type;
/*    */   private final Method newStaticMethod;
/*    */   
/*    */   public Android10Instantiator(Class<T> type)
/*    */   {
/* 36 */     this.type = type;
/* 37 */     this.newStaticMethod = getNewStaticMethod();
/*    */   }
/*    */   
/*    */   public T newInstance() {
/*    */     try {
/* 42 */       return (T)this.type.cast(this.newStaticMethod.invoke(null, new Object[] { this.type, Object.class }));
/*    */     }
/*    */     catch (Exception e) {
/* 45 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */   
/*    */   private static Method getNewStaticMethod() {
/*    */     try {
/* 51 */       Method newStaticMethod = ObjectInputStream.class.getDeclaredMethod("newInstance", new Class[] { Class.class, Class.class });
/*    */       
/* 53 */       newStaticMethod.setAccessible(true);
/* 54 */       return newStaticMethod;
/*    */     }
/*    */     catch (RuntimeException e) {
/* 57 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (NoSuchMethodException e) {
/* 60 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\objenesis\instantiator\android\Android10Instantiator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */