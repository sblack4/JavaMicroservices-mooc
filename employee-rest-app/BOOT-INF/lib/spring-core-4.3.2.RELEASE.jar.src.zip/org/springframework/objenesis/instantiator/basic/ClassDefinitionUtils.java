/*     */ package org.springframework.objenesis.instantiator.basic;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.ProtectionDomain;
/*     */ import org.springframework.objenesis.ObjenesisException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ClassDefinitionUtils
/*     */ {
/*     */   public static final byte OPS_aload_0 = 42;
/*     */   public static final byte OPS_invokespecial = -73;
/*     */   public static final byte OPS_return = -79;
/*     */   public static final byte OPS_new = -69;
/*     */   public static final byte OPS_dup = 89;
/*     */   public static final byte OPS_areturn = -80;
/*     */   public static final int CONSTANT_Utf8 = 1;
/*     */   public static final int CONSTANT_Integer = 3;
/*     */   public static final int CONSTANT_Float = 4;
/*     */   public static final int CONSTANT_Long = 5;
/*     */   public static final int CONSTANT_Double = 6;
/*     */   public static final int CONSTANT_Class = 7;
/*     */   public static final int CONSTANT_String = 8;
/*     */   public static final int CONSTANT_Fieldref = 9;
/*     */   public static final int CONSTANT_Methodref = 10;
/*     */   public static final int CONSTANT_InterfaceMethodref = 11;
/*     */   public static final int CONSTANT_NameAndType = 12;
/*     */   public static final int CONSTANT_MethodHandle = 15;
/*     */   public static final int CONSTANT_MethodType = 16;
/*     */   public static final int CONSTANT_InvokeDynamic = 18;
/*     */   public static final int ACC_PUBLIC = 1;
/*     */   public static final int ACC_FINAL = 16;
/*     */   public static final int ACC_SUPER = 32;
/*     */   public static final int ACC_INTERFACE = 512;
/*     */   public static final int ACC_ABSTRACT = 1024;
/*     */   public static final int ACC_SYNTHETIC = 4096;
/*     */   public static final int ACC_ANNOTATION = 8192;
/*     */   public static final int ACC_ENUM = 16384;
/*  84 */   public static final byte[] MAGIC = { -54, -2, -70, -66 };
/*  85 */   public static final byte[] VERSION = { 0, 0, 0, 49 };
/*     */   
/*     */ 
/*     */ 
/*     */   private static Method DEFINE_CLASS;
/*     */   
/*     */ 
/*     */ 
/*  93 */   private static final ProtectionDomain PROTECTION_DOMAIN = (ProtectionDomain)AccessController.doPrivileged(new PrivilegedAction() {
/*     */     public ProtectionDomain run() {
/*  95 */       return ClassDefinitionUtils.class.getProtectionDomain();
/*     */     }
/*  93 */   });
/*     */   
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  99 */     AccessController.doPrivileged(new PrivilegedAction() {
/*     */       public Object run() {
/*     */         try {
/* 102 */           Class<?> loader = Class.forName("java.lang.ClassLoader");
/* 103 */           ClassDefinitionUtils.access$002(loader.getDeclaredMethod("defineClass", new Class[] { String.class, byte[].class, Integer.TYPE, Integer.TYPE, ProtectionDomain.class }));
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 109 */           ClassDefinitionUtils.DEFINE_CLASS.setAccessible(true);
/*     */         } catch (ClassNotFoundException e) {
/* 111 */           throw new ObjenesisException(e);
/*     */         } catch (NoSuchMethodException e) {
/* 113 */           throw new ObjenesisException(e);
/*     */         }
/* 115 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T> Class<T> defineClass(String className, byte[] b, ClassLoader loader)
/*     */     throws Exception
/*     */   {
/* 134 */     Object[] args = { className, b, new Integer(0), new Integer(b.length), PROTECTION_DOMAIN };
/* 135 */     Class<T> c = (Class)DEFINE_CLASS.invoke(loader, args);
/*     */     
/* 137 */     Class.forName(className, true, loader);
/* 138 */     return c;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] readClass(String className)
/*     */     throws IOException
/*     */   {
/* 151 */     className = classNameToResource(className);
/*     */     
/* 153 */     byte[] b = new byte['ৄ'];
/*     */     
/*     */ 
/*     */ 
/* 157 */     InputStream in = ClassDefinitionUtils.class.getClassLoader().getResourceAsStream(className);
/*     */     int length;
/* 159 */     try { length = in.read(b);
/*     */     }
/*     */     finally {
/* 162 */       in.close();
/*     */     }
/*     */     
/* 165 */     if (length >= 2500) {
/* 166 */       throw new IllegalArgumentException("The class is longer that 2500 bytes which is currently unsupported");
/*     */     }
/*     */     
/* 169 */     byte[] copy = new byte[length];
/* 170 */     System.arraycopy(b, 0, copy, 0, length);
/* 171 */     return copy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String classNameToInternalClassName(String className)
/*     */   {
/* 199 */     return className.replace('.', '/');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String classNameToResource(String className)
/*     */   {
/* 210 */     return classNameToInternalClassName(className) + ".class";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T> Class<T> getExistingClass(ClassLoader classLoader, String className)
/*     */   {
/*     */     try
/*     */     {
/* 224 */       return Class.forName(className, true, classLoader);
/*     */     }
/*     */     catch (ClassNotFoundException e) {}
/* 227 */     return null;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public static void writeClass(String fileName, byte[] bytes)
/*     */     throws IOException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 161	java/io/BufferedOutputStream
/*     */     //   3: dup
/*     */     //   4: new 163	java/io/FileOutputStream
/*     */     //   7: dup
/*     */     //   8: aload_0
/*     */     //   9: invokespecial 164	java/io/FileOutputStream:<init>	(Ljava/lang/String;)V
/*     */     //   12: invokespecial 167	java/io/BufferedOutputStream:<init>	(Ljava/io/OutputStream;)V
/*     */     //   15: astore_2
/*     */     //   16: aload_2
/*     */     //   17: aload_1
/*     */     //   18: invokevirtual 171	java/io/BufferedOutputStream:write	([B)V
/*     */     //   21: aload_2
/*     */     //   22: invokevirtual 172	java/io/BufferedOutputStream:close	()V
/*     */     //   25: goto +10 -> 35
/*     */     //   28: astore_3
/*     */     //   29: aload_2
/*     */     //   30: invokevirtual 172	java/io/BufferedOutputStream:close	()V
/*     */     //   33: aload_3
/*     */     //   34: athrow
/*     */     //   35: return
/*     */     // Line number table:
/*     */     //   Java source line #182	-> byte code offset #0
/*     */     //   Java source line #184	-> byte code offset #16
/*     */     //   Java source line #187	-> byte code offset #21
/*     */     //   Java source line #188	-> byte code offset #25
/*     */     //   Java source line #187	-> byte code offset #28
/*     */     //   Java source line #189	-> byte code offset #35
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	36	0	fileName	String
/*     */     //   0	36	1	bytes	byte[]
/*     */     //   15	15	2	out	java.io.BufferedOutputStream
/*     */     //   28	6	3	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   16	21	28	finally
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\objenesis\instantiator\basic\ClassDefinitionUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */