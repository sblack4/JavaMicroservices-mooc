/*    */ package org.springframework.cglib.transform;
/*    */ 
/*    */ import org.springframework.asm.ClassVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassTransformerTee
/*    */   extends ClassTransformer
/*    */ {
/*    */   private ClassVisitor branch;
/*    */   
/*    */   public ClassTransformerTee(ClassVisitor branch)
/*    */   {
/* 25 */     super(327680);
/* 26 */     this.branch = branch;
/*    */   }
/*    */   
/*    */   public void setTarget(ClassVisitor target) {
/* 30 */     this.cv = new ClassVisitorTee(this.branch, target);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\cglib\transform\ClassTransformerTee.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */