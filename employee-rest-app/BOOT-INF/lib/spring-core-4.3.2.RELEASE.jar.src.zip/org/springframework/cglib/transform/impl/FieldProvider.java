package org.springframework.cglib.transform.impl;

public abstract interface FieldProvider
{
  public abstract String[] getFieldNames();
  
  public abstract Class[] getFieldTypes();
  
  public abstract void setField(int paramInt, Object paramObject);
  
  public abstract Object getField(int paramInt);
  
  public abstract void setField(String paramString, Object paramObject);
  
  public abstract Object getField(String paramString);
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\cglib\transform\impl\FieldProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */