/*     */ package org.springframework.cglib.core;
/*     */ 
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.asm.Attribute;
/*     */ import org.springframework.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectUtils
/*     */ {
/*  33 */   private static final Map primitives = new HashMap(8);
/*  34 */   private static final Map transforms = new HashMap(8);
/*  35 */   private static final ClassLoader defaultLoader = ReflectUtils.class.getClassLoader();
/*     */   
/*     */   private static Method DEFINE_CLASS;
/*     */   private static final ProtectionDomain PROTECTION_DOMAIN;
/*  39 */   private static final List<Method> OBJECT_METHODS = new ArrayList();
/*     */   private static final String[] CGLIB_PACKAGES;
/*     */   
/*  42 */   static { PROTECTION_DOMAIN = getProtectionDomain(ReflectUtils.class);
/*     */     
/*  44 */     AccessController.doPrivileged(new PrivilegedAction() {
/*     */       public Object run() {
/*     */         try {
/*  47 */           Class loader = Class.forName("java.lang.ClassLoader");
/*  48 */           ReflectUtils.access$002(loader.getDeclaredMethod("defineClass", new Class[] { String.class, byte[].class, Integer.TYPE, Integer.TYPE, ProtectionDomain.class }));
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  54 */           ReflectUtils.DEFINE_CLASS.setAccessible(true);
/*     */         } catch (ClassNotFoundException e) {
/*  56 */           throw new CodeGenerationException(e);
/*     */         } catch (NoSuchMethodException e) {
/*  58 */           throw new CodeGenerationException(e);
/*     */         }
/*  60 */         return null;
/*     */       }
/*  62 */     });
/*  63 */     Method[] methods = Object.class.getDeclaredMethods();
/*  64 */     for (Method method : methods) {
/*  65 */       if ((!"finalize".equals(method.getName())) && 
/*  66 */         ((method.getModifiers() & 0x18) <= 0))
/*     */       {
/*     */ 
/*  69 */         OBJECT_METHODS.add(method);
/*     */       }
/*     */     }
/*     */     
/*  73 */     CGLIB_PACKAGES = new String[] { "java.lang" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  78 */     primitives.put("byte", Byte.TYPE);
/*  79 */     primitives.put("char", Character.TYPE);
/*  80 */     primitives.put("double", Double.TYPE);
/*  81 */     primitives.put("float", Float.TYPE);
/*  82 */     primitives.put("int", Integer.TYPE);
/*  83 */     primitives.put("long", Long.TYPE);
/*  84 */     primitives.put("short", Short.TYPE);
/*  85 */     primitives.put("boolean", Boolean.TYPE);
/*     */     
/*  87 */     transforms.put("byte", "B");
/*  88 */     transforms.put("char", "C");
/*  89 */     transforms.put("double", "D");
/*  90 */     transforms.put("float", "F");
/*  91 */     transforms.put("int", "I");
/*  92 */     transforms.put("long", "J");
/*  93 */     transforms.put("short", "S");
/*  94 */     transforms.put("boolean", "Z");
/*     */   }
/*     */   
/*     */   public static ProtectionDomain getProtectionDomain(Class source) {
/*  98 */     if (source == null) {
/*  99 */       return null;
/*     */     }
/* 101 */     (ProtectionDomain)AccessController.doPrivileged(new PrivilegedAction() {
/*     */       public Object run() {
/* 103 */         return this.val$source.getProtectionDomain();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public static Type[] getExceptionTypes(Member member) {
/* 109 */     if ((member instanceof Method))
/* 110 */       return TypeUtils.getTypes(((Method)member).getExceptionTypes());
/* 111 */     if ((member instanceof Constructor)) {
/* 112 */       return TypeUtils.getTypes(((Constructor)member).getExceptionTypes());
/*     */     }
/* 114 */     throw new IllegalArgumentException("Cannot get exception types of a field");
/*     */   }
/*     */   
/*     */   public static Signature getSignature(Member member)
/*     */   {
/* 119 */     if ((member instanceof Method))
/* 120 */       return new Signature(member.getName(), Type.getMethodDescriptor((Method)member));
/* 121 */     if ((member instanceof Constructor)) {
/* 122 */       Type[] types = TypeUtils.getTypes(((Constructor)member).getParameterTypes());
/*     */       
/* 124 */       return new Signature("<init>", Type.getMethodDescriptor(Type.VOID_TYPE, types));
/*     */     }
/*     */     
/* 127 */     throw new IllegalArgumentException("Cannot get signature of a field");
/*     */   }
/*     */   
/*     */   public static Constructor findConstructor(String desc)
/*     */   {
/* 132 */     return findConstructor(desc, defaultLoader);
/*     */   }
/*     */   
/*     */   public static Constructor findConstructor(String desc, ClassLoader loader) {
/*     */     try {
/* 137 */       int lparen = desc.indexOf('(');
/* 138 */       String className = desc.substring(0, lparen).trim();
/* 139 */       return getClass(className, loader).getConstructor(parseTypes(desc, loader));
/*     */     } catch (ClassNotFoundException e) {
/* 141 */       throw new CodeGenerationException(e);
/*     */     } catch (NoSuchMethodException e) {
/* 143 */       throw new CodeGenerationException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Method findMethod(String desc) {
/* 148 */     return findMethod(desc, defaultLoader);
/*     */   }
/*     */   
/*     */   public static Method findMethod(String desc, ClassLoader loader) {
/*     */     try {
/* 153 */       int lparen = desc.indexOf('(');
/* 154 */       int dot = desc.lastIndexOf('.', lparen);
/* 155 */       String className = desc.substring(0, dot).trim();
/* 156 */       String methodName = desc.substring(dot + 1, lparen).trim();
/* 157 */       return getClass(className, loader).getDeclaredMethod(methodName, parseTypes(desc, loader));
/*     */     } catch (ClassNotFoundException e) {
/* 159 */       throw new CodeGenerationException(e);
/*     */     } catch (NoSuchMethodException e) {
/* 161 */       throw new CodeGenerationException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   private static Class[] parseTypes(String desc, ClassLoader loader) throws ClassNotFoundException {
/* 166 */     int lparen = desc.indexOf('(');
/* 167 */     int rparen = desc.indexOf(')', lparen);
/* 168 */     List params = new ArrayList();
/* 169 */     int start = lparen + 1;
/*     */     for (;;) {
/* 171 */       int comma = desc.indexOf(',', start);
/* 172 */       if (comma < 0) {
/*     */         break;
/*     */       }
/* 175 */       params.add(desc.substring(start, comma).trim());
/* 176 */       start = comma + 1;
/*     */     }
/* 178 */     if (start < rparen) {
/* 179 */       params.add(desc.substring(start, rparen).trim());
/*     */     }
/* 181 */     Class[] types = new Class[params.size()];
/* 182 */     for (int i = 0; i < types.length; i++) {
/* 183 */       types[i] = getClass((String)params.get(i), loader);
/*     */     }
/* 185 */     return types;
/*     */   }
/*     */   
/*     */   private static Class getClass(String className, ClassLoader loader) throws ClassNotFoundException {
/* 189 */     return getClass(className, loader, CGLIB_PACKAGES);
/*     */   }
/*     */   
/*     */   private static Class getClass(String className, ClassLoader loader, String[] packages) throws ClassNotFoundException {
/* 193 */     String save = className;
/* 194 */     int dimensions = 0;
/* 195 */     int index = 0;
/* 196 */     while ((index = className.indexOf("[]", index) + 1) > 0) {
/* 197 */       dimensions++;
/*     */     }
/* 199 */     StringBuffer brackets = new StringBuffer(className.length() - dimensions);
/* 200 */     for (int i = 0; i < dimensions; i++) {
/* 201 */       brackets.append('[');
/*     */     }
/* 203 */     className = className.substring(0, className.length() - 2 * dimensions);
/*     */     
/* 205 */     String prefix = dimensions > 0 ? brackets + "L" : "";
/* 206 */     String suffix = dimensions > 0 ? ";" : "";
/*     */     try {
/* 208 */       return Class.forName(prefix + className + suffix, false, loader);
/*     */     } catch (ClassNotFoundException localClassNotFoundException) {
/* 210 */       for (int i = 0; i < packages.length; i++) {
/*     */         try {
/* 212 */           return Class.forName(prefix + packages[i] + '.' + className + suffix, false, loader);
/*     */         } catch (ClassNotFoundException localClassNotFoundException1) {}
/*     */       }
/* 215 */       if (dimensions == 0) {
/* 216 */         Class c = (Class)primitives.get(className);
/* 217 */         if (c != null) {
/* 218 */           return c;
/*     */         }
/*     */       } else {
/* 221 */         String transform = (String)transforms.get(className);
/* 222 */         if (transform != null) {
/*     */           try {
/* 224 */             return Class.forName(brackets + transform, false, loader);
/*     */           } catch (ClassNotFoundException localClassNotFoundException2) {}
/*     */         }
/*     */       }
/* 228 */       throw new ClassNotFoundException(save);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Object newInstance(Class type) {
/* 233 */     return newInstance(type, Constants.EMPTY_CLASS_ARRAY, null);
/*     */   }
/*     */   
/*     */   public static Object newInstance(Class type, Class[] parameterTypes, Object[] args) {
/* 237 */     return newInstance(getConstructor(type, parameterTypes), args);
/*     */   }
/*     */   
/*     */   public static Object newInstance(Constructor cstruct, Object[] args)
/*     */   {
/* 242 */     boolean flag = cstruct.isAccessible();
/*     */     try {
/* 244 */       if (!flag) {
/* 245 */         cstruct.setAccessible(true);
/*     */       }
/* 247 */       Object result = cstruct.newInstance(args);
/* 248 */       return result;
/*     */     } catch (InstantiationException e) {
/* 250 */       throw new CodeGenerationException(e);
/*     */     } catch (IllegalAccessException e) {
/* 252 */       throw new CodeGenerationException(e);
/*     */     } catch (InvocationTargetException e) {
/* 254 */       throw new CodeGenerationException(e.getTargetException());
/*     */     } finally {
/* 256 */       if (!flag) {
/* 257 */         cstruct.setAccessible(flag);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static Constructor getConstructor(Class type, Class[] parameterTypes)
/*     */   {
/*     */     try {
/* 265 */       Constructor constructor = type.getDeclaredConstructor(parameterTypes);
/* 266 */       constructor.setAccessible(true);
/* 267 */       return constructor;
/*     */     } catch (NoSuchMethodException e) {
/* 269 */       throw new CodeGenerationException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public static String[] getNames(Class[] classes)
/*     */   {
/* 275 */     if (classes == null)
/* 276 */       return null;
/* 277 */     String[] names = new String[classes.length];
/* 278 */     for (int i = 0; i < names.length; i++) {
/* 279 */       names[i] = classes[i].getName();
/*     */     }
/* 281 */     return names;
/*     */   }
/*     */   
/*     */   public static Class[] getClasses(Object[] objects) {
/* 285 */     Class[] classes = new Class[objects.length];
/* 286 */     for (int i = 0; i < objects.length; i++) {
/* 287 */       classes[i] = objects[i].getClass();
/*     */     }
/* 289 */     return classes;
/*     */   }
/*     */   
/*     */   public static Method findNewInstance(Class iface) {
/* 293 */     Method m = findInterfaceMethod(iface);
/* 294 */     if (!m.getName().equals("newInstance")) {
/* 295 */       throw new IllegalArgumentException(iface + " missing newInstance method");
/*     */     }
/* 297 */     return m;
/*     */   }
/*     */   
/*     */   public static Method[] getPropertyMethods(PropertyDescriptor[] properties, boolean read, boolean write) {
/* 301 */     Set methods = new HashSet();
/* 302 */     for (int i = 0; i < properties.length; i++) {
/* 303 */       PropertyDescriptor pd = properties[i];
/* 304 */       if (read) {
/* 305 */         methods.add(pd.getReadMethod());
/*     */       }
/* 307 */       if (write) {
/* 308 */         methods.add(pd.getWriteMethod());
/*     */       }
/*     */     }
/* 311 */     methods.remove(null);
/* 312 */     return (Method[])methods.toArray(new Method[methods.size()]);
/*     */   }
/*     */   
/*     */   public static PropertyDescriptor[] getBeanProperties(Class type) {
/* 316 */     return getPropertiesHelper(type, true, true);
/*     */   }
/*     */   
/*     */   public static PropertyDescriptor[] getBeanGetters(Class type) {
/* 320 */     return getPropertiesHelper(type, true, false);
/*     */   }
/*     */   
/*     */   public static PropertyDescriptor[] getBeanSetters(Class type) {
/* 324 */     return getPropertiesHelper(type, false, true);
/*     */   }
/*     */   
/*     */   private static PropertyDescriptor[] getPropertiesHelper(Class type, boolean read, boolean write) {
/*     */     try {
/* 329 */       BeanInfo info = Introspector.getBeanInfo(type, Object.class);
/* 330 */       PropertyDescriptor[] all = info.getPropertyDescriptors();
/* 331 */       if ((read) && (write)) {
/* 332 */         return all;
/*     */       }
/* 334 */       List properties = new ArrayList(all.length);
/* 335 */       for (int i = 0; i < all.length; i++) {
/* 336 */         PropertyDescriptor pd = all[i];
/* 337 */         if (((read) && (pd.getReadMethod() != null)) || ((write) && 
/* 338 */           (pd.getWriteMethod() != null))) {
/* 339 */           properties.add(pd);
/*     */         }
/*     */       }
/* 342 */       return (PropertyDescriptor[])properties.toArray(new PropertyDescriptor[properties.size()]);
/*     */     } catch (IntrospectionException e) {
/* 344 */       throw new CodeGenerationException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Method findDeclaredMethod(Class type, String methodName, Class[] parameterTypes)
/*     */     throws NoSuchMethodException
/*     */   {
/* 354 */     Class cl = type;
/* 355 */     while (cl != null) {
/*     */       try {
/* 357 */         return cl.getDeclaredMethod(methodName, parameterTypes);
/*     */       } catch (NoSuchMethodException e) {
/* 359 */         cl = cl.getSuperclass();
/*     */       }
/*     */     }
/* 362 */     throw new NoSuchMethodException(methodName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static List addAllMethods(Class type, List list)
/*     */   {
/* 369 */     if (type == Object.class) {
/* 370 */       list.addAll(OBJECT_METHODS);
/*     */     } else {
/* 372 */       list.addAll(Arrays.asList(type.getDeclaredMethods()));
/*     */     }
/* 374 */     Class superclass = type.getSuperclass();
/* 375 */     if (superclass != null) {
/* 376 */       addAllMethods(superclass, list);
/*     */     }
/* 378 */     Class[] interfaces = type.getInterfaces();
/* 379 */     for (int i = 0; i < interfaces.length; i++) {
/* 380 */       addAllMethods(interfaces[i], list);
/*     */     }
/*     */     
/* 383 */     return list;
/*     */   }
/*     */   
/*     */   public static List addAllInterfaces(Class type, List list) {
/* 387 */     Class superclass = type.getSuperclass();
/* 388 */     if (superclass != null) {
/* 389 */       list.addAll(Arrays.asList(type.getInterfaces()));
/* 390 */       addAllInterfaces(superclass, list);
/*     */     }
/* 392 */     return list;
/*     */   }
/*     */   
/*     */   public static Method findInterfaceMethod(Class iface)
/*     */   {
/* 397 */     if (!iface.isInterface()) {
/* 398 */       throw new IllegalArgumentException(iface + " is not an interface");
/*     */     }
/* 400 */     Method[] methods = iface.getDeclaredMethods();
/* 401 */     if (methods.length != 1) {
/* 402 */       throw new IllegalArgumentException("expecting exactly 1 method in " + iface);
/*     */     }
/* 404 */     return methods[0];
/*     */   }
/*     */   
/*     */   public static Class defineClass(String className, byte[] b, ClassLoader loader) throws Exception {
/* 408 */     return defineClass(className, b, loader, PROTECTION_DOMAIN);
/*     */   }
/*     */   
/*     */   public static Class defineClass(String className, byte[] b, ClassLoader loader, ProtectionDomain protectionDomain) throws Exception {
/* 412 */     Object[] args = { className, b, new Integer(0), new Integer(b.length), protectionDomain };
/* 413 */     Class c = (Class)DEFINE_CLASS.invoke(loader, args);
/*     */     
/* 415 */     Class.forName(className, true, loader);
/* 416 */     return c;
/*     */   }
/*     */   
/*     */   public static int findPackageProtected(Class[] classes) {
/* 420 */     for (int i = 0; i < classes.length; i++) {
/* 421 */       if (!Modifier.isPublic(classes[i].getModifiers())) {
/* 422 */         return i;
/*     */       }
/*     */     }
/* 425 */     return 0;
/*     */   }
/*     */   
/*     */   public static MethodInfo getMethodInfo(Member member, final int modifiers) {
/* 429 */     final Signature sig = getSignature(member);
/* 430 */     new MethodInfo() {
/*     */       private ClassInfo ci;
/*     */       
/* 433 */       public ClassInfo getClassInfo() { if (this.ci == null)
/* 434 */           this.ci = ReflectUtils.getClassInfo(this.val$member.getDeclaringClass());
/* 435 */         return this.ci;
/*     */       }
/*     */       
/* 438 */       public int getModifiers() { return modifiers; }
/*     */       
/*     */       public Signature getSignature() {
/* 441 */         return sig;
/*     */       }
/*     */       
/* 444 */       public Type[] getExceptionTypes() { return ReflectUtils.getExceptionTypes(this.val$member); }
/*     */       
/*     */       public Attribute getAttribute() {
/* 447 */         return null;
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public static MethodInfo getMethodInfo(Member member) {
/* 453 */     return getMethodInfo(member, member.getModifiers());
/*     */   }
/*     */   
/*     */   public static ClassInfo getClassInfo(final Class clazz) {
/* 457 */     Type type = Type.getType(clazz);
/* 458 */     final Type sc = clazz.getSuperclass() == null ? null : Type.getType(clazz.getSuperclass());
/* 459 */     new ClassInfo() {
/*     */       public Type getType() {
/* 461 */         return this.val$type;
/*     */       }
/*     */       
/* 464 */       public Type getSuperType() { return sc; }
/*     */       
/*     */       public Type[] getInterfaces() {
/* 467 */         return TypeUtils.getTypes(clazz.getInterfaces());
/*     */       }
/*     */       
/* 470 */       public int getModifiers() { return clazz.getModifiers(); }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Method[] findMethods(String[] namesAndDescriptors, Method[] methods)
/*     */   {
/* 478 */     Map map = new HashMap();
/* 479 */     for (int i = 0; i < methods.length; i++) {
/* 480 */       Method method = methods[i];
/* 481 */       map.put(method.getName() + Type.getMethodDescriptor(method), method);
/*     */     }
/* 483 */     Method[] result = new Method[namesAndDescriptors.length / 2];
/* 484 */     for (int i = 0; i < result.length; i++) {
/* 485 */       result[i] = ((Method)map.get(namesAndDescriptors[(i * 2)] + namesAndDescriptors[(i * 2 + 1)]));
/* 486 */       if (result[i] != null) {}
/*     */     }
/*     */     
/*     */ 
/* 490 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\cglib\core\ReflectUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */