/*    */ package org.springframework.cglib.core;
/*    */ 
/*    */ import org.springframework.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Local
/*    */ {
/*    */   private Type type;
/*    */   private int index;
/*    */   
/*    */   public Local(int index, Type type)
/*    */   {
/* 26 */     this.type = type;
/* 27 */     this.index = index;
/*    */   }
/*    */   
/*    */   public int getIndex() {
/* 31 */     return this.index;
/*    */   }
/*    */   
/*    */   public Type getType() {
/* 35 */     return this.type;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\cglib\core\Local.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */