package org.springframework.cglib.core;

import org.springframework.asm.Label;

public abstract interface ProcessSwitchCallback
{
  public abstract void processCase(int paramInt, Label paramLabel)
    throws Exception;
  
  public abstract void processDefault()
    throws Exception;
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\cglib\core\ProcessSwitchCallback.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */