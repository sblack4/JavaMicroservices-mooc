package org.springframework.cglib.core;

public abstract interface Converter
{
  public abstract Object convert(Object paramObject1, Class paramClass, Object paramObject2);
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\cglib\core\Converter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */