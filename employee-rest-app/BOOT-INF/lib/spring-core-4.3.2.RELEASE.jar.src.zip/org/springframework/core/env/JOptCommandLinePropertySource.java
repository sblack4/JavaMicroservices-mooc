/*     */ package org.springframework.core.env;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import joptsimple.OptionSet;
/*     */ import joptsimple.OptionSpec;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JOptCommandLinePropertySource
/*     */   extends CommandLinePropertySource<OptionSet>
/*     */ {
/*     */   public JOptCommandLinePropertySource(OptionSet options)
/*     */   {
/*  66 */     super(options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JOptCommandLinePropertySource(String name, OptionSet options)
/*     */   {
/*  74 */     super(name, options);
/*     */   }
/*     */   
/*     */ 
/*     */   protected boolean containsOption(String name)
/*     */   {
/*  80 */     return ((OptionSet)this.source).has(name);
/*     */   }
/*     */   
/*     */   public String[] getPropertyNames()
/*     */   {
/*  85 */     List<String> names = new ArrayList();
/*  86 */     for (OptionSpec<?> spec : ((OptionSet)this.source).specs()) {
/*  87 */       List<String> aliases = new ArrayList(spec.options());
/*  88 */       if (!aliases.isEmpty())
/*     */       {
/*  90 */         names.add(aliases.get(aliases.size() - 1));
/*     */       }
/*     */     }
/*  93 */     return (String[])names.toArray(new String[names.size()]);
/*     */   }
/*     */   
/*     */   public List<String> getOptionValues(String name)
/*     */   {
/*  98 */     List<?> argValues = ((OptionSet)this.source).valuesOf(name);
/*  99 */     List<String> stringArgValues = new ArrayList();
/* 100 */     for (Object argValue : argValues) {
/* 101 */       stringArgValues.add((argValue instanceof String) ? (String)argValue : argValue.toString());
/*     */     }
/* 103 */     if (stringArgValues.isEmpty()) {
/* 104 */       return ((OptionSet)this.source).has(name) ? Collections.emptyList() : null;
/*     */     }
/* 106 */     return Collections.unmodifiableList(stringArgValues);
/*     */   }
/*     */   
/*     */   protected List<String> getNonOptionArgs()
/*     */   {
/* 111 */     List<?> argValues = ((OptionSet)this.source).nonOptionArguments();
/* 112 */     List<String> stringArgValues = new ArrayList();
/* 113 */     for (Object argValue : argValues) {
/* 114 */       Assert.isInstanceOf(String.class, argValue, "Argument values must be of type String");
/* 115 */       stringArgValues.add((String)argValue);
/*     */     }
/*     */     
/* 118 */     return stringArgValues.isEmpty() ? Collections.emptyList() : Collections.unmodifiableList(stringArgValues);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\env\JOptCommandLinePropertySource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */