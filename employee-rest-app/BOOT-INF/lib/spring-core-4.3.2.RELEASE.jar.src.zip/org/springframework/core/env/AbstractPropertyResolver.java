/*     */ package org.springframework.core.env;
/*     */ 
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.convert.support.ConfigurableConversionService;
/*     */ import org.springframework.core.convert.support.DefaultConversionService;
/*     */ import org.springframework.util.PropertyPlaceholderHelper;
/*     */ import org.springframework.util.PropertyPlaceholderHelper.PlaceholderResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractPropertyResolver
/*     */   implements ConfigurablePropertyResolver
/*     */ {
/*  39 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  41 */   protected ConfigurableConversionService conversionService = new DefaultConversionService();
/*     */   
/*     */   private PropertyPlaceholderHelper nonStrictHelper;
/*     */   
/*     */   private PropertyPlaceholderHelper strictHelper;
/*     */   
/*  47 */   private boolean ignoreUnresolvableNestedPlaceholders = false;
/*     */   
/*  49 */   private String placeholderPrefix = "${";
/*     */   
/*  51 */   private String placeholderSuffix = "}";
/*     */   
/*  53 */   private String valueSeparator = ":";
/*     */   
/*  55 */   private final Set<String> requiredProperties = new LinkedHashSet();
/*     */   
/*     */ 
/*     */   public ConfigurableConversionService getConversionService()
/*     */   {
/*  60 */     return this.conversionService;
/*     */   }
/*     */   
/*     */   public void setConversionService(ConfigurableConversionService conversionService)
/*     */   {
/*  65 */     this.conversionService = conversionService;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPlaceholderPrefix(String placeholderPrefix)
/*     */   {
/*  75 */     this.placeholderPrefix = placeholderPrefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPlaceholderSuffix(String placeholderSuffix)
/*     */   {
/*  85 */     this.placeholderSuffix = placeholderSuffix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValueSeparator(String valueSeparator)
/*     */   {
/*  97 */     this.valueSeparator = valueSeparator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIgnoreUnresolvableNestedPlaceholders(boolean ignoreUnresolvableNestedPlaceholders)
/*     */   {
/* 111 */     this.ignoreUnresolvableNestedPlaceholders = ignoreUnresolvableNestedPlaceholders;
/*     */   }
/*     */   
/*     */   public void setRequiredProperties(String... requiredProperties)
/*     */   {
/* 116 */     for (String key : requiredProperties) {
/* 117 */       this.requiredProperties.add(key);
/*     */     }
/*     */   }
/*     */   
/*     */   public void validateRequiredProperties()
/*     */   {
/* 123 */     MissingRequiredPropertiesException ex = new MissingRequiredPropertiesException();
/* 124 */     for (String key : this.requiredProperties) {
/* 125 */       if (getProperty(key) == null) {
/* 126 */         ex.addMissingRequiredProperty(key);
/*     */       }
/*     */     }
/* 129 */     if (!ex.getMissingRequiredProperties().isEmpty()) {
/* 130 */       throw ex;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean containsProperty(String key)
/*     */   {
/* 136 */     return getProperty(key) != null;
/*     */   }
/*     */   
/*     */   public String getProperty(String key)
/*     */   {
/* 141 */     return (String)getProperty(key, String.class);
/*     */   }
/*     */   
/*     */   public String getProperty(String key, String defaultValue)
/*     */   {
/* 146 */     String value = getProperty(key);
/* 147 */     return value != null ? value : defaultValue;
/*     */   }
/*     */   
/*     */   public <T> T getProperty(String key, Class<T> targetType, T defaultValue)
/*     */   {
/* 152 */     T value = getProperty(key, targetType);
/* 153 */     return value != null ? value : defaultValue;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public <T> Class<T> getPropertyAsClass(String key, Class<T> targetValueType)
/*     */   {
/* 159 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public String getRequiredProperty(String key) throws IllegalStateException
/*     */   {
/* 164 */     String value = getProperty(key);
/* 165 */     if (value == null) {
/* 166 */       throw new IllegalStateException(String.format("required key [%s] not found", new Object[] { key }));
/*     */     }
/* 168 */     return value;
/*     */   }
/*     */   
/*     */   public <T> T getRequiredProperty(String key, Class<T> valueType) throws IllegalStateException
/*     */   {
/* 173 */     T value = getProperty(key, valueType);
/* 174 */     if (value == null) {
/* 175 */       throw new IllegalStateException(String.format("required key [%s] not found", new Object[] { key }));
/*     */     }
/* 177 */     return value;
/*     */   }
/*     */   
/*     */   public String resolvePlaceholders(String text)
/*     */   {
/* 182 */     if (this.nonStrictHelper == null) {
/* 183 */       this.nonStrictHelper = createPlaceholderHelper(true);
/*     */     }
/* 185 */     return doResolvePlaceholders(text, this.nonStrictHelper);
/*     */   }
/*     */   
/*     */   public String resolveRequiredPlaceholders(String text) throws IllegalArgumentException
/*     */   {
/* 190 */     if (this.strictHelper == null) {
/* 191 */       this.strictHelper = createPlaceholderHelper(false);
/*     */     }
/* 193 */     return doResolvePlaceholders(text, this.strictHelper);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String resolveNestedPlaceholders(String value)
/*     */   {
/* 210 */     return this.ignoreUnresolvableNestedPlaceholders ? resolvePlaceholders(value) : resolveRequiredPlaceholders(value);
/*     */   }
/*     */   
/*     */   private PropertyPlaceholderHelper createPlaceholderHelper(boolean ignoreUnresolvablePlaceholders) {
/* 214 */     return new PropertyPlaceholderHelper(this.placeholderPrefix, this.placeholderSuffix, this.valueSeparator, ignoreUnresolvablePlaceholders);
/*     */   }
/*     */   
/*     */   private String doResolvePlaceholders(String text, PropertyPlaceholderHelper helper)
/*     */   {
/* 219 */     helper.replacePlaceholders(text, new PropertyPlaceholderHelper.PlaceholderResolver()
/*     */     {
/*     */       public String resolvePlaceholder(String placeholderName) {
/* 222 */         return AbstractPropertyResolver.this.getPropertyAsRawString(placeholderName);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   protected abstract String getPropertyAsRawString(String paramString);
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\env\AbstractPropertyResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */