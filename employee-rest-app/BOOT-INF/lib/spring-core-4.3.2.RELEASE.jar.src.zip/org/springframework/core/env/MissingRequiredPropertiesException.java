/*    */ package org.springframework.core.env;
/*    */ 
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MissingRequiredPropertiesException
/*    */   extends IllegalStateException
/*    */ {
/* 34 */   private final Set<String> missingRequiredProperties = new LinkedHashSet();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Set<String> getMissingRequiredProperties()
/*    */   {
/* 43 */     return this.missingRequiredProperties;
/*    */   }
/*    */   
/*    */   void addMissingRequiredProperty(String key) {
/* 47 */     this.missingRequiredProperties.add(key);
/*    */   }
/*    */   
/*    */   public String getMessage()
/*    */   {
/* 52 */     return String.format("The following properties were declared as required but could not be resolved: %s", new Object[] {
/*    */     
/* 54 */       getMissingRequiredProperties() });
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\env\MissingRequiredPropertiesException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */