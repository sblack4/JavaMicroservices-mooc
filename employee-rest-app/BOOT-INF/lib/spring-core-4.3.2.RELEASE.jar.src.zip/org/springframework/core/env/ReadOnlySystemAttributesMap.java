/*     */ package org.springframework.core.env;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ReadOnlySystemAttributesMap
/*     */   implements Map<String, String>
/*     */ {
/*     */   public boolean containsKey(Object key)
/*     */   {
/*  42 */     return get(key) != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String get(Object key)
/*     */   {
/*  51 */     if (!(key instanceof String))
/*     */     {
/*  53 */       throw new IllegalArgumentException("Type of key [" + (key != null ? key.getClass().getName() : "null") + "] must be java.lang.String.");
/*     */     }
/*     */     
/*  56 */     return getSystemAttribute((String)key);
/*     */   }
/*     */   
/*     */   public boolean isEmpty()
/*     */   {
/*  61 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract String getSystemAttribute(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int size()
/*     */   {
/*  75 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public String put(String key, String value)
/*     */   {
/*  80 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean containsValue(Object value)
/*     */   {
/*  85 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public String remove(Object key)
/*     */   {
/*  90 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void clear()
/*     */   {
/*  95 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Set<String> keySet()
/*     */   {
/* 100 */     return Collections.emptySet();
/*     */   }
/*     */   
/*     */   public void putAll(Map<? extends String, ? extends String> map)
/*     */   {
/* 105 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Collection<String> values()
/*     */   {
/* 110 */     return Collections.emptySet();
/*     */   }
/*     */   
/*     */   public Set<Map.Entry<String, String>> entrySet()
/*     */   {
/* 115 */     return Collections.emptySet();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\env\ReadOnlySystemAttributesMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */