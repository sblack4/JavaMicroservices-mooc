/*     */ package org.springframework.core.env;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MutablePropertySources
/*     */   implements PropertySources
/*     */ {
/*     */   private final Log logger;
/*  46 */   private final List<PropertySource<?>> propertySourceList = new CopyOnWriteArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MutablePropertySources()
/*     */   {
/*  53 */     this.logger = LogFactory.getLog(getClass());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MutablePropertySources(PropertySources propertySources)
/*     */   {
/*  61 */     this();
/*  62 */     for (PropertySource<?> propertySource : propertySources) {
/*  63 */       addLast(propertySource);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   MutablePropertySources(Log logger)
/*     */   {
/*  72 */     this.logger = logger;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean contains(String name)
/*     */   {
/*  78 */     return this.propertySourceList.contains(PropertySource.named(name));
/*     */   }
/*     */   
/*     */   public PropertySource<?> get(String name)
/*     */   {
/*  83 */     int index = this.propertySourceList.indexOf(PropertySource.named(name));
/*  84 */     return index != -1 ? (PropertySource)this.propertySourceList.get(index) : null;
/*     */   }
/*     */   
/*     */   public Iterator<PropertySource<?>> iterator()
/*     */   {
/*  89 */     return this.propertySourceList.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addFirst(PropertySource<?> propertySource)
/*     */   {
/*  96 */     if (this.logger.isDebugEnabled()) {
/*  97 */       this.logger.debug(String.format("Adding [%s] PropertySource with highest search precedence", new Object[] {propertySource
/*  98 */         .getName() }));
/*     */     }
/* 100 */     removeIfPresent(propertySource);
/* 101 */     this.propertySourceList.add(0, propertySource);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addLast(PropertySource<?> propertySource)
/*     */   {
/* 108 */     if (this.logger.isDebugEnabled()) {
/* 109 */       this.logger.debug(String.format("Adding [%s] PropertySource with lowest search precedence", new Object[] {propertySource
/* 110 */         .getName() }));
/*     */     }
/* 112 */     removeIfPresent(propertySource);
/* 113 */     this.propertySourceList.add(propertySource);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addBefore(String relativePropertySourceName, PropertySource<?> propertySource)
/*     */   {
/* 121 */     if (this.logger.isDebugEnabled()) {
/* 122 */       this.logger.debug(String.format("Adding [%s] PropertySource with search precedence immediately higher than [%s]", new Object[] {propertySource
/* 123 */         .getName(), relativePropertySourceName }));
/*     */     }
/* 125 */     assertLegalRelativeAddition(relativePropertySourceName, propertySource);
/* 126 */     removeIfPresent(propertySource);
/* 127 */     int index = assertPresentAndGetIndex(relativePropertySourceName);
/* 128 */     addAtIndex(index, propertySource);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addAfter(String relativePropertySourceName, PropertySource<?> propertySource)
/*     */   {
/* 136 */     if (this.logger.isDebugEnabled()) {
/* 137 */       this.logger.debug(String.format("Adding [%s] PropertySource with search precedence immediately lower than [%s]", new Object[] {propertySource
/* 138 */         .getName(), relativePropertySourceName }));
/*     */     }
/* 140 */     assertLegalRelativeAddition(relativePropertySourceName, propertySource);
/* 141 */     removeIfPresent(propertySource);
/* 142 */     int index = assertPresentAndGetIndex(relativePropertySourceName);
/* 143 */     addAtIndex(index + 1, propertySource);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int precedenceOf(PropertySource<?> propertySource)
/*     */   {
/* 150 */     return this.propertySourceList.indexOf(propertySource);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PropertySource<?> remove(String name)
/*     */   {
/* 158 */     if (this.logger.isDebugEnabled()) {
/* 159 */       this.logger.debug(String.format("Removing [%s] PropertySource", new Object[] { name }));
/*     */     }
/* 161 */     int index = this.propertySourceList.indexOf(PropertySource.named(name));
/* 162 */     return index != -1 ? (PropertySource)this.propertySourceList.remove(index) : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void replace(String name, PropertySource<?> propertySource)
/*     */   {
/* 173 */     if (this.logger.isDebugEnabled()) {
/* 174 */       this.logger.debug(String.format("Replacing [%s] PropertySource with [%s]", new Object[] { name, propertySource
/* 175 */         .getName() }));
/*     */     }
/* 177 */     int index = assertPresentAndGetIndex(name);
/* 178 */     this.propertySourceList.set(index, propertySource);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int size()
/*     */   {
/* 185 */     return this.propertySourceList.size();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 190 */     String[] names = new String[size()];
/* 191 */     for (int i = 0; i < size(); i++) {
/* 192 */       names[i] = ((PropertySource)this.propertySourceList.get(i)).getName();
/*     */     }
/* 194 */     return String.format("[%s]", new Object[] { StringUtils.arrayToCommaDelimitedString(names) });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void assertLegalRelativeAddition(String relativePropertySourceName, PropertySource<?> propertySource)
/*     */   {
/* 201 */     String newPropertySourceName = propertySource.getName();
/* 202 */     if (relativePropertySourceName.equals(newPropertySourceName))
/*     */     {
/* 204 */       throw new IllegalArgumentException(String.format("PropertySource named [%s] cannot be added relative to itself", new Object[] { newPropertySourceName }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void removeIfPresent(PropertySource<?> propertySource)
/*     */   {
/* 212 */     this.propertySourceList.remove(propertySource);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void addAtIndex(int index, PropertySource<?> propertySource)
/*     */   {
/* 219 */     removeIfPresent(propertySource);
/* 220 */     this.propertySourceList.add(index, propertySource);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int assertPresentAndGetIndex(String name)
/*     */   {
/* 230 */     int index = this.propertySourceList.indexOf(PropertySource.named(name));
/* 231 */     if (index == -1) {
/* 232 */       throw new IllegalArgumentException(String.format("PropertySource named [%s] does not exist", new Object[] { name }));
/*     */     }
/* 234 */     return index;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\env\MutablePropertySources.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */