/*     */ package org.springframework.core.env;
/*     */ 
/*     */ import java.security.AccessControlException;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.SpringProperties;
/*     */ import org.springframework.core.convert.support.ConfigurableConversionService;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractEnvironment
/*     */   implements ConfigurableEnvironment
/*     */ {
/*     */   public static final String IGNORE_GETENV_PROPERTY_NAME = "spring.getenv.ignore";
/*     */   public static final String ACTIVE_PROFILES_PROPERTY_NAME = "spring.profiles.active";
/*     */   public static final String DEFAULT_PROFILES_PROPERTY_NAME = "spring.profiles.default";
/*     */   protected static final String RESERVED_DEFAULT_PROFILE_NAME = "default";
/* 105 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/* 107 */   private final Set<String> activeProfiles = new LinkedHashSet();
/*     */   
/* 109 */   private final Set<String> defaultProfiles = new LinkedHashSet(getReservedDefaultProfiles());
/*     */   
/* 111 */   private final MutablePropertySources propertySources = new MutablePropertySources(this.logger);
/*     */   
/* 113 */   private final ConfigurablePropertyResolver propertyResolver = new PropertySourcesPropertyResolver(this.propertySources);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractEnvironment()
/*     */   {
/* 125 */     customizePropertySources(this.propertySources);
/* 126 */     if (this.logger.isDebugEnabled()) {
/* 127 */       this.logger.debug(String.format("Initialized %s with PropertySources %s", new Object[] {
/* 128 */         getClass().getSimpleName(), this.propertySources }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void customizePropertySources(MutablePropertySources propertySources) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Set<String> getReservedDefaultProfiles()
/*     */   {
/* 219 */     return Collections.singleton("default");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getActiveProfiles()
/*     */   {
/* 229 */     return StringUtils.toStringArray(doGetActiveProfiles());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Set<String> doGetActiveProfiles()
/*     */   {
/* 241 */     synchronized (this.activeProfiles) {
/* 242 */       if (this.activeProfiles.isEmpty()) {
/* 243 */         String profiles = getProperty("spring.profiles.active");
/* 244 */         if (StringUtils.hasText(profiles)) {
/* 245 */           setActiveProfiles(StringUtils.commaDelimitedListToStringArray(StringUtils.trimAllWhitespace(profiles)));
/*     */         }
/*     */       }
/* 248 */       return this.activeProfiles;
/*     */     }
/*     */   }
/*     */   
/*     */   public void setActiveProfiles(String... profiles)
/*     */   {
/* 254 */     Assert.notNull(profiles, "Profile array must not be null");
/* 255 */     synchronized (this.activeProfiles) {
/* 256 */       this.activeProfiles.clear();
/* 257 */       for (String profile : profiles) {
/* 258 */         validateProfile(profile);
/* 259 */         this.activeProfiles.add(profile);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void addActiveProfile(String profile)
/*     */   {
/* 266 */     if (this.logger.isDebugEnabled()) {
/* 267 */       this.logger.debug(String.format("Activating profile '%s'", new Object[] { profile }));
/*     */     }
/* 269 */     validateProfile(profile);
/* 270 */     doGetActiveProfiles();
/* 271 */     synchronized (this.activeProfiles) {
/* 272 */       this.activeProfiles.add(profile);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String[] getDefaultProfiles()
/*     */   {
/* 279 */     return StringUtils.toStringArray(doGetDefaultProfiles());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Set<String> doGetDefaultProfiles()
/*     */   {
/* 295 */     synchronized (this.defaultProfiles) {
/* 296 */       if (this.defaultProfiles.equals(getReservedDefaultProfiles())) {
/* 297 */         String profiles = getProperty("spring.profiles.default");
/* 298 */         if (StringUtils.hasText(profiles)) {
/* 299 */           setDefaultProfiles(StringUtils.commaDelimitedListToStringArray(StringUtils.trimAllWhitespace(profiles)));
/*     */         }
/*     */       }
/* 302 */       return this.defaultProfiles;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultProfiles(String... profiles)
/*     */   {
/* 316 */     Assert.notNull(profiles, "Profile array must not be null");
/* 317 */     synchronized (this.defaultProfiles) {
/* 318 */       this.defaultProfiles.clear();
/* 319 */       for (String profile : profiles) {
/* 320 */         validateProfile(profile);
/* 321 */         this.defaultProfiles.add(profile);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean acceptsProfiles(String... profiles)
/*     */   {
/* 328 */     Assert.notEmpty(profiles, "Must specify at least one profile");
/* 329 */     for (String profile : profiles) {
/* 330 */       if ((StringUtils.hasLength(profile)) && (profile.charAt(0) == '!')) {
/* 331 */         if (!isProfileActive(profile.substring(1))) {
/* 332 */           return true;
/*     */         }
/*     */       }
/* 335 */       else if (isProfileActive(profile)) {
/* 336 */         return true;
/*     */       }
/*     */     }
/* 339 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isProfileActive(String profile)
/*     */   {
/* 348 */     validateProfile(profile);
/* 349 */     Set<String> currentActiveProfiles = doGetActiveProfiles();
/*     */     
/* 351 */     return (currentActiveProfiles.contains(profile)) || ((currentActiveProfiles.isEmpty()) && (doGetDefaultProfiles().contains(profile)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void validateProfile(String profile)
/*     */   {
/* 365 */     if (!StringUtils.hasText(profile)) {
/* 366 */       throw new IllegalArgumentException("Invalid profile [" + profile + "]: must contain text");
/*     */     }
/* 368 */     if (profile.charAt(0) == '!') {
/* 369 */       throw new IllegalArgumentException("Invalid profile [" + profile + "]: must not begin with ! operator");
/*     */     }
/*     */   }
/*     */   
/*     */   public MutablePropertySources getPropertySources()
/*     */   {
/* 375 */     return this.propertySources;
/*     */   }
/*     */   
/*     */ 
/*     */   public Map<String, Object> getSystemEnvironment()
/*     */   {
/* 381 */     if (suppressGetenvAccess()) {
/* 382 */       return Collections.emptyMap();
/*     */     }
/*     */     try {
/* 385 */       return System.getenv();
/*     */     }
/*     */     catch (AccessControlException ex) {}
/* 388 */     new ReadOnlySystemAttributesMap()
/*     */     {
/*     */       protected String getSystemAttribute(String attributeName) {
/*     */         try {
/* 392 */           return System.getenv(attributeName);
/*     */         }
/*     */         catch (AccessControlException ex) {
/* 395 */           if (AbstractEnvironment.this.logger.isInfoEnabled())
/* 396 */             AbstractEnvironment.this.logger.info(String.format("Caught AccessControlException when accessing system environment variable [%s]; its value will be returned [null]. Reason: %s", new Object[] { attributeName, ex
/*     */             
/* 398 */               .getMessage() }));
/*     */         }
/* 400 */         return null;
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean suppressGetenvAccess()
/*     */   {
/* 419 */     return SpringProperties.getFlag("spring.getenv.ignore");
/*     */   }
/*     */   
/*     */   public Map<String, Object> getSystemProperties()
/*     */   {
/*     */     try
/*     */     {
/* 426 */       return System.getProperties();
/*     */     }
/*     */     catch (AccessControlException ex) {}
/* 429 */     new ReadOnlySystemAttributesMap()
/*     */     {
/*     */       protected String getSystemAttribute(String attributeName) {
/*     */         try {
/* 433 */           return System.getProperty(attributeName);
/*     */         }
/*     */         catch (AccessControlException ex) {
/* 436 */           if (AbstractEnvironment.this.logger.isInfoEnabled())
/* 437 */             AbstractEnvironment.this.logger.info(String.format("Caught AccessControlException when accessing system property [%s]; its value will be returned [null]. Reason: %s", new Object[] { attributeName, ex
/*     */             
/* 439 */               .getMessage() }));
/*     */         }
/* 441 */         return null;
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void merge(ConfigurableEnvironment parent)
/*     */   {
/* 450 */     for (PropertySource<?> ps : parent.getPropertySources()) {
/* 451 */       if (!this.propertySources.contains(ps.getName())) {
/* 452 */         this.propertySources.addLast(ps);
/*     */       }
/*     */     }
/* 455 */     String[] parentActiveProfiles = parent.getActiveProfiles();
/* 456 */     String str1; String profile; if (!ObjectUtils.isEmpty(parentActiveProfiles)) {
/* 457 */       synchronized (this.activeProfiles) {
/* 458 */         String[] arrayOfString1 = parentActiveProfiles;int i = arrayOfString1.length; for (str1 = 0; str1 < i; str1++) { profile = arrayOfString1[str1];
/* 459 */           this.activeProfiles.add(profile);
/*     */         }
/*     */       }
/*     */     }
/* 463 */     String[] parentDefaultProfiles = parent.getDefaultProfiles();
/* 464 */     if (!ObjectUtils.isEmpty(parentDefaultProfiles)) {
/* 465 */       synchronized (this.defaultProfiles) {
/* 466 */         this.defaultProfiles.remove("default");
/* 467 */         String[] arrayOfString2 = parentDefaultProfiles;str1 = arrayOfString2.length; for (profile = 0; profile < str1; profile++) { String profile = arrayOfString2[profile];
/* 468 */           this.defaultProfiles.add(profile);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConfigurableConversionService getConversionService()
/*     */   {
/* 481 */     return this.propertyResolver.getConversionService();
/*     */   }
/*     */   
/*     */   public void setConversionService(ConfigurableConversionService conversionService)
/*     */   {
/* 486 */     this.propertyResolver.setConversionService(conversionService);
/*     */   }
/*     */   
/*     */   public void setPlaceholderPrefix(String placeholderPrefix)
/*     */   {
/* 491 */     this.propertyResolver.setPlaceholderPrefix(placeholderPrefix);
/*     */   }
/*     */   
/*     */   public void setPlaceholderSuffix(String placeholderSuffix)
/*     */   {
/* 496 */     this.propertyResolver.setPlaceholderSuffix(placeholderSuffix);
/*     */   }
/*     */   
/*     */   public void setValueSeparator(String valueSeparator)
/*     */   {
/* 501 */     this.propertyResolver.setValueSeparator(valueSeparator);
/*     */   }
/*     */   
/*     */   public void setIgnoreUnresolvableNestedPlaceholders(boolean ignoreUnresolvableNestedPlaceholders)
/*     */   {
/* 506 */     this.propertyResolver.setIgnoreUnresolvableNestedPlaceholders(ignoreUnresolvableNestedPlaceholders);
/*     */   }
/*     */   
/*     */   public void setRequiredProperties(String... requiredProperties)
/*     */   {
/* 511 */     this.propertyResolver.setRequiredProperties(requiredProperties);
/*     */   }
/*     */   
/*     */   public void validateRequiredProperties() throws MissingRequiredPropertiesException
/*     */   {
/* 516 */     this.propertyResolver.validateRequiredProperties();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsProperty(String key)
/*     */   {
/* 526 */     return this.propertyResolver.containsProperty(key);
/*     */   }
/*     */   
/*     */   public String getProperty(String key)
/*     */   {
/* 531 */     return this.propertyResolver.getProperty(key);
/*     */   }
/*     */   
/*     */   public String getProperty(String key, String defaultValue)
/*     */   {
/* 536 */     return this.propertyResolver.getProperty(key, defaultValue);
/*     */   }
/*     */   
/*     */   public <T> T getProperty(String key, Class<T> targetType)
/*     */   {
/* 541 */     return (T)this.propertyResolver.getProperty(key, targetType);
/*     */   }
/*     */   
/*     */   public <T> T getProperty(String key, Class<T> targetType, T defaultValue)
/*     */   {
/* 546 */     return (T)this.propertyResolver.getProperty(key, targetType, defaultValue);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public <T> Class<T> getPropertyAsClass(String key, Class<T> targetType)
/*     */   {
/* 552 */     return this.propertyResolver.getPropertyAsClass(key, targetType);
/*     */   }
/*     */   
/*     */   public String getRequiredProperty(String key) throws IllegalStateException
/*     */   {
/* 557 */     return this.propertyResolver.getRequiredProperty(key);
/*     */   }
/*     */   
/*     */   public <T> T getRequiredProperty(String key, Class<T> targetType) throws IllegalStateException
/*     */   {
/* 562 */     return (T)this.propertyResolver.getRequiredProperty(key, targetType);
/*     */   }
/*     */   
/*     */   public String resolvePlaceholders(String text)
/*     */   {
/* 567 */     return this.propertyResolver.resolvePlaceholders(text);
/*     */   }
/*     */   
/*     */   public String resolveRequiredPlaceholders(String text) throws IllegalArgumentException
/*     */   {
/* 572 */     return this.propertyResolver.resolveRequiredPlaceholders(text);
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 578 */     return String.format("%s {activeProfiles=%s, defaultProfiles=%s, propertySources=%s}", new Object[] {
/* 579 */       getClass().getSimpleName(), this.activeProfiles, this.defaultProfiles, this.propertySources });
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\env\AbstractEnvironment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */