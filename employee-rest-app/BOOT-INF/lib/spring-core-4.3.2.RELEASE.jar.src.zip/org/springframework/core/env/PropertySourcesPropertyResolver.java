/*     */ package org.springframework.core.env;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.convert.ConversionException;
/*     */ import org.springframework.core.convert.support.ConfigurableConversionService;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertySourcesPropertyResolver
/*     */   extends AbstractPropertyResolver
/*     */ {
/*     */   private final PropertySources propertySources;
/*     */   
/*     */   public PropertySourcesPropertyResolver(PropertySources propertySources)
/*     */   {
/*  43 */     this.propertySources = propertySources;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean containsProperty(String key)
/*     */   {
/*  49 */     if (this.propertySources != null) {
/*  50 */       for (PropertySource<?> propertySource : this.propertySources) {
/*  51 */         if (propertySource.containsProperty(key)) {
/*  52 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*  56 */     return false;
/*     */   }
/*     */   
/*     */   public String getProperty(String key)
/*     */   {
/*  61 */     return (String)getProperty(key, String.class, true);
/*     */   }
/*     */   
/*     */   public <T> T getProperty(String key, Class<T> targetValueType)
/*     */   {
/*  66 */     return (T)getProperty(key, targetValueType, true);
/*     */   }
/*     */   
/*     */   protected String getPropertyAsRawString(String key)
/*     */   {
/*  71 */     return (String)getProperty(key, String.class, false);
/*     */   }
/*     */   
/*     */   protected <T> T getProperty(String key, Class<T> targetValueType, boolean resolveNestedPlaceholders) {
/*  75 */     if (this.propertySources != null) {
/*  76 */       for (PropertySource<?> propertySource : this.propertySources) {
/*  77 */         if (this.logger.isTraceEnabled()) {
/*  78 */           this.logger.trace(String.format("Searching for key '%s' in [%s]", new Object[] { key, propertySource.getName() }));
/*     */         }
/*  80 */         Object value = propertySource.getProperty(key);
/*  81 */         if (value != null) {
/*  82 */           if ((resolveNestedPlaceholders) && ((value instanceof String))) {
/*  83 */             value = resolveNestedPlaceholders((String)value);
/*     */           }
/*  85 */           logKeyFound(key, propertySource, value);
/*  86 */           return (T)this.conversionService.convert(value, targetValueType);
/*     */         }
/*     */       }
/*     */     }
/*  90 */     if (this.logger.isDebugEnabled()) {
/*  91 */       this.logger.debug(String.format("Could not find key '%s' in any property source", new Object[] { key }));
/*     */     }
/*  93 */     return null;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public <T> Class<T> getPropertyAsClass(String key, Class<T> targetValueType)
/*     */   {
/*  99 */     if (this.propertySources != null) {
/* 100 */       for (PropertySource<?> propertySource : this.propertySources) {
/* 101 */         if (this.logger.isTraceEnabled()) {
/* 102 */           this.logger.trace(String.format("Searching for key '%s' in [%s]", new Object[] { key, propertySource.getName() }));
/*     */         }
/* 104 */         Object value = propertySource.getProperty(key);
/* 105 */         if (value != null) {
/* 106 */           logKeyFound(key, propertySource, value);
/*     */           Class<?> clazz;
/* 108 */           if ((value instanceof String)) {
/*     */             try {
/* 110 */               clazz = ClassUtils.forName((String)value, null);
/*     */             } catch (Exception ex) {
/*     */               Class<?> clazz;
/* 113 */               throw new ClassConversionException((String)value, targetValueType, ex);
/*     */             }
/*     */           } else { Class<?> clazz;
/* 116 */             if ((value instanceof Class)) {
/* 117 */               clazz = (Class)value;
/*     */             }
/*     */             else
/* 120 */               clazz = value.getClass();
/*     */           }
/* 122 */           if (!targetValueType.isAssignableFrom(clazz)) {
/* 123 */             throw new ClassConversionException(clazz, targetValueType);
/*     */           }
/*     */           
/* 126 */           Class<T> targetClass = clazz;
/* 127 */           return targetClass;
/*     */         }
/*     */       }
/*     */     }
/* 131 */     if (this.logger.isDebugEnabled()) {
/* 132 */       this.logger.debug(String.format("Could not find key '%s' in any property source", new Object[] { key }));
/*     */     }
/* 134 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void logKeyFound(String key, PropertySource<?> propertySource, Object value)
/*     */   {
/* 148 */     if (this.logger.isDebugEnabled()) {
/* 149 */       this.logger.debug(String.format("Found key '%s' in [%s] with type [%s] and value '%s'", new Object[] { key, propertySource
/* 150 */         .getName(), value.getClass().getSimpleName(), value }));
/*     */     }
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   private static class ClassConversionException
/*     */     extends ConversionException
/*     */   {
/*     */     public ClassConversionException(Class<?> actual, Class<?> expected)
/*     */     {
/* 160 */       super();
/*     */     }
/*     */     
/*     */     public ClassConversionException(String actual, Class<?> expected, Exception ex) {
/* 165 */       super(ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\env\PropertySourcesPropertyResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */