/*    */ package org.springframework.core;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Parameter;
/*    */ import org.springframework.lang.UsesJava8;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @UsesJava8
/*    */ public class StandardReflectionParameterNameDiscoverer
/*    */   implements ParameterNameDiscoverer
/*    */ {
/*    */   public String[] getParameterNames(Method method)
/*    */   {
/* 38 */     Parameter[] parameters = method.getParameters();
/* 39 */     String[] parameterNames = new String[parameters.length];
/* 40 */     for (int i = 0; i < parameters.length; i++) {
/* 41 */       Parameter param = parameters[i];
/* 42 */       if (!param.isNamePresent()) {
/* 43 */         return null;
/*    */       }
/* 45 */       parameterNames[i] = param.getName();
/*    */     }
/* 47 */     return parameterNames;
/*    */   }
/*    */   
/*    */   public String[] getParameterNames(Constructor<?> ctor)
/*    */   {
/* 52 */     Parameter[] parameters = ctor.getParameters();
/* 53 */     String[] parameterNames = new String[parameters.length];
/* 54 */     for (int i = 0; i < parameters.length; i++) {
/* 55 */       Parameter param = parameters[i];
/* 56 */       if (!param.isNamePresent()) {
/* 57 */         return null;
/*    */       }
/* 59 */       parameterNames[i] = param.getName();
/*    */     }
/* 61 */     return parameterNames;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\StandardReflectionParameterNameDiscoverer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */