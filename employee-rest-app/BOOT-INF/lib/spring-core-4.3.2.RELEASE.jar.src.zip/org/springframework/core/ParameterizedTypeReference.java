/*    */ package org.springframework.core;
/*    */ 
/*    */ import java.lang.reflect.ParameterizedType;
/*    */ import java.lang.reflect.Type;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ParameterizedTypeReference<T>
/*    */ {
/*    */   private final Type type;
/*    */   
/*    */   protected ParameterizedTypeReference()
/*    */   {
/* 48 */     Class<?> parameterizedTypeReferenceSubclass = findParameterizedTypeReferenceSubclass(getClass());
/* 49 */     Type type = parameterizedTypeReferenceSubclass.getGenericSuperclass();
/* 50 */     Assert.isInstanceOf(ParameterizedType.class, type);
/* 51 */     ParameterizedType parameterizedType = (ParameterizedType)type;
/* 52 */     Assert.isTrue(parameterizedType.getActualTypeArguments().length == 1);
/* 53 */     this.type = parameterizedType.getActualTypeArguments()[0];
/*    */   }
/*    */   
/*    */   public Type getType()
/*    */   {
/* 58 */     return this.type;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 64 */     return (this == obj) || (((obj instanceof ParameterizedTypeReference)) && (this.type.equals(((ParameterizedTypeReference)obj).type)));
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 69 */     return this.type.hashCode();
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 74 */     return "ParameterizedTypeReference<" + this.type + ">";
/*    */   }
/*    */   
/*    */   private static Class<?> findParameterizedTypeReferenceSubclass(Class<?> child)
/*    */   {
/* 79 */     Class<?> parent = child.getSuperclass();
/* 80 */     if (Object.class == parent) {
/* 81 */       throw new IllegalStateException("Expected ParameterizedTypeReference superclass");
/*    */     }
/* 83 */     if (ParameterizedTypeReference.class == parent) {
/* 84 */       return child;
/*    */     }
/*    */     
/* 87 */     return findParameterizedTypeReferenceSubclass(parent);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\ParameterizedTypeReference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */