/*     */ package org.springframework.core;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class GenericCollectionTypeResolver
/*     */ {
/*     */   public static Class<?> getCollectionType(Class<? extends Collection> collectionClass)
/*     */   {
/*  46 */     return ResolvableType.forClass(collectionClass).asCollection().resolveGeneric(new int[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> getMapKeyType(Class<? extends Map> mapClass)
/*     */   {
/*  57 */     return ResolvableType.forClass(mapClass).asMap().resolveGeneric(new int[] { 0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> getMapValueType(Class<? extends Map> mapClass)
/*     */   {
/*  68 */     return ResolvableType.forClass(mapClass).asMap().resolveGeneric(new int[] { 1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> getCollectionFieldType(Field collectionField)
/*     */   {
/*  77 */     return ResolvableType.forField(collectionField).asCollection().resolveGeneric(new int[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> getCollectionFieldType(Field collectionField, int nestingLevel)
/*     */   {
/*  89 */     return ResolvableType.forField(collectionField).getNested(nestingLevel).asCollection().resolveGeneric(new int[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static Class<?> getCollectionFieldType(Field collectionField, int nestingLevel, Map<Integer, Integer> typeIndexesPerLevel)
/*     */   {
/* 105 */     return ResolvableType.forField(collectionField).getNested(nestingLevel, typeIndexesPerLevel).asCollection().resolveGeneric(new int[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> getMapKeyFieldType(Field mapField)
/*     */   {
/* 114 */     return ResolvableType.forField(mapField).asMap().resolveGeneric(new int[] { 0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> getMapKeyFieldType(Field mapField, int nestingLevel)
/*     */   {
/* 126 */     return ResolvableType.forField(mapField).getNested(nestingLevel).asMap().resolveGeneric(new int[] { 0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static Class<?> getMapKeyFieldType(Field mapField, int nestingLevel, Map<Integer, Integer> typeIndexesPerLevel)
/*     */   {
/* 142 */     return ResolvableType.forField(mapField).getNested(nestingLevel, typeIndexesPerLevel).asMap().resolveGeneric(new int[] { 0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> getMapValueFieldType(Field mapField)
/*     */   {
/* 151 */     return ResolvableType.forField(mapField).asMap().resolveGeneric(new int[] { 1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> getMapValueFieldType(Field mapField, int nestingLevel)
/*     */   {
/* 163 */     return ResolvableType.forField(mapField).getNested(nestingLevel).asMap().resolveGeneric(new int[] { 1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static Class<?> getMapValueFieldType(Field mapField, int nestingLevel, Map<Integer, Integer> typeIndexesPerLevel)
/*     */   {
/* 179 */     return ResolvableType.forField(mapField).getNested(nestingLevel, typeIndexesPerLevel).asMap().resolveGeneric(new int[] { 1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> getCollectionParameterType(MethodParameter methodParam)
/*     */   {
/* 188 */     return ResolvableType.forMethodParameter(methodParam).asCollection().resolveGeneric(new int[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> getMapKeyParameterType(MethodParameter methodParam)
/*     */   {
/* 197 */     return ResolvableType.forMethodParameter(methodParam).asMap().resolveGeneric(new int[] { 0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> getMapValueParameterType(MethodParameter methodParam)
/*     */   {
/* 206 */     return ResolvableType.forMethodParameter(methodParam).asMap().resolveGeneric(new int[] { 1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> getCollectionReturnType(Method method)
/*     */   {
/* 215 */     return ResolvableType.forMethodReturnType(method).asCollection().resolveGeneric(new int[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> getCollectionReturnType(Method method, int nestingLevel)
/*     */   {
/* 229 */     return ResolvableType.forMethodReturnType(method).getNested(nestingLevel).asCollection().resolveGeneric(new int[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> getMapKeyReturnType(Method method)
/*     */   {
/* 238 */     return ResolvableType.forMethodReturnType(method).asMap().resolveGeneric(new int[] { 0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> getMapKeyReturnType(Method method, int nestingLevel)
/*     */   {
/* 250 */     return ResolvableType.forMethodReturnType(method).getNested(nestingLevel).asMap().resolveGeneric(new int[] { 0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> getMapValueReturnType(Method method)
/*     */   {
/* 259 */     return ResolvableType.forMethodReturnType(method).asMap().resolveGeneric(new int[] { 1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> getMapValueReturnType(Method method, int nestingLevel)
/*     */   {
/* 271 */     return ResolvableType.forMethodReturnType(method).getNested(nestingLevel).asMap().resolveGeneric(new int[] { 1 });
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\GenericCollectionTypeResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */