/*     */ package org.springframework.core;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NestedCheckedException
/*     */   extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = 7100714597678207546L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  45 */     NestedExceptionUtils.class.getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NestedCheckedException(String msg)
/*     */   {
/*  54 */     super(msg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NestedCheckedException(String msg, Throwable cause)
/*     */   {
/*  64 */     super(msg, cause);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage()
/*     */   {
/*  74 */     return NestedExceptionUtils.buildMessage(super.getMessage(), getCause());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Throwable getRootCause()
/*     */   {
/*  83 */     Throwable rootCause = null;
/*  84 */     Throwable cause = getCause();
/*  85 */     while ((cause != null) && (cause != rootCause)) {
/*  86 */       rootCause = cause;
/*  87 */       cause = cause.getCause();
/*     */     }
/*  89 */     return rootCause;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Throwable getMostSpecificCause()
/*     */   {
/* 101 */     Throwable rootCause = getRootCause();
/* 102 */     return rootCause != null ? rootCause : this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean contains(Class<?> exType)
/*     */   {
/* 113 */     if (exType == null) {
/* 114 */       return false;
/*     */     }
/* 116 */     if (exType.isInstance(this)) {
/* 117 */       return true;
/*     */     }
/* 119 */     Throwable cause = getCause();
/* 120 */     if (cause == this) {
/* 121 */       return false;
/*     */     }
/* 123 */     if ((cause instanceof NestedCheckedException)) {
/* 124 */       return ((NestedCheckedException)cause).contains(exType);
/*     */     }
/*     */     
/* 127 */     while (cause != null) {
/* 128 */       if (exType.isInstance(cause)) {
/* 129 */         return true;
/*     */       }
/* 131 */       if (cause.getCause() == cause) {
/*     */         break;
/*     */       }
/* 134 */       cause = cause.getCause();
/*     */     }
/* 136 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\NestedCheckedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */