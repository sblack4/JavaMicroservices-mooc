/*     */ package org.springframework.core.task;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ConcurrencyThrottleSupport;
/*     */ import org.springframework.util.CustomizableThreadCreator;
/*     */ import org.springframework.util.concurrent.ListenableFuture;
/*     */ import org.springframework.util.concurrent.ListenableFutureTask;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleAsyncTaskExecutor
/*     */   extends CustomizableThreadCreator
/*     */   implements AsyncListenableTaskExecutor, Serializable
/*     */ {
/*     */   public static final int UNBOUNDED_CONCURRENCY = -1;
/*     */   public static final int NO_CONCURRENCY = 0;
/*  64 */   private final ConcurrencyThrottleAdapter concurrencyThrottle = new ConcurrencyThrottleAdapter(null);
/*     */   
/*     */ 
/*     */ 
/*     */   private ThreadFactory threadFactory;
/*     */   
/*     */ 
/*     */ 
/*     */   private TaskDecorator taskDecorator;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SimpleAsyncTaskExecutor() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public SimpleAsyncTaskExecutor(String threadNamePrefix)
/*     */   {
/*  83 */     super(threadNamePrefix);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SimpleAsyncTaskExecutor(ThreadFactory threadFactory)
/*     */   {
/*  91 */     this.threadFactory = threadFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setThreadFactory(ThreadFactory threadFactory)
/*     */   {
/* 104 */     this.threadFactory = threadFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final ThreadFactory getThreadFactory()
/*     */   {
/* 111 */     return this.threadFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setTaskDecorator(TaskDecorator taskDecorator)
/*     */   {
/* 125 */     this.taskDecorator = taskDecorator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConcurrencyLimit(int concurrencyLimit)
/*     */   {
/* 139 */     this.concurrencyThrottle.setConcurrencyLimit(concurrencyLimit);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final int getConcurrencyLimit()
/*     */   {
/* 146 */     return this.concurrencyThrottle.getConcurrencyLimit();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isThrottleActive()
/*     */   {
/* 156 */     return this.concurrencyThrottle.isThrottleActive();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void execute(Runnable task)
/*     */   {
/* 167 */     execute(task, Long.MAX_VALUE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void execute(Runnable task, long startTimeout)
/*     */   {
/* 181 */     Assert.notNull(task, "Runnable must not be null");
/* 182 */     Runnable taskToUse = this.taskDecorator != null ? this.taskDecorator.decorate(task) : task;
/* 183 */     if ((isThrottleActive()) && (startTimeout > 0L)) {
/* 184 */       this.concurrencyThrottle.beforeAccess();
/* 185 */       doExecute(new ConcurrencyThrottlingRunnable(taskToUse));
/*     */     }
/*     */     else {
/* 188 */       doExecute(taskToUse);
/*     */     }
/*     */   }
/*     */   
/*     */   public Future<?> submit(Runnable task)
/*     */   {
/* 194 */     FutureTask<Object> future = new FutureTask(task, null);
/* 195 */     execute(future, Long.MAX_VALUE);
/* 196 */     return future;
/*     */   }
/*     */   
/*     */   public <T> Future<T> submit(Callable<T> task)
/*     */   {
/* 201 */     FutureTask<T> future = new FutureTask(task);
/* 202 */     execute(future, Long.MAX_VALUE);
/* 203 */     return future;
/*     */   }
/*     */   
/*     */   public ListenableFuture<?> submitListenable(Runnable task)
/*     */   {
/* 208 */     ListenableFutureTask<Object> future = new ListenableFutureTask(task, null);
/* 209 */     execute(future, Long.MAX_VALUE);
/* 210 */     return future;
/*     */   }
/*     */   
/*     */   public <T> ListenableFuture<T> submitListenable(Callable<T> task)
/*     */   {
/* 215 */     ListenableFutureTask<T> future = new ListenableFutureTask(task);
/* 216 */     execute(future, Long.MAX_VALUE);
/* 217 */     return future;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doExecute(Runnable task)
/*     */   {
/* 229 */     Thread thread = this.threadFactory != null ? this.threadFactory.newThread(task) : createThread(task);
/* 230 */     thread.start();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class ConcurrencyThrottleAdapter
/*     */     extends ConcurrencyThrottleSupport
/*     */   {
/*     */     protected void beforeAccess()
/*     */     {
/* 243 */       super.beforeAccess();
/*     */     }
/*     */     
/*     */     protected void afterAccess()
/*     */     {
/* 248 */       super.afterAccess();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class ConcurrencyThrottlingRunnable
/*     */     implements Runnable
/*     */   {
/*     */     private final Runnable target;
/*     */     
/*     */ 
/*     */     public ConcurrencyThrottlingRunnable(Runnable target)
/*     */     {
/* 262 */       this.target = target;
/*     */     }
/*     */     
/*     */     /* Error */
/*     */     public void run()
/*     */     {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: getfield 3	org/springframework/core/task/SimpleAsyncTaskExecutor$ConcurrencyThrottlingRunnable:target	Ljava/lang/Runnable;
/*     */       //   4: invokeinterface 4 1 0
/*     */       //   9: aload_0
/*     */       //   10: getfield 1	org/springframework/core/task/SimpleAsyncTaskExecutor$ConcurrencyThrottlingRunnable:this$0	Lorg/springframework/core/task/SimpleAsyncTaskExecutor;
/*     */       //   13: invokestatic 5	org/springframework/core/task/SimpleAsyncTaskExecutor:access$100	(Lorg/springframework/core/task/SimpleAsyncTaskExecutor;)Lorg/springframework/core/task/SimpleAsyncTaskExecutor$ConcurrencyThrottleAdapter;
/*     */       //   16: invokevirtual 6	org/springframework/core/task/SimpleAsyncTaskExecutor$ConcurrencyThrottleAdapter:afterAccess	()V
/*     */       //   19: goto +16 -> 35
/*     */       //   22: astore_1
/*     */       //   23: aload_0
/*     */       //   24: getfield 1	org/springframework/core/task/SimpleAsyncTaskExecutor$ConcurrencyThrottlingRunnable:this$0	Lorg/springframework/core/task/SimpleAsyncTaskExecutor;
/*     */       //   27: invokestatic 5	org/springframework/core/task/SimpleAsyncTaskExecutor:access$100	(Lorg/springframework/core/task/SimpleAsyncTaskExecutor;)Lorg/springframework/core/task/SimpleAsyncTaskExecutor$ConcurrencyThrottleAdapter;
/*     */       //   30: invokevirtual 6	org/springframework/core/task/SimpleAsyncTaskExecutor$ConcurrencyThrottleAdapter:afterAccess	()V
/*     */       //   33: aload_1
/*     */       //   34: athrow
/*     */       //   35: return
/*     */       // Line number table:
/*     */       //   Java source line #268	-> byte code offset #0
/*     */       //   Java source line #271	-> byte code offset #9
/*     */       //   Java source line #272	-> byte code offset #19
/*     */       //   Java source line #271	-> byte code offset #22
/*     */       //   Java source line #273	-> byte code offset #35
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	signature
/*     */       //   0	36	0	this	ConcurrencyThrottlingRunnable
/*     */       //   22	12	1	localObject	Object
/*     */       // Exception table:
/*     */       //   from	to	target	type
/*     */       //   0	9	22	finally
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\task\SimpleAsyncTaskExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */