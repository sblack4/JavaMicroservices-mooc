package org.springframework.core.task;

import java.util.concurrent.Callable;
import org.springframework.util.concurrent.ListenableFuture;

public abstract interface AsyncListenableTaskExecutor
  extends AsyncTaskExecutor
{
  public abstract ListenableFuture<?> submitListenable(Runnable paramRunnable);
  
  public abstract <T> ListenableFuture<T> submitListenable(Callable<T> paramCallable);
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\task\AsyncListenableTaskExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */