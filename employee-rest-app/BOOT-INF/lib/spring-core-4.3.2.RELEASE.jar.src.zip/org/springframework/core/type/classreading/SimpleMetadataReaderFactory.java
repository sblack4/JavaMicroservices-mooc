/*    */ package org.springframework.core.type.classreading;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.springframework.core.io.DefaultResourceLoader;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleMetadataReaderFactory
/*    */   implements MetadataReaderFactory
/*    */ {
/*    */   private final ResourceLoader resourceLoader;
/*    */   
/*    */   public SimpleMetadataReaderFactory()
/*    */   {
/* 42 */     this.resourceLoader = new DefaultResourceLoader();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SimpleMetadataReaderFactory(ResourceLoader resourceLoader)
/*    */   {
/* 51 */     this.resourceLoader = (resourceLoader != null ? resourceLoader : new DefaultResourceLoader());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public SimpleMetadataReaderFactory(ClassLoader classLoader)
/*    */   {
/* 59 */     this.resourceLoader = (classLoader != null ? new DefaultResourceLoader(classLoader) : new DefaultResourceLoader());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public final ResourceLoader getResourceLoader()
/*    */   {
/* 69 */     return this.resourceLoader;
/*    */   }
/*    */   
/*    */ 
/*    */   public MetadataReader getMetadataReader(String className)
/*    */     throws IOException
/*    */   {
/* 76 */     String resourcePath = "classpath:" + ClassUtils.convertClassNameToResourcePath(className) + ".class";
/* 77 */     Resource resource = this.resourceLoader.getResource(resourcePath);
/* 78 */     if (!resource.exists())
/*    */     {
/*    */ 
/* 81 */       int lastDotIndex = className.lastIndexOf('.');
/* 82 */       if (lastDotIndex != -1)
/*    */       {
/* 84 */         String innerClassName = className.substring(0, lastDotIndex) + '$' + className.substring(lastDotIndex + 1);
/*    */         
/* 86 */         String innerClassResourcePath = "classpath:" + ClassUtils.convertClassNameToResourcePath(innerClassName) + ".class";
/* 87 */         Resource innerClassResource = this.resourceLoader.getResource(innerClassResourcePath);
/* 88 */         if (innerClassResource.exists()) {
/* 89 */           resource = innerClassResource;
/*    */         }
/*    */       }
/*    */     }
/* 93 */     return getMetadataReader(resource);
/*    */   }
/*    */   
/*    */   public MetadataReader getMetadataReader(Resource resource) throws IOException
/*    */   {
/* 98 */     return new SimpleMetadataReader(resource, this.resourceLoader.getClassLoader());
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\type\classreading\SimpleMetadataReaderFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */