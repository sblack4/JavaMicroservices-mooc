/*     */ package org.springframework.core.type.classreading;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.springframework.asm.AnnotationVisitor;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodMetadataReadingVisitor
/*     */   extends MethodVisitor
/*     */   implements MethodMetadata
/*     */ {
/*     */   protected final String methodName;
/*     */   protected final int access;
/*     */   protected final String declaringClassName;
/*     */   protected final String returnTypeName;
/*     */   protected final ClassLoader classLoader;
/*     */   protected final Set<MethodMetadata> methodMetadataSet;
/*  59 */   protected final Map<String, Set<String>> metaAnnotationMap = new LinkedHashMap(4);
/*     */   
/*  61 */   protected final LinkedMultiValueMap<String, AnnotationAttributes> attributesMap = new LinkedMultiValueMap(4);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MethodMetadataReadingVisitor(String methodName, int access, String declaringClassName, String returnTypeName, ClassLoader classLoader, Set<MethodMetadata> methodMetadataSet)
/*     */   {
/*  68 */     super(327680);
/*  69 */     this.methodName = methodName;
/*  70 */     this.access = access;
/*  71 */     this.declaringClassName = declaringClassName;
/*  72 */     this.returnTypeName = returnTypeName;
/*  73 */     this.classLoader = classLoader;
/*  74 */     this.methodMetadataSet = methodMetadataSet;
/*     */   }
/*     */   
/*     */ 
/*     */   public AnnotationVisitor visitAnnotation(String desc, boolean visible)
/*     */   {
/*  80 */     String className = Type.getType(desc).getClassName();
/*  81 */     this.methodMetadataSet.add(this);
/*  82 */     return new AnnotationAttributesReadingVisitor(className, this.attributesMap, this.metaAnnotationMap, this.classLoader);
/*     */   }
/*     */   
/*     */ 
/*     */   public String getMethodName()
/*     */   {
/*  88 */     return this.methodName;
/*     */   }
/*     */   
/*     */   public boolean isAbstract()
/*     */   {
/*  93 */     return (this.access & 0x400) != 0;
/*     */   }
/*     */   
/*     */   public boolean isStatic()
/*     */   {
/*  98 */     return (this.access & 0x8) != 0;
/*     */   }
/*     */   
/*     */   public boolean isFinal()
/*     */   {
/* 103 */     return (this.access & 0x10) != 0;
/*     */   }
/*     */   
/*     */   public boolean isOverridable()
/*     */   {
/* 108 */     return (!isStatic()) && (!isFinal()) && ((this.access & 0x2) == 0);
/*     */   }
/*     */   
/*     */   public boolean isAnnotated(String annotationName)
/*     */   {
/* 113 */     return this.attributesMap.containsKey(annotationName);
/*     */   }
/*     */   
/*     */   public AnnotationAttributes getAnnotationAttributes(String annotationName)
/*     */   {
/* 118 */     return getAnnotationAttributes(annotationName, false);
/*     */   }
/*     */   
/*     */   public AnnotationAttributes getAnnotationAttributes(String annotationName, boolean classValuesAsString)
/*     */   {
/* 123 */     AnnotationAttributes raw = AnnotationReadingVisitorUtils.getMergedAnnotationAttributes(this.attributesMap, this.metaAnnotationMap, annotationName);
/*     */     
/* 125 */     return AnnotationReadingVisitorUtils.convertClassValues("method '" + 
/* 126 */       getMethodName() + "'", this.classLoader, raw, classValuesAsString);
/*     */   }
/*     */   
/*     */   public MultiValueMap<String, Object> getAllAnnotationAttributes(String annotationName)
/*     */   {
/* 131 */     return getAllAnnotationAttributes(annotationName, false);
/*     */   }
/*     */   
/*     */   public MultiValueMap<String, Object> getAllAnnotationAttributes(String annotationName, boolean classValuesAsString)
/*     */   {
/* 136 */     if (!this.attributesMap.containsKey(annotationName)) {
/* 137 */       return null;
/*     */     }
/* 139 */     MultiValueMap<String, Object> allAttributes = new LinkedMultiValueMap();
/* 140 */     for (AnnotationAttributes annotationAttributes : this.attributesMap.get(annotationName)) {
/* 141 */       AnnotationAttributes convertedAttributes = AnnotationReadingVisitorUtils.convertClassValues("method '" + 
/* 142 */         getMethodName() + "'", this.classLoader, annotationAttributes, classValuesAsString);
/* 143 */       for (Map.Entry<String, Object> entry : convertedAttributes.entrySet()) {
/* 144 */         allAttributes.add(entry.getKey(), entry.getValue());
/*     */       }
/*     */     }
/* 147 */     return allAttributes;
/*     */   }
/*     */   
/*     */   public String getDeclaringClassName()
/*     */   {
/* 152 */     return this.declaringClassName;
/*     */   }
/*     */   
/*     */   public String getReturnTypeName()
/*     */   {
/* 157 */     return this.returnTypeName;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\type\classreading\MethodMetadataReadingVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */