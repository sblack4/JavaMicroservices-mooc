/*     */ package org.springframework.core.type.classreading;
/*     */ 
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.asm.AnnotationVisitor;
/*     */ import org.springframework.asm.Attribute;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.FieldVisitor;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.core.type.ClassMetadata;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ClassMetadataReadingVisitor
/*     */   extends ClassVisitor
/*     */   implements ClassMetadata
/*     */ {
/*     */   private String className;
/*     */   private boolean isInterface;
/*     */   private boolean isAnnotation;
/*     */   private boolean isAbstract;
/*     */   private boolean isFinal;
/*     */   private String enclosingClassName;
/*     */   private boolean independentInnerClass;
/*     */   private String superClassName;
/*     */   private String[] interfaces;
/*  64 */   private Set<String> memberClassNames = new LinkedHashSet();
/*     */   
/*     */   public ClassMetadataReadingVisitor()
/*     */   {
/*  68 */     super(327680);
/*     */   }
/*     */   
/*     */ 
/*     */   public void visit(int version, int access, String name, String signature, String supername, String[] interfaces)
/*     */   {
/*  74 */     this.className = ClassUtils.convertResourcePathToClassName(name);
/*  75 */     this.isInterface = ((access & 0x200) != 0);
/*  76 */     this.isAnnotation = ((access & 0x2000) != 0);
/*  77 */     this.isAbstract = ((access & 0x400) != 0);
/*  78 */     this.isFinal = ((access & 0x10) != 0);
/*  79 */     if ((supername != null) && (!this.isInterface)) {
/*  80 */       this.superClassName = ClassUtils.convertResourcePathToClassName(supername);
/*     */     }
/*  82 */     this.interfaces = new String[interfaces.length];
/*  83 */     for (int i = 0; i < interfaces.length; i++) {
/*  84 */       this.interfaces[i] = ClassUtils.convertResourcePathToClassName(interfaces[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public void visitOuterClass(String owner, String name, String desc)
/*     */   {
/*  90 */     this.enclosingClassName = ClassUtils.convertResourcePathToClassName(owner);
/*     */   }
/*     */   
/*     */   public void visitInnerClass(String name, String outerName, String innerName, int access)
/*     */   {
/*  95 */     if (outerName != null) {
/*  96 */       String fqName = ClassUtils.convertResourcePathToClassName(name);
/*  97 */       String fqOuterName = ClassUtils.convertResourcePathToClassName(outerName);
/*  98 */       if (this.className.equals(fqName)) {
/*  99 */         this.enclosingClassName = fqOuterName;
/* 100 */         this.independentInnerClass = ((access & 0x8) != 0);
/*     */       }
/* 102 */       else if (this.className.equals(fqOuterName)) {
/* 103 */         this.memberClassNames.add(fqName);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void visitSource(String source, String debug) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public AnnotationVisitor visitAnnotation(String desc, boolean visible)
/*     */   {
/* 116 */     return new EmptyAnnotationVisitor();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void visitAttribute(Attribute attr) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public FieldVisitor visitField(int access, String name, String desc, String signature, Object value)
/*     */   {
/* 127 */     return new EmptyFieldVisitor();
/*     */   }
/*     */   
/*     */ 
/*     */   public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions)
/*     */   {
/* 133 */     return new EmptyMethodVisitor();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void visitEnd() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public String getClassName()
/*     */   {
/* 144 */     return this.className;
/*     */   }
/*     */   
/*     */   public boolean isInterface()
/*     */   {
/* 149 */     return this.isInterface;
/*     */   }
/*     */   
/*     */   public boolean isAnnotation()
/*     */   {
/* 154 */     return this.isAnnotation;
/*     */   }
/*     */   
/*     */   public boolean isAbstract()
/*     */   {
/* 159 */     return this.isAbstract;
/*     */   }
/*     */   
/*     */   public boolean isConcrete()
/*     */   {
/* 164 */     return (!this.isInterface) && (!this.isAbstract);
/*     */   }
/*     */   
/*     */   public boolean isFinal()
/*     */   {
/* 169 */     return this.isFinal;
/*     */   }
/*     */   
/*     */   public boolean isIndependent()
/*     */   {
/* 174 */     return (this.enclosingClassName == null) || (this.independentInnerClass);
/*     */   }
/*     */   
/*     */   public boolean hasEnclosingClass()
/*     */   {
/* 179 */     return this.enclosingClassName != null;
/*     */   }
/*     */   
/*     */   public String getEnclosingClassName()
/*     */   {
/* 184 */     return this.enclosingClassName;
/*     */   }
/*     */   
/*     */   public boolean hasSuperClass()
/*     */   {
/* 189 */     return this.superClassName != null;
/*     */   }
/*     */   
/*     */   public String getSuperClassName()
/*     */   {
/* 194 */     return this.superClassName;
/*     */   }
/*     */   
/*     */   public String[] getInterfaceNames()
/*     */   {
/* 199 */     return this.interfaces;
/*     */   }
/*     */   
/*     */   public String[] getMemberClassNames()
/*     */   {
/* 204 */     return (String[])this.memberClassNames.toArray(new String[this.memberClassNames.size()]);
/*     */   }
/*     */   
/*     */   private static class EmptyAnnotationVisitor extends AnnotationVisitor
/*     */   {
/*     */     public EmptyAnnotationVisitor()
/*     */     {
/* 211 */       super();
/*     */     }
/*     */     
/*     */     public AnnotationVisitor visitAnnotation(String name, String desc)
/*     */     {
/* 216 */       return this;
/*     */     }
/*     */     
/*     */     public AnnotationVisitor visitArray(String name)
/*     */     {
/* 221 */       return this;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class EmptyMethodVisitor extends MethodVisitor
/*     */   {
/*     */     public EmptyMethodVisitor()
/*     */     {
/* 229 */       super();
/*     */     }
/*     */   }
/*     */   
/*     */   private static class EmptyFieldVisitor extends FieldVisitor
/*     */   {
/*     */     public EmptyFieldVisitor()
/*     */     {
/* 237 */       super();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\type\classreading\ClassMetadataReadingVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */