/*    */ package org.springframework.core.type.classreading;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.asm.AnnotationVisitor;
/*    */ import org.springframework.asm.Type;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.util.ReflectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractRecursiveAnnotationVisitor
/*    */   extends AnnotationVisitor
/*    */ {
/* 39 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */   
/*    */   protected final AnnotationAttributes attributes;
/*    */   
/*    */   protected final ClassLoader classLoader;
/*    */   
/*    */   public AbstractRecursiveAnnotationVisitor(ClassLoader classLoader, AnnotationAttributes attributes)
/*    */   {
/* 47 */     super(327680);
/* 48 */     this.classLoader = classLoader;
/* 49 */     this.attributes = attributes;
/*    */   }
/*    */   
/*    */ 
/*    */   public void visit(String attributeName, Object attributeValue)
/*    */   {
/* 55 */     this.attributes.put(attributeName, attributeValue);
/*    */   }
/*    */   
/*    */   public AnnotationVisitor visitAnnotation(String attributeName, String asmTypeDescriptor)
/*    */   {
/* 60 */     String annotationType = Type.getType(asmTypeDescriptor).getClassName();
/* 61 */     AnnotationAttributes nestedAttributes = new AnnotationAttributes(annotationType, this.classLoader);
/* 62 */     this.attributes.put(attributeName, nestedAttributes);
/* 63 */     return new RecursiveAnnotationAttributesVisitor(annotationType, nestedAttributes, this.classLoader);
/*    */   }
/*    */   
/*    */   public AnnotationVisitor visitArray(String attributeName)
/*    */   {
/* 68 */     return new RecursiveAnnotationArrayVisitor(attributeName, this.attributes, this.classLoader);
/*    */   }
/*    */   
/*    */   public void visitEnum(String attributeName, String asmTypeDescriptor, String attributeValue)
/*    */   {
/* 73 */     Object newValue = getEnumValue(asmTypeDescriptor, attributeValue);
/* 74 */     visit(attributeName, newValue);
/*    */   }
/*    */   
/*    */   protected Object getEnumValue(String asmTypeDescriptor, String attributeValue) {
/* 78 */     Object valueToUse = attributeValue;
/*    */     try {
/* 80 */       Class<?> enumType = this.classLoader.loadClass(Type.getType(asmTypeDescriptor).getClassName());
/* 81 */       Field enumConstant = ReflectionUtils.findField(enumType, attributeValue);
/* 82 */       if (enumConstant != null) {
/* 83 */         valueToUse = enumConstant.get(null);
/*    */       }
/*    */     }
/*    */     catch (ClassNotFoundException ex) {
/* 87 */       this.logger.debug("Failed to classload enum type while reading annotation metadata", ex);
/*    */     }
/*    */     catch (IllegalAccessException ex) {
/* 90 */       this.logger.warn("Could not access enum value while reading annotation metadata", ex);
/*    */     }
/* 92 */     return valueToUse;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\type\classreading\AbstractRecursiveAnnotationVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */