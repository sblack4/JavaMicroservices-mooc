/*     */ package org.springframework.core.io;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import org.springframework.core.NestedIOException;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractResource
/*     */   implements Resource
/*     */ {
/*     */   public boolean exists()
/*     */   {
/*     */     try
/*     */     {
/*  53 */       return getFile().exists();
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/*     */       try {
/*  58 */         InputStream is = getInputStream();
/*  59 */         is.close();
/*  60 */         return true;
/*     */       } catch (Throwable isEx) {}
/*     */     }
/*  63 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isReadable()
/*     */   {
/*  73 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isOpen()
/*     */   {
/*  81 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public URL getURL()
/*     */     throws IOException
/*     */   {
/*  90 */     throw new FileNotFoundException(getDescription() + " cannot be resolved to URL");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public URI getURI()
/*     */     throws IOException
/*     */   {
/*  99 */     URL url = getURL();
/*     */     try {
/* 101 */       return ResourceUtils.toURI(url);
/*     */     }
/*     */     catch (URISyntaxException ex) {
/* 104 */       throw new NestedIOException("Invalid URI [" + url + "]", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public File getFile()
/*     */     throws IOException
/*     */   {
/* 114 */     throw new FileNotFoundException(getDescription() + " cannot be resolved to absolute file path");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long contentLength()
/*     */     throws IOException
/*     */   {
/* 126 */     InputStream is = getInputStream();
/* 127 */     Assert.state(is != null, "Resource InputStream must not be null");
/*     */     try {
/* 129 */       long size = 0L;
/* 130 */       byte[] buf = new byte['ÿ'];
/*     */       int read;
/* 132 */       while ((read = is.read(buf)) != -1) {
/* 133 */         size += read;
/*     */       }
/* 135 */       return size;
/*     */     }
/*     */     finally {
/*     */       try {
/* 139 */         is.close();
/*     */       }
/*     */       catch (IOException localIOException1) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long lastModified()
/*     */     throws IOException
/*     */   {
/* 153 */     long lastModified = getFileForLastModifiedCheck().lastModified();
/* 154 */     if (lastModified == 0L) {
/* 155 */       throw new FileNotFoundException(getDescription() + " cannot be resolved in the file system for resolving its last-modified timestamp");
/*     */     }
/*     */     
/* 158 */     return lastModified;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected File getFileForLastModifiedCheck()
/*     */     throws IOException
/*     */   {
/* 169 */     return getFile();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Resource createRelative(String relativePath)
/*     */     throws IOException
/*     */   {
/* 178 */     throw new FileNotFoundException("Cannot create a relative resource for " + getDescription());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFilename()
/*     */   {
/* 187 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 197 */     return getDescription();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 207 */     return (obj == this) || (((obj instanceof Resource)) && (((Resource)obj).getDescription().equals(getDescription())));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 216 */     return getDescription().hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\io\AbstractResource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */