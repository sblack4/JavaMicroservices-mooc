/*     */ package org.springframework.core.io.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.nio.charset.Charset;
/*     */ import org.springframework.core.io.InputStreamSource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EncodedResource
/*     */   implements InputStreamSource
/*     */ {
/*     */   private final Resource resource;
/*     */   private final String encoding;
/*     */   private final Charset charset;
/*     */   
/*     */   public EncodedResource(Resource resource)
/*     */   {
/*  58 */     this(resource, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EncodedResource(Resource resource, String encoding)
/*     */   {
/*  68 */     this(resource, encoding, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EncodedResource(Resource resource, Charset charset)
/*     */   {
/*  78 */     this(resource, null, charset);
/*     */   }
/*     */   
/*     */   private EncodedResource(Resource resource, String encoding, Charset charset)
/*     */   {
/*  83 */     Assert.notNull(resource, "Resource must not be null");
/*  84 */     this.resource = resource;
/*  85 */     this.encoding = encoding;
/*  86 */     this.charset = charset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Resource getResource()
/*     */   {
/*  94 */     return this.resource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getEncoding()
/*     */   {
/* 102 */     return this.encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Charset getCharset()
/*     */   {
/* 110 */     return this.charset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean requiresReader()
/*     */   {
/* 121 */     return (this.encoding != null) || (this.charset != null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Reader getReader()
/*     */     throws IOException
/*     */   {
/* 133 */     if (this.charset != null) {
/* 134 */       return new InputStreamReader(this.resource.getInputStream(), this.charset);
/*     */     }
/* 136 */     if (this.encoding != null) {
/* 137 */       return new InputStreamReader(this.resource.getInputStream(), this.encoding);
/*     */     }
/*     */     
/* 140 */     return new InputStreamReader(this.resource.getInputStream());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputStream getInputStream()
/*     */     throws IOException
/*     */   {
/* 153 */     return this.resource.getInputStream();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 159 */     if (this == other) {
/* 160 */       return true;
/*     */     }
/* 162 */     if (!(other instanceof EncodedResource)) {
/* 163 */       return false;
/*     */     }
/* 165 */     EncodedResource otherResource = (EncodedResource)other;
/*     */     
/*     */ 
/* 168 */     return (this.resource.equals(otherResource.resource)) && (ObjectUtils.nullSafeEquals(this.charset, otherResource.charset)) && (ObjectUtils.nullSafeEquals(this.encoding, otherResource.encoding));
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 173 */     return this.resource.hashCode();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 178 */     return this.resource.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\io\support\EncodedResource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */