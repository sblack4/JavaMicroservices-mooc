/*     */ package org.springframework.core.io;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.LinkOption;
/*     */ import java.nio.file.OpenOption;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.nio.file.attribute.FileTime;
/*     */ import org.springframework.lang.UsesJava7;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @UsesJava7
/*     */ public class PathResource
/*     */   extends AbstractResource
/*     */   implements WritableResource
/*     */ {
/*     */   private final Path path;
/*     */   
/*     */   public PathResource(Path path)
/*     */   {
/*  59 */     Assert.notNull(path, "Path must not be null");
/*  60 */     this.path = path.normalize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PathResource(String path)
/*     */   {
/*  73 */     Assert.notNull(path, "Path must not be null");
/*  74 */     this.path = Paths.get(path, new String[0]).normalize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PathResource(URI uri)
/*     */   {
/*  87 */     Assert.notNull(uri, "URI must not be null");
/*  88 */     this.path = Paths.get(uri).normalize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getPath()
/*     */   {
/*  96 */     return this.path.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean exists()
/*     */   {
/* 105 */     return Files.exists(this.path, new LinkOption[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isReadable()
/*     */   {
/* 116 */     return (Files.isReadable(this.path)) && (!Files.isDirectory(this.path, new LinkOption[0]));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputStream getInputStream()
/*     */     throws IOException
/*     */   {
/* 125 */     if (!exists()) {
/* 126 */       throw new FileNotFoundException(getPath() + " (no such file or directory)");
/*     */     }
/* 128 */     if (Files.isDirectory(this.path, new LinkOption[0])) {
/* 129 */       throw new FileNotFoundException(getPath() + " (is a directory)");
/*     */     }
/* 131 */     return Files.newInputStream(this.path, new OpenOption[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isWritable()
/*     */   {
/* 142 */     return (Files.isWritable(this.path)) && (!Files.isDirectory(this.path, new LinkOption[0]));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public OutputStream getOutputStream()
/*     */     throws IOException
/*     */   {
/* 151 */     if (Files.isDirectory(this.path, new LinkOption[0])) {
/* 152 */       throw new FileNotFoundException(getPath() + " (is a directory)");
/*     */     }
/* 154 */     return Files.newOutputStream(this.path, new OpenOption[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URL getURL()
/*     */     throws IOException
/*     */   {
/* 164 */     return this.path.toUri().toURL();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public URI getURI()
/*     */     throws IOException
/*     */   {
/* 173 */     return this.path.toUri();
/*     */   }
/*     */   
/*     */ 
/*     */   public File getFile()
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 182 */       return this.path.toFile();
/*     */ 
/*     */     }
/*     */     catch (UnsupportedOperationException ex)
/*     */     {
/* 187 */       throw new FileNotFoundException(this.path + " cannot be resolved to " + "absolute file path");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public long contentLength()
/*     */     throws IOException
/*     */   {
/* 196 */     return Files.size(this.path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long lastModified()
/*     */     throws IOException
/*     */   {
/* 207 */     return Files.getLastModifiedTime(this.path, new LinkOption[0]).toMillis();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Resource createRelative(String relativePath)
/*     */     throws IOException
/*     */   {
/* 217 */     return new PathResource(this.path.resolve(relativePath));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFilename()
/*     */   {
/* 226 */     return this.path.getFileName().toString();
/*     */   }
/*     */   
/*     */   public String getDescription()
/*     */   {
/* 231 */     return "path [" + this.path.toAbsolutePath() + "]";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 241 */     return (this == obj) || (((obj instanceof PathResource)) && (this.path.equals(((PathResource)obj).path)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 249 */     return this.path.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\io\PathResource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */