/*     */ package org.springframework.core.io;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractFileResolvingResource
/*     */   extends AbstractResource
/*     */ {
/*     */   public File getFile()
/*     */     throws IOException
/*     */   {
/*  48 */     URL url = getURL();
/*  49 */     if (url.getProtocol().startsWith("vfs")) {
/*  50 */       return VfsResourceDelegate.getResource(url).getFile();
/*     */     }
/*  52 */     return ResourceUtils.getFile(url, getDescription());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected File getFileForLastModifiedCheck()
/*     */     throws IOException
/*     */   {
/*  61 */     URL url = getURL();
/*  62 */     if (ResourceUtils.isJarURL(url)) {
/*  63 */       URL actualUrl = ResourceUtils.extractArchiveURL(url);
/*  64 */       if (actualUrl.getProtocol().startsWith("vfs")) {
/*  65 */         return VfsResourceDelegate.getResource(actualUrl).getFile();
/*     */       }
/*  67 */       return ResourceUtils.getFile(actualUrl, "Jar URL");
/*     */     }
/*     */     
/*  70 */     return getFile();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected File getFile(URI uri)
/*     */     throws IOException
/*     */   {
/*  80 */     if (uri.getScheme().startsWith("vfs")) {
/*  81 */       return VfsResourceDelegate.getResource(uri).getFile();
/*     */     }
/*  83 */     return ResourceUtils.getFile(uri, getDescription());
/*     */   }
/*     */   
/*     */   public boolean exists()
/*     */   {
/*     */     try
/*     */     {
/*  90 */       URL url = getURL();
/*  91 */       if (ResourceUtils.isFileURL(url))
/*     */       {
/*  93 */         return getFile().exists();
/*     */       }
/*     */       
/*     */ 
/*  97 */       URLConnection con = url.openConnection();
/*  98 */       customizeConnection(con);
/*  99 */       HttpURLConnection httpCon = (con instanceof HttpURLConnection) ? (HttpURLConnection)con : null;
/*     */       
/* 101 */       if (httpCon != null) {
/* 102 */         int code = httpCon.getResponseCode();
/* 103 */         if (code == 200) {
/* 104 */           return true;
/*     */         }
/* 106 */         if (code == 404) {
/* 107 */           return false;
/*     */         }
/*     */       }
/* 110 */       if (con.getContentLength() >= 0) {
/* 111 */         return true;
/*     */       }
/* 113 */       if (httpCon != null)
/*     */       {
/* 115 */         httpCon.disconnect();
/* 116 */         return false;
/*     */       }
/*     */       
/*     */ 
/* 120 */       InputStream is = getInputStream();
/* 121 */       is.close();
/* 122 */       return true;
/*     */     }
/*     */     catch (IOException ex) {}
/*     */     
/*     */ 
/* 127 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isReadable()
/*     */   {
/*     */     try
/*     */     {
/* 134 */       URL url = getURL();
/* 135 */       if (ResourceUtils.isFileURL(url))
/*     */       {
/* 137 */         File file = getFile();
/* 138 */         return (file.canRead()) && (!file.isDirectory());
/*     */       }
/*     */       
/* 141 */       return true;
/*     */     }
/*     */     catch (IOException ex) {}
/*     */     
/* 145 */     return false;
/*     */   }
/*     */   
/*     */   public long contentLength()
/*     */     throws IOException
/*     */   {
/* 151 */     URL url = getURL();
/* 152 */     if (ResourceUtils.isFileURL(url))
/*     */     {
/* 154 */       return getFile().length();
/*     */     }
/*     */     
/*     */ 
/* 158 */     URLConnection con = url.openConnection();
/* 159 */     customizeConnection(con);
/* 160 */     return con.getContentLength();
/*     */   }
/*     */   
/*     */   public long lastModified()
/*     */     throws IOException
/*     */   {
/* 166 */     URL url = getURL();
/* 167 */     if ((ResourceUtils.isFileURL(url)) || (ResourceUtils.isJarURL(url)))
/*     */     {
/* 169 */       return super.lastModified();
/*     */     }
/*     */     
/*     */ 
/* 173 */     URLConnection con = url.openConnection();
/* 174 */     customizeConnection(con);
/* 175 */     return con.getLastModified();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void customizeConnection(URLConnection con)
/*     */     throws IOException
/*     */   {
/* 190 */     ResourceUtils.useCachesIfNecessary(con);
/* 191 */     if ((con instanceof HttpURLConnection)) {
/* 192 */       customizeConnection((HttpURLConnection)con);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void customizeConnection(HttpURLConnection con)
/*     */     throws IOException
/*     */   {
/* 204 */     con.setRequestMethod("HEAD");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class VfsResourceDelegate
/*     */   {
/*     */     public static Resource getResource(URL url)
/*     */       throws IOException
/*     */     {
/* 214 */       return new VfsResource(VfsUtils.getRoot(url));
/*     */     }
/*     */     
/*     */     public static Resource getResource(URI uri) throws IOException {
/* 218 */       return new VfsResource(VfsUtils.getRoot(uri));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\io\AbstractFileResolvingResource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */