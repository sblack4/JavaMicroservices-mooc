/*     */ package org.springframework.core.io.support;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.JarURLConnection;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.net.URLConnection;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.zip.ZipException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.FileSystemResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.UrlResource;
/*     */ import org.springframework.core.io.VfsResource;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PathMatchingResourcePatternResolver
/*     */   implements ResourcePatternResolver
/*     */ {
/* 182 */   private static final Log logger = LogFactory.getLog(PathMatchingResourcePatternResolver.class);
/*     */   private static Method equinoxResolveMethod;
/*     */   private final ResourceLoader resourceLoader;
/*     */   
/*     */   static
/*     */   {
/*     */     try {
/* 189 */       Class<?> fileLocatorClass = ClassUtils.forName("org.eclipse.core.runtime.FileLocator", PathMatchingResourcePatternResolver.class
/* 190 */         .getClassLoader());
/* 191 */       equinoxResolveMethod = fileLocatorClass.getMethod("resolve", new Class[] { URL.class });
/* 192 */       logger.debug("Found Equinox FileLocator for OSGi bundle URL resolution");
/*     */     }
/*     */     catch (Throwable ex) {
/* 195 */       equinoxResolveMethod = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 202 */   private PathMatcher pathMatcher = new AntPathMatcher();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PathMatchingResourcePatternResolver()
/*     */   {
/* 211 */     this.resourceLoader = new DefaultResourceLoader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PathMatchingResourcePatternResolver(ResourceLoader resourceLoader)
/*     */   {
/* 221 */     Assert.notNull(resourceLoader, "ResourceLoader must not be null");
/* 222 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PathMatchingResourcePatternResolver(ClassLoader classLoader)
/*     */   {
/* 233 */     this.resourceLoader = new DefaultResourceLoader(classLoader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceLoader getResourceLoader()
/*     */   {
/* 241 */     return this.resourceLoader;
/*     */   }
/*     */   
/*     */   public ClassLoader getClassLoader()
/*     */   {
/* 246 */     return getResourceLoader().getClassLoader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPathMatcher(PathMatcher pathMatcher)
/*     */   {
/* 255 */     Assert.notNull(pathMatcher, "PathMatcher must not be null");
/* 256 */     this.pathMatcher = pathMatcher;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PathMatcher getPathMatcher()
/*     */   {
/* 263 */     return this.pathMatcher;
/*     */   }
/*     */   
/*     */ 
/*     */   public Resource getResource(String location)
/*     */   {
/* 269 */     return getResourceLoader().getResource(location);
/*     */   }
/*     */   
/*     */   public Resource[] getResources(String locationPattern) throws IOException
/*     */   {
/* 274 */     Assert.notNull(locationPattern, "Location pattern must not be null");
/* 275 */     if (locationPattern.startsWith("classpath*:"))
/*     */     {
/* 277 */       if (getPathMatcher().isPattern(locationPattern.substring("classpath*:".length())))
/*     */       {
/* 279 */         return findPathMatchingResources(locationPattern);
/*     */       }
/*     */       
/*     */ 
/* 283 */       return findAllClassPathResources(locationPattern.substring("classpath*:".length()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 289 */     int prefixEnd = locationPattern.indexOf(":") + 1;
/* 290 */     if (getPathMatcher().isPattern(locationPattern.substring(prefixEnd)))
/*     */     {
/* 292 */       return findPathMatchingResources(locationPattern);
/*     */     }
/*     */     
/*     */ 
/* 296 */     return new Resource[] { getResourceLoader().getResource(locationPattern) };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Resource[] findAllClassPathResources(String location)
/*     */     throws IOException
/*     */   {
/* 311 */     String path = location;
/* 312 */     if (path.startsWith("/")) {
/* 313 */       path = path.substring(1);
/*     */     }
/* 315 */     Set<Resource> result = doFindAllClassPathResources(path);
/* 316 */     if (logger.isDebugEnabled()) {
/* 317 */       logger.debug("Resolved classpath location [" + location + "] to resources " + result);
/*     */     }
/* 319 */     return (Resource[])result.toArray(new Resource[result.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Set<Resource> doFindAllClassPathResources(String path)
/*     */     throws IOException
/*     */   {
/* 330 */     Set<Resource> result = new LinkedHashSet(16);
/* 331 */     ClassLoader cl = getClassLoader();
/* 332 */     Enumeration<URL> resourceUrls = cl != null ? cl.getResources(path) : ClassLoader.getSystemResources(path);
/* 333 */     while (resourceUrls.hasMoreElements()) {
/* 334 */       URL url = (URL)resourceUrls.nextElement();
/* 335 */       result.add(convertClassLoaderURL(url));
/*     */     }
/* 337 */     if ("".equals(path))
/*     */     {
/*     */ 
/* 340 */       addAllClassLoaderJarRoots(cl, result);
/*     */     }
/* 342 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Resource convertClassLoaderURL(URL url)
/*     */   {
/* 354 */     return new UrlResource(url);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addAllClassLoaderJarRoots(ClassLoader classLoader, Set<Resource> result)
/*     */   {
/* 365 */     if ((classLoader instanceof URLClassLoader)) {
/*     */       try {
/* 367 */         for (URL url : ((URLClassLoader)classLoader).getURLs()) {
/* 368 */           if (ResourceUtils.isJarFileURL(url)) {
/*     */             try
/*     */             {
/* 371 */               UrlResource jarResource = new UrlResource("jar:" + url.toString() + "!/");
/* 372 */               if (jarResource.exists()) {
/* 373 */                 result.add(jarResource);
/*     */               }
/*     */             }
/*     */             catch (MalformedURLException ex) {
/* 377 */               if (logger.isDebugEnabled()) {
/* 378 */                 logger.debug("Cannot search for matching files underneath [" + url + "] because it cannot be converted to a valid 'jar:' URL: " + ex
/* 379 */                   .getMessage());
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception ex) {
/* 386 */         if (logger.isDebugEnabled()) {
/* 387 */           logger.debug("Cannot introspect jar files since ClassLoader [" + classLoader + "] does not support 'getURLs()': " + ex);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 393 */     if (classLoader == ClassLoader.getSystemClassLoader())
/*     */     {
/* 395 */       addClassPathManifestEntries(result);
/*     */     }
/*     */     
/* 398 */     if (classLoader != null) {
/*     */       try
/*     */       {
/* 401 */         addAllClassLoaderJarRoots(classLoader.getParent(), result);
/*     */       }
/*     */       catch (Exception ex) {
/* 404 */         if (logger.isDebugEnabled()) {
/* 405 */           logger.debug("Cannot introspect jar files in parent ClassLoader since [" + classLoader + "] does not support 'getParent()': " + ex);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addClassPathManifestEntries(Set<Resource> result)
/*     */   {
/*     */     try
/*     */     {
/* 420 */       String javaClassPathProperty = System.getProperty("java.class.path");
/* 421 */       for (String url : StringUtils.delimitedListToStringArray(javaClassPathProperty, 
/* 422 */         System.getProperty("path.separator"))) {
/*     */         try {
/* 424 */           if (url.endsWith(".jar")) {
/* 425 */             UrlResource jarResource = new UrlResource("jar:file:" + url + "!/");
/*     */             
/* 427 */             if (jarResource.exists()) {
/* 428 */               result.add(jarResource);
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (MalformedURLException ex) {
/* 433 */           if (logger.isDebugEnabled()) {
/* 434 */             logger.debug("Cannot search for matching files underneath [" + url + "] because it cannot be converted to a valid 'jar:' URL: " + ex
/* 435 */               .getMessage());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 441 */       if (logger.isDebugEnabled()) {
/* 442 */         logger.debug("Failed to evaluate 'java.class.path' manifest entries: " + ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Resource[] findPathMatchingResources(String locationPattern)
/*     */     throws IOException
/*     */   {
/* 459 */     String rootDirPath = determineRootDir(locationPattern);
/* 460 */     String subPattern = locationPattern.substring(rootDirPath.length());
/* 461 */     Resource[] rootDirResources = getResources(rootDirPath);
/* 462 */     Set<Resource> result = new LinkedHashSet(16);
/* 463 */     for (Resource rootDirResource : rootDirResources) {
/* 464 */       rootDirResource = resolveRootDirResource(rootDirResource);
/* 465 */       URL rootDirURL = rootDirResource.getURL();
/* 466 */       if ((equinoxResolveMethod != null) && 
/* 467 */         (rootDirURL.getProtocol().startsWith("bundle"))) {
/* 468 */         rootDirURL = (URL)ReflectionUtils.invokeMethod(equinoxResolveMethod, null, new Object[] { rootDirURL });
/* 469 */         rootDirResource = new UrlResource(rootDirURL);
/*     */       }
/*     */       
/* 472 */       if (rootDirURL.getProtocol().startsWith("vfs")) {
/* 473 */         result.addAll(VfsResourceMatchingDelegate.findMatchingResources(rootDirURL, subPattern, getPathMatcher()));
/*     */       }
/* 475 */       else if ((ResourceUtils.isJarURL(rootDirURL)) || (isJarResource(rootDirResource))) {
/* 476 */         result.addAll(doFindPathMatchingJarResources(rootDirResource, rootDirURL, subPattern));
/*     */       }
/*     */       else {
/* 479 */         result.addAll(doFindPathMatchingFileResources(rootDirResource, subPattern));
/*     */       }
/*     */     }
/* 482 */     if (logger.isDebugEnabled()) {
/* 483 */       logger.debug("Resolved location pattern [" + locationPattern + "] to resources " + result);
/*     */     }
/* 485 */     return (Resource[])result.toArray(new Resource[result.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String determineRootDir(String location)
/*     */   {
/* 501 */     int prefixEnd = location.indexOf(":") + 1;
/* 502 */     int rootDirEnd = location.length();
/* 503 */     while ((rootDirEnd > prefixEnd) && (getPathMatcher().isPattern(location.substring(prefixEnd, rootDirEnd)))) {
/* 504 */       rootDirEnd = location.lastIndexOf('/', rootDirEnd - 2) + 1;
/*     */     }
/* 506 */     if (rootDirEnd == 0) {
/* 507 */       rootDirEnd = prefixEnd;
/*     */     }
/* 509 */     return location.substring(0, rootDirEnd);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Resource resolveRootDirResource(Resource original)
/*     */     throws IOException
/*     */   {
/* 523 */     return original;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isJarResource(Resource resource)
/*     */     throws IOException
/*     */   {
/* 539 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Set<Resource> doFindPathMatchingJarResources(Resource rootDirResource, URL rootDirURL, String subPattern)
/*     */     throws IOException
/*     */   {
/* 559 */     Set<Resource> result = doFindPathMatchingJarResources(rootDirResource, subPattern);
/* 560 */     if (result != null) {
/* 561 */       return result;
/*     */     }
/*     */     
/* 564 */     URLConnection con = rootDirURL.openConnection();
/*     */     
/*     */ 
/*     */     boolean closeJarFile;
/*     */     
/*     */ 
/* 570 */     if ((con instanceof JarURLConnection))
/*     */     {
/* 572 */       JarURLConnection jarCon = (JarURLConnection)con;
/* 573 */       ResourceUtils.useCachesIfNecessary(jarCon);
/* 574 */       JarFile jarFile = jarCon.getJarFile();
/* 575 */       String jarFileUrl = jarCon.getJarFileURL().toExternalForm();
/* 576 */       JarEntry jarEntry = jarCon.getJarEntry();
/* 577 */       String rootEntryPath = jarEntry != null ? jarEntry.getName() : "";
/* 578 */       closeJarFile = !jarCon.getUseCaches();
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 585 */       String urlFile = rootDirURL.getFile();
/*     */       try {
/* 587 */         int separatorIndex = urlFile.indexOf("!/");
/* 588 */         JarFile jarFile; String rootEntryPath; if (separatorIndex != -1) {
/* 589 */           String jarFileUrl = urlFile.substring(0, separatorIndex);
/* 590 */           String rootEntryPath = urlFile.substring(separatorIndex + "!/".length());
/* 591 */           jarFile = getJarFile(jarFileUrl);
/*     */         }
/*     */         else {
/* 594 */           JarFile jarFile = new JarFile(urlFile);
/* 595 */           String jarFileUrl = urlFile;
/* 596 */           rootEntryPath = "";
/*     */         }
/* 598 */         closeJarFile = true;
/*     */       } catch (ZipException ex) {
/*     */         boolean closeJarFile;
/* 601 */         if (logger.isDebugEnabled()) {
/* 602 */           logger.debug("Skipping invalid jar classpath entry [" + urlFile + "]");
/*     */         }
/* 604 */         return Collections.emptySet();
/*     */       }
/*     */     }
/*     */     try { String rootEntryPath;
/*     */       String jarFileUrl;
/* 609 */       if (logger.isDebugEnabled()) {
/* 610 */         logger.debug("Looking for matching resources in jar file [" + jarFileUrl + "]");
/*     */       }
/* 612 */       if ((!"".equals(rootEntryPath)) && (!rootEntryPath.endsWith("/")))
/*     */       {
/*     */ 
/* 615 */         rootEntryPath = rootEntryPath + "/";
/*     */       }
/* 617 */       result = new LinkedHashSet(8);
/* 618 */       for (Enumeration<JarEntry> entries = jarFile.entries(); entries.hasMoreElements();) {
/* 619 */         JarEntry entry = (JarEntry)entries.nextElement();
/* 620 */         String entryPath = entry.getName();
/* 621 */         if (entryPath.startsWith(rootEntryPath)) {
/* 622 */           String relativePath = entryPath.substring(rootEntryPath.length());
/* 623 */           if (getPathMatcher().match(subPattern, relativePath)) {
/* 624 */             result.add(rootDirResource.createRelative(relativePath));
/*     */           }
/*     */         }
/*     */       }
/* 628 */       return result;
/*     */     } finally { boolean closeJarFile;
/*     */       JarFile jarFile;
/* 631 */       if (closeJarFile) {
/* 632 */         jarFile.close();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected Set<Resource> doFindPathMatchingJarResources(Resource rootDirResource, String subPattern)
/*     */     throws IOException
/*     */   {
/* 651 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   protected JarFile getJarFile(String jarFileUrl)
/*     */     throws IOException
/*     */   {
/* 658 */     if (jarFileUrl.startsWith("file:")) {
/*     */       try {
/* 660 */         return new JarFile(ResourceUtils.toURI(jarFileUrl).getSchemeSpecificPart());
/*     */       }
/*     */       catch (URISyntaxException ex)
/*     */       {
/* 664 */         return new JarFile(jarFileUrl.substring("file:".length()));
/*     */       }
/*     */     }
/*     */     
/* 668 */     return new JarFile(jarFileUrl);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Set<Resource> doFindPathMatchingFileResources(Resource rootDirResource, String subPattern)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 687 */       rootDir = rootDirResource.getFile().getAbsoluteFile();
/*     */     } catch (IOException ex) {
/*     */       File rootDir;
/* 690 */       if (logger.isWarnEnabled()) {
/* 691 */         logger.warn("Cannot search for matching files underneath " + rootDirResource + " because it does not correspond to a directory in the file system", ex);
/*     */       }
/*     */       
/* 694 */       return Collections.emptySet(); }
/*     */     File rootDir;
/* 696 */     return doFindMatchingFileSystemResources(rootDir, subPattern);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Set<Resource> doFindMatchingFileSystemResources(File rootDir, String subPattern)
/*     */     throws IOException
/*     */   {
/* 710 */     if (logger.isDebugEnabled()) {
/* 711 */       logger.debug("Looking for matching resources in directory tree [" + rootDir.getPath() + "]");
/*     */     }
/* 713 */     Set<File> matchingFiles = retrieveMatchingFiles(rootDir, subPattern);
/* 714 */     Set<Resource> result = new LinkedHashSet(matchingFiles.size());
/* 715 */     for (File file : matchingFiles) {
/* 716 */       result.add(new FileSystemResource(file));
/*     */     }
/* 718 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Set<File> retrieveMatchingFiles(File rootDir, String pattern)
/*     */     throws IOException
/*     */   {
/* 731 */     if (!rootDir.exists())
/*     */     {
/* 733 */       if (logger.isDebugEnabled()) {
/* 734 */         logger.debug("Skipping [" + rootDir.getAbsolutePath() + "] because it does not exist");
/*     */       }
/* 736 */       return Collections.emptySet();
/*     */     }
/* 738 */     if (!rootDir.isDirectory())
/*     */     {
/* 740 */       if (logger.isWarnEnabled()) {
/* 741 */         logger.warn("Skipping [" + rootDir.getAbsolutePath() + "] because it does not denote a directory");
/*     */       }
/* 743 */       return Collections.emptySet();
/*     */     }
/* 745 */     if (!rootDir.canRead()) {
/* 746 */       if (logger.isWarnEnabled()) {
/* 747 */         logger.warn("Cannot search for matching files underneath directory [" + rootDir.getAbsolutePath() + "] because the application is not allowed to read the directory");
/*     */       }
/*     */       
/* 750 */       return Collections.emptySet();
/*     */     }
/* 752 */     String fullPattern = StringUtils.replace(rootDir.getAbsolutePath(), File.separator, "/");
/* 753 */     if (!pattern.startsWith("/")) {
/* 754 */       fullPattern = fullPattern + "/";
/*     */     }
/* 756 */     fullPattern = fullPattern + StringUtils.replace(pattern, File.separator, "/");
/* 757 */     Set<File> result = new LinkedHashSet(8);
/* 758 */     doRetrieveMatchingFiles(fullPattern, rootDir, result);
/* 759 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doRetrieveMatchingFiles(String fullPattern, File dir, Set<File> result)
/*     */     throws IOException
/*     */   {
/* 772 */     if (logger.isDebugEnabled()) {
/* 773 */       logger.debug("Searching directory [" + dir.getAbsolutePath() + "] for files matching pattern [" + fullPattern + "]");
/*     */     }
/*     */     
/* 776 */     File[] dirContents = dir.listFiles();
/* 777 */     if (dirContents == null) {
/* 778 */       if (logger.isWarnEnabled()) {
/* 779 */         logger.warn("Could not retrieve contents of directory [" + dir.getAbsolutePath() + "]");
/*     */       }
/* 781 */       return;
/*     */     }
/* 783 */     Arrays.sort(dirContents);
/* 784 */     for (File content : dirContents) {
/* 785 */       String currPath = StringUtils.replace(content.getAbsolutePath(), File.separator, "/");
/* 786 */       if ((content.isDirectory()) && (getPathMatcher().matchStart(fullPattern, currPath + "/"))) {
/* 787 */         if (!content.canRead()) {
/* 788 */           if (logger.isDebugEnabled()) {
/* 789 */             logger.debug("Skipping subdirectory [" + dir.getAbsolutePath() + "] because the application is not allowed to read the directory");
/*     */           }
/*     */           
/*     */         }
/*     */         else {
/* 794 */           doRetrieveMatchingFiles(fullPattern, content, result);
/*     */         }
/*     */       }
/* 797 */       if (getPathMatcher().match(fullPattern, currPath)) {
/* 798 */         result.add(content);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class VfsResourceMatchingDelegate
/*     */   {
/*     */     public static Set<Resource> findMatchingResources(URL rootDirURL, String locationPattern, PathMatcher pathMatcher)
/*     */       throws IOException
/*     */     {
/* 812 */       Object root = VfsPatternUtils.findRoot(rootDirURL);
/*     */       
/* 814 */       PathMatchingResourcePatternResolver.PatternVirtualFileVisitor visitor = new PathMatchingResourcePatternResolver.PatternVirtualFileVisitor(VfsPatternUtils.getPath(root), locationPattern, pathMatcher);
/* 815 */       VfsPatternUtils.visit(root, visitor);
/* 816 */       return visitor.getResources();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class PatternVirtualFileVisitor
/*     */     implements InvocationHandler
/*     */   {
/*     */     private final String subPattern;
/*     */     
/*     */ 
/*     */     private final PathMatcher pathMatcher;
/*     */     
/*     */ 
/*     */     private final String rootPath;
/*     */     
/* 833 */     private final Set<Resource> resources = new LinkedHashSet();
/*     */     
/*     */     public PatternVirtualFileVisitor(String rootPath, String subPattern, PathMatcher pathMatcher) {
/* 836 */       this.subPattern = subPattern;
/* 837 */       this.pathMatcher = pathMatcher;
/* 838 */       this.rootPath = (rootPath + "/");
/*     */     }
/*     */     
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
/*     */     {
/* 843 */       String methodName = method.getName();
/* 844 */       if (Object.class == method.getDeclaringClass()) {
/* 845 */         if (methodName.equals("equals"))
/*     */         {
/* 847 */           return Boolean.valueOf(proxy == args[0]);
/*     */         }
/* 849 */         if (methodName.equals("hashCode")) {
/* 850 */           return Integer.valueOf(System.identityHashCode(proxy));
/*     */         }
/*     */       } else {
/* 853 */         if ("getAttributes".equals(methodName)) {
/* 854 */           return getAttributes();
/*     */         }
/* 856 */         if ("visit".equals(methodName)) {
/* 857 */           visit(args[0]);
/* 858 */           return null;
/*     */         }
/* 860 */         if ("toString".equals(methodName)) {
/* 861 */           return toString();
/*     */         }
/*     */       }
/* 864 */       throw new IllegalStateException("Unexpected method invocation: " + method);
/*     */     }
/*     */     
/*     */     public void visit(Object vfsResource) {
/* 868 */       if (this.pathMatcher.match(this.subPattern, 
/* 869 */         VfsPatternUtils.getPath(vfsResource).substring(this.rootPath.length()))) {
/* 870 */         this.resources.add(new VfsResource(vfsResource));
/*     */       }
/*     */     }
/*     */     
/*     */     public Object getAttributes() {
/* 875 */       return VfsPatternUtils.getVisitorAttribute();
/*     */     }
/*     */     
/*     */     public Set<Resource> getResources() {
/* 879 */       return this.resources;
/*     */     }
/*     */     
/*     */     public int size() {
/* 883 */       return this.resources.size();
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 888 */       return "sub-pattern: " + this.subPattern + ", resources: " + this.resources;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\io\support\PathMatchingResourcePatternResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */