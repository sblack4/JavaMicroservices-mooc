/*    */ package org.springframework.core;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrioritizedParameterNameDiscoverer
/*    */   implements ParameterNameDiscoverer
/*    */ {
/* 38 */   private final List<ParameterNameDiscoverer> parameterNameDiscoverers = new LinkedList();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void addDiscoverer(ParameterNameDiscoverer pnd)
/*    */   {
/* 47 */     this.parameterNameDiscoverers.add(pnd);
/*    */   }
/*    */   
/*    */ 
/*    */   public String[] getParameterNames(Method method)
/*    */   {
/* 53 */     for (ParameterNameDiscoverer pnd : this.parameterNameDiscoverers) {
/* 54 */       String[] result = pnd.getParameterNames(method);
/* 55 */       if (result != null) {
/* 56 */         return result;
/*    */       }
/*    */     }
/* 59 */     return null;
/*    */   }
/*    */   
/*    */   public String[] getParameterNames(Constructor<?> ctor)
/*    */   {
/* 64 */     for (ParameterNameDiscoverer pnd : this.parameterNameDiscoverers) {
/* 65 */       String[] result = pnd.getParameterNames(ctor);
/* 66 */       if (result != null) {
/* 67 */         return result;
/*    */       }
/*    */     }
/* 70 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\PrioritizedParameterNameDiscoverer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */