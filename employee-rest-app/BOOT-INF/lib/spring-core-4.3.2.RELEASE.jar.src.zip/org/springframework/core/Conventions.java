/*     */ package org.springframework.core;
/*     */ 
/*     */ import java.io.Externalizable;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Conventions
/*     */ {
/*     */   private static final String PLURAL_SUFFIX = "List";
/*  54 */   private static final Set<Class<?>> IGNORED_INTERFACES = Collections.unmodifiableSet(new HashSet(
/*  55 */     Arrays.asList(new Class[] { Serializable.class, Externalizable.class, Cloneable.class, Comparable.class })));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getVariableName(Object value)
/*     */   {
/*  79 */     Assert.notNull(value, "Value must not be null");
/*     */     
/*  81 */     boolean pluralize = false;
/*     */     Class<?> valueClass;
/*  83 */     if (value.getClass().isArray()) {
/*  84 */       Class<?> valueClass = value.getClass().getComponentType();
/*  85 */       pluralize = true;
/*     */     }
/*  87 */     else if ((value instanceof Collection)) {
/*  88 */       Collection<?> collection = (Collection)value;
/*  89 */       if (collection.isEmpty()) {
/*  90 */         throw new IllegalArgumentException("Cannot generate variable name for an empty Collection");
/*     */       }
/*  92 */       Object valueToCheck = peekAhead(collection);
/*  93 */       Class<?> valueClass = getClassForValue(valueToCheck);
/*  94 */       pluralize = true;
/*     */     }
/*     */     else {
/*  97 */       valueClass = getClassForValue(value);
/*     */     }
/*     */     
/* 100 */     String name = ClassUtils.getShortNameAsProperty(valueClass);
/* 101 */     return pluralize ? pluralize(name) : name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getVariableNameForParameter(MethodParameter parameter)
/*     */   {
/* 111 */     Assert.notNull(parameter, "MethodParameter must not be null");
/*     */     
/* 113 */     boolean pluralize = false;
/*     */     Class<?> valueClass;
/* 115 */     if (parameter.getParameterType().isArray()) {
/* 116 */       Class<?> valueClass = parameter.getParameterType().getComponentType();
/* 117 */       pluralize = true;
/*     */     }
/* 119 */     else if (Collection.class.isAssignableFrom(parameter.getParameterType())) {
/* 120 */       Class<?> valueClass = GenericCollectionTypeResolver.getCollectionParameterType(parameter);
/* 121 */       if (valueClass == null) {
/* 122 */         throw new IllegalArgumentException("Cannot generate variable name for non-typed Collection parameter type");
/*     */       }
/*     */       
/* 125 */       pluralize = true;
/*     */     }
/*     */     else {
/* 128 */       valueClass = parameter.getParameterType();
/*     */     }
/*     */     
/* 131 */     String name = ClassUtils.getShortNameAsProperty(valueClass);
/* 132 */     return pluralize ? pluralize(name) : name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getVariableNameForReturnType(Method method)
/*     */   {
/* 142 */     return getVariableNameForReturnType(method, method.getReturnType(), null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getVariableNameForReturnType(Method method, Object value)
/*     */   {
/* 155 */     return getVariableNameForReturnType(method, method.getReturnType(), value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getVariableNameForReturnType(Method method, Class<?> resolvedType, Object value)
/*     */   {
/* 169 */     Assert.notNull(method, "Method must not be null");
/*     */     
/* 171 */     if (Object.class == resolvedType) {
/* 172 */       if (value == null) {
/* 173 */         throw new IllegalArgumentException("Cannot generate variable name for an Object return type with null value");
/*     */       }
/* 175 */       return getVariableName(value);
/*     */     }
/*     */     
/*     */ 
/* 179 */     boolean pluralize = false;
/*     */     Class<?> valueClass;
/* 181 */     if (resolvedType.isArray()) {
/* 182 */       Class<?> valueClass = resolvedType.getComponentType();
/* 183 */       pluralize = true;
/*     */     }
/* 185 */     else if (Collection.class.isAssignableFrom(resolvedType)) {
/* 186 */       Class<?> valueClass = GenericCollectionTypeResolver.getCollectionReturnType(method);
/* 187 */       if (valueClass == null) {
/* 188 */         if (!(value instanceof Collection)) {
/* 189 */           throw new IllegalArgumentException("Cannot generate variable name for non-typed Collection return type and a non-Collection value");
/*     */         }
/*     */         
/* 192 */         Collection<?> collection = (Collection)value;
/* 193 */         if (collection.isEmpty()) {
/* 194 */           throw new IllegalArgumentException("Cannot generate variable name for non-typed Collection return type and an empty Collection value");
/*     */         }
/*     */         
/* 197 */         Object valueToCheck = peekAhead(collection);
/* 198 */         valueClass = getClassForValue(valueToCheck);
/*     */       }
/* 200 */       pluralize = true;
/*     */     }
/*     */     else {
/* 203 */       valueClass = resolvedType;
/*     */     }
/*     */     
/* 206 */     String name = ClassUtils.getShortNameAsProperty(valueClass);
/* 207 */     return pluralize ? pluralize(name) : name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String attributeNameToPropertyName(String attributeName)
/*     */   {
/* 216 */     Assert.notNull(attributeName, "'attributeName' must not be null");
/* 217 */     if (!attributeName.contains("-")) {
/* 218 */       return attributeName;
/*     */     }
/* 220 */     char[] chars = attributeName.toCharArray();
/* 221 */     char[] result = new char[chars.length - 1];
/* 222 */     int currPos = 0;
/* 223 */     boolean upperCaseNext = false;
/* 224 */     for (char c : chars) {
/* 225 */       if (c == '-') {
/* 226 */         upperCaseNext = true;
/*     */       }
/* 228 */       else if (upperCaseNext) {
/* 229 */         result[(currPos++)] = Character.toUpperCase(c);
/* 230 */         upperCaseNext = false;
/*     */       }
/*     */       else {
/* 233 */         result[(currPos++)] = c;
/*     */       }
/*     */     }
/* 236 */     return new String(result, 0, currPos);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getQualifiedAttributeName(Class<?> enclosingClass, String attributeName)
/*     */   {
/* 245 */     Assert.notNull(enclosingClass, "'enclosingClass' must not be null");
/* 246 */     Assert.notNull(attributeName, "'attributeName' must not be null");
/* 247 */     return enclosingClass.getName() + "." + attributeName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Class<?> getClassForValue(Object value)
/*     */   {
/* 261 */     Class<?> valueClass = value.getClass();
/* 262 */     if (Proxy.isProxyClass(valueClass)) {
/* 263 */       Class<?>[] ifcs = valueClass.getInterfaces();
/* 264 */       for (Class<?> ifc : ifcs) {
/* 265 */         if (!IGNORED_INTERFACES.contains(ifc)) {
/* 266 */           return ifc;
/*     */         }
/*     */       }
/*     */     }
/* 270 */     else if ((valueClass.getName().lastIndexOf('$') != -1) && (valueClass.getDeclaringClass() == null))
/*     */     {
/*     */ 
/* 273 */       valueClass = valueClass.getSuperclass();
/*     */     }
/* 275 */     return valueClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static String pluralize(String name)
/*     */   {
/* 282 */     return name + "List";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static <E> E peekAhead(Collection<E> collection)
/*     */   {
/* 291 */     Iterator<E> it = collection.iterator();
/* 292 */     if (!it.hasNext()) {
/* 293 */       throw new IllegalStateException("Unable to peek ahead in non-empty collection - no element found");
/*     */     }
/*     */     
/* 296 */     E value = it.next();
/* 297 */     if (value == null) {
/* 298 */       throw new IllegalStateException("Unable to peek ahead in non-empty collection - only null element found");
/*     */     }
/*     */     
/* 301 */     return value;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\Conventions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */