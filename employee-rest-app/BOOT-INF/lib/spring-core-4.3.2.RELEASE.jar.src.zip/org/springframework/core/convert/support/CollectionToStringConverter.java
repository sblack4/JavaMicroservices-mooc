/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*    */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class CollectionToStringConverter
/*    */   implements ConditionalGenericConverter
/*    */ {
/*    */   private static final String DELIMITER = ",";
/*    */   private final ConversionService conversionService;
/*    */   
/*    */   public CollectionToStringConverter(ConversionService conversionService)
/*    */   {
/* 40 */     this.conversionService = conversionService;
/*    */   }
/*    */   
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*    */   {
/* 45 */     return Collections.singleton(new GenericConverter.ConvertiblePair(Collection.class, String.class));
/*    */   }
/*    */   
/*    */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 50 */     return ConversionUtils.canConvertElements(sourceType.getElementTypeDescriptor(), targetType, this.conversionService);
/*    */   }
/*    */   
/*    */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 55 */     if (source == null) {
/* 56 */       return null;
/*    */     }
/* 58 */     Collection<?> sourceCollection = (Collection)source;
/* 59 */     if (sourceCollection.size() == 0) {
/* 60 */       return "";
/*    */     }
/* 62 */     StringBuilder sb = new StringBuilder();
/* 63 */     int i = 0;
/* 64 */     for (Object sourceElement : sourceCollection) {
/* 65 */       if (i > 0) {
/* 66 */         sb.append(",");
/*    */       }
/* 68 */       Object targetElement = this.conversionService.convert(sourceElement, sourceType.elementTypeDescriptor(sourceElement), targetType);
/* 69 */       sb.append(targetElement);
/* 70 */       i++;
/*    */     }
/* 72 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\convert\support\CollectionToStringConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */