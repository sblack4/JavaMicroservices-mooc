/*     */ package org.springframework.core.convert.support;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.convert.ConversionFailedException;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*     */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ObjectToObjectConverter
/*     */   implements ConditionalGenericConverter
/*     */ {
/*  68 */   private static final Map<Class<?>, Member> conversionMemberCache = new ConcurrentReferenceHashMap(32);
/*     */   
/*     */ 
/*     */ 
/*     */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*     */   {
/*  74 */     return Collections.singleton(new GenericConverter.ConvertiblePair(Object.class, Object.class));
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/*  80 */     return (sourceType.getType() != targetType.getType()) && (hasConversionMethodOrConstructor(targetType.getType(), sourceType.getType()));
/*     */   }
/*     */   
/*     */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/*  85 */     if (source == null) {
/*  86 */       return null;
/*     */     }
/*  88 */     Class<?> sourceClass = sourceType.getType();
/*  89 */     Class<?> targetClass = targetType.getType();
/*  90 */     Member member = getValidatedMember(targetClass, sourceClass);
/*     */     try
/*     */     {
/*  93 */       if ((member instanceof Method)) {
/*  94 */         Method method = (Method)member;
/*  95 */         ReflectionUtils.makeAccessible(method);
/*  96 */         if (!Modifier.isStatic(method.getModifiers())) {
/*  97 */           return method.invoke(source, new Object[0]);
/*     */         }
/*     */         
/* 100 */         return method.invoke(null, new Object[] { source });
/*     */       }
/*     */       
/* 103 */       if ((member instanceof Constructor)) {
/* 104 */         Constructor<?> ctor = (Constructor)member;
/* 105 */         return ctor.newInstance(new Object[] { source });
/*     */       }
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 109 */       throw new ConversionFailedException(sourceType, targetType, source, ex.getTargetException());
/*     */     }
/*     */     catch (Throwable ex) {
/* 112 */       throw new ConversionFailedException(sourceType, targetType, source, ex);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 118 */     throw new IllegalStateException(String.format("No to%3$s() method exists on %1$s, and no static valueOf/of/from(%1$s) method or %3$s(%1$s) constructor exists on %2$s.", new Object[] {sourceClass
/*     */     
/* 120 */       .getName(), targetClass.getName(), targetClass.getSimpleName() }));
/*     */   }
/*     */   
/*     */ 
/*     */   static boolean hasConversionMethodOrConstructor(Class<?> targetClass, Class<?> sourceClass)
/*     */   {
/* 126 */     return getValidatedMember(targetClass, sourceClass) != null;
/*     */   }
/*     */   
/*     */   private static Member getValidatedMember(Class<?> targetClass, Class<?> sourceClass) {
/* 130 */     Member member = (Member)conversionMemberCache.get(targetClass);
/* 131 */     if (isApplicable(member, sourceClass)) {
/* 132 */       return member;
/*     */     }
/*     */     
/* 135 */     member = determineToMethod(targetClass, sourceClass);
/* 136 */     if (member == null) {
/* 137 */       member = determineFactoryMethod(targetClass, sourceClass);
/* 138 */       if (member == null) {
/* 139 */         member = determineFactoryConstructor(targetClass, sourceClass);
/* 140 */         if (member == null) {
/* 141 */           return null;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 146 */     conversionMemberCache.put(targetClass, member);
/* 147 */     return member;
/*     */   }
/*     */   
/*     */   private static boolean isApplicable(Member member, Class<?> sourceClass) {
/* 151 */     if ((member instanceof Method)) {
/* 152 */       Method method = (Method)member;
/*     */       
/*     */ 
/* 155 */       return method.getParameterTypes()[0] == sourceClass ? true : !Modifier.isStatic(method.getModifiers()) ? ClassUtils.isAssignable(method.getDeclaringClass(), sourceClass) : false;
/*     */     }
/* 157 */     if ((member instanceof Constructor)) {
/* 158 */       Constructor<?> ctor = (Constructor)member;
/* 159 */       return ctor.getParameterTypes()[0] == sourceClass;
/*     */     }
/*     */     
/* 162 */     return false;
/*     */   }
/*     */   
/*     */   private static Method determineToMethod(Class<?> targetClass, Class<?> sourceClass)
/*     */   {
/* 167 */     if ((String.class == targetClass) || (String.class == sourceClass))
/*     */     {
/* 169 */       return null;
/*     */     }
/*     */     
/* 172 */     Method method = ClassUtils.getMethodIfAvailable(sourceClass, "to" + targetClass.getSimpleName(), new Class[0]);
/*     */     
/* 174 */     return (method != null) && (!Modifier.isStatic(method.getModifiers())) && (ClassUtils.isAssignable(targetClass, method.getReturnType())) ? method : null;
/*     */   }
/*     */   
/*     */   private static Method determineFactoryMethod(Class<?> targetClass, Class<?> sourceClass) {
/* 178 */     if (String.class == targetClass)
/*     */     {
/* 180 */       return null;
/*     */     }
/*     */     
/* 183 */     Method method = ClassUtils.getStaticMethod(targetClass, "valueOf", new Class[] { sourceClass });
/* 184 */     if (method == null) {
/* 185 */       method = ClassUtils.getStaticMethod(targetClass, "of", new Class[] { sourceClass });
/* 186 */       if (method == null) {
/* 187 */         method = ClassUtils.getStaticMethod(targetClass, "from", new Class[] { sourceClass });
/*     */       }
/*     */     }
/* 190 */     return method;
/*     */   }
/*     */   
/*     */   private static Constructor<?> determineFactoryConstructor(Class<?> targetClass, Class<?> sourceClass) {
/* 194 */     return ClassUtils.getConstructorIfAvailable(targetClass, new Class[] { sourceClass });
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\convert\support\ObjectToObjectConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */