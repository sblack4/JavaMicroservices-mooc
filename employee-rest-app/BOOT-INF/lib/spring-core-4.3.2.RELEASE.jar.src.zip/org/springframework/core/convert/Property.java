/*     */ package org.springframework.core.convert;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Property
/*     */ {
/*  50 */   private static Map<Property, Annotation[]> annotationCache = new ConcurrentReferenceHashMap();
/*     */   
/*     */   private final Class<?> objectType;
/*     */   
/*     */   private final Method readMethod;
/*     */   
/*     */   private final Method writeMethod;
/*     */   
/*     */   private final String name;
/*     */   
/*     */   private final MethodParameter methodParameter;
/*     */   
/*     */   private Annotation[] annotations;
/*     */   
/*     */ 
/*     */   public Property(Class<?> objectType, Method readMethod, Method writeMethod)
/*     */   {
/*  67 */     this(objectType, readMethod, writeMethod, null);
/*     */   }
/*     */   
/*     */   public Property(Class<?> objectType, Method readMethod, Method writeMethod, String name) {
/*  71 */     this.objectType = objectType;
/*  72 */     this.readMethod = readMethod;
/*  73 */     this.writeMethod = writeMethod;
/*  74 */     this.methodParameter = resolveMethodParameter();
/*  75 */     this.name = (name == null ? resolveName() : name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getObjectType()
/*     */   {
/*  83 */     return this.objectType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/*  90 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Class<?> getType()
/*     */   {
/*  97 */     return this.methodParameter.getParameterType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Method getReadMethod()
/*     */   {
/* 104 */     return this.readMethod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Method getWriteMethod()
/*     */   {
/* 111 */     return this.writeMethod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   MethodParameter getMethodParameter()
/*     */   {
/* 118 */     return this.methodParameter;
/*     */   }
/*     */   
/*     */   Annotation[] getAnnotations() {
/* 122 */     if (this.annotations == null) {
/* 123 */       this.annotations = resolveAnnotations();
/*     */     }
/* 125 */     return this.annotations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private String resolveName()
/*     */   {
/* 132 */     if (this.readMethod != null) {
/* 133 */       int index = this.readMethod.getName().indexOf("get");
/* 134 */       if (index != -1) {
/* 135 */         index += 3;
/*     */       }
/*     */       else {
/* 138 */         index = this.readMethod.getName().indexOf("is");
/* 139 */         if (index == -1) {
/* 140 */           throw new IllegalArgumentException("Not a getter method");
/*     */         }
/* 142 */         index += 2;
/*     */       }
/* 144 */       return StringUtils.uncapitalize(this.readMethod.getName().substring(index));
/*     */     }
/*     */     
/* 147 */     int index = this.writeMethod.getName().indexOf("set") + 3;
/* 148 */     if (index == -1) {
/* 149 */       throw new IllegalArgumentException("Not a setter method");
/*     */     }
/* 151 */     return StringUtils.uncapitalize(this.writeMethod.getName().substring(index));
/*     */   }
/*     */   
/*     */   private MethodParameter resolveMethodParameter()
/*     */   {
/* 156 */     MethodParameter read = resolveReadMethodParameter();
/* 157 */     MethodParameter write = resolveWriteMethodParameter();
/* 158 */     if (write == null) {
/* 159 */       if (read == null) {
/* 160 */         throw new IllegalStateException("Property is neither readable nor writeable");
/*     */       }
/* 162 */       return read;
/*     */     }
/* 164 */     if (read != null) {
/* 165 */       Class<?> readType = read.getParameterType();
/* 166 */       Class<?> writeType = write.getParameterType();
/* 167 */       if ((!writeType.equals(readType)) && (writeType.isAssignableFrom(readType))) {
/* 168 */         return read;
/*     */       }
/*     */     }
/* 171 */     return write;
/*     */   }
/*     */   
/*     */   private MethodParameter resolveReadMethodParameter() {
/* 175 */     if (getReadMethod() == null) {
/* 176 */       return null;
/*     */     }
/* 178 */     return resolveParameterType(new MethodParameter(getReadMethod(), -1));
/*     */   }
/*     */   
/*     */   private MethodParameter resolveWriteMethodParameter() {
/* 182 */     if (getWriteMethod() == null) {
/* 183 */       return null;
/*     */     }
/* 185 */     return resolveParameterType(new MethodParameter(getWriteMethod(), 0));
/*     */   }
/*     */   
/*     */   private MethodParameter resolveParameterType(MethodParameter parameter)
/*     */   {
/* 190 */     GenericTypeResolver.resolveParameterType(parameter, getObjectType());
/* 191 */     return parameter;
/*     */   }
/*     */   
/*     */   private Annotation[] resolveAnnotations() {
/* 195 */     Annotation[] annotations = (Annotation[])annotationCache.get(this);
/* 196 */     if (annotations == null) {
/* 197 */       Map<Class<? extends Annotation>, Annotation> annotationMap = new LinkedHashMap();
/* 198 */       addAnnotationsToMap(annotationMap, getReadMethod());
/* 199 */       addAnnotationsToMap(annotationMap, getWriteMethod());
/* 200 */       addAnnotationsToMap(annotationMap, getField());
/* 201 */       annotations = (Annotation[])annotationMap.values().toArray(new Annotation[annotationMap.size()]);
/* 202 */       annotationCache.put(this, annotations);
/*     */     }
/* 204 */     return annotations;
/*     */   }
/*     */   
/*     */ 
/*     */   private void addAnnotationsToMap(Map<Class<? extends Annotation>, Annotation> annotationMap, AnnotatedElement object)
/*     */   {
/* 210 */     if (object != null) {
/* 211 */       for (Annotation annotation : object.getAnnotations()) {
/* 212 */         annotationMap.put(annotation.annotationType(), annotation);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private Field getField() {
/* 218 */     String name = getName();
/* 219 */     if (!StringUtils.hasLength(name)) {
/* 220 */       return null;
/*     */     }
/* 222 */     Class<?> declaringClass = declaringClass();
/* 223 */     Field field = ReflectionUtils.findField(declaringClass, name);
/* 224 */     if (field == null)
/*     */     {
/* 226 */       field = ReflectionUtils.findField(declaringClass, name
/* 227 */         .substring(0, 1).toLowerCase() + name.substring(1));
/* 228 */       if (field == null) {
/* 229 */         field = ReflectionUtils.findField(declaringClass, name
/* 230 */           .substring(0, 1).toUpperCase() + name.substring(1));
/*     */       }
/*     */     }
/* 233 */     return field;
/*     */   }
/*     */   
/*     */   private Class<?> declaringClass() {
/* 237 */     if (getReadMethod() != null) {
/* 238 */       return getReadMethod().getDeclaringClass();
/*     */     }
/*     */     
/* 241 */     return getWriteMethod().getDeclaringClass();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 248 */     if (this == other) {
/* 249 */       return true;
/*     */     }
/* 251 */     if (!(other instanceof Property)) {
/* 252 */       return false;
/*     */     }
/* 254 */     Property otherProperty = (Property)other;
/*     */     
/*     */ 
/*     */ 
/* 258 */     return (ObjectUtils.nullSafeEquals(this.objectType, otherProperty.objectType)) && (ObjectUtils.nullSafeEquals(this.name, otherProperty.name)) && (ObjectUtils.nullSafeEquals(this.readMethod, otherProperty.readMethod)) && (ObjectUtils.nullSafeEquals(this.writeMethod, otherProperty.writeMethod));
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 263 */     return ObjectUtils.nullSafeHashCode(this.objectType) * 31 + ObjectUtils.nullSafeHashCode(this.name);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\convert\Property.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */