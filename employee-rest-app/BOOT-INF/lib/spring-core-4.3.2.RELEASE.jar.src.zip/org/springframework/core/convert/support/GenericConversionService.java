/*     */ package org.springframework.core.convert.support;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.convert.ConversionFailedException;
/*     */ import org.springframework.core.convert.ConverterNotFoundException;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.ConditionalConverter;
/*     */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.core.convert.converter.ConverterFactory;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericConversionService
/*     */   implements ConfigurableConversionService
/*     */ {
/*  66 */   private static final GenericConverter NO_OP_CONVERTER = new NoOpConverter("NO_OP");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */   private static final GenericConverter NO_MATCH = new NoOpConverter("NO_MATCH");
/*     */   
/*     */ 
/*     */ 
/*  76 */   private static Object javaUtilOptionalEmpty = null;
/*     */   
/*     */   static {
/*     */     try {
/*  80 */       Class<?> clazz = ClassUtils.forName("java.util.Optional", GenericConversionService.class.getClassLoader());
/*  81 */       javaUtilOptionalEmpty = ClassUtils.getMethod(clazz, "empty", new Class[0]).invoke(null, new Object[0]);
/*     */     }
/*     */     catch (Exception localException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  89 */   private final Converters converters = new Converters(null);
/*     */   
/*  91 */   private final Map<ConverterCacheKey, GenericConverter> converterCache = new ConcurrentReferenceHashMap(64);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addConverter(Converter<?, ?> converter)
/*     */   {
/*  99 */     ResolvableType[] typeInfo = getRequiredTypeInfo(converter, Converter.class);
/* 100 */     Assert.notNull(typeInfo, "Unable to the determine sourceType <S> and targetType <T> which your Converter<S, T> converts between; declare these generic types.");
/*     */     
/* 102 */     addConverter(new ConverterAdapter(converter, typeInfo[0], typeInfo[1]));
/*     */   }
/*     */   
/*     */   public <S, T> void addConverter(Class<S> sourceType, Class<T> targetType, Converter<? super S, ? extends T> converter)
/*     */   {
/* 107 */     addConverter(new ConverterAdapter(converter, 
/* 108 */       ResolvableType.forClass(sourceType), ResolvableType.forClass(targetType)));
/*     */   }
/*     */   
/*     */   public void addConverter(GenericConverter converter)
/*     */   {
/* 113 */     this.converters.add(converter);
/* 114 */     invalidateCache();
/*     */   }
/*     */   
/*     */   public void addConverterFactory(ConverterFactory<?, ?> converterFactory)
/*     */   {
/* 119 */     ResolvableType[] typeInfo = getRequiredTypeInfo(converterFactory, ConverterFactory.class);
/* 120 */     Assert.notNull(typeInfo, "Unable to the determine source type <S> and target range type R which your ConverterFactory<S, R> converts between; declare these generic types.");
/*     */     
/* 122 */     addConverter(new ConverterFactoryAdapter(converterFactory, new GenericConverter.ConvertiblePair(typeInfo[0]
/* 123 */       .resolve(), typeInfo[1].resolve())));
/*     */   }
/*     */   
/*     */   public void removeConvertible(Class<?> sourceType, Class<?> targetType)
/*     */   {
/* 128 */     this.converters.remove(sourceType, targetType);
/* 129 */     invalidateCache();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean canConvert(Class<?> sourceType, Class<?> targetType)
/*     */   {
/* 137 */     Assert.notNull(targetType, "targetType to convert to cannot be null");
/* 138 */     return canConvert(sourceType != null ? TypeDescriptor.valueOf(sourceType) : null, 
/* 139 */       TypeDescriptor.valueOf(targetType));
/*     */   }
/*     */   
/*     */   public boolean canConvert(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/* 144 */     Assert.notNull(targetType, "targetType to convert to cannot be null");
/* 145 */     if (sourceType == null) {
/* 146 */       return true;
/*     */     }
/* 148 */     GenericConverter converter = getConverter(sourceType, targetType);
/* 149 */     return converter != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean canBypassConvert(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/* 164 */     Assert.notNull(targetType, "targetType to convert to cannot be null");
/* 165 */     if (sourceType == null) {
/* 166 */       return true;
/*     */     }
/* 168 */     GenericConverter converter = getConverter(sourceType, targetType);
/* 169 */     return converter == NO_OP_CONVERTER;
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> T convert(Object source, Class<T> targetType)
/*     */   {
/* 175 */     Assert.notNull(targetType, "targetType to convert to cannot be null");
/* 176 */     return (T)convert(source, TypeDescriptor.forObject(source), TypeDescriptor.valueOf(targetType));
/*     */   }
/*     */   
/*     */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/* 181 */     Assert.notNull(targetType, "targetType to convert to cannot be null");
/* 182 */     if (sourceType == null) {
/* 183 */       Assert.isTrue(source == null, "source must be [null] if sourceType == [null]");
/* 184 */       return handleResult(null, targetType, convertNullSource(null, targetType));
/*     */     }
/* 186 */     if ((source != null) && (!sourceType.getObjectType().isInstance(source)))
/*     */     {
/* 188 */       throw new IllegalArgumentException("source to convert from must be an instance of " + sourceType + "; instead it was a " + source.getClass().getName());
/*     */     }
/* 190 */     GenericConverter converter = getConverter(sourceType, targetType);
/* 191 */     if (converter != null) {
/* 192 */       Object result = ConversionUtils.invokeConverter(converter, source, sourceType, targetType);
/* 193 */       return handleResult(sourceType, targetType, result);
/*     */     }
/* 195 */     return handleConverterNotFound(source, sourceType, targetType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object convert(Object source, TypeDescriptor targetType)
/*     */   {
/* 212 */     return convert(source, TypeDescriptor.forObject(source), targetType);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 217 */     return this.converters.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object convertNullSource(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/* 234 */     if ((javaUtilOptionalEmpty != null) && (targetType.getObjectType() == javaUtilOptionalEmpty.getClass())) {
/* 235 */       return javaUtilOptionalEmpty;
/*     */     }
/* 237 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected GenericConverter getConverter(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/* 252 */     ConverterCacheKey key = new ConverterCacheKey(sourceType, targetType);
/* 253 */     GenericConverter converter = (GenericConverter)this.converterCache.get(key);
/* 254 */     if (converter != null) {
/* 255 */       return converter != NO_MATCH ? converter : null;
/*     */     }
/*     */     
/* 258 */     converter = this.converters.find(sourceType, targetType);
/* 259 */     if (converter == null) {
/* 260 */       converter = getDefaultConverter(sourceType, targetType);
/*     */     }
/*     */     
/* 263 */     if (converter != null) {
/* 264 */       this.converterCache.put(key, converter);
/* 265 */       return converter;
/*     */     }
/*     */     
/* 268 */     this.converterCache.put(key, NO_MATCH);
/* 269 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected GenericConverter getDefaultConverter(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/* 281 */     return sourceType.isAssignableTo(targetType) ? NO_OP_CONVERTER : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private ResolvableType[] getRequiredTypeInfo(Object converter, Class<?> genericIfc)
/*     */   {
/* 288 */     ResolvableType resolvableType = ResolvableType.forClass(converter.getClass()).as(genericIfc);
/* 289 */     ResolvableType[] generics = resolvableType.getGenerics();
/* 290 */     if (generics.length < 2) {
/* 291 */       return null;
/*     */     }
/* 293 */     Class<?> sourceType = generics[0].resolve();
/* 294 */     Class<?> targetType = generics[1].resolve();
/* 295 */     if ((sourceType == null) || (targetType == null)) {
/* 296 */       return null;
/*     */     }
/* 298 */     return generics;
/*     */   }
/*     */   
/*     */   private void invalidateCache() {
/* 302 */     this.converterCache.clear();
/*     */   }
/*     */   
/*     */   private Object handleConverterNotFound(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 306 */     if (source == null) {
/* 307 */       assertNotPrimitiveTargetType(sourceType, targetType);
/* 308 */       return null;
/*     */     }
/* 310 */     if ((sourceType.isAssignableTo(targetType)) && (targetType.getObjectType().isInstance(source))) {
/* 311 */       return source;
/*     */     }
/* 313 */     throw new ConverterNotFoundException(sourceType, targetType);
/*     */   }
/*     */   
/*     */   private Object handleResult(TypeDescriptor sourceType, TypeDescriptor targetType, Object result) {
/* 317 */     if (result == null) {
/* 318 */       assertNotPrimitiveTargetType(sourceType, targetType);
/*     */     }
/* 320 */     return result;
/*     */   }
/*     */   
/*     */   private void assertNotPrimitiveTargetType(TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 324 */     if (targetType.isPrimitive()) {
/* 325 */       throw new ConversionFailedException(sourceType, targetType, null, new IllegalArgumentException("A null value cannot be assigned to a primitive type"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private final class ConverterAdapter
/*     */     implements ConditionalGenericConverter
/*     */   {
/*     */     private final Converter<Object, Object> converter;
/*     */     
/*     */ 
/*     */     private final GenericConverter.ConvertiblePair typeInfo;
/*     */     
/*     */     private final ResolvableType targetType;
/*     */     
/*     */ 
/*     */     public ConverterAdapter(ResolvableType converter, ResolvableType sourceType)
/*     */     {
/* 344 */       this.converter = converter;
/* 345 */       this.typeInfo = new GenericConverter.ConvertiblePair(sourceType.resolve(Object.class), targetType.resolve(Object.class));
/* 346 */       this.targetType = targetType;
/*     */     }
/*     */     
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*     */     {
/* 351 */       return Collections.singleton(this.typeInfo);
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 357 */       if (this.typeInfo.getTargetType() != targetType.getObjectType()) {
/* 358 */         return false;
/*     */       }
/*     */       
/* 361 */       ResolvableType rt = targetType.getResolvableType();
/* 362 */       if ((!(rt.getType() instanceof Class)) && (!rt.isAssignableFrom(this.targetType)) && 
/* 363 */         (!this.targetType.hasUnresolvableGenerics())) {
/* 364 */         return false;
/*     */       }
/*     */       
/* 367 */       return (!(this.converter instanceof ConditionalConverter)) || (((ConditionalConverter)this.converter).matches(sourceType, targetType));
/*     */     }
/*     */     
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 372 */       if (source == null) {
/* 373 */         return GenericConversionService.this.convertNullSource(sourceType, targetType);
/*     */       }
/* 375 */       return this.converter.convert(source);
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 380 */       return this.typeInfo + " : " + this.converter;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private final class ConverterFactoryAdapter
/*     */     implements ConditionalGenericConverter
/*     */   {
/*     */     private final ConverterFactory<Object, Object> converterFactory;
/*     */     
/*     */     private final GenericConverter.ConvertiblePair typeInfo;
/*     */     
/*     */ 
/*     */     public ConverterFactoryAdapter(GenericConverter.ConvertiblePair converterFactory)
/*     */     {
/* 396 */       this.converterFactory = converterFactory;
/* 397 */       this.typeInfo = typeInfo;
/*     */     }
/*     */     
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*     */     {
/* 402 */       return Collections.singleton(this.typeInfo);
/*     */     }
/*     */     
/*     */     public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 407 */       boolean matches = true;
/* 408 */       if ((this.converterFactory instanceof ConditionalConverter)) {
/* 409 */         matches = ((ConditionalConverter)this.converterFactory).matches(sourceType, targetType);
/*     */       }
/* 411 */       if (matches) {
/* 412 */         Converter<?, ?> converter = this.converterFactory.getConverter(targetType.getType());
/* 413 */         if ((converter instanceof ConditionalConverter)) {
/* 414 */           matches = ((ConditionalConverter)converter).matches(sourceType, targetType);
/*     */         }
/*     */       }
/* 417 */       return matches;
/*     */     }
/*     */     
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 422 */       if (source == null) {
/* 423 */         return GenericConversionService.this.convertNullSource(sourceType, targetType);
/*     */       }
/* 425 */       return this.converterFactory.getConverter(targetType.getObjectType()).convert(source);
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 430 */       return this.typeInfo + " : " + this.converterFactory;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static final class ConverterCacheKey
/*     */     implements Comparable<ConverterCacheKey>
/*     */   {
/*     */     private final TypeDescriptor sourceType;
/*     */     
/*     */     private final TypeDescriptor targetType;
/*     */     
/*     */ 
/*     */     public ConverterCacheKey(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 445 */       this.sourceType = sourceType;
/* 446 */       this.targetType = targetType;
/*     */     }
/*     */     
/*     */     public boolean equals(Object other)
/*     */     {
/* 451 */       if (this == other) {
/* 452 */         return true;
/*     */       }
/* 454 */       if (!(other instanceof ConverterCacheKey)) {
/* 455 */         return false;
/*     */       }
/* 457 */       ConverterCacheKey otherKey = (ConverterCacheKey)other;
/*     */       
/* 459 */       return (ObjectUtils.nullSafeEquals(this.sourceType, otherKey.sourceType)) && (ObjectUtils.nullSafeEquals(this.targetType, otherKey.targetType));
/*     */     }
/*     */     
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 465 */       return ObjectUtils.nullSafeHashCode(this.sourceType) * 29 + ObjectUtils.nullSafeHashCode(this.targetType);
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 470 */       return "ConverterCacheKey [sourceType = " + this.sourceType + ", targetType = " + this.targetType + "]";
/*     */     }
/*     */     
/*     */ 
/*     */     public int compareTo(ConverterCacheKey other)
/*     */     {
/* 476 */       int result = this.sourceType.getResolvableType().toString().compareTo(other.sourceType
/* 477 */         .getResolvableType().toString());
/* 478 */       if (result == 0) {
/* 479 */         result = this.targetType.getResolvableType().toString().compareTo(other.targetType
/* 480 */           .getResolvableType().toString());
/*     */       }
/* 482 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class Converters
/*     */   {
/* 492 */     private final Set<GenericConverter> globalConverters = new LinkedHashSet();
/*     */     
/* 494 */     private final Map<GenericConverter.ConvertiblePair, GenericConversionService.ConvertersForPair> converters = new LinkedHashMap(36);
/*     */     
/*     */     public void add(GenericConverter converter)
/*     */     {
/* 498 */       Set<GenericConverter.ConvertiblePair> convertibleTypes = converter.getConvertibleTypes();
/* 499 */       if (convertibleTypes == null) {
/* 500 */         Assert.state(converter instanceof ConditionalConverter, "Only conditional converters may return null convertible types");
/*     */         
/* 502 */         this.globalConverters.add(converter);
/*     */       }
/*     */       else {
/* 505 */         for (GenericConverter.ConvertiblePair convertiblePair : convertibleTypes) {
/* 506 */           GenericConversionService.ConvertersForPair convertersForPair = getMatchableConverters(convertiblePair);
/* 507 */           convertersForPair.add(converter);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private GenericConversionService.ConvertersForPair getMatchableConverters(GenericConverter.ConvertiblePair convertiblePair) {
/* 513 */       GenericConversionService.ConvertersForPair convertersForPair = (GenericConversionService.ConvertersForPair)this.converters.get(convertiblePair);
/* 514 */       if (convertersForPair == null) {
/* 515 */         convertersForPair = new GenericConversionService.ConvertersForPair(null);
/* 516 */         this.converters.put(convertiblePair, convertersForPair);
/*     */       }
/* 518 */       return convertersForPair;
/*     */     }
/*     */     
/*     */     public void remove(Class<?> sourceType, Class<?> targetType) {
/* 522 */       this.converters.remove(new GenericConverter.ConvertiblePair(sourceType, targetType));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public GenericConverter find(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 535 */       List<Class<?>> sourceCandidates = getClassHierarchy(sourceType.getType());
/* 536 */       List<Class<?>> targetCandidates = getClassHierarchy(targetType.getType());
/* 537 */       for (Iterator localIterator1 = sourceCandidates.iterator(); localIterator1.hasNext();) { sourceCandidate = (Class)localIterator1.next();
/* 538 */         for (Class<?> targetCandidate : targetCandidates) {
/* 539 */           GenericConverter.ConvertiblePair convertiblePair = new GenericConverter.ConvertiblePair(sourceCandidate, targetCandidate);
/* 540 */           GenericConverter converter = getRegisteredConverter(sourceType, targetType, convertiblePair);
/* 541 */           if (converter != null)
/* 542 */             return converter;
/*     */         }
/*     */       }
/*     */       Class<?> sourceCandidate;
/* 546 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private GenericConverter getRegisteredConverter(TypeDescriptor sourceType, TypeDescriptor targetType, GenericConverter.ConvertiblePair convertiblePair)
/*     */     {
/* 553 */       GenericConversionService.ConvertersForPair convertersForPair = (GenericConversionService.ConvertersForPair)this.converters.get(convertiblePair);
/* 554 */       GenericConverter converter; if (convertersForPair != null) {
/* 555 */         converter = convertersForPair.getConverter(sourceType, targetType);
/* 556 */         if (converter != null) {
/* 557 */           return converter;
/*     */         }
/*     */       }
/*     */       
/* 561 */       for (GenericConverter globalConverter : this.globalConverters) {
/* 562 */         if (((ConditionalConverter)globalConverter).matches(sourceType, targetType)) {
/* 563 */           return globalConverter;
/*     */         }
/*     */       }
/* 566 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private List<Class<?>> getClassHierarchy(Class<?> type)
/*     */     {
/* 575 */       List<Class<?>> hierarchy = new ArrayList(20);
/* 576 */       Set<Class<?>> visited = new HashSet(20);
/* 577 */       addToClassHierarchy(0, ClassUtils.resolvePrimitiveIfNecessary(type), false, hierarchy, visited);
/* 578 */       boolean array = type.isArray();
/*     */       
/* 580 */       int i = 0;
/* 581 */       while (i < hierarchy.size()) {
/* 582 */         Class<?> candidate = (Class)hierarchy.get(i);
/* 583 */         candidate = array ? candidate.getComponentType() : ClassUtils.resolvePrimitiveIfNecessary(candidate);
/* 584 */         Class<?> superclass = candidate.getSuperclass();
/* 585 */         if ((superclass != null) && (superclass != Object.class) && (superclass != Enum.class)) {
/* 586 */           addToClassHierarchy(i + 1, candidate.getSuperclass(), array, hierarchy, visited);
/*     */         }
/* 588 */         addInterfacesToClassHierarchy(candidate, array, hierarchy, visited);
/* 589 */         i++;
/*     */       }
/*     */       
/* 592 */       if (Enum.class.isAssignableFrom(type)) {
/* 593 */         addToClassHierarchy(hierarchy.size(), Enum.class, array, hierarchy, visited);
/* 594 */         addToClassHierarchy(hierarchy.size(), Enum.class, false, hierarchy, visited);
/* 595 */         addInterfacesToClassHierarchy(Enum.class, array, hierarchy, visited);
/*     */       }
/*     */       
/* 598 */       addToClassHierarchy(hierarchy.size(), Object.class, array, hierarchy, visited);
/* 599 */       addToClassHierarchy(hierarchy.size(), Object.class, false, hierarchy, visited);
/* 600 */       return hierarchy;
/*     */     }
/*     */     
/*     */ 
/*     */     private void addInterfacesToClassHierarchy(Class<?> type, boolean asArray, List<Class<?>> hierarchy, Set<Class<?>> visited)
/*     */     {
/* 606 */       for (Class<?> implementedInterface : type.getInterfaces()) {
/* 607 */         addToClassHierarchy(hierarchy.size(), implementedInterface, asArray, hierarchy, visited);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     private void addToClassHierarchy(int index, Class<?> type, boolean asArray, List<Class<?>> hierarchy, Set<Class<?>> visited)
/*     */     {
/* 614 */       if (asArray) {
/* 615 */         type = Array.newInstance(type, 0).getClass();
/*     */       }
/* 617 */       if (visited.add(type)) {
/* 618 */         hierarchy.add(index, type);
/*     */       }
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 624 */       StringBuilder builder = new StringBuilder();
/* 625 */       builder.append("ConversionService converters =\n");
/* 626 */       for (String converterString : getConverterStrings()) {
/* 627 */         builder.append('\t').append(converterString).append('\n');
/*     */       }
/* 629 */       return builder.toString();
/*     */     }
/*     */     
/*     */     private List<String> getConverterStrings() {
/* 633 */       List<String> converterStrings = new ArrayList();
/* 634 */       for (GenericConversionService.ConvertersForPair convertersForPair : this.converters.values()) {
/* 635 */         converterStrings.add(convertersForPair.toString());
/*     */       }
/* 637 */       Collections.sort(converterStrings);
/* 638 */       return converterStrings;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class ConvertersForPair
/*     */   {
/* 648 */     private final LinkedList<GenericConverter> converters = new LinkedList();
/*     */     
/*     */     public void add(GenericConverter converter) {
/* 651 */       this.converters.addFirst(converter);
/*     */     }
/*     */     
/*     */     public GenericConverter getConverter(TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 655 */       for (GenericConverter converter : this.converters) {
/* 656 */         if ((!(converter instanceof ConditionalGenericConverter)) || 
/* 657 */           (((ConditionalGenericConverter)converter).matches(sourceType, targetType))) {
/* 658 */           return converter;
/*     */         }
/*     */       }
/* 661 */       return null;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 666 */       return StringUtils.collectionToCommaDelimitedString(this.converters);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class NoOpConverter
/*     */     implements GenericConverter
/*     */   {
/*     */     private final String name;
/*     */     
/*     */ 
/*     */     public NoOpConverter(String name)
/*     */     {
/* 679 */       this.name = name;
/*     */     }
/*     */     
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*     */     {
/* 684 */       return null;
/*     */     }
/*     */     
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 689 */       return source;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 694 */       return this.name;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\convert\support\GenericConversionService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */