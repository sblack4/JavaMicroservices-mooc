/*     */ package org.springframework.core.convert;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.lang.UsesJava8;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeDescriptor
/*     */   implements Serializable
/*     */ {
/*  50 */   static final Annotation[] EMPTY_ANNOTATION_ARRAY = new Annotation[0];
/*     */   
/*  52 */   private static final boolean streamAvailable = ClassUtils.isPresent("java.util.stream.Stream", TypeDescriptor.class
/*  53 */     .getClassLoader());
/*     */   
/*  55 */   private static final Map<Class<?>, TypeDescriptor> commonTypesCache = new HashMap(18);
/*     */   
/*  57 */   private static final Class<?>[] CACHED_COMMON_TYPES = { Boolean.TYPE, Boolean.class, Byte.TYPE, Byte.class, Character.TYPE, Character.class, Double.TYPE, Double.class, Integer.TYPE, Integer.class, Long.TYPE, Long.class, Float.TYPE, Float.class, Short.TYPE, Short.class, String.class, Object.class };
/*     */   private final Class<?> type;
/*     */   private final ResolvableType resolvableType;
/*     */   private final Annotation[] annotations;
/*     */   
/*     */   static {
/*  63 */     for (Class<?> preCachedClass : CACHED_COMMON_TYPES) {
/*  64 */       commonTypesCache.put(preCachedClass, valueOf(preCachedClass));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TypeDescriptor(MethodParameter methodParameter)
/*     */   {
/*  83 */     Assert.notNull(methodParameter, "MethodParameter must not be null");
/*  84 */     this.resolvableType = ResolvableType.forMethodParameter(methodParameter);
/*  85 */     this.type = this.resolvableType.resolve(methodParameter.getParameterType());
/*     */     
/*     */ 
/*  88 */     this.annotations = (methodParameter.getParameterIndex() == -1 ? nullSafeAnnotations(methodParameter.getMethodAnnotations()) : nullSafeAnnotations(methodParameter.getParameterAnnotations()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TypeDescriptor(Field field)
/*     */   {
/*  97 */     Assert.notNull(field, "Field must not be null");
/*  98 */     this.resolvableType = ResolvableType.forField(field);
/*  99 */     this.type = this.resolvableType.resolve(field.getType());
/* 100 */     this.annotations = nullSafeAnnotations(field.getAnnotations());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TypeDescriptor(Property property)
/*     */   {
/* 110 */     Assert.notNull(property, "Property must not be null");
/* 111 */     this.resolvableType = ResolvableType.forMethodParameter(property.getMethodParameter());
/* 112 */     this.type = this.resolvableType.resolve(property.getType());
/* 113 */     this.annotations = nullSafeAnnotations(property.getAnnotations());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TypeDescriptor(ResolvableType resolvableType, Class<?> type, Annotation[] annotations)
/*     */   {
/* 125 */     this.resolvableType = resolvableType;
/* 126 */     this.type = (type != null ? type : resolvableType.resolve(Object.class));
/* 127 */     this.annotations = nullSafeAnnotations(annotations);
/*     */   }
/*     */   
/*     */   private Annotation[] nullSafeAnnotations(Annotation[] annotations)
/*     */   {
/* 132 */     return annotations != null ? annotations : EMPTY_ANNOTATION_ARRAY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getObjectType()
/*     */   {
/* 142 */     return ClassUtils.resolvePrimitiveIfNecessary(getType());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getType()
/*     */   {
/* 154 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResolvableType getResolvableType()
/*     */   {
/* 162 */     return this.resolvableType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getSource()
/*     */   {
/* 173 */     return this.resolvableType != null ? this.resolvableType.getSource() : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TypeDescriptor narrow(Object value)
/*     */   {
/* 193 */     if (value == null) {
/* 194 */       return this;
/*     */     }
/* 196 */     ResolvableType narrowed = ResolvableType.forType(value.getClass(), this.resolvableType);
/* 197 */     return new TypeDescriptor(narrowed, null, this.annotations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TypeDescriptor upcast(Class<?> superType)
/*     */   {
/* 209 */     if (superType == null) {
/* 210 */       return null;
/*     */     }
/* 212 */     Assert.isAssignable(superType, getType());
/* 213 */     return new TypeDescriptor(this.resolvableType.as(superType), superType, this.annotations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 220 */     return ClassUtils.getQualifiedName(getType());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isPrimitive()
/*     */   {
/* 227 */     return getType().isPrimitive();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Annotation[] getAnnotations()
/*     */   {
/* 235 */     return this.annotations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasAnnotation(Class<? extends Annotation> annotationType)
/*     */   {
/* 246 */     return getAnnotation(annotationType) != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends Annotation> T getAnnotation(Class<T> annotationType)
/*     */   {
/* 259 */     for (Annotation annotation : getAnnotations()) {
/* 260 */       if (annotation.annotationType() == annotationType) {
/* 261 */         return annotation;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 266 */     for (Annotation composedAnnotation : getAnnotations()) {
/* 267 */       T ann = AnnotationUtils.findAnnotation(composedAnnotation.annotationType(), annotationType);
/* 268 */       if (ann != null) {
/* 269 */         return ann;
/*     */       }
/*     */     }
/* 272 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAssignableTo(TypeDescriptor typeDescriptor)
/*     */   {
/* 290 */     boolean typesAssignable = typeDescriptor.getObjectType().isAssignableFrom(getObjectType());
/* 291 */     if (!typesAssignable) {
/* 292 */       return false;
/*     */     }
/* 294 */     if ((isArray()) && (typeDescriptor.isArray())) {
/* 295 */       return getElementTypeDescriptor().isAssignableTo(typeDescriptor.getElementTypeDescriptor());
/*     */     }
/* 297 */     if ((isCollection()) && (typeDescriptor.isCollection())) {
/* 298 */       return isNestedAssignable(getElementTypeDescriptor(), typeDescriptor.getElementTypeDescriptor());
/*     */     }
/* 300 */     if ((isMap()) && (typeDescriptor.isMap()))
/*     */     {
/* 302 */       return (isNestedAssignable(getMapKeyTypeDescriptor(), typeDescriptor.getMapKeyTypeDescriptor())) && (isNestedAssignable(getMapValueTypeDescriptor(), typeDescriptor.getMapValueTypeDescriptor()));
/*     */     }
/*     */     
/* 305 */     return true;
/*     */   }
/*     */   
/*     */   private boolean isNestedAssignable(TypeDescriptor nestedTypeDescriptor, TypeDescriptor otherNestedTypeDescriptor)
/*     */   {
/* 310 */     if ((nestedTypeDescriptor == null) || (otherNestedTypeDescriptor == null)) {
/* 311 */       return true;
/*     */     }
/* 313 */     return nestedTypeDescriptor.isAssignableTo(otherNestedTypeDescriptor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isCollection()
/*     */   {
/* 320 */     return Collection.class.isAssignableFrom(getType());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isArray()
/*     */   {
/* 327 */     return getType().isArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TypeDescriptor getElementTypeDescriptor()
/*     */   {
/* 340 */     if (this.resolvableType.isArray()) {
/* 341 */       return new TypeDescriptor(this.resolvableType.getComponentType(), null, this.annotations);
/*     */     }
/* 343 */     if ((streamAvailable) && (StreamDelegate.isStream(this.type))) {
/* 344 */       return StreamDelegate.getStreamElementType(this);
/*     */     }
/* 346 */     return getRelatedIfResolvable(this, this.resolvableType.asCollection().getGeneric(new int[] { 0 }));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TypeDescriptor elementTypeDescriptor(Object element)
/*     */   {
/* 368 */     return narrow(element, getElementTypeDescriptor());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isMap()
/*     */   {
/* 375 */     return Map.class.isAssignableFrom(getType());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TypeDescriptor getMapKeyTypeDescriptor()
/*     */   {
/* 387 */     Assert.state(isMap(), "Not a java.util.Map");
/* 388 */     return getRelatedIfResolvable(this, this.resolvableType.asMap().getGeneric(new int[] { 0 }));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TypeDescriptor getMapKeyTypeDescriptor(Object mapKey)
/*     */   {
/* 409 */     return narrow(mapKey, getMapKeyTypeDescriptor());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TypeDescriptor getMapValueTypeDescriptor()
/*     */   {
/* 422 */     Assert.state(isMap(), "Not a java.util.Map");
/* 423 */     return getRelatedIfResolvable(this, this.resolvableType.asMap().getGeneric(new int[] { 1 }));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TypeDescriptor getMapValueTypeDescriptor(Object mapValue)
/*     */   {
/* 444 */     return narrow(mapValue, getMapValueTypeDescriptor());
/*     */   }
/*     */   
/*     */   private TypeDescriptor narrow(Object value, TypeDescriptor typeDescriptor) {
/* 448 */     if (typeDescriptor != null) {
/* 449 */       return typeDescriptor.narrow(value);
/*     */     }
/* 451 */     return value != null ? new TypeDescriptor(this.resolvableType, value.getClass(), this.annotations) : null;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 456 */     if (this == obj) {
/* 457 */       return true;
/*     */     }
/* 459 */     if (!(obj instanceof TypeDescriptor)) {
/* 460 */       return false;
/*     */     }
/* 462 */     TypeDescriptor other = (TypeDescriptor)obj;
/* 463 */     if (!ObjectUtils.nullSafeEquals(this.type, other.type)) {
/* 464 */       return false;
/*     */     }
/* 466 */     if (getAnnotations().length != other.getAnnotations().length) {
/* 467 */       return false;
/*     */     }
/* 469 */     for (Annotation ann : getAnnotations()) {
/* 470 */       if (!ann.equals(other.getAnnotation(ann.annotationType()))) {
/* 471 */         return false;
/*     */       }
/*     */     }
/* 474 */     if ((isCollection()) || (isArray())) {
/* 475 */       return ObjectUtils.nullSafeEquals(getElementTypeDescriptor(), other.getElementTypeDescriptor());
/*     */     }
/* 477 */     if (isMap())
/*     */     {
/* 479 */       return (ObjectUtils.nullSafeEquals(getMapKeyTypeDescriptor(), other.getMapKeyTypeDescriptor())) && (ObjectUtils.nullSafeEquals(getMapValueTypeDescriptor(), other.getMapValueTypeDescriptor()));
/*     */     }
/*     */     
/* 482 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 488 */     return getType().hashCode();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 493 */     StringBuilder builder = new StringBuilder();
/* 494 */     for (Annotation ann : getAnnotations()) {
/* 495 */       builder.append("@").append(ann.annotationType().getName()).append(' ');
/*     */     }
/* 497 */     builder.append(this.resolvableType.toString());
/* 498 */     return builder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TypeDescriptor valueOf(Class<?> type)
/*     */   {
/* 512 */     if (type == null) {
/* 513 */       type = Object.class;
/*     */     }
/* 515 */     TypeDescriptor desc = (TypeDescriptor)commonTypesCache.get(type);
/* 516 */     return desc != null ? desc : new TypeDescriptor(ResolvableType.forClass(type), null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TypeDescriptor collection(Class<?> collectionType, TypeDescriptor elementTypeDescriptor)
/*     */   {
/* 532 */     Assert.notNull(collectionType, "collectionType must not be null");
/* 533 */     if (!Collection.class.isAssignableFrom(collectionType)) {
/* 534 */       throw new IllegalArgumentException("collectionType must be a java.util.Collection");
/*     */     }
/* 536 */     ResolvableType element = elementTypeDescriptor != null ? elementTypeDescriptor.resolvableType : null;
/* 537 */     return new TypeDescriptor(ResolvableType.forClassWithGenerics(collectionType, new ResolvableType[] { element }), null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TypeDescriptor map(Class<?> mapType, TypeDescriptor keyTypeDescriptor, TypeDescriptor valueTypeDescriptor)
/*     */   {
/* 555 */     if (!Map.class.isAssignableFrom(mapType)) {
/* 556 */       throw new IllegalArgumentException("mapType must be a java.util.Map");
/*     */     }
/* 558 */     ResolvableType key = keyTypeDescriptor != null ? keyTypeDescriptor.resolvableType : null;
/* 559 */     ResolvableType value = valueTypeDescriptor != null ? valueTypeDescriptor.resolvableType : null;
/* 560 */     return new TypeDescriptor(ResolvableType.forClassWithGenerics(mapType, new ResolvableType[] { key, value }), null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TypeDescriptor array(TypeDescriptor elementTypeDescriptor)
/*     */   {
/* 574 */     if (elementTypeDescriptor == null) {
/* 575 */       return null;
/*     */     }
/*     */     
/* 578 */     return new TypeDescriptor(ResolvableType.forArrayComponent(elementTypeDescriptor.resolvableType), null, elementTypeDescriptor.getAnnotations());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TypeDescriptor nested(MethodParameter methodParameter, int nestingLevel)
/*     */   {
/* 604 */     if (methodParameter.getNestingLevel() != 1) {
/* 605 */       throw new IllegalArgumentException("MethodParameter nesting level must be 1: use the nestingLevel parameter to specify the desired nestingLevel for nested type traversal");
/*     */     }
/*     */     
/* 608 */     return nested(new TypeDescriptor(methodParameter), nestingLevel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TypeDescriptor nested(Field field, int nestingLevel)
/*     */   {
/* 632 */     return nested(new TypeDescriptor(field), nestingLevel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TypeDescriptor nested(Property property, int nestingLevel)
/*     */   {
/* 657 */     return nested(new TypeDescriptor(property), nestingLevel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TypeDescriptor forObject(Object source)
/*     */   {
/* 670 */     return source != null ? valueOf(source.getClass()) : null;
/*     */   }
/*     */   
/*     */   private static TypeDescriptor nested(TypeDescriptor typeDescriptor, int nestingLevel) {
/* 674 */     ResolvableType nested = typeDescriptor.resolvableType;
/* 675 */     for (int i = 0; i < nestingLevel; i++) {
/* 676 */       if (Object.class != nested.getType())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 681 */         nested = nested.getNested(2);
/*     */       }
/*     */     }
/* 684 */     if (nested == ResolvableType.NONE) {
/* 685 */       return null;
/*     */     }
/* 687 */     return getRelatedIfResolvable(typeDescriptor, nested);
/*     */   }
/*     */   
/*     */   private static TypeDescriptor getRelatedIfResolvable(TypeDescriptor source, ResolvableType type) {
/* 691 */     if (type.resolve() == null) {
/* 692 */       return null;
/*     */     }
/* 694 */     return new TypeDescriptor(type, null, source.annotations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @UsesJava8
/*     */   private static class StreamDelegate
/*     */   {
/*     */     public static boolean isStream(Class<?> type)
/*     */     {
/* 705 */       return Stream.class.isAssignableFrom(type);
/*     */     }
/*     */     
/*     */     public static TypeDescriptor getStreamElementType(TypeDescriptor source) {
/* 709 */       return TypeDescriptor.getRelatedIfResolvable(source, source.resolvableType.as(Stream.class).getGeneric(new int[] { 0 }));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\convert\TypeDescriptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */