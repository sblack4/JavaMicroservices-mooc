/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Optional;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.ResolvableType;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*    */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*    */ import org.springframework.lang.UsesJava8;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @UsesJava8
/*    */ final class ObjectToOptionalConverter
/*    */   implements ConditionalGenericConverter
/*    */ {
/*    */   private final ConversionService conversionService;
/*    */   
/*    */   public ObjectToOptionalConverter(ConversionService conversionService)
/*    */   {
/* 44 */     this.conversionService = conversionService;
/*    */   }
/*    */   
/*    */ 
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*    */   {
/* 50 */     return Collections.singleton(new GenericConverter.ConvertiblePair(Object.class, Optional.class));
/*    */   }
/*    */   
/*    */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 55 */     if (targetType.getResolvableType() != null) {
/* 56 */       return this.conversionService.canConvert(sourceType, new GenericTypeDescriptor(targetType));
/*    */     }
/*    */     
/* 59 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 65 */     if (source == null) {
/* 66 */       return Optional.empty();
/*    */     }
/* 68 */     if ((source instanceof Optional)) {
/* 69 */       return source;
/*    */     }
/* 71 */     if (targetType.getResolvableType() == null) {
/* 72 */       return Optional.of(source);
/*    */     }
/*    */     
/* 75 */     Object target = this.conversionService.convert(source, sourceType, new GenericTypeDescriptor(targetType));
/* 76 */     return Optional.ofNullable(target);
/*    */   }
/*    */   
/*    */ 
/*    */   private static class GenericTypeDescriptor
/*    */     extends TypeDescriptor
/*    */   {
/*    */     public GenericTypeDescriptor(TypeDescriptor typeDescriptor)
/*    */     {
/* 85 */       super(null, typeDescriptor.getAnnotations());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\convert\support\ObjectToOptionalConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */