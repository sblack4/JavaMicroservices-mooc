/*     */ package org.springframework.core.convert.support;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Currency;
/*     */ import java.util.Locale;
/*     */ import java.util.UUID;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.converter.ConverterRegistry;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultConversionService
/*     */   extends GenericConversionService
/*     */ {
/*  45 */   private static final boolean javaUtilOptionalClassAvailable = ClassUtils.isPresent("java.util.Optional", DefaultConversionService.class.getClassLoader());
/*     */   
/*     */ 
/*     */ 
/*  49 */   private static final boolean jsr310Available = ClassUtils.isPresent("java.time.ZoneId", DefaultConversionService.class.getClassLoader());
/*     */   
/*     */ 
/*  52 */   private static final boolean streamAvailable = ClassUtils.isPresent("java.util.stream.Stream", DefaultConversionService.class
/*  53 */     .getClassLoader());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultConversionService()
/*     */   {
/*  62 */     addDefaultConverters(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void addDefaultConverters(ConverterRegistry converterRegistry)
/*     */   {
/*  75 */     addScalarConverters(converterRegistry);
/*  76 */     addCollectionConverters(converterRegistry);
/*     */     
/*  78 */     converterRegistry.addConverter(new ByteBufferConverter((ConversionService)converterRegistry));
/*  79 */     if (jsr310Available) {
/*  80 */       Jsr310ConverterRegistrar.registerJsr310Converters(converterRegistry);
/*     */     }
/*     */     
/*  83 */     converterRegistry.addConverter(new ObjectToObjectConverter());
/*  84 */     converterRegistry.addConverter(new IdToEntityConverter((ConversionService)converterRegistry));
/*  85 */     converterRegistry.addConverter(new FallbackObjectToStringConverter());
/*  86 */     if (javaUtilOptionalClassAvailable) {
/*  87 */       converterRegistry.addConverter(new ObjectToOptionalConverter((ConversionService)converterRegistry));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void addCollectionConverters(ConverterRegistry converterRegistry)
/*     */   {
/*  99 */     ConversionService conversionService = (ConversionService)converterRegistry;
/*     */     
/* 101 */     converterRegistry.addConverter(new ArrayToCollectionConverter(conversionService));
/* 102 */     converterRegistry.addConverter(new CollectionToArrayConverter(conversionService));
/*     */     
/* 104 */     converterRegistry.addConverter(new ArrayToArrayConverter(conversionService));
/* 105 */     converterRegistry.addConverter(new CollectionToCollectionConverter(conversionService));
/* 106 */     converterRegistry.addConverter(new MapToMapConverter(conversionService));
/*     */     
/* 108 */     converterRegistry.addConverter(new ArrayToStringConverter(conversionService));
/* 109 */     converterRegistry.addConverter(new StringToArrayConverter(conversionService));
/*     */     
/* 111 */     converterRegistry.addConverter(new ArrayToObjectConverter(conversionService));
/* 112 */     converterRegistry.addConverter(new ObjectToArrayConverter(conversionService));
/*     */     
/* 114 */     converterRegistry.addConverter(new CollectionToStringConverter(conversionService));
/* 115 */     converterRegistry.addConverter(new StringToCollectionConverter(conversionService));
/*     */     
/* 117 */     converterRegistry.addConverter(new CollectionToObjectConverter(conversionService));
/* 118 */     converterRegistry.addConverter(new ObjectToCollectionConverter(conversionService));
/*     */     
/* 120 */     if (streamAvailable) {
/* 121 */       converterRegistry.addConverter(new StreamConverter(conversionService));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static void addScalarConverters(ConverterRegistry converterRegistry)
/*     */   {
/* 129 */     converterRegistry.addConverterFactory(new NumberToNumberConverterFactory());
/*     */     
/* 131 */     converterRegistry.addConverterFactory(new StringToNumberConverterFactory());
/* 132 */     converterRegistry.addConverter(Number.class, String.class, new ObjectToStringConverter());
/*     */     
/* 134 */     converterRegistry.addConverter(new StringToCharacterConverter());
/* 135 */     converterRegistry.addConverter(Character.class, String.class, new ObjectToStringConverter());
/*     */     
/* 137 */     converterRegistry.addConverter(new NumberToCharacterConverter());
/* 138 */     converterRegistry.addConverterFactory(new CharacterToNumberFactory());
/*     */     
/* 140 */     converterRegistry.addConverter(new StringToBooleanConverter());
/* 141 */     converterRegistry.addConverter(Boolean.class, String.class, new ObjectToStringConverter());
/*     */     
/* 143 */     converterRegistry.addConverterFactory(new StringToEnumConverterFactory());
/* 144 */     converterRegistry.addConverter(new EnumToStringConverter((ConversionService)converterRegistry));
/*     */     
/* 146 */     converterRegistry.addConverterFactory(new IntegerToEnumConverterFactory());
/* 147 */     converterRegistry.addConverter(new EnumToIntegerConverter((ConversionService)converterRegistry));
/*     */     
/* 149 */     converterRegistry.addConverter(new StringToLocaleConverter());
/* 150 */     converterRegistry.addConverter(Locale.class, String.class, new ObjectToStringConverter());
/*     */     
/* 152 */     converterRegistry.addConverter(new StringToCharsetConverter());
/* 153 */     converterRegistry.addConverter(Charset.class, String.class, new ObjectToStringConverter());
/*     */     
/* 155 */     converterRegistry.addConverter(new StringToCurrencyConverter());
/* 156 */     converterRegistry.addConverter(Currency.class, String.class, new ObjectToStringConverter());
/*     */     
/* 158 */     converterRegistry.addConverter(new StringToPropertiesConverter());
/* 159 */     converterRegistry.addConverter(new PropertiesToStringConverter());
/*     */     
/* 161 */     converterRegistry.addConverter(new StringToUUIDConverter());
/* 162 */     converterRegistry.addConverter(UUID.class, String.class, new ObjectToStringConverter());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class Jsr310ConverterRegistrar
/*     */   {
/*     */     public static void registerJsr310Converters(ConverterRegistry converterRegistry)
/*     */     {
/* 172 */       converterRegistry.addConverter(new StringToTimeZoneConverter());
/* 173 */       converterRegistry.addConverter(new ZoneIdToTimeZoneConverter());
/* 174 */       converterRegistry.addConverter(new ZonedDateTimeToCalendarConverter());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\convert\support\DefaultConversionService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */