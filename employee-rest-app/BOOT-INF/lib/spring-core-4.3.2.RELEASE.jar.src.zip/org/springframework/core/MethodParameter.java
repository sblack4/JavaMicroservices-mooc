/*     */ package org.springframework.core;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodParameter
/*     */ {
/*     */   private static final Class<?> javaUtilOptionalClass;
/*     */   private final Method method;
/*     */   private final Constructor<?> constructor;
/*     */   private final int parameterIndex;
/*     */   
/*     */   static
/*     */   {
/*     */     Class<?> clazz;
/*     */     try
/*     */     {
/*  56 */       clazz = ClassUtils.forName("java.util.Optional", MethodParameter.class.getClassLoader());
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/*     */       Class<?> clazz;
/*  60 */       clazz = null;
/*     */     }
/*  62 */     javaUtilOptionalClass = clazz;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */   private int nestingLevel = 1;
/*     */   
/*     */ 
/*     */   Map<Integer, Integer> typeIndexesPerLevel;
/*     */   
/*     */ 
/*     */   private volatile Class<?> containingClass;
/*     */   
/*     */ 
/*     */   private volatile Class<?> parameterType;
/*     */   
/*     */ 
/*     */   private volatile Type genericParameterType;
/*     */   
/*     */ 
/*     */   private volatile Annotation[] parameterAnnotations;
/*     */   
/*     */ 
/*     */   private volatile ParameterNameDiscoverer parameterNameDiscoverer;
/*     */   
/*     */ 
/*     */   private volatile String parameterName;
/*     */   
/*     */   private volatile MethodParameter nestedMethodParameter;
/*     */   
/*     */ 
/*     */   public MethodParameter(Method method, int parameterIndex)
/*     */   {
/* 100 */     this(method, parameterIndex, 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MethodParameter(Method method, int parameterIndex, int nestingLevel)
/*     */   {
/* 114 */     Assert.notNull(method, "Method must not be null");
/* 115 */     this.method = method;
/* 116 */     this.parameterIndex = parameterIndex;
/* 117 */     this.nestingLevel = nestingLevel;
/* 118 */     this.constructor = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MethodParameter(Constructor<?> constructor, int parameterIndex)
/*     */   {
/* 127 */     this(constructor, parameterIndex, 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MethodParameter(Constructor<?> constructor, int parameterIndex, int nestingLevel)
/*     */   {
/* 139 */     Assert.notNull(constructor, "Constructor must not be null");
/* 140 */     this.constructor = constructor;
/* 141 */     this.parameterIndex = parameterIndex;
/* 142 */     this.nestingLevel = nestingLevel;
/* 143 */     this.method = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MethodParameter(MethodParameter original)
/*     */   {
/* 152 */     Assert.notNull(original, "Original must not be null");
/* 153 */     this.method = original.method;
/* 154 */     this.constructor = original.constructor;
/* 155 */     this.parameterIndex = original.parameterIndex;
/* 156 */     this.nestingLevel = original.nestingLevel;
/* 157 */     this.typeIndexesPerLevel = original.typeIndexesPerLevel;
/* 158 */     this.containingClass = original.containingClass;
/* 159 */     this.parameterType = original.parameterType;
/* 160 */     this.genericParameterType = original.genericParameterType;
/* 161 */     this.parameterAnnotations = original.parameterAnnotations;
/* 162 */     this.parameterNameDiscoverer = original.parameterNameDiscoverer;
/* 163 */     this.parameterName = original.parameterName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Method getMethod()
/*     */   {
/* 173 */     return this.method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Constructor<?> getConstructor()
/*     */   {
/* 182 */     return this.constructor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Class<?> getDeclaringClass()
/*     */   {
/* 189 */     return getMember().getDeclaringClass();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Member getMember()
/*     */   {
/* 200 */     if (this.method != null) {
/* 201 */       return this.method;
/*     */     }
/*     */     
/* 204 */     return this.constructor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotatedElement getAnnotatedElement()
/*     */   {
/* 218 */     if (this.method != null) {
/* 219 */       return this.method;
/*     */     }
/*     */     
/* 222 */     return this.constructor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getParameterIndex()
/*     */   {
/* 231 */     return this.parameterIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void increaseNestingLevel()
/*     */   {
/* 239 */     this.nestingLevel += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void decreaseNestingLevel()
/*     */   {
/* 247 */     getTypeIndexesPerLevel().remove(Integer.valueOf(this.nestingLevel));
/* 248 */     this.nestingLevel -= 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNestingLevel()
/*     */   {
/* 257 */     return this.nestingLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTypeIndexForCurrentLevel(int typeIndex)
/*     */   {
/* 267 */     getTypeIndexesPerLevel().put(Integer.valueOf(this.nestingLevel), Integer.valueOf(typeIndex));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer getTypeIndexForCurrentLevel()
/*     */   {
/* 277 */     return getTypeIndexForLevel(this.nestingLevel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer getTypeIndexForLevel(int nestingLevel)
/*     */   {
/* 287 */     return (Integer)getTypeIndexesPerLevel().get(Integer.valueOf(nestingLevel));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private Map<Integer, Integer> getTypeIndexesPerLevel()
/*     */   {
/* 294 */     if (this.typeIndexesPerLevel == null) {
/* 295 */       this.typeIndexesPerLevel = new HashMap(4);
/*     */     }
/* 297 */     return this.typeIndexesPerLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MethodParameter nested()
/*     */   {
/* 308 */     if (this.nestedMethodParameter != null) {
/* 309 */       return this.nestedMethodParameter;
/*     */     }
/* 311 */     MethodParameter nestedParam = clone();
/* 312 */     this.nestingLevel += 1;
/* 313 */     this.nestedMethodParameter = nestedParam;
/* 314 */     return nestedParam;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isOptional()
/*     */   {
/* 323 */     return getParameterType() == javaUtilOptionalClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MethodParameter nestedIfOptional()
/*     */   {
/* 335 */     return isOptional() ? nested() : this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void setContainingClass(Class<?> containingClass)
/*     */   {
/* 343 */     this.containingClass = containingClass;
/*     */   }
/*     */   
/*     */   public Class<?> getContainingClass() {
/* 347 */     return this.containingClass != null ? this.containingClass : getDeclaringClass();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void setParameterType(Class<?> parameterType)
/*     */   {
/* 354 */     this.parameterType = parameterType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getParameterType()
/*     */   {
/* 362 */     if (this.parameterType == null) {
/* 363 */       if (this.parameterIndex < 0) {
/* 364 */         this.parameterType = (this.method != null ? this.method.getReturnType() : null);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 369 */         this.parameterType = (this.method != null ? this.method.getParameterTypes()[this.parameterIndex] : this.constructor.getParameterTypes()[this.parameterIndex]);
/*     */       }
/*     */     }
/* 372 */     return this.parameterType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Type getGenericParameterType()
/*     */   {
/* 381 */     if (this.genericParameterType == null) {
/* 382 */       if (this.parameterIndex < 0) {
/* 383 */         this.genericParameterType = (this.method != null ? this.method.getGenericReturnType() : null);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 388 */         this.genericParameterType = (this.method != null ? this.method.getGenericParameterTypes()[this.parameterIndex] : this.constructor.getGenericParameterTypes()[this.parameterIndex]);
/*     */       }
/*     */     }
/* 391 */     return this.genericParameterType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getNestedParameterType()
/*     */   {
/* 401 */     if (this.nestingLevel > 1) {
/* 402 */       Type type = getGenericParameterType();
/* 403 */       for (int i = 2; i <= this.nestingLevel; i++) {
/* 404 */         if ((type instanceof ParameterizedType)) {
/* 405 */           Type[] args = ((ParameterizedType)type).getActualTypeArguments();
/* 406 */           Integer index = getTypeIndexForLevel(i);
/* 407 */           type = args[(args.length - 1)];
/*     */         }
/*     */       }
/*     */       
/* 411 */       if ((type instanceof Class)) {
/* 412 */         return (Class)type;
/*     */       }
/* 414 */       if ((type instanceof ParameterizedType)) {
/* 415 */         Type arg = ((ParameterizedType)type).getRawType();
/* 416 */         if ((arg instanceof Class)) {
/* 417 */           return (Class)arg;
/*     */         }
/*     */       }
/* 420 */       return Object.class;
/*     */     }
/*     */     
/* 423 */     return getParameterType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Type getNestedGenericParameterType()
/*     */   {
/* 434 */     if (this.nestingLevel > 1) {
/* 435 */       Type type = getGenericParameterType();
/* 436 */       for (int i = 2; i <= this.nestingLevel; i++) {
/* 437 */         if ((type instanceof ParameterizedType)) {
/* 438 */           Type[] args = ((ParameterizedType)type).getActualTypeArguments();
/* 439 */           Integer index = getTypeIndexForLevel(i);
/* 440 */           type = args[(args.length - 1)];
/*     */         }
/*     */       }
/* 443 */       return type;
/*     */     }
/*     */     
/* 446 */     return getGenericParameterType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Annotation[] getMethodAnnotations()
/*     */   {
/* 454 */     return adaptAnnotationArray(getAnnotatedElement().getAnnotations());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <A extends Annotation> A getMethodAnnotation(Class<A> annotationType)
/*     */   {
/* 463 */     return adaptAnnotation(getAnnotatedElement().getAnnotation(annotationType));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <A extends Annotation> boolean hasMethodAnnotation(Class<A> annotationType)
/*     */   {
/* 473 */     return getAnnotatedElement().isAnnotationPresent(annotationType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Annotation[] getParameterAnnotations()
/*     */   {
/* 480 */     if (this.parameterAnnotations == null)
/*     */     {
/* 482 */       Annotation[][] annotationArray = this.method != null ? this.method.getParameterAnnotations() : this.constructor.getParameterAnnotations();
/* 483 */       if ((this.parameterIndex >= 0) && (this.parameterIndex < annotationArray.length)) {
/* 484 */         this.parameterAnnotations = adaptAnnotationArray(annotationArray[this.parameterIndex]);
/*     */       }
/*     */       else {
/* 487 */         this.parameterAnnotations = new Annotation[0];
/*     */       }
/*     */     }
/* 490 */     return this.parameterAnnotations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasParameterAnnotations()
/*     */   {
/* 499 */     return getParameterAnnotations().length != 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <A extends Annotation> A getParameterAnnotation(Class<A> annotationType)
/*     */   {
/* 509 */     Annotation[] anns = getParameterAnnotations();
/* 510 */     for (Annotation ann : anns) {
/* 511 */       if (annotationType.isInstance(ann)) {
/* 512 */         return ann;
/*     */       }
/*     */     }
/* 515 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <A extends Annotation> boolean hasParameterAnnotation(Class<A> annotationType)
/*     */   {
/* 524 */     return getParameterAnnotation(annotationType) != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initParameterNameDiscovery(ParameterNameDiscoverer parameterNameDiscoverer)
/*     */   {
/* 534 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getParameterName()
/*     */   {
/* 545 */     ParameterNameDiscoverer discoverer = this.parameterNameDiscoverer;
/* 546 */     if (discoverer != null)
/*     */     {
/* 548 */       String[] parameterNames = this.method != null ? discoverer.getParameterNames(this.method) : discoverer.getParameterNames(this.constructor);
/* 549 */       if (parameterNames != null) {
/* 550 */         this.parameterName = parameterNames[this.parameterIndex];
/*     */       }
/* 552 */       this.parameterNameDiscoverer = null;
/*     */     }
/* 554 */     return this.parameterName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected <A extends Annotation> A adaptAnnotation(A annotation)
/*     */   {
/* 567 */     return annotation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Annotation[] adaptAnnotationArray(Annotation[] annotations)
/*     */   {
/* 579 */     return annotations;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 585 */     if (this == other) {
/* 586 */       return true;
/*     */     }
/* 588 */     if (!(other instanceof MethodParameter)) {
/* 589 */       return false;
/*     */     }
/* 591 */     MethodParameter otherParam = (MethodParameter)other;
/* 592 */     return (this.parameterIndex == otherParam.parameterIndex) && (getMember().equals(otherParam.getMember()));
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 597 */     return getMember().hashCode() * 31 + this.parameterIndex;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 602 */     return (this.method != null ? "method '" + this.method.getName() + "'" : "constructor") + " parameter " + this.parameterIndex;
/*     */   }
/*     */   
/*     */ 
/*     */   public MethodParameter clone()
/*     */   {
/* 608 */     return new MethodParameter(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MethodParameter forMethodOrConstructor(Object methodOrConstructor, int parameterIndex)
/*     */   {
/* 621 */     if ((methodOrConstructor instanceof Method)) {
/* 622 */       return new MethodParameter((Method)methodOrConstructor, parameterIndex);
/*     */     }
/* 624 */     if ((methodOrConstructor instanceof Constructor)) {
/* 625 */       return new MethodParameter((Constructor)methodOrConstructor, parameterIndex);
/*     */     }
/*     */     
/* 628 */     throw new IllegalArgumentException("Given object [" + methodOrConstructor + "] is neither a Method nor a Constructor");
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\MethodParameter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */