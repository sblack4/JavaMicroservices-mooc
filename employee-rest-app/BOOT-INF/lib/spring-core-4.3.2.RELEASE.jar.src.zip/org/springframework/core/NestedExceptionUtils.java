/*    */ package org.springframework.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class NestedExceptionUtils
/*    */ {
/*    */   public static String buildMessage(String message, Throwable cause)
/*    */   {
/* 42 */     if (cause != null) {
/* 43 */       StringBuilder sb = new StringBuilder();
/* 44 */       if (message != null) {
/* 45 */         sb.append(message).append("; ");
/*    */       }
/* 47 */       sb.append("nested exception is ").append(cause);
/* 48 */       return sb.toString();
/*    */     }
/*    */     
/* 51 */     return message;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\NestedExceptionUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */