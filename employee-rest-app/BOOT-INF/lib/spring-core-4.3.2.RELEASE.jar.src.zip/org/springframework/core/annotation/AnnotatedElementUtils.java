/*      */ package org.springframework.core.annotation;
/*      */ 
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.reflect.AnnotatedElement;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import org.springframework.core.BridgeMethodResolver;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.LinkedMultiValueMap;
/*      */ import org.springframework.util.MultiValueMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class AnnotatedElementUtils
/*      */ {
/*  102 */   private static final Boolean CONTINUE = null;
/*      */   
/*  104 */   private static final Annotation[] EMPTY_ANNOTATION_ARRAY = new Annotation[0];
/*      */   
/*  106 */   private static final Processor<Boolean> alwaysTrueAnnotationProcessor = new AlwaysTrueBooleanAnnotationProcessor();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static AnnotatedElement forAnnotations(Annotation... annotations)
/*      */   {
/*  116 */     new AnnotatedElement()
/*      */     {
/*      */       public <T extends Annotation> T getAnnotation(Class<T> annotationClass)
/*      */       {
/*  120 */         for (Annotation ann : this.val$annotations) {
/*  121 */           if (ann.annotationType() == annotationClass) {
/*  122 */             return ann;
/*      */           }
/*      */         }
/*  125 */         return null;
/*      */       }
/*      */       
/*      */       public Annotation[] getAnnotations() {
/*  129 */         return this.val$annotations;
/*      */       }
/*      */       
/*      */       public Annotation[] getDeclaredAnnotations() {
/*  133 */         return this.val$annotations;
/*      */       }
/*      */     };
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Set<String> getMetaAnnotationTypes(AnnotatedElement element, Class<? extends Annotation> annotationType)
/*      */   {
/*  153 */     Assert.notNull(element, "AnnotatedElement must not be null");
/*  154 */     Assert.notNull(annotationType, "annotationType must not be null");
/*      */     
/*  156 */     return getMetaAnnotationTypes(element, element.getAnnotation(annotationType));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Set<String> getMetaAnnotationTypes(AnnotatedElement element, String annotationName)
/*      */   {
/*  174 */     Assert.notNull(element, "AnnotatedElement must not be null");
/*  175 */     Assert.hasLength(annotationName, "annotationName must not be null or empty");
/*      */     
/*  177 */     return getMetaAnnotationTypes(element, AnnotationUtils.getAnnotation(element, annotationName));
/*      */   }
/*      */   
/*      */   private static Set<String> getMetaAnnotationTypes(AnnotatedElement element, Annotation composed) {
/*  181 */     if (composed == null) {
/*  182 */       return null;
/*      */     }
/*      */     try
/*      */     {
/*  186 */       final Set<String> types = new LinkedHashSet();
/*  187 */       searchWithGetSemantics(composed.annotationType(), null, null, null, new SimpleAnnotationProcessor(true)
/*      */       
/*      */ 
/*      */ 
/*  191 */         new HashSet
/*      */         {
/*      */           public Object process(AnnotatedElement annotatedElement, Annotation annotation, int metaDepth) {
/*  190 */             types.add(annotation.annotationType().getName());
/*  191 */             return AnnotatedElementUtils.CONTINUE; } }, new HashSet(), 1);
/*      */       
/*      */ 
/*  194 */       return !types.isEmpty() ? types : null;
/*      */     }
/*      */     catch (Throwable ex) {
/*  197 */       AnnotationUtils.rethrowAnnotationConfigurationException(ex);
/*  198 */       throw new IllegalStateException("Failed to introspect annotations on " + element, ex);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean hasMetaAnnotationTypes(AnnotatedElement element, Class<? extends Annotation> annotationType)
/*      */   {
/*  215 */     Assert.notNull(element, "AnnotatedElement must not be null");
/*  216 */     Assert.notNull(annotationType, "annotationType must not be null");
/*      */     
/*  218 */     return hasMetaAnnotationTypes(element, annotationType, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean hasMetaAnnotationTypes(AnnotatedElement element, String annotationName)
/*      */   {
/*  234 */     Assert.notNull(element, "AnnotatedElement must not be null");
/*  235 */     Assert.hasLength(annotationName, "annotationName must not be null or empty");
/*      */     
/*  237 */     return hasMetaAnnotationTypes(element, null, annotationName);
/*      */   }
/*      */   
/*      */ 
/*      */   private static boolean hasMetaAnnotationTypes(AnnotatedElement element, Class<? extends Annotation> annotationType, String annotationName)
/*      */   {
/*  243 */     Boolean.TRUE.equals(
/*  244 */       searchWithGetSemantics(element, annotationType, annotationName, new SimpleAnnotationProcessor()
/*      */       {
/*      */ 
/*      */         public Boolean process(AnnotatedElement annotatedElement, Annotation annotation, int metaDepth)
/*      */         {
/*  248 */           return metaDepth > 0 ? Boolean.TRUE : AnnotatedElementUtils.CONTINUE;
/*      */         }
/*      */       }));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isAnnotated(AnnotatedElement element, Class<? extends Annotation> annotationType)
/*      */   {
/*  268 */     Assert.notNull(element, "AnnotatedElement must not be null");
/*  269 */     Assert.notNull(annotationType, "annotationType must not be null");
/*      */     
/*      */ 
/*  272 */     if (element.isAnnotationPresent(annotationType)) {
/*  273 */       return true;
/*      */     }
/*      */     
/*  276 */     return Boolean.TRUE.equals(searchWithGetSemantics(element, annotationType, null, alwaysTrueAnnotationProcessor));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isAnnotated(AnnotatedElement element, String annotationName)
/*      */   {
/*  292 */     Assert.notNull(element, "AnnotatedElement must not be null");
/*  293 */     Assert.hasLength(annotationName, "annotationName must not be null or empty");
/*      */     
/*  295 */     return Boolean.TRUE.equals(searchWithGetSemantics(element, null, annotationName, alwaysTrueAnnotationProcessor));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public static AnnotationAttributes getAnnotationAttributes(AnnotatedElement element, String annotationName)
/*      */   {
/*  303 */     return getMergedAnnotationAttributes(element, annotationName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public static AnnotationAttributes getAnnotationAttributes(AnnotatedElement element, String annotationName, boolean classValuesAsString, boolean nestedAnnotationsAsMap)
/*      */   {
/*  313 */     return getMergedAnnotationAttributes(element, annotationName, classValuesAsString, nestedAnnotationsAsMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static AnnotationAttributes getMergedAnnotationAttributes(AnnotatedElement element, Class<? extends Annotation> annotationType)
/*      */   {
/*  336 */     Assert.notNull(annotationType, "annotationType must not be null");
/*  337 */     AnnotationAttributes attributes = (AnnotationAttributes)searchWithGetSemantics(element, annotationType, null, new MergedAnnotationAttributesProcessor());
/*      */     
/*  339 */     AnnotationUtils.postProcessAnnotationAttributes(element, attributes, false, false);
/*  340 */     return attributes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static AnnotationAttributes getMergedAnnotationAttributes(AnnotatedElement element, String annotationName)
/*      */   {
/*  362 */     return getMergedAnnotationAttributes(element, annotationName, false, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static AnnotationAttributes getMergedAnnotationAttributes(AnnotatedElement element, String annotationName, boolean classValuesAsString, boolean nestedAnnotationsAsMap)
/*      */   {
/*  394 */     Assert.hasLength(annotationName, "annotationName must not be null or empty");
/*  395 */     AnnotationAttributes attributes = (AnnotationAttributes)searchWithGetSemantics(element, null, annotationName, new MergedAnnotationAttributesProcessor(classValuesAsString, nestedAnnotationsAsMap));
/*      */     
/*  397 */     AnnotationUtils.postProcessAnnotationAttributes(element, attributes, classValuesAsString, nestedAnnotationsAsMap);
/*  398 */     return attributes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <A extends Annotation> A getMergedAnnotation(AnnotatedElement element, Class<A> annotationType)
/*      */   {
/*  420 */     Assert.notNull(annotationType, "annotationType must not be null");
/*      */     
/*      */ 
/*  423 */     if (!(element instanceof Class))
/*      */     {
/*      */ 
/*  426 */       A annotation = element.getAnnotation(annotationType);
/*  427 */       if (annotation != null) {
/*  428 */         return AnnotationUtils.synthesizeAnnotation(annotation, element);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  433 */     AnnotationAttributes attributes = getMergedAnnotationAttributes(element, annotationType);
/*  434 */     return AnnotationUtils.synthesizeAnnotation(attributes, annotationType, element);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <A extends Annotation> Set<A> getAllMergedAnnotations(AnnotatedElement element, Class<A> annotationType)
/*      */   {
/*  460 */     Assert.notNull(element, "AnnotatedElement must not be null");
/*  461 */     Assert.notNull(annotationType, "annotationType must not be null");
/*      */     
/*  463 */     MergedAnnotationAttributesProcessor processor = new MergedAnnotationAttributesProcessor(false, false, true);
/*  464 */     searchWithGetSemantics(element, annotationType, null, processor);
/*  465 */     return postProcessAndSynthesizeAggregatedResults(element, annotationType, processor.getAggregatedResults());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <A extends Annotation> Set<A> getMergedRepeatableAnnotations(AnnotatedElement element, Class<A> annotationType)
/*      */   {
/*  495 */     return getMergedRepeatableAnnotations(element, annotationType, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <A extends Annotation> Set<A> getMergedRepeatableAnnotations(AnnotatedElement element, Class<A> annotationType, Class<? extends Annotation> containerType)
/*      */   {
/*  527 */     Assert.notNull(element, "AnnotatedElement must not be null");
/*  528 */     Assert.notNull(annotationType, "annotationType must not be null");
/*      */     
/*  530 */     if (containerType == null) {
/*  531 */       containerType = resolveContainerType(annotationType);
/*      */     }
/*      */     else {
/*  534 */       validateContainerType(annotationType, containerType);
/*      */     }
/*      */     
/*  537 */     MergedAnnotationAttributesProcessor processor = new MergedAnnotationAttributesProcessor(false, false, true);
/*  538 */     searchWithGetSemantics(element, annotationType, null, containerType, processor);
/*  539 */     return postProcessAndSynthesizeAggregatedResults(element, annotationType, processor.getAggregatedResults());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static MultiValueMap<String, Object> getAllAnnotationAttributes(AnnotatedElement element, String annotationName)
/*      */   {
/*  557 */     return getAllAnnotationAttributes(element, annotationName, false, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static MultiValueMap<String, Object> getAllAnnotationAttributes(AnnotatedElement element, String annotationName, boolean classValuesAsString, final boolean nestedAnnotationsAsMap)
/*      */   {
/*  581 */     final MultiValueMap<String, Object> attributesMap = new LinkedMultiValueMap();
/*      */     
/*  583 */     searchWithGetSemantics(element, null, annotationName, new SimpleAnnotationProcessor()
/*      */     {
/*      */       public Object process(AnnotatedElement annotatedElement, Annotation annotation, int metaDepth) {
/*  586 */         AnnotationAttributes annotationAttributes = AnnotationUtils.getAnnotationAttributes(annotation, this.val$classValuesAsString, nestedAnnotationsAsMap);
/*      */         
/*  588 */         for (Map.Entry<String, Object> entry : annotationAttributes.entrySet()) {
/*  589 */           attributesMap.add(entry.getKey(), entry.getValue());
/*      */         }
/*  591 */         return AnnotatedElementUtils.CONTINUE;
/*      */       }
/*      */       
/*  594 */     });
/*  595 */     return !attributesMap.isEmpty() ? attributesMap : null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean hasAnnotation(AnnotatedElement element, Class<? extends Annotation> annotationType)
/*      */   {
/*  613 */     Assert.notNull(element, "AnnotatedElement must not be null");
/*  614 */     Assert.notNull(annotationType, "annotationType must not be null");
/*      */     
/*      */ 
/*  617 */     if (element.isAnnotationPresent(annotationType)) {
/*  618 */       return true;
/*      */     }
/*      */     
/*  621 */     return Boolean.TRUE.equals(searchWithFindSemantics(element, annotationType, null, alwaysTrueAnnotationProcessor));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static AnnotationAttributes findMergedAnnotationAttributes(AnnotatedElement element, Class<? extends Annotation> annotationType, boolean classValuesAsString, boolean nestedAnnotationsAsMap)
/*      */   {
/*  656 */     AnnotationAttributes attributes = (AnnotationAttributes)searchWithFindSemantics(element, annotationType, null, new MergedAnnotationAttributesProcessor(classValuesAsString, nestedAnnotationsAsMap));
/*      */     
/*  658 */     AnnotationUtils.postProcessAnnotationAttributes(element, attributes, classValuesAsString, nestedAnnotationsAsMap);
/*  659 */     return attributes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static AnnotationAttributes findMergedAnnotationAttributes(AnnotatedElement element, String annotationName, boolean classValuesAsString, boolean nestedAnnotationsAsMap)
/*      */   {
/*  692 */     AnnotationAttributes attributes = (AnnotationAttributes)searchWithFindSemantics(element, null, annotationName, new MergedAnnotationAttributesProcessor(classValuesAsString, nestedAnnotationsAsMap));
/*      */     
/*  694 */     AnnotationUtils.postProcessAnnotationAttributes(element, attributes, classValuesAsString, nestedAnnotationsAsMap);
/*  695 */     return attributes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <A extends Annotation> A findMergedAnnotation(AnnotatedElement element, Class<A> annotationType)
/*      */   {
/*  717 */     Assert.notNull(annotationType, "annotationType must not be null");
/*      */     
/*      */ 
/*  720 */     if (!(element instanceof Class))
/*      */     {
/*      */ 
/*  723 */       A annotation = element.getAnnotation(annotationType);
/*  724 */       if (annotation != null) {
/*  725 */         return AnnotationUtils.synthesizeAnnotation(annotation, element);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  730 */     AnnotationAttributes attributes = findMergedAnnotationAttributes(element, annotationType, false, false);
/*  731 */     return AnnotationUtils.synthesizeAnnotation(attributes, annotationType, element);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public static <A extends Annotation> A findMergedAnnotation(AnnotatedElement element, String annotationName)
/*      */   {
/*  759 */     AnnotationAttributes attributes = findMergedAnnotationAttributes(element, annotationName, false, false);
/*  760 */     return AnnotationUtils.synthesizeAnnotation(attributes, attributes.annotationType(), element);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <A extends Annotation> Set<A> findAllMergedAnnotations(AnnotatedElement element, Class<A> annotationType)
/*      */   {
/*  785 */     Assert.notNull(element, "AnnotatedElement must not be null");
/*  786 */     Assert.notNull(annotationType, "annotationType must not be null");
/*      */     
/*  788 */     MergedAnnotationAttributesProcessor processor = new MergedAnnotationAttributesProcessor(false, false, true);
/*  789 */     searchWithFindSemantics(element, annotationType, null, processor);
/*  790 */     return postProcessAndSynthesizeAggregatedResults(element, annotationType, processor.getAggregatedResults());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <A extends Annotation> Set<A> findMergedRepeatableAnnotations(AnnotatedElement element, Class<A> annotationType)
/*      */   {
/*  820 */     return findMergedRepeatableAnnotations(element, annotationType, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <A extends Annotation> Set<A> findMergedRepeatableAnnotations(AnnotatedElement element, Class<A> annotationType, Class<? extends Annotation> containerType)
/*      */   {
/*  852 */     Assert.notNull(element, "AnnotatedElement must not be null");
/*  853 */     Assert.notNull(annotationType, "annotationType must not be null");
/*      */     
/*  855 */     if (containerType == null) {
/*  856 */       containerType = resolveContainerType(annotationType);
/*      */     }
/*      */     else {
/*  859 */       validateContainerType(annotationType, containerType);
/*      */     }
/*      */     
/*  862 */     MergedAnnotationAttributesProcessor processor = new MergedAnnotationAttributesProcessor(false, false, true);
/*  863 */     searchWithFindSemantics(element, annotationType, null, containerType, processor);
/*  864 */     return postProcessAndSynthesizeAggregatedResults(element, annotationType, processor.getAggregatedResults());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static <T> T searchWithGetSemantics(AnnotatedElement element, Class<? extends Annotation> annotationType, String annotationName, Processor<T> processor)
/*      */   {
/*  881 */     return (T)searchWithGetSemantics(element, annotationType, annotationName, null, processor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static <T> T searchWithGetSemantics(AnnotatedElement element, Class<? extends Annotation> annotationType, String annotationName, Class<? extends Annotation> containerType, Processor<T> processor)
/*      */   {
/*      */     try
/*      */     {
/*  902 */       return (T)searchWithGetSemantics(element, annotationType, annotationName, containerType, processor, new HashSet(), 0);
/*      */     }
/*      */     catch (Throwable ex)
/*      */     {
/*  906 */       AnnotationUtils.rethrowAnnotationConfigurationException(ex);
/*  907 */       throw new IllegalStateException("Failed to introspect annotations on " + element, ex);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static <T> T searchWithGetSemantics(AnnotatedElement element, Class<? extends Annotation> annotationType, String annotationName, Class<? extends Annotation> containerType, Processor<T> processor, Set<AnnotatedElement> visited, int metaDepth)
/*      */   {
/*  932 */     Assert.notNull(element, "AnnotatedElement must not be null");
/*      */     
/*  934 */     if (visited.add(element)) {
/*      */       try
/*      */       {
/*  937 */         List<Annotation> declaredAnnotations = Arrays.asList(element.getDeclaredAnnotations());
/*  938 */         T result = searchWithGetSemanticsInAnnotations(element, declaredAnnotations, annotationType, annotationName, containerType, processor, visited, metaDepth);
/*      */         
/*  940 */         if (result != null) {
/*  941 */           return result;
/*      */         }
/*      */         
/*  944 */         if ((element instanceof Class)) {
/*  945 */           List<Annotation> inheritedAnnotations = new ArrayList();
/*  946 */           for (Annotation annotation : element.getAnnotations()) {
/*  947 */             if (!declaredAnnotations.contains(annotation)) {
/*  948 */               inheritedAnnotations.add(annotation);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*  953 */           result = searchWithGetSemanticsInAnnotations(element, inheritedAnnotations, annotationType, annotationName, containerType, processor, visited, metaDepth);
/*      */           
/*  955 */           if (result != null) {
/*  956 */             return result;
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (Exception ex) {
/*  961 */         AnnotationUtils.handleIntrospectionFailure(element, ex);
/*      */       }
/*      */     }
/*      */     
/*  965 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static <T> T searchWithGetSemanticsInAnnotations(AnnotatedElement element, List<Annotation> annotations, Class<? extends Annotation> annotationType, String annotationName, Class<? extends Annotation> containerType, Processor<T> processor, Set<AnnotatedElement> visited, int metaDepth)
/*      */   {
/*  996 */     for (Annotation annotation : annotations) {
/*  997 */       if (!AnnotationUtils.isInJavaLangAnnotationPackage(annotation)) { T result;
/*  998 */         if ((annotation.annotationType() == annotationType) || 
/*  999 */           (annotation.annotationType().getName().equals(annotationName)) || 
/* 1000 */           (processor.alwaysProcesses())) {
/* 1001 */           result = processor.process(element, annotation, metaDepth);
/* 1002 */           if (result != null) {
/* 1003 */             if ((processor.aggregates()) && (metaDepth == 0)) {
/* 1004 */               processor.getAggregatedResults().add(result);
/*      */             }
/*      */             else {
/* 1007 */               return result;
/*      */             }
/*      */             
/*      */           }
/*      */         }
/* 1012 */         else if (annotation.annotationType() == containerType) {
/* 1013 */           for (Annotation contained : getRawAnnotationsFromContainer(element, annotation)) {
/* 1014 */             T result = processor.process(element, contained, metaDepth);
/* 1015 */             if (result != null)
/*      */             {
/*      */ 
/* 1018 */               processor.getAggregatedResults().add(result);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1026 */     for (Annotation annotation : annotations) {
/* 1027 */       if (!AnnotationUtils.isInJavaLangAnnotationPackage(annotation)) {
/* 1028 */         T result = searchWithGetSemantics(annotation.annotationType(), annotationType, annotationName, containerType, processor, visited, metaDepth + 1);
/*      */         
/* 1030 */         if (result != null) {
/* 1031 */           processor.postProcess(element, annotation, result);
/* 1032 */           if ((processor.aggregates()) && (metaDepth == 0)) {
/* 1033 */             processor.getAggregatedResults().add(result);
/*      */           }
/*      */           else {
/* 1036 */             return result;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1042 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static <T> T searchWithFindSemantics(AnnotatedElement element, Class<? extends Annotation> annotationType, String annotationName, Processor<T> processor)
/*      */   {
/* 1060 */     return (T)searchWithFindSemantics(element, annotationType, annotationName, null, processor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static <T> T searchWithFindSemantics(AnnotatedElement element, Class<? extends Annotation> annotationType, String annotationName, Class<? extends Annotation> containerType, Processor<T> processor)
/*      */   {
/* 1080 */     if ((containerType != null) && (!processor.aggregates())) {
/* 1081 */       throw new IllegalArgumentException("Searches for repeatable annotations must supply an aggregating Processor");
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1086 */       return (T)searchWithFindSemantics(element, annotationType, annotationName, containerType, processor, new HashSet(), 0);
/*      */     }
/*      */     catch (Throwable ex)
/*      */     {
/* 1090 */       AnnotationUtils.rethrowAnnotationConfigurationException(ex);
/* 1091 */       throw new IllegalStateException("Failed to introspect annotations on " + element, ex);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static <T> T searchWithFindSemantics(AnnotatedElement element, Class<? extends Annotation> annotationType, String annotationName, Class<? extends Annotation> containerType, Processor<T> processor, Set<AnnotatedElement> visited, int metaDepth)
/*      */   {
/* 1117 */     Assert.notNull(element, "AnnotatedElement must not be null");
/*      */     
/* 1119 */     if (visited.add(element)) {
/*      */       try
/*      */       {
/* 1122 */         Annotation[] annotations = element.getDeclaredAnnotations();
/* 1123 */         List<T> aggregatedResults = processor.aggregates() ? new ArrayList() : null;
/*      */         
/*      */ 
/* 1126 */         for (Annotation annotation : annotations) {
/* 1127 */           if (!AnnotationUtils.isInJavaLangAnnotationPackage(annotation)) { T result;
/* 1128 */             if ((annotation.annotationType() == annotationType) || 
/* 1129 */               (annotation.annotationType().getName().equals(annotationName)) || 
/* 1130 */               (processor.alwaysProcesses()))
/*      */             {
/* 1132 */               result = processor.process(element, annotation, metaDepth);
/* 1133 */               if (result != null) {
/* 1134 */                 if ((processor.aggregates()) && (metaDepth == 0)) {
/* 1135 */                   aggregatedResults.add(result);
/*      */                 }
/*      */                 else {
/* 1138 */                   return result;
/*      */                 }
/*      */                 
/*      */               }
/*      */             }
/* 1143 */             else if (annotation.annotationType() == containerType) {
/* 1144 */               for (Annotation contained : getRawAnnotationsFromContainer(element, annotation)) {
/* 1145 */                 T result = processor.process(element, contained, metaDepth);
/* 1146 */                 if (result != null)
/*      */                 {
/*      */ 
/* 1149 */                   aggregatedResults.add(result);
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 1157 */         for (Annotation annotation : annotations) {
/* 1158 */           if (!AnnotationUtils.isInJavaLangAnnotationPackage(annotation)) {
/* 1159 */             T result = searchWithFindSemantics(annotation.annotationType(), annotationType, annotationName, containerType, processor, visited, metaDepth + 1);
/*      */             
/* 1161 */             if (result != null) {
/* 1162 */               processor.postProcess(annotation.annotationType(), annotation, result);
/* 1163 */               if ((processor.aggregates()) && (metaDepth == 0)) {
/* 1164 */                 aggregatedResults.add(result);
/*      */               }
/*      */               else {
/* 1167 */                 return result;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         
/* 1173 */         if (processor.aggregates())
/*      */         {
/* 1175 */           processor.getAggregatedResults().addAll(0, aggregatedResults); }
/*      */         Object resolvedMethod;
/*      */         Object result;
/* 1178 */         Class<?>[] ifcs; if ((element instanceof Method)) {
/* 1179 */           Method method = (Method)element;
/*      */           
/*      */ 
/* 1182 */           resolvedMethod = BridgeMethodResolver.findBridgedMethod(method);
/* 1183 */           result = searchWithFindSemantics((AnnotatedElement)resolvedMethod, annotationType, annotationName, containerType, processor, visited, metaDepth);
/*      */           
/* 1185 */           if (result != null) {
/* 1186 */             return (T)result;
/*      */           }
/*      */           
/*      */ 
/* 1190 */           ifcs = method.getDeclaringClass().getInterfaces();
/* 1191 */           result = searchOnInterfaces(method, annotationType, annotationName, containerType, processor, visited, metaDepth, ifcs);
/*      */           
/* 1193 */           if (result != null) {
/* 1194 */             return (T)result;
/*      */           }
/*      */           
/*      */ 
/* 1198 */           Class<?> clazz = method.getDeclaringClass();
/*      */           do {
/* 1200 */             clazz = clazz.getSuperclass();
/* 1201 */             if ((clazz == null) || (Object.class == clazz)) {
/*      */               break;
/*      */             }
/*      */             try
/*      */             {
/* 1206 */               Method equivalentMethod = clazz.getDeclaredMethod(method.getName(), method.getParameterTypes());
/* 1207 */               Method resolvedEquivalentMethod = BridgeMethodResolver.findBridgedMethod(equivalentMethod);
/* 1208 */               result = searchWithFindSemantics(resolvedEquivalentMethod, annotationType, annotationName, containerType, processor, visited, metaDepth);
/*      */               
/* 1210 */               if (result != null) {
/* 1211 */                 return (T)result;
/*      */               }
/*      */             }
/*      */             catch (NoSuchMethodException localNoSuchMethodException1) {}
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 1219 */             result = searchOnInterfaces(method, annotationType, annotationName, containerType, processor, visited, metaDepth, clazz
/* 1220 */               .getInterfaces());
/* 1221 */           } while (result == null);
/* 1222 */           return (T)result;
/*      */ 
/*      */ 
/*      */         }
/* 1226 */         else if ((element instanceof Class)) {
/* 1227 */           Object clazz = (Class)element;
/*      */           
/*      */ 
/* 1230 */           resolvedMethod = ((Class)clazz).getInterfaces();Class<?>[] arrayOfClass1 = resolvedMethod.length; for (ifcs = 0; ifcs < arrayOfClass1; ifcs++) { Class<?> ifc = resolvedMethod[ifcs];
/* 1231 */             Object result = searchWithFindSemantics(ifc, annotationType, annotationName, containerType, processor, visited, metaDepth);
/*      */             
/* 1233 */             if (result != null) {
/* 1234 */               return (T)result;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/* 1239 */           Object superclass = ((Class)clazz).getSuperclass();
/* 1240 */           if ((superclass != null) && (Object.class != superclass)) {
/* 1241 */             Object result = searchWithFindSemantics((AnnotatedElement)superclass, annotationType, annotationName, containerType, processor, visited, metaDepth);
/*      */             
/* 1243 */             if (result != null) {
/* 1244 */               return (T)result;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (Exception ex) {
/* 1250 */         AnnotationUtils.handleIntrospectionFailure(element, ex);
/*      */       }
/*      */     }
/* 1253 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static <T> T searchOnInterfaces(Method method, Class<? extends Annotation> annotationType, String annotationName, Class<? extends Annotation> containerType, Processor<T> processor, Set<AnnotatedElement> visited, int metaDepth, Class<?>[] ifcs)
/*      */   {
/* 1260 */     for (Class<?> iface : ifcs) {
/* 1261 */       if (AnnotationUtils.isInterfaceWithAnnotatedMethods(iface)) {
/*      */         try {
/* 1263 */           Method equivalentMethod = iface.getMethod(method.getName(), method.getParameterTypes());
/* 1264 */           T result = searchWithFindSemantics(equivalentMethod, annotationType, annotationName, containerType, processor, visited, metaDepth);
/*      */           
/* 1266 */           if (result != null) {
/* 1267 */             return result;
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException) {}
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1276 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static <A extends Annotation> A[] getRawAnnotationsFromContainer(AnnotatedElement element, Annotation container)
/*      */   {
/*      */     try
/*      */     {
/* 1289 */       return (Annotation[])AnnotationUtils.getValue(container);
/*      */     }
/*      */     catch (Exception ex) {
/* 1292 */       AnnotationUtils.handleIntrospectionFailure(element, ex);
/*      */     }
/*      */     
/* 1295 */     return (Annotation[])EMPTY_ANNOTATION_ARRAY;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static Class<? extends Annotation> resolveContainerType(Class<? extends Annotation> annotationType)
/*      */   {
/* 1307 */     Class<? extends Annotation> containerType = AnnotationUtils.resolveContainerAnnotationType(annotationType);
/* 1308 */     if (containerType == null)
/*      */     {
/*      */ 
/* 1311 */       throw new IllegalArgumentException("annotationType must be a repeatable annotation: failed to resolve container type for " + annotationType.getName());
/*      */     }
/* 1313 */     return containerType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void validateContainerType(Class<? extends Annotation> annotationType, Class<? extends Annotation> containerType)
/*      */   {
/*      */     try
/*      */     {
/* 1329 */       Method method = containerType.getDeclaredMethod("value", new Class[0]);
/* 1330 */       Class<?> returnType = method.getReturnType();
/* 1331 */       if ((!returnType.isArray()) || (returnType.getComponentType() != annotationType)) {
/* 1332 */         String msg = String.format("Container type [%s] must declare a 'value' attribute for an array of type [%s]", new Object[] {containerType
/*      */         
/* 1334 */           .getName(), annotationType.getName() });
/* 1335 */         throw new AnnotationConfigurationException(msg);
/*      */       }
/*      */     }
/*      */     catch (Exception ex) {
/* 1339 */       AnnotationUtils.rethrowAnnotationConfigurationException(ex);
/* 1340 */       String msg = String.format("Invalid declaration of container type [%s] for repeatable annotation [%s]", new Object[] {containerType
/* 1341 */         .getName(), annotationType.getName() });
/* 1342 */       throw new AnnotationConfigurationException(msg, ex);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static <A extends Annotation> Set<A> postProcessAndSynthesizeAggregatedResults(AnnotatedElement element, Class<A> annotationType, List<AnnotationAttributes> aggregatedResults)
/*      */   {
/* 1352 */     Set<A> annotations = new LinkedHashSet();
/* 1353 */     for (AnnotationAttributes attributes : aggregatedResults) {
/* 1354 */       AnnotationUtils.postProcessAnnotationAttributes(element, attributes, false, false);
/* 1355 */       annotations.add(AnnotationUtils.synthesizeAnnotation(attributes, annotationType, element));
/*      */     }
/* 1357 */     return annotations;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static abstract interface Processor<T>
/*      */   {
/*      */     public abstract T process(AnnotatedElement paramAnnotatedElement, Annotation paramAnnotation, int paramInt);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public abstract void postProcess(AnnotatedElement paramAnnotatedElement, Annotation paramAnnotation, T paramT);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public abstract boolean alwaysProcesses();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public abstract boolean aggregates();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public abstract List<T> getAggregatedResults();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static abstract class SimpleAnnotationProcessor<T>
/*      */     implements AnnotatedElementUtils.Processor<T>
/*      */   {
/*      */     private final boolean alwaysProcesses;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public SimpleAnnotationProcessor()
/*      */     {
/* 1473 */       this(false);
/*      */     }
/*      */     
/*      */     public SimpleAnnotationProcessor(boolean alwaysProcesses) {
/* 1477 */       this.alwaysProcesses = alwaysProcesses;
/*      */     }
/*      */     
/*      */     public final boolean alwaysProcesses()
/*      */     {
/* 1482 */       return this.alwaysProcesses;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public final void postProcess(AnnotatedElement annotatedElement, Annotation annotation, T result) {}
/*      */     
/*      */ 
/*      */     public final boolean aggregates()
/*      */     {
/* 1492 */       return false;
/*      */     }
/*      */     
/*      */     public final List<T> getAggregatedResults()
/*      */     {
/* 1497 */       throw new UnsupportedOperationException("SimpleAnnotationProcessor does not support aggregated results");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static class AlwaysTrueBooleanAnnotationProcessor
/*      */     extends AnnotatedElementUtils.SimpleAnnotationProcessor<Boolean>
/*      */   {
/*      */     public final Boolean process(AnnotatedElement annotatedElement, Annotation annotation, int metaDepth)
/*      */     {
/* 1512 */       return Boolean.TRUE;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class MergedAnnotationAttributesProcessor
/*      */     implements AnnotatedElementUtils.Processor<AnnotationAttributes>
/*      */   {
/*      */     private final boolean classValuesAsString;
/*      */     
/*      */ 
/*      */ 
/*      */     private final boolean nestedAnnotationsAsMap;
/*      */     
/*      */ 
/*      */ 
/*      */     private final boolean aggregates;
/*      */     
/*      */ 
/*      */     private final List<AnnotationAttributes> aggregatedResults;
/*      */     
/*      */ 
/*      */ 
/*      */     MergedAnnotationAttributesProcessor()
/*      */     {
/* 1539 */       this(false, false, false);
/*      */     }
/*      */     
/*      */     MergedAnnotationAttributesProcessor(boolean classValuesAsString, boolean nestedAnnotationsAsMap) {
/* 1543 */       this(classValuesAsString, nestedAnnotationsAsMap, false);
/*      */     }
/*      */     
/*      */ 
/*      */     MergedAnnotationAttributesProcessor(boolean classValuesAsString, boolean nestedAnnotationsAsMap, boolean aggregates)
/*      */     {
/* 1549 */       this.classValuesAsString = classValuesAsString;
/* 1550 */       this.nestedAnnotationsAsMap = nestedAnnotationsAsMap;
/* 1551 */       this.aggregates = aggregates;
/* 1552 */       this.aggregatedResults = (aggregates ? new ArrayList() : null);
/*      */     }
/*      */     
/*      */     public boolean alwaysProcesses()
/*      */     {
/* 1557 */       return false;
/*      */     }
/*      */     
/*      */     public boolean aggregates()
/*      */     {
/* 1562 */       return this.aggregates;
/*      */     }
/*      */     
/*      */     public List<AnnotationAttributes> getAggregatedResults()
/*      */     {
/* 1567 */       return this.aggregatedResults;
/*      */     }
/*      */     
/*      */     public AnnotationAttributes process(AnnotatedElement annotatedElement, Annotation annotation, int metaDepth)
/*      */     {
/* 1572 */       return AnnotationUtils.retrieveAnnotationAttributes(annotatedElement, annotation, this.classValuesAsString, this.nestedAnnotationsAsMap);
/*      */     }
/*      */     
/*      */ 
/*      */     public void postProcess(AnnotatedElement element, Annotation annotation, AnnotationAttributes attributes)
/*      */     {
/* 1578 */       annotation = AnnotationUtils.synthesizeAnnotation(annotation, element);
/* 1579 */       Class<? extends Annotation> targetAnnotationType = attributes.annotationType();
/*      */       
/*      */ 
/*      */ 
/* 1583 */       Set<String> valuesAlreadyReplaced = new HashSet();
/*      */       
/* 1585 */       for (Method attributeMethod : AnnotationUtils.getAttributeMethods(annotation.annotationType())) {
/* 1586 */         String attributeName = attributeMethod.getName();
/* 1587 */         String attributeOverrideName = AnnotationUtils.getAttributeOverrideName(attributeMethod, targetAnnotationType);
/*      */         
/*      */ 
/* 1590 */         if (attributeOverrideName != null) {
/* 1591 */           if (!valuesAlreadyReplaced.contains(attributeOverrideName))
/*      */           {
/*      */ 
/*      */ 
/* 1595 */             List<String> targetAttributeNames = new ArrayList();
/* 1596 */             targetAttributeNames.add(attributeOverrideName);
/* 1597 */             valuesAlreadyReplaced.add(attributeOverrideName);
/*      */             
/*      */ 
/* 1600 */             List<String> aliases = (List)AnnotationUtils.getAttributeAliasMap(targetAnnotationType).get(attributeOverrideName);
/* 1601 */             if (aliases != null) {
/* 1602 */               for (String alias : aliases) {
/* 1603 */                 if (!valuesAlreadyReplaced.contains(alias)) {
/* 1604 */                   targetAttributeNames.add(alias);
/* 1605 */                   valuesAlreadyReplaced.add(alias);
/*      */                 }
/*      */               }
/*      */             }
/*      */             
/* 1610 */             overrideAttributes(element, annotation, attributes, attributeName, targetAttributeNames);
/*      */           }
/*      */         }
/* 1613 */         else if ((!"value".equals(attributeName)) && (attributes.containsKey(attributeName))) {
/* 1614 */           overrideAttribute(element, annotation, attributes, attributeName, attributeName);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     private void overrideAttributes(AnnotatedElement element, Annotation annotation, AnnotationAttributes attributes, String sourceAttributeName, List<String> targetAttributeNames)
/*      */     {
/* 1622 */       Object adaptedValue = getAdaptedValue(element, annotation, sourceAttributeName);
/*      */       
/* 1624 */       for (String targetAttributeName : targetAttributeNames) {
/* 1625 */         attributes.put(targetAttributeName, adaptedValue);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     private void overrideAttribute(AnnotatedElement element, Annotation annotation, AnnotationAttributes attributes, String sourceAttributeName, String targetAttributeName)
/*      */     {
/* 1632 */       attributes.put(targetAttributeName, getAdaptedValue(element, annotation, sourceAttributeName));
/*      */     }
/*      */     
/*      */     private Object getAdaptedValue(AnnotatedElement element, Annotation annotation, String sourceAttributeName) {
/* 1636 */       Object value = AnnotationUtils.getValue(annotation, sourceAttributeName);
/* 1637 */       return AnnotationUtils.adaptValue(element, value, this.classValuesAsString, this.nestedAnnotationsAsMap);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\annotation\AnnotatedElementUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */