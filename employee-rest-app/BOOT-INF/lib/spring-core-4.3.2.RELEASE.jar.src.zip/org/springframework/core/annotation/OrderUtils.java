/*    */ package org.springframework.core.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class OrderUtils
/*    */ {
/* 36 */   private static Class<? extends Annotation> priorityAnnotationType = null;
/*    */   
/*    */   static
/*    */   {
/*    */     try {
/* 41 */       priorityAnnotationType = ClassUtils.forName("javax.annotation.Priority", OrderUtils.class.getClassLoader());
/*    */     }
/*    */     catch (Throwable localThrowable) {}
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Integer getOrder(Class<?> type)
/*    */   {
/* 56 */     return getOrder(type, null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Integer getOrder(Class<?> type, Integer defaultOrder)
/*    */   {
/* 67 */     Order order = (Order)AnnotationUtils.findAnnotation(type, Order.class);
/* 68 */     if (order != null) {
/* 69 */       return Integer.valueOf(order.value());
/*    */     }
/* 71 */     Integer priorityOrder = getPriority(type);
/* 72 */     if (priorityOrder != null) {
/* 73 */       return priorityOrder;
/*    */     }
/* 75 */     return defaultOrder;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Integer getPriority(Class<?> type)
/*    */   {
/* 85 */     if (priorityAnnotationType != null) {
/* 86 */       Annotation priority = AnnotationUtils.findAnnotation(type, priorityAnnotationType);
/* 87 */       if (priority != null) {
/* 88 */         return (Integer)AnnotationUtils.getValue(priority);
/*    */       }
/*    */     }
/* 91 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\annotation\OrderUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */