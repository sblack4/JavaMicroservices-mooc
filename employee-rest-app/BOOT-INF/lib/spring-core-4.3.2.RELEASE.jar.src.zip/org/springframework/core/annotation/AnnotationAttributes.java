/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationAttributes
/*     */   extends LinkedHashMap<String, Object>
/*     */ {
/*     */   private static final String UNKNOWN = "unknown";
/*     */   private final Class<? extends Annotation> annotationType;
/*     */   private final String displayName;
/*  57 */   boolean validated = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationAttributes()
/*     */   {
/*  64 */     this.annotationType = null;
/*  65 */     this.displayName = "unknown";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationAttributes(int initialCapacity)
/*     */   {
/*  74 */     super(initialCapacity);
/*  75 */     this.annotationType = null;
/*  76 */     this.displayName = "unknown";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationAttributes(Class<? extends Annotation> annotationType)
/*     */   {
/*  87 */     Assert.notNull(annotationType, "'annotationType' must not be null");
/*  88 */     this.annotationType = annotationType;
/*  89 */     this.displayName = annotationType.getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationAttributes(String annotationType, ClassLoader classLoader)
/*     */   {
/* 102 */     Assert.notNull(annotationType, "'annotationType' must not be null");
/* 103 */     this.annotationType = getAnnotationType(annotationType, classLoader);
/* 104 */     this.displayName = annotationType;
/*     */   }
/*     */   
/*     */   private static Class<? extends Annotation> getAnnotationType(String annotationType, ClassLoader classLoader)
/*     */   {
/* 109 */     if (classLoader != null) {
/*     */       try {
/* 111 */         return classLoader.loadClass(annotationType);
/*     */       }
/*     */       catch (ClassNotFoundException localClassNotFoundException) {}
/*     */     }
/*     */     
/*     */ 
/* 117 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationAttributes(Map<String, Object> map)
/*     */   {
/* 127 */     super(map);
/* 128 */     this.annotationType = null;
/* 129 */     this.displayName = "unknown";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationAttributes(AnnotationAttributes other)
/*     */   {
/* 139 */     super(other);
/* 140 */     this.annotationType = other.annotationType;
/* 141 */     this.displayName = other.displayName;
/* 142 */     this.validated = other.validated;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<? extends Annotation> annotationType()
/*     */   {
/* 153 */     return this.annotationType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getString(String attributeName)
/*     */   {
/* 166 */     return (String)getRequiredAttribute(attributeName, String.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public String getAliasedString(String attributeName, Class<? extends Annotation> annotationType, Object annotationSource)
/*     */   {
/* 196 */     return (String)getRequiredAttributeWithAlias(attributeName, annotationType, annotationSource, String.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getStringArray(String attributeName)
/*     */   {
/* 212 */     return (String[])getRequiredAttribute(attributeName, String[].class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public String[] getAliasedStringArray(String attributeName, Class<? extends Annotation> annotationType, Object annotationSource)
/*     */   {
/* 242 */     return (String[])getRequiredAttributeWithAlias(attributeName, annotationType, annotationSource, String[].class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getBoolean(String attributeName)
/*     */   {
/* 255 */     return ((Boolean)getRequiredAttribute(attributeName, Boolean.class)).booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <N extends Number> N getNumber(String attributeName)
/*     */   {
/* 269 */     return (Number)getRequiredAttribute(attributeName, Number.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <E extends Enum<?>> E getEnum(String attributeName)
/*     */   {
/* 283 */     return (Enum)getRequiredAttribute(attributeName, Enum.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> Class<? extends T> getClass(String attributeName)
/*     */   {
/* 297 */     return (Class)getRequiredAttribute(attributeName, Class.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?>[] getClassArray(String attributeName)
/*     */   {
/* 313 */     return (Class[])getRequiredAttribute(attributeName, Class[].class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public Class<?>[] getAliasedClassArray(String attributeName, Class<? extends Annotation> annotationType, Object annotationSource)
/*     */   {
/* 343 */     return (Class[])getRequiredAttributeWithAlias(attributeName, annotationType, annotationSource, Class[].class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationAttributes getAnnotation(String attributeName)
/*     */   {
/* 358 */     return (AnnotationAttributes)getRequiredAttribute(attributeName, AnnotationAttributes.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <A extends Annotation> A getAnnotation(String attributeName, Class<A> annotationType)
/*     */   {
/* 373 */     return (Annotation)getRequiredAttribute(attributeName, annotationType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationAttributes[] getAnnotationArray(String attributeName)
/*     */   {
/* 391 */     return (AnnotationAttributes[])getRequiredAttribute(attributeName, AnnotationAttributes[].class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <A extends Annotation> A[] getAnnotationArray(String attributeName, Class<A> annotationType)
/*     */   {
/* 410 */     Object array = Array.newInstance(annotationType, 0);
/* 411 */     return (Annotation[])getRequiredAttribute(attributeName, array.getClass());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private <T> T getRequiredAttribute(String attributeName, Class<T> expectedType)
/*     */   {
/* 431 */     Assert.hasText(attributeName, "'attributeName' must not be null or empty");
/* 432 */     Object value = get(attributeName);
/* 433 */     assertAttributePresence(attributeName, value);
/* 434 */     assertNotException(attributeName, value);
/* 435 */     if ((!expectedType.isInstance(value)) && (expectedType.isArray()) && 
/* 436 */       (expectedType.getComponentType().isInstance(value))) {
/* 437 */       Object array = Array.newInstance(expectedType.getComponentType(), 1);
/* 438 */       Array.set(array, 0, value);
/* 439 */       value = array;
/*     */     }
/* 441 */     assertAttributeType(attributeName, value, expectedType);
/* 442 */     return (T)value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private <T> T getRequiredAttributeWithAlias(String attributeName, Class<? extends Annotation> annotationType, Object annotationSource, Class<T> expectedType)
/*     */   {
/* 471 */     Assert.hasText(attributeName, "'attributeName' must not be null or empty");
/* 472 */     Assert.notNull(annotationType, "'annotationType' must not be null");
/* 473 */     Assert.notNull(expectedType, "'expectedType' must not be null");
/*     */     
/* 475 */     T attributeValue = getAttribute(attributeName, expectedType);
/*     */     
/* 477 */     List<String> aliasNames = (List)AnnotationUtils.getAttributeAliasMap(annotationType).get(attributeName);
/* 478 */     if (aliasNames != null) {
/* 479 */       for (String aliasName : aliasNames) {
/* 480 */         T aliasValue = getAttribute(aliasName, expectedType);
/* 481 */         boolean attributeEmpty = ObjectUtils.isEmpty(attributeValue);
/* 482 */         boolean aliasEmpty = ObjectUtils.isEmpty(aliasValue);
/*     */         
/* 484 */         if ((!attributeEmpty) && (!aliasEmpty) && (!ObjectUtils.nullSafeEquals(attributeValue, aliasValue))) {
/* 485 */           String elementName = annotationSource == null ? "unknown element" : annotationSource.toString();
/* 486 */           String msg = String.format("In annotation [%s] declared on [%s], attribute [%s] and its alias [%s] are present with values of [%s] and [%s], but only one is permitted.", new Object[] {annotationType
/*     */           
/* 488 */             .getName(), elementName, attributeName, aliasName, 
/* 489 */             ObjectUtils.nullSafeToString(attributeValue), ObjectUtils.nullSafeToString(aliasValue) });
/* 490 */           throw new AnnotationConfigurationException(msg);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 496 */         if ((expectedType.isArray()) && (attributeValue == null) && (aliasValue != null)) {
/* 497 */           attributeValue = aliasValue;
/*     */ 
/*     */ 
/*     */         }
/* 501 */         else if ((attributeEmpty) && (!aliasEmpty)) {
/* 502 */           attributeValue = aliasValue;
/*     */         }
/*     */       }
/* 505 */       assertAttributePresence(attributeName, aliasNames, attributeValue);
/*     */     }
/*     */     
/* 508 */     return attributeValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private <T> T getAttribute(String attributeName, Class<T> expectedType)
/*     */   {
/* 524 */     Object value = get(attributeName);
/* 525 */     if (value != null) {
/* 526 */       assertNotException(attributeName, value);
/* 527 */       assertAttributeType(attributeName, value, expectedType);
/*     */     }
/* 529 */     return (T)value;
/*     */   }
/*     */   
/*     */   private void assertAttributePresence(String attributeName, Object attributeValue) {
/* 533 */     if (attributeValue == null) {
/* 534 */       throw new IllegalArgumentException(String.format("Attribute '%s' not found in attributes for annotation [%s]", new Object[] { attributeName, this.displayName }));
/*     */     }
/*     */   }
/*     */   
/*     */   private void assertAttributePresence(String attributeName, List<String> aliases, Object attributeValue)
/*     */   {
/* 540 */     if (attributeValue == null) {
/* 541 */       throw new IllegalArgumentException(String.format("Neither attribute '%s' nor one of its aliases %s was found in attributes for annotation [%s]", new Object[] { attributeName, aliases, this.displayName }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void assertNotException(String attributeName, Object attributeValue)
/*     */   {
/* 548 */     if ((attributeValue instanceof Exception)) {
/* 549 */       throw new IllegalArgumentException(String.format("Attribute '%s' for annotation [%s] was not resolvable due to exception [%s]", new Object[] { attributeName, this.displayName, attributeValue }), (Exception)attributeValue);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void assertAttributeType(String attributeName, Object attributeValue, Class<?> expectedType)
/*     */   {
/* 556 */     if (!expectedType.isInstance(attributeValue)) {
/* 557 */       throw new IllegalArgumentException(String.format("Attribute '%s' is of type [%s], but [%s] was expected in attributes for annotation [%s]", new Object[] { attributeName, attributeValue
/*     */       
/* 559 */         .getClass().getSimpleName(), expectedType.getSimpleName(), this.displayName }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object putIfAbsent(String key, Object value)
/*     */   {
/* 577 */     Object obj = get(key);
/* 578 */     if (obj == null) {
/* 579 */       obj = put(key, value);
/*     */     }
/* 581 */     return obj;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 586 */     Iterator<Map.Entry<String, Object>> entries = entrySet().iterator();
/* 587 */     StringBuilder sb = new StringBuilder("{");
/* 588 */     while (entries.hasNext()) {
/* 589 */       Map.Entry<String, Object> entry = (Map.Entry)entries.next();
/* 590 */       sb.append((String)entry.getKey());
/* 591 */       sb.append('=');
/* 592 */       sb.append(valueToString(entry.getValue()));
/* 593 */       sb.append(entries.hasNext() ? ", " : "");
/*     */     }
/* 595 */     sb.append("}");
/* 596 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private String valueToString(Object value) {
/* 600 */     if (value == this) {
/* 601 */       return "(this Map)";
/*     */     }
/* 603 */     if ((value instanceof Object[])) {
/* 604 */       return "[" + StringUtils.arrayToDelimitedString((Object[])value, ", ") + "]";
/*     */     }
/* 606 */     return String.valueOf(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AnnotationAttributes fromMap(Map<String, Object> map)
/*     */   {
/* 619 */     if (map == null) {
/* 620 */       return null;
/*     */     }
/* 622 */     if ((map instanceof AnnotationAttributes)) {
/* 623 */       return (AnnotationAttributes)map;
/*     */     }
/* 625 */     return new AnnotationAttributes(map);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\annotation\AnnotationAttributes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */