/*      */ package org.springframework.core.annotation;
/*      */ 
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.reflect.AnnotatedElement;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.InvocationHandler;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.lang.reflect.Proxy;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.core.BridgeMethodResolver;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ConcurrentReferenceHashMap;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.ReflectionUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AnnotationUtils
/*      */ {
/*      */   public static final String VALUE = "value";
/*      */   private static final String REPEATABLE_CLASS_NAME = "java.lang.annotation.Repeatable";
/*  117 */   private static final Map<AnnotationCacheKey, Annotation> findAnnotationCache = new ConcurrentReferenceHashMap(256);
/*      */   
/*      */ 
/*  120 */   private static final Map<AnnotationCacheKey, Boolean> metaPresentCache = new ConcurrentReferenceHashMap(256);
/*      */   
/*      */ 
/*  123 */   private static final Map<Class<?>, Boolean> annotatedInterfaceCache = new ConcurrentReferenceHashMap(256);
/*      */   
/*      */ 
/*  126 */   private static final Map<Class<? extends Annotation>, Boolean> synthesizableCache = new ConcurrentReferenceHashMap(256);
/*      */   
/*      */ 
/*  129 */   private static final Map<Class<? extends Annotation>, Map<String, List<String>>> attributeAliasesCache = new ConcurrentReferenceHashMap(256);
/*      */   
/*      */ 
/*  132 */   private static final Map<Class<? extends Annotation>, List<Method>> attributeMethodsCache = new ConcurrentReferenceHashMap(256);
/*      */   
/*      */ 
/*  135 */   private static final Map<Method, AliasDescriptor> aliasDescriptorCache = new ConcurrentReferenceHashMap(256);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static transient Log logger;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <A extends Annotation> A getAnnotation(Annotation ann, Class<A> annotationType)
/*      */   {
/*  155 */     if (annotationType.isInstance(ann)) {
/*  156 */       return synthesizeAnnotation(ann);
/*      */     }
/*  158 */     Class<? extends Annotation> annotatedElement = ann.annotationType();
/*      */     try {
/*  160 */       return synthesizeAnnotation(annotatedElement.getAnnotation(annotationType), annotatedElement);
/*      */     }
/*      */     catch (Exception ex) {
/*  163 */       handleIntrospectionFailure(annotatedElement, ex);
/*      */     }
/*  165 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <A extends Annotation> A getAnnotation(AnnotatedElement annotatedElement, Class<A> annotationType)
/*      */   {
/*      */     try
/*      */     {
/*  182 */       A annotation = annotatedElement.getAnnotation(annotationType);
/*  183 */       if (annotation == null) {
/*  184 */         for (Annotation metaAnn : annotatedElement.getAnnotations()) {
/*  185 */           annotation = metaAnn.annotationType().getAnnotation(annotationType);
/*  186 */           if (annotation != null) {
/*      */             break;
/*      */           }
/*      */         }
/*      */       }
/*  191 */       return synthesizeAnnotation(annotation, annotatedElement);
/*      */     }
/*      */     catch (Exception ex) {
/*  194 */       handleIntrospectionFailure(annotatedElement, ex);
/*      */     }
/*  196 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <A extends Annotation> A getAnnotation(Method method, Class<A> annotationType)
/*      */   {
/*  214 */     Method resolvedMethod = BridgeMethodResolver.findBridgedMethod(method);
/*  215 */     return getAnnotation(resolvedMethod, annotationType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Annotation[] getAnnotations(AnnotatedElement annotatedElement)
/*      */   {
/*      */     try
/*      */     {
/*  231 */       return synthesizeAnnotationArray(annotatedElement.getAnnotations(), annotatedElement);
/*      */     }
/*      */     catch (Exception ex) {
/*  234 */       handleIntrospectionFailure(annotatedElement, ex);
/*      */     }
/*  236 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Annotation[] getAnnotations(Method method)
/*      */   {
/*      */     try
/*      */     {
/*  253 */       return synthesizeAnnotationArray(BridgeMethodResolver.findBridgedMethod(method).getAnnotations(), method);
/*      */     }
/*      */     catch (Exception ex) {
/*  256 */       handleIntrospectionFailure(method, ex);
/*      */     }
/*  258 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public static <A extends Annotation> Set<A> getRepeatableAnnotation(Method method, Class<? extends Annotation> containerAnnotationType, Class<A> annotationType)
/*      */   {
/*  273 */     return getRepeatableAnnotations(method, annotationType, containerAnnotationType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public static <A extends Annotation> Set<A> getRepeatableAnnotation(AnnotatedElement annotatedElement, Class<? extends Annotation> containerAnnotationType, Class<A> annotationType)
/*      */   {
/*  288 */     return getRepeatableAnnotations(annotatedElement, annotationType, containerAnnotationType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <A extends Annotation> Set<A> getRepeatableAnnotations(AnnotatedElement annotatedElement, Class<A> annotationType)
/*      */   {
/*  321 */     return getRepeatableAnnotations(annotatedElement, annotationType, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <A extends Annotation> Set<A> getRepeatableAnnotations(AnnotatedElement annotatedElement, Class<A> annotationType, Class<? extends Annotation> containerAnnotationType)
/*      */   {
/*  357 */     Set<A> annotations = getDeclaredRepeatableAnnotations(annotatedElement, annotationType, containerAnnotationType);
/*  358 */     if (!annotations.isEmpty()) {
/*  359 */       return annotations;
/*      */     }
/*      */     
/*  362 */     if ((annotatedElement instanceof Class)) {
/*  363 */       Class<?> superclass = ((Class)annotatedElement).getSuperclass();
/*  364 */       if ((superclass != null) && (Object.class != superclass)) {
/*  365 */         return getRepeatableAnnotations(superclass, annotationType, containerAnnotationType);
/*      */       }
/*      */     }
/*      */     
/*  369 */     return getRepeatableAnnotations(annotatedElement, annotationType, containerAnnotationType, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <A extends Annotation> Set<A> getDeclaredRepeatableAnnotations(AnnotatedElement annotatedElement, Class<A> annotationType)
/*      */   {
/*  403 */     return getDeclaredRepeatableAnnotations(annotatedElement, annotationType, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <A extends Annotation> Set<A> getDeclaredRepeatableAnnotations(AnnotatedElement annotatedElement, Class<A> annotationType, Class<? extends Annotation> containerAnnotationType)
/*      */   {
/*  439 */     return getRepeatableAnnotations(annotatedElement, annotationType, containerAnnotationType, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static <A extends Annotation> Set<A> getRepeatableAnnotations(AnnotatedElement annotatedElement, Class<A> annotationType, Class<? extends Annotation> containerAnnotationType, boolean declaredMode)
/*      */   {
/*  465 */     Assert.notNull(annotatedElement, "AnnotatedElement must not be null");
/*  466 */     Assert.notNull(annotationType, "Annotation type must not be null");
/*      */     try
/*      */     {
/*  469 */       if ((annotatedElement instanceof Method)) {
/*  470 */         annotatedElement = BridgeMethodResolver.findBridgedMethod((Method)annotatedElement);
/*      */       }
/*  472 */       return new AnnotationCollector(annotationType, containerAnnotationType, declaredMode).getResult(annotatedElement);
/*      */     }
/*      */     catch (Exception ex) {
/*  475 */       handleIntrospectionFailure(annotatedElement, ex);
/*      */     }
/*  477 */     return Collections.emptySet();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <A extends Annotation> A findAnnotation(AnnotatedElement annotatedElement, Class<A> annotationType)
/*      */   {
/*  497 */     Assert.notNull(annotatedElement, "AnnotatedElement must not be null");
/*  498 */     if (annotationType == null) {
/*  499 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  504 */     A ann = findAnnotation(annotatedElement, annotationType, new HashSet());
/*  505 */     return synthesizeAnnotation(ann, annotatedElement);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static <A extends Annotation> A findAnnotation(AnnotatedElement annotatedElement, Class<A> annotationType, Set<Annotation> visited)
/*      */   {
/*      */     try
/*      */     {
/*  521 */       Annotation[] anns = annotatedElement.getDeclaredAnnotations();
/*  522 */       for (Annotation ann : anns) {
/*  523 */         if (ann.annotationType() == annotationType) {
/*  524 */           return ann;
/*      */         }
/*      */       }
/*  527 */       for (Annotation ann : anns) {
/*  528 */         if ((!isInJavaLangAnnotationPackage(ann)) && (visited.add(ann))) {
/*  529 */           A annotation = findAnnotation(ann.annotationType(), annotationType, visited);
/*  530 */           if (annotation != null) {
/*  531 */             return annotation;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception ex) {
/*  537 */       handleIntrospectionFailure(annotatedElement, ex);
/*      */     }
/*  539 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <A extends Annotation> A findAnnotation(Method method, Class<A> annotationType)
/*      */   {
/*  559 */     Assert.notNull(method, "Method must not be null");
/*  560 */     if (annotationType == null) {
/*  561 */       return null;
/*      */     }
/*      */     
/*  564 */     AnnotationCacheKey cacheKey = new AnnotationCacheKey(method, annotationType);
/*  565 */     A result = (Annotation)findAnnotationCache.get(cacheKey);
/*      */     
/*  567 */     if (result == null) {
/*  568 */       Method resolvedMethod = BridgeMethodResolver.findBridgedMethod(method);
/*  569 */       result = findAnnotation(resolvedMethod, annotationType);
/*      */       
/*  571 */       if (result == null) {
/*  572 */         result = searchOnInterfaces(method, annotationType, method.getDeclaringClass().getInterfaces());
/*      */       }
/*      */       
/*  575 */       Class<?> clazz = method.getDeclaringClass();
/*  576 */       while (result == null) {
/*  577 */         clazz = clazz.getSuperclass();
/*  578 */         if ((clazz == null) || (Object.class == clazz)) {
/*      */           break;
/*      */         }
/*      */         try {
/*  582 */           Method equivalentMethod = clazz.getDeclaredMethod(method.getName(), method.getParameterTypes());
/*  583 */           Method resolvedEquivalentMethod = BridgeMethodResolver.findBridgedMethod(equivalentMethod);
/*  584 */           result = findAnnotation(resolvedEquivalentMethod, annotationType);
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException) {}
/*      */         
/*      */ 
/*  589 */         if (result == null) {
/*  590 */           result = searchOnInterfaces(method, annotationType, clazz.getInterfaces());
/*      */         }
/*      */       }
/*      */       
/*  594 */       if (result != null) {
/*  595 */         result = synthesizeAnnotation(result, method);
/*  596 */         findAnnotationCache.put(cacheKey, result);
/*      */       }
/*      */     }
/*      */     
/*  600 */     return result;
/*      */   }
/*      */   
/*      */   private static <A extends Annotation> A searchOnInterfaces(Method method, Class<A> annotationType, Class<?>... ifcs) {
/*  604 */     A annotation = null;
/*  605 */     for (Class<?> iface : ifcs) {
/*  606 */       if (isInterfaceWithAnnotatedMethods(iface)) {
/*      */         try {
/*  608 */           Method equivalentMethod = iface.getMethod(method.getName(), method.getParameterTypes());
/*  609 */           annotation = getAnnotation(equivalentMethod, annotationType);
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException) {}
/*      */         
/*      */ 
/*  614 */         if (annotation != null) {
/*      */           break;
/*      */         }
/*      */       }
/*      */     }
/*  619 */     return annotation;
/*      */   }
/*      */   
/*      */   static boolean isInterfaceWithAnnotatedMethods(Class<?> iface) {
/*  623 */     Boolean found = (Boolean)annotatedInterfaceCache.get(iface);
/*  624 */     if (found != null) {
/*  625 */       return found.booleanValue();
/*      */     }
/*  627 */     found = Boolean.FALSE;
/*  628 */     for (Method ifcMethod : iface.getMethods()) {
/*      */       try {
/*  630 */         if (ifcMethod.getAnnotations().length > 0) {
/*  631 */           found = Boolean.TRUE;
/*  632 */           break;
/*      */         }
/*      */       }
/*      */       catch (Exception ex) {
/*  636 */         handleIntrospectionFailure(ifcMethod, ex);
/*      */       }
/*      */     }
/*  639 */     annotatedInterfaceCache.put(iface, found);
/*  640 */     return found.booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <A extends Annotation> A findAnnotation(Class<?> clazz, Class<A> annotationType)
/*      */   {
/*  666 */     return findAnnotation(clazz, annotationType, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static <A extends Annotation> A findAnnotation(Class<?> clazz, Class<A> annotationType, boolean synthesize)
/*      */   {
/*  681 */     Assert.notNull(clazz, "Class must not be null");
/*  682 */     if (annotationType == null) {
/*  683 */       return null;
/*      */     }
/*      */     
/*  686 */     AnnotationCacheKey cacheKey = new AnnotationCacheKey(clazz, annotationType);
/*  687 */     A result = (Annotation)findAnnotationCache.get(cacheKey);
/*  688 */     if (result == null) {
/*  689 */       result = findAnnotation(clazz, annotationType, new HashSet());
/*  690 */       if ((result != null) && (synthesize)) {
/*  691 */         result = synthesizeAnnotation(result, clazz);
/*  692 */         findAnnotationCache.put(cacheKey, result);
/*      */       }
/*      */     }
/*  695 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static <A extends Annotation> A findAnnotation(Class<?> clazz, Class<A> annotationType, Set<Annotation> visited)
/*      */   {
/*      */     try
/*      */     {
/*  710 */       Annotation[] anns = clazz.getDeclaredAnnotations();
/*  711 */       for (Annotation ann : anns) {
/*  712 */         if (ann.annotationType() == annotationType) {
/*  713 */           return ann;
/*      */         }
/*      */       }
/*  716 */       for (Annotation ann : anns) {
/*  717 */         if ((!isInJavaLangAnnotationPackage(ann)) && (visited.add(ann))) {
/*  718 */           A annotation = findAnnotation(ann.annotationType(), annotationType, visited);
/*  719 */           if (annotation != null) {
/*  720 */             return annotation;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception ex) {
/*  726 */       handleIntrospectionFailure(clazz, ex);
/*  727 */       return null;
/*      */     }
/*      */     
/*  730 */     for (Class<?> ifc : clazz.getInterfaces()) {
/*  731 */       A annotation = findAnnotation(ifc, annotationType, visited);
/*  732 */       if (annotation != null) {
/*  733 */         return annotation;
/*      */       }
/*      */     }
/*      */     
/*  737 */     Class<?> superclass = clazz.getSuperclass();
/*  738 */     if ((superclass == null) || (Object.class == superclass)) {
/*  739 */       return null;
/*      */     }
/*  741 */     return findAnnotation(superclass, annotationType, visited);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<?> findAnnotationDeclaringClass(Class<? extends Annotation> annotationType, Class<?> clazz)
/*      */   {
/*  767 */     Assert.notNull(annotationType, "Annotation type must not be null");
/*  768 */     if ((clazz == null) || (Object.class == clazz)) {
/*  769 */       return null;
/*      */     }
/*  771 */     if (isAnnotationDeclaredLocally(annotationType, clazz)) {
/*  772 */       return clazz;
/*      */     }
/*  774 */     return findAnnotationDeclaringClass(annotationType, clazz.getSuperclass());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<?> findAnnotationDeclaringClassForTypes(List<Class<? extends Annotation>> annotationTypes, Class<?> clazz)
/*      */   {
/*  802 */     Assert.notEmpty(annotationTypes, "List of annotation types must not be empty");
/*  803 */     if ((clazz == null) || (Object.class == clazz)) {
/*  804 */       return null;
/*      */     }
/*  806 */     for (Class<? extends Annotation> annotationType : annotationTypes) {
/*  807 */       if (isAnnotationDeclaredLocally(annotationType, clazz)) {
/*  808 */         return clazz;
/*      */       }
/*      */     }
/*  811 */     return findAnnotationDeclaringClassForTypes(annotationTypes, clazz.getSuperclass());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isAnnotationDeclaredLocally(Class<? extends Annotation> annotationType, Class<?> clazz)
/*      */   {
/*  833 */     Assert.notNull(annotationType, "Annotation type must not be null");
/*  834 */     Assert.notNull(clazz, "Class must not be null");
/*      */     try {
/*  836 */       for (Annotation ann : clazz.getDeclaredAnnotations()) {
/*  837 */         if (ann.annotationType() == annotationType) {
/*  838 */           return true;
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception ex) {
/*  843 */       handleIntrospectionFailure(clazz, ex);
/*      */     }
/*  845 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isAnnotationInherited(Class<? extends Annotation> annotationType, Class<?> clazz)
/*      */   {
/*  868 */     Assert.notNull(annotationType, "Annotation type must not be null");
/*  869 */     Assert.notNull(clazz, "Class must not be null");
/*  870 */     return (clazz.isAnnotationPresent(annotationType)) && (!isAnnotationDeclaredLocally(annotationType, clazz));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isAnnotationMetaPresent(Class<? extends Annotation> annotationType, Class<? extends Annotation> metaAnnotationType)
/*      */   {
/*  884 */     Assert.notNull(annotationType, "Annotation type must not be null");
/*  885 */     if (metaAnnotationType == null) {
/*  886 */       return false;
/*      */     }
/*      */     
/*  889 */     AnnotationCacheKey cacheKey = new AnnotationCacheKey(annotationType, metaAnnotationType);
/*  890 */     Boolean metaPresent = (Boolean)metaPresentCache.get(cacheKey);
/*  891 */     if (metaPresent != null) {
/*  892 */       return metaPresent.booleanValue();
/*      */     }
/*  894 */     metaPresent = Boolean.FALSE;
/*  895 */     if (findAnnotation(annotationType, metaAnnotationType, false) != null) {
/*  896 */       metaPresent = Boolean.TRUE;
/*      */     }
/*  898 */     metaPresentCache.put(cacheKey, metaPresent);
/*  899 */     return metaPresent.booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isInJavaLangAnnotationPackage(Annotation annotation)
/*      */   {
/*  909 */     Assert.notNull(annotation, "Annotation must not be null");
/*  910 */     return isInJavaLangAnnotationPackage(annotation.annotationType().getName());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isInJavaLangAnnotationPackage(String annotationType)
/*      */   {
/*  921 */     Assert.hasText(annotationType, "annotationType must not be null or empty");
/*  922 */     return annotationType.startsWith("java.lang.annotation");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Map<String, Object> getAnnotationAttributes(Annotation annotation)
/*      */   {
/*  941 */     return getAnnotationAttributes(null, annotation);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Map<String, Object> getAnnotationAttributes(Annotation annotation, boolean classValuesAsString)
/*      */   {
/*  959 */     return getAnnotationAttributes(annotation, classValuesAsString, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static AnnotationAttributes getAnnotationAttributes(Annotation annotation, boolean classValuesAsString, boolean nestedAnnotationsAsMap)
/*      */   {
/*  981 */     return getAnnotationAttributes(null, annotation, classValuesAsString, nestedAnnotationsAsMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static AnnotationAttributes getAnnotationAttributes(AnnotatedElement annotatedElement, Annotation annotation)
/*      */   {
/*  998 */     return getAnnotationAttributes(annotatedElement, annotation, false, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static AnnotationAttributes getAnnotationAttributes(AnnotatedElement annotatedElement, Annotation annotation, boolean classValuesAsString, boolean nestedAnnotationsAsMap)
/*      */   {
/* 1022 */     return getAnnotationAttributes(annotatedElement, annotation, classValuesAsString, nestedAnnotationsAsMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static AnnotationAttributes getAnnotationAttributes(Object annotatedElement, Annotation annotation, boolean classValuesAsString, boolean nestedAnnotationsAsMap)
/*      */   {
/* 1030 */     AnnotationAttributes attributes = retrieveAnnotationAttributes(annotatedElement, annotation, classValuesAsString, nestedAnnotationsAsMap);
/* 1031 */     postProcessAnnotationAttributes(annotatedElement, attributes, classValuesAsString, nestedAnnotationsAsMap);
/* 1032 */     return attributes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static AnnotationAttributes retrieveAnnotationAttributes(Object annotatedElement, Annotation annotation, boolean classValuesAsString, boolean nestedAnnotationsAsMap)
/*      */   {
/* 1066 */     Class<? extends Annotation> annotationType = annotation.annotationType();
/* 1067 */     AnnotationAttributes attributes = new AnnotationAttributes(annotationType);
/*      */     
/* 1069 */     for (Method method : getAttributeMethods(annotationType)) {
/*      */       try {
/* 1071 */         Object attributeValue = method.invoke(annotation, new Object[0]);
/* 1072 */         Object defaultValue = method.getDefaultValue();
/* 1073 */         if ((defaultValue != null) && (ObjectUtils.nullSafeEquals(attributeValue, defaultValue))) {
/* 1074 */           attributeValue = new DefaultValueHolder(defaultValue);
/*      */         }
/* 1076 */         attributes.put(method.getName(), 
/* 1077 */           adaptValue(annotatedElement, attributeValue, classValuesAsString, nestedAnnotationsAsMap));
/*      */       }
/*      */       catch (Exception ex) {
/* 1080 */         if ((ex instanceof InvocationTargetException)) {
/* 1081 */           Throwable targetException = ((InvocationTargetException)ex).getTargetException();
/* 1082 */           rethrowAnnotationConfigurationException(targetException);
/*      */         }
/* 1084 */         throw new IllegalStateException("Could not obtain annotation attribute value for " + method, ex);
/*      */       }
/*      */     }
/*      */     
/* 1088 */     return attributes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static Object adaptValue(Object annotatedElement, Object value, boolean classValuesAsString, boolean nestedAnnotationsAsMap)
/*      */   {
/* 1110 */     if (classValuesAsString) {
/* 1111 */       if ((value instanceof Class)) {
/* 1112 */         return ((Class)value).getName();
/*      */       }
/* 1114 */       if ((value instanceof Class[])) {
/* 1115 */         Class<?>[] clazzArray = (Class[])value;
/* 1116 */         String[] classNames = new String[clazzArray.length];
/* 1117 */         for (int i = 0; i < clazzArray.length; i++) {
/* 1118 */           classNames[i] = clazzArray[i].getName();
/*      */         }
/* 1120 */         return classNames;
/*      */       }
/*      */     }
/*      */     
/* 1124 */     if ((value instanceof Annotation)) {
/* 1125 */       Annotation annotation = (Annotation)value;
/* 1126 */       if (nestedAnnotationsAsMap) {
/* 1127 */         return getAnnotationAttributes(annotatedElement, annotation, classValuesAsString, true);
/*      */       }
/*      */       
/* 1130 */       return synthesizeAnnotation(annotation, annotatedElement);
/*      */     }
/*      */     
/*      */ 
/* 1134 */     if ((value instanceof Annotation[])) {
/* 1135 */       Annotation[] annotations = (Annotation[])value;
/* 1136 */       if (nestedAnnotationsAsMap) {
/* 1137 */         AnnotationAttributes[] mappedAnnotations = new AnnotationAttributes[annotations.length];
/* 1138 */         for (int i = 0; i < annotations.length; i++)
/*      */         {
/* 1140 */           mappedAnnotations[i] = getAnnotationAttributes(annotatedElement, annotations[i], classValuesAsString, true);
/*      */         }
/* 1142 */         return mappedAnnotations;
/*      */       }
/*      */       
/* 1145 */       return synthesizeAnnotationArray(annotations, annotatedElement);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1150 */     return value;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void registerDefaultValues(AnnotationAttributes attributes)
/*      */   {
/* 1163 */     Class<? extends Annotation> annotationType = attributes.annotationType();
/* 1164 */     if ((annotationType != null) && (Modifier.isPublic(annotationType.getModifiers())))
/*      */     {
/* 1166 */       for (Method annotationAttribute : getAttributeMethods(annotationType)) {
/* 1167 */         String attributeName = annotationAttribute.getName();
/* 1168 */         Object defaultValue = annotationAttribute.getDefaultValue();
/* 1169 */         if ((defaultValue != null) && (!attributes.containsKey(attributeName))) {
/* 1170 */           if ((defaultValue instanceof Annotation)) {
/* 1171 */             defaultValue = getAnnotationAttributes((Annotation)defaultValue, false, true);
/*      */           }
/* 1173 */           else if ((defaultValue instanceof Annotation[])) {
/* 1174 */             Annotation[] realAnnotations = (Annotation[])defaultValue;
/* 1175 */             AnnotationAttributes[] mappedAnnotations = new AnnotationAttributes[realAnnotations.length];
/* 1176 */             for (int i = 0; i < realAnnotations.length; i++) {
/* 1177 */               mappedAnnotations[i] = getAnnotationAttributes(realAnnotations[i], false, true);
/*      */             }
/* 1179 */             defaultValue = mappedAnnotations;
/*      */           }
/* 1181 */           attributes.put(attributeName, new DefaultValueHolder(defaultValue));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void postProcessAnnotationAttributes(Object annotatedElement, AnnotationAttributes attributes, boolean classValuesAsString)
/*      */   {
/* 1207 */     postProcessAnnotationAttributes(annotatedElement, attributes, classValuesAsString, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void postProcessAnnotationAttributes(Object annotatedElement, AnnotationAttributes attributes, boolean classValuesAsString, boolean nestedAnnotationsAsMap)
/*      */   {
/* 1234 */     if (attributes == null) {
/* 1235 */       return;
/*      */     }
/*      */     
/* 1238 */     Class<? extends Annotation> annotationType = attributes.annotationType();
/*      */     
/*      */ 
/*      */ 
/* 1242 */     Set<String> valuesAlreadyReplaced = new HashSet();
/*      */     Map<String, List<String>> aliasMap;
/* 1244 */     if (!attributes.validated)
/*      */     {
/* 1246 */       aliasMap = getAttributeAliasMap(annotationType);
/* 1247 */       for (Iterator localIterator1 = aliasMap.keySet().iterator(); localIterator1.hasNext();) { attributeName = (String)localIterator1.next();
/* 1248 */         if (!valuesAlreadyReplaced.contains(attributeName))
/*      */         {
/*      */ 
/* 1251 */           value = attributes.get(attributeName);
/* 1252 */           valuePresent = (value != null) && (!(value instanceof DefaultValueHolder));
/*      */           
/* 1254 */           for (String aliasedAttributeName : (List)aliasMap.get(attributeName))
/* 1255 */             if (!valuesAlreadyReplaced.contains(aliasedAttributeName))
/*      */             {
/*      */ 
/*      */ 
/* 1259 */               Object aliasedValue = attributes.get(aliasedAttributeName);
/* 1260 */               boolean aliasPresent = (aliasedValue != null) && (!(aliasedValue instanceof DefaultValueHolder));
/*      */               
/*      */ 
/* 1263 */               if ((valuePresent) || (aliasPresent))
/* 1264 */                 if ((valuePresent) && (aliasPresent))
/*      */                 {
/* 1266 */                   if (!ObjectUtils.nullSafeEquals(value, aliasedValue))
/*      */                   {
/* 1268 */                     String elementAsString = annotatedElement != null ? annotatedElement.toString() : "unknown element";
/* 1269 */                     throw new AnnotationConfigurationException(String.format("In AnnotationAttributes for annotation [%s] declared on %s, attribute '%s' and its alias '%s' are declared with values of [%s] and [%s], but only one is permitted.", new Object[] {annotationType
/*      */                     
/*      */ 
/* 1272 */                       .getName(), elementAsString, attributeName, aliasedAttributeName, 
/* 1273 */                       ObjectUtils.nullSafeToString(value), 
/* 1274 */                       ObjectUtils.nullSafeToString(aliasedValue) }));
/*      */                   }
/*      */                 }
/* 1277 */                 else if (aliasPresent)
/*      */                 {
/* 1279 */                   attributes.put(attributeName, 
/* 1280 */                     adaptValue(annotatedElement, aliasedValue, classValuesAsString, nestedAnnotationsAsMap));
/* 1281 */                   valuesAlreadyReplaced.add(attributeName);
/*      */                 }
/*      */                 else
/*      */                 {
/* 1285 */                   attributes.put(aliasedAttributeName, 
/* 1286 */                     adaptValue(annotatedElement, value, classValuesAsString, nestedAnnotationsAsMap));
/* 1287 */                   valuesAlreadyReplaced.add(aliasedAttributeName);
/*      */                 } } } }
/*      */       String attributeName;
/*      */       Object value;
/*      */       boolean valuePresent;
/* 1292 */       attributes.validated = true;
/*      */     }
/*      */     
/*      */ 
/* 1296 */     for (String attributeName : attributes.keySet()) {
/* 1297 */       if (!valuesAlreadyReplaced.contains(attributeName))
/*      */       {
/*      */ 
/* 1300 */         Object value = attributes.get(attributeName);
/* 1301 */         if ((value instanceof DefaultValueHolder)) {
/* 1302 */           value = ((DefaultValueHolder)value).defaultValue;
/* 1303 */           attributes.put(attributeName, 
/* 1304 */             adaptValue(annotatedElement, value, classValuesAsString, nestedAnnotationsAsMap));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Object getValue(Annotation annotation)
/*      */   {
/* 1317 */     return getValue(annotation, "value");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Object getValue(Annotation annotation, String attributeName)
/*      */   {
/* 1328 */     if ((annotation == null) || (!StringUtils.hasText(attributeName))) {
/* 1329 */       return null;
/*      */     }
/*      */     try {
/* 1332 */       Method method = annotation.annotationType().getDeclaredMethod(attributeName, new Class[0]);
/* 1333 */       ReflectionUtils.makeAccessible(method);
/* 1334 */       return method.invoke(annotation, new Object[0]);
/*      */     }
/*      */     catch (Exception ex) {}
/* 1337 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Object getDefaultValue(Annotation annotation)
/*      */   {
/* 1349 */     return getDefaultValue(annotation, "value");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Object getDefaultValue(Annotation annotation, String attributeName)
/*      */   {
/* 1360 */     if (annotation == null) {
/* 1361 */       return null;
/*      */     }
/* 1363 */     return getDefaultValue(annotation.annotationType(), attributeName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Object getDefaultValue(Class<? extends Annotation> annotationType)
/*      */   {
/* 1374 */     return getDefaultValue(annotationType, "value");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Object getDefaultValue(Class<? extends Annotation> annotationType, String attributeName)
/*      */   {
/* 1386 */     if ((annotationType == null) || (!StringUtils.hasText(attributeName))) {
/* 1387 */       return null;
/*      */     }
/*      */     try {
/* 1390 */       return annotationType.getDeclaredMethod(attributeName, new Class[0]).getDefaultValue();
/*      */     }
/*      */     catch (Exception ex) {}
/* 1393 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static <A extends Annotation> A synthesizeAnnotation(A annotation)
/*      */   {
/* 1412 */     return synthesizeAnnotation(annotation, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <A extends Annotation> A synthesizeAnnotation(A annotation, AnnotatedElement annotatedElement)
/*      */   {
/* 1433 */     return synthesizeAnnotation(annotation, annotatedElement);
/*      */   }
/*      */   
/*      */   static <A extends Annotation> A synthesizeAnnotation(A annotation, Object annotatedElement)
/*      */   {
/* 1438 */     if (annotation == null) {
/* 1439 */       return null;
/*      */     }
/* 1441 */     if ((annotation instanceof SynthesizedAnnotation)) {
/* 1442 */       return annotation;
/*      */     }
/*      */     
/* 1445 */     Class<? extends Annotation> annotationType = annotation.annotationType();
/* 1446 */     if (!isSynthesizable(annotationType)) {
/* 1447 */       return annotation;
/*      */     }
/*      */     
/* 1450 */     DefaultAnnotationAttributeExtractor attributeExtractor = new DefaultAnnotationAttributeExtractor(annotation, annotatedElement);
/*      */     
/* 1452 */     InvocationHandler handler = new SynthesizedAnnotationInvocationHandler(attributeExtractor);
/*      */     
/*      */ 
/*      */ 
/* 1456 */     Class<?>[] exposedInterfaces = { annotationType, SynthesizedAnnotation.class };
/* 1457 */     return (Annotation)Proxy.newProxyInstance(annotation.getClass().getClassLoader(), exposedInterfaces, handler);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <A extends Annotation> A synthesizeAnnotation(Map<String, Object> attributes, Class<A> annotationType, AnnotatedElement annotatedElement)
/*      */   {
/* 1494 */     Assert.notNull(annotationType, "annotationType must not be null");
/* 1495 */     if (attributes == null) {
/* 1496 */       return null;
/*      */     }
/*      */     
/* 1499 */     MapAnnotationAttributeExtractor attributeExtractor = new MapAnnotationAttributeExtractor(attributes, annotationType, annotatedElement);
/*      */     
/* 1501 */     InvocationHandler handler = new SynthesizedAnnotationInvocationHandler(attributeExtractor);
/* 1502 */     Class<?>[] exposedInterfaces = { canExposeSynthesizedMarker(annotationType) ? new Class[] { annotationType, SynthesizedAnnotation.class } : annotationType };
/*      */     
/* 1504 */     return (Annotation)Proxy.newProxyInstance(annotationType.getClassLoader(), exposedInterfaces, handler);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <A extends Annotation> A synthesizeAnnotation(Class<A> annotationType)
/*      */   {
/* 1523 */     return synthesizeAnnotation(Collections.emptyMap(), annotationType, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static Annotation[] synthesizeAnnotationArray(Annotation[] annotations, Object annotatedElement)
/*      */   {
/* 1543 */     if (annotations == null) {
/* 1544 */       return null;
/*      */     }
/*      */     
/* 1547 */     Annotation[] synthesized = (Annotation[])Array.newInstance(annotations
/* 1548 */       .getClass().getComponentType(), annotations.length);
/* 1549 */     for (int i = 0; i < annotations.length; i++) {
/* 1550 */       synthesized[i] = synthesizeAnnotation(annotations[i], annotatedElement);
/*      */     }
/* 1552 */     return synthesized;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static <A extends Annotation> A[] synthesizeAnnotationArray(Map<String, Object>[] maps, Class<A> annotationType)
/*      */   {
/* 1574 */     Assert.notNull(annotationType, "annotationType must not be null");
/* 1575 */     if (maps == null) {
/* 1576 */       return null;
/*      */     }
/*      */     
/* 1579 */     A[] synthesized = (Annotation[])Array.newInstance(annotationType, maps.length);
/* 1580 */     for (int i = 0; i < maps.length; i++) {
/* 1581 */       synthesized[i] = synthesizeAnnotation(maps[i], annotationType, null);
/*      */     }
/* 1583 */     return synthesized;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static Map<String, List<String>> getAttributeAliasMap(Class<? extends Annotation> annotationType)
/*      */   {
/* 1606 */     if (annotationType == null) {
/* 1607 */       return Collections.emptyMap();
/*      */     }
/*      */     
/* 1610 */     Map<String, List<String>> map = (Map)attributeAliasesCache.get(annotationType);
/* 1611 */     if (map != null) {
/* 1612 */       return map;
/*      */     }
/*      */     
/* 1615 */     map = new LinkedHashMap();
/* 1616 */     for (Method attribute : getAttributeMethods(annotationType)) {
/* 1617 */       List<String> aliasNames = getAttributeAliasNames(attribute);
/* 1618 */       if (!aliasNames.isEmpty()) {
/* 1619 */         map.put(attribute.getName(), aliasNames);
/*      */       }
/*      */     }
/*      */     
/* 1623 */     attributeAliasesCache.put(annotationType, map);
/* 1624 */     return map;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static boolean canExposeSynthesizedMarker(Class<? extends Annotation> annotationType)
/*      */   {
/*      */     try
/*      */     {
/* 1633 */       return Class.forName(SynthesizedAnnotation.class.getName(), false, annotationType.getClassLoader()) == SynthesizedAnnotation.class;
/*      */     }
/*      */     catch (ClassNotFoundException ex) {}
/*      */     
/* 1637 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static boolean isSynthesizable(Class<? extends Annotation> annotationType)
/*      */   {
/* 1656 */     Boolean synthesizable = (Boolean)synthesizableCache.get(annotationType);
/* 1657 */     if (synthesizable != null) {
/* 1658 */       return synthesizable.booleanValue();
/*      */     }
/*      */     
/* 1661 */     synthesizable = Boolean.FALSE;
/* 1662 */     for (Method attribute : getAttributeMethods(annotationType)) {
/* 1663 */       if (!getAttributeAliasNames(attribute).isEmpty()) {
/* 1664 */         synthesizable = Boolean.TRUE;
/* 1665 */         break;
/*      */       }
/* 1667 */       Class<?> returnType = attribute.getReturnType();
/* 1668 */       if (Annotation[].class.isAssignableFrom(returnType))
/*      */       {
/* 1670 */         Class<? extends Annotation> nestedAnnotationType = returnType.getComponentType();
/* 1671 */         if (isSynthesizable(nestedAnnotationType)) {
/* 1672 */           synthesizable = Boolean.TRUE;
/* 1673 */           break;
/*      */         }
/*      */       }
/* 1676 */       else if (Annotation.class.isAssignableFrom(returnType)) {
/* 1677 */         Class<? extends Annotation> nestedAnnotationType = returnType;
/* 1678 */         if (isSynthesizable(nestedAnnotationType)) {
/* 1679 */           synthesizable = Boolean.TRUE;
/* 1680 */           break;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1685 */     synthesizableCache.put(annotationType, synthesizable);
/* 1686 */     return synthesizable.booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static List<String> getAttributeAliasNames(Method attribute)
/*      */   {
/* 1703 */     Assert.notNull(attribute, "attribute must not be null");
/* 1704 */     AliasDescriptor descriptor = AliasDescriptor.from(attribute);
/* 1705 */     return descriptor != null ? descriptor.getAttributeAliasNames() : Collections.emptyList();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static String getAttributeOverrideName(Method attribute, Class<? extends Annotation> metaAnnotationType)
/*      */   {
/* 1725 */     Assert.notNull(attribute, "attribute must not be null");
/* 1726 */     Assert.notNull(metaAnnotationType, "metaAnnotationType must not be null");
/* 1727 */     Assert.isTrue(Annotation.class != metaAnnotationType, "metaAnnotationType must not be [java.lang.annotation.Annotation]");
/*      */     
/*      */ 
/* 1730 */     AliasDescriptor descriptor = AliasDescriptor.from(attribute);
/* 1731 */     return descriptor != null ? descriptor.getAttributeOverrideName(metaAnnotationType) : null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static List<Method> getAttributeMethods(Class<? extends Annotation> annotationType)
/*      */   {
/* 1746 */     List<Method> methods = (List)attributeMethodsCache.get(annotationType);
/* 1747 */     if (methods != null) {
/* 1748 */       return methods;
/*      */     }
/*      */     
/* 1751 */     methods = new ArrayList();
/* 1752 */     for (Method method : annotationType.getDeclaredMethods()) {
/* 1753 */       if (isAttributeMethod(method)) {
/* 1754 */         ReflectionUtils.makeAccessible(method);
/* 1755 */         methods.add(method);
/*      */       }
/*      */     }
/*      */     
/* 1759 */     attributeMethodsCache.put(annotationType, methods);
/* 1760 */     return methods;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static Annotation getAnnotation(AnnotatedElement element, String annotationName)
/*      */   {
/* 1773 */     for (Annotation annotation : element.getAnnotations()) {
/* 1774 */       if (annotation.annotationType().getName().equals(annotationName)) {
/* 1775 */         return annotation;
/*      */       }
/*      */     }
/* 1778 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static boolean isAttributeMethod(Method method)
/*      */   {
/* 1788 */     return (method != null) && (method.getParameterTypes().length == 0) && (method.getReturnType() != Void.TYPE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static boolean isAnnotationTypeMethod(Method method)
/*      */   {
/* 1798 */     return (method != null) && (method.getName().equals("annotationType")) && (method.getParameterTypes().length == 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static Class<? extends Annotation> resolveContainerAnnotationType(Class<? extends Annotation> annotationType)
/*      */   {
/*      */     try
/*      */     {
/* 1812 */       Annotation repeatable = getAnnotation(annotationType, "java.lang.annotation.Repeatable");
/* 1813 */       if (repeatable != null) {
/* 1814 */         Object value = getValue(repeatable);
/* 1815 */         return (Class)value;
/*      */       }
/*      */     }
/*      */     catch (Exception ex) {
/* 1819 */       handleIntrospectionFailure(annotationType, ex);
/*      */     }
/* 1821 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void rethrowAnnotationConfigurationException(Throwable ex)
/*      */   {
/* 1833 */     if ((ex instanceof AnnotationConfigurationException)) {
/* 1834 */       throw ((AnnotationConfigurationException)ex);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void handleIntrospectionFailure(AnnotatedElement element, Exception ex)
/*      */   {
/* 1853 */     rethrowAnnotationConfigurationException(ex);
/*      */     
/* 1855 */     Log loggerToUse = logger;
/* 1856 */     if (loggerToUse == null) {
/* 1857 */       loggerToUse = LogFactory.getLog(AnnotationUtils.class);
/* 1858 */       logger = loggerToUse;
/*      */     }
/* 1860 */     if (((element instanceof Class)) && (Annotation.class.isAssignableFrom((Class)element)))
/*      */     {
/* 1862 */       if (loggerToUse.isDebugEnabled()) {
/* 1863 */         loggerToUse.debug("Failed to introspect meta-annotations on [" + element + "]: " + ex);
/*      */       }
/*      */       
/*      */ 
/*      */     }
/* 1868 */     else if (loggerToUse.isInfoEnabled()) {
/* 1869 */       loggerToUse.info("Failed to introspect annotations on [" + element + "]: " + ex);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static final class AnnotationCacheKey
/*      */     implements Comparable<AnnotationCacheKey>
/*      */   {
/*      */     private final AnnotatedElement element;
/*      */     
/*      */     private final Class<? extends Annotation> annotationType;
/*      */     
/*      */ 
/*      */     public AnnotationCacheKey(AnnotatedElement element, Class<? extends Annotation> annotationType)
/*      */     {
/* 1885 */       this.element = element;
/* 1886 */       this.annotationType = annotationType;
/*      */     }
/*      */     
/*      */     public boolean equals(Object other)
/*      */     {
/* 1891 */       if (this == other) {
/* 1892 */         return true;
/*      */       }
/* 1894 */       if (!(other instanceof AnnotationCacheKey)) {
/* 1895 */         return false;
/*      */       }
/* 1897 */       AnnotationCacheKey otherKey = (AnnotationCacheKey)other;
/* 1898 */       return (this.element.equals(otherKey.element)) && (this.annotationType.equals(otherKey.annotationType));
/*      */     }
/*      */     
/*      */     public int hashCode()
/*      */     {
/* 1903 */       return this.element.hashCode() * 29 + this.annotationType.hashCode();
/*      */     }
/*      */     
/*      */     public String toString()
/*      */     {
/* 1908 */       return "@" + this.annotationType + " on " + this.element;
/*      */     }
/*      */     
/*      */     public int compareTo(AnnotationCacheKey other)
/*      */     {
/* 1913 */       int result = this.element.toString().compareTo(other.element.toString());
/* 1914 */       if (result == 0) {
/* 1915 */         result = this.annotationType.getName().compareTo(other.annotationType.getName());
/*      */       }
/* 1917 */       return result;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static class AnnotationCollector<A extends Annotation>
/*      */   {
/*      */     private final Class<A> annotationType;
/*      */     
/*      */     private final Class<? extends Annotation> containerAnnotationType;
/*      */     
/*      */     private final boolean declaredMode;
/*      */     
/* 1930 */     private final Set<AnnotatedElement> visited = new HashSet();
/*      */     
/* 1932 */     private final Set<A> result = new LinkedHashSet();
/*      */     
/*      */     AnnotationCollector(Class<A> annotationType, Class<? extends Annotation> containerAnnotationType, boolean declaredMode) {
/* 1935 */       this.annotationType = annotationType;
/* 1936 */       this.containerAnnotationType = (containerAnnotationType != null ? containerAnnotationType : 
/* 1937 */         AnnotationUtils.resolveContainerAnnotationType(annotationType));
/* 1938 */       this.declaredMode = declaredMode;
/*      */     }
/*      */     
/*      */     Set<A> getResult(AnnotatedElement element) {
/* 1942 */       process(element);
/* 1943 */       return Collections.unmodifiableSet(this.result);
/*      */     }
/*      */     
/*      */     private void process(AnnotatedElement element)
/*      */     {
/* 1948 */       if (this.visited.add(element)) {
/*      */         try {
/* 1950 */           Annotation[] annotations = this.declaredMode ? element.getDeclaredAnnotations() : element.getAnnotations();
/* 1951 */           for (Annotation ann : annotations) {
/* 1952 */             Class<? extends Annotation> currentAnnotationType = ann.annotationType();
/* 1953 */             if (ObjectUtils.nullSafeEquals(this.annotationType, currentAnnotationType)) {
/* 1954 */               this.result.add(AnnotationUtils.synthesizeAnnotation(ann, element));
/*      */             }
/* 1956 */             else if (ObjectUtils.nullSafeEquals(this.containerAnnotationType, currentAnnotationType)) {
/* 1957 */               this.result.addAll(getValue(element, ann));
/*      */             }
/* 1959 */             else if (!AnnotationUtils.isInJavaLangAnnotationPackage(ann)) {
/* 1960 */               process(currentAnnotationType);
/*      */             }
/*      */           }
/*      */         }
/*      */         catch (Exception ex) {
/* 1965 */           AnnotationUtils.handleIntrospectionFailure(element, ex);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     private List<A> getValue(AnnotatedElement element, Annotation annotation)
/*      */     {
/*      */       try {
/* 1973 */         List<A> synthesizedAnnotations = new ArrayList();
/* 1974 */         for (A anno : (Annotation[])AnnotationUtils.getValue(annotation)) {
/* 1975 */           synthesizedAnnotations.add(AnnotationUtils.synthesizeAnnotation(anno, element));
/*      */         }
/* 1977 */         return synthesizedAnnotations;
/*      */       }
/*      */       catch (Exception ex) {
/* 1980 */         AnnotationUtils.handleIntrospectionFailure(element, ex);
/*      */       }
/*      */       
/* 1983 */       return Collections.emptyList();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class AliasDescriptor
/*      */   {
/*      */     private final Method sourceAttribute;
/*      */     
/*      */ 
/*      */ 
/*      */     private final Class<? extends Annotation> sourceAnnotationType;
/*      */     
/*      */ 
/*      */ 
/*      */     private final String sourceAttributeName;
/*      */     
/*      */ 
/*      */ 
/*      */     private final Method aliasedAttribute;
/*      */     
/*      */ 
/*      */ 
/*      */     private final Class<? extends Annotation> aliasedAnnotationType;
/*      */     
/*      */ 
/*      */ 
/*      */     private final String aliasedAttributeName;
/*      */     
/*      */ 
/*      */ 
/*      */     private final boolean isAliasPair;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public static AliasDescriptor from(Method attribute)
/*      */     {
/* 2024 */       AliasDescriptor descriptor = (AliasDescriptor)AnnotationUtils.aliasDescriptorCache.get(attribute);
/* 2025 */       if (descriptor != null) {
/* 2026 */         return descriptor;
/*      */       }
/*      */       
/* 2029 */       AliasFor aliasFor = (AliasFor)attribute.getAnnotation(AliasFor.class);
/* 2030 */       if (aliasFor == null) {
/* 2031 */         return null;
/*      */       }
/*      */       
/* 2034 */       descriptor = new AliasDescriptor(attribute, aliasFor);
/* 2035 */       descriptor.validate();
/* 2036 */       AnnotationUtils.aliasDescriptorCache.put(attribute, descriptor);
/* 2037 */       return descriptor;
/*      */     }
/*      */     
/*      */     private AliasDescriptor(Method sourceAttribute, AliasFor aliasFor)
/*      */     {
/* 2042 */       Class<?> declaringClass = sourceAttribute.getDeclaringClass();
/* 2043 */       Assert.isTrue(declaringClass.isAnnotation(), "sourceAttribute must be from an annotation");
/*      */       
/* 2045 */       this.sourceAttribute = sourceAttribute;
/* 2046 */       this.sourceAnnotationType = declaringClass;
/* 2047 */       this.sourceAttributeName = sourceAttribute.getName();
/*      */       
/*      */ 
/* 2050 */       this.aliasedAnnotationType = (Annotation.class == aliasFor.annotation() ? this.sourceAnnotationType : aliasFor.annotation());
/* 2051 */       this.aliasedAttributeName = getAliasedAttributeName(aliasFor, sourceAttribute);
/* 2052 */       if ((this.aliasedAnnotationType == this.sourceAnnotationType) && 
/* 2053 */         (this.aliasedAttributeName.equals(this.sourceAttributeName))) {
/* 2054 */         String msg = String.format("@AliasFor declaration on attribute '%s' in annotation [%s] points to itself. Specify 'annotation' to point to a same-named attribute on a meta-annotation.", new Object[] {sourceAttribute
/*      */         
/* 2056 */           .getName(), declaringClass.getName() });
/* 2057 */         throw new AnnotationConfigurationException(msg);
/*      */       }
/*      */       try {
/* 2060 */         this.aliasedAttribute = this.aliasedAnnotationType.getDeclaredMethod(this.aliasedAttributeName, new Class[0]);
/*      */       }
/*      */       catch (NoSuchMethodException ex) {
/* 2063 */         String msg = String.format("Attribute '%s' in annotation [%s] is declared as an @AliasFor nonexistent attribute '%s' in annotation [%s].", new Object[] { this.sourceAttributeName, this.sourceAnnotationType
/*      */         
/* 2065 */           .getName(), this.aliasedAttributeName, this.aliasedAnnotationType
/* 2066 */           .getName() });
/* 2067 */         throw new AnnotationConfigurationException(msg, ex);
/*      */       }
/*      */       
/* 2070 */       this.isAliasPair = (this.sourceAnnotationType == this.aliasedAnnotationType);
/*      */     }
/*      */     
/*      */     private void validate()
/*      */     {
/* 2075 */       if ((!this.isAliasPair) && (!AnnotationUtils.isAnnotationMetaPresent(this.sourceAnnotationType, this.aliasedAnnotationType))) {
/* 2076 */         String msg = String.format("@AliasFor declaration on attribute '%s' in annotation [%s] declares an alias for attribute '%s' in meta-annotation [%s] which is not meta-present.", new Object[] { this.sourceAttributeName, this.sourceAnnotationType
/*      */         
/* 2078 */           .getName(), this.aliasedAttributeName, this.aliasedAnnotationType
/* 2079 */           .getName() });
/* 2080 */         throw new AnnotationConfigurationException(msg);
/*      */       }
/*      */       
/* 2083 */       if (this.isAliasPair) {
/* 2084 */         AliasFor mirrorAliasFor = (AliasFor)this.aliasedAttribute.getAnnotation(AliasFor.class);
/* 2085 */         if (mirrorAliasFor == null) {
/* 2086 */           String msg = String.format("Attribute '%s' in annotation [%s] must be declared as an @AliasFor [%s].", new Object[] { this.aliasedAttributeName, this.sourceAnnotationType
/* 2087 */             .getName(), this.sourceAttributeName });
/* 2088 */           throw new AnnotationConfigurationException(msg);
/*      */         }
/*      */         
/* 2091 */         String mirrorAliasedAttributeName = getAliasedAttributeName(mirrorAliasFor, this.aliasedAttribute);
/* 2092 */         if (!this.sourceAttributeName.equals(mirrorAliasedAttributeName)) {
/* 2093 */           String msg = String.format("Attribute '%s' in annotation [%s] must be declared as an @AliasFor [%s], not [%s].", new Object[] { this.aliasedAttributeName, this.sourceAnnotationType
/* 2094 */             .getName(), this.sourceAttributeName, mirrorAliasedAttributeName });
/*      */           
/* 2096 */           throw new AnnotationConfigurationException(msg);
/*      */         }
/*      */       }
/*      */       
/* 2100 */       Class<?> returnType = this.sourceAttribute.getReturnType();
/* 2101 */       Class<?> aliasedReturnType = this.aliasedAttribute.getReturnType();
/* 2102 */       if ((returnType != aliasedReturnType) && (
/* 2103 */         (!aliasedReturnType.isArray()) || (returnType != aliasedReturnType.getComponentType()))) {
/* 2104 */         String msg = String.format("Misconfigured aliases: attribute '%s' in annotation [%s] and attribute '%s' in annotation [%s] must declare the same return type.", new Object[] { this.sourceAttributeName, this.sourceAnnotationType
/*      */         
/* 2106 */           .getName(), this.aliasedAttributeName, this.aliasedAnnotationType
/* 2107 */           .getName() });
/* 2108 */         throw new AnnotationConfigurationException(msg);
/*      */       }
/*      */       
/* 2111 */       if (this.isAliasPair) {
/* 2112 */         validateDefaultValueConfiguration(this.aliasedAttribute);
/*      */       }
/*      */     }
/*      */     
/*      */     private void validateDefaultValueConfiguration(Method aliasedAttribute) {
/* 2117 */       Assert.notNull(aliasedAttribute, "aliasedAttribute must not be null");
/* 2118 */       Object defaultValue = this.sourceAttribute.getDefaultValue();
/* 2119 */       Object aliasedDefaultValue = aliasedAttribute.getDefaultValue();
/*      */       
/* 2121 */       if ((defaultValue == null) || (aliasedDefaultValue == null)) {
/* 2122 */         String msg = String.format("Misconfigured aliases: attribute '%s' in annotation [%s] and attribute '%s' in annotation [%s] must declare default values.", new Object[] { this.sourceAttributeName, this.sourceAnnotationType
/*      */         
/* 2124 */           .getName(), aliasedAttribute.getName(), aliasedAttribute
/* 2125 */           .getDeclaringClass().getName() });
/* 2126 */         throw new AnnotationConfigurationException(msg);
/*      */       }
/*      */       
/* 2129 */       if (!ObjectUtils.nullSafeEquals(defaultValue, aliasedDefaultValue)) {
/* 2130 */         String msg = String.format("Misconfigured aliases: attribute '%s' in annotation [%s] and attribute '%s' in annotation [%s] must declare the same default value.", new Object[] { this.sourceAttributeName, this.sourceAnnotationType
/*      */         
/* 2132 */           .getName(), aliasedAttribute.getName(), aliasedAttribute
/* 2133 */           .getDeclaringClass().getName() });
/* 2134 */         throw new AnnotationConfigurationException(msg);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private void validateAgainst(AliasDescriptor otherDescriptor)
/*      */     {
/* 2145 */       validateDefaultValueConfiguration(otherDescriptor.sourceAttribute);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private boolean isOverrideFor(Class<? extends Annotation> metaAnnotationType)
/*      */     {
/* 2154 */       return this.aliasedAnnotationType == metaAnnotationType;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private boolean isAliasFor(AliasDescriptor otherDescriptor)
/*      */     {
/* 2169 */       for (AliasDescriptor lhs = this; lhs != null; lhs = lhs.getAttributeOverrideDescriptor()) {
/* 2170 */         for (AliasDescriptor rhs = otherDescriptor; rhs != null; rhs = rhs.getAttributeOverrideDescriptor()) {
/* 2171 */           if (lhs.aliasedAttribute.equals(rhs.aliasedAttribute)) {
/* 2172 */             return true;
/*      */           }
/*      */         }
/*      */       }
/* 2176 */       return false;
/*      */     }
/*      */     
/*      */     public List<String> getAttributeAliasNames()
/*      */     {
/* 2181 */       if (this.isAliasPair) {
/* 2182 */         return Collections.singletonList(this.aliasedAttributeName);
/*      */       }
/*      */       
/*      */ 
/* 2186 */       List<String> aliases = new ArrayList();
/* 2187 */       for (AliasDescriptor otherDescriptor : getOtherDescriptors()) {
/* 2188 */         if (isAliasFor(otherDescriptor)) {
/* 2189 */           validateAgainst(otherDescriptor);
/* 2190 */           aliases.add(otherDescriptor.sourceAttributeName);
/*      */         }
/*      */       }
/* 2193 */       return aliases;
/*      */     }
/*      */     
/*      */     private List<AliasDescriptor> getOtherDescriptors() {
/* 2197 */       List<AliasDescriptor> otherDescriptors = new ArrayList();
/* 2198 */       for (Method currentAttribute : AnnotationUtils.getAttributeMethods(this.sourceAnnotationType)) {
/* 2199 */         if (!this.sourceAttribute.equals(currentAttribute)) {
/* 2200 */           AliasDescriptor otherDescriptor = from(currentAttribute);
/* 2201 */           if (otherDescriptor != null) {
/* 2202 */             otherDescriptors.add(otherDescriptor);
/*      */           }
/*      */         }
/*      */       }
/* 2206 */       return otherDescriptors;
/*      */     }
/*      */     
/*      */     public String getAttributeOverrideName(Class<? extends Annotation> metaAnnotationType) {
/* 2210 */       Assert.notNull(metaAnnotationType, "metaAnnotationType must not be null");
/* 2211 */       Assert.isTrue(Annotation.class != metaAnnotationType, "metaAnnotationType must not be [java.lang.annotation.Annotation]");
/*      */       
/*      */ 
/*      */ 
/* 2215 */       for (AliasDescriptor desc = this; desc != null; desc = desc.getAttributeOverrideDescriptor()) {
/* 2216 */         if (desc.isOverrideFor(metaAnnotationType)) {
/* 2217 */           return desc.aliasedAttributeName;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 2222 */       return null;
/*      */     }
/*      */     
/*      */     private AliasDescriptor getAttributeOverrideDescriptor() {
/* 2226 */       if (this.isAliasPair) {
/* 2227 */         return null;
/*      */       }
/* 2229 */       return from(this.aliasedAttribute);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private String getAliasedAttributeName(AliasFor aliasFor, Method attribute)
/*      */     {
/* 2249 */       String attributeName = aliasFor.attribute();
/* 2250 */       String value = aliasFor.value();
/* 2251 */       boolean attributeDeclared = StringUtils.hasText(attributeName);
/* 2252 */       boolean valueDeclared = StringUtils.hasText(value);
/*      */       
/*      */ 
/* 2255 */       if ((attributeDeclared) && (valueDeclared)) {
/* 2256 */         String msg = String.format("In @AliasFor declared on attribute '%s' in annotation [%s], attribute 'attribute' and its alias 'value' are present with values of [%s] and [%s], but only one is permitted.", new Object[] {attribute
/*      */         
/* 2258 */           .getName(), attribute.getDeclaringClass().getName(), attributeName, value });
/* 2259 */         throw new AnnotationConfigurationException(msg);
/*      */       }
/*      */       
/*      */ 
/* 2263 */       attributeName = attributeDeclared ? attributeName : value;
/* 2264 */       return StringUtils.hasText(attributeName) ? attributeName.trim() : attribute.getName();
/*      */     }
/*      */     
/*      */     public String toString()
/*      */     {
/* 2269 */       return String.format("%s: @%s(%s) is an alias for @%s(%s)", new Object[] { getClass().getSimpleName(), this.sourceAnnotationType
/* 2270 */         .getSimpleName(), this.sourceAttributeName, this.aliasedAnnotationType
/* 2271 */         .getSimpleName(), this.aliasedAttributeName });
/*      */     }
/*      */   }
/*      */   
/*      */   private static class DefaultValueHolder
/*      */   {
/*      */     final Object defaultValue;
/*      */     
/*      */     public DefaultValueHolder(Object defaultValue)
/*      */     {
/* 2281 */       this.defaultValue = defaultValue;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-core-4.3.2.RELEASE.jar!\org\springframework\core\annotation\AnnotationUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */