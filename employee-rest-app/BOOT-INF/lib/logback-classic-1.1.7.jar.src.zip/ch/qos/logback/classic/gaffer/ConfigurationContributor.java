package ch.qos.logback.classic.gaffer;

import java.util.Map;

public abstract interface ConfigurationContributor
{
  public abstract Map<String, String> getMappings();
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\logback-classic-1.1.7.jar!\ch\qos\logback\classic\gaffer\ConfigurationContributor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */