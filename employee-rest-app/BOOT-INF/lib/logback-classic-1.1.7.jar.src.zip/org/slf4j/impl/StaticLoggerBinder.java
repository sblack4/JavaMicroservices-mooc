/*     */ package org.slf4j.impl;
/*     */ 
/*     */ import ch.qos.logback.classic.LoggerContext;
/*     */ import ch.qos.logback.classic.selector.ContextSelector;
/*     */ import ch.qos.logback.classic.util.ContextInitializer;
/*     */ import ch.qos.logback.classic.util.ContextSelectorStaticBinder;
/*     */ import ch.qos.logback.core.joran.spi.JoranException;
/*     */ import ch.qos.logback.core.status.StatusUtil;
/*     */ import ch.qos.logback.core.util.StatusPrinter;
/*     */ import org.slf4j.ILoggerFactory;
/*     */ import org.slf4j.helpers.Util;
/*     */ import org.slf4j.spi.LoggerFactoryBinder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StaticLoggerBinder
/*     */   implements LoggerFactoryBinder
/*     */ {
/*  43 */   public static String REQUESTED_API_VERSION = "1.7.16";
/*     */   
/*     */ 
/*     */ 
/*     */   static final String NULL_CS_URL = "http://logback.qos.ch/codes.html#null_CS";
/*     */   
/*     */ 
/*  50 */   private static StaticLoggerBinder SINGLETON = new StaticLoggerBinder();
/*     */   
/*  52 */   private static Object KEY = new Object();
/*     */   
/*     */   static {
/*  55 */     SINGLETON.init();
/*     */   }
/*     */   
/*  58 */   private boolean initialized = false;
/*  59 */   private LoggerContext defaultLoggerContext = new LoggerContext();
/*  60 */   private final ContextSelectorStaticBinder contextSelectorBinder = ContextSelectorStaticBinder.getSingleton();
/*     */   
/*     */   private StaticLoggerBinder() {
/*  63 */     this.defaultLoggerContext.setName("default");
/*     */   }
/*     */   
/*     */   public static StaticLoggerBinder getSingleton() {
/*  67 */     return SINGLETON;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static void reset()
/*     */   {
/*  74 */     SINGLETON = new StaticLoggerBinder();
/*  75 */     SINGLETON.init();
/*     */   }
/*     */   
/*     */   void init()
/*     */   {
/*     */     try
/*     */     {
/*     */       try
/*     */       {
/*  84 */         new ContextInitializer(this.defaultLoggerContext).autoConfig();
/*     */       } catch (JoranException je) {
/*  86 */         Util.report("Failed to auto configure default logger context", je);
/*     */       }
/*     */       
/*  89 */       if (!StatusUtil.contextHasStatusListener(this.defaultLoggerContext)) {
/*  90 */         StatusPrinter.printInCaseOfErrorsOrWarnings(this.defaultLoggerContext);
/*     */       }
/*  92 */       this.contextSelectorBinder.init(this.defaultLoggerContext, KEY);
/*  93 */       this.initialized = true;
/*     */     }
/*     */     catch (Throwable t) {
/*  96 */       Util.report("Failed to instantiate [" + LoggerContext.class.getName() + "]", t);
/*     */     }
/*     */   }
/*     */   
/*     */   public ILoggerFactory getLoggerFactory() {
/* 101 */     if (!this.initialized) {
/* 102 */       return this.defaultLoggerContext;
/*     */     }
/*     */     
/* 105 */     if (this.contextSelectorBinder.getContextSelector() == null) {
/* 106 */       throw new IllegalStateException("contextSelector cannot be null. See also http://logback.qos.ch/codes.html#null_CS");
/*     */     }
/* 108 */     return this.contextSelectorBinder.getContextSelector().getLoggerContext();
/*     */   }
/*     */   
/*     */   public String getLoggerFactoryClassStr() {
/* 112 */     return this.contextSelectorBinder.getClass().getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\logback-classic-1.1.7.jar!\org\slf4j\impl\StaticLoggerBinder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */