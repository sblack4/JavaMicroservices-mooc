/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpServletResponseWrapper;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.web.filter.OncePerRequestFilter;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceUrlEncodingFilter
/*     */   extends OncePerRequestFilter
/*     */ {
/*  46 */   private static final Log logger = LogFactory.getLog(ResourceUrlEncodingFilter.class);
/*     */   
/*     */ 
/*     */ 
/*     */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/*  53 */     filterChain.doFilter(request, new ResourceUrlEncodingResponseWrapper(request, response));
/*     */   }
/*     */   
/*     */ 
/*     */   private static class ResourceUrlEncodingResponseWrapper
/*     */     extends HttpServletResponseWrapper
/*     */   {
/*     */     private final HttpServletRequest request;
/*     */     
/*     */     private Integer indexLookupPath;
/*     */     private String prefixLookupPath;
/*     */     
/*     */     public ResourceUrlEncodingResponseWrapper(HttpServletRequest request, HttpServletResponse wrapped)
/*     */     {
/*  67 */       super();
/*  68 */       this.request = request;
/*     */     }
/*     */     
/*     */     public String encodeURL(String url)
/*     */     {
/*  73 */       ResourceUrlProvider resourceUrlProvider = getResourceUrlProvider();
/*  74 */       if (resourceUrlProvider == null) {
/*  75 */         ResourceUrlEncodingFilter.logger.debug("Request attribute exposing ResourceUrlProvider not found");
/*  76 */         return super.encodeURL(url);
/*     */       }
/*     */       
/*  79 */       initLookupPath(resourceUrlProvider);
/*  80 */       if (url.startsWith(this.prefixLookupPath)) {
/*  81 */         int suffixIndex = getQueryParamsIndex(url);
/*  82 */         String suffix = url.substring(suffixIndex);
/*  83 */         String lookupPath = url.substring(this.indexLookupPath.intValue(), suffixIndex);
/*  84 */         lookupPath = resourceUrlProvider.getForLookupPath(lookupPath);
/*  85 */         if (lookupPath != null) {
/*  86 */           return super.encodeURL(this.prefixLookupPath + lookupPath + suffix);
/*     */         }
/*     */       }
/*     */       
/*  90 */       return super.encodeURL(url);
/*     */     }
/*     */     
/*     */     private ResourceUrlProvider getResourceUrlProvider() {
/*  94 */       return (ResourceUrlProvider)this.request.getAttribute(ResourceUrlProviderExposingInterceptor.RESOURCE_URL_PROVIDER_ATTR);
/*     */     }
/*     */     
/*     */     private void initLookupPath(ResourceUrlProvider urlProvider)
/*     */     {
/*  99 */       if (this.indexLookupPath == null) {
/* 100 */         UrlPathHelper pathHelper = urlProvider.getUrlPathHelper();
/* 101 */         String requestUri = pathHelper.getRequestUri(this.request);
/* 102 */         String lookupPath = pathHelper.getLookupPathForRequest(this.request);
/* 103 */         this.indexLookupPath = Integer.valueOf(requestUri.lastIndexOf(lookupPath));
/* 104 */         this.prefixLookupPath = requestUri.substring(0, this.indexLookupPath.intValue());
/*     */         
/* 106 */         if (("/".equals(lookupPath)) && (!"/".equals(requestUri))) {
/* 107 */           String contextPath = pathHelper.getContextPath(this.request);
/* 108 */           if (requestUri.equals(contextPath)) {
/* 109 */             this.indexLookupPath = Integer.valueOf(requestUri.length());
/* 110 */             this.prefixLookupPath = requestUri;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private int getQueryParamsIndex(String url) {
/* 117 */       int index = url.indexOf("?");
/* 118 */       return index > 0 ? index : url.length();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\resource\ResourceUrlEncodingFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */