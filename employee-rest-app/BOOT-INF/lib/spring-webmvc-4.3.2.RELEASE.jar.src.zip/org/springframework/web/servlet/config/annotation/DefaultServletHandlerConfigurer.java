/*    */ package org.springframework.web.servlet.config.annotation;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.servlet.ServletContext;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.HttpRequestHandler;
/*    */ import org.springframework.web.servlet.handler.AbstractHandlerMapping;
/*    */ import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
/*    */ import org.springframework.web.servlet.resource.DefaultServletHttpRequestHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultServletHandlerConfigurer
/*    */ {
/*    */   private final ServletContext servletContext;
/*    */   private DefaultServletHttpRequestHandler handler;
/*    */   
/*    */   public DefaultServletHandlerConfigurer(ServletContext servletContext)
/*    */   {
/* 53 */     Assert.notNull(servletContext, "A ServletContext is required to configure default servlet handling");
/* 54 */     this.servletContext = servletContext;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void enable()
/*    */   {
/* 64 */     enable(null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void enable(String defaultServletName)
/*    */   {
/* 73 */     this.handler = new DefaultServletHttpRequestHandler();
/* 74 */     this.handler.setDefaultServletName(defaultServletName);
/* 75 */     this.handler.setServletContext(this.servletContext);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected AbstractHandlerMapping getHandlerMapping()
/*    */   {
/* 84 */     if (this.handler == null) {
/* 85 */       return null;
/*    */     }
/*    */     
/* 88 */     Map<String, HttpRequestHandler> urlMap = new HashMap();
/* 89 */     urlMap.put("/**", this.handler);
/*    */     
/* 91 */     SimpleUrlHandlerMapping handlerMapping = new SimpleUrlHandlerMapping();
/* 92 */     handlerMapping.setOrder(Integer.MAX_VALUE);
/* 93 */     handlerMapping.setUrlMap(urlMap);
/* 94 */     return handlerMapping;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\config\annotation\DefaultServletHandlerConfigurer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */