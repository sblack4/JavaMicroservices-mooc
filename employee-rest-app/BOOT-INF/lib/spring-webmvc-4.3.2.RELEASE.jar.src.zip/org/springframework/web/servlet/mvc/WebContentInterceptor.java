/*     */ package org.springframework.web.servlet.mvc;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.http.CacheControl;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.web.servlet.HandlerInterceptor;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.support.WebContentGenerator;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebContentInterceptor
/*     */   extends WebContentGenerator
/*     */   implements HandlerInterceptor
/*     */ {
/*  54 */   private UrlPathHelper urlPathHelper = new UrlPathHelper();
/*     */   
/*  56 */   private PathMatcher pathMatcher = new AntPathMatcher();
/*     */   
/*  58 */   private Map<String, Integer> cacheMappings = new HashMap();
/*     */   
/*  60 */   private Map<String, CacheControl> cacheControlMappings = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */   public WebContentInterceptor()
/*     */   {
/*  66 */     super(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAlwaysUseFullPath(boolean alwaysUseFullPath)
/*     */   {
/*  80 */     this.urlPathHelper.setAlwaysUseFullPath(alwaysUseFullPath);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUrlDecode(boolean urlDecode)
/*     */   {
/*  94 */     this.urlPathHelper.setUrlDecode(urlDecode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUrlPathHelper(UrlPathHelper urlPathHelper)
/*     */   {
/* 107 */     Assert.notNull(urlPathHelper, "UrlPathHelper must not be null");
/* 108 */     this.urlPathHelper = urlPathHelper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCacheMappings(Properties cacheMappings)
/*     */   {
/* 124 */     this.cacheMappings.clear();
/* 125 */     Enumeration<?> propNames = cacheMappings.propertyNames();
/* 126 */     while (propNames.hasMoreElements()) {
/* 127 */       String path = (String)propNames.nextElement();
/* 128 */       int cacheSeconds = Integer.valueOf(cacheMappings.getProperty(path)).intValue();
/* 129 */       this.cacheMappings.put(path, Integer.valueOf(cacheSeconds));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addCacheMapping(CacheControl cacheControl, String... paths)
/*     */   {
/* 148 */     for (String path : paths) {
/* 149 */       this.cacheControlMappings.put(path, cacheControl);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPathMatcher(PathMatcher pathMatcher)
/*     */   {
/* 162 */     Assert.notNull(pathMatcher, "PathMatcher must not be null");
/* 163 */     this.pathMatcher = pathMatcher;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws ServletException
/*     */   {
/* 171 */     checkRequest(request);
/*     */     
/* 173 */     String lookupPath = this.urlPathHelper.getLookupPathForRequest(request);
/* 174 */     if (this.logger.isDebugEnabled()) {
/* 175 */       this.logger.debug("Looking up cache seconds for [" + lookupPath + "]");
/*     */     }
/*     */     
/* 178 */     CacheControl cacheControl = lookupCacheControl(lookupPath);
/* 179 */     Integer cacheSeconds = lookupCacheSeconds(lookupPath);
/* 180 */     if (cacheControl != null) {
/* 181 */       if (this.logger.isDebugEnabled()) {
/* 182 */         this.logger.debug("Applying CacheControl to [" + lookupPath + "]");
/*     */       }
/* 184 */       applyCacheControl(response, cacheControl);
/*     */     }
/* 186 */     else if (cacheSeconds != null) {
/* 187 */       if (this.logger.isDebugEnabled()) {
/* 188 */         this.logger.debug("Applying CacheControl to [" + lookupPath + "]");
/*     */       }
/* 190 */       applyCacheSeconds(response, cacheSeconds.intValue());
/*     */     }
/*     */     else {
/* 193 */       if (this.logger.isDebugEnabled()) {
/* 194 */         this.logger.debug("Applying default cache seconds to [" + lookupPath + "]");
/*     */       }
/* 196 */       prepareResponse(response);
/*     */     }
/*     */     
/* 199 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected CacheControl lookupCacheControl(String urlPath)
/*     */   {
/* 213 */     CacheControl cacheControl = (CacheControl)this.cacheControlMappings.get(urlPath);
/* 214 */     if (cacheControl == null)
/*     */     {
/* 216 */       for (String registeredPath : this.cacheControlMappings.keySet()) {
/* 217 */         if (this.pathMatcher.match(registeredPath, urlPath)) {
/* 218 */           cacheControl = (CacheControl)this.cacheControlMappings.get(registeredPath);
/*     */         }
/*     */       }
/*     */     }
/* 222 */     return cacheControl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Integer lookupCacheSeconds(String urlPath)
/*     */   {
/* 236 */     Integer cacheSeconds = (Integer)this.cacheMappings.get(urlPath);
/* 237 */     if (cacheSeconds == null)
/*     */     {
/* 239 */       for (String registeredPath : this.cacheMappings.keySet()) {
/* 240 */         if (this.pathMatcher.match(registeredPath, urlPath)) {
/* 241 */           cacheSeconds = (Integer)this.cacheMappings.get(registeredPath);
/*     */         }
/*     */       }
/*     */     }
/* 245 */     return cacheSeconds;
/*     */   }
/*     */   
/*     */   public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView)
/*     */     throws Exception
/*     */   {}
/*     */   
/*     */   public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
/*     */     throws Exception
/*     */   {}
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\WebContentInterceptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */