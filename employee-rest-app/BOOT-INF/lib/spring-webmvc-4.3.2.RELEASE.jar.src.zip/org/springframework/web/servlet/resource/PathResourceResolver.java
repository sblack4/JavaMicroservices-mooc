/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.net.URLDecoder;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.UrlResource;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.support.ServletContextResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PathResourceResolver
/*     */   extends AbstractResourceResolver
/*     */ {
/*     */   private Resource[] allowedLocations;
/*     */   
/*     */   public void setAllowedLocations(Resource... locations)
/*     */   {
/*  66 */     this.allowedLocations = locations;
/*     */   }
/*     */   
/*     */   public Resource[] getAllowedLocations() {
/*  70 */     return this.allowedLocations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Resource resolveResourceInternal(HttpServletRequest request, String requestPath, List<? extends Resource> locations, ResourceResolverChain chain)
/*     */   {
/*  78 */     return getResource(requestPath, locations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String resolveUrlPathInternal(String resourcePath, List<? extends Resource> locations, ResourceResolverChain chain)
/*     */   {
/*  85 */     return (StringUtils.hasText(resourcePath)) && (getResource(resourcePath, locations) != null) ? resourcePath : null;
/*     */   }
/*     */   
/*     */   private Resource getResource(String resourcePath, List<? extends Resource> locations) {
/*  89 */     for (Resource location : locations) {
/*     */       try {
/*  91 */         if (this.logger.isTraceEnabled()) {
/*  92 */           this.logger.trace("Checking location: " + location);
/*     */         }
/*  94 */         Resource resource = getResource(resourcePath, location);
/*  95 */         if (resource != null) {
/*  96 */           if (this.logger.isTraceEnabled()) {
/*  97 */             this.logger.trace("Found match: " + resource);
/*     */           }
/*  99 */           return resource;
/*     */         }
/* 101 */         if (this.logger.isTraceEnabled()) {
/* 102 */           this.logger.trace("No match for location: " + location);
/*     */         }
/*     */       }
/*     */       catch (IOException ex) {
/* 106 */         this.logger.trace("Failure checking for relative resource - trying next location", ex);
/*     */       }
/*     */     }
/* 109 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Resource getResource(String resourcePath, Resource location)
/*     */     throws IOException
/*     */   {
/* 121 */     Resource resource = location.createRelative(resourcePath);
/* 122 */     if ((resource.exists()) && (resource.isReadable())) {
/* 123 */       if (checkResource(resource, location)) {
/* 124 */         return resource;
/*     */       }
/* 126 */       if (this.logger.isTraceEnabled()) {
/* 127 */         this.logger.trace("Resource path=\"" + resourcePath + "\" was successfully resolved " + "but resource=\"" + resource
/* 128 */           .getURL() + "\" is neither under the " + "current location=\"" + location
/* 129 */           .getURL() + "\" nor under any of the " + "allowed locations=" + 
/* 130 */           Arrays.asList(getAllowedLocations()));
/*     */       }
/*     */     }
/* 133 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean checkResource(Resource resource, Resource location)
/*     */     throws IOException
/*     */   {
/* 147 */     if (isResourceUnderLocation(resource, location)) {
/* 148 */       return true;
/*     */     }
/* 150 */     if (getAllowedLocations() != null) {
/* 151 */       for (Resource current : getAllowedLocations()) {
/* 152 */         if (isResourceUnderLocation(resource, current)) {
/* 153 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 157 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isResourceUnderLocation(Resource resource, Resource location) throws IOException {
/* 161 */     if (resource.getClass() != location.getClass()) {
/* 162 */       return false;
/*     */     }
/*     */     
/*     */     String locationPath;
/*     */     
/*     */     String resourcePath;
/* 168 */     if ((resource instanceof UrlResource)) {
/* 169 */       String resourcePath = resource.getURL().toExternalForm();
/* 170 */       locationPath = StringUtils.cleanPath(location.getURL().toString());
/*     */     } else { String locationPath;
/* 172 */       if ((resource instanceof ClassPathResource)) {
/* 173 */         String resourcePath = ((ClassPathResource)resource).getPath();
/* 174 */         locationPath = StringUtils.cleanPath(((ClassPathResource)location).getPath());
/*     */       } else { String locationPath;
/* 176 */         if ((resource instanceof ServletContextResource)) {
/* 177 */           String resourcePath = ((ServletContextResource)resource).getPath();
/* 178 */           locationPath = StringUtils.cleanPath(((ServletContextResource)location).getPath());
/*     */         }
/*     */         else {
/* 181 */           resourcePath = resource.getURL().getPath();
/* 182 */           locationPath = StringUtils.cleanPath(location.getURL().getPath());
/*     */         }
/*     */       } }
/* 185 */     if (locationPath.equals(resourcePath)) {
/* 186 */       return true;
/*     */     }
/* 188 */     String locationPath = locationPath + "/";
/* 189 */     if (!resourcePath.startsWith(locationPath)) {
/* 190 */       return false;
/*     */     }
/*     */     
/* 193 */     if (resourcePath.contains("%"))
/*     */     {
/* 195 */       if (URLDecoder.decode(resourcePath, "UTF-8").contains("../")) {
/* 196 */         if (this.logger.isTraceEnabled()) {
/* 197 */           this.logger.trace("Resolved resource path contains \"../\" after decoding: " + resourcePath);
/*     */         }
/* 199 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 203 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\resource\PathResourceResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */