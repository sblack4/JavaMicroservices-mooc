/*     */ package org.springframework.web.servlet.i18n;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.context.i18n.LocaleContext;
/*     */ import org.springframework.context.i18n.TimeZoneAwareLocaleContext;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionLocaleResolver
/*     */   extends AbstractLocaleContextResolver
/*     */ {
/*  69 */   public static final String LOCALE_SESSION_ATTRIBUTE_NAME = SessionLocaleResolver.class.getName() + ".LOCALE";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */   public static final String TIME_ZONE_SESSION_ATTRIBUTE_NAME = SessionLocaleResolver.class.getName() + ".TIME_ZONE";
/*     */   
/*     */ 
/*     */   public Locale resolveLocale(HttpServletRequest request)
/*     */   {
/*  84 */     Locale locale = (Locale)WebUtils.getSessionAttribute(request, LOCALE_SESSION_ATTRIBUTE_NAME);
/*  85 */     if (locale == null) {
/*  86 */       locale = determineDefaultLocale(request);
/*     */     }
/*  88 */     return locale;
/*     */   }
/*     */   
/*     */   public LocaleContext resolveLocaleContext(final HttpServletRequest request)
/*     */   {
/*  93 */     new TimeZoneAwareLocaleContext()
/*     */     {
/*     */       public Locale getLocale() {
/*  96 */         Locale locale = (Locale)WebUtils.getSessionAttribute(request, SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME);
/*  97 */         if (locale == null) {
/*  98 */           locale = SessionLocaleResolver.this.determineDefaultLocale(request);
/*     */         }
/* 100 */         return locale;
/*     */       }
/*     */       
/*     */       public TimeZone getTimeZone() {
/* 104 */         TimeZone timeZone = (TimeZone)WebUtils.getSessionAttribute(request, SessionLocaleResolver.TIME_ZONE_SESSION_ATTRIBUTE_NAME);
/* 105 */         if (timeZone == null) {
/* 106 */           timeZone = SessionLocaleResolver.this.determineDefaultTimeZone(request);
/*     */         }
/* 108 */         return timeZone;
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public void setLocaleContext(HttpServletRequest request, HttpServletResponse response, LocaleContext localeContext)
/*     */   {
/* 115 */     Locale locale = null;
/* 116 */     TimeZone timeZone = null;
/* 117 */     if (localeContext != null) {
/* 118 */       locale = localeContext.getLocale();
/* 119 */       if ((localeContext instanceof TimeZoneAwareLocaleContext)) {
/* 120 */         timeZone = ((TimeZoneAwareLocaleContext)localeContext).getTimeZone();
/*     */       }
/*     */     }
/* 123 */     WebUtils.setSessionAttribute(request, LOCALE_SESSION_ATTRIBUTE_NAME, locale);
/* 124 */     WebUtils.setSessionAttribute(request, TIME_ZONE_SESSION_ATTRIBUTE_NAME, timeZone);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Locale determineDefaultLocale(HttpServletRequest request)
/*     */   {
/* 139 */     Locale defaultLocale = getDefaultLocale();
/* 140 */     if (defaultLocale == null) {
/* 141 */       defaultLocale = request.getLocale();
/*     */     }
/* 143 */     return defaultLocale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TimeZone determineDefaultTimeZone(HttpServletRequest request)
/*     */   {
/* 156 */     return getDefaultTimeZone();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\i18n\SessionLocaleResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */