/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.http.converter.ByteArrayHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.StringHttpMessageConverter;
/*     */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.SourceHttpMessageConverter;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.method.ControllerAdviceBean;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ import org.springframework.web.method.annotation.ExceptionHandlerMethodResolver;
/*     */ import org.springframework.web.method.annotation.MapMethodProcessor;
/*     */ import org.springframework.web.method.annotation.ModelAttributeMethodProcessor;
/*     */ import org.springframework.web.method.annotation.ModelMethodProcessor;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolverComposite;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandlerComposite;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.handler.AbstractHandlerMethodExceptionResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExceptionHandlerExceptionResolver
/*     */   extends AbstractHandlerMethodExceptionResolver
/*     */   implements ApplicationContextAware, InitializingBean
/*     */ {
/*     */   private List<HandlerMethodArgumentResolver> customArgumentResolvers;
/*     */   private HandlerMethodArgumentResolverComposite argumentResolvers;
/*     */   private List<HandlerMethodReturnValueHandler> customReturnValueHandlers;
/*     */   private HandlerMethodReturnValueHandlerComposite returnValueHandlers;
/*     */   private List<HttpMessageConverter<?>> messageConverters;
/*  84 */   private ContentNegotiationManager contentNegotiationManager = new ContentNegotiationManager();
/*     */   
/*  86 */   private final List<Object> responseBodyAdvice = new ArrayList();
/*     */   
/*     */   private ApplicationContext applicationContext;
/*     */   
/*  90 */   private final Map<Class<?>, ExceptionHandlerMethodResolver> exceptionHandlerCache = new ConcurrentHashMap(64);
/*     */   
/*     */ 
/*  93 */   private final Map<ControllerAdviceBean, ExceptionHandlerMethodResolver> exceptionHandlerAdviceCache = new LinkedHashMap();
/*     */   
/*     */ 
/*     */   public ExceptionHandlerExceptionResolver()
/*     */   {
/*  98 */     StringHttpMessageConverter stringHttpMessageConverter = new StringHttpMessageConverter();
/*  99 */     stringHttpMessageConverter.setWriteAcceptCharset(false);
/*     */     
/* 101 */     this.messageConverters = new ArrayList();
/* 102 */     this.messageConverters.add(new ByteArrayHttpMessageConverter());
/* 103 */     this.messageConverters.add(stringHttpMessageConverter);
/* 104 */     this.messageConverters.add(new SourceHttpMessageConverter());
/* 105 */     this.messageConverters.add(new AllEncompassingFormHttpMessageConverter());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCustomArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers)
/*     */   {
/* 115 */     this.customArgumentResolvers = argumentResolvers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<HandlerMethodArgumentResolver> getCustomArgumentResolvers()
/*     */   {
/* 122 */     return this.customArgumentResolvers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers)
/*     */   {
/* 130 */     if (argumentResolvers == null) {
/* 131 */       this.argumentResolvers = null;
/*     */     }
/*     */     else {
/* 134 */       this.argumentResolvers = new HandlerMethodArgumentResolverComposite();
/* 135 */       this.argumentResolvers.addResolvers(argumentResolvers);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public HandlerMethodArgumentResolverComposite getArgumentResolvers()
/*     */   {
/* 144 */     return this.argumentResolvers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCustomReturnValueHandlers(List<HandlerMethodReturnValueHandler> returnValueHandlers)
/*     */   {
/* 153 */     this.customReturnValueHandlers = returnValueHandlers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<HandlerMethodReturnValueHandler> getCustomReturnValueHandlers()
/*     */   {
/* 160 */     return this.customReturnValueHandlers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReturnValueHandlers(List<HandlerMethodReturnValueHandler> returnValueHandlers)
/*     */   {
/* 168 */     if (returnValueHandlers == null) {
/* 169 */       this.returnValueHandlers = null;
/*     */     }
/*     */     else {
/* 172 */       this.returnValueHandlers = new HandlerMethodReturnValueHandlerComposite();
/* 173 */       this.returnValueHandlers.addHandlers(returnValueHandlers);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public HandlerMethodReturnValueHandlerComposite getReturnValueHandlers()
/*     */   {
/* 182 */     return this.returnValueHandlers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessageConverters(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/* 190 */     this.messageConverters = messageConverters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<HttpMessageConverter<?>> getMessageConverters()
/*     */   {
/* 197 */     return this.messageConverters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContentNegotiationManager(ContentNegotiationManager contentNegotiationManager)
/*     */   {
/* 205 */     this.contentNegotiationManager = contentNegotiationManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ContentNegotiationManager getContentNegotiationManager()
/*     */   {
/* 212 */     return this.contentNegotiationManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResponseBodyAdvice(List<ResponseBodyAdvice<?>> responseBodyAdvice)
/*     */   {
/* 222 */     this.responseBodyAdvice.clear();
/* 223 */     if (responseBodyAdvice != null) {
/* 224 */       this.responseBodyAdvice.addAll(responseBodyAdvice);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext)
/*     */   {
/* 230 */     this.applicationContext = applicationContext;
/*     */   }
/*     */   
/*     */   public ApplicationContext getApplicationContext() {
/* 234 */     return this.applicationContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 241 */     initExceptionHandlerAdviceCache();
/*     */     
/* 243 */     if (this.argumentResolvers == null) {
/* 244 */       List<HandlerMethodArgumentResolver> resolvers = getDefaultArgumentResolvers();
/* 245 */       this.argumentResolvers = new HandlerMethodArgumentResolverComposite().addResolvers(resolvers);
/*     */     }
/* 247 */     if (this.returnValueHandlers == null) {
/* 248 */       List<HandlerMethodReturnValueHandler> handlers = getDefaultReturnValueHandlers();
/* 249 */       this.returnValueHandlers = new HandlerMethodReturnValueHandlerComposite().addHandlers(handlers);
/*     */     }
/*     */   }
/*     */   
/*     */   private void initExceptionHandlerAdviceCache() {
/* 254 */     if (getApplicationContext() == null) {
/* 255 */       return;
/*     */     }
/* 257 */     if (this.logger.isDebugEnabled()) {
/* 258 */       this.logger.debug("Looking for exception mappings: " + getApplicationContext());
/*     */     }
/*     */     
/* 261 */     List<ControllerAdviceBean> adviceBeans = ControllerAdviceBean.findAnnotatedBeans(getApplicationContext());
/* 262 */     AnnotationAwareOrderComparator.sort(adviceBeans);
/*     */     
/* 264 */     for (ControllerAdviceBean adviceBean : adviceBeans) {
/* 265 */       ExceptionHandlerMethodResolver resolver = new ExceptionHandlerMethodResolver(adviceBean.getBeanType());
/* 266 */       if (resolver.hasExceptionMappings()) {
/* 267 */         this.exceptionHandlerAdviceCache.put(adviceBean, resolver);
/* 268 */         if (this.logger.isInfoEnabled()) {
/* 269 */           this.logger.info("Detected @ExceptionHandler methods in " + adviceBean);
/*     */         }
/*     */       }
/* 272 */       if (ResponseBodyAdvice.class.isAssignableFrom(adviceBean.getBeanType())) {
/* 273 */         this.responseBodyAdvice.add(adviceBean);
/* 274 */         if (this.logger.isInfoEnabled()) {
/* 275 */           this.logger.info("Detected ResponseBodyAdvice implementation in " + adviceBean);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<ControllerAdviceBean, ExceptionHandlerMethodResolver> getExceptionHandlerAdviceCache()
/*     */   {
/* 288 */     return Collections.unmodifiableMap(this.exceptionHandlerAdviceCache);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<HandlerMethodArgumentResolver> getDefaultArgumentResolvers()
/*     */   {
/* 296 */     List<HandlerMethodArgumentResolver> resolvers = new ArrayList();
/*     */     
/*     */ 
/* 299 */     resolvers.add(new SessionAttributeMethodArgumentResolver());
/* 300 */     resolvers.add(new RequestAttributeMethodArgumentResolver());
/*     */     
/*     */ 
/* 303 */     resolvers.add(new ServletRequestMethodArgumentResolver());
/* 304 */     resolvers.add(new ServletResponseMethodArgumentResolver());
/* 305 */     resolvers.add(new ModelMethodProcessor());
/*     */     
/*     */ 
/* 308 */     if (getCustomArgumentResolvers() != null) {
/* 309 */       resolvers.addAll(getCustomArgumentResolvers());
/*     */     }
/*     */     
/* 312 */     return resolvers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<HandlerMethodReturnValueHandler> getDefaultReturnValueHandlers()
/*     */   {
/* 320 */     List<HandlerMethodReturnValueHandler> handlers = new ArrayList();
/*     */     
/*     */ 
/* 323 */     handlers.add(new ModelAndViewMethodReturnValueHandler());
/* 324 */     handlers.add(new ModelMethodProcessor());
/* 325 */     handlers.add(new ViewMethodReturnValueHandler());
/* 326 */     handlers.add(new HttpEntityMethodProcessor(
/* 327 */       getMessageConverters(), this.contentNegotiationManager, this.responseBodyAdvice));
/*     */     
/*     */ 
/* 330 */     handlers.add(new ModelAttributeMethodProcessor(false));
/* 331 */     handlers.add(new RequestResponseBodyMethodProcessor(
/* 332 */       getMessageConverters(), this.contentNegotiationManager, this.responseBodyAdvice));
/*     */     
/*     */ 
/* 335 */     handlers.add(new ViewNameMethodReturnValueHandler());
/* 336 */     handlers.add(new MapMethodProcessor());
/*     */     
/*     */ 
/* 339 */     if (getCustomReturnValueHandlers() != null) {
/* 340 */       handlers.addAll(getCustomReturnValueHandlers());
/*     */     }
/*     */     
/*     */ 
/* 344 */     handlers.add(new ModelAttributeMethodProcessor(true));
/*     */     
/* 346 */     return handlers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelAndView doResolveHandlerMethodException(HttpServletRequest request, HttpServletResponse response, HandlerMethod handlerMethod, Exception exception)
/*     */   {
/* 357 */     ServletInvocableHandlerMethod exceptionHandlerMethod = getExceptionHandlerMethod(handlerMethod, exception);
/* 358 */     if (exceptionHandlerMethod == null) {
/* 359 */       return null;
/*     */     }
/*     */     
/* 362 */     exceptionHandlerMethod.setHandlerMethodArgumentResolvers(this.argumentResolvers);
/* 363 */     exceptionHandlerMethod.setHandlerMethodReturnValueHandlers(this.returnValueHandlers);
/*     */     
/* 365 */     ServletWebRequest webRequest = new ServletWebRequest(request, response);
/* 366 */     ModelAndViewContainer mavContainer = new ModelAndViewContainer();
/*     */     try
/*     */     {
/* 369 */       if (this.logger.isDebugEnabled()) {
/* 370 */         this.logger.debug("Invoking @ExceptionHandler method: " + exceptionHandlerMethod);
/*     */       }
/* 372 */       Throwable cause = exception.getCause();
/* 373 */       if (cause != null)
/*     */       {
/* 375 */         exceptionHandlerMethod.invokeAndHandle(webRequest, mavContainer, new Object[] { exception, cause, handlerMethod });
/*     */       }
/*     */       else
/*     */       {
/* 379 */         exceptionHandlerMethod.invokeAndHandle(webRequest, mavContainer, new Object[] { exception, handlerMethod });
/*     */       }
/*     */     }
/*     */     catch (Exception invocationEx) {
/* 383 */       if (this.logger.isDebugEnabled()) {
/* 384 */         this.logger.debug("Failed to invoke @ExceptionHandler method: " + exceptionHandlerMethod, invocationEx);
/*     */       }
/* 386 */       return null;
/*     */     }
/*     */     
/* 389 */     if (mavContainer.isRequestHandled()) {
/* 390 */       return new ModelAndView();
/*     */     }
/*     */     
/* 393 */     ModelAndView mav = new ModelAndView().addAllObjects(mavContainer.getModel());
/* 394 */     mav.setViewName(mavContainer.getViewName());
/* 395 */     if (!mavContainer.isViewReference()) {
/* 396 */       mav.setView((View)mavContainer.getView());
/*     */     }
/* 398 */     return mav;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ServletInvocableHandlerMethod getExceptionHandlerMethod(HandlerMethod handlerMethod, Exception exception)
/*     */   {
/* 413 */     Class<?> handlerType = handlerMethod != null ? handlerMethod.getBeanType() : null;
/*     */     ExceptionHandlerMethodResolver resolver;
/* 415 */     if (handlerMethod != null) {
/* 416 */       resolver = (ExceptionHandlerMethodResolver)this.exceptionHandlerCache.get(handlerType);
/* 417 */       if (resolver == null) {
/* 418 */         resolver = new ExceptionHandlerMethodResolver(handlerType);
/* 419 */         this.exceptionHandlerCache.put(handlerType, resolver);
/*     */       }
/* 421 */       Method method = resolver.resolveMethod(exception);
/* 422 */       if (method != null) {
/* 423 */         return new ServletInvocableHandlerMethod(handlerMethod.getBean(), method);
/*     */       }
/*     */     }
/*     */     
/* 427 */     for (Map.Entry<ControllerAdviceBean, ExceptionHandlerMethodResolver> entry : this.exceptionHandlerAdviceCache.entrySet()) {
/* 428 */       if (((ControllerAdviceBean)entry.getKey()).isApplicableToBeanType(handlerType)) {
/* 429 */         ExceptionHandlerMethodResolver resolver = (ExceptionHandlerMethodResolver)entry.getValue();
/* 430 */         Method method = resolver.resolveMethod(exception);
/* 431 */         if (method != null) {
/* 432 */           return new ServletInvocableHandlerMethod(((ControllerAdviceBean)entry.getKey()).resolveBean(), method);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 437 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\method\annotation\ExceptionHandlerExceptionResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */