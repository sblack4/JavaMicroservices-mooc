/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.accept.PathExtensionContentNegotiationStrategy;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractMessageConverterMethodProcessor
/*     */   extends AbstractMessageConverterMethodArgumentResolver
/*     */   implements HandlerMethodReturnValueHandler
/*     */ {
/*  66 */   private static final Set<String> WHITELISTED_EXTENSIONS = new HashSet(Arrays.asList(new String[] { "txt", "text", "yml", "properties", "csv", "json", "xml", "atom", "rss", "png", "jpe", "jpeg", "jpg", "gif", "wbmp", "bmp" }));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  71 */   private static final Set<String> WHITELISTED_MEDIA_BASE_TYPES = new HashSet(
/*  72 */     Arrays.asList(new String[] { "audio", "image", "video" }));
/*     */   
/*  74 */   private static final MediaType MEDIA_TYPE_APPLICATION = new MediaType("application");
/*     */   
/*  76 */   private static final UrlPathHelper DECODING_URL_PATH_HELPER = new UrlPathHelper();
/*     */   
/*  78 */   private static final UrlPathHelper RAW_URL_PATH_HELPER = new UrlPathHelper();
/*     */   private final ContentNegotiationManager contentNegotiationManager;
/*     */   
/*  81 */   static { RAW_URL_PATH_HELPER.setRemoveSemicolonContent(false);
/*  82 */     RAW_URL_PATH_HELPER.setUrlDecode(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private final PathExtensionContentNegotiationStrategy pathStrategy;
/*     */   
/*     */ 
/*  90 */   private final Set<String> safeExtensions = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractMessageConverterMethodProcessor(List<HttpMessageConverter<?>> converters)
/*     */   {
/*  98 */     this(converters, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractMessageConverterMethodProcessor(List<HttpMessageConverter<?>> converters, ContentNegotiationManager contentNegotiationManager)
/*     */   {
/* 107 */     this(converters, contentNegotiationManager, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractMessageConverterMethodProcessor(List<HttpMessageConverter<?>> converters, ContentNegotiationManager manager, List<Object> requestResponseBodyAdvice)
/*     */   {
/* 117 */     super(converters, requestResponseBodyAdvice);
/* 118 */     this.contentNegotiationManager = (manager != null ? manager : new ContentNegotiationManager());
/* 119 */     this.pathStrategy = initPathStrategy(this.contentNegotiationManager);
/* 120 */     this.safeExtensions.addAll(this.contentNegotiationManager.getAllFileExtensions());
/* 121 */     this.safeExtensions.addAll(WHITELISTED_EXTENSIONS);
/*     */   }
/*     */   
/*     */   private static PathExtensionContentNegotiationStrategy initPathStrategy(ContentNegotiationManager manager) {
/* 125 */     Class<PathExtensionContentNegotiationStrategy> clazz = PathExtensionContentNegotiationStrategy.class;
/* 126 */     PathExtensionContentNegotiationStrategy strategy = (PathExtensionContentNegotiationStrategy)manager.getStrategy(clazz);
/* 127 */     return strategy != null ? strategy : new PathExtensionContentNegotiationStrategy();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ServletServerHttpResponse createOutputMessage(NativeWebRequest webRequest)
/*     */   {
/* 137 */     HttpServletResponse response = (HttpServletResponse)webRequest.getNativeResponse(HttpServletResponse.class);
/* 138 */     return new ServletServerHttpResponse(response);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected <T> void writeWithMessageConverters(T value, MethodParameter returnType, NativeWebRequest webRequest)
/*     */     throws IOException, HttpMediaTypeNotAcceptableException, HttpMessageNotWritableException
/*     */   {
/* 148 */     ServletServerHttpRequest inputMessage = createInputMessage(webRequest);
/* 149 */     ServletServerHttpResponse outputMessage = createOutputMessage(webRequest);
/* 150 */     writeWithMessageConverters(value, returnType, inputMessage, outputMessage);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected <T> void writeWithMessageConverters(T value, MethodParameter returnType, ServletServerHttpRequest inputMessage, ServletServerHttpResponse outputMessage)
/*     */     throws IOException, HttpMediaTypeNotAcceptableException, HttpMessageNotWritableException
/*     */   {
/*     */     Type declaredType;
/*     */     
/*     */ 
/*     */ 
/*     */     Object outputValue;
/*     */     
/*     */ 
/*     */     Class<?> valueType;
/*     */     
/*     */ 
/*     */     Type declaredType;
/*     */     
/*     */ 
/* 172 */     if ((value instanceof CharSequence)) {
/* 173 */       Object outputValue = value.toString();
/* 174 */       Class<?> valueType = String.class;
/* 175 */       declaredType = String.class;
/*     */     }
/*     */     else {
/* 178 */       outputValue = value;
/* 179 */       valueType = getReturnValueType(outputValue, returnType);
/* 180 */       declaredType = getGenericType(returnType);
/*     */     }
/*     */     
/* 183 */     HttpServletRequest request = inputMessage.getServletRequest();
/* 184 */     List<MediaType> requestedMediaTypes = getAcceptableMediaTypes(request);
/* 185 */     List<MediaType> producibleMediaTypes = getProducibleMediaTypes(request, valueType, declaredType);
/*     */     
/* 187 */     if ((outputValue != null) && (producibleMediaTypes.isEmpty())) {
/* 188 */       throw new IllegalArgumentException("No converter found for return value of type: " + valueType);
/*     */     }
/*     */     
/* 191 */     Set<MediaType> compatibleMediaTypes = new LinkedHashSet();
/* 192 */     for (Iterator localIterator1 = requestedMediaTypes.iterator(); localIterator1.hasNext();) { requestedType = (MediaType)localIterator1.next();
/* 193 */       for (MediaType producibleType : producibleMediaTypes) {
/* 194 */         if (requestedType.isCompatibleWith(producibleType))
/* 195 */           compatibleMediaTypes.add(getMostSpecificMediaType(requestedType, producibleType));
/*     */       }
/*     */     }
/*     */     MediaType requestedType;
/* 199 */     if (compatibleMediaTypes.isEmpty()) {
/* 200 */       if (outputValue != null) {
/* 201 */         throw new HttpMediaTypeNotAcceptableException(producibleMediaTypes);
/*     */       }
/* 203 */       return;
/*     */     }
/*     */     
/* 206 */     Object mediaTypes = new ArrayList(compatibleMediaTypes);
/* 207 */     MediaType.sortBySpecificityAndQuality((List)mediaTypes);
/*     */     
/* 209 */     MediaType selectedMediaType = null;
/* 210 */     for (MediaType mediaType : (List)mediaTypes) {
/* 211 */       if (mediaType.isConcrete()) {
/* 212 */         selectedMediaType = mediaType;
/* 213 */         break;
/*     */       }
/* 215 */       if ((mediaType.equals(MediaType.ALL)) || (mediaType.equals(MEDIA_TYPE_APPLICATION))) {
/* 216 */         selectedMediaType = MediaType.APPLICATION_OCTET_STREAM;
/* 217 */         break;
/*     */       }
/*     */     }
/*     */     
/* 221 */     if (selectedMediaType != null) {
/* 222 */       selectedMediaType = selectedMediaType.removeQualityValue();
/* 223 */       for (HttpMessageConverter<?> messageConverter : this.messageConverters) {
/* 224 */         if ((messageConverter instanceof GenericHttpMessageConverter)) {
/* 225 */           if (((GenericHttpMessageConverter)messageConverter).canWrite(declaredType, valueType, selectedMediaType))
/*     */           {
/* 227 */             outputValue = getAdvice().beforeBodyWrite(outputValue, returnType, selectedMediaType, messageConverter
/* 228 */               .getClass(), inputMessage, outputMessage);
/*     */             
/* 230 */             if (outputValue != null) {
/* 231 */               addContentDispositionHeader(inputMessage, outputMessage);
/* 232 */               ((GenericHttpMessageConverter)messageConverter).write(outputValue, declaredType, selectedMediaType, outputMessage);
/*     */               
/* 234 */               if (this.logger.isDebugEnabled()) {
/* 235 */                 this.logger.debug("Written [" + outputValue + "] as \"" + selectedMediaType + "\" using [" + messageConverter + "]");
/*     */               }
/*     */               
/*     */             }
/*     */             
/*     */           }
/*     */         }
/* 242 */         else if (messageConverter.canWrite(valueType, selectedMediaType)) {
/* 243 */           outputValue = getAdvice().beforeBodyWrite(outputValue, returnType, selectedMediaType, messageConverter
/* 244 */             .getClass(), inputMessage, outputMessage);
/*     */           
/* 246 */           if (outputValue != null) {
/* 247 */             addContentDispositionHeader(inputMessage, outputMessage);
/* 248 */             messageConverter.write(outputValue, selectedMediaType, outputMessage);
/* 249 */             if (this.logger.isDebugEnabled()) {
/* 250 */               this.logger.debug("Written [" + outputValue + "] as \"" + selectedMediaType + "\" using [" + messageConverter + "]");
/*     */             }
/*     */           }
/*     */           
/* 254 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 259 */     if (outputValue != null) {
/* 260 */       throw new HttpMediaTypeNotAcceptableException(this.allSupportedMediaTypes);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Class<?> getReturnValueType(Object value, MethodParameter returnType)
/*     */   {
/* 271 */     return value != null ? value.getClass() : returnType.getParameterType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Type getGenericType(MethodParameter returnType)
/*     */   {
/* 279 */     if (HttpEntity.class.isAssignableFrom(returnType.getParameterType())) {
/* 280 */       return ResolvableType.forType(returnType.getGenericParameterType()).getGeneric(new int[] { 0 }).getType();
/*     */     }
/*     */     
/* 283 */     return returnType.getGenericParameterType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<MediaType> getProducibleMediaTypes(HttpServletRequest request, Class<?> valueClass)
/*     */   {
/* 292 */     return getProducibleMediaTypes(request, valueClass, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<MediaType> getProducibleMediaTypes(HttpServletRequest request, Class<?> valueClass, Type declaredType)
/*     */   {
/* 306 */     Set<MediaType> mediaTypes = (Set)request.getAttribute(HandlerMapping.PRODUCIBLE_MEDIA_TYPES_ATTRIBUTE);
/* 307 */     if (!CollectionUtils.isEmpty(mediaTypes)) {
/* 308 */       return new ArrayList(mediaTypes);
/*     */     }
/* 310 */     if (!this.allSupportedMediaTypes.isEmpty()) {
/* 311 */       List<MediaType> result = new ArrayList();
/* 312 */       for (HttpMessageConverter<?> converter : this.messageConverters) {
/* 313 */         if (((converter instanceof GenericHttpMessageConverter)) && (declaredType != null)) {
/* 314 */           if (((GenericHttpMessageConverter)converter).canWrite(declaredType, valueClass, null)) {
/* 315 */             result.addAll(converter.getSupportedMediaTypes());
/*     */           }
/*     */         }
/* 318 */         else if (converter.canWrite(valueClass, null)) {
/* 319 */           result.addAll(converter.getSupportedMediaTypes());
/*     */         }
/*     */       }
/* 322 */       return result;
/*     */     }
/*     */     
/* 325 */     return Collections.singletonList(MediaType.ALL);
/*     */   }
/*     */   
/*     */   private List<MediaType> getAcceptableMediaTypes(HttpServletRequest request) throws HttpMediaTypeNotAcceptableException
/*     */   {
/* 330 */     List<MediaType> mediaTypes = this.contentNegotiationManager.resolveMediaTypes(new ServletWebRequest(request));
/* 331 */     return mediaTypes.isEmpty() ? Collections.singletonList(MediaType.ALL) : mediaTypes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private MediaType getMostSpecificMediaType(MediaType acceptType, MediaType produceType)
/*     */   {
/* 339 */     MediaType produceTypeToUse = produceType.copyQualityValue(acceptType);
/* 340 */     return MediaType.SPECIFICITY_COMPARATOR.compare(acceptType, produceTypeToUse) <= 0 ? acceptType : produceTypeToUse;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addContentDispositionHeader(ServletServerHttpRequest request, ServletServerHttpResponse response)
/*     */   {
/* 354 */     HttpHeaders headers = response.getHeaders();
/* 355 */     if (headers.containsKey("Content-Disposition")) {
/* 356 */       return;
/*     */     }
/*     */     try
/*     */     {
/* 360 */       int status = response.getServletResponse().getStatus();
/* 361 */       if ((status < 200) || (status > 299)) {
/* 362 */         return;
/*     */       }
/*     */     }
/*     */     catch (Throwable localThrowable) {}
/*     */     
/*     */ 
/*     */ 
/* 369 */     HttpServletRequest servletRequest = request.getServletRequest();
/* 370 */     String requestUri = RAW_URL_PATH_HELPER.getOriginatingRequestUri(servletRequest);
/*     */     
/* 372 */     int index = requestUri.lastIndexOf('/') + 1;
/* 373 */     String filename = requestUri.substring(index);
/* 374 */     String pathParams = "";
/*     */     
/* 376 */     index = filename.indexOf(';');
/* 377 */     if (index != -1) {
/* 378 */       pathParams = filename.substring(index);
/* 379 */       filename = filename.substring(0, index);
/*     */     }
/*     */     
/* 382 */     filename = DECODING_URL_PATH_HELPER.decodeRequestString(servletRequest, filename);
/* 383 */     String ext = StringUtils.getFilenameExtension(filename);
/*     */     
/* 385 */     pathParams = DECODING_URL_PATH_HELPER.decodeRequestString(servletRequest, pathParams);
/* 386 */     String extInPathParams = StringUtils.getFilenameExtension(pathParams);
/*     */     
/* 388 */     if ((!safeExtension(servletRequest, ext)) || (!safeExtension(servletRequest, extInPathParams))) {
/* 389 */       headers.add("Content-Disposition", "inline;filename=f.txt");
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean safeExtension(HttpServletRequest request, String extension)
/*     */   {
/* 395 */     if (!StringUtils.hasText(extension)) {
/* 396 */       return true;
/*     */     }
/* 398 */     extension = extension.toLowerCase(Locale.ENGLISH);
/* 399 */     if (this.safeExtensions.contains(extension)) {
/* 400 */       return true;
/*     */     }
/* 402 */     String pattern = (String)request.getAttribute(HandlerMapping.BEST_MATCHING_PATTERN_ATTRIBUTE);
/* 403 */     if ((pattern != null) && (pattern.endsWith("." + extension))) {
/* 404 */       return true;
/*     */     }
/* 406 */     if (extension.equals("html")) {
/* 407 */       String name = HandlerMapping.PRODUCIBLE_MEDIA_TYPES_ATTRIBUTE;
/* 408 */       Set<MediaType> mediaTypes = (Set)request.getAttribute(name);
/* 409 */       if ((!CollectionUtils.isEmpty(mediaTypes)) && (mediaTypes.contains(MediaType.TEXT_HTML))) {
/* 410 */         return true;
/*     */       }
/*     */     }
/* 413 */     return safeMediaTypesForExtension(extension);
/*     */   }
/*     */   
/*     */   private boolean safeMediaTypesForExtension(String extension) {
/* 417 */     List<MediaType> mediaTypes = null;
/*     */     try {
/* 419 */       mediaTypes = this.pathStrategy.resolveMediaTypeKey(null, extension);
/*     */     }
/*     */     catch (HttpMediaTypeNotAcceptableException localHttpMediaTypeNotAcceptableException) {}
/*     */     
/*     */ 
/* 424 */     if (CollectionUtils.isEmpty(mediaTypes)) {
/* 425 */       return false;
/*     */     }
/* 427 */     for (MediaType mediaType : mediaTypes) {
/* 428 */       if (!safeMediaType(mediaType)) {
/* 429 */         return false;
/*     */       }
/*     */     }
/* 432 */     return true;
/*     */   }
/*     */   
/*     */   private boolean safeMediaType(MediaType mediaType)
/*     */   {
/* 437 */     return (WHITELISTED_MEDIA_BASE_TYPES.contains(mediaType.getType())) || (mediaType.getSubtype().endsWith("+xml"));
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\method\annotation\AbstractMessageConverterMethodProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */