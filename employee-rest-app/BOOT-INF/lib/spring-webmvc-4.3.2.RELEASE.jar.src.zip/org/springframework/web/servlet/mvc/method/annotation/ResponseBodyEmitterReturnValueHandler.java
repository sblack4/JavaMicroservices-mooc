/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.ResponseEntity;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.server.ServerHttpResponse;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.async.DeferredResult;
/*     */ import org.springframework.web.context.request.async.WebAsyncManager;
/*     */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*     */ import org.springframework.web.filter.ShallowEtagHeaderFilter;
/*     */ import org.springframework.web.method.support.AsyncHandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResponseBodyEmitterReturnValueHandler
/*     */   implements AsyncHandlerMethodReturnValueHandler
/*     */ {
/*  57 */   private static final Log logger = LogFactory.getLog(ResponseBodyEmitterReturnValueHandler.class);
/*     */   
/*     */   private final List<HttpMessageConverter<?>> messageConverters;
/*     */   
/*     */   private final Map<Class<?>, ResponseBodyEmitterAdapter> adapterMap;
/*     */   
/*     */ 
/*     */   public ResponseBodyEmitterReturnValueHandler(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/*  66 */     Assert.notEmpty(messageConverters, "'messageConverters' must not be empty");
/*  67 */     this.messageConverters = messageConverters;
/*  68 */     this.adapterMap = new HashMap(3);
/*  69 */     this.adapterMap.put(ResponseBodyEmitter.class, new SimpleResponseBodyEmitterAdapter(null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<Class<?>, ResponseBodyEmitterAdapter> getAdapterMap()
/*     */   {
/*  80 */     return this.adapterMap;
/*     */   }
/*     */   
/*     */   private ResponseBodyEmitterAdapter getAdapterFor(Class<?> type) {
/*  84 */     if (type != null) {
/*  85 */       for (Class<?> adapteeType : getAdapterMap().keySet()) {
/*  86 */         if (adapteeType.isAssignableFrom(type)) {
/*  87 */           return (ResponseBodyEmitterAdapter)getAdapterMap().get(adapteeType);
/*     */         }
/*     */       }
/*     */     }
/*  91 */     return null;
/*     */   }
/*     */   
/*     */   public boolean supportsReturnType(MethodParameter returnType)
/*     */   {
/*     */     Class<?> bodyType;
/*     */     Class<?> bodyType;
/*  98 */     if (ResponseEntity.class.isAssignableFrom(returnType.getParameterType())) {
/*  99 */       bodyType = ResolvableType.forMethodParameter(returnType).getGeneric(new int[] { 0 }).resolve();
/*     */     }
/*     */     else {
/* 102 */       bodyType = returnType.getParameterType();
/*     */     }
/* 104 */     return getAdapterFor(bodyType) != null;
/*     */   }
/*     */   
/*     */   public boolean isAsyncReturnValue(Object returnValue, MethodParameter returnType)
/*     */   {
/* 109 */     if (returnValue != null) {
/* 110 */       Object adaptFrom = returnValue;
/* 111 */       if ((returnValue instanceof ResponseEntity)) {
/* 112 */         adaptFrom = ((ResponseEntity)returnValue).getBody();
/*     */       }
/* 114 */       if (adaptFrom != null) {
/* 115 */         return getAdapterFor(adaptFrom.getClass()) != null;
/*     */       }
/*     */     }
/* 118 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 125 */     if (returnValue == null) {
/* 126 */       mavContainer.setRequestHandled(true);
/* 127 */       return;
/*     */     }
/*     */     
/* 130 */     HttpServletResponse response = (HttpServletResponse)webRequest.getNativeResponse(HttpServletResponse.class);
/* 131 */     ServerHttpResponse outputMessage = new ServletServerHttpResponse(response);
/*     */     
/* 133 */     if ((returnValue instanceof ResponseEntity)) {
/* 134 */       ResponseEntity<?> responseEntity = (ResponseEntity)returnValue;
/* 135 */       response.setStatus(responseEntity.getStatusCodeValue());
/* 136 */       outputMessage.getHeaders().putAll(responseEntity.getHeaders());
/* 137 */       returnValue = responseEntity.getBody();
/* 138 */       if (returnValue == null) {
/* 139 */         mavContainer.setRequestHandled(true);
/* 140 */         outputMessage.flush();
/* 141 */         return;
/*     */       }
/*     */     }
/*     */     
/* 145 */     ServletRequest request = (ServletRequest)webRequest.getNativeRequest(ServletRequest.class);
/* 146 */     ShallowEtagHeaderFilter.disableContentCaching(request);
/*     */     
/* 148 */     ResponseBodyEmitterAdapter adapter = getAdapterFor(returnValue.getClass());
/* 149 */     Assert.notNull(adapter);
/* 150 */     ResponseBodyEmitter emitter = adapter.adaptToEmitter(returnValue, outputMessage);
/* 151 */     emitter.extendResponse(outputMessage);
/*     */     
/*     */ 
/* 154 */     outputMessage.getBody();
/* 155 */     outputMessage.flush();
/* 156 */     outputMessage = new StreamingServletServerHttpResponse(outputMessage);
/*     */     
/* 158 */     DeferredResult<?> deferredResult = new DeferredResult(emitter.getTimeout());
/* 159 */     WebAsyncUtils.getAsyncManager(webRequest).startDeferredResultProcessing(deferredResult, new Object[] { mavContainer });
/*     */     
/* 161 */     HttpMessageConvertingHandler handler = new HttpMessageConvertingHandler(outputMessage, deferredResult);
/* 162 */     emitter.initialize(handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class SimpleResponseBodyEmitterAdapter
/*     */     implements ResponseBodyEmitterAdapter
/*     */   {
/*     */     public ResponseBodyEmitter adaptToEmitter(Object returnValue, ServerHttpResponse response)
/*     */     {
/* 173 */       Assert.isInstanceOf(ResponseBodyEmitter.class, returnValue);
/* 174 */       return (ResponseBodyEmitter)returnValue;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private class HttpMessageConvertingHandler
/*     */     implements ResponseBodyEmitter.Handler
/*     */   {
/*     */     private final ServerHttpResponse outputMessage;
/*     */     
/*     */     private final DeferredResult<?> deferredResult;
/*     */     
/*     */     public HttpMessageConvertingHandler(DeferredResult<?> outputMessage)
/*     */     {
/* 188 */       this.outputMessage = outputMessage;
/* 189 */       this.deferredResult = deferredResult;
/*     */     }
/*     */     
/*     */     public void send(Object data, MediaType mediaType) throws IOException
/*     */     {
/* 194 */       sendInternal(data, mediaType);
/*     */     }
/*     */     
/*     */     private <T> void sendInternal(T data, MediaType mediaType) throws IOException
/*     */     {
/* 199 */       for (HttpMessageConverter<?> converter : ResponseBodyEmitterReturnValueHandler.this.messageConverters) {
/* 200 */         if (converter.canWrite(data.getClass(), mediaType)) {
/* 201 */           converter.write(data, mediaType, this.outputMessage);
/* 202 */           this.outputMessage.flush();
/* 203 */           if (ResponseBodyEmitterReturnValueHandler.logger.isDebugEnabled()) {
/* 204 */             ResponseBodyEmitterReturnValueHandler.logger.debug("Written [" + data + "] using [" + converter + "]");
/*     */           }
/* 206 */           return;
/*     */         }
/*     */       }
/* 209 */       throw new IllegalArgumentException("No suitable converter for " + data.getClass());
/*     */     }
/*     */     
/*     */     public void complete()
/*     */     {
/* 214 */       this.deferredResult.setResult(null);
/*     */     }
/*     */     
/*     */     public void completeWithError(Throwable failure)
/*     */     {
/* 219 */       this.deferredResult.setErrorResult(failure);
/*     */     }
/*     */     
/*     */     public void onTimeout(Runnable callback)
/*     */     {
/* 224 */       this.deferredResult.onTimeout(callback);
/*     */     }
/*     */     
/*     */     public void onCompletion(Runnable callback)
/*     */     {
/* 229 */       this.deferredResult.onCompletion(callback);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class StreamingServletServerHttpResponse
/*     */     implements ServerHttpResponse
/*     */   {
/*     */     private final ServerHttpResponse delegate;
/*     */     
/*     */ 
/* 242 */     private final HttpHeaders mutableHeaders = new HttpHeaders();
/*     */     
/*     */     public StreamingServletServerHttpResponse(ServerHttpResponse delegate) {
/* 245 */       this.delegate = delegate;
/* 246 */       this.mutableHeaders.putAll(delegate.getHeaders());
/*     */     }
/*     */     
/*     */     public void setStatusCode(HttpStatus status)
/*     */     {
/* 251 */       this.delegate.setStatusCode(status);
/*     */     }
/*     */     
/*     */     public HttpHeaders getHeaders()
/*     */     {
/* 256 */       return this.mutableHeaders;
/*     */     }
/*     */     
/*     */     public OutputStream getBody() throws IOException
/*     */     {
/* 261 */       return this.delegate.getBody();
/*     */     }
/*     */     
/*     */     public void flush() throws IOException
/*     */     {
/* 266 */       this.delegate.flush();
/*     */     }
/*     */     
/*     */     public void close()
/*     */     {
/* 271 */       this.delegate.close();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\method\annotation\ResponseBodyEmitterReturnValueHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */