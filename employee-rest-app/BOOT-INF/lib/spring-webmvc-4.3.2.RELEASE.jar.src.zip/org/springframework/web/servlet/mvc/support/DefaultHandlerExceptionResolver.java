/*     */ package org.springframework.web.servlet.mvc.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.ConversionNotSupportedException;
/*     */ import org.springframework.beans.TypeMismatchException;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.HttpRequestMethodNotSupportedException;
/*     */ import org.springframework.web.bind.MethodArgumentNotValidException;
/*     */ import org.springframework.web.bind.MissingPathVariableException;
/*     */ import org.springframework.web.bind.MissingServletRequestParameterException;
/*     */ import org.springframework.web.bind.ServletRequestBindingException;
/*     */ import org.springframework.web.multipart.support.MissingServletRequestPartException;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.NoHandlerFoundException;
/*     */ import org.springframework.web.servlet.handler.AbstractHandlerExceptionResolver;
/*     */ import org.springframework.web.servlet.mvc.multiaction.NoSuchRequestHandlingMethodException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultHandlerExceptionResolver
/*     */   extends AbstractHandlerExceptionResolver
/*     */ {
/*     */   public static final String PAGE_NOT_FOUND_LOG_CATEGORY = "org.springframework.web.servlet.PageNotFound";
/*  91 */   protected static final Log pageNotFoundLogger = LogFactory.getLog("org.springframework.web.servlet.PageNotFound");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultHandlerExceptionResolver()
/*     */   {
/*  98 */     setOrder(Integer.MAX_VALUE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
/*     */   {
/*     */     try
/*     */     {
/* 108 */       if ((ex instanceof NoSuchRequestHandlingMethodException)) {
/* 109 */         return handleNoSuchRequestHandlingMethod((NoSuchRequestHandlingMethodException)ex, request, response, handler);
/*     */       }
/*     */       
/* 112 */       if ((ex instanceof HttpRequestMethodNotSupportedException)) {
/* 113 */         return handleHttpRequestMethodNotSupported((HttpRequestMethodNotSupportedException)ex, request, response, handler);
/*     */       }
/*     */       
/* 116 */       if ((ex instanceof HttpMediaTypeNotSupportedException)) {
/* 117 */         return handleHttpMediaTypeNotSupported((HttpMediaTypeNotSupportedException)ex, request, response, handler);
/*     */       }
/*     */       
/* 120 */       if ((ex instanceof HttpMediaTypeNotAcceptableException)) {
/* 121 */         return handleHttpMediaTypeNotAcceptable((HttpMediaTypeNotAcceptableException)ex, request, response, handler);
/*     */       }
/*     */       
/* 124 */       if ((ex instanceof MissingPathVariableException)) {
/* 125 */         return handleMissingPathVariable((MissingPathVariableException)ex, request, response, handler);
/*     */       }
/*     */       
/* 128 */       if ((ex instanceof MissingServletRequestParameterException)) {
/* 129 */         return handleMissingServletRequestParameter((MissingServletRequestParameterException)ex, request, response, handler);
/*     */       }
/*     */       
/* 132 */       if ((ex instanceof ServletRequestBindingException)) {
/* 133 */         return handleServletRequestBindingException((ServletRequestBindingException)ex, request, response, handler);
/*     */       }
/*     */       
/* 136 */       if ((ex instanceof ConversionNotSupportedException)) {
/* 137 */         return handleConversionNotSupported((ConversionNotSupportedException)ex, request, response, handler);
/*     */       }
/* 139 */       if ((ex instanceof TypeMismatchException)) {
/* 140 */         return handleTypeMismatch((TypeMismatchException)ex, request, response, handler);
/*     */       }
/* 142 */       if ((ex instanceof HttpMessageNotReadableException)) {
/* 143 */         return handleHttpMessageNotReadable((HttpMessageNotReadableException)ex, request, response, handler);
/*     */       }
/* 145 */       if ((ex instanceof HttpMessageNotWritableException)) {
/* 146 */         return handleHttpMessageNotWritable((HttpMessageNotWritableException)ex, request, response, handler);
/*     */       }
/* 148 */       if ((ex instanceof MethodArgumentNotValidException)) {
/* 149 */         return handleMethodArgumentNotValidException((MethodArgumentNotValidException)ex, request, response, handler);
/*     */       }
/*     */       
/* 152 */       if ((ex instanceof MissingServletRequestPartException)) {
/* 153 */         return handleMissingServletRequestPartException((MissingServletRequestPartException)ex, request, response, handler);
/*     */       }
/*     */       
/* 156 */       if ((ex instanceof BindException)) {
/* 157 */         return handleBindException((BindException)ex, request, response, handler);
/*     */       }
/* 159 */       if ((ex instanceof NoHandlerFoundException)) {
/* 160 */         return handleNoHandlerFoundException((NoHandlerFoundException)ex, request, response, handler);
/*     */       }
/*     */     }
/*     */     catch (Exception handlerException) {
/* 164 */       if (this.logger.isWarnEnabled()) {
/* 165 */         this.logger.warn("Handling of [" + ex.getClass().getName() + "] resulted in Exception", handlerException);
/*     */       }
/*     */     }
/* 168 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected ModelAndView handleNoSuchRequestHandlingMethod(NoSuchRequestHandlingMethodException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 189 */     pageNotFoundLogger.warn(ex.getMessage());
/* 190 */     response.sendError(404);
/* 191 */     return new ModelAndView();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelAndView handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 210 */     pageNotFoundLogger.warn(ex.getMessage());
/* 211 */     String[] supportedMethods = ex.getSupportedMethods();
/* 212 */     if (supportedMethods != null) {
/* 213 */       response.setHeader("Allow", StringUtils.arrayToDelimitedString(supportedMethods, ", "));
/*     */     }
/* 215 */     response.sendError(405, ex.getMessage());
/* 216 */     return new ModelAndView();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelAndView handleHttpMediaTypeNotSupported(HttpMediaTypeNotSupportedException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 235 */     response.sendError(415);
/* 236 */     List<MediaType> mediaTypes = ex.getSupportedMediaTypes();
/* 237 */     if (!CollectionUtils.isEmpty(mediaTypes)) {
/* 238 */       response.setHeader("Accept", MediaType.toString(mediaTypes));
/*     */     }
/* 240 */     return new ModelAndView();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelAndView handleHttpMediaTypeNotAcceptable(HttpMediaTypeNotAcceptableException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 259 */     response.sendError(406);
/* 260 */     return new ModelAndView();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelAndView handleMissingPathVariable(MissingPathVariableException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 279 */     response.sendError(500, ex.getMessage());
/* 280 */     return new ModelAndView();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelAndView handleMissingServletRequestParameter(MissingServletRequestParameterException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 298 */     response.sendError(400, ex.getMessage());
/* 299 */     return new ModelAndView();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelAndView handleServletRequestBindingException(ServletRequestBindingException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 316 */     response.sendError(400, ex.getMessage());
/* 317 */     return new ModelAndView();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelAndView handleConversionNotSupported(ConversionNotSupportedException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 334 */     if (this.logger.isWarnEnabled()) {
/* 335 */       this.logger.warn("Failed to convert request element: " + ex);
/*     */     }
/* 337 */     sendServerError(ex, request, response);
/* 338 */     return new ModelAndView();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelAndView handleTypeMismatch(TypeMismatchException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 355 */     if (this.logger.isWarnEnabled()) {
/* 356 */       this.logger.warn("Failed to bind request element: " + ex);
/*     */     }
/* 358 */     response.sendError(400);
/* 359 */     return new ModelAndView();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelAndView handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 378 */     if (this.logger.isWarnEnabled()) {
/* 379 */       this.logger.warn("Failed to read HTTP message: " + ex);
/*     */     }
/* 381 */     response.sendError(400);
/* 382 */     return new ModelAndView();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelAndView handleHttpMessageNotWritable(HttpMessageNotWritableException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 401 */     if (this.logger.isWarnEnabled()) {
/* 402 */       this.logger.warn("Failed to write HTTP message: " + ex);
/*     */     }
/* 404 */     sendServerError(ex, request, response);
/* 405 */     return new ModelAndView();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelAndView handleMethodArgumentNotValidException(MethodArgumentNotValidException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 421 */     response.sendError(400);
/* 422 */     return new ModelAndView();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelAndView handleMissingServletRequestPartException(MissingServletRequestPartException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 438 */     response.sendError(400, ex.getMessage());
/* 439 */     return new ModelAndView();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelAndView handleBindException(BindException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 456 */     response.sendError(400);
/* 457 */     return new ModelAndView();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelAndView handleNoHandlerFoundException(NoHandlerFoundException ex, HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws IOException
/*     */   {
/* 477 */     response.sendError(404);
/* 478 */     return new ModelAndView();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void sendServerError(Exception ex, HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException
/*     */   {
/* 489 */     request.setAttribute("javax.servlet.error.exception", ex);
/* 490 */     response.sendError(500);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\support\DefaultHandlerExceptionResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */