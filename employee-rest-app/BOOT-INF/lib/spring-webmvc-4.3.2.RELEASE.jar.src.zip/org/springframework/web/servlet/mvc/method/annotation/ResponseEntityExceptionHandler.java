/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.ConversionNotSupportedException;
/*     */ import org.springframework.beans.TypeMismatchException;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.ResponseEntity;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.HttpRequestMethodNotSupportedException;
/*     */ import org.springframework.web.bind.MethodArgumentNotValidException;
/*     */ import org.springframework.web.bind.MissingPathVariableException;
/*     */ import org.springframework.web.bind.MissingServletRequestParameterException;
/*     */ import org.springframework.web.bind.ServletRequestBindingException;
/*     */ import org.springframework.web.bind.annotation.ExceptionHandler;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.multipart.support.MissingServletRequestPartException;
/*     */ import org.springframework.web.servlet.NoHandlerFoundException;
/*     */ import org.springframework.web.servlet.mvc.multiaction.NoSuchRequestHandlingMethodException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ResponseEntityExceptionHandler
/*     */ {
/*     */   public static final String PAGE_NOT_FOUND_LOG_CATEGORY = "org.springframework.web.servlet.PageNotFound";
/*  88 */   protected static final Log pageNotFoundLogger = LogFactory.getLog("org.springframework.web.servlet.PageNotFound");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  93 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @ExceptionHandler({NoSuchRequestHandlingMethodException.class, HttpRequestMethodNotSupportedException.class, HttpMediaTypeNotSupportedException.class, HttpMediaTypeNotAcceptableException.class, MissingPathVariableException.class, MissingServletRequestParameterException.class, ServletRequestBindingException.class, ConversionNotSupportedException.class, TypeMismatchException.class, HttpMessageNotReadableException.class, HttpMessageNotWritableException.class, MethodArgumentNotValidException.class, MissingServletRequestPartException.class, BindException.class, NoHandlerFoundException.class})
/*     */   public final ResponseEntity<Object> handleException(Exception ex, WebRequest request)
/*     */   {
/* 120 */     HttpHeaders headers = new HttpHeaders();
/* 121 */     if ((ex instanceof NoSuchRequestHandlingMethodException)) {
/* 122 */       HttpStatus status = HttpStatus.NOT_FOUND;
/* 123 */       return handleNoSuchRequestHandlingMethod((NoSuchRequestHandlingMethodException)ex, headers, status, request);
/*     */     }
/* 125 */     if ((ex instanceof HttpRequestMethodNotSupportedException)) {
/* 126 */       HttpStatus status = HttpStatus.METHOD_NOT_ALLOWED;
/* 127 */       return handleHttpRequestMethodNotSupported((HttpRequestMethodNotSupportedException)ex, headers, status, request);
/*     */     }
/* 129 */     if ((ex instanceof HttpMediaTypeNotSupportedException)) {
/* 130 */       HttpStatus status = HttpStatus.UNSUPPORTED_MEDIA_TYPE;
/* 131 */       return handleHttpMediaTypeNotSupported((HttpMediaTypeNotSupportedException)ex, headers, status, request);
/*     */     }
/* 133 */     if ((ex instanceof HttpMediaTypeNotAcceptableException)) {
/* 134 */       HttpStatus status = HttpStatus.NOT_ACCEPTABLE;
/* 135 */       return handleHttpMediaTypeNotAcceptable((HttpMediaTypeNotAcceptableException)ex, headers, status, request);
/*     */     }
/* 137 */     if ((ex instanceof MissingPathVariableException)) {
/* 138 */       HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
/* 139 */       return handleMissingPathVariable((MissingPathVariableException)ex, headers, status, request);
/*     */     }
/* 141 */     if ((ex instanceof MissingServletRequestParameterException)) {
/* 142 */       HttpStatus status = HttpStatus.BAD_REQUEST;
/* 143 */       return handleMissingServletRequestParameter((MissingServletRequestParameterException)ex, headers, status, request);
/*     */     }
/* 145 */     if ((ex instanceof ServletRequestBindingException)) {
/* 146 */       HttpStatus status = HttpStatus.BAD_REQUEST;
/* 147 */       return handleServletRequestBindingException((ServletRequestBindingException)ex, headers, status, request);
/*     */     }
/* 149 */     if ((ex instanceof ConversionNotSupportedException)) {
/* 150 */       HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
/* 151 */       return handleConversionNotSupported((ConversionNotSupportedException)ex, headers, status, request);
/*     */     }
/* 153 */     if ((ex instanceof TypeMismatchException)) {
/* 154 */       HttpStatus status = HttpStatus.BAD_REQUEST;
/* 155 */       return handleTypeMismatch((TypeMismatchException)ex, headers, status, request);
/*     */     }
/* 157 */     if ((ex instanceof HttpMessageNotReadableException)) {
/* 158 */       HttpStatus status = HttpStatus.BAD_REQUEST;
/* 159 */       return handleHttpMessageNotReadable((HttpMessageNotReadableException)ex, headers, status, request);
/*     */     }
/* 161 */     if ((ex instanceof HttpMessageNotWritableException)) {
/* 162 */       HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
/* 163 */       return handleHttpMessageNotWritable((HttpMessageNotWritableException)ex, headers, status, request);
/*     */     }
/* 165 */     if ((ex instanceof MethodArgumentNotValidException)) {
/* 166 */       HttpStatus status = HttpStatus.BAD_REQUEST;
/* 167 */       return handleMethodArgumentNotValid((MethodArgumentNotValidException)ex, headers, status, request);
/*     */     }
/* 169 */     if ((ex instanceof MissingServletRequestPartException)) {
/* 170 */       HttpStatus status = HttpStatus.BAD_REQUEST;
/* 171 */       return handleMissingServletRequestPart((MissingServletRequestPartException)ex, headers, status, request);
/*     */     }
/* 173 */     if ((ex instanceof BindException)) {
/* 174 */       HttpStatus status = HttpStatus.BAD_REQUEST;
/* 175 */       return handleBindException((BindException)ex, headers, status, request);
/*     */     }
/* 177 */     if ((ex instanceof NoHandlerFoundException)) {
/* 178 */       HttpStatus status = HttpStatus.NOT_FOUND;
/* 179 */       return handleNoHandlerFoundException((NoHandlerFoundException)ex, headers, status, request);
/*     */     }
/*     */     
/* 182 */     this.logger.warn("Unknown exception type: " + ex.getClass().getName());
/* 183 */     HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
/* 184 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 202 */     if (HttpStatus.INTERNAL_SERVER_ERROR.equals(status)) {
/* 203 */       request.setAttribute("javax.servlet.error.exception", ex, 0);
/*     */     }
/* 205 */     return new ResponseEntity(body, headers, status);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected ResponseEntity<Object> handleNoSuchRequestHandlingMethod(NoSuchRequestHandlingMethodException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 222 */     pageNotFoundLogger.warn(ex.getMessage());
/*     */     
/* 224 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 240 */     pageNotFoundLogger.warn(ex.getMessage());
/*     */     
/* 242 */     Set<HttpMethod> supportedMethods = ex.getSupportedHttpMethods();
/* 243 */     if (!supportedMethods.isEmpty()) {
/* 244 */       headers.setAllow(supportedMethods);
/*     */     }
/* 246 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(HttpMediaTypeNotSupportedException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 262 */     List<MediaType> mediaTypes = ex.getSupportedMediaTypes();
/* 263 */     if (!CollectionUtils.isEmpty(mediaTypes)) {
/* 264 */       headers.setAccept(mediaTypes);
/*     */     }
/*     */     
/* 267 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleHttpMediaTypeNotAcceptable(HttpMediaTypeNotAcceptableException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 282 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleMissingPathVariable(MissingPathVariableException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 298 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleMissingServletRequestParameter(MissingServletRequestParameterException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 313 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleServletRequestBindingException(ServletRequestBindingException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 328 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleConversionNotSupported(ConversionNotSupportedException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 343 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleTypeMismatch(TypeMismatchException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 358 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 373 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleHttpMessageNotWritable(HttpMessageNotWritableException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 388 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 403 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleMissingServletRequestPart(MissingServletRequestPartException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 418 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleBindException(BindException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 433 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleNoHandlerFoundException(NoHandlerFoundException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 449 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\method\annotation\ResponseEntityExceptionHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */