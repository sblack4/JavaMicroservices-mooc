/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.web.servlet.handler.AbstractHandlerMapping;
/*     */ import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
/*     */ import org.springframework.web.servlet.mvc.ParameterizableViewController;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ViewControllerRegistry
/*     */ {
/*  39 */   private final List<ViewControllerRegistration> registrations = new ArrayList(4);
/*     */   
/*  41 */   private final List<RedirectViewControllerRegistration> redirectRegistrations = new ArrayList(10);
/*     */   
/*     */ 
/*  44 */   private int order = 1;
/*     */   
/*     */ 
/*     */ 
/*     */   private ApplicationContext applicationContext;
/*     */   
/*     */ 
/*     */ 
/*     */   public ViewControllerRegistration addViewController(String urlPath)
/*     */   {
/*  54 */     ViewControllerRegistration registration = new ViewControllerRegistration(urlPath);
/*  55 */     registration.setApplicationContext(this.applicationContext);
/*  56 */     this.registrations.add(registration);
/*  57 */     return registration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RedirectViewControllerRegistration addRedirectViewController(String urlPath, String redirectUrl)
/*     */   {
/*  67 */     RedirectViewControllerRegistration registration = new RedirectViewControllerRegistration(urlPath, redirectUrl);
/*  68 */     registration.setApplicationContext(this.applicationContext);
/*  69 */     this.redirectRegistrations.add(registration);
/*  70 */     return registration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addStatusController(String urlPath, HttpStatus statusCode)
/*     */   {
/*  79 */     ViewControllerRegistration registration = new ViewControllerRegistration(urlPath);
/*  80 */     registration.setApplicationContext(this.applicationContext);
/*  81 */     registration.setStatusCode(statusCode);
/*  82 */     registration.getViewController().setStatusOnly(true);
/*  83 */     this.registrations.add(registration);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOrder(int order)
/*     */   {
/*  93 */     this.order = order;
/*     */   }
/*     */   
/*     */   protected void setApplicationContext(ApplicationContext applicationContext) {
/*  97 */     this.applicationContext = applicationContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractHandlerMapping getHandlerMapping()
/*     */   {
/* 106 */     if ((this.registrations.isEmpty()) && (this.redirectRegistrations.isEmpty())) {
/* 107 */       return null;
/*     */     }
/* 109 */     Map<String, Object> urlMap = new LinkedHashMap();
/* 110 */     for (ViewControllerRegistration registration : this.registrations) {
/* 111 */       urlMap.put(registration.getUrlPath(), registration.getViewController());
/*     */     }
/* 113 */     for (RedirectViewControllerRegistration registration : this.redirectRegistrations) {
/* 114 */       urlMap.put(registration.getUrlPath(), registration.getViewController());
/*     */     }
/* 116 */     SimpleUrlHandlerMapping handlerMapping = new SimpleUrlHandlerMapping();
/* 117 */     handlerMapping.setOrder(this.order);
/* 118 */     handlerMapping.setUrlMap(urlMap);
/* 119 */     return handlerMapping;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\config\annotation\ViewControllerRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */