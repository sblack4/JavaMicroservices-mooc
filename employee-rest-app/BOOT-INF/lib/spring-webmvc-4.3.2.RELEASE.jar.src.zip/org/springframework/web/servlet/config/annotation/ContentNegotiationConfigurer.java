/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.accept.ContentNegotiationManagerFactoryBean;
/*     */ import org.springframework.web.accept.ContentNegotiationStrategy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContentNegotiationConfigurer
/*     */ {
/*  88 */   private final ContentNegotiationManagerFactoryBean factory = new ContentNegotiationManagerFactoryBean();
/*     */   
/*     */ 
/*  91 */   private final Map<String, MediaType> mediaTypes = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationConfigurer(ServletContext servletContext)
/*     */   {
/*  98 */     this.factory.setServletContext(servletContext);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationConfigurer favorPathExtension(boolean favorPathExtension)
/*     */   {
/* 110 */     this.factory.setFavorPathExtension(favorPathExtension);
/* 111 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationConfigurer mediaType(String extension, MediaType mediaType)
/*     */   {
/* 130 */     this.mediaTypes.put(extension, mediaType);
/* 131 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationConfigurer mediaTypes(Map<String, MediaType> mediaTypes)
/*     */   {
/* 140 */     if (mediaTypes != null) {
/* 141 */       this.mediaTypes.putAll(mediaTypes);
/*     */     }
/* 143 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationConfigurer replaceMediaTypes(Map<String, MediaType> mediaTypes)
/*     */   {
/* 152 */     this.mediaTypes.clear();
/* 153 */     mediaTypes(mediaTypes);
/* 154 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationConfigurer ignoreUnknownPathExtensions(boolean ignore)
/*     */   {
/* 164 */     this.factory.setIgnoreUnknownPathExtensions(ignore);
/* 165 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationConfigurer useJaf(boolean useJaf)
/*     */   {
/* 176 */     this.factory.setUseJaf(useJaf);
/* 177 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationConfigurer favorParameter(boolean favorParameter)
/*     */   {
/* 188 */     this.factory.setFavorParameter(favorParameter);
/* 189 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationConfigurer parameterName(String parameterName)
/*     */   {
/* 197 */     this.factory.setParameterName(parameterName);
/* 198 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationConfigurer ignoreAcceptHeader(boolean ignoreAcceptHeader)
/*     */   {
/* 206 */     this.factory.setIgnoreAcceptHeader(ignoreAcceptHeader);
/* 207 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationConfigurer defaultContentType(MediaType defaultContentType)
/*     */   {
/* 216 */     this.factory.setDefaultContentType(defaultContentType);
/* 217 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationConfigurer defaultContentTypeStrategy(ContentNegotiationStrategy defaultStrategy)
/*     */   {
/* 228 */     this.factory.setDefaultContentTypeStrategy(defaultStrategy);
/* 229 */     return this;
/*     */   }
/*     */   
/*     */   protected ContentNegotiationManager getContentNegotiationManager() throws Exception {
/* 233 */     this.factory.addMediaTypes(this.mediaTypes);
/* 234 */     this.factory.afterPropertiesSet();
/* 235 */     return this.factory.getObject();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\config\annotation\ContentNegotiationConfigurer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */