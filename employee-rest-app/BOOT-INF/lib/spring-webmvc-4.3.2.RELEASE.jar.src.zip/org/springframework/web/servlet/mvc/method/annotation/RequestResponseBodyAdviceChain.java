/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.server.ServerHttpRequest;
/*     */ import org.springframework.http.server.ServerHttpResponse;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.web.method.ControllerAdviceBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RequestResponseBodyAdviceChain
/*     */   implements RequestBodyAdvice, ResponseBodyAdvice<Object>
/*     */ {
/*  45 */   private final List<Object> requestBodyAdvice = new ArrayList(4);
/*     */   
/*  47 */   private final List<Object> responseBodyAdvice = new ArrayList(4);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RequestResponseBodyAdviceChain(List<Object> requestResponseBodyAdvice)
/*     */   {
/*  55 */     initAdvice(requestResponseBodyAdvice);
/*     */   }
/*     */   
/*     */   private void initAdvice(List<Object> requestResponseBodyAdvice) {
/*  59 */     if (requestResponseBodyAdvice == null) {
/*  60 */       return;
/*     */     }
/*  62 */     for (Object advice : requestResponseBodyAdvice)
/*     */     {
/*  64 */       Class<?> beanType = (advice instanceof ControllerAdviceBean) ? ((ControllerAdviceBean)advice).getBeanType() : advice.getClass();
/*  65 */       if (RequestBodyAdvice.class.isAssignableFrom(beanType)) {
/*  66 */         this.requestBodyAdvice.add(advice);
/*     */       }
/*  68 */       else if (ResponseBodyAdvice.class.isAssignableFrom(beanType)) {
/*  69 */         this.responseBodyAdvice.add(advice);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private List<Object> getAdvice(Class<?> adviceType) {
/*  75 */     if (RequestBodyAdvice.class == adviceType) {
/*  76 */       return this.requestBodyAdvice;
/*     */     }
/*  78 */     if (ResponseBodyAdvice.class == adviceType) {
/*  79 */       return this.responseBodyAdvice;
/*     */     }
/*     */     
/*  82 */     throw new IllegalArgumentException("Unexpected adviceType: " + adviceType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean supports(MethodParameter param, Type type, Class<? extends HttpMessageConverter<?>> converterType)
/*     */   {
/*  89 */     throw new UnsupportedOperationException("Not implemented");
/*     */   }
/*     */   
/*     */   public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType)
/*     */   {
/*  94 */     throw new UnsupportedOperationException("Not implemented");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object handleEmptyBody(Object body, HttpInputMessage inputMessage, MethodParameter parameter, Type targetType, Class<? extends HttpMessageConverter<?>> converterType)
/*     */   {
/* 101 */     for (RequestBodyAdvice advice : getMatchingAdvice(parameter, RequestBodyAdvice.class)) {
/* 102 */       if (advice.supports(parameter, targetType, converterType)) {
/* 103 */         body = advice.handleEmptyBody(body, inputMessage, parameter, targetType, converterType);
/*     */       }
/*     */     }
/* 106 */     return body;
/*     */   }
/*     */   
/*     */ 
/*     */   public HttpInputMessage beforeBodyRead(HttpInputMessage request, MethodParameter parameter, Type targetType, Class<? extends HttpMessageConverter<?>> converterType)
/*     */     throws IOException
/*     */   {
/* 113 */     for (RequestBodyAdvice advice : getMatchingAdvice(parameter, RequestBodyAdvice.class)) {
/* 114 */       if (advice.supports(parameter, targetType, converterType)) {
/* 115 */         request = advice.beforeBodyRead(request, parameter, targetType, converterType);
/*     */       }
/*     */     }
/* 118 */     return request;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object afterBodyRead(Object body, HttpInputMessage inputMessage, MethodParameter parameter, Type targetType, Class<? extends HttpMessageConverter<?>> converterType)
/*     */   {
/* 125 */     for (RequestBodyAdvice advice : getMatchingAdvice(parameter, RequestBodyAdvice.class)) {
/* 126 */       if (advice.supports(parameter, targetType, converterType)) {
/* 127 */         body = advice.afterBodyRead(body, inputMessage, parameter, targetType, converterType);
/*     */       }
/*     */     }
/* 130 */     return body;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType contentType, Class<? extends HttpMessageConverter<?>> converterType, ServerHttpRequest request, ServerHttpResponse response)
/*     */   {
/* 138 */     return processBody(body, returnType, contentType, converterType, request, response);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private <T> Object processBody(Object body, MethodParameter returnType, MediaType contentType, Class<? extends HttpMessageConverter<?>> converterType, ServerHttpRequest request, ServerHttpResponse response)
/*     */   {
/* 146 */     for (ResponseBodyAdvice<?> advice : getMatchingAdvice(returnType, ResponseBodyAdvice.class)) {
/* 147 */       if (advice.supports(returnType, converterType)) {
/* 148 */         body = advice.beforeBodyWrite(body, returnType, contentType, converterType, request, response);
/*     */       }
/*     */     }
/*     */     
/* 152 */     return body;
/*     */   }
/*     */   
/*     */   private <A> List<A> getMatchingAdvice(MethodParameter parameter, Class<? extends A> adviceType)
/*     */   {
/* 157 */     List<Object> availableAdvice = getAdvice(adviceType);
/* 158 */     if (CollectionUtils.isEmpty(availableAdvice)) {
/* 159 */       return Collections.emptyList();
/*     */     }
/* 161 */     List<A> result = new ArrayList(availableAdvice.size());
/* 162 */     for (Object advice : availableAdvice) {
/* 163 */       if ((advice instanceof ControllerAdviceBean)) {
/* 164 */         ControllerAdviceBean adviceBean = (ControllerAdviceBean)advice;
/* 165 */         if (adviceBean.isApplicableToBeanType(parameter.getContainingClass()))
/*     */         {
/*     */ 
/* 168 */           advice = adviceBean.resolveBean();
/*     */         }
/* 170 */       } else if (adviceType.isAssignableFrom(advice.getClass())) {
/* 171 */         result.add(advice);
/*     */       }
/*     */     }
/* 174 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\method\annotation\RequestResponseBodyAdviceChain.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */