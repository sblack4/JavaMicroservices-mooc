/*     */ package org.springframework.web.servlet.config;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.springframework.web.cors.CorsConfiguration;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CorsBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*  45 */   private static final List<String> DEFAULT_ALLOWED_ORIGINS = Arrays.asList(new String[] { "*" });
/*     */   
/*     */ 
/*  48 */   private static final List<String> DEFAULT_ALLOWED_METHODS = Arrays.asList(new String[] {HttpMethod.GET.name(), HttpMethod.HEAD.name(), HttpMethod.POST.name() });
/*     */   
/*  50 */   private static final List<String> DEFAULT_ALLOWED_HEADERS = Arrays.asList(new String[] { "*" });
/*     */   
/*     */ 
/*     */   private static final boolean DEFAULT_ALLOW_CREDENTIALS = true;
/*     */   
/*     */   private static final long DEFAULT_MAX_AGE = 1600L;
/*     */   
/*     */ 
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext)
/*     */   {
/*  60 */     Map<String, CorsConfiguration> corsConfigurations = new LinkedHashMap();
/*  61 */     List<Element> mappings = DomUtils.getChildElementsByTagName(element, "mapping");
/*     */     CorsConfiguration config;
/*  63 */     if (mappings.isEmpty()) {
/*  64 */       config = new CorsConfiguration();
/*  65 */       config.setAllowedOrigins(DEFAULT_ALLOWED_ORIGINS);
/*  66 */       config.setAllowedMethods(DEFAULT_ALLOWED_METHODS);
/*  67 */       config.setAllowedHeaders(DEFAULT_ALLOWED_HEADERS);
/*  68 */       config.setAllowCredentials(Boolean.valueOf(true));
/*  69 */       config.setMaxAge(Long.valueOf(1600L));
/*  70 */       corsConfigurations.put("/**", config);
/*     */     }
/*     */     else {
/*  73 */       for (Element mapping : mappings) {
/*  74 */         CorsConfiguration config = new CorsConfiguration();
/*  75 */         if (mapping.hasAttribute("allowed-origins")) {
/*  76 */           String[] allowedOrigins = StringUtils.tokenizeToStringArray(mapping.getAttribute("allowed-origins"), ",");
/*  77 */           config.setAllowedOrigins(Arrays.asList(allowedOrigins));
/*     */         }
/*     */         else {
/*  80 */           config.setAllowedOrigins(DEFAULT_ALLOWED_ORIGINS);
/*     */         }
/*  82 */         if (mapping.hasAttribute("allowed-methods")) {
/*  83 */           String[] allowedMethods = StringUtils.tokenizeToStringArray(mapping.getAttribute("allowed-methods"), ",");
/*  84 */           config.setAllowedMethods(Arrays.asList(allowedMethods));
/*     */         }
/*     */         else {
/*  87 */           config.setAllowedMethods(DEFAULT_ALLOWED_METHODS);
/*     */         }
/*  89 */         if (mapping.hasAttribute("allowed-headers")) {
/*  90 */           String[] allowedHeaders = StringUtils.tokenizeToStringArray(mapping.getAttribute("allowed-headers"), ",");
/*  91 */           config.setAllowedHeaders(Arrays.asList(allowedHeaders));
/*     */         }
/*     */         else {
/*  94 */           config.setAllowedHeaders(DEFAULT_ALLOWED_HEADERS);
/*     */         }
/*  96 */         if (mapping.hasAttribute("exposed-headers")) {
/*  97 */           String[] exposedHeaders = StringUtils.tokenizeToStringArray(mapping.getAttribute("exposed-headers"), ",");
/*  98 */           config.setExposedHeaders(Arrays.asList(exposedHeaders));
/*     */         }
/* 100 */         if (mapping.hasAttribute("allow-credentials")) {
/* 101 */           config.setAllowCredentials(Boolean.valueOf(Boolean.parseBoolean(mapping.getAttribute("allow-credentials"))));
/*     */         }
/*     */         else {
/* 104 */           config.setAllowCredentials(Boolean.valueOf(true));
/*     */         }
/* 106 */         if (mapping.hasAttribute("max-age")) {
/* 107 */           config.setMaxAge(Long.valueOf(Long.parseLong(mapping.getAttribute("max-age"))));
/*     */         }
/*     */         else {
/* 110 */           config.setMaxAge(Long.valueOf(1600L));
/*     */         }
/* 112 */         corsConfigurations.put(mapping.getAttribute("path"), config);
/*     */       }
/*     */     }
/*     */     
/* 116 */     MvcNamespaceUtils.registerCorsConfigurations(corsConfigurations, parserContext, parserContext.extractSource(element));
/* 117 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\config\CorsBeanDefinitionParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */