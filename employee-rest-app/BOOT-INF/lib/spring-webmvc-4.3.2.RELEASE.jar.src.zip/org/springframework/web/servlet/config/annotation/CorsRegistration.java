/*    */ package org.springframework.web.servlet.config.annotation;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.web.bind.annotation.CrossOrigin;
/*    */ import org.springframework.web.cors.CorsConfiguration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CorsRegistration
/*    */ {
/*    */   private final String pathPattern;
/*    */   private final CorsConfiguration config;
/*    */   
/*    */   public CorsRegistration(String pathPattern)
/*    */   {
/* 50 */     this.pathPattern = pathPattern;
/*    */     
/* 52 */     this.config = new CorsConfiguration();
/* 53 */     this.config.setAllowedOrigins(Arrays.asList(CrossOrigin.DEFAULT_ORIGINS));
/* 54 */     this.config.setAllowedMethods(Arrays.asList(new String[] { HttpMethod.GET.name(), HttpMethod.HEAD
/* 55 */       .name(), HttpMethod.POST.name() }));
/* 56 */     this.config.setAllowedHeaders(Arrays.asList(CrossOrigin.DEFAULT_ALLOWED_HEADERS));
/* 57 */     this.config.setAllowCredentials(Boolean.valueOf(true));
/* 58 */     this.config.setMaxAge(Long.valueOf(1800L));
/*    */   }
/*    */   
/*    */   public CorsRegistration allowedOrigins(String... origins) {
/* 62 */     this.config.setAllowedOrigins(new ArrayList(Arrays.asList(origins)));
/* 63 */     return this;
/*    */   }
/*    */   
/*    */   public CorsRegistration allowedMethods(String... methods) {
/* 67 */     this.config.setAllowedMethods(new ArrayList(Arrays.asList(methods)));
/* 68 */     return this;
/*    */   }
/*    */   
/*    */   public CorsRegistration allowedHeaders(String... headers) {
/* 72 */     this.config.setAllowedHeaders(new ArrayList(Arrays.asList(headers)));
/* 73 */     return this;
/*    */   }
/*    */   
/*    */   public CorsRegistration exposedHeaders(String... headers) {
/* 77 */     this.config.setExposedHeaders(new ArrayList(Arrays.asList(headers)));
/* 78 */     return this;
/*    */   }
/*    */   
/*    */   public CorsRegistration maxAge(long maxAge) {
/* 82 */     this.config.setMaxAge(Long.valueOf(maxAge));
/* 83 */     return this;
/*    */   }
/*    */   
/*    */   public CorsRegistration allowCredentials(boolean allowCredentials) {
/* 87 */     this.config.setAllowCredentials(Boolean.valueOf(allowCredentials));
/* 88 */     return this;
/*    */   }
/*    */   
/*    */   protected String getPathPattern() {
/* 92 */     return this.pathPattern;
/*    */   }
/*    */   
/*    */   protected CorsConfiguration getCorsConfiguration() {
/* 96 */     return this.config;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\config\annotation\CorsRegistration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */