/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.aop.target.EmptyTargetSource;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
/*     */ import org.springframework.cglib.core.SpringNamingPolicy;
/*     */ import org.springframework.cglib.proxy.Callback;
/*     */ import org.springframework.cglib.proxy.Enhancer;
/*     */ import org.springframework.cglib.proxy.Factory;
/*     */ import org.springframework.cglib.proxy.MethodProxy;
/*     */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*     */ import org.springframework.core.MethodIntrospector;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.core.annotation.SynthesizingMethodParameter;
/*     */ import org.springframework.objenesis.ObjenesisException;
/*     */ import org.springframework.objenesis.SpringObjenesis;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.ReflectionUtils.MethodFilter;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.request.RequestAttributes;
/*     */ import org.springframework.web.context.request.RequestContextHolder;
/*     */ import org.springframework.web.context.request.ServletRequestAttributes;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ import org.springframework.web.method.annotation.RequestParamMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.CompositeUriComponentsContributor;
/*     */ import org.springframework.web.method.support.UriComponentsContributor;
/*     */ import org.springframework.web.servlet.DispatcherServlet;
/*     */ import org.springframework.web.servlet.mvc.method.RequestMappingInfoHandlerMapping;
/*     */ import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
/*     */ import org.springframework.web.util.UriComponents;
/*     */ import org.springframework.web.util.UriComponents.UriTemplateVariables;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MvcUriComponentsBuilder
/*     */ {
/*     */   public static final String MVC_URI_COMPONENTS_CONTRIBUTOR_BEAN_NAME = "mvcUriComponentsContributor";
/*  97 */   private static final Log logger = LogFactory.getLog(MvcUriComponentsBuilder.class);
/*     */   
/*  99 */   private static final SpringObjenesis objenesis = new SpringObjenesis();
/*     */   
/* 101 */   private static final PathMatcher pathMatcher = new AntPathMatcher();
/*     */   
/* 103 */   private static final ParameterNameDiscoverer parameterNameDiscoverer = new DefaultParameterNameDiscoverer();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 108 */   private static final CompositeUriComponentsContributor defaultUriComponentsContributor = new CompositeUriComponentsContributor(new UriComponentsContributor[] { new PathVariableMethodArgumentResolver(), new RequestParamMethodArgumentResolver(false) });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final UriComponentsBuilder baseUrl;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MvcUriComponentsBuilder(UriComponentsBuilder baseUrl)
/*     */   {
/* 124 */     Assert.notNull(baseUrl, "'baseUrl' is required");
/* 125 */     this.baseUrl = baseUrl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MvcUriComponentsBuilder relativeTo(UriComponentsBuilder baseUrl)
/*     */   {
/* 135 */     return new MvcUriComponentsBuilder(baseUrl);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UriComponentsBuilder fromController(Class<?> controllerType)
/*     */   {
/* 147 */     return fromController(null, controllerType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UriComponentsBuilder fromController(UriComponentsBuilder builder, Class<?> controllerType)
/*     */   {
/* 163 */     builder = getBaseUrlToUse(builder);
/* 164 */     String mapping = getTypeRequestMapping(controllerType);
/* 165 */     return builder.path(mapping);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UriComponentsBuilder fromMethodName(Class<?> controllerType, String methodName, Object... args)
/*     */   {
/* 182 */     Method method = getMethod(controllerType, methodName, args);
/* 183 */     return fromMethodInternal(null, controllerType, method, args);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UriComponentsBuilder fromMethodName(UriComponentsBuilder builder, Class<?> controllerType, String methodName, Object... args)
/*     */   {
/* 203 */     Method method = getMethod(controllerType, methodName, args);
/* 204 */     return fromMethodInternal(builder, controllerType, method, args);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UriComponentsBuilder fromMethodCall(Object info)
/*     */   {
/* 243 */     Assert.isInstanceOf(MethodInvocationInfo.class, info);
/* 244 */     MethodInvocationInfo invocationInfo = (MethodInvocationInfo)info;
/* 245 */     Class<?> controllerType = invocationInfo.getControllerType();
/* 246 */     Method method = invocationInfo.getControllerMethod();
/* 247 */     Object[] arguments = invocationInfo.getArgumentValues();
/* 248 */     return fromMethodInternal(null, controllerType, method, arguments);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UriComponentsBuilder fromMethodCall(UriComponentsBuilder builder, Object info)
/*     */   {
/* 263 */     Assert.isInstanceOf(MethodInvocationInfo.class, info);
/* 264 */     MethodInvocationInfo invocationInfo = (MethodInvocationInfo)info;
/* 265 */     Class<?> controllerType = invocationInfo.getControllerType();
/* 266 */     Method method = invocationInfo.getControllerMethod();
/* 267 */     Object[] arguments = invocationInfo.getArgumentValues();
/* 268 */     return fromMethodInternal(builder, controllerType, method, arguments);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MethodArgumentBuilder fromMappingName(String mappingName)
/*     */   {
/* 313 */     return fromMappingName(null, mappingName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MethodArgumentBuilder fromMappingName(UriComponentsBuilder builder, String name)
/*     */   {
/* 330 */     RequestMappingInfoHandlerMapping handlerMapping = getRequestMappingInfoHandlerMapping();
/* 331 */     List<HandlerMethod> handlerMethods = handlerMapping.getHandlerMethodsForMappingName(name);
/* 332 */     if (handlerMethods == null) {
/* 333 */       throw new IllegalArgumentException("Mapping mappingName not found: " + name);
/*     */     }
/* 335 */     if (handlerMethods.size() != 1) {
/* 336 */       throw new IllegalArgumentException("No unique match for mapping mappingName " + name + ": " + handlerMethods);
/*     */     }
/*     */     
/* 339 */     HandlerMethod handlerMethod = (HandlerMethod)handlerMethods.get(0);
/* 340 */     Class<?> controllerType = handlerMethod.getBeanType();
/* 341 */     Method method = handlerMethod.getMethod();
/* 342 */     return new MethodArgumentBuilder(builder, controllerType, method);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UriComponentsBuilder fromMethod(Class<?> controllerType, Method method, Object... args)
/*     */   {
/* 360 */     return fromMethodInternal(null, controllerType, method, args);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UriComponentsBuilder fromMethod(UriComponentsBuilder baseUrl, Class<?> controllerType, Method method, Object... args)
/*     */   {
/* 380 */     return fromMethodInternal(baseUrl, controllerType != null ? controllerType : method
/* 381 */       .getDeclaringClass(), method, args);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static UriComponentsBuilder fromMethod(Method method, Object... args)
/*     */   {
/* 392 */     return fromMethodInternal(null, method.getDeclaringClass(), method, args);
/*     */   }
/*     */   
/*     */ 
/*     */   private static UriComponentsBuilder fromMethodInternal(UriComponentsBuilder baseUrl, Class<?> controllerType, Method method, Object... args)
/*     */   {
/* 398 */     baseUrl = getBaseUrlToUse(baseUrl);
/* 399 */     String typePath = getTypeRequestMapping(controllerType);
/* 400 */     String methodPath = getMethodRequestMapping(method);
/* 401 */     String path = pathMatcher.combine(typePath, methodPath);
/* 402 */     baseUrl.path(path);
/* 403 */     UriComponents uriComponents = applyContributors(baseUrl, method, args);
/* 404 */     return UriComponentsBuilder.newInstance().uriComponents(uriComponents);
/*     */   }
/*     */   
/*     */   private static UriComponentsBuilder getBaseUrlToUse(UriComponentsBuilder baseUrl) {
/* 408 */     if (baseUrl != null) {
/* 409 */       return baseUrl.cloneBuilder();
/*     */     }
/*     */     
/* 412 */     return ServletUriComponentsBuilder.fromCurrentServletMapping();
/*     */   }
/*     */   
/*     */   private static String getTypeRequestMapping(Class<?> controllerType)
/*     */   {
/* 417 */     Assert.notNull(controllerType, "'controllerType' must not be null");
/* 418 */     RequestMapping requestMapping = (RequestMapping)AnnotatedElementUtils.findMergedAnnotation(controllerType, RequestMapping.class);
/* 419 */     if (requestMapping == null) {
/* 420 */       return "/";
/*     */     }
/* 422 */     String[] paths = requestMapping.path();
/* 423 */     if ((ObjectUtils.isEmpty(paths)) || (StringUtils.isEmpty(paths[0]))) {
/* 424 */       return "/";
/*     */     }
/* 426 */     if ((paths.length > 1) && (logger.isWarnEnabled())) {
/* 427 */       logger.warn("Multiple paths on controller " + controllerType.getName() + ", using first one");
/*     */     }
/* 429 */     return paths[0];
/*     */   }
/*     */   
/*     */   private static String getMethodRequestMapping(Method method) {
/* 433 */     Assert.notNull(method, "'method' must not be null");
/* 434 */     RequestMapping requestMapping = (RequestMapping)AnnotatedElementUtils.findMergedAnnotation(method, RequestMapping.class);
/* 435 */     if (requestMapping == null) {
/* 436 */       throw new IllegalArgumentException("No @RequestMapping on: " + method.toGenericString());
/*     */     }
/* 438 */     String[] paths = requestMapping.path();
/* 439 */     if ((ObjectUtils.isEmpty(paths)) || (StringUtils.isEmpty(paths[0]))) {
/* 440 */       return "/";
/*     */     }
/* 442 */     if ((paths.length > 1) && (logger.isWarnEnabled())) {
/* 443 */       logger.warn("Multiple paths on method " + method.toGenericString() + ", using first one");
/*     */     }
/* 445 */     return paths[0];
/*     */   }
/*     */   
/*     */   private static Method getMethod(Class<?> controllerType, String methodName, final Object... args) {
/* 449 */     ReflectionUtils.MethodFilter selector = new ReflectionUtils.MethodFilter()
/*     */     {
/*     */       public boolean matches(Method method) {
/* 452 */         String name = method.getName();
/* 453 */         int argLength = method.getParameterTypes().length;
/* 454 */         return (name.equals(this.val$methodName)) && (argLength == args.length);
/*     */       }
/* 456 */     };
/* 457 */     Set<Method> methods = MethodIntrospector.selectMethods(controllerType, selector);
/* 458 */     if (methods.size() == 1) {
/* 459 */       return (Method)methods.iterator().next();
/*     */     }
/* 461 */     if (methods.size() > 1) {
/* 462 */       throw new IllegalArgumentException(String.format("Found two methods named '%s' accepting arguments %s in controller %s: [%s]", new Object[] { methodName, 
/*     */       
/* 464 */         Arrays.asList(args), controllerType.getName(), methods }));
/*     */     }
/*     */     
/*     */ 
/* 468 */     throw new IllegalArgumentException("No method named '" + methodName + "' with " + args.length + " arguments found in controller " + controllerType.getName());
/*     */   }
/*     */   
/*     */   private static UriComponents applyContributors(UriComponentsBuilder builder, Method method, Object... args)
/*     */   {
/* 473 */     CompositeUriComponentsContributor contributor = getConfiguredUriComponentsContributor();
/* 474 */     if (contributor == null) {
/* 475 */       logger.debug("Using default CompositeUriComponentsContributor");
/* 476 */       contributor = defaultUriComponentsContributor;
/*     */     }
/*     */     
/* 479 */     int paramCount = method.getParameterTypes().length;
/* 480 */     int argCount = args.length;
/* 481 */     if (paramCount != argCount) {
/* 482 */       throw new IllegalArgumentException("Number of method parameters " + paramCount + " does not match number of argument values " + argCount);
/*     */     }
/*     */     
/*     */ 
/* 486 */     Map<String, Object> uriVars = new HashMap();
/* 487 */     for (int i = 0; i < paramCount; i++) {
/* 488 */       MethodParameter param = new SynthesizingMethodParameter(method, i);
/* 489 */       param.initParameterNameDiscovery(parameterNameDiscoverer);
/* 490 */       contributor.contributeMethodArgument(param, args[i], builder, uriVars);
/*     */     }
/*     */     
/*     */ 
/* 494 */     builder.build().expand(new UriComponents.UriTemplateVariables()
/*     */     {
/*     */       public Object getValue(String name) {
/* 497 */         return this.val$uriVars.containsKey(name) ? this.val$uriVars.get(name) : UriComponents.UriTemplateVariables.SKIP_VALUE;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private static CompositeUriComponentsContributor getConfiguredUriComponentsContributor() {
/* 503 */     WebApplicationContext wac = getWebApplicationContext();
/* 504 */     if (wac == null) {
/* 505 */       return null;
/*     */     }
/*     */     try {
/* 508 */       return (CompositeUriComponentsContributor)wac.getBean("mvcUriComponentsContributor", CompositeUriComponentsContributor.class);
/*     */     }
/*     */     catch (NoSuchBeanDefinitionException ex) {
/* 511 */       if (logger.isDebugEnabled()) {
/* 512 */         logger.debug("No CompositeUriComponentsContributor bean with name 'mvcUriComponentsContributor'");
/*     */       }
/*     */     }
/* 515 */     return null;
/*     */   }
/*     */   
/*     */   private static RequestMappingInfoHandlerMapping getRequestMappingInfoHandlerMapping()
/*     */   {
/* 520 */     WebApplicationContext wac = getWebApplicationContext();
/* 521 */     Assert.notNull(wac, "Cannot lookup handler method mappings without WebApplicationContext");
/*     */     try {
/* 523 */       return (RequestMappingInfoHandlerMapping)wac.getBean(RequestMappingInfoHandlerMapping.class);
/*     */     }
/*     */     catch (NoUniqueBeanDefinitionException ex) {
/* 526 */       throw new IllegalStateException("More than one RequestMappingInfoHandlerMapping beans found", ex);
/*     */     }
/*     */     catch (NoSuchBeanDefinitionException ex) {
/* 529 */       throw new IllegalStateException("No RequestMappingInfoHandlerMapping bean", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private static WebApplicationContext getWebApplicationContext() {
/* 534 */     RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
/* 535 */     if (requestAttributes == null) {
/* 536 */       logger.debug("No request bound to the current thread: is DispatcherSerlvet used?");
/* 537 */       return null;
/*     */     }
/*     */     
/* 540 */     HttpServletRequest request = ((ServletRequestAttributes)requestAttributes).getRequest();
/* 541 */     if (request == null) {
/* 542 */       logger.debug("Request bound to current thread is not an HttpServletRequest");
/* 543 */       return null;
/*     */     }
/*     */     
/* 546 */     String attributeName = DispatcherServlet.WEB_APPLICATION_CONTEXT_ATTRIBUTE;
/* 547 */     WebApplicationContext wac = (WebApplicationContext)request.getAttribute(attributeName);
/* 548 */     if (wac == null) {
/* 549 */       logger.debug("No WebApplicationContext found: not in a DispatcherServlet request?");
/* 550 */       return null;
/*     */     }
/* 552 */     return wac;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T> T on(Class<T> controllerType)
/*     */   {
/* 568 */     return (T)controller(controllerType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T> T controller(Class<T> controllerType)
/*     */   {
/* 590 */     Assert.notNull(controllerType, "'controllerType' must not be null");
/* 591 */     return (T)initProxy(controllerType, new ControllerMethodInvocationInterceptor(controllerType));
/*     */   }
/*     */   
/*     */   private static <T> T initProxy(Class<?> type, ControllerMethodInvocationInterceptor interceptor)
/*     */   {
/* 596 */     if (type.isInterface()) {
/* 597 */       ProxyFactory factory = new ProxyFactory(EmptyTargetSource.INSTANCE);
/* 598 */       factory.addInterface(type);
/* 599 */       factory.addInterface(MethodInvocationInfo.class);
/* 600 */       factory.addAdvice(interceptor);
/* 601 */       return (T)factory.getProxy();
/*     */     }
/*     */     
/*     */ 
/* 605 */     Enhancer enhancer = new Enhancer();
/* 606 */     enhancer.setSuperclass(type);
/* 607 */     enhancer.setInterfaces(new Class[] { MethodInvocationInfo.class });
/* 608 */     enhancer.setNamingPolicy(SpringNamingPolicy.INSTANCE);
/* 609 */     enhancer.setCallbackType(org.springframework.cglib.proxy.MethodInterceptor.class);
/*     */     
/* 611 */     Class<?> proxyClass = enhancer.createClass();
/* 612 */     Object proxy = null;
/*     */     
/* 614 */     if (objenesis.isWorthTrying()) {
/*     */       try {
/* 616 */         proxy = objenesis.newInstance(proxyClass, enhancer.getUseCache());
/*     */       }
/*     */       catch (ObjenesisException ex) {
/* 619 */         logger.debug("Unable to instantiate controller proxy using Objenesis, falling back to regular construction", ex);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 624 */     if (proxy == null) {
/*     */       try {
/* 626 */         proxy = proxyClass.newInstance();
/*     */       }
/*     */       catch (Throwable ex) {
/* 629 */         throw new IllegalStateException("Unable to instantiate controller proxy using Objenesis, and regular controller instantiation via default constructor fails as well", ex);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 634 */     ((Factory)proxy).setCallbacks(new Callback[] { interceptor });
/* 635 */     return (T)proxy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder withController(Class<?> controllerType)
/*     */   {
/* 645 */     return fromController(this.baseUrl, controllerType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder withMethodName(Class<?> controllerType, String methodName, Object... args)
/*     */   {
/* 654 */     return fromMethodName(this.baseUrl, controllerType, methodName, args);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder withMethodCall(Object invocationInfo)
/*     */   {
/* 663 */     return fromMethodCall(this.baseUrl, invocationInfo);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MethodArgumentBuilder withMappingName(String mappingName)
/*     */   {
/* 672 */     return fromMappingName(this.baseUrl, mappingName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder withMethod(Class<?> controllerType, Method method, Object... args)
/*     */   {
/* 681 */     return fromMethod(this.baseUrl, controllerType, method, args);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class ControllerMethodInvocationInterceptor
/*     */     implements org.springframework.cglib.proxy.MethodInterceptor, org.aopalliance.intercept.MethodInterceptor
/*     */   {
/* 689 */     private static final Method getControllerMethod = ReflectionUtils.findMethod(MvcUriComponentsBuilder.MethodInvocationInfo.class, "getControllerMethod");
/*     */     
/*     */ 
/* 692 */     private static final Method getArgumentValues = ReflectionUtils.findMethod(MvcUriComponentsBuilder.MethodInvocationInfo.class, "getArgumentValues");
/*     */     
/*     */ 
/* 695 */     private static final Method getControllerType = ReflectionUtils.findMethod(MvcUriComponentsBuilder.MethodInvocationInfo.class, "getControllerType");
/*     */     
/*     */     private Method controllerMethod;
/*     */     
/*     */     private Object[] argumentValues;
/*     */     private Class<?> controllerType;
/*     */     
/*     */     ControllerMethodInvocationInterceptor(Class<?> controllerType)
/*     */     {
/* 704 */       this.controllerType = controllerType;
/*     */     }
/*     */     
/*     */     public Object intercept(Object obj, Method method, Object[] args, MethodProxy proxy)
/*     */     {
/* 709 */       if (getControllerMethod.equals(method)) {
/* 710 */         return this.controllerMethod;
/*     */       }
/* 712 */       if (getArgumentValues.equals(method)) {
/* 713 */         return this.argumentValues;
/*     */       }
/* 715 */       if (getControllerType.equals(method)) {
/* 716 */         return this.controllerType;
/*     */       }
/* 718 */       if (ReflectionUtils.isObjectMethod(method)) {
/* 719 */         return ReflectionUtils.invokeMethod(method, obj, args);
/*     */       }
/*     */       
/* 722 */       this.controllerMethod = method;
/* 723 */       this.argumentValues = args;
/* 724 */       Class<?> returnType = method.getReturnType();
/* 725 */       return Void.TYPE == returnType ? null : returnType.cast(MvcUriComponentsBuilder.initProxy(returnType, this));
/*     */     }
/*     */     
/*     */     public Object invoke(MethodInvocation inv)
/*     */       throws Throwable
/*     */     {
/* 731 */       return intercept(inv.getThis(), inv.getMethod(), inv.getArguments(), null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static abstract interface MethodInvocationInfo
/*     */   {
/*     */     public abstract Method getControllerMethod();
/*     */     
/*     */ 
/*     */     public abstract Object[] getArgumentValues();
/*     */     
/*     */ 
/*     */     public abstract Class<?> getControllerType();
/*     */   }
/*     */   
/*     */ 
/*     */   public static class MethodArgumentBuilder
/*     */   {
/*     */     private final Class<?> controllerType;
/*     */     
/*     */     private final Method method;
/*     */     
/*     */     private final Object[] argumentValues;
/*     */     
/*     */     private final UriComponentsBuilder baseUrl;
/*     */     
/*     */     public MethodArgumentBuilder(Class<?> controllerType, Method method)
/*     */     {
/* 760 */       this(null, controllerType, method);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public MethodArgumentBuilder(UriComponentsBuilder baseUrl, Class<?> controllerType, Method method)
/*     */     {
/* 767 */       Assert.notNull(controllerType, "'controllerType' is required");
/* 768 */       Assert.notNull(method, "'method' is required");
/* 769 */       this.baseUrl = (baseUrl != null ? baseUrl : initBaseUrl());
/* 770 */       this.controllerType = controllerType;
/* 771 */       this.method = method;
/* 772 */       this.argumentValues = new Object[method.getParameterTypes().length];
/* 773 */       for (int i = 0; i < this.argumentValues.length; i++) {
/* 774 */         this.argumentValues[i] = null;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     @Deprecated
/*     */     public MethodArgumentBuilder(Method method)
/*     */     {
/* 784 */       this(method.getDeclaringClass(), method);
/*     */     }
/*     */     
/*     */     private static UriComponentsBuilder initBaseUrl() {
/* 788 */       UriComponentsBuilder builder = ServletUriComponentsBuilder.fromCurrentServletMapping();
/* 789 */       return UriComponentsBuilder.fromPath(builder.build().getPath());
/*     */     }
/*     */     
/*     */     public MethodArgumentBuilder arg(int index, Object value) {
/* 793 */       this.argumentValues[index] = value;
/* 794 */       return this;
/*     */     }
/*     */     
/*     */     public String build()
/*     */     {
/* 799 */       return MvcUriComponentsBuilder.fromMethodInternal(this.baseUrl, this.controllerType, this.method, this.argumentValues).build(false).encode().toUriString();
/*     */     }
/*     */     
/*     */     public String buildAndExpand(Object... uriVars)
/*     */     {
/* 804 */       return MvcUriComponentsBuilder.fromMethodInternal(this.baseUrl, this.controllerType, this.method, this.argumentValues).build(false).expand(uriVars).encode().toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\method\annotation\MvcUriComponentsBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */