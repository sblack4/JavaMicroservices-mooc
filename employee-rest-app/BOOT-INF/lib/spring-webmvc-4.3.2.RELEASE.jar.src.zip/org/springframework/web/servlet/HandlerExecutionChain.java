/*     */ package org.springframework.web.servlet;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HandlerExecutionChain
/*     */ {
/*  41 */   private static final Log logger = LogFactory.getLog(HandlerExecutionChain.class);
/*     */   
/*     */   private final Object handler;
/*     */   
/*     */   private HandlerInterceptor[] interceptors;
/*     */   
/*     */   private List<HandlerInterceptor> interceptorList;
/*     */   
/*  49 */   private int interceptorIndex = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HandlerExecutionChain(Object handler)
/*     */   {
/*  57 */     this(handler, (HandlerInterceptor[])null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HandlerExecutionChain(Object handler, HandlerInterceptor... interceptors)
/*     */   {
/*  67 */     if ((handler instanceof HandlerExecutionChain)) {
/*  68 */       HandlerExecutionChain originalChain = (HandlerExecutionChain)handler;
/*  69 */       this.handler = originalChain.getHandler();
/*  70 */       this.interceptorList = new ArrayList();
/*  71 */       CollectionUtils.mergeArrayIntoCollection(originalChain.getInterceptors(), this.interceptorList);
/*  72 */       CollectionUtils.mergeArrayIntoCollection(interceptors, this.interceptorList);
/*     */     }
/*     */     else {
/*  75 */       this.handler = handler;
/*  76 */       this.interceptors = interceptors;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getHandler()
/*     */   {
/*  86 */     return this.handler;
/*     */   }
/*     */   
/*     */   public void addInterceptor(HandlerInterceptor interceptor) {
/*  90 */     initInterceptorList().add(interceptor);
/*     */   }
/*     */   
/*     */   public void addInterceptors(HandlerInterceptor... interceptors) {
/*  94 */     if (!ObjectUtils.isEmpty(interceptors)) {
/*  95 */       initInterceptorList().addAll(Arrays.asList(interceptors));
/*     */     }
/*     */   }
/*     */   
/*     */   private List<HandlerInterceptor> initInterceptorList() {
/* 100 */     if (this.interceptorList == null) {
/* 101 */       this.interceptorList = new ArrayList();
/* 102 */       if (this.interceptors != null)
/*     */       {
/* 104 */         this.interceptorList.addAll(Arrays.asList(this.interceptors));
/*     */       }
/*     */     }
/* 107 */     this.interceptors = null;
/* 108 */     return this.interceptorList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public HandlerInterceptor[] getInterceptors()
/*     */   {
/* 116 */     if ((this.interceptors == null) && (this.interceptorList != null)) {
/* 117 */       this.interceptors = ((HandlerInterceptor[])this.interceptorList.toArray(new HandlerInterceptor[this.interceptorList.size()]));
/*     */     }
/* 119 */     return this.interceptors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean applyPreHandle(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 130 */     HandlerInterceptor[] interceptors = getInterceptors();
/* 131 */     if (!ObjectUtils.isEmpty(interceptors)) {
/* 132 */       for (int i = 0; i < interceptors.length; i++) {
/* 133 */         HandlerInterceptor interceptor = interceptors[i];
/* 134 */         if (!interceptor.preHandle(request, response, this.handler)) {
/* 135 */           triggerAfterCompletion(request, response, null);
/* 136 */           return false;
/*     */         }
/* 138 */         this.interceptorIndex = i;
/*     */       }
/*     */     }
/* 141 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   void applyPostHandle(HttpServletRequest request, HttpServletResponse response, ModelAndView mv)
/*     */     throws Exception
/*     */   {
/* 148 */     HandlerInterceptor[] interceptors = getInterceptors();
/* 149 */     if (!ObjectUtils.isEmpty(interceptors)) {
/* 150 */       for (int i = interceptors.length - 1; i >= 0; i--) {
/* 151 */         HandlerInterceptor interceptor = interceptors[i];
/* 152 */         interceptor.postHandle(request, response, this.handler, mv);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void triggerAfterCompletion(HttpServletRequest request, HttpServletResponse response, Exception ex)
/*     */     throws Exception
/*     */   {
/* 165 */     HandlerInterceptor[] interceptors = getInterceptors();
/* 166 */     if (!ObjectUtils.isEmpty(interceptors)) {
/* 167 */       for (int i = this.interceptorIndex; i >= 0; i--) {
/* 168 */         HandlerInterceptor interceptor = interceptors[i];
/*     */         try {
/* 170 */           interceptor.afterCompletion(request, response, this.handler, ex);
/*     */         }
/*     */         catch (Throwable ex2) {
/* 173 */           logger.error("HandlerInterceptor.afterCompletion threw exception", ex2);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void applyAfterConcurrentHandlingStarted(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 183 */     HandlerInterceptor[] interceptors = getInterceptors();
/* 184 */     if (!ObjectUtils.isEmpty(interceptors)) {
/* 185 */       for (int i = interceptors.length - 1; i >= 0; i--) {
/* 186 */         if ((interceptors[i] instanceof AsyncHandlerInterceptor)) {
/*     */           try {
/* 188 */             AsyncHandlerInterceptor asyncInterceptor = (AsyncHandlerInterceptor)interceptors[i];
/* 189 */             asyncInterceptor.afterConcurrentHandlingStarted(request, response, this.handler);
/*     */           }
/*     */           catch (Throwable ex) {
/* 192 */             logger.error("Interceptor [" + interceptors[i] + "] failed in afterConcurrentHandlingStarted", ex);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 205 */     if (this.handler == null) {
/* 206 */       return "HandlerExecutionChain with no handler";
/*     */     }
/* 208 */     StringBuilder sb = new StringBuilder();
/* 209 */     sb.append("HandlerExecutionChain with handler [").append(this.handler).append("]");
/* 210 */     if (!CollectionUtils.isEmpty(this.interceptorList)) {
/* 211 */       sb.append(" and ").append(this.interceptorList.size()).append(" interceptor");
/* 212 */       if (this.interceptorList.size() > 1) {
/* 213 */         sb.append("s");
/*     */       }
/*     */     }
/* 216 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\HandlerExecutionChain.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */