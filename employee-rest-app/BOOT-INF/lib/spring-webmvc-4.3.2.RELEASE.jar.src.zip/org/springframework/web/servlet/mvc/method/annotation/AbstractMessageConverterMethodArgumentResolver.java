/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PushbackInputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpRequest;
/*     */ import org.springframework.http.InvalidMediaTypeException;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.validation.annotation.Validated;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractMessageConverterMethodArgumentResolver
/*     */   implements HandlerMethodArgumentResolver
/*     */ {
/*  67 */   private static final Set<HttpMethod> SUPPORTED_METHODS = EnumSet.of(HttpMethod.POST, HttpMethod.PUT, HttpMethod.PATCH);
/*     */   
/*  69 */   private static final Object NO_VALUE = new Object();
/*     */   
/*     */ 
/*  72 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */ 
/*     */   protected final List<HttpMessageConverter<?>> messageConverters;
/*     */   
/*     */ 
/*     */   protected final List<MediaType> allSupportedMediaTypes;
/*     */   
/*     */   private final RequestResponseBodyAdviceChain advice;
/*     */   
/*     */ 
/*     */   public AbstractMessageConverterMethodArgumentResolver(List<HttpMessageConverter<?>> converters)
/*     */   {
/*  85 */     this(converters, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractMessageConverterMethodArgumentResolver(List<HttpMessageConverter<?>> converters, List<Object> requestResponseBodyAdvice)
/*     */   {
/*  95 */     Assert.notEmpty(converters, "'messageConverters' must not be empty");
/*  96 */     this.messageConverters = converters;
/*  97 */     this.allSupportedMediaTypes = getAllSupportedMediaTypes(converters);
/*  98 */     this.advice = new RequestResponseBodyAdviceChain(requestResponseBodyAdvice);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static List<MediaType> getAllSupportedMediaTypes(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/* 107 */     Set<MediaType> allSupportedMediaTypes = new LinkedHashSet();
/* 108 */     for (HttpMessageConverter<?> messageConverter : messageConverters) {
/* 109 */       allSupportedMediaTypes.addAll(messageConverter.getSupportedMediaTypes());
/*     */     }
/* 111 */     Object result = new ArrayList(allSupportedMediaTypes);
/* 112 */     MediaType.sortBySpecificity((List)result);
/* 113 */     return Collections.unmodifiableList((List)result);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected RequestResponseBodyAdviceChain getAdvice()
/*     */   {
/* 123 */     return this.advice;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected <T> Object readWithMessageConverters(NativeWebRequest webRequest, MethodParameter methodParam, Type paramType)
/*     */     throws IOException, HttpMediaTypeNotSupportedException, HttpMessageNotReadableException
/*     */   {
/* 140 */     HttpInputMessage inputMessage = createInputMessage(webRequest);
/* 141 */     return readWithMessageConverters(inputMessage, methodParam, paramType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected <T> Object readWithMessageConverters(HttpInputMessage inputMessage, MethodParameter param, Type targetType)
/*     */     throws IOException, HttpMediaTypeNotSupportedException, HttpMessageNotReadableException
/*     */   {
/* 161 */     boolean noContentType = false;
/*     */     try {
/* 163 */       contentType = inputMessage.getHeaders().getContentType();
/*     */     } catch (InvalidMediaTypeException ex) {
/*     */       MediaType contentType;
/* 166 */       throw new HttpMediaTypeNotSupportedException(ex.getMessage()); }
/*     */     MediaType contentType;
/* 168 */     if (contentType == null) {
/* 169 */       noContentType = true;
/* 170 */       contentType = MediaType.APPLICATION_OCTET_STREAM;
/*     */     }
/*     */     
/* 173 */     Class<?> contextClass = param != null ? param.getContainingClass() : null;
/* 174 */     Class<T> targetClass = (targetType instanceof Class) ? (Class)targetType : null;
/* 175 */     if (targetClass == null)
/*     */     {
/* 177 */       ResolvableType resolvableType = param != null ? ResolvableType.forMethodParameter(param) : ResolvableType.forType(targetType);
/* 178 */       targetClass = resolvableType.resolve();
/*     */     }
/*     */     
/* 181 */     HttpMethod httpMethod = ((HttpRequest)inputMessage).getMethod();
/* 182 */     Object body = NO_VALUE;
/*     */     try
/*     */     {
/* 185 */       inputMessage = new EmptyBodyCheckingHttpInputMessage(inputMessage);
/*     */       
/* 187 */       for (HttpMessageConverter<?> converter : this.messageConverters) {
/* 188 */         Class<HttpMessageConverter<?>> converterType = converter.getClass();
/* 189 */         if ((converter instanceof GenericHttpMessageConverter)) {
/* 190 */           GenericHttpMessageConverter<?> genericConverter = (GenericHttpMessageConverter)converter;
/* 191 */           if (genericConverter.canRead(targetType, contextClass, contentType)) {
/* 192 */             if (this.logger.isDebugEnabled()) {
/* 193 */               this.logger.debug("Read [" + targetType + "] as \"" + contentType + "\" with [" + converter + "]");
/*     */             }
/* 195 */             if (inputMessage.getBody() != null) {
/* 196 */               inputMessage = getAdvice().beforeBodyRead(inputMessage, param, targetType, converterType);
/* 197 */               body = genericConverter.read(targetType, contextClass, inputMessage);
/* 198 */               body = getAdvice().afterBodyRead(body, inputMessage, param, targetType, converterType); break;
/*     */             }
/*     */             
/* 201 */             body = null;
/* 202 */             body = getAdvice().handleEmptyBody(body, inputMessage, param, targetType, converterType);
/*     */             
/* 204 */             break;
/*     */           }
/*     */         }
/* 207 */         else if ((targetClass != null) && 
/* 208 */           (converter.canRead(targetClass, contentType))) {
/* 209 */           if (this.logger.isDebugEnabled()) {
/* 210 */             this.logger.debug("Read [" + targetType + "] as \"" + contentType + "\" with [" + converter + "]");
/*     */           }
/* 212 */           if (inputMessage.getBody() != null) {
/* 213 */             inputMessage = getAdvice().beforeBodyRead(inputMessage, param, targetType, converterType);
/* 214 */             body = converter.read(targetClass, inputMessage);
/* 215 */             body = getAdvice().afterBodyRead(body, inputMessage, param, targetType, converterType); break;
/*     */           }
/*     */           
/* 218 */           body = null;
/* 219 */           body = getAdvice().handleEmptyBody(body, inputMessage, param, targetType, converterType);
/*     */           
/* 221 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 227 */       throw new HttpMessageNotReadableException("Could not read document: " + ex.getMessage(), ex);
/*     */     }
/*     */     
/* 230 */     if (body == NO_VALUE) {
/* 231 */       if ((httpMethod == null) || (!SUPPORTED_METHODS.contains(httpMethod)) || ((noContentType) && 
/* 232 */         (inputMessage.getBody() == null))) {
/* 233 */         return null;
/*     */       }
/* 235 */       throw new HttpMediaTypeNotSupportedException(contentType, this.allSupportedMediaTypes);
/*     */     }
/*     */     
/* 238 */     return body;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ServletServerHttpRequest createInputMessage(NativeWebRequest webRequest)
/*     */   {
/* 247 */     HttpServletRequest servletRequest = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/* 248 */     return new ServletServerHttpRequest(servletRequest);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void validateIfApplicable(WebDataBinder binder, MethodParameter methodParam)
/*     */   {
/* 262 */     Annotation[] annotations = methodParam.getParameterAnnotations();
/* 263 */     for (Annotation ann : annotations) {
/* 264 */       Validated validatedAnn = (Validated)AnnotationUtils.getAnnotation(ann, Validated.class);
/* 265 */       if ((validatedAnn != null) || (ann.annotationType().getSimpleName().startsWith("Valid"))) {
/* 266 */         Object hints = validatedAnn != null ? validatedAnn.value() : AnnotationUtils.getValue(ann);
/* 267 */         Object[] validationHints = { (hints instanceof Object[]) ? (Object[])hints : hints };
/* 268 */         binder.validate(validationHints);
/* 269 */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isBindExceptionRequired(WebDataBinder binder, MethodParameter methodParam)
/*     */   {
/* 282 */     int i = methodParam.getParameterIndex();
/* 283 */     Class<?>[] paramTypes = methodParam.getMethod().getParameterTypes();
/* 284 */     boolean hasBindingResult = (paramTypes.length > i + 1) && (Errors.class.isAssignableFrom(paramTypes[(i + 1)]));
/* 285 */     return !hasBindingResult;
/*     */   }
/*     */   
/*     */ 
/*     */   private static class EmptyBodyCheckingHttpInputMessage
/*     */     implements HttpInputMessage
/*     */   {
/*     */     private final HttpHeaders headers;
/*     */     private final InputStream body;
/*     */     private final HttpMethod method;
/*     */     
/*     */     public EmptyBodyCheckingHttpInputMessage(HttpInputMessage inputMessage)
/*     */       throws IOException
/*     */     {
/* 299 */       this.headers = inputMessage.getHeaders();
/* 300 */       InputStream inputStream = inputMessage.getBody();
/* 301 */       if (inputStream == null) {
/* 302 */         this.body = null;
/*     */       }
/* 304 */       else if (inputStream.markSupported()) {
/* 305 */         inputStream.mark(1);
/* 306 */         this.body = (inputStream.read() != -1 ? inputStream : null);
/* 307 */         inputStream.reset();
/*     */       }
/*     */       else {
/* 310 */         PushbackInputStream pushbackInputStream = new PushbackInputStream(inputStream);
/* 311 */         int b = pushbackInputStream.read();
/* 312 */         if (b == -1) {
/* 313 */           this.body = null;
/*     */         }
/*     */         else {
/* 316 */           this.body = pushbackInputStream;
/* 317 */           pushbackInputStream.unread(b);
/*     */         }
/*     */       }
/* 320 */       this.method = ((HttpRequest)inputMessage).getMethod();
/*     */     }
/*     */     
/*     */     public HttpHeaders getHeaders()
/*     */     {
/* 325 */       return this.headers;
/*     */     }
/*     */     
/*     */     public InputStream getBody() throws IOException
/*     */     {
/* 330 */       return this.body;
/*     */     }
/*     */     
/*     */     public HttpMethod getMethod() {
/* 334 */       return this.method;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\method\annotation\AbstractMessageConverterMethodArgumentResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */