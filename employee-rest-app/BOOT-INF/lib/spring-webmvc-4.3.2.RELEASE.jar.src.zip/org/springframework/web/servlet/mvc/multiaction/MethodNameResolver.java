package org.springframework.web.servlet.mvc.multiaction;

import javax.servlet.http.HttpServletRequest;

@Deprecated
public abstract interface MethodNameResolver
{
  public abstract String getHandlerMethodName(HttpServletRequest paramHttpServletRequest)
    throws NoSuchRequestHandlingMethodException;
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\multiaction\MethodNameResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */