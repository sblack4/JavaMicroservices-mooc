/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.web.cors.CorsUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HeadersRequestCondition
/*     */   extends AbstractRequestCondition<HeadersRequestCondition>
/*     */ {
/*  42 */   private static final HeadersRequestCondition PRE_FLIGHT_MATCH = new HeadersRequestCondition(new String[0]);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Set<HeaderExpression> expressions;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HeadersRequestCondition(String... headers)
/*     */   {
/*  56 */     this(parseExpressions(headers));
/*     */   }
/*     */   
/*     */   private HeadersRequestCondition(Collection<HeaderExpression> conditions) {
/*  60 */     this.expressions = Collections.unmodifiableSet(new LinkedHashSet(conditions));
/*     */   }
/*     */   
/*     */   private static Collection<HeaderExpression> parseExpressions(String... headers)
/*     */   {
/*  65 */     Set<HeaderExpression> expressions = new LinkedHashSet();
/*  66 */     if (headers != null) {
/*  67 */       for (String header : headers) {
/*  68 */         HeaderExpression expr = new HeaderExpression(header);
/*  69 */         if ((!"Accept".equalsIgnoreCase(expr.name)) && (!"Content-Type".equalsIgnoreCase(expr.name)))
/*     */         {
/*     */ 
/*  72 */           expressions.add(expr); }
/*     */       }
/*     */     }
/*  75 */     return expressions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Set<NameValueExpression<String>> getExpressions()
/*     */   {
/*  82 */     return new LinkedHashSet(this.expressions);
/*     */   }
/*     */   
/*     */   protected Collection<HeaderExpression> getContent()
/*     */   {
/*  87 */     return this.expressions;
/*     */   }
/*     */   
/*     */   protected String getToStringInfix()
/*     */   {
/*  92 */     return " && ";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HeadersRequestCondition combine(HeadersRequestCondition other)
/*     */   {
/* 101 */     Set<HeaderExpression> set = new LinkedHashSet(this.expressions);
/* 102 */     set.addAll(other.expressions);
/* 103 */     return new HeadersRequestCondition(set);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HeadersRequestCondition getMatchingCondition(HttpServletRequest request)
/*     */   {
/* 112 */     if (CorsUtils.isPreFlightRequest(request)) {
/* 113 */       return PRE_FLIGHT_MATCH;
/*     */     }
/* 115 */     for (HeaderExpression expression : this.expressions) {
/* 116 */       if (!expression.match(request)) {
/* 117 */         return null;
/*     */       }
/*     */     }
/* 120 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compareTo(HeadersRequestCondition other, HttpServletRequest request)
/*     */   {
/* 136 */     return other.expressions.size() - this.expressions.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static class HeaderExpression
/*     */     extends AbstractNameValueExpression<String>
/*     */   {
/*     */     public HeaderExpression(String expression)
/*     */     {
/* 146 */       super();
/*     */     }
/*     */     
/*     */     protected boolean isCaseSensitiveName()
/*     */     {
/* 151 */       return false;
/*     */     }
/*     */     
/*     */     protected String parseValue(String valueExpression)
/*     */     {
/* 156 */       return valueExpression;
/*     */     }
/*     */     
/*     */     protected boolean matchName(HttpServletRequest request)
/*     */     {
/* 161 */       return request.getHeader(this.name) != null;
/*     */     }
/*     */     
/*     */     protected boolean matchValue(HttpServletRequest request)
/*     */     {
/* 166 */       return ((String)this.value).equals(request.getHeader(this.name));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\condition\HeadersRequestCondition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */