/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.http.HttpRequest;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.request.RequestAttributes;
/*     */ import org.springframework.web.context.request.RequestContextHolder;
/*     */ import org.springframework.web.context.request.ServletRequestAttributes;
/*     */ import org.springframework.web.util.UriComponents;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ import org.springframework.web.util.UriUtils;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletUriComponentsBuilder
/*     */   extends UriComponentsBuilder
/*     */ {
/*     */   private String originalPath;
/*     */   
/*     */   protected ServletUriComponentsBuilder() {}
/*     */   
/*     */   protected ServletUriComponentsBuilder(ServletUriComponentsBuilder other)
/*     */   {
/*  62 */     super(other);
/*  63 */     this.originalPath = other.originalPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ServletUriComponentsBuilder fromContextPath(HttpServletRequest request)
/*     */   {
/*  74 */     ServletUriComponentsBuilder builder = initFromRequest(request);
/*  75 */     builder.replacePath(prependForwardedPrefix(request, request.getContextPath()));
/*  76 */     return builder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ServletUriComponentsBuilder fromServletMapping(HttpServletRequest request)
/*     */   {
/*  88 */     ServletUriComponentsBuilder builder = fromContextPath(request);
/*  89 */     if (StringUtils.hasText(new UrlPathHelper().getPathWithinServletMapping(request))) {
/*  90 */       builder.path(request.getServletPath());
/*     */     }
/*  92 */     return builder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ServletUriComponentsBuilder fromRequestUri(HttpServletRequest request)
/*     */   {
/* 100 */     ServletUriComponentsBuilder builder = initFromRequest(request);
/* 101 */     builder.initPath(prependForwardedPrefix(request, request.getRequestURI()));
/* 102 */     return builder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ServletUriComponentsBuilder fromRequest(HttpServletRequest request)
/*     */   {
/* 110 */     ServletUriComponentsBuilder builder = initFromRequest(request);
/* 111 */     builder.initPath(prependForwardedPrefix(request, request.getRequestURI()));
/* 112 */     builder.query(request.getQueryString());
/* 113 */     return builder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static ServletUriComponentsBuilder initFromRequest(HttpServletRequest request)
/*     */   {
/* 120 */     HttpRequest httpRequest = new ServletServerHttpRequest(request);
/* 121 */     UriComponents uriComponents = UriComponentsBuilder.fromHttpRequest(httpRequest).build();
/* 122 */     String scheme = uriComponents.getScheme();
/* 123 */     String host = uriComponents.getHost();
/* 124 */     int port = uriComponents.getPort();
/*     */     
/* 126 */     ServletUriComponentsBuilder builder = new ServletUriComponentsBuilder();
/* 127 */     builder.scheme(scheme);
/* 128 */     builder.host(host);
/* 129 */     if ((("http".equals(scheme)) && (port != 80)) || (("https".equals(scheme)) && (port != 443))) {
/* 130 */       builder.port(port);
/*     */     }
/* 132 */     return builder;
/*     */   }
/*     */   
/*     */   private static String prependForwardedPrefix(HttpServletRequest request, String path) {
/* 136 */     String prefix = null;
/* 137 */     Enumeration<String> names = request.getHeaderNames();
/* 138 */     while (names.hasMoreElements()) {
/* 139 */       String name = (String)names.nextElement();
/* 140 */       if ("X-Forwarded-Prefix".equalsIgnoreCase(name)) {
/* 141 */         prefix = request.getHeader(name);
/*     */       }
/*     */     }
/* 144 */     if (prefix != null) {
/* 145 */       path = prefix + path;
/*     */     }
/* 147 */     return path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ServletUriComponentsBuilder fromCurrentContextPath()
/*     */   {
/* 158 */     return fromContextPath(getCurrentRequest());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ServletUriComponentsBuilder fromCurrentServletMapping()
/*     */   {
/* 166 */     return fromServletMapping(getCurrentRequest());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ServletUriComponentsBuilder fromCurrentRequestUri()
/*     */   {
/* 174 */     return fromRequestUri(getCurrentRequest());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ServletUriComponentsBuilder fromCurrentRequest()
/*     */   {
/* 182 */     return fromRequest(getCurrentRequest());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected static HttpServletRequest getCurrentRequest()
/*     */   {
/* 189 */     RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
/* 190 */     Assert.state(requestAttributes != null, "Could not find current request via RequestContextHolder");
/* 191 */     Assert.isInstanceOf(ServletRequestAttributes.class, requestAttributes);
/* 192 */     HttpServletRequest servletRequest = ((ServletRequestAttributes)requestAttributes).getRequest();
/* 193 */     Assert.state(servletRequest != null, "Could not find current HttpServletRequest");
/* 194 */     return servletRequest;
/*     */   }
/*     */   
/*     */   private void initPath(String path)
/*     */   {
/* 199 */     this.originalPath = path;
/* 200 */     replacePath(path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String removePathExtension()
/*     */   {
/* 219 */     String extension = null;
/* 220 */     if (this.originalPath != null) {
/* 221 */       extension = UriUtils.extractFileExtension(this.originalPath);
/* 222 */       if (!StringUtils.isEmpty(extension)) {
/* 223 */         int end = this.originalPath.length() - (extension.length() + 1);
/* 224 */         replacePath(this.originalPath.substring(0, end));
/*     */       }
/* 226 */       this.originalPath = null;
/*     */     }
/* 228 */     return extension;
/*     */   }
/*     */   
/*     */   public ServletUriComponentsBuilder cloneBuilder()
/*     */   {
/* 233 */     return new ServletUriComponentsBuilder(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\support\ServletUriComponentsBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */