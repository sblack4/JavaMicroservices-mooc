/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.web.servlet.HandlerExecutionChain;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractUrlHandlerMapping
/*     */   extends AbstractHandlerMapping
/*     */   implements MatchableHandlerMapping
/*     */ {
/*     */   private Object rootHandler;
/*  56 */   private boolean useTrailingSlashMatch = false;
/*     */   
/*  58 */   private boolean lazyInitHandlers = false;
/*     */   
/*  60 */   private final Map<String, Object> handlerMap = new LinkedHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRootHandler(Object rootHandler)
/*     */   {
/*  69 */     this.rootHandler = rootHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getRootHandler()
/*     */   {
/*  77 */     return this.rootHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUseTrailingSlashMatch(boolean useTrailingSlashMatch)
/*     */   {
/*  86 */     this.useTrailingSlashMatch = useTrailingSlashMatch;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean useTrailingSlashMatch()
/*     */   {
/*  93 */     return this.useTrailingSlashMatch;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLazyInitHandlers(boolean lazyInitHandlers)
/*     */   {
/* 107 */     this.lazyInitHandlers = lazyInitHandlers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object getHandlerInternal(HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/* 117 */     String lookupPath = getUrlPathHelper().getLookupPathForRequest(request);
/* 118 */     Object handler = lookupHandler(lookupPath, request);
/* 119 */     if (handler == null)
/*     */     {
/*     */ 
/* 122 */       Object rawHandler = null;
/* 123 */       if ("/".equals(lookupPath)) {
/* 124 */         rawHandler = getRootHandler();
/*     */       }
/* 126 */       if (rawHandler == null) {
/* 127 */         rawHandler = getDefaultHandler();
/*     */       }
/* 129 */       if (rawHandler != null)
/*     */       {
/* 131 */         if ((rawHandler instanceof String)) {
/* 132 */           String handlerName = (String)rawHandler;
/* 133 */           rawHandler = getApplicationContext().getBean(handlerName);
/*     */         }
/* 135 */         validateHandler(rawHandler, request);
/* 136 */         handler = buildPathExposingHandler(rawHandler, lookupPath, lookupPath, null);
/*     */       }
/*     */     }
/* 139 */     if ((handler != null) && (this.logger.isDebugEnabled())) {
/* 140 */       this.logger.debug("Mapping [" + lookupPath + "] to " + handler);
/*     */     }
/* 142 */     else if ((handler == null) && (this.logger.isTraceEnabled())) {
/* 143 */       this.logger.trace("No handler mapping found for [" + lookupPath + "]");
/*     */     }
/* 145 */     return handler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object lookupHandler(String urlPath, HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/* 163 */     Object handler = this.handlerMap.get(urlPath);
/* 164 */     if (handler != null)
/*     */     {
/* 166 */       if ((handler instanceof String)) {
/* 167 */         String handlerName = (String)handler;
/* 168 */         handler = getApplicationContext().getBean(handlerName);
/*     */       }
/* 170 */       validateHandler(handler, request);
/* 171 */       return buildPathExposingHandler(handler, urlPath, urlPath, null);
/*     */     }
/*     */     
/* 174 */     List<String> matchingPatterns = new ArrayList();
/* 175 */     for (String registeredPattern : this.handlerMap.keySet()) {
/* 176 */       if (getPathMatcher().match(registeredPattern, urlPath)) {
/* 177 */         matchingPatterns.add(registeredPattern);
/*     */       }
/* 179 */       else if ((useTrailingSlashMatch()) && 
/* 180 */         (!registeredPattern.endsWith("/")) && (getPathMatcher().match(registeredPattern + "/", urlPath))) {
/* 181 */         matchingPatterns.add(registeredPattern + "/");
/*     */       }
/*     */     }
/*     */     
/* 185 */     String bestPatternMatch = null;
/* 186 */     Comparator<String> patternComparator = getPathMatcher().getPatternComparator(urlPath);
/* 187 */     if (!matchingPatterns.isEmpty()) {
/* 188 */       Collections.sort(matchingPatterns, patternComparator);
/* 189 */       if (this.logger.isDebugEnabled()) {
/* 190 */         this.logger.debug("Matching patterns for request [" + urlPath + "] are " + matchingPatterns);
/*     */       }
/* 192 */       bestPatternMatch = (String)matchingPatterns.get(0);
/*     */     }
/* 194 */     if (bestPatternMatch != null) {
/* 195 */       handler = this.handlerMap.get(bestPatternMatch);
/* 196 */       if (handler == null) {
/* 197 */         Assert.isTrue(bestPatternMatch.endsWith("/"));
/* 198 */         handler = this.handlerMap.get(bestPatternMatch.substring(0, bestPatternMatch.length() - 1));
/*     */       }
/*     */       
/* 201 */       if ((handler instanceof String)) {
/* 202 */         String handlerName = (String)handler;
/* 203 */         handler = getApplicationContext().getBean(handlerName);
/*     */       }
/* 205 */       validateHandler(handler, request);
/* 206 */       String pathWithinMapping = getPathMatcher().extractPathWithinPattern(bestPatternMatch, urlPath);
/*     */       
/*     */ 
/*     */ 
/* 210 */       Map<String, String> uriTemplateVariables = new LinkedHashMap();
/* 211 */       for (String matchingPattern : matchingPatterns) {
/* 212 */         if (patternComparator.compare(bestPatternMatch, matchingPattern) == 0) {
/* 213 */           Map<String, String> vars = getPathMatcher().extractUriTemplateVariables(matchingPattern, urlPath);
/* 214 */           Map<String, String> decodedVars = getUrlPathHelper().decodePathVariables(request, vars);
/* 215 */           uriTemplateVariables.putAll(decodedVars);
/*     */         }
/*     */       }
/* 218 */       if (this.logger.isDebugEnabled()) {
/* 219 */         this.logger.debug("URI Template variables for request [" + urlPath + "] are " + uriTemplateVariables);
/*     */       }
/* 221 */       return buildPathExposingHandler(handler, bestPatternMatch, pathWithinMapping, uriTemplateVariables);
/*     */     }
/*     */     
/* 224 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void validateHandler(Object handler, HttpServletRequest request)
/*     */     throws Exception
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object buildPathExposingHandler(Object rawHandler, String bestMatchingPattern, String pathWithinMapping, Map<String, String> uriTemplateVariables)
/*     */   {
/* 252 */     HandlerExecutionChain chain = new HandlerExecutionChain(rawHandler);
/* 253 */     chain.addInterceptor(new PathExposingHandlerInterceptor(bestMatchingPattern, pathWithinMapping));
/* 254 */     if (!CollectionUtils.isEmpty(uriTemplateVariables)) {
/* 255 */       chain.addInterceptor(new UriTemplateVariablesHandlerInterceptor(uriTemplateVariables));
/*     */     }
/* 257 */     return chain;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void exposePathWithinMapping(String bestMatchingPattern, String pathWithinMapping, HttpServletRequest request)
/*     */   {
/* 267 */     request.setAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE, bestMatchingPattern);
/* 268 */     request.setAttribute(PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE, pathWithinMapping);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void exposeUriTemplateVariables(Map<String, String> uriTemplateVariables, HttpServletRequest request)
/*     */   {
/* 278 */     request.setAttribute(URI_TEMPLATE_VARIABLES_ATTRIBUTE, uriTemplateVariables);
/*     */   }
/*     */   
/*     */   public RequestMatchResult match(HttpServletRequest request, String pattern)
/*     */   {
/* 283 */     String lookupPath = getUrlPathHelper().getLookupPathForRequest(request);
/* 284 */     if (getPathMatcher().match(pattern, lookupPath)) {
/* 285 */       return new RequestMatchResult(pattern, lookupPath, getPathMatcher());
/*     */     }
/* 287 */     if ((useTrailingSlashMatch()) && 
/* 288 */       (!pattern.endsWith("/")) && (getPathMatcher().match(pattern + "/", lookupPath))) {
/* 289 */       return new RequestMatchResult(pattern + "/", lookupPath, getPathMatcher());
/*     */     }
/*     */     
/* 292 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void registerHandler(String[] urlPaths, String beanName)
/*     */     throws BeansException, IllegalStateException
/*     */   {
/* 303 */     Assert.notNull(urlPaths, "URL path array must not be null");
/* 304 */     for (String urlPath : urlPaths) {
/* 305 */       registerHandler(urlPath, beanName);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void registerHandler(String urlPath, Object handler)
/*     */     throws BeansException, IllegalStateException
/*     */   {
/* 318 */     Assert.notNull(urlPath, "URL path must not be null");
/* 319 */     Assert.notNull(handler, "Handler object must not be null");
/* 320 */     Object resolvedHandler = handler;
/*     */     
/*     */ 
/* 323 */     if ((!this.lazyInitHandlers) && ((handler instanceof String))) {
/* 324 */       String handlerName = (String)handler;
/* 325 */       if (getApplicationContext().isSingleton(handlerName)) {
/* 326 */         resolvedHandler = getApplicationContext().getBean(handlerName);
/*     */       }
/*     */     }
/*     */     
/* 330 */     Object mappedHandler = this.handlerMap.get(urlPath);
/* 331 */     if (mappedHandler != null) {
/* 332 */       if (mappedHandler != resolvedHandler)
/*     */       {
/*     */ 
/* 335 */         throw new IllegalStateException("Cannot map " + getHandlerDescription(handler) + " to URL path [" + urlPath + "]: There is already " + getHandlerDescription(mappedHandler) + " mapped.");
/*     */       }
/*     */       
/*     */     }
/* 339 */     else if (urlPath.equals("/")) {
/* 340 */       if (this.logger.isInfoEnabled()) {
/* 341 */         this.logger.info("Root mapping to " + getHandlerDescription(handler));
/*     */       }
/* 343 */       setRootHandler(resolvedHandler);
/*     */     }
/* 345 */     else if (urlPath.equals("/*")) {
/* 346 */       if (this.logger.isInfoEnabled()) {
/* 347 */         this.logger.info("Default mapping to " + getHandlerDescription(handler));
/*     */       }
/* 349 */       setDefaultHandler(resolvedHandler);
/*     */     }
/*     */     else {
/* 352 */       this.handlerMap.put(urlPath, resolvedHandler);
/* 353 */       if (this.logger.isInfoEnabled()) {
/* 354 */         this.logger.info("Mapped URL path [" + urlPath + "] onto " + getHandlerDescription(handler));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private String getHandlerDescription(Object handler)
/*     */   {
/* 361 */     return "handler " + ((handler instanceof String) ? "'" + handler + "'" : new StringBuilder().append("of type [").append(handler.getClass()).append("]").toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Map<String, Object> getHandlerMap()
/*     */   {
/* 372 */     return Collections.unmodifiableMap(this.handlerMap);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean supportsTypeLevelMappings()
/*     */   {
/* 379 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class PathExposingHandlerInterceptor
/*     */     extends HandlerInterceptorAdapter
/*     */   {
/*     */     private final String bestMatchingPattern;
/*     */     
/*     */ 
/*     */     private final String pathWithinMapping;
/*     */     
/*     */ 
/*     */     public PathExposingHandlerInterceptor(String bestMatchingPattern, String pathWithinMapping)
/*     */     {
/* 395 */       this.bestMatchingPattern = bestMatchingPattern;
/* 396 */       this.pathWithinMapping = pathWithinMapping;
/*     */     }
/*     */     
/*     */     public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     {
/* 401 */       AbstractUrlHandlerMapping.this.exposePathWithinMapping(this.bestMatchingPattern, this.pathWithinMapping, request);
/* 402 */       request.setAttribute(HandlerMapping.INTROSPECT_TYPE_LEVEL_MAPPING, Boolean.valueOf(AbstractUrlHandlerMapping.this.supportsTypeLevelMappings()));
/* 403 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class UriTemplateVariablesHandlerInterceptor
/*     */     extends HandlerInterceptorAdapter
/*     */   {
/*     */     private final Map<String, String> uriTemplateVariables;
/*     */     
/*     */ 
/*     */ 
/*     */     public UriTemplateVariablesHandlerInterceptor()
/*     */     {
/* 418 */       this.uriTemplateVariables = uriTemplateVariables;
/*     */     }
/*     */     
/*     */     public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     {
/* 423 */       AbstractUrlHandlerMapping.this.exposeUriTemplateVariables(this.uriTemplateVariables, request);
/* 424 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\handler\AbstractUrlHandlerMapping.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */