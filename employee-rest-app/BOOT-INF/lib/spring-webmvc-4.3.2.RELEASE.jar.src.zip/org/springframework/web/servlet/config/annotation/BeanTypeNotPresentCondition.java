/*    */ package org.springframework.web.servlet.config.annotation;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryUtils;
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.context.annotation.ConfigurationCondition;
/*    */ import org.springframework.context.annotation.ConfigurationCondition.ConfigurationPhase;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BeanTypeNotPresentCondition
/*    */   implements ConfigurationCondition
/*    */ {
/* 39 */   private static final Log logger = LogFactory.getLog("org.springframework.web.servlet.config.annotation.ViewResolution");
/*    */   
/*    */   private final Class<?> beanType;
/*    */   
/*    */   BeanTypeNotPresentCondition(Class<?> beanType)
/*    */   {
/* 45 */     this.beanType = beanType;
/*    */   }
/*    */   
/*    */ 
/*    */   public ConfigurationCondition.ConfigurationPhase getConfigurationPhase()
/*    */   {
/* 51 */     return ConfigurationCondition.ConfigurationPhase.PARSE_CONFIGURATION;
/*    */   }
/*    */   
/*    */   public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 55 */     ListableBeanFactory factory = context.getBeanFactory();
/* 56 */     String[] names = BeanFactoryUtils.beanNamesForTypeIncludingAncestors(factory, this.beanType, false, false);
/* 57 */     if (ObjectUtils.isEmpty(names)) {
/* 58 */       logger.debug("No bean of type [" + this.beanType + "]. Conditional configuration applies.");
/* 59 */       return true;
/*    */     }
/*    */     
/* 62 */     logger.debug("Found bean of type [" + this.beanType + "]. Conditional configuration does not apply.");
/* 63 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\config\annotation\BeanTypeNotPresentCondition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */