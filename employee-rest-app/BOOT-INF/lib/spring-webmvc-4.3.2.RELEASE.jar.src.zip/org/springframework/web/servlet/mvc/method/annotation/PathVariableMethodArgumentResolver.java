/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.bind.MissingPathVariableException;
/*     */ import org.springframework.web.bind.ServletRequestBindingException;
/*     */ import org.springframework.web.bind.annotation.PathVariable;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.annotation.AbstractNamedValueMethodArgumentResolver;
/*     */ import org.springframework.web.method.annotation.AbstractNamedValueMethodArgumentResolver.NamedValueInfo;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.method.support.UriComponentsContributor;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PathVariableMethodArgumentResolver
/*     */   extends AbstractNamedValueMethodArgumentResolver
/*     */   implements UriComponentsContributor
/*     */ {
/*  65 */   private static final TypeDescriptor STRING_TYPE_DESCRIPTOR = TypeDescriptor.valueOf(String.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/*  74 */     if (!parameter.hasParameterAnnotation(PathVariable.class)) {
/*  75 */       return false;
/*     */     }
/*  77 */     if (Map.class.isAssignableFrom(parameter.nestedIfOptional().getNestedParameterType())) {
/*  78 */       String paramName = ((PathVariable)parameter.getParameterAnnotation(PathVariable.class)).value();
/*  79 */       return StringUtils.hasText(paramName);
/*     */     }
/*  81 */     return true;
/*     */   }
/*     */   
/*     */   protected AbstractNamedValueMethodArgumentResolver.NamedValueInfo createNamedValueInfo(MethodParameter parameter)
/*     */   {
/*  86 */     PathVariable annotation = (PathVariable)parameter.getParameterAnnotation(PathVariable.class);
/*  87 */     return new PathVariableNamedValueInfo(annotation);
/*     */   }
/*     */   
/*     */   protected Object resolveName(String name, MethodParameter parameter, NativeWebRequest request)
/*     */     throws Exception
/*     */   {
/*  93 */     Map<String, String> uriTemplateVars = (Map)request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE, 0);
/*     */     
/*  95 */     return uriTemplateVars != null ? (String)uriTemplateVars.get(name) : null;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void handleMissingValue(String name, MethodParameter parameter)
/*     */     throws ServletRequestBindingException
/*     */   {
/* 102 */     throw new MissingPathVariableException(name, parameter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void handleResolvedValue(Object arg, String name, MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest request)
/*     */   {
/* 110 */     String key = View.PATH_VARIABLES;
/* 111 */     int scope = 0;
/* 112 */     Map<String, Object> pathVars = (Map)request.getAttribute(key, scope);
/* 113 */     if (pathVars == null) {
/* 114 */       pathVars = new HashMap();
/* 115 */       request.setAttribute(key, pathVars, scope);
/*     */     }
/* 117 */     pathVars.put(name, arg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void contributeMethodArgument(MethodParameter parameter, Object value, UriComponentsBuilder builder, Map<String, Object> uriVariables, ConversionService conversionService)
/*     */   {
/* 124 */     if (Map.class.isAssignableFrom(parameter.getNestedParameterType())) {
/* 125 */       return;
/*     */     }
/*     */     
/* 128 */     PathVariable ann = (PathVariable)parameter.getParameterAnnotation(PathVariable.class);
/* 129 */     String name = (ann == null) || (StringUtils.isEmpty(ann.value())) ? parameter.getParameterName() : ann.value();
/* 130 */     value = formatUriValue(conversionService, new TypeDescriptor(parameter), value);
/* 131 */     uriVariables.put(name, value);
/*     */   }
/*     */   
/*     */   protected String formatUriValue(ConversionService cs, TypeDescriptor sourceType, Object value) {
/* 135 */     if (value == null) {
/* 136 */       return null;
/*     */     }
/* 138 */     if ((value instanceof String)) {
/* 139 */       return (String)value;
/*     */     }
/* 141 */     if (cs != null) {
/* 142 */       return (String)cs.convert(value, sourceType, STRING_TYPE_DESCRIPTOR);
/*     */     }
/*     */     
/* 145 */     return value.toString();
/*     */   }
/*     */   
/*     */   private static class PathVariableNamedValueInfo
/*     */     extends AbstractNamedValueMethodArgumentResolver.NamedValueInfo
/*     */   {
/*     */     public PathVariableNamedValueInfo(PathVariable annotation)
/*     */     {
/* 153 */       super(true, "\n\t\t\n\t\t\n\n\t\t\t\t\n");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\method\annotation\PathVariableMethodArgumentResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */