/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.lang.UsesJava8;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.web.bind.MethodArgumentNotValidException;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.bind.annotation.RequestParam;
/*     */ import org.springframework.web.bind.annotation.RequestPart;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.multipart.MultipartException;
/*     */ import org.springframework.web.multipart.support.MissingServletRequestPartException;
/*     */ import org.springframework.web.multipart.support.MultipartResolutionDelegate;
/*     */ import org.springframework.web.multipart.support.RequestPartServletServerHttpRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RequestPartMethodArgumentResolver
/*     */   extends AbstractMessageConverterMethodArgumentResolver
/*     */ {
/*     */   public RequestPartMethodArgumentResolver(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/*  76 */     super(messageConverters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RequestPartMethodArgumentResolver(List<HttpMessageConverter<?>> messageConverters, List<Object> requestResponseBodyAdvice)
/*     */   {
/*  86 */     super(messageConverters, requestResponseBodyAdvice);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/* 100 */     if (parameter.hasParameterAnnotation(RequestPart.class)) {
/* 101 */       return true;
/*     */     }
/*     */     
/* 104 */     if (parameter.hasParameterAnnotation(RequestParam.class)) {
/* 105 */       return false;
/*     */     }
/* 107 */     return MultipartResolutionDelegate.isMultipartArgument(parameter.nestedIfOptional());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest request, WebDataBinderFactory binderFactory)
/*     */     throws Exception
/*     */   {
/* 115 */     HttpServletRequest servletRequest = (HttpServletRequest)request.getNativeRequest(HttpServletRequest.class);
/* 116 */     RequestPart requestPart = (RequestPart)parameter.getParameterAnnotation(RequestPart.class);
/* 117 */     boolean isRequired = ((requestPart == null) || (requestPart.required())) && (!parameter.isOptional());
/*     */     
/* 119 */     String name = getPartName(parameter, requestPart);
/* 120 */     parameter = parameter.nestedIfOptional();
/* 121 */     Object arg = null;
/*     */     
/* 123 */     Object mpArg = MultipartResolutionDelegate.resolveMultipartArgument(name, parameter, servletRequest);
/* 124 */     if (mpArg != MultipartResolutionDelegate.UNRESOLVABLE) {
/* 125 */       arg = mpArg;
/*     */     } else {
/*     */       try
/*     */       {
/* 129 */         HttpInputMessage inputMessage = new RequestPartServletServerHttpRequest(servletRequest, name);
/* 130 */         arg = readWithMessageConverters(inputMessage, parameter, parameter.getNestedGenericParameterType());
/* 131 */         WebDataBinder binder = binderFactory.createBinder(request, arg, name);
/* 132 */         if (arg != null) {
/* 133 */           validateIfApplicable(binder, parameter);
/* 134 */           if ((binder.getBindingResult().hasErrors()) && (isBindExceptionRequired(binder, parameter))) {
/* 135 */             throw new MethodArgumentNotValidException(parameter, binder.getBindingResult());
/*     */           }
/*     */         }
/* 138 */         mavContainer.addAttribute(BindingResult.MODEL_KEY_PREFIX + name, binder.getBindingResult());
/*     */       }
/*     */       catch (MissingServletRequestPartException ex) {
/* 141 */         if (isRequired) {
/* 142 */           throw ex;
/*     */         }
/*     */       }
/*     */       catch (MultipartException ex) {
/* 146 */         if (isRequired) {
/* 147 */           throw ex;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 152 */     if ((arg == null) && (isRequired)) {
/* 153 */       if (!MultipartResolutionDelegate.isMultipartRequest(servletRequest)) {
/* 154 */         throw new MultipartException("Current request is not a multipart request");
/*     */       }
/*     */       
/* 157 */       throw new MissingServletRequestPartException(name);
/*     */     }
/*     */     
/* 160 */     if (parameter.isOptional()) {
/* 161 */       arg = OptionalResolver.resolveValue(arg);
/*     */     }
/*     */     
/* 164 */     return arg;
/*     */   }
/*     */   
/*     */   private String getPartName(MethodParameter methodParam, RequestPart requestPart) {
/* 168 */     String partName = requestPart != null ? requestPart.name() : "";
/* 169 */     if (partName.length() == 0) {
/* 170 */       partName = methodParam.getParameterName();
/* 171 */       if (partName == null)
/*     */       {
/* 173 */         throw new IllegalArgumentException("Request part name for argument type [" + methodParam.getNestedParameterType().getName() + "] not specified, and parameter name information not found in class file either.");
/*     */       }
/*     */     }
/*     */     
/* 177 */     return partName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @UsesJava8
/*     */   private static class OptionalResolver
/*     */   {
/*     */     public static Object resolveValue(Object value)
/*     */     {
/* 188 */       if ((value == null) || (((value instanceof Collection)) && (((Collection)value).isEmpty())) || (((value instanceof Object[])) && (((Object[])value).length == 0)))
/*     */       {
/* 190 */         return Optional.empty();
/*     */       }
/* 192 */       return Optional.of(value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\method\annotation\RequestPartMethodArgumentResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */