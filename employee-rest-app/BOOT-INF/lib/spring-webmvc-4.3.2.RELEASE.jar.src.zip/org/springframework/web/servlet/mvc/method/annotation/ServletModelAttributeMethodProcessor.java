/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletRequest;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.validation.DataBinder;
/*     */ import org.springframework.web.bind.ServletRequestDataBinder;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.annotation.ModelAttributeMethodProcessor;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletModelAttributeMethodProcessor
/*     */   extends ModelAttributeMethodProcessor
/*     */ {
/*     */   public ServletModelAttributeMethodProcessor(boolean annotationNotRequired)
/*     */   {
/*  56 */     super(annotationNotRequired);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final Object createAttribute(String attributeName, MethodParameter methodParam, WebDataBinderFactory binderFactory, NativeWebRequest request)
/*     */     throws Exception
/*     */   {
/*  71 */     String value = getRequestValueForAttribute(attributeName, request);
/*  72 */     if (value != null) {
/*  73 */       Object attribute = createAttributeFromRequestValue(value, attributeName, methodParam, binderFactory, request);
/*     */       
/*  75 */       if (attribute != null) {
/*  76 */         return attribute;
/*     */       }
/*     */     }
/*     */     
/*  80 */     return super.createAttribute(attributeName, methodParam, binderFactory, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getRequestValueForAttribute(String attributeName, NativeWebRequest request)
/*     */   {
/*  93 */     Map<String, String> variables = getUriTemplateVariables(request);
/*  94 */     if (StringUtils.hasText((String)variables.get(attributeName))) {
/*  95 */       return (String)variables.get(attributeName);
/*     */     }
/*  97 */     if (StringUtils.hasText(request.getParameter(attributeName))) {
/*  98 */       return request.getParameter(attributeName);
/*     */     }
/*     */     
/* 101 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   protected final Map<String, String> getUriTemplateVariables(NativeWebRequest request)
/*     */   {
/* 107 */     Map<String, String> variables = (Map)request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE, 0);
/*     */     
/* 109 */     return variables != null ? variables : Collections.emptyMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object createAttributeFromRequestValue(String sourceValue, String attributeName, MethodParameter methodParam, WebDataBinderFactory binderFactory, NativeWebRequest request)
/*     */     throws Exception
/*     */   {
/* 129 */     DataBinder binder = binderFactory.createBinder(request, null, attributeName);
/* 130 */     ConversionService conversionService = binder.getConversionService();
/* 131 */     if (conversionService != null) {
/* 132 */       TypeDescriptor source = TypeDescriptor.valueOf(String.class);
/* 133 */       TypeDescriptor target = new TypeDescriptor(methodParam);
/* 134 */       if (conversionService.canConvert(source, target)) {
/* 135 */         return binder.convertIfNecessary(sourceValue, methodParam.getParameterType(), methodParam);
/*     */       }
/*     */     }
/* 138 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void bindRequestParameters(WebDataBinder binder, NativeWebRequest request)
/*     */   {
/* 148 */     ServletRequest servletRequest = (ServletRequest)request.getNativeRequest(ServletRequest.class);
/* 149 */     ServletRequestDataBinder servletBinder = (ServletRequestDataBinder)binder;
/* 150 */     servletBinder.bind(servletRequest);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\method\annotation\ServletModelAttributeMethodProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */