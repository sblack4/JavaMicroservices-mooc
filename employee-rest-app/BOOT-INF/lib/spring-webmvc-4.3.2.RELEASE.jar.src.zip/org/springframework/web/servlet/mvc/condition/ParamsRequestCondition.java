/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ParamsRequestCondition
/*     */   extends AbstractRequestCondition<ParamsRequestCondition>
/*     */ {
/*     */   private final Set<ParamExpression> expressions;
/*     */   
/*     */   public ParamsRequestCondition(String... params)
/*     */   {
/*  47 */     this(parseExpressions(params));
/*     */   }
/*     */   
/*     */   private ParamsRequestCondition(Collection<ParamExpression> conditions) {
/*  51 */     this.expressions = Collections.unmodifiableSet(new LinkedHashSet(conditions));
/*     */   }
/*     */   
/*     */   private static Collection<ParamExpression> parseExpressions(String... params)
/*     */   {
/*  56 */     Set<ParamExpression> expressions = new LinkedHashSet();
/*  57 */     if (params != null) {
/*  58 */       for (String param : params) {
/*  59 */         expressions.add(new ParamExpression(param));
/*     */       }
/*     */     }
/*  62 */     return expressions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<NameValueExpression<String>> getExpressions()
/*     */   {
/*  70 */     return new LinkedHashSet(this.expressions);
/*     */   }
/*     */   
/*     */   protected Collection<ParamExpression> getContent()
/*     */   {
/*  75 */     return this.expressions;
/*     */   }
/*     */   
/*     */   protected String getToStringInfix()
/*     */   {
/*  80 */     return " && ";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ParamsRequestCondition combine(ParamsRequestCondition other)
/*     */   {
/*  89 */     Set<ParamExpression> set = new LinkedHashSet(this.expressions);
/*  90 */     set.addAll(other.expressions);
/*  91 */     return new ParamsRequestCondition(set);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ParamsRequestCondition getMatchingCondition(HttpServletRequest request)
/*     */   {
/* 100 */     for (ParamExpression expression : this.expressions) {
/* 101 */       if (!expression.match(request)) {
/* 102 */         return null;
/*     */       }
/*     */     }
/* 105 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compareTo(ParamsRequestCondition other, HttpServletRequest request)
/*     */   {
/* 121 */     return other.expressions.size() - this.expressions.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static class ParamExpression
/*     */     extends AbstractNameValueExpression<String>
/*     */   {
/*     */     ParamExpression(String expression)
/*     */     {
/* 131 */       super();
/*     */     }
/*     */     
/*     */     protected boolean isCaseSensitiveName()
/*     */     {
/* 136 */       return true;
/*     */     }
/*     */     
/*     */     protected String parseValue(String valueExpression)
/*     */     {
/* 141 */       return valueExpression;
/*     */     }
/*     */     
/*     */     protected boolean matchName(HttpServletRequest request)
/*     */     {
/* 146 */       return WebUtils.hasSubmitParameter(request, this.name);
/*     */     }
/*     */     
/*     */     protected boolean matchValue(HttpServletRequest request)
/*     */     {
/* 151 */       return ((String)this.value).equals(request.getParameter(this.name));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\condition\ParamsRequestCondition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */