/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.http.CacheControl;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.HttpRequestMethodNotSupportedException;
/*     */ import org.springframework.web.HttpSessionRequiredException;
/*     */ import org.springframework.web.context.support.WebApplicationObjectSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class WebContentGenerator
/*     */   extends WebApplicationObjectSupport
/*     */ {
/*     */   public static final String METHOD_GET = "GET";
/*     */   public static final String METHOD_HEAD = "HEAD";
/*     */   public static final String METHOD_POST = "POST";
/*     */   private static final String HEADER_PRAGMA = "Pragma";
/*     */   private static final String HEADER_EXPIRES = "Expires";
/*     */   protected static final String HEADER_CACHE_CONTROL = "Cache-Control";
/*  85 */   private static final boolean servlet3Present = ClassUtils.hasMethod(HttpServletResponse.class, "getHeaders", new Class[] { String.class });
/*     */   
/*     */ 
/*     */   private Set<String> supportedMethods;
/*     */   
/*     */ 
/*     */   private String allowHeader;
/*     */   
/*  93 */   private boolean requireSession = false;
/*     */   
/*     */   private CacheControl cacheControl;
/*     */   
/*  97 */   private int cacheSeconds = -1;
/*     */   
/*     */ 
/*     */ 
/*     */   private String[] varyByRequestHeaders;
/*     */   
/*     */ 
/*     */ 
/* 105 */   private boolean useExpiresHeader = false;
/*     */   
/*     */ 
/* 108 */   private boolean useCacheControlHeader = true;
/*     */   
/*     */ 
/* 111 */   private boolean useCacheControlNoStore = true;
/*     */   
/* 113 */   private boolean alwaysMustRevalidate = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WebContentGenerator()
/*     */   {
/* 121 */     this(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WebContentGenerator(boolean restrictDefaultSupportedMethods)
/*     */   {
/* 131 */     if (restrictDefaultSupportedMethods) {
/* 132 */       this.supportedMethods = new LinkedHashSet(4);
/* 133 */       this.supportedMethods.add("GET");
/* 134 */       this.supportedMethods.add("HEAD");
/* 135 */       this.supportedMethods.add("POST");
/*     */     }
/* 137 */     initAllowHeader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public WebContentGenerator(String... supportedMethods)
/*     */   {
/* 145 */     setSupportedMethods(supportedMethods);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setSupportedMethods(String... methods)
/*     */   {
/* 155 */     if (!ObjectUtils.isEmpty(methods)) {
/* 156 */       this.supportedMethods = new LinkedHashSet(Arrays.asList(methods));
/*     */     }
/*     */     else {
/* 159 */       this.supportedMethods = null;
/*     */     }
/* 161 */     initAllowHeader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final String[] getSupportedMethods()
/*     */   {
/* 168 */     return StringUtils.toStringArray(this.supportedMethods);
/*     */   }
/*     */   
/*     */   private void initAllowHeader() {
/*     */     Collection<String> allowedMethods;
/* 173 */     if (this.supportedMethods == null) {
/* 174 */       Collection<String> allowedMethods = new ArrayList(HttpMethod.values().length - 1);
/* 175 */       for (HttpMethod method : HttpMethod.values()) {
/* 176 */         if (!HttpMethod.TRACE.equals(method))
/* 177 */           allowedMethods.add(method.name());
/*     */       }
/*     */     } else {
/*     */       Collection<String> allowedMethods;
/* 181 */       if (this.supportedMethods.contains(HttpMethod.OPTIONS.name())) {
/* 182 */         allowedMethods = this.supportedMethods;
/*     */       }
/*     */       else {
/* 185 */         allowedMethods = new ArrayList(this.supportedMethods);
/* 186 */         allowedMethods.add(HttpMethod.OPTIONS.name());
/*     */       }
/*     */     }
/* 189 */     this.allowHeader = StringUtils.collectionToCommaDelimitedString(allowedMethods);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getAllowHeader()
/*     */   {
/* 202 */     return this.allowHeader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void setRequireSession(boolean requireSession)
/*     */   {
/* 209 */     this.requireSession = requireSession;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final boolean isRequireSession()
/*     */   {
/* 216 */     return this.requireSession;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setCacheControl(CacheControl cacheControl)
/*     */   {
/* 225 */     this.cacheControl = cacheControl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final CacheControl getCacheControl()
/*     */   {
/* 234 */     return this.cacheControl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setCacheSeconds(int seconds)
/*     */   {
/* 250 */     this.cacheSeconds = seconds;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final int getCacheSeconds()
/*     */   {
/* 257 */     return this.cacheSeconds;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setVaryByRequestHeaders(String... varyByRequestHeaders)
/*     */   {
/* 272 */     this.varyByRequestHeaders = varyByRequestHeaders;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String[] getVaryByRequestHeaders()
/*     */   {
/* 280 */     return this.varyByRequestHeaders;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public final void setUseExpiresHeader(boolean useExpiresHeader)
/*     */   {
/* 293 */     this.useExpiresHeader = useExpiresHeader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public final boolean isUseExpiresHeader()
/*     */   {
/* 302 */     return this.useExpiresHeader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public final void setUseCacheControlHeader(boolean useCacheControlHeader)
/*     */   {
/* 314 */     this.useCacheControlHeader = useCacheControlHeader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public final boolean isUseCacheControlHeader()
/*     */   {
/* 323 */     return this.useCacheControlHeader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public final void setUseCacheControlNoStore(boolean useCacheControlNoStore)
/*     */   {
/* 333 */     this.useCacheControlNoStore = useCacheControlNoStore;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public final boolean isUseCacheControlNoStore()
/*     */   {
/* 342 */     return this.useCacheControlNoStore;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public final void setAlwaysMustRevalidate(boolean mustRevalidate)
/*     */   {
/* 355 */     this.alwaysMustRevalidate = mustRevalidate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public final boolean isAlwaysMustRevalidate()
/*     */   {
/* 364 */     return this.alwaysMustRevalidate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void checkRequest(HttpServletRequest request)
/*     */     throws ServletException
/*     */   {
/* 376 */     String method = request.getMethod();
/* 377 */     if ((this.supportedMethods != null) && (!this.supportedMethods.contains(method)))
/*     */     {
/* 379 */       throw new HttpRequestMethodNotSupportedException(method, StringUtils.toStringArray(this.supportedMethods));
/*     */     }
/*     */     
/*     */ 
/* 383 */     if ((this.requireSession) && (request.getSession(false) == null)) {
/* 384 */       throw new HttpSessionRequiredException("Pre-existing session required but none found");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void prepareResponse(HttpServletResponse response)
/*     */   {
/* 395 */     if (this.cacheControl != null) {
/* 396 */       applyCacheControl(response, this.cacheControl);
/*     */     }
/*     */     else {
/* 399 */       applyCacheSeconds(response, this.cacheSeconds);
/*     */     }
/* 401 */     if ((servlet3Present) && (this.varyByRequestHeaders != null)) {
/* 402 */       for (String value : getVaryRequestHeadersToAdd(response)) {
/* 403 */         response.addHeader("Vary", value);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void applyCacheControl(HttpServletResponse response, CacheControl cacheControl)
/*     */   {
/* 415 */     String ccValue = cacheControl.getHeaderValue();
/* 416 */     if (ccValue != null)
/*     */     {
/* 418 */       response.setHeader("Cache-Control", ccValue);
/*     */       
/* 420 */       if (response.containsHeader("Pragma"))
/*     */       {
/* 422 */         response.setHeader("Pragma", "");
/*     */       }
/* 424 */       if (response.containsHeader("Expires"))
/*     */       {
/* 426 */         response.setHeader("Expires", "");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void applyCacheSeconds(HttpServletResponse response, int cacheSeconds)
/*     */   {
/* 442 */     if ((this.useExpiresHeader) || (!this.useCacheControlHeader))
/*     */     {
/* 444 */       if (cacheSeconds > 0) {
/* 445 */         cacheForSeconds(response, cacheSeconds);
/*     */       }
/* 447 */       else if (cacheSeconds == 0) {
/* 448 */         preventCaching(response);
/*     */       }
/*     */     }
/*     */     else {
/*     */       CacheControl cControl;
/* 453 */       if (cacheSeconds > 0) {
/* 454 */         CacheControl cControl = CacheControl.maxAge(cacheSeconds, TimeUnit.SECONDS);
/* 455 */         if (this.alwaysMustRevalidate)
/* 456 */           cControl = cControl.mustRevalidate();
/*     */       } else {
/*     */         CacheControl cControl;
/* 459 */         if (cacheSeconds == 0) {
/* 460 */           cControl = this.useCacheControlNoStore ? CacheControl.noStore() : CacheControl.noCache();
/*     */         }
/*     */         else
/* 463 */           cControl = CacheControl.empty();
/*     */       }
/* 465 */       applyCacheControl(response, cControl);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected final void checkAndPrepare(HttpServletRequest request, HttpServletResponse response, boolean lastModified)
/*     */     throws ServletException
/*     */   {
/* 480 */     checkRequest(request);
/* 481 */     prepareResponse(response);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected final void checkAndPrepare(HttpServletRequest request, HttpServletResponse response, int cacheSeconds, boolean lastModified)
/*     */     throws ServletException
/*     */   {
/* 495 */     checkRequest(request);
/* 496 */     applyCacheSeconds(response, cacheSeconds);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected final void applyCacheSeconds(HttpServletResponse response, int cacheSeconds, boolean mustRevalidate)
/*     */   {
/* 514 */     if (cacheSeconds > 0) {
/* 515 */       cacheForSeconds(response, cacheSeconds, mustRevalidate);
/*     */     }
/* 517 */     else if (cacheSeconds == 0) {
/* 518 */       preventCaching(response);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected final void cacheForSeconds(HttpServletResponse response, int seconds)
/*     */   {
/* 532 */     cacheForSeconds(response, seconds, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected final void cacheForSeconds(HttpServletResponse response, int seconds, boolean mustRevalidate)
/*     */   {
/* 548 */     if (this.useExpiresHeader)
/*     */     {
/* 550 */       response.setDateHeader("Expires", System.currentTimeMillis() + seconds * 1000L);
/*     */     }
/* 552 */     else if (response.containsHeader("Expires"))
/*     */     {
/* 554 */       response.setHeader("Expires", "");
/*     */     }
/*     */     
/* 557 */     if (this.useCacheControlHeader)
/*     */     {
/* 559 */       String headerValue = "max-age=" + seconds;
/* 560 */       if ((mustRevalidate) || (this.alwaysMustRevalidate)) {
/* 561 */         headerValue = headerValue + ", must-revalidate";
/*     */       }
/* 563 */       response.setHeader("Cache-Control", headerValue);
/*     */     }
/*     */     
/* 566 */     if (response.containsHeader("Pragma"))
/*     */     {
/* 568 */       response.setHeader("Pragma", "");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected final void preventCaching(HttpServletResponse response)
/*     */   {
/* 580 */     response.setHeader("Pragma", "no-cache");
/*     */     
/* 582 */     if (this.useExpiresHeader)
/*     */     {
/* 584 */       response.setDateHeader("Expires", 1L);
/*     */     }
/*     */     
/* 587 */     if (this.useCacheControlHeader)
/*     */     {
/*     */ 
/* 590 */       response.setHeader("Cache-Control", "no-cache");
/* 591 */       if (this.useCacheControlNoStore) {
/* 592 */         response.addHeader("Cache-Control", "no-store");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private Collection<String> getVaryRequestHeadersToAdd(HttpServletResponse response)
/*     */   {
/* 599 */     if (!response.containsHeader("Vary")) {
/* 600 */       return Arrays.asList(getVaryByRequestHeaders());
/*     */     }
/* 602 */     Collection<String> result = new ArrayList(getVaryByRequestHeaders().length);
/* 603 */     Collections.addAll(result, getVaryByRequestHeaders());
/* 604 */     for (String header : response.getHeaders("Vary")) {
/* 605 */       for (String existing : StringUtils.tokenizeToStringArray(header, ",")) {
/* 606 */         if ("*".equals(existing)) {
/* 607 */           return Collections.emptyList();
/*     */         }
/* 609 */         for (String value : getVaryByRequestHeaders()) {
/* 610 */           if (value.equalsIgnoreCase(existing)) {
/* 611 */             result.remove(value);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 616 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\support\WebContentGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */