/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.SmartView;
/*     */ import org.springframework.web.servlet.View;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelAndViewMethodReturnValueHandler
/*     */   implements HandlerMethodReturnValueHandler
/*     */ {
/*     */   private String[] redirectPatterns;
/*     */   
/*     */   public void setRedirectPatterns(String... redirectPatterns)
/*     */   {
/*  59 */     this.redirectPatterns = redirectPatterns;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String[] getRedirectPatterns()
/*     */   {
/*  66 */     return this.redirectPatterns;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean supportsReturnType(MethodParameter returnType)
/*     */   {
/*  72 */     return ModelAndView.class.isAssignableFrom(returnType.getParameterType());
/*     */   }
/*     */   
/*     */ 
/*     */   public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/*  79 */     if (returnValue == null) {
/*  80 */       mavContainer.setRequestHandled(true);
/*  81 */       return;
/*     */     }
/*     */     
/*  84 */     ModelAndView mav = (ModelAndView)returnValue;
/*  85 */     if (mav.isReference()) {
/*  86 */       String viewName = mav.getViewName();
/*  87 */       mavContainer.setViewName(viewName);
/*  88 */       if ((viewName != null) && (isRedirectViewName(viewName))) {
/*  89 */         mavContainer.setRedirectModelScenario(true);
/*     */       }
/*     */     }
/*     */     else {
/*  93 */       View view = mav.getView();
/*  94 */       mavContainer.setView(view);
/*  95 */       if (((view instanceof SmartView)) && 
/*  96 */         (((SmartView)view).isRedirectView())) {
/*  97 */         mavContainer.setRedirectModelScenario(true);
/*     */       }
/*     */     }
/*     */     
/* 101 */     mavContainer.setStatus(mav.getStatus());
/* 102 */     mavContainer.addAllAttributes(mav.getModel());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isRedirectViewName(String viewName)
/*     */   {
/* 114 */     if (PatternMatchUtils.simpleMatch(this.redirectPatterns, viewName)) {
/* 115 */       return true;
/*     */     }
/* 117 */     return viewName.startsWith("redirect:");
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\method\annotation\ModelAndViewMethodReturnValueHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */