/*     */ package org.springframework.web.servlet;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.support.ServletContextResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceServlet
/*     */   extends HttpServletBean
/*     */ {
/*     */   public static final String RESOURCE_URL_DELIMITERS = ",; \t\n";
/*     */   public static final String RESOURCE_PARAM_NAME = "resource";
/*     */   private String defaultUrl;
/*     */   private String allowedResources;
/*     */   private String contentType;
/* 111 */   private boolean applyLastModified = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private PathMatcher pathMatcher;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private long startupTime;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultUrl(String defaultUrl)
/*     */   {
/* 128 */     this.defaultUrl = defaultUrl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAllowedResources(String allowedResources)
/*     */   {
/* 137 */     this.allowedResources = allowedResources;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContentType(String contentType)
/*     */   {
/* 149 */     this.contentType = contentType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setApplyLastModified(boolean applyLastModified)
/*     */   {
/* 164 */     this.applyLastModified = applyLastModified;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initServletBean()
/*     */   {
/* 173 */     this.pathMatcher = getPathMatcher();
/* 174 */     this.startupTime = System.currentTimeMillis();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PathMatcher getPathMatcher()
/*     */   {
/* 184 */     return new AntPathMatcher();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 197 */     String resourceUrl = determineResourceUrl(request);
/*     */     
/* 199 */     if (resourceUrl != null) {
/*     */       try {
/* 201 */         doInclude(request, response, resourceUrl);
/*     */       }
/*     */       catch (ServletException ex) {
/* 204 */         if (this.logger.isWarnEnabled()) {
/* 205 */           this.logger.warn("Failed to include content of resource [" + resourceUrl + "]", ex);
/*     */         }
/*     */         
/* 208 */         if (!includeDefaultUrl(request, response)) {
/* 209 */           throw ex;
/*     */         }
/*     */       }
/*     */       catch (IOException ex) {
/* 213 */         if (this.logger.isWarnEnabled()) {
/* 214 */           this.logger.warn("Failed to include content of resource [" + resourceUrl + "]", ex);
/*     */         }
/*     */         
/* 217 */         if (!includeDefaultUrl(request, response)) {
/* 218 */           throw ex;
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */     }
/* 224 */     else if (!includeDefaultUrl(request, response)) {
/* 225 */       throw new ServletException("No target resource URL found for request");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String determineResourceUrl(HttpServletRequest request)
/*     */   {
/* 238 */     return request.getParameter("resource");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean includeDefaultUrl(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 252 */     if (this.defaultUrl == null) {
/* 253 */       return false;
/*     */     }
/* 255 */     doInclude(request, response, this.defaultUrl);
/* 256 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void doInclude(HttpServletRequest request, HttpServletResponse response, String resourceUrl)
/*     */     throws ServletException, IOException
/*     */   {
/* 270 */     if (this.contentType != null) {
/* 271 */       response.setContentType(this.contentType);
/*     */     }
/*     */     
/* 274 */     String[] resourceUrls = StringUtils.tokenizeToStringArray(resourceUrl, ",; \t\n");
/* 275 */     for (int i = 0; i < resourceUrls.length; i++)
/*     */     {
/* 277 */       if ((this.allowedResources != null) && (!this.pathMatcher.match(this.allowedResources, resourceUrls[i]))) {
/* 278 */         throw new ServletException("Resource [" + resourceUrls[i] + "] does not match allowed pattern [" + this.allowedResources + "]");
/*     */       }
/*     */       
/* 281 */       if (this.logger.isDebugEnabled()) {
/* 282 */         this.logger.debug("Including resource [" + resourceUrls[i] + "]");
/*     */       }
/* 284 */       RequestDispatcher rd = request.getRequestDispatcher(resourceUrls[i]);
/* 285 */       rd.include(request, response);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final long getLastModified(HttpServletRequest request)
/*     */   {
/* 304 */     if (this.applyLastModified) {
/* 305 */       String resourceUrl = determineResourceUrl(request);
/* 306 */       if (resourceUrl == null) {
/* 307 */         resourceUrl = this.defaultUrl;
/*     */       }
/* 309 */       if (resourceUrl != null) {
/* 310 */         String[] resourceUrls = StringUtils.tokenizeToStringArray(resourceUrl, ",; \t\n");
/* 311 */         long latestTimestamp = -1L;
/* 312 */         for (int i = 0; i < resourceUrls.length; i++) {
/* 313 */           long timestamp = getFileTimestamp(resourceUrls[i]);
/* 314 */           if (timestamp > latestTimestamp) {
/* 315 */             latestTimestamp = timestamp;
/*     */           }
/*     */         }
/* 318 */         return latestTimestamp > this.startupTime ? latestTimestamp : this.startupTime;
/*     */       }
/*     */     }
/* 321 */     return -1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected long getFileTimestamp(String resourceUrl)
/*     */   {
/* 330 */     ServletContextResource resource = new ServletContextResource(getServletContext(), resourceUrl);
/*     */     try {
/* 332 */       long lastModifiedTime = resource.lastModified();
/* 333 */       if (this.logger.isDebugEnabled()) {
/* 334 */         this.logger.debug("Last-modified timestamp of " + resource + " is " + lastModifiedTime);
/*     */       }
/* 336 */       return lastModifiedTime;
/*     */     }
/*     */     catch (IOException ex) {
/* 339 */       this.logger.warn("Couldn't retrieve last-modified timestamp of [" + resource + "] - using ResourceServlet startup time");
/*     */     }
/* 341 */     return -1L;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\ResourceServlet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */