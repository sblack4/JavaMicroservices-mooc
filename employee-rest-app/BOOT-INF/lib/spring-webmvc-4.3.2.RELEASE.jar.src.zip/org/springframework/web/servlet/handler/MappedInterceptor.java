/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.web.context.request.WebRequestInterceptor;
/*     */ import org.springframework.web.servlet.HandlerInterceptor;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MappedInterceptor
/*     */   implements HandlerInterceptor
/*     */ {
/*     */   private final String[] includePatterns;
/*     */   private final String[] excludePatterns;
/*     */   private final HandlerInterceptor interceptor;
/*     */   private PathMatcher pathMatcher;
/*     */   
/*     */   public MappedInterceptor(String[] includePatterns, HandlerInterceptor interceptor)
/*     */   {
/*  61 */     this(includePatterns, null, interceptor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MappedInterceptor(String[] includePatterns, String[] excludePatterns, HandlerInterceptor interceptor)
/*     */   {
/*  71 */     this.includePatterns = includePatterns;
/*  72 */     this.excludePatterns = excludePatterns;
/*  73 */     this.interceptor = interceptor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MappedInterceptor(String[] includePatterns, WebRequestInterceptor interceptor)
/*     */   {
/*  83 */     this(includePatterns, null, interceptor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MappedInterceptor(String[] includePatterns, String[] excludePatterns, WebRequestInterceptor interceptor)
/*     */   {
/*  92 */     this(includePatterns, excludePatterns, new WebRequestHandlerInterceptorAdapter(interceptor));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPathMatcher(PathMatcher pathMatcher)
/*     */   {
/* 106 */     this.pathMatcher = pathMatcher;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PathMatcher getPathMatcher()
/*     */   {
/* 113 */     return this.pathMatcher;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String[] getPathPatterns()
/*     */   {
/* 120 */     return this.includePatterns;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public HandlerInterceptor getInterceptor()
/*     */   {
/* 127 */     return this.interceptor;
/*     */   }
/*     */   
/*     */   public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception
/*     */   {
/* 132 */     return this.interceptor.preHandle(request, response, handler);
/*     */   }
/*     */   
/*     */   public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception
/*     */   {
/* 137 */     this.interceptor.postHandle(request, response, handler, modelAndView);
/*     */   }
/*     */   
/*     */   public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception
/*     */   {
/* 142 */     this.interceptor.afterCompletion(request, response, handler, ex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matches(String lookupPath, PathMatcher pathMatcher)
/*     */   {
/* 151 */     PathMatcher pathMatcherToUse = this.pathMatcher != null ? this.pathMatcher : pathMatcher;
/* 152 */     if (this.excludePatterns != null) {
/* 153 */       for (String pattern : this.excludePatterns) {
/* 154 */         if (pathMatcherToUse.match(pattern, lookupPath)) {
/* 155 */           return false;
/*     */         }
/*     */       }
/*     */     }
/* 159 */     if (this.includePatterns == null) {
/* 160 */       return true;
/*     */     }
/*     */     
/* 163 */     for (String pattern : this.includePatterns) {
/* 164 */       if (pathMatcherToUse.match(pattern, lookupPath)) {
/* 165 */         return true;
/*     */       }
/*     */     }
/* 168 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\handler\MappedInterceptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */