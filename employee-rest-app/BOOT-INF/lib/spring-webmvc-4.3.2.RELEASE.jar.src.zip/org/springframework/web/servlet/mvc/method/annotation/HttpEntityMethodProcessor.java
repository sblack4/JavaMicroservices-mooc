/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.RequestEntity;
/*     */ import org.springframework.http.ResponseEntity;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpEntityMethodProcessor
/*     */   extends AbstractMessageConverterMethodProcessor
/*     */ {
/*     */   public HttpEntityMethodProcessor(List<HttpMessageConverter<?>> converters)
/*     */   {
/*  68 */     super(converters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpEntityMethodProcessor(List<HttpMessageConverter<?>> converters, ContentNegotiationManager manager)
/*     */   {
/*  79 */     super(converters, manager);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpEntityMethodProcessor(List<HttpMessageConverter<?>> converters, List<Object> requestResponseBodyAdvice)
/*     */   {
/*  91 */     super(converters, null, requestResponseBodyAdvice);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpEntityMethodProcessor(List<HttpMessageConverter<?>> converters, ContentNegotiationManager manager, List<Object> requestResponseBodyAdvice)
/*     */   {
/* 101 */     super(converters, manager, requestResponseBodyAdvice);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/* 108 */     return (HttpEntity.class == parameter.getParameterType()) || (RequestEntity.class == parameter.getParameterType());
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean supportsReturnType(MethodParameter returnType)
/*     */   {
/* 114 */     return (HttpEntity.class.isAssignableFrom(returnType.getParameterType())) && (!RequestEntity.class.isAssignableFrom(returnType.getParameterType()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*     */     throws IOException, HttpMediaTypeNotSupportedException
/*     */   {
/* 122 */     ServletServerHttpRequest inputMessage = createInputMessage(webRequest);
/* 123 */     Type paramType = getHttpEntityType(parameter);
/*     */     
/* 125 */     Object body = readWithMessageConverters(webRequest, parameter, paramType);
/* 126 */     if (RequestEntity.class == parameter.getParameterType())
/*     */     {
/* 128 */       return new RequestEntity(body, inputMessage.getHeaders(), inputMessage.getMethod(), inputMessage.getURI());
/*     */     }
/*     */     
/* 131 */     return new HttpEntity(body, inputMessage.getHeaders());
/*     */   }
/*     */   
/*     */   private Type getHttpEntityType(MethodParameter parameter)
/*     */   {
/* 136 */     Assert.isAssignable(HttpEntity.class, parameter.getParameterType());
/* 137 */     Type parameterType = parameter.getGenericParameterType();
/* 138 */     if ((parameterType instanceof ParameterizedType)) {
/* 139 */       ParameterizedType type = (ParameterizedType)parameterType;
/* 140 */       if (type.getActualTypeArguments().length != 1)
/*     */       {
/* 142 */         throw new IllegalArgumentException("Expected single generic parameter on '" + parameter.getParameterName() + "' in method " + parameter.getMethod());
/*     */       }
/* 144 */       return type.getActualTypeArguments()[0];
/*     */     }
/* 146 */     if ((parameterType instanceof Class)) {
/* 147 */       return Object.class;
/*     */     }
/*     */     
/* 150 */     throw new IllegalArgumentException("HttpEntity parameter '" + parameter.getParameterName() + "' in method " + parameter.getMethod() + " is not parameterized");
/*     */   }
/*     */   
/*     */ 
/*     */   public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 157 */     mavContainer.setRequestHandled(true);
/* 158 */     if (returnValue == null) {
/* 159 */       return;
/*     */     }
/*     */     
/* 162 */     ServletServerHttpRequest inputMessage = createInputMessage(webRequest);
/* 163 */     ServletServerHttpResponse outputMessage = createOutputMessage(webRequest);
/*     */     
/* 165 */     Assert.isInstanceOf(HttpEntity.class, returnValue);
/* 166 */     HttpEntity<?> responseEntity = (HttpEntity)returnValue;
/*     */     
/* 168 */     HttpHeaders outputHeaders = outputMessage.getHeaders();
/* 169 */     HttpHeaders entityHeaders = responseEntity.getHeaders();
/* 170 */     List<String> values; if ((outputHeaders.containsKey("Vary")) && (entityHeaders.containsKey("Vary"))) {
/* 171 */       values = getVaryRequestHeadersToAdd(outputHeaders, entityHeaders);
/* 172 */       if (!values.isEmpty()) {
/* 173 */         outputHeaders.setVary(values);
/*     */       }
/*     */     }
/* 176 */     if (!entityHeaders.isEmpty()) {
/* 177 */       for (Map.Entry<String, List<String>> entry : entityHeaders.entrySet()) {
/* 178 */         if (!outputHeaders.containsKey(entry.getKey())) {
/* 179 */           outputHeaders.put((String)entry.getKey(), (List)entry.getValue());
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 184 */     if ((responseEntity instanceof ResponseEntity)) {
/* 185 */       outputMessage.getServletResponse().setStatus(((ResponseEntity)responseEntity).getStatusCodeValue());
/* 186 */       HttpMethod method = inputMessage.getMethod();
/* 187 */       boolean isGetOrHead = (HttpMethod.GET == method) || (HttpMethod.HEAD == method);
/* 188 */       if ((isGetOrHead) && (isResourceNotModified(inputMessage, outputMessage))) {
/* 189 */         outputMessage.setStatusCode(HttpStatus.NOT_MODIFIED);
/*     */         
/* 191 */         outputMessage.flush();
/*     */         
/* 193 */         return;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 198 */     writeWithMessageConverters(responseEntity.getBody(), returnType, inputMessage, outputMessage);
/*     */     
/*     */ 
/* 201 */     outputMessage.flush();
/*     */   }
/*     */   
/*     */   private List<String> getVaryRequestHeadersToAdd(HttpHeaders responseHeaders, HttpHeaders entityHeaders) {
/* 205 */     if (!responseHeaders.containsKey("Vary")) {
/* 206 */       return entityHeaders.getVary();
/*     */     }
/* 208 */     List<String> entityHeadersVary = entityHeaders.getVary();
/* 209 */     List<String> result = new ArrayList(entityHeadersVary);
/* 210 */     for (String header : responseHeaders.get("Vary")) { String existing;
/* 211 */       for (existing : StringUtils.tokenizeToStringArray(header, ",")) {
/* 212 */         if ("*".equals(existing)) {
/* 213 */           return Collections.emptyList();
/*     */         }
/* 215 */         for (String value : entityHeadersVary) {
/* 216 */           if (value.equalsIgnoreCase(existing)) {
/* 217 */             result.remove(value);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 222 */     return result;
/*     */   }
/*     */   
/*     */   private boolean isResourceNotModified(ServletServerHttpRequest inputMessage, ServletServerHttpResponse outputMessage) {
/* 226 */     List<String> ifNoneMatch = inputMessage.getHeaders().getIfNoneMatch();
/* 227 */     long ifModifiedSince = inputMessage.getHeaders().getIfModifiedSince();
/* 228 */     String eTag = addEtagPadding(outputMessage.getHeaders().getETag());
/* 229 */     long lastModified = outputMessage.getHeaders().getLastModified();
/* 230 */     boolean notModified = false;
/*     */     
/* 232 */     if ((ifNoneMatch.isEmpty()) || ((!inputMessage.getHeaders().containsKey("If-Unmodified-Since")) && 
/* 233 */       (!inputMessage.getHeaders().containsKey("If-Match"))))
/*     */     {
/*     */ 
/* 236 */       if ((lastModified != -1L) && (StringUtils.hasLength(eTag))) {
/* 237 */         notModified = (isETagNotModified(ifNoneMatch, eTag)) && (isTimeStampNotModified(ifModifiedSince, lastModified));
/*     */       }
/* 239 */       else if (lastModified != -1L) {
/* 240 */         notModified = isTimeStampNotModified(ifModifiedSince, lastModified);
/*     */       }
/* 242 */       else if (StringUtils.hasLength(eTag))
/* 243 */         notModified = isETagNotModified(ifNoneMatch, eTag);
/*     */     }
/* 245 */     return notModified;
/*     */   }
/*     */   
/*     */   private boolean isETagNotModified(List<String> ifNoneMatch, String etag) {
/* 249 */     if (StringUtils.hasLength(etag)) {
/* 250 */       for (String clientETag : ifNoneMatch)
/*     */       {
/* 252 */         if ((StringUtils.hasLength(clientETag)) && 
/* 253 */           (clientETag.replaceFirst("^W/", "").equals(etag.replaceFirst("^W/", "")))) {
/* 254 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 258 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isTimeStampNotModified(long ifModifiedSince, long lastModifiedTimestamp) {
/* 262 */     return ifModifiedSince >= lastModifiedTimestamp / 1000L * 1000L;
/*     */   }
/*     */   
/*     */   private String addEtagPadding(String etag) {
/* 266 */     if ((StringUtils.hasLength(etag)) && (
/* 267 */       ((!etag.startsWith("\"")) && (!etag.startsWith("W/\""))) || (!etag.endsWith("\"")))) {
/* 268 */       etag = "\"" + etag + "\"";
/*     */     }
/* 270 */     return etag;
/*     */   }
/*     */   
/*     */   protected Class<?> getReturnValueType(Object returnValue, MethodParameter returnType)
/*     */   {
/* 275 */     if (returnValue != null) {
/* 276 */       return returnValue.getClass();
/*     */     }
/*     */     
/* 279 */     Type type = getHttpEntityType(returnType);
/* 280 */     return ResolvableType.forMethodParameter(returnType, type).resolve(Object.class);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\method\annotation\HttpEntityMethodProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */