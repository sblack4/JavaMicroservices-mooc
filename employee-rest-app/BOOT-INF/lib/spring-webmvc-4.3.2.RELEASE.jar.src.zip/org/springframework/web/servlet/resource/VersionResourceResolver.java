/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.io.AbstractResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VersionResourceResolver
/*     */   extends AbstractResourceResolver
/*     */ {
/*  65 */   private AntPathMatcher pathMatcher = new AntPathMatcher();
/*     */   
/*     */ 
/*  68 */   private final Map<String, VersionStrategy> versionStrategyMap = new LinkedHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStrategyMap(Map<String, VersionStrategy> map)
/*     */   {
/*  78 */     this.versionStrategyMap.clear();
/*  79 */     this.versionStrategyMap.putAll(map);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Map<String, VersionStrategy> getStrategyMap()
/*     */   {
/*  86 */     return this.versionStrategyMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public VersionResourceResolver addContentVersionStrategy(String... pathPatterns)
/*     */   {
/* 101 */     addVersionStrategy(new ContentVersionStrategy(), pathPatterns);
/* 102 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public VersionResourceResolver addFixedVersionStrategy(String version, String... pathPatterns)
/*     */   {
/* 123 */     List<String> patternsList = Arrays.asList(pathPatterns);
/* 124 */     List<String> prefixedPatterns = new ArrayList(pathPatterns.length);
/* 125 */     String versionPrefix = "/" + version;
/* 126 */     for (String pattern : patternsList) {
/* 127 */       prefixedPatterns.add(pattern);
/* 128 */       if ((!pattern.startsWith(versionPrefix)) && (!patternsList.contains(versionPrefix + pattern))) {
/* 129 */         prefixedPatterns.add(versionPrefix + pattern);
/*     */       }
/*     */     }
/* 132 */     return addVersionStrategy(new FixedVersionStrategy(version), (String[])prefixedPatterns.toArray(new String[0]));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public VersionResourceResolver addVersionStrategy(VersionStrategy strategy, String... pathPatterns)
/*     */   {
/* 144 */     for (String pattern : pathPatterns) {
/* 145 */       getStrategyMap().put(pattern, strategy);
/*     */     }
/* 147 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Resource resolveResourceInternal(HttpServletRequest request, String requestPath, List<? extends Resource> locations, ResourceResolverChain chain)
/*     */   {
/* 155 */     Resource resolved = chain.resolveResource(request, requestPath, locations);
/* 156 */     if (resolved != null) {
/* 157 */       return resolved;
/*     */     }
/*     */     
/* 160 */     VersionStrategy versionStrategy = getStrategyForPath(requestPath);
/* 161 */     if (versionStrategy == null) {
/* 162 */       return null;
/*     */     }
/*     */     
/* 165 */     String candidateVersion = versionStrategy.extractVersion(requestPath);
/* 166 */     if (StringUtils.isEmpty(candidateVersion)) {
/* 167 */       if (this.logger.isTraceEnabled()) {
/* 168 */         this.logger.trace("No version found in path \"" + requestPath + "\"");
/*     */       }
/* 170 */       return null;
/*     */     }
/*     */     
/* 173 */     String simplePath = versionStrategy.removeVersion(requestPath, candidateVersion);
/* 174 */     if (this.logger.isTraceEnabled()) {
/* 175 */       this.logger.trace("Extracted version from path, re-resolving without version: \"" + simplePath + "\"");
/*     */     }
/*     */     
/* 178 */     Resource baseResource = chain.resolveResource(request, simplePath, locations);
/* 179 */     if (baseResource == null) {
/* 180 */       return null;
/*     */     }
/*     */     
/* 183 */     String actualVersion = versionStrategy.getResourceVersion(baseResource);
/* 184 */     if (candidateVersion.equals(actualVersion)) {
/* 185 */       if (this.logger.isTraceEnabled()) {
/* 186 */         this.logger.trace("Resource matches extracted version [" + candidateVersion + "]");
/*     */       }
/* 188 */       return new FileNameVersionedResource(baseResource, candidateVersion);
/*     */     }
/*     */     
/* 191 */     if (this.logger.isTraceEnabled()) {
/* 192 */       this.logger.trace("Potential resource found for \"" + requestPath + "\", but version [" + candidateVersion + "] does not match");
/*     */     }
/*     */     
/* 195 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   protected String resolveUrlPathInternal(String resourceUrlPath, List<? extends Resource> locations, ResourceResolverChain chain)
/*     */   {
/* 201 */     String baseUrl = chain.resolveUrlPath(resourceUrlPath, locations);
/* 202 */     if (StringUtils.hasText(baseUrl)) {
/* 203 */       VersionStrategy versionStrategy = getStrategyForPath(resourceUrlPath);
/* 204 */       if (versionStrategy == null) {
/* 205 */         return null;
/*     */       }
/* 207 */       if (this.logger.isTraceEnabled()) {
/* 208 */         this.logger.trace("Getting the original resource to determine version for path \"" + resourceUrlPath + "\"");
/*     */       }
/* 210 */       Resource resource = chain.resolveResource(null, baseUrl, locations);
/* 211 */       String version = versionStrategy.getResourceVersion(resource);
/* 212 */       if (this.logger.isTraceEnabled()) {
/* 213 */         this.logger.trace("Determined version [" + version + "] for " + resource);
/*     */       }
/* 215 */       return versionStrategy.addVersion(baseUrl, version);
/*     */     }
/* 217 */     return baseUrl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected VersionStrategy getStrategyForPath(String requestPath)
/*     */   {
/* 225 */     String path = "/".concat(requestPath);
/* 226 */     List<String> matchingPatterns = new ArrayList();
/* 227 */     for (String pattern : this.versionStrategyMap.keySet()) {
/* 228 */       if (this.pathMatcher.match(pattern, path)) {
/* 229 */         matchingPatterns.add(pattern);
/*     */       }
/*     */     }
/* 232 */     if (!matchingPatterns.isEmpty()) {
/* 233 */       Object comparator = this.pathMatcher.getPatternComparator(path);
/* 234 */       Collections.sort(matchingPatterns, (Comparator)comparator);
/* 235 */       return (VersionStrategy)this.versionStrategyMap.get(matchingPatterns.get(0));
/*     */     }
/* 237 */     return null;
/*     */   }
/*     */   
/*     */   private class FileNameVersionedResource
/*     */     extends AbstractResource implements VersionedResource
/*     */   {
/*     */     private final Resource original;
/*     */     private final String version;
/*     */     
/*     */     public FileNameVersionedResource(Resource original, String version)
/*     */     {
/* 248 */       this.original = original;
/* 249 */       this.version = version;
/*     */     }
/*     */     
/*     */     public boolean exists()
/*     */     {
/* 254 */       return this.original.exists();
/*     */     }
/*     */     
/*     */     public boolean isReadable()
/*     */     {
/* 259 */       return this.original.isReadable();
/*     */     }
/*     */     
/*     */     public boolean isOpen()
/*     */     {
/* 264 */       return this.original.isOpen();
/*     */     }
/*     */     
/*     */     public URL getURL() throws IOException
/*     */     {
/* 269 */       return this.original.getURL();
/*     */     }
/*     */     
/*     */     public URI getURI() throws IOException
/*     */     {
/* 274 */       return this.original.getURI();
/*     */     }
/*     */     
/*     */     public File getFile() throws IOException
/*     */     {
/* 279 */       return this.original.getFile();
/*     */     }
/*     */     
/*     */     public String getFilename()
/*     */     {
/* 284 */       return this.original.getFilename();
/*     */     }
/*     */     
/*     */     public long contentLength() throws IOException
/*     */     {
/* 289 */       return this.original.contentLength();
/*     */     }
/*     */     
/*     */     public long lastModified() throws IOException
/*     */     {
/* 294 */       return this.original.lastModified();
/*     */     }
/*     */     
/*     */     public Resource createRelative(String relativePath) throws IOException
/*     */     {
/* 299 */       return this.original.createRelative(relativePath);
/*     */     }
/*     */     
/*     */     public String getDescription()
/*     */     {
/* 304 */       return this.original.getDescription();
/*     */     }
/*     */     
/*     */     public InputStream getInputStream() throws IOException
/*     */     {
/* 309 */       return this.original.getInputStream();
/*     */     }
/*     */     
/*     */     public String getVersion()
/*     */     {
/* 314 */       return this.version;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\resource\VersionResourceResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */