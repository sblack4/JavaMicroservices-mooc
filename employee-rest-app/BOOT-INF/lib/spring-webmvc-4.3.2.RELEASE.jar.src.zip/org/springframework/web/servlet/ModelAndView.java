/*     */ package org.springframework.web.servlet;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelAndView
/*     */ {
/*     */   private Object view;
/*     */   private ModelMap model;
/*     */   private HttpStatus status;
/*  58 */   private boolean cleared = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModelAndView() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModelAndView(String viewName)
/*     */   {
/*  78 */     this.view = viewName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModelAndView(View view)
/*     */   {
/*  88 */     this.view = view;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModelAndView(String viewName, Map<String, ?> model)
/*     */   {
/* 100 */     this.view = viewName;
/* 101 */     if (model != null) {
/* 102 */       getModelMap().addAllAttributes(model);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModelAndView(View view, Map<String, ?> model)
/*     */   {
/* 117 */     this.view = view;
/* 118 */     if (model != null) {
/* 119 */       getModelMap().addAllAttributes(model);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModelAndView(String viewName, Map<String, ?> model, HttpStatus status)
/*     */   {
/* 134 */     this.view = viewName;
/* 135 */     if (model != null) {
/* 136 */       getModelMap().addAllAttributes(model);
/*     */     }
/* 138 */     this.status = status;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModelAndView(String viewName, String modelName, Object modelObject)
/*     */   {
/* 149 */     this.view = viewName;
/* 150 */     addObject(modelName, modelObject);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModelAndView(View view, String modelName, Object modelObject)
/*     */   {
/* 160 */     this.view = view;
/* 161 */     addObject(modelName, modelObject);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setViewName(String viewName)
/*     */   {
/* 171 */     this.view = viewName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getViewName()
/*     */   {
/* 179 */     return (this.view instanceof String) ? (String)this.view : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setView(View view)
/*     */   {
/* 187 */     this.view = view;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public View getView()
/*     */   {
/* 195 */     return (this.view instanceof View) ? (View)this.view : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasView()
/*     */   {
/* 203 */     return this.view != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isReference()
/*     */   {
/* 212 */     return this.view instanceof String;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Map<String, Object> getModelInternal()
/*     */   {
/* 220 */     return this.model;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ModelMap getModelMap()
/*     */   {
/* 227 */     if (this.model == null) {
/* 228 */       this.model = new ModelMap();
/*     */     }
/* 230 */     return this.model;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, Object> getModel()
/*     */   {
/* 238 */     return getModelMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStatus(HttpStatus status)
/*     */   {
/* 246 */     this.status = status;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpStatus getStatus()
/*     */   {
/* 254 */     return this.status;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModelAndView addObject(String attributeName, Object attributeValue)
/*     */   {
/* 266 */     getModelMap().addAttribute(attributeName, attributeValue);
/* 267 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModelAndView addObject(Object attributeValue)
/*     */   {
/* 277 */     getModelMap().addAttribute(attributeValue);
/* 278 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModelAndView addAllObjects(Map<String, ?> modelMap)
/*     */   {
/* 288 */     getModelMap().addAllAttributes(modelMap);
/* 289 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 302 */     this.view = null;
/* 303 */     this.model = null;
/* 304 */     this.cleared = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 312 */     return (this.view == null) && (CollectionUtils.isEmpty(this.model));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean wasCleared()
/*     */   {
/* 323 */     return (this.cleared) && (isEmpty());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 332 */     StringBuilder sb = new StringBuilder("ModelAndView: ");
/* 333 */     if (isReference()) {
/* 334 */       sb.append("reference to view with name '").append(this.view).append("'");
/*     */     }
/*     */     else {
/* 337 */       sb.append("materialized View is [").append(this.view).append(']');
/*     */     }
/* 339 */     sb.append("; model is ").append(this.model);
/* 340 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\ModelAndView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */