/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.BeanInitializationException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.ViewResolver;
/*     */ import org.springframework.web.servlet.view.BeanNameViewResolver;
/*     */ import org.springframework.web.servlet.view.ContentNegotiatingViewResolver;
/*     */ import org.springframework.web.servlet.view.InternalResourceViewResolver;
/*     */ import org.springframework.web.servlet.view.UrlBasedViewResolver;
/*     */ import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;
/*     */ import org.springframework.web.servlet.view.freemarker.FreeMarkerViewResolver;
/*     */ import org.springframework.web.servlet.view.groovy.GroovyMarkupConfigurer;
/*     */ import org.springframework.web.servlet.view.groovy.GroovyMarkupViewResolver;
/*     */ import org.springframework.web.servlet.view.script.ScriptTemplateConfigurer;
/*     */ import org.springframework.web.servlet.view.script.ScriptTemplateViewResolver;
/*     */ import org.springframework.web.servlet.view.tiles3.TilesConfigurer;
/*     */ import org.springframework.web.servlet.view.tiles3.TilesViewResolver;
/*     */ import org.springframework.web.servlet.view.velocity.VelocityConfigurer;
/*     */ import org.springframework.web.servlet.view.velocity.VelocityViewResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ViewResolverRegistry
/*     */ {
/*     */   private ContentNegotiatingViewResolver contentNegotiatingResolver;
/*  58 */   private final List<ViewResolver> viewResolvers = new ArrayList(4);
/*     */   
/*     */   private Integer order;
/*     */   
/*     */   private ContentNegotiationManager contentNegotiationManager;
/*     */   
/*     */   private ApplicationContext applicationContext;
/*     */   
/*     */   protected void setContentNegotiationManager(ContentNegotiationManager contentNegotiationManager)
/*     */   {
/*  68 */     this.contentNegotiationManager = contentNegotiationManager;
/*     */   }
/*     */   
/*     */   protected void setApplicationContext(ApplicationContext applicationContext) {
/*  72 */     this.applicationContext = applicationContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean hasRegistrations()
/*     */   {
/*  79 */     return (this.contentNegotiatingResolver != null) || (!this.viewResolvers.isEmpty());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void enableContentNegotiation(View... defaultViews)
/*     */   {
/*  92 */     initContentNegotiatingViewResolver(defaultViews);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void enableContentNegotiation(boolean useNotAcceptableStatus, View... defaultViews)
/*     */   {
/* 105 */     initContentNegotiatingViewResolver(defaultViews);
/* 106 */     this.contentNegotiatingResolver.setUseNotAcceptableStatusCode(useNotAcceptableStatus);
/*     */   }
/*     */   
/*     */   private void initContentNegotiatingViewResolver(View[] defaultViews)
/*     */   {
/* 111 */     this.order = Integer.valueOf(this.order != null ? this.order.intValue() : Integer.MIN_VALUE);
/*     */     
/* 113 */     if (this.contentNegotiatingResolver != null) {
/* 114 */       if ((!ObjectUtils.isEmpty(defaultViews)) && 
/* 115 */         (!CollectionUtils.isEmpty(this.contentNegotiatingResolver.getDefaultViews()))) {
/* 116 */         List<View> views = new ArrayList(this.contentNegotiatingResolver.getDefaultViews());
/* 117 */         views.addAll(Arrays.asList(defaultViews));
/* 118 */         this.contentNegotiatingResolver.setDefaultViews(views);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 123 */       this.contentNegotiatingResolver = new ContentNegotiatingViewResolver();
/* 124 */       this.contentNegotiatingResolver.setDefaultViews(Arrays.asList(defaultViews));
/* 125 */       this.contentNegotiatingResolver.setViewResolvers(this.viewResolvers);
/* 126 */       this.contentNegotiatingResolver.setContentNegotiationManager(this.contentNegotiationManager);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UrlBasedViewResolverRegistration jsp()
/*     */   {
/* 140 */     return jsp("/WEB-INF/", ".jsp");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UrlBasedViewResolverRegistration jsp(String prefix, String suffix)
/*     */   {
/* 152 */     InternalResourceViewResolver resolver = new InternalResourceViewResolver();
/* 153 */     resolver.setPrefix(prefix);
/* 154 */     resolver.setSuffix(suffix);
/* 155 */     this.viewResolvers.add(resolver);
/* 156 */     return new UrlBasedViewResolverRegistration(resolver);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UrlBasedViewResolverRegistration tiles()
/*     */   {
/* 165 */     if ((this.applicationContext != null) && (!hasBeanOfType(TilesConfigurer.class))) {
/* 166 */       throw new BeanInitializationException("In addition to a Tiles view resolver there must also be a single TilesConfigurer bean in this web application context (or its parent).");
/*     */     }
/*     */     
/*     */ 
/* 170 */     TilesRegistration registration = new TilesRegistration();
/* 171 */     this.viewResolvers.add(registration.getViewResolver());
/* 172 */     return registration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UrlBasedViewResolverRegistration freeMarker()
/*     */   {
/* 182 */     if ((this.applicationContext != null) && (!hasBeanOfType(FreeMarkerConfigurer.class))) {
/* 183 */       throw new BeanInitializationException("In addition to a FreeMarker view resolver there must also be a single FreeMarkerConfig bean in this web application context (or its parent): FreeMarkerConfigurer is the usual implementation. This bean may be given any name.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 188 */     FreeMarkerRegistration registration = new FreeMarkerRegistration();
/* 189 */     this.viewResolvers.add(registration.getViewResolver());
/* 190 */     return registration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public UrlBasedViewResolverRegistration velocity()
/*     */   {
/* 202 */     if ((this.applicationContext != null) && (!hasBeanOfType(VelocityConfigurer.class))) {
/* 203 */       throw new BeanInitializationException("In addition to a Velocity view resolver there must also be a single VelocityConfig bean in this web application context (or its parent): VelocityConfigurer is the usual implementation. This bean may be given any name.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 208 */     VelocityRegistration registration = new VelocityRegistration();
/* 209 */     this.viewResolvers.add(registration.getViewResolver());
/* 210 */     return registration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public UrlBasedViewResolverRegistration groovy()
/*     */   {
/* 218 */     if ((this.applicationContext != null) && (!hasBeanOfType(GroovyMarkupConfigurer.class))) {
/* 219 */       throw new BeanInitializationException("In addition to a Groovy markup view resolver there must also be a single GroovyMarkupConfig bean in this web application context (or its parent): GroovyMarkupConfigurer is the usual implementation. This bean may be given any name.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 224 */     GroovyMarkupRegistration registration = new GroovyMarkupRegistration();
/* 225 */     this.viewResolvers.add(registration.getViewResolver());
/* 226 */     return registration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public UrlBasedViewResolverRegistration scriptTemplate()
/*     */   {
/* 234 */     if ((this.applicationContext != null) && (!hasBeanOfType(ScriptTemplateConfigurer.class))) {
/* 235 */       throw new BeanInitializationException("In addition to a script template view resolver there must also be a single ScriptTemplateConfig bean in this web application context (or its parent): ScriptTemplateConfigurer is the usual implementation. This bean may be given any name.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 240 */     ScriptRegistration registration = new ScriptRegistration();
/* 241 */     this.viewResolvers.add(registration.getViewResolver());
/* 242 */     return registration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void beanName()
/*     */   {
/* 250 */     BeanNameViewResolver resolver = new BeanNameViewResolver();
/* 251 */     this.viewResolvers.add(resolver);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void viewResolver(ViewResolver viewResolver)
/*     */   {
/* 261 */     if ((viewResolver instanceof ContentNegotiatingViewResolver)) {
/* 262 */       throw new BeanInitializationException("addViewResolver cannot be used to configure a ContentNegotiatingViewResolver. Please use the method enableContentNegotiation instead.");
/*     */     }
/*     */     
/*     */ 
/* 266 */     this.viewResolvers.add(viewResolver);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void order(int order)
/*     */   {
/* 282 */     this.order = Integer.valueOf(order);
/*     */   }
/*     */   
/*     */   protected boolean hasBeanOfType(Class<?> beanType) {
/* 286 */     return !ObjectUtils.isEmpty(BeanFactoryUtils.beanNamesForTypeIncludingAncestors(this.applicationContext, beanType, false, false));
/*     */   }
/*     */   
/*     */ 
/*     */   protected int getOrder()
/*     */   {
/* 292 */     return this.order != null ? this.order.intValue() : Integer.MAX_VALUE;
/*     */   }
/*     */   
/*     */   protected List<ViewResolver> getViewResolvers() {
/* 296 */     if (this.contentNegotiatingResolver != null) {
/* 297 */       return Collections.singletonList(this.contentNegotiatingResolver);
/*     */     }
/*     */     
/* 300 */     return this.viewResolvers;
/*     */   }
/*     */   
/*     */   private static class TilesRegistration
/*     */     extends UrlBasedViewResolverRegistration
/*     */   {
/*     */     public TilesRegistration()
/*     */     {
/* 308 */       super();
/*     */     }
/*     */   }
/*     */   
/*     */   private static class VelocityRegistration extends UrlBasedViewResolverRegistration
/*     */   {
/*     */     public VelocityRegistration()
/*     */     {
/* 316 */       super();
/* 317 */       getViewResolver().setSuffix(".vm");
/*     */     }
/*     */   }
/*     */   
/*     */   private static class FreeMarkerRegistration extends UrlBasedViewResolverRegistration
/*     */   {
/*     */     public FreeMarkerRegistration() {
/* 324 */       super();
/* 325 */       getViewResolver().setSuffix(".ftl");
/*     */     }
/*     */   }
/*     */   
/*     */   private static class GroovyMarkupRegistration extends UrlBasedViewResolverRegistration
/*     */   {
/*     */     public GroovyMarkupRegistration() {
/* 332 */       super();
/* 333 */       getViewResolver().setSuffix(".tpl");
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ScriptRegistration extends UrlBasedViewResolverRegistration
/*     */   {
/*     */     public ScriptRegistration() {
/* 340 */       super();
/* 341 */       getViewResolver();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\config\annotation\ViewResolverRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */