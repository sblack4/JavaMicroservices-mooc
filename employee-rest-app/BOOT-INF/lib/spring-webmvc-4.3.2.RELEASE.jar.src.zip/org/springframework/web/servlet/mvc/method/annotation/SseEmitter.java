/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.server.ServerHttpResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SseEmitter
/*     */   extends ResponseBodyEmitter
/*     */ {
/*  39 */   static final MediaType TEXT_PLAIN = new MediaType("text", "plain", Charset.forName("UTF-8"));
/*     */   
/*  41 */   static final MediaType UTF8_TEXT_EVENTSTREAM = new MediaType("text", "event-stream", Charset.forName("UTF-8"));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SseEmitter() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SseEmitter(Long timeout)
/*     */   {
/*  60 */     super(timeout);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void extendResponse(ServerHttpResponse outputMessage)
/*     */   {
/*  66 */     super.extendResponse(outputMessage);
/*     */     
/*  68 */     HttpHeaders headers = outputMessage.getHeaders();
/*  69 */     if (headers.getContentType() == null) {
/*  70 */       headers.setContentType(UTF8_TEXT_EVENTSTREAM);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void send(Object object)
/*     */     throws IOException
/*     */   {
/*  88 */     send(object, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void send(Object object, MediaType mediaType)
/*     */     throws IOException
/*     */   {
/* 105 */     if (object != null) {
/* 106 */       send(event().data(object, mediaType));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void send(SseEventBuilder builder)
/*     */     throws IOException
/*     */   {
/* 122 */     Set<ResponseBodyEmitter.DataWithMediaType> dataToSend = builder.build();
/* 123 */     synchronized (this) {
/* 124 */       for (ResponseBodyEmitter.DataWithMediaType entry : dataToSend) {
/* 125 */         super.send(entry.getData(), entry.getMediaType());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static SseEventBuilder event()
/*     */   {
/* 132 */     return new SseEventBuilderImpl(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class SseEventBuilderImpl
/*     */     implements SseEmitter.SseEventBuilder
/*     */   {
/* 185 */     private final Set<ResponseBodyEmitter.DataWithMediaType> dataToSend = new LinkedHashSet(4);
/*     */     
/*     */     private StringBuilder sb;
/*     */     
/*     */     public SseEmitter.SseEventBuilder comment(String comment)
/*     */     {
/* 191 */       append(":").append(comment != null ? comment : "").append("\n");
/* 192 */       return this;
/*     */     }
/*     */     
/*     */     public SseEmitter.SseEventBuilder name(String name)
/*     */     {
/* 197 */       append("event:").append(name != null ? name : "").append("\n");
/* 198 */       return this;
/*     */     }
/*     */     
/*     */     public SseEmitter.SseEventBuilder id(String id)
/*     */     {
/* 203 */       append("id:").append(id != null ? id : "").append("\n");
/* 204 */       return this;
/*     */     }
/*     */     
/*     */     public SseEmitter.SseEventBuilder reconnectTime(long reconnectTimeMillis)
/*     */     {
/* 209 */       append("retry:").append(String.valueOf(reconnectTimeMillis)).append("\n");
/* 210 */       return this;
/*     */     }
/*     */     
/*     */     public SseEmitter.SseEventBuilder data(Object object)
/*     */     {
/* 215 */       return data(object, null);
/*     */     }
/*     */     
/*     */     public SseEmitter.SseEventBuilder data(Object object, MediaType mediaType)
/*     */     {
/* 220 */       append("data:");
/* 221 */       saveAppendedText();
/* 222 */       this.dataToSend.add(new ResponseBodyEmitter.DataWithMediaType(object, mediaType));
/* 223 */       append("\n");
/* 224 */       return this;
/*     */     }
/*     */     
/*     */     SseEventBuilderImpl append(String text) {
/* 228 */       if (this.sb == null) {
/* 229 */         this.sb = new StringBuilder();
/*     */       }
/* 231 */       this.sb.append(text);
/* 232 */       return this;
/*     */     }
/*     */     
/*     */     public Set<ResponseBodyEmitter.DataWithMediaType> build()
/*     */     {
/* 237 */       if (((this.sb == null) || (this.sb.length() == 0)) && (this.dataToSend.isEmpty())) {
/* 238 */         return Collections.emptySet();
/*     */       }
/* 240 */       append("\n");
/* 241 */       saveAppendedText();
/* 242 */       return this.dataToSend;
/*     */     }
/*     */     
/*     */     private void saveAppendedText() {
/* 246 */       if (this.sb != null) {
/* 247 */         this.dataToSend.add(new ResponseBodyEmitter.DataWithMediaType(this.sb.toString(), SseEmitter.TEXT_PLAIN));
/* 248 */         this.sb = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract interface SseEventBuilder
/*     */   {
/*     */     public abstract SseEventBuilder comment(String paramString);
/*     */     
/*     */     public abstract SseEventBuilder name(String paramString);
/*     */     
/*     */     public abstract SseEventBuilder id(String paramString);
/*     */     
/*     */     public abstract SseEventBuilder reconnectTime(long paramLong);
/*     */     
/*     */     public abstract SseEventBuilder data(Object paramObject);
/*     */     
/*     */     public abstract SseEventBuilder data(Object paramObject, MediaType paramMediaType);
/*     */     
/*     */     public abstract Set<ResponseBodyEmitter.DataWithMediaType> build();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\method\annotation\SseEmitter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */