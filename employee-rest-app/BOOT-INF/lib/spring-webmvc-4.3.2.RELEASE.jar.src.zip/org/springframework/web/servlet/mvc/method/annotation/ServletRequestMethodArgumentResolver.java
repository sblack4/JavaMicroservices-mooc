/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.security.Principal;
/*     */ import java.time.ZoneId;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.UsesJava8;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.multipart.MultipartRequest;
/*     */ import org.springframework.web.servlet.support.RequestContextUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletRequestMethodArgumentResolver
/*     */   implements HandlerMethodArgumentResolver
/*     */ {
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/*  66 */     Class<?> paramType = parameter.getParameterType();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  76 */     return (WebRequest.class.isAssignableFrom(paramType)) || (ServletRequest.class.isAssignableFrom(paramType)) || (MultipartRequest.class.isAssignableFrom(paramType)) || (HttpSession.class.isAssignableFrom(paramType)) || (Principal.class.isAssignableFrom(paramType)) || (Locale.class == paramType) || (TimeZone.class == paramType) || ("java.time.ZoneId".equals(paramType.getName())) || (InputStream.class.isAssignableFrom(paramType)) || (Reader.class.isAssignableFrom(paramType)) || (HttpMethod.class == paramType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*     */     throws Exception
/*     */   {
/*  84 */     Class<?> paramType = parameter.getParameterType();
/*  85 */     if (WebRequest.class.isAssignableFrom(paramType)) {
/*  86 */       return webRequest;
/*     */     }
/*     */     
/*  89 */     HttpServletRequest request = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/*  90 */     if ((ServletRequest.class.isAssignableFrom(paramType)) || (MultipartRequest.class.isAssignableFrom(paramType))) {
/*  91 */       Object nativeRequest = webRequest.getNativeRequest(paramType);
/*  92 */       if (nativeRequest == null)
/*     */       {
/*  94 */         throw new IllegalStateException("Current request is not of type [" + paramType.getName() + "]: " + request);
/*     */       }
/*  96 */       return nativeRequest;
/*     */     }
/*  98 */     if (HttpSession.class.isAssignableFrom(paramType)) {
/*  99 */       return request.getSession();
/*     */     }
/* 101 */     if (HttpMethod.class == paramType) {
/* 102 */       return ((ServletWebRequest)webRequest).getHttpMethod();
/*     */     }
/* 104 */     if (Principal.class.isAssignableFrom(paramType)) {
/* 105 */       return request.getUserPrincipal();
/*     */     }
/* 107 */     if (Locale.class == paramType) {
/* 108 */       return RequestContextUtils.getLocale(request);
/*     */     }
/* 110 */     if (TimeZone.class == paramType) {
/* 111 */       TimeZone timeZone = RequestContextUtils.getTimeZone(request);
/* 112 */       return timeZone != null ? timeZone : TimeZone.getDefault();
/*     */     }
/* 114 */     if ("java.time.ZoneId".equals(paramType.getName())) {
/* 115 */       return ZoneIdResolver.resolveZoneId(request);
/*     */     }
/* 117 */     if (InputStream.class.isAssignableFrom(paramType)) {
/* 118 */       return request.getInputStream();
/*     */     }
/* 120 */     if (Reader.class.isAssignableFrom(paramType)) {
/* 121 */       return request.getReader();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 126 */     throw new UnsupportedOperationException("Unknown parameter type: " + paramType + " in method: " + parameter.getMethod());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @UsesJava8
/*     */   private static class ZoneIdResolver
/*     */   {
/*     */     public static Object resolveZoneId(HttpServletRequest request)
/*     */     {
/* 138 */       TimeZone timeZone = RequestContextUtils.getTimeZone(request);
/* 139 */       return timeZone != null ? timeZone.toZoneId() : ZoneId.systemDefault();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\method\annotation\ServletRequestMethodArgumentResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */