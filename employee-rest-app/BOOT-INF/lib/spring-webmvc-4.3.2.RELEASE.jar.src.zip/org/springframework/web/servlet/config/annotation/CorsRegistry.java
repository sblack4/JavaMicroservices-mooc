/*    */ package org.springframework.web.servlet.config.annotation;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.web.cors.CorsConfiguration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CorsRegistry
/*    */ {
/* 36 */   private final List<CorsRegistration> registrations = new ArrayList();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CorsRegistration addMapping(String pathPattern)
/*    */   {
/* 50 */     CorsRegistration registration = new CorsRegistration(pathPattern);
/* 51 */     this.registrations.add(registration);
/* 52 */     return registration;
/*    */   }
/*    */   
/*    */   protected Map<String, CorsConfiguration> getCorsConfigurations() {
/* 56 */     Map<String, CorsConfiguration> configs = new LinkedHashMap(this.registrations.size());
/* 57 */     for (CorsRegistration registration : this.registrations) {
/* 58 */       configs.put(registration.getPathPattern(), registration.getCorsConfiguration());
/*    */     }
/* 60 */     return configs;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\config\annotation\CorsRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */