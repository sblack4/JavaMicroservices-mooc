/*     */ package org.springframework.web.servlet.view.groovy;
/*     */ 
/*     */ import groovy.lang.Writable;
/*     */ import groovy.text.Template;
/*     */ import groovy.text.markup.MarkupTemplateEngine;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.IOException;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.web.servlet.view.AbstractTemplateView;
/*     */ import org.springframework.web.util.NestedServletException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GroovyMarkupView
/*     */   extends AbstractTemplateView
/*     */ {
/*     */   private MarkupTemplateEngine engine;
/*     */   
/*     */   public void setTemplateEngine(MarkupTemplateEngine engine)
/*     */   {
/*  63 */     this.engine = engine;
/*     */   }
/*     */   
/*     */   public boolean checkResource(Locale locale) throws Exception
/*     */   {
/*     */     try {
/*  69 */       this.engine.resolveTemplate(getUrl());
/*     */     }
/*     */     catch (IOException exception) {
/*  72 */       return false;
/*     */     }
/*  74 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initApplicationContext(ApplicationContext context)
/*     */   {
/*  87 */     super.initApplicationContext();
/*  88 */     if (this.engine == null) {
/*  89 */       setTemplateEngine(autodetectMarkupTemplateEngine());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected MarkupTemplateEngine autodetectMarkupTemplateEngine()
/*     */     throws BeansException
/*     */   {
/*     */     try
/*     */     {
/* 100 */       return ((GroovyMarkupConfig)BeanFactoryUtils.beanOfTypeIncludingAncestors(getApplicationContext(), GroovyMarkupConfig.class, true, false)).getTemplateEngine();
/*     */     }
/*     */     catch (NoSuchBeanDefinitionException ex) {
/* 103 */       throw new ApplicationContextException("Expected a single GroovyMarkupConfig bean in the current Servlet web application context or the parent root context: GroovyMarkupConfigurer is the usual implementation. This bean may have any name.", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void renderMergedTemplateModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 114 */     Template template = getTemplate(getUrl());
/* 115 */     template.make(model).writeTo(new BufferedWriter(response.getWriter()));
/*     */   }
/*     */   
/*     */ 
/*     */   protected Template getTemplate(String viewUrl)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 124 */       return this.engine.createTemplateByPath(viewUrl);
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 127 */       Throwable cause = ex.getCause() != null ? ex.getCause() : ex;
/*     */       
/* 129 */       throw new NestedServletException("Could not find class while rendering Groovy Markup view with name '" + getUrl() + "': " + ex.getMessage() + "'", cause);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\view\groovy\GroovyMarkupView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */