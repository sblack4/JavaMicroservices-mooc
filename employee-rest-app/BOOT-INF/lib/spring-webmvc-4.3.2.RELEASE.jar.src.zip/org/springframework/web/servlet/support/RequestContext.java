/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.jsp.jstl.core.Config;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceResolvable;
/*     */ import org.springframework.context.NoSuchMessageException;
/*     */ import org.springframework.context.i18n.LocaleContext;
/*     */ import org.springframework.context.i18n.SimpleTimeZoneAwareLocaleContext;
/*     */ import org.springframework.context.i18n.TimeZoneAwareLocaleContext;
/*     */ import org.springframework.ui.context.Theme;
/*     */ import org.springframework.ui.context.ThemeSource;
/*     */ import org.springframework.ui.context.support.ResourceBundleThemeSource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.web.bind.EscapedErrors;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.servlet.LocaleContextResolver;
/*     */ import org.springframework.web.servlet.LocaleResolver;
/*     */ import org.springframework.web.servlet.ThemeResolver;
/*     */ import org.springframework.web.util.HtmlUtils;
/*     */ import org.springframework.web.util.UriTemplate;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RequestContext
/*     */ {
/*     */   public static final String DEFAULT_THEME_NAME = "theme";
/*  91 */   public static final String WEB_APPLICATION_CONTEXT_ATTRIBUTE = RequestContext.class.getName() + ".CONTEXT";
/*     */   
/*     */ 
/*  94 */   protected static final boolean jstlPresent = ClassUtils.isPresent("javax.servlet.jsp.jstl.core.Config", RequestContext.class
/*  95 */     .getClassLoader());
/*     */   
/*     */ 
/*     */   private HttpServletRequest request;
/*     */   
/*     */ 
/*     */   private HttpServletResponse response;
/*     */   
/*     */ 
/*     */   private Map<String, Object> model;
/*     */   
/*     */ 
/*     */   private WebApplicationContext webApplicationContext;
/*     */   
/*     */ 
/*     */   private Locale locale;
/*     */   
/*     */ 
/*     */   private TimeZone timeZone;
/*     */   
/*     */ 
/*     */   private Theme theme;
/*     */   
/*     */ 
/*     */   private Boolean defaultHtmlEscape;
/*     */   
/*     */ 
/*     */   private Boolean responseEncodedHtmlEscape;
/*     */   
/*     */   private UrlPathHelper urlPathHelper;
/*     */   
/*     */   private RequestDataValueProcessor requestDataValueProcessor;
/*     */   
/*     */   private Map<String, Errors> errorsMap;
/*     */   
/*     */ 
/*     */   public RequestContext(HttpServletRequest request)
/*     */   {
/* 133 */     initContext(request, null, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RequestContext(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 148 */     initContext(request, response, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RequestContext(HttpServletRequest request, ServletContext servletContext)
/*     */   {
/* 164 */     initContext(request, null, servletContext, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RequestContext(HttpServletRequest request, Map<String, Object> model)
/*     */   {
/* 179 */     initContext(request, null, null, model);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RequestContext(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext, Map<String, Object> model)
/*     */   {
/* 199 */     initContext(request, response, servletContext, model);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected RequestContext() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initContext(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext, Map<String, Object> model)
/*     */   {
/* 226 */     this.request = request;
/* 227 */     this.response = response;
/* 228 */     this.model = model;
/*     */     
/*     */ 
/*     */ 
/* 232 */     this.webApplicationContext = ((WebApplicationContext)request.getAttribute(WEB_APPLICATION_CONTEXT_ATTRIBUTE));
/* 233 */     if (this.webApplicationContext == null) {
/* 234 */       this.webApplicationContext = RequestContextUtils.findWebApplicationContext(request, servletContext);
/* 235 */       if (this.webApplicationContext == null) {
/* 236 */         throw new IllegalStateException("No WebApplicationContext found: not in a DispatcherServlet request and no ContextLoaderListener registered?");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 242 */     LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver(request);
/* 243 */     if ((localeResolver instanceof LocaleContextResolver)) {
/* 244 */       LocaleContext localeContext = ((LocaleContextResolver)localeResolver).resolveLocaleContext(request);
/* 245 */       this.locale = localeContext.getLocale();
/* 246 */       if ((localeContext instanceof TimeZoneAwareLocaleContext)) {
/* 247 */         this.timeZone = ((TimeZoneAwareLocaleContext)localeContext).getTimeZone();
/*     */       }
/*     */     }
/* 250 */     else if (localeResolver != null)
/*     */     {
/* 252 */       this.locale = localeResolver.resolveLocale(request);
/*     */     }
/*     */     
/*     */ 
/* 256 */     if (this.locale == null) {
/* 257 */       this.locale = getFallbackLocale();
/*     */     }
/* 259 */     if (this.timeZone == null) {
/* 260 */       this.timeZone = getFallbackTimeZone();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 265 */     this.defaultHtmlEscape = WebUtils.getDefaultHtmlEscape(this.webApplicationContext.getServletContext());
/*     */     
/*     */ 
/*     */ 
/* 269 */     this.responseEncodedHtmlEscape = WebUtils.getResponseEncodedHtmlEscape(this.webApplicationContext.getServletContext());
/*     */     
/* 271 */     this.urlPathHelper = new UrlPathHelper();
/*     */     
/* 273 */     if (this.webApplicationContext.containsBean("requestDataValueProcessor")) {
/* 274 */       this.requestDataValueProcessor = ((RequestDataValueProcessor)this.webApplicationContext.getBean("requestDataValueProcessor", RequestDataValueProcessor.class));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Locale getFallbackLocale()
/*     */   {
/* 287 */     if (jstlPresent) {
/* 288 */       Locale locale = JstlLocaleResolver.getJstlLocale(getRequest(), getServletContext());
/* 289 */       if (locale != null) {
/* 290 */         return locale;
/*     */       }
/*     */     }
/* 293 */     return getRequest().getLocale();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TimeZone getFallbackTimeZone()
/*     */   {
/* 303 */     if (jstlPresent) {
/* 304 */       TimeZone timeZone = JstlLocaleResolver.getJstlTimeZone(getRequest(), getServletContext());
/* 305 */       if (timeZone != null) {
/* 306 */         return timeZone;
/*     */       }
/*     */     }
/* 309 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Theme getFallbackTheme()
/*     */   {
/* 318 */     ThemeSource themeSource = RequestContextUtils.getThemeSource(getRequest());
/* 319 */     if (themeSource == null) {
/* 320 */       themeSource = new ResourceBundleThemeSource();
/*     */     }
/* 322 */     Theme theme = themeSource.getTheme("theme");
/* 323 */     if (theme == null) {
/* 324 */       throw new IllegalStateException("No theme defined and no fallback theme found");
/*     */     }
/* 326 */     return theme;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final HttpServletRequest getRequest()
/*     */   {
/* 334 */     return this.request;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected final ServletContext getServletContext()
/*     */   {
/* 341 */     return this.webApplicationContext.getServletContext();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final WebApplicationContext getWebApplicationContext()
/*     */   {
/* 348 */     return this.webApplicationContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final MessageSource getMessageSource()
/*     */   {
/* 355 */     return this.webApplicationContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Map<String, Object> getModel()
/*     */   {
/* 363 */     return this.model;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Locale getLocale()
/*     */   {
/* 373 */     return this.locale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TimeZone getTimeZone()
/*     */   {
/* 383 */     return this.timeZone;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void changeLocale(Locale locale)
/*     */   {
/* 394 */     LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver(this.request);
/* 395 */     if (localeResolver == null) {
/* 396 */       throw new IllegalStateException("Cannot change locale if no LocaleResolver configured");
/*     */     }
/* 398 */     localeResolver.setLocale(this.request, this.response, locale);
/* 399 */     this.locale = locale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void changeLocale(Locale locale, TimeZone timeZone)
/*     */   {
/* 411 */     LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver(this.request);
/* 412 */     if (!(localeResolver instanceof LocaleContextResolver)) {
/* 413 */       throw new IllegalStateException("Cannot change locale context if no LocaleContextResolver configured");
/*     */     }
/* 415 */     ((LocaleContextResolver)localeResolver).setLocaleContext(this.request, this.response, new SimpleTimeZoneAwareLocaleContext(locale, timeZone));
/*     */     
/* 417 */     this.locale = locale;
/* 418 */     this.timeZone = timeZone;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Theme getTheme()
/*     */   {
/* 426 */     if (this.theme == null)
/*     */     {
/* 428 */       this.theme = RequestContextUtils.getTheme(this.request);
/* 429 */       if (this.theme == null)
/*     */       {
/* 431 */         this.theme = getFallbackTheme();
/*     */       }
/*     */     }
/* 434 */     return this.theme;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void changeTheme(Theme theme)
/*     */   {
/* 444 */     ThemeResolver themeResolver = RequestContextUtils.getThemeResolver(this.request);
/* 445 */     if (themeResolver == null) {
/* 446 */       throw new IllegalStateException("Cannot change theme if no ThemeResolver configured");
/*     */     }
/* 448 */     themeResolver.setThemeName(this.request, this.response, theme != null ? theme.getName() : null);
/* 449 */     this.theme = theme;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void changeTheme(String themeName)
/*     */   {
/* 459 */     ThemeResolver themeResolver = RequestContextUtils.getThemeResolver(this.request);
/* 460 */     if (themeResolver == null) {
/* 461 */       throw new IllegalStateException("Cannot change theme if no ThemeResolver configured");
/*     */     }
/* 463 */     themeResolver.setThemeName(this.request, this.response, themeName);
/*     */     
/* 465 */     this.theme = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultHtmlEscape(boolean defaultHtmlEscape)
/*     */   {
/* 474 */     this.defaultHtmlEscape = Boolean.valueOf(defaultHtmlEscape);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isDefaultHtmlEscape()
/*     */   {
/* 481 */     return (this.defaultHtmlEscape != null) && (this.defaultHtmlEscape.booleanValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean getDefaultHtmlEscape()
/*     */   {
/* 489 */     return this.defaultHtmlEscape;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isResponseEncodedHtmlEscape()
/*     */   {
/* 499 */     return (this.responseEncodedHtmlEscape == null) || (this.responseEncodedHtmlEscape.booleanValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean getResponseEncodedHtmlEscape()
/*     */   {
/* 509 */     return this.responseEncodedHtmlEscape;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUrlPathHelper(UrlPathHelper urlPathHelper)
/*     */   {
/* 519 */     Assert.notNull(urlPathHelper, "UrlPathHelper must not be null");
/* 520 */     this.urlPathHelper = urlPathHelper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UrlPathHelper getUrlPathHelper()
/*     */   {
/* 529 */     return this.urlPathHelper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RequestDataValueProcessor getRequestDataValueProcessor()
/*     */   {
/* 538 */     return this.requestDataValueProcessor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContextPath()
/*     */   {
/* 550 */     return this.urlPathHelper.getOriginatingContextPath(this.request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContextUrl(String relativeUrl)
/*     */   {
/* 559 */     String url = getContextPath() + relativeUrl;
/* 560 */     if (this.response != null) {
/* 561 */       url = this.response.encodeURL(url);
/*     */     }
/* 563 */     return url;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContextUrl(String relativeUrl, Map<String, ?> params)
/*     */   {
/* 575 */     String url = getContextPath() + relativeUrl;
/* 576 */     UriTemplate template = new UriTemplate(url);
/* 577 */     url = template.expand(params).toASCIIString();
/* 578 */     if (this.response != null) {
/* 579 */       url = this.response.encodeURL(url);
/*     */     }
/* 581 */     return url;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPathToServlet()
/*     */   {
/* 592 */     String path = this.urlPathHelper.getOriginatingContextPath(this.request);
/* 593 */     if (StringUtils.hasText(this.urlPathHelper.getPathWithinServletMapping(this.request))) {
/* 594 */       path = path + this.urlPathHelper.getOriginatingServletPath(this.request);
/*     */     }
/* 596 */     return path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRequestUri()
/*     */   {
/* 609 */     return this.urlPathHelper.getOriginatingRequestUri(this.request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getQueryString()
/*     */   {
/* 622 */     return this.urlPathHelper.getOriginatingQueryString(this.request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(String code, String defaultMessage)
/*     */   {
/* 632 */     return getMessage(code, null, defaultMessage, isDefaultHtmlEscape());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(String code, Object[] args, String defaultMessage)
/*     */   {
/* 643 */     return getMessage(code, args, defaultMessage, isDefaultHtmlEscape());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(String code, List<?> args, String defaultMessage)
/*     */   {
/* 654 */     return getMessage(code, args != null ? args.toArray() : null, defaultMessage, isDefaultHtmlEscape());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(String code, Object[] args, String defaultMessage, boolean htmlEscape)
/*     */   {
/* 666 */     String msg = this.webApplicationContext.getMessage(code, args, defaultMessage, this.locale);
/* 667 */     return htmlEscape ? HtmlUtils.htmlEscape(msg) : msg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(String code)
/*     */     throws NoSuchMessageException
/*     */   {
/* 677 */     return getMessage(code, null, isDefaultHtmlEscape());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(String code, Object[] args)
/*     */     throws NoSuchMessageException
/*     */   {
/* 688 */     return getMessage(code, args, isDefaultHtmlEscape());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(String code, List<?> args)
/*     */     throws NoSuchMessageException
/*     */   {
/* 699 */     return getMessage(code, args != null ? args.toArray() : null, isDefaultHtmlEscape());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(String code, Object[] args, boolean htmlEscape)
/*     */     throws NoSuchMessageException
/*     */   {
/* 711 */     String msg = this.webApplicationContext.getMessage(code, args, this.locale);
/* 712 */     return htmlEscape ? HtmlUtils.htmlEscape(msg) : msg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(MessageSourceResolvable resolvable)
/*     */     throws NoSuchMessageException
/*     */   {
/* 722 */     return getMessage(resolvable, isDefaultHtmlEscape());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(MessageSourceResolvable resolvable, boolean htmlEscape)
/*     */     throws NoSuchMessageException
/*     */   {
/* 733 */     String msg = this.webApplicationContext.getMessage(resolvable, this.locale);
/* 734 */     return htmlEscape ? HtmlUtils.htmlEscape(msg) : msg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getThemeMessage(String code, String defaultMessage)
/*     */   {
/* 746 */     return getTheme().getMessageSource().getMessage(code, null, defaultMessage, this.locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getThemeMessage(String code, Object[] args, String defaultMessage)
/*     */   {
/* 759 */     return getTheme().getMessageSource().getMessage(code, args, defaultMessage, this.locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getThemeMessage(String code, List<?> args, String defaultMessage)
/*     */   {
/* 772 */     return getTheme().getMessageSource().getMessage(code, args != null ? args.toArray() : null, defaultMessage, this.locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getThemeMessage(String code)
/*     */     throws NoSuchMessageException
/*     */   {
/* 785 */     return getTheme().getMessageSource().getMessage(code, null, this.locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getThemeMessage(String code, Object[] args)
/*     */     throws NoSuchMessageException
/*     */   {
/* 798 */     return getTheme().getMessageSource().getMessage(code, args, this.locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getThemeMessage(String code, List<?> args)
/*     */     throws NoSuchMessageException
/*     */   {
/* 811 */     return getTheme().getMessageSource().getMessage(code, args != null ? args.toArray() : null, this.locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getThemeMessage(MessageSourceResolvable resolvable)
/*     */     throws NoSuchMessageException
/*     */   {
/* 823 */     return getTheme().getMessageSource().getMessage(resolvable, this.locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Errors getErrors(String name)
/*     */   {
/* 832 */     return getErrors(name, isDefaultHtmlEscape());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Errors getErrors(String name, boolean htmlEscape)
/*     */   {
/* 842 */     if (this.errorsMap == null) {
/* 843 */       this.errorsMap = new HashMap();
/*     */     }
/* 845 */     Errors errors = (Errors)this.errorsMap.get(name);
/* 846 */     boolean put = false;
/* 847 */     if (errors == null) {
/* 848 */       errors = (Errors)getModelObject(BindingResult.MODEL_KEY_PREFIX + name);
/*     */       
/* 850 */       if ((errors instanceof BindException)) {
/* 851 */         errors = ((BindException)errors).getBindingResult();
/*     */       }
/* 853 */       if (errors == null) {
/* 854 */         return null;
/*     */       }
/* 856 */       put = true;
/*     */     }
/* 858 */     if ((htmlEscape) && (!(errors instanceof EscapedErrors))) {
/* 859 */       errors = new EscapedErrors(errors);
/* 860 */       put = true;
/*     */     }
/* 862 */     else if ((!htmlEscape) && ((errors instanceof EscapedErrors))) {
/* 863 */       errors = ((EscapedErrors)errors).getSource();
/* 864 */       put = true;
/*     */     }
/* 866 */     if (put) {
/* 867 */       this.errorsMap.put(name, errors);
/*     */     }
/* 869 */     return errors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object getModelObject(String modelName)
/*     */   {
/* 878 */     if (this.model != null) {
/* 879 */       return this.model.get(modelName);
/*     */     }
/*     */     
/* 882 */     return this.request.getAttribute(modelName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BindStatus getBindStatus(String path)
/*     */     throws IllegalStateException
/*     */   {
/* 893 */     return new BindStatus(this, path, isDefaultHtmlEscape());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BindStatus getBindStatus(String path, boolean htmlEscape)
/*     */     throws IllegalStateException
/*     */   {
/* 904 */     return new BindStatus(this, path, htmlEscape);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class JstlLocaleResolver
/*     */   {
/*     */     public static Locale getJstlLocale(HttpServletRequest request, ServletContext servletContext)
/*     */     {
/* 915 */       Object localeObject = Config.get(request, "javax.servlet.jsp.jstl.fmt.locale");
/* 916 */       if (localeObject == null) {
/* 917 */         HttpSession session = request.getSession(false);
/* 918 */         if (session != null) {
/* 919 */           localeObject = Config.get(session, "javax.servlet.jsp.jstl.fmt.locale");
/*     */         }
/* 921 */         if ((localeObject == null) && (servletContext != null)) {
/* 922 */           localeObject = Config.get(servletContext, "javax.servlet.jsp.jstl.fmt.locale");
/*     */         }
/*     */       }
/* 925 */       return (localeObject instanceof Locale) ? (Locale)localeObject : null;
/*     */     }
/*     */     
/*     */     public static TimeZone getJstlTimeZone(HttpServletRequest request, ServletContext servletContext) {
/* 929 */       Object timeZoneObject = Config.get(request, "javax.servlet.jsp.jstl.fmt.timeZone");
/* 930 */       if (timeZoneObject == null) {
/* 931 */         HttpSession session = request.getSession(false);
/* 932 */         if (session != null) {
/* 933 */           timeZoneObject = Config.get(session, "javax.servlet.jsp.jstl.fmt.timeZone");
/*     */         }
/* 935 */         if ((timeZoneObject == null) && (servletContext != null)) {
/* 936 */           timeZoneObject = Config.get(servletContext, "javax.servlet.jsp.jstl.fmt.timeZone");
/*     */         }
/*     */       }
/* 939 */       return (timeZoneObject instanceof TimeZone) ? (TimeZone)timeZoneObject : null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\support\RequestContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */