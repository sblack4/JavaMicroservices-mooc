/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PathMatchConfigurer
/*     */ {
/*     */   private Boolean suffixPatternMatch;
/*     */   private Boolean trailingSlashMatch;
/*     */   private Boolean registeredSuffixPatternMatch;
/*     */   private UrlPathHelper urlPathHelper;
/*     */   private PathMatcher pathMatcher;
/*     */   
/*     */   public PathMatchConfigurer setUseSuffixPatternMatch(Boolean suffixPatternMatch)
/*     */   {
/*  58 */     this.suffixPatternMatch = suffixPatternMatch;
/*  59 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PathMatchConfigurer setUseTrailingSlashMatch(Boolean trailingSlashMatch)
/*     */   {
/*  68 */     this.trailingSlashMatch = trailingSlashMatch;
/*  69 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PathMatchConfigurer setUseRegisteredSuffixPatternMatch(Boolean registeredSuffixPatternMatch)
/*     */   {
/*  84 */     this.registeredSuffixPatternMatch = registeredSuffixPatternMatch;
/*  85 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PathMatchConfigurer setUrlPathHelper(UrlPathHelper urlPathHelper)
/*     */   {
/*  95 */     this.urlPathHelper = urlPathHelper;
/*  96 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PathMatchConfigurer setPathMatcher(PathMatcher pathMatcher)
/*     */   {
/* 105 */     this.pathMatcher = pathMatcher;
/* 106 */     return this;
/*     */   }
/*     */   
/*     */   public Boolean isUseSuffixPatternMatch() {
/* 110 */     return this.suffixPatternMatch;
/*     */   }
/*     */   
/*     */   public Boolean isUseTrailingSlashMatch() {
/* 114 */     return this.trailingSlashMatch;
/*     */   }
/*     */   
/*     */   public Boolean isUseRegisteredSuffixPatternMatch() {
/* 118 */     return this.registeredSuffixPatternMatch;
/*     */   }
/*     */   
/*     */   public UrlPathHelper getUrlPathHelper() {
/* 122 */     return this.urlPathHelper;
/*     */   }
/*     */   
/*     */   public PathMatcher getPathMatcher() {
/* 126 */     return this.pathMatcher;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\config\annotation\PathMatchConfigurer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */