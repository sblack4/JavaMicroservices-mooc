/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.CompletionStage;
/*     */ import java.util.function.BiFunction;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.lang.UsesJava8;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.concurrent.ListenableFuture;
/*     */ import org.springframework.util.concurrent.ListenableFutureCallback;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.async.DeferredResult;
/*     */ import org.springframework.web.context.request.async.WebAsyncManager;
/*     */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*     */ import org.springframework.web.method.support.AsyncHandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeferredResultMethodReturnValueHandler
/*     */   implements AsyncHandlerMethodReturnValueHandler
/*     */ {
/*     */   private final Map<Class<?>, DeferredResultAdapter> adapterMap;
/*     */   
/*     */   public DeferredResultMethodReturnValueHandler()
/*     */   {
/*  50 */     this.adapterMap = new HashMap(5);
/*  51 */     this.adapterMap.put(DeferredResult.class, new SimpleDeferredResultAdapter(null));
/*  52 */     this.adapterMap.put(ListenableFuture.class, new ListenableFutureAdapter(null));
/*  53 */     if (ClassUtils.isPresent("java.util.concurrent.CompletionStage", getClass().getClassLoader())) {
/*  54 */       this.adapterMap.put(CompletionStage.class, new CompletionStageAdapter(null));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<Class<?>, DeferredResultAdapter> getAdapterMap()
/*     */   {
/*  66 */     return this.adapterMap;
/*     */   }
/*     */   
/*     */   private DeferredResultAdapter getAdapterFor(Class<?> type) {
/*  70 */     for (Class<?> adapteeType : getAdapterMap().keySet()) {
/*  71 */       if (adapteeType.isAssignableFrom(type)) {
/*  72 */         return (DeferredResultAdapter)getAdapterMap().get(adapteeType);
/*     */       }
/*     */     }
/*  75 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean supportsReturnType(MethodParameter returnType)
/*     */   {
/*  81 */     return getAdapterFor(returnType.getParameterType()) != null;
/*     */   }
/*     */   
/*     */   public boolean isAsyncReturnValue(Object returnValue, MethodParameter returnType)
/*     */   {
/*  86 */     return (returnValue != null) && (getAdapterFor(returnValue.getClass()) != null);
/*     */   }
/*     */   
/*     */ 
/*     */   public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/*  93 */     if (returnValue == null) {
/*  94 */       mavContainer.setRequestHandled(true);
/*  95 */       return;
/*     */     }
/*     */     
/*  98 */     DeferredResultAdapter adapter = getAdapterFor(returnValue.getClass());
/*  99 */     Assert.notNull(adapter);
/* 100 */     DeferredResult<?> result = adapter.adaptToDeferredResult(returnValue);
/* 101 */     WebAsyncUtils.getAsyncManager(webRequest).startDeferredResultProcessing(result, new Object[] { mavContainer });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class SimpleDeferredResultAdapter
/*     */     implements DeferredResultAdapter
/*     */   {
/*     */     public DeferredResult<?> adaptToDeferredResult(Object returnValue)
/*     */     {
/* 112 */       Assert.isInstanceOf(DeferredResult.class, returnValue);
/* 113 */       return (DeferredResult)returnValue;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class ListenableFutureAdapter
/*     */     implements DeferredResultAdapter
/*     */   {
/*     */     public DeferredResult<?> adaptToDeferredResult(Object returnValue)
/*     */     {
/* 125 */       Assert.isInstanceOf(ListenableFuture.class, returnValue);
/* 126 */       final DeferredResult<Object> result = new DeferredResult();
/* 127 */       ((ListenableFuture)returnValue).addCallback(new ListenableFutureCallback()
/*     */       {
/*     */         public void onSuccess(Object value) {
/* 130 */           result.setResult(value);
/*     */         }
/*     */         
/*     */         public void onFailure(Throwable ex) {
/* 134 */           result.setErrorResult(ex);
/*     */         }
/* 136 */       });
/* 137 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @UsesJava8
/*     */   private static class CompletionStageAdapter
/*     */     implements DeferredResultAdapter
/*     */   {
/*     */     public DeferredResult<?> adaptToDeferredResult(Object returnValue)
/*     */     {
/* 150 */       Assert.isInstanceOf(CompletionStage.class, returnValue);
/* 151 */       final DeferredResult<Object> result = new DeferredResult();
/*     */       
/* 153 */       CompletionStage<?> future = (CompletionStage)returnValue;
/* 154 */       future.handle(new BiFunction()
/*     */       {
/*     */         public Object apply(Object value, Throwable ex) {
/* 157 */           if (ex != null) {
/* 158 */             result.setErrorResult(ex);
/*     */           }
/*     */           else {
/* 161 */             result.setResult(value);
/*     */           }
/* 163 */           return null;
/*     */         }
/* 165 */       });
/* 166 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\method\annotation\DeferredResultMethodReturnValueHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */