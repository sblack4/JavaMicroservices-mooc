/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.BeanInitializationException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.format.support.DefaultFormattingConversionService;
/*     */ import org.springframework.format.support.FormattingConversionService;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.ByteArrayHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.ResourceHttpMessageConverter;
/*     */ import org.springframework.http.converter.StringHttpMessageConverter;
/*     */ import org.springframework.http.converter.feed.AtomFeedHttpMessageConverter;
/*     */ import org.springframework.http.converter.feed.RssChannelHttpMessageConverter;
/*     */ import org.springframework.http.converter.json.GsonHttpMessageConverter;
/*     */ import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
/*     */ import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
/*     */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.MappingJackson2XmlHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.SourceHttpMessageConverter;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.validation.MessageCodesResolver;
/*     */ import org.springframework.validation.Validator;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.bind.support.ConfigurableWebBindingInitializer;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ import org.springframework.web.cors.CorsConfiguration;
/*     */ import org.springframework.web.method.support.CompositeUriComponentsContributor;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.servlet.HandlerExceptionResolver;
/*     */ import org.springframework.web.servlet.HandlerInterceptor;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.servlet.ViewResolver;
/*     */ import org.springframework.web.servlet.handler.AbstractHandlerMapping;
/*     */ import org.springframework.web.servlet.handler.BeanNameUrlHandlerMapping;
/*     */ import org.springframework.web.servlet.handler.ConversionServiceExposingInterceptor;
/*     */ import org.springframework.web.servlet.handler.HandlerExceptionResolverComposite;
/*     */ import org.springframework.web.servlet.mvc.HttpRequestHandlerAdapter;
/*     */ import org.springframework.web.servlet.mvc.SimpleControllerHandlerAdapter;
/*     */ import org.springframework.web.servlet.mvc.annotation.ResponseStatusExceptionResolver;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.ExceptionHandlerExceptionResolver;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.JsonViewRequestBodyAdvice;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.JsonViewResponseBodyAdvice;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.RequestBodyAdvice;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;
/*     */ import org.springframework.web.servlet.mvc.support.DefaultHandlerExceptionResolver;
/*     */ import org.springframework.web.servlet.resource.ResourceUrlProvider;
/*     */ import org.springframework.web.servlet.resource.ResourceUrlProviderExposingInterceptor;
/*     */ import org.springframework.web.servlet.view.InternalResourceViewResolver;
/*     */ import org.springframework.web.servlet.view.ViewResolverComposite;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebMvcConfigurationSupport
/*     */   implements ApplicationContextAware, ServletContextAware
/*     */ {
/* 176 */   private static boolean romePresent = ClassUtils.isPresent("com.rometools.rome.feed.WireFeed", WebMvcConfigurationSupport.class.getClassLoader());
/*     */   
/*     */ 
/* 179 */   private static final boolean jaxb2Present = ClassUtils.isPresent("javax.xml.bind.Binder", WebMvcConfigurationSupport.class.getClassLoader());
/*     */   
/*     */ 
/* 182 */   private static final boolean jackson2Present = (ClassUtils.isPresent("com.fasterxml.jackson.databind.ObjectMapper", WebMvcConfigurationSupport.class.getClassLoader())) && 
/* 183 */     (ClassUtils.isPresent("com.fasterxml.jackson.core.JsonGenerator", WebMvcConfigurationSupport.class.getClassLoader()));
/*     */   
/*     */ 
/* 186 */   private static final boolean jackson2XmlPresent = ClassUtils.isPresent("com.fasterxml.jackson.dataformat.xml.XmlMapper", WebMvcConfigurationSupport.class.getClassLoader());
/*     */   
/*     */ 
/* 189 */   private static final boolean gsonPresent = ClassUtils.isPresent("com.google.gson.Gson", WebMvcConfigurationSupport.class.getClassLoader());
/*     */   
/*     */ 
/*     */   private ApplicationContext applicationContext;
/*     */   
/*     */ 
/*     */   private ServletContext servletContext;
/*     */   
/*     */ 
/*     */   private List<Object> interceptors;
/*     */   
/*     */ 
/*     */   private PathMatchConfigurer pathMatchConfigurer;
/*     */   
/*     */   private ContentNegotiationManager contentNegotiationManager;
/*     */   
/*     */   private List<HandlerMethodArgumentResolver> argumentResolvers;
/*     */   
/*     */   private List<HandlerMethodReturnValueHandler> returnValueHandlers;
/*     */   
/*     */   private List<HttpMessageConverter<?>> messageConverters;
/*     */   
/*     */   private Map<String, CorsConfiguration> corsConfigurations;
/*     */   
/*     */ 
/*     */   public void setApplicationContext(ApplicationContext applicationContext)
/*     */   {
/* 216 */     this.applicationContext = applicationContext;
/*     */   }
/*     */   
/*     */   public ApplicationContext getApplicationContext() {
/* 220 */     return this.applicationContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setServletContext(ServletContext servletContext)
/*     */   {
/* 229 */     this.servletContext = servletContext;
/*     */   }
/*     */   
/*     */   public ServletContext getServletContext() {
/* 233 */     return this.servletContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Bean
/*     */   public RequestMappingHandlerMapping requestMappingHandlerMapping()
/*     */   {
/* 242 */     RequestMappingHandlerMapping handlerMapping = createRequestMappingHandlerMapping();
/* 243 */     handlerMapping.setOrder(0);
/* 244 */     handlerMapping.setInterceptors(getInterceptors());
/* 245 */     handlerMapping.setContentNegotiationManager(mvcContentNegotiationManager());
/* 246 */     handlerMapping.setCorsConfigurations(getCorsConfigurations());
/*     */     
/* 248 */     PathMatchConfigurer configurer = getPathMatchConfigurer();
/* 249 */     if (configurer.isUseSuffixPatternMatch() != null) {
/* 250 */       handlerMapping.setUseSuffixPatternMatch(configurer.isUseSuffixPatternMatch().booleanValue());
/*     */     }
/* 252 */     if (configurer.isUseRegisteredSuffixPatternMatch() != null) {
/* 253 */       handlerMapping.setUseRegisteredSuffixPatternMatch(configurer.isUseRegisteredSuffixPatternMatch().booleanValue());
/*     */     }
/* 255 */     if (configurer.isUseTrailingSlashMatch() != null) {
/* 256 */       handlerMapping.setUseTrailingSlashMatch(configurer.isUseTrailingSlashMatch().booleanValue());
/*     */     }
/* 258 */     if (configurer.getPathMatcher() != null) {
/* 259 */       handlerMapping.setPathMatcher(configurer.getPathMatcher());
/*     */     }
/* 261 */     if (configurer.getUrlPathHelper() != null) {
/* 262 */       handlerMapping.setUrlPathHelper(configurer.getUrlPathHelper());
/*     */     }
/*     */     
/* 265 */     return handlerMapping;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected RequestMappingHandlerMapping createRequestMappingHandlerMapping()
/*     */   {
/* 273 */     return new RequestMappingHandlerMapping();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final Object[] getInterceptors()
/*     */   {
/* 282 */     if (this.interceptors == null) {
/* 283 */       InterceptorRegistry registry = new InterceptorRegistry();
/* 284 */       addInterceptors(registry);
/* 285 */       registry.addInterceptor(new ConversionServiceExposingInterceptor(mvcConversionService()));
/* 286 */       registry.addInterceptor(new ResourceUrlProviderExposingInterceptor(mvcResourceUrlProvider()));
/* 287 */       this.interceptors = registry.getInterceptors();
/*     */     }
/* 289 */     return this.interceptors.toArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addInterceptors(InterceptorRegistry registry) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PathMatchConfigurer getPathMatchConfigurer()
/*     */   {
/* 306 */     if (this.pathMatchConfigurer == null) {
/* 307 */       this.pathMatchConfigurer = new PathMatchConfigurer();
/* 308 */       configurePathMatch(this.pathMatchConfigurer);
/*     */     }
/* 310 */     return this.pathMatchConfigurer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void configurePathMatch(PathMatchConfigurer configurer) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Bean
/*     */   public ContentNegotiationManager mvcContentNegotiationManager()
/*     */   {
/* 327 */     if (this.contentNegotiationManager == null) {
/* 328 */       ContentNegotiationConfigurer configurer = new ContentNegotiationConfigurer(this.servletContext);
/* 329 */       configurer.mediaTypes(getDefaultMediaTypes());
/* 330 */       configureContentNegotiation(configurer);
/*     */       try {
/* 332 */         this.contentNegotiationManager = configurer.getContentNegotiationManager();
/*     */       }
/*     */       catch (Exception ex) {
/* 335 */         throw new BeanInitializationException("Could not create ContentNegotiationManager", ex);
/*     */       }
/*     */     }
/* 338 */     return this.contentNegotiationManager;
/*     */   }
/*     */   
/*     */   protected Map<String, MediaType> getDefaultMediaTypes() {
/* 342 */     Map<String, MediaType> map = new HashMap();
/* 343 */     if (romePresent) {
/* 344 */       map.put("atom", MediaType.APPLICATION_ATOM_XML);
/* 345 */       map.put("rss", MediaType.valueOf("application/rss+xml"));
/*     */     }
/* 347 */     if ((jaxb2Present) || (jackson2XmlPresent)) {
/* 348 */       map.put("xml", MediaType.APPLICATION_XML);
/*     */     }
/* 350 */     if ((jackson2Present) || (gsonPresent)) {
/* 351 */       map.put("json", MediaType.APPLICATION_JSON);
/*     */     }
/* 353 */     return map;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void configureContentNegotiation(ContentNegotiationConfigurer configurer) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Bean
/*     */   public HandlerMapping viewControllerHandlerMapping()
/*     */   {
/* 370 */     ViewControllerRegistry registry = new ViewControllerRegistry();
/* 371 */     registry.setApplicationContext(this.applicationContext);
/* 372 */     addViewControllers(registry);
/*     */     
/* 374 */     AbstractHandlerMapping handlerMapping = registry.getHandlerMapping();
/* 375 */     handlerMapping = handlerMapping != null ? handlerMapping : new EmptyHandlerMapping(null);
/* 376 */     handlerMapping.setPathMatcher(mvcPathMatcher());
/* 377 */     handlerMapping.setUrlPathHelper(mvcUrlPathHelper());
/* 378 */     handlerMapping.setInterceptors(getInterceptors());
/* 379 */     handlerMapping.setCorsConfigurations(getCorsConfigurations());
/* 380 */     return handlerMapping;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addViewControllers(ViewControllerRegistry registry) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Bean
/*     */   public BeanNameUrlHandlerMapping beanNameHandlerMapping()
/*     */   {
/* 396 */     BeanNameUrlHandlerMapping mapping = new BeanNameUrlHandlerMapping();
/* 397 */     mapping.setOrder(2);
/* 398 */     mapping.setInterceptors(getInterceptors());
/* 399 */     mapping.setCorsConfigurations(getCorsConfigurations());
/* 400 */     return mapping;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Bean
/*     */   public HandlerMapping resourceHandlerMapping()
/*     */   {
/* 411 */     ResourceHandlerRegistry registry = new ResourceHandlerRegistry(this.applicationContext, this.servletContext, mvcContentNegotiationManager());
/* 412 */     addResourceHandlers(registry);
/*     */     
/* 414 */     AbstractHandlerMapping handlerMapping = registry.getHandlerMapping();
/* 415 */     if (handlerMapping != null) {
/* 416 */       handlerMapping.setPathMatcher(mvcPathMatcher());
/* 417 */       handlerMapping.setUrlPathHelper(mvcUrlPathHelper());
/* 418 */       handlerMapping.setInterceptors(new HandlerInterceptor[] { new ResourceUrlProviderExposingInterceptor(
/* 419 */         mvcResourceUrlProvider()) });
/* 420 */       handlerMapping.setCorsConfigurations(getCorsConfigurations());
/*     */     }
/*     */     else {
/* 423 */       handlerMapping = new EmptyHandlerMapping(null);
/*     */     }
/* 425 */     return handlerMapping;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void addResourceHandlers(ResourceHandlerRegistry registry) {}
/*     */   
/*     */ 
/*     */ 
/*     */   @Bean
/*     */   public ResourceUrlProvider mvcResourceUrlProvider()
/*     */   {
/* 437 */     ResourceUrlProvider urlProvider = new ResourceUrlProvider();
/* 438 */     UrlPathHelper pathHelper = getPathMatchConfigurer().getUrlPathHelper();
/* 439 */     if (pathHelper != null) {
/* 440 */       urlProvider.setUrlPathHelper(pathHelper);
/*     */     }
/* 442 */     PathMatcher pathMatcher = getPathMatchConfigurer().getPathMatcher();
/* 443 */     if (pathMatcher != null) {
/* 444 */       urlProvider.setPathMatcher(pathMatcher);
/*     */     }
/* 446 */     return urlProvider;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Bean
/*     */   public HandlerMapping defaultServletHandlerMapping()
/*     */   {
/* 456 */     DefaultServletHandlerConfigurer configurer = new DefaultServletHandlerConfigurer(this.servletContext);
/* 457 */     configureDefaultServletHandling(configurer);
/* 458 */     AbstractHandlerMapping handlerMapping = configurer.getHandlerMapping();
/* 459 */     handlerMapping = handlerMapping != null ? handlerMapping : new EmptyHandlerMapping(null);
/* 460 */     return handlerMapping;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Bean
/*     */   public RequestMappingHandlerAdapter requestMappingHandlerAdapter()
/*     */   {
/* 482 */     RequestMappingHandlerAdapter adapter = createRequestMappingHandlerAdapter();
/* 483 */     adapter.setContentNegotiationManager(mvcContentNegotiationManager());
/* 484 */     adapter.setMessageConverters(getMessageConverters());
/* 485 */     adapter.setWebBindingInitializer(getConfigurableWebBindingInitializer());
/* 486 */     adapter.setCustomArgumentResolvers(getArgumentResolvers());
/* 487 */     adapter.setCustomReturnValueHandlers(getReturnValueHandlers());
/*     */     
/* 489 */     if (jackson2Present) {
/* 490 */       List<RequestBodyAdvice> requestBodyAdvices = new ArrayList();
/* 491 */       requestBodyAdvices.add(new JsonViewRequestBodyAdvice());
/* 492 */       adapter.setRequestBodyAdvice(requestBodyAdvices);
/*     */       
/* 494 */       List<ResponseBodyAdvice<?>> responseBodyAdvices = new ArrayList();
/* 495 */       responseBodyAdvices.add(new JsonViewResponseBodyAdvice());
/* 496 */       adapter.setResponseBodyAdvice(responseBodyAdvices);
/*     */     }
/*     */     
/* 499 */     AsyncSupportConfigurer configurer = new AsyncSupportConfigurer();
/* 500 */     configureAsyncSupport(configurer);
/*     */     
/* 502 */     if (configurer.getTaskExecutor() != null) {
/* 503 */       adapter.setTaskExecutor(configurer.getTaskExecutor());
/*     */     }
/* 505 */     if (configurer.getTimeout() != null) {
/* 506 */       adapter.setAsyncRequestTimeout(configurer.getTimeout().longValue());
/*     */     }
/* 508 */     adapter.setCallableInterceptors(configurer.getCallableInterceptors());
/* 509 */     adapter.setDeferredResultInterceptors(configurer.getDeferredResultInterceptors());
/*     */     
/* 511 */     return adapter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected RequestMappingHandlerAdapter createRequestMappingHandlerAdapter()
/*     */   {
/* 519 */     return new RequestMappingHandlerAdapter();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ConfigurableWebBindingInitializer getConfigurableWebBindingInitializer()
/*     */   {
/* 527 */     ConfigurableWebBindingInitializer initializer = new ConfigurableWebBindingInitializer();
/* 528 */     initializer.setConversionService(mvcConversionService());
/* 529 */     initializer.setValidator(mvcValidator());
/* 530 */     initializer.setMessageCodesResolver(getMessageCodesResolver());
/* 531 */     return initializer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Bean
/*     */   public FormattingConversionService mvcConversionService()
/*     */   {
/* 541 */     FormattingConversionService conversionService = new DefaultFormattingConversionService();
/* 542 */     addFormatters(conversionService);
/* 543 */     return conversionService;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Bean
/*     */   public Validator mvcValidator()
/*     */   {
/* 556 */     Validator validator = getValidator();
/* 557 */     if (validator == null) {
/* 558 */       if (ClassUtils.isPresent("javax.validation.Validator", getClass().getClassLoader()))
/*     */       {
/*     */         try {
/* 561 */           String className = "org.springframework.validation.beanvalidation.OptionalValidatorFactoryBean";
/* 562 */           clazz = ClassUtils.forName(className, WebMvcConfigurationSupport.class.getClassLoader());
/*     */         } catch (ClassNotFoundException ex) {
/*     */           Class<?> clazz;
/* 565 */           throw new BeanInitializationException("Could not find default validator class", ex);
/*     */         }
/*     */         catch (LinkageError ex) {
/* 568 */           throw new BeanInitializationException("Could not load default validator class", ex); }
/*     */         Class<?> clazz;
/* 570 */         validator = (Validator)BeanUtils.instantiate(clazz);
/*     */       }
/*     */       else {
/* 573 */         validator = new NoOpValidator(null);
/*     */       }
/*     */     }
/* 576 */     return validator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Bean
/*     */   public PathMatcher mvcPathMatcher()
/*     */   {
/* 588 */     if (getPathMatchConfigurer().getPathMatcher() != null) {
/* 589 */       return getPathMatchConfigurer().getPathMatcher();
/*     */     }
/*     */     
/* 592 */     return new AntPathMatcher();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Bean
/*     */   public UrlPathHelper mvcUrlPathHelper()
/*     */   {
/* 605 */     if (getPathMatchConfigurer().getUrlPathHelper() != null) {
/* 606 */       return getPathMatchConfigurer().getUrlPathHelper();
/*     */     }
/*     */     
/* 609 */     return new UrlPathHelper();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Validator getValidator()
/*     */   {
/* 617 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected MessageCodesResolver getMessageCodesResolver()
/*     */   {
/* 624 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final List<HandlerMethodArgumentResolver> getArgumentResolvers()
/*     */   {
/* 634 */     if (this.argumentResolvers == null) {
/* 635 */       this.argumentResolvers = new ArrayList();
/* 636 */       addArgumentResolvers(this.argumentResolvers);
/*     */     }
/* 638 */     return this.argumentResolvers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final List<HandlerMethodReturnValueHandler> getReturnValueHandlers()
/*     */   {
/* 662 */     if (this.returnValueHandlers == null) {
/* 663 */       this.returnValueHandlers = new ArrayList();
/* 664 */       addReturnValueHandlers(this.returnValueHandlers);
/*     */     }
/* 666 */     return this.returnValueHandlers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addReturnValueHandlers(List<HandlerMethodReturnValueHandler> returnValueHandlers) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final List<HttpMessageConverter<?>> getMessageConverters()
/*     */   {
/* 693 */     if (this.messageConverters == null) {
/* 694 */       this.messageConverters = new ArrayList();
/* 695 */       configureMessageConverters(this.messageConverters);
/* 696 */       if (this.messageConverters.isEmpty()) {
/* 697 */         addDefaultHttpMessageConverters(this.messageConverters);
/*     */       }
/* 699 */       extendMessageConverters(this.messageConverters);
/*     */     }
/* 701 */     return this.messageConverters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void configureMessageConverters(List<HttpMessageConverter<?>> converters) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void extendMessageConverters(List<HttpMessageConverter<?>> converters) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void addDefaultHttpMessageConverters(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/* 734 */     StringHttpMessageConverter stringConverter = new StringHttpMessageConverter();
/* 735 */     stringConverter.setWriteAcceptCharset(false);
/*     */     
/* 737 */     messageConverters.add(new ByteArrayHttpMessageConverter());
/* 738 */     messageConverters.add(stringConverter);
/* 739 */     messageConverters.add(new ResourceHttpMessageConverter());
/* 740 */     messageConverters.add(new SourceHttpMessageConverter());
/* 741 */     messageConverters.add(new AllEncompassingFormHttpMessageConverter());
/*     */     
/* 743 */     if (romePresent) {
/* 744 */       messageConverters.add(new AtomFeedHttpMessageConverter());
/* 745 */       messageConverters.add(new RssChannelHttpMessageConverter());
/*     */     }
/*     */     
/* 748 */     if (jackson2XmlPresent) {
/* 749 */       ObjectMapper objectMapper = Jackson2ObjectMapperBuilder.xml().applicationContext(this.applicationContext).build();
/* 750 */       messageConverters.add(new MappingJackson2XmlHttpMessageConverter(objectMapper));
/*     */     }
/* 752 */     else if (jaxb2Present) {
/* 753 */       messageConverters.add(new Jaxb2RootElementHttpMessageConverter());
/*     */     }
/*     */     
/* 756 */     if (jackson2Present) {
/* 757 */       ObjectMapper objectMapper = Jackson2ObjectMapperBuilder.json().applicationContext(this.applicationContext).build();
/* 758 */       messageConverters.add(new MappingJackson2HttpMessageConverter(objectMapper));
/*     */     }
/* 760 */     else if (gsonPresent) {
/* 761 */       messageConverters.add(new GsonHttpMessageConverter());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addFormatters(FormatterRegistry registry) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void configureAsyncSupport(AsyncSupportConfigurer configurer) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Bean
/*     */   public CompositeUriComponentsContributor mvcUriComponentsContributor()
/*     */   {
/* 785 */     return new CompositeUriComponentsContributor(requestMappingHandlerAdapter().getArgumentResolvers(), mvcConversionService());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Bean
/*     */   public HttpRequestHandlerAdapter httpRequestHandlerAdapter()
/*     */   {
/* 794 */     return new HttpRequestHandlerAdapter();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Bean
/*     */   public SimpleControllerHandlerAdapter simpleControllerHandlerAdapter()
/*     */   {
/* 803 */     return new SimpleControllerHandlerAdapter();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Bean
/*     */   public HandlerExceptionResolver handlerExceptionResolver()
/*     */   {
/* 818 */     List<HandlerExceptionResolver> exceptionResolvers = new ArrayList();
/* 819 */     configureHandlerExceptionResolvers(exceptionResolvers);
/*     */     
/* 821 */     if (exceptionResolvers.isEmpty()) {
/* 822 */       addDefaultHandlerExceptionResolvers(exceptionResolvers);
/*     */     }
/*     */     
/* 825 */     extendHandlerExceptionResolvers(exceptionResolvers);
/* 826 */     HandlerExceptionResolverComposite composite = new HandlerExceptionResolverComposite();
/* 827 */     composite.setOrder(0);
/* 828 */     composite.setExceptionResolvers(exceptionResolvers);
/* 829 */     return composite;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void configureHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void extendHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void addDefaultHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers)
/*     */   {
/* 868 */     ExceptionHandlerExceptionResolver exceptionHandlerResolver = createExceptionHandlerExceptionResolver();
/* 869 */     exceptionHandlerResolver.setContentNegotiationManager(mvcContentNegotiationManager());
/* 870 */     exceptionHandlerResolver.setMessageConverters(getMessageConverters());
/* 871 */     exceptionHandlerResolver.setCustomArgumentResolvers(getArgumentResolvers());
/* 872 */     exceptionHandlerResolver.setCustomReturnValueHandlers(getReturnValueHandlers());
/* 873 */     if (jackson2Present) {
/* 874 */       List<ResponseBodyAdvice<?>> interceptors = new ArrayList();
/* 875 */       interceptors.add(new JsonViewResponseBodyAdvice());
/* 876 */       exceptionHandlerResolver.setResponseBodyAdvice(interceptors);
/*     */     }
/* 878 */     exceptionHandlerResolver.setApplicationContext(this.applicationContext);
/* 879 */     exceptionHandlerResolver.afterPropertiesSet();
/* 880 */     exceptionResolvers.add(exceptionHandlerResolver);
/*     */     
/* 882 */     ResponseStatusExceptionResolver responseStatusResolver = new ResponseStatusExceptionResolver();
/* 883 */     responseStatusResolver.setMessageSource(this.applicationContext);
/* 884 */     exceptionResolvers.add(responseStatusResolver);
/*     */     
/* 886 */     exceptionResolvers.add(new DefaultHandlerExceptionResolver());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ExceptionHandlerExceptionResolver createExceptionHandlerExceptionResolver()
/*     */   {
/* 894 */     return new ExceptionHandlerExceptionResolver();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Bean
/*     */   public ViewResolver mvcViewResolver()
/*     */   {
/* 911 */     ViewResolverRegistry registry = new ViewResolverRegistry();
/* 912 */     registry.setContentNegotiationManager(mvcContentNegotiationManager());
/* 913 */     registry.setApplicationContext(this.applicationContext);
/* 914 */     configureViewResolvers(registry);
/*     */     
/* 916 */     if (registry.getViewResolvers().isEmpty()) {
/* 917 */       String[] names = BeanFactoryUtils.beanNamesForTypeIncludingAncestors(this.applicationContext, ViewResolver.class, true, false);
/*     */       
/* 919 */       if (names.length == 1) {
/* 920 */         registry.getViewResolvers().add(new InternalResourceViewResolver());
/*     */       }
/*     */     }
/*     */     
/* 924 */     ViewResolverComposite composite = new ViewResolverComposite();
/* 925 */     composite.setOrder(registry.getOrder());
/* 926 */     composite.setViewResolvers(registry.getViewResolvers());
/* 927 */     composite.setApplicationContext(this.applicationContext);
/* 928 */     composite.setServletContext(this.servletContext);
/* 929 */     return composite;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void configureViewResolvers(ViewResolverRegistry registry) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final Map<String, CorsConfiguration> getCorsConfigurations()
/*     */   {
/* 943 */     if (this.corsConfigurations == null) {
/* 944 */       CorsRegistry registry = new CorsRegistry();
/* 945 */       addCorsMappings(registry);
/* 946 */       this.corsConfigurations = registry.getCorsConfigurations();
/*     */     }
/* 948 */     return this.corsConfigurations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addCorsMappings(CorsRegistry registry) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class EmptyHandlerMapping
/*     */     extends AbstractHandlerMapping
/*     */   {
/*     */     protected Object getHandlerInternal(HttpServletRequest request)
/*     */     {
/* 964 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class NoOpValidator
/*     */     implements Validator
/*     */   {
/*     */     public boolean supports(Class<?> clazz)
/*     */     {
/* 973 */       return false;
/*     */     }
/*     */     
/*     */     public void validate(Object target, Errors errors) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\config\annotation\WebMvcConfigurationSupport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */