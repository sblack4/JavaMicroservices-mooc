/*     */ package org.springframework.web.servlet.config;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.beans.factory.support.ManagedMap;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.cache.concurrent.ConcurrentMapCache;
/*     */ import org.springframework.http.CacheControl;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.springframework.web.servlet.handler.MappedInterceptor;
/*     */ import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
/*     */ import org.springframework.web.servlet.resource.CachingResourceResolver;
/*     */ import org.springframework.web.servlet.resource.CachingResourceTransformer;
/*     */ import org.springframework.web.servlet.resource.ContentVersionStrategy;
/*     */ import org.springframework.web.servlet.resource.CssLinkResourceTransformer;
/*     */ import org.springframework.web.servlet.resource.FixedVersionStrategy;
/*     */ import org.springframework.web.servlet.resource.PathResourceResolver;
/*     */ import org.springframework.web.servlet.resource.ResourceHttpRequestHandler;
/*     */ import org.springframework.web.servlet.resource.ResourceUrlProvider;
/*     */ import org.springframework.web.servlet.resource.ResourceUrlProviderExposingInterceptor;
/*     */ import org.springframework.web.servlet.resource.VersionResourceResolver;
/*     */ import org.springframework.web.servlet.resource.WebJarsResourceResolver;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ResourcesBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   private static final String RESOURCE_CHAIN_CACHE = "spring-resource-chain-cache";
/*     */   private static final String VERSION_RESOLVER_ELEMENT = "version-resolver";
/*     */   private static final String VERSION_STRATEGY_ELEMENT = "version-strategy";
/*     */   private static final String FIXED_VERSION_STRATEGY_ELEMENT = "fixed-version-strategy";
/*     */   private static final String CONTENT_VERSION_STRATEGY_ELEMENT = "content-version-strategy";
/*     */   private static final String RESOURCE_URL_PROVIDER = "mvcResourceUrlProvider";
/*  84 */   private static final boolean isWebJarsAssetLocatorPresent = ClassUtils.isPresent("org.webjars.WebJarAssetLocator", ResourcesBeanDefinitionParser.class
/*  85 */     .getClassLoader());
/*     */   
/*     */ 
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext)
/*     */   {
/*  90 */     Object source = parserContext.extractSource(element);
/*     */     
/*  92 */     registerUrlProvider(parserContext, source);
/*     */     
/*  94 */     String resourceHandlerName = registerResourceHandler(parserContext, element, source);
/*  95 */     if (resourceHandlerName == null) {
/*  96 */       return null;
/*     */     }
/*     */     
/*  99 */     Map<String, String> urlMap = new ManagedMap();
/* 100 */     String resourceRequestPath = element.getAttribute("mapping");
/* 101 */     if (!StringUtils.hasText(resourceRequestPath)) {
/* 102 */       parserContext.getReaderContext().error("The 'mapping' attribute is required.", parserContext.extractSource(element));
/* 103 */       return null;
/*     */     }
/* 105 */     urlMap.put(resourceRequestPath, resourceHandlerName);
/*     */     
/* 107 */     RuntimeBeanReference pathMatcherRef = MvcNamespaceUtils.registerPathMatcher(null, parserContext, source);
/* 108 */     RuntimeBeanReference pathHelperRef = MvcNamespaceUtils.registerUrlPathHelper(null, parserContext, source);
/*     */     
/* 110 */     RootBeanDefinition handlerMappingDef = new RootBeanDefinition(SimpleUrlHandlerMapping.class);
/* 111 */     handlerMappingDef.setSource(source);
/* 112 */     handlerMappingDef.setRole(2);
/* 113 */     handlerMappingDef.getPropertyValues().add("urlMap", urlMap);
/* 114 */     handlerMappingDef.getPropertyValues().add("pathMatcher", pathMatcherRef).add("urlPathHelper", pathHelperRef);
/*     */     
/* 116 */     String order = element.getAttribute("order");
/*     */     
/* 118 */     handlerMappingDef.getPropertyValues().add("order", StringUtils.hasText(order) ? order : Integer.valueOf(2147483646));
/*     */     
/* 120 */     RuntimeBeanReference corsConfigurationsRef = MvcNamespaceUtils.registerCorsConfigurations(null, parserContext, source);
/* 121 */     handlerMappingDef.getPropertyValues().add("corsConfigurations", corsConfigurationsRef);
/*     */     
/* 123 */     String beanName = parserContext.getReaderContext().generateBeanName(handlerMappingDef);
/* 124 */     parserContext.getRegistry().registerBeanDefinition(beanName, handlerMappingDef);
/* 125 */     parserContext.registerComponent(new BeanComponentDefinition(handlerMappingDef, beanName));
/*     */     
/*     */ 
/*     */ 
/* 129 */     MvcNamespaceUtils.registerDefaultComponents(parserContext, source);
/*     */     
/* 131 */     return null;
/*     */   }
/*     */   
/*     */   private void registerUrlProvider(ParserContext parserContext, Object source) {
/* 135 */     if (!parserContext.getRegistry().containsBeanDefinition("mvcResourceUrlProvider")) {
/* 136 */       RootBeanDefinition urlProvider = new RootBeanDefinition(ResourceUrlProvider.class);
/* 137 */       urlProvider.setSource(source);
/* 138 */       urlProvider.setRole(2);
/* 139 */       parserContext.getRegistry().registerBeanDefinition("mvcResourceUrlProvider", urlProvider);
/* 140 */       parserContext.registerComponent(new BeanComponentDefinition(urlProvider, "mvcResourceUrlProvider"));
/*     */       
/* 142 */       RootBeanDefinition interceptor = new RootBeanDefinition(ResourceUrlProviderExposingInterceptor.class);
/* 143 */       interceptor.setSource(source);
/* 144 */       interceptor.getConstructorArgumentValues().addIndexedArgumentValue(0, urlProvider);
/*     */       
/* 146 */       RootBeanDefinition mappedInterceptor = new RootBeanDefinition(MappedInterceptor.class);
/* 147 */       mappedInterceptor.setSource(source);
/* 148 */       mappedInterceptor.setRole(2);
/* 149 */       mappedInterceptor.getConstructorArgumentValues().addIndexedArgumentValue(0, null);
/* 150 */       mappedInterceptor.getConstructorArgumentValues().addIndexedArgumentValue(1, interceptor);
/* 151 */       String mappedInterceptorName = parserContext.getReaderContext().registerWithGeneratedName(mappedInterceptor);
/* 152 */       parserContext.registerComponent(new BeanComponentDefinition(mappedInterceptor, mappedInterceptorName));
/*     */     }
/*     */   }
/*     */   
/*     */   private String registerResourceHandler(ParserContext parserContext, Element element, Object source) {
/* 157 */     String locationAttr = element.getAttribute("location");
/* 158 */     if (!StringUtils.hasText(locationAttr)) {
/* 159 */       parserContext.getReaderContext().error("The 'location' attribute is required.", parserContext.extractSource(element));
/* 160 */       return null;
/*     */     }
/*     */     
/* 163 */     ManagedList<String> locations = new ManagedList();
/* 164 */     locations.addAll(Arrays.asList(StringUtils.commaDelimitedListToStringArray(locationAttr)));
/*     */     
/* 166 */     RootBeanDefinition resourceHandlerDef = new RootBeanDefinition(ResourceHttpRequestHandler.class);
/* 167 */     resourceHandlerDef.setSource(source);
/* 168 */     resourceHandlerDef.setRole(2);
/*     */     
/* 170 */     MutablePropertyValues values = resourceHandlerDef.getPropertyValues();
/* 171 */     values.add("locations", locations);
/*     */     
/* 173 */     String cacheSeconds = element.getAttribute("cache-period");
/* 174 */     if (StringUtils.hasText(cacheSeconds)) {
/* 175 */       values.add("cacheSeconds", cacheSeconds);
/*     */     }
/*     */     
/* 178 */     Element cacheControlElement = DomUtils.getChildElementByTagName(element, "cache-control");
/* 179 */     if (cacheControlElement != null) {
/* 180 */       CacheControl cacheControl = parseCacheControl(cacheControlElement);
/* 181 */       values.add("cacheControl", cacheControl);
/*     */     }
/*     */     
/* 184 */     Element resourceChainElement = DomUtils.getChildElementByTagName(element, "resource-chain");
/* 185 */     if (resourceChainElement != null) {
/* 186 */       parseResourceChain(resourceHandlerDef, parserContext, resourceChainElement, source);
/*     */     }
/*     */     
/* 189 */     Object manager = MvcNamespaceUtils.getContentNegotiationManager(parserContext);
/* 190 */     if (manager != null) {
/* 191 */       values.add("contentNegotiationManager", manager);
/*     */     }
/*     */     
/* 194 */     String beanName = parserContext.getReaderContext().generateBeanName(resourceHandlerDef);
/* 195 */     parserContext.getRegistry().registerBeanDefinition(beanName, resourceHandlerDef);
/* 196 */     parserContext.registerComponent(new BeanComponentDefinition(resourceHandlerDef, beanName));
/* 197 */     return beanName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void parseResourceChain(RootBeanDefinition resourceHandlerDef, ParserContext parserContext, Element element, Object source)
/*     */   {
/* 204 */     String autoRegistration = element.getAttribute("auto-registration");
/* 205 */     boolean isAutoRegistration = (!StringUtils.hasText(autoRegistration)) || (!"false".equals(autoRegistration));
/*     */     
/* 207 */     ManagedList<? super Object> resourceResolvers = new ManagedList();
/* 208 */     resourceResolvers.setSource(source);
/* 209 */     ManagedList<? super Object> resourceTransformers = new ManagedList();
/* 210 */     resourceTransformers.setSource(source);
/*     */     
/* 212 */     parseResourceCache(resourceResolvers, resourceTransformers, element, source);
/* 213 */     parseResourceResolversTransformers(isAutoRegistration, resourceResolvers, resourceTransformers, parserContext, element, source);
/*     */     
/*     */ 
/* 216 */     if (!resourceResolvers.isEmpty()) {
/* 217 */       resourceHandlerDef.getPropertyValues().add("resourceResolvers", resourceResolvers);
/*     */     }
/* 219 */     if (!resourceTransformers.isEmpty()) {
/* 220 */       resourceHandlerDef.getPropertyValues().add("resourceTransformers", resourceTransformers);
/*     */     }
/*     */   }
/*     */   
/*     */   private CacheControl parseCacheControl(Element element) {
/* 225 */     CacheControl cacheControl = CacheControl.empty();
/* 226 */     if ("true".equals(element.getAttribute("no-cache"))) {
/* 227 */       cacheControl = CacheControl.noCache();
/*     */     }
/* 229 */     else if ("true".equals(element.getAttribute("no-store"))) {
/* 230 */       cacheControl = CacheControl.noStore();
/*     */     }
/* 232 */     else if (element.hasAttribute("max-age")) {
/* 233 */       cacheControl = CacheControl.maxAge(Long.parseLong(element.getAttribute("max-age")), TimeUnit.SECONDS);
/*     */     }
/* 235 */     if ("true".equals(element.getAttribute("must-revalidate"))) {
/* 236 */       cacheControl = cacheControl.mustRevalidate();
/*     */     }
/* 238 */     if ("true".equals(element.getAttribute("no-transform"))) {
/* 239 */       cacheControl = cacheControl.noTransform();
/*     */     }
/* 241 */     if ("true".equals(element.getAttribute("cache-public"))) {
/* 242 */       cacheControl = cacheControl.cachePublic();
/*     */     }
/* 244 */     if ("true".equals(element.getAttribute("cache-private"))) {
/* 245 */       cacheControl = cacheControl.cachePrivate();
/*     */     }
/* 247 */     if ("true".equals(element.getAttribute("proxy-revalidate"))) {
/* 248 */       cacheControl = cacheControl.proxyRevalidate();
/*     */     }
/* 250 */     if (element.hasAttribute("s-maxage")) {
/* 251 */       cacheControl = cacheControl.sMaxAge(Long.parseLong(element.getAttribute("s-maxage")), TimeUnit.SECONDS);
/*     */     }
/* 253 */     if (element.hasAttribute("stale-while-revalidate")) {
/* 254 */       cacheControl = cacheControl.staleWhileRevalidate(
/* 255 */         Long.parseLong(element.getAttribute("stale-while-revalidate")), TimeUnit.SECONDS);
/*     */     }
/* 257 */     if (element.hasAttribute("stale-if-error")) {
/* 258 */       cacheControl = cacheControl.staleIfError(
/* 259 */         Long.parseLong(element.getAttribute("stale-if-error")), TimeUnit.SECONDS);
/*     */     }
/* 261 */     return cacheControl;
/*     */   }
/*     */   
/*     */ 
/*     */   private void parseResourceCache(ManagedList<? super Object> resourceResolvers, ManagedList<? super Object> resourceTransformers, Element element, Object source)
/*     */   {
/* 267 */     String resourceCache = element.getAttribute("resource-cache");
/* 268 */     if ("true".equals(resourceCache)) {
/* 269 */       ConstructorArgumentValues cavs = new ConstructorArgumentValues();
/*     */       
/* 271 */       RootBeanDefinition cachingResolverDef = new RootBeanDefinition(CachingResourceResolver.class);
/* 272 */       cachingResolverDef.setSource(source);
/* 273 */       cachingResolverDef.setRole(2);
/* 274 */       cachingResolverDef.setConstructorArgumentValues(cavs);
/*     */       
/* 276 */       RootBeanDefinition cachingTransformerDef = new RootBeanDefinition(CachingResourceTransformer.class);
/* 277 */       cachingTransformerDef.setSource(source);
/* 278 */       cachingTransformerDef.setRole(2);
/* 279 */       cachingTransformerDef.setConstructorArgumentValues(cavs);
/*     */       
/* 281 */       String cacheManagerName = element.getAttribute("cache-manager");
/* 282 */       String cacheName = element.getAttribute("cache-name");
/* 283 */       if ((StringUtils.hasText(cacheManagerName)) && (StringUtils.hasText(cacheName))) {
/* 284 */         RuntimeBeanReference cacheManagerRef = new RuntimeBeanReference(cacheManagerName);
/* 285 */         cavs.addIndexedArgumentValue(0, cacheManagerRef);
/* 286 */         cavs.addIndexedArgumentValue(1, cacheName);
/*     */       }
/*     */       else {
/* 289 */         ConstructorArgumentValues cacheCavs = new ConstructorArgumentValues();
/* 290 */         cacheCavs.addIndexedArgumentValue(0, "spring-resource-chain-cache");
/* 291 */         RootBeanDefinition cacheDef = new RootBeanDefinition(ConcurrentMapCache.class);
/* 292 */         cacheDef.setSource(source);
/* 293 */         cacheDef.setRole(2);
/* 294 */         cacheDef.setConstructorArgumentValues(cacheCavs);
/* 295 */         cavs.addIndexedArgumentValue(0, cacheDef);
/*     */       }
/* 297 */       resourceResolvers.add(cachingResolverDef);
/* 298 */       resourceTransformers.add(cachingTransformerDef);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void parseResourceResolversTransformers(boolean isAutoRegistration, ManagedList<? super Object> resourceResolvers, ManagedList<? super Object> resourceTransformers, ParserContext parserContext, Element element, Object source)
/*     */   {
/* 307 */     Element resolversElement = DomUtils.getChildElementByTagName(element, "resolvers");
/* 308 */     Iterator localIterator; if (resolversElement != null) {
/* 309 */       for (localIterator = DomUtils.getChildElements(resolversElement).iterator(); localIterator.hasNext();) { beanElement = (Element)localIterator.next();
/* 310 */         if ("version-resolver".equals(beanElement.getLocalName())) {
/* 311 */           RootBeanDefinition versionResolverDef = parseVersionResolver(parserContext, beanElement, source);
/* 312 */           versionResolverDef.setSource(source);
/* 313 */           resourceResolvers.add(versionResolverDef);
/* 314 */           if (isAutoRegistration) {
/* 315 */             RootBeanDefinition cssLinkTransformerDef = new RootBeanDefinition(CssLinkResourceTransformer.class);
/* 316 */             cssLinkTransformerDef.setSource(source);
/* 317 */             cssLinkTransformerDef.setRole(2);
/* 318 */             resourceTransformers.add(cssLinkTransformerDef);
/*     */           }
/*     */         }
/*     */         else {
/* 322 */           Object object = parserContext.getDelegate().parsePropertySubElement(beanElement, null);
/* 323 */           resourceResolvers.add(object);
/*     */         }
/*     */       }
/*     */     }
/*     */     Element beanElement;
/* 328 */     if (isAutoRegistration) {
/* 329 */       if (isWebJarsAssetLocatorPresent) {
/* 330 */         RootBeanDefinition webJarsResolverDef = new RootBeanDefinition(WebJarsResourceResolver.class);
/* 331 */         webJarsResolverDef.setSource(source);
/* 332 */         webJarsResolverDef.setRole(2);
/* 333 */         resourceResolvers.add(webJarsResolverDef);
/*     */       }
/* 335 */       RootBeanDefinition pathResolverDef = new RootBeanDefinition(PathResourceResolver.class);
/* 336 */       pathResolverDef.setSource(source);
/* 337 */       pathResolverDef.setRole(2);
/* 338 */       resourceResolvers.add(pathResolverDef);
/*     */     }
/*     */     
/* 341 */     Element transformersElement = DomUtils.getChildElementByTagName(element, "transformers");
/* 342 */     if (transformersElement != null) {
/* 343 */       for (Element beanElement : DomUtils.getChildElementsByTagName(transformersElement, new String[] { "bean", "ref" })) {
/* 344 */         Object object = parserContext.getDelegate().parsePropertySubElement(beanElement, null);
/* 345 */         resourceTransformers.add(object);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private RootBeanDefinition parseVersionResolver(ParserContext parserContext, Element element, Object source) {
/* 351 */     ManagedMap<String, ? super Object> strategyMap = new ManagedMap();
/* 352 */     strategyMap.setSource(source);
/* 353 */     RootBeanDefinition versionResolverDef = new RootBeanDefinition(VersionResourceResolver.class);
/* 354 */     versionResolverDef.setSource(source);
/* 355 */     versionResolverDef.setRole(2);
/* 356 */     versionResolverDef.getPropertyValues().addPropertyValue("strategyMap", strategyMap);
/*     */     
/* 358 */     for (Element beanElement : DomUtils.getChildElements(element)) {
/* 359 */       String[] patterns = StringUtils.commaDelimitedListToStringArray(beanElement.getAttribute("patterns"));
/* 360 */       Object strategy = null;
/* 361 */       if ("fixed-version-strategy".equals(beanElement.getLocalName())) {
/* 362 */         ConstructorArgumentValues cavs = new ConstructorArgumentValues();
/* 363 */         cavs.addIndexedArgumentValue(0, beanElement.getAttribute("version"));
/* 364 */         strategyDef = new RootBeanDefinition(FixedVersionStrategy.class);
/* 365 */         strategyDef.setSource(source);
/* 366 */         strategyDef.setRole(2);
/* 367 */         strategyDef.setConstructorArgumentValues(cavs);
/* 368 */         strategy = strategyDef;
/*     */       }
/* 370 */       else if ("content-version-strategy".equals(beanElement.getLocalName())) {
/* 371 */         RootBeanDefinition strategyDef = new RootBeanDefinition(ContentVersionStrategy.class);
/* 372 */         strategyDef.setSource(source);
/* 373 */         strategyDef.setRole(2);
/* 374 */         strategy = strategyDef;
/*     */       }
/* 376 */       else if ("version-strategy".equals(beanElement.getLocalName())) {
/* 377 */         childElement = (Element)DomUtils.getChildElementsByTagName(beanElement, new String[] { "bean", "ref" }).get(0);
/* 378 */         strategy = parserContext.getDelegate().parsePropertySubElement(childElement, null);
/*     */       }
/* 380 */       Element childElement = patterns;RootBeanDefinition strategyDef = childElement.length; for (RootBeanDefinition localRootBeanDefinition1 = 0; localRootBeanDefinition1 < strategyDef; localRootBeanDefinition1++) { String pattern = childElement[localRootBeanDefinition1];
/* 381 */         strategyMap.put(pattern, strategy);
/*     */       }
/*     */     }
/*     */     
/* 385 */     return versionResolverDef;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\config\ResourcesBeanDefinitionParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */