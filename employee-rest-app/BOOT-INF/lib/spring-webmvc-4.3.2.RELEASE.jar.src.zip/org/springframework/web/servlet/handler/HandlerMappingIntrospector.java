/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletRequestWrapper;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.PropertiesLoaderUtils;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.cors.CorsConfiguration;
/*     */ import org.springframework.web.cors.CorsConfigurationSource;
/*     */ import org.springframework.web.servlet.DispatcherServlet;
/*     */ import org.springframework.web.servlet.HandlerExecutionChain;
/*     */ import org.springframework.web.servlet.HandlerInterceptor;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HandlerMappingIntrospector
/*     */   implements CorsConfigurationSource
/*     */ {
/*     */   private final List<HandlerMapping> handlerMappings;
/*     */   
/*     */   public HandlerMappingIntrospector(ApplicationContext context)
/*     */   {
/*  68 */     this.handlerMappings = initHandlerMappings(context);
/*     */   }
/*     */   
/*     */   private static List<HandlerMapping> initHandlerMappings(ApplicationContext context)
/*     */   {
/*  73 */     Map<String, HandlerMapping> beans = BeanFactoryUtils.beansOfTypeIncludingAncestors(context, HandlerMapping.class, true, false);
/*     */     
/*  75 */     if (!beans.isEmpty()) {
/*  76 */       List<HandlerMapping> mappings = new ArrayList(beans.values());
/*  77 */       AnnotationAwareOrderComparator.sort(mappings);
/*  78 */       return mappings;
/*     */     }
/*  80 */     return initDefaultHandlerMappings(context);
/*     */   }
/*     */   
/*     */   private static List<HandlerMapping> initDefaultHandlerMappings(ApplicationContext context)
/*     */   {
/*  85 */     String path = "DispatcherServlet.properties";
/*     */     try {
/*  87 */       Resource resource = new ClassPathResource(path, DispatcherServlet.class);
/*  88 */       props = PropertiesLoaderUtils.loadProperties(resource);
/*     */     } catch (IOException ex) {
/*     */       Properties props;
/*  91 */       throw new IllegalStateException("Could not load '" + path + "': " + ex.getMessage());
/*     */     }
/*     */     Properties props;
/*  94 */     String value = props.getProperty(HandlerMapping.class.getName());
/*  95 */     String[] names = StringUtils.commaDelimitedListToStringArray(value);
/*  96 */     List<HandlerMapping> result = new ArrayList(names.length);
/*  97 */     for (String name : names) {
/*     */       try {
/*  99 */         Class<?> clazz = ClassUtils.forName(name, DispatcherServlet.class.getClassLoader());
/* 100 */         Object mapping = context.getAutowireCapableBeanFactory().createBean(clazz);
/* 101 */         result.add((HandlerMapping)mapping);
/*     */       }
/*     */       catch (ClassNotFoundException ex) {
/* 104 */         throw new IllegalStateException("Could not find default HandlerMapping [" + name + "]");
/*     */       }
/*     */     }
/* 107 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<HandlerMapping> getHandlerMappings()
/*     */   {
/* 115 */     return this.handlerMappings;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MatchableHandlerMapping getMatchableHandlerMapping(HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/* 129 */     HttpServletRequest wrapper = new RequestAttributeChangeIgnoringWrapper(request);
/* 130 */     for (HandlerMapping handlerMapping : this.handlerMappings) {
/* 131 */       Object handler = handlerMapping.getHandler(wrapper);
/* 132 */       if (handler != null)
/*     */       {
/*     */ 
/* 135 */         if ((handlerMapping instanceof MatchableHandlerMapping)) {
/* 136 */           return (MatchableHandlerMapping)handlerMapping;
/*     */         }
/* 138 */         throw new IllegalStateException("HandlerMapping is not a MatchableHandlerMapping");
/*     */       } }
/* 140 */     return null;
/*     */   }
/*     */   
/*     */   public CorsConfiguration getCorsConfiguration(HttpServletRequest request)
/*     */   {
/* 145 */     HttpServletRequest wrapper = new RequestAttributeChangeIgnoringWrapper(request);
/* 146 */     for (HandlerMapping handlerMapping : this.handlerMappings) {
/* 147 */       HandlerExecutionChain handler = null;
/*     */       try {
/* 149 */         handler = handlerMapping.getHandler(wrapper);
/*     */       }
/*     */       catch (Exception localException) {}
/*     */       
/*     */ 
/* 154 */       if (handler != null)
/*     */       {
/*     */ 
/* 157 */         if (handler.getInterceptors() != null) {
/* 158 */           for (HandlerInterceptor interceptor : handler.getInterceptors()) {
/* 159 */             if ((interceptor instanceof CorsConfigurationSource)) {
/* 160 */               return ((CorsConfigurationSource)interceptor).getCorsConfiguration(wrapper);
/*     */             }
/*     */           }
/*     */         }
/* 164 */         if ((handler.getHandler() instanceof CorsConfigurationSource))
/* 165 */           return ((CorsConfigurationSource)handler.getHandler()).getCorsConfiguration(wrapper);
/*     */       }
/*     */     }
/* 168 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class RequestAttributeChangeIgnoringWrapper
/*     */     extends HttpServletRequestWrapper
/*     */   {
/*     */     public RequestAttributeChangeIgnoringWrapper(HttpServletRequest request)
/*     */     {
/* 178 */       super();
/*     */     }
/*     */     
/*     */     public void setAttribute(String name, Object value) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\handler\HandlerMappingIntrospector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */