/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractNameValueExpression<T>
/*     */   implements NameValueExpression<T>
/*     */ {
/*     */   protected final String name;
/*     */   protected final T value;
/*     */   protected final boolean isNegated;
/*     */   
/*     */   AbstractNameValueExpression(String expression)
/*     */   {
/*  39 */     int separator = expression.indexOf('=');
/*  40 */     if (separator == -1) {
/*  41 */       this.isNegated = expression.startsWith("!");
/*  42 */       this.name = (this.isNegated ? expression.substring(1) : expression);
/*  43 */       this.value = null;
/*     */     }
/*     */     else {
/*  46 */       this.isNegated = ((separator > 0) && (expression.charAt(separator - 1) == '!'));
/*  47 */       this.name = (this.isNegated ? expression.substring(0, separator - 1) : expression.substring(0, separator));
/*  48 */       this.value = parseValue(expression.substring(separator + 1));
/*     */     }
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/*  54 */     return this.name;
/*     */   }
/*     */   
/*     */   public T getValue()
/*     */   {
/*  59 */     return (T)this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*  64 */   public boolean isNegated() { return this.isNegated; }
/*     */   
/*     */   protected abstract boolean isCaseSensitiveName();
/*     */   
/*     */   protected abstract T parseValue(String paramString);
/*     */   
/*     */   public final boolean match(HttpServletRequest request) {
/*     */     boolean isMatch;
/*     */     boolean isMatch;
/*  73 */     if (this.value != null) {
/*  74 */       isMatch = matchValue(request);
/*     */     }
/*     */     else {
/*  77 */       isMatch = matchName(request);
/*     */     }
/*  79 */     return this.isNegated ? false : !isMatch ? true : isMatch;
/*     */   }
/*     */   
/*     */   protected abstract boolean matchName(HttpServletRequest paramHttpServletRequest);
/*     */   
/*     */   protected abstract boolean matchValue(HttpServletRequest paramHttpServletRequest);
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  88 */     if (this == obj) {
/*  89 */       return true;
/*     */     }
/*  91 */     if ((obj != null) && ((obj instanceof AbstractNameValueExpression))) {
/*  92 */       AbstractNameValueExpression<?> other = (AbstractNameValueExpression)obj;
/*  93 */       String thisName = isCaseSensitiveName() ? this.name : this.name.toLowerCase();
/*  94 */       String otherName = isCaseSensitiveName() ? other.name : other.name.toLowerCase();
/*     */       
/*  96 */       return (thisName.equalsIgnoreCase(otherName)) && (this.value != null ? this.value.equals(other.value) : other.value == null) && (this.isNegated == other.isNegated);
/*     */     }
/*     */     
/*  99 */     return false;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 104 */     int result = isCaseSensitiveName() ? this.name.hashCode() : this.name.toLowerCase().hashCode();
/* 105 */     result = 31 * result + (this.value != null ? this.value.hashCode() : 0);
/* 106 */     result = 31 * result + (this.isNegated ? 1 : 0);
/* 107 */     return result;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 112 */     StringBuilder builder = new StringBuilder();
/* 113 */     if (this.value != null) {
/* 114 */       builder.append(this.name);
/* 115 */       if (this.isNegated) {
/* 116 */         builder.append('!');
/*     */       }
/* 118 */       builder.append('=');
/* 119 */       builder.append(this.value);
/*     */     }
/*     */     else {
/* 122 */       if (this.isNegated) {
/* 123 */         builder.append('!');
/*     */       }
/* 125 */       builder.append(this.name);
/*     */     }
/* 127 */     return builder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\condition\AbstractNameValueExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */