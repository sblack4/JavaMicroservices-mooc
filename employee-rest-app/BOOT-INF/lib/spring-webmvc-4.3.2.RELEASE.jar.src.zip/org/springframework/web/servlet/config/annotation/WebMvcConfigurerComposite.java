/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.validation.MessageCodesResolver;
/*     */ import org.springframework.validation.Validator;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.servlet.HandlerExceptionResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WebMvcConfigurerComposite
/*     */   implements WebMvcConfigurer
/*     */ {
/*  38 */   private final List<WebMvcConfigurer> delegates = new ArrayList();
/*     */   
/*     */   public void addWebMvcConfigurers(List<WebMvcConfigurer> configurers) {
/*  41 */     if (configurers != null) {
/*  42 */       this.delegates.addAll(configurers);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addFormatters(FormatterRegistry registry)
/*     */   {
/*  48 */     for (WebMvcConfigurer delegate : this.delegates) {
/*  49 */       delegate.addFormatters(registry);
/*     */     }
/*     */   }
/*     */   
/*     */   public void configureContentNegotiation(ContentNegotiationConfigurer configurer)
/*     */   {
/*  55 */     for (WebMvcConfigurer delegate : this.delegates) {
/*  56 */       delegate.configureContentNegotiation(configurer);
/*     */     }
/*     */   }
/*     */   
/*     */   public void configureAsyncSupport(AsyncSupportConfigurer configurer)
/*     */   {
/*  62 */     for (WebMvcConfigurer delegate : this.delegates) {
/*  63 */       delegate.configureAsyncSupport(configurer);
/*     */     }
/*     */   }
/*     */   
/*     */   public void configurePathMatch(PathMatchConfigurer configurer)
/*     */   {
/*  69 */     for (WebMvcConfigurer delegate : this.delegates) {
/*  70 */       delegate.configurePathMatch(configurer);
/*     */     }
/*     */   }
/*     */   
/*     */   public void configureMessageConverters(List<HttpMessageConverter<?>> converters)
/*     */   {
/*  76 */     for (WebMvcConfigurer delegate : this.delegates) {
/*  77 */       delegate.configureMessageConverters(converters);
/*     */     }
/*     */   }
/*     */   
/*     */   public void extendMessageConverters(List<HttpMessageConverter<?>> converters)
/*     */   {
/*  83 */     for (WebMvcConfigurer delegate : this.delegates) {
/*  84 */       delegate.extendMessageConverters(converters);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers)
/*     */   {
/*  90 */     for (WebMvcConfigurer delegate : this.delegates) {
/*  91 */       delegate.addArgumentResolvers(argumentResolvers);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addReturnValueHandlers(List<HandlerMethodReturnValueHandler> returnValueHandlers)
/*     */   {
/*  97 */     for (WebMvcConfigurer delegate : this.delegates) {
/*  98 */       delegate.addReturnValueHandlers(returnValueHandlers);
/*     */     }
/*     */   }
/*     */   
/*     */   public void configureHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers)
/*     */   {
/* 104 */     for (WebMvcConfigurer delegate : this.delegates) {
/* 105 */       delegate.configureHandlerExceptionResolvers(exceptionResolvers);
/*     */     }
/*     */   }
/*     */   
/*     */   public void extendHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers)
/*     */   {
/* 111 */     for (WebMvcConfigurer delegate : this.delegates) {
/* 112 */       delegate.configureHandlerExceptionResolvers(exceptionResolvers);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addInterceptors(InterceptorRegistry registry)
/*     */   {
/* 118 */     for (WebMvcConfigurer delegate : this.delegates) {
/* 119 */       delegate.addInterceptors(registry);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addViewControllers(ViewControllerRegistry registry)
/*     */   {
/* 125 */     for (WebMvcConfigurer delegate : this.delegates) {
/* 126 */       delegate.addViewControllers(registry);
/*     */     }
/*     */   }
/*     */   
/*     */   public void configureViewResolvers(ViewResolverRegistry registry)
/*     */   {
/* 132 */     for (WebMvcConfigurer delegate : this.delegates) {
/* 133 */       delegate.configureViewResolvers(registry);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addResourceHandlers(ResourceHandlerRegistry registry)
/*     */   {
/* 139 */     for (WebMvcConfigurer delegate : this.delegates) {
/* 140 */       delegate.addResourceHandlers(registry);
/*     */     }
/*     */   }
/*     */   
/*     */   public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer)
/*     */   {
/* 146 */     for (WebMvcConfigurer delegate : this.delegates) {
/* 147 */       delegate.configureDefaultServletHandling(configurer);
/*     */     }
/*     */   }
/*     */   
/*     */   public Validator getValidator()
/*     */   {
/* 153 */     List<Validator> candidates = new ArrayList();
/* 154 */     for (WebMvcConfigurer configurer : this.delegates) {
/* 155 */       Validator validator = configurer.getValidator();
/* 156 */       if (validator != null) {
/* 157 */         candidates.add(validator);
/*     */       }
/*     */     }
/* 160 */     return (Validator)selectSingleInstance(candidates, Validator.class);
/*     */   }
/*     */   
/*     */   public void addCorsMappings(CorsRegistry registry)
/*     */   {
/* 165 */     for (WebMvcConfigurer delegate : this.delegates) {
/* 166 */       delegate.addCorsMappings(registry);
/*     */     }
/*     */   }
/*     */   
/*     */   private <T> T selectSingleInstance(List<T> instances, Class<T> instanceType) {
/* 171 */     if (instances.size() > 1) {
/* 172 */       throw new IllegalStateException("Only one [" + instanceType + "] was expected but multiple instances were provided: " + instances);
/*     */     }
/*     */     
/* 175 */     if (instances.size() == 1) {
/* 176 */       return (T)instances.get(0);
/*     */     }
/*     */     
/* 179 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public MessageCodesResolver getMessageCodesResolver()
/*     */   {
/* 185 */     List<MessageCodesResolver> candidates = new ArrayList();
/* 186 */     for (WebMvcConfigurer configurer : this.delegates) {
/* 187 */       MessageCodesResolver messageCodesResolver = configurer.getMessageCodesResolver();
/* 188 */       if (messageCodesResolver != null) {
/* 189 */         candidates.add(messageCodesResolver);
/*     */       }
/*     */     }
/* 192 */     return (MessageCodesResolver)selectSingleInstance(candidates, MessageCodesResolver.class);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\config\annotation\WebMvcConfigurerComposite.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */