/*    */ package org.springframework.web.servlet.view.document;
/*    */ 
/*    */ import com.lowagie.text.pdf.PdfReader;
/*    */ import com.lowagie.text.pdf.PdfStamper;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.web.servlet.view.AbstractUrlBasedView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractPdfStamperView
/*    */   extends AbstractUrlBasedView
/*    */ {
/*    */   public AbstractPdfStamperView()
/*    */   {
/* 44 */     setContentType("application/pdf");
/*    */   }
/*    */   
/*    */ 
/*    */   protected boolean generatesDownloadContent()
/*    */   {
/* 50 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected final void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*    */     throws Exception
/*    */   {
/* 58 */     ByteArrayOutputStream baos = createTemporaryOutputStream();
/*    */     
/* 60 */     PdfReader reader = readPdfResource();
/* 61 */     PdfStamper stamper = new PdfStamper(reader, baos);
/* 62 */     mergePdfDocument(model, stamper, request, response);
/* 63 */     stamper.close();
/*    */     
/*    */ 
/* 66 */     writeToResponse(response, baos);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected PdfReader readPdfResource()
/*    */     throws IOException
/*    */   {
/* 78 */     return new PdfReader(getApplicationContext().getResource(getUrl()).getInputStream());
/*    */   }
/*    */   
/*    */   protected abstract void mergePdfDocument(Map<String, Object> paramMap, PdfStamper paramPdfStamper, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
/*    */     throws Exception;
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\view\document\AbstractPdfStamperView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */