/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.concurrent.Callable;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.bind.annotation.ResponseStatus;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ import org.springframework.web.method.HandlerMethod.HandlerMethodParameter;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandlerComposite;
/*     */ import org.springframework.web.method.support.InvocableHandlerMethod;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.util.NestedServletException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletInvocableHandlerMethod
/*     */   extends InvocableHandlerMethod
/*     */ {
/*  58 */   private static final Method CALLABLE_METHOD = ClassUtils.getMethod(Callable.class, "call", new Class[0]);
/*     */   
/*     */ 
/*     */   private HttpStatus responseStatus;
/*     */   
/*     */ 
/*     */   private String responseReason;
/*     */   
/*     */ 
/*     */   private HandlerMethodReturnValueHandlerComposite returnValueHandlers;
/*     */   
/*     */ 
/*     */   public ServletInvocableHandlerMethod(Object handler, Method method)
/*     */   {
/*  72 */     super(handler, method);
/*  73 */     initResponseStatus();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ServletInvocableHandlerMethod(HandlerMethod handlerMethod)
/*     */   {
/*  80 */     super(handlerMethod);
/*  81 */     initResponseStatus();
/*     */   }
/*     */   
/*     */   private void initResponseStatus() {
/*  85 */     ResponseStatus annotation = (ResponseStatus)getMethodAnnotation(ResponseStatus.class);
/*  86 */     if (annotation == null) {
/*  87 */       annotation = (ResponseStatus)AnnotatedElementUtils.findMergedAnnotation(getBeanType(), ResponseStatus.class);
/*     */     }
/*  89 */     if (annotation != null) {
/*  90 */       this.responseStatus = annotation.code();
/*  91 */       this.responseReason = annotation.reason();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHandlerMethodReturnValueHandlers(HandlerMethodReturnValueHandlerComposite returnValueHandlers)
/*     */   {
/* 101 */     this.returnValueHandlers = returnValueHandlers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void invokeAndHandle(ServletWebRequest webRequest, ModelAndViewContainer mavContainer, Object... providedArgs)
/*     */     throws Exception
/*     */   {
/* 114 */     Object returnValue = invokeForRequest(webRequest, mavContainer, providedArgs);
/* 115 */     setResponseStatus(webRequest);
/*     */     
/* 117 */     if (returnValue == null) {
/* 118 */       if ((isRequestNotModified(webRequest)) || (hasResponseStatus()) || (mavContainer.isRequestHandled())) {
/* 119 */         mavContainer.setRequestHandled(true);
/*     */       }
/*     */       
/*     */     }
/* 123 */     else if (StringUtils.hasText(this.responseReason)) {
/* 124 */       mavContainer.setRequestHandled(true);
/* 125 */       return;
/*     */     }
/*     */     
/* 128 */     mavContainer.setRequestHandled(false);
/*     */     try {
/* 130 */       this.returnValueHandlers.handleReturnValue(returnValue, 
/* 131 */         getReturnValueType(returnValue), mavContainer, webRequest);
/*     */     }
/*     */     catch (Exception ex) {
/* 134 */       if (this.logger.isTraceEnabled()) {
/* 135 */         this.logger.trace(getReturnValueHandlingErrorMessage("Error handling return value", returnValue), ex);
/*     */       }
/* 137 */       throw ex;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void setResponseStatus(ServletWebRequest webRequest)
/*     */     throws IOException
/*     */   {
/* 145 */     if (this.responseStatus == null) {
/* 146 */       return;
/*     */     }
/* 148 */     if (StringUtils.hasText(this.responseReason)) {
/* 149 */       webRequest.getResponse().sendError(this.responseStatus.value(), this.responseReason);
/*     */     }
/*     */     else {
/* 152 */       webRequest.getResponse().setStatus(this.responseStatus.value());
/*     */     }
/*     */     
/* 155 */     webRequest.getRequest().setAttribute(View.RESPONSE_STATUS_ATTRIBUTE, this.responseStatus);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isRequestNotModified(ServletWebRequest webRequest)
/*     */   {
/* 164 */     return webRequest.isNotModified();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean hasResponseStatus()
/*     */   {
/* 171 */     return this.responseStatus != null;
/*     */   }
/*     */   
/*     */   private String getReturnValueHandlingErrorMessage(String message, Object returnValue) {
/* 175 */     StringBuilder sb = new StringBuilder(message);
/* 176 */     if (returnValue != null) {
/* 177 */       sb.append(" [type=").append(returnValue.getClass().getName()).append("]");
/*     */     }
/* 179 */     sb.append(" [value=").append(returnValue).append("]");
/* 180 */     return getDetailedErrorMessage(sb.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   ServletInvocableHandlerMethod wrapConcurrentResult(Object result)
/*     */   {
/* 190 */     return new ConcurrentResultHandlerMethod(result, new ConcurrentResultMethodParameter(result));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private class ConcurrentResultHandlerMethod
/*     */     extends ServletInvocableHandlerMethod
/*     */   {
/*     */     private final MethodParameter returnType;
/*     */     
/*     */ 
/*     */ 
/*     */     public ConcurrentResultHandlerMethod(final Object result, ServletInvocableHandlerMethod.ConcurrentResultMethodParameter returnType)
/*     */     {
/* 205 */       super(
/*     */       {
/*     */         public Object call() throws Exception {
/* 208 */           if ((result instanceof Exception)) {
/* 209 */             throw ((Exception)result);
/*     */           }
/* 211 */           if ((result instanceof Throwable)) {
/* 212 */             throw new NestedServletException("Async processing failed", (Throwable)result);
/*     */           }
/* 214 */           return result;
/*     */         }
/* 216 */       });
/* 217 */       setHandlerMethodReturnValueHandlers(ServletInvocableHandlerMethod.this.returnValueHandlers);
/* 218 */       this.returnType = returnType;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Class<?> getBeanType()
/*     */     {
/* 226 */       return ServletInvocableHandlerMethod.this.getBeanType();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public MethodParameter getReturnValueType(Object returnValue)
/*     */     {
/* 235 */       return this.returnType;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public <A extends Annotation> A getMethodAnnotation(Class<A> annotationType)
/*     */     {
/* 243 */       return ServletInvocableHandlerMethod.this.getMethodAnnotation(annotationType);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public <A extends Annotation> boolean hasMethodAnnotation(Class<A> annotationType)
/*     */     {
/* 251 */       return ServletInvocableHandlerMethod.this.hasMethodAnnotation(annotationType);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class ConcurrentResultMethodParameter
/*     */     extends HandlerMethod.HandlerMethodParameter
/*     */   {
/*     */     private final Object returnValue;
/*     */     
/*     */ 
/*     */     private final ResolvableType returnType;
/*     */     
/*     */ 
/*     */     public ConcurrentResultMethodParameter(Object returnValue)
/*     */     {
/* 268 */       super(-1);
/* 269 */       this.returnValue = returnValue;
/* 270 */       this.returnType = ResolvableType.forType(super.getGenericParameterType()).getGeneric(new int[] { 0 });
/*     */     }
/*     */     
/*     */     public ConcurrentResultMethodParameter(ConcurrentResultMethodParameter original) {
/* 274 */       super(original);
/* 275 */       this.returnValue = original.returnValue;
/* 276 */       this.returnType = original.returnType;
/*     */     }
/*     */     
/*     */     public Class<?> getParameterType()
/*     */     {
/* 281 */       if (this.returnValue != null) {
/* 282 */         return this.returnValue.getClass();
/*     */       }
/* 284 */       if (!ResolvableType.NONE.equals(this.returnType)) {
/* 285 */         return this.returnType.getRawClass();
/*     */       }
/* 287 */       return super.getParameterType();
/*     */     }
/*     */     
/*     */     public Type getGenericParameterType()
/*     */     {
/* 292 */       return this.returnType.getType();
/*     */     }
/*     */     
/*     */     public ConcurrentResultMethodParameter clone()
/*     */     {
/* 297 */       return new ConcurrentResultMethodParameter(ServletInvocableHandlerMethod.this, this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\method\annotation\ServletInvocableHandlerMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */