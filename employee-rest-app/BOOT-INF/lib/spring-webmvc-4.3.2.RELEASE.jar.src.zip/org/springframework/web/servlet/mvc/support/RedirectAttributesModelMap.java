/*     */ package org.springframework.web.servlet.mvc.support;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.validation.DataBinder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RedirectAttributesModelMap
/*     */   extends ModelMap
/*     */   implements RedirectAttributes
/*     */ {
/*     */   private final DataBinder dataBinder;
/*  39 */   private final ModelMap flashAttributes = new ModelMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public RedirectAttributesModelMap(DataBinder dataBinder)
/*     */   {
/*  46 */     this.dataBinder = dataBinder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public RedirectAttributesModelMap()
/*     */   {
/*  54 */     this(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, ?> getFlashAttributes()
/*     */   {
/*  62 */     return this.flashAttributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RedirectAttributesModelMap addAttribute(String attributeName, Object attributeValue)
/*     */   {
/*  71 */     super.addAttribute(attributeName, formatValue(attributeValue));
/*  72 */     return this;
/*     */   }
/*     */   
/*     */   private String formatValue(Object value) {
/*  76 */     if (value == null) {
/*  77 */       return null;
/*     */     }
/*  79 */     return this.dataBinder != null ? (String)this.dataBinder.convertIfNecessary(value, String.class) : value.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RedirectAttributesModelMap addAttribute(Object attributeValue)
/*     */   {
/*  88 */     super.addAttribute(attributeValue);
/*  89 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RedirectAttributesModelMap addAllAttributes(Collection<?> attributeValues)
/*     */   {
/*  98 */     super.addAllAttributes(attributeValues);
/*  99 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RedirectAttributesModelMap addAllAttributes(Map<String, ?> attributes)
/*     */   {
/* 108 */     if (attributes != null) {
/* 109 */       for (String key : attributes.keySet()) {
/* 110 */         addAttribute(key, attributes.get(key));
/*     */       }
/*     */     }
/* 113 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RedirectAttributesModelMap mergeAttributes(Map<String, ?> attributes)
/*     */   {
/* 122 */     if (attributes != null) {
/* 123 */       for (String key : attributes.keySet()) {
/* 124 */         if (!containsKey(key)) {
/* 125 */           addAttribute(key, attributes.get(key));
/*     */         }
/*     */       }
/*     */     }
/* 129 */     return this;
/*     */   }
/*     */   
/*     */   public Map<String, Object> asMap()
/*     */   {
/* 134 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object put(String key, Object value)
/*     */   {
/* 143 */     return super.put(key, formatValue(value));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void putAll(Map<? extends String, ? extends Object> map)
/*     */   {
/* 152 */     if (map != null) {
/* 153 */       for (String key : map.keySet()) {
/* 154 */         put(key, formatValue(map.get(key)));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public RedirectAttributes addFlashAttribute(String attributeName, Object attributeValue)
/*     */   {
/* 161 */     this.flashAttributes.addAttribute(attributeName, attributeValue);
/* 162 */     return this;
/*     */   }
/*     */   
/*     */   public RedirectAttributes addFlashAttribute(Object attributeValue)
/*     */   {
/* 167 */     this.flashAttributes.addAttribute(attributeValue);
/* 168 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\mvc\support\RedirectAttributesModelMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */