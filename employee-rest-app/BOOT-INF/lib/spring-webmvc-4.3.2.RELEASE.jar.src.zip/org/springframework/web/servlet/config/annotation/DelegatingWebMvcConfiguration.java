/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.validation.MessageCodesResolver;
/*     */ import org.springframework.validation.Validator;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.servlet.HandlerExceptionResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ public class DelegatingWebMvcConfiguration
/*     */   extends WebMvcConfigurationSupport
/*     */ {
/*  43 */   private final WebMvcConfigurerComposite configurers = new WebMvcConfigurerComposite();
/*     */   
/*     */   @Autowired(required=false)
/*     */   public void setConfigurers(List<WebMvcConfigurer> configurers)
/*     */   {
/*  48 */     if ((configurers == null) || (configurers.isEmpty())) {
/*  49 */       return;
/*     */     }
/*  51 */     this.configurers.addWebMvcConfigurers(configurers);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void addInterceptors(InterceptorRegistry registry)
/*     */   {
/*  57 */     this.configurers.addInterceptors(registry);
/*     */   }
/*     */   
/*     */   protected void configureContentNegotiation(ContentNegotiationConfigurer configurer)
/*     */   {
/*  62 */     this.configurers.configureContentNegotiation(configurer);
/*     */   }
/*     */   
/*     */   public void configureAsyncSupport(AsyncSupportConfigurer configurer)
/*     */   {
/*  67 */     this.configurers.configureAsyncSupport(configurer);
/*     */   }
/*     */   
/*     */   public void configurePathMatch(PathMatchConfigurer configurer)
/*     */   {
/*  72 */     this.configurers.configurePathMatch(configurer);
/*     */   }
/*     */   
/*     */   protected void addViewControllers(ViewControllerRegistry registry)
/*     */   {
/*  77 */     this.configurers.addViewControllers(registry);
/*     */   }
/*     */   
/*     */   protected void configureViewResolvers(ViewResolverRegistry registry)
/*     */   {
/*  82 */     this.configurers.configureViewResolvers(registry);
/*     */   }
/*     */   
/*     */   protected void addResourceHandlers(ResourceHandlerRegistry registry)
/*     */   {
/*  87 */     this.configurers.addResourceHandlers(registry);
/*     */   }
/*     */   
/*     */   protected void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer)
/*     */   {
/*  92 */     this.configurers.configureDefaultServletHandling(configurer);
/*     */   }
/*     */   
/*     */   protected void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers)
/*     */   {
/*  97 */     this.configurers.addArgumentResolvers(argumentResolvers);
/*     */   }
/*     */   
/*     */   protected void addReturnValueHandlers(List<HandlerMethodReturnValueHandler> returnValueHandlers)
/*     */   {
/* 102 */     this.configurers.addReturnValueHandlers(returnValueHandlers);
/*     */   }
/*     */   
/*     */   protected void configureMessageConverters(List<HttpMessageConverter<?>> converters)
/*     */   {
/* 107 */     this.configurers.configureMessageConverters(converters);
/*     */   }
/*     */   
/*     */   protected void extendMessageConverters(List<HttpMessageConverter<?>> converters)
/*     */   {
/* 112 */     this.configurers.extendMessageConverters(converters);
/*     */   }
/*     */   
/*     */   protected void addFormatters(FormatterRegistry registry)
/*     */   {
/* 117 */     this.configurers.addFormatters(registry);
/*     */   }
/*     */   
/*     */   protected Validator getValidator()
/*     */   {
/* 122 */     return this.configurers.getValidator();
/*     */   }
/*     */   
/*     */   protected MessageCodesResolver getMessageCodesResolver()
/*     */   {
/* 127 */     return this.configurers.getMessageCodesResolver();
/*     */   }
/*     */   
/*     */   protected void configureHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers)
/*     */   {
/* 132 */     this.configurers.configureHandlerExceptionResolvers(exceptionResolvers);
/*     */   }
/*     */   
/*     */   protected void addCorsMappings(CorsRegistry registry)
/*     */   {
/* 137 */     this.configurers.addCorsMappings(registry);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\config\annotation\DelegatingWebMvcConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */