/*     */ package org.springframework.web.servlet.view.script;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintWriter;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.script.Invocable;
/*     */ import javax.script.ScriptEngine;
/*     */ import javax.script.ScriptEngineManager;
/*     */ import javax.script.ScriptException;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.core.NamedThreadLocal;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.scripting.support.StandardScriptEvalException;
/*     */ import org.springframework.scripting.support.StandardScriptUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.view.AbstractUrlBasedView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScriptTemplateView
/*     */   extends AbstractUrlBasedView
/*     */ {
/*     */   public static final String DEFAULT_CONTENT_TYPE = "text/html";
/*  71 */   private static final Charset DEFAULT_CHARSET = Charset.forName("UTF-8");
/*     */   
/*     */ 
/*     */   private static final String DEFAULT_RESOURCE_LOADER_PATH = "classpath:";
/*     */   
/*  76 */   private static final ThreadLocal<Map<Object, ScriptEngine>> enginesHolder = new NamedThreadLocal("ScriptTemplateView engines");
/*     */   
/*     */ 
/*     */   private ScriptEngine engine;
/*     */   
/*     */ 
/*     */   private String engineName;
/*     */   
/*     */ 
/*     */   private Boolean sharedEngine;
/*     */   
/*     */ 
/*     */   private String[] scripts;
/*     */   
/*     */ 
/*     */   private String renderObject;
/*     */   
/*     */   private String renderFunction;
/*     */   
/*     */   private Charset charset;
/*     */   
/*     */   private String[] resourceLoaderPaths;
/*     */   
/*     */   private ResourceLoader resourceLoader;
/*     */   
/*     */   private volatile ScriptEngineManager scriptEngineManager;
/*     */   
/*     */ 
/*     */   public ScriptTemplateView()
/*     */   {
/* 106 */     setContentType(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ScriptTemplateView(String url)
/*     */   {
/* 114 */     super(url);
/* 115 */     setContentType(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEngine(ScriptEngine engine)
/*     */   {
/* 123 */     Assert.isInstanceOf(Invocable.class, engine);
/* 124 */     this.engine = engine;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setEngineName(String engineName)
/*     */   {
/* 131 */     this.engineName = engineName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setSharedEngine(Boolean sharedEngine)
/*     */   {
/* 138 */     this.sharedEngine = sharedEngine;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setScripts(String... scripts)
/*     */   {
/* 145 */     this.scripts = scripts;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setRenderObject(String renderObject)
/*     */   {
/* 152 */     this.renderObject = renderObject;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setRenderFunction(String functionName)
/*     */   {
/* 159 */     this.renderFunction = functionName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContentType(String contentType)
/*     */   {
/* 168 */     super.setContentType(contentType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setCharset(Charset charset)
/*     */   {
/* 175 */     this.charset = charset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setResourceLoaderPath(String resourceLoaderPath)
/*     */   {
/* 182 */     String[] paths = StringUtils.commaDelimitedListToStringArray(resourceLoaderPath);
/* 183 */     this.resourceLoaderPaths = new String[paths.length + 1];
/* 184 */     this.resourceLoaderPaths[0] = "";
/* 185 */     for (int i = 0; i < paths.length; i++) {
/* 186 */       String path = paths[i];
/* 187 */       if ((!path.endsWith("/")) && (!path.endsWith(":"))) {
/* 188 */         path = path + "/";
/*     */       }
/* 190 */       this.resourceLoaderPaths[(i + 1)] = path;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void initApplicationContext(ApplicationContext context)
/*     */   {
/* 197 */     super.initApplicationContext(context);
/*     */     
/* 199 */     ScriptTemplateConfig viewConfig = autodetectViewConfig();
/* 200 */     if ((this.engine == null) && (viewConfig.getEngine() != null)) {
/* 201 */       setEngine(viewConfig.getEngine());
/*     */     }
/* 203 */     if ((this.engineName == null) && (viewConfig.getEngineName() != null)) {
/* 204 */       this.engineName = viewConfig.getEngineName();
/*     */     }
/* 206 */     if ((this.scripts == null) && (viewConfig.getScripts() != null)) {
/* 207 */       this.scripts = viewConfig.getScripts();
/*     */     }
/* 209 */     if ((this.renderObject == null) && (viewConfig.getRenderObject() != null)) {
/* 210 */       this.renderObject = viewConfig.getRenderObject();
/*     */     }
/* 212 */     if ((this.renderFunction == null) && (viewConfig.getRenderFunction() != null)) {
/* 213 */       this.renderFunction = viewConfig.getRenderFunction();
/*     */     }
/* 215 */     if (getContentType() == null) {
/* 216 */       setContentType(viewConfig.getContentType() != null ? viewConfig.getContentType() : "text/html");
/*     */     }
/* 218 */     if (this.charset == null) {
/* 219 */       this.charset = (viewConfig.getCharset() != null ? viewConfig.getCharset() : DEFAULT_CHARSET);
/*     */     }
/* 221 */     if (this.resourceLoaderPaths == null) {
/* 222 */       String resourceLoaderPath = viewConfig.getResourceLoaderPath();
/* 223 */       setResourceLoaderPath(resourceLoaderPath == null ? "classpath:" : resourceLoaderPath);
/*     */     }
/* 225 */     if (this.resourceLoader == null) {
/* 226 */       this.resourceLoader = getApplicationContext();
/*     */     }
/* 228 */     if ((this.sharedEngine == null) && (viewConfig.isSharedEngine() != null)) {
/* 229 */       this.sharedEngine = viewConfig.isSharedEngine();
/*     */     }
/*     */     
/* 232 */     Assert.isTrue((this.engine == null) || (this.engineName == null), "You should define either 'engine' or 'engineName', not both.");
/*     */     
/* 234 */     Assert.isTrue((this.engine != null) || (this.engineName != null), "No script engine found, please specify either 'engine' or 'engineName'.");
/*     */     
/*     */ 
/* 237 */     if (Boolean.FALSE.equals(this.sharedEngine)) {
/* 238 */       Assert.isTrue(this.engineName != null, "When 'sharedEngine' is set to false, you should specify the script engine using the 'engineName' property, not the 'engine' one.");
/*     */ 
/*     */ 
/*     */     }
/* 242 */     else if (this.engine != null) {
/* 243 */       loadScripts(this.engine);
/*     */     }
/*     */     else {
/* 246 */       setEngine(createEngineFromName());
/*     */     }
/*     */     
/* 249 */     Assert.isTrue(this.renderFunction != null, "The 'renderFunction' property must be defined.");
/*     */   }
/*     */   
/*     */   protected ScriptEngine getEngine()
/*     */   {
/* 254 */     if (Boolean.FALSE.equals(this.sharedEngine)) {
/* 255 */       Map<Object, ScriptEngine> engines = (Map)enginesHolder.get();
/* 256 */       if (engines == null) {
/* 257 */         engines = new HashMap(4);
/* 258 */         enginesHolder.set(engines);
/*     */       }
/* 260 */       Object engineKey = !ObjectUtils.isEmpty(this.scripts) ? new EngineKey(this.engineName, this.scripts) : this.engineName;
/*     */       
/* 262 */       ScriptEngine engine = (ScriptEngine)engines.get(engineKey);
/* 263 */       if (engine == null) {
/* 264 */         engine = createEngineFromName();
/* 265 */         engines.put(engineKey, engine);
/*     */       }
/* 267 */       return engine;
/*     */     }
/*     */     
/*     */ 
/* 271 */     return this.engine;
/*     */   }
/*     */   
/*     */   protected ScriptEngine createEngineFromName()
/*     */   {
/* 276 */     if (this.scriptEngineManager == null) {
/* 277 */       this.scriptEngineManager = new ScriptEngineManager(getApplicationContext().getClassLoader());
/*     */     }
/*     */     
/* 280 */     ScriptEngine engine = StandardScriptUtils.retrieveEngineByName(this.scriptEngineManager, this.engineName);
/* 281 */     loadScripts(engine);
/* 282 */     return engine;
/*     */   }
/*     */   
/*     */   protected void loadScripts(ScriptEngine engine) {
/* 286 */     if (!ObjectUtils.isEmpty(this.scripts)) {
/*     */       try {
/* 288 */         for (String script : this.scripts) {
/* 289 */           Resource resource = getResource(script);
/* 290 */           engine.eval(new InputStreamReader(resource.getInputStream()));
/*     */         }
/*     */       }
/*     */       catch (Exception ex) {
/* 294 */         throw new IllegalStateException("Failed to load script", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected Resource getResource(String location) {
/* 300 */     for (String path : this.resourceLoaderPaths) {
/* 301 */       Resource resource = this.resourceLoader.getResource(path + location);
/* 302 */       if (resource.exists()) {
/* 303 */         return resource;
/*     */       }
/*     */     }
/* 306 */     throw new IllegalStateException("Resource [" + location + "] not found");
/*     */   }
/*     */   
/*     */   protected ScriptTemplateConfig autodetectViewConfig() throws BeansException {
/*     */     try {
/* 311 */       return (ScriptTemplateConfig)BeanFactoryUtils.beanOfTypeIncludingAncestors(
/* 312 */         getApplicationContext(), ScriptTemplateConfig.class, true, false);
/*     */     }
/*     */     catch (NoSuchBeanDefinitionException ex) {
/* 315 */       throw new ApplicationContextException("Expected a single ScriptTemplateConfig bean in the current Servlet web application context or the parent root context: ScriptTemplateConfigurer is the usual implementation. This bean may have any name.", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void prepareResponse(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 323 */     super.prepareResponse(request, response);
/*     */     
/* 325 */     setResponseContentType(request, response);
/* 326 */     response.setCharacterEncoding(this.charset.name());
/*     */   }
/*     */   
/*     */   protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 334 */       ScriptEngine engine = getEngine();
/* 335 */       Invocable invocable = (Invocable)engine;
/* 336 */       String url = getUrl();
/* 337 */       String template = getTemplate(url);
/*     */       Object html;
/*     */       Object html;
/* 340 */       if (this.renderObject != null) {
/* 341 */         Object thiz = engine.eval(this.renderObject);
/* 342 */         html = invocable.invokeMethod(thiz, this.renderFunction, new Object[] { template, model, url });
/*     */       }
/*     */       else {
/* 345 */         html = invocable.invokeFunction(this.renderFunction, new Object[] { template, model, url });
/*     */       }
/*     */       
/* 348 */       response.getWriter().write(String.valueOf(html));
/*     */     }
/*     */     catch (ScriptException ex) {
/* 351 */       throw new ServletException("Failed to render script template", new StandardScriptEvalException(ex));
/*     */     }
/*     */   }
/*     */   
/*     */   protected String getTemplate(String path) throws IOException {
/* 356 */     Resource resource = getResource(path);
/* 357 */     InputStreamReader reader = new InputStreamReader(resource.getInputStream(), this.charset);
/* 358 */     return FileCopyUtils.copyToString(reader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class EngineKey
/*     */   {
/*     */     private final String engineName;
/*     */     
/*     */ 
/*     */     private final String[] scripts;
/*     */     
/*     */ 
/*     */ 
/*     */     public EngineKey(String engineName, String[] scripts)
/*     */     {
/* 374 */       this.engineName = engineName;
/* 375 */       this.scripts = scripts;
/*     */     }
/*     */     
/*     */     public boolean equals(Object other)
/*     */     {
/* 380 */       if (this == other) {
/* 381 */         return true;
/*     */       }
/* 383 */       if (!(other instanceof EngineKey)) {
/* 384 */         return false;
/*     */       }
/* 386 */       EngineKey otherKey = (EngineKey)other;
/* 387 */       return (this.engineName.equals(otherKey.engineName)) && (Arrays.equals(this.scripts, otherKey.scripts));
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 392 */       return this.engineName.hashCode() * 29 + Arrays.hashCode(this.scripts);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\view\script\ScriptTemplateView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */