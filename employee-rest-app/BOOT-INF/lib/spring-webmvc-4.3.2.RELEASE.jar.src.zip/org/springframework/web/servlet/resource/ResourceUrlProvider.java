/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.event.ContextRefreshedEvent;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceUrlProvider
/*     */   implements ApplicationListener<ContextRefreshedEvent>
/*     */ {
/*  52 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  54 */   private UrlPathHelper urlPathHelper = new UrlPathHelper();
/*     */   
/*  56 */   private PathMatcher pathMatcher = new AntPathMatcher();
/*     */   
/*  58 */   private final Map<String, ResourceHttpRequestHandler> handlerMap = new LinkedHashMap();
/*     */   
/*  60 */   private boolean autodetect = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUrlPathHelper(UrlPathHelper urlPathHelper)
/*     */   {
/*  69 */     this.urlPathHelper = urlPathHelper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public UrlPathHelper getUrlPathHelper()
/*     */   {
/*  77 */     return this.urlPathHelper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public UrlPathHelper getPathHelper()
/*     */   {
/*  85 */     return this.urlPathHelper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPathMatcher(PathMatcher pathMatcher)
/*     */   {
/*  93 */     this.pathMatcher = pathMatcher;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PathMatcher getPathMatcher()
/*     */   {
/* 100 */     return this.pathMatcher;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHandlerMap(Map<String, ResourceHttpRequestHandler> handlerMap)
/*     */   {
/* 110 */     if (handlerMap != null) {
/* 111 */       this.handlerMap.clear();
/* 112 */       this.handlerMap.putAll(handlerMap);
/* 113 */       this.autodetect = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, ResourceHttpRequestHandler> getHandlerMap()
/*     */   {
/* 122 */     return this.handlerMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAutodetect()
/*     */   {
/* 130 */     return this.autodetect;
/*     */   }
/*     */   
/*     */   public void onApplicationEvent(ContextRefreshedEvent event)
/*     */   {
/* 135 */     if (isAutodetect()) {
/* 136 */       this.handlerMap.clear();
/* 137 */       detectResourceHandlers(event.getApplicationContext());
/* 138 */       if ((this.handlerMap.isEmpty()) && (this.logger.isDebugEnabled())) {
/* 139 */         this.logger.debug("No resource handling mappings found");
/*     */       }
/* 141 */       if (!this.handlerMap.isEmpty()) {
/* 142 */         this.autodetect = false;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void detectResourceHandlers(ApplicationContext appContext)
/*     */   {
/* 149 */     this.logger.debug("Looking for resource handler mappings");
/*     */     
/* 151 */     Map<String, SimpleUrlHandlerMapping> map = appContext.getBeansOfType(SimpleUrlHandlerMapping.class);
/* 152 */     List<SimpleUrlHandlerMapping> handlerMappings = new ArrayList(map.values());
/* 153 */     AnnotationAwareOrderComparator.sort(handlerMappings);
/*     */     
/* 155 */     for (Iterator localIterator1 = handlerMappings.iterator(); localIterator1.hasNext();) { hm = (SimpleUrlHandlerMapping)localIterator1.next();
/* 156 */       for (String pattern : hm.getHandlerMap().keySet()) {
/* 157 */         Object handler = hm.getHandlerMap().get(pattern);
/* 158 */         if ((handler instanceof ResourceHttpRequestHandler)) {
/* 159 */           ResourceHttpRequestHandler resourceHandler = (ResourceHttpRequestHandler)handler;
/* 160 */           if (this.logger.isDebugEnabled()) {
/* 161 */             this.logger.debug("Found resource handler mapping: URL pattern=\"" + pattern + "\", " + "locations=" + resourceHandler
/* 162 */               .getLocations() + ", " + "resolvers=" + resourceHandler
/* 163 */               .getResourceResolvers());
/*     */           }
/* 165 */           this.handlerMap.put(pattern, resourceHandler);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     SimpleUrlHandlerMapping hm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getForRequestUrl(HttpServletRequest request, String requestUrl)
/*     */   {
/* 180 */     if (this.logger.isTraceEnabled()) {
/* 181 */       this.logger.trace("Getting resource URL for request URL \"" + requestUrl + "\"");
/*     */     }
/* 183 */     int prefixIndex = getLookupPathIndex(request);
/* 184 */     int suffixIndex = getQueryParamsIndex(requestUrl);
/* 185 */     String prefix = requestUrl.substring(0, prefixIndex);
/* 186 */     String suffix = requestUrl.substring(suffixIndex);
/* 187 */     String lookupPath = requestUrl.substring(prefixIndex, suffixIndex);
/* 188 */     String resolvedLookupPath = getForLookupPath(lookupPath);
/* 189 */     return resolvedLookupPath != null ? prefix + resolvedLookupPath + suffix : null;
/*     */   }
/*     */   
/*     */   private int getLookupPathIndex(HttpServletRequest request) {
/* 193 */     UrlPathHelper pathHelper = getUrlPathHelper();
/* 194 */     String requestUri = pathHelper.getRequestUri(request);
/* 195 */     String lookupPath = pathHelper.getLookupPathForRequest(request);
/* 196 */     return requestUri.indexOf(lookupPath);
/*     */   }
/*     */   
/*     */   private int getQueryParamsIndex(String lookupPath) {
/* 200 */     int index = lookupPath.indexOf("?");
/* 201 */     return index > 0 ? index : lookupPath.length();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getForLookupPath(String lookupPath)
/*     */   {
/* 217 */     if (this.logger.isTraceEnabled()) {
/* 218 */       this.logger.trace("Getting resource URL for lookup path \"" + lookupPath + "\"");
/*     */     }
/*     */     
/* 221 */     List<String> matchingPatterns = new ArrayList();
/* 222 */     for (Iterator localIterator = this.handlerMap.keySet().iterator(); localIterator.hasNext();) { pattern = (String)localIterator.next();
/* 223 */       if (getPathMatcher().match(pattern, lookupPath)) {
/* 224 */         matchingPatterns.add(pattern);
/*     */       }
/*     */     }
/*     */     String pattern;
/* 228 */     if (!matchingPatterns.isEmpty()) {
/* 229 */       Object patternComparator = getPathMatcher().getPatternComparator(lookupPath);
/* 230 */       Collections.sort(matchingPatterns, (Comparator)patternComparator);
/* 231 */       for (String pattern : matchingPatterns) {
/* 232 */         String pathWithinMapping = getPathMatcher().extractPathWithinPattern(pattern, lookupPath);
/* 233 */         String pathMapping = lookupPath.substring(0, lookupPath.indexOf(pathWithinMapping));
/* 234 */         if (this.logger.isTraceEnabled()) {
/* 235 */           this.logger.trace("Invoking ResourceResolverChain for URL pattern \"" + pattern + "\"");
/*     */         }
/* 237 */         ResourceHttpRequestHandler handler = (ResourceHttpRequestHandler)this.handlerMap.get(pattern);
/* 238 */         ResourceResolverChain chain = new DefaultResourceResolverChain(handler.getResourceResolvers());
/* 239 */         String resolved = chain.resolveUrlPath(pathWithinMapping, handler.getLocations());
/* 240 */         if (resolved != null)
/*     */         {
/*     */ 
/* 243 */           if (this.logger.isTraceEnabled()) {
/* 244 */             this.logger.trace("Resolved public resource URL path \"" + resolved + "\"");
/*     */           }
/* 246 */           return pathMapping + resolved;
/*     */         }
/*     */       }
/*     */     }
/* 250 */     if (this.logger.isDebugEnabled()) {
/* 251 */       this.logger.debug("No matching resource mapping for lookup path \"" + lookupPath + "\"");
/*     */     }
/* 253 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\resource\ResourceUrlProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */