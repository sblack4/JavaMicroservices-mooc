/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.beans.factory.BeanInitializationException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.HttpRequestHandler;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.servlet.handler.AbstractHandlerMapping;
/*     */ import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
/*     */ import org.springframework.web.servlet.resource.ResourceHttpRequestHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceHandlerRegistry
/*     */ {
/*     */   private final ServletContext servletContext;
/*     */   private final ApplicationContext appContext;
/*     */   private final ContentNegotiationManager contentNegotiationManager;
/*  61 */   private final List<ResourceHandlerRegistration> registrations = new ArrayList();
/*     */   
/*  63 */   private int order = 2147483646;
/*     */   
/*     */   public ResourceHandlerRegistry(ApplicationContext applicationContext, ServletContext servletContext)
/*     */   {
/*  67 */     this(applicationContext, servletContext, null);
/*     */   }
/*     */   
/*     */   public ResourceHandlerRegistry(ApplicationContext applicationContext, ServletContext servletContext, ContentNegotiationManager contentNegotiationManager)
/*     */   {
/*  72 */     Assert.notNull(applicationContext, "ApplicationContext is required");
/*  73 */     this.appContext = applicationContext;
/*  74 */     this.servletContext = servletContext;
/*  75 */     this.contentNegotiationManager = contentNegotiationManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceHandlerRegistration addResourceHandler(String... pathPatterns)
/*     */   {
/*  85 */     ResourceHandlerRegistration registration = new ResourceHandlerRegistration(this.appContext, pathPatterns);
/*  86 */     this.registrations.add(registration);
/*  87 */     return registration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean hasMappingForPattern(String pathPattern)
/*     */   {
/*  94 */     for (ResourceHandlerRegistration registration : this.registrations) {
/*  95 */       if (Arrays.asList(registration.getPathPatterns()).contains(pathPattern)) {
/*  96 */         return true;
/*     */       }
/*     */     }
/*  99 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceHandlerRegistry setOrder(int order)
/*     */   {
/* 107 */     this.order = order;
/* 108 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected AbstractHandlerMapping getHandlerMapping()
/*     */   {
/* 115 */     if (this.registrations.isEmpty()) {
/* 116 */       return null;
/*     */     }
/*     */     
/* 119 */     Map<String, HttpRequestHandler> urlMap = new LinkedHashMap();
/* 120 */     for (ResourceHandlerRegistration registration : this.registrations) {
/* 121 */       for (String pathPattern : registration.getPathPatterns()) {
/* 122 */         ResourceHttpRequestHandler handler = registration.getRequestHandler();
/* 123 */         handler.setServletContext(this.servletContext);
/* 124 */         handler.setApplicationContext(this.appContext);
/* 125 */         handler.setContentNegotiationManager(this.contentNegotiationManager);
/*     */         try {
/* 127 */           handler.afterPropertiesSet();
/*     */         }
/*     */         catch (Exception e) {
/* 130 */           throw new BeanInitializationException("Failed to init ResourceHttpRequestHandler", e);
/*     */         }
/* 132 */         urlMap.put(pathPattern, handler);
/*     */       }
/*     */     }
/*     */     
/* 136 */     SimpleUrlHandlerMapping handlerMapping = new SimpleUrlHandlerMapping();
/* 137 */     handlerMapping.setOrder(this.order);
/* 138 */     handlerMapping.setUrlMap(urlMap);
/* 139 */     return handlerMapping;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\config\annotation\ResourceHandlerRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */