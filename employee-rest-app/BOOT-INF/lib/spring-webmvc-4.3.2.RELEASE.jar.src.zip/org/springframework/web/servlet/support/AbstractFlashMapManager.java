/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.FlashMap;
/*     */ import org.springframework.web.servlet.FlashMapManager;
/*     */ import org.springframework.web.util.UriComponents;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractFlashMapManager
/*     */   implements FlashMapManager
/*     */ {
/*  49 */   private static final Object DEFAULT_FLASH_MAPS_MUTEX = new Object();
/*     */   
/*     */ 
/*  52 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  54 */   private int flashMapTimeout = 180;
/*     */   
/*  56 */   private UrlPathHelper urlPathHelper = new UrlPathHelper();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFlashMapTimeout(int flashMapTimeout)
/*     */   {
/*  65 */     this.flashMapTimeout = flashMapTimeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getFlashMapTimeout()
/*     */   {
/*  72 */     return this.flashMapTimeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setUrlPathHelper(UrlPathHelper urlPathHelper)
/*     */   {
/*  79 */     Assert.notNull(urlPathHelper, "UrlPathHelper must not be null");
/*  80 */     this.urlPathHelper = urlPathHelper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public UrlPathHelper getUrlPathHelper()
/*     */   {
/*  87 */     return this.urlPathHelper;
/*     */   }
/*     */   
/*     */ 
/*     */   public final FlashMap retrieveAndUpdate(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  93 */     List<FlashMap> allFlashMaps = retrieveFlashMaps(request);
/*  94 */     if (CollectionUtils.isEmpty(allFlashMaps)) {
/*  95 */       return null;
/*     */     }
/*     */     
/*  98 */     if (this.logger.isDebugEnabled()) {
/*  99 */       this.logger.debug("Retrieved FlashMap(s): " + allFlashMaps);
/*     */     }
/* 101 */     List<FlashMap> mapsToRemove = getExpiredFlashMaps(allFlashMaps);
/* 102 */     FlashMap match = getMatchingFlashMap(allFlashMaps, request);
/* 103 */     if (match != null) {
/* 104 */       mapsToRemove.add(match);
/*     */     }
/*     */     
/* 107 */     if (!mapsToRemove.isEmpty()) {
/* 108 */       if (this.logger.isDebugEnabled()) {
/* 109 */         this.logger.debug("Removing FlashMap(s): " + mapsToRemove);
/*     */       }
/* 111 */       Object mutex = getFlashMapsMutex(request);
/* 112 */       if (mutex != null) {
/* 113 */         synchronized (mutex) {
/* 114 */           allFlashMaps = retrieveFlashMaps(request);
/* 115 */           if (allFlashMaps != null) {
/* 116 */             allFlashMaps.removeAll(mapsToRemove);
/* 117 */             updateFlashMaps(allFlashMaps, request, response);
/*     */           }
/*     */         }
/*     */       }
/*     */       else {
/* 122 */         allFlashMaps.removeAll(mapsToRemove);
/* 123 */         updateFlashMaps(allFlashMaps, request, response);
/*     */       }
/*     */     }
/*     */     
/* 127 */     return match;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private List<FlashMap> getExpiredFlashMaps(List<FlashMap> allMaps)
/*     */   {
/* 134 */     List<FlashMap> result = new LinkedList();
/* 135 */     for (FlashMap map : allMaps) {
/* 136 */       if (map.isExpired()) {
/* 137 */         result.add(map);
/*     */       }
/*     */     }
/* 140 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private FlashMap getMatchingFlashMap(List<FlashMap> allMaps, HttpServletRequest request)
/*     */   {
/* 148 */     List<FlashMap> result = new LinkedList();
/* 149 */     for (FlashMap flashMap : allMaps) {
/* 150 */       if (isFlashMapForRequest(flashMap, request)) {
/* 151 */         result.add(flashMap);
/*     */       }
/*     */     }
/* 154 */     if (!result.isEmpty()) {
/* 155 */       Collections.sort(result);
/* 156 */       if (this.logger.isDebugEnabled()) {
/* 157 */         this.logger.debug("Found matching FlashMap(s): " + result);
/*     */       }
/* 159 */       return (FlashMap)result.get(0);
/*     */     }
/* 161 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isFlashMapForRequest(FlashMap flashMap, HttpServletRequest request)
/*     */   {
/* 169 */     String expectedPath = flashMap.getTargetRequestPath();
/* 170 */     if (expectedPath != null) {
/* 171 */       String requestUri = getUrlPathHelper().getOriginatingRequestUri(request);
/* 172 */       if ((!requestUri.equals(expectedPath)) && (!requestUri.equals(expectedPath + "/"))) {
/* 173 */         return false;
/*     */       }
/*     */     }
/* 176 */     UriComponents uriComponents = ServletUriComponentsBuilder.fromRequest(request).build();
/* 177 */     MultiValueMap<String, String> actualParams = uriComponents.getQueryParams();
/* 178 */     MultiValueMap<String, String> expectedParams = flashMap.getTargetRequestParams();
/* 179 */     for (String expectedName : expectedParams.keySet()) {
/* 180 */       actualValues = (List)actualParams.get(expectedName);
/* 181 */       if (actualValues == null) {
/* 182 */         return false;
/*     */       }
/* 184 */       for (String expectedValue : (List)expectedParams.get(expectedName)) {
/* 185 */         if (!actualValues.contains(expectedValue))
/* 186 */           return false;
/*     */       }
/*     */     }
/*     */     List<String> actualValues;
/* 190 */     return true;
/*     */   }
/*     */   
/*     */   public final void saveOutputFlashMap(FlashMap flashMap, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 195 */     if (CollectionUtils.isEmpty(flashMap)) {
/* 196 */       return;
/*     */     }
/*     */     
/* 199 */     String path = decodeAndNormalizePath(flashMap.getTargetRequestPath(), request);
/* 200 */     flashMap.setTargetRequestPath(path);
/*     */     
/* 202 */     if (this.logger.isDebugEnabled()) {
/* 203 */       this.logger.debug("Saving FlashMap=" + flashMap);
/*     */     }
/* 205 */     flashMap.startExpirationPeriod(getFlashMapTimeout());
/*     */     
/* 207 */     Object mutex = getFlashMapsMutex(request);
/* 208 */     if (mutex != null) {
/* 209 */       synchronized (mutex) {
/* 210 */         List<FlashMap> allFlashMaps = retrieveFlashMaps(request);
/* 211 */         allFlashMaps = allFlashMaps != null ? allFlashMaps : new CopyOnWriteArrayList();
/* 212 */         allFlashMaps.add(flashMap);
/* 213 */         updateFlashMaps(allFlashMaps, request, response);
/*     */       }
/*     */     }
/*     */     else {
/* 217 */       List<FlashMap> allFlashMaps = retrieveFlashMaps(request);
/* 218 */       allFlashMaps = allFlashMaps != null ? allFlashMaps : new LinkedList();
/* 219 */       allFlashMaps.add(flashMap);
/* 220 */       updateFlashMaps(allFlashMaps, request, response);
/*     */     }
/*     */   }
/*     */   
/*     */   private String decodeAndNormalizePath(String path, HttpServletRequest request) {
/* 225 */     if (path != null) {
/* 226 */       path = getUrlPathHelper().decodeRequestString(request, path);
/* 227 */       if (path.charAt(0) != '/') {
/* 228 */         String requestUri = getUrlPathHelper().getRequestUri(request);
/* 229 */         path = requestUri.substring(0, requestUri.lastIndexOf('/') + 1) + path;
/* 230 */         path = StringUtils.cleanPath(path);
/*     */       }
/*     */     }
/* 233 */     return path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract List<FlashMap> retrieveFlashMaps(HttpServletRequest paramHttpServletRequest);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void updateFlashMaps(List<FlashMap> paramList, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object getFlashMapsMutex(HttpServletRequest request)
/*     */   {
/* 263 */     return DEFAULT_FLASH_MAPS_MUTEX;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\support\AbstractFlashMapManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */