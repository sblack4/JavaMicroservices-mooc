/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.http.CacheControl;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.servlet.resource.ResourceHttpRequestHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceHandlerRegistration
/*     */ {
/*     */   private final ResourceLoader resourceLoader;
/*     */   private final String[] pathPatterns;
/*  44 */   private final List<Resource> locations = new ArrayList();
/*     */   
/*     */ 
/*     */   private Integer cachePeriod;
/*     */   
/*     */ 
/*     */   private CacheControl cacheControl;
/*     */   
/*     */ 
/*     */   private ResourceChainRegistration resourceChainRegistration;
/*     */   
/*     */ 
/*     */ 
/*     */   public ResourceHandlerRegistration(ResourceLoader resourceLoader, String... pathPatterns)
/*     */   {
/*  59 */     Assert.notEmpty(pathPatterns, "At least one path pattern is required for resource handling.");
/*  60 */     this.resourceLoader = resourceLoader;
/*  61 */     this.pathPatterns = pathPatterns;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceHandlerRegistration addResourceLocations(String... resourceLocations)
/*     */   {
/*  75 */     for (String location : resourceLocations) {
/*  76 */       this.locations.add(this.resourceLoader.getResource(location));
/*     */     }
/*  78 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceHandlerRegistration setCachePeriod(Integer cachePeriod)
/*     */   {
/*  89 */     this.cachePeriod = cachePeriod;
/*  90 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceHandlerRegistration setCacheControl(CacheControl cacheControl)
/*     */   {
/* 104 */     this.cacheControl = cacheControl;
/* 105 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceChainRegistration resourceChain(boolean cacheResources)
/*     */   {
/* 123 */     this.resourceChainRegistration = new ResourceChainRegistration(cacheResources);
/* 124 */     return this.resourceChainRegistration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceChainRegistration resourceChain(boolean cacheResources, Cache cache)
/*     */   {
/* 147 */     this.resourceChainRegistration = new ResourceChainRegistration(cacheResources, cache);
/* 148 */     return this.resourceChainRegistration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String[] getPathPatterns()
/*     */   {
/* 155 */     return this.pathPatterns;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected ResourceHttpRequestHandler getRequestHandler()
/*     */   {
/* 162 */     ResourceHttpRequestHandler handler = new ResourceHttpRequestHandler();
/* 163 */     if (this.resourceChainRegistration != null) {
/* 164 */       handler.setResourceResolvers(this.resourceChainRegistration.getResourceResolvers());
/* 165 */       handler.setResourceTransformers(this.resourceChainRegistration.getResourceTransformers());
/*     */     }
/* 167 */     handler.setLocations(this.locations);
/* 168 */     if (this.cacheControl != null) {
/* 169 */       handler.setCacheControl(this.cacheControl);
/*     */     }
/* 171 */     else if (this.cachePeriod != null) {
/* 172 */       handler.setCacheSeconds(this.cachePeriod.intValue());
/*     */     }
/* 174 */     return handler;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\config\annotation\ResourceHandlerRegistration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */