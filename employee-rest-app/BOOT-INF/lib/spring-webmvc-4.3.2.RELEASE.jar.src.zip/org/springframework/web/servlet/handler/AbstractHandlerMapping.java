/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.web.HttpRequestHandler;
/*     */ import org.springframework.web.context.request.WebRequestInterceptor;
/*     */ import org.springframework.web.context.support.WebApplicationObjectSupport;
/*     */ import org.springframework.web.cors.CorsConfiguration;
/*     */ import org.springframework.web.cors.CorsConfigurationSource;
/*     */ import org.springframework.web.cors.CorsProcessor;
/*     */ import org.springframework.web.cors.CorsUtils;
/*     */ import org.springframework.web.cors.DefaultCorsProcessor;
/*     */ import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
/*     */ import org.springframework.web.servlet.HandlerExecutionChain;
/*     */ import org.springframework.web.servlet.HandlerInterceptor;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractHandlerMapping
/*     */   extends WebApplicationObjectSupport
/*     */   implements HandlerMapping, Ordered
/*     */ {
/*  70 */   private int order = Integer.MAX_VALUE;
/*     */   
/*     */   private Object defaultHandler;
/*     */   
/*  74 */   private UrlPathHelper urlPathHelper = new UrlPathHelper();
/*     */   
/*  76 */   private PathMatcher pathMatcher = new AntPathMatcher();
/*     */   
/*  78 */   private final List<Object> interceptors = new ArrayList();
/*     */   
/*  80 */   private final List<HandlerInterceptor> adaptedInterceptors = new ArrayList();
/*     */   
/*  82 */   private CorsProcessor corsProcessor = new DefaultCorsProcessor();
/*     */   
/*  84 */   private final UrlBasedCorsConfigurationSource corsConfigSource = new UrlBasedCorsConfigurationSource();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setOrder(int order)
/*     */   {
/*  93 */     this.order = order;
/*     */   }
/*     */   
/*     */   public final int getOrder()
/*     */   {
/*  98 */     return this.order;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultHandler(Object defaultHandler)
/*     */   {
/* 107 */     this.defaultHandler = defaultHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getDefaultHandler()
/*     */   {
/* 115 */     return this.defaultHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAlwaysUseFullPath(boolean alwaysUseFullPath)
/*     */   {
/* 126 */     this.urlPathHelper.setAlwaysUseFullPath(alwaysUseFullPath);
/* 127 */     this.corsConfigSource.setAlwaysUseFullPath(alwaysUseFullPath);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUrlDecode(boolean urlDecode)
/*     */   {
/* 138 */     this.urlPathHelper.setUrlDecode(urlDecode);
/* 139 */     this.corsConfigSource.setUrlDecode(urlDecode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemoveSemicolonContent(boolean removeSemicolonContent)
/*     */   {
/* 148 */     this.urlPathHelper.setRemoveSemicolonContent(removeSemicolonContent);
/* 149 */     this.corsConfigSource.setRemoveSemicolonContent(removeSemicolonContent);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUrlPathHelper(UrlPathHelper urlPathHelper)
/*     */   {
/* 159 */     Assert.notNull(urlPathHelper, "UrlPathHelper must not be null");
/* 160 */     this.urlPathHelper = urlPathHelper;
/* 161 */     this.corsConfigSource.setUrlPathHelper(urlPathHelper);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public UrlPathHelper getUrlPathHelper()
/*     */   {
/* 168 */     return this.urlPathHelper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPathMatcher(PathMatcher pathMatcher)
/*     */   {
/* 177 */     Assert.notNull(pathMatcher, "PathMatcher must not be null");
/* 178 */     this.pathMatcher = pathMatcher;
/* 179 */     this.corsConfigSource.setPathMatcher(pathMatcher);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PathMatcher getPathMatcher()
/*     */   {
/* 187 */     return this.pathMatcher;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInterceptors(Object[] interceptors)
/*     */   {
/* 201 */     this.interceptors.addAll(Arrays.asList(interceptors));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCorsProcessor(CorsProcessor corsProcessor)
/*     */   {
/* 211 */     Assert.notNull(corsProcessor, "CorsProcessor must not be null");
/* 212 */     this.corsProcessor = corsProcessor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CorsProcessor getCorsProcessor()
/*     */   {
/* 219 */     return this.corsProcessor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCorsConfigurations(Map<String, CorsConfiguration> corsConfigurations)
/*     */   {
/* 229 */     this.corsConfigSource.setCorsConfigurations(corsConfigurations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Map<String, CorsConfiguration> getCorsConfigurations()
/*     */   {
/* 236 */     return this.corsConfigSource.getCorsConfigurations();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initApplicationContext()
/*     */     throws BeansException
/*     */   {
/* 246 */     extendInterceptors(this.interceptors);
/* 247 */     detectMappedInterceptors(this.adaptedInterceptors);
/* 248 */     initInterceptors();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void extendInterceptors(List<Object> interceptors) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void detectMappedInterceptors(List<HandlerInterceptor> mappedInterceptors)
/*     */   {
/* 271 */     mappedInterceptors.addAll(
/* 272 */       BeanFactoryUtils.beansOfTypeIncludingAncestors(
/* 273 */       getApplicationContext(), MappedInterceptor.class, true, false).values());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initInterceptors()
/*     */   {
/* 283 */     if (!this.interceptors.isEmpty()) {
/* 284 */       for (int i = 0; i < this.interceptors.size(); i++) {
/* 285 */         Object interceptor = this.interceptors.get(i);
/* 286 */         if (interceptor == null) {
/* 287 */           throw new IllegalArgumentException("Entry number " + i + " in interceptors array is null");
/*     */         }
/* 289 */         this.adaptedInterceptors.add(adaptInterceptor(interceptor));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected HandlerInterceptor adaptInterceptor(Object interceptor)
/*     */   {
/* 307 */     if ((interceptor instanceof HandlerInterceptor)) {
/* 308 */       return (HandlerInterceptor)interceptor;
/*     */     }
/* 310 */     if ((interceptor instanceof WebRequestInterceptor)) {
/* 311 */       return new WebRequestHandlerInterceptorAdapter((WebRequestInterceptor)interceptor);
/*     */     }
/*     */     
/* 314 */     throw new IllegalArgumentException("Interceptor type not supported: " + interceptor.getClass().getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final HandlerInterceptor[] getAdaptedInterceptors()
/*     */   {
/* 323 */     int count = this.adaptedInterceptors.size();
/* 324 */     return count > 0 ? (HandlerInterceptor[])this.adaptedInterceptors.toArray(new HandlerInterceptor[count]) : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final MappedInterceptor[] getMappedInterceptors()
/*     */   {
/* 332 */     List<MappedInterceptor> mappedInterceptors = new ArrayList();
/* 333 */     for (HandlerInterceptor interceptor : this.adaptedInterceptors) {
/* 334 */       if ((interceptor instanceof MappedInterceptor)) {
/* 335 */         mappedInterceptors.add((MappedInterceptor)interceptor);
/*     */       }
/*     */     }
/* 338 */     int count = mappedInterceptors.size();
/* 339 */     return count > 0 ? (MappedInterceptor[])mappedInterceptors.toArray(new MappedInterceptor[count]) : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final HandlerExecutionChain getHandler(HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/* 351 */     Object handler = getHandlerInternal(request);
/* 352 */     if (handler == null) {
/* 353 */       handler = getDefaultHandler();
/*     */     }
/* 355 */     if (handler == null) {
/* 356 */       return null;
/*     */     }
/*     */     
/* 359 */     if ((handler instanceof String)) {
/* 360 */       String handlerName = (String)handler;
/* 361 */       handler = getApplicationContext().getBean(handlerName);
/*     */     }
/*     */     
/* 364 */     HandlerExecutionChain executionChain = getHandlerExecutionChain(handler, request);
/* 365 */     if (CorsUtils.isCorsRequest(request)) {
/* 366 */       CorsConfiguration globalConfig = this.corsConfigSource.getCorsConfiguration(request);
/* 367 */       CorsConfiguration handlerConfig = getCorsConfiguration(handler, request);
/* 368 */       CorsConfiguration config = globalConfig != null ? globalConfig.combine(handlerConfig) : handlerConfig;
/* 369 */       executionChain = getCorsHandlerExecutionChain(request, executionChain, config);
/*     */     }
/* 371 */     return executionChain;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract Object getHandlerInternal(HttpServletRequest paramHttpServletRequest)
/*     */     throws Exception;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected HandlerExecutionChain getHandlerExecutionChain(Object handler, HttpServletRequest request)
/*     */   {
/* 413 */     HandlerExecutionChain chain = (handler instanceof HandlerExecutionChain) ? (HandlerExecutionChain)handler : new HandlerExecutionChain(handler);
/*     */     
/*     */ 
/* 416 */     String lookupPath = this.urlPathHelper.getLookupPathForRequest(request);
/* 417 */     for (HandlerInterceptor interceptor : this.adaptedInterceptors) {
/* 418 */       if ((interceptor instanceof MappedInterceptor)) {
/* 419 */         MappedInterceptor mappedInterceptor = (MappedInterceptor)interceptor;
/* 420 */         if (mappedInterceptor.matches(lookupPath, this.pathMatcher)) {
/* 421 */           chain.addInterceptor(mappedInterceptor.getInterceptor());
/*     */         }
/*     */       }
/*     */       else {
/* 425 */         chain.addInterceptor(interceptor);
/*     */       }
/*     */     }
/* 428 */     return chain;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected CorsConfiguration getCorsConfiguration(Object handler, HttpServletRequest request)
/*     */   {
/* 439 */     if ((handler instanceof HandlerExecutionChain)) {
/* 440 */       handler = ((HandlerExecutionChain)handler).getHandler();
/*     */     }
/* 442 */     if ((handler instanceof CorsConfigurationSource)) {
/* 443 */       return ((CorsConfigurationSource)handler).getCorsConfiguration(request);
/*     */     }
/* 445 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected HandlerExecutionChain getCorsHandlerExecutionChain(HttpServletRequest request, HandlerExecutionChain chain, CorsConfiguration config)
/*     */   {
/* 463 */     if (CorsUtils.isPreFlightRequest(request)) {
/* 464 */       HandlerInterceptor[] interceptors = chain.getInterceptors();
/* 465 */       chain = new HandlerExecutionChain(new PreFlightHandler(config), interceptors);
/*     */     }
/*     */     else {
/* 468 */       chain.addInterceptor(new CorsInterceptor(config));
/*     */     }
/* 470 */     return chain;
/*     */   }
/*     */   
/*     */   private class PreFlightHandler implements HttpRequestHandler, CorsConfigurationSource
/*     */   {
/*     */     private final CorsConfiguration config;
/*     */     
/*     */     public PreFlightHandler(CorsConfiguration config)
/*     */     {
/* 479 */       this.config = config;
/*     */     }
/*     */     
/*     */ 
/*     */     public void handleRequest(HttpServletRequest request, HttpServletResponse response)
/*     */       throws IOException
/*     */     {
/* 486 */       AbstractHandlerMapping.this.corsProcessor.processRequest(this.config, request, response);
/*     */     }
/*     */     
/*     */     public CorsConfiguration getCorsConfiguration(HttpServletRequest request)
/*     */     {
/* 491 */       return this.config;
/*     */     }
/*     */   }
/*     */   
/*     */   private class CorsInterceptor extends HandlerInterceptorAdapter implements CorsConfigurationSource
/*     */   {
/*     */     private final CorsConfiguration config;
/*     */     
/*     */     public CorsInterceptor(CorsConfiguration config)
/*     */     {
/* 501 */       this.config = config;
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */       throws Exception
/*     */     {
/* 508 */       return AbstractHandlerMapping.this.corsProcessor.processRequest(this.config, request, response);
/*     */     }
/*     */     
/*     */     public CorsConfiguration getCorsConfiguration(HttpServletRequest request)
/*     */     {
/* 513 */       return this.config;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\handler\AbstractHandlerMapping.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */