/*     */ package org.springframework.web.servlet.config;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.BeanReference;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.format.support.FormattingConversionServiceFactoryBean;
/*     */ import org.springframework.http.converter.ByteArrayHttpMessageConverter;
/*     */ import org.springframework.http.converter.ResourceHttpMessageConverter;
/*     */ import org.springframework.http.converter.StringHttpMessageConverter;
/*     */ import org.springframework.http.converter.feed.AtomFeedHttpMessageConverter;
/*     */ import org.springframework.http.converter.feed.RssChannelHttpMessageConverter;
/*     */ import org.springframework.http.converter.json.GsonHttpMessageConverter;
/*     */ import org.springframework.http.converter.json.Jackson2ObjectMapperFactoryBean;
/*     */ import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
/*     */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.MappingJackson2XmlHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.SourceHttpMessageConverter;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.springframework.web.accept.ContentNegotiationManagerFactoryBean;
/*     */ import org.springframework.web.bind.support.ConfigurableWebBindingInitializer;
/*     */ import org.springframework.web.bind.support.WebArgumentResolver;
/*     */ import org.springframework.web.method.support.CompositeUriComponentsContributor;
/*     */ import org.springframework.web.servlet.handler.ConversionServiceExposingInterceptor;
/*     */ import org.springframework.web.servlet.handler.MappedInterceptor;
/*     */ import org.springframework.web.servlet.mvc.annotation.ResponseStatusExceptionResolver;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.ExceptionHandlerExceptionResolver;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.JsonViewRequestBodyAdvice;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.JsonViewResponseBodyAdvice;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.ServletWebArgumentResolverAdapter;
/*     */ import org.springframework.web.servlet.mvc.support.DefaultHandlerExceptionResolver;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AnnotationDrivenBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/* 152 */   public static final String HANDLER_MAPPING_BEAN_NAME = RequestMappingHandlerMapping.class.getName();
/*     */   
/* 154 */   public static final String HANDLER_ADAPTER_BEAN_NAME = RequestMappingHandlerAdapter.class.getName();
/*     */   
/*     */ 
/*     */   public static final String CONTENT_NEGOTIATION_MANAGER_BEAN_NAME = "mvcContentNegotiationManager";
/*     */   
/* 159 */   private static final boolean javaxValidationPresent = ClassUtils.isPresent("javax.validation.Validator", AnnotationDrivenBeanDefinitionParser.class.getClassLoader());
/*     */   
/*     */ 
/* 162 */   private static boolean romePresent = ClassUtils.isPresent("com.rometools.rome.feed.WireFeed", AnnotationDrivenBeanDefinitionParser.class.getClassLoader());
/*     */   
/*     */ 
/* 165 */   private static final boolean jaxb2Present = ClassUtils.isPresent("javax.xml.bind.Binder", AnnotationDrivenBeanDefinitionParser.class.getClassLoader());
/*     */   
/*     */ 
/* 168 */   private static final boolean jackson2Present = (ClassUtils.isPresent("com.fasterxml.jackson.databind.ObjectMapper", AnnotationDrivenBeanDefinitionParser.class.getClassLoader())) && 
/* 169 */     (ClassUtils.isPresent("com.fasterxml.jackson.core.JsonGenerator", AnnotationDrivenBeanDefinitionParser.class.getClassLoader()));
/*     */   
/*     */ 
/* 172 */   private static final boolean jackson2XmlPresent = ClassUtils.isPresent("com.fasterxml.jackson.dataformat.xml.XmlMapper", AnnotationDrivenBeanDefinitionParser.class.getClassLoader());
/*     */   
/*     */ 
/* 175 */   private static final boolean gsonPresent = ClassUtils.isPresent("com.google.gson.Gson", AnnotationDrivenBeanDefinitionParser.class.getClassLoader());
/*     */   
/*     */ 
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext)
/*     */   {
/* 180 */     Object source = parserContext.extractSource(element);
/* 181 */     XmlReaderContext readerContext = parserContext.getReaderContext();
/*     */     
/* 183 */     CompositeComponentDefinition compDefinition = new CompositeComponentDefinition(element.getTagName(), source);
/* 184 */     parserContext.pushContainingComponent(compDefinition);
/*     */     
/* 186 */     RuntimeBeanReference contentNegotiationManager = getContentNegotiationManager(element, source, parserContext);
/*     */     
/* 188 */     RootBeanDefinition handlerMappingDef = new RootBeanDefinition(RequestMappingHandlerMapping.class);
/* 189 */     handlerMappingDef.setSource(source);
/* 190 */     handlerMappingDef.setRole(2);
/* 191 */     handlerMappingDef.getPropertyValues().add("order", Integer.valueOf(0));
/* 192 */     handlerMappingDef.getPropertyValues().add("contentNegotiationManager", contentNegotiationManager);
/*     */     
/* 194 */     if (element.hasAttribute("enable-matrix-variables")) {
/* 195 */       Boolean enableMatrixVariables = Boolean.valueOf(element.getAttribute("enable-matrix-variables"));
/* 196 */       handlerMappingDef.getPropertyValues().add("removeSemicolonContent", Boolean.valueOf(!enableMatrixVariables.booleanValue()));
/*     */     }
/* 198 */     else if (element.hasAttribute("enableMatrixVariables")) {
/* 199 */       Boolean enableMatrixVariables = Boolean.valueOf(element.getAttribute("enableMatrixVariables"));
/* 200 */       handlerMappingDef.getPropertyValues().add("removeSemicolonContent", Boolean.valueOf(!enableMatrixVariables.booleanValue()));
/*     */     }
/*     */     
/* 203 */     configurePathMatchingProperties(handlerMappingDef, element, parserContext);
/* 204 */     readerContext.getRegistry().registerBeanDefinition(HANDLER_MAPPING_BEAN_NAME, handlerMappingDef);
/*     */     
/* 206 */     RuntimeBeanReference corsConfigurationsRef = MvcNamespaceUtils.registerCorsConfigurations(null, parserContext, source);
/* 207 */     handlerMappingDef.getPropertyValues().add("corsConfigurations", corsConfigurationsRef);
/*     */     
/* 209 */     RuntimeBeanReference conversionService = getConversionService(element, source, parserContext);
/* 210 */     RuntimeBeanReference validator = getValidator(element, source, parserContext);
/* 211 */     RuntimeBeanReference messageCodesResolver = getMessageCodesResolver(element);
/*     */     
/* 213 */     RootBeanDefinition bindingDef = new RootBeanDefinition(ConfigurableWebBindingInitializer.class);
/* 214 */     bindingDef.setSource(source);
/* 215 */     bindingDef.setRole(2);
/* 216 */     bindingDef.getPropertyValues().add("conversionService", conversionService);
/* 217 */     bindingDef.getPropertyValues().add("validator", validator);
/* 218 */     bindingDef.getPropertyValues().add("messageCodesResolver", messageCodesResolver);
/*     */     
/* 220 */     ManagedList<?> messageConverters = getMessageConverters(element, source, parserContext);
/* 221 */     ManagedList<?> argumentResolvers = getArgumentResolvers(element, parserContext);
/* 222 */     ManagedList<?> returnValueHandlers = getReturnValueHandlers(element, parserContext);
/* 223 */     String asyncTimeout = getAsyncTimeout(element);
/* 224 */     RuntimeBeanReference asyncExecutor = getAsyncExecutor(element);
/* 225 */     ManagedList<?> callableInterceptors = getCallableInterceptors(element, source, parserContext);
/* 226 */     ManagedList<?> deferredResultInterceptors = getDeferredResultInterceptors(element, source, parserContext);
/*     */     
/* 228 */     RootBeanDefinition handlerAdapterDef = new RootBeanDefinition(RequestMappingHandlerAdapter.class);
/* 229 */     handlerAdapterDef.setSource(source);
/* 230 */     handlerAdapterDef.setRole(2);
/* 231 */     handlerAdapterDef.getPropertyValues().add("contentNegotiationManager", contentNegotiationManager);
/* 232 */     handlerAdapterDef.getPropertyValues().add("webBindingInitializer", bindingDef);
/* 233 */     handlerAdapterDef.getPropertyValues().add("messageConverters", messageConverters);
/* 234 */     addRequestBodyAdvice(handlerAdapterDef);
/* 235 */     addResponseBodyAdvice(handlerAdapterDef);
/*     */     
/* 237 */     if (element.hasAttribute("ignore-default-model-on-redirect")) {
/* 238 */       Boolean ignoreDefaultModel = Boolean.valueOf(element.getAttribute("ignore-default-model-on-redirect"));
/* 239 */       handlerAdapterDef.getPropertyValues().add("ignoreDefaultModelOnRedirect", ignoreDefaultModel);
/*     */     }
/* 241 */     else if (element.hasAttribute("ignoreDefaultModelOnRedirect"))
/*     */     {
/* 243 */       Boolean ignoreDefaultModel = Boolean.valueOf(element.getAttribute("ignoreDefaultModelOnRedirect"));
/* 244 */       handlerAdapterDef.getPropertyValues().add("ignoreDefaultModelOnRedirect", ignoreDefaultModel);
/*     */     }
/*     */     
/* 247 */     if (argumentResolvers != null) {
/* 248 */       handlerAdapterDef.getPropertyValues().add("customArgumentResolvers", argumentResolvers);
/*     */     }
/* 250 */     if (returnValueHandlers != null) {
/* 251 */       handlerAdapterDef.getPropertyValues().add("customReturnValueHandlers", returnValueHandlers);
/*     */     }
/* 253 */     if (asyncTimeout != null) {
/* 254 */       handlerAdapterDef.getPropertyValues().add("asyncRequestTimeout", asyncTimeout);
/*     */     }
/* 256 */     if (asyncExecutor != null) {
/* 257 */       handlerAdapterDef.getPropertyValues().add("taskExecutor", asyncExecutor);
/*     */     }
/*     */     
/* 260 */     handlerAdapterDef.getPropertyValues().add("callableInterceptors", callableInterceptors);
/* 261 */     handlerAdapterDef.getPropertyValues().add("deferredResultInterceptors", deferredResultInterceptors);
/* 262 */     readerContext.getRegistry().registerBeanDefinition(HANDLER_ADAPTER_BEAN_NAME, handlerAdapterDef);
/*     */     
/* 264 */     String uriCompContribName = "mvcUriComponentsContributor";
/* 265 */     RootBeanDefinition uriCompContribDef = new RootBeanDefinition(CompositeUriComponentsContributorFactoryBean.class);
/* 266 */     uriCompContribDef.setSource(source);
/* 267 */     uriCompContribDef.getPropertyValues().addPropertyValue("handlerAdapter", handlerAdapterDef);
/* 268 */     uriCompContribDef.getPropertyValues().addPropertyValue("conversionService", conversionService);
/* 269 */     readerContext.getRegistry().registerBeanDefinition(uriCompContribName, uriCompContribDef);
/*     */     
/* 271 */     RootBeanDefinition csInterceptorDef = new RootBeanDefinition(ConversionServiceExposingInterceptor.class);
/* 272 */     csInterceptorDef.setSource(source);
/* 273 */     csInterceptorDef.getConstructorArgumentValues().addIndexedArgumentValue(0, conversionService);
/* 274 */     RootBeanDefinition mappedCsInterceptorDef = new RootBeanDefinition(MappedInterceptor.class);
/* 275 */     mappedCsInterceptorDef.setSource(source);
/* 276 */     mappedCsInterceptorDef.setRole(2);
/* 277 */     mappedCsInterceptorDef.getConstructorArgumentValues().addIndexedArgumentValue(0, null);
/* 278 */     mappedCsInterceptorDef.getConstructorArgumentValues().addIndexedArgumentValue(1, csInterceptorDef);
/* 279 */     String mappedInterceptorName = readerContext.registerWithGeneratedName(mappedCsInterceptorDef);
/*     */     
/* 281 */     RootBeanDefinition exceptionHandlerExceptionResolver = new RootBeanDefinition(ExceptionHandlerExceptionResolver.class);
/* 282 */     exceptionHandlerExceptionResolver.setSource(source);
/* 283 */     exceptionHandlerExceptionResolver.setRole(2);
/* 284 */     exceptionHandlerExceptionResolver.getPropertyValues().add("contentNegotiationManager", contentNegotiationManager);
/* 285 */     exceptionHandlerExceptionResolver.getPropertyValues().add("messageConverters", messageConverters);
/* 286 */     exceptionHandlerExceptionResolver.getPropertyValues().add("order", Integer.valueOf(0));
/* 287 */     addResponseBodyAdvice(exceptionHandlerExceptionResolver);
/*     */     
/* 289 */     if (argumentResolvers != null) {
/* 290 */       exceptionHandlerExceptionResolver.getPropertyValues().add("customArgumentResolvers", argumentResolvers);
/*     */     }
/* 292 */     if (returnValueHandlers != null) {
/* 293 */       exceptionHandlerExceptionResolver.getPropertyValues().add("customReturnValueHandlers", returnValueHandlers);
/*     */     }
/*     */     
/* 296 */     String methodExceptionResolverName = readerContext.registerWithGeneratedName(exceptionHandlerExceptionResolver);
/*     */     
/* 298 */     RootBeanDefinition responseStatusExceptionResolver = new RootBeanDefinition(ResponseStatusExceptionResolver.class);
/* 299 */     responseStatusExceptionResolver.setSource(source);
/* 300 */     responseStatusExceptionResolver.setRole(2);
/* 301 */     responseStatusExceptionResolver.getPropertyValues().add("order", Integer.valueOf(1));
/*     */     
/* 303 */     String responseStatusExceptionResolverName = readerContext.registerWithGeneratedName(responseStatusExceptionResolver);
/*     */     
/* 305 */     RootBeanDefinition defaultExceptionResolver = new RootBeanDefinition(DefaultHandlerExceptionResolver.class);
/* 306 */     defaultExceptionResolver.setSource(source);
/* 307 */     defaultExceptionResolver.setRole(2);
/* 308 */     defaultExceptionResolver.getPropertyValues().add("order", Integer.valueOf(2));
/*     */     
/* 310 */     String defaultExceptionResolverName = readerContext.registerWithGeneratedName(defaultExceptionResolver);
/*     */     
/* 312 */     parserContext.registerComponent(new BeanComponentDefinition(handlerMappingDef, HANDLER_MAPPING_BEAN_NAME));
/* 313 */     parserContext.registerComponent(new BeanComponentDefinition(handlerAdapterDef, HANDLER_ADAPTER_BEAN_NAME));
/* 314 */     parserContext.registerComponent(new BeanComponentDefinition(uriCompContribDef, uriCompContribName));
/* 315 */     parserContext.registerComponent(new BeanComponentDefinition(exceptionHandlerExceptionResolver, methodExceptionResolverName));
/* 316 */     parserContext.registerComponent(new BeanComponentDefinition(responseStatusExceptionResolver, responseStatusExceptionResolverName));
/* 317 */     parserContext.registerComponent(new BeanComponentDefinition(defaultExceptionResolver, defaultExceptionResolverName));
/* 318 */     parserContext.registerComponent(new BeanComponentDefinition(mappedCsInterceptorDef, mappedInterceptorName));
/*     */     
/*     */ 
/* 321 */     MvcNamespaceUtils.registerDefaultComponents(parserContext, source);
/*     */     
/* 323 */     parserContext.popAndRegisterContainingComponent();
/*     */     
/* 325 */     return null;
/*     */   }
/*     */   
/*     */   protected void addRequestBodyAdvice(RootBeanDefinition beanDef) {
/* 329 */     if (jackson2Present) {
/* 330 */       beanDef.getPropertyValues().add("requestBodyAdvice", new RootBeanDefinition(JsonViewRequestBodyAdvice.class));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addResponseBodyAdvice(RootBeanDefinition beanDef)
/*     */   {
/* 336 */     if (jackson2Present) {
/* 337 */       beanDef.getPropertyValues().add("responseBodyAdvice", new RootBeanDefinition(JsonViewResponseBodyAdvice.class));
/*     */     }
/*     */   }
/*     */   
/*     */   private RuntimeBeanReference getConversionService(Element element, Object source, ParserContext parserContext) {
/*     */     RuntimeBeanReference conversionServiceRef;
/*     */     RuntimeBeanReference conversionServiceRef;
/* 344 */     if (element.hasAttribute("conversion-service")) {
/* 345 */       conversionServiceRef = new RuntimeBeanReference(element.getAttribute("conversion-service"));
/*     */     }
/*     */     else {
/* 348 */       RootBeanDefinition conversionDef = new RootBeanDefinition(FormattingConversionServiceFactoryBean.class);
/* 349 */       conversionDef.setSource(source);
/* 350 */       conversionDef.setRole(2);
/* 351 */       String conversionName = parserContext.getReaderContext().registerWithGeneratedName(conversionDef);
/* 352 */       parserContext.registerComponent(new BeanComponentDefinition(conversionDef, conversionName));
/* 353 */       conversionServiceRef = new RuntimeBeanReference(conversionName);
/*     */     }
/* 355 */     return conversionServiceRef;
/*     */   }
/*     */   
/*     */   private RuntimeBeanReference getValidator(Element element, Object source, ParserContext parserContext) {
/* 359 */     if (element.hasAttribute("validator")) {
/* 360 */       return new RuntimeBeanReference(element.getAttribute("validator"));
/*     */     }
/* 362 */     if (javaxValidationPresent) {
/* 363 */       RootBeanDefinition validatorDef = new RootBeanDefinition("org.springframework.validation.beanvalidation.OptionalValidatorFactoryBean");
/*     */       
/* 365 */       validatorDef.setSource(source);
/* 366 */       validatorDef.setRole(2);
/* 367 */       String validatorName = parserContext.getReaderContext().registerWithGeneratedName(validatorDef);
/* 368 */       parserContext.registerComponent(new BeanComponentDefinition(validatorDef, validatorName));
/* 369 */       return new RuntimeBeanReference(validatorName);
/*     */     }
/*     */     
/* 372 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   private RuntimeBeanReference getContentNegotiationManager(Element element, Object source, ParserContext parserContext)
/*     */   {
/*     */     RuntimeBeanReference beanRef;
/*     */     RuntimeBeanReference beanRef;
/* 380 */     if (element.hasAttribute("content-negotiation-manager")) {
/* 381 */       String name = element.getAttribute("content-negotiation-manager");
/* 382 */       beanRef = new RuntimeBeanReference(name);
/*     */     }
/*     */     else {
/* 385 */       RootBeanDefinition factoryBeanDef = new RootBeanDefinition(ContentNegotiationManagerFactoryBean.class);
/* 386 */       factoryBeanDef.setSource(source);
/* 387 */       factoryBeanDef.setRole(2);
/* 388 */       factoryBeanDef.getPropertyValues().add("mediaTypes", getDefaultMediaTypes());
/*     */       
/* 390 */       String name = "mvcContentNegotiationManager";
/* 391 */       parserContext.getReaderContext().getRegistry().registerBeanDefinition(name, factoryBeanDef);
/* 392 */       parserContext.registerComponent(new BeanComponentDefinition(factoryBeanDef, name));
/* 393 */       beanRef = new RuntimeBeanReference(name);
/*     */     }
/* 395 */     return beanRef;
/*     */   }
/*     */   
/*     */ 
/*     */   private void configurePathMatchingProperties(RootBeanDefinition handlerMappingDef, Element element, ParserContext parserContext)
/*     */   {
/* 401 */     Element pathMatchingElement = DomUtils.getChildElementByTagName(element, "path-matching");
/* 402 */     if (pathMatchingElement != null) {
/* 403 */       Object source = parserContext.extractSource(element);
/* 404 */       if (pathMatchingElement.hasAttribute("suffix-pattern")) {
/* 405 */         Boolean useSuffixPatternMatch = Boolean.valueOf(pathMatchingElement.getAttribute("suffix-pattern"));
/* 406 */         handlerMappingDef.getPropertyValues().add("useSuffixPatternMatch", useSuffixPatternMatch);
/*     */       }
/* 408 */       if (pathMatchingElement.hasAttribute("trailing-slash")) {
/* 409 */         Boolean useTrailingSlashMatch = Boolean.valueOf(pathMatchingElement.getAttribute("trailing-slash"));
/* 410 */         handlerMappingDef.getPropertyValues().add("useTrailingSlashMatch", useTrailingSlashMatch);
/*     */       }
/* 412 */       if (pathMatchingElement.hasAttribute("registered-suffixes-only")) {
/* 413 */         Boolean useRegisteredSuffixPatternMatch = Boolean.valueOf(pathMatchingElement.getAttribute("registered-suffixes-only"));
/* 414 */         handlerMappingDef.getPropertyValues().add("useRegisteredSuffixPatternMatch", useRegisteredSuffixPatternMatch);
/*     */       }
/* 416 */       RuntimeBeanReference pathHelperRef = null;
/* 417 */       if (pathMatchingElement.hasAttribute("path-helper")) {
/* 418 */         pathHelperRef = new RuntimeBeanReference(pathMatchingElement.getAttribute("path-helper"));
/*     */       }
/* 420 */       pathHelperRef = MvcNamespaceUtils.registerUrlPathHelper(pathHelperRef, parserContext, source);
/* 421 */       handlerMappingDef.getPropertyValues().add("urlPathHelper", pathHelperRef);
/*     */       
/* 423 */       RuntimeBeanReference pathMatcherRef = null;
/* 424 */       if (pathMatchingElement.hasAttribute("path-matcher")) {
/* 425 */         pathMatcherRef = new RuntimeBeanReference(pathMatchingElement.getAttribute("path-matcher"));
/*     */       }
/* 427 */       pathMatcherRef = MvcNamespaceUtils.registerPathMatcher(pathMatcherRef, parserContext, source);
/* 428 */       handlerMappingDef.getPropertyValues().add("pathMatcher", pathMatcherRef);
/*     */     }
/*     */   }
/*     */   
/*     */   private Properties getDefaultMediaTypes() {
/* 433 */     Properties props = new Properties();
/* 434 */     if (romePresent) {
/* 435 */       props.put("atom", "application/atom+xml");
/* 436 */       props.put("rss", "application/rss+xml");
/*     */     }
/* 438 */     if ((jaxb2Present) || (jackson2XmlPresent)) {
/* 439 */       props.put("xml", "application/xml");
/*     */     }
/* 441 */     if ((jackson2Present) || (gsonPresent)) {
/* 442 */       props.put("json", "application/json");
/*     */     }
/* 444 */     return props;
/*     */   }
/*     */   
/*     */   private RuntimeBeanReference getMessageCodesResolver(Element element) {
/* 448 */     if (element.hasAttribute("message-codes-resolver")) {
/* 449 */       return new RuntimeBeanReference(element.getAttribute("message-codes-resolver"));
/*     */     }
/*     */     
/* 452 */     return null;
/*     */   }
/*     */   
/*     */   private String getAsyncTimeout(Element element)
/*     */   {
/* 457 */     Element asyncElement = DomUtils.getChildElementByTagName(element, "async-support");
/* 458 */     return asyncElement != null ? asyncElement.getAttribute("default-timeout") : null;
/*     */   }
/*     */   
/*     */   private RuntimeBeanReference getAsyncExecutor(Element element) {
/* 462 */     Element asyncElement = DomUtils.getChildElementByTagName(element, "async-support");
/* 463 */     if ((asyncElement != null) && 
/* 464 */       (asyncElement.hasAttribute("task-executor"))) {
/* 465 */       return new RuntimeBeanReference(asyncElement.getAttribute("task-executor"));
/*     */     }
/*     */     
/* 468 */     return null;
/*     */   }
/*     */   
/*     */   private ManagedList<?> getCallableInterceptors(Element element, Object source, ParserContext parserContext) {
/* 472 */     ManagedList<? super Object> interceptors = new ManagedList();
/* 473 */     Element asyncElement = DomUtils.getChildElementByTagName(element, "async-support");
/* 474 */     if (asyncElement != null) {
/* 475 */       Element interceptorsElement = DomUtils.getChildElementByTagName(asyncElement, "callable-interceptors");
/* 476 */       if (interceptorsElement != null) {
/* 477 */         interceptors.setSource(source);
/* 478 */         for (Element converter : DomUtils.getChildElementsByTagName(interceptorsElement, "bean")) {
/* 479 */           BeanDefinitionHolder beanDef = parserContext.getDelegate().parseBeanDefinitionElement(converter);
/* 480 */           beanDef = parserContext.getDelegate().decorateBeanDefinitionIfRequired(converter, beanDef);
/* 481 */           interceptors.add(beanDef);
/*     */         }
/*     */       }
/*     */     }
/* 485 */     return interceptors;
/*     */   }
/*     */   
/*     */   private ManagedList<?> getDeferredResultInterceptors(Element element, Object source, ParserContext parserContext) {
/* 489 */     ManagedList<? super Object> interceptors = new ManagedList();
/* 490 */     Element asyncElement = DomUtils.getChildElementByTagName(element, "async-support");
/* 491 */     if (asyncElement != null) {
/* 492 */       Element interceptorsElement = DomUtils.getChildElementByTagName(asyncElement, "deferred-result-interceptors");
/* 493 */       if (interceptorsElement != null) {
/* 494 */         interceptors.setSource(source);
/* 495 */         for (Element converter : DomUtils.getChildElementsByTagName(interceptorsElement, "bean")) {
/* 496 */           BeanDefinitionHolder beanDef = parserContext.getDelegate().parseBeanDefinitionElement(converter);
/* 497 */           beanDef = parserContext.getDelegate().decorateBeanDefinitionIfRequired(converter, beanDef);
/* 498 */           interceptors.add(beanDef);
/*     */         }
/*     */       }
/*     */     }
/* 502 */     return interceptors;
/*     */   }
/*     */   
/*     */   private ManagedList<?> getArgumentResolvers(Element element, ParserContext parserContext) {
/* 506 */     Element resolversElement = DomUtils.getChildElementByTagName(element, "argument-resolvers");
/* 507 */     if (resolversElement != null) {
/* 508 */       ManagedList<Object> resolvers = extractBeanSubElements(resolversElement, parserContext);
/* 509 */       return wrapLegacyResolvers(resolvers, parserContext);
/*     */     }
/* 511 */     return null;
/*     */   }
/*     */   
/*     */   private ManagedList<Object> wrapLegacyResolvers(List<Object> list, ParserContext context) {
/* 515 */     ManagedList<Object> result = new ManagedList();
/* 516 */     for (Object object : list) {
/* 517 */       if ((object instanceof BeanDefinitionHolder)) {
/* 518 */         BeanDefinitionHolder beanDef = (BeanDefinitionHolder)object;
/* 519 */         String className = beanDef.getBeanDefinition().getBeanClassName();
/* 520 */         Class<?> clazz = ClassUtils.resolveClassName(className, context.getReaderContext().getBeanClassLoader());
/* 521 */         if (WebArgumentResolver.class.isAssignableFrom(clazz)) {
/* 522 */           RootBeanDefinition adapter = new RootBeanDefinition(ServletWebArgumentResolverAdapter.class);
/* 523 */           adapter.getConstructorArgumentValues().addIndexedArgumentValue(0, beanDef);
/* 524 */           result.add(new BeanDefinitionHolder(adapter, beanDef.getBeanName() + "Adapter"));
/* 525 */           continue;
/*     */         }
/*     */       }
/* 528 */       result.add(object);
/*     */     }
/* 530 */     return result;
/*     */   }
/*     */   
/*     */   private ManagedList<?> getReturnValueHandlers(Element element, ParserContext parserContext) {
/* 534 */     Element handlers = DomUtils.getChildElementByTagName(element, "return-value-handlers");
/* 535 */     return handlers != null ? extractBeanSubElements(handlers, parserContext) : null;
/*     */   }
/*     */   
/*     */   private ManagedList<?> getMessageConverters(Element element, Object source, ParserContext parserContext) {
/* 539 */     Element convertersElement = DomUtils.getChildElementByTagName(element, "message-converters");
/* 540 */     ManagedList<? super Object> messageConverters = new ManagedList();
/* 541 */     if (convertersElement != null) {
/* 542 */       messageConverters.setSource(source);
/* 543 */       for (Element beanElement : DomUtils.getChildElementsByTagName(convertersElement, new String[] { "bean", "ref" })) {
/* 544 */         Object object = parserContext.getDelegate().parsePropertySubElement(beanElement, null);
/* 545 */         messageConverters.add(object);
/*     */       }
/*     */     }
/*     */     
/* 549 */     if ((convertersElement == null) || (Boolean.valueOf(convertersElement.getAttribute("register-defaults")).booleanValue())) {
/* 550 */       messageConverters.setSource(source);
/* 551 */       messageConverters.add(createConverterDefinition(ByteArrayHttpMessageConverter.class, source));
/*     */       
/* 553 */       RootBeanDefinition stringConverterDef = createConverterDefinition(StringHttpMessageConverter.class, source);
/* 554 */       stringConverterDef.getPropertyValues().add("writeAcceptCharset", Boolean.valueOf(false));
/* 555 */       messageConverters.add(stringConverterDef);
/*     */       
/* 557 */       messageConverters.add(createConverterDefinition(ResourceHttpMessageConverter.class, source));
/* 558 */       messageConverters.add(createConverterDefinition(SourceHttpMessageConverter.class, source));
/* 559 */       messageConverters.add(createConverterDefinition(AllEncompassingFormHttpMessageConverter.class, source));
/*     */       
/* 561 */       if (romePresent) {
/* 562 */         messageConverters.add(createConverterDefinition(AtomFeedHttpMessageConverter.class, source));
/* 563 */         messageConverters.add(createConverterDefinition(RssChannelHttpMessageConverter.class, source));
/*     */       }
/*     */       
/* 566 */       if (jackson2XmlPresent) {
/* 567 */         RootBeanDefinition jacksonConverterDef = createConverterDefinition(MappingJackson2XmlHttpMessageConverter.class, source);
/* 568 */         GenericBeanDefinition jacksonFactoryDef = createObjectMapperFactoryDefinition(source);
/* 569 */         jacksonFactoryDef.getPropertyValues().add("createXmlMapper", Boolean.valueOf(true));
/* 570 */         jacksonConverterDef.getConstructorArgumentValues().addIndexedArgumentValue(0, jacksonFactoryDef);
/* 571 */         messageConverters.add(jacksonConverterDef);
/*     */       }
/* 573 */       else if (jaxb2Present) {
/* 574 */         messageConverters.add(createConverterDefinition(Jaxb2RootElementHttpMessageConverter.class, source));
/*     */       }
/*     */       
/* 577 */       if (jackson2Present) {
/* 578 */         RootBeanDefinition jacksonConverterDef = createConverterDefinition(MappingJackson2HttpMessageConverter.class, source);
/* 579 */         GenericBeanDefinition jacksonFactoryDef = createObjectMapperFactoryDefinition(source);
/* 580 */         jacksonConverterDef.getConstructorArgumentValues().addIndexedArgumentValue(0, jacksonFactoryDef);
/* 581 */         messageConverters.add(jacksonConverterDef);
/*     */       }
/* 583 */       else if (gsonPresent) {
/* 584 */         messageConverters.add(createConverterDefinition(GsonHttpMessageConverter.class, source));
/*     */       }
/*     */     }
/* 587 */     return messageConverters;
/*     */   }
/*     */   
/*     */   private GenericBeanDefinition createObjectMapperFactoryDefinition(Object source) {
/* 591 */     GenericBeanDefinition beanDefinition = new GenericBeanDefinition();
/* 592 */     beanDefinition.setBeanClass(Jackson2ObjectMapperFactoryBean.class);
/* 593 */     beanDefinition.setSource(source);
/* 594 */     beanDefinition.setRole(2);
/* 595 */     return beanDefinition;
/*     */   }
/*     */   
/*     */   private RootBeanDefinition createConverterDefinition(Class<?> converterClass, Object source) {
/* 599 */     RootBeanDefinition beanDefinition = new RootBeanDefinition(converterClass);
/* 600 */     beanDefinition.setSource(source);
/* 601 */     beanDefinition.setRole(2);
/* 602 */     return beanDefinition;
/*     */   }
/*     */   
/*     */   private ManagedList<Object> extractBeanSubElements(Element parentElement, ParserContext parserContext)
/*     */   {
/* 607 */     ManagedList<Object> list = new ManagedList();
/* 608 */     list.setSource(parserContext.extractSource(parentElement));
/* 609 */     for (Element beanElement : DomUtils.getChildElementsByTagName(parentElement, new String[] { "bean", "ref" })) {
/* 610 */       Object object = parserContext.getDelegate().parsePropertySubElement(beanElement, null);
/* 611 */       list.add(object);
/*     */     }
/* 613 */     return list;
/*     */   }
/*     */   
/*     */   private ManagedList<BeanReference> extractBeanRefSubElements(Element parentElement, ParserContext parserContext) {
/* 617 */     ManagedList<BeanReference> list = new ManagedList();
/* 618 */     list.setSource(parserContext.extractSource(parentElement));
/* 619 */     for (Element refElement : DomUtils.getChildElementsByTagName(parentElement, "ref"))
/*     */     {
/* 621 */       if (StringUtils.hasText("bean")) {
/* 622 */         BeanReference reference = new RuntimeBeanReference(refElement.getAttribute("bean"), false);
/* 623 */         list.add(reference);
/*     */       }
/* 625 */       else if (StringUtils.hasText("parent")) {
/* 626 */         BeanReference reference = new RuntimeBeanReference(refElement.getAttribute("parent"), true);
/* 627 */         list.add(reference);
/*     */       }
/*     */       else {
/* 630 */         parserContext.getReaderContext().error("'bean' or 'parent' attribute is required for <ref> element", parserContext
/* 631 */           .extractSource(parentElement));
/*     */       }
/*     */     }
/* 634 */     return list;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static class CompositeUriComponentsContributorFactoryBean
/*     */     implements FactoryBean<CompositeUriComponentsContributor>, InitializingBean
/*     */   {
/*     */     private RequestMappingHandlerAdapter handlerAdapter;
/*     */     
/*     */ 
/*     */     private ConversionService conversionService;
/*     */     
/*     */ 
/*     */     private CompositeUriComponentsContributor uriComponentsContributor;
/*     */     
/*     */ 
/*     */     public void setHandlerAdapter(RequestMappingHandlerAdapter handlerAdapter)
/*     */     {
/* 653 */       this.handlerAdapter = handlerAdapter;
/*     */     }
/*     */     
/*     */     public void setConversionService(ConversionService conversionService) {
/* 657 */       this.conversionService = conversionService;
/*     */     }
/*     */     
/*     */ 
/*     */     public void afterPropertiesSet()
/*     */     {
/* 663 */       this.uriComponentsContributor = new CompositeUriComponentsContributor(this.handlerAdapter.getArgumentResolvers(), this.conversionService);
/*     */     }
/*     */     
/*     */     public CompositeUriComponentsContributor getObject() throws Exception
/*     */     {
/* 668 */       return this.uriComponentsContributor;
/*     */     }
/*     */     
/*     */     public Class<?> getObjectType()
/*     */     {
/* 673 */       return CompositeUriComponentsContributor.class;
/*     */     }
/*     */     
/*     */     public boolean isSingleton()
/*     */     {
/* 678 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\config\AnnotationDrivenBeanDefinitionParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */