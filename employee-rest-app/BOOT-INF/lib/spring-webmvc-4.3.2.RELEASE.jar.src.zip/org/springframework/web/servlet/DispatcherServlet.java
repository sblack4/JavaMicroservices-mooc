/*      */ package org.springframework.web.servlet;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.beans.factory.BeanFactoryUtils;
/*      */ import org.springframework.beans.factory.BeanInitializationException;
/*      */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*      */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*      */ import org.springframework.context.ApplicationContext;
/*      */ import org.springframework.context.i18n.LocaleContext;
/*      */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*      */ import org.springframework.core.io.ClassPathResource;
/*      */ import org.springframework.core.io.support.PropertiesLoaderUtils;
/*      */ import org.springframework.http.HttpStatus;
/*      */ import org.springframework.http.server.ServletServerHttpRequest;
/*      */ import org.springframework.ui.context.ThemeSource;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ import org.springframework.web.context.WebApplicationContext;
/*      */ import org.springframework.web.context.request.ServletWebRequest;
/*      */ import org.springframework.web.context.request.async.WebAsyncManager;
/*      */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*      */ import org.springframework.web.multipart.MultipartException;
/*      */ import org.springframework.web.multipart.MultipartHttpServletRequest;
/*      */ import org.springframework.web.multipart.MultipartResolver;
/*      */ import org.springframework.web.util.NestedServletException;
/*      */ import org.springframework.web.util.WebUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DispatcherServlet
/*      */   extends FrameworkServlet
/*      */ {
/*      */   public static final String MULTIPART_RESOLVER_BEAN_NAME = "multipartResolver";
/*      */   public static final String LOCALE_RESOLVER_BEAN_NAME = "localeResolver";
/*      */   public static final String THEME_RESOLVER_BEAN_NAME = "themeResolver";
/*      */   public static final String HANDLER_MAPPING_BEAN_NAME = "handlerMapping";
/*      */   public static final String HANDLER_ADAPTER_BEAN_NAME = "handlerAdapter";
/*      */   public static final String HANDLER_EXCEPTION_RESOLVER_BEAN_NAME = "handlerExceptionResolver";
/*      */   public static final String REQUEST_TO_VIEW_NAME_TRANSLATOR_BEAN_NAME = "viewNameTranslator";
/*      */   public static final String VIEW_RESOLVER_BEAN_NAME = "viewResolver";
/*      */   public static final String FLASH_MAP_MANAGER_BEAN_NAME = "flashMapManager";
/*  211 */   public static final String WEB_APPLICATION_CONTEXT_ATTRIBUTE = DispatcherServlet.class.getName() + ".CONTEXT";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  217 */   public static final String LOCALE_RESOLVER_ATTRIBUTE = DispatcherServlet.class.getName() + ".LOCALE_RESOLVER";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  223 */   public static final String THEME_RESOLVER_ATTRIBUTE = DispatcherServlet.class.getName() + ".THEME_RESOLVER";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  229 */   public static final String THEME_SOURCE_ATTRIBUTE = DispatcherServlet.class.getName() + ".THEME_SOURCE";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  236 */   public static final String INPUT_FLASH_MAP_ATTRIBUTE = DispatcherServlet.class.getName() + ".INPUT_FLASH_MAP";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  243 */   public static final String OUTPUT_FLASH_MAP_ATTRIBUTE = DispatcherServlet.class.getName() + ".OUTPUT_FLASH_MAP";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  249 */   public static final String FLASH_MAP_MANAGER_ATTRIBUTE = DispatcherServlet.class.getName() + ".FLASH_MAP_MANAGER";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  256 */   public static final String EXCEPTION_ATTRIBUTE = DispatcherServlet.class.getName() + ".EXCEPTION";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String PAGE_NOT_FOUND_LOG_CATEGORY = "org.springframework.web.servlet.PageNotFound";
/*      */   
/*      */ 
/*      */ 
/*      */   private static final String DEFAULT_STRATEGIES_PATH = "DispatcherServlet.properties";
/*      */   
/*      */ 
/*      */ 
/*  269 */   protected static final Log pageNotFoundLogger = LogFactory.getLog("org.springframework.web.servlet.PageNotFound");
/*      */   
/*      */   private static final Properties defaultStrategies;
/*      */   
/*      */ 
/*      */   static
/*      */   {
/*      */     try
/*      */     {
/*  278 */       ClassPathResource resource = new ClassPathResource("DispatcherServlet.properties", DispatcherServlet.class);
/*  279 */       defaultStrategies = PropertiesLoaderUtils.loadProperties(resource);
/*      */     }
/*      */     catch (IOException ex) {
/*  282 */       throw new IllegalStateException("Could not load 'DispatcherServlet.properties': " + ex.getMessage());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*  287 */   private boolean detectAllHandlerMappings = true;
/*      */   
/*      */ 
/*  290 */   private boolean detectAllHandlerAdapters = true;
/*      */   
/*      */ 
/*  293 */   private boolean detectAllHandlerExceptionResolvers = true;
/*      */   
/*      */ 
/*  296 */   private boolean detectAllViewResolvers = true;
/*      */   
/*      */ 
/*  299 */   private boolean throwExceptionIfNoHandlerFound = false;
/*      */   
/*      */ 
/*  302 */   private boolean cleanupAfterInclude = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private MultipartResolver multipartResolver;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private LocaleResolver localeResolver;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ThemeResolver themeResolver;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private List<HandlerMapping> handlerMappings;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private List<HandlerAdapter> handlerAdapters;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private List<HandlerExceptionResolver> handlerExceptionResolvers;
/*      */   
/*      */ 
/*      */ 
/*      */   private RequestToViewNameTranslator viewNameTranslator;
/*      */   
/*      */ 
/*      */ 
/*      */   private FlashMapManager flashMapManager;
/*      */   
/*      */ 
/*      */ 
/*      */   private List<ViewResolver> viewResolvers;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public DispatcherServlet()
/*      */   {
/*  351 */     setDispatchOptionsRequest(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DispatcherServlet(WebApplicationContext webApplicationContext)
/*      */   {
/*  394 */     super(webApplicationContext);
/*  395 */     setDispatchOptionsRequest(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDetectAllHandlerMappings(boolean detectAllHandlerMappings)
/*      */   {
/*  406 */     this.detectAllHandlerMappings = detectAllHandlerMappings;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDetectAllHandlerAdapters(boolean detectAllHandlerAdapters)
/*      */   {
/*  416 */     this.detectAllHandlerAdapters = detectAllHandlerAdapters;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDetectAllHandlerExceptionResolvers(boolean detectAllHandlerExceptionResolvers)
/*      */   {
/*  426 */     this.detectAllHandlerExceptionResolvers = detectAllHandlerExceptionResolvers;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDetectAllViewResolvers(boolean detectAllViewResolvers)
/*      */   {
/*  436 */     this.detectAllViewResolvers = detectAllViewResolvers;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setThrowExceptionIfNoHandlerFound(boolean throwExceptionIfNoHandlerFound)
/*      */   {
/*  451 */     this.throwExceptionIfNoHandlerFound = throwExceptionIfNoHandlerFound;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCleanupAfterInclude(boolean cleanupAfterInclude)
/*      */   {
/*  467 */     this.cleanupAfterInclude = cleanupAfterInclude;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void onRefresh(ApplicationContext context)
/*      */   {
/*  476 */     initStrategies(context);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void initStrategies(ApplicationContext context)
/*      */   {
/*  484 */     initMultipartResolver(context);
/*  485 */     initLocaleResolver(context);
/*  486 */     initThemeResolver(context);
/*  487 */     initHandlerMappings(context);
/*  488 */     initHandlerAdapters(context);
/*  489 */     initHandlerExceptionResolvers(context);
/*  490 */     initRequestToViewNameTranslator(context);
/*  491 */     initViewResolvers(context);
/*  492 */     initFlashMapManager(context);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initMultipartResolver(ApplicationContext context)
/*      */   {
/*      */     try
/*      */     {
/*  502 */       this.multipartResolver = ((MultipartResolver)context.getBean("multipartResolver", MultipartResolver.class));
/*  503 */       if (this.logger.isDebugEnabled()) {
/*  504 */         this.logger.debug("Using MultipartResolver [" + this.multipartResolver + "]");
/*      */       }
/*      */     }
/*      */     catch (NoSuchBeanDefinitionException ex)
/*      */     {
/*  509 */       this.multipartResolver = null;
/*  510 */       if (this.logger.isDebugEnabled()) {
/*  511 */         this.logger.debug("Unable to locate MultipartResolver with name 'multipartResolver': no multipart request handling provided");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initLocaleResolver(ApplicationContext context)
/*      */   {
/*      */     try
/*      */     {
/*  524 */       this.localeResolver = ((LocaleResolver)context.getBean("localeResolver", LocaleResolver.class));
/*  525 */       if (this.logger.isDebugEnabled()) {
/*  526 */         this.logger.debug("Using LocaleResolver [" + this.localeResolver + "]");
/*      */       }
/*      */     }
/*      */     catch (NoSuchBeanDefinitionException ex)
/*      */     {
/*  531 */       this.localeResolver = ((LocaleResolver)getDefaultStrategy(context, LocaleResolver.class));
/*  532 */       if (this.logger.isDebugEnabled()) {
/*  533 */         this.logger.debug("Unable to locate LocaleResolver with name 'localeResolver': using default [" + this.localeResolver + "]");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initThemeResolver(ApplicationContext context)
/*      */   {
/*      */     try
/*      */     {
/*  546 */       this.themeResolver = ((ThemeResolver)context.getBean("themeResolver", ThemeResolver.class));
/*  547 */       if (this.logger.isDebugEnabled()) {
/*  548 */         this.logger.debug("Using ThemeResolver [" + this.themeResolver + "]");
/*      */       }
/*      */     }
/*      */     catch (NoSuchBeanDefinitionException ex)
/*      */     {
/*  553 */       this.themeResolver = ((ThemeResolver)getDefaultStrategy(context, ThemeResolver.class));
/*  554 */       if (this.logger.isDebugEnabled()) {
/*  555 */         this.logger.debug("Unable to locate ThemeResolver with name 'themeResolver': using default [" + this.themeResolver + "]");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initHandlerMappings(ApplicationContext context)
/*      */   {
/*  567 */     this.handlerMappings = null;
/*      */     
/*  569 */     if (this.detectAllHandlerMappings)
/*      */     {
/*      */ 
/*  572 */       Map<String, HandlerMapping> matchingBeans = BeanFactoryUtils.beansOfTypeIncludingAncestors(context, HandlerMapping.class, true, false);
/*  573 */       if (!matchingBeans.isEmpty()) {
/*  574 */         this.handlerMappings = new ArrayList(matchingBeans.values());
/*      */         
/*  576 */         AnnotationAwareOrderComparator.sort(this.handlerMappings);
/*      */       }
/*      */     }
/*      */     else {
/*      */       try {
/*  581 */         HandlerMapping hm = (HandlerMapping)context.getBean("handlerMapping", HandlerMapping.class);
/*  582 */         this.handlerMappings = Collections.singletonList(hm);
/*      */       }
/*      */       catch (NoSuchBeanDefinitionException localNoSuchBeanDefinitionException) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  591 */     if (this.handlerMappings == null) {
/*  592 */       this.handlerMappings = getDefaultStrategies(context, HandlerMapping.class);
/*  593 */       if (this.logger.isDebugEnabled()) {
/*  594 */         this.logger.debug("No HandlerMappings found in servlet '" + getServletName() + "': using default");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initHandlerAdapters(ApplicationContext context)
/*      */   {
/*  605 */     this.handlerAdapters = null;
/*      */     
/*  607 */     if (this.detectAllHandlerAdapters)
/*      */     {
/*      */ 
/*  610 */       Map<String, HandlerAdapter> matchingBeans = BeanFactoryUtils.beansOfTypeIncludingAncestors(context, HandlerAdapter.class, true, false);
/*  611 */       if (!matchingBeans.isEmpty()) {
/*  612 */         this.handlerAdapters = new ArrayList(matchingBeans.values());
/*      */         
/*  614 */         AnnotationAwareOrderComparator.sort(this.handlerAdapters);
/*      */       }
/*      */     }
/*      */     else {
/*      */       try {
/*  619 */         HandlerAdapter ha = (HandlerAdapter)context.getBean("handlerAdapter", HandlerAdapter.class);
/*  620 */         this.handlerAdapters = Collections.singletonList(ha);
/*      */       }
/*      */       catch (NoSuchBeanDefinitionException localNoSuchBeanDefinitionException) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  629 */     if (this.handlerAdapters == null) {
/*  630 */       this.handlerAdapters = getDefaultStrategies(context, HandlerAdapter.class);
/*  631 */       if (this.logger.isDebugEnabled()) {
/*  632 */         this.logger.debug("No HandlerAdapters found in servlet '" + getServletName() + "': using default");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initHandlerExceptionResolvers(ApplicationContext context)
/*      */   {
/*  643 */     this.handlerExceptionResolvers = null;
/*      */     
/*  645 */     if (this.detectAllHandlerExceptionResolvers)
/*      */     {
/*      */ 
/*  648 */       Map<String, HandlerExceptionResolver> matchingBeans = BeanFactoryUtils.beansOfTypeIncludingAncestors(context, HandlerExceptionResolver.class, true, false);
/*  649 */       if (!matchingBeans.isEmpty()) {
/*  650 */         this.handlerExceptionResolvers = new ArrayList(matchingBeans.values());
/*      */         
/*  652 */         AnnotationAwareOrderComparator.sort(this.handlerExceptionResolvers);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*      */       try {
/*  658 */         HandlerExceptionResolver her = (HandlerExceptionResolver)context.getBean("handlerExceptionResolver", HandlerExceptionResolver.class);
/*  659 */         this.handlerExceptionResolvers = Collections.singletonList(her);
/*      */       }
/*      */       catch (NoSuchBeanDefinitionException localNoSuchBeanDefinitionException) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  668 */     if (this.handlerExceptionResolvers == null) {
/*  669 */       this.handlerExceptionResolvers = getDefaultStrategies(context, HandlerExceptionResolver.class);
/*  670 */       if (this.logger.isDebugEnabled()) {
/*  671 */         this.logger.debug("No HandlerExceptionResolvers found in servlet '" + getServletName() + "': using default");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initRequestToViewNameTranslator(ApplicationContext context)
/*      */   {
/*      */     try
/*      */     {
/*  683 */       this.viewNameTranslator = ((RequestToViewNameTranslator)context.getBean("viewNameTranslator", RequestToViewNameTranslator.class));
/*  684 */       if (this.logger.isDebugEnabled()) {
/*  685 */         this.logger.debug("Using RequestToViewNameTranslator [" + this.viewNameTranslator + "]");
/*      */       }
/*      */     }
/*      */     catch (NoSuchBeanDefinitionException ex)
/*      */     {
/*  690 */       this.viewNameTranslator = ((RequestToViewNameTranslator)getDefaultStrategy(context, RequestToViewNameTranslator.class));
/*  691 */       if (this.logger.isDebugEnabled()) {
/*  692 */         this.logger.debug("Unable to locate RequestToViewNameTranslator with name 'viewNameTranslator': using default [" + this.viewNameTranslator + "]");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initViewResolvers(ApplicationContext context)
/*      */   {
/*  705 */     this.viewResolvers = null;
/*      */     
/*  707 */     if (this.detectAllViewResolvers)
/*      */     {
/*      */ 
/*  710 */       Map<String, ViewResolver> matchingBeans = BeanFactoryUtils.beansOfTypeIncludingAncestors(context, ViewResolver.class, true, false);
/*  711 */       if (!matchingBeans.isEmpty()) {
/*  712 */         this.viewResolvers = new ArrayList(matchingBeans.values());
/*      */         
/*  714 */         AnnotationAwareOrderComparator.sort(this.viewResolvers);
/*      */       }
/*      */     }
/*      */     else {
/*      */       try {
/*  719 */         ViewResolver vr = (ViewResolver)context.getBean("viewResolver", ViewResolver.class);
/*  720 */         this.viewResolvers = Collections.singletonList(vr);
/*      */       }
/*      */       catch (NoSuchBeanDefinitionException localNoSuchBeanDefinitionException) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  729 */     if (this.viewResolvers == null) {
/*  730 */       this.viewResolvers = getDefaultStrategies(context, ViewResolver.class);
/*  731 */       if (this.logger.isDebugEnabled()) {
/*  732 */         this.logger.debug("No ViewResolvers found in servlet '" + getServletName() + "': using default");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initFlashMapManager(ApplicationContext context)
/*      */   {
/*      */     try
/*      */     {
/*  744 */       this.flashMapManager = ((FlashMapManager)context.getBean("flashMapManager", FlashMapManager.class));
/*  745 */       if (this.logger.isDebugEnabled()) {
/*  746 */         this.logger.debug("Using FlashMapManager [" + this.flashMapManager + "]");
/*      */       }
/*      */     }
/*      */     catch (NoSuchBeanDefinitionException ex)
/*      */     {
/*  751 */       this.flashMapManager = ((FlashMapManager)getDefaultStrategy(context, FlashMapManager.class));
/*  752 */       if (this.logger.isDebugEnabled()) {
/*  753 */         this.logger.debug("Unable to locate FlashMapManager with name 'flashMapManager': using default [" + this.flashMapManager + "]");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final ThemeSource getThemeSource()
/*      */   {
/*  767 */     if ((getWebApplicationContext() instanceof ThemeSource)) {
/*  768 */       return (ThemeSource)getWebApplicationContext();
/*      */     }
/*      */     
/*  771 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final MultipartResolver getMultipartResolver()
/*      */   {
/*  781 */     return this.multipartResolver;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected <T> T getDefaultStrategy(ApplicationContext context, Class<T> strategyInterface)
/*      */   {
/*  794 */     List<T> strategies = getDefaultStrategies(context, strategyInterface);
/*  795 */     if (strategies.size() != 1)
/*      */     {
/*  797 */       throw new BeanInitializationException("DispatcherServlet needs exactly 1 strategy for interface [" + strategyInterface.getName() + "]");
/*      */     }
/*  799 */     return (T)strategies.get(0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected <T> List<T> getDefaultStrategies(ApplicationContext context, Class<T> strategyInterface)
/*      */   {
/*  813 */     String key = strategyInterface.getName();
/*  814 */     String value = defaultStrategies.getProperty(key);
/*  815 */     if (value != null) {
/*  816 */       String[] classNames = StringUtils.commaDelimitedListToStringArray(value);
/*  817 */       List<T> strategies = new ArrayList(classNames.length);
/*  818 */       for (String className : classNames) {
/*      */         try {
/*  820 */           Class<?> clazz = ClassUtils.forName(className, DispatcherServlet.class.getClassLoader());
/*  821 */           Object strategy = createDefaultStrategy(context, clazz);
/*  822 */           strategies.add(strategy);
/*      */         }
/*      */         catch (ClassNotFoundException ex) {
/*  825 */           throw new BeanInitializationException("Could not find DispatcherServlet's default strategy class [" + className + "] for interface [" + key + "]", ex);
/*      */ 
/*      */         }
/*      */         catch (LinkageError err)
/*      */         {
/*  830 */           throw new BeanInitializationException("Error loading DispatcherServlet's default strategy class [" + className + "] for interface [" + key + "]: problem with class file or dependent class", err);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  835 */       return strategies;
/*      */     }
/*      */     
/*  838 */     return new LinkedList();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Object createDefaultStrategy(ApplicationContext context, Class<?> clazz)
/*      */   {
/*  853 */     return context.getAutowireCapableBeanFactory().createBean(clazz);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doService(HttpServletRequest request, HttpServletResponse response)
/*      */     throws Exception
/*      */   {
/*  863 */     if (this.logger.isDebugEnabled()) {
/*  864 */       String resumed = WebAsyncUtils.getAsyncManager(request).hasConcurrentResult() ? " resumed" : "";
/*  865 */       this.logger.debug("DispatcherServlet with name '" + getServletName() + "'" + resumed + " processing " + request
/*  866 */         .getMethod() + " request for [" + getRequestUri(request) + "]");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  871 */     Map<String, Object> attributesSnapshot = null;
/*  872 */     if (WebUtils.isIncludeRequest(request)) {
/*  873 */       attributesSnapshot = new HashMap();
/*  874 */       Enumeration<?> attrNames = request.getAttributeNames();
/*  875 */       while (attrNames.hasMoreElements()) {
/*  876 */         String attrName = (String)attrNames.nextElement();
/*  877 */         if ((this.cleanupAfterInclude) || (attrName.startsWith("org.springframework.web.servlet"))) {
/*  878 */           attributesSnapshot.put(attrName, request.getAttribute(attrName));
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  884 */     request.setAttribute(WEB_APPLICATION_CONTEXT_ATTRIBUTE, getWebApplicationContext());
/*  885 */     request.setAttribute(LOCALE_RESOLVER_ATTRIBUTE, this.localeResolver);
/*  886 */     request.setAttribute(THEME_RESOLVER_ATTRIBUTE, this.themeResolver);
/*  887 */     request.setAttribute(THEME_SOURCE_ATTRIBUTE, getThemeSource());
/*      */     
/*  889 */     FlashMap inputFlashMap = this.flashMapManager.retrieveAndUpdate(request, response);
/*  890 */     if (inputFlashMap != null) {
/*  891 */       request.setAttribute(INPUT_FLASH_MAP_ATTRIBUTE, Collections.unmodifiableMap(inputFlashMap));
/*      */     }
/*  893 */     request.setAttribute(OUTPUT_FLASH_MAP_ATTRIBUTE, new FlashMap());
/*  894 */     request.setAttribute(FLASH_MAP_MANAGER_ATTRIBUTE, this.flashMapManager);
/*      */     try
/*      */     {
/*  897 */       doDispatch(request, response);
/*      */     }
/*      */     finally {
/*  900 */       if (!WebAsyncUtils.getAsyncManager(request).isConcurrentHandlingStarted())
/*      */       {
/*  902 */         if (attributesSnapshot != null) {
/*  903 */           restoreAttributesAfterInclude(request, attributesSnapshot);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doDispatch(HttpServletRequest request, HttpServletResponse response)
/*      */     throws Exception
/*      */   {
/*  921 */     HttpServletRequest processedRequest = request;
/*  922 */     HandlerExecutionChain mappedHandler = null;
/*  923 */     boolean multipartRequestParsed = false;
/*      */     
/*  925 */     WebAsyncManager asyncManager = WebAsyncUtils.getAsyncManager(request);
/*      */     try
/*      */     {
/*  928 */       ModelAndView mv = null;
/*  929 */       Exception dispatchException = null;
/*      */       try
/*      */       {
/*  932 */         processedRequest = checkMultipart(request);
/*  933 */         multipartRequestParsed = processedRequest != request;
/*      */         
/*      */ 
/*  936 */         mappedHandler = getHandler(processedRequest);
/*  937 */         if ((mappedHandler == null) || (mappedHandler.getHandler() == null)) {
/*  938 */           noHandlerFound(processedRequest, response);
/*  939 */           return;
/*      */         }
/*      */         
/*      */ 
/*  943 */         HandlerAdapter ha = getHandlerAdapter(mappedHandler.getHandler());
/*      */         
/*      */ 
/*  946 */         String method = request.getMethod();
/*  947 */         boolean isGet = "GET".equals(method);
/*  948 */         if ((isGet) || ("HEAD".equals(method))) {
/*  949 */           long lastModified = ha.getLastModified(request, mappedHandler.getHandler());
/*  950 */           if (this.logger.isDebugEnabled()) {
/*  951 */             this.logger.debug("Last-Modified value for [" + getRequestUri(request) + "] is: " + lastModified);
/*      */           }
/*  953 */           if ((new ServletWebRequest(request, response).checkNotModified(lastModified)) && (isGet)) {
/*  954 */             return;
/*      */           }
/*      */         }
/*      */         
/*  958 */         if (!mappedHandler.applyPreHandle(processedRequest, response)) {
/*  959 */           return;
/*      */         }
/*      */         
/*      */ 
/*  963 */         mv = ha.handle(processedRequest, response, mappedHandler.getHandler());
/*      */         
/*  965 */         if (asyncManager.isConcurrentHandlingStarted()) {
/*  966 */           return;
/*      */         }
/*      */         
/*  969 */         applyDefaultViewName(processedRequest, mv);
/*  970 */         mappedHandler.applyPostHandle(processedRequest, response, mv);
/*      */       }
/*      */       catch (Exception ex) {
/*  973 */         dispatchException = ex;
/*      */ 
/*      */       }
/*      */       catch (Throwable err)
/*      */       {
/*  978 */         dispatchException = new NestedServletException("Handler dispatch failed", err);
/*      */       }
/*  980 */       processDispatchResult(processedRequest, response, mappedHandler, mv, dispatchException);
/*      */     }
/*      */     catch (Exception ex) {
/*  983 */       triggerAfterCompletion(processedRequest, response, mappedHandler, ex);
/*      */     }
/*      */     catch (Throwable err) {
/*  986 */       triggerAfterCompletion(processedRequest, response, mappedHandler, new NestedServletException("Handler processing failed", err));
/*      */     }
/*      */     finally
/*      */     {
/*  990 */       if (asyncManager.isConcurrentHandlingStarted())
/*      */       {
/*  992 */         if (mappedHandler != null) {
/*  993 */           mappedHandler.applyAfterConcurrentHandlingStarted(processedRequest, response);
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*  998 */       else if (multipartRequestParsed) {
/*  999 */         cleanupMultipart(processedRequest);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void applyDefaultViewName(HttpServletRequest request, ModelAndView mv)
/*      */     throws Exception
/*      */   {
/* 1009 */     if ((mv != null) && (!mv.hasView())) {
/* 1010 */       mv.setViewName(getDefaultViewName(request));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void processDispatchResult(HttpServletRequest request, HttpServletResponse response, HandlerExecutionChain mappedHandler, ModelAndView mv, Exception exception)
/*      */     throws Exception
/*      */   {
/* 1021 */     boolean errorView = false;
/*      */     
/* 1023 */     if (exception != null) {
/* 1024 */       if ((exception instanceof ModelAndViewDefiningException)) {
/* 1025 */         this.logger.debug("ModelAndViewDefiningException encountered", exception);
/* 1026 */         mv = ((ModelAndViewDefiningException)exception).getModelAndView();
/*      */       }
/*      */       else {
/* 1029 */         Object handler = mappedHandler != null ? mappedHandler.getHandler() : null;
/* 1030 */         mv = processHandlerException(request, response, handler, exception);
/* 1031 */         errorView = mv != null;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1036 */     if ((mv != null) && (!mv.wasCleared())) {
/* 1037 */       render(mv, request, response);
/* 1038 */       if (errorView) {
/* 1039 */         WebUtils.clearErrorRequestAttributes(request);
/*      */       }
/*      */       
/*      */     }
/* 1043 */     else if (this.logger.isDebugEnabled()) {
/* 1044 */       this.logger.debug("Null ModelAndView returned to DispatcherServlet with name '" + getServletName() + "': assuming HandlerAdapter completed request handling");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1049 */     if (WebAsyncUtils.getAsyncManager(request).isConcurrentHandlingStarted())
/*      */     {
/* 1051 */       return;
/*      */     }
/*      */     
/* 1054 */     if (mappedHandler != null) {
/* 1055 */       mappedHandler.triggerAfterCompletion(request, response, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected LocaleContext buildLocaleContext(final HttpServletRequest request)
/*      */   {
/* 1068 */     if ((this.localeResolver instanceof LocaleContextResolver)) {
/* 1069 */       return ((LocaleContextResolver)this.localeResolver).resolveLocaleContext(request);
/*      */     }
/*      */     
/* 1072 */     new LocaleContext()
/*      */     {
/*      */       public Locale getLocale() {
/* 1075 */         return DispatcherServlet.this.localeResolver.resolveLocale(request);
/*      */       }
/*      */     };
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected HttpServletRequest checkMultipart(HttpServletRequest request)
/*      */     throws MultipartException
/*      */   {
/* 1089 */     if ((this.multipartResolver != null) && (this.multipartResolver.isMultipart(request))) {
/* 1090 */       if (WebUtils.getNativeRequest(request, MultipartHttpServletRequest.class) != null) {
/* 1091 */         this.logger.debug("Request is already a MultipartHttpServletRequest - if not in a forward, this typically results from an additional MultipartFilter in web.xml");
/*      */ 
/*      */       }
/* 1094 */       else if ((request.getAttribute("javax.servlet.error.exception") instanceof MultipartException)) {
/* 1095 */         this.logger.debug("Multipart resolution failed for current request before - skipping re-resolution for undisturbed error rendering");
/*      */       }
/*      */       else
/*      */       {
/* 1099 */         return this.multipartResolver.resolveMultipart(request);
/*      */       }
/*      */     }
/*      */     
/* 1103 */     return request;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void cleanupMultipart(HttpServletRequest request)
/*      */   {
/* 1113 */     MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest)WebUtils.getNativeRequest(request, MultipartHttpServletRequest.class);
/* 1114 */     if (multipartRequest != null) {
/* 1115 */       this.multipartResolver.cleanupMultipart(multipartRequest);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected HandlerExecutionChain getHandler(HttpServletRequest request)
/*      */     throws Exception
/*      */   {
/* 1126 */     for (HandlerMapping hm : this.handlerMappings) {
/* 1127 */       if (this.logger.isTraceEnabled()) {
/* 1128 */         this.logger.trace("Testing handler map [" + hm + "] in DispatcherServlet with name '" + 
/* 1129 */           getServletName() + "'");
/*      */       }
/* 1131 */       HandlerExecutionChain handler = hm.getHandler(request);
/* 1132 */       if (handler != null) {
/* 1133 */         return handler;
/*      */       }
/*      */     }
/* 1136 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void noHandlerFound(HttpServletRequest request, HttpServletResponse response)
/*      */     throws Exception
/*      */   {
/* 1146 */     if (pageNotFoundLogger.isWarnEnabled()) {
/* 1147 */       pageNotFoundLogger.warn("No mapping found for HTTP request with URI [" + getRequestUri(request) + "] in DispatcherServlet with name '" + 
/* 1148 */         getServletName() + "'");
/*      */     }
/* 1150 */     if (this.throwExceptionIfNoHandlerFound)
/*      */     {
/* 1152 */       throw new NoHandlerFoundException(request.getMethod(), getRequestUri(request), new ServletServerHttpRequest(request).getHeaders());
/*      */     }
/*      */     
/* 1155 */     response.sendError(404);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected HandlerAdapter getHandlerAdapter(Object handler)
/*      */     throws ServletException
/*      */   {
/* 1165 */     for (HandlerAdapter ha : this.handlerAdapters) {
/* 1166 */       if (this.logger.isTraceEnabled()) {
/* 1167 */         this.logger.trace("Testing handler adapter [" + ha + "]");
/*      */       }
/* 1169 */       if (ha.supports(handler)) {
/* 1170 */         return ha;
/*      */       }
/*      */     }
/* 1173 */     throw new ServletException("No adapter for handler [" + handler + "]: The DispatcherServlet configuration needs to include a HandlerAdapter that supports this handler");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ModelAndView processHandlerException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
/*      */     throws Exception
/*      */   {
/* 1191 */     ModelAndView exMv = null;
/* 1192 */     for (HandlerExceptionResolver handlerExceptionResolver : this.handlerExceptionResolvers) {
/* 1193 */       exMv = handlerExceptionResolver.resolveException(request, response, handler, ex);
/* 1194 */       if (exMv != null) {
/*      */         break;
/*      */       }
/*      */     }
/* 1198 */     if (exMv != null) {
/* 1199 */       if (exMv.isEmpty()) {
/* 1200 */         request.setAttribute(EXCEPTION_ATTRIBUTE, ex);
/* 1201 */         return null;
/*      */       }
/*      */       
/* 1204 */       if (!exMv.hasView()) {
/* 1205 */         exMv.setViewName(getDefaultViewName(request));
/*      */       }
/* 1207 */       if (this.logger.isDebugEnabled()) {
/* 1208 */         this.logger.debug("Handler execution resulted in exception - forwarding to resolved error view: " + exMv, ex);
/*      */       }
/* 1210 */       WebUtils.exposeErrorRequestAttributes(request, ex, getServletName());
/* 1211 */       return exMv;
/*      */     }
/*      */     
/* 1214 */     throw ex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void render(ModelAndView mv, HttpServletRequest request, HttpServletResponse response)
/*      */     throws Exception
/*      */   {
/* 1228 */     Locale locale = this.localeResolver.resolveLocale(request);
/* 1229 */     response.setLocale(locale);
/*      */     
/*      */     View view;
/* 1232 */     if (mv.isReference())
/*      */     {
/* 1234 */       View view = resolveViewName(mv.getViewName(), mv.getModelInternal(), locale, request);
/* 1235 */       if (view == null)
/*      */       {
/* 1237 */         throw new ServletException("Could not resolve view with name '" + mv.getViewName() + "' in servlet with name '" + getServletName() + "'");
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1242 */       view = mv.getView();
/* 1243 */       if (view == null)
/*      */       {
/* 1245 */         throw new ServletException("ModelAndView [" + mv + "] neither contains a view name nor a " + "View object in servlet with name '" + getServletName() + "'");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1250 */     if (this.logger.isDebugEnabled()) {
/* 1251 */       this.logger.debug("Rendering view [" + view + "] in DispatcherServlet with name '" + getServletName() + "'");
/*      */     }
/*      */     try {
/* 1254 */       if (mv.getStatus() != null) {
/* 1255 */         response.setStatus(mv.getStatus().value());
/*      */       }
/* 1257 */       view.render(mv.getModelInternal(), request, response);
/*      */     }
/*      */     catch (Exception ex) {
/* 1260 */       if (this.logger.isDebugEnabled()) {
/* 1261 */         this.logger.debug("Error rendering view [" + view + "] in DispatcherServlet with name '" + 
/* 1262 */           getServletName() + "'", ex);
/*      */       }
/* 1264 */       throw ex;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getDefaultViewName(HttpServletRequest request)
/*      */     throws Exception
/*      */   {
/* 1275 */     return this.viewNameTranslator.getViewName(request);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected View resolveViewName(String viewName, Map<String, Object> model, Locale locale, HttpServletRequest request)
/*      */     throws Exception
/*      */   {
/* 1295 */     for (ViewResolver viewResolver : this.viewResolvers) {
/* 1296 */       View view = viewResolver.resolveViewName(viewName, locale);
/* 1297 */       if (view != null) {
/* 1298 */         return view;
/*      */       }
/*      */     }
/* 1301 */     return null;
/*      */   }
/*      */   
/*      */   private void triggerAfterCompletion(HttpServletRequest request, HttpServletResponse response, HandlerExecutionChain mappedHandler, Exception ex)
/*      */     throws Exception
/*      */   {
/* 1307 */     if (mappedHandler != null) {
/* 1308 */       mappedHandler.triggerAfterCompletion(request, response, ex);
/*      */     }
/* 1310 */     throw ex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void restoreAttributesAfterInclude(HttpServletRequest request, Map<?, ?> attributesSnapshot)
/*      */   {
/* 1322 */     Set<String> attrsToCheck = new HashSet();
/* 1323 */     Enumeration<?> attrNames = request.getAttributeNames();
/* 1324 */     String attrName; while (attrNames.hasMoreElements()) {
/* 1325 */       attrName = (String)attrNames.nextElement();
/* 1326 */       if ((this.cleanupAfterInclude) || (attrName.startsWith("org.springframework.web.servlet"))) {
/* 1327 */         attrsToCheck.add(attrName);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1332 */     attrsToCheck.addAll(attributesSnapshot.keySet());
/*      */     
/*      */ 
/*      */ 
/* 1336 */     for (String attrName : attrsToCheck) {
/* 1337 */       Object attrValue = attributesSnapshot.get(attrName);
/* 1338 */       if (attrValue == null) {
/* 1339 */         request.removeAttribute(attrName);
/*      */       }
/* 1341 */       else if (attrValue != request.getAttribute(attrName)) {
/* 1342 */         request.setAttribute(attrName, attrValue);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private static String getRequestUri(HttpServletRequest request) {
/* 1348 */     String uri = (String)request.getAttribute("javax.servlet.include.request_uri");
/* 1349 */     if (uri == null) {
/* 1350 */       uri = request.getRequestURI();
/*      */     }
/* 1352 */     return uri;
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\DispatcherServlet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */