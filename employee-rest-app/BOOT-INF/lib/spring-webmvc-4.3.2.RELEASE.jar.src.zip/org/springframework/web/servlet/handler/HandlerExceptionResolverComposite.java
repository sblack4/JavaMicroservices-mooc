/*    */ package org.springframework.web.servlet.handler;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.web.servlet.HandlerExceptionResolver;
/*    */ import org.springframework.web.servlet.ModelAndView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HandlerExceptionResolverComposite
/*    */   implements HandlerExceptionResolver, Ordered
/*    */ {
/*    */   private List<HandlerExceptionResolver> resolvers;
/* 38 */   private int order = Integer.MAX_VALUE;
/*    */   
/*    */   public void setOrder(int order) {
/* 41 */     this.order = order;
/*    */   }
/*    */   
/*    */   public int getOrder()
/*    */   {
/* 46 */     return this.order;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers)
/*    */   {
/* 53 */     this.resolvers = exceptionResolvers;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public List<HandlerExceptionResolver> getExceptionResolvers()
/*    */   {
/* 60 */     return Collections.unmodifiableList(this.resolvers);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
/*    */   {
/* 72 */     if (this.resolvers != null) {
/* 73 */       for (HandlerExceptionResolver handlerExceptionResolver : this.resolvers) {
/* 74 */         ModelAndView mav = handlerExceptionResolver.resolveException(request, response, handler, ex);
/* 75 */         if (mav != null) {
/* 76 */           return mav;
/*    */         }
/*    */       }
/*    */     }
/* 80 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\handler\HandlerExceptionResolverComposite.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */