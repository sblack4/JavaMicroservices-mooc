/*     */ package org.springframework.web.servlet.config;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.web.cors.CorsConfiguration;
/*     */ import org.springframework.web.servlet.handler.BeanNameUrlHandlerMapping;
/*     */ import org.springframework.web.servlet.mvc.HttpRequestHandlerAdapter;
/*     */ import org.springframework.web.servlet.mvc.SimpleControllerHandlerAdapter;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class MvcNamespaceUtils
/*     */ {
/*  44 */   private static final String BEAN_NAME_URL_HANDLER_MAPPING_BEAN_NAME = BeanNameUrlHandlerMapping.class
/*  45 */     .getName();
/*     */   
/*  47 */   private static final String SIMPLE_CONTROLLER_HANDLER_ADAPTER_BEAN_NAME = SimpleControllerHandlerAdapter.class
/*  48 */     .getName();
/*     */   
/*  50 */   private static final String HTTP_REQUEST_HANDLER_ADAPTER_BEAN_NAME = HttpRequestHandlerAdapter.class
/*  51 */     .getName();
/*     */   
/*     */   private static final String URL_PATH_HELPER_BEAN_NAME = "mvcUrlPathHelper";
/*     */   
/*     */   private static final String PATH_MATCHER_BEAN_NAME = "mvcPathMatcher";
/*     */   
/*     */   private static final String CORS_CONFIGURATION_BEAN_NAME = "mvcCorsConfigurations";
/*     */   
/*     */   public static void registerDefaultComponents(ParserContext parserContext, Object source)
/*     */   {
/*  61 */     registerBeanNameUrlHandlerMapping(parserContext, source);
/*  62 */     registerHttpRequestHandlerAdapter(parserContext, source);
/*  63 */     registerSimpleControllerHandlerAdapter(parserContext, source);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static RuntimeBeanReference registerUrlPathHelper(RuntimeBeanReference urlPathHelperRef, ParserContext parserContext, Object source)
/*     */   {
/*  72 */     if (urlPathHelperRef != null) {
/*  73 */       if (parserContext.getRegistry().isAlias("mvcUrlPathHelper")) {
/*  74 */         parserContext.getRegistry().removeAlias("mvcUrlPathHelper");
/*     */       }
/*  76 */       parserContext.getRegistry().registerAlias(urlPathHelperRef.getBeanName(), "mvcUrlPathHelper");
/*     */     }
/*  78 */     else if ((!parserContext.getRegistry().isAlias("mvcUrlPathHelper")) && 
/*  79 */       (!parserContext.getRegistry().containsBeanDefinition("mvcUrlPathHelper"))) {
/*  80 */       RootBeanDefinition urlPathHelperDef = new RootBeanDefinition(UrlPathHelper.class);
/*  81 */       urlPathHelperDef.setSource(source);
/*  82 */       urlPathHelperDef.setRole(2);
/*  83 */       parserContext.getRegistry().registerBeanDefinition("mvcUrlPathHelper", urlPathHelperDef);
/*  84 */       parserContext.registerComponent(new BeanComponentDefinition(urlPathHelperDef, "mvcUrlPathHelper"));
/*     */     }
/*  86 */     return new RuntimeBeanReference("mvcUrlPathHelper");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static RuntimeBeanReference registerPathMatcher(RuntimeBeanReference pathMatcherRef, ParserContext parserContext, Object source)
/*     */   {
/*  95 */     if (pathMatcherRef != null) {
/*  96 */       if (parserContext.getRegistry().isAlias("mvcPathMatcher")) {
/*  97 */         parserContext.getRegistry().removeAlias("mvcPathMatcher");
/*     */       }
/*  99 */       parserContext.getRegistry().registerAlias(pathMatcherRef.getBeanName(), "mvcPathMatcher");
/*     */     }
/* 101 */     else if ((!parserContext.getRegistry().isAlias("mvcPathMatcher")) && 
/* 102 */       (!parserContext.getRegistry().containsBeanDefinition("mvcPathMatcher"))) {
/* 103 */       RootBeanDefinition pathMatcherDef = new RootBeanDefinition(AntPathMatcher.class);
/* 104 */       pathMatcherDef.setSource(source);
/* 105 */       pathMatcherDef.setRole(2);
/* 106 */       parserContext.getRegistry().registerBeanDefinition("mvcPathMatcher", pathMatcherDef);
/* 107 */       parserContext.registerComponent(new BeanComponentDefinition(pathMatcherDef, "mvcPathMatcher"));
/*     */     }
/* 109 */     return new RuntimeBeanReference("mvcPathMatcher");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void registerBeanNameUrlHandlerMapping(ParserContext parserContext, Object source)
/*     */   {
/* 117 */     if (!parserContext.getRegistry().containsBeanDefinition(BEAN_NAME_URL_HANDLER_MAPPING_BEAN_NAME)) {
/* 118 */       RootBeanDefinition beanNameMappingDef = new RootBeanDefinition(BeanNameUrlHandlerMapping.class);
/* 119 */       beanNameMappingDef.setSource(source);
/* 120 */       beanNameMappingDef.setRole(2);
/* 121 */       beanNameMappingDef.getPropertyValues().add("order", Integer.valueOf(2));
/* 122 */       RuntimeBeanReference corsConfigurationsRef = registerCorsConfigurations(null, parserContext, source);
/* 123 */       beanNameMappingDef.getPropertyValues().add("corsConfigurations", corsConfigurationsRef);
/* 124 */       parserContext.getRegistry().registerBeanDefinition(BEAN_NAME_URL_HANDLER_MAPPING_BEAN_NAME, beanNameMappingDef);
/* 125 */       parserContext.registerComponent(new BeanComponentDefinition(beanNameMappingDef, BEAN_NAME_URL_HANDLER_MAPPING_BEAN_NAME));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void registerHttpRequestHandlerAdapter(ParserContext parserContext, Object source)
/*     */   {
/* 134 */     if (!parserContext.getRegistry().containsBeanDefinition(HTTP_REQUEST_HANDLER_ADAPTER_BEAN_NAME)) {
/* 135 */       RootBeanDefinition handlerAdapterDef = new RootBeanDefinition(HttpRequestHandlerAdapter.class);
/* 136 */       handlerAdapterDef.setSource(source);
/* 137 */       handlerAdapterDef.setRole(2);
/* 138 */       parserContext.getRegistry().registerBeanDefinition(HTTP_REQUEST_HANDLER_ADAPTER_BEAN_NAME, handlerAdapterDef);
/* 139 */       parserContext.registerComponent(new BeanComponentDefinition(handlerAdapterDef, HTTP_REQUEST_HANDLER_ADAPTER_BEAN_NAME));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void registerSimpleControllerHandlerAdapter(ParserContext parserContext, Object source)
/*     */   {
/* 148 */     if (!parserContext.getRegistry().containsBeanDefinition(SIMPLE_CONTROLLER_HANDLER_ADAPTER_BEAN_NAME)) {
/* 149 */       RootBeanDefinition handlerAdapterDef = new RootBeanDefinition(SimpleControllerHandlerAdapter.class);
/* 150 */       handlerAdapterDef.setSource(source);
/* 151 */       handlerAdapterDef.setRole(2);
/* 152 */       parserContext.getRegistry().registerBeanDefinition(SIMPLE_CONTROLLER_HANDLER_ADAPTER_BEAN_NAME, handlerAdapterDef);
/* 153 */       parserContext.registerComponent(new BeanComponentDefinition(handlerAdapterDef, SIMPLE_CONTROLLER_HANDLER_ADAPTER_BEAN_NAME));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static RuntimeBeanReference registerCorsConfigurations(Map<String, CorsConfiguration> corsConfigurations, ParserContext parserContext, Object source)
/*     */   {
/* 164 */     if (!parserContext.getRegistry().containsBeanDefinition("mvcCorsConfigurations")) {
/* 165 */       RootBeanDefinition corsConfigurationsDef = new RootBeanDefinition(LinkedHashMap.class);
/* 166 */       corsConfigurationsDef.setSource(source);
/* 167 */       corsConfigurationsDef.setRole(2);
/* 168 */       if (corsConfigurations != null) {
/* 169 */         corsConfigurationsDef.getConstructorArgumentValues().addIndexedArgumentValue(0, corsConfigurations);
/*     */       }
/* 171 */       parserContext.getReaderContext().getRegistry().registerBeanDefinition("mvcCorsConfigurations", corsConfigurationsDef);
/* 172 */       parserContext.registerComponent(new BeanComponentDefinition(corsConfigurationsDef, "mvcCorsConfigurations"));
/*     */     }
/* 174 */     else if (corsConfigurations != null) {
/* 175 */       BeanDefinition corsConfigurationsDef = parserContext.getRegistry().getBeanDefinition("mvcCorsConfigurations");
/* 176 */       corsConfigurationsDef.getConstructorArgumentValues().addIndexedArgumentValue(0, corsConfigurations);
/*     */     }
/* 178 */     return new RuntimeBeanReference("mvcCorsConfigurations");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getContentNegotiationManager(ParserContext context)
/*     */   {
/* 187 */     String name = AnnotationDrivenBeanDefinitionParser.HANDLER_MAPPING_BEAN_NAME;
/* 188 */     if (context.getRegistry().containsBeanDefinition(name)) {
/* 189 */       BeanDefinition handlerMappingBeanDef = context.getRegistry().getBeanDefinition(name);
/* 190 */       return handlerMappingBeanDef.getPropertyValues().get("contentNegotiationManager");
/*     */     }
/* 192 */     name = "mvcContentNegotiationManager";
/* 193 */     if (context.getRegistry().containsBeanDefinition(name)) {
/* 194 */       return new RuntimeBeanReference(name);
/*     */     }
/* 196 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\config\MvcNamespaceUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */