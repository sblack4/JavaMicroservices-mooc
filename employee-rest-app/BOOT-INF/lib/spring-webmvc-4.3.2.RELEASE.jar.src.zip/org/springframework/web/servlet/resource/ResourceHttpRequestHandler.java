/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URLDecoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.ResourceRegion;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpRange;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.ResourceHttpMessageConverter;
/*     */ import org.springframework.http.converter.ResourceRegionHttpMessageConverter;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.HttpRequestHandler;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.accept.ContentNegotiationManagerFactoryBean;
/*     */ import org.springframework.web.accept.PathExtensionContentNegotiationStrategy;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.cors.CorsConfiguration;
/*     */ import org.springframework.web.cors.CorsConfigurationSource;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.servlet.support.WebContentGenerator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceHttpRequestHandler
/*     */   extends WebContentGenerator
/*     */   implements HttpRequestHandler, InitializingBean, CorsConfigurationSource
/*     */ {
/*  97 */   private static final boolean contentLengthLongAvailable = ClassUtils.hasMethod(ServletResponse.class, "setContentLengthLong", new Class[] { Long.TYPE });
/*     */   
/*  99 */   private static final Log logger = LogFactory.getLog(ResourceHttpRequestHandler.class);
/*     */   
/*     */ 
/* 102 */   private final List<Resource> locations = new ArrayList(4);
/*     */   
/* 104 */   private final List<ResourceResolver> resourceResolvers = new ArrayList(4);
/*     */   
/* 106 */   private final List<ResourceTransformer> resourceTransformers = new ArrayList(4);
/*     */   
/*     */   private ResourceHttpMessageConverter resourceHttpMessageConverter;
/*     */   
/*     */   private ResourceRegionHttpMessageConverter resourceRegionHttpMessageConverter;
/*     */   
/*     */   private ContentNegotiationManager contentNegotiationManager;
/*     */   
/* 114 */   private final ContentNegotiationManagerFactoryBean cnmFactoryBean = new ContentNegotiationManagerFactoryBean();
/*     */   
/*     */   private CorsConfiguration corsConfiguration;
/*     */   
/*     */   public ResourceHttpRequestHandler()
/*     */   {
/* 120 */     super(new String[] { HttpMethod.GET.name(), HttpMethod.HEAD.name() });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocations(List<Resource> locations)
/*     */   {
/* 129 */     Assert.notNull(locations, "Locations list must not be null");
/* 130 */     this.locations.clear();
/* 131 */     this.locations.addAll(locations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Resource> getLocations()
/*     */   {
/* 139 */     return this.locations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResourceResolvers(List<ResourceResolver> resourceResolvers)
/*     */   {
/* 148 */     this.resourceResolvers.clear();
/* 149 */     if (resourceResolvers != null) {
/* 150 */       this.resourceResolvers.addAll(resourceResolvers);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<ResourceResolver> getResourceResolvers()
/*     */   {
/* 158 */     return this.resourceResolvers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResourceTransformers(List<ResourceTransformer> resourceTransformers)
/*     */   {
/* 166 */     this.resourceTransformers.clear();
/* 167 */     if (resourceTransformers != null) {
/* 168 */       this.resourceTransformers.addAll(resourceTransformers);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<ResourceTransformer> getResourceTransformers()
/*     */   {
/* 176 */     return this.resourceTransformers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResourceHttpMessageConverter(ResourceHttpMessageConverter resourceHttpMessageConverter)
/*     */   {
/* 185 */     this.resourceHttpMessageConverter = resourceHttpMessageConverter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceHttpMessageConverter getResourceHttpMessageConverter()
/*     */   {
/* 193 */     return this.resourceHttpMessageConverter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResourceRegionHttpMessageConverter(ResourceRegionHttpMessageConverter resourceRegionHttpMessageConverter)
/*     */   {
/* 202 */     this.resourceRegionHttpMessageConverter = resourceRegionHttpMessageConverter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceRegionHttpMessageConverter getResourceRegionHttpMessageConverter()
/*     */   {
/* 210 */     return this.resourceRegionHttpMessageConverter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContentNegotiationManager(ContentNegotiationManager contentNegotiationManager)
/*     */   {
/* 228 */     this.contentNegotiationManager = contentNegotiationManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationManager getContentNegotiationManager()
/*     */   {
/* 236 */     return this.contentNegotiationManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCorsConfiguration(CorsConfiguration corsConfiguration)
/*     */   {
/* 244 */     this.corsConfiguration = corsConfiguration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CorsConfiguration getCorsConfiguration(HttpServletRequest request)
/*     */   {
/* 252 */     return this.corsConfiguration;
/*     */   }
/*     */   
/*     */   protected void initServletContext(ServletContext servletContext)
/*     */   {
/* 257 */     this.cnmFactoryBean.setServletContext(servletContext);
/*     */   }
/*     */   
/*     */   public void afterPropertiesSet()
/*     */     throws Exception
/*     */   {
/* 263 */     if ((logger.isWarnEnabled()) && (CollectionUtils.isEmpty(this.locations))) {
/* 264 */       logger.warn("Locations list is empty. No resources will be served unless a custom ResourceResolver is configured as an alternative to PathResourceResolver.");
/*     */     }
/*     */     
/* 267 */     if (this.resourceResolvers.isEmpty()) {
/* 268 */       this.resourceResolvers.add(new PathResourceResolver());
/*     */     }
/* 270 */     initAllowedLocations();
/* 271 */     if (this.contentNegotiationManager == null) {
/* 272 */       this.cnmFactoryBean.afterPropertiesSet();
/* 273 */       this.contentNegotiationManager = this.cnmFactoryBean.getObject();
/*     */     }
/* 275 */     if (this.resourceHttpMessageConverter == null) {
/* 276 */       this.resourceHttpMessageConverter = new ResourceHttpMessageConverter();
/*     */     }
/* 278 */     if (this.resourceRegionHttpMessageConverter == null) {
/* 279 */       this.resourceRegionHttpMessageConverter = new ResourceRegionHttpMessageConverter();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initAllowedLocations()
/*     */   {
/* 289 */     if (CollectionUtils.isEmpty(this.locations)) {
/* 290 */       return;
/*     */     }
/* 292 */     for (int i = getResourceResolvers().size() - 1; i >= 0; i--) {
/* 293 */       if ((getResourceResolvers().get(i) instanceof PathResourceResolver)) {
/* 294 */         PathResourceResolver pathResolver = (PathResourceResolver)getResourceResolvers().get(i);
/* 295 */         if (!ObjectUtils.isEmpty(pathResolver.getAllowedLocations())) break;
/* 296 */         pathResolver.setAllowedLocations((Resource[])getLocations().toArray(new Resource[getLocations().size()])); break;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleRequest(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 320 */     Resource resource = getResource(request);
/* 321 */     if (resource == null) {
/* 322 */       logger.trace("No matching resource found - returning 404");
/* 323 */       response.sendError(404);
/* 324 */       return;
/*     */     }
/*     */     
/* 327 */     if (HttpMethod.OPTIONS.matches(request.getMethod())) {
/* 328 */       response.setHeader("Allow", getAllowHeader());
/* 329 */       return;
/*     */     }
/*     */     
/*     */ 
/* 333 */     checkRequest(request);
/*     */     
/*     */ 
/* 336 */     if (new ServletWebRequest(request, response).checkNotModified(resource.lastModified())) {
/* 337 */       logger.trace("Resource not modified - returning 304");
/* 338 */       return;
/*     */     }
/*     */     
/*     */ 
/* 342 */     prepareResponse(response);
/*     */     
/*     */ 
/* 345 */     MediaType mediaType = getMediaType(request, resource);
/* 346 */     if (mediaType != null) {
/* 347 */       if (logger.isTraceEnabled()) {
/* 348 */         logger.trace("Determined media type '" + mediaType + "' for " + resource);
/*     */       }
/*     */       
/*     */     }
/* 352 */     else if (logger.isTraceEnabled()) {
/* 353 */       logger.trace("No media type found for " + resource + " - not sending a content-type header");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 358 */     if ("HEAD".equals(request.getMethod())) {
/* 359 */       setHeaders(response, resource, mediaType);
/* 360 */       logger.trace("HEAD request - skipping content");
/* 361 */       return;
/*     */     }
/*     */     
/* 364 */     ServletServerHttpResponse outputMessage = new ServletServerHttpResponse(response);
/* 365 */     if (request.getHeader("Range") == null) {
/* 366 */       setHeaders(response, resource, mediaType);
/* 367 */       this.resourceHttpMessageConverter.write(resource, mediaType, outputMessage);
/*     */     }
/*     */     else {
/* 370 */       response.setHeader("Accept-Ranges", "bytes");
/* 371 */       ServletServerHttpRequest inputMessage = new ServletServerHttpRequest(request);
/*     */       try {
/* 373 */         List<HttpRange> httpRanges = inputMessage.getHeaders().getRange();
/* 374 */         response.setStatus(206);
/* 375 */         if (httpRanges.size() == 1) {
/* 376 */           ResourceRegion resourceRegion = ((HttpRange)httpRanges.get(0)).toResourceRegion(resource);
/* 377 */           this.resourceRegionHttpMessageConverter.write(resourceRegion, mediaType, outputMessage);
/*     */         }
/*     */         else {
/* 380 */           this.resourceRegionHttpMessageConverter.write(
/* 381 */             HttpRange.toResourceRegions(httpRanges, resource), mediaType, outputMessage);
/*     */         }
/*     */       }
/*     */       catch (IllegalArgumentException ex) {
/* 385 */         response.setHeader("Content-Range", "bytes */" + resource.contentLength());
/* 386 */         response.sendError(416);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected Resource getResource(HttpServletRequest request) throws IOException {
/* 392 */     String path = (String)request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE);
/* 393 */     if (path == null) {
/* 394 */       throw new IllegalStateException("Required request attribute '" + HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE + "' is not set");
/*     */     }
/*     */     
/* 397 */     path = processPath(path);
/* 398 */     if ((!StringUtils.hasText(path)) || (isInvalidPath(path))) {
/* 399 */       if (logger.isTraceEnabled()) {
/* 400 */         logger.trace("Ignoring invalid resource path [" + path + "]");
/*     */       }
/* 402 */       return null;
/*     */     }
/* 404 */     if (path.contains("%")) {
/*     */       try
/*     */       {
/* 407 */         if (isInvalidPath(URLDecoder.decode(path, "UTF-8"))) {
/* 408 */           if (logger.isTraceEnabled()) {
/* 409 */             logger.trace("Ignoring invalid resource path with escape sequences [" + path + "].");
/*     */           }
/* 411 */           return null;
/*     */         }
/*     */       }
/*     */       catch (IllegalArgumentException localIllegalArgumentException) {}
/*     */     }
/*     */     
/*     */ 
/* 418 */     ResourceResolverChain resolveChain = new DefaultResourceResolverChain(getResourceResolvers());
/* 419 */     Resource resource = resolveChain.resolveResource(request, path, getLocations());
/* 420 */     if ((resource == null) || (getResourceTransformers().isEmpty())) {
/* 421 */       return resource;
/*     */     }
/*     */     
/* 424 */     ResourceTransformerChain transformChain = new DefaultResourceTransformerChain(resolveChain, getResourceTransformers());
/* 425 */     resource = transformChain.transform(request, resource);
/* 426 */     return resource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String processPath(String path)
/*     */   {
/* 437 */     boolean slash = false;
/* 438 */     for (int i = 0; i < path.length(); i++) {
/* 439 */       if (path.charAt(i) == '/') {
/* 440 */         slash = true;
/*     */       }
/* 442 */       else if ((path.charAt(i) > ' ') && (path.charAt(i) != '')) {
/* 443 */         if ((i == 0) || ((i == 1) && (slash))) {
/* 444 */           return path;
/*     */         }
/* 446 */         path = slash ? "/" + path.substring(i) : path.substring(i);
/* 447 */         if (logger.isTraceEnabled()) {
/* 448 */           logger.trace("Path after trimming leading '/' and control characters: " + path);
/*     */         }
/* 450 */         return path;
/*     */       }
/*     */     }
/* 453 */     return slash ? "/" : "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isInvalidPath(String path)
/*     */   {
/* 472 */     if (logger.isTraceEnabled()) {
/* 473 */       logger.trace("Applying \"invalid path\" checks to path: " + path);
/*     */     }
/* 475 */     if ((path.contains("WEB-INF")) || (path.contains("META-INF"))) {
/* 476 */       if (logger.isTraceEnabled()) {
/* 477 */         logger.trace("Path contains \"WEB-INF\" or \"META-INF\".");
/*     */       }
/* 479 */       return true;
/*     */     }
/* 481 */     if (path.contains(":/")) {
/* 482 */       String relativePath = path.charAt(0) == '/' ? path.substring(1) : path;
/* 483 */       if ((ResourceUtils.isUrl(relativePath)) || (relativePath.startsWith("url:"))) {
/* 484 */         if (logger.isTraceEnabled()) {
/* 485 */           logger.trace("Path represents URL or has \"url:\" prefix.");
/*     */         }
/* 487 */         return true;
/*     */       }
/*     */     }
/* 490 */     if (path.contains("..")) {
/* 491 */       path = StringUtils.cleanPath(path);
/* 492 */       if (path.contains("../")) {
/* 493 */         if (logger.isTraceEnabled()) {
/* 494 */           logger.trace("Path contains \"../\" after call to StringUtils#cleanPath.");
/*     */         }
/* 496 */         return true;
/*     */       }
/*     */     }
/* 499 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MediaType getMediaType(HttpServletRequest request, Resource resource)
/*     */   {
/* 516 */     MediaType mediaType = getMediaType(resource);
/* 517 */     if (mediaType != null) {
/* 518 */       return mediaType;
/*     */     }
/*     */     
/* 521 */     Class<PathExtensionContentNegotiationStrategy> clazz = PathExtensionContentNegotiationStrategy.class;
/* 522 */     PathExtensionContentNegotiationStrategy strategy = (PathExtensionContentNegotiationStrategy)this.contentNegotiationManager.getStrategy(clazz);
/* 523 */     if (strategy != null) {
/* 524 */       mediaType = strategy.getMediaTypeForResource(resource);
/*     */     }
/*     */     
/* 527 */     if (mediaType == null) {
/* 528 */       ServletWebRequest webRequest = new ServletWebRequest(request);
/*     */       try {
/* 530 */         List<MediaType> mediaTypes = getContentNegotiationManager().resolveMediaTypes(webRequest);
/* 531 */         if (!mediaTypes.isEmpty()) {
/* 532 */           mediaType = (MediaType)mediaTypes.get(0);
/*     */         }
/*     */       }
/*     */       catch (HttpMediaTypeNotAcceptableException localHttpMediaTypeNotAcceptableException) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 540 */     return mediaType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected MediaType getMediaType(Resource resource)
/*     */   {
/* 552 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setHeaders(HttpServletResponse response, Resource resource, MediaType mediaType)
/*     */     throws IOException
/*     */   {
/* 564 */     long length = resource.contentLength();
/* 565 */     if (length > 2147483647L) {
/* 566 */       if (contentLengthLongAvailable) {
/* 567 */         response.setContentLengthLong(length);
/*     */       }
/*     */       else {
/* 570 */         response.setHeader("Content-Length", Long.toString(length));
/*     */       }
/*     */     }
/*     */     else {
/* 574 */       response.setContentLength((int)length);
/*     */     }
/*     */     
/* 577 */     if (mediaType != null) {
/* 578 */       response.setContentType(mediaType.toString());
/*     */     }
/* 580 */     if ((resource instanceof EncodedResource)) {
/* 581 */       response.setHeader("Content-Encoding", ((EncodedResource)resource).getContentEncoding());
/*     */     }
/* 583 */     if ((resource instanceof VersionedResource)) {
/* 584 */       response.setHeader("ETag", "\"" + ((VersionedResource)resource).getVersion() + "\"");
/*     */     }
/* 586 */     response.setHeader("Accept-Ranges", "bytes");
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 592 */     return "ResourceHttpRequestHandler [locations=" + getLocations() + ", resolvers=" + getResourceResolvers() + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-webmvc-4.3.2.RELEASE.jar!\org\springframework\web\servlet\resource\ResourceHttpRequestHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */