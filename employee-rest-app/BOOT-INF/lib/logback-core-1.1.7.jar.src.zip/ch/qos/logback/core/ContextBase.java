/*     */ package ch.qos.logback.core;
/*     */ 
/*     */ import ch.qos.logback.core.spi.LifeCycle;
/*     */ import ch.qos.logback.core.spi.LogbackLock;
/*     */ import ch.qos.logback.core.status.StatusManager;
/*     */ import ch.qos.logback.core.util.ExecutorServiceUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextBase
/*     */   implements Context, LifeCycle
/*     */ {
/*  35 */   private long birthTime = System.currentTimeMillis();
/*     */   
/*     */   private String name;
/*  38 */   private StatusManager sm = new BasicStatusManager();
/*     */   
/*     */ 
/*     */ 
/*  42 */   Map<String, String> propertyMap = new HashMap();
/*  43 */   Map<String, Object> objectMap = new HashMap();
/*     */   
/*  45 */   LogbackLock configurationLock = new LogbackLock();
/*     */   
/*     */   private ExecutorService executorService;
/*     */   private ScheduledExecutorService scheduledExecutorService;
/*  49 */   protected List<ScheduledFuture<?>> scheduledFutures = new ArrayList(1);
/*     */   private LifeCycleManager lifeCycleManager;
/*     */   private boolean started;
/*     */   
/*     */   public ContextBase() {
/*  54 */     initCollisionMaps();
/*     */   }
/*     */   
/*     */   public StatusManager getStatusManager() {
/*  58 */     return this.sm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStatusManager(StatusManager statusManager)
/*     */   {
/*  73 */     if (statusManager == null) {
/*  74 */       throw new IllegalArgumentException("null StatusManager not allowed");
/*     */     }
/*  76 */     this.sm = statusManager;
/*     */   }
/*     */   
/*     */   public Map<String, String> getCopyOfPropertyMap() {
/*  80 */     return new HashMap(this.propertyMap);
/*     */   }
/*     */   
/*     */   public void putProperty(String key, String val) {
/*  84 */     this.propertyMap.put(key, val);
/*     */   }
/*     */   
/*     */   protected void initCollisionMaps() {
/*  88 */     putObject("RFA_FILENAME_COLLISION_MAP", new HashMap());
/*  89 */     putObject("RFA_FILENAME_PATTERN_COLLISION_MAP", new HashMap());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getProperty(String key)
/*     */   {
/* 100 */     if ("CONTEXT_NAME".equals(key)) {
/* 101 */       return getName();
/*     */     }
/* 103 */     return (String)this.propertyMap.get(key);
/*     */   }
/*     */   
/*     */   public Object getObject(String key) {
/* 107 */     return this.objectMap.get(key);
/*     */   }
/*     */   
/*     */   public void putObject(String key, Object value) {
/* 111 */     this.objectMap.put(key, value);
/*     */   }
/*     */   
/*     */   public void removeObject(String key) {
/* 115 */     this.objectMap.remove(key);
/*     */   }
/*     */   
/*     */   public String getName() {
/* 119 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void start()
/*     */   {
/* 126 */     this.started = true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void stop()
/*     */   {
/* 132 */     stopExecutorServices();
/* 133 */     this.started = false;
/*     */   }
/*     */   
/*     */   public boolean isStarted() {
/* 137 */     return this.started;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/* 145 */     removeShutdownHook();
/* 146 */     getLifeCycleManager().reset();
/* 147 */     this.propertyMap.clear();
/* 148 */     this.objectMap.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String name)
/*     */     throws IllegalStateException
/*     */   {
/* 159 */     if ((name != null) && (name.equals(this.name))) {
/* 160 */       return;
/*     */     }
/* 162 */     if ((this.name == null) || ("default".equals(this.name))) {
/* 163 */       this.name = name;
/*     */     } else {
/* 165 */       throw new IllegalStateException("Context has been already given a name");
/*     */     }
/*     */   }
/*     */   
/*     */   public long getBirthTime() {
/* 170 */     return this.birthTime;
/*     */   }
/*     */   
/*     */   public Object getConfigurationLock() {
/* 174 */     return this.configurationLock;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized ExecutorService getExecutorService()
/*     */   {
/* 182 */     return getScheduledExecutorService();
/*     */   }
/*     */   
/*     */   public synchronized ScheduledExecutorService getScheduledExecutorService()
/*     */   {
/* 187 */     if (this.scheduledExecutorService == null) {
/* 188 */       this.scheduledExecutorService = ExecutorServiceUtil.newScheduledExecutorService();
/*     */     }
/* 190 */     return this.scheduledExecutorService;
/*     */   }
/*     */   
/*     */   private synchronized void stopExecutorServices() {
/* 194 */     if (this.executorService != null) {
/* 195 */       ExecutorServiceUtil.shutdown(this.executorService);
/* 196 */       this.executorService = null;
/*     */     }
/* 198 */     if (this.scheduledExecutorService != null) {
/* 199 */       ExecutorServiceUtil.shutdown(this.scheduledExecutorService);
/* 200 */       this.scheduledExecutorService = null;
/*     */     }
/*     */   }
/*     */   
/*     */   private void removeShutdownHook() {
/* 205 */     Thread hook = (Thread)getObject("SHUTDOWN_HOOK");
/* 206 */     if (hook != null) {
/* 207 */       removeObject("SHUTDOWN_HOOK");
/*     */       try {
/* 209 */         Runtime.getRuntime().removeShutdownHook(hook);
/*     */       }
/*     */       catch (IllegalStateException e) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void register(LifeCycle component)
/*     */   {
/* 218 */     getLifeCycleManager().register(component);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   synchronized LifeCycleManager getLifeCycleManager()
/*     */   {
/* 234 */     if (this.lifeCycleManager == null) {
/* 235 */       this.lifeCycleManager = new LifeCycleManager();
/*     */     }
/* 237 */     return this.lifeCycleManager;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 242 */     return this.name;
/*     */   }
/*     */   
/*     */   public void addScheduledFuture(ScheduledFuture<?> scheduledFuture)
/*     */   {
/* 247 */     this.scheduledFutures.add(scheduledFuture);
/*     */   }
/*     */   
/*     */   public List<ScheduledFuture<?>> getScheduledFutures() {
/* 251 */     return new ArrayList(this.scheduledFutures);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\logback-core-1.1.7.jar!\ch\qos\logback\core\ContextBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */