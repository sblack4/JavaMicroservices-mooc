/*     */ package ch.qos.logback.core.rolling.helper;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.pattern.Converter;
/*     */ import ch.qos.logback.core.pattern.ConverterUtil;
/*     */ import ch.qos.logback.core.pattern.LiteralConverter;
/*     */ import ch.qos.logback.core.pattern.parser.Node;
/*     */ import ch.qos.logback.core.pattern.parser.Parser;
/*     */ import ch.qos.logback.core.pattern.util.AlmostAsIsEscapeUtil;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.spi.ScanException;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileNamePattern
/*     */   extends ContextAwareBase
/*     */ {
/*  40 */   static final Map<String, String> CONVERTER_MAP = new HashMap();
/*     */   
/*  42 */   static { CONVERTER_MAP.put("i", IntegerTokenConverter.class.getName());
/*  43 */     CONVERTER_MAP.put("d", DateTokenConverter.class.getName());
/*     */   }
/*     */   
/*     */ 
/*     */   String pattern;
/*     */   
/*     */   public FileNamePattern(String patternArg, Context contextArg)
/*     */   {
/*  51 */     setPattern(FileFilterUtil.slashify(patternArg));
/*  52 */     setContext(contextArg);
/*  53 */     parse();
/*  54 */     ConverterUtil.startConverters(this.headTokenConverter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void parse()
/*     */   {
/*     */     try
/*     */     {
/*  63 */       String patternForParsing = escapeRightParantesis(this.pattern);
/*  64 */       Parser<Object> p = new Parser(patternForParsing, new AlmostAsIsEscapeUtil());
/*  65 */       p.setContext(this.context);
/*  66 */       Node t = p.parse();
/*  67 */       this.headTokenConverter = p.compile(t, CONVERTER_MAP);
/*     */     }
/*     */     catch (ScanException sce) {
/*  70 */       addError("Failed to parse pattern \"" + this.pattern + "\".", sce);
/*     */     }
/*     */   }
/*     */   
/*     */   String escapeRightParantesis(String in) {
/*  75 */     return this.pattern.replace(")", "\\)");
/*     */   }
/*     */   
/*     */   public String toString() {
/*  79 */     return this.pattern;
/*     */   }
/*     */   
/*     */   public DateTokenConverter<Object> getPrimaryDateTokenConverter() {
/*  83 */     Converter<Object> p = this.headTokenConverter;
/*     */     
/*  85 */     while (p != null) {
/*  86 */       if ((p instanceof DateTokenConverter)) {
/*  87 */         DateTokenConverter<Object> dtc = (DateTokenConverter)p;
/*     */         
/*  89 */         if (dtc.isPrimary()) {
/*  90 */           return dtc;
/*     */         }
/*     */       }
/*  93 */       p = p.getNext();
/*     */     }
/*     */     
/*  96 */     return null;
/*     */   }
/*     */   
/*     */   public IntegerTokenConverter getIntegerTokenConverter() {
/* 100 */     Converter<Object> p = this.headTokenConverter;
/*     */     
/* 102 */     while (p != null) {
/* 103 */       if ((p instanceof IntegerTokenConverter)) {
/* 104 */         return (IntegerTokenConverter)p;
/*     */       }
/*     */       
/* 107 */       p = p.getNext();
/*     */     }
/* 109 */     return null;
/*     */   }
/*     */   
/*     */   public boolean hasIntegerTokenCOnverter() {
/* 113 */     IntegerTokenConverter itc = getIntegerTokenConverter();
/* 114 */     return itc != null;
/*     */   }
/*     */   
/*     */   public String convertMultipleArguments(Object... objectList) {
/* 118 */     StringBuilder buf = new StringBuilder();
/* 119 */     Converter<Object> c = this.headTokenConverter;
/* 120 */     while (c != null) {
/* 121 */       if ((c instanceof MonoTypedConverter)) {
/* 122 */         MonoTypedConverter monoTyped = (MonoTypedConverter)c;
/* 123 */         for (Object o : objectList) {
/* 124 */           if (monoTyped.isApplicable(o)) {
/* 125 */             buf.append(c.convert(o));
/*     */           }
/*     */         }
/*     */       } else {
/* 129 */         buf.append(c.convert(objectList));
/*     */       }
/* 131 */       c = c.getNext();
/*     */     }
/* 133 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public String convert(Object o) {
/* 137 */     StringBuilder buf = new StringBuilder();
/* 138 */     Converter<Object> p = this.headTokenConverter;
/* 139 */     while (p != null) {
/* 140 */       buf.append(p.convert(o));
/* 141 */       p = p.getNext();
/*     */     }
/* 143 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public String convertInt(int i) {
/* 147 */     return convert(Integer.valueOf(i));
/*     */   }
/*     */   
/*     */   public void setPattern(String pattern) {
/* 151 */     if (pattern != null)
/*     */     {
/* 153 */       this.pattern = pattern.trim();
/*     */     }
/*     */   }
/*     */   
/*     */   public String getPattern() {
/* 158 */     return this.pattern;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   Converter<Object> headTokenConverter;
/*     */   
/*     */ 
/*     */   public String toRegexForFixedDate(Date date)
/*     */   {
/* 168 */     StringBuilder buf = new StringBuilder();
/* 169 */     Converter<Object> p = this.headTokenConverter;
/* 170 */     while (p != null) {
/* 171 */       if ((p instanceof LiteralConverter)) {
/* 172 */         buf.append(p.convert(null));
/* 173 */       } else if ((p instanceof IntegerTokenConverter)) {
/* 174 */         buf.append("(\\d{1,3})");
/* 175 */       } else if ((p instanceof DateTokenConverter)) {
/* 176 */         buf.append(p.convert(date));
/*     */       }
/* 178 */       p = p.getNext();
/*     */     }
/* 180 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toRegex()
/*     */   {
/* 187 */     StringBuilder buf = new StringBuilder();
/* 188 */     Converter<Object> p = this.headTokenConverter;
/* 189 */     while (p != null) {
/* 190 */       if ((p instanceof LiteralConverter)) {
/* 191 */         buf.append(p.convert(null));
/* 192 */       } else if ((p instanceof IntegerTokenConverter)) {
/* 193 */         buf.append("\\d{1,2}");
/* 194 */       } else if ((p instanceof DateTokenConverter)) {
/* 195 */         DateTokenConverter<Object> dtc = (DateTokenConverter)p;
/* 196 */         buf.append(dtc.toRegex());
/*     */       }
/* 198 */       p = p.getNext();
/*     */     }
/* 200 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\logback-core-1.1.7.jar!\ch\qos\logback\core\rolling\helper\FileNamePattern.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */