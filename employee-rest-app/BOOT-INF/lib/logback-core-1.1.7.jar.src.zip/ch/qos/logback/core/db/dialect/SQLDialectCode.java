package ch.qos.logback.core.db.dialect;

public enum SQLDialectCode
{
  UNKNOWN_DIALECT,  POSTGRES_DIALECT,  MYSQL_DIALECT,  ORACLE_DIALECT,  MSSQL_DIALECT,  HSQL_DIALECT,  H2_DIALECT,  SYBASE_SQLANYWHERE_DIALECT,  SQLITE_DIALECT;
  
  private SQLDialectCode() {}
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\logback-core-1.1.7.jar!\ch\qos\logback\core\db\dialect\SQLDialectCode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */