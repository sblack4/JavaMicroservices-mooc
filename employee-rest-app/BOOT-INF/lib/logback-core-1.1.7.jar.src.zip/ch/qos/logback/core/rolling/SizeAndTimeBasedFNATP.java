/*     */ package ch.qos.logback.core.rolling;
/*     */ 
/*     */ import ch.qos.logback.core.joran.spi.NoAutoStart;
/*     */ import ch.qos.logback.core.rolling.helper.ArchiveRemover;
/*     */ import ch.qos.logback.core.rolling.helper.CompressionMode;
/*     */ import ch.qos.logback.core.rolling.helper.FileFilterUtil;
/*     */ import ch.qos.logback.core.rolling.helper.FileNamePattern;
/*     */ import ch.qos.logback.core.rolling.helper.SizeAndTimeBasedArchiveRemover;
/*     */ import ch.qos.logback.core.util.DefaultInvocationGate;
/*     */ import ch.qos.logback.core.util.FileSize;
/*     */ import ch.qos.logback.core.util.InvocationGate;
/*     */ import java.io.File;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @NoAutoStart
/*     */ public class SizeAndTimeBasedFNATP<E>
/*     */   extends TimeBasedFileNamingAndTriggeringPolicyBase<E>
/*     */ {
/*  32 */   int currentPeriodsCounter = 0;
/*     */   FileSize maxFileSize;
/*     */   String maxFileSizeAsString;
/*  35 */   long nextSizeCheck = 0L;
/*  36 */   static String MISSING_INT_TOKEN = "Missing integer token, that is %i, in FileNamePattern [";
/*  37 */   static String MISSING_DATE_TOKEN = "Missing date token, that is %d, in FileNamePattern [";
/*     */   
/*     */ 
/*     */   public void start()
/*     */   {
/*  42 */     super.start();
/*     */     
/*  44 */     if (!super.isErrorFree()) {
/*  45 */       return;
/*     */     }
/*  47 */     if (!validateDateAndIntegerTokens()) {
/*  48 */       this.started = false;
/*  49 */       return;
/*     */     }
/*     */     
/*  52 */     this.archiveRemover = createArchiveRemover();
/*  53 */     this.archiveRemover.setContext(this.context);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  58 */     String regex = this.tbrp.fileNamePattern.toRegexForFixedDate(this.dateInCurrentPeriod);
/*  59 */     String stemRegex = FileFilterUtil.afterLastSlash(regex);
/*     */     
/*  61 */     computeCurrentPeriodsHighestCounterValue(stemRegex);
/*     */     
/*  63 */     this.started = true;
/*     */   }
/*     */   
/*     */   private boolean validateDateAndIntegerTokens() {
/*  67 */     boolean inError = false;
/*  68 */     if (this.tbrp.fileNamePattern.getIntegerTokenConverter() == null) {
/*  69 */       inError = true;
/*  70 */       addError(MISSING_INT_TOKEN + this.tbrp.fileNamePatternStr + "]");
/*  71 */       addError("See also http://logback.qos.ch/codes.html#sat_missing_integer_token");
/*     */     }
/*  73 */     if (this.tbrp.fileNamePattern.getPrimaryDateTokenConverter() == null) {
/*  74 */       inError = true;
/*  75 */       addError(MISSING_DATE_TOKEN + this.tbrp.fileNamePatternStr + "]");
/*     */     }
/*     */     
/*  78 */     return !inError;
/*     */   }
/*     */   
/*     */   protected ArchiveRemover createArchiveRemover() {
/*  82 */     return new SizeAndTimeBasedArchiveRemover(this.tbrp.fileNamePattern, this.rc);
/*     */   }
/*     */   
/*     */   void computeCurrentPeriodsHighestCounterValue(String stemRegex) {
/*  86 */     File file = new File(getCurrentPeriodsFileNameWithoutCompressionSuffix());
/*  87 */     File parentDir = file.getParentFile();
/*     */     
/*  89 */     File[] matchingFileArray = FileFilterUtil.filesInFolderMatchingStemRegex(parentDir, stemRegex);
/*     */     
/*  91 */     if ((matchingFileArray == null) || (matchingFileArray.length == 0)) {
/*  92 */       this.currentPeriodsCounter = 0;
/*  93 */       return;
/*     */     }
/*  95 */     this.currentPeriodsCounter = FileFilterUtil.findHighestCounter(matchingFileArray, stemRegex);
/*     */     
/*     */ 
/*     */ 
/*  99 */     if ((this.tbrp.getParentsRawFileProperty() != null) || (this.tbrp.compressionMode != CompressionMode.NONE))
/*     */     {
/* 101 */       this.currentPeriodsCounter += 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/* 106 */   InvocationGate invocationGate = new DefaultInvocationGate();
/*     */   
/*     */   public boolean isTriggeringEvent(File activeFile, E event)
/*     */   {
/* 110 */     long time = getCurrentTime();
/*     */     
/*     */ 
/* 113 */     if (time >= this.nextCheck) {
/* 114 */       Date dateInElapsedPeriod = this.dateInCurrentPeriod;
/* 115 */       this.elapsedPeriodsFileName = this.tbrp.fileNamePatternWCS.convertMultipleArguments(new Object[] { dateInElapsedPeriod, Integer.valueOf(this.currentPeriodsCounter) });
/* 116 */       this.currentPeriodsCounter = 0;
/* 117 */       setDateInCurrentPeriod(time);
/* 118 */       computeNextCheck();
/* 119 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 124 */     if (this.invocationGate.isTooSoon(time)) {
/* 125 */       return false;
/*     */     }
/*     */     
/* 128 */     if (activeFile.length() >= this.maxFileSize.getSize())
/*     */     {
/* 130 */       this.elapsedPeriodsFileName = this.tbrp.fileNamePatternWCS.convertMultipleArguments(new Object[] { this.dateInCurrentPeriod, Integer.valueOf(this.currentPeriodsCounter) });
/* 131 */       this.currentPeriodsCounter += 1;
/* 132 */       return true;
/*     */     }
/*     */     
/* 135 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getCurrentPeriodsFileNameWithoutCompressionSuffix()
/*     */   {
/* 141 */     return this.tbrp.fileNamePatternWCS.convertMultipleArguments(new Object[] { this.dateInCurrentPeriod, Integer.valueOf(this.currentPeriodsCounter) });
/*     */   }
/*     */   
/*     */   public String getMaxFileSize() {
/* 145 */     return this.maxFileSizeAsString;
/*     */   }
/*     */   
/*     */   public void setMaxFileSize(String maxFileSize) {
/* 149 */     this.maxFileSizeAsString = maxFileSize;
/* 150 */     this.maxFileSize = FileSize.valueOf(maxFileSize);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\logback-core-1.1.7.jar!\ch\qos\logback\core\rolling\SizeAndTimeBasedFNATP.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */