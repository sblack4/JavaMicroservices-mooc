/*     */ package ch.qos.logback.core.rolling;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.FileAppender;
/*     */ import ch.qos.logback.core.rolling.helper.CompressionMode;
/*     */ import ch.qos.logback.core.rolling.helper.FileNamePattern;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RollingFileAppender<E>
/*     */   extends FileAppender<E>
/*     */ {
/*     */   File currentlyActiveFile;
/*     */   TriggeringPolicy<E> triggeringPolicy;
/*     */   RollingPolicy rollingPolicy;
/*  45 */   private static String RFA_NO_TP_URL = "http://logback.qos.ch/codes.html#rfa_no_tp";
/*  46 */   private static String RFA_NO_RP_URL = "http://logback.qos.ch/codes.html#rfa_no_rp";
/*  47 */   private static String COLLISION_URL = "http://logback.qos.ch/codes.html#rfa_collision";
/*  48 */   private static String RFA_LATE_FILE_URL = "http://logback.qos.ch/codes.html#rfa_file_after";
/*     */   
/*     */   public void start() {
/*  51 */     if (this.triggeringPolicy == null) {
/*  52 */       addWarn("No TriggeringPolicy was set for the RollingFileAppender named " + getName());
/*  53 */       addWarn("For more information, please visit " + RFA_NO_TP_URL);
/*  54 */       return;
/*     */     }
/*  56 */     if (!this.triggeringPolicy.isStarted()) {
/*  57 */       addWarn("TriggeringPolicy has not started. RollingFileAppender will not start");
/*  58 */       return;
/*     */     }
/*     */     
/*  61 */     if (checkForCollisionsInPreviousRollingFileAppenders()) {
/*  62 */       addError("Collisions detected with FileAppender/RollingAppender instances defined earlier. Aborting.");
/*  63 */       addError("For more information, please visit " + COLLISION_WITH_EARLIER_APPENDER_URL);
/*  64 */       return;
/*     */     }
/*     */     
/*     */ 
/*  68 */     if (!this.append) {
/*  69 */       addWarn("Append mode is mandatory for RollingFileAppender. Defaulting to append=true.");
/*  70 */       this.append = true;
/*     */     }
/*     */     
/*  73 */     if (this.rollingPolicy == null) {
/*  74 */       addError("No RollingPolicy was set for the RollingFileAppender named " + getName());
/*  75 */       addError("For more information, please visit " + RFA_NO_RP_URL);
/*  76 */       return;
/*     */     }
/*     */     
/*     */ 
/*  80 */     if (checkForFileAndPatternCollisions()) {
/*  81 */       addError("File property collides with fileNamePattern. Aborting.");
/*  82 */       addError("For more information, please visit " + COLLISION_URL);
/*  83 */       return;
/*     */     }
/*     */     
/*  86 */     if (isPrudent()) {
/*  87 */       if (rawFileProperty() != null) {
/*  88 */         addWarn("Setting \"File\" property to null on account of prudent mode");
/*  89 */         setFile(null);
/*     */       }
/*  91 */       if (this.rollingPolicy.getCompressionMode() != CompressionMode.NONE) {
/*  92 */         addError("Compression is not supported in prudent mode. Aborting");
/*  93 */         return;
/*     */       }
/*     */     }
/*     */     
/*  97 */     this.currentlyActiveFile = new File(getFile());
/*  98 */     addInfo("Active log file name: " + getFile());
/*  99 */     super.start();
/*     */   }
/*     */   
/*     */   private boolean checkForFileAndPatternCollisions() {
/* 103 */     if ((this.triggeringPolicy instanceof RollingPolicyBase)) {
/* 104 */       RollingPolicyBase base = (RollingPolicyBase)this.triggeringPolicy;
/* 105 */       FileNamePattern fileNamePattern = base.fileNamePattern;
/*     */       
/* 107 */       if ((fileNamePattern != null) && (this.fileName != null)) {
/* 108 */         String regex = fileNamePattern.toRegex();
/* 109 */         return this.fileName.matches(regex);
/*     */       }
/*     */     }
/* 112 */     return false;
/*     */   }
/*     */   
/*     */   private boolean checkForCollisionsInPreviousRollingFileAppenders() {
/* 116 */     boolean collisionResult = false;
/* 117 */     if ((this.triggeringPolicy instanceof RollingPolicyBase)) {
/* 118 */       RollingPolicyBase base = (RollingPolicyBase)this.triggeringPolicy;
/* 119 */       FileNamePattern fileNamePattern = base.fileNamePattern;
/* 120 */       boolean collisionsDetected = innerCheckForFileNamePatternCollisionInPreviousRFA(fileNamePattern.toString());
/* 121 */       if (collisionsDetected)
/* 122 */         collisionResult = true;
/*     */     }
/* 124 */     return collisionResult;
/*     */   }
/*     */   
/*     */   private boolean innerCheckForFileNamePatternCollisionInPreviousRFA(String fileNamePattern) {
/* 128 */     boolean collisionsDetected = false;
/*     */     
/* 130 */     Map<String, String> map = (Map)this.context.getObject("RFA_FILENAME_COLLISION_MAP");
/* 131 */     if (map == null) {
/* 132 */       return collisionsDetected;
/*     */     }
/* 134 */     for (Map.Entry<String, String> entry : map.entrySet()) {
/* 135 */       if (fileNamePattern.equals(entry.getValue())) {
/* 136 */         addErrorForCollision("FileNamePattern", (String)entry.getValue(), (String)entry.getKey());
/* 137 */         collisionsDetected = true;
/*     */       }
/*     */     }
/* 140 */     if (this.name != null) {
/* 141 */       map.put(getName(), fileNamePattern);
/*     */     }
/* 143 */     return collisionsDetected;
/*     */   }
/*     */   
/*     */   public void stop()
/*     */   {
/* 148 */     if (this.rollingPolicy != null)
/* 149 */       this.rollingPolicy.stop();
/* 150 */     if (this.triggeringPolicy != null)
/* 151 */       this.triggeringPolicy.stop();
/* 152 */     super.stop();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setFile(String file)
/*     */   {
/* 159 */     if ((file != null) && ((this.triggeringPolicy != null) || (this.rollingPolicy != null))) {
/* 160 */       addError("File property must be set before any triggeringPolicy or rollingPolicy properties");
/* 161 */       addError("For more information, please visit " + RFA_LATE_FILE_URL);
/*     */     }
/* 163 */     super.setFile(file);
/*     */   }
/*     */   
/*     */   public String getFile()
/*     */   {
/* 168 */     return this.rollingPolicy.getActiveFileName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void rollover()
/*     */   {
/* 175 */     this.lock.lock();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 182 */       closeOutputStream();
/* 183 */       attemptRollover();
/* 184 */       attemptOpenFile();
/*     */     } finally {
/* 186 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   private void attemptOpenFile()
/*     */   {
/*     */     try {
/* 193 */       this.currentlyActiveFile = new File(this.rollingPolicy.getActiveFileName());
/*     */       
/*     */ 
/* 196 */       openFile(this.rollingPolicy.getActiveFileName());
/*     */     } catch (IOException e) {
/* 198 */       addError("setFile(" + this.fileName + ", false) call failed.", e);
/*     */     }
/*     */   }
/*     */   
/*     */   private void attemptRollover() {
/*     */     try {
/* 204 */       this.rollingPolicy.rollover();
/*     */     } catch (RolloverFailure rf) {
/* 206 */       addWarn("RolloverFailure occurred. Deferring roll-over.");
/*     */       
/* 208 */       this.append = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void subAppend(E event)
/*     */   {
/* 222 */     synchronized (this.triggeringPolicy) {
/* 223 */       if (this.triggeringPolicy.isTriggeringEvent(this.currentlyActiveFile, event)) {
/* 224 */         rollover();
/*     */       }
/*     */     }
/*     */     
/* 228 */     super.subAppend(event);
/*     */   }
/*     */   
/*     */   public RollingPolicy getRollingPolicy() {
/* 232 */     return this.rollingPolicy;
/*     */   }
/*     */   
/*     */   public TriggeringPolicy<E> getTriggeringPolicy() {
/* 236 */     return this.triggeringPolicy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRollingPolicy(RollingPolicy policy)
/*     */   {
/* 248 */     this.rollingPolicy = policy;
/* 249 */     if ((this.rollingPolicy instanceof TriggeringPolicy)) {
/* 250 */       this.triggeringPolicy = ((TriggeringPolicy)policy);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setTriggeringPolicy(TriggeringPolicy<E> policy)
/*     */   {
/* 256 */     this.triggeringPolicy = policy;
/* 257 */     if ((policy instanceof RollingPolicy)) {
/* 258 */       this.rollingPolicy = ((RollingPolicy)policy);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\logback-core-1.1.7.jar!\ch\qos\logback\core\rolling\RollingFileAppender.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */