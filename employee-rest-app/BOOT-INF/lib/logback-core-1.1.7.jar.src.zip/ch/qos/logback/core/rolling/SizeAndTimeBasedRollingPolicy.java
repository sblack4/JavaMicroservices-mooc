/*    */ package ch.qos.logback.core.rolling;
/*    */ 
/*    */ 
/*    */ public class SizeAndTimeBasedRollingPolicy<E>
/*    */   extends TimeBasedRollingPolicy<E>
/*    */ {
/*    */   String maxFileSizeAsString;
/*    */   
/*    */   public void start()
/*    */   {
/* 11 */     SizeAndTimeBasedFNATP<E> sizeAndTimeBasedFNATP = new SizeAndTimeBasedFNATP();
/* 12 */     if (this.maxFileSizeAsString == null) {
/* 13 */       addError("MaxFileSize property must be set");
/* 14 */       return;
/*    */     }
/* 16 */     addInfo("Achive files will be limied to [" + this.maxFileSizeAsString + "] each.");
/*    */     
/*    */ 
/* 19 */     sizeAndTimeBasedFNATP.setMaxFileSize(this.maxFileSizeAsString);
/* 20 */     this.timeBasedFileNamingAndTriggeringPolicy = sizeAndTimeBasedFNATP;
/*    */     
/*    */ 
/* 23 */     super.start();
/*    */   }
/*    */   
/*    */   public void setMaxFileSize(String maxFileSize)
/*    */   {
/* 28 */     this.maxFileSizeAsString = maxFileSize;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 33 */     return "c.q.l.core.rolling.SizeAndTimeBasedRollingPolicy@" + hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\logback-core-1.1.7.jar!\ch\qos\logback\core\rolling\SizeAndTimeBasedRollingPolicy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */