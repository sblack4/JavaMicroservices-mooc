package ch.qos.logback.core.spi;

import java.util.Map;

public abstract interface PropertyContainer
{
  public abstract String getProperty(String paramString);
  
  public abstract Map<String, String> getCopyOfPropertyMap();
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\logback-core-1.1.7.jar!\ch\qos\logback\core\spi\PropertyContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */