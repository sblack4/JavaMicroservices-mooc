package ch.qos.logback.core.html;

public class NOPThrowableRenderer
  implements IThrowableRenderer
{
  public void render(StringBuilder sbuf, Object event) {}
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\logback-core-1.1.7.jar!\ch\qos\logback\core\html\NOPThrowableRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */