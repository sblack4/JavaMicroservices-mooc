/*     */ package ch.qos.logback.core.rolling.helper;
/*     */ 
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RollingCalendar
/*     */   extends GregorianCalendar
/*     */ {
/*     */   private static final long serialVersionUID = -5937537740925066161L;
/*  42 */   static final TimeZone GMT_TIMEZONE = TimeZone.getTimeZone("GMT");
/*     */   
/*  44 */   PeriodicityType periodicityType = PeriodicityType.ERRONEOUS;
/*     */   String datePattern;
/*     */   
/*     */   public RollingCalendar(String datePattern)
/*     */   {
/*  49 */     this.datePattern = datePattern;
/*  50 */     this.periodicityType = computePeriodicityType();
/*     */   }
/*     */   
/*     */   public RollingCalendar(String datePattern, TimeZone tz, Locale locale) {
/*  54 */     super(tz, locale);
/*  55 */     this.datePattern = datePattern;
/*  56 */     this.periodicityType = computePeriodicityType();
/*     */   }
/*     */   
/*     */   public PeriodicityType getPeriodicityType() {
/*  60 */     return this.periodicityType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PeriodicityType computePeriodicityType()
/*     */   {
/*  73 */     GregorianCalendar calendar = new GregorianCalendar(GMT_TIMEZONE, Locale.getDefault());
/*     */     
/*     */ 
/*     */ 
/*  77 */     Date epoch = new Date(0L);
/*     */     
/*  79 */     if (this.datePattern != null) {
/*  80 */       for (PeriodicityType i : PeriodicityType.VALID_ORDERED_LIST) {
/*  81 */         SimpleDateFormat simpleDateFormat = new SimpleDateFormat(this.datePattern);
/*  82 */         simpleDateFormat.setTimeZone(GMT_TIMEZONE);
/*     */         
/*  84 */         String r0 = simpleDateFormat.format(epoch);
/*     */         
/*  86 */         Date next = innerGetEndOfThisPeriod(calendar, i, epoch);
/*  87 */         String r1 = simpleDateFormat.format(next);
/*     */         
/*     */ 
/*  90 */         if ((r0 != null) && (r1 != null) && (!r0.equals(r1))) {
/*  91 */           return i;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  96 */     return PeriodicityType.ERRONEOUS;
/*     */   }
/*     */   
/*     */   public boolean isCollisionFree() {
/* 100 */     switch (this.periodicityType)
/*     */     {
/*     */     case TOP_OF_HOUR: 
/* 103 */       return !collision(43200000L);
/*     */     
/*     */ 
/*     */     case TOP_OF_DAY: 
/* 107 */       if (collision(604800000L)) {
/* 108 */         return false;
/*     */       }
/* 110 */       if (collision(2678400000L)) {
/* 111 */         return false;
/*     */       }
/* 113 */       if (collision(31536000000L))
/* 114 */         return false;
/* 115 */       return true;
/*     */     
/*     */     case TOP_OF_WEEK: 
/* 118 */       if (collision(2937600000L)) {
/* 119 */         return false;
/*     */       }
/* 121 */       if (collision(31622400000L))
/* 122 */         return false;
/* 123 */       return true;
/*     */     }
/* 125 */     return true;
/*     */   }
/*     */   
/*     */   private boolean collision(long delta)
/*     */   {
/* 130 */     SimpleDateFormat simpleDateFormat = new SimpleDateFormat(this.datePattern);
/* 131 */     simpleDateFormat.setTimeZone(GMT_TIMEZONE);
/* 132 */     Date epoch0 = new Date(0L);
/* 133 */     String r0 = simpleDateFormat.format(epoch0);
/* 134 */     Date epoch12 = new Date(delta);
/* 135 */     String r12 = simpleDateFormat.format(epoch12);
/*     */     
/* 137 */     return r0.equals(r12);
/*     */   }
/*     */   
/*     */   public void printPeriodicity(ContextAwareBase cab) {
/* 141 */     switch (this.periodicityType) {
/*     */     case TOP_OF_MILLISECOND: 
/* 143 */       cab.addInfo("Roll-over every millisecond.");
/* 144 */       break;
/*     */     
/*     */     case TOP_OF_SECOND: 
/* 147 */       cab.addInfo("Roll-over every second.");
/* 148 */       break;
/*     */     
/*     */     case TOP_OF_MINUTE: 
/* 151 */       cab.addInfo("Roll-over every minute.");
/* 152 */       break;
/*     */     
/*     */     case TOP_OF_HOUR: 
/* 155 */       cab.addInfo("Roll-over at the top of every hour.");
/* 156 */       break;
/*     */     
/*     */     case HALF_DAY: 
/* 159 */       cab.addInfo("Roll-over at midday and midnight.");
/* 160 */       break;
/*     */     
/*     */     case TOP_OF_DAY: 
/* 163 */       cab.addInfo("Roll-over at midnight.");
/* 164 */       break;
/*     */     
/*     */     case TOP_OF_WEEK: 
/* 167 */       cab.addInfo("Rollover at the start of week.");
/* 168 */       break;
/*     */     
/*     */     case TOP_OF_MONTH: 
/* 171 */       cab.addInfo("Rollover at start of every month.");
/* 172 */       break;
/*     */     
/*     */     default: 
/* 175 */       cab.addInfo("Unknown periodicity.");
/*     */     }
/*     */   }
/*     */   
/*     */   public long periodBarriersCrossed(long start, long end) {
/* 180 */     if (start > end) {
/* 181 */       throw new IllegalArgumentException("Start cannot come before end");
/*     */     }
/* 183 */     Date startFloored = getsStartOfCurrentPeriod(start);
/* 184 */     Date endFloored = getsStartOfCurrentPeriod(end);
/*     */     
/* 186 */     long diff = endFloored.getTime() - startFloored.getTime();
/*     */     
/* 188 */     switch (this.periodicityType)
/*     */     {
/*     */     case TOP_OF_MILLISECOND: 
/* 191 */       return diff;
/*     */     case TOP_OF_SECOND: 
/* 193 */       return diff / 1000L;
/*     */     case TOP_OF_MINUTE: 
/* 195 */       return diff / 60000L;
/*     */     case TOP_OF_HOUR: 
/* 197 */       return (int)diff / 3600000L;
/*     */     case TOP_OF_DAY: 
/* 199 */       return diff / 86400000L;
/*     */     case TOP_OF_WEEK: 
/* 201 */       return diff / 604800000L;
/*     */     case TOP_OF_MONTH: 
/* 203 */       return diffInMonths(start, end);
/*     */     }
/* 205 */     throw new IllegalStateException("Unknown periodicity type.");
/*     */   }
/*     */   
/*     */   public static int diffInMonths(long startTime, long endTime)
/*     */   {
/* 210 */     if (startTime > endTime)
/* 211 */       throw new IllegalArgumentException("startTime cannot be larger than endTime");
/* 212 */     Calendar startCal = Calendar.getInstance();
/* 213 */     startCal.setTimeInMillis(startTime);
/* 214 */     Calendar endCal = Calendar.getInstance();
/* 215 */     endCal.setTimeInMillis(endTime);
/* 216 */     int yearDiff = endCal.get(1) - startCal.get(1);
/* 217 */     int monthDiff = endCal.get(2) - startCal.get(2);
/* 218 */     return yearDiff * 12 + monthDiff;
/*     */   }
/*     */   
/*     */   private static Date innerGetEndOfThisPeriod(Calendar cal, PeriodicityType periodicityType, Date now) {
/* 222 */     return innerGetEndOfNextNthPeriod(cal, periodicityType, now, 1);
/*     */   }
/*     */   
/*     */   private static Date innerGetEndOfNextNthPeriod(Calendar cal, PeriodicityType periodicityType, Date now, int numPeriods) {
/* 226 */     cal.setTime(now);
/* 227 */     switch (periodicityType) {
/*     */     case TOP_OF_MILLISECOND: 
/* 229 */       cal.add(14, numPeriods);
/* 230 */       break;
/*     */     
/*     */     case TOP_OF_SECOND: 
/* 233 */       cal.set(14, 0);
/* 234 */       cal.add(13, numPeriods);
/* 235 */       break;
/*     */     
/*     */     case TOP_OF_MINUTE: 
/* 238 */       cal.set(13, 0);
/* 239 */       cal.set(14, 0);
/* 240 */       cal.add(12, numPeriods);
/* 241 */       break;
/*     */     
/*     */     case TOP_OF_HOUR: 
/* 244 */       cal.set(12, 0);
/* 245 */       cal.set(13, 0);
/* 246 */       cal.set(14, 0);
/* 247 */       cal.add(11, numPeriods);
/* 248 */       break;
/*     */     
/*     */     case TOP_OF_DAY: 
/* 251 */       cal.set(11, 0);
/* 252 */       cal.set(12, 0);
/* 253 */       cal.set(13, 0);
/* 254 */       cal.set(14, 0);
/* 255 */       cal.add(5, numPeriods);
/* 256 */       break;
/*     */     
/*     */     case TOP_OF_WEEK: 
/* 259 */       cal.set(7, cal.getFirstDayOfWeek());
/* 260 */       cal.set(11, 0);
/* 261 */       cal.set(12, 0);
/* 262 */       cal.set(13, 0);
/* 263 */       cal.set(14, 0);
/* 264 */       cal.add(3, numPeriods);
/* 265 */       break;
/*     */     
/*     */     case TOP_OF_MONTH: 
/* 268 */       cal.set(5, 1);
/* 269 */       cal.set(11, 0);
/* 270 */       cal.set(12, 0);
/* 271 */       cal.set(13, 0);
/* 272 */       cal.set(14, 0);
/* 273 */       cal.add(2, numPeriods);
/* 274 */       break;
/*     */     case HALF_DAY: 
/*     */     default: 
/* 277 */       throw new IllegalStateException("Unknown periodicity type.");
/*     */     }
/*     */     
/* 280 */     return cal.getTime();
/*     */   }
/*     */   
/*     */   public Date getEndOfNextNthPeriod(Date now, int periods) {
/* 284 */     return innerGetEndOfNextNthPeriod(this, this.periodicityType, now, periods);
/*     */   }
/*     */   
/*     */   public Date getNextTriggeringDate(Date now) {
/* 288 */     return getEndOfNextNthPeriod(now, 1);
/*     */   }
/*     */   
/*     */   public Date getsStartOfCurrentPeriod(long now) {
/* 292 */     Calendar aCal = Calendar.getInstance(getTimeZone());
/* 293 */     aCal.setTimeInMillis(now);
/* 294 */     return getEndOfNextNthPeriod(aCal.getTime(), 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\logback-core-1.1.7.jar!\ch\qos\logback\core\rolling\helper\RollingCalendar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */