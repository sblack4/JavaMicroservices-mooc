/*    */ package ch.qos.logback.core.joran.util.beans;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanDescriptionFactory
/*    */ {
/* 19 */   public static final BeanDescriptionFactory INSTANCE = new BeanDescriptionFactory();
/*    */   
/* 21 */   private BeanUtil beanUtil = BeanUtil.INSTANCE;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public BeanDescription create(Class<?> clazz)
/*    */   {
/* 29 */     Map<String, Method> propertyNameToGetter = new HashMap();
/* 30 */     Map<String, Method> propertyNameToSetter = new HashMap();
/* 31 */     Map<String, Method> propertyNameToAdder = new HashMap();
/* 32 */     Method[] methods = clazz.getMethods();
/* 33 */     for (Method method : methods) {
/* 34 */       if (this.beanUtil.isGetter(method)) {
/* 35 */         String propertyName = this.beanUtil.getPropertyName(method);
/* 36 */         Method oldGetter = (Method)propertyNameToGetter.put(propertyName, method);
/* 37 */         if (oldGetter != null) {
/* 38 */           if (oldGetter.getName().startsWith("is")) {
/* 39 */             propertyNameToGetter.put(propertyName, oldGetter);
/*    */           }
/* 41 */           String message = String.format("Warning: Class '%s' contains multiple getters for the same property '%s'.", new Object[] { clazz.getCanonicalName(), propertyName });
/* 42 */           System.err.println(message);
/*    */         }
/* 44 */       } else if (this.beanUtil.isSetter(method)) {
/* 45 */         String propertyName = this.beanUtil.getPropertyName(method);
/* 46 */         Method oldSetter = (Method)propertyNameToSetter.put(propertyName, method);
/* 47 */         if (oldSetter != null) {
/* 48 */           String message = String.format("Warning: Class '%s' contains multiple setters for the same property '%s'.", new Object[] { clazz.getCanonicalName(), propertyName });
/* 49 */           System.err.println(message);
/*    */         }
/* 51 */       } else if (this.beanUtil.isAdder(method)) {
/* 52 */         String propertyName = this.beanUtil.getPropertyName(method);
/* 53 */         Method oldAdder = (Method)propertyNameToAdder.put(propertyName, method);
/* 54 */         if (oldAdder != null) {
/* 55 */           String message = String.format("Warning: Class '%s' contains multiple adders for the same property '%s'.", new Object[] { clazz.getCanonicalName(), propertyName });
/* 56 */           System.err.println(message);
/*    */         }
/*    */       }
/*    */     }
/* 60 */     return new BeanDescription(clazz, propertyNameToGetter, propertyNameToSetter, propertyNameToAdder);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\logback-core-1.1.7.jar!\ch\qos\logback\core\joran\util\beans\BeanDescriptionFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */