/*    */ package ch.qos.logback.core.status;
/*    */ 
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.spi.ContextAwareBase;
/*    */ import ch.qos.logback.core.spi.LifeCycle;
/*    */ import ch.qos.logback.core.util.StatusPrinter;
/*    */ import java.io.PrintStream;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class OnPrintStreamStatusListenerBase
/*    */   extends ContextAwareBase
/*    */   implements StatusListener, LifeCycle
/*    */ {
/* 29 */   boolean isStarted = false;
/*    */   
/*    */   static final long DEFAULT_RETROSPECTIVE = 300L;
/* 32 */   long retrospectiveThresold = 300L;
/*    */   
/*    */ 
/*    */ 
/*    */   protected abstract PrintStream getPrintStream();
/*    */   
/*    */ 
/*    */   private void print(Status status)
/*    */   {
/* 41 */     StringBuilder sb = new StringBuilder();
/* 42 */     StatusPrinter.buildStr(sb, "", status);
/* 43 */     getPrintStream().print(sb);
/*    */   }
/*    */   
/*    */   public void addStatusEvent(Status status) {
/* 47 */     if (!this.isStarted)
/* 48 */       return;
/* 49 */     print(status);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   private void retrospectivePrint()
/*    */   {
/* 56 */     if (this.context == null)
/* 57 */       return;
/* 58 */     long now = System.currentTimeMillis();
/* 59 */     StatusManager sm = this.context.getStatusManager();
/* 60 */     List<Status> statusList = sm.getCopyOfStatusList();
/* 61 */     for (Status status : statusList) {
/* 62 */       long timestampOfStatusMesage = status.getDate().longValue();
/* 63 */       if (isElapsedTimeLongerThanThreshold(now, timestampOfStatusMesage)) {
/* 64 */         print(status);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   private boolean isElapsedTimeLongerThanThreshold(long now, long timestamp) {
/* 70 */     long elapsedTime = now - timestamp;
/* 71 */     return elapsedTime < this.retrospectiveThresold;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void start()
/*    */   {
/* 79 */     this.isStarted = true;
/* 80 */     if (this.retrospectiveThresold > 0L) {
/* 81 */       retrospectivePrint();
/*    */     }
/*    */   }
/*    */   
/*    */   public void setRetrospective(long retrospective) {
/* 86 */     this.retrospectiveThresold = retrospective;
/*    */   }
/*    */   
/*    */   public long getRetrospective() {
/* 90 */     return this.retrospectiveThresold;
/*    */   }
/*    */   
/*    */   public void stop() {
/* 94 */     this.isStarted = false;
/*    */   }
/*    */   
/*    */   public boolean isStarted() {
/* 98 */     return this.isStarted;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\logback-core-1.1.7.jar!\ch\qos\logback\core\status\OnPrintStreamStatusListenerBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */