/*     */ package ch.qos.logback.core;
/*     */ 
/*     */ import ch.qos.logback.core.recovery.ResilientFileOutputStream;
/*     */ import ch.qos.logback.core.util.FileUtil;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.channels.FileLock;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileAppender<E>
/*     */   extends OutputStreamAppender<E>
/*     */ {
/*  39 */   protected static String COLLISION_WITH_EARLIER_APPENDER_URL = "http://logback.qos.ch/codes.html#earlier_fa_collision";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  46 */   protected boolean append = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  51 */   protected String fileName = null;
/*     */   
/*  53 */   private boolean prudent = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFile(String file)
/*     */   {
/*  60 */     if (file == null) {
/*  61 */       this.fileName = file;
/*     */     }
/*     */     else
/*     */     {
/*  65 */       this.fileName = file.trim();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isAppend()
/*     */   {
/*  73 */     return this.append;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String rawFileProperty()
/*     */   {
/*  83 */     return this.fileName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFile()
/*     */   {
/*  94 */     return this.fileName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void start()
/*     */   {
/* 103 */     int errors = 0;
/* 104 */     if (getFile() != null) {
/* 105 */       addInfo("File property is set to [" + this.fileName + "]");
/*     */       
/* 107 */       if (checkForFileCollisionInPreviousFileAppenders()) {
/* 108 */         addError("Collisions detected with FileAppender/RollingAppender instances defined earlier. Aborting.");
/* 109 */         addError("For more information, please visit " + COLLISION_WITH_EARLIER_APPENDER_URL);
/* 110 */         errors++;
/*     */       }
/*     */       
/* 113 */       if ((this.prudent) && 
/* 114 */         (!isAppend())) {
/* 115 */         setAppend(true);
/* 116 */         addWarn("Setting \"Append\" property to true on account of \"Prudent\" mode");
/*     */       }
/*     */       
/*     */       try
/*     */       {
/* 121 */         openFile(getFile());
/*     */       } catch (IOException e) {
/* 123 */         errors++;
/* 124 */         addError("openFile(" + this.fileName + "," + this.append + ") call failed.", e);
/*     */       }
/*     */     } else {
/* 127 */       errors++;
/* 128 */       addError("\"File\" property not set for appender named [" + this.name + "].");
/*     */     }
/* 130 */     if (errors == 0) {
/* 131 */       super.start();
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean checkForFileCollisionInPreviousFileAppenders() {
/* 136 */     boolean collisionsDetected = false;
/* 137 */     if (this.fileName == null) {
/* 138 */       return false;
/*     */     }
/*     */     
/* 141 */     Map<String, String> map = (Map)this.context.getObject("RFA_FILENAME_PATTERN_COLLISION_MAP");
/* 142 */     if (map == null) {
/* 143 */       return collisionsDetected;
/*     */     }
/* 145 */     for (Map.Entry<String, String> entry : map.entrySet()) {
/* 146 */       if (this.fileName.equals(entry.getValue())) {
/* 147 */         addErrorForCollision("File", (String)entry.getValue(), (String)entry.getKey());
/* 148 */         collisionsDetected = true;
/*     */       }
/*     */     }
/* 151 */     if (this.name != null) {
/* 152 */       map.put(getName(), this.fileName);
/*     */     }
/* 154 */     return collisionsDetected;
/*     */   }
/*     */   
/*     */   protected void addErrorForCollision(String optionName, String optionValue, String appenderName) {
/* 158 */     addError("'" + optionName + "' option has the same value \"" + optionValue + "\" as that given for appender [" + appenderName + "] defined earlier.");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void openFile(String file_name)
/*     */     throws IOException
/*     */   {
/* 178 */     this.lock.lock();
/*     */     try {
/* 180 */       File file = new File(file_name);
/* 181 */       boolean result = FileUtil.createMissingParentDirectories(file);
/* 182 */       if (!result) {
/* 183 */         addError("Failed to create parent directories for [" + file.getAbsolutePath() + "]");
/*     */       }
/*     */       
/* 186 */       ResilientFileOutputStream resilientFos = new ResilientFileOutputStream(file, this.append);
/* 187 */       resilientFos.setContext(this.context);
/* 188 */       setOutputStream(resilientFos);
/*     */     } finally {
/* 190 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPrudent()
/*     */   {
/* 200 */     return this.prudent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPrudent(boolean prudent)
/*     */   {
/* 210 */     this.prudent = prudent;
/*     */   }
/*     */   
/*     */   public void setAppend(boolean append) {
/* 214 */     this.append = append;
/*     */   }
/*     */   
/*     */   private void safeWrite(E event) throws IOException {
/* 218 */     ResilientFileOutputStream resilientFOS = (ResilientFileOutputStream)getOutputStream();
/* 219 */     FileChannel fileChannel = resilientFOS.getChannel();
/* 220 */     if (fileChannel == null) {
/* 221 */       return;
/*     */     }
/*     */     
/*     */ 
/* 225 */     boolean interrupted = Thread.interrupted();
/*     */     
/* 227 */     FileLock fileLock = null;
/*     */     try {
/* 229 */       fileLock = fileChannel.lock();
/* 230 */       long position = fileChannel.position();
/* 231 */       long size = fileChannel.size();
/* 232 */       if (size != position) {
/* 233 */         fileChannel.position(size);
/*     */       }
/* 235 */       super.writeOut(event);
/*     */     }
/*     */     catch (IOException e) {
/* 238 */       resilientFOS.postIOFailure(e);
/*     */     } finally {
/* 240 */       if ((fileLock != null) && (fileLock.isValid())) {
/* 241 */         fileLock.release();
/*     */       }
/*     */       
/*     */ 
/* 245 */       if (interrupted) {
/* 246 */         Thread.currentThread().interrupt();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void writeOut(E event) throws IOException
/*     */   {
/* 253 */     if (this.prudent) {
/* 254 */       safeWrite(event);
/*     */     } else {
/* 256 */       super.writeOut(event);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\logback-core-1.1.7.jar!\ch\qos\logback\core\FileAppender.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */