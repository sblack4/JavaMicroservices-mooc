/*     */ package ch.qos.logback.core.pattern;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.LayoutBase;
/*     */ import ch.qos.logback.core.pattern.parser.Node;
/*     */ import ch.qos.logback.core.pattern.parser.Parser;
/*     */ import ch.qos.logback.core.spi.ScanException;
/*     */ import ch.qos.logback.core.status.ErrorStatus;
/*     */ import ch.qos.logback.core.status.StatusManager;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PatternLayoutBase<E>
/*     */   extends LayoutBase<E>
/*     */ {
/*     */   Converter<E> head;
/*     */   String pattern;
/*     */   protected PostCompileProcessor<E> postCompileProcessor;
/*  34 */   Map<String, String> instanceConverterMap = new HashMap();
/*  35 */   protected boolean outputPatternAsHeader = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Map<String, String> getDefaultConverterMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, String> getEffectiveConverterMap()
/*     */   {
/*  50 */     Map<String, String> effectiveMap = new HashMap();
/*     */     
/*     */ 
/*  53 */     Map<String, String> defaultMap = getDefaultConverterMap();
/*  54 */     if (defaultMap != null) {
/*  55 */       effectiveMap.putAll(defaultMap);
/*     */     }
/*     */     
/*     */ 
/*  59 */     Context context = getContext();
/*  60 */     if (context != null)
/*     */     {
/*  62 */       Map<String, String> contextMap = (Map)context.getObject("PATTERN_RULE_REGISTRY");
/*  63 */       if (contextMap != null) {
/*  64 */         effectiveMap.putAll(contextMap);
/*     */       }
/*     */     }
/*     */     
/*  68 */     effectiveMap.putAll(this.instanceConverterMap);
/*  69 */     return effectiveMap;
/*     */   }
/*     */   
/*     */   public void start() {
/*  73 */     if ((this.pattern == null) || (this.pattern.length() == 0)) {
/*  74 */       addError("Empty or null pattern.");
/*  75 */       return;
/*     */     }
/*     */     try {
/*  78 */       Parser<E> p = new Parser(this.pattern);
/*  79 */       if (getContext() != null) {
/*  80 */         p.setContext(getContext());
/*     */       }
/*  82 */       Node t = p.parse();
/*  83 */       this.head = p.compile(t, getEffectiveConverterMap());
/*  84 */       if (this.postCompileProcessor != null) {
/*  85 */         this.postCompileProcessor.process(this.context, this.head);
/*     */       }
/*  87 */       ConverterUtil.setContextForConverters(getContext(), this.head);
/*  88 */       ConverterUtil.startConverters(this.head);
/*  89 */       super.start();
/*     */     } catch (ScanException sce) {
/*  91 */       StatusManager sm = getContext().getStatusManager();
/*  92 */       sm.add(new ErrorStatus("Failed to parse pattern \"" + getPattern() + "\".", this, sce));
/*     */     }
/*     */   }
/*     */   
/*     */   public void setPostCompileProcessor(PostCompileProcessor<E> postCompileProcessor) {
/*  97 */     this.postCompileProcessor = postCompileProcessor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   protected void setContextForConverters(Converter<E> head)
/*     */   {
/* 107 */     ConverterUtil.setContextForConverters(getContext(), head);
/*     */   }
/*     */   
/*     */   protected String writeLoopOnConverters(E event) {
/* 111 */     StringBuilder buf = new StringBuilder(128);
/* 112 */     Converter<E> c = this.head;
/* 113 */     while (c != null) {
/* 114 */       c.write(buf, event);
/* 115 */       c = c.getNext();
/*     */     }
/* 117 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public String getPattern() {
/* 121 */     return this.pattern;
/*     */   }
/*     */   
/*     */   public void setPattern(String pattern) {
/* 125 */     this.pattern = pattern;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 129 */     return getClass().getName() + "(\"" + getPattern() + "\")";
/*     */   }
/*     */   
/*     */   public Map<String, String> getInstanceConverterMap() {
/* 133 */     return this.instanceConverterMap;
/*     */   }
/*     */   
/*     */   protected String getPresentationHeaderPrefix() {
/* 137 */     return "";
/*     */   }
/*     */   
/*     */   public boolean isOutputPatternAsHeader() {
/* 141 */     return this.outputPatternAsHeader;
/*     */   }
/*     */   
/*     */   public void setOutputPatternAsHeader(boolean outputPatternAsHeader) {
/* 145 */     this.outputPatternAsHeader = outputPatternAsHeader;
/*     */   }
/*     */   
/*     */   public String getPresentationHeader()
/*     */   {
/* 150 */     if (this.outputPatternAsHeader) {
/* 151 */       return getPresentationHeaderPrefix() + this.pattern;
/*     */     }
/* 153 */     return super.getPresentationHeader();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\logback-core-1.1.7.jar!\ch\qos\logback\core\pattern\PatternLayoutBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */