/*     */ package ch.qos.logback.core.net;
/*     */ 
/*     */ import ch.qos.logback.core.AppenderBase;
/*     */ import ch.qos.logback.core.Layout;
/*     */ import ch.qos.logback.core.boolex.EvaluationException;
/*     */ import ch.qos.logback.core.boolex.EventEvaluator;
/*     */ import ch.qos.logback.core.helpers.CyclicBuffer;
/*     */ import ch.qos.logback.core.pattern.PatternLayoutBase;
/*     */ import ch.qos.logback.core.sift.DefaultDiscriminator;
/*     */ import ch.qos.logback.core.sift.Discriminator;
/*     */ import ch.qos.logback.core.spi.CyclicBufferTracker;
/*     */ import ch.qos.logback.core.util.ContentTypeUtil;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import javax.mail.Message.RecipientType;
/*     */ import javax.mail.Multipart;
/*     */ import javax.mail.Session;
/*     */ import javax.mail.Transport;
/*     */ import javax.mail.internet.AddressException;
/*     */ import javax.mail.internet.InternetAddress;
/*     */ import javax.mail.internet.MimeBodyPart;
/*     */ import javax.mail.internet.MimeMessage;
/*     */ import javax.mail.internet.MimeMultipart;
/*     */ import javax.naming.InitialContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SMTPAppenderBase<E>
/*     */   extends AppenderBase<E>
/*     */ {
/*  64 */   static InternetAddress[] EMPTY_IA_ARRAY = new InternetAddress[0];
/*     */   static final long MAX_DELAY_BETWEEN_STATUS_MESSAGES = 1228800000L;
/*     */   
/*     */   public SMTPAppenderBase() {
/*  68 */     this.lastTrackerStatusPrint = 0L;
/*  69 */     this.delayBetweenStatusMessages = 300000L;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  74 */     this.toPatternLayoutList = new ArrayList();
/*     */     
/*  76 */     this.subjectStr = null;
/*     */     
/*  78 */     this.smtpPort = 25;
/*  79 */     this.starttls = false;
/*  80 */     this.ssl = false;
/*  81 */     this.sessionViaJNDI = false;
/*  82 */     this.jndiLocation = "java:comp/env/mail/Session";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  88 */     this.asynchronousSending = true;
/*     */     
/*  90 */     this.charsetEncoding = "UTF-8";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */     this.discriminator = new DefaultDiscriminator();
/*     */     
/*     */ 
/*  99 */     this.errorCount = 0;
/*     */   }
/*     */   
/*     */   long lastTrackerStatusPrint;
/*     */   long delayBetweenStatusMessages;
/*     */   protected Layout<E> subjectLayout;
/*     */   protected Layout<E> layout;
/*     */   private List<PatternLayoutBase<E>> toPatternLayoutList;
/*     */   private String from;
/*     */   private String subjectStr;
/*     */   private String smtpHost;
/*     */   private int smtpPort;
/*     */   private boolean starttls;
/*     */   private boolean ssl;
/*     */   protected abstract Layout<E> makeSubjectLayout(String paramString);
/*     */   
/*     */   public void start() {
/* 116 */     if (this.cbTracker == null) {
/* 117 */       this.cbTracker = new CyclicBufferTracker();
/*     */     }
/*     */     
/* 120 */     if (this.sessionViaJNDI) {
/* 121 */       this.session = lookupSessionInJNDI();
/*     */     } else {
/* 123 */       this.session = buildSessionFromProperties();
/*     */     }
/* 125 */     if (this.session == null) {
/* 126 */       addError("Failed to obtain javax.mail.Session. Cannot start.");
/* 127 */       return;
/*     */     }
/*     */     
/* 130 */     this.subjectLayout = makeSubjectLayout(this.subjectStr);
/*     */     
/* 132 */     this.started = true;
/*     */   }
/*     */   
/*     */   private Session lookupSessionInJNDI() {
/* 136 */     addInfo("Looking up javax.mail.Session at JNDI location [" + this.jndiLocation + "]");
/*     */     try {
/* 138 */       javax.naming.Context initialContext = new InitialContext();
/* 139 */       Object obj = initialContext.lookup(this.jndiLocation);
/* 140 */       return (Session)obj;
/*     */     } catch (Exception e) {
/* 142 */       addError("Failed to obtain javax.mail.Session from JNDI location [" + this.jndiLocation + "]"); }
/* 143 */     return null;
/*     */   }
/*     */   
/*     */   private Session buildSessionFromProperties()
/*     */   {
/* 148 */     Properties props = new Properties(OptionHelper.getSystemProperties());
/* 149 */     if (this.smtpHost != null) {
/* 150 */       props.put("mail.smtp.host", this.smtpHost);
/*     */     }
/* 152 */     props.put("mail.smtp.port", Integer.toString(this.smtpPort));
/*     */     
/* 154 */     if (this.localhost != null) {
/* 155 */       props.put("mail.smtp.localhost", this.localhost);
/*     */     }
/*     */     
/* 158 */     LoginAuthenticator loginAuthenticator = null;
/*     */     
/* 160 */     if (this.username != null) {
/* 161 */       loginAuthenticator = new LoginAuthenticator(this.username, this.password);
/* 162 */       props.put("mail.smtp.auth", "true");
/*     */     }
/*     */     
/* 165 */     if ((isSTARTTLS()) && (isSSL())) {
/* 166 */       addError("Both SSL and StartTLS cannot be enabled simultaneously");
/*     */     } else {
/* 168 */       if (isSTARTTLS())
/*     */       {
/* 170 */         props.put("mail.smtp.starttls.enable", "true");
/*     */       }
/* 172 */       if (isSSL()) {
/* 173 */         String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";
/* 174 */         props.put("mail.smtp.socketFactory.port", Integer.toString(this.smtpPort));
/* 175 */         props.put("mail.smtp.socketFactory.class", SSL_FACTORY);
/* 176 */         props.put("mail.smtp.socketFactory.fallback", "true");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 182 */     return Session.getInstance(props, loginAuthenticator);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void append(E eventObject)
/*     */   {
/* 191 */     if (!checkEntryConditions()) {
/* 192 */       return;
/*     */     }
/*     */     
/* 195 */     String key = this.discriminator.getDiscriminatingValue(eventObject);
/* 196 */     long now = System.currentTimeMillis();
/* 197 */     CyclicBuffer<E> cb = (CyclicBuffer)this.cbTracker.getOrCreate(key, now);
/* 198 */     subAppend(cb, eventObject);
/*     */     try
/*     */     {
/* 201 */       if (this.eventEvaluator.evaluate(eventObject))
/*     */       {
/* 203 */         CyclicBuffer<E> cbClone = new CyclicBuffer(cb);
/*     */         
/* 205 */         cb.clear();
/*     */         
/* 207 */         if (this.asynchronousSending)
/*     */         {
/* 209 */           SMTPAppenderBase<E>.SenderRunnable senderRunnable = new SenderRunnable(cbClone, eventObject);
/* 210 */           this.context.getExecutorService().execute(senderRunnable);
/*     */         }
/*     */         else {
/* 213 */           sendBuffer(cbClone, eventObject);
/*     */         }
/*     */       }
/*     */     } catch (EvaluationException ex) {
/* 217 */       this.errorCount += 1;
/* 218 */       if (this.errorCount < 4) {
/* 219 */         addError("SMTPAppender's EventEvaluator threw an Exception-", ex);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 224 */     if (eventMarksEndOfLife(eventObject)) {
/* 225 */       this.cbTracker.endOfLife(key);
/*     */     }
/*     */     
/* 228 */     this.cbTracker.removeStaleComponents(now);
/*     */     
/* 230 */     if (this.lastTrackerStatusPrint + this.delayBetweenStatusMessages < now) {
/* 231 */       addInfo("SMTPAppender [" + this.name + "] is tracking [" + this.cbTracker.getComponentCount() + "] buffers");
/* 232 */       this.lastTrackerStatusPrint = now;
/*     */       
/* 234 */       if (this.delayBetweenStatusMessages < 1228800000L) {
/* 235 */         this.delayBetweenStatusMessages *= 4L;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract boolean eventMarksEndOfLife(E paramE);
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract void subAppend(CyclicBuffer<E> paramCyclicBuffer, E paramE);
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean checkEntryConditions()
/*     */   {
/* 253 */     if (!this.started) {
/* 254 */       addError("Attempting to append to a non-started appender: " + getName());
/* 255 */       return false;
/*     */     }
/*     */     
/* 258 */     if (this.eventEvaluator == null) {
/* 259 */       addError("No EventEvaluator is set for appender [" + this.name + "].");
/* 260 */       return false;
/*     */     }
/*     */     
/* 263 */     if (this.layout == null) {
/* 264 */       addError("No layout set for appender named [" + this.name + "]. For more information, please visit http://logback.qos.ch/codes.html#smtp_no_layout");
/* 265 */       return false;
/*     */     }
/* 267 */     return true;
/*     */   }
/*     */   
/*     */   public synchronized void stop() {
/* 271 */     this.started = false;
/*     */   }
/*     */   
/*     */   InternetAddress getAddress(String addressStr) {
/*     */     try {
/* 276 */       return new InternetAddress(addressStr);
/*     */     } catch (AddressException e) {
/* 278 */       addError("Could not parse address [" + addressStr + "].", e); }
/* 279 */     return null;
/*     */   }
/*     */   
/*     */   private List<InternetAddress> parseAddress(E event)
/*     */   {
/* 284 */     int len = this.toPatternLayoutList.size();
/*     */     
/* 286 */     List<InternetAddress> iaList = new ArrayList();
/*     */     
/* 288 */     for (int i = 0; i < len; i++) {
/*     */       try {
/* 290 */         PatternLayoutBase<E> emailPL = (PatternLayoutBase)this.toPatternLayoutList.get(i);
/* 291 */         String emailAdrr = emailPL.doLayout(event);
/* 292 */         if ((emailAdrr == null) || (emailAdrr.length() != 0))
/*     */         {
/*     */ 
/* 295 */           InternetAddress[] tmp = InternetAddress.parse(emailAdrr, true);
/* 296 */           iaList.addAll(Arrays.asList(tmp));
/*     */         }
/* 298 */       } catch (AddressException e) { addError("Could not parse email address for [" + this.toPatternLayoutList.get(i) + "] for event [" + event + "]", e);
/* 299 */         return iaList;
/*     */       }
/*     */     }
/*     */     
/* 303 */     return iaList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<PatternLayoutBase<E>> getToList()
/*     */   {
/* 310 */     return this.toPatternLayoutList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void sendBuffer(CyclicBuffer<E> cb, E lastEventObject)
/*     */   {
/*     */     try
/*     */     {
/* 321 */       MimeBodyPart part = new MimeBodyPart();
/*     */       
/* 323 */       StringBuffer sbuf = new StringBuffer();
/*     */       
/* 325 */       String header = this.layout.getFileHeader();
/* 326 */       if (header != null) {
/* 327 */         sbuf.append(header);
/*     */       }
/* 329 */       String presentationHeader = this.layout.getPresentationHeader();
/* 330 */       if (presentationHeader != null) {
/* 331 */         sbuf.append(presentationHeader);
/*     */       }
/* 333 */       fillBuffer(cb, sbuf);
/* 334 */       String presentationFooter = this.layout.getPresentationFooter();
/* 335 */       if (presentationFooter != null) {
/* 336 */         sbuf.append(presentationFooter);
/*     */       }
/* 338 */       String footer = this.layout.getFileFooter();
/* 339 */       if (footer != null) {
/* 340 */         sbuf.append(footer);
/*     */       }
/*     */       
/* 343 */       String subjectStr = "Undefined subject";
/* 344 */       if (this.subjectLayout != null) {
/* 345 */         subjectStr = this.subjectLayout.doLayout(lastEventObject);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 350 */         int newLinePos = subjectStr != null ? subjectStr.indexOf('\n') : -1;
/* 351 */         if (newLinePos > -1) {
/* 352 */           subjectStr = subjectStr.substring(0, newLinePos);
/*     */         }
/*     */       }
/*     */       
/* 356 */       MimeMessage mimeMsg = new MimeMessage(this.session);
/*     */       
/* 358 */       if (this.from != null) {
/* 359 */         mimeMsg.setFrom(getAddress(this.from));
/*     */       } else {
/* 361 */         mimeMsg.setFrom();
/*     */       }
/*     */       
/* 364 */       mimeMsg.setSubject(subjectStr, this.charsetEncoding);
/*     */       
/* 366 */       List<InternetAddress> destinationAddresses = parseAddress(lastEventObject);
/* 367 */       if (destinationAddresses.isEmpty()) {
/* 368 */         addInfo("Empty destination address. Aborting email transmission");
/* 369 */         return;
/*     */       }
/*     */       
/* 372 */       InternetAddress[] toAddressArray = (InternetAddress[])destinationAddresses.toArray(EMPTY_IA_ARRAY);
/* 373 */       mimeMsg.setRecipients(Message.RecipientType.TO, toAddressArray);
/*     */       
/* 375 */       String contentType = this.layout.getContentType();
/*     */       
/* 377 */       if (ContentTypeUtil.isTextual(contentType)) {
/* 378 */         part.setText(sbuf.toString(), this.charsetEncoding, ContentTypeUtil.getSubType(contentType));
/*     */       } else {
/* 380 */         part.setContent(sbuf.toString(), this.layout.getContentType());
/*     */       }
/*     */       
/* 383 */       Multipart mp = new MimeMultipart();
/* 384 */       mp.addBodyPart(part);
/* 385 */       mimeMsg.setContent(mp);
/*     */       
/* 387 */       mimeMsg.setSentDate(new Date());
/* 388 */       addInfo("About to send out SMTP message \"" + subjectStr + "\" to " + Arrays.toString(toAddressArray));
/* 389 */       Transport.send(mimeMsg);
/*     */     } catch (Exception e) {
/* 391 */       addError("Error occurred while sending e-mail notification.", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected abstract void fillBuffer(CyclicBuffer<E> paramCyclicBuffer, StringBuffer paramStringBuffer);
/*     */   
/*     */ 
/*     */   public String getFrom()
/*     */   {
/* 401 */     return this.from;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getSubject()
/*     */   {
/* 408 */     return this.subjectStr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFrom(String from)
/*     */   {
/* 416 */     this.from = from;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSubject(String subject)
/*     */   {
/* 424 */     this.subjectStr = subject;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSMTPHost(String smtpHost)
/*     */   {
/* 433 */     setSmtpHost(smtpHost);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSmtpHost(String smtpHost)
/*     */   {
/* 441 */     this.smtpHost = smtpHost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getSMTPHost()
/*     */   {
/* 448 */     return getSmtpHost();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getSmtpHost()
/*     */   {
/* 455 */     return this.smtpHost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSMTPPort(int port)
/*     */   {
/* 464 */     setSmtpPort(port);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSmtpPort(int port)
/*     */   {
/* 473 */     this.smtpPort = port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSMTPPort()
/*     */   {
/* 482 */     return getSmtpPort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSmtpPort()
/*     */   {
/* 491 */     return this.smtpPort;
/*     */   }
/*     */   
/*     */ 
/* 495 */   public String getLocalhost() { return this.localhost; }
/*     */   
/*     */   private boolean sessionViaJNDI;
/*     */   private String jndiLocation;
/*     */   String username;
/*     */   String password;
/*     */   String localhost;
/*     */   boolean asynchronousSending;
/*     */   private String charsetEncoding;
/*     */   protected Session session;
/*     */   protected EventEvaluator<E> eventEvaluator;
/*     */   protected Discriminator<E> discriminator;
/*     */   protected CyclicBufferTracker<E> cbTracker;
/*     */   private int errorCount;
/* 509 */   public void setLocalhost(String localhost) { this.localhost = localhost; }
/*     */   
/*     */ 
/*     */   public CyclicBufferTracker<E> getCyclicBufferTracker() {
/* 513 */     return this.cbTracker;
/*     */   }
/*     */   
/*     */   public void setCyclicBufferTracker(CyclicBufferTracker<E> cbTracker) {
/* 517 */     this.cbTracker = cbTracker;
/*     */   }
/*     */   
/*     */   public Discriminator<E> getDiscriminator() {
/* 521 */     return this.discriminator;
/*     */   }
/*     */   
/*     */   public void setDiscriminator(Discriminator<E> discriminator) {
/* 525 */     this.discriminator = discriminator;
/*     */   }
/*     */   
/*     */   public boolean isAsynchronousSending() {
/* 529 */     return this.asynchronousSending;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAsynchronousSending(boolean asynchronousSending)
/*     */   {
/* 540 */     this.asynchronousSending = asynchronousSending;
/*     */   }
/*     */   
/*     */   public void addTo(String to) {
/* 544 */     if ((to == null) || (to.length() == 0)) {
/* 545 */       throw new IllegalArgumentException("Null or empty <to> property");
/*     */     }
/* 547 */     PatternLayoutBase plb = makeNewToPatternLayout(to.trim());
/* 548 */     plb.setContext(this.context);
/* 549 */     plb.start();
/* 550 */     this.toPatternLayoutList.add(plb);
/*     */   }
/*     */   
/*     */   protected abstract PatternLayoutBase<E> makeNewToPatternLayout(String paramString);
/*     */   
/*     */   public List<String> getToAsListOfString() {
/* 556 */     List<String> toList = new ArrayList();
/* 557 */     for (PatternLayoutBase plb : this.toPatternLayoutList) {
/* 558 */       toList.add(plb.getPattern());
/*     */     }
/* 560 */     return toList;
/*     */   }
/*     */   
/*     */   public boolean isSTARTTLS() {
/* 564 */     return this.starttls;
/*     */   }
/*     */   
/*     */   public void setSTARTTLS(boolean startTLS) {
/* 568 */     this.starttls = startTLS;
/*     */   }
/*     */   
/*     */   public boolean isSSL() {
/* 572 */     return this.ssl;
/*     */   }
/*     */   
/*     */   public void setSSL(boolean ssl) {
/* 576 */     this.ssl = ssl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEvaluator(EventEvaluator<E> eventEvaluator)
/*     */   {
/* 586 */     this.eventEvaluator = eventEvaluator;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/* 590 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/* 594 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 598 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 602 */     this.password = password;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCharsetEncoding()
/*     */   {
/* 610 */     return this.charsetEncoding;
/*     */   }
/*     */   
/*     */   public String getJndiLocation() {
/* 614 */     return this.jndiLocation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setJndiLocation(String jndiLocation)
/*     */   {
/* 625 */     this.jndiLocation = jndiLocation;
/*     */   }
/*     */   
/*     */   public boolean isSessionViaJNDI() {
/* 629 */     return this.sessionViaJNDI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSessionViaJNDI(boolean sessionViaJNDI)
/*     */   {
/* 639 */     this.sessionViaJNDI = sessionViaJNDI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCharsetEncoding(String charsetEncoding)
/*     */   {
/* 649 */     this.charsetEncoding = charsetEncoding;
/*     */   }
/*     */   
/*     */   public Layout<E> getLayout() {
/* 653 */     return this.layout;
/*     */   }
/*     */   
/*     */   public void setLayout(Layout<E> layout) {
/* 657 */     this.layout = layout;
/*     */   }
/*     */   
/*     */   class SenderRunnable implements Runnable
/*     */   {
/*     */     final CyclicBuffer<E> cyclicBuffer;
/*     */     final E e;
/*     */     
/*     */     SenderRunnable(E cyclicBuffer) {
/* 666 */       this.cyclicBuffer = cyclicBuffer;
/* 667 */       this.e = e;
/*     */     }
/*     */     
/*     */     public void run() {
/* 671 */       SMTPAppenderBase.this.sendBuffer(this.cyclicBuffer, this.e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\logback-core-1.1.7.jar!\ch\qos\logback\core\net\SMTPAppenderBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */