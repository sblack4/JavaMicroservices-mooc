/*    */ package ch.qos.logback.core.rolling;
/*    */ 
/*    */ import ch.qos.logback.core.util.DefaultInvocationGate;
/*    */ import ch.qos.logback.core.util.FileSize;
/*    */ import ch.qos.logback.core.util.InvocationGate;
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SizeBasedTriggeringPolicy<E>
/*    */   extends TriggeringPolicyBase<E>
/*    */ {
/*    */   public static final String SEE_SIZE_FORMAT = "http://logback.qos.ch/codes.html#sbtp_size_format";
/*    */   public static final long DEFAULT_MAX_FILE_SIZE = 10485760L;
/* 41 */   String maxFileSizeAsString = Long.toString(10485760L);
/*    */   FileSize maxFileSize;
/*    */   
/*    */   public SizeBasedTriggeringPolicy() {}
/*    */   
/*    */   public SizeBasedTriggeringPolicy(String maxFileSize)
/*    */   {
/* 48 */     setMaxFileSize(maxFileSize);
/*    */   }
/*    */   
/* 51 */   InvocationGate invocationGate = new DefaultInvocationGate();
/*    */   
/*    */   public boolean isTriggeringEvent(File activeFile, E event)
/*    */   {
/* 55 */     long now = System.currentTimeMillis();
/* 56 */     if (this.invocationGate.isTooSoon(now)) {
/* 57 */       return false;
/*    */     }
/* 59 */     return activeFile.length() >= this.maxFileSize.getSize();
/*    */   }
/*    */   
/*    */   public String getMaxFileSize() {
/* 63 */     return this.maxFileSizeAsString;
/*    */   }
/*    */   
/*    */   public void setMaxFileSize(String maxFileSize) {
/* 67 */     this.maxFileSizeAsString = maxFileSize;
/* 68 */     this.maxFileSize = FileSize.valueOf(maxFileSize);
/*    */   }
/*    */   
/*    */   long toFileSize(String value) {
/* 72 */     if (value == null) {
/* 73 */       return 10485760L;
/*    */     }
/* 75 */     String s = value.trim().toUpperCase();
/* 76 */     long multiplier = 1L;
/*    */     
/*    */     int index;
/* 79 */     if ((index = s.indexOf("KB")) != -1) {
/* 80 */       multiplier = 1024L;
/* 81 */       s = s.substring(0, index);
/* 82 */     } else if ((index = s.indexOf("MB")) != -1) {
/* 83 */       multiplier = 1048576L;
/* 84 */       s = s.substring(0, index);
/* 85 */     } else if ((index = s.indexOf("GB")) != -1) {
/* 86 */       multiplier = 1073741824L;
/* 87 */       s = s.substring(0, index);
/*    */     }
/* 89 */     if (s != null) {
/*    */       try {
/* 91 */         return Long.valueOf(s).longValue() * multiplier;
/*    */       } catch (NumberFormatException e) {
/* 93 */         addError("[" + s + "] is not in proper int format. Please refer to " + "http://logback.qos.ch/codes.html#sbtp_size_format");
/* 94 */         addError("[" + value + "] not in expected format.", e);
/*    */       }
/*    */     }
/* 97 */     return 10485760L;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\logback-core-1.1.7.jar!\ch\qos\logback\core\rolling\SizeBasedTriggeringPolicy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */