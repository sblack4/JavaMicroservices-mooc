/*     */ package ch.qos.logback.core.rolling.helper;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.pattern.Converter;
/*     */ import ch.qos.logback.core.pattern.LiteralConverter;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.util.FileSize;
/*     */ import java.io.File;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.Date;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Future;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimeBasedArchiveRemover
/*     */   extends ContextAwareBase
/*     */   implements ArchiveRemover
/*     */ {
/*     */   private static final int UNTOUCHABLE_ARCHIVE_FILE_COUNT = 2;
/*     */   protected static final long UNINITIALIZED = -1L;
/*     */   protected static final long INACTIVITY_TOLERANCE_IN_MILLIS = 2764800000L;
/*     */   static final int MAX_VALUE_FOR_INACTIVITY_PERIODS = 336;
/*     */   final FileNamePattern fileNamePattern;
/*     */   final RollingCalendar rc;
/*  42 */   private int maxHistory = 0;
/*  43 */   private long totalSizeCap = 0L;
/*     */   final boolean parentClean;
/*  45 */   long lastHeartBeat = -1L;
/*     */   
/*     */   public TimeBasedArchiveRemover(FileNamePattern fileNamePattern, RollingCalendar rc) {
/*  48 */     this.fileNamePattern = fileNamePattern;
/*  49 */     this.rc = rc;
/*  50 */     this.parentClean = computeParentCleaningFlag(fileNamePattern);
/*     */   }
/*     */   
/*     */   public void clean(Date now) {
/*  54 */     long nowInMillis = now.getTime();
/*     */     
/*  56 */     int periodsElapsed = computeElapsedPeriodsSinceLastClean(nowInMillis);
/*  57 */     this.lastHeartBeat = nowInMillis;
/*  58 */     if (periodsElapsed > 1) {
/*  59 */       addInfo("Multiple periods, i.e. " + periodsElapsed + " periods, seem to have elapsed. This is expected at application start.");
/*     */     }
/*  61 */     for (int i = 0; i < periodsElapsed; i++) {
/*  62 */       int offset = getPeriodOffsetForDeletionTarget() - i;
/*  63 */       Date dateOfPeriodToClean = this.rc.getEndOfNextNthPeriod(now, offset);
/*  64 */       cleanPeriod(dateOfPeriodToClean);
/*     */     }
/*     */   }
/*     */   
/*     */   protected File[] getFilesInPeriod(Date dateOfPeriodToClean) {
/*  69 */     String filenameToDelete = this.fileNamePattern.convert(dateOfPeriodToClean);
/*  70 */     File file2Delete = new File(filenameToDelete);
/*     */     
/*  72 */     if (fileExistsAndIsFile(file2Delete)) {
/*  73 */       return new File[] { file2Delete };
/*     */     }
/*  75 */     return new File[0];
/*     */   }
/*     */   
/*     */   private boolean fileExistsAndIsFile(File file2Delete)
/*     */   {
/*  80 */     return (file2Delete.exists()) && (file2Delete.isFile());
/*     */   }
/*     */   
/*     */   public void cleanPeriod(Date dateOfPeriodToClean) {
/*  84 */     File[] matchingFileArray = getFilesInPeriod(dateOfPeriodToClean);
/*     */     
/*  86 */     for (File f : matchingFileArray) {
/*  87 */       addInfo("deleting " + f);
/*  88 */       f.delete();
/*     */     }
/*     */     
/*  91 */     if ((this.parentClean) && (matchingFileArray.length > 0)) {
/*  92 */       File parentDir = getParentDir(matchingFileArray[0]);
/*  93 */       removeFolderIfEmpty(parentDir);
/*     */     }
/*     */   }
/*     */   
/*     */   void capTotalSize(Date now) {
/*  98 */     int totalSize = 0;
/*  99 */     int totalRemoved = 0;
/* 100 */     for (int offset = 0; offset < this.maxHistory; offset++) {
/* 101 */       Date date = this.rc.getEndOfNextNthPeriod(now, -offset);
/* 102 */       File[] matchingFileArray = getFilesInPeriod(date);
/* 103 */       descendingSortByLastModified(matchingFileArray);
/* 104 */       for (File f : matchingFileArray) {
/* 105 */         long size = f.length();
/* 106 */         if (totalSize + size > this.totalSizeCap) {
/* 107 */           if (offset >= 2) {
/* 108 */             addInfo("Deleting [" + f + "]" + " of size " + new FileSize(size));
/* 109 */             totalRemoved = (int)(totalRemoved + size);
/* 110 */             f.delete();
/*     */           } else {
/* 112 */             addWarn("Skipping [" + f + "]" + " of size " + new FileSize(size) + " as it is one of the two newest log achives.");
/*     */           }
/*     */         }
/* 115 */         totalSize = (int)(totalSize + size);
/*     */       }
/*     */     }
/* 118 */     addInfo("Removed  " + new FileSize(totalRemoved) + " of files");
/*     */   }
/*     */   
/*     */   private void descendingSortByLastModified(File[] matchingFileArray) {
/* 122 */     Arrays.sort(matchingFileArray, new Comparator()
/*     */     {
/*     */       public int compare(File f1, File f2) {
/* 125 */         long l1 = f1.lastModified();
/* 126 */         long l2 = f2.lastModified();
/* 127 */         if (l1 == l2) {
/* 128 */           return 0;
/*     */         }
/* 130 */         if (l2 < l1) {
/* 131 */           return -1;
/*     */         }
/* 133 */         return 1;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   File getParentDir(File file) {
/* 139 */     File absolute = file.getAbsoluteFile();
/* 140 */     File parentDir = absolute.getParentFile();
/* 141 */     return parentDir;
/*     */   }
/*     */   
/*     */   int computeElapsedPeriodsSinceLastClean(long nowInMillis) {
/* 145 */     long periodsElapsed = 0L;
/* 146 */     if (this.lastHeartBeat == -1L) {
/* 147 */       addInfo("first clean up after appender initialization");
/* 148 */       periodsElapsed = this.rc.periodBarriersCrossed(nowInMillis, nowInMillis + 2764800000L);
/* 149 */       periodsElapsed = Math.min(periodsElapsed, 336L);
/*     */     } else {
/* 151 */       periodsElapsed = this.rc.periodBarriersCrossed(this.lastHeartBeat, nowInMillis);
/*     */     }
/*     */     
/* 154 */     return (int)periodsElapsed;
/*     */   }
/*     */   
/*     */   boolean computeParentCleaningFlag(FileNamePattern fileNamePattern) {
/* 158 */     DateTokenConverter<Object> dtc = fileNamePattern.getPrimaryDateTokenConverter();
/*     */     
/* 160 */     if (dtc.getDatePattern().indexOf('/') != -1) {
/* 161 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 166 */     Converter<Object> p = fileNamePattern.headTokenConverter;
/*     */     
/*     */ 
/* 169 */     while ((p != null) && 
/* 170 */       (!(p instanceof DateTokenConverter)))
/*     */     {
/*     */ 
/* 173 */       p = p.getNext();
/*     */     }
/*     */     
/* 176 */     while (p != null) {
/* 177 */       if ((p instanceof LiteralConverter)) {
/* 178 */         String s = p.convert(null);
/* 179 */         if (s.indexOf('/') != -1) {
/* 180 */           return true;
/*     */         }
/*     */       }
/* 183 */       p = p.getNext();
/*     */     }
/*     */     
/*     */ 
/* 187 */     return false;
/*     */   }
/*     */   
/*     */   void removeFolderIfEmpty(File dir) {
/* 191 */     removeFolderIfEmpty(dir, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void removeFolderIfEmpty(File dir, int depth)
/*     */   {
/* 204 */     if (depth >= 3) {
/* 205 */       return;
/*     */     }
/* 207 */     if ((dir.isDirectory()) && (FileFilterUtil.isEmptyDirectory(dir))) {
/* 208 */       addInfo("deleting folder [" + dir + "]");
/* 209 */       dir.delete();
/* 210 */       removeFolderIfEmpty(dir.getParentFile(), depth + 1);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setMaxHistory(int maxHistory) {
/* 215 */     this.maxHistory = maxHistory;
/*     */   }
/*     */   
/*     */   protected int getPeriodOffsetForDeletionTarget() {
/* 219 */     return -this.maxHistory - 1;
/*     */   }
/*     */   
/*     */   public void setTotalSizeCap(long totalSizeCap) {
/* 223 */     this.totalSizeCap = totalSizeCap;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 227 */     return "c.q.l.core.rolling.helper.TimeBasedArchiveRemover";
/*     */   }
/*     */   
/*     */   public Future<?> cleanAsynchronously(Date now) {
/* 231 */     ArhiveRemoverRunnable runnable = new ArhiveRemoverRunnable(now);
/* 232 */     ExecutorService executorService = this.context.getScheduledExecutorService();
/* 233 */     Future<?> future = executorService.submit(runnable);
/* 234 */     return future;
/*     */   }
/*     */   
/*     */   public class ArhiveRemoverRunnable implements Runnable {
/*     */     Date now;
/*     */     
/*     */     ArhiveRemoverRunnable(Date now) {
/* 241 */       this.now = now;
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/* 246 */       TimeBasedArchiveRemover.this.clean(this.now);
/* 247 */       if ((TimeBasedArchiveRemover.this.totalSizeCap != 0L) && (TimeBasedArchiveRemover.this.totalSizeCap > 0L)) {
/* 248 */         TimeBasedArchiveRemover.this.capTotalSize(this.now);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\logback-core-1.1.7.jar!\ch\qos\logback\core\rolling\helper\TimeBasedArchiveRemover.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */