/*     */ package ch.qos.logback.core.joran.util;
/*     */ 
/*     */ import ch.qos.logback.core.joran.spi.DefaultClass;
/*     */ import ch.qos.logback.core.joran.spi.DefaultNestedComponentRegistry;
/*     */ import ch.qos.logback.core.joran.util.beans.BeanDescription;
/*     */ import ch.qos.logback.core.joran.util.beans.BeanDescriptionCache;
/*     */ import ch.qos.logback.core.joran.util.beans.BeanUtil;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.util.AggregationType;
/*     */ import ch.qos.logback.core.util.PropertySetterException;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertySetter
/*     */   extends ContextAwareBase
/*     */ {
/*     */   protected final Object obj;
/*     */   protected final Class<?> objClass;
/*     */   protected final BeanDescription beanDescription;
/*     */   
/*     */   public PropertySetter(BeanDescriptionCache beanDescriptionCache, Object obj)
/*     */   {
/*  66 */     this.obj = obj;
/*  67 */     this.objClass = obj.getClass();
/*  68 */     this.beanDescription = beanDescriptionCache.getBeanDescription(this.objClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProperty(String name, String value)
/*     */   {
/*  91 */     if (value == null) {
/*  92 */       return;
/*     */     }
/*  94 */     Method setter = findSetterMethod(name);
/*  95 */     if (setter == null) {
/*  96 */       addWarn("No setter for property [" + name + "] in " + this.objClass.getName() + ".");
/*     */     } else {
/*     */       try {
/*  99 */         setProperty(setter, name, value);
/*     */       } catch (PropertySetterException ex) {
/* 101 */         addWarn("Failed to set property [" + name + "] to value \"" + value + "\". ", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setProperty(Method setter, String name, String value)
/*     */     throws PropertySetterException
/*     */   {
/* 119 */     Class<?>[] paramTypes = setter.getParameterTypes();
/*     */     
/*     */     Object arg;
/*     */     try
/*     */     {
/* 124 */       arg = StringToObjectConverter.convertArg(this, value, paramTypes[0]);
/*     */     } catch (Throwable t) {
/* 126 */       throw new PropertySetterException("Conversion to type [" + paramTypes[0] + "] failed. ", t);
/*     */     }
/*     */     
/* 129 */     if (arg == null) {
/* 130 */       throw new PropertySetterException("Conversion to type [" + paramTypes[0] + "] failed.");
/*     */     }
/*     */     try {
/* 133 */       setter.invoke(this.obj, new Object[] { arg });
/*     */     } catch (Exception ex) {
/* 135 */       throw new PropertySetterException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public AggregationType computeAggregationType(String name) {
/* 140 */     String cName = capitalizeFirstLetter(name);
/*     */     
/* 142 */     Method addMethod = findAdderMethod(cName);
/*     */     
/*     */ 
/* 145 */     if (addMethod != null) {
/* 146 */       AggregationType type = computeRawAggregationType(addMethod);
/* 147 */       switch (type) {
/*     */       case NOT_FOUND: 
/* 149 */         return AggregationType.NOT_FOUND;
/*     */       case AS_BASIC_PROPERTY: 
/* 151 */         return AggregationType.AS_BASIC_PROPERTY_COLLECTION;
/*     */       case AS_COMPLEX_PROPERTY: 
/* 153 */         return AggregationType.AS_COMPLEX_PROPERTY_COLLECTION;
/*     */       }
/*     */       
/*     */     }
/* 157 */     Method setter = findSetterMethod(name);
/* 158 */     if (setter != null) {
/* 159 */       return computeRawAggregationType(setter);
/*     */     }
/*     */     
/* 162 */     return AggregationType.NOT_FOUND;
/*     */   }
/*     */   
/*     */   private Method findAdderMethod(String name)
/*     */   {
/* 167 */     String propertyName = BeanUtil.INSTANCE.toLowerCamelCase(name);
/* 168 */     return this.beanDescription.getAdder(propertyName);
/*     */   }
/*     */   
/*     */   private Method findSetterMethod(String name) {
/* 172 */     String propertyName = BeanUtil.INSTANCE.toLowerCamelCase(name);
/* 173 */     return this.beanDescription.getSetter(propertyName);
/*     */   }
/*     */   
/*     */   private Class<?> getParameterClassForMethod(Method method) {
/* 177 */     if (method == null) {
/* 178 */       return null;
/*     */     }
/* 180 */     Class<?>[] classArray = method.getParameterTypes();
/* 181 */     if (classArray.length != 1) {
/* 182 */       return null;
/*     */     }
/* 184 */     return classArray[0];
/*     */   }
/*     */   
/*     */   private AggregationType computeRawAggregationType(Method method)
/*     */   {
/* 189 */     Class<?> parameterClass = getParameterClassForMethod(method);
/* 190 */     if (parameterClass == null) {
/* 191 */       return AggregationType.NOT_FOUND;
/*     */     }
/* 193 */     if (StringToObjectConverter.canBeBuiltFromSimpleString(parameterClass)) {
/* 194 */       return AggregationType.AS_BASIC_PROPERTY;
/*     */     }
/* 196 */     return AggregationType.AS_COMPLEX_PROPERTY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isUnequivocallyInstantiable(Class<?> clazz)
/*     */   {
/* 208 */     if (clazz.isInterface()) {
/* 209 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 216 */       Object o = clazz.newInstance();
/* 217 */       if (o != null) {
/* 218 */         return true;
/*     */       }
/* 220 */       return false;
/*     */     }
/*     */     catch (InstantiationException e) {
/* 223 */       return false;
/*     */     } catch (IllegalAccessException e) {}
/* 225 */     return false;
/*     */   }
/*     */   
/*     */   public Class<?> getObjClass()
/*     */   {
/* 230 */     return this.objClass;
/*     */   }
/*     */   
/*     */   public void addComplexProperty(String name, Object complexProperty) {
/* 234 */     Method adderMethod = findAdderMethod(name);
/*     */     
/* 236 */     if (adderMethod != null) {
/* 237 */       Class<?>[] paramTypes = adderMethod.getParameterTypes();
/* 238 */       if (!isSanityCheckSuccessful(name, adderMethod, paramTypes, complexProperty)) {
/* 239 */         return;
/*     */       }
/* 241 */       invokeMethodWithSingleParameterOnThisObject(adderMethod, complexProperty);
/*     */     } else {
/* 243 */       addError("Could not find method [add" + name + "] in class [" + this.objClass.getName() + "].");
/*     */     }
/*     */   }
/*     */   
/*     */   void invokeMethodWithSingleParameterOnThisObject(Method method, Object parameter) {
/* 248 */     Class<?> ccc = parameter.getClass();
/*     */     try {
/* 250 */       method.invoke(this.obj, new Object[] { parameter });
/*     */     } catch (Exception e) {
/* 252 */       addError("Could not invoke method " + method.getName() + " in class " + this.obj.getClass().getName() + " with parameter of type " + ccc.getName(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addBasicProperty(String name, String strValue)
/*     */   {
/* 258 */     if (strValue == null) {
/* 259 */       return;
/*     */     }
/*     */     
/* 262 */     name = capitalizeFirstLetter(name);
/* 263 */     Method adderMethod = findAdderMethod(name);
/*     */     
/* 265 */     if (adderMethod == null) {
/* 266 */       addError("No adder for property [" + name + "].");
/* 267 */       return;
/*     */     }
/*     */     
/* 270 */     Class<?>[] paramTypes = adderMethod.getParameterTypes();
/* 271 */     isSanityCheckSuccessful(name, adderMethod, paramTypes, strValue);
/*     */     Object arg;
/*     */     try
/*     */     {
/* 275 */       arg = StringToObjectConverter.convertArg(this, strValue, paramTypes[0]);
/*     */     } catch (Throwable t) {
/* 277 */       addError("Conversion to type [" + paramTypes[0] + "] failed. ", t);
/* 278 */       return;
/*     */     }
/* 280 */     if (arg != null) {
/* 281 */       invokeMethodWithSingleParameterOnThisObject(adderMethod, strValue);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setComplexProperty(String name, Object complexProperty) {
/* 286 */     Method setter = findSetterMethod(name);
/*     */     
/* 288 */     if (setter == null) {
/* 289 */       addWarn("Not setter method for property [" + name + "] in " + this.obj.getClass().getName());
/*     */       
/* 291 */       return;
/*     */     }
/*     */     
/* 294 */     Class<?>[] paramTypes = setter.getParameterTypes();
/*     */     
/* 296 */     if (!isSanityCheckSuccessful(name, setter, paramTypes, complexProperty)) {
/* 297 */       return;
/*     */     }
/*     */     try {
/* 300 */       invokeMethodWithSingleParameterOnThisObject(setter, complexProperty);
/*     */     }
/*     */     catch (Exception e) {
/* 303 */       addError("Could not set component " + this.obj + " for parent component " + this.obj, e);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isSanityCheckSuccessful(String name, Method method, Class<?>[] params, Object complexProperty) {
/* 308 */     Class<?> ccc = complexProperty.getClass();
/* 309 */     if (params.length != 1) {
/* 310 */       addError("Wrong number of parameters in setter method for property [" + name + "] in " + this.obj.getClass().getName());
/*     */       
/* 312 */       return false;
/*     */     }
/*     */     
/* 315 */     if (!params[0].isAssignableFrom(complexProperty.getClass())) {
/* 316 */       addError("A \"" + ccc.getName() + "\" object is not assignable to a \"" + params[0].getName() + "\" variable.");
/* 317 */       addError("The class \"" + params[0].getName() + "\" was loaded by ");
/* 318 */       addError("[" + params[0].getClassLoader() + "] whereas object of type ");
/* 319 */       addError("\"" + ccc.getName() + "\" was loaded by [" + ccc.getClassLoader() + "].");
/* 320 */       return false;
/*     */     }
/*     */     
/* 323 */     return true;
/*     */   }
/*     */   
/*     */   private String capitalizeFirstLetter(String name) {
/* 327 */     return name.substring(0, 1).toUpperCase() + name.substring(1);
/*     */   }
/*     */   
/*     */   public Object getObj()
/*     */   {
/* 332 */     return this.obj;
/*     */   }
/*     */   
/*     */   Method getRelevantMethod(String name, AggregationType aggregationType) {
/*     */     Method relevantMethod;
/* 337 */     if (aggregationType == AggregationType.AS_COMPLEX_PROPERTY_COLLECTION) {
/* 338 */       relevantMethod = findAdderMethod(name); } else { Method relevantMethod;
/* 339 */       if (aggregationType == AggregationType.AS_COMPLEX_PROPERTY) {
/* 340 */         relevantMethod = findSetterMethod(name);
/*     */       } else
/* 342 */         throw new IllegalStateException(aggregationType + " not allowed here"); }
/*     */     Method relevantMethod;
/* 344 */     return relevantMethod;
/*     */   }
/*     */   
/*     */   <T extends Annotation> T getAnnotation(String name, Class<T> annonationClass, Method relevantMethod)
/*     */   {
/* 349 */     if (relevantMethod != null) {
/* 350 */       return relevantMethod.getAnnotation(annonationClass);
/*     */     }
/* 352 */     return null;
/*     */   }
/*     */   
/*     */   Class<?> getDefaultClassNameByAnnonation(String name, Method relevantMethod)
/*     */   {
/* 357 */     DefaultClass defaultClassAnnon = (DefaultClass)getAnnotation(name, DefaultClass.class, relevantMethod);
/* 358 */     if (defaultClassAnnon != null) {
/* 359 */       return defaultClassAnnon.value();
/*     */     }
/* 361 */     return null;
/*     */   }
/*     */   
/*     */   Class<?> getByConcreteType(String name, Method relevantMethod)
/*     */   {
/* 366 */     Class<?> paramType = getParameterClassForMethod(relevantMethod);
/* 367 */     if (paramType == null) {
/* 368 */       return null;
/*     */     }
/*     */     
/* 371 */     boolean isUnequivocallyInstantiable = isUnequivocallyInstantiable(paramType);
/* 372 */     if (isUnequivocallyInstantiable) {
/* 373 */       return paramType;
/*     */     }
/* 375 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Class<?> getClassNameViaImplicitRules(String name, AggregationType aggregationType, DefaultNestedComponentRegistry registry)
/*     */   {
/* 382 */     Class<?> registryResult = registry.findDefaultComponentType(this.obj.getClass(), name);
/* 383 */     if (registryResult != null) {
/* 384 */       return registryResult;
/*     */     }
/*     */     
/* 387 */     Method relevantMethod = getRelevantMethod(name, aggregationType);
/* 388 */     if (relevantMethod == null) {
/* 389 */       return null;
/*     */     }
/* 391 */     Class<?> byAnnotation = getDefaultClassNameByAnnonation(name, relevantMethod);
/* 392 */     if (byAnnotation != null) {
/* 393 */       return byAnnotation;
/*     */     }
/* 395 */     return getByConcreteType(name, relevantMethod);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\logback-core-1.1.7.jar!\ch\qos\logback\core\joran\util\PropertySetter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */