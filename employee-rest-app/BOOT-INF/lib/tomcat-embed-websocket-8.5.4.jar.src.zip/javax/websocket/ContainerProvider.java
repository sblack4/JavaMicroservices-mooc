/*    */ package javax.websocket;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.ServiceLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ContainerProvider
/*    */ {
/*    */   private static final String DEFAULT_PROVIDER_CLASS_NAME = "org.apache.tomcat.websocket.WsWebSocketContainer";
/*    */   
/*    */   public static WebSocketContainer getWebSocketContainer()
/*    */   {
/* 37 */     WebSocketContainer result = null;
/*    */     
/* 39 */     ServiceLoader<ContainerProvider> serviceLoader = ServiceLoader.load(ContainerProvider.class);
/*    */     
/* 41 */     Iterator<ContainerProvider> iter = serviceLoader.iterator();
/* 42 */     while ((result == null) && (iter.hasNext())) {
/* 43 */       result = ((ContainerProvider)iter.next()).getContainer();
/*    */     }
/*    */     
/*    */ 
/* 47 */     if (result == null) {
/*    */       try
/*    */       {
/* 50 */         Class<WebSocketContainer> clazz = Class.forName("org.apache.tomcat.websocket.WsWebSocketContainer");
/*    */         
/*    */ 
/* 53 */         result = (WebSocketContainer)clazz.newInstance();
/*    */       }
/*    */       catch (ClassNotFoundException|InstantiationException|IllegalAccessException localClassNotFoundException) {}
/*    */     }
/*    */     
/*    */ 
/* 59 */     return result;
/*    */   }
/*    */   
/*    */   protected abstract WebSocketContainer getContainer();
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-websocket-8.5.4.jar!\javax\websocket\ContainerProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */