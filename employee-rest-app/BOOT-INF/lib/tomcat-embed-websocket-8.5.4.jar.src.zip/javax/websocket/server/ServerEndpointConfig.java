/*     */ package javax.websocket.server;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ServiceLoader;
/*     */ import javax.websocket.Decoder;
/*     */ import javax.websocket.Encoder;
/*     */ import javax.websocket.EndpointConfig;
/*     */ import javax.websocket.Extension;
/*     */ import javax.websocket.HandshakeResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface ServerEndpointConfig
/*     */   extends EndpointConfig
/*     */ {
/*     */   public abstract Class<?> getEndpointClass();
/*     */   
/*     */   public abstract String getPath();
/*     */   
/*     */   public abstract List<String> getSubprotocols();
/*     */   
/*     */   public abstract List<Extension> getExtensions();
/*     */   
/*     */   public abstract Configurator getConfigurator();
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     private final Class<?> endpointClass;
/*     */     private final String path;
/*     */     
/*     */     public static Builder create(Class<?> endpointClass, String path)
/*     */     {
/*  57 */       return new Builder(endpointClass, path);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  63 */     private List<Class<? extends Encoder>> encoders = Collections.emptyList();
/*     */     
/*  65 */     private List<Class<? extends Decoder>> decoders = Collections.emptyList();
/*     */     
/*  67 */     private List<String> subprotocols = Collections.emptyList();
/*  68 */     private List<Extension> extensions = Collections.emptyList();
/*  69 */     private ServerEndpointConfig.Configurator configurator = ServerEndpointConfig.Configurator.fetchContainerDefaultConfigurator();
/*     */     
/*     */ 
/*     */ 
/*     */     private Builder(Class<?> endpointClass, String path)
/*     */     {
/*  75 */       this.endpointClass = endpointClass;
/*  76 */       this.path = path;
/*     */     }
/*     */     
/*     */     public ServerEndpointConfig build() {
/*  80 */       return new DefaultServerEndpointConfig(this.endpointClass, this.path, this.subprotocols, this.extensions, this.encoders, this.decoders, this.configurator);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Builder encoders(List<Class<? extends Encoder>> encoders)
/*     */     {
/*  87 */       if ((encoders == null) || (encoders.size() == 0)) {
/*  88 */         this.encoders = Collections.emptyList();
/*     */       } else {
/*  90 */         this.encoders = Collections.unmodifiableList(encoders);
/*     */       }
/*  92 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */     public Builder decoders(List<Class<? extends Decoder>> decoders)
/*     */     {
/*  98 */       if ((decoders == null) || (decoders.size() == 0)) {
/*  99 */         this.decoders = Collections.emptyList();
/*     */       } else {
/* 101 */         this.decoders = Collections.unmodifiableList(decoders);
/*     */       }
/* 103 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */     public Builder subprotocols(List<String> subprotocols)
/*     */     {
/* 109 */       if ((subprotocols == null) || (subprotocols.size() == 0)) {
/* 110 */         this.subprotocols = Collections.emptyList();
/*     */       } else {
/* 112 */         this.subprotocols = Collections.unmodifiableList(subprotocols);
/*     */       }
/* 114 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */     public Builder extensions(List<Extension> extensions)
/*     */     {
/* 120 */       if ((extensions == null) || (extensions.size() == 0)) {
/* 121 */         this.extensions = Collections.emptyList();
/*     */       } else {
/* 123 */         this.extensions = Collections.unmodifiableList(extensions);
/*     */       }
/* 125 */       return this;
/*     */     }
/*     */     
/*     */     public Builder configurator(ServerEndpointConfig.Configurator serverEndpointConfigurator)
/*     */     {
/* 130 */       if (serverEndpointConfigurator == null) {
/* 131 */         this.configurator = ServerEndpointConfig.Configurator.fetchContainerDefaultConfigurator();
/*     */       } else {
/* 133 */         this.configurator = serverEndpointConfigurator;
/*     */       }
/* 135 */       return this;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class Configurator
/*     */   {
/* 142 */     private static volatile Configurator defaultImpl = null;
/* 143 */     private static final Object defaultImplLock = new Object();
/*     */     
/*     */     private static final String DEFAULT_IMPL_CLASSNAME = "org.apache.tomcat.websocket.server.DefaultServerEndpointConfigurator";
/*     */     
/*     */     static Configurator fetchContainerDefaultConfigurator()
/*     */     {
/* 149 */       if (defaultImpl == null) {
/* 150 */         synchronized (defaultImplLock) {
/* 151 */           if (defaultImpl == null) {
/* 152 */             defaultImpl = loadDefault();
/*     */           }
/*     */         }
/*     */       }
/* 156 */       return defaultImpl;
/*     */     }
/*     */     
/*     */     private static Configurator loadDefault()
/*     */     {
/* 161 */       Configurator result = null;
/*     */       
/* 163 */       ServiceLoader<Configurator> serviceLoader = ServiceLoader.load(Configurator.class);
/*     */       
/*     */ 
/* 166 */       Iterator<Configurator> iter = serviceLoader.iterator();
/* 167 */       while ((result == null) && (iter.hasNext())) {
/* 168 */         result = (Configurator)iter.next();
/*     */       }
/*     */       
/*     */ 
/* 172 */       if (result == null) {
/*     */         try
/*     */         {
/* 175 */           Class<Configurator> clazz = Class.forName("org.apache.tomcat.websocket.server.DefaultServerEndpointConfigurator");
/*     */           
/*     */ 
/* 178 */           result = (Configurator)clazz.newInstance();
/*     */         }
/*     */         catch (ClassNotFoundException|InstantiationException|IllegalAccessException localClassNotFoundException) {}
/*     */       }
/*     */       
/*     */ 
/* 184 */       return result;
/*     */     }
/*     */     
/*     */     public String getNegotiatedSubprotocol(List<String> supported, List<String> requested)
/*     */     {
/* 189 */       return fetchContainerDefaultConfigurator().getNegotiatedSubprotocol(supported, requested);
/*     */     }
/*     */     
/*     */     public List<Extension> getNegotiatedExtensions(List<Extension> installed, List<Extension> requested)
/*     */     {
/* 194 */       return fetchContainerDefaultConfigurator().getNegotiatedExtensions(installed, requested);
/*     */     }
/*     */     
/*     */     public boolean checkOrigin(String originHeaderValue) {
/* 198 */       return fetchContainerDefaultConfigurator().checkOrigin(originHeaderValue);
/*     */     }
/*     */     
/*     */     public void modifyHandshake(ServerEndpointConfig sec, HandshakeRequest request, HandshakeResponse response)
/*     */     {
/* 203 */       fetchContainerDefaultConfigurator().modifyHandshake(sec, request, response);
/*     */     }
/*     */     
/*     */     public <T> T getEndpointInstance(Class<T> clazz) throws InstantiationException
/*     */     {
/* 208 */       return (T)fetchContainerDefaultConfigurator().getEndpointInstance(clazz);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-websocket-8.5.4.jar!\javax\websocket\server\ServerEndpointConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */