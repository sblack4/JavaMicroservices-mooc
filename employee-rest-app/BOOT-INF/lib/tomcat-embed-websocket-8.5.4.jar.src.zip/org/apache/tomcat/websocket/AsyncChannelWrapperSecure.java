/*     */ package org.apache.tomcat.websocket;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.AsynchronousSocketChannel;
/*     */ import java.nio.channels.CompletionHandler;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import javax.net.ssl.SSLEngine;
/*     */ import javax.net.ssl.SSLEngineResult;
/*     */ import javax.net.ssl.SSLEngineResult.HandshakeStatus;
/*     */ import javax.net.ssl.SSLEngineResult.Status;
/*     */ import javax.net.ssl.SSLException;
/*     */ import javax.net.ssl.SSLSession;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsyncChannelWrapperSecure
/*     */   implements AsyncChannelWrapper
/*     */ {
/*  51 */   private static final Log log = LogFactory.getLog(AsyncChannelWrapperSecure.class);
/*     */   
/*  53 */   private static final StringManager sm = StringManager.getManager(AsyncChannelWrapperSecure.class);
/*     */   
/*     */ 
/*  56 */   private static final ByteBuffer DUMMY = ByteBuffer.allocate(8192);
/*     */   
/*     */   private final AsynchronousSocketChannel socketChannel;
/*     */   private final SSLEngine sslEngine;
/*     */   private final ByteBuffer socketReadBuffer;
/*     */   private final ByteBuffer socketWriteBuffer;
/*  62 */   private final ExecutorService executor = Executors.newFixedThreadPool(2, new SecureIOThreadFactory(null));
/*     */   
/*  64 */   private AtomicBoolean writing = new AtomicBoolean(false);
/*  65 */   private AtomicBoolean reading = new AtomicBoolean(false);
/*     */   
/*     */   public AsyncChannelWrapperSecure(AsynchronousSocketChannel socketChannel, SSLEngine sslEngine)
/*     */   {
/*  69 */     this.socketChannel = socketChannel;
/*  70 */     this.sslEngine = sslEngine;
/*     */     
/*  72 */     int socketBufferSize = sslEngine.getSession().getPacketBufferSize();
/*  73 */     this.socketReadBuffer = ByteBuffer.allocateDirect(socketBufferSize);
/*  74 */     this.socketWriteBuffer = ByteBuffer.allocateDirect(socketBufferSize);
/*     */   }
/*     */   
/*     */   public Future<Integer> read(ByteBuffer dst)
/*     */   {
/*  79 */     WrapperFuture<Integer, Void> future = new WrapperFuture();
/*     */     
/*  81 */     if (!this.reading.compareAndSet(false, true)) {
/*  82 */       throw new IllegalStateException(sm.getString("asyncChannelWrapperSecure.concurrentRead"));
/*     */     }
/*     */     
/*     */ 
/*  86 */     ReadTask readTask = new ReadTask(dst, future);
/*     */     
/*  88 */     this.executor.execute(readTask);
/*     */     
/*  90 */     return future;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public <B, A extends B> void read(ByteBuffer dst, A attachment, CompletionHandler<Integer, B> handler)
/*     */   {
/*  97 */     WrapperFuture<Integer, B> future = new WrapperFuture(handler, attachment);
/*     */     
/*     */ 
/* 100 */     if (!this.reading.compareAndSet(false, true)) {
/* 101 */       throw new IllegalStateException(sm.getString("asyncChannelWrapperSecure.concurrentRead"));
/*     */     }
/*     */     
/*     */ 
/* 105 */     ReadTask readTask = new ReadTask(dst, future);
/*     */     
/* 107 */     this.executor.execute(readTask);
/*     */   }
/*     */   
/*     */ 
/*     */   public Future<Integer> write(ByteBuffer src)
/*     */   {
/* 113 */     WrapperFuture<Long, Void> inner = new WrapperFuture();
/*     */     
/* 115 */     if (!this.writing.compareAndSet(false, true)) {
/* 116 */       throw new IllegalStateException(sm.getString("asyncChannelWrapperSecure.concurrentWrite"));
/*     */     }
/*     */     
/*     */ 
/* 120 */     WriteTask writeTask = new WriteTask(new ByteBuffer[] { src }, 0, 1, inner);
/*     */     
/*     */ 
/* 123 */     this.executor.execute(writeTask);
/*     */     
/* 125 */     Future<Integer> future = new LongToIntegerFuture(inner);
/* 126 */     return future;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public <B, A extends B> void write(ByteBuffer[] srcs, int offset, int length, long timeout, TimeUnit unit, A attachment, CompletionHandler<Long, B> handler)
/*     */   {
/* 134 */     WrapperFuture<Long, B> future = new WrapperFuture(handler, attachment);
/*     */     
/*     */ 
/* 137 */     if (!this.writing.compareAndSet(false, true)) {
/* 138 */       throw new IllegalStateException(sm.getString("asyncChannelWrapperSecure.concurrentWrite"));
/*     */     }
/*     */     
/*     */ 
/* 142 */     WriteTask writeTask = new WriteTask(srcs, offset, length, future);
/*     */     
/* 144 */     this.executor.execute(writeTask);
/*     */   }
/*     */   
/*     */   public void close()
/*     */   {
/*     */     try {
/* 150 */       this.socketChannel.close();
/*     */     } catch (IOException e) {
/* 152 */       log.info(sm.getString("asyncChannelWrapperSecure.closeFail"));
/*     */     }
/* 154 */     this.executor.shutdownNow();
/*     */   }
/*     */   
/*     */   public Future<Void> handshake()
/*     */     throws SSLException
/*     */   {
/* 160 */     WrapperFuture<Void, Void> wFuture = new WrapperFuture();
/*     */     
/* 162 */     Thread t = new WebSocketSslHandshakeThread(wFuture);
/* 163 */     t.start();
/*     */     
/* 165 */     return wFuture;
/*     */   }
/*     */   
/*     */   private class WriteTask
/*     */     implements Runnable
/*     */   {
/*     */     private final ByteBuffer[] srcs;
/*     */     private final int offset;
/*     */     private final int length;
/*     */     private final AsyncChannelWrapperSecure.WrapperFuture<Long, ?> future;
/*     */     
/*     */     public WriteTask(int srcs, int offset, AsyncChannelWrapperSecure.WrapperFuture<Long, ?> length)
/*     */     {
/* 178 */       this.srcs = srcs;
/* 179 */       this.future = future;
/* 180 */       this.offset = offset;
/* 181 */       this.length = length;
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/* 186 */       long written = 0L;
/*     */       try
/*     */       {
/* 189 */         for (int i = this.offset; i < this.offset + this.length; i++) {
/* 190 */           ByteBuffer src = this.srcs[i];
/* 191 */           while (src.hasRemaining()) {
/* 192 */             AsyncChannelWrapperSecure.this.socketWriteBuffer.clear();
/*     */             
/*     */ 
/* 195 */             SSLEngineResult r = AsyncChannelWrapperSecure.this.sslEngine.wrap(src, AsyncChannelWrapperSecure.this.socketWriteBuffer);
/* 196 */             written += r.bytesConsumed();
/* 197 */             SSLEngineResult.Status s = r.getStatus();
/*     */             
/* 199 */             if ((s != SSLEngineResult.Status.OK) && (s != SSLEngineResult.Status.BUFFER_OVERFLOW))
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 205 */               throw new IllegalStateException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.statusWrap"));
/*     */             }
/*     */             
/*     */ 
/*     */ 
/* 210 */             if (r.getHandshakeStatus() == SSLEngineResult.HandshakeStatus.NEED_TASK) {
/* 211 */               Runnable runnable = AsyncChannelWrapperSecure.this.sslEngine.getDelegatedTask();
/* 212 */               while (runnable != null) {
/* 213 */                 runnable.run();
/* 214 */                 runnable = AsyncChannelWrapperSecure.this.sslEngine.getDelegatedTask();
/*     */               }
/*     */             }
/*     */             
/* 218 */             AsyncChannelWrapperSecure.this.socketWriteBuffer.flip();
/*     */             
/*     */ 
/* 221 */             int toWrite = r.bytesProduced();
/* 222 */             while (toWrite > 0) {
/* 223 */               Future<Integer> f = AsyncChannelWrapperSecure.this.socketChannel.write(AsyncChannelWrapperSecure.this.socketWriteBuffer);
/*     */               
/* 225 */               Integer socketWrite = (Integer)f.get();
/* 226 */               toWrite -= socketWrite.intValue();
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 232 */         if (AsyncChannelWrapperSecure.this.writing.compareAndSet(true, false)) {
/* 233 */           this.future.complete(Long.valueOf(written));
/*     */         } else {
/* 235 */           this.future.fail(new IllegalStateException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.wrongStateWrite")));
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 239 */         this.future.fail(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private class ReadTask implements Runnable
/*     */   {
/*     */     private final ByteBuffer dest;
/*     */     private final AsyncChannelWrapperSecure.WrapperFuture<Integer, ?> future;
/*     */     
/*     */     public ReadTask(AsyncChannelWrapperSecure.WrapperFuture<Integer, ?> dest)
/*     */     {
/* 251 */       this.dest = dest;
/* 252 */       this.future = future;
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/* 257 */       int read = 0;
/*     */       
/* 259 */       boolean forceRead = false;
/*     */       try
/*     */       {
/* 262 */         while (read == 0) {
/* 263 */           AsyncChannelWrapperSecure.this.socketReadBuffer.compact();
/*     */           
/* 265 */           if (forceRead) {
/* 266 */             forceRead = false;
/* 267 */             Future<Integer> f = AsyncChannelWrapperSecure.this.socketChannel.read(AsyncChannelWrapperSecure.this.socketReadBuffer);
/* 268 */             Integer socketRead = (Integer)f.get();
/* 269 */             if (socketRead.intValue() == -1) {
/* 270 */               throw new EOFException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.eof"));
/*     */             }
/*     */           }
/*     */           
/*     */ 
/* 275 */           AsyncChannelWrapperSecure.this.socketReadBuffer.flip();
/*     */           
/* 277 */           if (AsyncChannelWrapperSecure.this.socketReadBuffer.hasRemaining())
/*     */           {
/* 279 */             SSLEngineResult r = AsyncChannelWrapperSecure.this.sslEngine.unwrap(AsyncChannelWrapperSecure.this.socketReadBuffer, this.dest);
/*     */             
/* 281 */             read += r.bytesProduced();
/* 282 */             SSLEngineResult.Status s = r.getStatus();
/*     */             
/* 284 */             if (s != SSLEngineResult.Status.OK)
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/* 289 */               if (s == SSLEngineResult.Status.BUFFER_UNDERFLOW)
/*     */               {
/* 291 */                 if (read == 0)
/*     */                 {
/*     */ 
/* 294 */                   forceRead = true;
/*     */                 }
/*     */                 
/*     */               }
/* 298 */               else if (s == SSLEngineResult.Status.BUFFER_OVERFLOW)
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 304 */                 if (AsyncChannelWrapperSecure.this.reading.compareAndSet(true, false)) {
/* 305 */                   throw new ReadBufferOverflowException(AsyncChannelWrapperSecure.this.sslEngine.getSession().getApplicationBufferSize());
/*     */                 }
/*     */                 
/* 308 */                 this.future.fail(new IllegalStateException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.wrongStateRead")));
/*     */ 
/*     */               }
/*     */               else
/*     */               {
/* 313 */                 throw new IllegalStateException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.statusUnwrap"));
/*     */               }
/*     */             }
/*     */             
/*     */ 
/* 318 */             if (r.getHandshakeStatus() == SSLEngineResult.HandshakeStatus.NEED_TASK) {
/* 319 */               Runnable runnable = AsyncChannelWrapperSecure.this.sslEngine.getDelegatedTask();
/* 320 */               while (runnable != null) {
/* 321 */                 runnable.run();
/* 322 */                 runnable = AsyncChannelWrapperSecure.this.sslEngine.getDelegatedTask();
/*     */               }
/*     */             }
/*     */           } else {
/* 326 */             forceRead = true;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 331 */         if (AsyncChannelWrapperSecure.this.reading.compareAndSet(true, false)) {
/* 332 */           this.future.complete(Integer.valueOf(read));
/*     */         } else {
/* 334 */           this.future.fail(new IllegalStateException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.wrongStateRead")));
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 338 */         this.future.fail(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private class WebSocketSslHandshakeThread
/*     */     extends Thread
/*     */   {
/*     */     private final AsyncChannelWrapperSecure.WrapperFuture<Void, Void> hFuture;
/*     */     private SSLEngineResult.HandshakeStatus handshakeStatus;
/*     */     private SSLEngineResult.Status resultStatus;
/*     */     
/*     */     public WebSocketSslHandshakeThread()
/*     */     {
/* 352 */       this.hFuture = hFuture;
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/*     */       try {
/* 358 */         AsyncChannelWrapperSecure.this.sslEngine.beginHandshake();
/*     */         
/* 360 */         AsyncChannelWrapperSecure.this.socketReadBuffer.position(AsyncChannelWrapperSecure.this.socketReadBuffer.limit());
/*     */         
/* 362 */         this.handshakeStatus = AsyncChannelWrapperSecure.this.sslEngine.getHandshakeStatus();
/* 363 */         this.resultStatus = SSLEngineResult.Status.OK;
/*     */         
/* 365 */         boolean handshaking = true;
/*     */         
/* 367 */         while (handshaking) {
/* 368 */           switch (AsyncChannelWrapperSecure.1.$SwitchMap$javax$net$ssl$SSLEngineResult$HandshakeStatus[this.handshakeStatus.ordinal()]) {
/*     */           case 1: 
/* 370 */             AsyncChannelWrapperSecure.this.socketWriteBuffer.clear();
/* 371 */             SSLEngineResult r = AsyncChannelWrapperSecure.this.sslEngine.wrap(AsyncChannelWrapperSecure.DUMMY, AsyncChannelWrapperSecure.this.socketWriteBuffer);
/*     */             
/* 373 */             checkResult(r, true);
/* 374 */             AsyncChannelWrapperSecure.this.socketWriteBuffer.flip();
/* 375 */             Future<Integer> fWrite = AsyncChannelWrapperSecure.this.socketChannel.write(AsyncChannelWrapperSecure.this.socketWriteBuffer);
/*     */             
/* 377 */             fWrite.get();
/* 378 */             break;
/*     */           
/*     */           case 2: 
/* 381 */             AsyncChannelWrapperSecure.this.socketReadBuffer.compact();
/* 382 */             if ((AsyncChannelWrapperSecure.this.socketReadBuffer.position() == 0) || (this.resultStatus == SSLEngineResult.Status.BUFFER_UNDERFLOW))
/*     */             {
/* 384 */               Future<Integer> fRead = AsyncChannelWrapperSecure.this.socketChannel.read(AsyncChannelWrapperSecure.this.socketReadBuffer);
/*     */               
/* 386 */               fRead.get();
/*     */             }
/* 388 */             AsyncChannelWrapperSecure.this.socketReadBuffer.flip();
/* 389 */             SSLEngineResult r = AsyncChannelWrapperSecure.this.sslEngine.unwrap(AsyncChannelWrapperSecure.this.socketReadBuffer, AsyncChannelWrapperSecure.DUMMY);
/*     */             
/* 391 */             checkResult(r, false);
/* 392 */             break;
/*     */           
/*     */           case 3: 
/* 395 */             Runnable r = null;
/* 396 */             while ((r = AsyncChannelWrapperSecure.this.sslEngine.getDelegatedTask()) != null) {
/* 397 */               r.run();
/*     */             }
/* 399 */             this.handshakeStatus = AsyncChannelWrapperSecure.this.sslEngine.getHandshakeStatus();
/* 400 */             break;
/*     */           
/*     */           case 4: 
/* 403 */             handshaking = false;
/* 404 */             break;
/*     */           
/*     */           case 5: 
/* 407 */             throw new SSLException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.notHandshaking"));
/*     */           }
/*     */           
/*     */         }
/*     */       }
/*     */       catch (SSLException|InterruptedException|ExecutionException e)
/*     */       {
/* 414 */         this.hFuture.fail(e);
/*     */       }
/*     */       
/* 417 */       this.hFuture.complete(null);
/*     */     }
/*     */     
/*     */     private void checkResult(SSLEngineResult result, boolean wrap)
/*     */       throws SSLException
/*     */     {
/* 423 */       this.handshakeStatus = result.getHandshakeStatus();
/* 424 */       this.resultStatus = result.getStatus();
/*     */       
/* 426 */       if ((this.resultStatus != SSLEngineResult.Status.OK) && ((wrap) || (this.resultStatus != SSLEngineResult.Status.BUFFER_UNDERFLOW)))
/*     */       {
/* 428 */         throw new SSLException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.check.notOk", new Object[] { this.resultStatus }));
/*     */       }
/*     */       
/* 431 */       if ((wrap) && (result.bytesConsumed() != 0)) {
/* 432 */         throw new SSLException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.check.wrap"));
/*     */       }
/* 434 */       if ((!wrap) && (result.bytesProduced() != 0)) {
/* 435 */         throw new SSLException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.check.unwrap"));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class WrapperFuture<T, A>
/*     */     implements Future<T>
/*     */   {
/*     */     private final CompletionHandler<T, A> handler;
/*     */     private final A attachment;
/* 446 */     private volatile T result = null;
/* 447 */     private volatile Throwable throwable = null;
/* 448 */     private CountDownLatch completionLatch = new CountDownLatch(1);
/*     */     
/*     */     public WrapperFuture() {
/* 451 */       this(null, null);
/*     */     }
/*     */     
/*     */     public WrapperFuture(CompletionHandler<T, A> handler, A attachment) {
/* 455 */       this.handler = handler;
/* 456 */       this.attachment = attachment;
/*     */     }
/*     */     
/*     */     public void complete(T result) {
/* 460 */       this.result = result;
/* 461 */       this.completionLatch.countDown();
/* 462 */       if (this.handler != null) {
/* 463 */         this.handler.completed(result, this.attachment);
/*     */       }
/*     */     }
/*     */     
/*     */     public void fail(Throwable t) {
/* 468 */       this.throwable = t;
/* 469 */       this.completionLatch.countDown();
/* 470 */       if (this.handler != null) {
/* 471 */         this.handler.failed(this.throwable, this.attachment);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public final boolean cancel(boolean mayInterruptIfRunning)
/*     */     {
/* 478 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */     public final boolean isCancelled()
/*     */     {
/* 484 */       return false;
/*     */     }
/*     */     
/*     */     public final boolean isDone()
/*     */     {
/* 489 */       return this.completionLatch.getCount() > 0L;
/*     */     }
/*     */     
/*     */     public T get() throws InterruptedException, ExecutionException
/*     */     {
/* 494 */       this.completionLatch.await();
/* 495 */       if (this.throwable != null) {
/* 496 */         throw new ExecutionException(this.throwable);
/*     */       }
/* 498 */       return (T)this.result;
/*     */     }
/*     */     
/*     */ 
/*     */     public T get(long timeout, TimeUnit unit)
/*     */       throws InterruptedException, ExecutionException, TimeoutException
/*     */     {
/* 505 */       boolean latchResult = this.completionLatch.await(timeout, unit);
/* 506 */       if (!latchResult) {
/* 507 */         throw new TimeoutException();
/*     */       }
/* 509 */       if (this.throwable != null) {
/* 510 */         throw new ExecutionException(this.throwable);
/*     */       }
/* 512 */       return (T)this.result;
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class LongToIntegerFuture implements Future<Integer>
/*     */   {
/*     */     private final Future<Long> wrapped;
/*     */     
/*     */     public LongToIntegerFuture(Future<Long> wrapped) {
/* 521 */       this.wrapped = wrapped;
/*     */     }
/*     */     
/*     */     public boolean cancel(boolean mayInterruptIfRunning)
/*     */     {
/* 526 */       return this.wrapped.cancel(mayInterruptIfRunning);
/*     */     }
/*     */     
/*     */     public boolean isCancelled()
/*     */     {
/* 531 */       return this.wrapped.isCancelled();
/*     */     }
/*     */     
/*     */     public boolean isDone()
/*     */     {
/* 536 */       return this.wrapped.isDone();
/*     */     }
/*     */     
/*     */     public Integer get() throws InterruptedException, ExecutionException
/*     */     {
/* 541 */       Long result = (Long)this.wrapped.get();
/* 542 */       if (result.longValue() > 2147483647L) {
/* 543 */         throw new ExecutionException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.tooBig", new Object[] { result }), null);
/*     */       }
/*     */       
/* 546 */       return Integer.valueOf(result.intValue());
/*     */     }
/*     */     
/*     */ 
/*     */     public Integer get(long timeout, TimeUnit unit)
/*     */       throws InterruptedException, ExecutionException, TimeoutException
/*     */     {
/* 553 */       Long result = (Long)this.wrapped.get(timeout, unit);
/* 554 */       if (result.longValue() > 2147483647L) {
/* 555 */         throw new ExecutionException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.tooBig", new Object[] { result }), null);
/*     */       }
/*     */       
/* 558 */       return Integer.valueOf(result.intValue());
/*     */     }
/*     */   }
/*     */   
/*     */   private static class SecureIOThreadFactory
/*     */     implements ThreadFactory
/*     */   {
/* 565 */     private AtomicInteger count = new AtomicInteger(0);
/*     */     
/*     */     public Thread newThread(Runnable r)
/*     */     {
/* 569 */       Thread t = new Thread(r);
/* 570 */       t.setName("WebSocketClient-SecureIO-" + this.count.incrementAndGet());
/*     */       
/*     */ 
/* 573 */       t.setDaemon(true);
/* 574 */       return t;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-websocket-8.5.4.jar!\org\apache\tomcat\websocket\AsyncChannelWrapperSecure.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */