/*     */ package org.apache.tomcat.websocket;
/*     */ 
/*     */ import java.nio.channels.AsynchronousChannelGroup;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsyncChannelGroupUtil
/*     */ {
/*  39 */   private static final StringManager sm = StringManager.getManager(AsyncChannelGroupUtil.class);
/*     */   
/*     */ 
/*  42 */   private static AsynchronousChannelGroup group = null;
/*  43 */   private static int usageCount = 0;
/*  44 */   private static final Object lock = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AsynchronousChannelGroup register()
/*     */   {
/*  53 */     synchronized (lock) {
/*  54 */       if (usageCount == 0) {
/*  55 */         group = createAsynchronousChannelGroup();
/*     */       }
/*  57 */       usageCount += 1;
/*  58 */       return group;
/*     */     }
/*     */   }
/*     */   
/*     */   public static void unregister()
/*     */   {
/*  64 */     synchronized (lock) {
/*  65 */       usageCount -= 1;
/*  66 */       if (usageCount == 0) {
/*  67 */         group.shutdown();
/*  68 */         group = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private static AsynchronousChannelGroup createAsynchronousChannelGroup()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: invokestatic 7	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   3: invokevirtual 8	java/lang/Thread:getContextClassLoader	()Ljava/lang/ClassLoader;
/*     */     //   6: astore_0
/*     */     //   7: invokestatic 7	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   10: ldc_w 9
/*     */     //   13: invokevirtual 10	java/lang/Class:getClassLoader	()Ljava/lang/ClassLoader;
/*     */     //   16: invokevirtual 11	java/lang/Thread:setContextClassLoader	(Ljava/lang/ClassLoader;)V
/*     */     //   19: invokestatic 12	java/lang/Runtime:getRuntime	()Ljava/lang/Runtime;
/*     */     //   22: invokevirtual 13	java/lang/Runtime:availableProcessors	()I
/*     */     //   25: istore_1
/*     */     //   26: new 14	org/apache/tomcat/util/threads/ThreadPoolExecutor
/*     */     //   29: dup
/*     */     //   30: iconst_0
/*     */     //   31: ldc 15
/*     */     //   33: ldc2_w 16
/*     */     //   36: getstatic 18	java/util/concurrent/TimeUnit:MILLISECONDS	Ljava/util/concurrent/TimeUnit;
/*     */     //   39: new 19	java/util/concurrent/SynchronousQueue
/*     */     //   42: dup
/*     */     //   43: invokespecial 20	java/util/concurrent/SynchronousQueue:<init>	()V
/*     */     //   46: new 9	org/apache/tomcat/websocket/AsyncChannelGroupUtil$AsyncIOThreadFactory
/*     */     //   49: dup
/*     */     //   50: aconst_null
/*     */     //   51: invokespecial 21	org/apache/tomcat/websocket/AsyncChannelGroupUtil$AsyncIOThreadFactory:<init>	(Lorg/apache/tomcat/websocket/AsyncChannelGroupUtil$1;)V
/*     */     //   54: invokespecial 22	org/apache/tomcat/util/threads/ThreadPoolExecutor:<init>	(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V
/*     */     //   57: astore_2
/*     */     //   58: aload_2
/*     */     //   59: iload_1
/*     */     //   60: invokestatic 23	java/nio/channels/AsynchronousChannelGroup:withCachedThreadPool	(Ljava/util/concurrent/ExecutorService;I)Ljava/nio/channels/AsynchronousChannelGroup;
/*     */     //   63: astore_3
/*     */     //   64: invokestatic 7	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   67: aload_0
/*     */     //   68: invokevirtual 11	java/lang/Thread:setContextClassLoader	(Ljava/lang/ClassLoader;)V
/*     */     //   71: aload_3
/*     */     //   72: areturn
/*     */     //   73: astore_3
/*     */     //   74: new 25	java/lang/IllegalStateException
/*     */     //   77: dup
/*     */     //   78: getstatic 26	org/apache/tomcat/websocket/AsyncChannelGroupUtil:sm	Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   81: ldc 27
/*     */     //   83: invokevirtual 28	org/apache/tomcat/util/res/StringManager:getString	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   86: invokespecial 29	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
/*     */     //   89: athrow
/*     */     //   90: astore 4
/*     */     //   92: invokestatic 7	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   95: aload_0
/*     */     //   96: invokevirtual 11	java/lang/Thread:setContextClassLoader	(Ljava/lang/ClassLoader;)V
/*     */     //   99: aload 4
/*     */     //   101: athrow
/*     */     // Line number table:
/*     */     //   Java source line #77	-> byte code offset #0
/*     */     //   Java source line #80	-> byte code offset #7
/*     */     //   Java source line #85	-> byte code offset #19
/*     */     //   Java source line #86	-> byte code offset #26
/*     */     //   Java source line #94	-> byte code offset #58
/*     */     //   Java source line #101	-> byte code offset #64
/*     */     //   Java source line #96	-> byte code offset #73
/*     */     //   Java source line #98	-> byte code offset #74
/*     */     //   Java source line #101	-> byte code offset #90
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   6	90	0	original	ClassLoader
/*     */     //   25	35	1	initialSize	int
/*     */     //   57	2	2	executorService	java.util.concurrent.ExecutorService
/*     */     //   63	9	3	localAsynchronousChannelGroup	AsynchronousChannelGroup
/*     */     //   73	2	3	e	java.io.IOException
/*     */     //   90	10	4	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   58	64	73	java/io/IOException
/*     */     //   7	64	90	finally
/*     */     //   73	92	90	finally
/*     */   }
/*     */   
/*     */   private static class AsyncIOThreadFactory
/*     */     implements ThreadFactory
/*     */   {
/*     */     public Thread newThread(Runnable r)
/*     */     {
/* 122 */       return (Thread)AccessController.doPrivileged(new NewThreadPrivilegedAction(r));
/*     */     }
/*     */     
/*     */     static {}
/*     */     
/*     */     private static class NewThreadPrivilegedAction implements PrivilegedAction<Thread>
/*     */     {
/* 129 */       private static AtomicInteger count = new AtomicInteger(0);
/*     */       private final Runnable r;
/*     */       
/*     */       public NewThreadPrivilegedAction(Runnable r)
/*     */       {
/* 134 */         this.r = r;
/*     */       }
/*     */       
/*     */       public Thread run()
/*     */       {
/* 139 */         Thread t = new Thread(this.r);
/* 140 */         t.setName("WebSocketClient-AsyncIO-" + count.incrementAndGet());
/* 141 */         t.setContextClassLoader(getClass().getClassLoader());
/* 142 */         t.setDaemon(true);
/* 143 */         return t;
/*     */       }
/*     */       
/*     */       private static void load() {}
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-websocket-8.5.4.jar!\org\apache\tomcat\websocket\AsyncChannelGroupUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */