package org.apache.tomcat.websocket.server;

interface package-info {}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-websocket-8.5.4.jar!\org\apache\tomcat\websocket\server\package-info.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */