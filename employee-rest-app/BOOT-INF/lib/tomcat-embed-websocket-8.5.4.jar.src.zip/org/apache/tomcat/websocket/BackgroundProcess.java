package org.apache.tomcat.websocket;

public abstract interface BackgroundProcess
{
  public abstract void backgroundProcess();
  
  public abstract void setProcessPeriod(int paramInt);
  
  public abstract int getProcessPeriod();
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-websocket-8.5.4.jar!\org\apache\tomcat\websocket\BackgroundProcess.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */