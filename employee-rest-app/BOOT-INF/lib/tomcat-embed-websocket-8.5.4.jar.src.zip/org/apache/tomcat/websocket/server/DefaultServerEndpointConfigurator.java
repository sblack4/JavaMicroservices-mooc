/*    */ package org.apache.tomcat.websocket.server;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import javax.websocket.Extension;
/*    */ import javax.websocket.HandshakeResponse;
/*    */ import javax.websocket.server.HandshakeRequest;
/*    */ import javax.websocket.server.ServerEndpointConfig;
/*    */ import javax.websocket.server.ServerEndpointConfig.Configurator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultServerEndpointConfigurator
/*    */   extends ServerEndpointConfig.Configurator
/*    */ {
/*    */   public <T> T getEndpointInstance(Class<T> clazz)
/*    */     throws InstantiationException
/*    */   {
/*    */     try
/*    */     {
/* 36 */       return (T)clazz.newInstance();
/*    */     } catch (IllegalAccessException e) {
/* 38 */       InstantiationException ie = new InstantiationException();
/* 39 */       ie.initCause(e);
/* 40 */       throw ie;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getNegotiatedSubprotocol(List<String> supported, List<String> requested)
/*    */   {
/* 49 */     for (String request : requested) {
/* 50 */       if (supported.contains(request)) {
/* 51 */         return request;
/*    */       }
/*    */     }
/* 54 */     return "";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public List<Extension> getNegotiatedExtensions(List<Extension> installed, List<Extension> requested)
/*    */   {
/* 61 */     Set<String> installedNames = new HashSet();
/* 62 */     for (Extension e : installed) {
/* 63 */       installedNames.add(e.getName());
/*    */     }
/* 65 */     List<Extension> result = new ArrayList();
/* 66 */     for (Extension request : requested) {
/* 67 */       if (installedNames.contains(request.getName())) {
/* 68 */         result.add(request);
/*    */       }
/*    */     }
/* 71 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean checkOrigin(String originHeaderValue)
/*    */   {
/* 77 */     return true;
/*    */   }
/*    */   
/*    */   public void modifyHandshake(ServerEndpointConfig sec, HandshakeRequest request, HandshakeResponse response) {}
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-websocket-8.5.4.jar!\org\apache\tomcat\websocket\server\DefaultServerEndpointConfigurator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */