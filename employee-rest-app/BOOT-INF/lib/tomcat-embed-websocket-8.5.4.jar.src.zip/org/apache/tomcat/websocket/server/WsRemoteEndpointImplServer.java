/*     */ package org.apache.tomcat.websocket.server;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.net.SocketTimeoutException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.concurrent.Executor;
/*     */ import javax.websocket.SendHandler;
/*     */ import javax.websocket.SendResult;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.net.AbstractEndpoint;
/*     */ import org.apache.tomcat.util.net.SocketWrapperBase;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.websocket.Transformation;
/*     */ import org.apache.tomcat.websocket.WsRemoteEndpointImplBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WsRemoteEndpointImplServer
/*     */   extends WsRemoteEndpointImplBase
/*     */ {
/*  42 */   private static final StringManager sm = StringManager.getManager(WsRemoteEndpointImplServer.class);
/*     */   
/*  44 */   private static final Log log = LogFactory.getLog(WsRemoteEndpointImplServer.class);
/*     */   
/*     */   private final SocketWrapperBase<?> socketWrapper;
/*     */   private final WsWriteTimeout wsWriteTimeout;
/*  48 */   private volatile SendHandler handler = null;
/*  49 */   private volatile ByteBuffer[] buffers = null;
/*     */   
/*  51 */   private volatile long timeoutExpiry = -1L;
/*     */   private volatile boolean close;
/*     */   
/*     */   public WsRemoteEndpointImplServer(SocketWrapperBase<?> socketWrapper, WsServerContainer serverContainer)
/*     */   {
/*  56 */     this.socketWrapper = socketWrapper;
/*  57 */     this.wsWriteTimeout = serverContainer.getTimeout();
/*     */   }
/*     */   
/*     */ 
/*     */   protected final boolean isMasked()
/*     */   {
/*  63 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void doWrite(SendHandler handler, long blockingWriteTimeoutExpiry, ByteBuffer... buffers)
/*     */   {
/*  70 */     if (blockingWriteTimeoutExpiry == -1L) {
/*  71 */       this.handler = handler;
/*  72 */       this.buffers = buffers;
/*     */       
/*     */ 
/*  75 */       onWritePossible(true);
/*     */     }
/*     */     else {
/*  78 */       for (ByteBuffer buffer : buffers) {
/*  79 */         long timeout = blockingWriteTimeoutExpiry - System.currentTimeMillis();
/*  80 */         if (timeout < 0L) {
/*  81 */           SendResult sr = new SendResult(new SocketTimeoutException());
/*  82 */           handler.onResult(sr);
/*  83 */           return;
/*     */         }
/*  85 */         this.socketWrapper.setWriteTimeout(timeout);
/*     */         try {
/*  87 */           this.socketWrapper.write(true, buffer.array(), buffer.arrayOffset(), buffer.limit());
/*     */           
/*  89 */           buffer.position(buffer.limit());
/*  90 */           timeout = blockingWriteTimeoutExpiry - System.currentTimeMillis();
/*  91 */           if (timeout < 0L) {
/*  92 */             SendResult sr = new SendResult(new SocketTimeoutException());
/*  93 */             handler.onResult(sr);
/*  94 */             return;
/*     */           }
/*  96 */           this.socketWrapper.setWriteTimeout(timeout);
/*  97 */           this.socketWrapper.flush(true);
/*  98 */           handler.onResult(SENDRESULT_OK);
/*     */         } catch (IOException e) {
/* 100 */           SendResult sr = new SendResult(e);
/* 101 */           handler.onResult(sr);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void onWritePossible(boolean useDispatch)
/*     */   {
/* 109 */     ByteBuffer[] buffers = this.buffers;
/* 110 */     if (buffers == null)
/*     */     {
/*     */ 
/* 113 */       return;
/*     */     }
/* 115 */     boolean complete = false;
/*     */     try {
/* 117 */       this.socketWrapper.flush(false);
/*     */       
/* 119 */       while (this.socketWrapper.isReadyForWrite()) {
/* 120 */         complete = true;
/* 121 */         for (ByteBuffer buffer : buffers) {
/* 122 */           if (buffer.hasRemaining()) {
/* 123 */             complete = false;
/* 124 */             this.socketWrapper.write(false, buffer.array(), buffer.arrayOffset(), buffer.limit());
/*     */             
/* 126 */             buffer.position(buffer.limit());
/* 127 */             break;
/*     */           }
/*     */         }
/* 130 */         if (complete) {
/* 131 */           this.socketWrapper.flush(false);
/* 132 */           complete = this.socketWrapper.isReadyForWrite();
/* 133 */           if (complete) {
/* 134 */             this.wsWriteTimeout.unregister(this);
/* 135 */             clearHandler(null, useDispatch);
/* 136 */             if (this.close) {
/* 137 */               close();
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (IOException|IllegalStateException e) {
/* 144 */       this.wsWriteTimeout.unregister(this);
/* 145 */       clearHandler(e, useDispatch);
/* 146 */       close();
/*     */     }
/*     */     
/* 149 */     if (!complete)
/*     */     {
/* 151 */       long timeout = getSendTimeout();
/* 152 */       if (timeout > 0L)
/*     */       {
/* 154 */         this.timeoutExpiry = (timeout + System.currentTimeMillis());
/* 155 */         this.wsWriteTimeout.register(this);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void doClose()
/*     */   {
/* 163 */     if (this.handler != null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 168 */       clearHandler(new EOFException(), true);
/*     */     }
/*     */     try {
/* 171 */       this.socketWrapper.close();
/*     */     } catch (IOException e) {
/* 173 */       if (log.isInfoEnabled()) {
/* 174 */         log.info(sm.getString("wsRemoteEndpointServer.closeFailed"), e);
/*     */       }
/*     */     }
/* 177 */     this.wsWriteTimeout.unregister(this);
/*     */   }
/*     */   
/*     */   protected long getTimeoutExpiry()
/*     */   {
/* 182 */     return this.timeoutExpiry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void onTimeout(boolean useDispatch)
/*     */   {
/* 194 */     if (this.handler != null) {
/* 195 */       clearHandler(new SocketTimeoutException(), useDispatch);
/*     */     }
/* 197 */     close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void setTransformation(Transformation transformation)
/*     */   {
/* 204 */     super.setTransformation(transformation);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void clearHandler(Throwable t, boolean useDispatch)
/*     */   {
/* 223 */     SendHandler sh = this.handler;
/* 224 */     this.handler = null;
/* 225 */     this.buffers = null;
/* 226 */     if (sh != null) {
/* 227 */       if (useDispatch) {
/* 228 */         OnResultRunnable r = new OnResultRunnable(sh, t, null);
/* 229 */         AbstractEndpoint<?> endpoint = this.socketWrapper.getEndpoint();
/* 230 */         Executor containerExecutor = endpoint.getExecutor();
/* 231 */         if ((endpoint.isRunning()) && (containerExecutor != null)) {
/* 232 */           containerExecutor.execute(r);
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/* 241 */           r.run();
/*     */         }
/*     */       }
/* 244 */       else if (t == null) {
/* 245 */         sh.onResult(new SendResult());
/*     */       } else {
/* 247 */         sh.onResult(new SendResult(t));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static class OnResultRunnable
/*     */     implements Runnable
/*     */   {
/*     */     private final SendHandler sh;
/*     */     private final Throwable t;
/*     */     
/*     */     private OnResultRunnable(SendHandler sh, Throwable t)
/*     */     {
/* 260 */       this.sh = sh;
/* 261 */       this.t = t;
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/* 266 */       if (this.t == null) {
/* 267 */         this.sh.onResult(new SendResult());
/*     */       } else {
/* 269 */         this.sh.onResult(new SendResult(this.t));
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-websocket-8.5.4.jar!\org\apache\tomcat\websocket\server\WsRemoteEndpointImplServer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */