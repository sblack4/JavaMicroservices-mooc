/*     */ package org.apache.tomcat.websocket;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.CompletionHandler;
/*     */ import javax.websocket.CloseReason;
/*     */ import javax.websocket.CloseReason.CloseCodes;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WsFrameClient
/*     */   extends WsFrameBase
/*     */ {
/*  33 */   private final Log log = LogFactory.getLog(WsFrameClient.class);
/*  34 */   private static final StringManager sm = StringManager.getManager(WsFrameClient.class);
/*     */   
/*     */   private final AsyncChannelWrapper channel;
/*     */   
/*     */   private final CompletionHandler<Integer, Void> handler;
/*     */   
/*     */   private volatile ByteBuffer response;
/*     */   
/*     */   public WsFrameClient(ByteBuffer response, AsyncChannelWrapper channel, WsSession wsSession, Transformation transformation)
/*     */   {
/*  44 */     super(wsSession, transformation);
/*  45 */     this.response = response;
/*  46 */     this.channel = channel;
/*  47 */     this.handler = new WsFrameClientCompletionHandler(null);
/*     */   }
/*     */   
/*     */   void startInputProcessing()
/*     */   {
/*     */     try {
/*  53 */       processSocketRead();
/*     */     } catch (IOException e) {
/*  55 */       close(e);
/*     */     }
/*     */   }
/*     */   
/*     */   private void processSocketRead()
/*     */     throws IOException
/*     */   {
/*  62 */     while (this.response.hasRemaining()) {
/*  63 */       int remaining = this.response.remaining();
/*     */       
/*  65 */       int toCopy = Math.min(remaining, this.inputBuffer.length - this.writePos);
/*     */       
/*     */ 
/*     */ 
/*  69 */       this.response.get(this.inputBuffer, this.writePos, toCopy);
/*  70 */       this.writePos += toCopy;
/*     */       
/*     */ 
/*  73 */       processInputBuffer();
/*     */     }
/*  75 */     this.response.clear();
/*     */     
/*     */ 
/*  78 */     if (isOpen()) {
/*  79 */       this.channel.read(this.response, null, this.handler);
/*     */     }
/*     */   }
/*     */   
/*     */   private final void close(Throwable t) {
/*     */     CloseReason cr;
/*     */     CloseReason cr;
/*  86 */     if ((t instanceof WsIOException)) {
/*  87 */       cr = ((WsIOException)t).getCloseReason();
/*     */     } else {
/*  89 */       cr = new CloseReason(CloseReason.CloseCodes.CLOSED_ABNORMALLY, t.getMessage());
/*     */     }
/*     */     
/*     */     try
/*     */     {
/*  94 */       this.wsSession.close(cr);
/*     */     }
/*     */     catch (IOException localIOException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isMasked()
/*     */   {
/* 104 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   protected Log getLog()
/*     */   {
/* 110 */     return this.log;
/*     */   }
/*     */   
/*     */   private class WsFrameClientCompletionHandler implements CompletionHandler<Integer, Void>
/*     */   {
/*     */     private WsFrameClientCompletionHandler() {}
/*     */     
/*     */     public void completed(Integer result, Void attachment)
/*     */     {
/* 119 */       if (result.intValue() == -1)
/*     */       {
/*     */ 
/* 122 */         if (WsFrameClient.this.isOpen())
/*     */         {
/* 124 */           WsFrameClient.this.close(new EOFException());
/*     */         }
/*     */         
/* 127 */         return;
/*     */       }
/* 129 */       WsFrameClient.this.response.flip();
/*     */       try {
/* 131 */         WsFrameClient.this.processSocketRead();
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/*     */ 
/* 138 */         if (WsFrameClient.this.isOpen()) {
/* 139 */           WsFrameClient.this.log.debug(WsFrameClient.sm.getString("wsFrameClient.ioe"), e);
/* 140 */           WsFrameClient.this.close(e);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     public void failed(Throwable exc, Void attachment)
/*     */     {
/* 147 */       if ((exc instanceof ReadBufferOverflowException))
/*     */       {
/* 149 */         WsFrameClient.this.response = ByteBuffer.allocate(((ReadBufferOverflowException)exc).getMinBufferSize());
/*     */         
/* 151 */         WsFrameClient.this.response.flip();
/*     */         try {
/* 153 */           WsFrameClient.this.processSocketRead();
/*     */         } catch (IOException e) {
/* 155 */           WsFrameClient.this.close(e);
/*     */         }
/*     */       } else {
/* 158 */         WsFrameClient.this.close(exc);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-websocket-8.5.4.jar!\org\apache\tomcat\websocket\WsFrameClient.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */