/*     */ package org.apache.tomcat.websocket;
/*     */ 
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import javax.websocket.SendHandler;
/*     */ import javax.websocket.SendResult;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FutureToSendHandler
/*     */   implements Future<Void>, SendHandler
/*     */ {
/*  33 */   private final CountDownLatch latch = new CountDownLatch(1);
/*     */   private final WsSession wsSession;
/*  35 */   private volatile SendResult result = null;
/*     */   
/*     */   public FutureToSendHandler(WsSession wsSession) {
/*  38 */     this.wsSession = wsSession;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onResult(SendResult result)
/*     */   {
/*  47 */     this.result = result;
/*  48 */     this.latch.countDown();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean cancel(boolean mayInterruptIfRunning)
/*     */   {
/*  57 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isCancelled()
/*     */   {
/*  63 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isDone()
/*     */   {
/*  68 */     return this.latch.getCount() == 0L;
/*     */   }
/*     */   
/*     */   public Void get() throws InterruptedException, ExecutionException
/*     */   {
/*     */     try
/*     */     {
/*  75 */       this.wsSession.registerFuture(this);
/*  76 */       this.latch.await();
/*     */     } finally {
/*  78 */       this.wsSession.unregisterFuture(this);
/*     */     }
/*  80 */     if (this.result.getException() != null) {
/*  81 */       throw new ExecutionException(this.result.getException());
/*     */     }
/*  83 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public Void get(long timeout, TimeUnit unit)
/*     */     throws InterruptedException, ExecutionException, TimeoutException
/*     */   {
/*  90 */     boolean retval = false;
/*     */     try {
/*  92 */       this.wsSession.registerFuture(this);
/*  93 */       retval = this.latch.await(timeout, unit);
/*     */     } finally {
/*  95 */       this.wsSession.unregisterFuture(this);
/*     */     }
/*     */     
/*  98 */     if (!retval) {
/*  99 */       throw new TimeoutException();
/*     */     }
/* 101 */     if (this.result.getException() != null) {
/* 102 */       throw new ExecutionException(this.result.getException());
/*     */     }
/* 104 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-websocket-8.5.4.jar!\org\apache\tomcat\websocket\FutureToSendHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */