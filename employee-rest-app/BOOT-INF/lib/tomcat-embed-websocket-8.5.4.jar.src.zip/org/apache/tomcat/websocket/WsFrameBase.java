/*     */ package org.apache.tomcat.websocket;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.charset.CharsetDecoder;
/*     */ import java.nio.charset.CoderResult;
/*     */ import java.nio.charset.CodingErrorAction;
/*     */ import java.util.List;
/*     */ import javax.websocket.CloseReason;
/*     */ import javax.websocket.CloseReason.CloseCodes;
/*     */ import javax.websocket.Endpoint;
/*     */ import javax.websocket.Extension;
/*     */ import javax.websocket.MessageHandler;
/*     */ import javax.websocket.MessageHandler.Partial;
/*     */ import javax.websocket.MessageHandler.Whole;
/*     */ import javax.websocket.PongMessage;
/*     */ import javax.websocket.RemoteEndpoint.Basic;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.buf.Utf8Decoder;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class WsFrameBase
/*     */ {
/*  45 */   private static final StringManager sm = StringManager.getManager(WsFrameBase.class);
/*     */   
/*     */ 
/*     */   protected final WsSession wsSession;
/*     */   
/*     */ 
/*     */   protected final byte[] inputBuffer;
/*     */   
/*     */ 
/*     */   private final Transformation transformation;
/*     */   
/*  56 */   private final ByteBuffer controlBufferBinary = ByteBuffer.allocate(125);
/*  57 */   private final CharBuffer controlBufferText = CharBuffer.allocate(125);
/*     */   
/*     */ 
/*  60 */   private final CharsetDecoder utf8DecoderControl = new Utf8Decoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT);
/*     */   
/*     */ 
/*  63 */   private final CharsetDecoder utf8DecoderMessage = new Utf8Decoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT);
/*     */   
/*     */ 
/*  66 */   private boolean continuationExpected = false;
/*  67 */   private boolean textMessage = false;
/*     */   
/*     */   private ByteBuffer messageBufferBinary;
/*     */   
/*     */   private CharBuffer messageBufferText;
/*  72 */   private MessageHandler binaryMsgHandler = null;
/*  73 */   private MessageHandler textMsgHandler = null;
/*     */   
/*     */ 
/*  76 */   private boolean fin = false;
/*  77 */   private int rsv = 0;
/*  78 */   private byte opCode = 0;
/*  79 */   private final byte[] mask = new byte[4];
/*  80 */   private int maskIndex = 0;
/*  81 */   private long payloadLength = 0L;
/*  82 */   private volatile long payloadWritten = 0L;
/*     */   
/*     */ 
/*  85 */   private volatile State state = State.NEW_FRAME;
/*  86 */   private volatile boolean open = true;
/*  87 */   private volatile int readPos = 0;
/*  88 */   protected volatile int writePos = 0;
/*     */   
/*     */   public WsFrameBase(WsSession wsSession, Transformation transformation) {
/*  91 */     this.inputBuffer = new byte[Constants.DEFAULT_BUFFER_SIZE];
/*  92 */     this.messageBufferBinary = ByteBuffer.allocate(wsSession.getMaxBinaryMessageBufferSize());
/*     */     
/*  94 */     this.messageBufferText = CharBuffer.allocate(wsSession.getMaxTextMessageBufferSize());
/*     */     
/*  96 */     this.wsSession = wsSession;
/*     */     Transformation finalTransformation;
/*  98 */     Transformation finalTransformation; if (isMasked()) {
/*  99 */       finalTransformation = new UnmaskTransformation(null);
/*     */     } else {
/* 101 */       finalTransformation = new NoopTransformation(null);
/*     */     }
/* 103 */     if (transformation == null) {
/* 104 */       this.transformation = finalTransformation;
/*     */     } else {
/* 106 */       transformation.setNext(finalTransformation);
/* 107 */       this.transformation = transformation;
/*     */     }
/*     */   }
/*     */   
/*     */   protected void processInputBuffer() throws IOException
/*     */   {
/*     */     for (;;) {
/* 114 */       this.wsSession.updateLastActive();
/* 115 */       if (this.state == State.NEW_FRAME) {
/* 116 */         if (!processInitialHeader()) {
/*     */           break;
/*     */         }
/*     */         
/*     */ 
/* 121 */         if (!this.open) {
/* 122 */           throw new IOException(sm.getString("wsFrame.closed"));
/*     */         }
/*     */       }
/* 125 */       if ((this.state != State.PARTIAL_HEADER) || 
/* 126 */         (processRemainingHeader()))
/*     */       {
/*     */ 
/*     */ 
/* 130 */         if ((this.state == State.DATA) && 
/* 131 */           (!processData())) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean processInitialHeader()
/*     */     throws IOException
/*     */   {
/* 145 */     if (this.writePos - this.readPos < 2) {
/* 146 */       return false;
/*     */     }
/* 148 */     int b = this.inputBuffer[(this.readPos++)];
/* 149 */     this.fin = ((b & 0x80) > 0);
/* 150 */     this.rsv = ((b & 0x70) >>> 4);
/* 151 */     this.opCode = ((byte)(b & 0xF));
/* 152 */     if (!this.transformation.validateRsv(this.rsv, this.opCode)) {
/* 153 */       throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.wrongRsv", new Object[] { Integer.valueOf(this.rsv), Integer.valueOf(this.opCode) })));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 159 */     if (Util.isControl(this.opCode)) {
/* 160 */       if (!this.fin) {
/* 161 */         throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.controlFragmented")));
/*     */       }
/*     */       
/*     */ 
/* 165 */       if ((this.opCode != 9) && (this.opCode != 10) && (this.opCode != 8))
/*     */       {
/*     */ 
/* 168 */         throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.invalidOpCode", new Object[] { Integer.valueOf(this.opCode) })));
/*     */       }
/*     */       
/*     */     }
/*     */     else
/*     */     {
/* 174 */       if (this.continuationExpected) {
/* 175 */         if (!Util.isContinuation(this.opCode)) {
/* 176 */           throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.noContinuation")));
/*     */         }
/*     */       }
/*     */       else {
/*     */         try
/*     */         {
/* 182 */           if (this.opCode == 2)
/*     */           {
/* 184 */             this.textMessage = false;
/* 185 */             int size = this.wsSession.getMaxBinaryMessageBufferSize();
/* 186 */             if (size != this.messageBufferBinary.capacity()) {
/* 187 */               this.messageBufferBinary = ByteBuffer.allocate(size);
/*     */             }
/* 189 */             this.binaryMsgHandler = this.wsSession.getBinaryMessageHandler();
/* 190 */             this.textMsgHandler = null;
/* 191 */           } else if (this.opCode == 1)
/*     */           {
/* 193 */             this.textMessage = true;
/* 194 */             int size = this.wsSession.getMaxTextMessageBufferSize();
/* 195 */             if (size != this.messageBufferText.capacity()) {
/* 196 */               this.messageBufferText = CharBuffer.allocate(size);
/*     */             }
/* 198 */             this.binaryMsgHandler = null;
/* 199 */             this.textMsgHandler = this.wsSession.getTextMessageHandler();
/*     */           } else {
/* 201 */             throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.invalidOpCode", new Object[] { Integer.valueOf(this.opCode) })));
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         catch (IllegalStateException ise)
/*     */         {
/* 208 */           throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.sessionClosed")));
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 213 */       this.continuationExpected = (!this.fin);
/*     */     }
/* 215 */     b = this.inputBuffer[(this.readPos++)];
/*     */     
/* 217 */     if (((b & 0x80) == 0) && (isMasked())) {
/* 218 */       throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.notMasked")));
/*     */     }
/*     */     
/*     */ 
/* 222 */     this.payloadLength = (b & 0x7F);
/* 223 */     this.state = State.PARTIAL_HEADER;
/* 224 */     if (getLog().isDebugEnabled()) {
/* 225 */       getLog().debug(sm.getString("wsFrame.partialHeaderComplete", new Object[] { Boolean.toString(this.fin), Integer.toString(this.rsv), Integer.toString(this.opCode), Long.toString(this.payloadLength) }));
/*     */     }
/*     */     
/* 228 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   protected abstract boolean isMasked();
/*     */   
/*     */ 
/*     */   protected abstract Log getLog();
/*     */   
/*     */ 
/*     */   private boolean processRemainingHeader()
/*     */     throws IOException
/*     */   {
/*     */     int headerLength;
/*     */     int headerLength;
/* 243 */     if (isMasked()) {
/* 244 */       headerLength = 4;
/*     */     } else {
/* 246 */       headerLength = 0;
/*     */     }
/*     */     
/* 249 */     if (this.payloadLength == 126L) {
/* 250 */       headerLength += 2;
/* 251 */     } else if (this.payloadLength == 127L) {
/* 252 */       headerLength += 8;
/*     */     }
/* 254 */     if (this.writePos - this.readPos < headerLength) {
/* 255 */       return false;
/*     */     }
/*     */     
/* 258 */     if (this.payloadLength == 126L) {
/* 259 */       this.payloadLength = byteArrayToLong(this.inputBuffer, this.readPos, 2);
/* 260 */       this.readPos += 2;
/* 261 */     } else if (this.payloadLength == 127L) {
/* 262 */       this.payloadLength = byteArrayToLong(this.inputBuffer, this.readPos, 8);
/* 263 */       this.readPos += 8;
/*     */     }
/* 265 */     if (Util.isControl(this.opCode)) {
/* 266 */       if (this.payloadLength > 125L) {
/* 267 */         throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.controlPayloadTooBig", new Object[] { Long.valueOf(this.payloadLength) })));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 272 */       if (!this.fin) {
/* 273 */         throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.controlNoFin")));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 278 */     if (isMasked()) {
/* 279 */       System.arraycopy(this.inputBuffer, this.readPos, this.mask, 0, 4);
/* 280 */       this.readPos += 4;
/*     */     }
/* 282 */     this.state = State.DATA;
/* 283 */     return true;
/*     */   }
/*     */   
/*     */   private boolean processData() throws IOException {
/*     */     boolean result;
/*     */     boolean result;
/* 289 */     if (Util.isControl(this.opCode)) {
/* 290 */       result = processDataControl(); } else { boolean result;
/* 291 */       if (this.textMessage) { boolean result;
/* 292 */         if (this.textMsgHandler == null) {
/* 293 */           result = swallowInput();
/*     */         } else
/* 295 */           result = processDataText();
/*     */       } else {
/*     */         boolean result;
/* 298 */         if (this.binaryMsgHandler == null) {
/* 299 */           result = swallowInput();
/*     */         } else
/* 301 */           result = processDataBinary();
/*     */       }
/*     */     }
/* 304 */     checkRoomPayload();
/* 305 */     return result;
/*     */   }
/*     */   
/*     */   private boolean processDataControl() throws IOException
/*     */   {
/* 310 */     TransformationResult tr = this.transformation.getMoreData(this.opCode, this.fin, this.rsv, this.controlBufferBinary);
/* 311 */     if (TransformationResult.UNDERFLOW.equals(tr)) {
/* 312 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 317 */     this.controlBufferBinary.flip();
/* 318 */     if (this.opCode == 8) {
/* 319 */       this.open = false;
/* 320 */       String reason = null;
/* 321 */       int code = CloseReason.CloseCodes.NORMAL_CLOSURE.getCode();
/* 322 */       if (this.controlBufferBinary.remaining() == 1) {
/* 323 */         this.controlBufferBinary.clear();
/*     */         
/* 325 */         throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.oneByteCloseCode")));
/*     */       }
/*     */       
/*     */ 
/* 329 */       if (this.controlBufferBinary.remaining() > 1) {
/* 330 */         code = this.controlBufferBinary.getShort();
/* 331 */         if (this.controlBufferBinary.remaining() > 0) {
/* 332 */           CoderResult cr = this.utf8DecoderControl.decode(this.controlBufferBinary, this.controlBufferText, true);
/*     */           
/* 334 */           if (cr.isError()) {
/* 335 */             this.controlBufferBinary.clear();
/* 336 */             this.controlBufferText.clear();
/* 337 */             throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.invalidUtf8Close")));
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 344 */           this.controlBufferText.flip();
/* 345 */           reason = this.controlBufferText.toString();
/*     */         }
/*     */       }
/* 348 */       this.wsSession.onClose(new CloseReason(Util.getCloseCode(code), reason));
/* 349 */     } else if (this.opCode == 9) {
/* 350 */       if (this.wsSession.isOpen()) {
/* 351 */         this.wsSession.getBasicRemote().sendPong(this.controlBufferBinary);
/*     */       }
/* 353 */     } else if (this.opCode == 10) {
/* 354 */       MessageHandler.Whole<PongMessage> mhPong = this.wsSession.getPongMessageHandler();
/*     */       
/* 356 */       if (mhPong != null) {
/*     */         try {
/* 358 */           mhPong.onMessage(new WsPongMessage(this.controlBufferBinary));
/*     */         } catch (Throwable t) {
/* 360 */           handleThrowableOnSend(t);
/*     */         } finally {
/* 362 */           this.controlBufferBinary.clear();
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 367 */       this.controlBufferBinary.clear();
/* 368 */       throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.invalidOpCode", new Object[] { Integer.valueOf(this.opCode) })));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 373 */     this.controlBufferBinary.clear();
/* 374 */     newFrame();
/* 375 */     return true;
/*     */   }
/*     */   
/*     */   protected void sendMessageText(boolean last)
/*     */     throws WsIOException
/*     */   {
/* 381 */     if ((this.textMsgHandler instanceof WrappedMessageHandler)) {
/* 382 */       long maxMessageSize = ((WrappedMessageHandler)this.textMsgHandler).getMaxMessageSize();
/*     */       
/* 384 */       if ((maxMessageSize > -1L) && (this.messageBufferText.remaining() > maxMessageSize))
/*     */       {
/* 386 */         throw new WsIOException(new CloseReason(CloseReason.CloseCodes.TOO_BIG, sm.getString("wsFrame.messageTooBig", new Object[] { Long.valueOf(this.messageBufferText.remaining()), Long.valueOf(maxMessageSize) })));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 394 */       if ((this.textMsgHandler instanceof MessageHandler.Partial)) {
/* 395 */         ((MessageHandler.Partial)this.textMsgHandler).onMessage(this.messageBufferText.toString(), last);
/*     */       }
/*     */       else
/*     */       {
/* 399 */         ((MessageHandler.Whole)this.textMsgHandler).onMessage(this.messageBufferText.toString());
/*     */       }
/*     */     }
/*     */     catch (Throwable t) {
/* 403 */       handleThrowableOnSend(t);
/*     */     } finally {
/* 405 */       this.messageBufferText.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean processDataText()
/*     */     throws IOException
/*     */   {
/* 412 */     TransformationResult tr = this.transformation.getMoreData(this.opCode, this.fin, this.rsv, this.messageBufferBinary);
/* 413 */     while (!TransformationResult.END_OF_FRAME.equals(tr))
/*     */     {
/*     */ 
/* 416 */       this.messageBufferBinary.flip();
/*     */       for (;;) {
/* 418 */         CoderResult cr = this.utf8DecoderMessage.decode(this.messageBufferBinary, this.messageBufferText, false);
/*     */         
/* 420 */         if (cr.isError()) {
/* 421 */           throw new WsIOException(new CloseReason(CloseReason.CloseCodes.NOT_CONSISTENT, sm.getString("wsFrame.invalidUtf8")));
/*     */         }
/*     */         
/* 424 */         if (cr.isOverflow())
/*     */         {
/* 426 */           if (usePartial()) {
/* 427 */             this.messageBufferText.flip();
/* 428 */             sendMessageText(false);
/* 429 */             this.messageBufferText.clear();
/*     */           } else {
/* 431 */             throw new WsIOException(new CloseReason(CloseReason.CloseCodes.TOO_BIG, sm.getString("wsFrame.textMessageTooBig")));
/*     */           }
/*     */           
/*     */         }
/* 435 */         else if (cr.isUnderflow())
/*     */         {
/* 437 */           this.messageBufferBinary.compact();
/*     */           
/*     */ 
/*     */ 
/* 441 */           if (TransformationResult.OVERFLOW.equals(tr)) {
/*     */             break;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 448 */           return false;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 453 */       tr = this.transformation.getMoreData(this.opCode, this.fin, this.rsv, this.messageBufferBinary);
/*     */     }
/*     */     
/* 456 */     this.messageBufferBinary.flip();
/* 457 */     boolean last = false;
/*     */     
/*     */     for (;;)
/*     */     {
/* 461 */       CoderResult cr = this.utf8DecoderMessage.decode(this.messageBufferBinary, this.messageBufferText, last);
/*     */       
/* 463 */       if (cr.isError()) {
/* 464 */         throw new WsIOException(new CloseReason(CloseReason.CloseCodes.NOT_CONSISTENT, sm.getString("wsFrame.invalidUtf8")));
/*     */       }
/*     */       
/* 467 */       if (cr.isOverflow())
/*     */       {
/* 469 */         if (usePartial()) {
/* 470 */           this.messageBufferText.flip();
/* 471 */           sendMessageText(false);
/* 472 */           this.messageBufferText.clear();
/*     */         } else {
/* 474 */           throw new WsIOException(new CloseReason(CloseReason.CloseCodes.TOO_BIG, sm.getString("wsFrame.textMessageTooBig")));
/*     */         }
/*     */         
/*     */       }
/* 478 */       else if ((cr.isUnderflow()) && (!last))
/*     */       {
/*     */ 
/* 481 */         if (this.continuationExpected)
/*     */         {
/*     */ 
/* 484 */           if (usePartial()) {
/* 485 */             this.messageBufferText.flip();
/* 486 */             sendMessageText(false);
/* 487 */             this.messageBufferText.clear();
/*     */           }
/* 489 */           this.messageBufferBinary.compact();
/* 490 */           newFrame();
/*     */           
/* 492 */           return true;
/*     */         }
/*     */         
/* 495 */         last = true;
/*     */       }
/*     */       else
/*     */       {
/* 499 */         this.messageBufferText.flip();
/* 500 */         sendMessageText(true);
/*     */         
/* 502 */         newMessage();
/* 503 */         return true;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean processDataBinary()
/*     */     throws IOException
/*     */   {
/* 511 */     TransformationResult tr = this.transformation.getMoreData(this.opCode, this.fin, this.rsv, this.messageBufferBinary);
/* 512 */     while (!TransformationResult.END_OF_FRAME.equals(tr))
/*     */     {
/* 514 */       if (TransformationResult.UNDERFLOW.equals(tr))
/*     */       {
/* 516 */         return false;
/*     */       }
/*     */       
/*     */ 
/* 520 */       if (!usePartial()) {
/* 521 */         CloseReason cr = new CloseReason(CloseReason.CloseCodes.TOO_BIG, sm.getString("wsFrame.bufferTooSmall", new Object[] { Integer.valueOf(this.messageBufferBinary.capacity()), Long.valueOf(this.payloadLength) }));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 526 */         throw new WsIOException(cr);
/*     */       }
/* 528 */       this.messageBufferBinary.flip();
/* 529 */       ByteBuffer copy = ByteBuffer.allocate(this.messageBufferBinary.limit());
/*     */       
/* 531 */       copy.put(this.messageBufferBinary);
/* 532 */       copy.flip();
/* 533 */       sendMessageBinary(copy, false);
/* 534 */       this.messageBufferBinary.clear();
/*     */       
/* 536 */       tr = this.transformation.getMoreData(this.opCode, this.fin, this.rsv, this.messageBufferBinary);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 543 */     if ((usePartial()) || (!this.continuationExpected)) {
/* 544 */       this.messageBufferBinary.flip();
/* 545 */       ByteBuffer copy = ByteBuffer.allocate(this.messageBufferBinary.limit());
/*     */       
/* 547 */       copy.put(this.messageBufferBinary);
/* 548 */       copy.flip();
/* 549 */       sendMessageBinary(copy, !this.continuationExpected);
/* 550 */       this.messageBufferBinary.clear();
/*     */     }
/*     */     
/* 553 */     if (this.continuationExpected)
/*     */     {
/* 555 */       newFrame();
/*     */     }
/*     */     else {
/* 558 */       newMessage();
/*     */     }
/*     */     
/* 561 */     return true;
/*     */   }
/*     */   
/*     */   private void handleThrowableOnSend(Throwable t) throws WsIOException
/*     */   {
/* 566 */     ExceptionUtils.handleThrowable(t);
/* 567 */     this.wsSession.getLocal().onError(this.wsSession, t);
/* 568 */     CloseReason cr = new CloseReason(CloseReason.CloseCodes.CLOSED_ABNORMALLY, sm.getString("wsFrame.ioeTriggeredClose"));
/*     */     
/* 570 */     throw new WsIOException(cr);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void sendMessageBinary(ByteBuffer msg, boolean last)
/*     */     throws WsIOException
/*     */   {
/* 577 */     if ((this.binaryMsgHandler instanceof WrappedMessageHandler)) {
/* 578 */       long maxMessageSize = ((WrappedMessageHandler)this.binaryMsgHandler).getMaxMessageSize();
/*     */       
/* 580 */       if ((maxMessageSize > -1L) && (msg.remaining() > maxMessageSize)) {
/* 581 */         throw new WsIOException(new CloseReason(CloseReason.CloseCodes.TOO_BIG, sm.getString("wsFrame.messageTooBig", new Object[] { Long.valueOf(msg.remaining()), Long.valueOf(maxMessageSize) })));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 588 */       if ((this.binaryMsgHandler instanceof MessageHandler.Partial)) {
/* 589 */         ((MessageHandler.Partial)this.binaryMsgHandler).onMessage(msg, last);
/*     */       }
/*     */       else {
/* 592 */         ((MessageHandler.Whole)this.binaryMsgHandler).onMessage(msg);
/*     */       }
/*     */     } catch (Throwable t) {
/* 595 */       handleThrowableOnSend(t);
/*     */     }
/*     */   }
/*     */   
/*     */   private void newMessage()
/*     */   {
/* 601 */     this.messageBufferBinary.clear();
/* 602 */     this.messageBufferText.clear();
/* 603 */     this.utf8DecoderMessage.reset();
/* 604 */     this.continuationExpected = false;
/* 605 */     newFrame();
/*     */   }
/*     */   
/*     */   private void newFrame()
/*     */   {
/* 610 */     if (this.readPos == this.writePos) {
/* 611 */       this.readPos = 0;
/* 612 */       this.writePos = 0;
/*     */     }
/*     */     
/* 615 */     this.maskIndex = 0;
/* 616 */     this.payloadWritten = 0L;
/* 617 */     this.state = State.NEW_FRAME;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 622 */     checkRoomHeaders();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void checkRoomHeaders()
/*     */   {
/* 629 */     if (this.inputBuffer.length - this.readPos < 131)
/*     */     {
/* 631 */       makeRoom();
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkRoomPayload()
/*     */   {
/* 637 */     if (this.inputBuffer.length - this.readPos - this.payloadLength + this.payloadWritten < 0L) {
/* 638 */       makeRoom();
/*     */     }
/*     */   }
/*     */   
/*     */   private void makeRoom()
/*     */   {
/* 644 */     System.arraycopy(this.inputBuffer, this.readPos, this.inputBuffer, 0, this.writePos - this.readPos);
/*     */     
/* 646 */     this.writePos -= this.readPos;
/* 647 */     this.readPos = 0;
/*     */   }
/*     */   
/*     */   private boolean usePartial()
/*     */   {
/* 652 */     if (Util.isControl(this.opCode))
/* 653 */       return false;
/* 654 */     if (this.textMessage) {
/* 655 */       return this.textMsgHandler instanceof MessageHandler.Partial;
/*     */     }
/*     */     
/* 658 */     return this.binaryMsgHandler instanceof MessageHandler.Partial;
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean swallowInput()
/*     */   {
/* 664 */     long toSkip = Math.min(this.payloadLength - this.payloadWritten, this.writePos - this.readPos);
/* 665 */     this.readPos = ((int)(this.readPos + toSkip));
/* 666 */     this.payloadWritten += toSkip;
/* 667 */     if (this.payloadWritten == this.payloadLength) {
/* 668 */       if (this.continuationExpected) {
/* 669 */         newFrame();
/*     */       } else {
/* 671 */         newMessage();
/*     */       }
/* 673 */       return true;
/*     */     }
/* 675 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   protected static long byteArrayToLong(byte[] b, int start, int len)
/*     */     throws IOException
/*     */   {
/* 682 */     if (len > 8) {
/* 683 */       throw new IOException(sm.getString("wsFrame.byteToLongFail", new Object[] { Long.valueOf(len) }));
/*     */     }
/*     */     
/* 686 */     int shift = 0;
/* 687 */     long result = 0L;
/* 688 */     for (int i = start + len - 1; i >= start; i--) {
/* 689 */       result += ((b[i] & 0xFF) << shift);
/* 690 */       shift += 8;
/*     */     }
/* 692 */     return result;
/*     */   }
/*     */   
/*     */   protected boolean isOpen()
/*     */   {
/* 697 */     return this.open;
/*     */   }
/*     */   
/*     */   protected Transformation getTransformation()
/*     */   {
/* 702 */     return this.transformation;
/*     */   }
/*     */   
/*     */   private static enum State
/*     */   {
/* 707 */     NEW_FRAME,  PARTIAL_HEADER,  DATA;
/*     */     
/*     */     private State() {}
/*     */   }
/*     */   
/*     */   private abstract class TerminalTransformation implements Transformation
/*     */   {
/*     */     private TerminalTransformation() {}
/*     */     
/*     */     public boolean validateRsvBits(int i) {
/* 717 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */     public Extension getExtensionResponse()
/*     */     {
/* 723 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setNext(Transformation t) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean validateRsv(int rsv, byte opCode)
/*     */     {
/* 738 */       return rsv == 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void close() {}
/*     */   }
/*     */   
/*     */ 
/*     */   private final class NoopTransformation
/*     */     extends WsFrameBase.TerminalTransformation
/*     */   {
/*     */     private NoopTransformation()
/*     */     {
/* 752 */       super(null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public TransformationResult getMoreData(byte opCode, boolean fin, int rsv, ByteBuffer dest)
/*     */     {
/* 760 */       long toWrite = Math.min(WsFrameBase.this.payloadLength - WsFrameBase.this.payloadWritten, WsFrameBase.this.writePos - WsFrameBase.this.readPos);
/*     */       
/* 762 */       toWrite = Math.min(toWrite, dest.remaining());
/*     */       
/* 764 */       dest.put(WsFrameBase.this.inputBuffer, WsFrameBase.this.readPos, (int)toWrite);
/* 765 */       WsFrameBase.access$514(WsFrameBase.this, toWrite);
/* 766 */       WsFrameBase.access$414(WsFrameBase.this, toWrite);
/*     */       
/* 768 */       if (WsFrameBase.this.payloadWritten == WsFrameBase.this.payloadLength)
/* 769 */         return TransformationResult.END_OF_FRAME;
/* 770 */       if (WsFrameBase.this.readPos == WsFrameBase.this.writePos) {
/* 771 */         return TransformationResult.UNDERFLOW;
/*     */       }
/*     */       
/* 774 */       return TransformationResult.OVERFLOW;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public List<MessagePart> sendMessagePart(List<MessagePart> messageParts)
/*     */     {
/* 783 */       return messageParts;
/*     */     }
/*     */   }
/*     */   
/*     */   private final class UnmaskTransformation
/*     */     extends WsFrameBase.TerminalTransformation
/*     */   {
/*     */     private UnmaskTransformation()
/*     */     {
/* 792 */       super(null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public TransformationResult getMoreData(byte opCode, boolean fin, int rsv, ByteBuffer dest)
/*     */     {
/* 800 */       while ((WsFrameBase.this.payloadWritten < WsFrameBase.this.payloadLength) && (WsFrameBase.this.readPos < WsFrameBase.this.writePos) && (dest.hasRemaining()))
/*     */       {
/* 802 */         byte b = (byte)((WsFrameBase.this.inputBuffer[WsFrameBase.this.readPos] ^ WsFrameBase.this.mask[WsFrameBase.this.maskIndex]) & 0xFF);
/* 803 */         WsFrameBase.access$708(WsFrameBase.this);
/* 804 */         if (WsFrameBase.this.maskIndex == 4) {
/* 805 */           WsFrameBase.this.maskIndex = 0;
/*     */         }
/* 807 */         WsFrameBase.access$508(WsFrameBase.this);
/* 808 */         WsFrameBase.access$408(WsFrameBase.this);
/* 809 */         dest.put(b);
/*     */       }
/* 811 */       if (WsFrameBase.this.payloadWritten == WsFrameBase.this.payloadLength)
/* 812 */         return TransformationResult.END_OF_FRAME;
/* 813 */       if (WsFrameBase.this.readPos == WsFrameBase.this.writePos) {
/* 814 */         return TransformationResult.UNDERFLOW;
/*     */       }
/*     */       
/* 817 */       return TransformationResult.OVERFLOW;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public List<MessagePart> sendMessagePart(List<MessagePart> messageParts)
/*     */     {
/* 824 */       return messageParts;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-websocket-8.5.4.jar!\org\apache\tomcat\websocket\WsFrameBase.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */