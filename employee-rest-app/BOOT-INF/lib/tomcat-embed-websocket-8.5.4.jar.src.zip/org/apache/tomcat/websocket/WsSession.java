/*     */ package org.apache.tomcat.websocket;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.WritePendingException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.Principal;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import javax.websocket.CloseReason;
/*     */ import javax.websocket.CloseReason.CloseCode;
/*     */ import javax.websocket.CloseReason.CloseCodes;
/*     */ import javax.websocket.DeploymentException;
/*     */ import javax.websocket.Endpoint;
/*     */ import javax.websocket.EndpointConfig;
/*     */ import javax.websocket.Extension;
/*     */ import javax.websocket.MessageHandler;
/*     */ import javax.websocket.MessageHandler.Partial;
/*     */ import javax.websocket.MessageHandler.Whole;
/*     */ import javax.websocket.PongMessage;
/*     */ import javax.websocket.RemoteEndpoint.Async;
/*     */ import javax.websocket.RemoteEndpoint.Basic;
/*     */ import javax.websocket.SendResult;
/*     */ import javax.websocket.Session;
/*     */ import javax.websocket.WebSocketContainer;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.InstanceManager;
/*     */ import org.apache.tomcat.InstanceManagerBindings;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WsSession
/*     */   implements Session
/*     */ {
/*  60 */   private static final byte[] ELLIPSIS_BYTES = "…".getBytes(StandardCharsets.UTF_8);
/*     */   
/*     */ 
/*  63 */   private static final int ELLIPSIS_BYTES_LEN = ELLIPSIS_BYTES.length;
/*     */   
/*  65 */   private static final StringManager sm = StringManager.getManager(WsSession.class);
/*  66 */   private static AtomicLong ids = new AtomicLong(0L);
/*     */   
/*  68 */   private final Log log = LogFactory.getLog(WsSession.class);
/*     */   
/*     */   private final Endpoint localEndpoint;
/*     */   
/*     */   private final WsRemoteEndpointImplBase wsRemoteEndpoint;
/*     */   
/*     */   private final RemoteEndpoint.Async remoteEndpointAsync;
/*     */   
/*     */   private final RemoteEndpoint.Basic remoteEndpointBasic;
/*     */   private final ClassLoader applicationClassLoader;
/*     */   private final WsWebSocketContainer webSocketContainer;
/*     */   private final URI requestUri;
/*     */   private final Map<String, List<String>> requestParameterMap;
/*     */   private final String queryString;
/*     */   private final Principal userPrincipal;
/*     */   private final EndpointConfig endpointConfig;
/*     */   private final List<Extension> negotiatedExtensions;
/*     */   private final String subProtocol;
/*     */   private final Map<String, String> pathParameters;
/*     */   private final boolean secure;
/*     */   private final String httpSessionId;
/*     */   private final String id;
/*  90 */   private volatile MessageHandler textMessageHandler = null;
/*     */   
/*  92 */   private volatile MessageHandler binaryMessageHandler = null;
/*  93 */   private volatile MessageHandler.Whole<PongMessage> pongMessageHandler = null;
/*  94 */   private volatile State state = State.OPEN;
/*  95 */   private final Object stateLock = new Object();
/*  96 */   private final Map<String, Object> userProperties = new ConcurrentHashMap();
/*  97 */   private volatile int maxBinaryMessageBufferSize = Constants.DEFAULT_BUFFER_SIZE;
/*     */   
/*  99 */   private volatile int maxTextMessageBufferSize = Constants.DEFAULT_BUFFER_SIZE;
/*     */   
/* 101 */   private volatile long maxIdleTimeout = 0L;
/* 102 */   private volatile long lastActive = System.currentTimeMillis();
/* 103 */   private Map<FutureToSendHandler, FutureToSendHandler> futures = new ConcurrentHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WsSession(Endpoint localEndpoint, WsRemoteEndpointImplBase wsRemoteEndpoint, WsWebSocketContainer wsWebSocketContainer, URI requestUri, Map<String, List<String>> requestParameterMap, String queryString, Principal userPrincipal, String httpSessionId, List<Extension> negotiatedExtensions, String subProtocol, Map<String, String> pathParameters, boolean secure, EndpointConfig endpointConfig)
/*     */     throws DeploymentException
/*     */   {
/* 147 */     this.localEndpoint = localEndpoint;
/* 148 */     this.wsRemoteEndpoint = wsRemoteEndpoint;
/* 149 */     this.wsRemoteEndpoint.setSession(this);
/* 150 */     this.remoteEndpointAsync = new WsRemoteEndpointAsync(wsRemoteEndpoint);
/* 151 */     this.remoteEndpointBasic = new WsRemoteEndpointBasic(wsRemoteEndpoint);
/* 152 */     this.webSocketContainer = wsWebSocketContainer;
/* 153 */     this.applicationClassLoader = Thread.currentThread().getContextClassLoader();
/* 154 */     wsRemoteEndpoint.setSendTimeout(wsWebSocketContainer.getDefaultAsyncSendTimeout());
/*     */     
/* 156 */     this.maxBinaryMessageBufferSize = this.webSocketContainer.getDefaultMaxBinaryMessageBufferSize();
/*     */     
/* 158 */     this.maxTextMessageBufferSize = this.webSocketContainer.getDefaultMaxTextMessageBufferSize();
/*     */     
/* 160 */     this.maxIdleTimeout = this.webSocketContainer.getDefaultMaxSessionIdleTimeout();
/*     */     
/* 162 */     this.requestUri = requestUri;
/* 163 */     if (requestParameterMap == null) {
/* 164 */       this.requestParameterMap = Collections.emptyMap();
/*     */     } else {
/* 166 */       this.requestParameterMap = requestParameterMap;
/*     */     }
/* 168 */     this.queryString = queryString;
/* 169 */     this.userPrincipal = userPrincipal;
/* 170 */     this.httpSessionId = httpSessionId;
/* 171 */     this.negotiatedExtensions = negotiatedExtensions;
/* 172 */     if (subProtocol == null) {
/* 173 */       this.subProtocol = "";
/*     */     } else {
/* 175 */       this.subProtocol = subProtocol;
/*     */     }
/* 177 */     this.pathParameters = pathParameters;
/* 178 */     this.secure = secure;
/* 179 */     this.wsRemoteEndpoint.setEncoders(endpointConfig);
/* 180 */     this.endpointConfig = endpointConfig;
/*     */     
/* 182 */     this.userProperties.putAll(endpointConfig.getUserProperties());
/* 183 */     this.id = Long.toHexString(ids.getAndIncrement());
/*     */     
/* 185 */     InstanceManager instanceManager = this.webSocketContainer.getInstanceManager();
/* 186 */     if (instanceManager == null) {
/* 187 */       instanceManager = InstanceManagerBindings.get(this.applicationClassLoader);
/*     */     }
/* 189 */     if (instanceManager != null) {
/*     */       try {
/* 191 */         instanceManager.newInstance(localEndpoint);
/*     */       } catch (Exception e) {
/* 193 */         throw new DeploymentException(sm.getString("wsSession.instanceNew"), e);
/*     */       }
/*     */     }
/*     */     
/* 197 */     if (this.log.isDebugEnabled()) {
/* 198 */       this.log.debug(sm.getString("wsSession.created", new Object[] { this.id }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public WebSocketContainer getContainer()
/*     */   {
/* 205 */     checkState();
/* 206 */     return this.webSocketContainer;
/*     */   }
/*     */   
/*     */ 
/*     */   public void addMessageHandler(MessageHandler listener)
/*     */   {
/* 212 */     Class<?> target = Util.getMessageType(listener);
/* 213 */     doAddMessageHandler(target, listener);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> void addMessageHandler(Class<T> clazz, MessageHandler.Partial<T> handler)
/*     */     throws IllegalStateException
/*     */   {
/* 220 */     doAddMessageHandler(clazz, handler);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> void addMessageHandler(Class<T> clazz, MessageHandler.Whole<T> handler)
/*     */     throws IllegalStateException
/*     */   {
/* 227 */     doAddMessageHandler(clazz, handler);
/*     */   }
/*     */   
/*     */ 
/*     */   private void doAddMessageHandler(Class<?> target, MessageHandler listener)
/*     */   {
/* 233 */     checkState();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 245 */     Set<MessageHandlerResult> mhResults = Util.getMessageHandlers(target, listener, this.endpointConfig, this);
/*     */     
/*     */ 
/* 248 */     for (MessageHandlerResult mhResult : mhResults) {
/* 249 */       switch (mhResult.getType()) {
/*     */       case TEXT: 
/* 251 */         if (this.textMessageHandler != null) {
/* 252 */           throw new IllegalStateException(sm.getString("wsSession.duplicateHandlerText"));
/*     */         }
/*     */         
/* 255 */         this.textMessageHandler = mhResult.getHandler();
/* 256 */         break;
/*     */       
/*     */       case BINARY: 
/* 259 */         if (this.binaryMessageHandler != null) {
/* 260 */           throw new IllegalStateException(sm.getString("wsSession.duplicateHandlerBinary"));
/*     */         }
/*     */         
/* 263 */         this.binaryMessageHandler = mhResult.getHandler();
/* 264 */         break;
/*     */       
/*     */       case PONG: 
/* 267 */         if (this.pongMessageHandler != null) {
/* 268 */           throw new IllegalStateException(sm.getString("wsSession.duplicateHandlerPong"));
/*     */         }
/*     */         
/* 271 */         MessageHandler handler = mhResult.getHandler();
/* 272 */         if ((handler instanceof MessageHandler.Whole)) {
/* 273 */           this.pongMessageHandler = ((MessageHandler.Whole)handler);
/*     */         }
/*     */         else {
/* 276 */           throw new IllegalStateException(sm.getString("wsSession.invalidHandlerTypePong"));
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */         break;
/*     */       default: 
/* 283 */         throw new IllegalArgumentException(sm.getString("wsSession.unknownHandlerType", new Object[] { listener, mhResult.getType() }));
/*     */       }
/*     */       
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<MessageHandler> getMessageHandlers()
/*     */   {
/* 294 */     checkState();
/* 295 */     Set<MessageHandler> result = new HashSet();
/* 296 */     if (this.binaryMessageHandler != null) {
/* 297 */       result.add(this.binaryMessageHandler);
/*     */     }
/* 299 */     if (this.textMessageHandler != null) {
/* 300 */       result.add(this.textMessageHandler);
/*     */     }
/* 302 */     if (this.pongMessageHandler != null) {
/* 303 */       result.add(this.pongMessageHandler);
/*     */     }
/* 305 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public void removeMessageHandler(MessageHandler listener)
/*     */   {
/* 311 */     checkState();
/* 312 */     if (listener == null) {
/* 313 */       return;
/*     */     }
/*     */     
/* 316 */     MessageHandler wrapped = null;
/*     */     
/* 318 */     if ((listener instanceof WrappedMessageHandler)) {
/* 319 */       wrapped = ((WrappedMessageHandler)listener).getWrappedHandler();
/*     */     }
/*     */     
/* 322 */     if (wrapped == null) {
/* 323 */       wrapped = listener;
/*     */     }
/*     */     
/* 326 */     boolean removed = false;
/* 327 */     if ((wrapped.equals(this.textMessageHandler)) || (listener.equals(this.textMessageHandler)))
/*     */     {
/* 329 */       this.textMessageHandler = null;
/* 330 */       removed = true;
/*     */     }
/*     */     
/* 333 */     if ((wrapped.equals(this.binaryMessageHandler)) || (listener.equals(this.binaryMessageHandler)))
/*     */     {
/* 335 */       this.binaryMessageHandler = null;
/* 336 */       removed = true;
/*     */     }
/*     */     
/* 339 */     if ((wrapped.equals(this.pongMessageHandler)) || (listener.equals(this.pongMessageHandler)))
/*     */     {
/* 341 */       this.pongMessageHandler = null;
/* 342 */       removed = true;
/*     */     }
/*     */     
/* 345 */     if (!removed)
/*     */     {
/*     */ 
/* 348 */       throw new IllegalStateException(sm.getString("wsSession.removeHandlerFailed", new Object[] { listener }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getProtocolVersion()
/*     */   {
/* 356 */     checkState();
/* 357 */     return "13";
/*     */   }
/*     */   
/*     */ 
/*     */   public String getNegotiatedSubprotocol()
/*     */   {
/* 363 */     checkState();
/* 364 */     return this.subProtocol;
/*     */   }
/*     */   
/*     */ 
/*     */   public List<Extension> getNegotiatedExtensions()
/*     */   {
/* 370 */     checkState();
/* 371 */     return this.negotiatedExtensions;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isSecure()
/*     */   {
/* 377 */     checkState();
/* 378 */     return this.secure;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isOpen()
/*     */   {
/* 384 */     return this.state == State.OPEN;
/*     */   }
/*     */   
/*     */ 
/*     */   public long getMaxIdleTimeout()
/*     */   {
/* 390 */     checkState();
/* 391 */     return this.maxIdleTimeout;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setMaxIdleTimeout(long timeout)
/*     */   {
/* 397 */     checkState();
/* 398 */     this.maxIdleTimeout = timeout;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setMaxBinaryMessageBufferSize(int max)
/*     */   {
/* 404 */     checkState();
/* 405 */     this.maxBinaryMessageBufferSize = max;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getMaxBinaryMessageBufferSize()
/*     */   {
/* 411 */     checkState();
/* 412 */     return this.maxBinaryMessageBufferSize;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setMaxTextMessageBufferSize(int max)
/*     */   {
/* 418 */     checkState();
/* 419 */     this.maxTextMessageBufferSize = max;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getMaxTextMessageBufferSize()
/*     */   {
/* 425 */     checkState();
/* 426 */     return this.maxTextMessageBufferSize;
/*     */   }
/*     */   
/*     */ 
/*     */   public Set<Session> getOpenSessions()
/*     */   {
/* 432 */     checkState();
/* 433 */     return this.webSocketContainer.getOpenSessions(this.localEndpoint);
/*     */   }
/*     */   
/*     */ 
/*     */   public RemoteEndpoint.Async getAsyncRemote()
/*     */   {
/* 439 */     checkState();
/* 440 */     return this.remoteEndpointAsync;
/*     */   }
/*     */   
/*     */ 
/*     */   public RemoteEndpoint.Basic getBasicRemote()
/*     */   {
/* 446 */     checkState();
/* 447 */     return this.remoteEndpointBasic;
/*     */   }
/*     */   
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 453 */     close(new CloseReason(CloseReason.CloseCodes.NORMAL_CLOSURE, ""));
/*     */   }
/*     */   
/*     */   public void close(CloseReason closeReason)
/*     */     throws IOException
/*     */   {
/* 459 */     doClose(closeReason, closeReason);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doClose(CloseReason closeReasonMessage, CloseReason closeReasonLocal)
/*     */   {
/* 473 */     if (this.state != State.OPEN) {
/* 474 */       return;
/*     */     }
/*     */     
/* 477 */     synchronized (this.stateLock) {
/* 478 */       if (this.state != State.OPEN) {
/* 479 */         return;
/*     */       }
/*     */       
/* 482 */       if (this.log.isDebugEnabled()) {
/* 483 */         this.log.debug(sm.getString("wsSession.doClose", new Object[] { this.id }));
/*     */       }
/*     */       try {
/* 486 */         this.wsRemoteEndpoint.setBatchingAllowed(false);
/*     */       } catch (IOException e) {
/* 488 */         this.log.warn(sm.getString("wsSession.flushFailOnClose"), e);
/* 489 */         fireEndpointOnError(e);
/*     */       }
/*     */       
/* 492 */       this.state = State.OUTPUT_CLOSED;
/*     */       
/* 494 */       sendCloseMessage(closeReasonMessage);
/* 495 */       fireEndpointOnClose(closeReasonLocal);
/*     */     }
/*     */     
/* 498 */     IOException ioe = new IOException(sm.getString("wsSession.messageFailed"));
/* 499 */     SendResult sr = new SendResult(ioe);
/* 500 */     for (FutureToSendHandler f2sh : this.futures.keySet()) {
/* 501 */       f2sh.onResult(sr);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onClose(CloseReason closeReason)
/*     */   {
/* 516 */     synchronized (this.stateLock) {
/* 517 */       if (this.state != State.CLOSED) {
/*     */         try {
/* 519 */           this.wsRemoteEndpoint.setBatchingAllowed(false);
/*     */         } catch (IOException e) {
/* 521 */           this.log.warn(sm.getString("wsSession.flushFailOnClose"), e);
/* 522 */           fireEndpointOnError(e);
/*     */         }
/* 524 */         if (this.state == State.OPEN) {
/* 525 */           this.state = State.OUTPUT_CLOSED;
/* 526 */           sendCloseMessage(closeReason);
/* 527 */           fireEndpointOnClose(closeReason);
/*     */         }
/* 529 */         this.state = State.CLOSED;
/*     */         
/*     */ 
/* 532 */         this.wsRemoteEndpoint.close();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void fireEndpointOnClose(CloseReason closeReason)
/*     */   {
/* 540 */     Throwable throwable = null;
/* 541 */     InstanceManager instanceManager = this.webSocketContainer.getInstanceManager();
/* 542 */     if (instanceManager == null) {
/* 543 */       instanceManager = InstanceManagerBindings.get(this.applicationClassLoader);
/*     */     }
/* 545 */     Thread t = Thread.currentThread();
/* 546 */     ClassLoader cl = t.getContextClassLoader();
/* 547 */     t.setContextClassLoader(this.applicationClassLoader);
/*     */     try {
/* 549 */       this.localEndpoint.onClose(this, closeReason);
/*     */     } catch (Throwable t1) {
/* 551 */       ExceptionUtils.handleThrowable(t1);
/* 552 */       throwable = t1;
/*     */     } finally {
/* 554 */       if (instanceManager != null) {
/*     */         try {
/* 556 */           instanceManager.destroyInstance(this.localEndpoint);
/*     */         } catch (Throwable t2) {
/* 558 */           ExceptionUtils.handleThrowable(t2);
/* 559 */           if (throwable == null) {
/* 560 */             throwable = t2;
/*     */           }
/*     */         }
/*     */       }
/* 564 */       t.setContextClassLoader(cl);
/*     */     }
/*     */     
/* 567 */     if (throwable != null) {
/* 568 */       fireEndpointOnError(throwable);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void fireEndpointOnError(Throwable throwable)
/*     */   {
/* 577 */     Thread t = Thread.currentThread();
/* 578 */     ClassLoader cl = t.getContextClassLoader();
/* 579 */     t.setContextClassLoader(this.applicationClassLoader);
/*     */     try {
/* 581 */       this.localEndpoint.onError(this, throwable);
/*     */     } finally {
/* 583 */       t.setContextClassLoader(cl);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void sendCloseMessage(CloseReason closeReason)
/*     */   {
/* 590 */     ByteBuffer msg = ByteBuffer.allocate(125);
/* 591 */     CloseReason.CloseCode closeCode = closeReason.getCloseCode();
/*     */     
/* 593 */     if (closeCode == CloseReason.CloseCodes.CLOSED_ABNORMALLY)
/*     */     {
/* 595 */       msg.putShort((short)CloseReason.CloseCodes.PROTOCOL_ERROR.getCode());
/*     */     } else {
/* 597 */       msg.putShort((short)closeCode.getCode());
/*     */     }
/*     */     
/* 600 */     String reason = closeReason.getReasonPhrase();
/* 601 */     if ((reason != null) && (reason.length() > 0)) {
/* 602 */       appendCloseReasonWithTruncation(msg, reason);
/*     */     }
/* 604 */     msg.flip();
/*     */     try {
/* 606 */       this.wsRemoteEndpoint.sendMessageBlock((byte)8, msg, true);
/*     */     }
/*     */     catch (IOException|WritePendingException e)
/*     */     {
/* 610 */       if (this.log.isDebugEnabled()) {
/* 611 */         this.log.debug(sm.getString("wsSession.sendCloseFail", new Object[] { this.id }), e);
/*     */       }
/* 613 */       this.wsRemoteEndpoint.close();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 618 */       if (closeCode != CloseReason.CloseCodes.CLOSED_ABNORMALLY) {
/* 619 */         this.localEndpoint.onError(this, e);
/*     */       }
/*     */     } finally {
/* 622 */       this.webSocketContainer.unregisterSession(this.localEndpoint, this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void appendCloseReasonWithTruncation(ByteBuffer msg, String reason)
/*     */   {
/* 638 */     byte[] reasonBytes = reason.getBytes(StandardCharsets.UTF_8);
/*     */     
/* 640 */     if (reasonBytes.length <= 123)
/*     */     {
/* 642 */       msg.put(reasonBytes);
/*     */     }
/*     */     else {
/* 645 */       int remaining = 123 - ELLIPSIS_BYTES_LEN;
/* 646 */       int pos = 0;
/* 647 */       byte[] bytesNext = reason.substring(pos, pos + 1).getBytes(StandardCharsets.UTF_8);
/*     */       
/* 649 */       while (remaining >= bytesNext.length) {
/* 650 */         msg.put(bytesNext);
/* 651 */         remaining -= bytesNext.length;
/* 652 */         pos++;
/* 653 */         bytesNext = reason.substring(pos, pos + 1).getBytes(StandardCharsets.UTF_8);
/*     */       }
/*     */       
/* 656 */       msg.put(ELLIPSIS_BYTES);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void registerFuture(FutureToSendHandler f2sh)
/*     */   {
/* 668 */     boolean fail = false;
/* 669 */     synchronized (this.stateLock)
/*     */     {
/*     */ 
/*     */ 
/* 673 */       if (this.state == State.OPEN) {
/* 674 */         this.futures.put(f2sh, f2sh);
/* 675 */       } else if (!f2sh.isDone())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 681 */         fail = true;
/*     */       }
/*     */     }
/*     */     
/* 685 */     if (fail) {
/* 686 */       IOException ioe = new IOException(sm.getString("wsSession.messageFailed"));
/* 687 */       SendResult sr = new SendResult(ioe);
/* 688 */       f2sh.onResult(sr);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void unregisterFuture(FutureToSendHandler f2sh)
/*     */   {
/* 698 */     this.futures.remove(f2sh);
/*     */   }
/*     */   
/*     */ 
/*     */   public URI getRequestURI()
/*     */   {
/* 704 */     checkState();
/* 705 */     return this.requestUri;
/*     */   }
/*     */   
/*     */ 
/*     */   public Map<String, List<String>> getRequestParameterMap()
/*     */   {
/* 711 */     checkState();
/* 712 */     return this.requestParameterMap;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getQueryString()
/*     */   {
/* 718 */     checkState();
/* 719 */     return this.queryString;
/*     */   }
/*     */   
/*     */ 
/*     */   public Principal getUserPrincipal()
/*     */   {
/* 725 */     checkState();
/* 726 */     return this.userPrincipal;
/*     */   }
/*     */   
/*     */ 
/*     */   public Map<String, String> getPathParameters()
/*     */   {
/* 732 */     checkState();
/* 733 */     return this.pathParameters;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getId()
/*     */   {
/* 739 */     return this.id;
/*     */   }
/*     */   
/*     */ 
/*     */   public Map<String, Object> getUserProperties()
/*     */   {
/* 745 */     checkState();
/* 746 */     return this.userProperties;
/*     */   }
/*     */   
/*     */   public Endpoint getLocal()
/*     */   {
/* 751 */     return this.localEndpoint;
/*     */   }
/*     */   
/*     */   public String getHttpSessionId()
/*     */   {
/* 756 */     return this.httpSessionId;
/*     */   }
/*     */   
/*     */   protected MessageHandler getTextMessageHandler()
/*     */   {
/* 761 */     return this.textMessageHandler;
/*     */   }
/*     */   
/*     */   protected MessageHandler getBinaryMessageHandler()
/*     */   {
/* 766 */     return this.binaryMessageHandler;
/*     */   }
/*     */   
/*     */   protected MessageHandler.Whole<PongMessage> getPongMessageHandler()
/*     */   {
/* 771 */     return this.pongMessageHandler;
/*     */   }
/*     */   
/*     */   protected void updateLastActive()
/*     */   {
/* 776 */     this.lastActive = System.currentTimeMillis();
/*     */   }
/*     */   
/*     */   protected void checkExpiration()
/*     */   {
/* 781 */     long timeout = this.maxIdleTimeout;
/* 782 */     if (timeout < 1L) {
/* 783 */       return;
/*     */     }
/*     */     
/* 786 */     if (System.currentTimeMillis() - this.lastActive > timeout) {
/* 787 */       String msg = sm.getString("wsSession.timeout", new Object[] { getId() });
/* 788 */       if (this.log.isDebugEnabled()) {
/* 789 */         this.log.debug(msg);
/*     */       }
/* 791 */       doClose(new CloseReason(CloseReason.CloseCodes.GOING_AWAY, msg), new CloseReason(CloseReason.CloseCodes.CLOSED_ABNORMALLY, msg));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void checkState()
/*     */   {
/* 798 */     if (this.state == State.CLOSED)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 803 */       throw new IllegalStateException(sm.getString("wsSession.closed", new Object[] { this.id }));
/*     */     }
/*     */   }
/*     */   
/*     */   private static enum State {
/* 808 */     OPEN, 
/* 809 */     OUTPUT_CLOSED, 
/* 810 */     CLOSED;
/*     */     
/*     */     private State() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-websocket-8.5.4.jar!\org\apache\tomcat\websocket\WsSession.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */