/*     */ package org.apache.tomcat.websocket.pojo;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.websocket.DecodeException;
/*     */ import javax.websocket.Decoder;
/*     */ import javax.websocket.Decoder.Binary;
/*     */ import javax.websocket.Decoder.BinaryStream;
/*     */ import javax.websocket.EndpointConfig;
/*     */ import javax.websocket.Session;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PojoMessageHandlerWholeBinary
/*     */   extends PojoMessageHandlerWholeBase<ByteBuffer>
/*     */ {
/*  41 */   private static final StringManager sm = StringManager.getManager(PojoMessageHandlerWholeBinary.class);
/*     */   
/*     */ 
/*  44 */   private final List<Decoder> decoders = new ArrayList();
/*     */   
/*     */ 
/*     */   private final boolean isForInputStream;
/*     */   
/*     */ 
/*     */ 
/*     */   public PojoMessageHandlerWholeBinary(Object pojo, Method method, Session session, EndpointConfig config, List<Class<? extends Decoder>> decoderClazzes, Object[] params, int indexPayload, boolean convert, int indexSession, boolean isForInputStream, long maxMessageSize)
/*     */   {
/*  53 */     super(pojo, method, session, params, indexPayload, convert, indexSession, maxMessageSize);
/*     */     
/*     */ 
/*     */ 
/*  57 */     if ((maxMessageSize > -1L) && (maxMessageSize > session.getMaxBinaryMessageBufferSize())) {
/*  58 */       if (maxMessageSize > 2147483647L) {
/*  59 */         throw new IllegalArgumentException(sm.getString("pojoMessageHandlerWhole.maxBufferSize"));
/*     */       }
/*     */       
/*  62 */       session.setMaxBinaryMessageBufferSize((int)maxMessageSize);
/*     */     }
/*     */     try
/*     */     {
/*  66 */       if (decoderClazzes != null) {
/*  67 */         for (Class<? extends Decoder> decoderClazz : decoderClazzes) {
/*  68 */           if (Decoder.Binary.class.isAssignableFrom(decoderClazz)) {
/*  69 */             Decoder.Binary<?> decoder = (Decoder.Binary)decoderClazz.newInstance();
/*     */             
/*  71 */             decoder.init(config);
/*  72 */             this.decoders.add(decoder);
/*  73 */           } else if (Decoder.BinaryStream.class.isAssignableFrom(decoderClazz))
/*     */           {
/*  75 */             Decoder.BinaryStream<?> decoder = (Decoder.BinaryStream)decoderClazz.newInstance();
/*     */             
/*  77 */             decoder.init(config);
/*  78 */             this.decoders.add(decoder);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (IllegalAccessException|InstantiationException e)
/*     */     {
/*  85 */       throw new IllegalArgumentException(e);
/*     */     }
/*  87 */     this.isForInputStream = isForInputStream;
/*     */   }
/*     */   
/*     */   protected Object decode(ByteBuffer message)
/*     */     throws DecodeException
/*     */   {
/*  93 */     for (Decoder decoder : this.decoders) {
/*  94 */       if ((decoder instanceof Decoder.Binary)) {
/*  95 */         if (((Decoder.Binary)decoder).willDecode(message)) {
/*  96 */           return ((Decoder.Binary)decoder).decode(message);
/*     */         }
/*     */       } else {
/*  99 */         byte[] array = new byte[message.limit() - message.position()];
/* 100 */         message.get(array);
/* 101 */         ByteArrayInputStream bais = new ByteArrayInputStream(array);
/*     */         try {
/* 103 */           return ((Decoder.BinaryStream)decoder).decode(bais);
/*     */         } catch (IOException ioe) {
/* 105 */           throw new DecodeException(message, sm.getString("pojoMessageHandlerWhole.decodeIoFail"), ioe);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 110 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   protected Object convert(ByteBuffer message)
/*     */   {
/* 116 */     byte[] array = new byte[message.remaining()];
/* 117 */     message.get(array);
/* 118 */     if (this.isForInputStream) {
/* 119 */       return new ByteArrayInputStream(array);
/*     */     }
/* 121 */     return array;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void onClose()
/*     */   {
/* 128 */     for (Decoder decoder : this.decoders) {
/* 129 */       decoder.destroy();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-websocket-8.5.4.jar!\org\apache\tomcat\websocket\pojo\PojoMessageHandlerWholeBinary.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */