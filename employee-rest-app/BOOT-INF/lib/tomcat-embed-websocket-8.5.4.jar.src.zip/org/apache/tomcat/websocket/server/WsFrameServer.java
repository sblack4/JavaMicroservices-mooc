/*     */ package org.apache.tomcat.websocket.server;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.net.SocketWrapperBase;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.websocket.Transformation;
/*     */ import org.apache.tomcat.websocket.WsFrameBase;
/*     */ import org.apache.tomcat.websocket.WsIOException;
/*     */ import org.apache.tomcat.websocket.WsSession;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WsFrameServer
/*     */   extends WsFrameBase
/*     */ {
/*  33 */   private static final Log log = LogFactory.getLog(WsFrameServer.class);
/*  34 */   private static final StringManager sm = StringManager.getManager(WsFrameServer.class);
/*     */   
/*     */   private final SocketWrapperBase<?> socketWrapper;
/*     */   
/*     */   private final ClassLoader applicationClassLoader;
/*     */   
/*     */   public WsFrameServer(SocketWrapperBase<?> socketWrapper, WsSession wsSession, Transformation transformation, ClassLoader applicationClassLoader)
/*     */   {
/*  42 */     super(wsSession, transformation);
/*  43 */     this.socketWrapper = socketWrapper;
/*  44 */     this.applicationClassLoader = applicationClassLoader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onDataAvailable()
/*     */     throws IOException
/*     */   {
/*  55 */     if (log.isDebugEnabled()) {
/*  56 */       log.debug("wsFrameServer.onDataAvailable");
/*     */     }
/*  58 */     while ((isOpen()) && (this.socketWrapper.isReadyForRead()))
/*     */     {
/*  60 */       int read = this.socketWrapper.read(false, this.inputBuffer, this.writePos, this.inputBuffer.length - this.writePos);
/*     */       
/*  62 */       if (read <= 0) {
/*  63 */         return;
/*     */       }
/*  65 */       if (log.isDebugEnabled()) {
/*  66 */         log.debug(sm.getString("wsFrameServer.bytesRead", new Object[] { Integer.toString(read) }));
/*     */       }
/*  68 */       this.writePos += read;
/*  69 */       processInputBuffer();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean isMasked()
/*     */   {
/*  77 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Transformation getTransformation()
/*     */   {
/*  84 */     return super.getTransformation();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean isOpen()
/*     */   {
/*  91 */     return super.isOpen();
/*     */   }
/*     */   
/*     */ 
/*     */   protected Log getLog()
/*     */   {
/*  97 */     return log;
/*     */   }
/*     */   
/*     */   protected void sendMessageText(boolean last)
/*     */     throws WsIOException
/*     */   {
/* 103 */     ClassLoader cl = Thread.currentThread().getContextClassLoader();
/*     */     try {
/* 105 */       Thread.currentThread().setContextClassLoader(this.applicationClassLoader);
/* 106 */       super.sendMessageText(last);
/*     */     } finally {
/* 108 */       Thread.currentThread().setContextClassLoader(cl);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void sendMessageBinary(ByteBuffer msg, boolean last)
/*     */     throws WsIOException
/*     */   {
/* 115 */     ClassLoader cl = Thread.currentThread().getContextClassLoader();
/*     */     try {
/* 117 */       Thread.currentThread().setContextClassLoader(this.applicationClassLoader);
/* 118 */       super.sendMessageBinary(msg, last);
/*     */     } finally {
/* 120 */       Thread.currentThread().setContextClassLoader(cl);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-websocket-8.5.4.jar!\org\apache\tomcat\websocket\server\WsFrameServer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */