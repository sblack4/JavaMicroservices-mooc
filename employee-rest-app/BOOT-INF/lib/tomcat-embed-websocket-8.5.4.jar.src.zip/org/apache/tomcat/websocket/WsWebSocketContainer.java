/*     */ package org.apache.tomcat.websocket;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Proxy;
/*     */ import java.net.Proxy.Type;
/*     */ import java.net.ProxySelector;
/*     */ import java.net.SocketAddress;
/*     */ import java.net.URI;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.AsynchronousChannelGroup;
/*     */ import java.nio.channels.AsynchronousSocketChannel;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.KeyStore;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLEngine;
/*     */ import javax.net.ssl.SSLException;
/*     */ import javax.net.ssl.TrustManagerFactory;
/*     */ import javax.websocket.ClientEndpoint;
/*     */ import javax.websocket.ClientEndpointConfig;
/*     */ import javax.websocket.ClientEndpointConfig.Builder;
/*     */ import javax.websocket.ClientEndpointConfig.Configurator;
/*     */ import javax.websocket.CloseReason;
/*     */ import javax.websocket.CloseReason.CloseCodes;
/*     */ import javax.websocket.DeploymentException;
/*     */ import javax.websocket.Endpoint;
/*     */ import javax.websocket.Extension;
/*     */ import javax.websocket.Extension.Parameter;
/*     */ import javax.websocket.HandshakeResponse;
/*     */ import javax.websocket.Session;
/*     */ import javax.websocket.WebSocketContainer;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.InstanceManager;
/*     */ import org.apache.tomcat.util.codec.binary.Base64;
/*     */ import org.apache.tomcat.util.collections.CaseInsensitiveKeyMap;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.websocket.pojo.PojoEndpointClient;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WsWebSocketContainer
/*     */   implements WebSocketContainer, BackgroundProcess
/*     */ {
/*  77 */   private static final StringManager sm = StringManager.getManager(WsWebSocketContainer.class);
/*  78 */   private static final Random random = new Random();
/*  79 */   private static final byte[] crlf = { 13, 10 };
/*     */   
/*  81 */   private static final byte[] GET_BYTES = "GET ".getBytes(StandardCharsets.ISO_8859_1);
/*  82 */   private static final byte[] ROOT_URI_BYTES = "/".getBytes(StandardCharsets.ISO_8859_1);
/*  83 */   private static final byte[] HTTP_VERSION_BYTES = " HTTP/1.1\r\n".getBytes(StandardCharsets.ISO_8859_1);
/*     */   private volatile AsynchronousChannelGroup asynchronousChannelGroup;
/*     */   
/*  86 */   public WsWebSocketContainer() { this.asynchronousChannelGroup = null;
/*  87 */     this.asynchronousChannelGroupLock = new Object();
/*     */     
/*  89 */     this.log = LogFactory.getLog(WsWebSocketContainer.class);
/*  90 */     this.endpointSessionMap = new HashMap();
/*     */     
/*  92 */     this.sessions = new ConcurrentHashMap();
/*  93 */     this.endPointSessionMapLock = new Object();
/*     */     
/*  95 */     this.defaultAsyncTimeout = -1L;
/*  96 */     this.maxBinaryMessageBufferSize = Constants.DEFAULT_BUFFER_SIZE;
/*  97 */     this.maxTextMessageBufferSize = Constants.DEFAULT_BUFFER_SIZE;
/*  98 */     this.defaultMaxSessionIdleTimeout = 0L;
/*  99 */     this.backgroundProcessCount = 0;
/* 100 */     this.processPeriod = Constants.DEFAULT_PROCESS_PERIOD;
/*     */   }
/*     */   
/*     */   InstanceManager getInstanceManager()
/*     */   {
/* 105 */     return this.instanceManager;
/*     */   }
/*     */   
/*     */   protected void setInstanceManager(InstanceManager instanceManager) {
/* 109 */     this.instanceManager = instanceManager;
/*     */   }
/*     */   
/*     */ 
/*     */   public Session connectToServer(Object pojo, URI path)
/*     */     throws DeploymentException
/*     */   {
/* 116 */     ClientEndpoint annotation = (ClientEndpoint)pojo.getClass().getAnnotation(ClientEndpoint.class);
/*     */     
/* 118 */     if (annotation == null) {
/* 119 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.missingAnnotation", new Object[] { pojo.getClass().getName() }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 124 */     Endpoint ep = new PojoEndpointClient(pojo, Arrays.asList(annotation.decoders()));
/*     */     
/* 126 */     Class<? extends ClientEndpointConfig.Configurator> configuratorClazz = annotation.configurator();
/*     */     
/*     */ 
/* 129 */     ClientEndpointConfig.Configurator configurator = null;
/* 130 */     if (!ClientEndpointConfig.Configurator.class.equals(configuratorClazz)) {
/*     */       try
/*     */       {
/* 133 */         configurator = (ClientEndpointConfig.Configurator)configuratorClazz.newInstance();
/*     */       } catch (InstantiationException|IllegalAccessException e) {
/* 135 */         throw new DeploymentException(sm.getString("wsWebSocketContainer.defaultConfiguratorFail"), e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 140 */     ClientEndpointConfig.Builder builder = ClientEndpointConfig.Builder.create();
/*     */     
/* 142 */     if (configurator != null) {
/* 143 */       builder.configurator(configurator);
/*     */     }
/* 145 */     ClientEndpointConfig config = builder.decoders(Arrays.asList(annotation.decoders())).encoders(Arrays.asList(annotation.encoders())).preferredSubprotocols(Arrays.asList(annotation.subprotocols())).build();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 150 */     return connectToServer(ep, config, path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Session connectToServer(Class<?> annotatedEndpointClass, URI path)
/*     */     throws DeploymentException
/*     */   {
/*     */     try
/*     */     {
/* 160 */       pojo = annotatedEndpointClass.newInstance();
/*     */     } catch (InstantiationException|IllegalAccessException e) { Object pojo;
/* 162 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.endpointCreateFail", new Object[] { annotatedEndpointClass.getName() }), e);
/*     */     }
/*     */     
/*     */     Object pojo;
/*     */     
/* 167 */     return connectToServer(pojo, path);
/*     */   }
/*     */   
/*     */ 
/*     */   private final Object asynchronousChannelGroupLock;
/*     */   private final Log log;
/*     */   public Session connectToServer(Class<? extends Endpoint> clazz, ClientEndpointConfig clientEndpointConfiguration, URI path)
/*     */     throws DeploymentException
/*     */   {
/*     */     try
/*     */     {
/* 178 */       endpoint = (Endpoint)clazz.newInstance();
/*     */     } catch (InstantiationException|IllegalAccessException e) { Endpoint endpoint;
/* 180 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.endpointCreateFail", new Object[] { clazz.getName() }), e);
/*     */     }
/*     */     
/*     */     Endpoint endpoint;
/*     */     
/* 185 */     return connectToServer(endpoint, clientEndpointConfiguration, path);
/*     */   }
/*     */   
/*     */ 
/*     */   private final Map<Endpoint, Set<WsSession>> endpointSessionMap;
/*     */   private final Map<WsSession, WsSession> sessions;
/*     */   private final Object endPointSessionMapLock;
/*     */   public Session connectToServer(Endpoint endpoint, ClientEndpointConfig clientEndpointConfiguration, URI path)
/*     */     throws DeploymentException
/*     */   {
/* 195 */     boolean secure = false;
/* 196 */     ByteBuffer proxyConnect = null;
/*     */     
/*     */ 
/*     */ 
/* 200 */     String scheme = path.getScheme();
/* 201 */     URI proxyPath; if ("ws".equalsIgnoreCase(scheme)) {
/* 202 */       proxyPath = URI.create("http" + path.toString().substring(2));
/* 203 */     } else if ("wss".equalsIgnoreCase(scheme)) {
/* 204 */       URI proxyPath = URI.create("https" + path.toString().substring(3));
/* 205 */       secure = true;
/*     */     } else {
/* 207 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.pathWrongScheme", new Object[] { scheme }));
/*     */     }
/*     */     
/*     */     URI proxyPath;
/*     */     
/* 212 */     String host = path.getHost();
/* 213 */     if (host == null) {
/* 214 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.pathNoHost"));
/*     */     }
/*     */     
/* 217 */     int port = path.getPort();
/*     */     
/* 219 */     SocketAddress sa = null;
/*     */     
/*     */ 
/*     */ 
/* 223 */     List<Proxy> proxies = ProxySelector.getDefault().select(proxyPath);
/* 224 */     Proxy selectedProxy = null;
/* 225 */     for (Proxy proxy : proxies) {
/* 226 */       if (proxy.type().equals(Proxy.Type.HTTP)) {
/* 227 */         sa = proxy.address();
/* 228 */         if ((sa instanceof InetSocketAddress)) {
/* 229 */           InetSocketAddress inet = (InetSocketAddress)sa;
/* 230 */           if (inet.isUnresolved()) {
/* 231 */             sa = new InetSocketAddress(inet.getHostName(), inet.getPort());
/*     */           }
/*     */         }
/* 234 */         selectedProxy = proxy;
/* 235 */         break;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 240 */     if (sa == null) {
/* 241 */       if (port == -1) {
/* 242 */         if ("ws".equalsIgnoreCase(scheme)) {
/* 243 */           sa = new InetSocketAddress(host, 80);
/*     */         }
/*     */         else {
/* 246 */           sa = new InetSocketAddress(host, 443);
/*     */         }
/*     */       } else {
/* 249 */         sa = new InetSocketAddress(host, port);
/*     */       }
/*     */     } else {
/* 252 */       proxyConnect = createProxyRequest(host, port);
/*     */     }
/*     */     
/*     */ 
/* 256 */     Map<String, List<String>> reqHeaders = createRequestHeaders(host, port, clientEndpointConfiguration.getPreferredSubprotocols(), clientEndpointConfiguration.getExtensions());
/*     */     
/*     */ 
/* 259 */     clientEndpointConfiguration.getConfigurator().beforeRequest(reqHeaders);
/*     */     
/* 261 */     if ((Constants.DEFAULT_ORIGIN_HEADER_VALUE != null) && (!reqHeaders.containsKey("Origin")))
/*     */     {
/* 263 */       List<String> originValues = new ArrayList(1);
/* 264 */       originValues.add(Constants.DEFAULT_ORIGIN_HEADER_VALUE);
/* 265 */       reqHeaders.put("Origin", originValues);
/*     */     }
/* 267 */     ByteBuffer request = createRequest(path, reqHeaders);
/*     */     
/*     */     try
/*     */     {
/* 271 */       socketChannel = AsynchronousSocketChannel.open(getAsynchronousChannelGroup());
/*     */     } catch (IOException ioe) { AsynchronousSocketChannel socketChannel;
/* 273 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.asynchronousSocketChannelFail"), ioe);
/*     */     }
/*     */     
/*     */     AsynchronousSocketChannel socketChannel;
/*     */     
/* 278 */     long timeout = 5000L;
/* 279 */     String timeoutValue = (String)clientEndpointConfiguration.getUserProperties().get("org.apache.tomcat.websocket.IO_TIMEOUT_MS");
/*     */     
/* 281 */     if (timeoutValue != null) {
/* 282 */       timeout = Long.valueOf(timeoutValue).intValue();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 287 */     ByteBuffer response = ByteBuffer.allocate(this.maxBinaryMessageBufferSize);
/*     */     
/* 289 */     boolean success = false;
/* 290 */     List<Extension> extensionsAgreed = new ArrayList();
/* 291 */     Transformation transformation = null;
/*     */     
/*     */ 
/* 294 */     Future<Void> fConnect = socketChannel.connect(sa);
/* 295 */     AsyncChannelWrapper channel = null;
/*     */     
/* 297 */     if (proxyConnect != null) {
/*     */       try {
/* 299 */         fConnect.get(timeout, TimeUnit.MILLISECONDS);
/*     */         
/* 301 */         channel = new AsyncChannelWrapperNonSecure(socketChannel);
/* 302 */         writeRequest(channel, proxyConnect, timeout);
/* 303 */         HttpResponse httpResponse = processResponse(response, channel, timeout);
/* 304 */         if (httpResponse.getStatus() != 200) {
/* 305 */           throw new DeploymentException(sm.getString("wsWebSocketContainer.proxyConnectFail", new Object[] { selectedProxy, Integer.toString(httpResponse.getStatus()) }));
/*     */         }
/*     */         
/*     */       }
/*     */       catch (TimeoutException|InterruptedException|ExecutionException|EOFException e)
/*     */       {
/* 311 */         if (channel != null) {
/* 312 */           channel.close();
/*     */         }
/* 314 */         throw new DeploymentException(sm.getString("wsWebSocketContainer.httpRequestFailed"), e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 319 */     if (secure)
/*     */     {
/*     */ 
/*     */ 
/* 323 */       SSLEngine sslEngine = createSSLEngine(clientEndpointConfiguration.getUserProperties());
/*     */       
/* 325 */       channel = new AsyncChannelWrapperSecure(socketChannel, sslEngine);
/* 326 */     } else if (channel == null)
/*     */     {
/*     */ 
/* 329 */       channel = new AsyncChannelWrapperNonSecure(socketChannel);
/*     */     }
/*     */     try
/*     */     {
/* 333 */       fConnect.get(timeout, TimeUnit.MILLISECONDS);
/*     */       
/* 335 */       Future<Void> fHandshake = channel.handshake();
/* 336 */       fHandshake.get(timeout, TimeUnit.MILLISECONDS);
/*     */       
/* 338 */       writeRequest(channel, request, timeout);
/*     */       
/* 340 */       HttpResponse httpResponse = processResponse(response, channel, timeout);
/*     */       
/* 342 */       if (httpResponse.status != 101) {
/* 343 */         throw new DeploymentException(sm.getString("wsWebSocketContainer.invalidStatus", new Object[] { Integer.toString(httpResponse.status) }));
/*     */       }
/*     */       
/* 346 */       HandshakeResponse handshakeResponse = httpResponse.getHandshakeResponse();
/* 347 */       clientEndpointConfiguration.getConfigurator().afterResponse(handshakeResponse);
/*     */       
/*     */ 
/* 350 */       List<String> protocolHeaders = (List)handshakeResponse.getHeaders().get("Sec-WebSocket-Protocol");
/*     */       String subProtocol;
/* 352 */       if ((protocolHeaders == null) || (protocolHeaders.size() == 0)) {
/* 353 */         subProtocol = null; } else { String subProtocol;
/* 354 */         if (protocolHeaders.size() == 1) {
/* 355 */           subProtocol = (String)protocolHeaders.get(0);
/*     */         } else {
/* 357 */           throw new DeploymentException(sm.getString("wsWebSocketContainer.invalidSubProtocol"));
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */       String subProtocol;
/*     */       
/* 364 */       List<String> extHeaders = (List)handshakeResponse.getHeaders().get("Sec-WebSocket-Extensions");
/*     */       
/* 366 */       if (extHeaders != null) {
/* 367 */         for (String extHeader : extHeaders) {
/* 368 */           Util.parseExtensionHeader(extensionsAgreed, extHeader);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 373 */       TransformationFactory factory = TransformationFactory.getInstance();
/* 374 */       for (Extension extension : extensionsAgreed) {
/* 375 */         List<List<Extension.Parameter>> wrapper = new ArrayList(1);
/* 376 */         wrapper.add(extension.getParameters());
/* 377 */         Transformation t = factory.create(extension.getName(), wrapper, false);
/* 378 */         if (t == null) {
/* 379 */           throw new DeploymentException(sm.getString("wsWebSocketContainer.invalidExtensionParameters"));
/*     */         }
/*     */         
/* 382 */         if (transformation == null) {
/* 383 */           transformation = t;
/*     */         } else {
/* 385 */           transformation.setNext(t);
/*     */         }
/*     */       }
/*     */       
/* 389 */       success = true;
/*     */     }
/*     */     catch (ExecutionException|InterruptedException|SSLException|EOFException|TimeoutException e) {
/* 392 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.httpRequestFailed"), e);
/*     */     }
/*     */     finally {
/* 395 */       if (!success) {
/* 396 */         channel.close();
/*     */       }
/*     */     }
/*     */     
/*     */     String subProtocol;
/* 401 */     WsRemoteEndpointImplClient wsRemoteEndpointClient = new WsRemoteEndpointImplClient(channel);
/*     */     
/* 403 */     WsSession wsSession = new WsSession(endpoint, wsRemoteEndpointClient, this, null, null, null, null, null, extensionsAgreed, subProtocol, Collections.emptyMap(), secure, clientEndpointConfiguration);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 408 */     WsFrameClient wsFrameClient = new WsFrameClient(response, channel, wsSession, transformation);
/*     */     
/*     */ 
/*     */ 
/* 412 */     wsRemoteEndpointClient.setTransformation(wsFrameClient.getTransformation());
/*     */     
/* 414 */     endpoint.onOpen(wsSession, clientEndpointConfiguration);
/* 415 */     registerSession(endpoint, wsSession);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 427 */     wsFrameClient.startInputProcessing();
/*     */     
/* 429 */     return wsSession;
/*     */   }
/*     */   
/*     */   private static void writeRequest(AsyncChannelWrapper channel, ByteBuffer request, long timeout)
/*     */     throws TimeoutException, InterruptedException, ExecutionException
/*     */   {
/* 435 */     int toWrite = request.limit();
/*     */     
/* 437 */     Future<Integer> fWrite = channel.write(request);
/* 438 */     Integer thisWrite = (Integer)fWrite.get(timeout, TimeUnit.MILLISECONDS);
/* 439 */     toWrite -= thisWrite.intValue();
/*     */     
/* 441 */     while (toWrite > 0) {
/* 442 */       fWrite = channel.write(request);
/* 443 */       thisWrite = (Integer)fWrite.get(timeout, TimeUnit.MILLISECONDS);
/* 444 */       toWrite -= thisWrite.intValue();
/*     */     }
/*     */   }
/*     */   
/*     */   private static ByteBuffer createProxyRequest(String host, int port)
/*     */   {
/* 450 */     StringBuilder request = new StringBuilder();
/* 451 */     request.append("CONNECT ");
/* 452 */     request.append(host);
/* 453 */     if (port != -1) {
/* 454 */       request.append(':');
/* 455 */       request.append(port);
/*     */     }
/* 457 */     request.append(" HTTP/1.1\r\nProxy-Connection: keep-alive\r\nConnection: keepalive\r\nHost: ");
/* 458 */     request.append(host);
/* 459 */     if (port != -1) {
/* 460 */       request.append(':');
/* 461 */       request.append(port);
/*     */     }
/* 463 */     request.append("\r\n\r\n");
/*     */     
/* 465 */     byte[] bytes = request.toString().getBytes(StandardCharsets.ISO_8859_1);
/* 466 */     return ByteBuffer.wrap(bytes);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void registerSession(Endpoint endpoint, WsSession wsSession)
/*     */   {
/* 472 */     if (!wsSession.isOpen())
/*     */     {
/* 474 */       return;
/*     */     }
/* 476 */     synchronized (this.endPointSessionMapLock) {
/* 477 */       if (this.endpointSessionMap.size() == 0) {
/* 478 */         BackgroundProcessManager.getInstance().register(this);
/*     */       }
/* 480 */       Set<WsSession> wsSessions = (Set)this.endpointSessionMap.get(endpoint);
/* 481 */       if (wsSessions == null) {
/* 482 */         wsSessions = new HashSet();
/* 483 */         this.endpointSessionMap.put(endpoint, wsSessions);
/*     */       }
/* 485 */       wsSessions.add(wsSession);
/*     */     }
/* 487 */     this.sessions.put(wsSession, wsSession);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void unregisterSession(Endpoint endpoint, WsSession wsSession)
/*     */   {
/* 493 */     synchronized (this.endPointSessionMapLock) {
/* 494 */       Set<WsSession> wsSessions = (Set)this.endpointSessionMap.get(endpoint);
/* 495 */       if (wsSessions != null) {
/* 496 */         wsSessions.remove(wsSession);
/* 497 */         if (wsSessions.size() == 0) {
/* 498 */           this.endpointSessionMap.remove(endpoint);
/*     */         }
/*     */       }
/* 501 */       if (this.endpointSessionMap.size() == 0) {
/* 502 */         BackgroundProcessManager.getInstance().unregister(this);
/*     */       }
/*     */     }
/* 505 */     this.sessions.remove(wsSession);
/*     */   }
/*     */   
/*     */   Set<Session> getOpenSessions(Endpoint endpoint)
/*     */   {
/* 510 */     HashSet<Session> result = new HashSet();
/* 511 */     synchronized (this.endPointSessionMapLock) {
/* 512 */       Set<WsSession> sessions = (Set)this.endpointSessionMap.get(endpoint);
/* 513 */       if (sessions != null) {
/* 514 */         result.addAll(sessions);
/*     */       }
/*     */     }
/* 517 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   private static Map<String, List<String>> createRequestHeaders(String host, int port, List<String> subProtocols, List<Extension> extensions)
/*     */   {
/* 523 */     Map<String, List<String>> headers = new HashMap();
/*     */     
/*     */ 
/* 526 */     List<String> hostValues = new ArrayList(1);
/* 527 */     if (port == -1) {
/* 528 */       hostValues.add(host);
/*     */     } else {
/* 530 */       hostValues.add(host + ':' + port);
/*     */     }
/*     */     
/* 533 */     headers.put("Host", hostValues);
/*     */     
/*     */ 
/* 536 */     List<String> upgradeValues = new ArrayList(1);
/* 537 */     upgradeValues.add("websocket");
/* 538 */     headers.put("Upgrade", upgradeValues);
/*     */     
/*     */ 
/* 541 */     List<String> connectionValues = new ArrayList(1);
/* 542 */     connectionValues.add("upgrade");
/* 543 */     headers.put("Connection", connectionValues);
/*     */     
/*     */ 
/* 546 */     List<String> wsVersionValues = new ArrayList(1);
/* 547 */     wsVersionValues.add("13");
/* 548 */     headers.put("Sec-WebSocket-Version", wsVersionValues);
/*     */     
/*     */ 
/* 551 */     List<String> wsKeyValues = new ArrayList(1);
/* 552 */     wsKeyValues.add(generateWsKeyValue());
/* 553 */     headers.put("Sec-WebSocket-Key", wsKeyValues);
/*     */     
/*     */ 
/* 556 */     if ((subProtocols != null) && (subProtocols.size() > 0)) {
/* 557 */       headers.put("Sec-WebSocket-Protocol", subProtocols);
/*     */     }
/*     */     
/*     */ 
/* 561 */     if ((extensions != null) && (extensions.size() > 0)) {
/* 562 */       headers.put("Sec-WebSocket-Extensions", generateExtensionHeaders(extensions));
/*     */     }
/*     */     
/*     */ 
/* 566 */     return headers;
/*     */   }
/*     */   
/*     */   private static List<String> generateExtensionHeaders(List<Extension> extensions)
/*     */   {
/* 571 */     List<String> result = new ArrayList(extensions.size());
/* 572 */     for (Extension extension : extensions) {
/* 573 */       StringBuilder header = new StringBuilder();
/* 574 */       header.append(extension.getName());
/* 575 */       for (Extension.Parameter param : extension.getParameters()) {
/* 576 */         header.append(';');
/* 577 */         header.append(param.getName());
/* 578 */         String value = param.getValue();
/* 579 */         if ((value != null) && (value.length() > 0)) {
/* 580 */           header.append('=');
/* 581 */           header.append(value);
/*     */         }
/*     */       }
/* 584 */       result.add(header.toString());
/*     */     }
/* 586 */     return result;
/*     */   }
/*     */   
/*     */   private static String generateWsKeyValue()
/*     */   {
/* 591 */     byte[] keyBytes = new byte[16];
/* 592 */     random.nextBytes(keyBytes);
/* 593 */     return Base64.encodeBase64String(keyBytes);
/*     */   }
/*     */   
/*     */   private static ByteBuffer createRequest(URI uri, Map<String, List<String>> reqHeaders)
/*     */   {
/* 598 */     ByteBuffer result = ByteBuffer.allocate(4096);
/*     */     
/*     */ 
/* 601 */     result.put(GET_BYTES);
/* 602 */     if ((null == uri.getPath()) || ("".equals(uri.getPath()))) {
/* 603 */       result.put(ROOT_URI_BYTES);
/*     */     } else {
/* 605 */       result.put(uri.getRawPath().getBytes(StandardCharsets.ISO_8859_1));
/*     */     }
/* 607 */     String query = uri.getRawQuery();
/* 608 */     if (query != null) {
/* 609 */       result.put((byte)63);
/* 610 */       result.put(query.getBytes(StandardCharsets.ISO_8859_1));
/*     */     }
/* 612 */     result.put(HTTP_VERSION_BYTES);
/*     */     
/*     */ 
/* 615 */     Iterator<Map.Entry<String, List<String>>> iter = reqHeaders.entrySet().iterator();
/* 616 */     while (iter.hasNext()) {
/* 617 */       Map.Entry<String, List<String>> entry = (Map.Entry)iter.next();
/* 618 */       addHeader(result, (String)entry.getKey(), (List)entry.getValue());
/*     */     }
/*     */     
/*     */ 
/* 622 */     result.put(crlf);
/*     */     
/* 624 */     result.flip();
/*     */     
/* 626 */     return result;
/*     */   }
/*     */   
/*     */   private static void addHeader(ByteBuffer result, String key, List<String> values)
/*     */   {
/* 631 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 633 */     Iterator<String> iter = values.iterator();
/* 634 */     if (!iter.hasNext()) {
/* 635 */       return;
/*     */     }
/* 637 */     sb.append((String)iter.next());
/* 638 */     while (iter.hasNext()) {
/* 639 */       sb.append(',');
/* 640 */       sb.append((String)iter.next());
/*     */     }
/*     */     
/* 643 */     result.put(key.getBytes(StandardCharsets.ISO_8859_1));
/* 644 */     result.put(": ".getBytes(StandardCharsets.ISO_8859_1));
/* 645 */     result.put(sb.toString().getBytes(StandardCharsets.ISO_8859_1));
/* 646 */     result.put(crlf);
/*     */   }
/*     */   
/*     */ 
/*     */   private long defaultAsyncTimeout;
/*     */   
/*     */   private int maxBinaryMessageBufferSize;
/*     */   
/*     */   private int maxTextMessageBufferSize;
/*     */   private volatile long defaultMaxSessionIdleTimeout;
/*     */   private int backgroundProcessCount;
/*     */   private int processPeriod;
/*     */   private InstanceManager instanceManager;
/*     */   private HttpResponse processResponse(ByteBuffer response, AsyncChannelWrapper channel, long timeout)
/*     */     throws InterruptedException, ExecutionException, DeploymentException, EOFException, TimeoutException
/*     */   {
/* 662 */     Map<String, List<String>> headers = new CaseInsensitiveKeyMap();
/*     */     
/* 664 */     int status = 0;
/* 665 */     boolean readStatus = false;
/* 666 */     boolean readHeaders = false;
/* 667 */     String line = null;
/* 668 */     for (; !readHeaders; 
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 694 */         goto 78)
/*     */     {
/* 671 */       response.clear();
/*     */       
/* 673 */       Future<Integer> read = channel.read(response);
/* 674 */       Integer bytesRead = (Integer)read.get(timeout, TimeUnit.MILLISECONDS);
/* 675 */       if (bytesRead.intValue() == -1) {
/* 676 */         throw new EOFException();
/*     */       }
/* 678 */       response.flip();
/* 679 */       while ((response.hasRemaining()) && (!readHeaders)) {
/* 680 */         if (line == null) {
/* 681 */           line = readLine(response);
/*     */         } else {
/* 683 */           line = line + readLine(response);
/*     */         }
/* 685 */         if ("\r\n".equals(line)) {
/* 686 */           readHeaders = true;
/* 687 */         } else if (line.endsWith("\r\n")) {
/* 688 */           if (readStatus) {
/* 689 */             parseHeaders(line, headers);
/*     */           } else {
/* 691 */             status = parseStatus(line);
/* 692 */             readStatus = true;
/*     */           }
/* 694 */           line = null;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 699 */     return new HttpResponse(status, new WsHandshakeResponse(headers));
/*     */   }
/*     */   
/*     */ 
/*     */   private int parseStatus(String line)
/*     */     throws DeploymentException
/*     */   {
/* 706 */     String[] parts = line.trim().split(" ");
/*     */     
/* 708 */     if ((parts.length < 2) || ((!"HTTP/1.0".equals(parts[0])) && (!"HTTP/1.1".equals(parts[0])))) {
/* 709 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.invalidStatus", new Object[] { line }));
/*     */     }
/*     */     try
/*     */     {
/* 713 */       return Integer.parseInt(parts[1]);
/*     */     } catch (NumberFormatException nfe) {
/* 715 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.invalidStatus", new Object[] { line }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void parseHeaders(String line, Map<String, List<String>> headers)
/*     */   {
/* 724 */     int index = line.indexOf(':');
/* 725 */     if (index == -1) {
/* 726 */       this.log.warn(sm.getString("wsWebSocketContainer.invalidHeader", new Object[] { line }));
/* 727 */       return;
/*     */     }
/*     */     
/* 730 */     String headerName = line.substring(0, index).trim().toLowerCase(Locale.ENGLISH);
/*     */     
/*     */ 
/* 733 */     String headerValue = line.substring(index + 1).trim();
/*     */     
/* 735 */     List<String> values = (List)headers.get(headerName);
/* 736 */     if (values == null) {
/* 737 */       values = new ArrayList(1);
/* 738 */       headers.put(headerName, values);
/*     */     }
/* 740 */     values.add(headerValue);
/*     */   }
/*     */   
/*     */   private String readLine(ByteBuffer response)
/*     */   {
/* 745 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 747 */     char c = '\000';
/* 748 */     while (response.hasRemaining()) {
/* 749 */       c = (char)response.get();
/* 750 */       sb.append(c);
/* 751 */       if (c == '\n') {
/*     */         break;
/*     */       }
/*     */     }
/*     */     
/* 756 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   private SSLEngine createSSLEngine(Map<String, Object> userProperties)
/*     */     throws DeploymentException
/*     */   {
/*     */     try
/*     */     {
/* 765 */       SSLContext sslContext = (SSLContext)userProperties.get("org.apache.tomcat.websocket.SSL_CONTEXT");
/*     */       
/*     */ 
/* 768 */       if (sslContext == null)
/*     */       {
/* 770 */         sslContext = SSLContext.getInstance("TLS");
/*     */         
/*     */ 
/* 773 */         String sslTrustStoreValue = (String)userProperties.get("org.apache.tomcat.websocket.SSL_TRUSTSTORE");
/*     */         
/* 775 */         if (sslTrustStoreValue != null) {
/* 776 */           String sslTrustStorePwdValue = (String)userProperties.get("org.apache.tomcat.websocket.SSL_TRUSTSTORE_PWD");
/*     */           
/* 778 */           if (sslTrustStorePwdValue == null) {
/* 779 */             sslTrustStorePwdValue = "changeit";
/*     */           }
/*     */           
/* 782 */           File keyStoreFile = new File(sslTrustStoreValue);
/* 783 */           KeyStore ks = KeyStore.getInstance("JKS");
/* 784 */           InputStream is = new FileInputStream(keyStoreFile);Throwable localThrowable2 = null;
/* 785 */           try { ks.load(is, sslTrustStorePwdValue.toCharArray());
/*     */           }
/*     */           catch (Throwable localThrowable1)
/*     */           {
/* 784 */             localThrowable2 = localThrowable1;throw localThrowable1;
/*     */           } finally {
/* 786 */             if (is != null) if (localThrowable2 != null) try { is.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else is.close();
/*     */           }
/* 788 */           TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
/*     */           
/* 790 */           tmf.init(ks);
/*     */           
/* 792 */           sslContext.init(null, tmf.getTrustManagers(), null);
/*     */         } else {
/* 794 */           sslContext.init(null, null, null);
/*     */         }
/*     */       }
/*     */       
/* 798 */       SSLEngine engine = sslContext.createSSLEngine();
/*     */       
/* 800 */       String sslProtocolsValue = (String)userProperties.get("org.apache.tomcat.websocket.SSL_PROTOCOLS");
/*     */       
/* 802 */       if (sslProtocolsValue != null) {
/* 803 */         engine.setEnabledProtocols(sslProtocolsValue.split(","));
/*     */       }
/*     */       
/* 806 */       engine.setUseClientMode(true);
/*     */       
/* 808 */       return engine;
/*     */     } catch (Exception e) {
/* 810 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.sslEngineFail"), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public long getDefaultMaxSessionIdleTimeout()
/*     */   {
/* 818 */     return this.defaultMaxSessionIdleTimeout;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setDefaultMaxSessionIdleTimeout(long timeout)
/*     */   {
/* 824 */     this.defaultMaxSessionIdleTimeout = timeout;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getDefaultMaxBinaryMessageBufferSize()
/*     */   {
/* 830 */     return this.maxBinaryMessageBufferSize;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setDefaultMaxBinaryMessageBufferSize(int max)
/*     */   {
/* 836 */     this.maxBinaryMessageBufferSize = max;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getDefaultMaxTextMessageBufferSize()
/*     */   {
/* 842 */     return this.maxTextMessageBufferSize;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setDefaultMaxTextMessageBufferSize(int max)
/*     */   {
/* 848 */     this.maxTextMessageBufferSize = max;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<Extension> getInstalledExtensions()
/*     */   {
/* 859 */     return Collections.emptySet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getDefaultAsyncSendTimeout()
/*     */   {
/* 870 */     return this.defaultAsyncTimeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAsyncSendTimeout(long timeout)
/*     */   {
/* 881 */     this.defaultAsyncTimeout = timeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 891 */     CloseReason cr = new CloseReason(CloseReason.CloseCodes.GOING_AWAY, sm.getString("wsWebSocketContainer.shutdown"));
/*     */     
/*     */ 
/* 894 */     for (WsSession session : this.sessions.keySet()) {
/*     */       try {
/* 896 */         session.close(cr);
/*     */       } catch (IOException ioe) {
/* 898 */         this.log.debug(sm.getString("wsWebSocketContainer.sessionCloseFail", new Object[] { session.getId() }), ioe);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 905 */     if (this.asynchronousChannelGroup != null) {
/* 906 */       synchronized (this.asynchronousChannelGroupLock) {
/* 907 */         if (this.asynchronousChannelGroup != null) {
/* 908 */           AsyncChannelGroupUtil.unregister();
/* 909 */           this.asynchronousChannelGroup = null;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private AsynchronousChannelGroup getAsynchronousChannelGroup()
/*     */   {
/* 919 */     AsynchronousChannelGroup result = this.asynchronousChannelGroup;
/* 920 */     if (result == null) {
/* 921 */       synchronized (this.asynchronousChannelGroupLock) {
/* 922 */         if (this.asynchronousChannelGroup == null) {
/* 923 */           this.asynchronousChannelGroup = AsyncChannelGroupUtil.register();
/*     */         }
/* 925 */         result = this.asynchronousChannelGroup;
/*     */       }
/*     */     }
/* 928 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void backgroundProcess()
/*     */   {
/* 937 */     this.backgroundProcessCount += 1;
/* 938 */     if (this.backgroundProcessCount >= this.processPeriod) {
/* 939 */       this.backgroundProcessCount = 0;
/*     */       
/* 941 */       for (WsSession wsSession : this.sessions.keySet()) {
/* 942 */         wsSession.checkExpiration();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setProcessPeriod(int period)
/*     */   {
/* 951 */     this.processPeriod = period;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getProcessPeriod()
/*     */   {
/* 963 */     return this.processPeriod;
/*     */   }
/*     */   
/*     */   private static class HttpResponse
/*     */   {
/*     */     private final int status;
/*     */     private final HandshakeResponse handshakeResponse;
/*     */     
/*     */     public HttpResponse(int status, HandshakeResponse handshakeResponse) {
/* 972 */       this.status = status;
/* 973 */       this.handshakeResponse = handshakeResponse;
/*     */     }
/*     */     
/*     */     public int getStatus()
/*     */     {
/* 978 */       return this.status;
/*     */     }
/*     */     
/*     */     public HandshakeResponse getHandshakeResponse()
/*     */     {
/* 983 */       return this.handshakeResponse;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-websocket-8.5.4.jar!\org\apache\tomcat\websocket\WsWebSocketContainer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */