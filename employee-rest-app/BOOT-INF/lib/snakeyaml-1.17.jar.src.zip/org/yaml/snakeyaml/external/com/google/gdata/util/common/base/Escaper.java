package org.yaml.snakeyaml.external.com.google.gdata.util.common.base;

public abstract interface Escaper
{
  public abstract String escape(String paramString);
  
  public abstract Appendable escape(Appendable paramAppendable);
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\snakeyaml-1.17.jar!\org\yaml\snakeyaml\external\com\google\gdata\util\common\base\Escaper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */