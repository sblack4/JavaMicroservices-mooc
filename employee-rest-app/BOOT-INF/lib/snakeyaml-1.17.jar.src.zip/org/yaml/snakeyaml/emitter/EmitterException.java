/*    */ package org.yaml.snakeyaml.emitter;
/*    */ 
/*    */ import org.yaml.snakeyaml.error.YAMLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmitterException
/*    */   extends YAMLException
/*    */ {
/*    */   private static final long serialVersionUID = -8280070025452995908L;
/*    */   
/*    */   public EmitterException(String msg)
/*    */   {
/* 24 */     super(msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\snakeyaml-1.17.jar!\org\yaml\snakeyaml\emitter\EmitterException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */