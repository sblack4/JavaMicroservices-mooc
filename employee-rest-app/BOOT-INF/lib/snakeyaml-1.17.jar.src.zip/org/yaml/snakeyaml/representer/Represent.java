package org.yaml.snakeyaml.representer;

import org.yaml.snakeyaml.nodes.Node;

public abstract interface Represent
{
  public abstract Node representData(Object paramObject);
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\snakeyaml-1.17.jar!\org\yaml\snakeyaml\representer\Represent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */