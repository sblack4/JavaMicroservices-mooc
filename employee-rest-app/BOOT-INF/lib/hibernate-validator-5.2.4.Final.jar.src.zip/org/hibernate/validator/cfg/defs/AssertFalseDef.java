/*    */ package org.hibernate.validator.cfg.defs;
/*    */ 
/*    */ import javax.validation.constraints.AssertFalse;
/*    */ import org.hibernate.validator.cfg.ConstraintDef;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AssertFalseDef
/*    */   extends ConstraintDef<AssertFalseDef, AssertFalse>
/*    */ {
/*    */   public AssertFalseDef()
/*    */   {
/* 19 */     super(AssertFalse.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\cfg\defs\AssertFalseDef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */