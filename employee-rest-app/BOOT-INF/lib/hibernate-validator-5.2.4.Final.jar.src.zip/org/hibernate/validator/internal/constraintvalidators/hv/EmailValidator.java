/*     */ package org.hibernate.validator.internal.constraintvalidators.hv;
/*     */ 
/*     */ import java.net.IDN;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.validation.ConstraintValidator;
/*     */ import javax.validation.ConstraintValidatorContext;
/*     */ import org.hibernate.validator.constraints.Email;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EmailValidator
/*     */   implements ConstraintValidator<Email, CharSequence>
/*     */ {
/*     */   private static final String ATOM = "[a-z0-9!#$%&'*+/=?^_`{|}~-]";
/*     */   private static final String DOMAIN = "[a-z0-9!#$%&'*+/=?^_`{|}~-]+(\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*";
/*     */   private static final String IP_DOMAIN = "\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\]";
/*     */   private static final int MAX_LOCAL_PART_LENGTH = 64;
/*     */   private static final int MAX_DOMAIN_PART_LENGTH = 255;
/*  43 */   private final Pattern localPattern = Pattern.compile("[a-z0-9!#$%&'*+/=?^_`{|}~-]+(\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*", 2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  50 */   private final Pattern domainPattern = Pattern.compile("[a-z0-9!#$%&'*+/=?^_`{|}~-]+(\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\]", 2);
/*     */   
/*     */ 
/*     */ 
/*     */   public void initialize(Email annotation) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isValid(CharSequence value, ConstraintValidatorContext context)
/*     */   {
/*  60 */     if ((value == null) || (value.length() == 0)) {
/*  61 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  68 */     String[] emailParts = value.toString().split("@", 3);
/*  69 */     if (emailParts.length != 2) {
/*  70 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  76 */     if ((emailParts[0].endsWith(".")) || (emailParts[1].endsWith("."))) {
/*  77 */       return false;
/*     */     }
/*     */     
/*  80 */     if (!matchPart(emailParts[0], this.localPattern, 64)) {
/*  81 */       return false;
/*     */     }
/*     */     
/*  84 */     return matchPart(emailParts[1], this.domainPattern, 255);
/*     */   }
/*     */   
/*     */   private boolean matchPart(String part, Pattern pattern, int maxLength)
/*     */   {
/*     */     try {
/*  90 */       asciiString = toAscii(part);
/*     */     } catch (IllegalArgumentException e) {
/*     */       String asciiString;
/*  93 */       return false;
/*     */     }
/*     */     String asciiString;
/*  96 */     if (asciiString.length() > maxLength) {
/*  97 */       return false;
/*     */     }
/*     */     
/* 100 */     Matcher matcher = pattern.matcher(asciiString);
/* 101 */     return matcher.matches();
/*     */   }
/*     */   
/*     */   private String toAscii(String unicodeString) throws IllegalArgumentException {
/* 105 */     String asciiString = "";
/* 106 */     int start = 0;
/* 107 */     int end = unicodeString.length() <= 63 ? unicodeString.length() : 63;
/*     */     for (;;)
/*     */     {
/* 110 */       asciiString = asciiString + IDN.toASCII(unicodeString.substring(start, end));
/* 111 */       if (end == unicodeString.length()) {
/*     */         break;
/*     */       }
/* 114 */       start = end;
/* 115 */       end = start + 63 > unicodeString.length() ? unicodeString.length() : start + 63;
/*     */     }
/*     */     
/* 118 */     return asciiString;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\constraintvalidators\hv\EmailValidator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */