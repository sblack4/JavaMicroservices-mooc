/*    */ package org.hibernate.validator.internal.cfg.context;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.hibernate.validator.cfg.context.TypeConstraintMappingContext;
/*    */ import org.hibernate.validator.internal.metadata.core.ConstraintHelper;
/*    */ import org.hibernate.validator.internal.metadata.core.MetaConstraint;
/*    */ import org.hibernate.validator.internal.metadata.descriptor.ConstraintDescriptorImpl;
/*    */ import org.hibernate.validator.internal.metadata.descriptor.ConstraintDescriptorImpl.ConstraintType;
/*    */ import org.hibernate.validator.internal.metadata.location.ConstraintLocation;
/*    */ import org.hibernate.validator.internal.util.CollectionHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class ConstraintMappingContextImplBase
/*    */ {
/*    */   protected final DefaultConstraintMapping mapping;
/*    */   private final Set<ConfiguredConstraint<?>> constraints;
/*    */   
/*    */   ConstraintMappingContextImplBase(DefaultConstraintMapping mapping)
/*    */   {
/* 32 */     this.mapping = mapping;
/* 33 */     this.constraints = CollectionHelper.newHashSet();
/*    */   }
/*    */   
/*    */   public <C> TypeConstraintMappingContext<C> type(Class<C> type) {
/* 37 */     return this.mapping.type(type);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected abstract ConstraintDescriptorImpl.ConstraintType getConstraintType();
/*    */   
/*    */ 
/*    */ 
/*    */   protected DefaultConstraintMapping getConstraintMapping()
/*    */   {
/* 48 */     return this.mapping;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void addConstraint(ConfiguredConstraint<?> constraint)
/*    */   {
/* 57 */     this.constraints.add(constraint);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected Set<MetaConstraint<?>> getConstraints(ConstraintHelper constraintHelper)
/*    */   {
/* 68 */     if (this.constraints == null) {
/* 69 */       return Collections.emptySet();
/*    */     }
/*    */     
/* 72 */     Set<MetaConstraint<?>> metaConstraints = CollectionHelper.newHashSet();
/*    */     
/* 74 */     for (ConfiguredConstraint<?> configuredConstraint : this.constraints) {
/* 75 */       metaConstraints.add(asMetaConstraint(configuredConstraint, constraintHelper));
/*    */     }
/*    */     
/* 78 */     return metaConstraints;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private <A extends Annotation> MetaConstraint<A> asMetaConstraint(ConfiguredConstraint<A> config, ConstraintHelper constraintHelper)
/*    */   {
/* 87 */     ConstraintDescriptorImpl<A> constraintDescriptor = new ConstraintDescriptorImpl(constraintHelper, config.getLocation().getMember(), config.createAnnotationProxy(), config.getElementType(), getConstraintType());
/*    */     
/*    */ 
/* 90 */     return new MetaConstraint(constraintDescriptor, config.getLocation());
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\cfg\context\ConstraintMappingContextImplBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */