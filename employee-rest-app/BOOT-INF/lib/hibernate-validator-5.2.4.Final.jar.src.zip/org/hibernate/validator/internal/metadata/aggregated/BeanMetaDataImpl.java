/*     */ package org.hibernate.validator.internal.metadata.aggregated;
/*     */ 
/*     */ import java.lang.annotation.ElementType;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.validation.ElementKind;
/*     */ import javax.validation.groups.Default;
/*     */ import javax.validation.metadata.BeanDescriptor;
/*     */ import javax.validation.metadata.ConstructorDescriptor;
/*     */ import javax.validation.metadata.MethodType;
/*     */ import javax.validation.metadata.PropertyDescriptor;
/*     */ import org.hibernate.validator.internal.engine.groups.Sequence;
/*     */ import org.hibernate.validator.internal.engine.groups.ValidationOrder;
/*     */ import org.hibernate.validator.internal.engine.groups.ValidationOrderGenerator;
/*     */ import org.hibernate.validator.internal.metadata.core.ConstraintHelper;
/*     */ import org.hibernate.validator.internal.metadata.core.MetaConstraint;
/*     */ import org.hibernate.validator.internal.metadata.descriptor.BeanDescriptorImpl;
/*     */ import org.hibernate.validator.internal.metadata.descriptor.ConstraintDescriptorImpl;
/*     */ import org.hibernate.validator.internal.metadata.descriptor.ExecutableDescriptorImpl;
/*     */ import org.hibernate.validator.internal.metadata.facets.Cascadable;
/*     */ import org.hibernate.validator.internal.metadata.location.ConstraintLocation;
/*     */ import org.hibernate.validator.internal.metadata.raw.BeanConfiguration;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConfigurationSource;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedElement;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedElement.ConstrainedElementKind;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedExecutable;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedField;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedType;
/*     */ import org.hibernate.validator.internal.metadata.raw.ExecutableElement;
/*     */ import org.hibernate.validator.internal.util.CollectionHelper;
/*     */ import org.hibernate.validator.internal.util.CollectionHelper.Partitioner;
/*     */ import org.hibernate.validator.internal.util.ExecutableHelper;
/*     */ import org.hibernate.validator.internal.util.classhierarchy.ClassHierarchyHelper;
/*     */ import org.hibernate.validator.internal.util.classhierarchy.Filter;
/*     */ import org.hibernate.validator.internal.util.classhierarchy.Filters;
/*     */ import org.hibernate.validator.internal.util.logging.Log;
/*     */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*     */ import org.hibernate.validator.spi.group.DefaultGroupSequenceProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BeanMetaDataImpl<T>
/*     */   implements BeanMetaData<T>
/*     */ {
/*  67 */   private static final Log log = ;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  72 */   private static final List<Class<?>> DEFAULT_GROUP_SEQUENCE = Collections.singletonList(Default.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ValidationOrderGenerator validationOrderGenerator;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Class<T> beanClass;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Set<MetaConstraint<?>> allMetaConstraints;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Set<MetaConstraint<?>> directMetaConstraints;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Map<String, ExecutableMetaData> executableMetaDataMap;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Map<String, PropertyMetaData> propertyMetaDataMap;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Set<Cascadable> cascadedProperties;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final BeanDescriptor beanDescriptor;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 121 */   private List<Class<?>> defaultGroupSequence = CollectionHelper.newArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private DefaultGroupSequenceProvider<? super T> defaultGroupSequenceProvider;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ValidationOrder validationOrder;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final List<Class<? super T>> classHierarchyWithoutInterfaces;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BeanMetaDataImpl(Class<T> beanClass, List<Class<?>> defaultGroupSequence, DefaultGroupSequenceProvider<? super T> defaultGroupSequenceProvider, Set<ConstraintMetaData> constraintMetaDataSet, ValidationOrderGenerator validationOrderGenerator)
/*     */   {
/* 152 */     this.validationOrderGenerator = validationOrderGenerator;
/* 153 */     this.beanClass = beanClass;
/* 154 */     this.propertyMetaDataMap = CollectionHelper.newHashMap();
/*     */     
/* 156 */     Set<PropertyMetaData> propertyMetaDataSet = CollectionHelper.newHashSet();
/* 157 */     Set<ExecutableMetaData> executableMetaDataSet = CollectionHelper.newHashSet();
/*     */     
/* 159 */     for (ConstraintMetaData constraintMetaData : constraintMetaDataSet) {
/* 160 */       if (constraintMetaData.getKind() == ElementKind.PROPERTY) {
/* 161 */         propertyMetaDataSet.add((PropertyMetaData)constraintMetaData);
/*     */       }
/*     */       else {
/* 164 */         executableMetaDataSet.add((ExecutableMetaData)constraintMetaData);
/*     */       }
/*     */     }
/*     */     
/* 168 */     Object cascadedProperties = CollectionHelper.newHashSet();
/* 169 */     Set<MetaConstraint<?>> allMetaConstraints = CollectionHelper.newHashSet();
/*     */     
/* 171 */     for (PropertyMetaData propertyMetaData : propertyMetaDataSet) {
/* 172 */       this.propertyMetaDataMap.put(propertyMetaData.getName(), propertyMetaData);
/*     */       
/* 174 */       if (propertyMetaData.isCascading()) {
/* 175 */         ((Set)cascadedProperties).add(propertyMetaData);
/*     */       }
/*     */       else {
/* 178 */         allMetaConstraints.addAll(propertyMetaData.getTypeArgumentsConstraints());
/*     */       }
/*     */       
/* 181 */       allMetaConstraints.addAll(propertyMetaData.getConstraints());
/*     */     }
/*     */     
/* 184 */     this.cascadedProperties = Collections.unmodifiableSet((Set)cascadedProperties);
/* 185 */     this.allMetaConstraints = Collections.unmodifiableSet(allMetaConstraints);
/*     */     
/* 187 */     this.classHierarchyWithoutInterfaces = ClassHierarchyHelper.getHierarchy(beanClass, new Filter[] {
/*     */     
/* 189 */       Filters.excludeInterfaces() });
/*     */     
/*     */ 
/* 192 */     setDefaultGroupSequenceOrProvider(defaultGroupSequence, defaultGroupSequenceProvider, validationOrderGenerator);
/*     */     
/* 194 */     this.directMetaConstraints = getDirectConstraints();
/*     */     
/* 196 */     this.executableMetaDataMap = Collections.unmodifiableMap(bySignature(executableMetaDataSet));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 205 */     this.beanDescriptor = new BeanDescriptorImpl(beanClass, getClassLevelConstraintsAsDescriptors(), getConstrainedPropertiesAsDescriptors(), getConstrainedMethodsAsDescriptors(), getConstrainedConstructorsAsDescriptors(), defaultGroupSequenceIsRedefined(), getDefaultGroupSequence(null));
/*     */   }
/*     */   
/*     */ 
/*     */   public Class<T> getBeanClass()
/*     */   {
/* 211 */     return this.beanClass;
/*     */   }
/*     */   
/*     */   public boolean hasConstraints()
/*     */   {
/* 216 */     if ((!this.beanDescriptor.isBeanConstrained()) && 
/* 217 */       (this.beanDescriptor.getConstrainedConstructors().isEmpty())) {
/* 218 */       if (this.beanDescriptor.getConstrainedMethods(MethodType.NON_GETTER, new MethodType[] { MethodType.GETTER }).isEmpty()) {}
/* 219 */     } else { return true;
/*     */     }
/*     */     
/* 222 */     return false;
/*     */   }
/*     */   
/*     */   public BeanDescriptor getBeanDescriptor()
/*     */   {
/* 227 */     return this.beanDescriptor;
/*     */   }
/*     */   
/*     */   public Set<Cascadable> getCascadables()
/*     */   {
/* 232 */     return this.cascadedProperties;
/*     */   }
/*     */   
/*     */   public PropertyMetaData getMetaDataFor(String propertyName)
/*     */   {
/* 237 */     return (PropertyMetaData)this.propertyMetaDataMap.get(propertyName);
/*     */   }
/*     */   
/*     */   public Set<MetaConstraint<?>> getMetaConstraints()
/*     */   {
/* 242 */     return this.allMetaConstraints;
/*     */   }
/*     */   
/*     */   public Set<MetaConstraint<?>> getDirectMetaConstraints()
/*     */   {
/* 247 */     return this.directMetaConstraints;
/*     */   }
/*     */   
/*     */   public ExecutableMetaData getMetaDataFor(ExecutableElement executable)
/*     */   {
/* 252 */     return (ExecutableMetaData)this.executableMetaDataMap.get(executable.getSignature());
/*     */   }
/*     */   
/*     */   public List<Class<?>> getDefaultGroupSequence(T beanState)
/*     */   {
/* 257 */     if (hasDefaultGroupSequenceProvider()) {
/* 258 */       List<Class<?>> providerDefaultGroupSequence = this.defaultGroupSequenceProvider.getValidationGroups(beanState);
/* 259 */       return getValidDefaultGroupSequence(providerDefaultGroupSequence);
/*     */     }
/*     */     
/* 262 */     return Collections.unmodifiableList(this.defaultGroupSequence);
/*     */   }
/*     */   
/*     */   public Iterator<Sequence> getDefaultValidationSequence(T beanState)
/*     */   {
/* 267 */     if (hasDefaultGroupSequenceProvider()) {
/* 268 */       List<Class<?>> providerDefaultGroupSequence = this.defaultGroupSequenceProvider.getValidationGroups(beanState);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 273 */       return this.validationOrderGenerator.getDefaultValidationOrder(this.beanClass, getValidDefaultGroupSequence(providerDefaultGroupSequence)).getSequenceIterator();
/*     */     }
/*     */     
/* 276 */     return this.validationOrder.getSequenceIterator();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean defaultGroupSequenceIsRedefined()
/*     */   {
/* 282 */     return (this.defaultGroupSequence.size() > 1) || (hasDefaultGroupSequenceProvider());
/*     */   }
/*     */   
/*     */   public List<Class<? super T>> getClassHierarchy()
/*     */   {
/* 287 */     return this.classHierarchyWithoutInterfaces;
/*     */   }
/*     */   
/*     */   private Set<ConstraintDescriptorImpl<?>> getClassLevelConstraintsAsDescriptors() {
/* 291 */     Set<MetaConstraint<?>> classLevelConstraints = getClassLevelConstraints(this.allMetaConstraints);
/*     */     
/* 293 */     Set<ConstraintDescriptorImpl<?>> theValue = CollectionHelper.newHashSet();
/*     */     
/* 295 */     for (MetaConstraint<?> metaConstraint : classLevelConstraints) {
/* 296 */       theValue.add(metaConstraint.getDescriptor());
/*     */     }
/*     */     
/* 299 */     return theValue;
/*     */   }
/*     */   
/*     */   private Map<String, PropertyDescriptor> getConstrainedPropertiesAsDescriptors() {
/* 303 */     Map<String, PropertyDescriptor> theValue = CollectionHelper.newHashMap();
/*     */     
/* 305 */     for (Map.Entry<String, PropertyMetaData> entry : this.propertyMetaDataMap.entrySet()) {
/* 306 */       if ((((PropertyMetaData)entry.getValue()).isConstrained()) && (((PropertyMetaData)entry.getValue()).getName() != null)) {
/* 307 */         theValue.put(entry
/* 308 */           .getKey(), 
/* 309 */           ((PropertyMetaData)entry.getValue()).asDescriptor(
/* 310 */           defaultGroupSequenceIsRedefined(), 
/* 311 */           getDefaultGroupSequence(null)));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 317 */     return theValue;
/*     */   }
/*     */   
/*     */   private Map<String, ExecutableDescriptorImpl> getConstrainedMethodsAsDescriptors() {
/* 321 */     Map<String, ExecutableDescriptorImpl> constrainedMethodDescriptors = CollectionHelper.newHashMap();
/*     */     
/* 323 */     for (ExecutableMetaData executableMetaData : this.executableMetaDataMap.values()) {
/* 324 */       if ((executableMetaData.getKind() == ElementKind.METHOD) && 
/* 325 */         (executableMetaData.isConstrained())) {
/* 326 */         descriptor = executableMetaData.asDescriptor(
/* 327 */           defaultGroupSequenceIsRedefined(), 
/* 328 */           getDefaultGroupSequence(null));
/*     */         
/*     */ 
/* 331 */         for (String signature : executableMetaData.getSignatures()) {
/* 332 */           constrainedMethodDescriptors.put(signature, descriptor);
/*     */         }
/*     */       }
/*     */     }
/*     */     ExecutableDescriptorImpl descriptor;
/* 337 */     return constrainedMethodDescriptors;
/*     */   }
/*     */   
/*     */   private Map<String, ConstructorDescriptor> getConstrainedConstructorsAsDescriptors() {
/* 341 */     Map<String, ConstructorDescriptor> constrainedMethodDescriptors = CollectionHelper.newHashMap();
/*     */     
/* 343 */     for (ExecutableMetaData executableMetaData : this.executableMetaDataMap.values()) {
/* 344 */       if ((executableMetaData.getKind() == ElementKind.CONSTRUCTOR) && (executableMetaData.isConstrained())) {
/* 345 */         constrainedMethodDescriptors.put(executableMetaData
/*     */         
/* 347 */           .getSignatures().iterator().next(), executableMetaData
/* 348 */           .asDescriptor(
/* 349 */           defaultGroupSequenceIsRedefined(), 
/* 350 */           getDefaultGroupSequence(null)));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 356 */     return constrainedMethodDescriptors;
/*     */   }
/*     */   
/*     */   private void setDefaultGroupSequenceOrProvider(List<Class<?>> defaultGroupSequence, DefaultGroupSequenceProvider<? super T> defaultGroupSequenceProvider, ValidationOrderGenerator validationOrderGenerator) {
/* 360 */     if ((defaultGroupSequence != null) && (defaultGroupSequenceProvider != null)) {
/* 361 */       throw log.getInvalidDefaultGroupSequenceDefinitionException();
/*     */     }
/*     */     
/* 364 */     if (defaultGroupSequenceProvider != null) {
/* 365 */       this.defaultGroupSequenceProvider = defaultGroupSequenceProvider;
/* 366 */       this.validationOrder = null;
/*     */     }
/* 368 */     else if ((defaultGroupSequence != null) && (!defaultGroupSequence.isEmpty())) {
/* 369 */       setDefaultGroupSequence(defaultGroupSequence);
/* 370 */       this.validationOrder = validationOrderGenerator.getDefaultValidationOrder(this.beanClass, this.defaultGroupSequence);
/*     */     }
/*     */     else {
/* 373 */       this.defaultGroupSequence = DEFAULT_GROUP_SEQUENCE;
/* 374 */       this.validationOrder = ValidationOrder.DEFAULT_SEQUENCE;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private Set<MetaConstraint<?>> getClassLevelConstraints(Set<MetaConstraint<?>> constraints)
/*     */   {
/* 382 */     Set<MetaConstraint<?>> classLevelConstraints = (Set)CollectionHelper.partition(constraints, byElementType()).get(ElementType.TYPE);
/*     */     
/* 384 */     return classLevelConstraints != null ? classLevelConstraints : Collections.emptySet();
/*     */   }
/*     */   
/*     */   private Set<MetaConstraint<?>> getDirectConstraints() {
/* 388 */     Set<MetaConstraint<?>> constraints = CollectionHelper.newHashSet();
/*     */     
/* 390 */     Set<Class<?>> classAndInterfaces = CollectionHelper.newHashSet();
/* 391 */     classAndInterfaces.add(this.beanClass);
/* 392 */     classAndInterfaces.addAll(ClassHierarchyHelper.getDirectlyImplementedInterfaces(this.beanClass));
/*     */     
/* 394 */     for (Iterator localIterator1 = classAndInterfaces.iterator(); localIterator1.hasNext();) { clazz = (Class)localIterator1.next();
/* 395 */       for (MetaConstraint<?> metaConstraint : this.allMetaConstraints) {
/* 396 */         if (metaConstraint.getLocation().getDeclaringClass().equals(clazz)) {
/* 397 */           constraints.add(metaConstraint);
/*     */         }
/*     */       }
/*     */     }
/*     */     Class<?> clazz;
/* 402 */     return Collections.unmodifiableSet(constraints);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Map<String, ExecutableMetaData> bySignature(Set<ExecutableMetaData> executables)
/*     */   {
/* 410 */     Map<String, ExecutableMetaData> theValue = CollectionHelper.newHashMap();
/*     */     
/* 412 */     for (Iterator localIterator1 = executables.iterator(); localIterator1.hasNext();) { executableMetaData = (ExecutableMetaData)localIterator1.next();
/* 413 */       for (String signature : executableMetaData.getSignatures()) {
/* 414 */         theValue.put(signature, executableMetaData);
/*     */       }
/*     */     }
/*     */     ExecutableMetaData executableMetaData;
/* 418 */     return theValue;
/*     */   }
/*     */   
/*     */   private void setDefaultGroupSequence(List<Class<?>> groupSequence) {
/* 422 */     this.defaultGroupSequence = getValidDefaultGroupSequence(groupSequence);
/*     */   }
/*     */   
/*     */   private List<Class<?>> getValidDefaultGroupSequence(List<Class<?>> groupSequence) {
/* 426 */     List<Class<?>> validDefaultGroupSequence = new ArrayList();
/*     */     
/* 428 */     boolean groupSequenceContainsDefault = false;
/* 429 */     if (groupSequence != null) {
/* 430 */       for (Class<?> group : groupSequence) {
/* 431 */         if (group.getName().equals(this.beanClass.getName())) {
/* 432 */           validDefaultGroupSequence.add(Default.class);
/* 433 */           groupSequenceContainsDefault = true;
/*     */         } else {
/* 435 */           if (group.getName().equals(Default.class.getName())) {
/* 436 */             throw log.getNoDefaultGroupInGroupSequenceException();
/*     */           }
/*     */           
/* 439 */           validDefaultGroupSequence.add(group);
/*     */         }
/*     */       }
/*     */     }
/* 443 */     if (!groupSequenceContainsDefault) {
/* 444 */       throw log.getBeanClassMustBePartOfRedefinedDefaultGroupSequenceException(this.beanClass.getName());
/*     */     }
/* 446 */     if (log.isTraceEnabled()) {
/* 447 */       log.tracef("Members of the default group sequence for bean %s are: %s.", this.beanClass
/*     */       
/* 449 */         .getName(), validDefaultGroupSequence);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 454 */     return validDefaultGroupSequence;
/*     */   }
/*     */   
/*     */   private boolean hasDefaultGroupSequenceProvider() {
/* 458 */     return this.defaultGroupSequenceProvider != null;
/*     */   }
/*     */   
/*     */   private CollectionHelper.Partitioner<ElementType, MetaConstraint<?>> byElementType() {
/* 462 */     new CollectionHelper.Partitioner()
/*     */     {
/*     */       public ElementType getPartition(MetaConstraint<?> constraint) {
/* 465 */         return constraint.getElementType();
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 472 */     StringBuilder sb = new StringBuilder();
/* 473 */     sb.append("BeanMetaDataImpl");
/* 474 */     sb.append("{beanClass=").append(this.beanClass.getSimpleName());
/* 475 */     sb.append(", constraintCount=").append(getMetaConstraints().size());
/* 476 */     sb.append(", cascadedPropertiesCount=").append(this.cascadedProperties.size());
/* 477 */     sb.append(", defaultGroupSequence=").append(getDefaultGroupSequence(null));
/* 478 */     sb.append('}');
/* 479 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public static class BeanMetaDataBuilder<T>
/*     */   {
/*     */     private final ConstraintHelper constraintHelper;
/*     */     
/*     */     private final ValidationOrderGenerator validationOrderGenerator;
/*     */     
/*     */     private final Class<T> beanClass;
/* 490 */     private final Set<BeanMetaDataImpl.BuilderDelegate> builders = CollectionHelper.newHashSet();
/*     */     
/*     */ 
/*     */     private final ExecutableHelper executableHelper;
/*     */     
/*     */ 
/*     */     private ConfigurationSource sequenceSource;
/*     */     
/*     */     private ConfigurationSource providerSource;
/*     */     
/*     */     private List<Class<?>> defaultGroupSequence;
/*     */     
/*     */     private DefaultGroupSequenceProvider<? super T> defaultGroupSequenceProvider;
/*     */     
/*     */ 
/*     */     private BeanMetaDataBuilder(ConstraintHelper constraintHelper, ExecutableHelper executableHelper, ValidationOrderGenerator validationOrderGenerator, Class<T> beanClass)
/*     */     {
/* 507 */       this.beanClass = beanClass;
/* 508 */       this.constraintHelper = constraintHelper;
/* 509 */       this.validationOrderGenerator = validationOrderGenerator;
/* 510 */       this.executableHelper = executableHelper;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public static <T> BeanMetaDataBuilder<T> getInstance(ConstraintHelper constraintHelper, ExecutableHelper executableHelper, ValidationOrderGenerator validationOrderGenerator, Class<T> beanClass)
/*     */     {
/* 518 */       return new BeanMetaDataBuilder(constraintHelper, executableHelper, validationOrderGenerator, beanClass);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void add(BeanConfiguration<? super T> configuration)
/*     */     {
/* 527 */       if (configuration.getBeanClass().equals(this.beanClass)) {
/* 528 */         if ((configuration.getDefaultGroupSequence() != null) && ((this.sequenceSource == null) || 
/*     */         
/* 530 */           (configuration.getSource().getPriority() >= this.sequenceSource.getPriority())))
/*     */         {
/* 532 */           this.sequenceSource = configuration.getSource();
/* 533 */           this.defaultGroupSequence = configuration.getDefaultGroupSequence();
/*     */         }
/*     */         
/* 536 */         if ((configuration.getDefaultGroupSequenceProvider() != null) && ((this.providerSource == null) || 
/*     */         
/* 538 */           (configuration.getSource().getPriority() >= this.providerSource.getPriority())))
/*     */         {
/* 540 */           this.providerSource = configuration.getSource();
/* 541 */           this.defaultGroupSequenceProvider = configuration.getDefaultGroupSequenceProvider();
/*     */         }
/*     */       }
/*     */       
/* 545 */       for (ConstrainedElement constrainedElement : configuration.getConstrainedElements()) {
/* 546 */         addMetaDataToBuilder(constrainedElement, this.builders);
/*     */       }
/*     */     }
/*     */     
/*     */     private void addMetaDataToBuilder(ConstrainedElement constrainableElement, Set<BeanMetaDataImpl.BuilderDelegate> builders) {
/* 551 */       for (BeanMetaDataImpl.BuilderDelegate builder : builders) {
/* 552 */         boolean foundBuilder = builder.add(constrainableElement);
/*     */         
/* 554 */         if (foundBuilder) {
/* 555 */           return;
/*     */         }
/*     */       }
/*     */       
/* 559 */       builders.add(new BeanMetaDataImpl.BuilderDelegate(this.beanClass, constrainableElement, this.constraintHelper, this.executableHelper));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public BeanMetaDataImpl<T> build()
/*     */     {
/* 570 */       Set<ConstraintMetaData> aggregatedElements = CollectionHelper.newHashSet();
/*     */       
/* 572 */       for (BeanMetaDataImpl.BuilderDelegate builder : this.builders) {
/* 573 */         aggregatedElements.addAll(builder.build());
/*     */       }
/*     */       
/* 576 */       return new BeanMetaDataImpl(this.beanClass, this.defaultGroupSequence, this.defaultGroupSequenceProvider, aggregatedElements, this.validationOrderGenerator);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class BuilderDelegate
/*     */   {
/*     */     private final Class<?> beanClass;
/*     */     
/*     */     private final ConstraintHelper constraintHelper;
/*     */     
/*     */     private final ExecutableHelper executableHelper;
/*     */     
/*     */     private MetaDataBuilder propertyBuilder;
/*     */     private ExecutableMetaData.Builder methodBuilder;
/*     */     
/*     */     public BuilderDelegate(Class<?> beanClass, ConstrainedElement constrainedElement, ConstraintHelper constraintHelper, ExecutableHelper executableHelper)
/*     */     {
/* 594 */       this.beanClass = beanClass;
/* 595 */       this.constraintHelper = constraintHelper;
/* 596 */       this.executableHelper = executableHelper;
/*     */       
/* 598 */       switch (BeanMetaDataImpl.2.$SwitchMap$org$hibernate$validator$internal$metadata$raw$ConstrainedElement$ConstrainedElementKind[constrainedElement.getKind().ordinal()]) {
/*     */       case 1: 
/* 600 */         ConstrainedField constrainedField = (ConstrainedField)constrainedElement;
/* 601 */         this.propertyBuilder = new PropertyMetaData.Builder(beanClass, constrainedField, constraintHelper);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 606 */         break;
/*     */       case 2: 
/*     */       case 3: 
/* 609 */         ConstrainedExecutable constrainedExecutable = (ConstrainedExecutable)constrainedElement;
/* 610 */         Member member = constrainedExecutable.getExecutable().getMember();
/*     */         
/*     */ 
/*     */ 
/* 614 */         if ((!Modifier.isPrivate(member.getModifiers())) || (beanClass == member.getDeclaringClass())) {
/* 615 */           this.methodBuilder = new ExecutableMetaData.Builder(beanClass, constrainedExecutable, constraintHelper, executableHelper);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 623 */         if (constrainedExecutable.isGetterMethod()) {
/* 624 */           this.propertyBuilder = new PropertyMetaData.Builder(beanClass, constrainedExecutable, constraintHelper);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */         break;
/*     */       case 4: 
/* 632 */         ConstrainedType constrainedType = (ConstrainedType)constrainedElement;
/* 633 */         this.propertyBuilder = new PropertyMetaData.Builder(beanClass, constrainedType, constraintHelper);
/*     */       }
/*     */       
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean add(ConstrainedElement constrainedElement)
/*     */     {
/* 643 */       boolean added = false;
/*     */       
/* 645 */       if ((this.methodBuilder != null) && (this.methodBuilder.accepts(constrainedElement))) {
/* 646 */         this.methodBuilder.add(constrainedElement);
/* 647 */         added = true;
/*     */       }
/*     */       
/* 650 */       if ((this.propertyBuilder != null) && (this.propertyBuilder.accepts(constrainedElement))) {
/* 651 */         this.propertyBuilder.add(constrainedElement);
/*     */         
/* 653 */         if ((!added) && (constrainedElement.getKind() == ConstrainedElement.ConstrainedElementKind.METHOD) && (this.methodBuilder == null)) {
/* 654 */           ConstrainedExecutable constrainedMethod = (ConstrainedExecutable)constrainedElement;
/* 655 */           this.methodBuilder = new ExecutableMetaData.Builder(this.beanClass, constrainedMethod, this.constraintHelper, this.executableHelper);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 663 */         added = true;
/*     */       }
/*     */       
/* 666 */       return added;
/*     */     }
/*     */     
/*     */     public Set<ConstraintMetaData> build() {
/* 670 */       Set<ConstraintMetaData> metaDataSet = CollectionHelper.newHashSet();
/*     */       
/* 672 */       if (this.propertyBuilder != null) {
/* 673 */         metaDataSet.add(this.propertyBuilder.build());
/*     */       }
/*     */       
/* 676 */       if (this.methodBuilder != null) {
/* 677 */         metaDataSet.add(this.methodBuilder.build());
/*     */       }
/*     */       
/* 680 */       return metaDataSet;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\metadata\aggregated\BeanMetaDataImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */