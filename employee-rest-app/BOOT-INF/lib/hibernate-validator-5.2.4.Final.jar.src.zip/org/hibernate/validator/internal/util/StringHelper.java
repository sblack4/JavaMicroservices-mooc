/*    */ package org.hibernate.validator.internal.util;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringHelper
/*    */ {
/*    */   public static String join(Object[] array, String separator)
/*    */   {
/* 31 */     return array != null ? join(Arrays.asList(array), separator) : null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String join(Iterable<?> iterable, String separator)
/*    */   {
/* 44 */     if (iterable == null) {
/* 45 */       return null;
/*    */     }
/*    */     
/* 48 */     StringBuilder sb = new StringBuilder();
/* 49 */     boolean isFirst = true;
/*    */     
/* 51 */     for (Object object : iterable) {
/* 52 */       if (!isFirst) {
/* 53 */         sb.append(separator);
/*    */       }
/*    */       else {
/* 56 */         isFirst = false;
/*    */       }
/*    */       
/* 59 */       sb.append(object);
/*    */     }
/*    */     
/* 62 */     return sb.toString();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String decapitalize(String string)
/*    */   {
/* 80 */     if ((string == null) || (string.isEmpty()) || (startsWithSeveralUpperCaseLetters(string))) {
/* 81 */       return string;
/*    */     }
/*    */     
/* 84 */     return string.substring(0, 1).toLowerCase() + string.substring(1);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   private static boolean startsWithSeveralUpperCaseLetters(String string)
/*    */   {
/* 91 */     return (string.length() > 1) && (Character.isUpperCase(string.charAt(0))) && (Character.isUpperCase(string.charAt(1)));
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\util\StringHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */