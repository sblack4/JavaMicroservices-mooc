/*    */ package org.hibernate.validator.internal.engine.messageinterpolation.parser;
/*    */ 
/*    */ import org.hibernate.validator.internal.engine.messageinterpolation.InterpolationTermType;
/*    */ import org.hibernate.validator.internal.util.logging.Log;
/*    */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageState
/*    */   implements ParserState
/*    */ {
/* 17 */   private static final Log log = ;
/*    */   
/*    */   public void start(TokenCollector tokenCollector)
/*    */   {
/* 21 */     throw new IllegalStateException("The parsing of the message descriptor cannot start in this state.");
/*    */   }
/*    */   
/*    */   public void terminate(TokenCollector tokenCollector) throws MessageDescriptorFormatException
/*    */   {
/* 26 */     tokenCollector.terminateToken();
/*    */   }
/*    */   
/*    */   public void handleNonMetaCharacter(char character, TokenCollector tokenCollector)
/*    */     throws MessageDescriptorFormatException
/*    */   {
/* 32 */     tokenCollector.appendToToken(character);
/* 33 */     tokenCollector.next();
/*    */   }
/*    */   
/*    */   public void handleBeginTerm(char character, TokenCollector tokenCollector) throws MessageDescriptorFormatException
/*    */   {
/* 38 */     tokenCollector.terminateToken();
/*    */     
/* 40 */     tokenCollector.appendToToken(character);
/* 41 */     if (tokenCollector.getInterpolationType().equals(InterpolationTermType.PARAMETER)) {
/* 42 */       tokenCollector.makeParameterToken();
/*    */     }
/* 44 */     tokenCollector.transitionState(new InterpolationTermState());
/* 45 */     tokenCollector.next();
/*    */   }
/*    */   
/*    */   public void handleEndTerm(char character, TokenCollector tokenCollector) throws MessageDescriptorFormatException
/*    */   {
/* 50 */     throw log.getNonTerminatedParameterException(tokenCollector
/* 51 */       .getOriginalMessageDescriptor(), character);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void handleEscapeCharacter(char character, TokenCollector tokenCollector)
/*    */     throws MessageDescriptorFormatException
/*    */   {
/* 59 */     tokenCollector.appendToToken(character);
/*    */     
/* 61 */     tokenCollector.transitionState(new EscapedState(this));
/* 62 */     tokenCollector.next();
/*    */   }
/*    */   
/*    */   public void handleELDesignator(char character, TokenCollector tokenCollector)
/*    */     throws MessageDescriptorFormatException
/*    */   {
/* 68 */     if (tokenCollector.getInterpolationType().equals(InterpolationTermType.PARAMETER)) {
/* 69 */       handleNonMetaCharacter(character, tokenCollector);
/*    */     }
/*    */     else {
/* 72 */       tokenCollector.transitionState(new ELState());
/* 73 */       tokenCollector.next();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\engine\messageinterpolation\parser\MessageState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */