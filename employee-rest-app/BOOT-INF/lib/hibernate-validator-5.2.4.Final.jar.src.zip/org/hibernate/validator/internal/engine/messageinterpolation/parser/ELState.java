/*    */ package org.hibernate.validator.internal.engine.messageinterpolation.parser;
/*    */ 
/*    */ import org.hibernate.validator.internal.util.logging.Log;
/*    */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ELState
/*    */   implements ParserState
/*    */ {
/* 16 */   private static final Log log = ;
/*    */   
/*    */   public void start(TokenCollector tokenCollector)
/*    */   {
/* 20 */     throw new IllegalStateException("Parsing of message descriptor cannot start in this state");
/*    */   }
/*    */   
/*    */   public void terminate(TokenCollector tokenCollector) throws MessageDescriptorFormatException
/*    */   {
/* 25 */     tokenCollector.appendToToken('$');
/* 26 */     tokenCollector.terminateToken();
/*    */   }
/*    */   
/*    */   public void handleNonMetaCharacter(char character, TokenCollector tokenCollector)
/*    */     throws MessageDescriptorFormatException
/*    */   {
/* 32 */     tokenCollector.appendToToken('$');
/* 33 */     tokenCollector.appendToToken(character);
/* 34 */     tokenCollector.terminateToken();
/* 35 */     tokenCollector.transitionState(new BeginState());
/* 36 */     tokenCollector.next();
/*    */   }
/*    */   
/*    */   public void handleBeginTerm(char character, TokenCollector tokenCollector) throws MessageDescriptorFormatException
/*    */   {
/* 41 */     tokenCollector.terminateToken();
/*    */     
/* 43 */     tokenCollector.appendToToken('$');
/* 44 */     tokenCollector.appendToToken(character);
/* 45 */     tokenCollector.makeELToken();
/* 46 */     tokenCollector.transitionState(new InterpolationTermState());
/* 47 */     tokenCollector.next();
/*    */   }
/*    */   
/*    */   public void handleEndTerm(char character, TokenCollector tokenCollector) throws MessageDescriptorFormatException
/*    */   {
/* 52 */     throw log.getNonTerminatedParameterException(tokenCollector
/* 53 */       .getOriginalMessageDescriptor(), character);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void handleEscapeCharacter(char character, TokenCollector tokenCollector)
/*    */     throws MessageDescriptorFormatException
/*    */   {
/* 61 */     tokenCollector.transitionState(new EscapedState(this));
/* 62 */     tokenCollector.next();
/*    */   }
/*    */   
/*    */   public void handleELDesignator(char character, TokenCollector tokenCollector)
/*    */     throws MessageDescriptorFormatException
/*    */   {
/* 68 */     handleNonMetaCharacter(character, tokenCollector);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\engine\messageinterpolation\parser\ELState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */