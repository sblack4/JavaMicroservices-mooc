/*    */ package org.hibernate.validator.internal.constraintvalidators.bv.size;
/*    */ 
/*    */ import java.util.Map;
/*    */ import javax.validation.ConstraintValidator;
/*    */ import javax.validation.ConstraintValidatorContext;
/*    */ import javax.validation.constraints.Size;
/*    */ import org.hibernate.validator.internal.util.logging.Log;
/*    */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SizeValidatorForMap
/*    */   implements ConstraintValidator<Size, Map<?, ?>>
/*    */ {
/* 24 */   private static final Log log = ;
/*    */   private int min;
/*    */   private int max;
/*    */   
/*    */   public void initialize(Size parameters)
/*    */   {
/* 30 */     this.min = parameters.min();
/* 31 */     this.max = parameters.max();
/* 32 */     validateParameters();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isValid(Map<?, ?> map, ConstraintValidatorContext constraintValidatorContext)
/*    */   {
/* 46 */     if (map == null) {
/* 47 */       return true;
/*    */     }
/* 49 */     int size = map.size();
/* 50 */     return (size >= this.min) && (size <= this.max);
/*    */   }
/*    */   
/*    */   private void validateParameters() {
/* 54 */     if (this.min < 0) {
/* 55 */       throw log.getMaxCannotBeNegativeException();
/*    */     }
/* 57 */     if (this.max < 0) {
/* 58 */       throw log.getMaxCannotBeNegativeException();
/*    */     }
/* 60 */     if (this.max < this.min) {
/* 61 */       throw log.getLengthCannotBeNegativeException();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\constraintvalidators\bv\size\SizeValidatorForMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */