/*    */ package org.hibernate.validator.internal.constraintvalidators.hv;
/*    */ 
/*    */ import javax.validation.ConstraintValidator;
/*    */ import javax.validation.ConstraintValidatorContext;
/*    */ import org.hibernate.validator.constraints.NotBlank;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotBlankValidator
/*    */   implements ConstraintValidator<NotBlank, CharSequence>
/*    */ {
/*    */   public void initialize(NotBlank annotation) {}
/*    */   
/*    */   public boolean isValid(CharSequence charSequence, ConstraintValidatorContext constraintValidatorContext)
/*    */   {
/* 34 */     if (charSequence == null) {
/* 35 */       return true;
/*    */     }
/*    */     
/* 38 */     return charSequence.toString().trim().length() > 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\constraintvalidators\hv\NotBlankValidator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */