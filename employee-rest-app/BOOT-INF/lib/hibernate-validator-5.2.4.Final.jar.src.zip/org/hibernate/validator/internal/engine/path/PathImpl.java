/*     */ package org.hibernate.validator.internal.engine.path;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.validation.ElementKind;
/*     */ import javax.validation.Path;
/*     */ import javax.validation.Path.Node;
/*     */ import org.hibernate.validator.internal.metadata.aggregated.ExecutableMetaData;
/*     */ import org.hibernate.validator.internal.util.Contracts;
/*     */ import org.hibernate.validator.internal.util.logging.Log;
/*     */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*     */ import org.hibernate.validator.internal.util.logging.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PathImpl
/*     */   implements Path, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 7564511574909882392L;
/*  36 */   private static final Log log = ;
/*     */   
/*     */ 
/*     */   private static final String PROPERTY_PATH_SEPARATOR = ".";
/*     */   
/*     */ 
/*     */   private static final String LEADING_PROPERTY_GROUP = "[^\\[\\.]+";
/*     */   
/*     */ 
/*     */   private static final String OPTIONAL_INDEX_GROUP = "\\[(\\w*)\\]";
/*     */   
/*     */   private static final String REMAINING_PROPERTY_STRING = "\\.(.*)";
/*     */   
/*  49 */   private static final Pattern PATH_PATTERN = Pattern.compile("([^\\[\\.]+)(\\[(\\w*)\\])?(\\.(.*))*");
/*     */   
/*     */ 
/*     */   private static final int PROPERTY_NAME_GROUP = 1;
/*     */   
/*     */ 
/*     */   private static final int INDEXED_GROUP = 2;
/*     */   
/*     */ 
/*     */   private static final int INDEX_GROUP = 3;
/*     */   
/*     */ 
/*     */   private static final int REMAINING_STRING_GROUP = 5;
/*     */   
/*     */   private final List<Path.Node> nodeList;
/*     */   
/*     */   private NodeImpl currentLeafNode;
/*     */   
/*     */   private int hashCode;
/*     */   
/*     */ 
/*     */   public static PathImpl createPathFromString(String propertyPath)
/*     */   {
/*  72 */     Contracts.assertNotNull(propertyPath, Messages.MESSAGES.propertyPathCannotBeNull());
/*     */     
/*  74 */     if (propertyPath.length() == 0) {
/*  75 */       return createRootPath();
/*     */     }
/*     */     
/*  78 */     return parseProperty(propertyPath);
/*     */   }
/*     */   
/*     */   public static PathImpl createPathForExecutable(ExecutableMetaData executable) {
/*  82 */     Contracts.assertNotNull(executable, "A method is required to create a method return value path.");
/*     */     
/*  84 */     PathImpl path = createRootPath();
/*     */     
/*  86 */     if (executable.getKind() == ElementKind.CONSTRUCTOR) {
/*  87 */       path.addConstructorNode(executable.getName(), executable.getParameterTypes());
/*     */     }
/*     */     else {
/*  90 */       path.addMethodNode(executable.getName(), executable.getParameterTypes());
/*     */     }
/*     */     
/*  93 */     return path;
/*     */   }
/*     */   
/*     */   public static PathImpl createRootPath() {
/*  97 */     PathImpl path = new PathImpl();
/*  98 */     path.addBeanNode();
/*  99 */     return path;
/*     */   }
/*     */   
/*     */   public static PathImpl createCopy(PathImpl path) {
/* 103 */     return new PathImpl(path);
/*     */   }
/*     */   
/*     */   public boolean isRootPath() {
/* 107 */     return (this.nodeList.size() == 1) && (((Path.Node)this.nodeList.get(0)).getName() == null);
/*     */   }
/*     */   
/*     */   public PathImpl getPathWithoutLeafNode() {
/* 111 */     return new PathImpl(this.nodeList.subList(0, this.nodeList.size() - 1));
/*     */   }
/*     */   
/*     */   public NodeImpl addPropertyNode(String nodeName) {
/* 115 */     NodeImpl parent = this.nodeList.isEmpty() ? null : (NodeImpl)this.nodeList.get(this.nodeList.size() - 1);
/* 116 */     this.currentLeafNode = NodeImpl.createPropertyNode(nodeName, parent);
/* 117 */     this.nodeList.add(this.currentLeafNode);
/* 118 */     this.hashCode = -1;
/* 119 */     return this.currentLeafNode;
/*     */   }
/*     */   
/*     */   public NodeImpl addParameterNode(String nodeName, int index) {
/* 123 */     NodeImpl parent = this.nodeList.isEmpty() ? null : (NodeImpl)this.nodeList.get(this.nodeList.size() - 1);
/* 124 */     this.currentLeafNode = NodeImpl.createParameterNode(nodeName, parent, index);
/* 125 */     this.nodeList.add(this.currentLeafNode);
/* 126 */     this.hashCode = -1;
/* 127 */     return this.currentLeafNode;
/*     */   }
/*     */   
/*     */   public NodeImpl addCrossParameterNode() {
/* 131 */     NodeImpl parent = this.nodeList.isEmpty() ? null : (NodeImpl)this.nodeList.get(this.nodeList.size() - 1);
/* 132 */     this.currentLeafNode = NodeImpl.createCrossParameterNode(parent);
/* 133 */     this.nodeList.add(this.currentLeafNode);
/* 134 */     this.hashCode = -1;
/* 135 */     return this.currentLeafNode;
/*     */   }
/*     */   
/*     */   public NodeImpl addBeanNode() {
/* 139 */     NodeImpl parent = this.nodeList.isEmpty() ? null : (NodeImpl)this.nodeList.get(this.nodeList.size() - 1);
/* 140 */     this.currentLeafNode = NodeImpl.createBeanNode(parent);
/* 141 */     this.nodeList.add(this.currentLeafNode);
/* 142 */     this.hashCode = -1;
/* 143 */     return this.currentLeafNode;
/*     */   }
/*     */   
/*     */   public NodeImpl addReturnValueNode() {
/* 147 */     NodeImpl parent = this.nodeList.isEmpty() ? null : (NodeImpl)this.nodeList.get(this.nodeList.size() - 1);
/* 148 */     this.currentLeafNode = NodeImpl.createReturnValue(parent);
/* 149 */     this.nodeList.add(this.currentLeafNode);
/* 150 */     this.hashCode = -1;
/* 151 */     return this.currentLeafNode;
/*     */   }
/*     */   
/*     */   private NodeImpl addConstructorNode(String name, Class<?>[] parameterTypes) {
/* 155 */     NodeImpl parent = this.nodeList.isEmpty() ? null : (NodeImpl)this.nodeList.get(this.nodeList.size() - 1);
/* 156 */     this.currentLeafNode = NodeImpl.createConstructorNode(name, parent, parameterTypes);
/* 157 */     this.nodeList.add(this.currentLeafNode);
/* 158 */     this.hashCode = -1;
/* 159 */     return this.currentLeafNode;
/*     */   }
/*     */   
/*     */   private NodeImpl addMethodNode(String name, Class<?>[] parameterTypes) {
/* 163 */     NodeImpl parent = this.nodeList.isEmpty() ? null : (NodeImpl)this.nodeList.get(this.nodeList.size() - 1);
/* 164 */     this.currentLeafNode = NodeImpl.createMethodNode(name, parent, parameterTypes);
/* 165 */     this.nodeList.add(this.currentLeafNode);
/* 166 */     this.hashCode = -1;
/* 167 */     return this.currentLeafNode;
/*     */   }
/*     */   
/*     */   public NodeImpl makeLeafNodeIterable() {
/* 171 */     this.currentLeafNode = NodeImpl.makeIterable(this.currentLeafNode);
/*     */     
/* 173 */     this.nodeList.remove(this.nodeList.size() - 1);
/* 174 */     this.nodeList.add(this.currentLeafNode);
/* 175 */     this.hashCode = -1;
/* 176 */     return this.currentLeafNode;
/*     */   }
/*     */   
/*     */   public NodeImpl setLeafNodeIndex(Integer index) {
/* 180 */     this.currentLeafNode = NodeImpl.setIndex(this.currentLeafNode, index);
/*     */     
/* 182 */     this.nodeList.remove(this.nodeList.size() - 1);
/* 183 */     this.nodeList.add(this.currentLeafNode);
/* 184 */     this.hashCode = -1;
/* 185 */     return this.currentLeafNode;
/*     */   }
/*     */   
/*     */   public NodeImpl setLeafNodeMapKey(Object key) {
/* 189 */     this.currentLeafNode = NodeImpl.setMapKey(this.currentLeafNode, key);
/*     */     
/* 191 */     this.nodeList.remove(this.nodeList.size() - 1);
/* 192 */     this.nodeList.add(this.currentLeafNode);
/* 193 */     this.hashCode = -1;
/* 194 */     return this.currentLeafNode;
/*     */   }
/*     */   
/*     */   public NodeImpl setLeafNodeValue(Object value) {
/* 198 */     this.currentLeafNode = NodeImpl.setPropertyValue(this.currentLeafNode, value);
/*     */     
/* 200 */     this.nodeList.remove(this.nodeList.size() - 1);
/* 201 */     this.nodeList.add(this.currentLeafNode);
/* 202 */     this.hashCode = -1;
/* 203 */     return this.currentLeafNode;
/*     */   }
/*     */   
/*     */   public NodeImpl getLeafNode() {
/* 207 */     return this.currentLeafNode;
/*     */   }
/*     */   
/*     */   public Iterator<Path.Node> iterator()
/*     */   {
/* 212 */     if (this.nodeList.size() == 0) {
/* 213 */       return Collections.emptyList().iterator();
/*     */     }
/* 215 */     if (this.nodeList.size() == 1) {
/* 216 */       return this.nodeList.iterator();
/*     */     }
/* 218 */     return this.nodeList.subList(1, this.nodeList.size()).iterator();
/*     */   }
/*     */   
/*     */   public String asString() {
/* 222 */     StringBuilder builder = new StringBuilder();
/* 223 */     boolean first = true;
/* 224 */     for (int i = 1; i < this.nodeList.size(); i++) {
/* 225 */       NodeImpl nodeImpl = (NodeImpl)this.nodeList.get(i);
/* 226 */       String name = nodeImpl.asString();
/* 227 */       if (!name.isEmpty())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 232 */         if (!first) {
/* 233 */           builder.append(".");
/*     */         }
/*     */         
/* 236 */         builder.append(nodeImpl.asString());
/*     */         
/* 238 */         first = false;
/*     */       } }
/* 240 */     return builder.toString();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 245 */     return asString();
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 250 */     if (this == obj) {
/* 251 */       return true;
/*     */     }
/* 253 */     if (obj == null) {
/* 254 */       return false;
/*     */     }
/* 256 */     if (getClass() != obj.getClass()) {
/* 257 */       return false;
/*     */     }
/* 259 */     PathImpl other = (PathImpl)obj;
/* 260 */     if (this.nodeList == null) {
/* 261 */       if (other.nodeList != null) {
/* 262 */         return false;
/*     */       }
/*     */     }
/* 265 */     else if (!this.nodeList.equals(other.nodeList)) {
/* 266 */       return false;
/*     */     }
/* 268 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 274 */     if (this.hashCode == -1) {
/* 275 */       this.hashCode = buildHashCode();
/*     */     }
/*     */     
/* 278 */     return this.hashCode;
/*     */   }
/*     */   
/*     */   private int buildHashCode() {
/* 282 */     int prime = 31;
/* 283 */     int result = 1;
/*     */     
/* 285 */     result = 31 * result + (this.nodeList == null ? 0 : this.nodeList.hashCode());
/* 286 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private PathImpl(PathImpl path)
/*     */   {
/* 295 */     this(path.nodeList);
/* 296 */     this.currentLeafNode = ((NodeImpl)this.nodeList.get(this.nodeList.size() - 1));
/*     */   }
/*     */   
/*     */   private PathImpl() {
/* 300 */     this.nodeList = new ArrayList();
/* 301 */     this.hashCode = -1;
/*     */   }
/*     */   
/*     */   private PathImpl(List<Path.Node> nodeList) {
/* 305 */     this.nodeList = new ArrayList(nodeList);
/* 306 */     this.hashCode = -1;
/*     */   }
/*     */   
/*     */   private static PathImpl parseProperty(String propertyName) {
/* 310 */     PathImpl path = createRootPath();
/* 311 */     String tmp = propertyName;
/*     */     do {
/* 313 */       Matcher matcher = PATH_PATTERN.matcher(tmp);
/* 314 */       if (matcher.matches())
/*     */       {
/* 316 */         String value = matcher.group(1);
/* 317 */         if (!isValidJavaIdentifier(value)) {
/* 318 */           throw log.getInvalidJavaIdentifierException(value);
/*     */         }
/*     */         
/*     */ 
/* 322 */         path.addPropertyNode(value);
/*     */         
/*     */ 
/* 325 */         if (matcher.group(2) != null) {
/* 326 */           path.makeLeafNodeIterable();
/*     */         }
/*     */         
/*     */ 
/* 330 */         String indexOrKey = matcher.group(3);
/* 331 */         if ((indexOrKey != null) && (indexOrKey.length() > 0)) {
/*     */           try {
/* 333 */             Integer i = Integer.valueOf(Integer.parseInt(indexOrKey));
/* 334 */             path.setLeafNodeIndex(i);
/*     */           }
/*     */           catch (NumberFormatException e) {
/* 337 */             path.setLeafNodeMapKey(indexOrKey);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 342 */         tmp = matcher.group(5);
/*     */       }
/*     */       else {
/* 345 */         throw log.getUnableToParsePropertyPathException(propertyName);
/*     */       }
/* 347 */     } while (tmp != null);
/*     */     
/* 349 */     if (path.getLeafNode().isIterable()) {
/* 350 */       path.addBeanNode();
/*     */     }
/*     */     
/* 353 */     return path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isValidJavaIdentifier(String identifier)
/*     */   {
/* 367 */     Contracts.assertNotNull(identifier, "identifier param cannot be null");
/*     */     
/* 369 */     if ((identifier.length() == 0) || (!Character.isJavaIdentifierStart(identifier.charAt(0)))) {
/* 370 */       return false;
/*     */     }
/*     */     
/* 373 */     for (int i = 1; i < identifier.length(); i++) {
/* 374 */       if (!Character.isJavaIdentifierPart(identifier.charAt(i))) {
/* 375 */         return false;
/*     */       }
/*     */     }
/* 378 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\engine\path\PathImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */