/*    */ package org.hibernate.validator.internal.util;
/*    */ 
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ import org.hibernate.validator.internal.util.logging.Log;
/*    */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Version
/*    */ {
/*    */   private static final Pattern JAVA_VERSION_PATTERN;
/*    */   private static Log LOG;
/*    */   private static int JAVA_RELEASE;
/*    */   
/*    */   static
/*    */   {
/* 20 */     Version.JAVA_VERSION_PATTERN = Pattern.compile("^(?:1\\.)?(\\d+)$");
/*    */     
/* 22 */     Version.LOG = LoggerFactory.make();
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 27 */     Version.JAVA_RELEASE = Version.determineJavaRelease(System.getProperty("java.specification.version"));
/*    */     
/*    */ 
/* 30 */     Version.LOG.version(Version.getVersionString());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static int getJavaRelease()
/*    */   {
/* 46 */     return Version.JAVA_RELEASE;
/*    */   }
/*    */   
/*    */   public static int determineJavaRelease(String specificationVersion) {
/* 50 */     if ((specificationVersion != null) && (!specificationVersion.trim().isEmpty())) {
/* 51 */       Matcher matcher = Version.JAVA_VERSION_PATTERN.matcher(specificationVersion);
/*    */       
/* 53 */       if (matcher.find()) {
/* 54 */         return Integer.valueOf(matcher.group(1)).intValue();
/*    */       }
/*    */     }
/*    */     
/*    */ 
/* 59 */     Version.LOG.unknownJvmVersion(specificationVersion);
/* 60 */     return 6;
/*    */   }
/*    */   
/*    */   private Version() {
/* 64 */     super();
/*    */   }
/*    */   
/*    */   public static String getVersionString()
/*    */   {
/*    */     return "5.2.4.Final";
/*    */   }
/*    */   
/*    */   public static void touch() {}
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\util\Version.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */