/*     */ package org.hibernate.validator.internal.metadata.raw;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.hibernate.validator.internal.engine.valuehandling.UnwrapMode;
/*     */ import org.hibernate.validator.internal.metadata.core.MetaConstraint;
/*     */ import org.hibernate.validator.internal.metadata.descriptor.ConstraintDescriptorImpl;
/*     */ import org.hibernate.validator.internal.metadata.location.ConstraintLocation;
/*     */ import org.hibernate.validator.internal.util.CollectionHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstrainedParameter
/*     */   extends AbstractConstrainedElement
/*     */ {
/*     */   private final Type type;
/*     */   private final String name;
/*     */   private final int index;
/*     */   private final Set<MetaConstraint<?>> typeArgumentsConstraints;
/*     */   
/*     */   public ConstrainedParameter(ConfigurationSource source, ConstraintLocation location, Type type, int index, String name)
/*     */   {
/*  38 */     this(source, location, type, index, name, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  44 */       Collections.emptySet(), 
/*  45 */       Collections.emptySet(), 
/*  46 */       Collections.emptyMap(), false, UnwrapMode.AUTOMATIC);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConstrainedParameter(ConfigurationSource source, ConstraintLocation location, Type type, int index, String name, Set<MetaConstraint<?>> constraints, Set<MetaConstraint<?>> typeArgumentsConstraints, Map<Class<?>, Class<?>> groupConversions, boolean isCascading, UnwrapMode unwrapMode)
/*     */   {
/*  79 */     super(source, ConstrainedElement.ConstrainedElementKind.PARAMETER, location, constraints, groupConversions, isCascading, unwrapMode);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  89 */     this.type = type;
/*  90 */     this.name = name;
/*  91 */     this.index = index;
/*  92 */     this.typeArgumentsConstraints = (typeArgumentsConstraints != null ? Collections.unmodifiableSet(typeArgumentsConstraints) : 
/*     */     
/*  94 */       Collections.emptySet());
/*     */   }
/*     */   
/*     */   public Type getType() {
/*  98 */     return this.type;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 102 */     return this.name;
/*     */   }
/*     */   
/*     */   public int getIndex() {
/* 106 */     return this.index;
/*     */   }
/*     */   
/*     */   public Set<MetaConstraint<?>> getTypeArgumentsConstraints() {
/* 110 */     return this.typeArgumentsConstraints;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConstrainedParameter merge(ConstrainedParameter other)
/*     */   {
/* 122 */     ConfigurationSource mergedSource = ConfigurationSource.max(this.source, other.source);
/*     */     String mergedName;
/*     */     String mergedName;
/* 125 */     if (this.source.getPriority() > other.source.getPriority()) {
/* 126 */       mergedName = this.name;
/*     */     }
/*     */     else {
/* 129 */       mergedName = other.name;
/*     */     }
/*     */     
/*     */     UnwrapMode mergedUnwrapMode;
/*     */     UnwrapMode mergedUnwrapMode;
/* 134 */     if (this.source.getPriority() > other.source.getPriority()) {
/* 135 */       mergedUnwrapMode = this.unwrapMode;
/*     */     }
/*     */     else {
/* 138 */       mergedUnwrapMode = other.unwrapMode;
/*     */     }
/*     */     
/* 141 */     Set<MetaConstraint<?>> mergedConstraints = CollectionHelper.newHashSet(this.constraints);
/* 142 */     mergedConstraints.addAll(other.constraints);
/*     */     
/* 144 */     Set<MetaConstraint<?>> mergedTypeArgumentsConstraints = CollectionHelper.newHashSet(this.typeArgumentsConstraints);
/* 145 */     mergedTypeArgumentsConstraints.addAll(other.typeArgumentsConstraints);
/*     */     
/* 147 */     Map<Class<?>, Class<?>> mergedGroupConversions = CollectionHelper.newHashMap(this.groupConversions);
/* 148 */     mergedGroupConversions.putAll(other.groupConversions);
/*     */     
/*     */ 
/*     */ 
/* 152 */     return new ConstrainedParameter(mergedSource, getLocation(), this.type, this.index, mergedName, mergedConstraints, mergedTypeArgumentsConstraints, mergedGroupConversions, (this.isCascading) || (other.isCascading), mergedUnwrapMode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 167 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 169 */     for (MetaConstraint<?> oneConstraint : getConstraints()) {
/* 170 */       sb.append(oneConstraint.getDescriptor().getAnnotation().annotationType().getSimpleName());
/* 171 */       sb.append(", ");
/*     */     }
/*     */     
/* 174 */     String constraintsAsString = sb.length() > 0 ? sb.substring(0, sb.length() - 2) : sb.toString();
/*     */     
/*     */ 
/* 177 */     return "ParameterMetaData [location=" + getLocation() + "], name=" + this.name + "], constraints=[" + constraintsAsString + "], isCascading=" + isCascading() + "]";
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 182 */     int prime = 31;
/* 183 */     int result = super.hashCode();
/* 184 */     result = 31 * result + this.index;
/* 185 */     result = 31 * result + (getLocation().getMember() == null ? 0 : getLocation().getMember().hashCode());
/* 186 */     return result;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 191 */     if (this == obj) {
/* 192 */       return true;
/*     */     }
/* 194 */     if (!super.equals(obj)) {
/* 195 */       return false;
/*     */     }
/* 197 */     if (getClass() != obj.getClass()) {
/* 198 */       return false;
/*     */     }
/* 200 */     ConstrainedParameter other = (ConstrainedParameter)obj;
/* 201 */     if (this.index != other.index) {
/* 202 */       return false;
/*     */     }
/* 204 */     if (getLocation().getMember() == null) {
/* 205 */       if (other.getLocation().getMember() != null) {
/* 206 */         return false;
/*     */       }
/*     */     }
/* 209 */     else if (!getLocation().getMember().equals(other.getLocation().getMember())) {
/* 210 */       return false;
/*     */     }
/* 212 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\metadata\raw\ConstrainedParameter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */