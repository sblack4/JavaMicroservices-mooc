/*    */ package org.hibernate.validator.internal.constraintvalidators.bv;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import javax.validation.ConstraintValidator;
/*    */ import javax.validation.ConstraintValidatorContext;
/*    */ import javax.validation.constraints.Max;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MaxValidatorForCharSequence
/*    */   implements ConstraintValidator<Max, CharSequence>
/*    */ {
/*    */   private BigDecimal maxValue;
/*    */   
/*    */   public void initialize(Max maxValue)
/*    */   {
/* 26 */     this.maxValue = BigDecimal.valueOf(maxValue.value());
/*    */   }
/*    */   
/*    */   public boolean isValid(CharSequence value, ConstraintValidatorContext constraintValidatorContext)
/*    */   {
/* 31 */     if (value == null) {
/* 32 */       return true;
/*    */     }
/*    */     try {
/* 35 */       return new BigDecimal(value.toString()).compareTo(this.maxValue) != 1;
/*    */     }
/*    */     catch (NumberFormatException nfe) {}
/* 38 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\constraintvalidators\bv\MaxValidatorForCharSequence.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */