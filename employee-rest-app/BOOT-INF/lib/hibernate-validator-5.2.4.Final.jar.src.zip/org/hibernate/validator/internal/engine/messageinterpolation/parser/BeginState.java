/*    */ package org.hibernate.validator.internal.engine.messageinterpolation.parser;
/*    */ 
/*    */ import org.hibernate.validator.internal.engine.messageinterpolation.InterpolationTermType;
/*    */ import org.hibernate.validator.internal.util.logging.Log;
/*    */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeginState
/*    */   implements ParserState
/*    */ {
/* 17 */   private static final Log log = ;
/*    */   
/*    */   public void terminate(TokenCollector tokenCollector)
/*    */     throws MessageDescriptorFormatException
/*    */   {}
/*    */   
/*    */   public void start(TokenCollector tokenCollector) throws MessageDescriptorFormatException
/*    */   {
/* 25 */     tokenCollector.next();
/*    */   }
/*    */   
/*    */   public void handleNonMetaCharacter(char character, TokenCollector tokenCollector)
/*    */     throws MessageDescriptorFormatException
/*    */   {
/* 31 */     tokenCollector.appendToToken(character);
/* 32 */     tokenCollector.transitionState(new MessageState());
/* 33 */     tokenCollector.next();
/*    */   }
/*    */   
/*    */   public void handleBeginTerm(char character, TokenCollector tokenCollector)
/*    */     throws MessageDescriptorFormatException
/*    */   {
/* 39 */     tokenCollector.terminateToken();
/*    */     
/* 41 */     tokenCollector.appendToToken(character);
/* 42 */     if (tokenCollector.getInterpolationType().equals(InterpolationTermType.PARAMETER)) {
/* 43 */       tokenCollector.makeParameterToken();
/*    */     }
/* 45 */     tokenCollector.transitionState(new InterpolationTermState());
/* 46 */     tokenCollector.next();
/*    */   }
/*    */   
/*    */   public void handleEndTerm(char character, TokenCollector tokenCollector) throws MessageDescriptorFormatException
/*    */   {
/* 51 */     throw log.getNonTerminatedParameterException(tokenCollector.getOriginalMessageDescriptor(), character);
/*    */   }
/*    */   
/*    */   public void handleEscapeCharacter(char character, TokenCollector tokenCollector)
/*    */     throws MessageDescriptorFormatException
/*    */   {
/* 57 */     tokenCollector.appendToToken(character);
/* 58 */     tokenCollector.transitionState(new EscapedState(this));
/* 59 */     tokenCollector.next();
/*    */   }
/*    */   
/*    */   public void handleELDesignator(char character, TokenCollector tokenCollector)
/*    */     throws MessageDescriptorFormatException
/*    */   {
/* 65 */     if (tokenCollector.getInterpolationType().equals(InterpolationTermType.PARAMETER)) {
/* 66 */       handleNonMetaCharacter(character, tokenCollector);
/*    */     }
/*    */     else {
/* 69 */       ParserState state = new ELState();
/* 70 */       tokenCollector.transitionState(state);
/* 71 */       tokenCollector.next();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\engine\messageinterpolation\parser\BeginState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */