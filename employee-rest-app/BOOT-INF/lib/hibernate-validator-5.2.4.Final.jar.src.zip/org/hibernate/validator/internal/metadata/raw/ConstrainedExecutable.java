/*     */ package org.hibernate.validator.internal.metadata.raw;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.validation.metadata.ConstraintDescriptor;
/*     */ import org.hibernate.validator.internal.engine.valuehandling.UnwrapMode;
/*     */ import org.hibernate.validator.internal.metadata.core.MetaConstraint;
/*     */ import org.hibernate.validator.internal.metadata.location.ConstraintLocation;
/*     */ import org.hibernate.validator.internal.util.CollectionHelper;
/*     */ import org.hibernate.validator.internal.util.logging.Log;
/*     */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstrainedExecutable
/*     */   extends AbstractConstrainedElement
/*     */ {
/*  36 */   private static final Log log = ;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ExecutableElement executable;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final List<ConstrainedParameter> parameterMetaData;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Set<MetaConstraint<?>> typeArgumentsConstraints;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final boolean hasParameterConstraints;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Set<MetaConstraint<?>> crossParameterConstraints;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConstrainedExecutable(ConfigurationSource source, ConstraintLocation location, Set<MetaConstraint<?>> returnValueConstraints, Map<Class<?>, Class<?>> groupConversions, boolean isCascading, UnwrapMode unwrapMode)
/*     */   {
/*  70 */     this(source, location, 
/*     */     
/*     */ 
/*  73 */       Collections.emptyList(), 
/*  74 */       Collections.emptySet(), returnValueConstraints, 
/*     */       
/*  76 */       Collections.emptySet(), groupConversions, isCascading, unwrapMode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConstrainedExecutable(ConfigurationSource source, ConstraintLocation location, List<ConstrainedParameter> parameterMetaData, Set<MetaConstraint<?>> crossParameterConstraints, Set<MetaConstraint<?>> returnValueConstraints, Set<MetaConstraint<?>> typeArgumentsConstraints, Map<Class<?>, Class<?>> groupConversions, boolean isCascading, UnwrapMode unwrapMode)
/*     */   {
/* 113 */     super(source, 
/*     */     
/* 115 */       (location.getMember() instanceof Constructor) ? ConstrainedElement.ConstrainedElementKind.CONSTRUCTOR : ConstrainedElement.ConstrainedElementKind.METHOD, location, returnValueConstraints, groupConversions, isCascading, unwrapMode);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */     this.executable = ((location.getMember() instanceof Method) ? ExecutableElement.forMethod((Method)location.getMember()) : ExecutableElement.forConstructor((Constructor)location.getMember()));
/*     */     
/* 127 */     if (parameterMetaData.size() != this.executable.getParameterTypes().length) {
/* 128 */       throw log.getInvalidLengthOfParameterMetaDataListException(this.executable
/* 129 */         .getAsString(), this.executable
/* 130 */         .getParameterTypes().length, parameterMetaData
/* 131 */         .size());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 137 */     this.typeArgumentsConstraints = (typeArgumentsConstraints != null ? Collections.unmodifiableSet(typeArgumentsConstraints) : Collections.emptySet());
/* 138 */     this.crossParameterConstraints = crossParameterConstraints;
/* 139 */     this.parameterMetaData = Collections.unmodifiableList(parameterMetaData);
/* 140 */     this.hasParameterConstraints = ((hasParameterConstraints(parameterMetaData)) || (!crossParameterConstraints.isEmpty()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConstrainedParameter getParameterMetaData(int parameterIndex)
/*     */   {
/* 155 */     if ((parameterIndex < 0) || (parameterIndex > this.parameterMetaData.size() - 1)) {
/* 156 */       throw log.getInvalidExecutableParameterIndexException(this.executable
/* 157 */         .getAsString(), parameterIndex);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 162 */     return (ConstrainedParameter)this.parameterMetaData.get(parameterIndex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<ConstrainedParameter> getAllParameterMetaData()
/*     */   {
/* 174 */     return this.parameterMetaData;
/*     */   }
/*     */   
/*     */   public Set<MetaConstraint<?>> getCrossParameterConstraints() {
/* 178 */     return this.crossParameterConstraints;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isConstrained()
/*     */   {
/* 193 */     return (super.isConstrained()) || (this.hasParameterConstraints);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasParameterConstraints()
/*     */   {
/* 204 */     return this.hasParameterConstraints;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isGetterMethod()
/*     */   {
/* 214 */     return this.executable.isGetterMethod();
/*     */   }
/*     */   
/*     */   public ExecutableElement getExecutable() {
/* 218 */     return this.executable;
/*     */   }
/*     */   
/*     */   public Set<MetaConstraint<?>> getTypeArgumentsConstraints() {
/* 222 */     return this.typeArgumentsConstraints;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 227 */     return "ConstrainedExecutable [location=" + getLocation() + ", parameterMetaData=" + this.parameterMetaData + ", hasParameterConstraints=" + this.hasParameterConstraints + "]";
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean hasParameterConstraints(List<ConstrainedParameter> parameterMetaData)
/*     */   {
/* 233 */     for (ConstrainedParameter oneParameter : parameterMetaData) {
/* 234 */       if (oneParameter.isConstrained()) {
/* 235 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 239 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEquallyParameterConstrained(ConstrainedExecutable other)
/*     */   {
/* 253 */     if (!getDescriptors(this.crossParameterConstraints).equals(getDescriptors(other.crossParameterConstraints))) {
/* 254 */       return false;
/*     */     }
/*     */     
/* 257 */     int i = 0;
/* 258 */     for (ConstrainedParameter parameter : this.parameterMetaData) {
/* 259 */       ConstrainedParameter otherParameter = other.getParameterMetaData(i);
/* 260 */       if ((parameter.isCascading != otherParameter.isCascading) || 
/* 261 */         (!getDescriptors(parameter.getConstraints()).equals(getDescriptors(otherParameter.getConstraints())))) {
/* 262 */         return false;
/*     */       }
/* 264 */       i++;
/*     */     }
/*     */     
/* 267 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConstrainedExecutable merge(ConstrainedExecutable other)
/*     */   {
/* 280 */     ConfigurationSource mergedSource = ConfigurationSource.max(this.source, other.source);
/*     */     
/* 282 */     List<ConstrainedParameter> mergedParameterMetaData = CollectionHelper.newArrayList(this.parameterMetaData.size());
/* 283 */     int i = 0;
/* 284 */     for (ConstrainedParameter parameter : this.parameterMetaData) {
/* 285 */       mergedParameterMetaData.add(parameter.merge(other.getParameterMetaData(i)));
/* 286 */       i++;
/*     */     }
/*     */     
/* 289 */     Object mergedCrossParameterConstraints = CollectionHelper.newHashSet(this.crossParameterConstraints);
/* 290 */     ((Set)mergedCrossParameterConstraints).addAll(other.crossParameterConstraints);
/*     */     
/* 292 */     Set<MetaConstraint<?>> mergedReturnValueConstraints = CollectionHelper.newHashSet(this.constraints);
/* 293 */     mergedReturnValueConstraints.addAll(other.constraints);
/*     */     
/* 295 */     Set<MetaConstraint<?>> mergedTypeArgumentsConstraints = CollectionHelper.newHashSet(this.typeArgumentsConstraints);
/* 296 */     mergedTypeArgumentsConstraints.addAll(other.typeArgumentsConstraints);
/*     */     
/* 298 */     Map<Class<?>, Class<?>> mergedGroupConversions = CollectionHelper.newHashMap(this.groupConversions);
/* 299 */     mergedGroupConversions.putAll(other.groupConversions);
/*     */     
/*     */     UnwrapMode mergedUnwrapMode;
/*     */     UnwrapMode mergedUnwrapMode;
/* 303 */     if (this.source.getPriority() > other.source.getPriority()) {
/* 304 */       mergedUnwrapMode = this.unwrapMode;
/*     */     }
/*     */     else {
/* 307 */       mergedUnwrapMode = other.unwrapMode;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 312 */     return new ConstrainedExecutable(mergedSource, getLocation(), mergedParameterMetaData, (Set)mergedCrossParameterConstraints, mergedReturnValueConstraints, mergedTypeArgumentsConstraints, mergedGroupConversions, (this.isCascading) || (other.isCascading), mergedUnwrapMode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Set<ConstraintDescriptor<?>> getDescriptors(Iterable<MetaConstraint<?>> constraints)
/*     */   {
/* 324 */     Set<ConstraintDescriptor<?>> descriptors = CollectionHelper.newHashSet();
/*     */     
/* 326 */     for (MetaConstraint<?> constraint : constraints) {
/* 327 */       descriptors.add(constraint.getDescriptor());
/*     */     }
/*     */     
/* 330 */     return descriptors;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 335 */     int prime = 31;
/* 336 */     int result = super.hashCode();
/*     */     
/* 338 */     result = 31 * result + (this.executable == null ? 0 : this.executable.hashCode());
/* 339 */     return result;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 344 */     if (this == obj) {
/* 345 */       return true;
/*     */     }
/* 347 */     if (!super.equals(obj)) {
/* 348 */       return false;
/*     */     }
/* 350 */     if (getClass() != obj.getClass()) {
/* 351 */       return false;
/*     */     }
/* 353 */     ConstrainedExecutable other = (ConstrainedExecutable)obj;
/* 354 */     if (this.executable == null) {
/* 355 */       if (other.executable != null) {
/* 356 */         return false;
/*     */       }
/*     */     }
/* 359 */     else if (!this.executable.equals(other.executable)) {
/* 360 */       return false;
/*     */     }
/* 362 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\metadata\raw\ConstrainedExecutable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */