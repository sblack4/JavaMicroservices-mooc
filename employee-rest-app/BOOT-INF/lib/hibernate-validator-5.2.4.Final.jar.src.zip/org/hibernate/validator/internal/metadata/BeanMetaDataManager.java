/*     */ package org.hibernate.validator.internal.metadata;
/*     */ 
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import javax.validation.ParameterNameProvider;
/*     */ import org.hibernate.validator.internal.engine.groups.ValidationOrderGenerator;
/*     */ import org.hibernate.validator.internal.metadata.aggregated.BeanMetaData;
/*     */ import org.hibernate.validator.internal.metadata.aggregated.BeanMetaDataImpl;
/*     */ import org.hibernate.validator.internal.metadata.aggregated.BeanMetaDataImpl.BeanMetaDataBuilder;
/*     */ import org.hibernate.validator.internal.metadata.aggregated.UnconstrainedEntityMetaDataSingleton;
/*     */ import org.hibernate.validator.internal.metadata.core.AnnotationProcessingOptions;
/*     */ import org.hibernate.validator.internal.metadata.core.AnnotationProcessingOptionsImpl;
/*     */ import org.hibernate.validator.internal.metadata.core.ConstraintHelper;
/*     */ import org.hibernate.validator.internal.metadata.provider.AnnotationMetaDataProvider;
/*     */ import org.hibernate.validator.internal.metadata.provider.MetaDataProvider;
/*     */ import org.hibernate.validator.internal.metadata.provider.TypeAnnotationAwareMetaDataProvider;
/*     */ import org.hibernate.validator.internal.metadata.raw.BeanConfiguration;
/*     */ import org.hibernate.validator.internal.util.CollectionHelper;
/*     */ import org.hibernate.validator.internal.util.ConcurrentReferenceHashMap;
/*     */ import org.hibernate.validator.internal.util.ConcurrentReferenceHashMap.Option;
/*     */ import org.hibernate.validator.internal.util.ConcurrentReferenceHashMap.ReferenceType;
/*     */ import org.hibernate.validator.internal.util.Contracts;
/*     */ import org.hibernate.validator.internal.util.ExecutableHelper;
/*     */ import org.hibernate.validator.internal.util.Version;
/*     */ import org.hibernate.validator.internal.util.logging.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanMetaDataManager
/*     */ {
/*     */   private static final int DEFAULT_INITIAL_CAPACITY = 16;
/*     */   private static final float DEFAULT_LOAD_FACTOR = 0.75F;
/*     */   private static final int DEFAULT_CONCURRENCY_LEVEL = 16;
/*     */   private final List<MetaDataProvider> metaDataProviders;
/*     */   private final ConstraintHelper constraintHelper;
/*     */   private final ConcurrentReferenceHashMap<Class<?>, BeanMetaData<?>> beanMetaDataCache;
/*     */   private final ExecutableHelper executableHelper;
/*  90 */   private final ValidationOrderGenerator validationOrderGenerator = new ValidationOrderGenerator();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BeanMetaDataManager(ConstraintHelper constraintHelper, ExecutableHelper executableHelper, ParameterNameProvider parameterNameProvider, List<MetaDataProvider> optionalMetaDataProviders)
/*     */   {
/* 104 */     this.constraintHelper = constraintHelper;
/* 105 */     this.metaDataProviders = CollectionHelper.newArrayList();
/* 106 */     this.metaDataProviders.addAll(optionalMetaDataProviders);
/* 107 */     this.executableHelper = executableHelper;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 115 */     this.beanMetaDataCache = new ConcurrentReferenceHashMap(16, 0.75F, 16, ConcurrentReferenceHashMap.ReferenceType.SOFT, ConcurrentReferenceHashMap.ReferenceType.SOFT, EnumSet.of(ConcurrentReferenceHashMap.Option.IDENTITY_COMPARISONS));
/*     */     
/*     */ 
/* 118 */     AnnotationProcessingOptions annotationProcessingOptions = getAnnotationProcessingOptionsFromNonDefaultProviders();
/* 119 */     AnnotationMetaDataProvider defaultProvider = null;
/* 120 */     if (Version.getJavaRelease() >= 8) {
/* 121 */       defaultProvider = new TypeAnnotationAwareMetaDataProvider(constraintHelper, parameterNameProvider, annotationProcessingOptions);
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 128 */       defaultProvider = new AnnotationMetaDataProvider(constraintHelper, parameterNameProvider, annotationProcessingOptions);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 134 */     this.metaDataProviders.add(defaultProvider);
/*     */   }
/*     */   
/*     */   public boolean isConstrained(Class<?> beanClass) {
/* 138 */     return getOrCreateBeanMetaData(beanClass, true).hasConstraints();
/*     */   }
/*     */   
/*     */   public <T> BeanMetaData<T> getBeanMetaData(Class<T> beanClass) {
/* 142 */     return getOrCreateBeanMetaData(beanClass, false);
/*     */   }
/*     */   
/*     */   public void clear() {
/* 146 */     this.beanMetaDataCache.clear();
/*     */   }
/*     */   
/*     */   public int numberOfCachedBeanMetaDataInstances() {
/* 150 */     return this.beanMetaDataCache.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private <T> BeanMetaDataImpl<T> createBeanMetaData(Class<T> clazz)
/*     */   {
/* 163 */     BeanMetaDataImpl.BeanMetaDataBuilder<T> builder = BeanMetaDataImpl.BeanMetaDataBuilder.getInstance(this.constraintHelper, this.executableHelper, this.validationOrderGenerator, clazz);
/*     */     
/* 165 */     for (MetaDataProvider provider : this.metaDataProviders) {
/* 166 */       for (BeanConfiguration<? super T> beanConfiguration : provider.getBeanConfigurationForHierarchy(clazz)) {
/* 167 */         builder.add(beanConfiguration);
/*     */       }
/*     */     }
/*     */     
/* 171 */     return builder.build();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private AnnotationProcessingOptions getAnnotationProcessingOptionsFromNonDefaultProviders()
/*     */   {
/* 178 */     AnnotationProcessingOptions options = new AnnotationProcessingOptionsImpl();
/* 179 */     for (MetaDataProvider metaDataProvider : this.metaDataProviders) {
/* 180 */       options.merge(metaDataProvider.getAnnotationProcessingOptions());
/*     */     }
/*     */     
/* 183 */     return options;
/*     */   }
/*     */   
/*     */   private <T> BeanMetaData<T> getOrCreateBeanMetaData(Class<T> beanClass, boolean allowUnconstrainedTypeSingleton)
/*     */   {
/* 188 */     Contracts.assertNotNull(beanClass, Messages.MESSAGES.beanTypeCannotBeNull());
/*     */     
/* 190 */     BeanMetaData<T> beanMetaData = (BeanMetaData)this.beanMetaDataCache.get(beanClass);
/*     */     
/*     */ 
/* 193 */     if (beanMetaData == null) {
/* 194 */       beanMetaData = createBeanMetaData(beanClass);
/* 195 */       if ((!beanMetaData.hasConstraints()) && (allowUnconstrainedTypeSingleton)) {
/* 196 */         beanMetaData = UnconstrainedEntityMetaDataSingleton.getSingleton();
/*     */       }
/*     */       
/* 199 */       BeanMetaData<T> cachedBeanMetaData = (BeanMetaData)this.beanMetaDataCache.putIfAbsent(beanClass, beanMetaData);
/*     */       
/*     */ 
/*     */ 
/* 203 */       if (cachedBeanMetaData != null) {
/* 204 */         beanMetaData = cachedBeanMetaData;
/*     */       }
/*     */     }
/*     */     
/* 208 */     if (((beanMetaData instanceof UnconstrainedEntityMetaDataSingleton)) && (!allowUnconstrainedTypeSingleton)) {
/* 209 */       beanMetaData = createBeanMetaData(beanClass);
/* 210 */       this.beanMetaDataCache.put(beanClass, beanMetaData);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 216 */     return beanMetaData;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\metadata\BeanMetaDataManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */