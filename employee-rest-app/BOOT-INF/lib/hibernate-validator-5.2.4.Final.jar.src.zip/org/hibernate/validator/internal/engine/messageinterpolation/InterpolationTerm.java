/*    */ package org.hibernate.validator.internal.engine.messageinterpolation;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import javax.validation.MessageInterpolator.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InterpolationTerm
/*    */ {
/*    */   private static final String EL_DESIGNATION_CHARACTER = "$";
/*    */   private final String expression;
/*    */   private final InterpolationTermType type;
/*    */   private final TermResolver resolver;
/*    */   
/*    */   public InterpolationTerm(String expression, Locale locale)
/*    */   {
/* 41 */     this.expression = expression;
/* 42 */     if (isElExpression(expression)) {
/* 43 */       this.type = InterpolationTermType.EL;
/* 44 */       this.resolver = new ElTermResolver(locale);
/*    */     }
/*    */     else {
/* 47 */       this.type = InterpolationTermType.PARAMETER;
/* 48 */       this.resolver = new ParameterTermResolver();
/*    */     }
/*    */   }
/*    */   
/*    */   public static boolean isElExpression(String expression) {
/* 53 */     return expression.startsWith("$");
/*    */   }
/*    */   
/*    */   public String interpolate(MessageInterpolator.Context context) {
/* 57 */     return this.resolver.interpolate(context, this.expression);
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 62 */     StringBuilder sb = new StringBuilder();
/* 63 */     sb.append("InterpolationExpression");
/* 64 */     sb.append("{expression='").append(this.expression).append('\'');
/* 65 */     sb.append(", type=").append(this.type);
/* 66 */     sb.append('}');
/* 67 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\engine\messageinterpolation\InterpolationTerm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */