/*     */ package org.hibernate.validator.internal.engine.messageinterpolation.parser;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.hibernate.validator.internal.engine.messageinterpolation.InterpolationTermType;
/*     */ import org.hibernate.validator.internal.util.CollectionHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TokenCollector
/*     */ {
/*     */   public static final char BEGIN_TERM = '{';
/*     */   public static final char END_TERM = '}';
/*     */   public static final char EL_DESIGNATOR = '$';
/*     */   public static final char ESCAPE_CHARACTER = '\\';
/*     */   private final String originalMessageDescriptor;
/*     */   private final InterpolationTermType interpolationTermType;
/*     */   private List<Token> tokenList;
/*     */   private ParserState currentParserState;
/*     */   private int currentPosition;
/*     */   private Token currentToken;
/*     */   
/*     */   public TokenCollector(String originalMessageDescriptor, InterpolationTermType interpolationTermType)
/*     */     throws MessageDescriptorFormatException
/*     */   {
/*  38 */     this.originalMessageDescriptor = originalMessageDescriptor;
/*  39 */     this.interpolationTermType = interpolationTermType;
/*  40 */     this.currentParserState = new BeginState();
/*  41 */     this.tokenList = CollectionHelper.newArrayList();
/*     */     
/*  43 */     parse();
/*     */   }
/*     */   
/*     */   public void terminateToken() {
/*  47 */     if (this.currentToken == null) {
/*  48 */       return;
/*     */     }
/*  50 */     this.currentToken.terminate();
/*  51 */     this.tokenList.add(this.currentToken);
/*  52 */     this.currentToken = null;
/*     */   }
/*     */   
/*     */   public void appendToToken(char character) {
/*  56 */     if (this.currentToken == null) {
/*  57 */       this.currentToken = new Token(character);
/*     */     }
/*     */     else {
/*  60 */       this.currentToken.append(character);
/*     */     }
/*     */   }
/*     */   
/*     */   public void makeParameterToken() {
/*  65 */     this.currentToken.makeParameterToken();
/*     */   }
/*     */   
/*     */   public void makeELToken() {
/*  69 */     this.currentToken.makeELToken();
/*     */   }
/*     */   
/*     */   public void next() throws MessageDescriptorFormatException {
/*  73 */     if (this.currentPosition == this.originalMessageDescriptor.length())
/*     */     {
/*  75 */       this.currentParserState.terminate(this);
/*  76 */       return;
/*     */     }
/*  78 */     char currentCharacter = this.originalMessageDescriptor.charAt(this.currentPosition);
/*  79 */     this.currentPosition += 1;
/*  80 */     switch (currentCharacter) {
/*     */     case '{': 
/*  82 */       this.currentParserState.handleBeginTerm(currentCharacter, this);
/*  83 */       break;
/*     */     
/*     */     case '}': 
/*  86 */       this.currentParserState.handleEndTerm(currentCharacter, this);
/*  87 */       break;
/*     */     
/*     */     case '$': 
/*  90 */       this.currentParserState.handleELDesignator(currentCharacter, this);
/*  91 */       break;
/*     */     
/*     */     case '\\': 
/*  94 */       this.currentParserState.handleEscapeCharacter(currentCharacter, this);
/*  95 */       break;
/*     */     
/*     */     default: 
/*  98 */       this.currentParserState.handleNonMetaCharacter(currentCharacter, this);
/*     */     }
/*     */     
/*     */     
/* 102 */     terminateToken();
/*     */   }
/*     */   
/*     */   public void parse() throws MessageDescriptorFormatException {
/* 106 */     this.currentParserState.start(this);
/*     */   }
/*     */   
/*     */   public void transitionState(ParserState newState) {
/* 110 */     this.currentParserState = newState;
/*     */   }
/*     */   
/*     */   public InterpolationTermType getInterpolationType() {
/* 114 */     return this.interpolationTermType;
/*     */   }
/*     */   
/*     */   public List<Token> getTokenList() {
/* 118 */     return Collections.unmodifiableList(this.tokenList);
/*     */   }
/*     */   
/*     */   public String getOriginalMessageDescriptor() {
/* 122 */     return this.originalMessageDescriptor;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\engine\messageinterpolation\parser\TokenCollector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */