/*    */ package org.hibernate.validator.internal.cfg.context;
/*    */ 
/*    */ import java.util.Set;
/*    */ import javax.validation.ParameterNameProvider;
/*    */ import org.hibernate.validator.cfg.ConstraintMapping;
/*    */ import org.hibernate.validator.cfg.context.TypeConstraintMappingContext;
/*    */ import org.hibernate.validator.internal.metadata.core.AnnotationProcessingOptionsImpl;
/*    */ import org.hibernate.validator.internal.metadata.core.ConstraintHelper;
/*    */ import org.hibernate.validator.internal.metadata.raw.BeanConfiguration;
/*    */ import org.hibernate.validator.internal.util.CollectionHelper;
/*    */ import org.hibernate.validator.internal.util.Contracts;
/*    */ import org.hibernate.validator.internal.util.logging.Log;
/*    */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*    */ import org.hibernate.validator.internal.util.logging.Messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultConstraintMapping
/*    */   implements ConstraintMapping
/*    */ {
/* 34 */   private static final Log log = ;
/*    */   private final AnnotationProcessingOptionsImpl annotationProcessingOptions;
/*    */   private final Set<Class<?>> configuredTypes;
/*    */   private final Set<TypeConstraintMappingContextImpl<?>> typeContexts;
/*    */   
/*    */   public DefaultConstraintMapping()
/*    */   {
/* 41 */     this.annotationProcessingOptions = new AnnotationProcessingOptionsImpl();
/* 42 */     this.configuredTypes = CollectionHelper.newHashSet();
/* 43 */     this.typeContexts = CollectionHelper.newHashSet();
/*    */   }
/*    */   
/*    */   public final <C> TypeConstraintMappingContext<C> type(Class<C> type)
/*    */   {
/* 48 */     Contracts.assertNotNull(type, Messages.MESSAGES.beanTypeMustNotBeNull());
/*    */     
/* 50 */     if (this.configuredTypes.contains(type)) {
/* 51 */       throw log.getBeanClassHasAlreadyBeConfiguredViaProgrammaticApiException(type.getName());
/*    */     }
/*    */     
/* 54 */     TypeConstraintMappingContextImpl<C> typeContext = new TypeConstraintMappingContextImpl(this, type);
/* 55 */     this.typeContexts.add(typeContext);
/* 56 */     this.configuredTypes.add(type);
/*    */     
/* 58 */     return typeContext;
/*    */   }
/*    */   
/*    */   public final AnnotationProcessingOptionsImpl getAnnotationProcessingOptions() {
/* 62 */     return this.annotationProcessingOptions;
/*    */   }
/*    */   
/*    */   public Set<Class<?>> getConfiguredTypes() {
/* 66 */     return this.configuredTypes;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Set<BeanConfiguration<?>> getBeanConfigurations(ConstraintHelper constraintHelper, ParameterNameProvider parameterNameProvider)
/*    */   {
/* 78 */     Set<BeanConfiguration<?>> configurations = CollectionHelper.newHashSet();
/*    */     
/* 80 */     for (TypeConstraintMappingContextImpl<?> typeContext : this.typeContexts) {
/* 81 */       configurations.add(typeContext.build(constraintHelper, parameterNameProvider));
/*    */     }
/*    */     
/* 84 */     return configurations;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\cfg\context\DefaultConstraintMapping.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */