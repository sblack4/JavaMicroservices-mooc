/*    */ package org.hibernate.validator.internal.constraintvalidators.hv;
/*    */ 
/*    */ import javax.validation.ConstraintValidator;
/*    */ import javax.validation.ConstraintValidatorContext;
/*    */ import org.hibernate.validator.constraints.Length;
/*    */ import org.hibernate.validator.internal.util.logging.Log;
/*    */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LengthValidator
/*    */   implements ConstraintValidator<Length, CharSequence>
/*    */ {
/* 24 */   private static final Log log = ;
/*    */   private int min;
/*    */   private int max;
/*    */   
/*    */   public void initialize(Length parameters)
/*    */   {
/* 30 */     this.min = parameters.min();
/* 31 */     this.max = parameters.max();
/* 32 */     validateParameters();
/*    */   }
/*    */   
/*    */   public boolean isValid(CharSequence value, ConstraintValidatorContext constraintValidatorContext) {
/* 36 */     if (value == null) {
/* 37 */       return true;
/*    */     }
/* 39 */     int length = value.length();
/* 40 */     return (length >= this.min) && (length <= this.max);
/*    */   }
/*    */   
/*    */   private void validateParameters() {
/* 44 */     if (this.min < 0) {
/* 45 */       throw log.getMinCannotBeNegativeException();
/*    */     }
/* 47 */     if (this.max < 0) {
/* 48 */       throw log.getMaxCannotBeNegativeException();
/*    */     }
/* 50 */     if (this.max < this.min) {
/* 51 */       throw log.getLengthCannotBeNegativeException();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\constraintvalidators\hv\LengthValidator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */