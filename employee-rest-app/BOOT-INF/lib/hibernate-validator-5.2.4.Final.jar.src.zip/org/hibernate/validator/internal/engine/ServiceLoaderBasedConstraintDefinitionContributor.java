/*    */ package org.hibernate.validator.internal.engine;
/*    */ 
/*    */ import com.fasterxml.classmate.ResolvedType;
/*    */ import com.fasterxml.classmate.TypeResolver;
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Type;
/*    */ import java.security.AccessController;
/*    */ import java.security.PrivilegedAction;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import javax.validation.ConstraintValidator;
/*    */ import org.hibernate.validator.internal.util.CollectionHelper;
/*    */ import org.hibernate.validator.internal.util.TypeResolutionHelper;
/*    */ import org.hibernate.validator.internal.util.privilegedactions.GetConstraintValidatorList;
/*    */ import org.hibernate.validator.spi.constraintdefinition.ConstraintDefinitionContributor;
/*    */ import org.hibernate.validator.spi.constraintdefinition.ConstraintDefinitionContributor.ConstraintDefinitionBuilder;
/*    */ import org.hibernate.validator.spi.constraintdefinition.ConstraintDefinitionContributor.ConstraintDefinitionBuilderContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServiceLoaderBasedConstraintDefinitionContributor
/*    */   implements ConstraintDefinitionContributor
/*    */ {
/*    */   private final TypeResolutionHelper typeResolutionHelper;
/*    */   
/*    */   public ServiceLoaderBasedConstraintDefinitionContributor(TypeResolutionHelper typeResolutionHelper)
/*    */   {
/* 35 */     this.typeResolutionHelper = typeResolutionHelper;
/*    */   }
/*    */   
/*    */   public void collectConstraintDefinitions(ConstraintDefinitionContributor.ConstraintDefinitionBuilder constraintDefinitionContributionBuilder)
/*    */   {
/* 40 */     Map<Class<?>, List<Class<?>>> customValidators = CollectionHelper.newHashMap();
/*    */     
/*    */ 
/* 43 */     GetConstraintValidatorList constraintValidatorListAction = new GetConstraintValidatorList();
/* 44 */     List<ConstraintValidator<?, ?>> discoveredConstraintValidators = (List)run(constraintValidatorListAction);
/*    */     
/* 46 */     for (ConstraintValidator<?, ?> constraintValidator : discoveredConstraintValidators) {
/* 47 */       Class<?> constraintValidatorClass = constraintValidator.getClass();
/* 48 */       Class<?> annotationType = determineAnnotationType(constraintValidatorClass);
/*    */       
/* 50 */       List<Class<?>> validators = (List)customValidators.get(annotationType);
/* 51 */       if ((annotationType != null) && (validators == null)) {
/* 52 */         validators = new ArrayList();
/* 53 */         customValidators.put(annotationType, validators);
/*    */       }
/* 55 */       validators.add(constraintValidatorClass);
/*    */     }
/*    */     
/* 58 */     for (Map.Entry<Class<?>, List<Class<?>>> entry : customValidators.entrySet()) {
/* 59 */       registerConstraintDefinition(constraintDefinitionContributionBuilder, (Class)entry.getKey(), (List)entry.getValue());
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private <A extends Annotation> void registerConstraintDefinition(ConstraintDefinitionContributor.ConstraintDefinitionBuilder builder, Class<?> constraintType, List<Class<?>> validatorTypes)
/*    */   {
/* 69 */     ConstraintDefinitionContributor.ConstraintDefinitionBuilderContext<A> context = builder.constraint(constraintType).includeExistingValidators(true);
/*    */     
/* 71 */     for (Class<?> validatorType : validatorTypes) {
/* 72 */       context.validatedBy(validatorType);
/*    */     }
/*    */   }
/*    */   
/*    */   private Class<?> determineAnnotationType(Class<?> constraintValidatorClass)
/*    */   {
/* 78 */     ResolvedType resolvedType = this.typeResolutionHelper.getTypeResolver().resolve(constraintValidatorClass, new Type[0]);
/*    */     
/* 80 */     return ((ResolvedType)resolvedType.typeParametersFor(ConstraintValidator.class).get(0)).getErasedType();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private <T> T run(PrivilegedAction<T> action)
/*    */   {
/* 90 */     return (T)(System.getSecurityManager() != null ? AccessController.doPrivileged(action) : action.run());
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\engine\ServiceLoaderBasedConstraintDefinitionContributor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */