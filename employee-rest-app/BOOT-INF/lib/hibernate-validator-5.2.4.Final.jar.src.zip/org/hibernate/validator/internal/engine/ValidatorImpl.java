/*      */ package org.hibernate.validator.internal.engine;
/*      */ 
/*      */ import java.lang.annotation.ElementType;
/*      */ import java.lang.reflect.AccessibleObject;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Member;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Type;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import javax.validation.ConstraintValidatorFactory;
/*      */ import javax.validation.ConstraintViolation;
/*      */ import javax.validation.ElementKind;
/*      */ import javax.validation.MessageInterpolator;
/*      */ import javax.validation.ParameterNameProvider;
/*      */ import javax.validation.Path;
/*      */ import javax.validation.Path.Node;
/*      */ import javax.validation.TraversableResolver;
/*      */ import javax.validation.Validator;
/*      */ import javax.validation.executable.ExecutableValidator;
/*      */ import javax.validation.groups.Default;
/*      */ import javax.validation.metadata.BeanDescriptor;
/*      */ import org.hibernate.validator.internal.engine.constraintvalidation.ConstraintValidatorManager;
/*      */ import org.hibernate.validator.internal.engine.groups.Group;
/*      */ import org.hibernate.validator.internal.engine.groups.GroupWithInheritance;
/*      */ import org.hibernate.validator.internal.engine.groups.Sequence;
/*      */ import org.hibernate.validator.internal.engine.groups.ValidationOrder;
/*      */ import org.hibernate.validator.internal.engine.groups.ValidationOrderGenerator;
/*      */ import org.hibernate.validator.internal.engine.path.NodeImpl;
/*      */ import org.hibernate.validator.internal.engine.path.PathImpl;
/*      */ import org.hibernate.validator.internal.engine.resolver.CachingTraversableResolverForSingleValidation;
/*      */ import org.hibernate.validator.internal.engine.valuehandling.UnwrapMode;
/*      */ import org.hibernate.validator.internal.metadata.BeanMetaDataManager;
/*      */ import org.hibernate.validator.internal.metadata.aggregated.BeanMetaData;
/*      */ import org.hibernate.validator.internal.metadata.aggregated.ExecutableMetaData;
/*      */ import org.hibernate.validator.internal.metadata.aggregated.ParameterMetaData;
/*      */ import org.hibernate.validator.internal.metadata.aggregated.PropertyMetaData;
/*      */ import org.hibernate.validator.internal.metadata.aggregated.ReturnValueMetaData;
/*      */ import org.hibernate.validator.internal.metadata.core.MetaConstraint;
/*      */ import org.hibernate.validator.internal.metadata.facets.Cascadable;
/*      */ import org.hibernate.validator.internal.metadata.facets.Validatable;
/*      */ import org.hibernate.validator.internal.metadata.location.ConstraintLocation;
/*      */ import org.hibernate.validator.internal.metadata.raw.ExecutableElement;
/*      */ import org.hibernate.validator.internal.util.CollectionHelper;
/*      */ import org.hibernate.validator.internal.util.ConcurrentReferenceHashMap;
/*      */ import org.hibernate.validator.internal.util.ConcurrentReferenceHashMap.ReferenceType;
/*      */ import org.hibernate.validator.internal.util.Contracts;
/*      */ import org.hibernate.validator.internal.util.ReflectionHelper;
/*      */ import org.hibernate.validator.internal.util.TypeHelper;
/*      */ import org.hibernate.validator.internal.util.TypeResolutionHelper;
/*      */ import org.hibernate.validator.internal.util.logging.Log;
/*      */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*      */ import org.hibernate.validator.internal.util.logging.Messages;
/*      */ import org.hibernate.validator.internal.util.privilegedactions.GetDeclaredField;
/*      */ import org.hibernate.validator.internal.util.privilegedactions.GetDeclaredMethod;
/*      */ import org.hibernate.validator.internal.util.privilegedactions.SetAccessibility;
/*      */ import org.hibernate.validator.spi.time.TimeProvider;
/*      */ import org.hibernate.validator.spi.valuehandling.ValidatedValueUnwrapper;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ValidatorImpl
/*      */   implements Validator, ExecutableValidator
/*      */ {
/*      */   private static final String TYPE_USE = "TYPE_USE";
/*   92 */   private static final Log log = ;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   97 */   private static final Collection<Class<?>> DEFAULT_GROUPS = Collections.singletonList(Default.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final transient ValidationOrderGenerator validationOrderGenerator;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final ConstraintValidatorFactory constraintValidatorFactory;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final MessageInterpolator messageInterpolator;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final TraversableResolver traversableResolver;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final BeanMetaDataManager beanMetaDataManager;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final ConstraintValidatorManager constraintValidatorManager;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final ParameterNameProvider parameterNameProvider;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final TimeProvider timeProvider;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final boolean failFast;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final TypeResolutionHelper typeResolutionHelper;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final List<ValidatedValueUnwrapper<?>> validatedValueHandlers;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final ConcurrentMap<Member, Member> accessibleMembers;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ValidatorImpl(ConstraintValidatorFactory constraintValidatorFactory, MessageInterpolator messageInterpolator, TraversableResolver traversableResolver, BeanMetaDataManager beanMetaDataManager, ParameterNameProvider parameterNameProvider, TimeProvider timeProvider, TypeResolutionHelper typeResolutionHelper, List<ValidatedValueUnwrapper<?>> validatedValueHandlers, ConstraintValidatorManager constraintValidatorManager, boolean failFast)
/*      */   {
/*  168 */     this.constraintValidatorFactory = constraintValidatorFactory;
/*  169 */     this.messageInterpolator = messageInterpolator;
/*  170 */     this.traversableResolver = traversableResolver;
/*  171 */     this.beanMetaDataManager = beanMetaDataManager;
/*  172 */     this.parameterNameProvider = parameterNameProvider;
/*  173 */     this.timeProvider = timeProvider;
/*  174 */     this.typeResolutionHelper = typeResolutionHelper;
/*  175 */     this.validatedValueHandlers = validatedValueHandlers;
/*  176 */     this.constraintValidatorManager = constraintValidatorManager;
/*  177 */     this.failFast = failFast;
/*      */     
/*  179 */     this.validationOrderGenerator = new ValidationOrderGenerator();
/*      */     
/*  181 */     this.accessibleMembers = new ConcurrentReferenceHashMap(100, ConcurrentReferenceHashMap.ReferenceType.SOFT, ConcurrentReferenceHashMap.ReferenceType.SOFT);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final <T> Set<ConstraintViolation<T>> validate(T object, Class<?>... groups)
/*      */   {
/*  190 */     Contracts.assertNotNull(object, Messages.MESSAGES.validatedObjectMustNotBeNull());
/*      */     
/*  192 */     if (!this.beanMetaDataManager.isConstrained(object.getClass())) {
/*  193 */       return Collections.emptySet();
/*      */     }
/*      */     
/*  196 */     ValidationOrder validationOrder = determineGroupValidationOrder(groups);
/*  197 */     ValidationContext<T> validationContext = getValidationContext().forValidate(object);
/*      */     
/*  199 */     ValueContext<?, Object> valueContext = ValueContext.getLocalExecutionContext(object, this.beanMetaDataManager
/*      */     
/*  201 */       .getBeanMetaData(object.getClass()), 
/*  202 */       PathImpl.createRootPath());
/*      */     
/*      */ 
/*  205 */     return validateInContext(valueContext, validationContext, validationOrder);
/*      */   }
/*      */   
/*      */   public final <T> Set<ConstraintViolation<T>> validateProperty(T object, String propertyName, Class<?>... groups)
/*      */   {
/*  210 */     Contracts.assertNotNull(object, Messages.MESSAGES.validatedObjectMustNotBeNull());
/*      */     
/*  212 */     sanityCheckPropertyPath(propertyName);
/*  213 */     ValidationOrder validationOrder = determineGroupValidationOrder(groups);
/*  214 */     ValidationContext<T> context = getValidationContext().forValidateProperty(object);
/*      */     
/*  216 */     if (!this.beanMetaDataManager.isConstrained(context.getRootBeanClass())) {
/*  217 */       return Collections.emptySet();
/*      */     }
/*      */     
/*  220 */     return validatePropertyInContext(context, 
/*      */     
/*  222 */       PathImpl.createPathFromString(propertyName), validationOrder);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public final <T> Set<ConstraintViolation<T>> validateValue(Class<T> beanType, String propertyName, Object value, Class<?>... groups)
/*      */   {
/*  229 */     Contracts.assertNotNull(beanType, Messages.MESSAGES.beanTypeCannotBeNull());
/*      */     
/*  231 */     if (!this.beanMetaDataManager.isConstrained(beanType)) {
/*  232 */       return Collections.emptySet();
/*      */     }
/*      */     
/*  235 */     sanityCheckPropertyPath(propertyName);
/*  236 */     ValidationOrder validationOrder = determineGroupValidationOrder(groups);
/*  237 */     ValidationContext<T> context = getValidationContext().forValidateValue(beanType);
/*      */     
/*  239 */     return validateValueInContext(context, value, 
/*      */     
/*      */ 
/*  242 */       PathImpl.createPathFromString(propertyName), validationOrder);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public <T> Set<ConstraintViolation<T>> validateParameters(T object, Method method, Object[] parameterValues, Class<?>... groups)
/*      */   {
/*  249 */     Contracts.assertNotNull(object, Messages.MESSAGES.validatedObjectMustNotBeNull());
/*  250 */     Contracts.assertNotNull(method, Messages.MESSAGES.validatedMethodMustNotBeNull());
/*  251 */     Contracts.assertNotNull(parameterValues, Messages.MESSAGES.validatedParameterArrayMustNotBeNull());
/*      */     
/*  253 */     return validateParameters(object, ExecutableElement.forMethod(method), parameterValues, groups);
/*      */   }
/*      */   
/*      */   public <T> Set<ConstraintViolation<T>> validateConstructorParameters(Constructor<? extends T> constructor, Object[] parameterValues, Class<?>... groups)
/*      */   {
/*  258 */     Contracts.assertNotNull(constructor, Messages.MESSAGES.validatedConstructorMustNotBeNull());
/*  259 */     Contracts.assertNotNull(parameterValues, Messages.MESSAGES.validatedParameterArrayMustNotBeNull());
/*      */     
/*  261 */     return validateParameters(null, ExecutableElement.forConstructor(constructor), parameterValues, groups);
/*      */   }
/*      */   
/*      */   public <T> Set<ConstraintViolation<T>> validateConstructorReturnValue(Constructor<? extends T> constructor, T createdObject, Class<?>... groups)
/*      */   {
/*  266 */     Contracts.assertNotNull(constructor, Messages.MESSAGES.validatedConstructorMustNotBeNull());
/*  267 */     Contracts.assertNotNull(createdObject, Messages.MESSAGES.validatedConstructorCreatedInstanceMustNotBeNull());
/*      */     
/*  269 */     return validateReturnValue(null, ExecutableElement.forConstructor(constructor), createdObject, groups);
/*      */   }
/*      */   
/*      */   public <T> Set<ConstraintViolation<T>> validateReturnValue(T object, Method method, Object returnValue, Class<?>... groups)
/*      */   {
/*  274 */     Contracts.assertNotNull(object, Messages.MESSAGES.validatedObjectMustNotBeNull());
/*  275 */     Contracts.assertNotNull(method, Messages.MESSAGES.validatedMethodMustNotBeNull());
/*      */     
/*  277 */     return validateReturnValue(object, ExecutableElement.forMethod(method), returnValue, groups);
/*      */   }
/*      */   
/*      */   private <T> Set<ConstraintViolation<T>> validateParameters(T object, ExecutableElement executable, Object[] parameterValues, Class<?>... groups)
/*      */   {
/*  282 */     if (parameterValues == null) {
/*  283 */       return Collections.emptySet();
/*      */     }
/*      */     
/*  286 */     ValidationOrder validationOrder = determineGroupValidationOrder(groups);
/*      */     
/*  288 */     ValidationContext<T> context = getValidationContext().forValidateParameters(this.parameterNameProvider, object, executable, parameterValues);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  295 */     if (!this.beanMetaDataManager.isConstrained(context.getRootBeanClass())) {
/*  296 */       return Collections.emptySet();
/*      */     }
/*      */     
/*  299 */     validateParametersInContext(context, parameterValues, validationOrder);
/*      */     
/*  301 */     return context.getFailingConstraints();
/*      */   }
/*      */   
/*      */   private <T> Set<ConstraintViolation<T>> validateReturnValue(T object, ExecutableElement executable, Object returnValue, Class<?>... groups) {
/*  305 */     ValidationOrder validationOrder = determineGroupValidationOrder(groups);
/*      */     
/*  307 */     ValidationContext<T> context = getValidationContext().forValidateReturnValue(object, executable, returnValue);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  313 */     if (!this.beanMetaDataManager.isConstrained(context.getRootBeanClass())) {
/*  314 */       return Collections.emptySet();
/*      */     }
/*      */     
/*  317 */     validateReturnValueInContext(context, object, returnValue, validationOrder);
/*      */     
/*  319 */     return context.getFailingConstraints();
/*      */   }
/*      */   
/*      */   public final BeanDescriptor getConstraintsForClass(Class<?> clazz)
/*      */   {
/*  324 */     return this.beanMetaDataManager.getBeanMetaData(clazz).getBeanDescriptor();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final <T> T unwrap(Class<T> type)
/*      */   {
/*  332 */     if (type.isAssignableFrom(Validator.class)) {
/*  333 */       return (T)type.cast(this);
/*      */     }
/*  335 */     throw log.getTypeNotSupportedForUnwrappingException(type);
/*      */   }
/*      */   
/*      */   public ExecutableValidator forExecutables()
/*      */   {
/*  340 */     return this;
/*      */   }
/*      */   
/*      */   private ValidationContext.ValidationContextBuilder getValidationContext() {
/*  344 */     return ValidationContext.getValidationContext(this.constraintValidatorManager, this.messageInterpolator, this.constraintValidatorFactory, 
/*      */     
/*      */ 
/*      */ 
/*  348 */       getCachingTraversableResolver(), this.timeProvider, this.validatedValueHandlers, this.typeResolutionHelper, this.failFast);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void sanityCheckPropertyPath(String propertyName)
/*      */   {
/*  357 */     if ((propertyName == null) || (propertyName.length() == 0)) {
/*  358 */       throw log.getInvalidPropertyPathException();
/*      */     }
/*      */   }
/*      */   
/*      */   private ValidationOrder determineGroupValidationOrder(Class<?>[] groups) {
/*  363 */     Contracts.assertNotNull(groups, Messages.MESSAGES.groupMustNotBeNull());
/*  364 */     for (Class<?> clazz : groups) {
/*  365 */       if (clazz == null) {
/*  366 */         throw new IllegalArgumentException(Messages.MESSAGES.groupMustNotBeNull());
/*      */       }
/*      */     }
/*      */     
/*      */     Object resultGroups;
/*      */     Object resultGroups;
/*  372 */     if (groups.length == 0) {
/*  373 */       resultGroups = DEFAULT_GROUPS;
/*      */     }
/*      */     else {
/*  376 */       resultGroups = Arrays.asList(groups);
/*      */     }
/*  378 */     return this.validationOrderGenerator.getValidationOrder((Collection)resultGroups);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private <T, U> Set<ConstraintViolation<T>> validateInContext(ValueContext<U, Object> valueContext, ValidationContext<T> context, ValidationOrder validationOrder)
/*      */   {
/*  392 */     if (valueContext.getCurrentBean() == null) {
/*  393 */       return Collections.emptySet();
/*      */     }
/*      */     
/*  396 */     BeanMetaData<U> beanMetaData = this.beanMetaDataManager.getBeanMetaData(valueContext.getCurrentBeanType());
/*  397 */     if (beanMetaData.defaultGroupSequenceIsRedefined()) {
/*  398 */       validationOrder.assertDefaultGroupSequenceIsExpandable(beanMetaData.getDefaultGroupSequence(valueContext.getCurrentBean()));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  403 */     Iterator<Group> groupIterator = validationOrder.getGroupIterator();
/*  404 */     while (groupIterator.hasNext()) {
/*  405 */       Group group = (Group)groupIterator.next();
/*  406 */       valueContext.setCurrentGroup(group.getDefiningClass());
/*  407 */       validateConstraintsForCurrentGroup(context, valueContext);
/*  408 */       if (shouldFailFast(context)) {
/*  409 */         return context.getFailingConstraints();
/*      */       }
/*      */     }
/*  412 */     groupIterator = validationOrder.getGroupIterator();
/*  413 */     while (groupIterator.hasNext()) {
/*  414 */       Group group = (Group)groupIterator.next();
/*  415 */       valueContext.setCurrentGroup(group.getDefiningClass());
/*  416 */       validateCascadedConstraints(context, valueContext);
/*  417 */       if (shouldFailFast(context)) {
/*  418 */         return context.getFailingConstraints();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  423 */     Iterator<Sequence> sequenceIterator = validationOrder.getSequenceIterator();
/*  424 */     while (sequenceIterator.hasNext()) {
/*  425 */       Sequence sequence = (Sequence)sequenceIterator.next();
/*  426 */       for (GroupWithInheritance groupOfGroups : sequence) {
/*  427 */         int numberOfViolations = context.getFailingConstraints().size();
/*      */         
/*  429 */         for (Group group : groupOfGroups) {
/*  430 */           valueContext.setCurrentGroup(group.getDefiningClass());
/*      */           
/*  432 */           validateConstraintsForCurrentGroup(context, valueContext);
/*  433 */           if (shouldFailFast(context)) {
/*  434 */             return context.getFailingConstraints();
/*      */           }
/*      */           
/*  437 */           validateCascadedConstraints(context, valueContext);
/*  438 */           if (shouldFailFast(context)) {
/*  439 */             return context.getFailingConstraints();
/*      */           }
/*      */         }
/*  442 */         if (context.getFailingConstraints().size() > numberOfViolations) {
/*      */           break;
/*      */         }
/*      */       }
/*      */     }
/*  447 */     return context.getFailingConstraints();
/*      */   }
/*      */   
/*      */ 
/*      */   private void validateConstraintsForCurrentGroup(ValidationContext<?> validationContext, ValueContext<?, Object> valueContext)
/*      */   {
/*  453 */     if (!valueContext.validatingDefault()) {
/*  454 */       validateConstraintsForNonDefaultGroup(validationContext, valueContext);
/*      */     }
/*      */     else {
/*  457 */       validateConstraintsForDefaultGroup(validationContext, valueContext);
/*      */     }
/*      */   }
/*      */   
/*      */   private <U> void validateConstraintsForDefaultGroup(ValidationContext<?> validationContext, ValueContext<U, Object> valueContext) {
/*  462 */     BeanMetaData<U> beanMetaData = this.beanMetaDataManager.getBeanMetaData(valueContext.getCurrentBeanType());
/*  463 */     Map<Class<?>, Class<?>> validatedInterfaces = CollectionHelper.newHashMap();
/*      */     
/*      */ 
/*  466 */     for (Class<? super U> clazz : beanMetaData.getClassHierarchy()) {
/*  467 */       BeanMetaData<? super U> hostingBeanMetaData = this.beanMetaDataManager.getBeanMetaData(clazz);
/*  468 */       boolean defaultGroupSequenceIsRedefined = hostingBeanMetaData.defaultGroupSequenceIsRedefined();
/*      */       
/*      */ 
/*  471 */       if (defaultGroupSequenceIsRedefined) {
/*  472 */         Iterator<Sequence> defaultGroupSequence = hostingBeanMetaData.getDefaultValidationSequence(valueContext.getCurrentBean());
/*  473 */         Set<MetaConstraint<?>> metaConstraints = hostingBeanMetaData.getMetaConstraints();
/*      */         
/*  475 */         while (defaultGroupSequence.hasNext()) {
/*  476 */           for (GroupWithInheritance groupOfGroups : (Sequence)defaultGroupSequence.next()) {
/*  477 */             boolean validationSuccessful = true;
/*      */             
/*  479 */             for (Group defaultSequenceMember : groupOfGroups) {
/*  480 */               validationSuccessful = validateConstraintsForSingleDefaultGroupElement(validationContext, valueContext, validatedInterfaces, clazz, metaConstraints, defaultSequenceMember);
/*      */             }
/*      */             
/*  483 */             if (!validationSuccessful) {
/*      */               break;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  491 */         Set<MetaConstraint<?>> metaConstraints = hostingBeanMetaData.getDirectMetaConstraints();
/*  492 */         validateConstraintsForSingleDefaultGroupElement(validationContext, valueContext, validatedInterfaces, clazz, metaConstraints, Group.DEFAULT_GROUP);
/*      */       }
/*      */       
/*      */ 
/*  496 */       validationContext.markCurrentBeanAsProcessed(valueContext);
/*      */       
/*      */ 
/*  499 */       if (defaultGroupSequenceIsRedefined) {
/*      */         break;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private <U> boolean validateConstraintsForSingleDefaultGroupElement(ValidationContext<?> validationContext, ValueContext<U, Object> valueContext, Map<Class<?>, Class<?>> validatedInterfaces, Class<? super U> clazz, Set<MetaConstraint<?>> metaConstraints, Group defaultSequenceMember)
/*      */   {
/*  507 */     boolean validationSuccessful = true;
/*      */     
/*  509 */     valueContext.setCurrentGroup(defaultSequenceMember.getDefiningClass());
/*  510 */     PathImpl currentPath = valueContext.getPropertyPath();
/*      */     
/*  512 */     for (MetaConstraint<?> metaConstraint : metaConstraints)
/*      */     {
/*      */ 
/*  515 */       Class<?> declaringClass = metaConstraint.getLocation().getDeclaringClass();
/*  516 */       if (declaringClass.isInterface()) {
/*  517 */         Class<?> validatedForClass = (Class)validatedInterfaces.get(declaringClass);
/*  518 */         if ((validatedForClass == null) || (validatedForClass.equals(clazz)))
/*      */         {
/*      */ 
/*  521 */           validatedInterfaces.put(declaringClass, clazz);
/*      */         }
/*      */       } else {
/*  524 */         boolean tmp = validateConstraint(validationContext, valueContext, false, metaConstraint);
/*  525 */         if (shouldFailFast(validationContext)) {
/*  526 */           return false;
/*      */         }
/*      */         
/*  529 */         validationSuccessful = (validationSuccessful) && (tmp);
/*      */         
/*  531 */         valueContext.setPropertyPath(currentPath);
/*      */       } }
/*  533 */     return validationSuccessful;
/*      */   }
/*      */   
/*      */   private void validateConstraintsForNonDefaultGroup(ValidationContext<?> validationContext, ValueContext<?, Object> valueContext) {
/*  537 */     BeanMetaData<?> beanMetaData = this.beanMetaDataManager.getBeanMetaData(valueContext.getCurrentBeanType());
/*  538 */     PathImpl currentPath = valueContext.getPropertyPath();
/*  539 */     for (MetaConstraint<?> metaConstraint : beanMetaData.getMetaConstraints()) {
/*  540 */       validateConstraint(validationContext, valueContext, false, metaConstraint);
/*  541 */       if (shouldFailFast(validationContext)) {
/*  542 */         return;
/*      */       }
/*      */       
/*  545 */       valueContext.setPropertyPath(currentPath);
/*      */     }
/*  547 */     validationContext.markCurrentBeanAsProcessed(valueContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean validateConstraint(ValidationContext<?> validationContext, ValueContext<?, Object> valueContext, boolean propertyPathComplete, MetaConstraint<?> metaConstraint)
/*      */   {
/*  557 */     if (metaConstraint.getElementType() != ElementType.TYPE)
/*      */     {
/*  559 */       PropertyMetaData propertyMetaData = this.beanMetaDataManager.getBeanMetaData(valueContext.getCurrentBeanType()).getMetaDataFor(
/*  560 */         ReflectionHelper.getPropertyName(metaConstraint.getLocation().getMember()));
/*      */       
/*      */ 
/*  563 */       if (!propertyPathComplete) {
/*  564 */         valueContext.appendNode(propertyMetaData);
/*      */       }
/*      */       
/*  567 */       if ("TYPE_USE".equals(metaConstraint.getElementType().name()))
/*      */       {
/*  569 */         valueContext.setUnwrapMode(UnwrapMode.UNWRAP);
/*      */       }
/*      */       else
/*      */       {
/*  573 */         valueContext.setUnwrapMode(propertyMetaData.unwrapMode());
/*      */       }
/*      */     }
/*      */     else {
/*  577 */       valueContext.appendBeanNode();
/*      */     }
/*      */     
/*  580 */     boolean validationSuccessful = validateMetaConstraint(validationContext, valueContext, metaConstraint);
/*      */     
/*      */ 
/*  583 */     valueContext.setUnwrapMode(UnwrapMode.AUTOMATIC);
/*  584 */     return validationSuccessful;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean validatePropertyTypeConstraint(ValidationContext<?> validationContext, ValueContext<?, Object> valueContext, boolean propertyPathComplete, MetaConstraint<?> metaConstraint)
/*      */   {
/*  593 */     PropertyMetaData propertyMetaData = this.beanMetaDataManager.getBeanMetaData(valueContext.getCurrentBeanType()).getMetaDataFor(
/*  594 */       ReflectionHelper.getPropertyName(metaConstraint.getLocation().getMember()));
/*      */     
/*      */ 
/*  597 */     if (!propertyPathComplete) {
/*  598 */       valueContext.appendNode(propertyMetaData);
/*      */     }
/*      */     
/*  601 */     valueContext.setUnwrapMode(UnwrapMode.UNWRAP);
/*  602 */     boolean validationSuccessful = validateMetaConstraint(validationContext, valueContext, metaConstraint);
/*  603 */     valueContext.setUnwrapMode(UnwrapMode.AUTOMATIC);
/*      */     
/*  605 */     return validationSuccessful;
/*      */   }
/*      */   
/*      */   private boolean validateMetaConstraint(ValidationContext<?> validationContext, ValueContext<?, Object> valueContext, MetaConstraint<?> metaConstraint) {
/*  609 */     if (isValidationRequired(validationContext, valueContext, metaConstraint)) {
/*  610 */       if (valueContext.getCurrentBean() != null) {
/*  611 */         Object valueToValidate = getValue(metaConstraint
/*  612 */           .getLocation().getMember(), valueContext
/*  613 */           .getCurrentBean());
/*      */         
/*  615 */         valueContext.setCurrentValidatedValue(valueToValidate);
/*      */       }
/*  617 */       return metaConstraint.validateConstraint(validationContext, valueContext);
/*      */     }
/*  619 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void validateCascadedConstraints(ValidationContext<?> validationContext, ValueContext<?, Object> valueContext)
/*      */   {
/*  630 */     Validatable validatable = valueContext.getCurrentValidatable();
/*  631 */     PathImpl originalPath = valueContext.getPropertyPath();
/*  632 */     Class<?> originalGroup = valueContext.getCurrentGroup();
/*      */     
/*  634 */     for (Cascadable cascadable : validatable.getCascadables()) {
/*  635 */       valueContext.appendNode(cascadable);
/*  636 */       Class<?> group = cascadable.convertGroup(originalGroup);
/*  637 */       valueContext.setCurrentGroup(group);
/*      */       
/*  639 */       ElementType elementType = cascadable.getElementType();
/*  640 */       if (isCascadeRequired(validationContext, valueContext
/*      */       
/*  642 */         .getCurrentBean(), valueContext
/*  643 */         .getPropertyPath(), elementType))
/*      */       {
/*      */ 
/*      */ 
/*  647 */         Object value = getValue(valueContext.getCurrentBean(), validationContext, cascadable);
/*      */         
/*  649 */         if (value != null)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  654 */           ValidationOrder validationOrder = this.validationOrderGenerator.getValidationOrder(group, group != originalGroup);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  659 */           Type type = value.getClass();
/*      */           
/*      */ 
/*  662 */           if ((ReflectionHelper.isIterable(type)) || (ReflectionHelper.isMap(type))) {
/*  663 */             Iterator<?> valueIter = Collections.singletonList(value).iterator();
/*  664 */             validateCascadedConstraint(validationContext, valueIter, false, valueContext, validationOrder, 
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  670 */               Collections.emptySet());
/*      */             
/*  672 */             if (shouldFailFast(validationContext)) {
/*  673 */               return;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*  678 */           Iterator<?> elementsIter = createIteratorForCascadedValue(type, value, valueContext);
/*  679 */           boolean isIndexable = isIndexable(type);
/*      */           
/*  681 */           validateCascadedConstraint(validationContext, elementsIter, isIndexable, valueContext, validationOrder, cascadable
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  687 */             .getTypeArgumentsConstraints());
/*      */           
/*  689 */           if (shouldFailFast(validationContext)) {
/*  690 */             return;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  696 */       valueContext.setPropertyPath(originalPath);
/*  697 */       valueContext.setCurrentGroup(originalGroup);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Iterator<?> createIteratorForCascadedValue(Type type, Object value, ValueContext<?, ?> valueContext)
/*      */   {
/*      */     Iterator<?> iter;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  713 */     if (ReflectionHelper.isIterable(type)) {
/*  714 */       Iterator<?> iter = ((Iterable)value).iterator();
/*  715 */       valueContext.markCurrentPropertyAsIterable();
/*      */     }
/*  717 */     else if (ReflectionHelper.isMap(type)) {
/*  718 */       Map<?, ?> map = (Map)value;
/*  719 */       Iterator<?> iter = map.entrySet().iterator();
/*  720 */       valueContext.markCurrentPropertyAsIterable();
/*      */     }
/*  722 */     else if (TypeHelper.isArray(type)) {
/*  723 */       List<?> arrayList = Arrays.asList((Object[])value);
/*  724 */       Iterator<?> iter = arrayList.iterator();
/*  725 */       valueContext.markCurrentPropertyAsIterable();
/*      */     }
/*      */     else {
/*  728 */       iter = Collections.singletonList(value).iterator();
/*      */     }
/*  730 */     return iter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isIndexable(Type type)
/*      */   {
/*  742 */     boolean isIndexable = false;
/*  743 */     if (ReflectionHelper.isList(type)) {
/*  744 */       isIndexable = true;
/*      */     }
/*  746 */     else if (ReflectionHelper.isMap(type)) {
/*  747 */       isIndexable = true;
/*      */     }
/*  749 */     else if (TypeHelper.isArray(type)) {
/*  750 */       isIndexable = true;
/*      */     }
/*  752 */     return isIndexable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void validateCascadedConstraint(ValidationContext<?> context, Iterator<?> iter, boolean isIndexable, ValueContext<?, Object> valueContext, ValidationOrder validationOrder, Set<MetaConstraint<?>> typeArgumentsConstraint)
/*      */   {
/*  759 */     int i = 0;
/*  760 */     while (iter.hasNext()) {
/*  761 */       Object value = iter.next();
/*  762 */       if ((value instanceof Map.Entry)) {
/*  763 */         Object mapKey = ((Map.Entry)value).getKey();
/*  764 */         valueContext.setKey(mapKey);
/*  765 */         value = ((Map.Entry)value).getValue();
/*      */       }
/*  767 */       else if (isIndexable) {
/*  768 */         valueContext.setIndex(Integer.valueOf(i));
/*      */       }
/*      */       
/*  771 */       if (!context.isBeanAlreadyValidated(value, valueContext
/*      */       
/*  773 */         .getCurrentGroup(), valueContext
/*  774 */         .getPropertyPath()))
/*      */       {
/*  776 */         validateTypeArgumentConstraints(context, valueContext, value, typeArgumentsConstraint);
/*      */         
/*      */         ValueContext<?, Object> newValueContext;
/*      */         ValueContext<?, Object> newValueContext;
/*  780 */         if (value != null) {
/*  781 */           newValueContext = ValueContext.getLocalExecutionContext(value, this.beanMetaDataManager
/*      */           
/*  783 */             .getBeanMetaData(value.getClass()), valueContext
/*  784 */             .getPropertyPath());
/*      */         }
/*      */         else
/*      */         {
/*  788 */           newValueContext = ValueContext.getLocalExecutionContext(valueContext
/*  789 */             .getCurrentBeanType(), this.beanMetaDataManager
/*  790 */             .getBeanMetaData(valueContext.getCurrentBeanType()), valueContext
/*  791 */             .getPropertyPath());
/*      */         }
/*      */         
/*      */ 
/*  795 */         validateInContext(newValueContext, context, validationOrder);
/*  796 */         if (shouldFailFast(context)) {
/*  797 */           return;
/*      */         }
/*      */       }
/*  800 */       i++;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void validateTypeArgumentConstraints(ValidationContext<?> context, ValueContext<?, Object> valueContext, Object value, Set<MetaConstraint<?>> typeArgumentsConstraints)
/*      */   {
/*  808 */     valueContext.setCurrentValidatedValue(value);
/*  809 */     for (MetaConstraint<?> metaConstraint : typeArgumentsConstraints) {
/*  810 */       metaConstraint.validateConstraint(context, valueContext);
/*  811 */       if (shouldFailFast(context)) {
/*  812 */         return;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private <T> Set<ConstraintViolation<T>> validatePropertyInContext(ValidationContext<T> context, PathImpl propertyPath, ValidationOrder validationOrder) {
/*  818 */     List<MetaConstraint<?>> metaConstraints = CollectionHelper.newArrayList();
/*  819 */     List<MetaConstraint<?>> typeUseConstraints = CollectionHelper.newArrayList();
/*  820 */     Iterator<Path.Node> propertyIter = propertyPath.iterator();
/*  821 */     ValueContext<?, Object> valueContext = collectMetaConstraintsForPath(context, propertyIter, propertyPath, metaConstraints, typeUseConstraints);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  829 */     if (valueContext.getCurrentBean() == null) {
/*  830 */       throw log.getInvalidPropertyPathException();
/*      */     }
/*      */     
/*  833 */     if ((metaConstraints.size() == 0) && (typeUseConstraints.size() == 0)) {
/*  834 */       return context.getFailingConstraints();
/*      */     }
/*      */     
/*  837 */     assertDefaultGroupSequenceIsExpandable(valueContext, validationOrder);
/*      */     
/*      */ 
/*  840 */     Iterator<Group> groupIterator = validationOrder.getGroupIterator();
/*  841 */     while (groupIterator.hasNext()) {
/*  842 */       Group group = (Group)groupIterator.next();
/*  843 */       valueContext.setCurrentGroup(group.getDefiningClass());
/*  844 */       validatePropertyForCurrentGroup(valueContext, context, metaConstraints, typeUseConstraints);
/*  845 */       if (shouldFailFast(context)) {
/*  846 */         return context.getFailingConstraints();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  851 */     Iterator<Sequence> sequenceIterator = validationOrder.getSequenceIterator();
/*  852 */     while (sequenceIterator.hasNext()) {
/*  853 */       Sequence sequence = (Sequence)sequenceIterator.next();
/*      */       
/*  855 */       for (GroupWithInheritance groupOfGroups : sequence) {
/*  856 */         int numberOfConstraintViolations = 0;
/*      */         
/*  858 */         for (Group group : groupOfGroups) {
/*  859 */           valueContext.setCurrentGroup(group.getDefiningClass());
/*  860 */           numberOfConstraintViolations += validatePropertyForCurrentGroup(valueContext, context, metaConstraints, typeUseConstraints);
/*      */           
/*      */ 
/*  863 */           if (shouldFailFast(context)) {
/*  864 */             return context.getFailingConstraints();
/*      */           }
/*      */         }
/*  867 */         if (numberOfConstraintViolations > 0) {
/*      */           break;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  873 */     return context.getFailingConstraints();
/*      */   }
/*      */   
/*      */   private <T> void assertDefaultGroupSequenceIsExpandable(ValueContext<T, ?> valueContext, ValidationOrder validationOrder) {
/*  877 */     BeanMetaData<T> beanMetaData = this.beanMetaDataManager.getBeanMetaData(valueContext.getCurrentBeanType());
/*  878 */     if (beanMetaData.defaultGroupSequenceIsRedefined()) {
/*  879 */       validationOrder.assertDefaultGroupSequenceIsExpandable(beanMetaData.getDefaultGroupSequence(valueContext.getCurrentBean()));
/*      */     }
/*      */   }
/*      */   
/*      */   private <T> Set<ConstraintViolation<T>> validateValueInContext(ValidationContext<T> context, Object value, PathImpl propertyPath, ValidationOrder validationOrder) {
/*  884 */     List<MetaConstraint<?>> metaConstraints = CollectionHelper.newArrayList();
/*  885 */     List<MetaConstraint<?>> typeArgumentConstraints = CollectionHelper.newArrayList();
/*  886 */     ValueContext<?, Object> valueContext = collectMetaConstraintsForPath(context, propertyPath
/*  887 */       .iterator(), propertyPath, metaConstraints, typeArgumentConstraints);
/*      */     
/*  889 */     valueContext.setCurrentValidatedValue(value);
/*      */     
/*  891 */     if ((metaConstraints.size() == 0) && (typeArgumentConstraints.size() == 0)) {
/*  892 */       return context.getFailingConstraints();
/*      */     }
/*      */     
/*  895 */     BeanMetaData<?> beanMetaData = this.beanMetaDataManager.getBeanMetaData(valueContext.getCurrentBeanType());
/*  896 */     if (beanMetaData.defaultGroupSequenceIsRedefined()) {
/*  897 */       validationOrder.assertDefaultGroupSequenceIsExpandable(beanMetaData.getDefaultGroupSequence(null));
/*      */     }
/*      */     
/*      */ 
/*  901 */     Iterator<Group> groupIterator = validationOrder.getGroupIterator();
/*  902 */     while (groupIterator.hasNext()) {
/*  903 */       Group group = (Group)groupIterator.next();
/*  904 */       valueContext.setCurrentGroup(group.getDefiningClass());
/*  905 */       validatePropertyForCurrentGroup(valueContext, context, metaConstraints, typeArgumentConstraints);
/*  906 */       if (shouldFailFast(context)) {
/*  907 */         return context.getFailingConstraints();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  912 */     Iterator<Sequence> sequenceIterator = validationOrder.getSequenceIterator();
/*  913 */     while (sequenceIterator.hasNext()) {
/*  914 */       Sequence sequence = (Sequence)sequenceIterator.next();
/*  915 */       for (GroupWithInheritance groupOfGroups : sequence) {
/*  916 */         int numberOfConstraintViolations = 0;
/*  917 */         for (Group group : groupOfGroups) {
/*  918 */           valueContext.setCurrentGroup(group.getDefiningClass());
/*  919 */           numberOfConstraintViolations += validatePropertyForCurrentGroup(valueContext, context, metaConstraints, typeArgumentConstraints);
/*      */           
/*      */ 
/*  922 */           if (shouldFailFast(context)) {
/*  923 */             return context.getFailingConstraints();
/*      */           }
/*      */         }
/*  926 */         if (numberOfConstraintViolations > 0) {
/*      */           break;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  932 */     return context.getFailingConstraints();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int validatePropertyForCurrentGroup(ValueContext<?, Object> valueContext, ValidationContext<?> validationContext, List<MetaConstraint<?>> metaConstraints, List<MetaConstraint<?>> typeUseConstraints)
/*      */   {
/*  947 */     if (!valueContext.validatingDefault()) {
/*  948 */       return validatePropertyForNonDefaultGroup(valueContext, validationContext, metaConstraints, typeUseConstraints);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  957 */     return validatePropertyForDefaultGroup(valueContext, validationContext, metaConstraints, typeUseConstraints);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int validatePropertyForNonDefaultGroup(ValueContext<?, Object> valueContext, ValidationContext<?> validationContext, List<MetaConstraint<?>> metaConstraints, List<MetaConstraint<?>> typeArgumentConstraints)
/*      */   {
/*  975 */     int numberOfConstraintViolationsBefore = validationContext.getFailingConstraints().size();
/*  976 */     for (MetaConstraint<?> metaConstraint : metaConstraints) {
/*  977 */       validateConstraint(validationContext, valueContext, true, metaConstraint);
/*  978 */       if (shouldFailFast(validationContext))
/*      */       {
/*  980 */         return validationContext.getFailingConstraints().size() - numberOfConstraintViolationsBefore;
/*      */       }
/*      */     }
/*  983 */     for (MetaConstraint<?> metaConstraint : typeArgumentConstraints) {
/*  984 */       validatePropertyTypeConstraint(validationContext, valueContext, true, metaConstraint);
/*  985 */       if (shouldFailFast(validationContext))
/*      */       {
/*  987 */         return validationContext.getFailingConstraints().size() - numberOfConstraintViolationsBefore;
/*      */       }
/*      */     }
/*  990 */     return validationContext.getFailingConstraints().size() - numberOfConstraintViolationsBefore;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private <U> int validatePropertyForDefaultGroup(ValueContext<U, Object> valueContext, ValidationContext<?> validationContext, List<MetaConstraint<?>> constraintList, List<MetaConstraint<?>> typeUseConstraints)
/*      */   {
/* 1010 */     int numberOfConstraintViolationsBefore = validationContext.getFailingConstraints().size();
/* 1011 */     BeanMetaData<U> beanMetaData = this.beanMetaDataManager.getBeanMetaData(valueContext.getCurrentBeanType());
/* 1012 */     Map<Class<?>, Class<?>> validatedInterfaces = CollectionHelper.newHashMap();
/*      */     
/*      */ 
/* 1015 */     for (Class<? super U> clazz : beanMetaData.getClassHierarchy()) {
/* 1016 */       BeanMetaData<? super U> hostingBeanMetaData = this.beanMetaDataManager.getBeanMetaData(clazz);
/* 1017 */       boolean defaultGroupSequenceIsRedefined = hostingBeanMetaData.defaultGroupSequenceIsRedefined();
/*      */       
/* 1019 */       if (defaultGroupSequenceIsRedefined) {
/* 1020 */         Iterator<Sequence> defaultGroupSequence = hostingBeanMetaData.getDefaultValidationSequence(valueContext.getCurrentBean());
/* 1021 */         Set<MetaConstraint<?>> metaConstraints = hostingBeanMetaData.getMetaConstraints();
/*      */         
/* 1023 */         while (defaultGroupSequence.hasNext()) {
/* 1024 */           for (GroupWithInheritance groupOfGroups : (Sequence)defaultGroupSequence.next()) {
/* 1025 */             boolean validationSuccessful = true;
/*      */             
/* 1027 */             for (Group groupClass : groupOfGroups) {
/* 1028 */               validationSuccessful = validatePropertyForSingleDefaultGroupElement(valueContext, validationContext, constraintList, typeUseConstraints, validatedInterfaces, clazz, metaConstraints, groupClass);
/*      */             }
/*      */             
/*      */ 
/* 1032 */             if (!validationSuccessful) {
/*      */               break;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1040 */         Set<MetaConstraint<?>> metaConstraints = hostingBeanMetaData.getDirectMetaConstraints();
/*      */         
/* 1042 */         validatePropertyForSingleDefaultGroupElement(valueContext, validationContext, constraintList, typeUseConstraints, validatedInterfaces, clazz, metaConstraints, Group.DEFAULT_GROUP);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1047 */       if (defaultGroupSequenceIsRedefined) {
/*      */         break;
/*      */       }
/*      */     }
/* 1051 */     return validationContext.getFailingConstraints().size() - numberOfConstraintViolationsBefore;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private <U> boolean validatePropertyForSingleDefaultGroupElement(ValueContext<U, Object> valueContext, ValidationContext<?> validationContext, List<MetaConstraint<?>> constraintList, List<MetaConstraint<?>> typeUseConstraints, Map<Class<?>, Class<?>> validatedInterfaces, Class<? super U> clazz, Set<MetaConstraint<?>> metaConstraints, Group groupClass)
/*      */   {
/* 1058 */     valueContext.setCurrentGroup(groupClass.getDefiningClass());
/* 1059 */     boolean validationSuccessful = true;
/*      */     
/* 1061 */     for (MetaConstraint<?> metaConstraint : metaConstraints)
/*      */     {
/*      */ 
/* 1064 */       Class<?> declaringClass = metaConstraint.getLocation().getDeclaringClass();
/* 1065 */       if (declaringClass.isInterface()) {
/* 1066 */         Class<?> validatedForClass = (Class)validatedInterfaces.get(declaringClass);
/* 1067 */         if ((validatedForClass == null) || (validatedForClass.equals(clazz)))
/*      */         {
/*      */ 
/* 1070 */           validatedInterfaces.put(declaringClass, clazz);
/*      */         }
/*      */       } else {
/* 1073 */         if (constraintList.contains(metaConstraint)) {
/* 1074 */           boolean tmp = validateConstraint(validationContext, valueContext, true, metaConstraint);
/*      */           
/* 1076 */           validationSuccessful = (validationSuccessful) && (tmp);
/* 1077 */           if (shouldFailFast(validationContext)) {
/* 1078 */             return false;
/*      */           }
/*      */         }
/*      */         
/* 1082 */         if (typeUseConstraints.contains(metaConstraint)) {
/* 1083 */           boolean tmp = validatePropertyTypeConstraint(validationContext, valueContext, true, metaConstraint);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1089 */           validationSuccessful = (validationSuccessful) && (tmp);
/* 1090 */           if (shouldFailFast(validationContext)) {
/* 1091 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1096 */     return validationSuccessful;
/*      */   }
/*      */   
/*      */ 
/*      */   private <T> void validateParametersInContext(ValidationContext<T> validationContext, Object[] parameterValues, ValidationOrder validationOrder)
/*      */   {
/* 1102 */     BeanMetaData<T> beanMetaData = this.beanMetaDataManager.getBeanMetaData(validationContext.getRootBeanClass());
/* 1103 */     ExecutableMetaData executableMetaData = beanMetaData.getMetaDataFor(validationContext.getExecutable());
/*      */     
/* 1105 */     if (executableMetaData == null)
/*      */     {
/* 1107 */       throw log.getMethodOrConstructorNotDefinedByValidatedTypeException(beanMetaData
/* 1108 */         .getBeanClass().getName(), validationContext
/* 1109 */         .getExecutable().getMember());
/*      */     }
/*      */     
/*      */ 
/* 1113 */     if (beanMetaData.defaultGroupSequenceIsRedefined()) {
/* 1114 */       validationOrder.assertDefaultGroupSequenceIsExpandable(beanMetaData
/* 1115 */         .getDefaultGroupSequence(validationContext
/* 1116 */         .getRootBean()));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1122 */     Iterator<Group> groupIterator = validationOrder.getGroupIterator();
/* 1123 */     while (groupIterator.hasNext()) {
/* 1124 */       validateParametersForGroup(validationContext, parameterValues, (Group)groupIterator.next());
/* 1125 */       if (shouldFailFast(validationContext)) {
/* 1126 */         return;
/*      */       }
/*      */     }
/*      */     
/* 1130 */     ValueContext<Object[], Object> cascadingValueContext = ValueContext.getLocalExecutionContext(parameterValues, executableMetaData
/*      */     
/* 1132 */       .getValidatableParametersMetaData(), 
/* 1133 */       PathImpl.createPathForExecutable(executableMetaData));
/*      */     
/* 1135 */     cascadingValueContext.setUnwrapMode(executableMetaData.unwrapMode());
/*      */     
/* 1137 */     groupIterator = validationOrder.getGroupIterator();
/* 1138 */     while (groupIterator.hasNext()) {
/* 1139 */       Group group = (Group)groupIterator.next();
/* 1140 */       cascadingValueContext.setCurrentGroup(group.getDefiningClass());
/* 1141 */       validateCascadedConstraints(validationContext, cascadingValueContext);
/* 1142 */       if (shouldFailFast(validationContext)) {
/* 1143 */         return;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1148 */     Iterator<Sequence> sequenceIterator = validationOrder.getSequenceIterator();
/* 1149 */     while (sequenceIterator.hasNext()) {
/* 1150 */       Sequence sequence = (Sequence)sequenceIterator.next();
/* 1151 */       for (GroupWithInheritance groupOfGroups : sequence) {
/* 1152 */         int numberOfFailingConstraint = 0;
/*      */         
/* 1154 */         for (Group group : groupOfGroups) {
/* 1155 */           numberOfFailingConstraint += validateParametersForGroup(validationContext, parameterValues, group);
/*      */           
/*      */ 
/* 1158 */           if (shouldFailFast(validationContext)) {
/* 1159 */             return;
/*      */           }
/*      */           
/* 1162 */           cascadingValueContext.setCurrentGroup(group.getDefiningClass());
/* 1163 */           validateCascadedConstraints(validationContext, cascadingValueContext);
/*      */           
/* 1165 */           if (shouldFailFast(validationContext)) {
/* 1166 */             return;
/*      */           }
/*      */         }
/*      */         
/* 1170 */         if (numberOfFailingConstraint > 0) {
/*      */           break;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private <T> int validateParametersForGroup(ValidationContext<T> validationContext, Object[] parameterValues, Group group) {
/* 1178 */     int numberOfViolationsBefore = validationContext.getFailingConstraints().size();
/*      */     
/* 1180 */     BeanMetaData<T> beanMetaData = this.beanMetaDataManager.getBeanMetaData(validationContext.getRootBeanClass());
/* 1181 */     ExecutableMetaData executableMetaData = beanMetaData.getMetaDataFor(validationContext.getExecutable());
/*      */     
/* 1183 */     if (parameterValues.length != executableMetaData.getParameterTypes().length) {
/* 1184 */       throw log.getInvalidParameterCountForExecutableException(
/* 1185 */         ExecutableElement.getExecutableAsString(executableMetaData
/* 1186 */         .getType().toString() + "#" + executableMetaData.getName(), executableMetaData
/* 1187 */         .getParameterTypes()), parameterValues.length, executableMetaData
/* 1188 */         .getParameterTypes().length);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1197 */     if (group.isDefaultGroup()) {
/* 1198 */       Iterator<Sequence> defaultGroupSequence = beanMetaData.getDefaultValidationSequence(validationContext.getRootBean());
/*      */       
/* 1200 */       while (defaultGroupSequence.hasNext()) {
/* 1201 */         Sequence sequence = (Sequence)defaultGroupSequence.next();
/* 1202 */         for (GroupWithInheritance expandedGroup : sequence) {
/* 1203 */           int numberOfViolationsOfCurrentGroup = 0;
/*      */           
/* 1205 */           for (Group defaultGroupSequenceElement : expandedGroup) {
/* 1206 */             numberOfViolationsOfCurrentGroup += validateParametersForSingleGroup(validationContext, parameterValues, executableMetaData, defaultGroupSequenceElement.getDefiningClass());
/*      */             
/* 1208 */             if (shouldFailFast(validationContext)) {
/* 1209 */               return validationContext.getFailingConstraints().size() - numberOfViolationsBefore;
/*      */             }
/*      */           }
/*      */           
/* 1213 */           if (numberOfViolationsOfCurrentGroup > 0) {
/* 1214 */             return validationContext.getFailingConstraints().size() - numberOfViolationsBefore;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/* 1220 */       validateParametersForSingleGroup(validationContext, parameterValues, executableMetaData, group.getDefiningClass());
/*      */     }
/*      */     
/* 1223 */     return validationContext.getFailingConstraints().size() - numberOfViolationsBefore;
/*      */   }
/*      */   
/*      */   private <T> int validateParametersForSingleGroup(ValidationContext<T> validationContext, Object[] parameterValues, ExecutableMetaData executableMetaData, Class<?> currentValidatedGroup) {
/* 1227 */     int numberOfViolationsBefore = validationContext.getFailingConstraints().size();
/*      */     
/* 1229 */     ValueContext<T, Object> valueContext = getExecutableValueContext(validationContext
/* 1230 */       .getRootBean(), executableMetaData, currentValidatedGroup);
/*      */     
/* 1232 */     valueContext.appendCrossParameterNode();
/* 1233 */     valueContext.setCurrentValidatedValue(parameterValues);
/*      */     
/*      */ 
/* 1236 */     validateConstraintsForGroup(validationContext, valueContext, executableMetaData
/* 1237 */       .getCrossParameterConstraints());
/*      */     
/* 1239 */     if (shouldFailFast(validationContext)) {
/* 1240 */       return validationContext.getFailingConstraints().size() - numberOfViolationsBefore;
/*      */     }
/*      */     
/* 1243 */     valueContext = getExecutableValueContext(validationContext
/* 1244 */       .getRootBean(), executableMetaData, currentValidatedGroup);
/*      */     
/* 1246 */     valueContext.setCurrentValidatedValue(parameterValues);
/*      */     
/*      */ 
/* 1249 */     for (int i = 0; i < parameterValues.length; i++) {
/* 1250 */       PathImpl originalPath = valueContext.getPropertyPath();
/*      */       
/* 1252 */       ParameterMetaData parameterMetaData = executableMetaData.getParameterMetaData(i);
/* 1253 */       Object value = parameterValues[i];
/*      */       
/* 1255 */       if (value != null) {
/* 1256 */         Class<?> valueType = value.getClass();
/* 1257 */         if (((parameterMetaData.getType() instanceof Class)) && (((Class)parameterMetaData.getType()).isPrimitive())) {
/* 1258 */           valueType = ReflectionHelper.unBoxedType(valueType);
/*      */         }
/* 1260 */         if (!TypeHelper.isAssignable(
/* 1261 */           TypeHelper.getErasedType(parameterMetaData.getType()), valueType))
/*      */         {
/*      */ 
/* 1264 */           throw log.getParameterTypesDoNotMatchException(valueType
/* 1265 */             .getName(), parameterMetaData
/* 1266 */             .getType().toString(), i, validationContext
/*      */             
/* 1268 */             .getExecutable().getMember());
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1273 */       valueContext.appendNode(parameterMetaData);
/* 1274 */       valueContext.setUnwrapMode(parameterMetaData.unwrapMode());
/* 1275 */       valueContext.setCurrentValidatedValue(value);
/*      */       
/* 1277 */       validateConstraintsForGroup(validationContext, valueContext, parameterMetaData);
/*      */       
/*      */ 
/* 1280 */       if (shouldFailFast(validationContext)) {
/* 1281 */         return validationContext.getFailingConstraints().size() - numberOfViolationsBefore;
/*      */       }
/*      */       
/* 1284 */       if (!parameterMetaData.isCascading()) {
/* 1285 */         validateConstraintsForGroup(validationContext, valueContext, parameterMetaData
/* 1286 */           .getTypeArgumentsConstraints());
/*      */         
/* 1288 */         if (shouldFailFast(validationContext)) {
/* 1289 */           return validationContext.getFailingConstraints().size() - numberOfViolationsBefore;
/*      */         }
/*      */       }
/*      */       
/* 1293 */       valueContext.setPropertyPath(originalPath);
/*      */     }
/*      */     
/* 1296 */     return validationContext.getFailingConstraints().size() - numberOfViolationsBefore;
/*      */   }
/*      */   
/*      */   private <T> ValueContext<T, Object> getExecutableValueContext(T object, ExecutableMetaData executableMetaData, Class<?> group) {
/*      */     ValueContext<T, Object> valueContext;
/*      */     ValueContext<T, Object> valueContext;
/* 1302 */     if (object != null) {
/* 1303 */       valueContext = ValueContext.getLocalExecutionContext(object, null, 
/*      */       
/*      */ 
/* 1306 */         PathImpl.createPathForExecutable(executableMetaData));
/*      */     }
/*      */     else
/*      */     {
/* 1310 */       valueContext = ValueContext.getLocalExecutionContext((Class)null, null, 
/*      */       
/*      */ 
/* 1313 */         PathImpl.createPathForExecutable(executableMetaData));
/*      */     }
/*      */     
/*      */ 
/* 1317 */     valueContext.setCurrentGroup(group);
/*      */     
/* 1319 */     return valueContext;
/*      */   }
/*      */   
/*      */   private <V, T> void validateReturnValueInContext(ValidationContext<T> context, T bean, V value, ValidationOrder validationOrder) {
/* 1323 */     BeanMetaData<T> beanMetaData = this.beanMetaDataManager.getBeanMetaData(context.getRootBeanClass());
/* 1324 */     ExecutableMetaData executableMetaData = beanMetaData.getMetaDataFor(context.getExecutable());
/*      */     
/* 1326 */     if (executableMetaData == null) {
/* 1327 */       return;
/*      */     }
/*      */     
/* 1330 */     if (beanMetaData.defaultGroupSequenceIsRedefined()) {
/* 1331 */       validationOrder.assertDefaultGroupSequenceIsExpandable(beanMetaData.getDefaultGroupSequence(bean));
/*      */     }
/*      */     
/* 1334 */     Iterator<Group> groupIterator = validationOrder.getGroupIterator();
/*      */     
/*      */ 
/* 1337 */     while (groupIterator.hasNext()) {
/* 1338 */       validateReturnValueForGroup(context, bean, value, (Group)groupIterator.next());
/* 1339 */       if (shouldFailFast(context)) {
/* 1340 */         return;
/*      */       }
/*      */     }
/*      */     
/* 1344 */     ValueContext<V, Object> cascadingValueContext = null;
/*      */     
/* 1346 */     if (value != null) {
/* 1347 */       cascadingValueContext = ValueContext.getLocalExecutionContext(value, executableMetaData
/*      */       
/* 1349 */         .getReturnValueMetaData(), 
/* 1350 */         PathImpl.createPathForExecutable(executableMetaData));
/*      */       
/*      */ 
/* 1353 */       groupIterator = validationOrder.getGroupIterator();
/* 1354 */       while (groupIterator.hasNext()) {
/* 1355 */         Group group = (Group)groupIterator.next();
/* 1356 */         cascadingValueContext.setCurrentGroup(group.getDefiningClass());
/* 1357 */         validateCascadedConstraints(context, cascadingValueContext);
/* 1358 */         if (shouldFailFast(context)) {
/* 1359 */           return;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1365 */     Iterator<Sequence> sequenceIterator = validationOrder.getSequenceIterator();
/* 1366 */     while (sequenceIterator.hasNext()) {
/* 1367 */       Sequence sequence = (Sequence)sequenceIterator.next();
/* 1368 */       for (GroupWithInheritance groupOfGroups : sequence) {
/* 1369 */         int numberOfFailingConstraint = 0;
/* 1370 */         for (Group group : groupOfGroups) {
/* 1371 */           numberOfFailingConstraint += validateReturnValueForGroup(context, bean, value, group);
/*      */           
/*      */ 
/* 1374 */           if (shouldFailFast(context)) {
/* 1375 */             return;
/*      */           }
/*      */           
/* 1378 */           if (value != null) {
/* 1379 */             cascadingValueContext.setCurrentGroup(group.getDefiningClass());
/* 1380 */             validateCascadedConstraints(context, cascadingValueContext);
/*      */             
/* 1382 */             if (shouldFailFast(context)) {
/* 1383 */               return;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/* 1388 */         if (numberOfFailingConstraint > 0) {
/*      */           break;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private <T> int validateReturnValueForGroup(ValidationContext<T> validationContext, T bean, Object value, Group group)
/*      */   {
/* 1397 */     int numberOfViolationsBefore = validationContext.getFailingConstraints().size();
/*      */     
/* 1399 */     BeanMetaData<T> beanMetaData = this.beanMetaDataManager.getBeanMetaData(validationContext.getRootBeanClass());
/* 1400 */     ExecutableMetaData executableMetaData = beanMetaData.getMetaDataFor(validationContext.getExecutable());
/*      */     
/* 1402 */     if (executableMetaData == null)
/*      */     {
/* 1404 */       return 0;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1413 */     if (group.isDefaultGroup()) {
/* 1414 */       Iterator<Sequence> defaultGroupSequence = beanMetaData.getDefaultValidationSequence(bean);
/*      */       
/* 1416 */       while (defaultGroupSequence.hasNext()) {
/* 1417 */         Sequence sequence = (Sequence)defaultGroupSequence.next();
/* 1418 */         for (GroupWithInheritance expandedGroup : sequence) {
/* 1419 */           int numberOfViolationsOfCurrentGroup = 0;
/*      */           
/* 1421 */           for (Group defaultGroupSequenceElement : expandedGroup) {
/* 1422 */             numberOfViolationsOfCurrentGroup += validateReturnValueForSingleGroup(validationContext, executableMetaData, bean, value, defaultGroupSequenceElement.getDefiningClass());
/*      */             
/* 1424 */             if (shouldFailFast(validationContext)) {
/* 1425 */               return validationContext.getFailingConstraints().size() - numberOfViolationsBefore;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/* 1430 */           if (numberOfViolationsOfCurrentGroup > 0) {
/* 1431 */             return validationContext.getFailingConstraints().size() - numberOfViolationsBefore;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/* 1437 */       validateReturnValueForSingleGroup(validationContext, executableMetaData, bean, value, group.getDefiningClass());
/*      */     }
/*      */     
/* 1440 */     return validationContext.getFailingConstraints().size() - numberOfViolationsBefore;
/*      */   }
/*      */   
/*      */   private <T> int validateReturnValueForSingleGroup(ValidationContext<T> validationContext, ExecutableMetaData executableMetaData, T bean, Object value, Class<?> oneGroup) {
/* 1444 */     int numberOfViolationsBefore = validationContext.getFailingConstraints().size();
/*      */     
/*      */ 
/* 1447 */     ValueContext<?, Object> valueContext = getExecutableValueContext(executableMetaData
/* 1448 */       .getKind() == ElementKind.CONSTRUCTOR ? value : bean, executableMetaData, oneGroup);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1453 */     valueContext.setCurrentValidatedValue(value);
/* 1454 */     ReturnValueMetaData returnValueMetaData = executableMetaData.getReturnValueMetaData();
/* 1455 */     valueContext.appendNode(returnValueMetaData);
/* 1456 */     valueContext.setUnwrapMode(returnValueMetaData.unwrapMode());
/*      */     
/*      */ 
/* 1459 */     int numberOfViolationsOfCurrentGroup = validateConstraintsForGroup(validationContext, valueContext, returnValueMetaData);
/*      */     
/*      */ 
/* 1462 */     if (shouldFailFast(validationContext)) {
/* 1463 */       return validationContext.getFailingConstraints().size() - numberOfViolationsBefore;
/*      */     }
/*      */     
/* 1466 */     if (!returnValueMetaData.isCascading()) {
/* 1467 */       numberOfViolationsOfCurrentGroup += validateConstraintsForGroup(validationContext, valueContext, returnValueMetaData
/* 1468 */         .getTypeArgumentsConstraints());
/*      */       
/* 1470 */       if (shouldFailFast(validationContext)) {
/* 1471 */         return validationContext.getFailingConstraints().size() - numberOfViolationsBefore;
/*      */       }
/*      */     }
/*      */     
/* 1475 */     return numberOfViolationsOfCurrentGroup;
/*      */   }
/*      */   
/*      */ 
/*      */   private int validateConstraintsForGroup(ValidationContext<?> validationContext, ValueContext<?, ?> valueContext, Iterable<MetaConstraint<?>> constraints)
/*      */   {
/* 1481 */     int numberOfViolationsBefore = validationContext.getFailingConstraints().size();
/*      */     
/* 1483 */     for (MetaConstraint<?> metaConstraint : constraints) {
/* 1484 */       if (isValidationRequired(validationContext, valueContext, metaConstraint))
/*      */       {
/*      */ 
/*      */ 
/* 1488 */         metaConstraint.validateConstraint(validationContext, valueContext);
/* 1489 */         if (shouldFailFast(validationContext)) {
/*      */           break;
/*      */         }
/*      */       }
/*      */     }
/* 1494 */     return validationContext.getFailingConstraints().size() - numberOfViolationsBefore;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private <V> ValueContext<?, V> collectMetaConstraintsForPath(ValidationContext validationContext, Iterator<Path.Node> propertyIter, PathImpl propertyPath, List<MetaConstraint<?>> metaConstraintsList, List<MetaConstraint<?>> typeArgumentConstraints)
/*      */   {
/* 1515 */     Class<?> clazz = validationContext.getRootBeanClass();
/* 1516 */     Object value = validationContext.getRootBean();
/*      */     
/*      */ 
/* 1519 */     NodeImpl elem = (NodeImpl)propertyIter.next();
/* 1520 */     Object newValue = value;
/*      */     
/* 1522 */     BeanMetaData<?> metaData = this.beanMetaDataManager.getBeanMetaData(clazz);
/* 1523 */     PropertyMetaData property = metaData.getMetaDataFor(elem.getName());
/*      */     
/*      */ 
/* 1526 */     if (property == null) {
/* 1527 */       throw log.getInvalidPropertyPathException(elem.getName(), metaData.getBeanClass().getName());
/*      */     }
/* 1529 */     if (!propertyIter.hasNext()) {
/* 1530 */       metaConstraintsList.addAll(property.getConstraints());
/* 1531 */       typeArgumentConstraints.addAll(property.getTypeArgumentsConstraints());
/*      */ 
/*      */     }
/* 1534 */     else if (property.isCascading()) {
/* 1535 */       Type type = property.getType();
/* 1536 */       newValue = newValue == null ? null : getValue(newValue, validationContext, property);
/* 1537 */       if (elem.isIterable()) {
/* 1538 */         if ((newValue != null) && (elem.getIndex() != null)) {
/* 1539 */           newValue = ReflectionHelper.getIndexedValue(newValue, elem.getIndex());
/*      */         }
/* 1541 */         else if ((newValue != null) && (elem.getKey() != null)) {
/* 1542 */           newValue = ReflectionHelper.getMappedValue(newValue, elem.getKey());
/*      */         }
/* 1544 */         else if (newValue != null) {
/* 1545 */           throw log.getPropertyPathMustProvideIndexOrMapKeyException();
/*      */         }
/* 1547 */         type = ReflectionHelper.getIndexedType(type);
/*      */       }
/*      */       ValidationContext newValidationContext;
/*      */       ValidationContext newValidationContext;
/* 1551 */       if (newValue != null) {
/* 1552 */         newValidationContext = getValidationContext().forValidateProperty(newValue);
/*      */       }
/*      */       else {
/* 1555 */         newValidationContext = getValidationContext().forValidateValue((Class)type);
/*      */       }
/* 1557 */       return collectMetaConstraintsForPath(newValidationContext, propertyIter, propertyPath, metaConstraintsList, typeArgumentConstraints);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1567 */     if (newValue == null) {
/* 1568 */       return ValueContext.getLocalExecutionContext(clazz, null, propertyPath);
/*      */     }
/* 1570 */     return ValueContext.getLocalExecutionContext(value, null, propertyPath);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private TraversableResolver getCachingTraversableResolver()
/*      */   {
/* 1580 */     return new CachingTraversableResolverForSingleValidation(this.traversableResolver);
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean isValidationRequired(ValidationContext<?> validationContext, ValueContext<?, ?> valueContext, MetaConstraint<?> metaConstraint)
/*      */   {
/* 1586 */     if (validationContext.hasMetaConstraintBeenProcessed(valueContext
/* 1587 */       .getCurrentBean(), valueContext
/* 1588 */       .getPropertyPath(), metaConstraint))
/*      */     {
/*      */ 
/* 1591 */       return false;
/*      */     }
/*      */     
/* 1594 */     if (!metaConstraint.getGroupList().contains(valueContext.getCurrentGroup())) {
/* 1595 */       return false;
/*      */     }
/* 1597 */     return isReachable(validationContext, valueContext
/*      */     
/* 1599 */       .getCurrentBean(), valueContext
/* 1600 */       .getPropertyPath(), metaConstraint
/* 1601 */       .getElementType());
/*      */   }
/*      */   
/*      */   private boolean isReachable(ValidationContext<?> validationContext, Object traversableObject, PathImpl path, ElementType type)
/*      */   {
/* 1606 */     if (needToCallTraversableResolver(path, type)) {
/* 1607 */       return true;
/*      */     }
/*      */     
/* 1610 */     Path pathToObject = path.getPathWithoutLeafNode();
/*      */     try {
/* 1612 */       return validationContext.getTraversableResolver().isReachable(traversableObject, path
/*      */       
/* 1614 */         .getLeafNode(), validationContext
/* 1615 */         .getRootBeanClass(), pathToObject, type);
/*      */ 
/*      */     }
/*      */     catch (RuntimeException e)
/*      */     {
/*      */ 
/* 1621 */       throw log.getErrorDuringCallOfTraversableResolverIsReachableException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean needToCallTraversableResolver(PathImpl path, ElementType type)
/*      */   {
/* 1633 */     return (isClassLevelConstraint(type)) || (isCrossParameterValidation(path)) || (isParameterValidation(path)) || (isReturnValueValidation(path));
/*      */   }
/*      */   
/*      */   private boolean isCascadeRequired(ValidationContext<?> validationContext, Object traversableObject, PathImpl path, ElementType type) {
/* 1637 */     if (needToCallTraversableResolver(path, type)) {
/* 1638 */       return true;
/*      */     }
/*      */     
/* 1641 */     boolean isReachable = isReachable(validationContext, traversableObject, path, type);
/* 1642 */     if (!isReachable) {
/* 1643 */       return false;
/*      */     }
/*      */     
/* 1646 */     Path pathToObject = path.getPathWithoutLeafNode();
/*      */     try {
/* 1648 */       return validationContext.getTraversableResolver().isCascadable(traversableObject, path
/*      */       
/* 1650 */         .getLeafNode(), validationContext
/* 1651 */         .getRootBeanClass(), pathToObject, type);
/*      */ 
/*      */     }
/*      */     catch (RuntimeException e)
/*      */     {
/*      */ 
/* 1657 */       throw log.getErrorDuringCallOfTraversableResolverIsCascadableException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean isClassLevelConstraint(ElementType type) {
/* 1662 */     return ElementType.TYPE.equals(type);
/*      */   }
/*      */   
/*      */   private boolean isCrossParameterValidation(PathImpl path) {
/* 1666 */     return path.getLeafNode().getKind() == ElementKind.CROSS_PARAMETER;
/*      */   }
/*      */   
/*      */   private boolean isParameterValidation(PathImpl path) {
/* 1670 */     return path.getLeafNode().getKind() == ElementKind.PARAMETER;
/*      */   }
/*      */   
/*      */   private boolean isReturnValueValidation(PathImpl path) {
/* 1674 */     return path.getLeafNode().getKind() == ElementKind.RETURN_VALUE;
/*      */   }
/*      */   
/*      */ 
/* 1678 */   private boolean shouldFailFast(ValidationContext<?> context) { return (context.isFailFastModeEnabled()) && (!context.getFailingConstraints().isEmpty()); }
/*      */   
/*      */   private Object getValue(Object object, ValidationContext validationContext, Cascadable cascadable) {
/*      */     Object value;
/*      */     Object value;
/* 1683 */     if ((cascadable instanceof PropertyMetaData)) {
/* 1684 */       Member member = getAccessible(((PropertyMetaData)cascadable).getCascadingMember());
/* 1685 */       value = getValue(member, object);
/*      */     } else { Object value;
/* 1687 */       if ((cascadable instanceof ParameterMetaData)) {
/* 1688 */         value = ((Object[])(Object[])object)[((ParameterMetaData)cascadable).getIndex()];
/*      */       }
/*      */       else {
/* 1691 */         value = object;
/*      */       }
/*      */     }
/*      */     
/* 1695 */     UnwrapMode unwrapMode = cascadable.unwrapMode();
/* 1696 */     if ((UnwrapMode.UNWRAP.equals(unwrapMode)) || (UnwrapMode.AUTOMATIC.equals(unwrapMode))) {
/* 1697 */       ValidatedValueUnwrapper valueHandler = validationContext.getValidatedValueUnwrapper(cascadable.getType());
/* 1698 */       if (valueHandler != null) {
/* 1699 */         value = valueHandler.handleValidatedValue(value);
/*      */       }
/*      */     }
/*      */     
/* 1703 */     return value;
/*      */   }
/*      */   
/*      */   private Object getValue(Member member, Object object) {
/* 1707 */     if (member == null) {
/* 1708 */       return object;
/*      */     }
/*      */     
/* 1711 */     member = getAccessible(member);
/*      */     
/* 1713 */     if ((member instanceof Method)) {
/* 1714 */       return ReflectionHelper.getValue((Method)member, object);
/*      */     }
/* 1716 */     if ((member instanceof Field)) {
/* 1717 */       return ReflectionHelper.getValue((Field)member, object);
/*      */     }
/* 1719 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Member getAccessible(Member original)
/*      */   {
/* 1728 */     if (((AccessibleObject)original).isAccessible()) {
/* 1729 */       return original;
/*      */     }
/*      */     
/* 1732 */     Member member = (Member)this.accessibleMembers.get(original);
/*      */     
/* 1734 */     if (member != null) {
/* 1735 */       return member;
/*      */     }
/*      */     
/* 1738 */     Class<?> clazz = original.getDeclaringClass();
/*      */     
/* 1740 */     if ((original instanceof Field)) {
/* 1741 */       member = (Member)run(GetDeclaredField.action(clazz, original.getName()));
/*      */     }
/*      */     else {
/* 1744 */       member = (Member)run(GetDeclaredMethod.action(clazz, original.getName(), new Class[0]));
/*      */     }
/*      */     
/* 1747 */     run(SetAccessibility.action(member));
/*      */     
/* 1749 */     Member cached = (Member)this.accessibleMembers.putIfAbsent(original, member);
/* 1750 */     if (cached != null) {
/* 1751 */       member = cached;
/*      */     }
/*      */     
/* 1754 */     return member;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private <T> T run(PrivilegedAction<T> action)
/*      */   {
/* 1764 */     return (T)(System.getSecurityManager() != null ? AccessController.doPrivileged(action) : action.run());
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\engine\ValidatorImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */