/*      */ package org.hibernate.validator.internal.util;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.lang.ref.Reference;
/*      */ import java.lang.ref.ReferenceQueue;
/*      */ import java.lang.ref.SoftReference;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.util.AbstractCollection;
/*      */ import java.util.AbstractMap;
/*      */ import java.util.AbstractSet;
/*      */ import java.util.Collection;
/*      */ import java.util.EnumSet;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import java.util.concurrent.locks.ReentrantLock;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ConcurrentReferenceHashMap<K, V>
/*      */   extends AbstractMap<K, V>
/*      */   implements ConcurrentMap<K, V>, Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 7249069246763182397L;
/*      */   
/*      */   public static enum ReferenceType
/*      */   {
/*  149 */     STRONG, 
/*      */     
/*  151 */     WEAK, 
/*      */     
/*  153 */     SOFT;
/*      */     
/*      */     private ReferenceType() {}
/*      */   }
/*      */   
/*      */   public static enum Option
/*      */   {
/*  160 */     IDENTITY_COMPARISONS;
/*      */     
/*      */     private Option() {}
/*      */   }
/*      */   
/*  165 */   static final ReferenceType DEFAULT_KEY_TYPE = ReferenceType.WEAK;
/*      */   
/*  167 */   static final ReferenceType DEFAULT_VALUE_TYPE = ReferenceType.STRONG;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int DEFAULT_INITIAL_CAPACITY = 16;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final float DEFAULT_LOAD_FACTOR = 0.75F;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int DEFAULT_CONCURRENCY_LEVEL = 16;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int MAXIMUM_CAPACITY = 1073741824;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int MAX_SEGMENTS = 65536;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int RETRIES_BEFORE_LOCK = 2;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   final int segmentMask;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   final int segmentShift;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   final Segment<K, V>[] segments;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean identityComparisons;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   transient Set<K> keySet;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   transient Set<Map.Entry<K, V>> entrySet;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   transient Collection<V> values;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static int hash(int h)
/*      */   {
/*  246 */     h += (h << 15 ^ 0xCD7D);
/*  247 */     h ^= h >>> 10;
/*  248 */     h += (h << 3);
/*  249 */     h ^= h >>> 6;
/*  250 */     h += (h << 2) + (h << 14);
/*  251 */     return h ^ h >>> 16;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final Segment<K, V> segmentFor(int hash)
/*      */   {
/*  260 */     return this.segments[(hash >>> this.segmentShift & this.segmentMask)];
/*      */   }
/*      */   
/*      */   private int hashOf(Object key) {
/*  264 */     return hash(this.identityComparisons ? 
/*  265 */       System.identityHashCode(key) : key.hashCode());
/*      */   }
/*      */   
/*      */   static abstract interface KeyReference
/*      */   {
/*      */     public abstract int keyHash();
/*      */     
/*      */     public abstract Object keyRef();
/*      */   }
/*      */   
/*      */   static final class WeakKeyReference<K> extends WeakReference<K> implements ConcurrentReferenceHashMap.KeyReference
/*      */   {
/*      */     final int hash;
/*      */     
/*      */     WeakKeyReference(K key, int hash, ReferenceQueue<Object> refQueue)
/*      */     {
/*  281 */       super(refQueue);
/*  282 */       this.hash = hash;
/*      */     }
/*      */     
/*  285 */     public final int keyHash() { return this.hash; }
/*      */     
/*      */     public final Object keyRef()
/*      */     {
/*  289 */       return this;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class SoftKeyReference<K> extends SoftReference<K> implements ConcurrentReferenceHashMap.KeyReference
/*      */   {
/*      */     final int hash;
/*      */     
/*      */     SoftKeyReference(K key, int hash, ReferenceQueue<Object> refQueue)
/*      */     {
/*  299 */       super(refQueue);
/*  300 */       this.hash = hash;
/*      */     }
/*      */     
/*  303 */     public final int keyHash() { return this.hash; }
/*      */     
/*      */ 
/*      */ 
/*  307 */     public final Object keyRef() { return this; }
/*      */   }
/*      */   
/*      */   static final class WeakValueReference<V> extends WeakReference<V> implements ConcurrentReferenceHashMap.KeyReference {
/*      */     final Object keyRef;
/*      */     final int hash;
/*      */     
/*      */     WeakValueReference(V value, Object keyRef, int hash, ReferenceQueue<Object> refQueue) {
/*  315 */       super(refQueue);
/*  316 */       this.keyRef = keyRef;
/*  317 */       this.hash = hash;
/*      */     }
/*      */     
/*      */     public final int keyHash() {
/*  321 */       return this.hash;
/*      */     }
/*      */     
/*      */ 
/*  325 */     public final Object keyRef() { return this.keyRef; }
/*      */   }
/*      */   
/*      */   static final class SoftValueReference<V> extends SoftReference<V> implements ConcurrentReferenceHashMap.KeyReference {
/*      */     final Object keyRef;
/*      */     final int hash;
/*      */     
/*      */     SoftValueReference(V value, Object keyRef, int hash, ReferenceQueue<Object> refQueue) {
/*  333 */       super(refQueue);
/*  334 */       this.keyRef = keyRef;
/*  335 */       this.hash = hash;
/*      */     }
/*      */     
/*  338 */     public final int keyHash() { return this.hash; }
/*      */     
/*      */     public final Object keyRef()
/*      */     {
/*  342 */       return this.keyRef;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final class HashEntry<K, V>
/*      */   {
/*      */     final Object keyRef;
/*      */     
/*      */ 
/*      */ 
/*      */     final int hash;
/*      */     
/*      */ 
/*      */     volatile Object valueRef;
/*      */     
/*      */ 
/*      */     final HashEntry<K, V> next;
/*      */     
/*      */ 
/*      */ 
/*      */     HashEntry(K key, int hash, HashEntry<K, V> next, V value, ConcurrentReferenceHashMap.ReferenceType keyType, ConcurrentReferenceHashMap.ReferenceType valueType, ReferenceQueue<Object> refQueue)
/*      */     {
/*  367 */       this.hash = hash;
/*  368 */       this.next = next;
/*  369 */       this.keyRef = newKeyReference(key, keyType, refQueue);
/*  370 */       this.valueRef = newValueReference(value, valueType, refQueue);
/*      */     }
/*      */     
/*      */     final Object newKeyReference(K key, ConcurrentReferenceHashMap.ReferenceType keyType, ReferenceQueue<Object> refQueue)
/*      */     {
/*  375 */       if (keyType == ConcurrentReferenceHashMap.ReferenceType.WEAK)
/*  376 */         return new ConcurrentReferenceHashMap.WeakKeyReference(key, this.hash, refQueue);
/*  377 */       if (keyType == ConcurrentReferenceHashMap.ReferenceType.SOFT) {
/*  378 */         return new ConcurrentReferenceHashMap.SoftKeyReference(key, this.hash, refQueue);
/*      */       }
/*  380 */       return key;
/*      */     }
/*      */     
/*      */     final Object newValueReference(V value, ConcurrentReferenceHashMap.ReferenceType valueType, ReferenceQueue<Object> refQueue)
/*      */     {
/*  385 */       if (valueType == ConcurrentReferenceHashMap.ReferenceType.WEAK)
/*  386 */         return new ConcurrentReferenceHashMap.WeakValueReference(value, this.keyRef, this.hash, refQueue);
/*  387 */       if (valueType == ConcurrentReferenceHashMap.ReferenceType.SOFT) {
/*  388 */         return new ConcurrentReferenceHashMap.SoftValueReference(value, this.keyRef, this.hash, refQueue);
/*      */       }
/*  390 */       return value;
/*      */     }
/*      */     
/*      */     final K key()
/*      */     {
/*  395 */       if ((this.keyRef instanceof ConcurrentReferenceHashMap.KeyReference)) {
/*  396 */         return (K)((Reference)this.keyRef).get();
/*      */       }
/*  398 */       return (K)this.keyRef;
/*      */     }
/*      */     
/*      */     final V value() {
/*  402 */       return (V)dereferenceValue(this.valueRef);
/*      */     }
/*      */     
/*      */     final V dereferenceValue(Object value)
/*      */     {
/*  407 */       if ((value instanceof ConcurrentReferenceHashMap.KeyReference)) {
/*  408 */         return (V)((Reference)value).get();
/*      */       }
/*  410 */       return (V)value;
/*      */     }
/*      */     
/*      */     final void setValue(V value, ConcurrentReferenceHashMap.ReferenceType valueType, ReferenceQueue<Object> refQueue) {
/*  414 */       this.valueRef = newValueReference(value, valueType, refQueue);
/*      */     }
/*      */     
/*      */     static final <K, V> HashEntry<K, V>[] newArray(int i)
/*      */     {
/*  419 */       return new HashEntry[i];
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final class Segment<K, V>
/*      */     extends ReentrantLock
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 2249069246763182397L;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     volatile transient int count;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     transient int modCount;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     transient int threshold;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     volatile transient ConcurrentReferenceHashMap.HashEntry<K, V>[] table;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     final float loadFactor;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     volatile transient ReferenceQueue<Object> refQueue;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     final ConcurrentReferenceHashMap.ReferenceType keyType;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     final ConcurrentReferenceHashMap.ReferenceType valueType;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     final boolean identityComparisons;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Segment(int initialCapacity, float lf, ConcurrentReferenceHashMap.ReferenceType keyType, ConcurrentReferenceHashMap.ReferenceType valueType, boolean identityComparisons)
/*      */     {
/*  517 */       this.loadFactor = lf;
/*  518 */       this.keyType = keyType;
/*  519 */       this.valueType = valueType;
/*  520 */       this.identityComparisons = identityComparisons;
/*  521 */       setTable(ConcurrentReferenceHashMap.HashEntry.newArray(initialCapacity));
/*      */     }
/*      */     
/*      */     static final <K, V> Segment<K, V>[] newArray(int i)
/*      */     {
/*  526 */       return new Segment[i];
/*      */     }
/*      */     
/*      */     private boolean keyEq(Object src, Object dest) {
/*  530 */       return this.identityComparisons ? false : src == dest ? true : src.equals(dest);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     void setTable(ConcurrentReferenceHashMap.HashEntry<K, V>[] newTable)
/*      */     {
/*  538 */       this.threshold = ((int)(newTable.length * this.loadFactor));
/*  539 */       this.table = newTable;
/*  540 */       this.refQueue = new ReferenceQueue();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     ConcurrentReferenceHashMap.HashEntry<K, V> getFirst(int hash)
/*      */     {
/*  547 */       ConcurrentReferenceHashMap.HashEntry<K, V>[] tab = this.table;
/*  548 */       return tab[(hash & tab.length - 1)];
/*      */     }
/*      */     
/*      */     ConcurrentReferenceHashMap.HashEntry<K, V> newHashEntry(K key, int hash, ConcurrentReferenceHashMap.HashEntry<K, V> next, V value) {
/*  552 */       return new ConcurrentReferenceHashMap.HashEntry(key, hash, next, value, this.keyType, this.valueType, this.refQueue);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     V readValueUnderLock(ConcurrentReferenceHashMap.HashEntry<K, V> e)
/*      */     {
/*  563 */       lock();
/*      */       try {
/*  565 */         removeStale();
/*  566 */         return (V)e.value();
/*      */       } finally {
/*  568 */         unlock();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     V get(Object key, int hash)
/*      */     {
/*  575 */       if (this.count != 0) {
/*  576 */         ConcurrentReferenceHashMap.HashEntry<K, V> e = getFirst(hash);
/*  577 */         while (e != null) {
/*  578 */           if ((e.hash == hash) && (keyEq(key, e.key()))) {
/*  579 */             Object opaque = e.valueRef;
/*  580 */             if (opaque != null) {
/*  581 */               return (V)e.dereferenceValue(opaque);
/*      */             }
/*  583 */             return (V)readValueUnderLock(e);
/*      */           }
/*  585 */           e = e.next;
/*      */         }
/*      */       }
/*  588 */       return null;
/*      */     }
/*      */     
/*      */     boolean containsKey(Object key, int hash) {
/*  592 */       if (this.count != 0) {
/*  593 */         ConcurrentReferenceHashMap.HashEntry<K, V> e = getFirst(hash);
/*  594 */         while (e != null) {
/*  595 */           if ((e.hash == hash) && (keyEq(key, e.key())))
/*  596 */             return true;
/*  597 */           e = e.next;
/*      */         }
/*      */       }
/*  600 */       return false;
/*      */     }
/*      */     
/*      */     boolean containsValue(Object value) {
/*  604 */       if (this.count != 0) {
/*  605 */         ConcurrentReferenceHashMap.HashEntry<K, V>[] tab = this.table;
/*  606 */         int len = tab.length;
/*  607 */         for (int i = 0; i < len; i++) {
/*  608 */           for (ConcurrentReferenceHashMap.HashEntry<K, V> e = tab[i]; e != null; e = e.next) {
/*  609 */             Object opaque = e.valueRef;
/*      */             V v;
/*      */             V v;
/*  612 */             if (opaque == null) {
/*  613 */               v = readValueUnderLock(e);
/*      */             } else {
/*  615 */               v = e.dereferenceValue(opaque);
/*      */             }
/*  617 */             if (value.equals(v))
/*  618 */               return true;
/*      */           }
/*      */         }
/*      */       }
/*  622 */       return false;
/*      */     }
/*      */     
/*      */     boolean replace(K key, int hash, V oldValue, V newValue) {
/*  626 */       lock();
/*      */       try {
/*  628 */         removeStale();
/*  629 */         ConcurrentReferenceHashMap.HashEntry<K, V> e = getFirst(hash);
/*  630 */         while ((e != null) && ((e.hash != hash) || (!keyEq(key, e.key())))) {
/*  631 */           e = e.next;
/*      */         }
/*  633 */         boolean replaced = false;
/*  634 */         if ((e != null) && (oldValue.equals(e.value()))) {
/*  635 */           replaced = true;
/*  636 */           e.setValue(newValue, this.valueType, this.refQueue);
/*      */         }
/*  638 */         return replaced;
/*      */       } finally {
/*  640 */         unlock();
/*      */       }
/*      */     }
/*      */     
/*      */     V replace(K key, int hash, V newValue) {
/*  645 */       lock();
/*      */       try {
/*  647 */         removeStale();
/*  648 */         ConcurrentReferenceHashMap.HashEntry<K, V> e = getFirst(hash);
/*  649 */         while ((e != null) && ((e.hash != hash) || (!keyEq(key, e.key())))) {
/*  650 */           e = e.next;
/*      */         }
/*  652 */         V oldValue = null;
/*  653 */         if (e != null) {
/*  654 */           oldValue = e.value();
/*  655 */           e.setValue(newValue, this.valueType, this.refQueue);
/*      */         }
/*  657 */         return oldValue;
/*      */       } finally {
/*  659 */         unlock();
/*      */       }
/*      */     }
/*      */     
/*      */     V put(K key, int hash, V value, boolean onlyIfAbsent)
/*      */     {
/*  665 */       lock();
/*      */       try {
/*  667 */         removeStale();
/*  668 */         int c = this.count;
/*  669 */         if (c++ > this.threshold) {
/*  670 */           int reduced = rehash();
/*  671 */           if (reduced > 0) {
/*  672 */             this.count = (c -= reduced - 1);
/*      */           }
/*      */         }
/*  675 */         ConcurrentReferenceHashMap.HashEntry<K, V>[] tab = this.table;
/*  676 */         int index = hash & tab.length - 1;
/*  677 */         ConcurrentReferenceHashMap.HashEntry<K, V> first = tab[index];
/*  678 */         ConcurrentReferenceHashMap.HashEntry<K, V> e = first;
/*  679 */         while ((e != null) && ((e.hash != hash) || (!keyEq(key, e.key())))) {
/*  680 */           e = e.next;
/*      */         }
/*      */         V oldValue;
/*  683 */         if (e != null) {
/*  684 */           V oldValue = e.value();
/*  685 */           if ((!onlyIfAbsent) || (oldValue == null)) {
/*  686 */             e.setValue(value, this.valueType, this.refQueue);
/*      */           }
/*      */         } else {
/*  689 */           oldValue = null;
/*  690 */           this.modCount += 1;
/*  691 */           tab[index] = newHashEntry(key, hash, first, value);
/*  692 */           this.count = c;
/*      */         }
/*  694 */         return oldValue;
/*      */       } finally {
/*  696 */         unlock();
/*      */       }
/*      */     }
/*      */     
/*      */     int rehash() {
/*  701 */       ConcurrentReferenceHashMap.HashEntry<K, V>[] oldTable = this.table;
/*  702 */       int oldCapacity = oldTable.length;
/*  703 */       if (oldCapacity >= 1073741824) {
/*  704 */         return 0;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  720 */       ConcurrentReferenceHashMap.HashEntry<K, V>[] newTable = ConcurrentReferenceHashMap.HashEntry.newArray(oldCapacity << 1);
/*  721 */       this.threshold = ((int)(newTable.length * this.loadFactor));
/*  722 */       int sizeMask = newTable.length - 1;
/*  723 */       int reduce = 0;
/*  724 */       for (int i = 0; i < oldCapacity; i++)
/*      */       {
/*      */ 
/*  727 */         ConcurrentReferenceHashMap.HashEntry<K, V> e = oldTable[i];
/*      */         
/*  729 */         if (e != null) {
/*  730 */           ConcurrentReferenceHashMap.HashEntry<K, V> next = e.next;
/*  731 */           int idx = e.hash & sizeMask;
/*      */           
/*      */ 
/*  734 */           if (next == null) {
/*  735 */             newTable[idx] = e;
/*      */           }
/*      */           else
/*      */           {
/*  739 */             ConcurrentReferenceHashMap.HashEntry<K, V> lastRun = e;
/*  740 */             int lastIdx = idx;
/*  741 */             for (ConcurrentReferenceHashMap.HashEntry<K, V> last = next; 
/*  742 */                 last != null; 
/*  743 */                 last = last.next) {
/*  744 */               int k = last.hash & sizeMask;
/*  745 */               if (k != lastIdx) {
/*  746 */                 lastIdx = k;
/*  747 */                 lastRun = last;
/*      */               }
/*      */             }
/*  750 */             newTable[lastIdx] = lastRun;
/*      */             
/*  752 */             for (ConcurrentReferenceHashMap.HashEntry<K, V> p = e; p != lastRun; p = p.next)
/*      */             {
/*  754 */               K key = p.key();
/*  755 */               if (key == null) {
/*  756 */                 reduce++;
/*      */               }
/*      */               else {
/*  759 */                 int k = p.hash & sizeMask;
/*  760 */                 ConcurrentReferenceHashMap.HashEntry<K, V> n = newTable[k];
/*  761 */                 newTable[k] = newHashEntry(key, p.hash, n, p.value());
/*      */               }
/*      */             }
/*      */           }
/*      */         } }
/*  766 */       this.table = newTable;
/*  767 */       return reduce;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     V remove(Object key, int hash, Object value, boolean refRemove)
/*      */     {
/*  774 */       lock();
/*      */       try {
/*  776 */         if (!refRemove)
/*  777 */           removeStale();
/*  778 */         int c = this.count - 1;
/*  779 */         ConcurrentReferenceHashMap.HashEntry<K, V>[] tab = this.table;
/*  780 */         int index = hash & tab.length - 1;
/*  781 */         ConcurrentReferenceHashMap.HashEntry<K, V> first = tab[index];
/*  782 */         ConcurrentReferenceHashMap.HashEntry<K, V> e = first;
/*      */         
/*  784 */         while ((e != null) && (key != e.keyRef) && ((refRemove) || (hash != e.hash) || 
/*  785 */           (!keyEq(key, e.key())))) {
/*  786 */           e = e.next;
/*      */         }
/*  788 */         V oldValue = null;
/*  789 */         V v; if (e != null) {
/*  790 */           v = e.value();
/*  791 */           if ((value == null) || (value.equals(v))) {
/*  792 */             oldValue = v;
/*      */             
/*      */ 
/*      */ 
/*  796 */             this.modCount += 1;
/*  797 */             ConcurrentReferenceHashMap.HashEntry<K, V> newFirst = e.next;
/*  798 */             for (ConcurrentReferenceHashMap.HashEntry<K, V> p = first; p != e; p = p.next) {
/*  799 */               K pKey = p.key();
/*  800 */               if (pKey == null) {
/*  801 */                 c--;
/*      */               }
/*      */               else
/*      */               {
/*  805 */                 newFirst = newHashEntry(pKey, p.hash, newFirst, p.value()); }
/*      */             }
/*  807 */             tab[index] = newFirst;
/*  808 */             this.count = c;
/*      */           }
/*      */         }
/*  811 */         return oldValue;
/*      */       } finally {
/*  813 */         unlock();
/*      */       }
/*      */     }
/*      */     
/*      */     final void removeStale() {
/*      */       ConcurrentReferenceHashMap.KeyReference ref;
/*  819 */       while ((ref = (ConcurrentReferenceHashMap.KeyReference)this.refQueue.poll()) != null) {
/*  820 */         remove(ref.keyRef(), ref.keyHash(), null, true);
/*      */       }
/*      */     }
/*      */     
/*      */     /* Error */
/*      */     void clear()
/*      */     {
/*      */       // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: getfield 22	org/hibernate/validator/internal/util/ConcurrentReferenceHashMap$Segment:count	I
/*      */       //   4: ifeq +70 -> 74
/*      */       //   7: aload_0
/*      */       //   8: invokevirtual 18	org/hibernate/validator/internal/util/ConcurrentReferenceHashMap$Segment:lock	()V
/*      */       //   11: aload_0
/*      */       //   12: getfield 12	org/hibernate/validator/internal/util/ConcurrentReferenceHashMap$Segment:table	[Lorg/hibernate/validator/internal/util/ConcurrentReferenceHashMap$HashEntry;
/*      */       //   15: astore_1
/*      */       //   16: iconst_0
/*      */       //   17: istore_2
/*      */       //   18: iload_2
/*      */       //   19: aload_1
/*      */       //   20: arraylength
/*      */       //   21: if_icmpge +13 -> 34
/*      */       //   24: aload_1
/*      */       //   25: iload_2
/*      */       //   26: aconst_null
/*      */       //   27: aastore
/*      */       //   28: iinc 2 1
/*      */       //   31: goto -13 -> 18
/*      */       //   34: aload_0
/*      */       //   35: dup
/*      */       //   36: getfield 33	org/hibernate/validator/internal/util/ConcurrentReferenceHashMap$Segment:modCount	I
/*      */       //   39: iconst_1
/*      */       //   40: iadd
/*      */       //   41: putfield 33	org/hibernate/validator/internal/util/ConcurrentReferenceHashMap$Segment:modCount	I
/*      */       //   44: aload_0
/*      */       //   45: new 13	java/lang/ref/ReferenceQueue
/*      */       //   48: dup
/*      */       //   49: invokespecial 14	java/lang/ref/ReferenceQueue:<init>	()V
/*      */       //   52: putfield 15	org/hibernate/validator/internal/util/ConcurrentReferenceHashMap$Segment:refQueue	Ljava/lang/ref/ReferenceQueue;
/*      */       //   55: aload_0
/*      */       //   56: iconst_0
/*      */       //   57: putfield 22	org/hibernate/validator/internal/util/ConcurrentReferenceHashMap$Segment:count	I
/*      */       //   60: aload_0
/*      */       //   61: invokevirtual 21	org/hibernate/validator/internal/util/ConcurrentReferenceHashMap$Segment:unlock	()V
/*      */       //   64: goto +10 -> 74
/*      */       //   67: astore_3
/*      */       //   68: aload_0
/*      */       //   69: invokevirtual 21	org/hibernate/validator/internal/util/ConcurrentReferenceHashMap$Segment:unlock	()V
/*      */       //   72: aload_3
/*      */       //   73: athrow
/*      */       //   74: return
/*      */       // Line number table:
/*      */       //   Java source line #825	-> byte code offset #0
/*      */       //   Java source line #826	-> byte code offset #7
/*      */       //   Java source line #828	-> byte code offset #11
/*      */       //   Java source line #829	-> byte code offset #16
/*      */       //   Java source line #830	-> byte code offset #24
/*      */       //   Java source line #829	-> byte code offset #28
/*      */       //   Java source line #831	-> byte code offset #34
/*      */       //   Java source line #833	-> byte code offset #44
/*      */       //   Java source line #834	-> byte code offset #55
/*      */       //   Java source line #836	-> byte code offset #60
/*      */       //   Java source line #837	-> byte code offset #64
/*      */       //   Java source line #836	-> byte code offset #67
/*      */       //   Java source line #839	-> byte code offset #74
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	signature
/*      */       //   0	75	0	this	Segment<K, V>
/*      */       //   15	10	1	tab	ConcurrentReferenceHashMap.HashEntry<K, V>[]
/*      */       //   17	12	2	i	int
/*      */       //   67	6	3	localObject	Object
/*      */       // Exception table:
/*      */       //   from	to	target	type
/*      */       //   11	60	67	finally
/*      */     }
/*      */   }
/*      */   
/*      */   public ConcurrentReferenceHashMap(int initialCapacity, float loadFactor, int concurrencyLevel, ReferenceType keyType, ReferenceType valueType, EnumSet<Option> options)
/*      */   {
/*  872 */     if ((loadFactor <= 0.0F) || (initialCapacity < 0) || (concurrencyLevel <= 0)) {
/*  873 */       throw new IllegalArgumentException();
/*      */     }
/*  875 */     if (concurrencyLevel > 65536) {
/*  876 */       concurrencyLevel = 65536;
/*      */     }
/*      */     
/*  879 */     int sshift = 0;
/*  880 */     int ssize = 1;
/*  881 */     while (ssize < concurrencyLevel) {
/*  882 */       sshift++;
/*  883 */       ssize <<= 1;
/*      */     }
/*  885 */     this.segmentShift = (32 - sshift);
/*  886 */     this.segmentMask = (ssize - 1);
/*  887 */     this.segments = Segment.newArray(ssize);
/*      */     
/*  889 */     if (initialCapacity > 1073741824)
/*  890 */       initialCapacity = 1073741824;
/*  891 */     int c = initialCapacity / ssize;
/*  892 */     if (c * ssize < initialCapacity)
/*  893 */       c++;
/*  894 */     int cap = 1;
/*  895 */     while (cap < c) {
/*  896 */       cap <<= 1;
/*      */     }
/*  898 */     this.identityComparisons = ((options != null) && (options.contains(Option.IDENTITY_COMPARISONS)));
/*      */     
/*  900 */     for (int i = 0; i < this.segments.length; i++) {
/*  901 */       this.segments[i] = new Segment(cap, loadFactor, keyType, valueType, this.identityComparisons);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ConcurrentReferenceHashMap(int initialCapacity, float loadFactor, int concurrencyLevel)
/*      */   {
/*  923 */     this(initialCapacity, loadFactor, concurrencyLevel, DEFAULT_KEY_TYPE, DEFAULT_VALUE_TYPE, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ConcurrentReferenceHashMap(int initialCapacity, float loadFactor)
/*      */   {
/*  943 */     this(initialCapacity, loadFactor, 16);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ConcurrentReferenceHashMap(int initialCapacity, ReferenceType keyType, ReferenceType valueType)
/*      */   {
/*  960 */     this(initialCapacity, 0.75F, 16, keyType, valueType, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ConcurrentReferenceHashMap(int initialCapacity)
/*      */   {
/*  975 */     this(initialCapacity, 0.75F, 16);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ConcurrentReferenceHashMap()
/*      */   {
/*  984 */     this(16, 0.75F, 16);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ConcurrentReferenceHashMap(Map<? extends K, ? extends V> m)
/*      */   {
/*  996 */     this(Math.max((int)(m.size() / 0.75F) + 1, 16), 0.75F, 16);
/*      */     
/*      */ 
/*  999 */     putAll(m);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isEmpty()
/*      */   {
/* 1008 */     Segment<K, V>[] segments = this.segments;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1018 */     int[] mc = new int[segments.length];
/* 1019 */     int mcsum = 0;
/* 1020 */     for (int i = 0; i < segments.length; i++) {
/* 1021 */       if (segments[i].count != 0) {
/* 1022 */         return false;
/*      */       }
/* 1024 */       mcsum += (mc[i] = segments[i].modCount);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1029 */     if (mcsum != 0) {
/* 1030 */       for (int i = 0; i < segments.length; i++) {
/* 1031 */         if ((segments[i].count != 0) || (mc[i] != segments[i].modCount))
/*      */         {
/* 1033 */           return false; }
/*      */       }
/*      */     }
/* 1036 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int size()
/*      */   {
/* 1047 */     Segment<K, V>[] segments = this.segments;
/* 1048 */     long sum = 0L;
/* 1049 */     long check = 0L;
/* 1050 */     int[] mc = new int[segments.length];
/*      */     
/*      */ 
/* 1053 */     for (int k = 0; k < 2; k++) {
/* 1054 */       check = 0L;
/* 1055 */       sum = 0L;
/* 1056 */       int mcsum = 0;
/* 1057 */       for (int i = 0; i < segments.length; i++) {
/* 1058 */         sum += segments[i].count;
/* 1059 */         mcsum += (mc[i] = segments[i].modCount);
/*      */       }
/* 1061 */       if (mcsum != 0) {
/* 1062 */         for (int i = 0; i < segments.length; i++) {
/* 1063 */           check += segments[i].count;
/* 1064 */           if (mc[i] != segments[i].modCount) {
/* 1065 */             check = -1L;
/* 1066 */             break;
/*      */           }
/*      */         }
/*      */       }
/* 1070 */       if (check == sum)
/*      */         break;
/*      */     }
/* 1073 */     if (check != sum) {
/* 1074 */       sum = 0L;
/* 1075 */       for (int i = 0; i < segments.length; i++)
/* 1076 */         segments[i].lock();
/* 1077 */       for (int i = 0; i < segments.length; i++)
/* 1078 */         sum += segments[i].count;
/* 1079 */       for (int i = 0; i < segments.length; i++)
/* 1080 */         segments[i].unlock();
/*      */     }
/* 1082 */     if (sum > 2147483647L) {
/* 1083 */       return Integer.MAX_VALUE;
/*      */     }
/* 1085 */     return (int)sum;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public V get(Object key)
/*      */   {
/* 1100 */     int hash = hashOf(key);
/* 1101 */     return (V)segmentFor(hash).get(key, hash);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsKey(Object key)
/*      */   {
/* 1114 */     int hash = hashOf(key);
/* 1115 */     return segmentFor(hash).containsKey(key, hash);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsValue(Object value)
/*      */   {
/* 1130 */     if (value == null) {
/* 1131 */       throw new NullPointerException();
/*      */     }
/*      */     
/*      */ 
/* 1135 */     Segment<K, V>[] segments = this.segments;
/* 1136 */     int[] mc = new int[segments.length];
/*      */     
/*      */ 
/* 1139 */     for (int k = 0; k < 2; k++) {
/* 1140 */       int mcsum = 0;
/* 1141 */       for (int i = 0; i < segments.length; i++) {
/* 1142 */         mcsum += (mc[i] = segments[i].modCount);
/* 1143 */         if (segments[i].containsValue(value))
/* 1144 */           return true;
/*      */       }
/* 1146 */       boolean cleanSweep = true;
/* 1147 */       if (mcsum != 0) {
/* 1148 */         for (int i = 0; i < segments.length; i++) {
/* 1149 */           if (mc[i] != segments[i].modCount) {
/* 1150 */             cleanSweep = false;
/* 1151 */             break;
/*      */           }
/*      */         }
/*      */       }
/* 1155 */       if (cleanSweep) {
/* 1156 */         return false;
/*      */       }
/*      */     }
/* 1159 */     for (int i = 0; i < segments.length; i++)
/* 1160 */       segments[i].lock();
/* 1161 */     boolean found = false;
/*      */     try {
/* 1163 */       for (int i = 0; i < segments.length; i++)
/* 1164 */         if (segments[i].containsValue(value)) {
/* 1165 */           found = true;
/* 1166 */           break;
/*      */         }
/*      */     } finally {
/*      */       int i;
/* 1170 */       for (int i = 0; i < segments.length; i++)
/* 1171 */         segments[i].unlock();
/*      */     }
/* 1173 */     return found;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean contains(Object value)
/*      */   {
/* 1192 */     return containsValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public V put(K key, V value)
/*      */   {
/* 1209 */     if (value == null)
/* 1210 */       throw new NullPointerException();
/* 1211 */     int hash = hashOf(key);
/* 1212 */     return (V)segmentFor(hash).put(key, hash, value, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public V putIfAbsent(K key, V value)
/*      */   {
/* 1223 */     if (value == null)
/* 1224 */       throw new NullPointerException();
/* 1225 */     int hash = hashOf(key);
/* 1226 */     return (V)segmentFor(hash).put(key, hash, value, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void putAll(Map<? extends K, ? extends V> m)
/*      */   {
/* 1237 */     for (Map.Entry<? extends K, ? extends V> e : m.entrySet()) {
/* 1238 */       put(e.getKey(), e.getValue());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public V remove(Object key)
/*      */   {
/* 1251 */     int hash = hashOf(key);
/* 1252 */     return (V)segmentFor(hash).remove(key, hash, null, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean remove(Object key, Object value)
/*      */   {
/* 1261 */     int hash = hashOf(key);
/* 1262 */     if (value == null)
/* 1263 */       return false;
/* 1264 */     return segmentFor(hash).remove(key, hash, value, false) != null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean replace(K key, V oldValue, V newValue)
/*      */   {
/* 1273 */     if ((oldValue == null) || (newValue == null))
/* 1274 */       throw new NullPointerException();
/* 1275 */     int hash = hashOf(key);
/* 1276 */     return segmentFor(hash).replace(key, hash, oldValue, newValue);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public V replace(K key, V value)
/*      */   {
/* 1287 */     if (value == null)
/* 1288 */       throw new NullPointerException();
/* 1289 */     int hash = hashOf(key);
/* 1290 */     return (V)segmentFor(hash).replace(key, hash, value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void clear()
/*      */   {
/* 1297 */     for (int i = 0; i < this.segments.length; i++) {
/* 1298 */       this.segments[i].clear();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void purgeStaleEntries()
/*      */   {
/* 1313 */     for (int i = 0; i < this.segments.length; i++) {
/* 1314 */       this.segments[i].removeStale();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<K> keySet()
/*      */   {
/* 1335 */     Set<K> ks = this.keySet;
/* 1336 */     return ks != null ? ks : (this.keySet = new KeySet());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Collection<V> values()
/*      */   {
/* 1356 */     Collection<V> vs = this.values;
/* 1357 */     return vs != null ? vs : (this.values = new Values());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<Map.Entry<K, V>> entrySet()
/*      */   {
/* 1377 */     Set<Map.Entry<K, V>> es = this.entrySet;
/* 1378 */     return es != null ? es : (this.entrySet = new EntrySet());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Enumeration<K> keys()
/*      */   {
/* 1388 */     return new KeyIterator();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Enumeration<V> elements()
/*      */   {
/* 1398 */     return new ValueIterator();
/*      */   }
/*      */   
/*      */   abstract class HashIterator
/*      */   {
/*      */     int nextSegmentIndex;
/*      */     int nextTableIndex;
/*      */     ConcurrentReferenceHashMap.HashEntry<K, V>[] currentTable;
/*      */     ConcurrentReferenceHashMap.HashEntry<K, V> nextEntry;
/*      */     ConcurrentReferenceHashMap.HashEntry<K, V> lastReturned;
/*      */     K currentKey;
/*      */     
/*      */     HashIterator()
/*      */     {
/* 1412 */       this.nextSegmentIndex = (ConcurrentReferenceHashMap.this.segments.length - 1);
/* 1413 */       this.nextTableIndex = -1;
/* 1414 */       advance();
/*      */     }
/*      */     
/* 1417 */     public boolean hasMoreElements() { return hasNext(); }
/*      */     
/*      */     final void advance() {
/* 1420 */       if ((this.nextEntry != null) && ((this.nextEntry = this.nextEntry.next) != null)) {
/* 1421 */         return;
/*      */       }
/* 1423 */       while (this.nextTableIndex >= 0) {
/* 1424 */         if ((this.nextEntry = this.currentTable[(this.nextTableIndex--)]) != null) {
/* 1425 */           return;
/*      */         }
/*      */       }
/* 1428 */       while (this.nextSegmentIndex >= 0) {
/* 1429 */         ConcurrentReferenceHashMap.Segment<K, V> seg = ConcurrentReferenceHashMap.this.segments[(this.nextSegmentIndex--)];
/* 1430 */         if (seg.count != 0) {
/* 1431 */           this.currentTable = seg.table;
/* 1432 */           for (int j = this.currentTable.length - 1; j >= 0; j--) {
/* 1433 */             if ((this.nextEntry = this.currentTable[j]) != null) {
/* 1434 */               this.nextTableIndex = (j - 1);
/* 1435 */               return;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean hasNext() {
/* 1443 */       while (this.nextEntry != null) {
/* 1444 */         if (this.nextEntry.key() != null)
/* 1445 */           return true;
/* 1446 */         advance();
/*      */       }
/*      */       
/* 1449 */       return false;
/*      */     }
/*      */     
/*      */     ConcurrentReferenceHashMap.HashEntry<K, V> nextEntry() {
/*      */       do {
/* 1454 */         if (this.nextEntry == null) {
/* 1455 */           throw new NoSuchElementException();
/*      */         }
/* 1457 */         this.lastReturned = this.nextEntry;
/* 1458 */         this.currentKey = this.lastReturned.key();
/* 1459 */         advance();
/* 1460 */       } while (this.currentKey == null);
/*      */       
/* 1462 */       return this.lastReturned;
/*      */     }
/*      */     
/*      */     public void remove() {
/* 1466 */       if (this.lastReturned == null)
/* 1467 */         throw new IllegalStateException();
/* 1468 */       ConcurrentReferenceHashMap.this.remove(this.currentKey);
/* 1469 */       this.lastReturned = null;
/*      */     }
/*      */   }
/*      */   
/* 1473 */   final class KeyIterator extends ConcurrentReferenceHashMap<K, V>.HashIterator implements Iterator<K>, Enumeration<K> { KeyIterator() { super(); }
/*      */     
/*      */ 
/*      */ 
/* 1477 */     public K next() { return (K)super.nextEntry().key(); }
/* 1478 */     public K nextElement() { return (K)super.nextEntry().key(); }
/*      */   }
/*      */   
/* 1481 */   final class ValueIterator extends ConcurrentReferenceHashMap<K, V>.HashIterator implements Iterator<V>, Enumeration<V> { ValueIterator() { super(); }
/*      */     
/*      */ 
/*      */ 
/* 1485 */     public V next() { return (V)super.nextEntry().value(); }
/* 1486 */     public V nextElement() { return (V)super.nextEntry().value(); }
/*      */   }
/*      */   
/*      */ 
/*      */   static class SimpleEntry<K, V>
/*      */     implements Map.Entry<K, V>, Serializable
/*      */   {
/*      */     private static final long serialVersionUID = -8499721149061103585L;
/*      */     
/*      */     private final K key;
/*      */     private V value;
/*      */     
/*      */     public SimpleEntry(K key, V value)
/*      */     {
/* 1500 */       this.key = key;
/* 1501 */       this.value = value;
/*      */     }
/*      */     
/*      */     public SimpleEntry(Map.Entry<? extends K, ? extends V> entry) {
/* 1505 */       this.key = entry.getKey();
/* 1506 */       this.value = entry.getValue();
/*      */     }
/*      */     
/*      */     public K getKey() {
/* 1510 */       return (K)this.key;
/*      */     }
/*      */     
/*      */     public V getValue() {
/* 1514 */       return (V)this.value;
/*      */     }
/*      */     
/*      */     public V setValue(V value) {
/* 1518 */       V oldValue = this.value;
/* 1519 */       this.value = value;
/* 1520 */       return oldValue;
/*      */     }
/*      */     
/*      */     public boolean equals(Object o) {
/* 1524 */       if (!(o instanceof Map.Entry))
/* 1525 */         return false;
/* 1526 */       Map.Entry<?, ?> e = (Map.Entry)o;
/* 1527 */       return (eq(this.key, e.getKey())) && (eq(this.value, e.getValue()));
/*      */     }
/*      */     
/*      */     public int hashCode()
/*      */     {
/* 1532 */       return (this.key == null ? 0 : this.key.hashCode()) ^ (this.value == null ? 0 : this.value.hashCode());
/*      */     }
/*      */     
/*      */     public String toString() {
/* 1536 */       return this.key + "=" + this.value;
/*      */     }
/*      */     
/*      */     private static boolean eq(Object o1, Object o2) {
/* 1540 */       return o1 == null ? false : o2 == null ? true : o1.equals(o2);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   final class WriteThroughEntry
/*      */     extends ConcurrentReferenceHashMap.SimpleEntry<K, V>
/*      */   {
/*      */     private static final long serialVersionUID = -7900634345345313646L;
/*      */     
/*      */ 
/*      */     WriteThroughEntry(V k)
/*      */     {
/* 1554 */       super(v);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public V setValue(V value)
/*      */     {
/* 1567 */       if (value == null) throw new NullPointerException();
/* 1568 */       V v = super.setValue(value);
/* 1569 */       ConcurrentReferenceHashMap.this.put(getKey(), value);
/* 1570 */       return v;
/*      */     }
/*      */   }
/*      */   
/* 1574 */   final class EntryIterator extends ConcurrentReferenceHashMap<K, V>.HashIterator implements Iterator<Map.Entry<K, V>> { EntryIterator() { super(); }
/*      */     
/*      */ 
/*      */     public Map.Entry<K, V> next()
/*      */     {
/* 1579 */       ConcurrentReferenceHashMap.HashEntry<K, V> e = super.nextEntry();
/* 1580 */       return new ConcurrentReferenceHashMap.WriteThroughEntry(ConcurrentReferenceHashMap.this, e.key(), e.value());
/*      */     }
/*      */   }
/*      */   
/*      */   final class KeySet extends AbstractSet<K> { KeySet() {}
/*      */     
/* 1586 */     public Iterator<K> iterator() { return new ConcurrentReferenceHashMap.KeyIterator(ConcurrentReferenceHashMap.this); }
/*      */     
/*      */     public int size() {
/* 1589 */       return ConcurrentReferenceHashMap.this.size();
/*      */     }
/*      */     
/* 1592 */     public boolean isEmpty() { return ConcurrentReferenceHashMap.this.isEmpty(); }
/*      */     
/*      */     public boolean contains(Object o) {
/* 1595 */       return ConcurrentReferenceHashMap.this.containsKey(o);
/*      */     }
/*      */     
/* 1598 */     public boolean remove(Object o) { return ConcurrentReferenceHashMap.this.remove(o) != null; }
/*      */     
/*      */ 
/* 1601 */     public void clear() { ConcurrentReferenceHashMap.this.clear(); }
/*      */   }
/*      */   
/*      */   final class Values extends AbstractCollection<V> {
/*      */     Values() {}
/*      */     
/* 1607 */     public Iterator<V> iterator() { return new ConcurrentReferenceHashMap.ValueIterator(ConcurrentReferenceHashMap.this); }
/*      */     
/*      */     public int size() {
/* 1610 */       return ConcurrentReferenceHashMap.this.size();
/*      */     }
/*      */     
/* 1613 */     public boolean isEmpty() { return ConcurrentReferenceHashMap.this.isEmpty(); }
/*      */     
/*      */     public boolean contains(Object o) {
/* 1616 */       return ConcurrentReferenceHashMap.this.containsValue(o);
/*      */     }
/*      */     
/* 1619 */     public void clear() { ConcurrentReferenceHashMap.this.clear(); }
/*      */   }
/*      */   
/*      */   final class EntrySet extends AbstractSet<Map.Entry<K, V>> {
/*      */     EntrySet() {}
/*      */     
/* 1625 */     public Iterator<Map.Entry<K, V>> iterator() { return new ConcurrentReferenceHashMap.EntryIterator(ConcurrentReferenceHashMap.this); }
/*      */     
/*      */     public boolean contains(Object o) {
/* 1628 */       if (!(o instanceof Map.Entry))
/* 1629 */         return false;
/* 1630 */       Map.Entry<?, ?> e = (Map.Entry)o;
/* 1631 */       V v = ConcurrentReferenceHashMap.this.get(e.getKey());
/* 1632 */       return (v != null) && (v.equals(e.getValue()));
/*      */     }
/*      */     
/* 1635 */     public boolean remove(Object o) { if (!(o instanceof Map.Entry))
/* 1636 */         return false;
/* 1637 */       Map.Entry<?, ?> e = (Map.Entry)o;
/* 1638 */       return ConcurrentReferenceHashMap.this.remove(e.getKey(), e.getValue());
/*      */     }
/*      */     
/* 1641 */     public int size() { return ConcurrentReferenceHashMap.this.size(); }
/*      */     
/*      */     public boolean isEmpty() {
/* 1644 */       return ConcurrentReferenceHashMap.this.isEmpty();
/*      */     }
/*      */     
/* 1647 */     public void clear() { ConcurrentReferenceHashMap.this.clear(); }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeObject(ObjectOutputStream s)
/*      */     throws IOException
/*      */   {
/* 1665 */     s.defaultWriteObject();
/*      */     
/* 1667 */     for (int k = 0; k < this.segments.length; k++) {
/* 1668 */       Segment<K, V> seg = this.segments[k];
/* 1669 */       seg.lock();
/*      */       try {
/* 1671 */         HashEntry<K, V>[] tab = seg.table;
/* 1672 */         for (int i = 0; i < tab.length; i++)
/* 1673 */           for (HashEntry<K, V> e = tab[i]; e != null; e = e.next) {
/* 1674 */             K key = e.key();
/* 1675 */             if (key != null)
/*      */             {
/*      */ 
/* 1678 */               s.writeObject(key);
/* 1679 */               s.writeObject(e.value());
/*      */             }
/*      */           }
/*      */       } finally {
/* 1683 */         seg.unlock();
/*      */       }
/*      */     }
/* 1686 */     s.writeObject(null);
/* 1687 */     s.writeObject(null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readObject(ObjectInputStream s)
/*      */     throws IOException, ClassNotFoundException
/*      */   {
/* 1701 */     s.defaultReadObject();
/*      */     
/*      */ 
/* 1704 */     for (int i = 0; i < this.segments.length; i++) {
/* 1705 */       this.segments[i].setTable(new HashEntry[1]);
/*      */     }
/*      */     
/*      */     for (;;)
/*      */     {
/* 1710 */       K key = s.readObject();
/* 1711 */       V value = s.readObject();
/* 1712 */       if (key == null)
/*      */         break;
/* 1714 */       put(key, value);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\util\ConcurrentReferenceHashMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */