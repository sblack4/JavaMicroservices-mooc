/*    */ package org.hibernate.validator.internal.engine.constraintdefinition;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.List;
/*    */ import org.hibernate.validator.internal.util.CollectionHelper;
/*    */ import org.hibernate.validator.spi.constraintdefinition.ConstraintDefinitionContributor.ConstraintDefinitionBuilder;
/*    */ import org.hibernate.validator.spi.constraintdefinition.ConstraintDefinitionContributor.ConstraintDefinitionBuilderContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstraintDefinitionBuilderImpl
/*    */   implements ConstraintDefinitionContributor.ConstraintDefinitionBuilder
/*    */ {
/* 22 */   private final List<ConstraintDefinitionBuilderContextImpl<?>> contexts = CollectionHelper.newArrayList();
/*    */   
/*    */   public <A extends Annotation> ConstraintDefinitionContributor.ConstraintDefinitionBuilderContext<A> constraint(Class<A> constraintType)
/*    */   {
/* 26 */     ConstraintDefinitionBuilderContextImpl<A> context = new ConstraintDefinitionBuilderContextImpl(this, constraintType);
/*    */     
/*    */ 
/* 29 */     this.contexts.add(context);
/* 30 */     return context;
/*    */   }
/*    */   
/*    */   public List<ConstraintDefinitionContribution<?>> getConstraintValidatorContributions() {
/* 34 */     List<ConstraintDefinitionContribution<?>> contributions = CollectionHelper.newArrayList(this.contexts.size());
/*    */     
/* 36 */     for (ConstraintDefinitionBuilderContextImpl<?> context : this.contexts) {
/* 37 */       contributions.add(context.build());
/*    */     }
/*    */     
/* 40 */     return contributions;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\engine\constraintdefinition\ConstraintDefinitionBuilderImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */