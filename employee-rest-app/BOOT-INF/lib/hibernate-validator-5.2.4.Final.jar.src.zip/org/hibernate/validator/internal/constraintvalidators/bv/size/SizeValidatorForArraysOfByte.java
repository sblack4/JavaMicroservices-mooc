/*    */ package org.hibernate.validator.internal.constraintvalidators.bv.size;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import javax.validation.ConstraintValidator;
/*    */ import javax.validation.ConstraintValidatorContext;
/*    */ import javax.validation.constraints.Size;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SizeValidatorForArraysOfByte
/*    */   extends SizeValidatorForArraysOfPrimitives
/*    */   implements ConstraintValidator<Size, byte[]>
/*    */ {
/*    */   public boolean isValid(byte[] array, ConstraintValidatorContext constraintValidatorContext)
/*    */   {
/* 31 */     if (array == null) {
/* 32 */       return true;
/*    */     }
/* 34 */     int length = Array.getLength(array);
/* 35 */     return (length >= this.min) && (length <= this.max);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\constraintvalidators\bv\size\SizeValidatorForArraysOfByte.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */