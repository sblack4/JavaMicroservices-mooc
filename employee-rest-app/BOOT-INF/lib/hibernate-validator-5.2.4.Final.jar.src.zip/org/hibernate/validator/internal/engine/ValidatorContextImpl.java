/*     */ package org.hibernate.validator.internal.engine;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.validation.ConstraintValidatorFactory;
/*     */ import javax.validation.MessageInterpolator;
/*     */ import javax.validation.ParameterNameProvider;
/*     */ import javax.validation.TraversableResolver;
/*     */ import javax.validation.Validator;
/*     */ import org.hibernate.validator.HibernateValidatorContext;
/*     */ import org.hibernate.validator.spi.time.TimeProvider;
/*     */ import org.hibernate.validator.spi.valuehandling.ValidatedValueUnwrapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidatorContextImpl
/*     */   implements HibernateValidatorContext
/*     */ {
/*     */   private final ValidatorFactoryImpl validatorFactory;
/*     */   private MessageInterpolator messageInterpolator;
/*     */   private TraversableResolver traversableResolver;
/*     */   private ConstraintValidatorFactory constraintValidatorFactory;
/*     */   private ParameterNameProvider parameterNameProvider;
/*     */   private boolean failFast;
/*     */   private final List<ValidatedValueUnwrapper<?>> validatedValueHandlers;
/*     */   private TimeProvider timeProvider;
/*     */   
/*     */   public ValidatorContextImpl(ValidatorFactoryImpl validatorFactory)
/*     */   {
/*  41 */     this.validatorFactory = validatorFactory;
/*  42 */     this.messageInterpolator = validatorFactory.getMessageInterpolator();
/*  43 */     this.traversableResolver = validatorFactory.getTraversableResolver();
/*  44 */     this.constraintValidatorFactory = validatorFactory.getConstraintValidatorFactory();
/*  45 */     this.parameterNameProvider = validatorFactory.getParameterNameProvider();
/*  46 */     this.failFast = validatorFactory.isFailFast();
/*     */     
/*  48 */     this.validatedValueHandlers = new ArrayList(validatorFactory.getValidatedValueHandlers());
/*     */     
/*  50 */     this.timeProvider = validatorFactory.getTimeProvider();
/*     */   }
/*     */   
/*     */   public HibernateValidatorContext messageInterpolator(MessageInterpolator messageInterpolator)
/*     */   {
/*  55 */     if (messageInterpolator == null) {
/*  56 */       this.messageInterpolator = this.validatorFactory.getMessageInterpolator();
/*     */     }
/*     */     else {
/*  59 */       this.messageInterpolator = messageInterpolator;
/*     */     }
/*  61 */     return this;
/*     */   }
/*     */   
/*     */   public HibernateValidatorContext traversableResolver(TraversableResolver traversableResolver)
/*     */   {
/*  66 */     if (traversableResolver == null) {
/*  67 */       this.traversableResolver = this.validatorFactory.getTraversableResolver();
/*     */     }
/*     */     else {
/*  70 */       this.traversableResolver = traversableResolver;
/*     */     }
/*  72 */     return this;
/*     */   }
/*     */   
/*     */   public HibernateValidatorContext constraintValidatorFactory(ConstraintValidatorFactory factory)
/*     */   {
/*  77 */     if (factory == null) {
/*  78 */       this.constraintValidatorFactory = this.validatorFactory.getConstraintValidatorFactory();
/*     */     }
/*     */     else {
/*  81 */       this.constraintValidatorFactory = factory;
/*     */     }
/*  83 */     return this;
/*     */   }
/*     */   
/*     */   public HibernateValidatorContext parameterNameProvider(ParameterNameProvider parameterNameProvider)
/*     */   {
/*  88 */     if (parameterNameProvider == null) {
/*  89 */       this.parameterNameProvider = this.validatorFactory.getParameterNameProvider();
/*     */     }
/*     */     else {
/*  92 */       this.parameterNameProvider = parameterNameProvider;
/*     */     }
/*  94 */     return this;
/*     */   }
/*     */   
/*     */   public HibernateValidatorContext failFast(boolean failFast)
/*     */   {
/*  99 */     this.failFast = failFast;
/* 100 */     return this;
/*     */   }
/*     */   
/*     */   public HibernateValidatorContext addValidationValueHandler(ValidatedValueUnwrapper<?> handler)
/*     */   {
/* 105 */     this.validatedValueHandlers.add(handler);
/* 106 */     return this;
/*     */   }
/*     */   
/*     */   public HibernateValidatorContext timeProvider(TimeProvider timeProvider)
/*     */   {
/* 111 */     if (timeProvider == null) {
/* 112 */       this.timeProvider = this.validatorFactory.getTimeProvider();
/*     */     }
/*     */     else {
/* 115 */       this.timeProvider = timeProvider;
/*     */     }
/* 117 */     return this;
/*     */   }
/*     */   
/*     */   public Validator getValidator()
/*     */   {
/* 122 */     return this.validatorFactory.createValidator(this.constraintValidatorFactory, this.messageInterpolator, this.traversableResolver, this.parameterNameProvider, this.failFast, this.validatedValueHandlers, this.timeProvider);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\engine\ValidatorContextImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */