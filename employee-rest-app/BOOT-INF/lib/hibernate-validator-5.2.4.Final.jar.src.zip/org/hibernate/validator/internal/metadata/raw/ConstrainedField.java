/*    */ package org.hibernate.validator.internal.metadata.raw;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.hibernate.validator.internal.engine.valuehandling.UnwrapMode;
/*    */ import org.hibernate.validator.internal.metadata.core.MetaConstraint;
/*    */ import org.hibernate.validator.internal.metadata.location.ConstraintLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstrainedField
/*    */   extends AbstractConstrainedElement
/*    */ {
/*    */   private final Set<MetaConstraint<?>> typeArgumentsConstraints;
/*    */   
/*    */   public ConstrainedField(ConfigurationSource source, ConstraintLocation location, Set<MetaConstraint<?>> constraints, Set<MetaConstraint<?>> typeArgumentsConstraints, Map<Class<?>, Class<?>> groupConversions, boolean isCascading, UnwrapMode unwrapMode)
/*    */   {
/* 48 */     super(source, ConstrainedElement.ConstrainedElementKind.FIELD, location, constraints, groupConversions, isCascading, unwrapMode);
/*    */     
/* 50 */     this.typeArgumentsConstraints = (typeArgumentsConstraints != null ? Collections.unmodifiableSet(typeArgumentsConstraints) : 
/*    */     
/* 52 */       Collections.emptySet());
/*    */   }
/*    */   
/*    */   public Set<MetaConstraint<?>> getTypeArgumentsConstraints() {
/* 56 */     return this.typeArgumentsConstraints;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 61 */     int prime = 31;
/* 62 */     int result = super.hashCode();
/* 63 */     result = 31 * result + (getLocation().getMember() == null ? 0 : getLocation().getMember().hashCode());
/* 64 */     return result;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 69 */     if (this == obj) {
/* 70 */       return true;
/*    */     }
/* 72 */     if (!super.equals(obj)) {
/* 73 */       return false;
/*    */     }
/* 75 */     if (getClass() != obj.getClass()) {
/* 76 */       return false;
/*    */     }
/* 78 */     ConstrainedField other = (ConstrainedField)obj;
/* 79 */     if (getLocation().getMember() == null) {
/* 80 */       if (other.getLocation().getMember() != null) {
/* 81 */         return false;
/*    */       }
/*    */     }
/* 84 */     else if (!getLocation().getMember().equals(other.getLocation().getMember())) {
/* 85 */       return false;
/*    */     }
/* 87 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\metadata\raw\ConstrainedField.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */