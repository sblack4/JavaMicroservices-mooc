/*     */ package org.hibernate.validator.internal.engine.groups;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.validation.GroupDefinitionException;
/*     */ import org.hibernate.validator.internal.util.CollectionHelper;
/*     */ import org.hibernate.validator.internal.util.logging.Log;
/*     */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DefaultValidationOrder
/*     */   implements ValidationOrder
/*     */ {
/*  27 */   private static final Log log = ;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  32 */   private List<Group> groupList = CollectionHelper.newArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  38 */   private Map<Class<?>, Sequence> sequenceMap = CollectionHelper.newHashMap();
/*     */   
/*     */   public Iterator<Group> getGroupIterator() {
/*  41 */     return this.groupList.iterator();
/*     */   }
/*     */   
/*     */   public Iterator<Sequence> getSequenceIterator() {
/*  45 */     return this.sequenceMap.values().iterator();
/*     */   }
/*     */   
/*     */   public void insertGroup(Group group) {
/*  49 */     if (!this.groupList.contains(group)) {
/*  50 */       this.groupList.add(group);
/*     */     }
/*     */   }
/*     */   
/*     */   public void insertSequence(Sequence sequence) {
/*  55 */     if (sequence == null) {
/*  56 */       return;
/*     */     }
/*     */     
/*  59 */     if (!this.sequenceMap.containsKey(sequence.getDefiningClass())) {
/*  60 */       this.sequenceMap.put(sequence.getDefiningClass(), sequence);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  66 */     return "ValidationOrder{groupList=" + this.groupList + ", sequenceMap=" + this.sequenceMap + '}';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void assertDefaultGroupSequenceIsExpandable(List<Class<?>> defaultGroupSequence)
/*     */     throws GroupDefinitionException
/*     */   {
/*  83 */     for (Map.Entry<Class<?>, Sequence> entry : this.sequenceMap.entrySet()) {
/*  84 */       List<Group> sequenceGroups = ((Sequence)entry.getValue()).getComposingGroups();
/*  85 */       int defaultGroupIndex = sequenceGroups.indexOf(Group.DEFAULT_GROUP);
/*  86 */       if (defaultGroupIndex != -1) {
/*  87 */         List<Group> defaultGroupList = buildTempGroupList(defaultGroupSequence);
/*  88 */         ensureDefaultGroupSequenceIsExpandable(sequenceGroups, defaultGroupList, defaultGroupIndex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void ensureDefaultGroupSequenceIsExpandable(List<Group> groupList, List<Group> defaultGroupList, int defaultGroupIndex) {
/*  94 */     for (int i = 0; i < defaultGroupList.size(); i++) {
/*  95 */       Group group = (Group)defaultGroupList.get(i);
/*  96 */       if (!Group.DEFAULT_GROUP.equals(group))
/*     */       {
/*     */ 
/*  99 */         int index = groupList.indexOf(group);
/* 100 */         if (index != -1)
/*     */         {
/*     */ 
/*     */ 
/* 104 */           if (((i != 0) || (index != defaultGroupIndex - 1)) && ((i != defaultGroupList.size() - 1) || (index != defaultGroupIndex + 1)))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/* 109 */             throw log.getUnableToExpandDefaultGroupListException(defaultGroupList, groupList); } }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 114 */   private List<Group> buildTempGroupList(List<Class<?>> defaultGroupSequence) { List<Group> groups = new ArrayList();
/* 115 */     for (Class<?> clazz : defaultGroupSequence) {
/* 116 */       Group g = new Group(clazz);
/* 117 */       groups.add(g);
/*     */     }
/* 119 */     return groups;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\engine\groups\DefaultValidationOrder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */