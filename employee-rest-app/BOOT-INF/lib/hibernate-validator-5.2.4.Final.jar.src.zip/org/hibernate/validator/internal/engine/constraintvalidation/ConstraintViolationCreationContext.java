/*    */ package org.hibernate.validator.internal.engine.constraintvalidation;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import org.hibernate.validator.internal.engine.path.PathImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstraintViolationCreationContext
/*    */ {
/*    */   private final String message;
/*    */   private final PathImpl propertyPath;
/*    */   private final Map<String, Object> expressionVariables;
/*    */   
/*    */   public ConstraintViolationCreationContext(String message, PathImpl property)
/*    */   {
/* 25 */     this(message, property, Collections.emptyMap());
/*    */   }
/*    */   
/*    */   public ConstraintViolationCreationContext(String message, PathImpl property, Map<String, Object> expressionVariables) {
/* 29 */     this.message = message;
/* 30 */     this.propertyPath = property;
/* 31 */     this.expressionVariables = expressionVariables;
/*    */   }
/*    */   
/*    */   public final String getMessage() {
/* 35 */     return this.message;
/*    */   }
/*    */   
/*    */   public final PathImpl getPath() {
/* 39 */     return this.propertyPath;
/*    */   }
/*    */   
/*    */   public Map<String, Object> getExpressionVariables() {
/* 43 */     return this.expressionVariables;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 48 */     StringBuilder sb = new StringBuilder("ConstraintViolationCreationContext{");
/* 49 */     sb.append("message='").append(this.message).append('\'');
/* 50 */     sb.append(", propertyPath=").append(this.propertyPath);
/* 51 */     sb.append(", messageParameters=").append(this.expressionVariables);
/* 52 */     sb.append('}');
/* 53 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\engine\constraintvalidation\ConstraintViolationCreationContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */