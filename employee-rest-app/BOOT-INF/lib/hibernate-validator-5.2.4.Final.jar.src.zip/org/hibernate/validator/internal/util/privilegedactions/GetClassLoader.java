/*    */ package org.hibernate.validator.internal.util.privilegedactions;
/*    */ 
/*    */ import java.security.PrivilegedAction;
/*    */ import org.hibernate.validator.internal.util.Contracts;
/*    */ import org.hibernate.validator.internal.util.logging.Messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GetClassLoader
/*    */   implements PrivilegedAction<ClassLoader>
/*    */ {
/*    */   private final Class<?> clazz;
/*    */   
/*    */   public static GetClassLoader fromContext()
/*    */   {
/* 22 */     return new GetClassLoader(null);
/*    */   }
/*    */   
/*    */   public static GetClassLoader fromClass(Class<?> clazz) {
/* 26 */     Contracts.assertNotNull(clazz, Messages.MESSAGES.classIsNull());
/* 27 */     return new GetClassLoader(clazz);
/*    */   }
/*    */   
/*    */   private GetClassLoader(Class<?> clazz) {
/* 31 */     this.clazz = clazz;
/*    */   }
/*    */   
/*    */   public ClassLoader run() {
/* 35 */     if (this.clazz != null) {
/* 36 */       return this.clazz.getClassLoader();
/*    */     }
/*    */     
/* 39 */     return Thread.currentThread().getContextClassLoader();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\util\privilegedactions\GetClassLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */