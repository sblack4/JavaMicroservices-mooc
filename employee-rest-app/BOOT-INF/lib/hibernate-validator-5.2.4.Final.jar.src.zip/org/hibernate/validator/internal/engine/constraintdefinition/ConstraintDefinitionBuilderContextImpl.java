/*    */ package org.hibernate.validator.internal.engine.constraintdefinition;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.List;
/*    */ import javax.validation.ConstraintValidator;
/*    */ import org.hibernate.validator.internal.util.CollectionHelper;
/*    */ import org.hibernate.validator.spi.constraintdefinition.ConstraintDefinitionContributor.ConstraintDefinitionBuilder;
/*    */ import org.hibernate.validator.spi.constraintdefinition.ConstraintDefinitionContributor.ConstraintDefinitionBuilderContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ConstraintDefinitionBuilderContextImpl<A extends Annotation>
/*    */   implements ConstraintDefinitionContributor.ConstraintDefinitionBuilderContext<A>
/*    */ {
/*    */   private final ConstraintDefinitionContributor.ConstraintDefinitionBuilder builder;
/*    */   private final Class<A> constraintType;
/* 25 */   private boolean includeExistingValidators = true;
/* 26 */   private final List<Class<? extends ConstraintValidator<A, ?>>> validatorTypes = CollectionHelper.newArrayList();
/*    */   
/*    */   public ConstraintDefinitionBuilderContextImpl(ConstraintDefinitionContributor.ConstraintDefinitionBuilder builder, Class<A> constraintType) {
/* 29 */     this.builder = builder;
/* 30 */     this.constraintType = constraintType;
/*    */   }
/*    */   
/*    */   public ConstraintDefinitionContributor.ConstraintDefinitionBuilderContext<A> includeExistingValidators(boolean include)
/*    */   {
/* 35 */     this.includeExistingValidators = include;
/* 36 */     return this;
/*    */   }
/*    */   
/*    */   public ConstraintDefinitionContributor.ConstraintDefinitionBuilderContext<A> validatedBy(Class<? extends ConstraintValidator<A, ?>> validatorType)
/*    */   {
/* 41 */     this.validatorTypes.add(validatorType);
/* 42 */     return this;
/*    */   }
/*    */   
/*    */   public <B extends Annotation> ConstraintDefinitionContributor.ConstraintDefinitionBuilderContext<B> constraint(Class<B> constraintType)
/*    */   {
/* 47 */     return this.builder.constraint(constraintType);
/*    */   }
/*    */   
/*    */   ConstraintDefinitionContribution<?> build() {
/* 51 */     return new ConstraintDefinitionContribution(this.constraintType, this.validatorTypes, this.includeExistingValidators);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\engine\constraintdefinition\ConstraintDefinitionBuilderContextImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */