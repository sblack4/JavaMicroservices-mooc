/*     */ package org.hibernate.validator.internal.xml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import javax.validation.BootstrapConfiguration;
/*     */ import javax.validation.executable.ExecutableType;
/*     */ import javax.xml.bind.JAXBContext;
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.validation.Schema;
/*     */ import org.hibernate.validator.internal.util.logging.Log;
/*     */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*     */ import org.hibernate.validator.internal.util.privilegedactions.NewJaxbContext;
/*     */ import org.hibernate.validator.internal.util.privilegedactions.Unmarshal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidationXmlParser
/*     */ {
/*  41 */   private static final Log log = ;
/*     */   
/*     */   private static final String VALIDATION_XML_FILE = "META-INF/validation.xml";
/*  44 */   private static final ConcurrentMap<String, String> SCHEMAS_BY_VERSION = new ConcurrentHashMap(2, 0.75F, 1);
/*     */   
/*     */ 
/*     */   private final ClassLoader externalClassLoader;
/*     */   
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  53 */     SCHEMAS_BY_VERSION.put("1.0", "META-INF/validation-configuration-1.0.xsd");
/*  54 */     SCHEMAS_BY_VERSION.put("1.1", "META-INF/validation-configuration-1.1.xsd");
/*     */   }
/*     */   
/*     */   public ValidationXmlParser(ClassLoader externalClassLoader) {
/*  58 */     this.externalClassLoader = externalClassLoader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final BootstrapConfiguration parseValidationXml()
/*     */   {
/*  67 */     InputStream inputStream = getValidationXmlInputStream();
/*  68 */     if (inputStream == null) {
/*  69 */       return BootstrapConfigurationImpl.getDefaultBootstrapConfiguration();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/*  76 */       XmlParserHelper xmlParserHelper = new XmlParserHelper();
/*  77 */       XMLEventReader xmlEventReader = xmlParserHelper.createXmlEventReader("META-INF/validation.xml", inputStream);
/*     */       
/*  79 */       String schemaVersion = xmlParserHelper.getSchemaVersion("META-INF/validation.xml", xmlEventReader);
/*  80 */       Schema schema = getSchema(xmlParserHelper, schemaVersion);
/*  81 */       ValidationConfigType validationConfig = unmarshal(xmlEventReader, schema);
/*     */       
/*  83 */       return createBootstrapConfiguration(validationConfig);
/*     */     }
/*     */     finally {
/*  86 */       closeStream(inputStream);
/*     */     }
/*     */   }
/*     */   
/*     */   private InputStream getValidationXmlInputStream() {
/*  91 */     log.debugf("Trying to load %s for XML based Validator configuration.", "META-INF/validation.xml");
/*  92 */     InputStream inputStream = ResourceLoaderHelper.getResettableInputStreamForPath("META-INF/validation.xml", this.externalClassLoader);
/*     */     
/*  94 */     if (inputStream != null) {
/*  95 */       return inputStream;
/*     */     }
/*     */     
/*  98 */     log.debugf("No %s found. Using annotation based configuration only.", "META-INF/validation.xml");
/*  99 */     return null;
/*     */   }
/*     */   
/*     */   private Schema getSchema(XmlParserHelper xmlParserHelper, String schemaVersion)
/*     */   {
/* 104 */     String schemaResource = (String)SCHEMAS_BY_VERSION.get(schemaVersion);
/*     */     
/* 106 */     if (schemaResource == null) {
/* 107 */       throw log.getUnsupportedSchemaVersionException("META-INF/validation.xml", schemaVersion);
/*     */     }
/*     */     
/* 110 */     return xmlParserHelper.getSchema(schemaResource);
/*     */   }
/*     */   
/*     */   private ValidationConfigType unmarshal(XMLEventReader xmlEventReader, Schema schema) {
/* 114 */     log.parsingXMLFile("META-INF/validation.xml");
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 119 */       JAXBContext jc = (JAXBContext)run(NewJaxbContext.action(ValidationConfigType.class));
/* 120 */       Unmarshaller unmarshaller = jc.createUnmarshaller();
/* 121 */       unmarshaller.setSchema(schema);
/*     */       
/*     */ 
/*     */ 
/* 125 */       JAXBElement<ValidationConfigType> root = (JAXBElement)run(Unmarshal.action(unmarshaller, xmlEventReader, ValidationConfigType.class));
/* 126 */       return (ValidationConfigType)root.getValue();
/*     */     }
/*     */     catch (Exception e) {
/* 129 */       throw log.getUnableToParseValidationXmlFileException("META-INF/validation.xml", e);
/*     */     }
/*     */   }
/*     */   
/*     */   private void closeStream(InputStream inputStream) {
/*     */     try {
/* 135 */       inputStream.close();
/*     */     }
/*     */     catch (IOException io) {
/* 138 */       log.unableToCloseXMLFileInputStream("META-INF/validation.xml");
/*     */     }
/*     */   }
/*     */   
/*     */   private BootstrapConfiguration createBootstrapConfiguration(ValidationConfigType config) {
/* 143 */     Map<String, String> properties = new HashMap();
/* 144 */     for (PropertyType property : config.getProperty()) {
/* 145 */       if (log.isDebugEnabled()) {
/* 146 */         log.debugf("Found property '%s' with value '%s' in validation.xml.", property
/*     */         
/* 148 */           .getName(), property
/* 149 */           .getValue());
/*     */       }
/*     */       
/* 152 */       properties.put(property.getName(), property.getValue());
/*     */     }
/*     */     
/* 155 */     ExecutableValidationType executableValidationType = config.getExecutableValidation();
/*     */     
/*     */ 
/* 158 */     EnumSet<ExecutableType> defaultValidatedExecutableTypes = executableValidationType == null ? getValidatedExecutableTypes(null) : getValidatedExecutableTypes(executableValidationType.getDefaultValidatedExecutableTypes());
/* 159 */     boolean executableValidationEnabled = (executableValidationType == null) || (executableValidationType.getEnabled());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 169 */     return new BootstrapConfigurationImpl(config.getDefaultProvider(), config.getConstraintValidatorFactory(), config.getMessageInterpolator(), config.getTraversableResolver(), config.getParameterNameProvider(), defaultValidatedExecutableTypes, executableValidationEnabled, new HashSet(config.getConstraintMapping()), properties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private EnumSet<ExecutableType> getValidatedExecutableTypes(DefaultValidatedExecutableTypesType validatedExecutables)
/*     */   {
/* 184 */     if (validatedExecutables == null) {
/* 185 */       return null;
/*     */     }
/*     */     
/* 188 */     EnumSet<ExecutableType> executableTypes = EnumSet.noneOf(ExecutableType.class);
/* 189 */     executableTypes.addAll(validatedExecutables.getExecutableType());
/*     */     
/* 191 */     return executableTypes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private <T> T run(PrivilegedExceptionAction<T> action)
/*     */     throws Exception
/*     */   {
/* 201 */     return (T)(System.getSecurityManager() != null ? AccessController.doPrivileged(action) : action.run());
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\xml\ValidationXmlParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */