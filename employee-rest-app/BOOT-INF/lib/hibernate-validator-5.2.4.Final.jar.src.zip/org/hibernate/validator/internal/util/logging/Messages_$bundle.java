/*     */ package org.hibernate.validator.internal.util.logging;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Messages_$bundle
/*     */   implements Serializable, Messages
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  18 */   public static final bundle INSTANCE = new bundle();
/*     */   
/*     */   private static final String mustNotBeNull0 = "must not be null.";
/*     */   
/*     */   private static final String mustNotBeNull1 = "%s must not be null.";
/*     */   private static final String parameterMustNotBeNull = "The parameter \"%s\" must not be null.";
/*     */   private static final String parameterMustNotBeEmpty = "The parameter \"%s\" must not be empty.";
/*     */   private static final String beanTypeCannotBeNull = "The bean type cannot be null.";
/*     */   private static final String propertyPathCannotBeNull = "null is not allowed as property path.";
/*     */   private static final String propertyNameMustNotBeEmpty = "The property name must not be empty.";
/*     */   private static final String groupMustNotBeNull = "null passed as group name.";
/*     */   private static final String beanTypeMustNotBeNull = "The bean type must not be null when creating a constraint mapping.";
/*     */   private static final String methodNameMustNotBeNull = "The method name must not be null.";
/*     */   private static final String validatedObjectMustNotBeNull = "The object to be validated must not be null.";
/*     */   private static final String validatedMethodMustNotBeNull = "The method to be validated must not be null.";
/*     */   private static final String classCannotBeNull = "The class cannot be null.";
/*     */   private static final String classIsNull = "Class is null.";
/*     */   private static final String unableToFindScriptEngine = "No JSR 223 script engine found for language \"%s\".";
/*     */   private static final String validatedConstructorMustNotBeNull = "The constructor to be validated must not be null.";
/*     */   private static final String validatedParameterArrayMustNotBeNull = "The method parameter array cannot not be null.";
/*     */   private static final String validatedConstructorCreatedInstanceMustNotBeNull = "The created instance must not be null.";
/*     */   private static final String inputStreamCannotBeNull = "The input stream for #addMapping() cannot be null.";
/*     */   private static final String constraintOnConstructorOfNonStaticInnerClass = "Constraints on the parameters of constructors of non-static inner classes are not supported if those parameters have a generic type due to JDK bug JDK-5087240.";
/*     */   private static final String parameterizedTypesWithMoreThanOneTypeArgument = "Custom parameterized types with more than one type argument are not supported and will not be checked for type use constraints.";
/*     */   private static final String unableToUseResourceBundleAggregation = "Hibernate Validator cannot instantiate AggregateResourceBundle.CONTROL. This can happen most notably in a Google App Engine environment. A PlatformResourceBundleLocator without bundle aggregation was created. This only effects you in case you are using multiple ConstraintDefinitionContributor jars. ConstraintDefinitionContributors are a Hibernate Validator specific feature. All Bean Validation features work as expected. See also https://hibernate.atlassian.net/browse/HV-1023.";
/*     */   
/*     */   protected Object readResolve()
/*     */   {
/*  46 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   public final String mustNotBeNull() {
/*  50 */     String result = mustNotBeNull0$str();
/*  51 */     return result;
/*     */   }
/*     */   
/*     */   protected String mustNotBeNull0$str() {
/*  55 */     return "must not be null.";
/*     */   }
/*     */   
/*     */   public final String mustNotBeNull(String parameterName) {
/*  59 */     String result = String.format(mustNotBeNull1$str(), new Object[] { parameterName });
/*  60 */     return result;
/*     */   }
/*     */   
/*     */   protected String mustNotBeNull1$str() {
/*  64 */     return "%s must not be null.";
/*     */   }
/*     */   
/*     */   public final String parameterMustNotBeNull(String parameterName) {
/*  68 */     String result = String.format(parameterMustNotBeNull$str(), new Object[] { parameterName });
/*  69 */     return result;
/*     */   }
/*     */   
/*     */   protected String parameterMustNotBeNull$str() {
/*  73 */     return "The parameter \"%s\" must not be null.";
/*     */   }
/*     */   
/*     */   public final String parameterMustNotBeEmpty(String parameterName) {
/*  77 */     String result = String.format(parameterMustNotBeEmpty$str(), new Object[] { parameterName });
/*  78 */     return result;
/*     */   }
/*     */   
/*     */   protected String parameterMustNotBeEmpty$str() {
/*  82 */     return "The parameter \"%s\" must not be empty.";
/*     */   }
/*     */   
/*     */   public final String beanTypeCannotBeNull() {
/*  86 */     String result = beanTypeCannotBeNull$str();
/*  87 */     return result;
/*     */   }
/*     */   
/*     */   protected String beanTypeCannotBeNull$str() {
/*  91 */     return "The bean type cannot be null.";
/*     */   }
/*     */   
/*     */   public final String propertyPathCannotBeNull() {
/*  95 */     String result = propertyPathCannotBeNull$str();
/*  96 */     return result;
/*     */   }
/*     */   
/*     */   protected String propertyPathCannotBeNull$str() {
/* 100 */     return "null is not allowed as property path.";
/*     */   }
/*     */   
/*     */   public final String propertyNameMustNotBeEmpty() {
/* 104 */     String result = propertyNameMustNotBeEmpty$str();
/* 105 */     return result;
/*     */   }
/*     */   
/*     */   protected String propertyNameMustNotBeEmpty$str() {
/* 109 */     return "The property name must not be empty.";
/*     */   }
/*     */   
/*     */   public final String groupMustNotBeNull() {
/* 113 */     String result = groupMustNotBeNull$str();
/* 114 */     return result;
/*     */   }
/*     */   
/*     */   protected String groupMustNotBeNull$str() {
/* 118 */     return "null passed as group name.";
/*     */   }
/*     */   
/*     */   public final String beanTypeMustNotBeNull() {
/* 122 */     String result = beanTypeMustNotBeNull$str();
/* 123 */     return result;
/*     */   }
/*     */   
/*     */   protected String beanTypeMustNotBeNull$str() {
/* 127 */     return "The bean type must not be null when creating a constraint mapping.";
/*     */   }
/*     */   
/*     */   public final String methodNameMustNotBeNull() {
/* 131 */     String result = methodNameMustNotBeNull$str();
/* 132 */     return result;
/*     */   }
/*     */   
/*     */   protected String methodNameMustNotBeNull$str() {
/* 136 */     return "The method name must not be null.";
/*     */   }
/*     */   
/*     */   public final String validatedObjectMustNotBeNull() {
/* 140 */     String result = validatedObjectMustNotBeNull$str();
/* 141 */     return result;
/*     */   }
/*     */   
/*     */   protected String validatedObjectMustNotBeNull$str() {
/* 145 */     return "The object to be validated must not be null.";
/*     */   }
/*     */   
/*     */   public final String validatedMethodMustNotBeNull() {
/* 149 */     String result = validatedMethodMustNotBeNull$str();
/* 150 */     return result;
/*     */   }
/*     */   
/*     */   protected String validatedMethodMustNotBeNull$str() {
/* 154 */     return "The method to be validated must not be null.";
/*     */   }
/*     */   
/*     */   public final String classCannotBeNull() {
/* 158 */     String result = classCannotBeNull$str();
/* 159 */     return result;
/*     */   }
/*     */   
/*     */   protected String classCannotBeNull$str() {
/* 163 */     return "The class cannot be null.";
/*     */   }
/*     */   
/*     */   public final String classIsNull() {
/* 167 */     String result = classIsNull$str();
/* 168 */     return result;
/*     */   }
/*     */   
/*     */   protected String classIsNull$str() {
/* 172 */     return "Class is null.";
/*     */   }
/*     */   
/*     */   public final String unableToFindScriptEngine(String languageName) {
/* 176 */     String result = String.format(unableToFindScriptEngine$str(), new Object[] { languageName });
/* 177 */     return result;
/*     */   }
/*     */   
/*     */   protected String unableToFindScriptEngine$str() {
/* 181 */     return "No JSR 223 script engine found for language \"%s\".";
/*     */   }
/*     */   
/*     */   public final String validatedConstructorMustNotBeNull() {
/* 185 */     String result = validatedConstructorMustNotBeNull$str();
/* 186 */     return result;
/*     */   }
/*     */   
/*     */   protected String validatedConstructorMustNotBeNull$str() {
/* 190 */     return "The constructor to be validated must not be null.";
/*     */   }
/*     */   
/*     */   public final String validatedParameterArrayMustNotBeNull() {
/* 194 */     String result = validatedParameterArrayMustNotBeNull$str();
/* 195 */     return result;
/*     */   }
/*     */   
/*     */   protected String validatedParameterArrayMustNotBeNull$str() {
/* 199 */     return "The method parameter array cannot not be null.";
/*     */   }
/*     */   
/*     */   public final String validatedConstructorCreatedInstanceMustNotBeNull() {
/* 203 */     String result = validatedConstructorCreatedInstanceMustNotBeNull$str();
/* 204 */     return result;
/*     */   }
/*     */   
/*     */   protected String validatedConstructorCreatedInstanceMustNotBeNull$str() {
/* 208 */     return "The created instance must not be null.";
/*     */   }
/*     */   
/*     */   public final String inputStreamCannotBeNull() {
/* 212 */     String result = String.format(inputStreamCannotBeNull$str(), new Object[0]);
/* 213 */     return result;
/*     */   }
/*     */   
/*     */   protected String inputStreamCannotBeNull$str() {
/* 217 */     return "The input stream for #addMapping() cannot be null.";
/*     */   }
/*     */   
/*     */   public final String constraintOnConstructorOfNonStaticInnerClass() {
/* 221 */     String result = String.format(constraintOnConstructorOfNonStaticInnerClass$str(), new Object[0]);
/* 222 */     return result;
/*     */   }
/*     */   
/*     */   protected String constraintOnConstructorOfNonStaticInnerClass$str() {
/* 226 */     return "Constraints on the parameters of constructors of non-static inner classes are not supported if those parameters have a generic type due to JDK bug JDK-5087240.";
/*     */   }
/*     */   
/*     */   public final String parameterizedTypesWithMoreThanOneTypeArgument() {
/* 230 */     String result = String.format(parameterizedTypesWithMoreThanOneTypeArgument$str(), new Object[0]);
/* 231 */     return result;
/*     */   }
/*     */   
/*     */   protected String parameterizedTypesWithMoreThanOneTypeArgument$str() {
/* 235 */     return "Custom parameterized types with more than one type argument are not supported and will not be checked for type use constraints.";
/*     */   }
/*     */   
/*     */   public final String unableToUseResourceBundleAggregation() {
/* 239 */     String result = String.format(unableToUseResourceBundleAggregation$str(), new Object[0]);
/* 240 */     return result;
/*     */   }
/*     */   
/*     */   protected String unableToUseResourceBundleAggregation$str() {
/* 244 */     return "Hibernate Validator cannot instantiate AggregateResourceBundle.CONTROL. This can happen most notably in a Google App Engine environment. A PlatformResourceBundleLocator without bundle aggregation was created. This only effects you in case you are using multiple ConstraintDefinitionContributor jars. ConstraintDefinitionContributors are a Hibernate Validator specific feature. All Bean Validation features work as expected. See also https://hibernate.atlassian.net/browse/HV-1023.";
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\util\logging\Messages_$bundle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */