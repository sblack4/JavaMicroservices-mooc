/*     */ package org.hibernate.validator.internal.engine;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.ElementType;
/*     */ import java.util.Map;
/*     */ import javax.validation.ConstraintViolation;
/*     */ import javax.validation.Path;
/*     */ import javax.validation.metadata.ConstraintDescriptor;
/*     */ import org.hibernate.validator.internal.util.logging.Log;
/*     */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstraintViolationImpl<T>
/*     */   implements ConstraintViolation<T>, Serializable
/*     */ {
/*  24 */   private static final Log log = ;
/*     */   
/*     */   private static final long serialVersionUID = -4970067626703103139L;
/*     */   
/*     */   private final String interpolatedMessage;
/*     */   
/*     */   private final T rootBean;
/*     */   
/*     */   private final Object value;
/*     */   
/*     */   private final Path propertyPath;
/*     */   
/*     */   private final Object leafBeanInstance;
/*     */   
/*     */   private final ConstraintDescriptor<?> constraintDescriptor;
/*     */   
/*     */   private final String messageTemplate;
/*     */   
/*     */   private final Map<String, Object> expressionVariables;
/*     */   private final Class<T> rootBeanClass;
/*     */   private final ElementType elementType;
/*     */   private final Object[] executableParameters;
/*     */   private final Object executableReturnValue;
/*     */   private final int hashCode;
/*     */   
/*     */   public static <T> ConstraintViolation<T> forBeanValidation(String messageTemplate, Map<String, Object> expressionVariables, String interpolatedMessage, Class<T> rootBeanClass, T rootBean, Object leafBeanInstance, Object value, Path propertyPath, ConstraintDescriptor<?> constraintDescriptor, ElementType elementType)
/*     */   {
/*  51 */     return new ConstraintViolationImpl(messageTemplate, expressionVariables, interpolatedMessage, rootBeanClass, rootBean, leafBeanInstance, value, propertyPath, constraintDescriptor, elementType, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T> ConstraintViolation<T> forParameterValidation(String messageTemplate, Map<String, Object> expressionVariables, String interpolatedMessage, Class<T> rootBeanClass, T rootBean, Object leafBeanInstance, Object value, Path propertyPath, ConstraintDescriptor<?> constraintDescriptor, ElementType elementType, Object[] executableParameters)
/*     */   {
/*  78 */     return new ConstraintViolationImpl(messageTemplate, expressionVariables, interpolatedMessage, rootBeanClass, rootBean, leafBeanInstance, value, propertyPath, constraintDescriptor, elementType, executableParameters, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T> ConstraintViolation<T> forReturnValueValidation(String messageTemplate, Map<String, Object> expressionVariables, String interpolatedMessage, Class<T> rootBeanClass, T rootBean, Object leafBeanInstance, Object value, Path propertyPath, ConstraintDescriptor<?> constraintDescriptor, ElementType elementType, Object executableReturnValue)
/*     */   {
/* 105 */     return new ConstraintViolationImpl(messageTemplate, expressionVariables, interpolatedMessage, rootBeanClass, rootBean, leafBeanInstance, value, propertyPath, constraintDescriptor, elementType, null, executableReturnValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ConstraintViolationImpl(String messageTemplate, Map<String, Object> expressionVariables, String interpolatedMessage, Class<T> rootBeanClass, T rootBean, Object leafBeanInstance, Object value, Path propertyPath, ConstraintDescriptor<?> constraintDescriptor, ElementType elementType, Object[] executableParameters, Object executableReturnValue)
/*     */   {
/* 133 */     this.messageTemplate = messageTemplate;
/* 134 */     this.expressionVariables = expressionVariables;
/* 135 */     this.interpolatedMessage = interpolatedMessage;
/* 136 */     this.rootBean = rootBean;
/* 137 */     this.value = value;
/* 138 */     this.propertyPath = propertyPath;
/* 139 */     this.leafBeanInstance = leafBeanInstance;
/* 140 */     this.constraintDescriptor = constraintDescriptor;
/* 141 */     this.rootBeanClass = rootBeanClass;
/* 142 */     this.elementType = elementType;
/* 143 */     this.executableParameters = executableParameters;
/* 144 */     this.executableReturnValue = executableReturnValue;
/*     */     
/* 146 */     this.hashCode = createHashCode();
/*     */   }
/*     */   
/*     */   public final String getMessage()
/*     */   {
/* 151 */     return this.interpolatedMessage;
/*     */   }
/*     */   
/*     */   public final String getMessageTemplate()
/*     */   {
/* 156 */     return this.messageTemplate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, Object> getExpressionVariables()
/*     */   {
/* 164 */     return this.expressionVariables;
/*     */   }
/*     */   
/*     */   public final T getRootBean()
/*     */   {
/* 169 */     return (T)this.rootBean;
/*     */   }
/*     */   
/*     */   public final Class<T> getRootBeanClass()
/*     */   {
/* 174 */     return this.rootBeanClass;
/*     */   }
/*     */   
/*     */   public final Object getLeafBean()
/*     */   {
/* 179 */     return this.leafBeanInstance;
/*     */   }
/*     */   
/*     */   public final Object getInvalidValue()
/*     */   {
/* 184 */     return this.value;
/*     */   }
/*     */   
/*     */   public final Path getPropertyPath()
/*     */   {
/* 189 */     return this.propertyPath;
/*     */   }
/*     */   
/*     */   public final ConstraintDescriptor<?> getConstraintDescriptor()
/*     */   {
/* 194 */     return this.constraintDescriptor;
/*     */   }
/*     */   
/*     */   public <C> C unwrap(Class<C> type)
/*     */   {
/* 199 */     if (type.isAssignableFrom(ConstraintViolation.class)) {
/* 200 */       return (C)type.cast(this);
/*     */     }
/* 202 */     throw log.getTypeNotSupportedForUnwrappingException(type);
/*     */   }
/*     */   
/*     */   public Object[] getExecutableParameters()
/*     */   {
/* 207 */     return this.executableParameters;
/*     */   }
/*     */   
/*     */   public Object getExecutableReturnValue()
/*     */   {
/* 212 */     return this.executableReturnValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 222 */     if (this == o) {
/* 223 */       return true;
/*     */     }
/* 225 */     if ((o == null) || (getClass() != o.getClass())) {
/* 226 */       return false;
/*     */     }
/*     */     
/* 229 */     ConstraintViolationImpl<?> that = (ConstraintViolationImpl)o;
/*     */     
/* 231 */     if (this.interpolatedMessage != null ? !this.interpolatedMessage.equals(that.interpolatedMessage) : that.interpolatedMessage != null) {
/* 232 */       return false;
/*     */     }
/* 234 */     if (this.propertyPath != null ? !this.propertyPath.equals(that.propertyPath) : that.propertyPath != null) {
/* 235 */       return false;
/*     */     }
/* 237 */     if (this.rootBean != null ? !this.rootBean.equals(that.rootBean) : that.rootBean != null) {
/* 238 */       return false;
/*     */     }
/* 240 */     if (this.leafBeanInstance != null ? !this.leafBeanInstance.equals(that.leafBeanInstance) : that.leafBeanInstance != null) {
/* 241 */       return false;
/*     */     }
/* 243 */     if (this.constraintDescriptor != null ? !this.constraintDescriptor.equals(that.constraintDescriptor) : that.constraintDescriptor != null) {
/* 244 */       return false;
/*     */     }
/* 246 */     if (this.elementType != null ? !this.elementType.equals(that.elementType) : that.elementType != null) {
/* 247 */       return false;
/*     */     }
/* 249 */     if (this.messageTemplate != null ? !this.messageTemplate.equals(that.messageTemplate) : that.messageTemplate != null) {
/* 250 */       return false;
/*     */     }
/* 252 */     if (this.rootBeanClass != null ? !this.rootBeanClass.equals(that.rootBeanClass) : that.rootBeanClass != null) {
/* 253 */       return false;
/*     */     }
/* 255 */     if (this.value != null ? !this.value.equals(that.value) : that.value != null) {
/* 256 */       return false;
/*     */     }
/*     */     
/* 259 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 264 */     return this.hashCode;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 269 */     StringBuilder sb = new StringBuilder();
/* 270 */     sb.append("ConstraintViolationImpl");
/* 271 */     sb.append("{interpolatedMessage='").append(this.interpolatedMessage).append('\'');
/* 272 */     sb.append(", propertyPath=").append(this.propertyPath);
/* 273 */     sb.append(", rootBeanClass=").append(this.rootBeanClass);
/* 274 */     sb.append(", messageTemplate='").append(this.messageTemplate).append('\'');
/* 275 */     sb.append('}');
/* 276 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private int createHashCode()
/*     */   {
/* 281 */     int result = this.interpolatedMessage != null ? this.interpolatedMessage.hashCode() : 0;
/* 282 */     result = 31 * result + (this.propertyPath != null ? this.propertyPath.hashCode() : 0);
/* 283 */     result = 31 * result + (this.rootBean != null ? this.rootBean.hashCode() : 0);
/* 284 */     result = 31 * result + (this.leafBeanInstance != null ? this.leafBeanInstance.hashCode() : 0);
/* 285 */     result = 31 * result + (this.value != null ? this.value.hashCode() : 0);
/* 286 */     result = 31 * result + (this.constraintDescriptor != null ? this.constraintDescriptor.hashCode() : 0);
/* 287 */     result = 31 * result + (this.messageTemplate != null ? this.messageTemplate.hashCode() : 0);
/* 288 */     result = 31 * result + (this.rootBeanClass != null ? this.rootBeanClass.hashCode() : 0);
/* 289 */     result = 31 * result + (this.elementType != null ? this.elementType.hashCode() : 0);
/* 290 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\engine\ConstraintViolationImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */