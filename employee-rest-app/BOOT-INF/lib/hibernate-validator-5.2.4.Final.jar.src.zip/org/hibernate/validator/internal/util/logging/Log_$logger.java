/*      */ package org.hibernate.validator.internal.util.logging;
/*      */ 
/*      */ import java.lang.annotation.ElementType;
/*      */ import java.lang.reflect.Member;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Type;
/*      */ import java.lang.reflect.TypeVariable;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import java.util.regex.PatternSyntaxException;
/*      */ import javax.validation.ConstraintDeclarationException;
/*      */ import javax.validation.ConstraintDefinitionException;
/*      */ import javax.validation.ConstraintTarget;
/*      */ import javax.validation.ElementKind;
/*      */ import javax.validation.GroupDefinitionException;
/*      */ import javax.validation.Path;
/*      */ import javax.validation.UnexpectedTypeException;
/*      */ import javax.validation.ValidationException;
/*      */ import javax.xml.stream.XMLStreamException;
/*      */ import org.hibernate.validator.internal.engine.messageinterpolation.parser.MessageDescriptorFormatException;
/*      */ import org.hibernate.validator.internal.metadata.descriptor.ConstraintDescriptorImpl.ConstraintType;
/*      */ import org.jboss.logging.BasicLogger;
/*      */ import org.jboss.logging.DelegatingBasicLogger;
/*      */ import org.jboss.logging.Logger;
/*      */ import org.jboss.logging.Logger.Level;
/*      */ 
/*      */ public class Log_$logger extends DelegatingBasicLogger implements java.io.Serializable, Log, BasicLogger
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   31 */   private static final String FQCN = logger.class.getName();
/*      */   private static final String version = "HV000001: Hibernate Validator %s";
/*      */   private static final String ignoringXmlConfiguration = "HV000002: Ignoring XML configuration.";
/*      */   private static final String usingConstraintFactory = "HV000003: Using %s as constraint factory.";
/*      */   private static final String usingMessageInterpolator = "HV000004: Using %s as message interpolator.";
/*      */   private static final String usingTraversableResolver = "HV000005: Using %s as traversable resolver.";
/*      */   private static final String usingValidationProvider = "HV000006: Using %s as validation provider.";
/*      */   private static final String parsingXMLFile = "HV000007: %s found. Parsing XML based configuration.";
/*      */   private static final String unableToCloseInputStream = "HV000008: Unable to close input stream.";
/*      */   private static final String unableToCloseXMLFileInputStream = "HV000010: Unable to close input stream for %s.";
/*      */   private static final String unableToCreateSchema = "HV000011: Unable to create schema for %1$s: %2$s";
/*      */   private static final String getUnableToCreateAnnotationForConfiguredConstraintException = "HV000012: Unable to create annotation for configured constraint";
/*      */   private static final String getUnableToFindPropertyWithAccessException = "HV000013: The class %1$s does not have a property '%2$s' with access %3$s.";
/*      */   private static final String getUnableToFindMethodException = "HV000014: Type %1$s doesn't have a method %2$s.";
/*      */   private static final String getInvalidBigDecimalFormatException = "HV000016: %s does not represent a valid BigDecimal format.";
/*      */   private static final String getInvalidLengthForIntegerPartException = "HV000017: The length of the integer part cannot be negative.";
/*      */   private static final String getInvalidLengthForFractionPartException = "HV000018: The length of the fraction part cannot be negative.";
/*      */   private static final String getMinCannotBeNegativeException = "HV000019: The min parameter cannot be negative.";
/*      */   private static final String getMaxCannotBeNegativeException = "HV000020: The max parameter cannot be negative.";
/*      */   private static final String getLengthCannotBeNegativeException = "HV000021: The length cannot be negative.";
/*      */   private static final String getInvalidRegularExpressionException = "HV000022: Invalid regular expression.";
/*      */   private static final String getErrorDuringScriptExecutionException = "HV000023: Error during execution of script \"%s\" occurred.";
/*      */   private static final String getScriptMustReturnTrueOrFalseException1 = "HV000024: Script \"%s\" returned null, but must return either true or false.";
/*      */   private static final String getScriptMustReturnTrueOrFalseException3 = "HV000025: Script \"%1$s\" returned %2$s (of type %3$s), but must return either true or false.";
/*      */   private static final String getInconsistentConfigurationException = "HV000026: Assertion error: inconsistent ConfigurationImpl construction.";
/*      */   private static final String getUnableToFindProviderException = "HV000027: Unable to find provider: %s.";
/*      */   private static final String getExceptionDuringIsValidCallException = "HV000028: Unexpected exception during isValid call.";
/*      */   private static final String getConstraintFactoryMustNotReturnNullException = "HV000029: Constraint factory returned null when trying to create instance of %s.";
/*      */   private static final String getNoValidatorFoundForTypeException = "HV000030: No validator could be found for constraint '%s' validating type '%s'. Check configuration for '%s'";
/*      */   private static final String getMoreThanOneValidatorFoundForTypeException = "HV000031: There are multiple validator classes which could validate the type %1$s. The validator classes are: %2$s.";
/*      */   private static final String getUnableToInitializeConstraintValidatorException = "HV000032: Unable to initialize %s.";
/*      */   private static final String getAtLeastOneCustomMessageMustBeCreatedException = "HV000033: At least one custom message must be created if the default error message gets disabled.";
/*      */   private static final String getInvalidJavaIdentifierException = "HV000034: %s is not a valid Java Identifier.";
/*      */   private static final String getUnableToParsePropertyPathException = "HV000035: Unable to parse property path %s.";
/*      */   private static final String getTypeNotSupportedForUnwrappingException = "HV000036: Type %s not supported for unwrapping.";
/*      */   private static final String getInconsistentFailFastConfigurationException = "HV000037: Inconsistent fail fast configuration. Fail fast enabled via programmatic API, but explicitly disabled via properties.";
/*      */   private static final String getInvalidPropertyPathException0 = "HV000038: Invalid property path.";
/*      */   private static final String getInvalidPropertyPathException2 = "HV000039: Invalid property path. There is no property %1$s in entity %2$s.";
/*      */   private static final String getPropertyPathMustProvideIndexOrMapKeyException = "HV000040: Property path must provide index or map key.";
/*      */   private static final String getErrorDuringCallOfTraversableResolverIsReachableException = "HV000041: Call to TraversableResolver.isReachable() threw an exception.";
/*      */   private static final String getErrorDuringCallOfTraversableResolverIsCascadableException = "HV000042: Call to TraversableResolver.isCascadable() threw an exception.";
/*      */   private static final String getUnableToExpandDefaultGroupListException = "HV000043: Unable to expand default group list %1$s into sequence %2$s.";
/*      */   private static final String getAtLeastOneGroupHasToBeSpecifiedException = "HV000044: At least one group has to be specified.";
/*      */   private static final String getGroupHasToBeAnInterfaceException = "HV000045: A group has to be an interface. %s is not.";
/*      */   private static final String getSequenceDefinitionsNotAllowedException = "HV000046: Sequence definitions are not allowed as composing parts of a sequence.";
/*      */   private static final String getCyclicDependencyInGroupsDefinitionException = "HV000047: Cyclic dependency in groups definition";
/*      */   private static final String getUnableToExpandGroupSequenceException = "HV000048: Unable to expand group sequence.";
/*      */   private static final String getInvalidDefaultGroupSequenceDefinitionException = "HV000052: Default group sequence and default group sequence provider cannot be defined at the same time.";
/*      */   private static final String getNoDefaultGroupInGroupSequenceException = "HV000053: 'Default.class' cannot appear in default group sequence list.";
/*      */   private static final String getBeanClassMustBePartOfRedefinedDefaultGroupSequenceException = "HV000054: %s must be part of the redefined default group sequence.";
/*      */   private static final String getWrongDefaultGroupSequenceProviderTypeException = "HV000055: The default group sequence provider defined for %s has the wrong type";
/*      */   private static final String getInvalidExecutableParameterIndexException = "HV000056: Method or constructor %1$s doesn't have a parameter with index %2$d.";
/*      */   private static final String getUnableToRetrieveAnnotationParameterValueException = "HV000059: Unable to retrieve annotation parameter value.";
/*      */   private static final String getInvalidLengthOfParameterMetaDataListException = "HV000062: Method or constructor %1$s has %2$s parameters, but the passed list of parameter meta data has a size of %3$s.";
/*      */   private static final String getUnableToInstantiateException1 = "HV000063: Unable to instantiate %s.";
/*      */   private static final String getUnableToInstantiateException2 = "HV000064: Unable to instantiate %1$s: %2$s.";
/*      */   private static final String getUnableToLoadClassException = "HV000065: Unable to load class: %s.";
/*      */   private static final String getStartIndexCannotBeNegativeException = "HV000068: Start index cannot be negative: %d.";
/*      */   private static final String getEndIndexCannotBeNegativeException = "HV000069: End index cannot be negative: %d.";
/*      */   private static final String getInvalidRangeException = "HV000070: Invalid Range: %1$d > %2$d.";
/*      */   private static final String getInvalidCheckDigitException = "HV000071: A explicitly specified check digit must lie outside the interval: [%1$d, %2$d].";
/*      */   private static final String getCharacterIsNotADigitException = "HV000072: '%c' is not a digit.";
/*      */   private static final String getConstraintParametersCannotStartWithValidException = "HV000073: Parameters starting with 'valid' are not allowed in a constraint.";
/*      */   private static final String getConstraintWithoutMandatoryParameterException = "HV000074: %2$s contains Constraint annotation, but does not contain a %1$s parameter.";
/*      */   private static final String getWrongDefaultValueForPayloadParameterException = "HV000075: %s contains Constraint annotation, but the payload parameter default value is not the empty array.";
/*      */   private static final String getWrongTypeForPayloadParameterException = "HV000076: %s contains Constraint annotation, but the payload parameter is of wrong type.";
/*      */   private static final String getWrongDefaultValueForGroupsParameterException = "HV000077: %s contains Constraint annotation, but the groups parameter default value is not the empty array.";
/*      */   private static final String getWrongTypeForGroupsParameterException = "HV000078: %s contains Constraint annotation, but the groups parameter is of wrong type.";
/*      */   private static final String getWrongTypeForMessageParameterException = "HV000079: %s contains Constraint annotation, but the message parameter is not of type java.lang.String.";
/*      */   private static final String getOverriddenConstraintAttributeNotFoundException = "HV000080: Overridden constraint does not define an attribute with name %s.";
/*      */   private static final String getWrongAttributeTypeForOverriddenConstraintException = "HV000081: The overriding type of a composite constraint must be identical to the overridden one. Expected %1$s found %2$s.";
/*      */   private static final String getWrongParameterTypeException = "HV000082: Wrong parameter type. Expected: %1$s Actual: %2$s.";
/*      */   private static final String getUnableToFindAnnotationParameterException = "HV000083: The specified annotation defines no parameter '%s'.";
/*      */   private static final String getUnableToGetAnnotationParameterException = "HV000084: Unable to get '%1$s' from %2$s.";
/*      */   private static final String getNoValueProvidedForAnnotationParameterException = "HV000085: No value provided for parameter '%1$s' of annotation @%2$s.";
/*      */   private static final String getTryingToInstantiateAnnotationWithUnknownParametersException = "HV000086: Trying to instantiate %1$s with unknown parameter(s): %2$s.";
/*      */   private static final String getPropertyNameCannotBeNullOrEmptyException = "HV000087: Property name cannot be null or empty.";
/*      */   private static final String getElementTypeHasToBeFieldOrMethodException = "HV000088: Element type has to be FIELD or METHOD.";
/*      */   private static final String getMemberIsNeitherAFieldNorAMethodException = "HV000089: Member %s is neither a field nor a method.";
/*      */   private static final String getUnableToAccessMemberException = "HV000090: Unable to access %s.";
/*      */   private static final String getHasToBeAPrimitiveTypeException = "HV000091: %s has to be a primitive type.";
/*      */   private static final String getNullIsAnInvalidTypeForAConstraintValidatorException = "HV000093: null is an invalid type for a constraint validator.";
/*      */   private static final String getMissingActualTypeArgumentForTypeParameterException = "HV000094: Missing actual type argument for type parameter: %s.";
/*      */   private static final String getUnableToInstantiateConstraintFactoryClassException = "HV000095: Unable to instantiate constraint factory class %s.";
/*      */   private static final String getUnableToOpenInputStreamForMappingFileException = "HV000096: Unable to open input stream for mapping file %s.";
/*      */   private static final String getUnableToInstantiateMessageInterpolatorClassException = "HV000097: Unable to instantiate message interpolator class %s.";
/*      */   private static final String getUnableToInstantiateTraversableResolverClassException = "HV000098: Unable to instantiate traversable resolver class %s.";
/*      */   private static final String getUnableToInstantiateValidationProviderClassException = "HV000099: Unable to instantiate validation provider class %s.";
/*      */   private static final String getUnableToParseValidationXmlFileException = "HV000100: Unable to parse %s.";
/*      */   private static final String getIsNotAnAnnotationException = "HV000101: %s is not an annotation.";
/*      */   private static final String getIsNotAConstraintValidatorClassException = "HV000102: %s is not a constraint validator class.";
/*      */   private static final String getBeanClassHasAlreadyBeConfiguredInXmlException = "HV000103: %s is configured at least twice in xml.";
/*      */   private static final String getIsDefinedTwiceInMappingXmlForBeanException = "HV000104: %1$s is defined twice in mapping xml for bean %2$s.";
/*      */   private static final String getBeanDoesNotContainTheFieldException = "HV000105: %1$s does not contain the fieldType %2$s.";
/*      */   private static final String getBeanDoesNotContainThePropertyException = "HV000106: %1$s does not contain the property %2$s.";
/*      */   private static final String getAnnotationDoesNotContainAParameterException = "HV000107: Annotation of type %1$s does not contain a parameter %2$s.";
/*      */   private static final String getAttemptToSpecifyAnArrayWhereSingleValueIsExpectedException = "HV000108: Attempt to specify an array where single value is expected.";
/*      */   private static final String getUnexpectedParameterValueException = "HV000109: Unexpected parameter value.";
/*      */   private static final String getInvalidNumberFormatException = "HV000110: Invalid %s format.";
/*      */   private static final String getInvalidCharValueException = "HV000111: Invalid char value: %s.";
/*      */   private static final String getInvalidReturnTypeException = "HV000112: Invalid return type: %s. Should be a enumeration type.";
/*      */   private static final String getReservedParameterNamesException = "HV000113: %s, %s, %s are reserved parameter names.";
/*      */   private static final String getWrongPayloadClassException = "HV000114: Specified payload class %s does not implement javax.validation.Payload";
/*      */   private static final String getErrorParsingMappingFileException = "HV000115: Error parsing mapping file.";
/*      */   private static final String getIllegalArgumentException = "HV000116: %s";
/*      */   private static final String getUnableToNarrowNodeTypeException = "HV000118: Unable to cast %s (with element kind %s) to %s";
/*      */   private static final String usingParameterNameProvider = "HV000119: Using %s as parameter name provider.";
/*      */   private static final String getUnableToInstantiateParameterNameProviderClassException = "HV000120: Unable to instantiate parameter name provider class %s.";
/*      */   private static final String getUnableToDetermineSchemaVersionException = "HV000121: Unable to parse %s.";
/*      */   private static final String getUnsupportedSchemaVersionException = "HV000122: Unsupported schema version for %s: %s.";
/*      */   private static final String getMultipleGroupConversionsForSameSourceException = "HV000124: Found multiple group conversions for source group %s: %s.";
/*      */   private static final String getGroupConversionOnNonCascadingElementException = "HV000125: Found group conversions for non-cascading element: %s.";
/*      */   private static final String getGroupConversionForSequenceException = "HV000127: Found group conversion using a group sequence as source: %s.";
/*      */   private static final String unknownPropertyInExpressionLanguage = "HV000129: EL expression '%s' references an unknown property";
/*      */   private static final String errorInExpressionLanguage = "HV000130: Error in EL expression '%s'";
/*      */   private static final String getMethodReturnValueMustNotBeMarkedMoreThanOnceForCascadedValidationException = "HV000131: A method return value must not be marked for cascaded validation more than once in a class hierarchy, but the following two methods are marked as such: %s, %s.";
/*      */   private static final String getVoidMethodsMustNotBeConstrainedException = "HV000132: Void methods must not be constrained or marked for cascaded validation, but method %s is.";
/*      */   private static final String getBeanDoesNotContainConstructorException = "HV000133: %1$s does not contain a constructor with the parameter types %2$s.";
/*      */   private static final String getInvalidParameterTypeException = "HV000134: Unable to load parameter of type '%1$s' in %2$s.";
/*      */   private static final String getBeanDoesNotContainMethodException = "HV000135: %1$s does not contain a method with the name '%2$s' and parameter types %3$s.";
/*      */   private static final String getUnableToLoadConstraintAnnotationClassException = "HV000136: The specified constraint annotation class %1$s cannot be loaded.";
/*      */   private static final String getMethodIsDefinedTwiceInMappingXmlForBeanException = "HV000137: The method '%1$s' is defined twice in the mapping xml for bean %2$s.";
/*      */   private static final String getConstructorIsDefinedTwiceInMappingXmlForBeanException = "HV000138: The constructor '%1$s' is defined twice in the mapping xml for bean %2$s.";
/*      */   private static final String getMultipleCrossParameterValidatorClassesException = "HV000139: The constraint '%1$s' defines multiple cross parameter validators. Only one is allowed.";
/*      */   private static final String getImplicitConstraintTargetInAmbiguousConfigurationException = "HV000141: The constraint %1$s used ConstraintTarget#IMPLICIT where the target cannot be inferred.";
/*      */   private static final String getCrossParameterConstraintOnMethodWithoutParametersException = "HV000142: Cross parameter constraint %1$s is illegally placed on a parameterless method or constructor '%2$s'.";
/*      */   private static final String getCrossParameterConstraintOnClassException = "HV000143: Cross parameter constraint %1$s is illegally placed on class level.";
/*      */   private static final String getCrossParameterConstraintOnFieldException = "HV000144: Cross parameter constraint %1$s is illegally placed on field '%2$s'.";
/*      */   private static final String getParameterNodeAddedForNonCrossParameterConstraintException = "HV000146: No parameter nodes may be added since path %s doesn't refer to a cross-parameter constraint.";
/*      */   private static final String getConstrainedElementConfiguredMultipleTimesException = "HV000147: %1$s is configured multiple times (note, <getter> and <method> nodes for the same method are not allowed)";
/*      */   private static final String evaluatingExpressionLanguageExpressionCausedException = "HV000148: An exception occurred during evaluation of EL expression '%s'";
/*      */   private static final String getExceptionOccurredDuringMessageInterpolationException = "HV000149: An exception occurred during message interpolation";
/*      */   private static final String getMultipleValidatorsForSameTypeException = "HV000150: The constraint '%s' defines multiple validators for the type '%s'. Only one is allowed.";
/*      */   private static final String getParameterConfigurationAlteredInSubTypeException = "HV000151: A method overriding another method must not alter the parameter constraint configuration, but method %2$s changes the configuration of %1$s.";
/*      */   private static final String getParameterConstraintsDefinedInMethodsFromParallelTypesException = "HV000152: Two methods defined in parallel types must not declare parameter constraints, if they are overridden by the same method, but methods %s and %s both define parameter constraints.";
/*      */   private static final String getParametersOrReturnValueConstraintTargetGivenAtNonExecutableException = "HV000153: The constraint %1$s used ConstraintTarget#%2$s but is not specified on a method or constructor.";
/*      */   private static final String getCrossParameterConstraintHasNoValidatorException = "HV000154: Cross parameter constraint %1$s has no cross-parameter validator.";
/*      */   private static final String getComposedAndComposingConstraintsHaveDifferentTypesException = "HV000155: Composed and composing constraints must have the same constraint type, but composed constraint %1$s has type %3$s, while composing constraint %2$s has type %4$s.";
/*      */   private static final String getGenericAndCrossParameterConstraintDoesNotDefineValidationAppliesToParameterException = "HV000156: Constraints with generic as well as cross-parameter validators must define an attribute validationAppliesTo(), but constraint %s doesn't.";
/*      */   private static final String getValidationAppliesToParameterMustHaveReturnTypeConstraintTargetException = "HV000157: Return type of the attribute validationAppliesTo() of the constraint %s must be javax.validation.ConstraintTarget.";
/*      */   private static final String getValidationAppliesToParameterMustHaveDefaultValueImplicitException = "HV000158: Default value of the attribute validationAppliesTo() of the constraint %s must be ConstraintTarget#IMPLICIT.";
/*      */   private static final String getValidationAppliesToParameterMustNotBeDefinedForNonGenericAndCrossParameterConstraintException = "HV000159: Only constraints with generic as well as cross-parameter validators must define an attribute validationAppliesTo(), but constraint %s does.";
/*      */   private static final String getValidatorForCrossParameterConstraintMustEitherValidateObjectOrObjectArrayException = "HV000160: Validator for cross-parameter constraint %s does not validate Object nor Object[].";
/*      */   private static final String getMethodsFromParallelTypesMustNotDefineGroupConversionsForCascadedReturnValueException = "HV000161: Two methods defined in parallel types must not define group conversions for a cascaded method return value, if they are overridden by the same method, but methods %s and %s both define parameter constraints.";
/*      */   private static final String getMethodOrConstructorNotDefinedByValidatedTypeException = "HV000162: The validated type %1$s does not specify the constructor/method: %2$s";
/*      */   private static final String getParameterTypesDoNotMatchException = "HV000163: The actual parameter type '%1$s' is not assignable to the expected one '%2$s' for parameter %3$d of '%4$s'";
/*      */   private static final String getHasToBeABoxedTypeException = "HV000164: %s has to be a auto-boxed type.";
/*      */   private static final String getMixingImplicitWithOtherExecutableTypesException = "HV000165: Mixing IMPLICIT and other executable types is not allowed.";
/*      */   private static final String getValidateOnExecutionOnOverriddenOrInterfaceMethodException = "HV000166: @ValidateOnExecution is not allowed on methods overriding a superclass method or implementing an interface. Check configuration for %1$s";
/*      */   private static final String getOverridingConstraintDefinitionsInMultipleMappingFilesException = "HV000167: A given constraint definition can only be overridden in one mapping file. %1$s is overridden in multiple files";
/*      */   private static final String getNonTerminatedParameterException = "HV000168: The message descriptor '%1$s' contains an unbalanced meta character '%2$c' parameter.";
/*      */   private static final String getNestedParameterException = "HV000169: The message descriptor '%1$s' has nested parameters.";
/*      */   private static final String getCreationOfScriptExecutorFailedException = "HV000170: No JSR-223 scripting engine could be bootstrapped for language \"%s\".";
/*      */   private static final String getBeanClassHasAlreadyBeConfiguredViaProgrammaticApiException = "HV000171: %s is configured more than once via the programmatic constraint declaration API.";
/*      */   private static final String getPropertyHasAlreadyBeConfiguredViaProgrammaticApiException = "HV000172: Property \"%2$s\" of type %1$s is configured more than once via the programmatic constraint declaration API.";
/*      */   private static final String getMethodHasAlreadyBeConfiguredViaProgrammaticApiException = "HV000173: Method %2$s of type %1$s is configured more than once via the programmatic constraint declaration API.";
/*      */   private static final String getParameterHasAlreadyBeConfiguredViaProgrammaticApiException = "HV000174: Parameter %3$s of method or constructor %2$s of type %1$s is configured more than once via the programmatic constraint declaration API.";
/*      */   private static final String getReturnValueHasAlreadyBeConfiguredViaProgrammaticApiException = "HV000175: The return value of method or constructor %2$s of type %1$s is configured more than once via the programmatic constraint declaration API.";
/*      */   private static final String getConstructorHasAlreadyBeConfiguredViaProgrammaticApiException = "HV000176: Constructor %2$s of type %1$s is configured more than once via the programmatic constraint declaration API.";
/*      */   private static final String getCrossParameterElementHasAlreadyBeConfiguredViaProgrammaticApiException = "HV000177: Cross-parameter constraints for the method or constructor %2$s of type %1$s are declared more than once via the programmatic constraint declaration API.";
/*      */   private static final String getMultiplierCannotBeNegativeException = "HV000178: Multiplier cannot be negative: %d.";
/*      */   private static final String getWeightCannotBeNegativeException = "HV000179: Weight cannot be negative: %d.";
/*      */   private static final String getTreatCheckAsIsNotADigitNorALetterException = "HV000180: '%c' is not a digit nor a letter.";
/*      */   private static final String getInvalidParameterCountForExecutableException = "HV000181: Wrong number of parameters. Method or constructor %1$s expects %2$d parameters, but got %3$d.";
/*      */   private static final String getNoUnwrapperFoundForTypeException = "HV000182: No validation value unwrapper is registered for type '%1$s'.";
/*      */   private static final String getMissingELDependenciesException = "HV000183: Unable to load 'javax.el.ExpressionFactory'. Check that you have the EL dependencies on the classpath, or use ParameterMessageInterpolator instead";
/*      */   private static final String creationOfParameterMessageInterpolation = "HV000184: ParameterMessageInterpolator has been chosen, EL interpolation will not be supported";
/*      */   private static final String getElUnsupported = "HV000185: Message contains EL expression: %1s, which is unsupported with chosen Interpolator";
/*      */   private static final String getConstraintValidatorExistsForWrapperAndWrappedValueException = "HV000186: The constraint of type '%2$s' defined on '%1$s' has multiple matching constraint validators which is due to an additional value handler of type '%3$s'. It is unclear which value needs validating. Clarify configuration via @UnwrapValidatedValue.";
/*      */   private static final String getTypeAnnotationConstraintOnIterableRequiresUseOfValidAnnotationException = "HV000187: When using type annotation constraints on parameterized iterables or map @Valid must be used. Check %s#%s";
/*      */   private static final String parameterizedTypeWithMoreThanOneTypeArgumentIsNotSupported = "HV000188: Parameterized type with more than one argument is not supported: %s";
/*      */   private static final String getInconsistentValueUnwrappingConfigurationBetweenFieldAndItsGetterException = "HV000189: The configuration of value unwrapping for property '%s' of bean '%s' is inconsistent between the field and its getter.";
/*      */   private static final String getUnableToCreateXMLEventReader = "HV000190: Unable to parse %s.";
/*      */   private static final String validatedValueUnwrapperCannotBeCreated = "HV000191: Error creating unwrapper: %s";
/*      */   private static final String unknownJvmVersion = "HV000192: Couldn't determine Java version from value %1s; Not enabling features requiring Java 8";
/*      */   
/*      */   public Log_$logger(Logger log) {
/*  208 */     super(log);
/*      */   }
/*      */   
/*      */   public final void version(String version) {
/*  212 */     this.log.logf(FQCN, Logger.Level.INFO, null, version$str(), version);
/*      */   }
/*      */   
/*      */   protected String version$str() {
/*  216 */     return "HV000001: Hibernate Validator %s";
/*      */   }
/*      */   
/*      */   public final void ignoringXmlConfiguration() {
/*  220 */     this.log.logf(FQCN, Logger.Level.INFO, null, ignoringXmlConfiguration$str(), new Object[0]);
/*      */   }
/*      */   
/*      */   protected String ignoringXmlConfiguration$str() {
/*  224 */     return "HV000002: Ignoring XML configuration.";
/*      */   }
/*      */   
/*      */   public final void usingConstraintFactory(String constraintFactoryClassName) {
/*  228 */     this.log.logf(FQCN, Logger.Level.INFO, null, usingConstraintFactory$str(), constraintFactoryClassName);
/*      */   }
/*      */   
/*      */   protected String usingConstraintFactory$str() {
/*  232 */     return "HV000003: Using %s as constraint factory.";
/*      */   }
/*      */   
/*      */   public final void usingMessageInterpolator(String messageInterpolatorClassName) {
/*  236 */     this.log.logf(FQCN, Logger.Level.INFO, null, usingMessageInterpolator$str(), messageInterpolatorClassName);
/*      */   }
/*      */   
/*      */   protected String usingMessageInterpolator$str() {
/*  240 */     return "HV000004: Using %s as message interpolator.";
/*      */   }
/*      */   
/*      */   public final void usingTraversableResolver(String traversableResolverClassName) {
/*  244 */     this.log.logf(FQCN, Logger.Level.INFO, null, usingTraversableResolver$str(), traversableResolverClassName);
/*      */   }
/*      */   
/*      */   protected String usingTraversableResolver$str() {
/*  248 */     return "HV000005: Using %s as traversable resolver.";
/*      */   }
/*      */   
/*      */   public final void usingValidationProvider(String validationProviderClassName) {
/*  252 */     this.log.logf(FQCN, Logger.Level.INFO, null, usingValidationProvider$str(), validationProviderClassName);
/*      */   }
/*      */   
/*      */   protected String usingValidationProvider$str() {
/*  256 */     return "HV000006: Using %s as validation provider.";
/*      */   }
/*      */   
/*      */   public final void parsingXMLFile(String fileName) {
/*  260 */     this.log.logf(FQCN, Logger.Level.INFO, null, parsingXMLFile$str(), fileName);
/*      */   }
/*      */   
/*      */   protected String parsingXMLFile$str() {
/*  264 */     return "HV000007: %s found. Parsing XML based configuration.";
/*      */   }
/*      */   
/*      */   public final void unableToCloseInputStream() {
/*  268 */     this.log.logf(FQCN, Logger.Level.WARN, null, unableToCloseInputStream$str(), new Object[0]);
/*      */   }
/*      */   
/*      */   protected String unableToCloseInputStream$str() {
/*  272 */     return "HV000008: Unable to close input stream.";
/*      */   }
/*      */   
/*      */   public final void unableToCloseXMLFileInputStream(String fileName) {
/*  276 */     this.log.logf(FQCN, Logger.Level.WARN, null, unableToCloseXMLFileInputStream$str(), fileName);
/*      */   }
/*      */   
/*      */   protected String unableToCloseXMLFileInputStream$str() {
/*  280 */     return "HV000010: Unable to close input stream for %s.";
/*      */   }
/*      */   
/*      */   public final void unableToCreateSchema(String fileName, String message) {
/*  284 */     this.log.logf(FQCN, Logger.Level.WARN, null, unableToCreateSchema$str(), fileName, message);
/*      */   }
/*      */   
/*      */   protected String unableToCreateSchema$str() {
/*  288 */     return "HV000011: Unable to create schema for %1$s: %2$s";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToCreateAnnotationForConfiguredConstraintException(RuntimeException e) {
/*  292 */     ValidationException result = new ValidationException(String.format(getUnableToCreateAnnotationForConfiguredConstraintException$str(), new Object[0]), e);
/*  293 */     StackTraceElement[] st = result.getStackTrace();
/*  294 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  295 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToCreateAnnotationForConfiguredConstraintException$str() {
/*  299 */     return "HV000012: Unable to create annotation for configured constraint";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToFindPropertyWithAccessException(Class beanClass, String property, ElementType elementType) {
/*  303 */     ValidationException result = new ValidationException(String.format(getUnableToFindPropertyWithAccessException$str(), new Object[] { beanClass, property, elementType }));
/*  304 */     StackTraceElement[] st = result.getStackTrace();
/*  305 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  306 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToFindPropertyWithAccessException$str() {
/*  310 */     return "HV000013: The class %1$s does not have a property '%2$s' with access %3$s.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getUnableToFindMethodException(Class beanClass, String method) {
/*  314 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getUnableToFindMethodException$str(), new Object[] { beanClass, method }));
/*  315 */     StackTraceElement[] st = result.getStackTrace();
/*  316 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  317 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToFindMethodException$str() {
/*  321 */     return "HV000014: Type %1$s doesn't have a method %2$s.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getInvalidBigDecimalFormatException(String value, NumberFormatException e) {
/*  325 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getInvalidBigDecimalFormatException$str(), new Object[] { value }), e);
/*  326 */     StackTraceElement[] st = result.getStackTrace();
/*  327 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  328 */     return result;
/*      */   }
/*      */   
/*      */   protected String getInvalidBigDecimalFormatException$str() {
/*  332 */     return "HV000016: %s does not represent a valid BigDecimal format.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getInvalidLengthForIntegerPartException() {
/*  336 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getInvalidLengthForIntegerPartException$str(), new Object[0]));
/*  337 */     StackTraceElement[] st = result.getStackTrace();
/*  338 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  339 */     return result;
/*      */   }
/*      */   
/*      */   protected String getInvalidLengthForIntegerPartException$str() {
/*  343 */     return "HV000017: The length of the integer part cannot be negative.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getInvalidLengthForFractionPartException() {
/*  347 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getInvalidLengthForFractionPartException$str(), new Object[0]));
/*  348 */     StackTraceElement[] st = result.getStackTrace();
/*  349 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  350 */     return result;
/*      */   }
/*      */   
/*      */   protected String getInvalidLengthForFractionPartException$str() {
/*  354 */     return "HV000018: The length of the fraction part cannot be negative.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getMinCannotBeNegativeException() {
/*  358 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getMinCannotBeNegativeException$str(), new Object[0]));
/*  359 */     StackTraceElement[] st = result.getStackTrace();
/*  360 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  361 */     return result;
/*      */   }
/*      */   
/*      */   protected String getMinCannotBeNegativeException$str() {
/*  365 */     return "HV000019: The min parameter cannot be negative.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getMaxCannotBeNegativeException() {
/*  369 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getMaxCannotBeNegativeException$str(), new Object[0]));
/*  370 */     StackTraceElement[] st = result.getStackTrace();
/*  371 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  372 */     return result;
/*      */   }
/*      */   
/*      */   protected String getMaxCannotBeNegativeException$str() {
/*  376 */     return "HV000020: The max parameter cannot be negative.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getLengthCannotBeNegativeException() {
/*  380 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getLengthCannotBeNegativeException$str(), new Object[0]));
/*  381 */     StackTraceElement[] st = result.getStackTrace();
/*  382 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  383 */     return result;
/*      */   }
/*      */   
/*      */   protected String getLengthCannotBeNegativeException$str() {
/*  387 */     return "HV000021: The length cannot be negative.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getInvalidRegularExpressionException(PatternSyntaxException e) {
/*  391 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getInvalidRegularExpressionException$str(), new Object[0]), e);
/*  392 */     StackTraceElement[] st = result.getStackTrace();
/*  393 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  394 */     return result;
/*      */   }
/*      */   
/*      */   protected String getInvalidRegularExpressionException$str() {
/*  398 */     return "HV000022: Invalid regular expression.";
/*      */   }
/*      */   
/*      */   public final ConstraintDeclarationException getErrorDuringScriptExecutionException(String script, Exception e) {
/*  402 */     ConstraintDeclarationException result = new ConstraintDeclarationException(String.format(getErrorDuringScriptExecutionException$str(), new Object[] { script }), e);
/*  403 */     StackTraceElement[] st = result.getStackTrace();
/*  404 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  405 */     return result;
/*      */   }
/*      */   
/*      */   protected String getErrorDuringScriptExecutionException$str() {
/*  409 */     return "HV000023: Error during execution of script \"%s\" occurred.";
/*      */   }
/*      */   
/*      */   public final ConstraintDeclarationException getScriptMustReturnTrueOrFalseException(String script) {
/*  413 */     ConstraintDeclarationException result = new ConstraintDeclarationException(String.format(getScriptMustReturnTrueOrFalseException1$str(), new Object[] { script }));
/*  414 */     StackTraceElement[] st = result.getStackTrace();
/*  415 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  416 */     return result;
/*      */   }
/*      */   
/*      */   protected String getScriptMustReturnTrueOrFalseException1$str() {
/*  420 */     return "HV000024: Script \"%s\" returned null, but must return either true or false.";
/*      */   }
/*      */   
/*      */   public final ConstraintDeclarationException getScriptMustReturnTrueOrFalseException(String script, Object executionResult, String type) {
/*  424 */     ConstraintDeclarationException result = new ConstraintDeclarationException(String.format(getScriptMustReturnTrueOrFalseException3$str(), new Object[] { script, executionResult, type }));
/*  425 */     StackTraceElement[] st = result.getStackTrace();
/*  426 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  427 */     return result;
/*      */   }
/*      */   
/*      */   protected String getScriptMustReturnTrueOrFalseException3$str() {
/*  431 */     return "HV000025: Script \"%1$s\" returned %2$s (of type %3$s), but must return either true or false.";
/*      */   }
/*      */   
/*      */   public final ValidationException getInconsistentConfigurationException() {
/*  435 */     ValidationException result = new ValidationException(String.format(getInconsistentConfigurationException$str(), new Object[0]));
/*  436 */     StackTraceElement[] st = result.getStackTrace();
/*  437 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  438 */     return result;
/*      */   }
/*      */   
/*      */   protected String getInconsistentConfigurationException$str() {
/*  442 */     return "HV000026: Assertion error: inconsistent ConfigurationImpl construction.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToFindProviderException(Class providerClass) {
/*  446 */     ValidationException result = new ValidationException(String.format(getUnableToFindProviderException$str(), new Object[] { providerClass }));
/*  447 */     StackTraceElement[] st = result.getStackTrace();
/*  448 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  449 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToFindProviderException$str() {
/*  453 */     return "HV000027: Unable to find provider: %s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getExceptionDuringIsValidCallException(RuntimeException e) {
/*  457 */     ValidationException result = new ValidationException(String.format(getExceptionDuringIsValidCallException$str(), new Object[0]), e);
/*  458 */     StackTraceElement[] st = result.getStackTrace();
/*  459 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  460 */     return result;
/*      */   }
/*      */   
/*      */   protected String getExceptionDuringIsValidCallException$str() {
/*  464 */     return "HV000028: Unexpected exception during isValid call.";
/*      */   }
/*      */   
/*      */   public final ValidationException getConstraintFactoryMustNotReturnNullException(String validatorClassName) {
/*  468 */     ValidationException result = new ValidationException(String.format(getConstraintFactoryMustNotReturnNullException$str(), new Object[] { validatorClassName }));
/*  469 */     StackTraceElement[] st = result.getStackTrace();
/*  470 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  471 */     return result;
/*      */   }
/*      */   
/*      */   protected String getConstraintFactoryMustNotReturnNullException$str() {
/*  475 */     return "HV000029: Constraint factory returned null when trying to create instance of %s.";
/*      */   }
/*      */   
/*      */   public final UnexpectedTypeException getNoValidatorFoundForTypeException(String constraintType, String validatedValueType, String path) {
/*  479 */     UnexpectedTypeException result = new UnexpectedTypeException(String.format(getNoValidatorFoundForTypeException$str(), new Object[] { constraintType, validatedValueType, path }));
/*  480 */     StackTraceElement[] st = result.getStackTrace();
/*  481 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  482 */     return result;
/*      */   }
/*      */   
/*      */   protected String getNoValidatorFoundForTypeException$str() {
/*  486 */     return "HV000030: No validator could be found for constraint '%s' validating type '%s'. Check configuration for '%s'";
/*      */   }
/*      */   
/*      */   public final UnexpectedTypeException getMoreThanOneValidatorFoundForTypeException(Type type, String validatorClasses) {
/*  490 */     UnexpectedTypeException result = new UnexpectedTypeException(String.format(getMoreThanOneValidatorFoundForTypeException$str(), new Object[] { type, validatorClasses }));
/*  491 */     StackTraceElement[] st = result.getStackTrace();
/*  492 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  493 */     return result;
/*      */   }
/*      */   
/*      */   protected String getMoreThanOneValidatorFoundForTypeException$str() {
/*  497 */     return "HV000031: There are multiple validator classes which could validate the type %1$s. The validator classes are: %2$s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToInitializeConstraintValidatorException(String validatorClassName, RuntimeException e) {
/*  501 */     ValidationException result = new ValidationException(String.format(getUnableToInitializeConstraintValidatorException$str(), new Object[] { validatorClassName }), e);
/*  502 */     StackTraceElement[] st = result.getStackTrace();
/*  503 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  504 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToInitializeConstraintValidatorException$str() {
/*  508 */     return "HV000032: Unable to initialize %s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getAtLeastOneCustomMessageMustBeCreatedException() {
/*  512 */     ValidationException result = new ValidationException(String.format(getAtLeastOneCustomMessageMustBeCreatedException$str(), new Object[0]));
/*  513 */     StackTraceElement[] st = result.getStackTrace();
/*  514 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  515 */     return result;
/*      */   }
/*      */   
/*      */   protected String getAtLeastOneCustomMessageMustBeCreatedException$str() {
/*  519 */     return "HV000033: At least one custom message must be created if the default error message gets disabled.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getInvalidJavaIdentifierException(String identifier) {
/*  523 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getInvalidJavaIdentifierException$str(), new Object[] { identifier }));
/*  524 */     StackTraceElement[] st = result.getStackTrace();
/*  525 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  526 */     return result;
/*      */   }
/*      */   
/*      */   protected String getInvalidJavaIdentifierException$str() {
/*  530 */     return "HV000034: %s is not a valid Java Identifier.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getUnableToParsePropertyPathException(String propertyPath) {
/*  534 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getUnableToParsePropertyPathException$str(), new Object[] { propertyPath }));
/*  535 */     StackTraceElement[] st = result.getStackTrace();
/*  536 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  537 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToParsePropertyPathException$str() {
/*  541 */     return "HV000035: Unable to parse property path %s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getTypeNotSupportedForUnwrappingException(Class type) {
/*  545 */     ValidationException result = new ValidationException(String.format(getTypeNotSupportedForUnwrappingException$str(), new Object[] { type }));
/*  546 */     StackTraceElement[] st = result.getStackTrace();
/*  547 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  548 */     return result;
/*      */   }
/*      */   
/*      */   protected String getTypeNotSupportedForUnwrappingException$str() {
/*  552 */     return "HV000036: Type %s not supported for unwrapping.";
/*      */   }
/*      */   
/*      */   public final ValidationException getInconsistentFailFastConfigurationException() {
/*  556 */     ValidationException result = new ValidationException(String.format(getInconsistentFailFastConfigurationException$str(), new Object[0]));
/*  557 */     StackTraceElement[] st = result.getStackTrace();
/*  558 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  559 */     return result;
/*      */   }
/*      */   
/*      */   protected String getInconsistentFailFastConfigurationException$str() {
/*  563 */     return "HV000037: Inconsistent fail fast configuration. Fail fast enabled via programmatic API, but explicitly disabled via properties.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getInvalidPropertyPathException() {
/*  567 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getInvalidPropertyPathException0$str(), new Object[0]));
/*  568 */     StackTraceElement[] st = result.getStackTrace();
/*  569 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  570 */     return result;
/*      */   }
/*      */   
/*      */   protected String getInvalidPropertyPathException0$str() {
/*  574 */     return "HV000038: Invalid property path.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getInvalidPropertyPathException(String propertyName, String beanClassName) {
/*  578 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getInvalidPropertyPathException2$str(), new Object[] { propertyName, beanClassName }));
/*  579 */     StackTraceElement[] st = result.getStackTrace();
/*  580 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  581 */     return result;
/*      */   }
/*      */   
/*      */   protected String getInvalidPropertyPathException2$str() {
/*  585 */     return "HV000039: Invalid property path. There is no property %1$s in entity %2$s.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getPropertyPathMustProvideIndexOrMapKeyException() {
/*  589 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getPropertyPathMustProvideIndexOrMapKeyException$str(), new Object[0]));
/*  590 */     StackTraceElement[] st = result.getStackTrace();
/*  591 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  592 */     return result;
/*      */   }
/*      */   
/*      */   protected String getPropertyPathMustProvideIndexOrMapKeyException$str() {
/*  596 */     return "HV000040: Property path must provide index or map key.";
/*      */   }
/*      */   
/*      */   public final ValidationException getErrorDuringCallOfTraversableResolverIsReachableException(RuntimeException e) {
/*  600 */     ValidationException result = new ValidationException(String.format(getErrorDuringCallOfTraversableResolverIsReachableException$str(), new Object[0]), e);
/*  601 */     StackTraceElement[] st = result.getStackTrace();
/*  602 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  603 */     return result;
/*      */   }
/*      */   
/*      */   protected String getErrorDuringCallOfTraversableResolverIsReachableException$str() {
/*  607 */     return "HV000041: Call to TraversableResolver.isReachable() threw an exception.";
/*      */   }
/*      */   
/*      */   public final ValidationException getErrorDuringCallOfTraversableResolverIsCascadableException(RuntimeException e) {
/*  611 */     ValidationException result = new ValidationException(String.format(getErrorDuringCallOfTraversableResolverIsCascadableException$str(), new Object[0]), e);
/*  612 */     StackTraceElement[] st = result.getStackTrace();
/*  613 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  614 */     return result;
/*      */   }
/*      */   
/*      */   protected String getErrorDuringCallOfTraversableResolverIsCascadableException$str() {
/*  618 */     return "HV000042: Call to TraversableResolver.isCascadable() threw an exception.";
/*      */   }
/*      */   
/*      */   public final GroupDefinitionException getUnableToExpandDefaultGroupListException(List defaultGroupList, List groupList) {
/*  622 */     GroupDefinitionException result = new GroupDefinitionException(String.format(getUnableToExpandDefaultGroupListException$str(), new Object[] { defaultGroupList, groupList }));
/*  623 */     StackTraceElement[] st = result.getStackTrace();
/*  624 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  625 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToExpandDefaultGroupListException$str() {
/*  629 */     return "HV000043: Unable to expand default group list %1$s into sequence %2$s.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getAtLeastOneGroupHasToBeSpecifiedException() {
/*  633 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getAtLeastOneGroupHasToBeSpecifiedException$str(), new Object[0]));
/*  634 */     StackTraceElement[] st = result.getStackTrace();
/*  635 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  636 */     return result;
/*      */   }
/*      */   
/*      */   protected String getAtLeastOneGroupHasToBeSpecifiedException$str() {
/*  640 */     return "HV000044: At least one group has to be specified.";
/*      */   }
/*      */   
/*      */   public final ValidationException getGroupHasToBeAnInterfaceException(String className) {
/*  644 */     ValidationException result = new ValidationException(String.format(getGroupHasToBeAnInterfaceException$str(), new Object[] { className }));
/*  645 */     StackTraceElement[] st = result.getStackTrace();
/*  646 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  647 */     return result;
/*      */   }
/*      */   
/*      */   protected String getGroupHasToBeAnInterfaceException$str() {
/*  651 */     return "HV000045: A group has to be an interface. %s is not.";
/*      */   }
/*      */   
/*      */   public final GroupDefinitionException getSequenceDefinitionsNotAllowedException() {
/*  655 */     GroupDefinitionException result = new GroupDefinitionException(String.format(getSequenceDefinitionsNotAllowedException$str(), new Object[0]));
/*  656 */     StackTraceElement[] st = result.getStackTrace();
/*  657 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  658 */     return result;
/*      */   }
/*      */   
/*      */   protected String getSequenceDefinitionsNotAllowedException$str() {
/*  662 */     return "HV000046: Sequence definitions are not allowed as composing parts of a sequence.";
/*      */   }
/*      */   
/*      */   public final GroupDefinitionException getCyclicDependencyInGroupsDefinitionException() {
/*  666 */     GroupDefinitionException result = new GroupDefinitionException(String.format(getCyclicDependencyInGroupsDefinitionException$str(), new Object[0]));
/*  667 */     StackTraceElement[] st = result.getStackTrace();
/*  668 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  669 */     return result;
/*      */   }
/*      */   
/*      */   protected String getCyclicDependencyInGroupsDefinitionException$str() {
/*  673 */     return "HV000047: Cyclic dependency in groups definition";
/*      */   }
/*      */   
/*      */   public final GroupDefinitionException getUnableToExpandGroupSequenceException() {
/*  677 */     GroupDefinitionException result = new GroupDefinitionException(String.format(getUnableToExpandGroupSequenceException$str(), new Object[0]));
/*  678 */     StackTraceElement[] st = result.getStackTrace();
/*  679 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  680 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToExpandGroupSequenceException$str() {
/*  684 */     return "HV000048: Unable to expand group sequence.";
/*      */   }
/*      */   
/*      */   public final GroupDefinitionException getInvalidDefaultGroupSequenceDefinitionException() {
/*  688 */     GroupDefinitionException result = new GroupDefinitionException(String.format(getInvalidDefaultGroupSequenceDefinitionException$str(), new Object[0]));
/*  689 */     StackTraceElement[] st = result.getStackTrace();
/*  690 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  691 */     return result;
/*      */   }
/*      */   
/*      */   protected String getInvalidDefaultGroupSequenceDefinitionException$str() {
/*  695 */     return "HV000052: Default group sequence and default group sequence provider cannot be defined at the same time.";
/*      */   }
/*      */   
/*      */   public final GroupDefinitionException getNoDefaultGroupInGroupSequenceException() {
/*  699 */     GroupDefinitionException result = new GroupDefinitionException(String.format(getNoDefaultGroupInGroupSequenceException$str(), new Object[0]));
/*  700 */     StackTraceElement[] st = result.getStackTrace();
/*  701 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  702 */     return result;
/*      */   }
/*      */   
/*      */   protected String getNoDefaultGroupInGroupSequenceException$str() {
/*  706 */     return "HV000053: 'Default.class' cannot appear in default group sequence list.";
/*      */   }
/*      */   
/*      */   public final GroupDefinitionException getBeanClassMustBePartOfRedefinedDefaultGroupSequenceException(String beanClassName) {
/*  710 */     GroupDefinitionException result = new GroupDefinitionException(String.format(getBeanClassMustBePartOfRedefinedDefaultGroupSequenceException$str(), new Object[] { beanClassName }));
/*  711 */     StackTraceElement[] st = result.getStackTrace();
/*  712 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  713 */     return result;
/*      */   }
/*      */   
/*      */   protected String getBeanClassMustBePartOfRedefinedDefaultGroupSequenceException$str() {
/*  717 */     return "HV000054: %s must be part of the redefined default group sequence.";
/*      */   }
/*      */   
/*      */   public final GroupDefinitionException getWrongDefaultGroupSequenceProviderTypeException(String beanClassName) {
/*  721 */     GroupDefinitionException result = new GroupDefinitionException(String.format(getWrongDefaultGroupSequenceProviderTypeException$str(), new Object[] { beanClassName }));
/*  722 */     StackTraceElement[] st = result.getStackTrace();
/*  723 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  724 */     return result;
/*      */   }
/*      */   
/*      */   protected String getWrongDefaultGroupSequenceProviderTypeException$str() {
/*  728 */     return "HV000055: The default group sequence provider defined for %s has the wrong type";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getInvalidExecutableParameterIndexException(String executable, int index) {
/*  732 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getInvalidExecutableParameterIndexException$str(), new Object[] { executable, Integer.valueOf(index) }));
/*  733 */     StackTraceElement[] st = result.getStackTrace();
/*  734 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  735 */     return result;
/*      */   }
/*      */   
/*      */   protected String getInvalidExecutableParameterIndexException$str() {
/*  739 */     return "HV000056: Method or constructor %1$s doesn't have a parameter with index %2$d.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToRetrieveAnnotationParameterValueException(Exception e) {
/*  743 */     ValidationException result = new ValidationException(String.format(getUnableToRetrieveAnnotationParameterValueException$str(), new Object[0]), e);
/*  744 */     StackTraceElement[] st = result.getStackTrace();
/*  745 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  746 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToRetrieveAnnotationParameterValueException$str() {
/*  750 */     return "HV000059: Unable to retrieve annotation parameter value.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getInvalidLengthOfParameterMetaDataListException(String executableName, int nbParameters, int listSize) {
/*  754 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getInvalidLengthOfParameterMetaDataListException$str(), new Object[] { executableName, Integer.valueOf(nbParameters), Integer.valueOf(listSize) }));
/*  755 */     StackTraceElement[] st = result.getStackTrace();
/*  756 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  757 */     return result;
/*      */   }
/*      */   
/*      */   protected String getInvalidLengthOfParameterMetaDataListException$str() {
/*  761 */     return "HV000062: Method or constructor %1$s has %2$s parameters, but the passed list of parameter meta data has a size of %3$s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToInstantiateException(String className, Exception e) {
/*  765 */     ValidationException result = new ValidationException(String.format(getUnableToInstantiateException1$str(), new Object[] { className }), e);
/*  766 */     StackTraceElement[] st = result.getStackTrace();
/*  767 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  768 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToInstantiateException1$str() {
/*  772 */     return "HV000063: Unable to instantiate %s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToInstantiateException(Class clazz, Exception e) {
/*  776 */     ValidationException result = new ValidationException(String.format(getUnableToInstantiateException1$str(), new Object[] { clazz }), e);
/*  777 */     StackTraceElement[] st = result.getStackTrace();
/*  778 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  779 */     return result;
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToInstantiateException(String message, Class clazz, Exception e) {
/*  783 */     ValidationException result = new ValidationException(String.format(getUnableToInstantiateException2$str(), new Object[] { message, clazz }), e);
/*  784 */     StackTraceElement[] st = result.getStackTrace();
/*  785 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  786 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToInstantiateException2$str() {
/*  790 */     return "HV000064: Unable to instantiate %1$s: %2$s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToLoadClassException(String className) {
/*  794 */     ValidationException result = new ValidationException(String.format(getUnableToLoadClassException$str(), new Object[] { className }));
/*  795 */     StackTraceElement[] st = result.getStackTrace();
/*  796 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  797 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToLoadClassException$str() {
/*  801 */     return "HV000065: Unable to load class: %s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToLoadClassException(String className, Exception e) {
/*  805 */     ValidationException result = new ValidationException(String.format(getUnableToLoadClassException$str(), new Object[] { className }), e);
/*  806 */     StackTraceElement[] st = result.getStackTrace();
/*  807 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  808 */     return result;
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getStartIndexCannotBeNegativeException(int startIndex) {
/*  812 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getStartIndexCannotBeNegativeException$str(), new Object[] { Integer.valueOf(startIndex) }));
/*  813 */     StackTraceElement[] st = result.getStackTrace();
/*  814 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  815 */     return result;
/*      */   }
/*      */   
/*      */   protected String getStartIndexCannotBeNegativeException$str() {
/*  819 */     return "HV000068: Start index cannot be negative: %d.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getEndIndexCannotBeNegativeException(int endIndex) {
/*  823 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getEndIndexCannotBeNegativeException$str(), new Object[] { Integer.valueOf(endIndex) }));
/*  824 */     StackTraceElement[] st = result.getStackTrace();
/*  825 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  826 */     return result;
/*      */   }
/*      */   
/*      */   protected String getEndIndexCannotBeNegativeException$str() {
/*  830 */     return "HV000069: End index cannot be negative: %d.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getInvalidRangeException(int startIndex, int endIndex) {
/*  834 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getInvalidRangeException$str(), new Object[] { Integer.valueOf(startIndex), Integer.valueOf(endIndex) }));
/*  835 */     StackTraceElement[] st = result.getStackTrace();
/*  836 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  837 */     return result;
/*      */   }
/*      */   
/*      */   protected String getInvalidRangeException$str() {
/*  841 */     return "HV000070: Invalid Range: %1$d > %2$d.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getInvalidCheckDigitException(int startIndex, int endIndex) {
/*  845 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getInvalidCheckDigitException$str(), new Object[] { Integer.valueOf(startIndex), Integer.valueOf(endIndex) }));
/*  846 */     StackTraceElement[] st = result.getStackTrace();
/*  847 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  848 */     return result;
/*      */   }
/*      */   
/*      */   protected String getInvalidCheckDigitException$str() {
/*  852 */     return "HV000071: A explicitly specified check digit must lie outside the interval: [%1$d, %2$d].";
/*      */   }
/*      */   
/*      */   public final NumberFormatException getCharacterIsNotADigitException(char c) {
/*  856 */     NumberFormatException result = new NumberFormatException(String.format(getCharacterIsNotADigitException$str(), new Object[] { Character.valueOf(c) }));
/*  857 */     StackTraceElement[] st = result.getStackTrace();
/*  858 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  859 */     return result;
/*      */   }
/*      */   
/*      */   protected String getCharacterIsNotADigitException$str() {
/*  863 */     return "HV000072: '%c' is not a digit.";
/*      */   }
/*      */   
/*      */   public final ConstraintDefinitionException getConstraintParametersCannotStartWithValidException() {
/*  867 */     ConstraintDefinitionException result = new ConstraintDefinitionException(String.format(getConstraintParametersCannotStartWithValidException$str(), new Object[0]));
/*  868 */     StackTraceElement[] st = result.getStackTrace();
/*  869 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  870 */     return result;
/*      */   }
/*      */   
/*      */   protected String getConstraintParametersCannotStartWithValidException$str() {
/*  874 */     return "HV000073: Parameters starting with 'valid' are not allowed in a constraint.";
/*      */   }
/*      */   
/*      */   public final ConstraintDefinitionException getConstraintWithoutMandatoryParameterException(String parameterName, String constraintName) {
/*  878 */     ConstraintDefinitionException result = new ConstraintDefinitionException(String.format(getConstraintWithoutMandatoryParameterException$str(), new Object[] { parameterName, constraintName }));
/*  879 */     StackTraceElement[] st = result.getStackTrace();
/*  880 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  881 */     return result;
/*      */   }
/*      */   
/*      */   protected String getConstraintWithoutMandatoryParameterException$str() {
/*  885 */     return "HV000074: %2$s contains Constraint annotation, but does not contain a %1$s parameter.";
/*      */   }
/*      */   
/*      */   public final ConstraintDefinitionException getWrongDefaultValueForPayloadParameterException(String constraintName) {
/*  889 */     ConstraintDefinitionException result = new ConstraintDefinitionException(String.format(getWrongDefaultValueForPayloadParameterException$str(), new Object[] { constraintName }));
/*  890 */     StackTraceElement[] st = result.getStackTrace();
/*  891 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  892 */     return result;
/*      */   }
/*      */   
/*      */   protected String getWrongDefaultValueForPayloadParameterException$str() {
/*  896 */     return "HV000075: %s contains Constraint annotation, but the payload parameter default value is not the empty array.";
/*      */   }
/*      */   
/*      */   public final ConstraintDefinitionException getWrongTypeForPayloadParameterException(String constraintName, ClassCastException e) {
/*  900 */     ConstraintDefinitionException result = new ConstraintDefinitionException(String.format(getWrongTypeForPayloadParameterException$str(), new Object[] { constraintName }), e);
/*  901 */     StackTraceElement[] st = result.getStackTrace();
/*  902 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  903 */     return result;
/*      */   }
/*      */   
/*      */   protected String getWrongTypeForPayloadParameterException$str() {
/*  907 */     return "HV000076: %s contains Constraint annotation, but the payload parameter is of wrong type.";
/*      */   }
/*      */   
/*      */   public final ConstraintDefinitionException getWrongDefaultValueForGroupsParameterException(String constraintName) {
/*  911 */     ConstraintDefinitionException result = new ConstraintDefinitionException(String.format(getWrongDefaultValueForGroupsParameterException$str(), new Object[] { constraintName }));
/*  912 */     StackTraceElement[] st = result.getStackTrace();
/*  913 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  914 */     return result;
/*      */   }
/*      */   
/*      */   protected String getWrongDefaultValueForGroupsParameterException$str() {
/*  918 */     return "HV000077: %s contains Constraint annotation, but the groups parameter default value is not the empty array.";
/*      */   }
/*      */   
/*      */   public final ConstraintDefinitionException getWrongTypeForGroupsParameterException(String constraintName, ClassCastException e) {
/*  922 */     ConstraintDefinitionException result = new ConstraintDefinitionException(String.format(getWrongTypeForGroupsParameterException$str(), new Object[] { constraintName }), e);
/*  923 */     StackTraceElement[] st = result.getStackTrace();
/*  924 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  925 */     return result;
/*      */   }
/*      */   
/*      */   protected String getWrongTypeForGroupsParameterException$str() {
/*  929 */     return "HV000078: %s contains Constraint annotation, but the groups parameter is of wrong type.";
/*      */   }
/*      */   
/*      */   public final ConstraintDefinitionException getWrongTypeForMessageParameterException(String constraintName) {
/*  933 */     ConstraintDefinitionException result = new ConstraintDefinitionException(String.format(getWrongTypeForMessageParameterException$str(), new Object[] { constraintName }));
/*  934 */     StackTraceElement[] st = result.getStackTrace();
/*  935 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  936 */     return result;
/*      */   }
/*      */   
/*      */   protected String getWrongTypeForMessageParameterException$str() {
/*  940 */     return "HV000079: %s contains Constraint annotation, but the message parameter is not of type java.lang.String.";
/*      */   }
/*      */   
/*      */   public final ConstraintDefinitionException getOverriddenConstraintAttributeNotFoundException(String attributeName) {
/*  944 */     ConstraintDefinitionException result = new ConstraintDefinitionException(String.format(getOverriddenConstraintAttributeNotFoundException$str(), new Object[] { attributeName }));
/*  945 */     StackTraceElement[] st = result.getStackTrace();
/*  946 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  947 */     return result;
/*      */   }
/*      */   
/*      */   protected String getOverriddenConstraintAttributeNotFoundException$str() {
/*  951 */     return "HV000080: Overridden constraint does not define an attribute with name %s.";
/*      */   }
/*      */   
/*      */   public final ConstraintDefinitionException getWrongAttributeTypeForOverriddenConstraintException(String expectedReturnType, Class currentReturnType) {
/*  955 */     ConstraintDefinitionException result = new ConstraintDefinitionException(String.format(getWrongAttributeTypeForOverriddenConstraintException$str(), new Object[] { expectedReturnType, currentReturnType }));
/*  956 */     StackTraceElement[] st = result.getStackTrace();
/*  957 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  958 */     return result;
/*      */   }
/*      */   
/*      */   protected String getWrongAttributeTypeForOverriddenConstraintException$str() {
/*  962 */     return "HV000081: The overriding type of a composite constraint must be identical to the overridden one. Expected %1$s found %2$s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getWrongParameterTypeException(String expectedType, String currentType) {
/*  966 */     ValidationException result = new ValidationException(String.format(getWrongParameterTypeException$str(), new Object[] { expectedType, currentType }));
/*  967 */     StackTraceElement[] st = result.getStackTrace();
/*  968 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  969 */     return result;
/*      */   }
/*      */   
/*      */   protected String getWrongParameterTypeException$str() {
/*  973 */     return "HV000082: Wrong parameter type. Expected: %1$s Actual: %2$s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToFindAnnotationParameterException(String parameterName, NoSuchMethodException e) {
/*  977 */     ValidationException result = new ValidationException(String.format(getUnableToFindAnnotationParameterException$str(), new Object[] { parameterName }), e);
/*  978 */     StackTraceElement[] st = result.getStackTrace();
/*  979 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  980 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToFindAnnotationParameterException$str() {
/*  984 */     return "HV000083: The specified annotation defines no parameter '%s'.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToGetAnnotationParameterException(String parameterName, String annotationName, Exception e) {
/*  988 */     ValidationException result = new ValidationException(String.format(getUnableToGetAnnotationParameterException$str(), new Object[] { parameterName, annotationName }), e);
/*  989 */     StackTraceElement[] st = result.getStackTrace();
/*  990 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  991 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToGetAnnotationParameterException$str() {
/*  995 */     return "HV000084: Unable to get '%1$s' from %2$s.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getNoValueProvidedForAnnotationParameterException(String parameterName, String annotation) {
/*  999 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getNoValueProvidedForAnnotationParameterException$str(), new Object[] { parameterName, annotation }));
/* 1000 */     StackTraceElement[] st = result.getStackTrace();
/* 1001 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1002 */     return result;
/*      */   }
/*      */   
/*      */   protected String getNoValueProvidedForAnnotationParameterException$str() {
/* 1006 */     return "HV000085: No value provided for parameter '%1$s' of annotation @%2$s.";
/*      */   }
/*      */   
/*      */   public final RuntimeException getTryingToInstantiateAnnotationWithUnknownParametersException(Class annotationType, Set unknownParameters) {
/* 1010 */     RuntimeException result = new RuntimeException(String.format(getTryingToInstantiateAnnotationWithUnknownParametersException$str(), new Object[] { annotationType, unknownParameters }));
/* 1011 */     StackTraceElement[] st = result.getStackTrace();
/* 1012 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1013 */     return result;
/*      */   }
/*      */   
/*      */   protected String getTryingToInstantiateAnnotationWithUnknownParametersException$str() {
/* 1017 */     return "HV000086: Trying to instantiate %1$s with unknown parameter(s): %2$s.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getPropertyNameCannotBeNullOrEmptyException() {
/* 1021 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getPropertyNameCannotBeNullOrEmptyException$str(), new Object[0]));
/* 1022 */     StackTraceElement[] st = result.getStackTrace();
/* 1023 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1024 */     return result;
/*      */   }
/*      */   
/*      */   protected String getPropertyNameCannotBeNullOrEmptyException$str() {
/* 1028 */     return "HV000087: Property name cannot be null or empty.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getElementTypeHasToBeFieldOrMethodException() {
/* 1032 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getElementTypeHasToBeFieldOrMethodException$str(), new Object[0]));
/* 1033 */     StackTraceElement[] st = result.getStackTrace();
/* 1034 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1035 */     return result;
/*      */   }
/*      */   
/*      */   protected String getElementTypeHasToBeFieldOrMethodException$str() {
/* 1039 */     return "HV000088: Element type has to be FIELD or METHOD.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getMemberIsNeitherAFieldNorAMethodException(Member member) {
/* 1043 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getMemberIsNeitherAFieldNorAMethodException$str(), new Object[] { member }));
/* 1044 */     StackTraceElement[] st = result.getStackTrace();
/* 1045 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1046 */     return result;
/*      */   }
/*      */   
/*      */   protected String getMemberIsNeitherAFieldNorAMethodException$str() {
/* 1050 */     return "HV000089: Member %s is neither a field nor a method.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToAccessMemberException(String memberName, Exception e) {
/* 1054 */     ValidationException result = new ValidationException(String.format(getUnableToAccessMemberException$str(), new Object[] { memberName }), e);
/* 1055 */     StackTraceElement[] st = result.getStackTrace();
/* 1056 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1057 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToAccessMemberException$str() {
/* 1061 */     return "HV000090: Unable to access %s.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getHasToBeAPrimitiveTypeException(Class clazz) {
/* 1065 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getHasToBeAPrimitiveTypeException$str(), new Object[] { clazz }));
/* 1066 */     StackTraceElement[] st = result.getStackTrace();
/* 1067 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1068 */     return result;
/*      */   }
/*      */   
/*      */   protected String getHasToBeAPrimitiveTypeException$str() {
/* 1072 */     return "HV000091: %s has to be a primitive type.";
/*      */   }
/*      */   
/*      */   public final ValidationException getNullIsAnInvalidTypeForAConstraintValidatorException() {
/* 1076 */     ValidationException result = new ValidationException(String.format(getNullIsAnInvalidTypeForAConstraintValidatorException$str(), new Object[0]));
/* 1077 */     StackTraceElement[] st = result.getStackTrace();
/* 1078 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1079 */     return result;
/*      */   }
/*      */   
/*      */   protected String getNullIsAnInvalidTypeForAConstraintValidatorException$str() {
/* 1083 */     return "HV000093: null is an invalid type for a constraint validator.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getMissingActualTypeArgumentForTypeParameterException(TypeVariable typeParameter) {
/* 1087 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getMissingActualTypeArgumentForTypeParameterException$str(), new Object[] { typeParameter }));
/* 1088 */     StackTraceElement[] st = result.getStackTrace();
/* 1089 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1090 */     return result;
/*      */   }
/*      */   
/*      */   protected String getMissingActualTypeArgumentForTypeParameterException$str() {
/* 1094 */     return "HV000094: Missing actual type argument for type parameter: %s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToInstantiateConstraintFactoryClassException(String constraintFactoryClassName, ValidationException e) {
/* 1098 */     ValidationException result = new ValidationException(String.format(getUnableToInstantiateConstraintFactoryClassException$str(), new Object[] { constraintFactoryClassName }), e);
/* 1099 */     StackTraceElement[] st = result.getStackTrace();
/* 1100 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1101 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToInstantiateConstraintFactoryClassException$str() {
/* 1105 */     return "HV000095: Unable to instantiate constraint factory class %s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToOpenInputStreamForMappingFileException(String mappingFileName) {
/* 1109 */     ValidationException result = new ValidationException(String.format(getUnableToOpenInputStreamForMappingFileException$str(), new Object[] { mappingFileName }));
/* 1110 */     StackTraceElement[] st = result.getStackTrace();
/* 1111 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1112 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToOpenInputStreamForMappingFileException$str() {
/* 1116 */     return "HV000096: Unable to open input stream for mapping file %s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToInstantiateMessageInterpolatorClassException(String messageInterpolatorClassName, Exception e) {
/* 1120 */     ValidationException result = new ValidationException(String.format(getUnableToInstantiateMessageInterpolatorClassException$str(), new Object[] { messageInterpolatorClassName }), e);
/* 1121 */     StackTraceElement[] st = result.getStackTrace();
/* 1122 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1123 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToInstantiateMessageInterpolatorClassException$str() {
/* 1127 */     return "HV000097: Unable to instantiate message interpolator class %s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToInstantiateTraversableResolverClassException(String traversableResolverClassName, Exception e) {
/* 1131 */     ValidationException result = new ValidationException(String.format(getUnableToInstantiateTraversableResolverClassException$str(), new Object[] { traversableResolverClassName }), e);
/* 1132 */     StackTraceElement[] st = result.getStackTrace();
/* 1133 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1134 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToInstantiateTraversableResolverClassException$str() {
/* 1138 */     return "HV000098: Unable to instantiate traversable resolver class %s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToInstantiateValidationProviderClassException(String providerClassName, Exception e) {
/* 1142 */     ValidationException result = new ValidationException(String.format(getUnableToInstantiateValidationProviderClassException$str(), new Object[] { providerClassName }), e);
/* 1143 */     StackTraceElement[] st = result.getStackTrace();
/* 1144 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1145 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToInstantiateValidationProviderClassException$str() {
/* 1149 */     return "HV000099: Unable to instantiate validation provider class %s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToParseValidationXmlFileException(String file, Exception e) {
/* 1153 */     ValidationException result = new ValidationException(String.format(getUnableToParseValidationXmlFileException$str(), new Object[] { file }), e);
/* 1154 */     StackTraceElement[] st = result.getStackTrace();
/* 1155 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1156 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToParseValidationXmlFileException$str() {
/* 1160 */     return "HV000100: Unable to parse %s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getIsNotAnAnnotationException(String annotationClassName) {
/* 1164 */     ValidationException result = new ValidationException(String.format(getIsNotAnAnnotationException$str(), new Object[] { annotationClassName }));
/* 1165 */     StackTraceElement[] st = result.getStackTrace();
/* 1166 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1167 */     return result;
/*      */   }
/*      */   
/*      */   protected String getIsNotAnAnnotationException$str() {
/* 1171 */     return "HV000101: %s is not an annotation.";
/*      */   }
/*      */   
/*      */   public final ValidationException getIsNotAConstraintValidatorClassException(Class validatorClass) {
/* 1175 */     ValidationException result = new ValidationException(String.format(getIsNotAConstraintValidatorClassException$str(), new Object[] { validatorClass }));
/* 1176 */     StackTraceElement[] st = result.getStackTrace();
/* 1177 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1178 */     return result;
/*      */   }
/*      */   
/*      */   protected String getIsNotAConstraintValidatorClassException$str() {
/* 1182 */     return "HV000102: %s is not a constraint validator class.";
/*      */   }
/*      */   
/*      */   public final ValidationException getBeanClassHasAlreadyBeConfiguredInXmlException(String beanClassName) {
/* 1186 */     ValidationException result = new ValidationException(String.format(getBeanClassHasAlreadyBeConfiguredInXmlException$str(), new Object[] { beanClassName }));
/* 1187 */     StackTraceElement[] st = result.getStackTrace();
/* 1188 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1189 */     return result;
/*      */   }
/*      */   
/*      */   protected String getBeanClassHasAlreadyBeConfiguredInXmlException$str() {
/* 1193 */     return "HV000103: %s is configured at least twice in xml.";
/*      */   }
/*      */   
/*      */   public final ValidationException getIsDefinedTwiceInMappingXmlForBeanException(String name, String beanClassName) {
/* 1197 */     ValidationException result = new ValidationException(String.format(getIsDefinedTwiceInMappingXmlForBeanException$str(), new Object[] { name, beanClassName }));
/* 1198 */     StackTraceElement[] st = result.getStackTrace();
/* 1199 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1200 */     return result;
/*      */   }
/*      */   
/*      */   protected String getIsDefinedTwiceInMappingXmlForBeanException$str() {
/* 1204 */     return "HV000104: %1$s is defined twice in mapping xml for bean %2$s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getBeanDoesNotContainTheFieldException(String beanClassName, String fieldName) {
/* 1208 */     ValidationException result = new ValidationException(String.format(getBeanDoesNotContainTheFieldException$str(), new Object[] { beanClassName, fieldName }));
/* 1209 */     StackTraceElement[] st = result.getStackTrace();
/* 1210 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1211 */     return result;
/*      */   }
/*      */   
/*      */   protected String getBeanDoesNotContainTheFieldException$str() {
/* 1215 */     return "HV000105: %1$s does not contain the fieldType %2$s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getBeanDoesNotContainThePropertyException(String beanClassName, String getterName) {
/* 1219 */     ValidationException result = new ValidationException(String.format(getBeanDoesNotContainThePropertyException$str(), new Object[] { beanClassName, getterName }));
/* 1220 */     StackTraceElement[] st = result.getStackTrace();
/* 1221 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1222 */     return result;
/*      */   }
/*      */   
/*      */   protected String getBeanDoesNotContainThePropertyException$str() {
/* 1226 */     return "HV000106: %1$s does not contain the property %2$s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getAnnotationDoesNotContainAParameterException(String annotationClassName, String parameterName) {
/* 1230 */     ValidationException result = new ValidationException(String.format(getAnnotationDoesNotContainAParameterException$str(), new Object[] { annotationClassName, parameterName }));
/* 1231 */     StackTraceElement[] st = result.getStackTrace();
/* 1232 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1233 */     return result;
/*      */   }
/*      */   
/*      */   protected String getAnnotationDoesNotContainAParameterException$str() {
/* 1237 */     return "HV000107: Annotation of type %1$s does not contain a parameter %2$s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getAttemptToSpecifyAnArrayWhereSingleValueIsExpectedException() {
/* 1241 */     ValidationException result = new ValidationException(String.format(getAttemptToSpecifyAnArrayWhereSingleValueIsExpectedException$str(), new Object[0]));
/* 1242 */     StackTraceElement[] st = result.getStackTrace();
/* 1243 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1244 */     return result;
/*      */   }
/*      */   
/*      */   protected String getAttemptToSpecifyAnArrayWhereSingleValueIsExpectedException$str() {
/* 1248 */     return "HV000108: Attempt to specify an array where single value is expected.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnexpectedParameterValueException() {
/* 1252 */     ValidationException result = new ValidationException(String.format(getUnexpectedParameterValueException$str(), new Object[0]));
/* 1253 */     StackTraceElement[] st = result.getStackTrace();
/* 1254 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1255 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnexpectedParameterValueException$str() {
/* 1259 */     return "HV000109: Unexpected parameter value.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnexpectedParameterValueException(ClassCastException e) {
/* 1263 */     ValidationException result = new ValidationException(String.format(getUnexpectedParameterValueException$str(), new Object[0]), e);
/* 1264 */     StackTraceElement[] st = result.getStackTrace();
/* 1265 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1266 */     return result;
/*      */   }
/*      */   
/*      */   public final ValidationException getInvalidNumberFormatException(String formatName, NumberFormatException e) {
/* 1270 */     ValidationException result = new ValidationException(String.format(getInvalidNumberFormatException$str(), new Object[] { formatName }), e);
/* 1271 */     StackTraceElement[] st = result.getStackTrace();
/* 1272 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1273 */     return result;
/*      */   }
/*      */   
/*      */   protected String getInvalidNumberFormatException$str() {
/* 1277 */     return "HV000110: Invalid %s format.";
/*      */   }
/*      */   
/*      */   public final ValidationException getInvalidCharValueException(String value) {
/* 1281 */     ValidationException result = new ValidationException(String.format(getInvalidCharValueException$str(), new Object[] { value }));
/* 1282 */     StackTraceElement[] st = result.getStackTrace();
/* 1283 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1284 */     return result;
/*      */   }
/*      */   
/*      */   protected String getInvalidCharValueException$str() {
/* 1288 */     return "HV000111: Invalid char value: %s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getInvalidReturnTypeException(Class returnType, ClassCastException e) {
/* 1292 */     ValidationException result = new ValidationException(String.format(getInvalidReturnTypeException$str(), new Object[] { returnType }), e);
/* 1293 */     StackTraceElement[] st = result.getStackTrace();
/* 1294 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1295 */     return result;
/*      */   }
/*      */   
/*      */   protected String getInvalidReturnTypeException$str() {
/* 1299 */     return "HV000112: Invalid return type: %s. Should be a enumeration type.";
/*      */   }
/*      */   
/*      */   public final ValidationException getReservedParameterNamesException(String messageParameterName, String groupsParameterName, String payloadParameterName) {
/* 1303 */     ValidationException result = new ValidationException(String.format(getReservedParameterNamesException$str(), new Object[] { messageParameterName, groupsParameterName, payloadParameterName }));
/* 1304 */     StackTraceElement[] st = result.getStackTrace();
/* 1305 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1306 */     return result;
/*      */   }
/*      */   
/*      */   protected String getReservedParameterNamesException$str() {
/* 1310 */     return "HV000113: %s, %s, %s are reserved parameter names.";
/*      */   }
/*      */   
/*      */   public final ValidationException getWrongPayloadClassException(String payloadClassName) {
/* 1314 */     ValidationException result = new ValidationException(String.format(getWrongPayloadClassException$str(), new Object[] { payloadClassName }));
/* 1315 */     StackTraceElement[] st = result.getStackTrace();
/* 1316 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1317 */     return result;
/*      */   }
/*      */   
/*      */   protected String getWrongPayloadClassException$str() {
/* 1321 */     return "HV000114: Specified payload class %s does not implement javax.validation.Payload";
/*      */   }
/*      */   
/*      */   public final ValidationException getErrorParsingMappingFileException(Exception e) {
/* 1325 */     ValidationException result = new ValidationException(String.format(getErrorParsingMappingFileException$str(), new Object[0]), e);
/* 1326 */     StackTraceElement[] st = result.getStackTrace();
/* 1327 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1328 */     return result;
/*      */   }
/*      */   
/*      */   protected String getErrorParsingMappingFileException$str() {
/* 1332 */     return "HV000115: Error parsing mapping file.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getIllegalArgumentException(String message) {
/* 1336 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getIllegalArgumentException$str(), new Object[] { message }));
/* 1337 */     StackTraceElement[] st = result.getStackTrace();
/* 1338 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1339 */     return result;
/*      */   }
/*      */   
/*      */   protected String getIllegalArgumentException$str() {
/* 1343 */     return "HV000116: %s";
/*      */   }
/*      */   
/*      */   public final ClassCastException getUnableToNarrowNodeTypeException(String actualDescriptorType, ElementKind kind, String expectedDescriptorType) {
/* 1347 */     ClassCastException result = new ClassCastException(String.format(getUnableToNarrowNodeTypeException$str(), new Object[] { actualDescriptorType, kind, expectedDescriptorType }));
/* 1348 */     StackTraceElement[] st = result.getStackTrace();
/* 1349 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1350 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToNarrowNodeTypeException$str() {
/* 1354 */     return "HV000118: Unable to cast %s (with element kind %s) to %s";
/*      */   }
/*      */   
/*      */   public final void usingParameterNameProvider(String parameterNameProviderClassName) {
/* 1358 */     this.log.logf(FQCN, Logger.Level.INFO, null, usingParameterNameProvider$str(), parameterNameProviderClassName);
/*      */   }
/*      */   
/*      */   protected String usingParameterNameProvider$str() {
/* 1362 */     return "HV000119: Using %s as parameter name provider.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToInstantiateParameterNameProviderClassException(String parameterNameProviderClassName, ValidationException e) {
/* 1366 */     ValidationException result = new ValidationException(String.format(getUnableToInstantiateParameterNameProviderClassException$str(), new Object[] { parameterNameProviderClassName }), e);
/* 1367 */     StackTraceElement[] st = result.getStackTrace();
/* 1368 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1369 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToInstantiateParameterNameProviderClassException$str() {
/* 1373 */     return "HV000120: Unable to instantiate parameter name provider class %s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToDetermineSchemaVersionException(String file, XMLStreamException e) {
/* 1377 */     ValidationException result = new ValidationException(String.format(getUnableToDetermineSchemaVersionException$str(), new Object[] { file }), e);
/* 1378 */     StackTraceElement[] st = result.getStackTrace();
/* 1379 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1380 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToDetermineSchemaVersionException$str() {
/* 1384 */     return "HV000121: Unable to parse %s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnsupportedSchemaVersionException(String file, String version) {
/* 1388 */     ValidationException result = new ValidationException(String.format(getUnsupportedSchemaVersionException$str(), new Object[] { file, version }));
/* 1389 */     StackTraceElement[] st = result.getStackTrace();
/* 1390 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1391 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnsupportedSchemaVersionException$str() {
/* 1395 */     return "HV000122: Unsupported schema version for %s: %s.";
/*      */   }
/*      */   
/*      */   public final ConstraintDeclarationException getMultipleGroupConversionsForSameSourceException(Class from, Set tos) {
/* 1399 */     ConstraintDeclarationException result = new ConstraintDeclarationException(String.format(getMultipleGroupConversionsForSameSourceException$str(), new Object[] { from, tos }));
/* 1400 */     StackTraceElement[] st = result.getStackTrace();
/* 1401 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1402 */     return result;
/*      */   }
/*      */   
/*      */   protected String getMultipleGroupConversionsForSameSourceException$str() {
/* 1406 */     return "HV000124: Found multiple group conversions for source group %s: %s.";
/*      */   }
/*      */   
/*      */   public final ConstraintDeclarationException getGroupConversionOnNonCascadingElementException(String location) {
/* 1410 */     ConstraintDeclarationException result = new ConstraintDeclarationException(String.format(getGroupConversionOnNonCascadingElementException$str(), new Object[] { location }));
/* 1411 */     StackTraceElement[] st = result.getStackTrace();
/* 1412 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1413 */     return result;
/*      */   }
/*      */   
/*      */   protected String getGroupConversionOnNonCascadingElementException$str() {
/* 1417 */     return "HV000125: Found group conversions for non-cascading element: %s.";
/*      */   }
/*      */   
/*      */   public final ConstraintDeclarationException getGroupConversionForSequenceException(Class from) {
/* 1421 */     ConstraintDeclarationException result = new ConstraintDeclarationException(String.format(getGroupConversionForSequenceException$str(), new Object[] { from }));
/* 1422 */     StackTraceElement[] st = result.getStackTrace();
/* 1423 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1424 */     return result;
/*      */   }
/*      */   
/*      */   protected String getGroupConversionForSequenceException$str() {
/* 1428 */     return "HV000127: Found group conversion using a group sequence as source: %s.";
/*      */   }
/*      */   
/*      */   public final void unknownPropertyInExpressionLanguage(String expression, Exception e) {
/* 1432 */     this.log.logf(FQCN, Logger.Level.WARN, e, unknownPropertyInExpressionLanguage$str(), expression);
/*      */   }
/*      */   
/*      */   protected String unknownPropertyInExpressionLanguage$str() {
/* 1436 */     return "HV000129: EL expression '%s' references an unknown property";
/*      */   }
/*      */   
/*      */   public final void errorInExpressionLanguage(String expression, Exception e) {
/* 1440 */     this.log.logf(FQCN, Logger.Level.WARN, e, errorInExpressionLanguage$str(), expression);
/*      */   }
/*      */   
/*      */   protected String errorInExpressionLanguage$str() {
/* 1444 */     return "HV000130: Error in EL expression '%s'";
/*      */   }
/*      */   
/*      */   public final ConstraintDeclarationException getMethodReturnValueMustNotBeMarkedMoreThanOnceForCascadedValidationException(Member member1, Member member2) {
/* 1448 */     ConstraintDeclarationException result = new ConstraintDeclarationException(String.format(getMethodReturnValueMustNotBeMarkedMoreThanOnceForCascadedValidationException$str(), new Object[] { member1, member2 }));
/* 1449 */     StackTraceElement[] st = result.getStackTrace();
/* 1450 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1451 */     return result;
/*      */   }
/*      */   
/*      */   protected String getMethodReturnValueMustNotBeMarkedMoreThanOnceForCascadedValidationException$str() {
/* 1455 */     return "HV000131: A method return value must not be marked for cascaded validation more than once in a class hierarchy, but the following two methods are marked as such: %s, %s.";
/*      */   }
/*      */   
/*      */   public final ConstraintDeclarationException getVoidMethodsMustNotBeConstrainedException(Member member) {
/* 1459 */     ConstraintDeclarationException result = new ConstraintDeclarationException(String.format(getVoidMethodsMustNotBeConstrainedException$str(), new Object[] { member }));
/* 1460 */     StackTraceElement[] st = result.getStackTrace();
/* 1461 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1462 */     return result;
/*      */   }
/*      */   
/*      */   protected String getVoidMethodsMustNotBeConstrainedException$str() {
/* 1466 */     return "HV000132: Void methods must not be constrained or marked for cascaded validation, but method %s is.";
/*      */   }
/*      */   
/*      */   public final ValidationException getBeanDoesNotContainConstructorException(String beanClassName, String parameterTypes) {
/* 1470 */     ValidationException result = new ValidationException(String.format(getBeanDoesNotContainConstructorException$str(), new Object[] { beanClassName, parameterTypes }));
/* 1471 */     StackTraceElement[] st = result.getStackTrace();
/* 1472 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1473 */     return result;
/*      */   }
/*      */   
/*      */   protected String getBeanDoesNotContainConstructorException$str() {
/* 1477 */     return "HV000133: %1$s does not contain a constructor with the parameter types %2$s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getInvalidParameterTypeException(String type, String beanClassName) {
/* 1481 */     ValidationException result = new ValidationException(String.format(getInvalidParameterTypeException$str(), new Object[] { type, beanClassName }));
/* 1482 */     StackTraceElement[] st = result.getStackTrace();
/* 1483 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1484 */     return result;
/*      */   }
/*      */   
/*      */   protected String getInvalidParameterTypeException$str() {
/* 1488 */     return "HV000134: Unable to load parameter of type '%1$s' in %2$s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getBeanDoesNotContainMethodException(String beanClassName, String methodName, List parameterTypes) {
/* 1492 */     ValidationException result = new ValidationException(String.format(getBeanDoesNotContainMethodException$str(), new Object[] { beanClassName, methodName, parameterTypes }));
/* 1493 */     StackTraceElement[] st = result.getStackTrace();
/* 1494 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1495 */     return result;
/*      */   }
/*      */   
/*      */   protected String getBeanDoesNotContainMethodException$str() {
/* 1499 */     return "HV000135: %1$s does not contain a method with the name '%2$s' and parameter types %3$s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToLoadConstraintAnnotationClassException(String constraintAnnotationClass, Exception e) {
/* 1503 */     ValidationException result = new ValidationException(String.format(getUnableToLoadConstraintAnnotationClassException$str(), new Object[] { constraintAnnotationClass }), e);
/* 1504 */     StackTraceElement[] st = result.getStackTrace();
/* 1505 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1506 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToLoadConstraintAnnotationClassException$str() {
/* 1510 */     return "HV000136: The specified constraint annotation class %1$s cannot be loaded.";
/*      */   }
/*      */   
/*      */   public final ValidationException getMethodIsDefinedTwiceInMappingXmlForBeanException(String name, String beanClassName) {
/* 1514 */     ValidationException result = new ValidationException(String.format(getMethodIsDefinedTwiceInMappingXmlForBeanException$str(), new Object[] { name, beanClassName }));
/* 1515 */     StackTraceElement[] st = result.getStackTrace();
/* 1516 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1517 */     return result;
/*      */   }
/*      */   
/*      */   protected String getMethodIsDefinedTwiceInMappingXmlForBeanException$str() {
/* 1521 */     return "HV000137: The method '%1$s' is defined twice in the mapping xml for bean %2$s.";
/*      */   }
/*      */   
/*      */   public final ValidationException getConstructorIsDefinedTwiceInMappingXmlForBeanException(String name, String beanClassName) {
/* 1525 */     ValidationException result = new ValidationException(String.format(getConstructorIsDefinedTwiceInMappingXmlForBeanException$str(), new Object[] { name, beanClassName }));
/* 1526 */     StackTraceElement[] st = result.getStackTrace();
/* 1527 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1528 */     return result;
/*      */   }
/*      */   
/*      */   protected String getConstructorIsDefinedTwiceInMappingXmlForBeanException$str() {
/* 1532 */     return "HV000138: The constructor '%1$s' is defined twice in the mapping xml for bean %2$s.";
/*      */   }
/*      */   
/*      */   public final ConstraintDefinitionException getMultipleCrossParameterValidatorClassesException(String constraint) {
/* 1536 */     ConstraintDefinitionException result = new ConstraintDefinitionException(String.format(getMultipleCrossParameterValidatorClassesException$str(), new Object[] { constraint }));
/* 1537 */     StackTraceElement[] st = result.getStackTrace();
/* 1538 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1539 */     return result;
/*      */   }
/*      */   
/*      */   protected String getMultipleCrossParameterValidatorClassesException$str() {
/* 1543 */     return "HV000139: The constraint '%1$s' defines multiple cross parameter validators. Only one is allowed.";
/*      */   }
/*      */   
/*      */   public final ConstraintDeclarationException getImplicitConstraintTargetInAmbiguousConfigurationException(String constraint) {
/* 1547 */     ConstraintDeclarationException result = new ConstraintDeclarationException(String.format(getImplicitConstraintTargetInAmbiguousConfigurationException$str(), new Object[] { constraint }));
/* 1548 */     StackTraceElement[] st = result.getStackTrace();
/* 1549 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1550 */     return result;
/*      */   }
/*      */   
/*      */   protected String getImplicitConstraintTargetInAmbiguousConfigurationException$str() {
/* 1554 */     return "HV000141: The constraint %1$s used ConstraintTarget#IMPLICIT where the target cannot be inferred.";
/*      */   }
/*      */   
/*      */   public final ConstraintDeclarationException getCrossParameterConstraintOnMethodWithoutParametersException(String constraint, String member) {
/* 1558 */     ConstraintDeclarationException result = new ConstraintDeclarationException(String.format(getCrossParameterConstraintOnMethodWithoutParametersException$str(), new Object[] { constraint, member }));
/* 1559 */     StackTraceElement[] st = result.getStackTrace();
/* 1560 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1561 */     return result;
/*      */   }
/*      */   
/*      */   protected String getCrossParameterConstraintOnMethodWithoutParametersException$str() {
/* 1565 */     return "HV000142: Cross parameter constraint %1$s is illegally placed on a parameterless method or constructor '%2$s'.";
/*      */   }
/*      */   
/*      */   public final ConstraintDeclarationException getCrossParameterConstraintOnClassException(String constraint) {
/* 1569 */     ConstraintDeclarationException result = new ConstraintDeclarationException(String.format(getCrossParameterConstraintOnClassException$str(), new Object[] { constraint }));
/* 1570 */     StackTraceElement[] st = result.getStackTrace();
/* 1571 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1572 */     return result;
/*      */   }
/*      */   
/*      */   protected String getCrossParameterConstraintOnClassException$str() {
/* 1576 */     return "HV000143: Cross parameter constraint %1$s is illegally placed on class level.";
/*      */   }
/*      */   
/*      */   public final ConstraintDeclarationException getCrossParameterConstraintOnFieldException(String constraint, String field) {
/* 1580 */     ConstraintDeclarationException result = new ConstraintDeclarationException(String.format(getCrossParameterConstraintOnFieldException$str(), new Object[] { constraint, field }));
/* 1581 */     StackTraceElement[] st = result.getStackTrace();
/* 1582 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1583 */     return result;
/*      */   }
/*      */   
/*      */   protected String getCrossParameterConstraintOnFieldException$str() {
/* 1587 */     return "HV000144: Cross parameter constraint %1$s is illegally placed on field '%2$s'.";
/*      */   }
/*      */   
/*      */   public final IllegalStateException getParameterNodeAddedForNonCrossParameterConstraintException(Path path) {
/* 1591 */     IllegalStateException result = new IllegalStateException(String.format(getParameterNodeAddedForNonCrossParameterConstraintException$str(), new Object[] { path }));
/* 1592 */     StackTraceElement[] st = result.getStackTrace();
/* 1593 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1594 */     return result;
/*      */   }
/*      */   
/*      */   protected String getParameterNodeAddedForNonCrossParameterConstraintException$str() {
/* 1598 */     return "HV000146: No parameter nodes may be added since path %s doesn't refer to a cross-parameter constraint.";
/*      */   }
/*      */   
/*      */   public final ValidationException getConstrainedElementConfiguredMultipleTimesException(String location) {
/* 1602 */     ValidationException result = new ValidationException(String.format(getConstrainedElementConfiguredMultipleTimesException$str(), new Object[] { location }));
/* 1603 */     StackTraceElement[] st = result.getStackTrace();
/* 1604 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1605 */     return result;
/*      */   }
/*      */   
/*      */   protected String getConstrainedElementConfiguredMultipleTimesException$str() {
/* 1609 */     return "HV000147: %1$s is configured multiple times (note, <getter> and <method> nodes for the same method are not allowed)";
/*      */   }
/*      */   
/*      */   public final void evaluatingExpressionLanguageExpressionCausedException(String expression, Exception e) {
/* 1613 */     this.log.logf(FQCN, Logger.Level.WARN, e, evaluatingExpressionLanguageExpressionCausedException$str(), expression);
/*      */   }
/*      */   
/*      */   protected String evaluatingExpressionLanguageExpressionCausedException$str() {
/* 1617 */     return "HV000148: An exception occurred during evaluation of EL expression '%s'";
/*      */   }
/*      */   
/*      */   public final ValidationException getExceptionOccurredDuringMessageInterpolationException(Exception e) {
/* 1621 */     ValidationException result = new ValidationException(String.format(getExceptionOccurredDuringMessageInterpolationException$str(), new Object[0]), e);
/* 1622 */     StackTraceElement[] st = result.getStackTrace();
/* 1623 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1624 */     return result;
/*      */   }
/*      */   
/*      */   protected String getExceptionOccurredDuringMessageInterpolationException$str() {
/* 1628 */     return "HV000149: An exception occurred during message interpolation";
/*      */   }
/*      */   
/*      */   public final UnexpectedTypeException getMultipleValidatorsForSameTypeException(String constraint, String type) {
/* 1632 */     UnexpectedTypeException result = new UnexpectedTypeException(String.format(getMultipleValidatorsForSameTypeException$str(), new Object[] { constraint, type }));
/* 1633 */     StackTraceElement[] st = result.getStackTrace();
/* 1634 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1635 */     return result;
/*      */   }
/*      */   
/*      */   protected String getMultipleValidatorsForSameTypeException$str() {
/* 1639 */     return "HV000150: The constraint '%s' defines multiple validators for the type '%s'. Only one is allowed.";
/*      */   }
/*      */   
/*      */   public final ConstraintDeclarationException getParameterConfigurationAlteredInSubTypeException(Member superMethod, Member subMethod) {
/* 1643 */     ConstraintDeclarationException result = new ConstraintDeclarationException(String.format(getParameterConfigurationAlteredInSubTypeException$str(), new Object[] { superMethod, subMethod }));
/* 1644 */     StackTraceElement[] st = result.getStackTrace();
/* 1645 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1646 */     return result;
/*      */   }
/*      */   
/*      */   protected String getParameterConfigurationAlteredInSubTypeException$str() {
/* 1650 */     return "HV000151: A method overriding another method must not alter the parameter constraint configuration, but method %2$s changes the configuration of %1$s.";
/*      */   }
/*      */   
/*      */   public final ConstraintDeclarationException getParameterConstraintsDefinedInMethodsFromParallelTypesException(Member method1, Member method2) {
/* 1654 */     ConstraintDeclarationException result = new ConstraintDeclarationException(String.format(getParameterConstraintsDefinedInMethodsFromParallelTypesException$str(), new Object[] { method1, method2 }));
/* 1655 */     StackTraceElement[] st = result.getStackTrace();
/* 1656 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1657 */     return result;
/*      */   }
/*      */   
/*      */   protected String getParameterConstraintsDefinedInMethodsFromParallelTypesException$str() {
/* 1661 */     return "HV000152: Two methods defined in parallel types must not declare parameter constraints, if they are overridden by the same method, but methods %s and %s both define parameter constraints.";
/*      */   }
/*      */   
/*      */   public final ConstraintDeclarationException getParametersOrReturnValueConstraintTargetGivenAtNonExecutableException(String constraint, ConstraintTarget target) {
/* 1665 */     ConstraintDeclarationException result = new ConstraintDeclarationException(String.format(getParametersOrReturnValueConstraintTargetGivenAtNonExecutableException$str(), new Object[] { constraint, target }));
/* 1666 */     StackTraceElement[] st = result.getStackTrace();
/* 1667 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1668 */     return result;
/*      */   }
/*      */   
/*      */   protected String getParametersOrReturnValueConstraintTargetGivenAtNonExecutableException$str() {
/* 1672 */     return "HV000153: The constraint %1$s used ConstraintTarget#%2$s but is not specified on a method or constructor.";
/*      */   }
/*      */   
/*      */   public final ConstraintDefinitionException getCrossParameterConstraintHasNoValidatorException(String constraint) {
/* 1676 */     ConstraintDefinitionException result = new ConstraintDefinitionException(String.format(getCrossParameterConstraintHasNoValidatorException$str(), new Object[] { constraint }));
/* 1677 */     StackTraceElement[] st = result.getStackTrace();
/* 1678 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1679 */     return result;
/*      */   }
/*      */   
/*      */   protected String getCrossParameterConstraintHasNoValidatorException$str() {
/* 1683 */     return "HV000154: Cross parameter constraint %1$s has no cross-parameter validator.";
/*      */   }
/*      */   
/*      */   public final ConstraintDefinitionException getComposedAndComposingConstraintsHaveDifferentTypesException(String composedConstraintTypeName, String composingConstraintTypeName, ConstraintDescriptorImpl.ConstraintType composedConstraintType, ConstraintDescriptorImpl.ConstraintType composingConstraintType) {
/* 1687 */     ConstraintDefinitionException result = new ConstraintDefinitionException(String.format(getComposedAndComposingConstraintsHaveDifferentTypesException$str(), new Object[] { composedConstraintTypeName, composingConstraintTypeName, composedConstraintType, composingConstraintType }));
/* 1688 */     StackTraceElement[] st = result.getStackTrace();
/* 1689 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1690 */     return result;
/*      */   }
/*      */   
/*      */   protected String getComposedAndComposingConstraintsHaveDifferentTypesException$str() {
/* 1694 */     return "HV000155: Composed and composing constraints must have the same constraint type, but composed constraint %1$s has type %3$s, while composing constraint %2$s has type %4$s.";
/*      */   }
/*      */   
/*      */   public final ConstraintDefinitionException getGenericAndCrossParameterConstraintDoesNotDefineValidationAppliesToParameterException(String constraint) {
/* 1698 */     ConstraintDefinitionException result = new ConstraintDefinitionException(String.format(getGenericAndCrossParameterConstraintDoesNotDefineValidationAppliesToParameterException$str(), new Object[] { constraint }));
/* 1699 */     StackTraceElement[] st = result.getStackTrace();
/* 1700 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1701 */     return result;
/*      */   }
/*      */   
/*      */   protected String getGenericAndCrossParameterConstraintDoesNotDefineValidationAppliesToParameterException$str() {
/* 1705 */     return "HV000156: Constraints with generic as well as cross-parameter validators must define an attribute validationAppliesTo(), but constraint %s doesn't.";
/*      */   }
/*      */   
/*      */   public final ConstraintDefinitionException getValidationAppliesToParameterMustHaveReturnTypeConstraintTargetException(String constraint) {
/* 1709 */     ConstraintDefinitionException result = new ConstraintDefinitionException(String.format(getValidationAppliesToParameterMustHaveReturnTypeConstraintTargetException$str(), new Object[] { constraint }));
/* 1710 */     StackTraceElement[] st = result.getStackTrace();
/* 1711 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1712 */     return result;
/*      */   }
/*      */   
/*      */   protected String getValidationAppliesToParameterMustHaveReturnTypeConstraintTargetException$str() {
/* 1716 */     return "HV000157: Return type of the attribute validationAppliesTo() of the constraint %s must be javax.validation.ConstraintTarget.";
/*      */   }
/*      */   
/*      */   public final ConstraintDefinitionException getValidationAppliesToParameterMustHaveDefaultValueImplicitException(String constraint) {
/* 1720 */     ConstraintDefinitionException result = new ConstraintDefinitionException(String.format(getValidationAppliesToParameterMustHaveDefaultValueImplicitException$str(), new Object[] { constraint }));
/* 1721 */     StackTraceElement[] st = result.getStackTrace();
/* 1722 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1723 */     return result;
/*      */   }
/*      */   
/*      */   protected String getValidationAppliesToParameterMustHaveDefaultValueImplicitException$str() {
/* 1727 */     return "HV000158: Default value of the attribute validationAppliesTo() of the constraint %s must be ConstraintTarget#IMPLICIT.";
/*      */   }
/*      */   
/*      */   public final ConstraintDefinitionException getValidationAppliesToParameterMustNotBeDefinedForNonGenericAndCrossParameterConstraintException(String constraint) {
/* 1731 */     ConstraintDefinitionException result = new ConstraintDefinitionException(String.format(getValidationAppliesToParameterMustNotBeDefinedForNonGenericAndCrossParameterConstraintException$str(), new Object[] { constraint }));
/* 1732 */     StackTraceElement[] st = result.getStackTrace();
/* 1733 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1734 */     return result;
/*      */   }
/*      */   
/*      */   protected String getValidationAppliesToParameterMustNotBeDefinedForNonGenericAndCrossParameterConstraintException$str() {
/* 1738 */     return "HV000159: Only constraints with generic as well as cross-parameter validators must define an attribute validationAppliesTo(), but constraint %s does.";
/*      */   }
/*      */   
/*      */   public final ConstraintDefinitionException getValidatorForCrossParameterConstraintMustEitherValidateObjectOrObjectArrayException(String constraint) {
/* 1742 */     ConstraintDefinitionException result = new ConstraintDefinitionException(String.format(getValidatorForCrossParameterConstraintMustEitherValidateObjectOrObjectArrayException$str(), new Object[] { constraint }));
/* 1743 */     StackTraceElement[] st = result.getStackTrace();
/* 1744 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1745 */     return result;
/*      */   }
/*      */   
/*      */   protected String getValidatorForCrossParameterConstraintMustEitherValidateObjectOrObjectArrayException$str() {
/* 1749 */     return "HV000160: Validator for cross-parameter constraint %s does not validate Object nor Object[].";
/*      */   }
/*      */   
/*      */   public final ConstraintDeclarationException getMethodsFromParallelTypesMustNotDefineGroupConversionsForCascadedReturnValueException(Member method1, Member method2) {
/* 1753 */     ConstraintDeclarationException result = new ConstraintDeclarationException(String.format(getMethodsFromParallelTypesMustNotDefineGroupConversionsForCascadedReturnValueException$str(), new Object[] { method1, method2 }));
/* 1754 */     StackTraceElement[] st = result.getStackTrace();
/* 1755 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1756 */     return result;
/*      */   }
/*      */   
/*      */   protected String getMethodsFromParallelTypesMustNotDefineGroupConversionsForCascadedReturnValueException$str() {
/* 1760 */     return "HV000161: Two methods defined in parallel types must not define group conversions for a cascaded method return value, if they are overridden by the same method, but methods %s and %s both define parameter constraints.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getMethodOrConstructorNotDefinedByValidatedTypeException(String validatedTypeName, Member member) {
/* 1764 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getMethodOrConstructorNotDefinedByValidatedTypeException$str(), new Object[] { validatedTypeName, member }));
/* 1765 */     StackTraceElement[] st = result.getStackTrace();
/* 1766 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1767 */     return result;
/*      */   }
/*      */   
/*      */   protected String getMethodOrConstructorNotDefinedByValidatedTypeException$str() {
/* 1771 */     return "HV000162: The validated type %1$s does not specify the constructor/method: %2$s";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getParameterTypesDoNotMatchException(String actualType, String expectedType, int index, Member member) {
/* 1775 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getParameterTypesDoNotMatchException$str(), new Object[] { actualType, expectedType, Integer.valueOf(index), member }));
/* 1776 */     StackTraceElement[] st = result.getStackTrace();
/* 1777 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1778 */     return result;
/*      */   }
/*      */   
/*      */   protected String getParameterTypesDoNotMatchException$str() {
/* 1782 */     return "HV000163: The actual parameter type '%1$s' is not assignable to the expected one '%2$s' for parameter %3$d of '%4$s'";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getHasToBeABoxedTypeException(Class clazz) {
/* 1786 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getHasToBeABoxedTypeException$str(), new Object[] { clazz }));
/* 1787 */     StackTraceElement[] st = result.getStackTrace();
/* 1788 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1789 */     return result;
/*      */   }
/*      */   
/*      */   protected String getHasToBeABoxedTypeException$str() {
/* 1793 */     return "HV000164: %s has to be a auto-boxed type.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getMixingImplicitWithOtherExecutableTypesException() {
/* 1797 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getMixingImplicitWithOtherExecutableTypesException$str(), new Object[0]));
/* 1798 */     StackTraceElement[] st = result.getStackTrace();
/* 1799 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1800 */     return result;
/*      */   }
/*      */   
/*      */   protected String getMixingImplicitWithOtherExecutableTypesException$str() {
/* 1804 */     return "HV000165: Mixing IMPLICIT and other executable types is not allowed.";
/*      */   }
/*      */   
/*      */   public final ValidationException getValidateOnExecutionOnOverriddenOrInterfaceMethodException(Method m) {
/* 1808 */     ValidationException result = new ValidationException(String.format(getValidateOnExecutionOnOverriddenOrInterfaceMethodException$str(), new Object[] { m }));
/* 1809 */     StackTraceElement[] st = result.getStackTrace();
/* 1810 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1811 */     return result;
/*      */   }
/*      */   
/*      */   protected String getValidateOnExecutionOnOverriddenOrInterfaceMethodException$str() {
/* 1815 */     return "HV000166: @ValidateOnExecution is not allowed on methods overriding a superclass method or implementing an interface. Check configuration for %1$s";
/*      */   }
/*      */   
/*      */   public final ValidationException getOverridingConstraintDefinitionsInMultipleMappingFilesException(String constraintClass) {
/* 1819 */     ValidationException result = new ValidationException(String.format(getOverridingConstraintDefinitionsInMultipleMappingFilesException$str(), new Object[] { constraintClass }));
/* 1820 */     StackTraceElement[] st = result.getStackTrace();
/* 1821 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1822 */     return result;
/*      */   }
/*      */   
/*      */   protected String getOverridingConstraintDefinitionsInMultipleMappingFilesException$str() {
/* 1826 */     return "HV000167: A given constraint definition can only be overridden in one mapping file. %1$s is overridden in multiple files";
/*      */   }
/*      */   
/*      */   public final MessageDescriptorFormatException getNonTerminatedParameterException(String messageDescriptor, char character) {
/* 1830 */     MessageDescriptorFormatException result = new MessageDescriptorFormatException(String.format(getNonTerminatedParameterException$str(), new Object[] { messageDescriptor, Character.valueOf(character) }));
/* 1831 */     StackTraceElement[] st = result.getStackTrace();
/* 1832 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1833 */     return result;
/*      */   }
/*      */   
/*      */   protected String getNonTerminatedParameterException$str() {
/* 1837 */     return "HV000168: The message descriptor '%1$s' contains an unbalanced meta character '%2$c' parameter.";
/*      */   }
/*      */   
/*      */   public final MessageDescriptorFormatException getNestedParameterException(String messageDescriptor) {
/* 1841 */     MessageDescriptorFormatException result = new MessageDescriptorFormatException(String.format(getNestedParameterException$str(), new Object[] { messageDescriptor }));
/* 1842 */     StackTraceElement[] st = result.getStackTrace();
/* 1843 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1844 */     return result;
/*      */   }
/*      */   
/*      */   protected String getNestedParameterException$str() {
/* 1848 */     return "HV000169: The message descriptor '%1$s' has nested parameters.";
/*      */   }
/*      */   
/*      */   public final ConstraintDeclarationException getCreationOfScriptExecutorFailedException(String languageName, Exception e) {
/* 1852 */     ConstraintDeclarationException result = new ConstraintDeclarationException(String.format(getCreationOfScriptExecutorFailedException$str(), new Object[] { languageName }), e);
/* 1853 */     StackTraceElement[] st = result.getStackTrace();
/* 1854 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1855 */     return result;
/*      */   }
/*      */   
/*      */   protected String getCreationOfScriptExecutorFailedException$str() {
/* 1859 */     return "HV000170: No JSR-223 scripting engine could be bootstrapped for language \"%s\".";
/*      */   }
/*      */   
/*      */   public final ValidationException getBeanClassHasAlreadyBeConfiguredViaProgrammaticApiException(String beanClassName) {
/* 1863 */     ValidationException result = new ValidationException(String.format(getBeanClassHasAlreadyBeConfiguredViaProgrammaticApiException$str(), new Object[] { beanClassName }));
/* 1864 */     StackTraceElement[] st = result.getStackTrace();
/* 1865 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1866 */     return result;
/*      */   }
/*      */   
/*      */   protected String getBeanClassHasAlreadyBeConfiguredViaProgrammaticApiException$str() {
/* 1870 */     return "HV000171: %s is configured more than once via the programmatic constraint declaration API.";
/*      */   }
/*      */   
/*      */   public final ValidationException getPropertyHasAlreadyBeConfiguredViaProgrammaticApiException(String beanClassName, String propertyName) {
/* 1874 */     ValidationException result = new ValidationException(String.format(getPropertyHasAlreadyBeConfiguredViaProgrammaticApiException$str(), new Object[] { beanClassName, propertyName }));
/* 1875 */     StackTraceElement[] st = result.getStackTrace();
/* 1876 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1877 */     return result;
/*      */   }
/*      */   
/*      */   protected String getPropertyHasAlreadyBeConfiguredViaProgrammaticApiException$str() {
/* 1881 */     return "HV000172: Property \"%2$s\" of type %1$s is configured more than once via the programmatic constraint declaration API.";
/*      */   }
/*      */   
/*      */   public final ValidationException getMethodHasAlreadyBeConfiguredViaProgrammaticApiException(String beanClassName, String method) {
/* 1885 */     ValidationException result = new ValidationException(String.format(getMethodHasAlreadyBeConfiguredViaProgrammaticApiException$str(), new Object[] { beanClassName, method }));
/* 1886 */     StackTraceElement[] st = result.getStackTrace();
/* 1887 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1888 */     return result;
/*      */   }
/*      */   
/*      */   protected String getMethodHasAlreadyBeConfiguredViaProgrammaticApiException$str() {
/* 1892 */     return "HV000173: Method %2$s of type %1$s is configured more than once via the programmatic constraint declaration API.";
/*      */   }
/*      */   
/*      */   public final ValidationException getParameterHasAlreadyBeConfiguredViaProgrammaticApiException(String beanClassName, String executable, int parameterIndex) {
/* 1896 */     ValidationException result = new ValidationException(String.format(getParameterHasAlreadyBeConfiguredViaProgrammaticApiException$str(), new Object[] { beanClassName, executable, Integer.valueOf(parameterIndex) }));
/* 1897 */     StackTraceElement[] st = result.getStackTrace();
/* 1898 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1899 */     return result;
/*      */   }
/*      */   
/*      */   protected String getParameterHasAlreadyBeConfiguredViaProgrammaticApiException$str() {
/* 1903 */     return "HV000174: Parameter %3$s of method or constructor %2$s of type %1$s is configured more than once via the programmatic constraint declaration API.";
/*      */   }
/*      */   
/*      */   public final ValidationException getReturnValueHasAlreadyBeConfiguredViaProgrammaticApiException(String beanClassName, String executable) {
/* 1907 */     ValidationException result = new ValidationException(String.format(getReturnValueHasAlreadyBeConfiguredViaProgrammaticApiException$str(), new Object[] { beanClassName, executable }));
/* 1908 */     StackTraceElement[] st = result.getStackTrace();
/* 1909 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1910 */     return result;
/*      */   }
/*      */   
/*      */   protected String getReturnValueHasAlreadyBeConfiguredViaProgrammaticApiException$str() {
/* 1914 */     return "HV000175: The return value of method or constructor %2$s of type %1$s is configured more than once via the programmatic constraint declaration API.";
/*      */   }
/*      */   
/*      */   public final ValidationException getConstructorHasAlreadyBeConfiguredViaProgrammaticApiException(String beanClassName, String constructor) {
/* 1918 */     ValidationException result = new ValidationException(String.format(getConstructorHasAlreadyBeConfiguredViaProgrammaticApiException$str(), new Object[] { beanClassName, constructor }));
/* 1919 */     StackTraceElement[] st = result.getStackTrace();
/* 1920 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1921 */     return result;
/*      */   }
/*      */   
/*      */   protected String getConstructorHasAlreadyBeConfiguredViaProgrammaticApiException$str() {
/* 1925 */     return "HV000176: Constructor %2$s of type %1$s is configured more than once via the programmatic constraint declaration API.";
/*      */   }
/*      */   
/*      */   public final ValidationException getCrossParameterElementHasAlreadyBeConfiguredViaProgrammaticApiException(String beanClassName, String executable) {
/* 1929 */     ValidationException result = new ValidationException(String.format(getCrossParameterElementHasAlreadyBeConfiguredViaProgrammaticApiException$str(), new Object[] { beanClassName, executable }));
/* 1930 */     StackTraceElement[] st = result.getStackTrace();
/* 1931 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1932 */     return result;
/*      */   }
/*      */   
/*      */   protected String getCrossParameterElementHasAlreadyBeConfiguredViaProgrammaticApiException$str() {
/* 1936 */     return "HV000177: Cross-parameter constraints for the method or constructor %2$s of type %1$s are declared more than once via the programmatic constraint declaration API.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getMultiplierCannotBeNegativeException(int multiplier) {
/* 1940 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getMultiplierCannotBeNegativeException$str(), new Object[] { Integer.valueOf(multiplier) }));
/* 1941 */     StackTraceElement[] st = result.getStackTrace();
/* 1942 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1943 */     return result;
/*      */   }
/*      */   
/*      */   protected String getMultiplierCannotBeNegativeException$str() {
/* 1947 */     return "HV000178: Multiplier cannot be negative: %d.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getWeightCannotBeNegativeException(int weight) {
/* 1951 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getWeightCannotBeNegativeException$str(), new Object[] { Integer.valueOf(weight) }));
/* 1952 */     StackTraceElement[] st = result.getStackTrace();
/* 1953 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1954 */     return result;
/*      */   }
/*      */   
/*      */   protected String getWeightCannotBeNegativeException$str() {
/* 1958 */     return "HV000179: Weight cannot be negative: %d.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getTreatCheckAsIsNotADigitNorALetterException(int weight) {
/* 1962 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getTreatCheckAsIsNotADigitNorALetterException$str(), new Object[] { Integer.valueOf(weight) }));
/* 1963 */     StackTraceElement[] st = result.getStackTrace();
/* 1964 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1965 */     return result;
/*      */   }
/*      */   
/*      */   protected String getTreatCheckAsIsNotADigitNorALetterException$str() {
/* 1969 */     return "HV000180: '%c' is not a digit nor a letter.";
/*      */   }
/*      */   
/*      */   public final IllegalArgumentException getInvalidParameterCountForExecutableException(String executable, int expectedParameterCount, int actualParameterCount) {
/* 1973 */     IllegalArgumentException result = new IllegalArgumentException(String.format(getInvalidParameterCountForExecutableException$str(), new Object[] { executable, Integer.valueOf(expectedParameterCount), Integer.valueOf(actualParameterCount) }));
/* 1974 */     StackTraceElement[] st = result.getStackTrace();
/* 1975 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1976 */     return result;
/*      */   }
/*      */   
/*      */   protected String getInvalidParameterCountForExecutableException$str() {
/* 1980 */     return "HV000181: Wrong number of parameters. Method or constructor %1$s expects %2$d parameters, but got %3$d.";
/*      */   }
/*      */   
/*      */   public final ValidationException getNoUnwrapperFoundForTypeException(String typeName) {
/* 1984 */     ValidationException result = new ValidationException(String.format(getNoUnwrapperFoundForTypeException$str(), new Object[] { typeName }));
/* 1985 */     StackTraceElement[] st = result.getStackTrace();
/* 1986 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1987 */     return result;
/*      */   }
/*      */   
/*      */   protected String getNoUnwrapperFoundForTypeException$str() {
/* 1991 */     return "HV000182: No validation value unwrapper is registered for type '%1$s'.";
/*      */   }
/*      */   
/*      */   public final ValidationException getMissingELDependenciesException() {
/* 1995 */     ValidationException result = new ValidationException(String.format(getMissingELDependenciesException$str(), new Object[0]));
/* 1996 */     StackTraceElement[] st = result.getStackTrace();
/* 1997 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 1998 */     return result;
/*      */   }
/*      */   
/*      */   protected String getMissingELDependenciesException$str() {
/* 2002 */     return "HV000183: Unable to load 'javax.el.ExpressionFactory'. Check that you have the EL dependencies on the classpath, or use ParameterMessageInterpolator instead";
/*      */   }
/*      */   
/*      */   public final void creationOfParameterMessageInterpolation() {
/* 2006 */     this.log.logf(FQCN, Logger.Level.WARN, null, creationOfParameterMessageInterpolation$str(), new Object[0]);
/*      */   }
/*      */   
/*      */   protected String creationOfParameterMessageInterpolation$str() {
/* 2010 */     return "HV000184: ParameterMessageInterpolator has been chosen, EL interpolation will not be supported";
/*      */   }
/*      */   
/*      */   public final void getElUnsupported(String expression) {
/* 2014 */     this.log.logf(FQCN, Logger.Level.WARN, null, getElUnsupported$str(), expression);
/*      */   }
/*      */   
/*      */   protected String getElUnsupported$str() {
/* 2018 */     return "HV000185: Message contains EL expression: %1s, which is unsupported with chosen Interpolator";
/*      */   }
/*      */   
/*      */   public final UnexpectedTypeException getConstraintValidatorExistsForWrapperAndWrappedValueException(String property, String constraint, String valueHandler) {
/* 2022 */     UnexpectedTypeException result = new UnexpectedTypeException(String.format(getConstraintValidatorExistsForWrapperAndWrappedValueException$str(), new Object[] { property, constraint, valueHandler }));
/* 2023 */     StackTraceElement[] st = result.getStackTrace();
/* 2024 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 2025 */     return result;
/*      */   }
/*      */   
/*      */   protected String getConstraintValidatorExistsForWrapperAndWrappedValueException$str() {
/* 2029 */     return "HV000186: The constraint of type '%2$s' defined on '%1$s' has multiple matching constraint validators which is due to an additional value handler of type '%3$s'. It is unclear which value needs validating. Clarify configuration via @UnwrapValidatedValue.";
/*      */   }
/*      */   
/*      */   public final ValidationException getTypeAnnotationConstraintOnIterableRequiresUseOfValidAnnotationException(String declaringClass, String name) {
/* 2033 */     ValidationException result = new ValidationException(String.format(getTypeAnnotationConstraintOnIterableRequiresUseOfValidAnnotationException$str(), new Object[] { declaringClass, name }));
/* 2034 */     StackTraceElement[] st = result.getStackTrace();
/* 2035 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 2036 */     return result;
/*      */   }
/*      */   
/*      */   protected String getTypeAnnotationConstraintOnIterableRequiresUseOfValidAnnotationException$str() {
/* 2040 */     return "HV000187: When using type annotation constraints on parameterized iterables or map @Valid must be used. Check %s#%s";
/*      */   }
/*      */   
/*      */   public final void parameterizedTypeWithMoreThanOneTypeArgumentIsNotSupported(String type) {
/* 2044 */     this.log.logf(FQCN, Logger.Level.DEBUG, null, parameterizedTypeWithMoreThanOneTypeArgumentIsNotSupported$str(), type);
/*      */   }
/*      */   
/*      */   protected String parameterizedTypeWithMoreThanOneTypeArgumentIsNotSupported$str() {
/* 2048 */     return "HV000188: Parameterized type with more than one argument is not supported: %s";
/*      */   }
/*      */   
/*      */   public final ConstraintDeclarationException getInconsistentValueUnwrappingConfigurationBetweenFieldAndItsGetterException(String property, String clazz) {
/* 2052 */     ConstraintDeclarationException result = new ConstraintDeclarationException(String.format(getInconsistentValueUnwrappingConfigurationBetweenFieldAndItsGetterException$str(), new Object[] { property, clazz }));
/* 2053 */     StackTraceElement[] st = result.getStackTrace();
/* 2054 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 2055 */     return result;
/*      */   }
/*      */   
/*      */   protected String getInconsistentValueUnwrappingConfigurationBetweenFieldAndItsGetterException$str() {
/* 2059 */     return "HV000189: The configuration of value unwrapping for property '%s' of bean '%s' is inconsistent between the field and its getter.";
/*      */   }
/*      */   
/*      */   public final ValidationException getUnableToCreateXMLEventReader(String file, Exception e) {
/* 2063 */     ValidationException result = new ValidationException(String.format(getUnableToCreateXMLEventReader$str(), new Object[] { file }), e);
/* 2064 */     StackTraceElement[] st = result.getStackTrace();
/* 2065 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 2066 */     return result;
/*      */   }
/*      */   
/*      */   protected String getUnableToCreateXMLEventReader$str() {
/* 2070 */     return "HV000190: Unable to parse %s.";
/*      */   }
/*      */   
/*      */   public final ValidationException validatedValueUnwrapperCannotBeCreated(String className, Exception e) {
/* 2074 */     ValidationException result = new ValidationException(String.format(validatedValueUnwrapperCannotBeCreated$str(), new Object[] { className }), e);
/* 2075 */     StackTraceElement[] st = result.getStackTrace();
/* 2076 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 2077 */     return result;
/*      */   }
/*      */   
/*      */   protected String validatedValueUnwrapperCannotBeCreated$str() {
/* 2081 */     return "HV000191: Error creating unwrapper: %s";
/*      */   }
/*      */   
/*      */   public final void unknownJvmVersion(String vmVersionStr) {
/* 2085 */     this.log.logf(FQCN, Logger.Level.WARN, null, unknownJvmVersion$str(), vmVersionStr);
/*      */   }
/*      */   
/*      */   protected String unknownJvmVersion$str() {
/* 2089 */     return "HV000192: Couldn't determine Java version from value %1s; Not enabling features requiring Java 8";
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\util\logging\Log_$logger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */