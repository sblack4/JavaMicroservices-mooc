/*     */ package org.hibernate.validator.internal.metadata.provider;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.annotation.ElementType;
/*     */ import java.lang.reflect.AccessibleObject;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.validation.GroupSequence;
/*     */ import javax.validation.ParameterNameProvider;
/*     */ import javax.validation.Valid;
/*     */ import javax.validation.groups.ConvertGroup;
/*     */ import javax.validation.groups.ConvertGroup.List;
/*     */ import org.hibernate.validator.group.GroupSequenceProvider;
/*     */ import org.hibernate.validator.internal.engine.valuehandling.UnwrapMode;
/*     */ import org.hibernate.validator.internal.metadata.core.AnnotationProcessingOptions;
/*     */ import org.hibernate.validator.internal.metadata.core.AnnotationProcessingOptionsImpl;
/*     */ import org.hibernate.validator.internal.metadata.core.ConstraintHelper;
/*     */ import org.hibernate.validator.internal.metadata.core.MetaConstraint;
/*     */ import org.hibernate.validator.internal.metadata.descriptor.ConstraintDescriptorImpl;
/*     */ import org.hibernate.validator.internal.metadata.descriptor.ConstraintDescriptorImpl.ConstraintType;
/*     */ import org.hibernate.validator.internal.metadata.location.ConstraintLocation;
/*     */ import org.hibernate.validator.internal.metadata.raw.BeanConfiguration;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConfigurationSource;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedElement;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedExecutable;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedField;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedParameter;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedType;
/*     */ import org.hibernate.validator.internal.metadata.raw.ExecutableElement;
/*     */ import org.hibernate.validator.internal.util.CollectionHelper;
/*     */ import org.hibernate.validator.internal.util.CollectionHelper.Partitioner;
/*     */ import org.hibernate.validator.internal.util.ConcurrentReferenceHashMap;
/*     */ import org.hibernate.validator.internal.util.ConcurrentReferenceHashMap.ReferenceType;
/*     */ import org.hibernate.validator.internal.util.ReflectionHelper;
/*     */ import org.hibernate.validator.internal.util.classhierarchy.ClassHierarchyHelper;
/*     */ import org.hibernate.validator.internal.util.classhierarchy.Filter;
/*     */ import org.hibernate.validator.internal.util.logging.Log;
/*     */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*     */ import org.hibernate.validator.internal.util.privilegedactions.GetDeclaredConstructors;
/*     */ import org.hibernate.validator.internal.util.privilegedactions.GetDeclaredFields;
/*     */ import org.hibernate.validator.internal.util.privilegedactions.GetDeclaredMethods;
/*     */ import org.hibernate.validator.internal.util.privilegedactions.GetMethods;
/*     */ import org.hibernate.validator.internal.util.privilegedactions.NewInstance;
/*     */ import org.hibernate.validator.spi.group.DefaultGroupSequenceProvider;
/*     */ import org.hibernate.validator.valuehandling.UnwrapValidatedValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationMetaDataProvider
/*     */   implements MetaDataProvider
/*     */ {
/*  74 */   private static final Log log = ;
/*     */   
/*     */   static final int DEFAULT_INITIAL_CAPACITY = 16;
/*     */   
/*     */   protected final ConstraintHelper constraintHelper;
/*     */   
/*     */   protected final ConcurrentReferenceHashMap<Class<?>, BeanConfiguration<?>> configuredBeans;
/*     */   
/*     */   protected final AnnotationProcessingOptions annotationProcessingOptions;
/*     */   
/*     */   protected final ParameterNameProvider parameterNameProvider;
/*     */   
/*     */   public AnnotationMetaDataProvider(ConstraintHelper constraintHelper, ParameterNameProvider parameterNameProvider, AnnotationProcessingOptions annotationProcessingOptions)
/*     */   {
/*  88 */     this.constraintHelper = constraintHelper;
/*  89 */     this.parameterNameProvider = parameterNameProvider;
/*  90 */     this.annotationProcessingOptions = annotationProcessingOptions;
/*  91 */     this.configuredBeans = new ConcurrentReferenceHashMap(16, ConcurrentReferenceHashMap.ReferenceType.SOFT, ConcurrentReferenceHashMap.ReferenceType.SOFT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationProcessingOptions getAnnotationProcessingOptions()
/*     */   {
/* 100 */     return new AnnotationProcessingOptionsImpl();
/*     */   }
/*     */   
/*     */   public <T> List<BeanConfiguration<? super T>> getBeanConfigurationForHierarchy(Class<T> beanClass)
/*     */   {
/* 105 */     List<BeanConfiguration<? super T>> configurations = CollectionHelper.newArrayList();
/*     */     
/* 107 */     for (Class<? super T> hierarchyClass : ClassHierarchyHelper.getHierarchy(beanClass, new Filter[0])) {
/* 108 */       BeanConfiguration<? super T> configuration = getBeanConfiguration(hierarchyClass);
/* 109 */       if (configuration != null) {
/* 110 */         configurations.add(configuration);
/*     */       }
/*     */     }
/*     */     
/* 114 */     return configurations;
/*     */   }
/*     */   
/*     */   private <T> BeanConfiguration<T> getBeanConfiguration(Class<T> beanClass)
/*     */   {
/* 119 */     BeanConfiguration<T> configuration = (BeanConfiguration)this.configuredBeans.get(beanClass);
/*     */     
/* 121 */     if (configuration != null) {
/* 122 */       return configuration;
/*     */     }
/*     */     
/* 125 */     configuration = retrieveBeanConfiguration(beanClass);
/* 126 */     this.configuredBeans.put(beanClass, configuration);
/*     */     
/* 128 */     return configuration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private <T> BeanConfiguration<T> retrieveBeanConfiguration(Class<T> beanClass)
/*     */   {
/* 137 */     Set<ConstrainedElement> constrainedElements = getFieldMetaData(beanClass);
/* 138 */     constrainedElements.addAll(getMethodMetaData(beanClass));
/* 139 */     constrainedElements.addAll(getConstructorMetaData(beanClass));
/*     */     
/*     */ 
/*     */ 
/* 143 */     Set<MetaConstraint<?>> classLevelConstraints = getClassLevelConstraints(beanClass);
/* 144 */     if (!classLevelConstraints.isEmpty())
/*     */     {
/*     */ 
/*     */ 
/* 148 */       ConstrainedType classLevelMetaData = new ConstrainedType(ConfigurationSource.ANNOTATION, ConstraintLocation.forClass(beanClass), classLevelConstraints);
/*     */       
/*     */ 
/* 151 */       constrainedElements.add(classLevelMetaData);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 159 */     return new BeanConfiguration(ConfigurationSource.ANNOTATION, beanClass, constrainedElements, getDefaultGroupSequence(beanClass), getDefaultGroupSequenceProvider(beanClass));
/*     */   }
/*     */   
/*     */   private List<Class<?>> getDefaultGroupSequence(Class<?> beanClass)
/*     */   {
/* 164 */     GroupSequence groupSequenceAnnotation = (GroupSequence)beanClass.getAnnotation(GroupSequence.class);
/* 165 */     return groupSequenceAnnotation != null ? Arrays.asList(groupSequenceAnnotation.value()) : null;
/*     */   }
/*     */   
/*     */   private <T> DefaultGroupSequenceProvider<? super T> getDefaultGroupSequenceProvider(Class<T> beanClass) {
/* 169 */     GroupSequenceProvider groupSequenceProviderAnnotation = (GroupSequenceProvider)beanClass.getAnnotation(GroupSequenceProvider.class);
/*     */     
/* 171 */     if (groupSequenceProviderAnnotation != null)
/*     */     {
/*     */ 
/* 174 */       Class<? extends DefaultGroupSequenceProvider<? super T>> providerClass = groupSequenceProviderAnnotation.value();
/* 175 */       return newGroupSequenceProviderClassInstance(beanClass, providerClass);
/*     */     }
/*     */     
/* 178 */     return null;
/*     */   }
/*     */   
/*     */   private <T> DefaultGroupSequenceProvider<? super T> newGroupSequenceProviderClassInstance(Class<T> beanClass, Class<? extends DefaultGroupSequenceProvider<? super T>> providerClass)
/*     */   {
/* 183 */     Method[] providerMethods = (Method[])run(GetMethods.action(providerClass));
/* 184 */     for (Method method : providerMethods) {
/* 185 */       Class<?>[] paramTypes = method.getParameterTypes();
/* 186 */       if (("getValidationGroups".equals(method.getName())) && (!method.isBridge()) && (paramTypes.length == 1) && 
/* 187 */         (paramTypes[0].isAssignableFrom(beanClass)))
/*     */       {
/* 189 */         return (DefaultGroupSequenceProvider)run(
/* 190 */           NewInstance.action(providerClass, "the default group sequence provider"));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 195 */     throw log.getWrongDefaultGroupSequenceProviderTypeException(beanClass.getName());
/*     */   }
/*     */   
/*     */   private Set<MetaConstraint<?>> getClassLevelConstraints(Class<?> clazz) {
/* 199 */     if (this.annotationProcessingOptions.areClassLevelConstraintsIgnoredFor(clazz)) {
/* 200 */       return Collections.emptySet();
/*     */     }
/*     */     
/* 203 */     Set<MetaConstraint<?>> classLevelConstraints = CollectionHelper.newHashSet();
/*     */     
/*     */ 
/* 206 */     List<ConstraintDescriptorImpl<?>> classMetaData = findClassLevelConstraints(clazz);
/*     */     
/* 208 */     for (ConstraintDescriptorImpl<?> constraintDescription : classMetaData) {
/* 209 */       classLevelConstraints.add(createMetaConstraint(clazz, constraintDescription));
/*     */     }
/*     */     
/* 212 */     return classLevelConstraints;
/*     */   }
/*     */   
/*     */   private Set<ConstrainedElement> getFieldMetaData(Class<?> beanClass) {
/* 216 */     Set<ConstrainedElement> propertyMetaData = CollectionHelper.newHashSet();
/*     */     
/* 218 */     for (Field field : (Field[])run(GetDeclaredFields.action(beanClass)))
/*     */     {
/* 220 */       if ((!Modifier.isStatic(field.getModifiers())) && 
/* 221 */         (!this.annotationProcessingOptions.areMemberConstraintsIgnoredFor(field)) && 
/* 222 */         (!field.isSynthetic()))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 227 */         propertyMetaData.add(findPropertyMetaData(field)); }
/*     */     }
/* 229 */     return propertyMetaData;
/*     */   }
/*     */   
/*     */   private ConstrainedField findPropertyMetaData(Field field) {
/* 233 */     Set<MetaConstraint<?>> constraints = convertToMetaConstraints(
/* 234 */       findConstraints(field, ElementType.FIELD), field);
/*     */     
/*     */ 
/*     */ 
/* 238 */     Map<Class<?>, Class<?>> groupConversions = getGroupConversions(
/* 239 */       (ConvertGroup)field.getAnnotation(ConvertGroup.class), 
/* 240 */       (ConvertGroup.List)field.getAnnotation(ConvertGroup.List.class));
/*     */     
/*     */ 
/* 243 */     boolean isCascading = field.isAnnotationPresent(Valid.class);
/* 244 */     Set<MetaConstraint<?>> typeArgumentsConstraints = findTypeAnnotationConstraintsForMember(field);
/*     */     
/* 246 */     boolean typeArgumentAnnotated = !typeArgumentsConstraints.isEmpty();
/* 247 */     UnwrapMode unwrapMode = unwrapMode(field, typeArgumentAnnotated);
/*     */     
/*     */ 
/*     */ 
/* 251 */     return new ConstrainedField(ConfigurationSource.ANNOTATION, ConstraintLocation.forProperty(field), constraints, typeArgumentsConstraints, groupConversions, isCascading, unwrapMode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private UnwrapMode unwrapMode(Field field, boolean typeArgumentAnnotated)
/*     */   {
/* 261 */     boolean notIterable = !ReflectionHelper.isIterable(ReflectionHelper.typeOf(field));
/* 262 */     UnwrapValidatedValue unwrapValidatedValue = (UnwrapValidatedValue)field.getAnnotation(UnwrapValidatedValue.class);
/* 263 */     return unwrapMode(typeArgumentAnnotated, notIterable, unwrapValidatedValue);
/*     */   }
/*     */   
/*     */   private UnwrapMode unwrapMode(ExecutableElement executable, boolean typeArgumentAnnotated) {
/* 267 */     boolean notIterable = !ReflectionHelper.isIterable(ReflectionHelper.typeOf(executable.getMember()));
/* 268 */     UnwrapValidatedValue unwrapValidatedValue = (UnwrapValidatedValue)executable.getAccessibleObject().getAnnotation(UnwrapValidatedValue.class);
/* 269 */     return unwrapMode(typeArgumentAnnotated, notIterable, unwrapValidatedValue);
/*     */   }
/*     */   
/*     */   private Set<MetaConstraint<?>> convertToMetaConstraints(List<ConstraintDescriptorImpl<?>> constraintDescriptors, Field field) {
/* 273 */     Set<MetaConstraint<?>> constraints = CollectionHelper.newHashSet();
/*     */     
/* 275 */     for (ConstraintDescriptorImpl<?> constraintDescription : constraintDescriptors) {
/* 276 */       constraints.add(createMetaConstraint(field, constraintDescription));
/*     */     }
/* 278 */     return constraints;
/*     */   }
/*     */   
/*     */   private UnwrapMode unwrapMode(boolean typeArgumentAnnotated, boolean notIterable, UnwrapValidatedValue unwrapValidatedValue) {
/* 282 */     if ((unwrapValidatedValue == null) && (typeArgumentAnnotated) && (notIterable))
/*     */     {
/*     */ 
/*     */ 
/* 286 */       return UnwrapMode.UNWRAP;
/*     */     }
/* 288 */     if (unwrapValidatedValue != null)
/*     */     {
/*     */ 
/*     */ 
/* 292 */       return unwrapValidatedValue.value() ? UnwrapMode.UNWRAP : UnwrapMode.SKIP_UNWRAP;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 299 */     return UnwrapMode.AUTOMATIC;
/*     */   }
/*     */   
/*     */   private Set<ConstrainedExecutable> getConstructorMetaData(Class<?> clazz) {
/* 303 */     List<ExecutableElement> declaredConstructors = ExecutableElement.forConstructors(
/* 304 */       (Constructor[])run(GetDeclaredConstructors.action(clazz)));
/*     */     
/*     */ 
/* 307 */     return getMetaData(declaredConstructors);
/*     */   }
/*     */   
/*     */   private Set<ConstrainedExecutable> getMethodMetaData(Class<?> clazz) {
/* 311 */     List<ExecutableElement> declaredMethods = ExecutableElement.forMethods(
/* 312 */       (Method[])run(GetDeclaredMethods.action(clazz)));
/*     */     
/*     */ 
/* 315 */     return getMetaData(declaredMethods);
/*     */   }
/*     */   
/*     */   private Set<ConstrainedExecutable> getMetaData(List<ExecutableElement> executableElements) {
/* 319 */     Set<ConstrainedExecutable> executableMetaData = CollectionHelper.newHashSet();
/*     */     
/* 321 */     for (ExecutableElement executable : executableElements)
/*     */     {
/*     */ 
/* 324 */       Member member = executable.getMember();
/* 325 */       if ((!Modifier.isStatic(member.getModifiers())) && (!member.isSynthetic()))
/*     */       {
/*     */ 
/*     */ 
/* 329 */         executableMetaData.add(findExecutableMetaData(executable));
/*     */       }
/*     */     }
/* 332 */     return executableMetaData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ConstrainedExecutable findExecutableMetaData(ExecutableElement executable)
/*     */   {
/* 344 */     List<ConstrainedParameter> parameterConstraints = getParameterMetaData(executable);
/*     */     
/* 346 */     AccessibleObject member = executable.getAccessibleObject();
/*     */     
/* 348 */     Map<ConstraintDescriptorImpl.ConstraintType, List<ConstraintDescriptorImpl<?>>> executableConstraints = CollectionHelper.partition(
/* 349 */       findConstraints(executable
/* 350 */       .getMember(), executable
/* 351 */       .getElementType()), 
/* 352 */       byType());
/*     */     
/*     */     Set<MetaConstraint<?>> crossParameterConstraints;
/*     */     Set<MetaConstraint<?>> crossParameterConstraints;
/* 356 */     if (this.annotationProcessingOptions.areCrossParameterConstraintsIgnoredFor(executable.getMember())) {
/* 357 */       crossParameterConstraints = Collections.emptySet();
/*     */     }
/*     */     else {
/* 360 */       crossParameterConstraints = convertToMetaConstraints(
/* 361 */         (List)executableConstraints.get(ConstraintDescriptorImpl.ConstraintType.CROSS_PARAMETER), executable);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 371 */     UnwrapMode unwrapMode = UnwrapMode.AUTOMATIC;
/* 372 */     boolean isCascading; Set<MetaConstraint<?>> typeArgumentsConstraints; Set<MetaConstraint<?>> returnValueConstraints; Map<Class<?>, Class<?>> groupConversions; boolean isCascading; if (this.annotationProcessingOptions.areReturnValueConstraintsIgnoredFor(executable.getMember())) {
/* 373 */       Set<MetaConstraint<?>> returnValueConstraints = Collections.emptySet();
/* 374 */       Set<MetaConstraint<?>> typeArgumentsConstraints = Collections.emptySet();
/* 375 */       Map<Class<?>, Class<?>> groupConversions = Collections.emptyMap();
/* 376 */       isCascading = false;
/*     */     }
/*     */     else {
/* 379 */       typeArgumentsConstraints = findTypeAnnotationConstraintsForMember(executable.getMember());
/* 380 */       boolean typeArgumentAnnotated = !typeArgumentsConstraints.isEmpty();
/* 381 */       unwrapMode = unwrapMode(executable, typeArgumentAnnotated);
/* 382 */       returnValueConstraints = convertToMetaConstraints(
/* 383 */         (List)executableConstraints.get(ConstraintDescriptorImpl.ConstraintType.GENERIC), executable);
/*     */       
/*     */ 
/* 386 */       groupConversions = getGroupConversions(
/* 387 */         (ConvertGroup)member.getAnnotation(ConvertGroup.class), 
/* 388 */         (ConvertGroup.List)member.getAnnotation(ConvertGroup.List.class));
/*     */       
/* 390 */       isCascading = executable.getAccessibleObject().isAnnotationPresent(Valid.class);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 395 */     return new ConstrainedExecutable(ConfigurationSource.ANNOTATION, ConstraintLocation.forReturnValue(executable), parameterConstraints, crossParameterConstraints, returnValueConstraints, typeArgumentsConstraints, groupConversions, isCascading, unwrapMode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Set<MetaConstraint<?>> convertToMetaConstraints(List<ConstraintDescriptorImpl<?>> constraintsDescriptors, ExecutableElement executable)
/*     */   {
/* 407 */     if (constraintsDescriptors == null) {
/* 408 */       return Collections.emptySet();
/*     */     }
/*     */     
/* 411 */     Set<MetaConstraint<?>> constraints = CollectionHelper.newHashSet();
/*     */     
/* 413 */     for (ConstraintDescriptorImpl<?> constraintDescriptor : constraintsDescriptors) {
/* 414 */       constraints.add(constraintDescriptor
/* 415 */         .getConstraintType() == ConstraintDescriptorImpl.ConstraintType.GENERIC ? 
/* 416 */         createReturnValueMetaConstraint(executable, constraintDescriptor) : 
/* 417 */         createCrossParameterMetaConstraint(executable, constraintDescriptor));
/*     */     }
/*     */     
/*     */ 
/* 421 */     return constraints;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<ConstrainedParameter> getParameterMetaData(ExecutableElement executable)
/*     */   {
/* 433 */     List<ConstrainedParameter> metaData = CollectionHelper.newArrayList();
/*     */     
/* 435 */     List<String> parameterNames = executable.getParameterNames(this.parameterNameProvider);
/* 436 */     int i = 0;
/* 437 */     for (Annotation[] parameterAnnotations : executable.getParameterAnnotations()) {
/* 438 */       boolean parameterIsCascading = false;
/* 439 */       String parameterName = (String)parameterNames.get(i);
/* 440 */       Set<MetaConstraint<?>> parameterConstraints = CollectionHelper.newHashSet();
/* 441 */       Set<MetaConstraint<?>> typeArgumentsConstraints = CollectionHelper.newHashSet();
/* 442 */       ConvertGroup groupConversion = null;
/* 443 */       ConvertGroup.List groupConversionList = null;
/*     */       
/* 445 */       if (this.annotationProcessingOptions.areParameterConstraintsIgnoredFor(executable.getMember(), i)) {
/* 446 */         metaData.add(new ConstrainedParameter(ConfigurationSource.ANNOTATION, 
/*     */         
/*     */ 
/* 449 */           ConstraintLocation.forParameter(executable, i), 
/* 450 */           ReflectionHelper.typeOf(executable, i), i, parameterName, parameterConstraints, typeArgumentsConstraints, 
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 455 */           getGroupConversions(groupConversion, groupConversionList), false, UnwrapMode.AUTOMATIC));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 460 */         i++;
/*     */       }
/*     */       else
/*     */       {
/* 464 */         UnwrapValidatedValue unwrapValidatedValue = null;
/* 465 */         for (Annotation parameterAnnotation : parameterAnnotations)
/*     */         {
/* 467 */           if (parameterAnnotation.annotationType().equals(Valid.class)) {
/* 468 */             parameterIsCascading = true;
/*     */ 
/*     */ 
/*     */           }
/* 472 */           else if (parameterAnnotation.annotationType().equals(ConvertGroup.class)) {
/* 473 */             groupConversion = (ConvertGroup)parameterAnnotation;
/*     */           }
/* 475 */           else if (parameterAnnotation.annotationType().equals(ConvertGroup.List.class)) {
/* 476 */             groupConversionList = (ConvertGroup.List)parameterAnnotation;
/*     */ 
/*     */ 
/*     */           }
/* 480 */           else if (parameterAnnotation.annotationType().equals(UnwrapValidatedValue.class)) {
/* 481 */             unwrapValidatedValue = (UnwrapValidatedValue)parameterAnnotation;
/*     */           }
/*     */           
/*     */ 
/* 485 */           List<ConstraintDescriptorImpl<?>> constraints = findConstraintAnnotations(executable
/* 486 */             .getMember(), parameterAnnotation, ElementType.PARAMETER);
/*     */           
/* 488 */           for (ConstraintDescriptorImpl<?> constraintDescriptorImpl : constraints) {
/* 489 */             parameterConstraints.add(
/* 490 */               createParameterMetaConstraint(executable, i, constraintDescriptorImpl));
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 495 */         typeArgumentsConstraints = findTypeAnnotationConstraintsForExecutableParameter(executable.getMember(), i);
/* 496 */         boolean typeArgumentAnnotated = !typeArgumentsConstraints.isEmpty();
/* 497 */         boolean notIterable = !ReflectionHelper.isIterable(ReflectionHelper.typeOf(executable, i));
/* 498 */         UnwrapMode unwrapMode = unwrapMode(typeArgumentAnnotated, notIterable, unwrapValidatedValue);
/*     */         
/* 500 */         metaData.add(new ConstrainedParameter(ConfigurationSource.ANNOTATION, 
/*     */         
/*     */ 
/* 503 */           ConstraintLocation.forParameter(executable, i), 
/* 504 */           ReflectionHelper.typeOf(executable, i), i, parameterName, parameterConstraints, typeArgumentsConstraints, 
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 509 */           getGroupConversions(groupConversion, groupConversionList), parameterIsCascading, unwrapMode));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 514 */         i++;
/*     */       }
/*     */     }
/* 517 */     return metaData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<ConstraintDescriptorImpl<?>> findConstraints(Member member, ElementType type)
/*     */   {
/* 530 */     List<ConstraintDescriptorImpl<?>> metaData = CollectionHelper.newArrayList();
/* 531 */     for (Annotation annotation : ((AccessibleObject)member).getDeclaredAnnotations()) {
/* 532 */       metaData.addAll(findConstraintAnnotations(member, annotation, type));
/*     */     }
/*     */     
/* 535 */     return metaData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<ConstraintDescriptorImpl<?>> findClassLevelConstraints(Class<?> beanClass)
/*     */   {
/* 547 */     List<ConstraintDescriptorImpl<?>> metaData = CollectionHelper.newArrayList();
/* 548 */     for (Annotation annotation : beanClass.getDeclaredAnnotations()) {
/* 549 */       metaData.addAll(findConstraintAnnotations(null, annotation, ElementType.TYPE));
/*     */     }
/* 551 */     return metaData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected <A extends Annotation> List<ConstraintDescriptorImpl<?>> findConstraintAnnotations(Member member, A annotation, ElementType type)
/*     */   {
/* 571 */     if (annotation.annotationType().getPackage().getName().equals("jdk.internal")) {
/* 572 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 575 */     List<ConstraintDescriptorImpl<?>> constraintDescriptors = CollectionHelper.newArrayList();
/*     */     
/* 577 */     List<Annotation> constraints = CollectionHelper.newArrayList();
/* 578 */     Class<? extends Annotation> annotationType = annotation.annotationType();
/* 579 */     if (this.constraintHelper.isConstraintAnnotation(annotationType)) {
/* 580 */       constraints.add(annotation);
/*     */     }
/* 582 */     else if (this.constraintHelper.isMultiValueConstraint(annotationType)) {
/* 583 */       constraints.addAll(this.constraintHelper.getConstraintsFromMultiValueConstraint(annotation));
/*     */     }
/*     */     
/* 586 */     for (Annotation constraint : constraints) {
/* 587 */       ConstraintDescriptorImpl<?> constraintDescriptor = buildConstraintDescriptor(member, constraint, type);
/*     */       
/*     */ 
/* 590 */       constraintDescriptors.add(constraintDescriptor);
/*     */     }
/* 592 */     return constraintDescriptors;
/*     */   }
/*     */   
/*     */   private Map<Class<?>, Class<?>> getGroupConversions(ConvertGroup groupConversion, ConvertGroup.List groupConversionList) {
/* 596 */     Map<Class<?>, Class<?>> groupConversions = CollectionHelper.newHashMap();
/*     */     
/* 598 */     if (groupConversion != null) {
/* 599 */       groupConversions.put(groupConversion.from(), groupConversion.to());
/*     */     }
/*     */     
/* 602 */     if (groupConversionList != null) {
/* 603 */       for (ConvertGroup conversion : groupConversionList.value()) {
/* 604 */         if (groupConversions.containsKey(conversion.from())) {
/* 605 */           throw log.getMultipleGroupConversionsForSameSourceException(conversion
/* 606 */             .from(), 
/* 607 */             CollectionHelper.asSet(new Class[] {
/* 608 */             (Class)groupConversions.get(conversion.from()), conversion
/* 609 */             .to() }));
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 614 */         groupConversions.put(conversion.from(), conversion.to());
/*     */       }
/*     */     }
/*     */     
/* 618 */     return groupConversions;
/*     */   }
/*     */   
/*     */   private CollectionHelper.Partitioner<ConstraintDescriptorImpl.ConstraintType, ConstraintDescriptorImpl<?>> byType() {
/* 622 */     new CollectionHelper.Partitioner()
/*     */     {
/*     */       public ConstraintDescriptorImpl.ConstraintType getPartition(ConstraintDescriptorImpl<?> v)
/*     */       {
/* 626 */         return v.getConstraintType();
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   private <A extends Annotation> MetaConstraint<?> createMetaConstraint(Class<?> declaringClass, ConstraintDescriptorImpl<A> descriptor)
/*     */   {
/* 633 */     return new MetaConstraint(descriptor, ConstraintLocation.forClass(declaringClass));
/*     */   }
/*     */   
/*     */   private <A extends Annotation> MetaConstraint<?> createMetaConstraint(Member member, ConstraintDescriptorImpl<A> descriptor) {
/* 637 */     return new MetaConstraint(descriptor, ConstraintLocation.forProperty(member));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private <A extends Annotation> MetaConstraint<A> createParameterMetaConstraint(ExecutableElement member, int parameterIndex, ConstraintDescriptorImpl<A> descriptor)
/*     */   {
/* 644 */     return new MetaConstraint(descriptor, ConstraintLocation.forParameter(member, parameterIndex));
/*     */   }
/*     */   
/*     */ 
/*     */   private <A extends Annotation> MetaConstraint<A> createReturnValueMetaConstraint(ExecutableElement member, ConstraintDescriptorImpl<A> descriptor)
/*     */   {
/* 650 */     return new MetaConstraint(descriptor, ConstraintLocation.forReturnValue(member));
/*     */   }
/*     */   
/*     */   private <A extends Annotation> MetaConstraint<A> createCrossParameterMetaConstraint(ExecutableElement member, ConstraintDescriptorImpl<A> descriptor)
/*     */   {
/* 655 */     return new MetaConstraint(descriptor, ConstraintLocation.forCrossParameter(member));
/*     */   }
/*     */   
/*     */ 
/*     */   private <A extends Annotation> ConstraintDescriptorImpl<A> buildConstraintDescriptor(Member member, A annotation, ElementType type)
/*     */   {
/* 661 */     return new ConstraintDescriptorImpl(this.constraintHelper, member, annotation, type);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private <T> T run(PrivilegedAction<T> action)
/*     */   {
/* 676 */     return (T)(System.getSecurityManager() != null ? AccessController.doPrivileged(action) : action.run());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Set<MetaConstraint<?>> findTypeAnnotationConstraintsForMember(Member member)
/*     */   {
/* 688 */     return Collections.emptySet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Set<MetaConstraint<?>> findTypeAnnotationConstraintsForExecutableParameter(Member member, int i)
/*     */   {
/* 701 */     return Collections.emptySet();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\metadata\provider\AnnotationMetaDataProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */