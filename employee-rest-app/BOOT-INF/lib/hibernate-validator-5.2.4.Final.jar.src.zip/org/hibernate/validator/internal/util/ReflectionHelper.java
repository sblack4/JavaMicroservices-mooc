/*     */ package org.hibernate.validator.internal.util;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.lang.reflect.WildcardType;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.hibernate.validator.internal.metadata.raw.ExecutableElement;
/*     */ import org.hibernate.validator.internal.util.logging.Log;
/*     */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReflectionHelper
/*     */ {
/*     */   private static final String PROPERTY_ACCESSOR_PREFIX_GET = "get";
/*     */   private static final String PROPERTY_ACCESSOR_PREFIX_IS = "is";
/*     */   private static final String PROPERTY_ACCESSOR_PREFIX_HAS = "has";
/*  43 */   public static final String[] PROPERTY_ACCESSOR_PREFIXES = { "get", "is", "has" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  49 */   private static final Log log = LoggerFactory.make();
/*     */   private static final Map<Class<?>, Class<?>> PRIMITIVE_TO_WRAPPER_TYPES;
/*     */   private static final Map<Class<?>, Class<?>> WRAPPER_TO_PRIMITIVE_TYPES;
/*     */   
/*     */   static {
/*  54 */     Map<Class<?>, Class<?>> tmpMap = CollectionHelper.newHashMap(9);
/*     */     
/*  56 */     tmpMap.put(Boolean.TYPE, Boolean.class);
/*  57 */     tmpMap.put(Character.TYPE, Character.class);
/*  58 */     tmpMap.put(Double.TYPE, Double.class);
/*  59 */     tmpMap.put(Float.TYPE, Float.class);
/*  60 */     tmpMap.put(Long.TYPE, Long.class);
/*  61 */     tmpMap.put(Integer.TYPE, Integer.class);
/*  62 */     tmpMap.put(Short.TYPE, Short.class);
/*  63 */     tmpMap.put(Byte.TYPE, Byte.class);
/*  64 */     tmpMap.put(Void.TYPE, Void.TYPE);
/*     */     
/*  66 */     PRIMITIVE_TO_WRAPPER_TYPES = Collections.unmodifiableMap(tmpMap);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */     Map<Class<?>, Class<?>> tmpMap = CollectionHelper.newHashMap(9);
/*     */     
/*  74 */     tmpMap.put(Boolean.class, Boolean.TYPE);
/*  75 */     tmpMap.put(Character.class, Character.TYPE);
/*  76 */     tmpMap.put(Double.class, Double.TYPE);
/*  77 */     tmpMap.put(Float.class, Float.TYPE);
/*  78 */     tmpMap.put(Long.class, Long.TYPE);
/*  79 */     tmpMap.put(Integer.class, Integer.TYPE);
/*  80 */     tmpMap.put(Short.class, Short.TYPE);
/*  81 */     tmpMap.put(Byte.class, Byte.TYPE);
/*  82 */     tmpMap.put(Void.TYPE, Void.TYPE);
/*     */     
/*  84 */     WRAPPER_TO_PRIMITIVE_TYPES = Collections.unmodifiableMap(tmpMap);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getPropertyName(Member member)
/*     */   {
/* 116 */     String name = null;
/*     */     
/* 118 */     if ((member instanceof Field)) {
/* 119 */       name = member.getName();
/*     */     }
/*     */     
/* 122 */     if ((member instanceof Method)) {
/* 123 */       String methodName = member.getName();
/* 124 */       for (String prefix : PROPERTY_ACCESSOR_PREFIXES) {
/* 125 */         if (methodName.startsWith(prefix)) {
/* 126 */           name = StringHelper.decapitalize(methodName.substring(prefix.length()));
/*     */         }
/*     */       }
/*     */     }
/* 130 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isGetterMethod(Method method)
/*     */   {
/* 150 */     if (method.getParameterTypes().length != 0) {
/* 151 */       return false;
/*     */     }
/*     */     
/* 154 */     String methodName = method.getName();
/*     */     
/*     */ 
/* 157 */     if ((methodName.startsWith("get")) && (method.getReturnType() != Void.TYPE)) {
/* 158 */       return true;
/*     */     }
/*     */     
/* 161 */     if ((methodName.startsWith("is")) && (method.getReturnType() == Boolean.TYPE)) {
/* 162 */       return true;
/*     */     }
/*     */     
/* 165 */     if ((methodName.startsWith("has")) && (method.getReturnType() == Boolean.TYPE)) {
/* 166 */       return true;
/*     */     }
/*     */     
/* 169 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type typeOf(Member member)
/*     */   {
/*     */     Type type;
/*     */     
/*     */ 
/*     */ 
/* 181 */     if ((member instanceof Field)) {
/* 182 */       type = ((Field)member).getGenericType();
/*     */     } else { Type type;
/* 184 */       if ((member instanceof Method)) {
/* 185 */         type = ((Method)member).getGenericReturnType();
/*     */       } else { Type type;
/* 187 */         if ((member instanceof Constructor)) {
/* 188 */           type = member.getDeclaringClass();
/*     */         }
/*     */         else
/*     */         {
/* 192 */           throw log.getMemberIsNeitherAFieldNorAMethodException(member); } } }
/*     */     Type type;
/* 194 */     if ((type instanceof TypeVariable)) {
/* 195 */       type = TypeHelper.getErasedType(type);
/*     */     }
/* 197 */     return type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type typeOf(ExecutableElement executable, int parameterIndex)
/*     */   {
/* 209 */     Type[] genericParameterTypes = executable.getGenericParameterTypes();
/*     */     
/*     */ 
/* 212 */     if (parameterIndex >= genericParameterTypes.length) {
/* 213 */       genericParameterTypes = executable.getParameterTypes();
/*     */     }
/*     */     
/* 216 */     Type type = genericParameterTypes[parameterIndex];
/*     */     
/* 218 */     if ((type instanceof TypeVariable)) {
/* 219 */       type = TypeHelper.getErasedType(type);
/*     */     }
/* 221 */     return type;
/*     */   }
/*     */   
/*     */   public static Object getValue(Member member, Object object) {
/* 225 */     if ((member instanceof Method)) {
/* 226 */       return getValue((Method)member, object);
/*     */     }
/* 228 */     if ((member instanceof Field)) {
/* 229 */       return getValue((Field)member, object);
/*     */     }
/* 231 */     return null;
/*     */   }
/*     */   
/*     */   public static Object getValue(Field field, Object object) {
/*     */     try {
/* 236 */       return field.get(object);
/*     */     }
/*     */     catch (IllegalAccessException e) {
/* 239 */       throw log.getUnableToAccessMemberException(field.getName(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Object getValue(Method method, Object object) {
/*     */     try {
/* 245 */       return method.invoke(object, new Object[0]);
/*     */     }
/*     */     catch (IllegalAccessException e) {
/* 248 */       throw log.getUnableToAccessMemberException(method.getName(), e);
/*     */     }
/*     */     catch (InvocationTargetException e) {
/* 251 */       throw log.getUnableToAccessMemberException(method.getName(), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type getIndexedType(Type type)
/*     */   {
/* 264 */     Type indexedType = null;
/* 265 */     if ((isIterable(type)) && ((type instanceof ParameterizedType))) {
/* 266 */       ParameterizedType paramType = (ParameterizedType)type;
/* 267 */       indexedType = paramType.getActualTypeArguments()[0];
/*     */     }
/* 269 */     else if ((isMap(type)) && ((type instanceof ParameterizedType))) {
/* 270 */       ParameterizedType paramType = (ParameterizedType)type;
/* 271 */       indexedType = paramType.getActualTypeArguments()[1];
/*     */     }
/* 273 */     else if (TypeHelper.isArray(type)) {
/* 274 */       indexedType = TypeHelper.getComponentType(type);
/*     */     }
/* 276 */     return indexedType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isIterable(Type type)
/*     */   {
/* 285 */     if (((type instanceof Class)) && (Iterable.class.isAssignableFrom((Class)type))) {
/* 286 */       return true;
/*     */     }
/* 288 */     if ((type instanceof ParameterizedType)) {
/* 289 */       return isIterable(((ParameterizedType)type).getRawType());
/*     */     }
/* 291 */     if ((type instanceof WildcardType)) {
/* 292 */       Type[] upperBounds = ((WildcardType)type).getUpperBounds();
/* 293 */       return (upperBounds.length != 0) && (isIterable(upperBounds[0]));
/*     */     }
/* 295 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isMap(Type type)
/*     */   {
/* 304 */     if (((type instanceof Class)) && (Map.class.isAssignableFrom((Class)type))) {
/* 305 */       return true;
/*     */     }
/* 307 */     if ((type instanceof ParameterizedType)) {
/* 308 */       return isMap(((ParameterizedType)type).getRawType());
/*     */     }
/* 310 */     if ((type instanceof WildcardType)) {
/* 311 */       Type[] upperBounds = ((WildcardType)type).getUpperBounds();
/* 312 */       return (upperBounds.length != 0) && (isMap(upperBounds[0]));
/*     */     }
/* 314 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isList(Type type)
/*     */   {
/* 323 */     if (((type instanceof Class)) && (List.class.isAssignableFrom((Class)type))) {
/* 324 */       return true;
/*     */     }
/* 326 */     if ((type instanceof ParameterizedType)) {
/* 327 */       return isList(((ParameterizedType)type).getRawType());
/*     */     }
/* 329 */     if ((type instanceof WildcardType)) {
/* 330 */       Type[] upperBounds = ((WildcardType)type).getUpperBounds();
/* 331 */       return (upperBounds.length != 0) && (isList(upperBounds[0]));
/*     */     }
/* 333 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getIndexedValue(Object value, Integer index)
/*     */   {
/* 348 */     if (value == null) {
/* 349 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 353 */     Type type = value.getClass();
/* 354 */     Iterator<?> iter; if (isIterable(type)) {
/* 355 */       iter = ((Iterable)value).iterator();
/*     */     } else { Iterator<?> iter;
/* 357 */       if (TypeHelper.isArray(type)) {
/* 358 */         List<?> arrayList = Arrays.asList(new Object[] { value });
/* 359 */         iter = arrayList.iterator();
/*     */       }
/*     */       else {
/* 362 */         return null;
/*     */       } }
/*     */     Iterator<?> iter;
/* 365 */     int i = 0;
/*     */     
/* 367 */     while (iter.hasNext()) {
/* 368 */       Object o = iter.next();
/* 369 */       if (i == index.intValue()) {
/* 370 */         return o;
/*     */       }
/* 372 */       i++;
/*     */     }
/* 374 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getMappedValue(Object value, Object key)
/*     */   {
/* 387 */     if (!(value instanceof Map)) {
/* 388 */       return null;
/*     */     }
/*     */     
/* 391 */     Map<?, ?> map = (Map)value;
/*     */     
/* 393 */     return map.get(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> boxedType(Class<?> primitiveType)
/*     */   {
/* 409 */     Class<?> wrapperType = (Class)PRIMITIVE_TO_WRAPPER_TYPES.get(primitiveType);
/*     */     
/* 411 */     if (wrapperType == null) {
/* 412 */       throw log.getHasToBeAPrimitiveTypeException(primitiveType.getClass());
/*     */     }
/*     */     
/* 415 */     return wrapperType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> unBoxedType(Class<?> type)
/*     */   {
/* 431 */     Class<?> wrapperType = (Class)WRAPPER_TO_PRIMITIVE_TYPES.get(type);
/*     */     
/* 433 */     if (wrapperType == null) {
/* 434 */       throw log.getHasToBeABoxedTypeException(type.getClass());
/*     */     }
/*     */     
/* 437 */     return wrapperType;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\util\ReflectionHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */