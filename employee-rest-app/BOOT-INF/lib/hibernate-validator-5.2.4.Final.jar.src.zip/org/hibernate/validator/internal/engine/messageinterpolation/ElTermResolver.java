/*     */ package org.hibernate.validator.internal.engine.messageinterpolation;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.el.ELException;
/*     */ import javax.el.ExpressionFactory;
/*     */ import javax.el.PropertyNotFoundException;
/*     */ import javax.el.ValueExpression;
/*     */ import javax.validation.MessageInterpolator.Context;
/*     */ import javax.validation.metadata.ConstraintDescriptor;
/*     */ import org.hibernate.validator.internal.engine.MessageInterpolatorContext;
/*     */ import org.hibernate.validator.internal.engine.messageinterpolation.el.SimpleELContext;
/*     */ import org.hibernate.validator.internal.util.logging.Log;
/*     */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ElTermResolver
/*     */   implements TermResolver
/*     */ {
/*  31 */   private static final Log log = ;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String VALIDATED_VALUE_NAME = "validatedValue";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Locale locale;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  49 */   private static final ExpressionFactory expressionFactory = ExpressionFactory.newInstance();
/*     */   
/*     */   public ElTermResolver(Locale locale)
/*     */   {
/*  53 */     this.locale = locale;
/*     */   }
/*     */   
/*     */   public String interpolate(MessageInterpolator.Context context, String expression)
/*     */   {
/*  58 */     String resolvedExpression = expression;
/*  59 */     SimpleELContext elContext = new SimpleELContext();
/*     */     try {
/*  61 */       ValueExpression valueExpression = bindContextValues(expression, context, elContext);
/*  62 */       resolvedExpression = (String)valueExpression.getValue(elContext);
/*     */     }
/*     */     catch (PropertyNotFoundException pnfe) {
/*  65 */       log.unknownPropertyInExpressionLanguage(expression, pnfe);
/*     */     }
/*     */     catch (ELException e) {
/*  68 */       log.errorInExpressionLanguage(expression, e);
/*     */     }
/*     */     catch (Exception e) {
/*  71 */       log.evaluatingExpressionLanguageExpressionCausedException(expression, e);
/*     */     }
/*     */     
/*  74 */     return resolvedExpression;
/*     */   }
/*     */   
/*     */   private ValueExpression bindContextValues(String messageTemplate, MessageInterpolator.Context messageInterpolatorContext, SimpleELContext elContext)
/*     */   {
/*  79 */     ValueExpression valueExpression = expressionFactory.createValueExpression(messageInterpolatorContext
/*  80 */       .getValidatedValue(), Object.class);
/*     */     
/*     */ 
/*  83 */     elContext.setVariable("validatedValue", valueExpression);
/*     */     
/*     */ 
/*  86 */     valueExpression = expressionFactory.createValueExpression(new FormatterWrapper(this.locale), FormatterWrapper.class);
/*     */     
/*     */ 
/*     */ 
/*  90 */     elContext.setVariable("formatter", valueExpression);
/*     */     
/*     */ 
/*  93 */     for (Iterator localIterator = messageInterpolatorContext.getConstraintDescriptor()
/*  94 */           .getAttributes()
/*  95 */           .entrySet().iterator(); localIterator.hasNext();) { entry = (Map.Entry)localIterator.next();
/*     */       
/*     */ 
/*  96 */       valueExpression = expressionFactory.createValueExpression(entry.getValue(), Object.class);
/*  97 */       elContext.setVariable((String)entry.getKey(), valueExpression);
/*     */     }
/*     */     
/*     */     Map.Entry<String, Object> entry;
/* 101 */     if ((messageInterpolatorContext instanceof MessageInterpolatorContext)) {
/* 102 */       MessageInterpolatorContext internalContext = (MessageInterpolatorContext)messageInterpolatorContext;
/* 103 */       for (Map.Entry<String, Object> entry : internalContext.getMessageParameters().entrySet()) {
/* 104 */         valueExpression = expressionFactory.createValueExpression(entry.getValue(), Object.class);
/* 105 */         elContext.setVariable((String)entry.getKey(), valueExpression);
/*     */       }
/*     */     }
/*     */     
/* 109 */     return expressionFactory.createValueExpression(elContext, messageTemplate, String.class);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\engine\messageinterpolation\ElTermResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */