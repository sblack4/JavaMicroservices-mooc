/*     */ package org.hibernate.validator.internal.xml;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.List;
/*     */ import javax.validation.Payload;
/*     */ import javax.validation.ValidationException;
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import org.hibernate.validator.internal.metadata.core.ConstraintHelper;
/*     */ import org.hibernate.validator.internal.metadata.core.MetaConstraint;
/*     */ import org.hibernate.validator.internal.metadata.descriptor.ConstraintDescriptorImpl;
/*     */ import org.hibernate.validator.internal.metadata.descriptor.ConstraintDescriptorImpl.ConstraintType;
/*     */ import org.hibernate.validator.internal.metadata.location.ConstraintLocation;
/*     */ import org.hibernate.validator.internal.util.CollectionHelper;
/*     */ import org.hibernate.validator.internal.util.annotationfactory.AnnotationDescriptor;
/*     */ import org.hibernate.validator.internal.util.annotationfactory.AnnotationFactory;
/*     */ import org.hibernate.validator.internal.util.logging.Log;
/*     */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*     */ import org.hibernate.validator.internal.util.privilegedactions.GetMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MetaConstraintBuilder
/*     */ {
/*  38 */   private static final Log log = ;
/*     */   
/*     */   private static final String MESSAGE_PARAM = "message";
/*     */   private static final String GROUPS_PARAM = "groups";
/*     */   private static final String PAYLOAD_PARAM = "payload";
/*     */   private final ClassLoadingHelper classLoadingHelper;
/*     */   private final ConstraintHelper constraintHelper;
/*     */   
/*     */   MetaConstraintBuilder(ClassLoadingHelper classLoadingHelper, ConstraintHelper constraintHelper)
/*     */   {
/*  48 */     this.classLoadingHelper = classLoadingHelper;
/*  49 */     this.constraintHelper = constraintHelper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   <A extends Annotation> MetaConstraint<A> buildMetaConstraint(ConstraintLocation constraintLocation, ConstraintType constraint, java.lang.annotation.ElementType type, String defaultPackage, ConstraintDescriptorImpl.ConstraintType constraintType)
/*     */   {
/*     */     try
/*     */     {
/*  60 */       annotationClass = this.classLoadingHelper.loadClass(constraint.getAnnotation(), defaultPackage);
/*     */     } catch (ValidationException e) {
/*     */       Class<A> annotationClass;
/*  63 */       throw log.getUnableToLoadConstraintAnnotationClassException(constraint.getAnnotation(), e); }
/*     */     Class<A> annotationClass;
/*  65 */     AnnotationDescriptor<A> annotationDescriptor = new AnnotationDescriptor(annotationClass);
/*     */     
/*  67 */     if (constraint.getMessage() != null) {
/*  68 */       annotationDescriptor.setValue("message", constraint.getMessage());
/*     */     }
/*  70 */     annotationDescriptor.setValue("groups", getGroups(constraint.getGroups(), defaultPackage));
/*  71 */     annotationDescriptor.setValue("payload", getPayload(constraint.getPayload(), defaultPackage));
/*     */     
/*  73 */     for (ElementType elementType : constraint.getElement()) {
/*  74 */       String name = elementType.getName();
/*  75 */       checkNameIsValid(name);
/*  76 */       Class<?> returnType = getAnnotationParameterType(annotationClass, name);
/*  77 */       Object elementValue = getElementValue(elementType, returnType, defaultPackage);
/*  78 */       annotationDescriptor.setValue(name, elementValue);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/*  83 */       annotation = AnnotationFactory.create(annotationDescriptor);
/*     */     } catch (RuntimeException e) {
/*     */       Object annotation;
/*  86 */       throw log.getUnableToCreateAnnotationForConfiguredConstraintException(e);
/*     */     }
/*     */     
/*     */ 
/*     */     A annotation;
/*     */     
/*  92 */     ConstraintDescriptorImpl<A> constraintDescriptor = new ConstraintDescriptorImpl(this.constraintHelper, constraintLocation.getMember(), annotation, type, constraintType);
/*     */     
/*     */ 
/*  95 */     return new MetaConstraint(constraintDescriptor, constraintLocation);
/*     */   }
/*     */   
/*     */   private <A extends Annotation> Annotation buildAnnotation(AnnotationType annotationType, Class<A> returnType, String defaultPackage) {
/*  99 */     AnnotationDescriptor<A> annotationDescriptor = new AnnotationDescriptor(returnType);
/* 100 */     for (ElementType elementType : annotationType.getElement()) {
/* 101 */       String name = elementType.getName();
/* 102 */       Class<?> parameterType = getAnnotationParameterType(returnType, name);
/* 103 */       Object elementValue = getElementValue(elementType, parameterType, defaultPackage);
/* 104 */       annotationDescriptor.setValue(name, elementValue);
/*     */     }
/* 106 */     return AnnotationFactory.create(annotationDescriptor);
/*     */   }
/*     */   
/*     */   private static void checkNameIsValid(String name) {
/* 110 */     if (("message".equals(name)) || ("groups".equals(name))) {
/* 111 */       throw log.getReservedParameterNamesException("message", "groups", "payload");
/*     */     }
/*     */   }
/*     */   
/*     */   private static <A extends Annotation> Class<?> getAnnotationParameterType(Class<A> annotationClass, String name) {
/* 116 */     Method m = (Method)run(GetMethod.action(annotationClass, name));
/* 117 */     if (m == null) {
/* 118 */       throw log.getAnnotationDoesNotContainAParameterException(annotationClass.getName(), name);
/*     */     }
/* 120 */     return m.getReturnType();
/*     */   }
/*     */   
/*     */   private Object getElementValue(ElementType elementType, Class<?> returnType, String defaultPackage) {
/* 124 */     removeEmptyContentElements(elementType);
/*     */     
/* 126 */     boolean isArray = returnType.isArray();
/* 127 */     if (!isArray) {
/* 128 */       if (elementType.getContent().size() != 1) {
/* 129 */         throw log.getAttemptToSpecifyAnArrayWhereSingleValueIsExpectedException();
/*     */       }
/* 131 */       return getSingleValue((Serializable)elementType.getContent().get(0), returnType, defaultPackage);
/*     */     }
/*     */     
/* 134 */     List<Object> values = CollectionHelper.newArrayList();
/* 135 */     for (Serializable s : elementType.getContent()) {
/* 136 */       values.add(getSingleValue(s, returnType.getComponentType(), defaultPackage));
/*     */     }
/* 138 */     return values.toArray((Object[])Array.newInstance(returnType.getComponentType(), values.size()));
/*     */   }
/*     */   
/*     */   private static void removeEmptyContentElements(ElementType elementType)
/*     */   {
/* 143 */     List<Serializable> contentToDelete = CollectionHelper.newArrayList();
/* 144 */     for (Serializable content : elementType.getContent()) {
/* 145 */       if (((content instanceof String)) && (((String)content).matches("[\\n ].*"))) {
/* 146 */         contentToDelete.add(content);
/*     */       }
/*     */     }
/* 149 */     elementType.getContent().removeAll(contentToDelete);
/*     */   }
/*     */   
/*     */   private Object getSingleValue(Serializable serializable, Class<?> returnType, String defaultPackage)
/*     */   {
/*     */     Object returnValue;
/* 155 */     if ((serializable instanceof String)) {
/* 156 */       String value = (String)serializable;
/* 157 */       returnValue = convertStringToReturnType(returnType, value, defaultPackage);
/*     */     } else { Object returnValue;
/* 159 */       if (((serializable instanceof JAXBElement)) && 
/* 160 */         (((JAXBElement)serializable).getDeclaredType().equals(String.class))) {
/* 161 */         JAXBElement<?> elem = (JAXBElement)serializable;
/* 162 */         String value = (String)elem.getValue();
/* 163 */         returnValue = convertStringToReturnType(returnType, value, defaultPackage);
/*     */       } else { Object returnValue;
/* 165 */         if (((serializable instanceof JAXBElement)) && 
/* 166 */           (((JAXBElement)serializable).getDeclaredType().equals(AnnotationType.class))) {
/* 167 */           JAXBElement<?> elem = (JAXBElement)serializable;
/* 168 */           AnnotationType annotationType = (AnnotationType)elem.getValue();
/*     */           try
/*     */           {
/* 171 */             Class<Annotation> annotationClass = returnType;
/* 172 */             returnValue = buildAnnotation(annotationType, annotationClass, defaultPackage);
/*     */           } catch (ClassCastException e) {
/*     */             Object returnValue;
/* 175 */             throw log.getUnexpectedParameterValueException(e);
/*     */           }
/*     */         }
/*     */         else {
/* 179 */           throw log.getUnexpectedParameterValueException(); } } }
/*     */     Object returnValue;
/* 181 */     return returnValue;
/*     */   }
/*     */   
/*     */ 
/*     */   private Object convertStringToReturnType(Class<?> returnType, String value, String defaultPackage)
/*     */   {
/* 187 */     if (returnType.getName().equals(Byte.TYPE.getName())) {
/*     */       try {
/* 189 */         returnValue = Byte.valueOf(Byte.parseByte(value));
/*     */       } catch (NumberFormatException e) {
/*     */         Object returnValue;
/* 192 */         throw log.getInvalidNumberFormatException("byte", e);
/*     */       }
/*     */     }
/* 195 */     else if (returnType.getName().equals(Short.TYPE.getName())) {
/*     */       try {
/* 197 */         returnValue = Short.valueOf(Short.parseShort(value));
/*     */       } catch (NumberFormatException e) {
/*     */         Object returnValue;
/* 200 */         throw log.getInvalidNumberFormatException("short", e);
/*     */       }
/*     */     }
/* 203 */     else if (returnType.getName().equals(Integer.TYPE.getName())) {
/*     */       try {
/* 205 */         returnValue = Integer.valueOf(Integer.parseInt(value));
/*     */       } catch (NumberFormatException e) {
/*     */         Object returnValue;
/* 208 */         throw log.getInvalidNumberFormatException("int", e);
/*     */       }
/*     */     }
/* 211 */     else if (returnType.getName().equals(Long.TYPE.getName())) {
/*     */       try {
/* 213 */         returnValue = Long.valueOf(Long.parseLong(value));
/*     */       } catch (NumberFormatException e) {
/*     */         Object returnValue;
/* 216 */         throw log.getInvalidNumberFormatException("long", e);
/*     */       }
/*     */     }
/* 219 */     else if (returnType.getName().equals(Float.TYPE.getName())) {
/*     */       try {
/* 221 */         returnValue = Float.valueOf(Float.parseFloat(value));
/*     */       } catch (NumberFormatException e) {
/*     */         Object returnValue;
/* 224 */         throw log.getInvalidNumberFormatException("float", e);
/*     */       }
/*     */     }
/* 227 */     else if (returnType.getName().equals(Double.TYPE.getName())) {
/*     */       try {
/* 229 */         returnValue = Double.valueOf(Double.parseDouble(value));
/*     */       } catch (NumberFormatException e) {
/*     */         Object returnValue;
/* 232 */         throw log.getInvalidNumberFormatException("double", e);
/*     */       }
/*     */     } else { Object returnValue;
/* 235 */       if (returnType.getName().equals(Boolean.TYPE.getName())) {
/* 236 */         returnValue = Boolean.valueOf(Boolean.parseBoolean(value));
/*     */       } else { Object returnValue;
/* 238 */         if (returnType.getName().equals(Character.TYPE.getName())) {
/* 239 */           if (value.length() != 1) {
/* 240 */             throw log.getInvalidCharValueException(value);
/*     */           }
/* 242 */           returnValue = Character.valueOf(value.charAt(0));
/*     */         } else { Object returnValue;
/* 244 */           if (returnType.getName().equals(String.class.getName())) {
/* 245 */             returnValue = value;
/*     */           } else { Object returnValue;
/* 247 */             if (returnType.getName().equals(Class.class.getName())) {
/* 248 */               returnValue = this.classLoadingHelper.loadClass(value, defaultPackage);
/*     */             }
/*     */             else
/*     */               try
/*     */               {
/* 253 */                 Class<Enum> enumClass = returnType;
/* 254 */                 returnValue = Enum.valueOf(enumClass, value);
/*     */               } catch (ClassCastException e) {
/*     */                 Object returnValue;
/* 257 */                 throw log.getInvalidReturnTypeException(returnType, e);
/*     */               } } } } }
/*     */     Object returnValue;
/* 260 */     return returnValue;
/*     */   }
/*     */   
/*     */   private Class<?>[] getGroups(GroupsType groupsType, String defaultPackage) {
/* 264 */     if (groupsType == null) {
/* 265 */       return new Class[0];
/*     */     }
/*     */     
/* 268 */     List<Class<?>> groupList = CollectionHelper.newArrayList();
/* 269 */     for (String groupClass : groupsType.getValue()) {
/* 270 */       groupList.add(this.classLoadingHelper.loadClass(groupClass, defaultPackage));
/*     */     }
/* 272 */     return (Class[])groupList.toArray(new Class[groupList.size()]);
/*     */   }
/*     */   
/*     */   private Class<? extends Payload>[] getPayload(PayloadType payloadType, String defaultPackage)
/*     */   {
/* 277 */     if (payloadType == null) {
/* 278 */       return new Class[0];
/*     */     }
/*     */     
/* 281 */     List<Class<? extends Payload>> payloadList = CollectionHelper.newArrayList();
/* 282 */     for (String groupClass : payloadType.getValue()) {
/* 283 */       Class<?> payload = this.classLoadingHelper.loadClass(groupClass, defaultPackage);
/* 284 */       if (!Payload.class.isAssignableFrom(payload)) {
/* 285 */         throw log.getWrongPayloadClassException(payload.getName());
/*     */       }
/*     */       
/* 288 */       payloadList.add(payload);
/*     */     }
/*     */     
/* 291 */     return (Class[])payloadList.toArray(new Class[payloadList.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static <T> T run(PrivilegedAction<T> action)
/*     */   {
/* 301 */     return (T)(System.getSecurityManager() != null ? AccessController.doPrivileged(action) : action.run());
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\xml\MetaConstraintBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */