/*     */ package org.hibernate.validator.internal.metadata.raw;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.hibernate.validator.internal.util.CollectionHelper;
/*     */ import org.hibernate.validator.spi.group.DefaultGroupSequenceProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanConfiguration<T>
/*     */ {
/*     */   private final ConfigurationSource source;
/*     */   private final Class<T> beanClass;
/*     */   private final Set<ConstrainedElement> constrainedElements;
/*     */   private final List<Class<?>> defaultGroupSequence;
/*     */   private final DefaultGroupSequenceProvider<? super T> defaultGroupSequenceProvider;
/*     */   
/*     */   public BeanConfiguration(ConfigurationSource source, Class<T> beanClass, Set<? extends ConstrainedElement> constrainedElements, List<Class<?>> defaultGroupSequence, DefaultGroupSequenceProvider<? super T> defaultGroupSequenceProvider)
/*     */   {
/*  55 */     this.source = source;
/*  56 */     this.beanClass = beanClass;
/*  57 */     this.constrainedElements = CollectionHelper.newHashSet(constrainedElements);
/*  58 */     this.defaultGroupSequence = defaultGroupSequence;
/*  59 */     this.defaultGroupSequenceProvider = defaultGroupSequenceProvider;
/*     */   }
/*     */   
/*     */   public ConfigurationSource getSource() {
/*  63 */     return this.source;
/*     */   }
/*     */   
/*     */   public Class<T> getBeanClass() {
/*  67 */     return this.beanClass;
/*     */   }
/*     */   
/*     */   public Set<ConstrainedElement> getConstrainedElements() {
/*  71 */     return this.constrainedElements;
/*     */   }
/*     */   
/*     */   public List<Class<?>> getDefaultGroupSequence() {
/*  75 */     return this.defaultGroupSequence;
/*     */   }
/*     */   
/*     */   public DefaultGroupSequenceProvider<? super T> getDefaultGroupSequenceProvider() {
/*  79 */     return this.defaultGroupSequenceProvider;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  84 */     return "BeanConfiguration [beanClass=" + this.beanClass.getSimpleName() + ", source=" + this.source + ", constrainedElements=" + this.constrainedElements + ", defaultGroupSequence=" + this.defaultGroupSequence + ", defaultGroupSequenceProvider=" + this.defaultGroupSequenceProvider + "]";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  94 */     int prime = 31;
/*  95 */     int result = 1;
/*     */     
/*  97 */     result = 31 * result + (this.beanClass == null ? 0 : this.beanClass.hashCode());
/*  98 */     result = 31 * result + (this.source == null ? 0 : this.source.hashCode());
/*  99 */     return result;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 104 */     if (this == obj) {
/* 105 */       return true;
/*     */     }
/* 107 */     if (obj == null) {
/* 108 */       return false;
/*     */     }
/* 110 */     if (getClass() != obj.getClass()) {
/* 111 */       return false;
/*     */     }
/* 113 */     BeanConfiguration<?> other = (BeanConfiguration)obj;
/* 114 */     if (this.beanClass == null) {
/* 115 */       if (other.beanClass != null) {
/* 116 */         return false;
/*     */       }
/*     */     }
/* 119 */     else if (!this.beanClass.equals(other.beanClass)) {
/* 120 */       return false;
/*     */     }
/* 122 */     if (this.source != other.source) {
/* 123 */       return false;
/*     */     }
/* 125 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\metadata\raw\BeanConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */