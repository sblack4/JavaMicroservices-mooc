/*     */ package org.hibernate.validator.internal.cfg.context;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.annotation.ElementType;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.hibernate.validator.cfg.ConstraintDef;
/*     */ import org.hibernate.validator.internal.metadata.location.ConstraintLocation;
/*     */ import org.hibernate.validator.internal.metadata.raw.ExecutableElement;
/*     */ import org.hibernate.validator.internal.util.annotationfactory.AnnotationDescriptor;
/*     */ import org.hibernate.validator.internal.util.annotationfactory.AnnotationFactory;
/*     */ import org.hibernate.validator.internal.util.logging.Log;
/*     */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfiguredConstraint<A extends Annotation>
/*     */ {
/*  31 */   private static final Log log = ;
/*     */   
/*     */   private final ConstraintDefAccessor<A> constraint;
/*     */   private final ConstraintLocation location;
/*     */   private final ElementType elementType;
/*     */   
/*     */   private ConfiguredConstraint(ConstraintDef<?, A> constraint, ConstraintLocation location, ElementType elementType)
/*     */   {
/*  39 */     this.constraint = new ConstraintDefAccessor(constraint, null);
/*  40 */     this.location = location;
/*  41 */     this.elementType = elementType;
/*     */   }
/*     */   
/*     */   static <A extends Annotation> ConfiguredConstraint<A> forType(ConstraintDef<?, A> constraint, Class<?> beanType) {
/*  45 */     return new ConfiguredConstraint(constraint, ConstraintLocation.forClass(beanType), ElementType.TYPE);
/*     */   }
/*     */   
/*     */ 
/*     */   static <A extends Annotation> ConfiguredConstraint<A> forProperty(ConstraintDef<?, A> constraint, Member member)
/*     */   {
/*  51 */     return new ConfiguredConstraint(constraint, ConstraintLocation.forProperty(member), (member instanceof Field) ? ElementType.FIELD : ElementType.METHOD);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static <A extends Annotation> ConfiguredConstraint<A> forParameter(ConstraintDef<?, A> constraint, ExecutableElement executable, int parameterIndex)
/*     */   {
/*  58 */     return new ConfiguredConstraint(constraint, ConstraintLocation.forParameter(executable, parameterIndex), executable.getElementType());
/*     */   }
/*     */   
/*     */ 
/*     */   public static <A extends Annotation> ConfiguredConstraint<A> forExecutable(ConstraintDef<?, A> constraint, ExecutableElement executable)
/*     */   {
/*  64 */     return new ConfiguredConstraint(constraint, ConstraintLocation.forReturnValue(executable), executable.getElementType());
/*     */   }
/*     */   
/*     */   public ConstraintDef<?, A> getConstraint()
/*     */   {
/*  69 */     return this.constraint;
/*     */   }
/*     */   
/*     */   public ConstraintLocation getLocation() {
/*  73 */     return this.location;
/*     */   }
/*     */   
/*     */   public Class<A> getConstraintType() {
/*  77 */     return this.constraint.getConstraintType();
/*     */   }
/*     */   
/*     */   public Map<String, Object> getParameters() {
/*  81 */     return this.constraint.getParameters();
/*     */   }
/*     */   
/*     */   public A createAnnotationProxy()
/*     */   {
/*  86 */     AnnotationDescriptor<A> annotationDescriptor = new AnnotationDescriptor(getConstraintType());
/*  87 */     for (Map.Entry<String, Object> parameter : getParameters().entrySet()) {
/*  88 */       annotationDescriptor.setValue((String)parameter.getKey(), parameter.getValue());
/*     */     }
/*     */     try
/*     */     {
/*  92 */       return AnnotationFactory.create(annotationDescriptor);
/*     */     }
/*     */     catch (RuntimeException e) {
/*  95 */       throw log.getUnableToCreateAnnotationForConfiguredConstraintException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 101 */     return this.constraint.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class ConstraintDefAccessor<A extends Annotation>
/*     */     extends ConstraintDef<ConstraintDefAccessor<A>, A>
/*     */   {
/*     */     private ConstraintDefAccessor(ConstraintDef<?, A> original)
/*     */     {
/* 111 */       super();
/*     */     }
/*     */     
/*     */     private Class<A> getConstraintType() {
/* 115 */       return this.constraintType;
/*     */     }
/*     */     
/*     */     private Map<String, Object> getParameters() {
/* 119 */       return this.parameters;
/*     */     }
/*     */   }
/*     */   
/*     */   public ElementType getElementType() {
/* 124 */     return this.elementType;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\cfg\context\ConfiguredConstraint.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */