/*    */ package org.hibernate.validator.internal.constraintvalidators.bv;
/*    */ 
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.PatternSyntaxException;
/*    */ import javax.validation.ConstraintValidator;
/*    */ import javax.validation.ConstraintValidatorContext;
/*    */ import javax.validation.constraints.Pattern.Flag;
/*    */ import org.hibernate.validator.internal.util.logging.Log;
/*    */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PatternValidator
/*    */   implements ConstraintValidator<javax.validation.constraints.Pattern, CharSequence>
/*    */ {
/* 23 */   private static final Log log = ;
/*    */   private java.util.regex.Pattern pattern;
/*    */   
/*    */   public void initialize(javax.validation.constraints.Pattern parameters)
/*    */   {
/* 28 */     Pattern.Flag[] flags = parameters.flags();
/* 29 */     int intFlag = 0;
/* 30 */     for (Pattern.Flag flag : flags) {
/* 31 */       intFlag |= flag.getValue();
/*    */     }
/*    */     try
/*    */     {
/* 35 */       this.pattern = java.util.regex.Pattern.compile(parameters.regexp(), intFlag);
/*    */     }
/*    */     catch (PatternSyntaxException e) {
/* 38 */       throw log.getInvalidRegularExpressionException(e);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isValid(CharSequence value, ConstraintValidatorContext constraintValidatorContext) {
/* 43 */     if (value == null) {
/* 44 */       return true;
/*    */     }
/* 46 */     Matcher m = this.pattern.matcher(value);
/* 47 */     return m.matches();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\constraintvalidators\bv\PatternValidator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */