/*    */ package org.hibernate.validator.internal.engine.messageinterpolation.parser;
/*    */ 
/*    */ import org.hibernate.validator.internal.util.logging.Log;
/*    */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InterpolationTermState
/*    */   implements ParserState
/*    */ {
/* 16 */   private static final Log log = ;
/*    */   
/*    */   public void start(TokenCollector tokenCollector)
/*    */   {
/* 20 */     throw new IllegalStateException("Parsing of message descriptor cannot start in this state");
/*    */   }
/*    */   
/*    */   public void terminate(TokenCollector tokenCollector) throws MessageDescriptorFormatException
/*    */   {
/* 25 */     throw log.getNonTerminatedParameterException(tokenCollector
/* 26 */       .getOriginalMessageDescriptor(), '{');
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void handleNonMetaCharacter(char character, TokenCollector tokenCollector)
/*    */     throws MessageDescriptorFormatException
/*    */   {
/* 34 */     tokenCollector.appendToToken(character);
/* 35 */     tokenCollector.next();
/*    */   }
/*    */   
/*    */   public void handleBeginTerm(char character, TokenCollector tokenCollector) throws MessageDescriptorFormatException
/*    */   {
/* 40 */     throw log.getNestedParameterException(tokenCollector.getOriginalMessageDescriptor());
/*    */   }
/*    */   
/*    */   public void handleEndTerm(char character, TokenCollector tokenCollector) throws MessageDescriptorFormatException
/*    */   {
/* 45 */     tokenCollector.appendToToken(character);
/* 46 */     tokenCollector.terminateToken();
/* 47 */     BeginState beginState = new BeginState();
/* 48 */     tokenCollector.transitionState(beginState);
/* 49 */     tokenCollector.next();
/*    */   }
/*    */   
/*    */   public void handleEscapeCharacter(char character, TokenCollector tokenCollector)
/*    */     throws MessageDescriptorFormatException
/*    */   {
/* 55 */     tokenCollector.appendToToken(character);
/* 56 */     ParserState state = new EscapedState(this);
/* 57 */     tokenCollector.transitionState(state);
/* 58 */     tokenCollector.next();
/*    */   }
/*    */   
/*    */ 
/*    */   public void handleELDesignator(char character, TokenCollector tokenCollector)
/*    */     throws MessageDescriptorFormatException
/*    */   {
/* 65 */     tokenCollector.appendToToken(character);
/* 66 */     tokenCollector.next();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\engine\messageinterpolation\parser\InterpolationTermState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */