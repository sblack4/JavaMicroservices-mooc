/*    */ package org.hibernate.validator.internal.engine.messageinterpolation.parser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EscapedState
/*    */   implements ParserState
/*    */ {
/*    */   ParserState previousState;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public EscapedState(ParserState previousState)
/*    */   {
/* 16 */     this.previousState = previousState;
/*    */   }
/*    */   
/*    */   public void start(TokenCollector tokenCollector)
/*    */   {
/* 21 */     throw new IllegalStateException("Parsing of message descriptor cannot start in this state");
/*    */   }
/*    */   
/*    */   public void terminate(TokenCollector tokenCollector) throws MessageDescriptorFormatException
/*    */   {
/* 26 */     tokenCollector.terminateToken();
/*    */   }
/*    */   
/*    */   public void handleNonMetaCharacter(char character, TokenCollector tokenCollector)
/*    */     throws MessageDescriptorFormatException
/*    */   {
/* 32 */     handleEscapedCharacter(character, tokenCollector);
/*    */   }
/*    */   
/*    */   public void handleBeginTerm(char character, TokenCollector tokenCollector) throws MessageDescriptorFormatException
/*    */   {
/* 37 */     handleEscapedCharacter(character, tokenCollector);
/*    */   }
/*    */   
/*    */   public void handleEndTerm(char character, TokenCollector tokenCollector) throws MessageDescriptorFormatException
/*    */   {
/* 42 */     handleEscapedCharacter(character, tokenCollector);
/*    */   }
/*    */   
/*    */   public void handleEscapeCharacter(char character, TokenCollector tokenCollector)
/*    */     throws MessageDescriptorFormatException
/*    */   {
/* 48 */     handleEscapedCharacter(character, tokenCollector);
/*    */   }
/*    */   
/*    */   public void handleELDesignator(char character, TokenCollector tokenCollector)
/*    */     throws MessageDescriptorFormatException
/*    */   {
/* 54 */     handleEscapedCharacter(character, tokenCollector);
/*    */   }
/*    */   
/*    */   private void handleEscapedCharacter(char character, TokenCollector tokenCollector) throws MessageDescriptorFormatException
/*    */   {
/* 59 */     tokenCollector.appendToToken(character);
/* 60 */     tokenCollector.transitionState(this.previousState);
/* 61 */     tokenCollector.next();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\engine\messageinterpolation\parser\EscapedState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */