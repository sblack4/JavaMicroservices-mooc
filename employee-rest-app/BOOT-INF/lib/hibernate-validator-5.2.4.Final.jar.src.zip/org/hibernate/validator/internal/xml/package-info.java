package org.hibernate.validator.internal.xml;

import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;

@XmlSchema(namespace="http://jboss.org/xml/ns/javax/validation/mapping", elementFormDefault=XmlNsForm.QUALIFIED)
abstract interface package-info {}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\xml\package-info.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */