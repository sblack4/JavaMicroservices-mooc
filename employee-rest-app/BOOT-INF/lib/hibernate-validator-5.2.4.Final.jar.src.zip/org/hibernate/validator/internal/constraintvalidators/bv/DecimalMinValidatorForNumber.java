/*    */ package org.hibernate.validator.internal.constraintvalidators.bv;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ import javax.validation.ConstraintValidator;
/*    */ import javax.validation.ConstraintValidatorContext;
/*    */ import javax.validation.constraints.DecimalMin;
/*    */ import org.hibernate.validator.internal.util.logging.Log;
/*    */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DecimalMinValidatorForNumber
/*    */   implements ConstraintValidator<DecimalMin, Number>
/*    */ {
/* 27 */   private static final Log log = ;
/*    */   private BigDecimal minValue;
/*    */   private boolean inclusive;
/*    */   
/*    */   public void initialize(DecimalMin minValue)
/*    */   {
/*    */     try {
/* 34 */       this.minValue = new BigDecimal(minValue.value());
/*    */     }
/*    */     catch (NumberFormatException nfe) {
/* 37 */       throw log.getInvalidBigDecimalFormatException(minValue.value(), nfe);
/*    */     }
/* 39 */     this.inclusive = minValue.inclusive();
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isValid(Number value, ConstraintValidatorContext constraintValidatorContext)
/*    */   {
/* 45 */     if (value == null) {
/* 46 */       return true;
/*    */     }
/*    */     
/*    */ 
/* 50 */     if ((value instanceof Double)) {
/* 51 */       if (((Double)value).doubleValue() == Double.POSITIVE_INFINITY) {
/* 52 */         return true;
/*    */       }
/* 54 */       if ((Double.isNaN(((Double)value).doubleValue())) || (((Double)value).doubleValue() == Double.NEGATIVE_INFINITY)) {
/* 55 */         return false;
/*    */       }
/*    */     }
/* 58 */     else if ((value instanceof Float)) {
/* 59 */       if (((Float)value).floatValue() == Float.POSITIVE_INFINITY) {
/* 60 */         return true;
/*    */       }
/* 62 */       if ((Float.isNaN(((Float)value).floatValue())) || (((Float)value).floatValue() == Float.NEGATIVE_INFINITY)) {
/* 63 */         return false;
/*    */       }
/*    */     }
/*    */     int comparisonResult;
/*    */     int comparisonResult;
/* 68 */     if ((value instanceof BigDecimal)) {
/* 69 */       comparisonResult = ((BigDecimal)value).compareTo(this.minValue);
/*    */     } else { int comparisonResult;
/* 71 */       if ((value instanceof BigInteger)) {
/* 72 */         comparisonResult = new BigDecimal((BigInteger)value).compareTo(this.minValue);
/*    */       } else { int comparisonResult;
/* 74 */         if ((value instanceof Long)) {
/* 75 */           comparisonResult = BigDecimal.valueOf(value.longValue()).compareTo(this.minValue);
/*    */         }
/*    */         else
/* 78 */           comparisonResult = BigDecimal.valueOf(value.doubleValue()).compareTo(this.minValue);
/*    */       } }
/* 80 */     return comparisonResult >= 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\constraintvalidators\bv\DecimalMinValidatorForNumber.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */