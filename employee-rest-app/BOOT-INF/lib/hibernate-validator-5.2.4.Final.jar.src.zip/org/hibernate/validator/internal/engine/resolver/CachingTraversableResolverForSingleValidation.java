/*     */ package org.hibernate.validator.internal.engine.resolver;
/*     */ 
/*     */ import java.lang.annotation.ElementType;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.validation.Path;
/*     */ import javax.validation.Path.Node;
/*     */ import javax.validation.TraversableResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CachingTraversableResolverForSingleValidation
/*     */   implements TraversableResolver
/*     */ {
/*     */   private TraversableResolver delegate;
/*  24 */   private Map<TraversableHolder, TraversableHolder> traversables = new HashMap();
/*     */   
/*     */   public CachingTraversableResolverForSingleValidation(TraversableResolver delegate) {
/*  27 */     this.delegate = delegate;
/*     */   }
/*     */   
/*     */   public boolean isReachable(Object traversableObject, Path.Node traversableProperty, Class<?> rootBeanType, Path pathToTraversableObject, ElementType elementType) {
/*  31 */     TraversableHolder currentLH = new TraversableHolder(traversableObject, traversableProperty, rootBeanType, pathToTraversableObject, elementType, null);
/*     */     
/*     */ 
/*  34 */     TraversableHolder cachedLH = (TraversableHolder)this.traversables.get(currentLH);
/*  35 */     if (cachedLH == null) {
/*  36 */       currentLH.isReachable = Boolean.valueOf(this.delegate.isReachable(traversableObject, traversableProperty, rootBeanType, pathToTraversableObject, elementType));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  43 */       this.traversables.put(currentLH, currentLH);
/*  44 */       cachedLH = currentLH;
/*     */     }
/*  46 */     else if (cachedLH.isReachable == null) {
/*  47 */       cachedLH.isReachable = Boolean.valueOf(this.delegate.isReachable(traversableObject, traversableProperty, rootBeanType, pathToTraversableObject, elementType));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  55 */     return cachedLH.isReachable.booleanValue();
/*     */   }
/*     */   
/*     */   public boolean isCascadable(Object traversableObject, Path.Node traversableProperty, Class<?> rootBeanType, Path pathToTraversableObject, ElementType elementType) {
/*  59 */     TraversableHolder currentLH = new TraversableHolder(traversableObject, traversableProperty, rootBeanType, pathToTraversableObject, elementType, null);
/*     */     
/*     */ 
/*  62 */     TraversableHolder cachedLH = (TraversableHolder)this.traversables.get(currentLH);
/*  63 */     if (cachedLH == null) {
/*  64 */       currentLH.isCascadable = Boolean.valueOf(this.delegate.isCascadable(traversableObject, traversableProperty, rootBeanType, pathToTraversableObject, elementType));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  71 */       this.traversables.put(currentLH, currentLH);
/*  72 */       cachedLH = currentLH;
/*     */     }
/*  74 */     else if (cachedLH.isCascadable == null) {
/*  75 */       cachedLH.isCascadable = Boolean.valueOf(this.delegate.isCascadable(traversableObject, traversableProperty, rootBeanType, pathToTraversableObject, elementType));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */     return cachedLH.isCascadable.booleanValue();
/*     */   }
/*     */   
/*     */   private static final class TraversableHolder
/*     */   {
/*     */     private final Object traversableObject;
/*     */     private final Path.Node traversableProperty;
/*     */     private final Class<?> rootBeanType;
/*     */     private final Path pathToTraversableObject;
/*     */     private final ElementType elementType;
/*     */     private final int hashCode;
/*     */     private Boolean isReachable;
/*     */     private Boolean isCascadable;
/*     */     
/*     */     private TraversableHolder(Object traversableObject, Path.Node traversableProperty, Class<?> rootBeanType, Path pathToTraversableObject, ElementType elementType)
/*     */     {
/*  99 */       this.traversableObject = traversableObject;
/* 100 */       this.traversableProperty = traversableProperty;
/* 101 */       this.rootBeanType = rootBeanType;
/* 102 */       this.pathToTraversableObject = pathToTraversableObject;
/* 103 */       this.elementType = elementType;
/* 104 */       this.hashCode = buildHashCode();
/*     */     }
/*     */     
/*     */     public boolean equals(Object o)
/*     */     {
/* 109 */       if (this == o) {
/* 110 */         return true;
/*     */       }
/* 112 */       if ((o == null) || (getClass() != o.getClass())) {
/* 113 */         return false;
/*     */       }
/*     */       
/* 116 */       TraversableHolder that = (TraversableHolder)o;
/*     */       
/* 118 */       if (this.elementType != that.elementType) {
/* 119 */         return false;
/*     */       }
/* 121 */       if (!this.pathToTraversableObject.equals(that.pathToTraversableObject)) {
/* 122 */         return false;
/*     */       }
/* 124 */       if (!this.rootBeanType.equals(that.rootBeanType)) {
/* 125 */         return false;
/*     */       }
/* 127 */       if (this.traversableObject != null ? !this.traversableObject.equals(that.traversableObject) : that.traversableObject != null) {
/* 128 */         return false;
/*     */       }
/* 130 */       if (!this.traversableProperty.equals(that.traversableProperty)) {
/* 131 */         return false;
/*     */       }
/*     */       
/* 134 */       return true;
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 139 */       return this.hashCode;
/*     */     }
/*     */     
/*     */     public int buildHashCode() {
/* 143 */       int result = this.traversableObject != null ? this.traversableObject.hashCode() : 0;
/* 144 */       result = 31 * result + this.traversableProperty.hashCode();
/* 145 */       result = 31 * result + this.rootBeanType.hashCode();
/* 146 */       result = 31 * result + this.pathToTraversableObject.hashCode();
/* 147 */       result = 31 * result + this.elementType.hashCode();
/* 148 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\engine\resolver\CachingTraversableResolverForSingleValidation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */