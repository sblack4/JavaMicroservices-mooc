/*     */ package org.hibernate.validator.internal.util.classhierarchy;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.hibernate.validator.internal.util.CollectionHelper;
/*     */ import org.hibernate.validator.internal.util.Contracts;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassHierarchyHelper
/*     */ {
/*     */   public static <T> List<Class<? super T>> getHierarchy(Class<T> clazz, Filter... filters)
/*     */   {
/*  43 */     Contracts.assertNotNull(clazz);
/*     */     
/*  45 */     List<Class<? super T>> classes = CollectionHelper.newArrayList();
/*     */     
/*  47 */     List<Filter> allFilters = CollectionHelper.newArrayList();
/*  48 */     allFilters.addAll(Arrays.asList(filters));
/*  49 */     allFilters.add(Filters.excludeProxies());
/*     */     
/*  51 */     getHierarchy(clazz, classes, allFilters);
/*  52 */     return classes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static <T> void getHierarchy(Class<? super T> clazz, List<Class<? super T>> classes, Iterable<Filter> filters)
/*     */   {
/*  64 */     for (Class<? super T> current = clazz; current != null; current = current.getSuperclass()) {
/*  65 */       if (classes.contains(current)) {
/*  66 */         return;
/*     */       }
/*     */       
/*  69 */       if (acceptedByAllFilters(current, filters)) {
/*  70 */         classes.add(current);
/*     */       }
/*     */       
/*  73 */       for (Class<?> currentInterface : current.getInterfaces())
/*     */       {
/*     */ 
/*  76 */         Class<? super T> currentInterfaceCasted = currentInterface;
/*  77 */         getHierarchy(currentInterfaceCasted, classes, filters);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static boolean acceptedByAllFilters(Class<?> clazz, Iterable<Filter> filters) {
/*  83 */     for (Filter classFilter : filters) {
/*  84 */       if (!classFilter.accepts(clazz)) {
/*  85 */         return false;
/*     */       }
/*     */     }
/*     */     
/*  89 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T> Set<Class<? super T>> getDirectlyImplementedInterfaces(Class<T> clazz)
/*     */   {
/* 105 */     Contracts.assertNotNull(clazz);
/*     */     
/* 107 */     Set<Class<? super T>> classes = CollectionHelper.newHashSet();
/* 108 */     getImplementedInterfaces(clazz, classes);
/* 109 */     return classes;
/*     */   }
/*     */   
/*     */   private static <T> void getImplementedInterfaces(Class<? super T> clazz, Set<Class<? super T>> classes) {
/* 113 */     for (Class<?> currentInterface : clazz.getInterfaces())
/*     */     {
/* 115 */       Class<? super T> currentInterfaceCasted = currentInterface;
/* 116 */       classes.add(currentInterfaceCasted);
/* 117 */       getImplementedInterfaces(currentInterfaceCasted, classes);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\util\classhierarchy\ClassHierarchyHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */