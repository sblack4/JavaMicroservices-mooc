/*    */ package org.hibernate.validator.internal.util.classhierarchy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Filters
/*    */ {
/* 17 */   private static final Filter PROXY_FILTER = new WeldProxyFilter(null);
/* 18 */   private static final Filter INTERFACES_FILTER = new InterfacesFilter(null);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Filter excludeInterfaces()
/*    */   {
/* 26 */     return INTERFACES_FILTER;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Filter excludeProxies()
/*    */   {
/* 35 */     return PROXY_FILTER;
/*    */   }
/*    */   
/*    */   private static class InterfacesFilter implements Filter
/*    */   {
/*    */     public boolean accepts(Class<?> clazz)
/*    */     {
/* 42 */       return !clazz.isInterface();
/*    */     }
/*    */   }
/*    */   
/*    */   private static class WeldProxyFilter implements Filter
/*    */   {
/*    */     private static final String WELD_PROXY_INTERFACE_NAME = "org.jboss.weld.bean.proxy.ProxyObject";
/*    */     
/*    */     public boolean accepts(Class<?> clazz)
/*    */     {
/* 52 */       return !isWeldProxy(clazz);
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     private boolean isWeldProxy(Class<?> clazz)
/*    */     {
/* 66 */       for (Class<?> implementedInterface : clazz.getInterfaces()) {
/* 67 */         if (implementedInterface.getName().equals("org.jboss.weld.bean.proxy.ProxyObject")) {
/* 68 */           return true;
/*    */         }
/*    */       }
/*    */       
/* 72 */       return false;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\util\classhierarchy\Filters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */