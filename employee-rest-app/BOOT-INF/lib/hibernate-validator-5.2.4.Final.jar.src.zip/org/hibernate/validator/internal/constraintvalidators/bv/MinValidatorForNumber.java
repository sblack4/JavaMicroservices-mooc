/*    */ package org.hibernate.validator.internal.constraintvalidators.bv;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ import javax.validation.ConstraintValidator;
/*    */ import javax.validation.ConstraintValidatorContext;
/*    */ import javax.validation.constraints.Min;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MinValidatorForNumber
/*    */   implements ConstraintValidator<Min, Number>
/*    */ {
/*    */   private long minValue;
/*    */   
/*    */   public void initialize(Min minValue)
/*    */   {
/* 28 */     this.minValue = minValue.value();
/*    */   }
/*    */   
/*    */   public boolean isValid(Number value, ConstraintValidatorContext constraintValidatorContext)
/*    */   {
/* 33 */     if (value == null) {
/* 34 */       return true;
/*    */     }
/*    */     
/*    */ 
/* 38 */     if ((value instanceof Double)) {
/* 39 */       if (((Double)value).doubleValue() == Double.POSITIVE_INFINITY) {
/* 40 */         return true;
/*    */       }
/* 42 */       if ((Double.isNaN(((Double)value).doubleValue())) || (((Double)value).doubleValue() == Double.NEGATIVE_INFINITY)) {
/* 43 */         return false;
/*    */       }
/*    */     }
/* 46 */     else if ((value instanceof Float)) {
/* 47 */       if (((Float)value).floatValue() == Float.POSITIVE_INFINITY) {
/* 48 */         return true;
/*    */       }
/* 50 */       if ((Float.isNaN(((Float)value).floatValue())) || (((Float)value).floatValue() == Float.NEGATIVE_INFINITY)) {
/* 51 */         return false;
/*    */       }
/*    */     }
/*    */     
/* 55 */     if ((value instanceof BigDecimal)) {
/* 56 */       return ((BigDecimal)value).compareTo(BigDecimal.valueOf(this.minValue)) != -1;
/*    */     }
/* 58 */     if ((value instanceof BigInteger)) {
/* 59 */       return ((BigInteger)value).compareTo(BigInteger.valueOf(this.minValue)) != -1;
/*    */     }
/*    */     
/* 62 */     long longValue = value.longValue();
/* 63 */     return longValue >= this.minValue;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\constraintvalidators\bv\MinValidatorForNumber.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */