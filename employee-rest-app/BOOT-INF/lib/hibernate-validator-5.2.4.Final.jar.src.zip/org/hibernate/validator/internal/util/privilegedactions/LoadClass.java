/*     */ package org.hibernate.validator.internal.util.privilegedactions;
/*     */ 
/*     */ import java.security.PrivilegedAction;
/*     */ import org.hibernate.validator.HibernateValidator;
/*     */ import org.hibernate.validator.internal.util.logging.Log;
/*     */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LoadClass
/*     */   implements PrivilegedAction<Class<?>>
/*     */ {
/*  31 */   private static final Log log = ;
/*     */   
/*     */ 
/*     */   private static final String HIBERNATE_VALIDATOR_CLASS_NAME = "org.hibernate.validator";
/*     */   
/*     */   private final String className;
/*     */   
/*     */   private final ClassLoader classLoader;
/*     */   
/*     */   private final boolean fallbackOnTCCL;
/*     */   
/*     */ 
/*     */   public static LoadClass action(String className, ClassLoader classLoader)
/*     */   {
/*  45 */     return new LoadClass(className, classLoader, true);
/*     */   }
/*     */   
/*     */   public static LoadClass action(String className, ClassLoader classLoader, boolean fallbackOnTCCL) {
/*  49 */     return new LoadClass(className, classLoader, fallbackOnTCCL);
/*     */   }
/*     */   
/*     */   private LoadClass(String className, ClassLoader classLoader, boolean fallbackOnTCCL) {
/*  53 */     this.className = className;
/*  54 */     this.classLoader = classLoader;
/*  55 */     this.fallbackOnTCCL = fallbackOnTCCL;
/*     */   }
/*     */   
/*     */   public Class<?> run()
/*     */   {
/*  60 */     if (this.className.startsWith("org.hibernate.validator")) {
/*  61 */       return loadClassInValidatorNameSpace();
/*     */     }
/*     */     
/*  64 */     return loadNonValidatorClass();
/*     */   }
/*     */   
/*     */ 
/*     */   private Class<?> loadClassInValidatorNameSpace()
/*     */   {
/*     */     try
/*     */     {
/*  72 */       return Class.forName(this.className, true, HibernateValidator.class.getClassLoader());
/*     */     }
/*     */     catch (ClassNotFoundException localClassNotFoundException1) {}catch (RuntimeException localRuntimeException) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */     if (this.fallbackOnTCCL) {
/*     */       try {
/*  82 */         ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
/*  83 */         if (contextClassLoader != null) {
/*  84 */           return Class.forName(this.className, false, contextClassLoader);
/*     */         }
/*     */         
/*  87 */         throw log.getUnableToLoadClassException(this.className);
/*     */       }
/*     */       catch (ClassNotFoundException e)
/*     */       {
/*  91 */         throw log.getUnableToLoadClassException(this.className, e);
/*     */       }
/*     */     }
/*     */     
/*  95 */     throw log.getUnableToLoadClassException(this.className);
/*     */   }
/*     */   
/*     */   private Class<?> loadNonValidatorClass()
/*     */   {
/* 100 */     Exception exception = null;
/*     */     try {
/* 102 */       if (this.classLoader != null) {
/* 103 */         return Class.forName(this.className, false, this.classLoader);
/*     */       }
/*     */     }
/*     */     catch (ClassNotFoundException e)
/*     */     {
/* 108 */       exception = e;
/*     */     }
/*     */     catch (RuntimeException e)
/*     */     {
/* 112 */       exception = e;
/*     */     }
/* 114 */     if (this.fallbackOnTCCL) {
/*     */       try {
/* 116 */         ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
/* 117 */         if (contextClassLoader != null) {
/* 118 */           return Class.forName(this.className, false, contextClassLoader);
/*     */         }
/*     */       }
/*     */       catch (ClassNotFoundException localClassNotFoundException1) {}catch (RuntimeException localRuntimeException1) {}
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/* 128 */         return Class.forName(this.className, true, LoadClass.class.getClassLoader());
/*     */       }
/*     */       catch (ClassNotFoundException e) {
/* 131 */         throw log.getUnableToLoadClassException(this.className, e);
/*     */       }
/*     */     }
/*     */     
/* 135 */     throw log.getUnableToLoadClassException(this.className, exception);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\util\privilegedactions\LoadClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */