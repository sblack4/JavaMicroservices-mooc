/*     */ package org.hibernate.validator.internal.engine;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.validation.BootstrapConfiguration;
/*     */ import javax.validation.ConstraintValidatorFactory;
/*     */ import javax.validation.MessageInterpolator;
/*     */ import javax.validation.ParameterNameProvider;
/*     */ import javax.validation.TraversableResolver;
/*     */ import javax.validation.ValidationException;
/*     */ import javax.validation.ValidationProviderResolver;
/*     */ import javax.validation.ValidatorFactory;
/*     */ import javax.validation.spi.BootstrapState;
/*     */ import javax.validation.spi.ConfigurationState;
/*     */ import javax.validation.spi.ValidationProvider;
/*     */ import org.hibernate.validator.HibernateValidatorConfiguration;
/*     */ import org.hibernate.validator.cfg.ConstraintMapping;
/*     */ import org.hibernate.validator.internal.cfg.context.DefaultConstraintMapping;
/*     */ import org.hibernate.validator.internal.engine.constraintvalidation.ConstraintValidatorFactoryImpl;
/*     */ import org.hibernate.validator.internal.engine.resolver.DefaultTraversableResolver;
/*     */ import org.hibernate.validator.internal.engine.valuehandling.OptionalValueUnwrapper;
/*     */ import org.hibernate.validator.internal.util.CollectionHelper;
/*     */ import org.hibernate.validator.internal.util.Contracts;
/*     */ import org.hibernate.validator.internal.util.TypeResolutionHelper;
/*     */ import org.hibernate.validator.internal.util.Version;
/*     */ import org.hibernate.validator.internal.util.logging.Log;
/*     */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*     */ import org.hibernate.validator.internal.util.logging.Messages;
/*     */ import org.hibernate.validator.internal.util.privilegedactions.LoadClass;
/*     */ import org.hibernate.validator.internal.xml.ValidationBootstrapParameters;
/*     */ import org.hibernate.validator.internal.xml.ValidationXmlParser;
/*     */ import org.hibernate.validator.messageinterpolation.ResourceBundleMessageInterpolator;
/*     */ import org.hibernate.validator.resourceloading.PlatformResourceBundleLocator;
/*     */ import org.hibernate.validator.spi.constraintdefinition.ConstraintDefinitionContributor;
/*     */ import org.hibernate.validator.spi.resourceloading.ResourceBundleLocator;
/*     */ import org.hibernate.validator.spi.time.TimeProvider;
/*     */ import org.hibernate.validator.spi.valuehandling.ValidatedValueUnwrapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigurationImpl
/*     */   implements HibernateValidatorConfiguration, ConfigurationState
/*     */ {
/*     */   private static final String JFX_UNWRAPPER_CLASS = "org.hibernate.validator.internal.engine.valuehandling.JavaFXPropertyValueUnwrapper";
/*     */   
/*     */   static
/*     */   {
/*  69 */     Version.touch();
/*     */   }
/*     */   
/*  72 */   private static final Log log = LoggerFactory.make();
/*     */   
/*     */   private final ResourceBundleLocator defaultResourceBundleLocator;
/*     */   
/*     */   private final MessageInterpolator defaultMessageInterpolator;
/*     */   private final TraversableResolver defaultTraversableResolver;
/*     */   private final ConstraintValidatorFactory defaultConstraintValidatorFactory;
/*     */   private final ParameterNameProvider defaultParameterNameProvider;
/*     */   private final ConstraintDefinitionContributor defaultConstraintDefinitionContributor;
/*     */   private ValidationProviderResolver providerResolver;
/*     */   private final ValidationBootstrapParameters validationBootstrapParameters;
/*  83 */   private boolean ignoreXmlConfiguration = false;
/*  84 */   private final Set<InputStream> configurationStreams = CollectionHelper.newHashSet();
/*     */   
/*     */   private BootstrapConfiguration bootstrapConfiguration;
/*     */   
/*  88 */   private final Set<DefaultConstraintMapping> programmaticMappings = CollectionHelper.newHashSet();
/*     */   private boolean failFast;
/*  90 */   private final Set<ConstraintDefinitionContributor> constraintDefinitionContributors = CollectionHelper.newHashSet();
/*  91 */   private final List<ValidatedValueUnwrapper<?>> validatedValueHandlers = CollectionHelper.newArrayList();
/*     */   private ClassLoader externalClassLoader;
/*     */   private TimeProvider timeProvider;
/*     */   
/*     */   public ConfigurationImpl(BootstrapState state) {
/*  96 */     this();
/*  97 */     if (state.getValidationProviderResolver() == null) {
/*  98 */       this.providerResolver = state.getDefaultValidationProviderResolver();
/*     */     }
/*     */     else {
/* 101 */       this.providerResolver = state.getValidationProviderResolver();
/*     */     }
/*     */   }
/*     */   
/*     */   public ConfigurationImpl(ValidationProvider<?> provider) {
/* 106 */     this();
/* 107 */     if (provider == null) {
/* 108 */       throw log.getInconsistentConfigurationException();
/*     */     }
/* 110 */     this.providerResolver = null;
/* 111 */     this.validationBootstrapParameters.setProvider(provider);
/*     */   }
/*     */   
/*     */   private ConfigurationImpl() {
/* 115 */     this.validationBootstrapParameters = new ValidationBootstrapParameters();
/* 116 */     TypeResolutionHelper typeResolutionHelper = new TypeResolutionHelper();
/* 117 */     if (isJavaFxInClasspath()) {
/* 118 */       this.validatedValueHandlers.add(createJavaFXUnwrapperClass(typeResolutionHelper));
/*     */     }
/* 120 */     if (Version.getJavaRelease() >= 8) {
/* 121 */       this.validatedValueHandlers.add(new OptionalValueUnwrapper(typeResolutionHelper));
/*     */     }
/* 123 */     this.defaultResourceBundleLocator = new PlatformResourceBundleLocator("ValidationMessages");
/*     */     
/*     */ 
/* 126 */     this.defaultTraversableResolver = new DefaultTraversableResolver();
/* 127 */     this.defaultConstraintValidatorFactory = new ConstraintValidatorFactoryImpl();
/* 128 */     this.defaultParameterNameProvider = new DefaultParameterNameProvider();
/* 129 */     this.defaultMessageInterpolator = new ResourceBundleMessageInterpolator(this.defaultResourceBundleLocator);
/* 130 */     this.defaultConstraintDefinitionContributor = new ServiceLoaderBasedConstraintDefinitionContributor(typeResolutionHelper);
/*     */     
/*     */ 
/* 133 */     addConstraintDefinitionContributor(this.defaultConstraintDefinitionContributor);
/*     */   }
/*     */   
/*     */   private ValidatedValueUnwrapper<?> createJavaFXUnwrapperClass(TypeResolutionHelper typeResolutionHelper) {
/*     */     try {
/* 138 */       Class<?> jfxUnwrapperClass = (Class)run(LoadClass.action("org.hibernate.validator.internal.engine.valuehandling.JavaFXPropertyValueUnwrapper", getClass().getClassLoader()));
/* 139 */       return (ValidatedValueUnwrapper)jfxUnwrapperClass.getConstructor(new Class[] { TypeResolutionHelper.class }).newInstance(new Object[] { typeResolutionHelper });
/*     */     }
/*     */     catch (Exception e) {
/* 142 */       throw log.validatedValueUnwrapperCannotBeCreated("org.hibernate.validator.internal.engine.valuehandling.JavaFXPropertyValueUnwrapper", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public final HibernateValidatorConfiguration ignoreXmlConfiguration()
/*     */   {
/* 148 */     this.ignoreXmlConfiguration = true;
/* 149 */     return this;
/*     */   }
/*     */   
/*     */   public final ConfigurationImpl messageInterpolator(MessageInterpolator interpolator)
/*     */   {
/* 154 */     if ((log.isDebugEnabled()) && 
/* 155 */       (interpolator != null)) {
/* 156 */       log.debug("Setting custom MessageInterpolator of type " + interpolator.getClass().getName());
/*     */     }
/*     */     
/* 159 */     this.validationBootstrapParameters.setMessageInterpolator(interpolator);
/* 160 */     return this;
/*     */   }
/*     */   
/*     */   public final ConfigurationImpl traversableResolver(TraversableResolver resolver)
/*     */   {
/* 165 */     if ((log.isDebugEnabled()) && 
/* 166 */       (resolver != null)) {
/* 167 */       log.debug("Setting custom TraversableResolver of type " + resolver.getClass().getName());
/*     */     }
/*     */     
/* 170 */     this.validationBootstrapParameters.setTraversableResolver(resolver);
/* 171 */     return this;
/*     */   }
/*     */   
/*     */   public final ConfigurationImpl constraintValidatorFactory(ConstraintValidatorFactory constraintValidatorFactory)
/*     */   {
/* 176 */     if ((log.isDebugEnabled()) && 
/* 177 */       (constraintValidatorFactory != null)) {
/* 178 */       log.debug("Setting custom ConstraintValidatorFactory of type " + constraintValidatorFactory
/* 179 */         .getClass()
/* 180 */         .getName());
/*     */     }
/*     */     
/*     */ 
/* 184 */     this.validationBootstrapParameters.setConstraintValidatorFactory(constraintValidatorFactory);
/* 185 */     return this;
/*     */   }
/*     */   
/*     */   public HibernateValidatorConfiguration parameterNameProvider(ParameterNameProvider parameterNameProvider)
/*     */   {
/* 190 */     if ((log.isDebugEnabled()) && 
/* 191 */       (parameterNameProvider != null)) {
/* 192 */       log.debug("Setting custom ParameterNameProvider of type " + parameterNameProvider
/* 193 */         .getClass()
/* 194 */         .getName());
/*     */     }
/*     */     
/*     */ 
/* 198 */     this.validationBootstrapParameters.setParameterNameProvider(parameterNameProvider);
/* 199 */     return this;
/*     */   }
/*     */   
/*     */   public final HibernateValidatorConfiguration addMapping(InputStream stream)
/*     */   {
/* 204 */     Contracts.assertNotNull(stream, Messages.MESSAGES.inputStreamCannotBeNull());
/*     */     
/* 206 */     this.validationBootstrapParameters.addMapping(stream.markSupported() ? stream : new BufferedInputStream(stream));
/* 207 */     return this;
/*     */   }
/*     */   
/*     */   public final HibernateValidatorConfiguration failFast(boolean failFast)
/*     */   {
/* 212 */     this.failFast = failFast;
/* 213 */     return this;
/*     */   }
/*     */   
/*     */   public final ConstraintMapping createConstraintMapping()
/*     */   {
/* 218 */     return new DefaultConstraintMapping();
/*     */   }
/*     */   
/*     */   public final HibernateValidatorConfiguration addMapping(ConstraintMapping mapping)
/*     */   {
/* 223 */     Contracts.assertNotNull(mapping, Messages.MESSAGES.parameterMustNotBeNull("mapping"));
/*     */     
/* 225 */     this.programmaticMappings.add((DefaultConstraintMapping)mapping);
/* 226 */     return this;
/*     */   }
/*     */   
/*     */   public final HibernateValidatorConfiguration addProperty(String name, String value)
/*     */   {
/* 231 */     if (value != null) {
/* 232 */       this.validationBootstrapParameters.addConfigProperty(name, value);
/*     */     }
/* 234 */     return this;
/*     */   }
/*     */   
/*     */   public HibernateValidatorConfiguration addValidatedValueHandler(ValidatedValueUnwrapper<?> handler)
/*     */   {
/* 239 */     Contracts.assertNotNull(handler, Messages.MESSAGES.parameterMustNotBeNull("handler"));
/* 240 */     this.validatedValueHandlers.add(handler);
/*     */     
/* 242 */     return this;
/*     */   }
/*     */   
/*     */   public ConstraintDefinitionContributor getDefaultConstraintDefinitionContributor()
/*     */   {
/* 247 */     return this.defaultConstraintDefinitionContributor;
/*     */   }
/*     */   
/*     */   public Set<ConstraintDefinitionContributor> getConstraintDefinitionContributors() {
/* 251 */     return this.constraintDefinitionContributors;
/*     */   }
/*     */   
/*     */   public HibernateValidatorConfiguration addConstraintDefinitionContributor(ConstraintDefinitionContributor contributor)
/*     */   {
/* 256 */     Contracts.assertNotNull(contributor, Messages.MESSAGES.parameterMustNotBeNull("contributor"));
/* 257 */     this.constraintDefinitionContributors.add(contributor);
/*     */     
/* 259 */     return this;
/*     */   }
/*     */   
/*     */   public HibernateValidatorConfiguration externalClassLoader(ClassLoader externalClassLoader)
/*     */   {
/* 264 */     Contracts.assertNotNull(externalClassLoader, Messages.MESSAGES.parameterMustNotBeNull("externalClassLoader"));
/* 265 */     this.externalClassLoader = externalClassLoader;
/*     */     
/* 267 */     return this;
/*     */   }
/*     */   
/*     */   public HibernateValidatorConfiguration timeProvider(TimeProvider timeProvider)
/*     */   {
/* 272 */     Contracts.assertNotNull(timeProvider, Messages.MESSAGES.parameterMustNotBeNull("timeProvider"));
/* 273 */     this.timeProvider = timeProvider;
/*     */     
/* 275 */     return this;
/*     */   }
/*     */   
/*     */   public final ValidatorFactory buildValidatorFactory()
/*     */   {
/* 280 */     parseValidationXml();
/* 281 */     ValidatorFactory factory = null;
/*     */     try {
/* 283 */       if (isSpecificProvider()) {
/* 284 */         factory = this.validationBootstrapParameters.getProvider().buildValidatorFactory(this);
/*     */       }
/*     */       else {
/* 287 */         providerClass = this.validationBootstrapParameters.getProviderClass();
/* 288 */         if (providerClass != null) {
/* 289 */           for (ValidationProvider<?> provider : this.providerResolver.getValidationProviders()) {
/* 290 */             if (providerClass.isAssignableFrom(provider.getClass())) {
/* 291 */               factory = provider.buildValidatorFactory(this);
/* 292 */               break;
/*     */             }
/*     */           }
/* 295 */           if (factory == null) {
/* 296 */             throw log.getUnableToFindProviderException(providerClass);
/*     */           }
/*     */         }
/*     */         else {
/* 300 */           Object providers = this.providerResolver.getValidationProviders();
/* 301 */           assert (((List)providers).size() != 0);
/* 302 */           factory = ((ValidationProvider)((List)providers).get(0)).buildValidatorFactory(this);
/*     */         }
/*     */       }
/*     */     } finally {
/*     */       Class<? extends ValidationProvider<?>> providerClass;
/*     */       InputStream in;
/* 308 */       for (InputStream in : this.configurationStreams) {
/*     */         try {
/* 310 */           in.close();
/*     */         }
/*     */         catch (IOException io) {
/* 313 */           log.unableToCloseInputStream();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 318 */     return factory;
/*     */   }
/*     */   
/*     */   public final boolean isIgnoreXmlConfiguration()
/*     */   {
/* 323 */     return this.ignoreXmlConfiguration;
/*     */   }
/*     */   
/*     */   public final MessageInterpolator getMessageInterpolator()
/*     */   {
/* 328 */     return this.validationBootstrapParameters.getMessageInterpolator();
/*     */   }
/*     */   
/*     */   public final Set<InputStream> getMappingStreams()
/*     */   {
/* 333 */     return this.validationBootstrapParameters.getMappings();
/*     */   }
/*     */   
/*     */   public final boolean getFailFast() {
/* 337 */     return this.failFast;
/*     */   }
/*     */   
/*     */   public final ConstraintValidatorFactory getConstraintValidatorFactory()
/*     */   {
/* 342 */     return this.validationBootstrapParameters.getConstraintValidatorFactory();
/*     */   }
/*     */   
/*     */   public final TraversableResolver getTraversableResolver()
/*     */   {
/* 347 */     return this.validationBootstrapParameters.getTraversableResolver();
/*     */   }
/*     */   
/*     */   public BootstrapConfiguration getBootstrapConfiguration()
/*     */   {
/* 352 */     if (this.bootstrapConfiguration == null) {
/* 353 */       this.bootstrapConfiguration = new ValidationXmlParser(this.externalClassLoader).parseValidationXml();
/*     */     }
/* 355 */     return this.bootstrapConfiguration;
/*     */   }
/*     */   
/*     */   public ParameterNameProvider getParameterNameProvider()
/*     */   {
/* 360 */     return this.validationBootstrapParameters.getParameterNameProvider();
/*     */   }
/*     */   
/*     */   public List<ValidatedValueUnwrapper<?>> getValidatedValueHandlers() {
/* 364 */     return this.validatedValueHandlers;
/*     */   }
/*     */   
/*     */   public TimeProvider getTimeProvider() {
/* 368 */     return this.timeProvider;
/*     */   }
/*     */   
/*     */   public final Map<String, String> getProperties()
/*     */   {
/* 373 */     return this.validationBootstrapParameters.getConfigProperties();
/*     */   }
/*     */   
/*     */   public ClassLoader getExternalClassLoader() {
/* 377 */     return this.externalClassLoader;
/*     */   }
/*     */   
/*     */   public final MessageInterpolator getDefaultMessageInterpolator()
/*     */   {
/* 382 */     return this.defaultMessageInterpolator;
/*     */   }
/*     */   
/*     */   public final TraversableResolver getDefaultTraversableResolver()
/*     */   {
/* 387 */     return this.defaultTraversableResolver;
/*     */   }
/*     */   
/*     */   public final ConstraintValidatorFactory getDefaultConstraintValidatorFactory()
/*     */   {
/* 392 */     return this.defaultConstraintValidatorFactory;
/*     */   }
/*     */   
/*     */   public final ResourceBundleLocator getDefaultResourceBundleLocator()
/*     */   {
/* 397 */     return this.defaultResourceBundleLocator;
/*     */   }
/*     */   
/*     */   public ParameterNameProvider getDefaultParameterNameProvider()
/*     */   {
/* 402 */     return this.defaultParameterNameProvider;
/*     */   }
/*     */   
/*     */   public final Set<DefaultConstraintMapping> getProgrammaticMappings() {
/* 406 */     return this.programmaticMappings;
/*     */   }
/*     */   
/*     */   private boolean isSpecificProvider() {
/* 410 */     return this.validationBootstrapParameters.getProvider() != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void parseValidationXml()
/*     */   {
/* 417 */     if (this.ignoreXmlConfiguration) {
/* 418 */       log.ignoringXmlConfiguration();
/*     */       
/*     */ 
/* 421 */       if (this.validationBootstrapParameters.getMessageInterpolator() == null) {
/* 422 */         this.validationBootstrapParameters.setMessageInterpolator(
/* 423 */           getDefaultMessageInterpolatorConfiguredWithClassLoader());
/*     */       }
/*     */       
/* 426 */       if (this.validationBootstrapParameters.getTraversableResolver() == null) {
/* 427 */         this.validationBootstrapParameters.setTraversableResolver(this.defaultTraversableResolver);
/*     */       }
/* 429 */       if (this.validationBootstrapParameters.getConstraintValidatorFactory() == null) {
/* 430 */         this.validationBootstrapParameters.setConstraintValidatorFactory(this.defaultConstraintValidatorFactory);
/*     */       }
/* 432 */       if (this.validationBootstrapParameters.getParameterNameProvider() == null) {
/* 433 */         this.validationBootstrapParameters.setParameterNameProvider(this.defaultParameterNameProvider);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 438 */       ValidationBootstrapParameters xmlParameters = new ValidationBootstrapParameters(getBootstrapConfiguration(), this.externalClassLoader);
/*     */       
/* 440 */       applyXmlSettings(xmlParameters);
/*     */     }
/*     */   }
/*     */   
/*     */   private void applyXmlSettings(ValidationBootstrapParameters xmlParameters) {
/* 445 */     this.validationBootstrapParameters.setProviderClass(xmlParameters.getProviderClass());
/*     */     
/* 447 */     if (this.validationBootstrapParameters.getMessageInterpolator() == null) {
/* 448 */       if (xmlParameters.getMessageInterpolator() != null) {
/* 449 */         this.validationBootstrapParameters.setMessageInterpolator(xmlParameters.getMessageInterpolator());
/*     */       }
/*     */       else {
/* 452 */         this.validationBootstrapParameters.setMessageInterpolator(
/* 453 */           getDefaultMessageInterpolatorConfiguredWithClassLoader());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 458 */     if (this.validationBootstrapParameters.getTraversableResolver() == null) {
/* 459 */       if (xmlParameters.getTraversableResolver() != null) {
/* 460 */         this.validationBootstrapParameters.setTraversableResolver(xmlParameters.getTraversableResolver());
/*     */       }
/*     */       else {
/* 463 */         this.validationBootstrapParameters.setTraversableResolver(this.defaultTraversableResolver);
/*     */       }
/*     */     }
/*     */     
/* 467 */     if (this.validationBootstrapParameters.getConstraintValidatorFactory() == null) {
/* 468 */       if (xmlParameters.getConstraintValidatorFactory() != null) {
/* 469 */         this.validationBootstrapParameters.setConstraintValidatorFactory(xmlParameters
/* 470 */           .getConstraintValidatorFactory());
/*     */       }
/*     */       else
/*     */       {
/* 474 */         this.validationBootstrapParameters.setConstraintValidatorFactory(this.defaultConstraintValidatorFactory);
/*     */       }
/*     */     }
/*     */     
/* 478 */     if (this.validationBootstrapParameters.getParameterNameProvider() == null) {
/* 479 */       if (xmlParameters.getParameterNameProvider() != null) {
/* 480 */         this.validationBootstrapParameters.setParameterNameProvider(xmlParameters.getParameterNameProvider());
/*     */       }
/*     */       else {
/* 483 */         this.validationBootstrapParameters.setParameterNameProvider(this.defaultParameterNameProvider);
/*     */       }
/*     */     }
/*     */     
/* 487 */     this.validationBootstrapParameters.addAllMappings(xmlParameters.getMappings());
/* 488 */     this.configurationStreams.addAll(xmlParameters.getMappings());
/*     */     
/* 490 */     for (Map.Entry<String, String> entry : xmlParameters.getConfigProperties().entrySet()) {
/* 491 */       if (this.validationBootstrapParameters.getConfigProperties().get(entry.getKey()) == null) {
/* 492 */         this.validationBootstrapParameters.addConfigProperty((String)entry.getKey(), (String)entry.getValue());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isJavaFxInClasspath() {
/* 498 */     return isClassPresent("javafx.application.Application", false);
/*     */   }
/*     */   
/*     */   private boolean isClassPresent(String className, boolean fallbackOnTCCL) {
/*     */     try {
/* 503 */       run(LoadClass.action(className, getClass().getClassLoader(), fallbackOnTCCL));
/* 504 */       return true;
/*     */     }
/*     */     catch (ValidationException e) {}
/* 507 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private MessageInterpolator getDefaultMessageInterpolatorConfiguredWithClassLoader()
/*     */   {
/* 515 */     return this.externalClassLoader != null ? new ResourceBundleMessageInterpolator(new PlatformResourceBundleLocator("ValidationMessages", this.externalClassLoader), new PlatformResourceBundleLocator("ContributorValidationMessages", this.externalClassLoader, true)) : this.defaultMessageInterpolator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static <T> T run(PrivilegedAction<T> action)
/*     */   {
/* 537 */     return (T)(System.getSecurityManager() != null ? AccessController.doPrivileged(action) : action.run());
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\engine\ConfigurationImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */