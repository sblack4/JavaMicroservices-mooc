/*     */ package org.hibernate.validator.internal.xml;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import javax.validation.ConstraintValidator;
/*     */ import javax.validation.ParameterNameProvider;
/*     */ import javax.xml.bind.JAXBContext;
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.validation.Schema;
/*     */ import org.hibernate.validator.internal.metadata.core.AnnotationProcessingOptions;
/*     */ import org.hibernate.validator.internal.metadata.core.AnnotationProcessingOptionsImpl;
/*     */ import org.hibernate.validator.internal.metadata.core.ConstraintHelper;
/*     */ import org.hibernate.validator.internal.metadata.location.ConstraintLocation;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedElement;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedExecutable;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedField;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedType;
/*     */ import org.hibernate.validator.internal.util.CollectionHelper;
/*     */ import org.hibernate.validator.internal.util.logging.Log;
/*     */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*     */ import org.hibernate.validator.internal.util.privilegedactions.NewJaxbContext;
/*     */ import org.hibernate.validator.internal.util.privilegedactions.Unmarshal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlMappingParser
/*     */ {
/*  54 */   private static final Log log = ;
/*     */   
/*  56 */   private final Set<Class<?>> processedClasses = CollectionHelper.newHashSet();
/*     */   
/*     */   private final ConstraintHelper constraintHelper;
/*     */   
/*     */   private final AnnotationProcessingOptionsImpl annotationProcessingOptions;
/*     */   
/*     */   private final Map<Class<?>, List<Class<?>>> defaultSequences;
/*     */   private final Map<Class<?>, Set<ConstrainedElement>> constrainedElements;
/*     */   private final XmlParserHelper xmlParserHelper;
/*     */   private final ParameterNameProvider parameterNameProvider;
/*     */   private final ClassLoadingHelper classLoadingHelper;
/*  67 */   private static final ConcurrentMap<String, String> SCHEMAS_BY_VERSION = new ConcurrentHashMap(2, 0.75F, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  74 */     SCHEMAS_BY_VERSION.put("1.0", "META-INF/validation-mapping-1.0.xsd");
/*  75 */     SCHEMAS_BY_VERSION.put("1.1", "META-INF/validation-mapping-1.1.xsd");
/*     */   }
/*     */   
/*     */   public XmlMappingParser(ConstraintHelper constraintHelper, ParameterNameProvider parameterNameProvider, ClassLoader externalClassLoader)
/*     */   {
/*  80 */     this.constraintHelper = constraintHelper;
/*  81 */     this.annotationProcessingOptions = new AnnotationProcessingOptionsImpl();
/*  82 */     this.defaultSequences = CollectionHelper.newHashMap();
/*  83 */     this.constrainedElements = CollectionHelper.newHashMap();
/*  84 */     this.xmlParserHelper = new XmlParserHelper();
/*  85 */     this.parameterNameProvider = parameterNameProvider;
/*  86 */     this.classLoadingHelper = new ClassLoadingHelper(externalClassLoader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void parse(Set<InputStream> mappingStreams)
/*     */   {
/*     */     try
/*     */     {
/*  99 */       jc = (JAXBContext)run(NewJaxbContext.action(ConstraintMappingsType.class));
/*     */       
/* 101 */       MetaConstraintBuilder metaConstraintBuilder = new MetaConstraintBuilder(this.classLoadingHelper, this.constraintHelper);
/*     */       
/*     */ 
/*     */ 
/* 105 */       GroupConversionBuilder groupConversionBuilder = new GroupConversionBuilder(this.classLoadingHelper);
/*     */       
/* 107 */       constrainedTypeBuilder = new ConstrainedTypeBuilder(this.classLoadingHelper, metaConstraintBuilder, this.annotationProcessingOptions, this.defaultSequences);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 113 */       constrainedFieldBuilder = new ConstrainedFieldBuilder(metaConstraintBuilder, groupConversionBuilder, this.annotationProcessingOptions);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 118 */       constrainedExecutableBuilder = new ConstrainedExecutableBuilder(this.classLoadingHelper, this.parameterNameProvider, metaConstraintBuilder, groupConversionBuilder, this.annotationProcessingOptions);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */       constrainedGetterBuilder = new ConstrainedGetterBuilder(metaConstraintBuilder, groupConversionBuilder, this.annotationProcessingOptions);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 131 */       alreadyProcessedConstraintDefinitions = CollectionHelper.newHashSet();
/* 132 */       for (InputStream in : mappingStreams)
/*     */       {
/*     */ 
/* 135 */         boolean markSupported = in.markSupported();
/* 136 */         if (markSupported) {
/* 137 */           in.mark(Integer.MAX_VALUE);
/*     */         }
/*     */         
/* 140 */         XMLEventReader xmlEventReader = this.xmlParserHelper.createXmlEventReader("constraint mapping file", new CloseIgnoringInputStream(in));
/* 141 */         String schemaVersion = this.xmlParserHelper.getSchemaVersion("constraint mapping file", xmlEventReader);
/* 142 */         String schemaResourceName = getSchemaResourceName(schemaVersion);
/* 143 */         Schema schema = this.xmlParserHelper.getSchema(schemaResourceName);
/*     */         
/* 145 */         Unmarshaller unmarshaller = jc.createUnmarshaller();
/* 146 */         unmarshaller.setSchema(schema);
/*     */         
/* 148 */         ConstraintMappingsType mapping = getValidationConfig(xmlEventReader, unmarshaller);
/* 149 */         String defaultPackage = mapping.getDefaultPackage();
/*     */         
/* 151 */         parseConstraintDefinitions(mapping
/* 152 */           .getConstraintDefinition(), defaultPackage, alreadyProcessedConstraintDefinitions);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 157 */         for (BeanType bean : mapping.getBean()) {
/* 158 */           processBeanType(constrainedTypeBuilder, constrainedFieldBuilder, constrainedExecutableBuilder, constrainedGetterBuilder, defaultPackage, bean);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 168 */         if (markSupported)
/*     */           try {
/* 170 */             in.reset();
/*     */           }
/*     */           catch (IOException e) {
/* 173 */             log.debug("Unable to reset input stream."); } } } catch (JAXBException e) { JAXBContext jc;
/*     */       ConstrainedTypeBuilder constrainedTypeBuilder;
/*     */       ConstrainedFieldBuilder constrainedFieldBuilder;
/*     */       ConstrainedExecutableBuilder constrainedExecutableBuilder;
/*     */       ConstrainedGetterBuilder constrainedGetterBuilder;
/*     */       Set<String> alreadyProcessedConstraintDefinitions;
/* 179 */       throw log.getErrorParsingMappingFileException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public final Set<Class<?>> getXmlConfiguredClasses() {
/* 184 */     return this.processedClasses;
/*     */   }
/*     */   
/*     */   public final AnnotationProcessingOptions getAnnotationProcessingOptions() {
/* 188 */     return this.annotationProcessingOptions;
/*     */   }
/*     */   
/*     */   public final Set<ConstrainedElement> getConstrainedElementsForClass(Class<?> beanClass) {
/* 192 */     if (this.constrainedElements.containsKey(beanClass)) {
/* 193 */       return (Set)this.constrainedElements.get(beanClass);
/*     */     }
/*     */     
/* 196 */     return Collections.emptySet();
/*     */   }
/*     */   
/*     */   public final List<Class<?>> getDefaultSequenceForClass(Class<?> beanClass)
/*     */   {
/* 201 */     return (List)this.defaultSequences.get(beanClass);
/*     */   }
/*     */   
/*     */   private void processBeanType(ConstrainedTypeBuilder constrainedTypeBuilder, ConstrainedFieldBuilder constrainedFieldBuilder, ConstrainedExecutableBuilder constrainedExecutableBuilder, ConstrainedGetterBuilder constrainedGetterBuilder, String defaultPackage, BeanType bean) {
/* 205 */     Class<?> beanClass = this.classLoadingHelper.loadClass(bean.getClazz(), defaultPackage);
/* 206 */     checkClassHasNotBeenProcessed(this.processedClasses, beanClass);
/*     */     
/*     */ 
/* 209 */     this.annotationProcessingOptions.ignoreAnnotationConstraintForClass(beanClass, bean
/*     */     
/* 211 */       .getIgnoreAnnotations());
/*     */     
/*     */ 
/* 214 */     ConstrainedType constrainedType = constrainedTypeBuilder.buildConstrainedType(bean
/* 215 */       .getClassType(), beanClass, defaultPackage);
/*     */     
/*     */ 
/*     */ 
/* 219 */     if (constrainedType != null) {
/* 220 */       addConstrainedElement(beanClass, constrainedType);
/*     */     }
/*     */     
/* 223 */     Set<ConstrainedField> constrainedFields = constrainedFieldBuilder.buildConstrainedFields(bean
/* 224 */       .getField(), beanClass, defaultPackage);
/*     */     
/*     */ 
/*     */ 
/* 228 */     addConstrainedElements(beanClass, constrainedFields);
/*     */     
/* 230 */     Set<ConstrainedExecutable> constrainedGetters = constrainedGetterBuilder.buildConstrainedGetters(bean
/* 231 */       .getGetter(), beanClass, defaultPackage);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 236 */     addConstrainedElements(beanClass, constrainedGetters);
/*     */     
/* 238 */     Set<ConstrainedExecutable> constrainedConstructors = constrainedExecutableBuilder.buildConstructorConstrainedExecutable(bean
/* 239 */       .getConstructor(), beanClass, defaultPackage);
/*     */     
/*     */ 
/*     */ 
/* 243 */     addConstrainedElements(beanClass, constrainedConstructors);
/*     */     
/* 245 */     Set<ConstrainedExecutable> constrainedMethods = constrainedExecutableBuilder.buildMethodConstrainedExecutable(bean
/* 246 */       .getMethod(), beanClass, defaultPackage);
/*     */     
/*     */ 
/*     */ 
/* 250 */     addConstrainedElements(beanClass, constrainedMethods);
/*     */     
/* 252 */     this.processedClasses.add(beanClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void parseConstraintDefinitions(List<ConstraintDefinitionType> constraintDefinitionList, String defaultPackage, Set<String> alreadyProcessedConstraintDefinitions)
/*     */   {
/* 259 */     for (ConstraintDefinitionType constraintDefinition : constraintDefinitionList) {
/* 260 */       String annotationClassName = constraintDefinition.getAnnotation();
/* 261 */       if (alreadyProcessedConstraintDefinitions.contains(annotationClassName)) {
/* 262 */         throw log.getOverridingConstraintDefinitionsInMultipleMappingFilesException(annotationClassName);
/*     */       }
/*     */       
/* 265 */       alreadyProcessedConstraintDefinitions.add(annotationClassName);
/*     */       
/*     */ 
/* 268 */       Class<?> clazz = this.classLoadingHelper.loadClass(annotationClassName, defaultPackage);
/* 269 */       if (!clazz.isAnnotation()) {
/* 270 */         throw log.getIsNotAnAnnotationException(annotationClassName);
/*     */       }
/* 272 */       Class<? extends Annotation> annotationClass = clazz;
/*     */       
/* 274 */       addValidatorDefinitions(annotationClass, defaultPackage, constraintDefinition.getValidatedBy());
/*     */     }
/*     */   }
/*     */   
/*     */   private <A extends Annotation> void addValidatorDefinitions(Class<A> annotationClass, String defaultPackage, ValidatedByType validatedByType)
/*     */   {
/* 280 */     List<Class<? extends ConstraintValidator<A, ?>>> constraintValidatorClasses = CollectionHelper.newArrayList();
/*     */     
/* 282 */     for (String validatorClassName : validatedByType.getValue())
/*     */     {
/*     */ 
/* 285 */       Class<? extends ConstraintValidator<A, ?>> validatorClass = this.classLoadingHelper.loadClass(validatorClassName, defaultPackage);
/*     */       
/* 287 */       if (!ConstraintValidator.class.isAssignableFrom(validatorClass)) {
/* 288 */         throw log.getIsNotAConstraintValidatorClassException(validatorClass);
/*     */       }
/*     */       
/* 291 */       constraintValidatorClasses.add(validatorClass);
/*     */     }
/* 293 */     this.constraintHelper.putValidatorClasses(annotationClass, constraintValidatorClasses, Boolean.TRUE
/*     */     
/*     */ 
/* 296 */       .equals(validatedByType.getIncludeExistingValidators()));
/*     */   }
/*     */   
/*     */   private void checkClassHasNotBeenProcessed(Set<Class<?>> processedClasses, Class<?> beanClass)
/*     */   {
/* 301 */     if (processedClasses.contains(beanClass)) {
/* 302 */       throw log.getBeanClassHasAlreadyBeConfiguredInXmlException(beanClass.getName());
/*     */     }
/*     */   }
/*     */   
/*     */   private void addConstrainedElement(Class<?> beanClass, ConstrainedElement constrainedElement) {
/* 307 */     if (this.constrainedElements.containsKey(beanClass)) {
/* 308 */       ((Set)this.constrainedElements.get(beanClass)).add(constrainedElement);
/*     */     }
/*     */     else {
/* 311 */       Set<ConstrainedElement> tmpList = CollectionHelper.newHashSet();
/* 312 */       tmpList.add(constrainedElement);
/* 313 */       this.constrainedElements.put(beanClass, tmpList);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addConstrainedElements(Class<?> beanClass, Set<? extends ConstrainedElement> newConstrainedElements) { Set<ConstrainedElement> existingConstrainedElements;
/* 318 */     if (this.constrainedElements.containsKey(beanClass)) {
/* 319 */       existingConstrainedElements = (Set)this.constrainedElements.get(beanClass);
/* 320 */       for (ConstrainedElement constrainedElement : newConstrainedElements) {
/* 321 */         for (ConstrainedElement existingConstrainedElement : existingConstrainedElements) {
/* 322 */           if ((existingConstrainedElement.getLocation().getMember() != null) && 
/* 323 */             (existingConstrainedElement.getLocation().getMember().equals(constrainedElement
/* 324 */             .getLocation().getMember())))
/*     */           {
/* 326 */             ConstraintLocation location = constrainedElement.getLocation();
/* 327 */             throw log.getConstrainedElementConfiguredMultipleTimesException(location
/* 328 */               .getMember().toString());
/*     */           }
/*     */         }
/*     */         
/* 332 */         existingConstrainedElements.add(constrainedElement);
/*     */       }
/*     */     }
/*     */     else {
/* 336 */       Set<ConstrainedElement> tmpSet = CollectionHelper.newHashSet();
/* 337 */       tmpSet.addAll(newConstrainedElements);
/* 338 */       this.constrainedElements.put(beanClass, tmpSet);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private ConstraintMappingsType getValidationConfig(XMLEventReader xmlEventReader, Unmarshaller unmarshaller)
/*     */   {
/*     */     try
/*     */     {
/* 347 */       JAXBElement<ConstraintMappingsType> root = (JAXBElement)run(
/* 348 */         Unmarshal.action(unmarshaller, xmlEventReader, ConstraintMappingsType.class));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 354 */       constraintMappings = (ConstraintMappingsType)root.getValue();
/*     */     } catch (Exception e) {
/*     */       ConstraintMappingsType constraintMappings;
/* 357 */       throw log.getErrorParsingMappingFileException(e); }
/*     */     ConstraintMappingsType constraintMappings;
/* 359 */     return constraintMappings;
/*     */   }
/*     */   
/*     */   private String getSchemaResourceName(String schemaVersion) {
/* 363 */     String schemaResource = (String)SCHEMAS_BY_VERSION.get(schemaVersion);
/*     */     
/* 365 */     if (schemaResource == null) {
/* 366 */       throw log.getUnsupportedSchemaVersionException("constraint mapping file", schemaVersion);
/*     */     }
/*     */     
/* 369 */     return schemaResource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private <T> T run(PrivilegedExceptionAction<T> action)
/*     */     throws JAXBException
/*     */   {
/*     */     try
/*     */     {
/* 380 */       return (T)(System.getSecurityManager() != null ? AccessController.doPrivileged(action) : action.run());
/*     */     }
/*     */     catch (JAXBException e) {
/* 383 */       throw e;
/*     */     }
/*     */     catch (Exception e) {
/* 386 */       throw log.getErrorParsingMappingFileException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class CloseIgnoringInputStream
/*     */     extends FilterInputStream
/*     */   {
/*     */     public CloseIgnoringInputStream(InputStream in)
/*     */     {
/* 395 */       super();
/*     */     }
/*     */     
/*     */     public void close() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\xml\XmlMappingParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */