/*    */ package org.hibernate.validator.internal.constraintvalidators.hv;
/*    */ 
/*    */ import java.net.MalformedURLException;
/*    */ import javax.validation.ConstraintValidator;
/*    */ import javax.validation.ConstraintValidatorContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class URLValidator
/*    */   implements ConstraintValidator<org.hibernate.validator.constraints.URL, CharSequence>
/*    */ {
/*    */   private String protocol;
/*    */   private String host;
/*    */   private int port;
/*    */   
/*    */   public void initialize(org.hibernate.validator.constraints.URL url)
/*    */   {
/* 24 */     this.protocol = url.protocol();
/* 25 */     this.host = url.host();
/* 26 */     this.port = url.port();
/*    */   }
/*    */   
/*    */   public boolean isValid(CharSequence value, ConstraintValidatorContext constraintValidatorContext) {
/* 30 */     if ((value == null) || (value.length() == 0)) {
/* 31 */       return true;
/*    */     }
/*    */     
/*    */     try
/*    */     {
/* 36 */       url = new java.net.URL(value.toString());
/*    */     } catch (MalformedURLException e) {
/*    */       java.net.URL url;
/* 39 */       return false;
/*    */     }
/*    */     java.net.URL url;
/* 42 */     if ((this.protocol != null) && (this.protocol.length() > 0) && (!url.getProtocol().equals(this.protocol))) {
/* 43 */       return false;
/*    */     }
/*    */     
/* 46 */     if ((this.host != null) && (this.host.length() > 0) && (!url.getHost().equals(this.host))) {
/* 47 */       return false;
/*    */     }
/*    */     
/* 50 */     if ((this.port != -1) && (url.getPort() != this.port)) {
/* 51 */       return false;
/*    */     }
/*    */     
/* 54 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\constraintvalidators\hv\URLValidator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */