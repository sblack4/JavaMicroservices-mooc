/*     */ package org.hibernate.validator.internal.engine.path;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.validation.ElementKind;
/*     */ import javax.validation.Path.BeanNode;
/*     */ import javax.validation.Path.ConstructorNode;
/*     */ import javax.validation.Path.CrossParameterNode;
/*     */ import javax.validation.Path.MethodNode;
/*     */ import javax.validation.Path.Node;
/*     */ import javax.validation.Path.ParameterNode;
/*     */ import javax.validation.Path.PropertyNode;
/*     */ import javax.validation.Path.ReturnValueNode;
/*     */ import org.hibernate.validator.internal.util.Contracts;
/*     */ import org.hibernate.validator.internal.util.logging.Log;
/*     */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*     */ import org.hibernate.validator.path.PropertyNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NodeImpl
/*     */   implements Path.PropertyNode, Path.MethodNode, Path.ConstructorNode, Path.BeanNode, Path.ParameterNode, Path.ReturnValueNode, Path.CrossParameterNode, PropertyNode, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2075466571633860499L;
/*  36 */   private static final Class<?>[] EMPTY_CLASS_ARRAY = new Class[0];
/*     */   
/*  38 */   private static final Log log = LoggerFactory.make();
/*     */   
/*     */   private static final String INDEX_OPEN = "[";
/*     */   
/*     */   private static final String INDEX_CLOSE = "]";
/*     */   
/*     */   private static final String RETURN_VALUE_NODE_NAME = "<return value>";
/*     */   
/*     */   private static final String CROSS_PARAMETER_NODE_NAME = "<cross-parameter>";
/*     */   private final String name;
/*     */   private final NodeImpl parent;
/*     */   private final boolean isIterable;
/*     */   private final Integer index;
/*     */   private final Object key;
/*     */   private final ElementKind kind;
/*     */   private final int hashCode;
/*     */   private final Class<?>[] parameterTypes;
/*     */   private final Integer parameterIndex;
/*     */   private final Object value;
/*     */   private String asString;
/*     */   
/*     */   private NodeImpl(String name, NodeImpl parent, boolean indexable, Integer index, Object key, ElementKind kind, Class<?>[] parameterTypes, Integer parameterIndex, Object value)
/*     */   {
/*  61 */     this.name = name;
/*  62 */     this.parent = parent;
/*  63 */     this.index = index;
/*  64 */     this.key = key;
/*  65 */     this.value = value;
/*  66 */     this.isIterable = indexable;
/*  67 */     this.kind = kind;
/*  68 */     this.parameterTypes = parameterTypes;
/*  69 */     this.parameterIndex = parameterIndex;
/*  70 */     this.hashCode = buildHashCode();
/*     */   }
/*     */   
/*     */   public static NodeImpl createPropertyNode(String name, NodeImpl parent)
/*     */   {
/*  75 */     return new NodeImpl(name, parent, false, null, null, ElementKind.PROPERTY, EMPTY_CLASS_ARRAY, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NodeImpl createParameterNode(String name, NodeImpl parent, int parameterIndex)
/*     */   {
/*  97 */     return new NodeImpl(name, parent, false, null, null, ElementKind.PARAMETER, EMPTY_CLASS_ARRAY, Integer.valueOf(parameterIndex), null);
/*     */   }
/*     */   
/*     */ 
/*     */   public static NodeImpl createCrossParameterNode(NodeImpl parent)
/*     */   {
/* 103 */     return new NodeImpl("<cross-parameter>", parent, false, null, null, ElementKind.CROSS_PARAMETER, EMPTY_CLASS_ARRAY, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NodeImpl createMethodNode(String name, NodeImpl parent, Class<?>[] parameterTypes)
/*     */   {
/* 117 */     return new NodeImpl(name, parent, false, null, null, ElementKind.METHOD, parameterTypes, null, null);
/*     */   }
/*     */   
/*     */   public static NodeImpl createConstructorNode(String name, NodeImpl parent, Class<?>[] parameterTypes) {
/* 121 */     return new NodeImpl(name, parent, false, null, null, ElementKind.CONSTRUCTOR, parameterTypes, null, null);
/*     */   }
/*     */   
/*     */   public static NodeImpl createBeanNode(NodeImpl parent) {
/* 125 */     return new NodeImpl(null, parent, false, null, null, ElementKind.BEAN, EMPTY_CLASS_ARRAY, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NodeImpl createReturnValue(NodeImpl parent)
/*     */   {
/* 139 */     return new NodeImpl("<return value>", parent, false, null, null, ElementKind.RETURN_VALUE, EMPTY_CLASS_ARRAY, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NodeImpl makeIterable(NodeImpl node)
/*     */   {
/* 153 */     return new NodeImpl(node.name, node.parent, true, null, null, node.kind, node.parameterTypes, node.parameterIndex, node.value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NodeImpl setIndex(NodeImpl node, Integer index)
/*     */   {
/* 168 */     return new NodeImpl(node.name, node.parent, true, index, null, node.kind, node.parameterTypes, node.parameterIndex, node.value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NodeImpl setMapKey(NodeImpl node, Object key)
/*     */   {
/* 182 */     return new NodeImpl(node.name, node.parent, true, null, key, node.kind, node.parameterTypes, node.parameterIndex, node.value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NodeImpl setPropertyValue(NodeImpl node, Object value)
/*     */   {
/* 196 */     return new NodeImpl(node.name, node.parent, node.isIterable, node.index, node.key, node.kind, node.parameterTypes, node.parameterIndex, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getName()
/*     */   {
/* 211 */     return this.name;
/*     */   }
/*     */   
/*     */   public final boolean isInIterable()
/*     */   {
/* 216 */     return (this.parent != null) && (this.parent.isIterable());
/*     */   }
/*     */   
/*     */   public final boolean isIterable() {
/* 220 */     return this.isIterable;
/*     */   }
/*     */   
/*     */   public final Integer getIndex()
/*     */   {
/* 225 */     if (this.parent == null) {
/* 226 */       return null;
/*     */     }
/*     */     
/* 229 */     return this.parent.index;
/*     */   }
/*     */   
/*     */ 
/*     */   public final Object getKey()
/*     */   {
/* 235 */     if (this.parent == null) {
/* 236 */       return null;
/*     */     }
/*     */     
/* 239 */     return this.parent.key;
/*     */   }
/*     */   
/*     */   public final NodeImpl getParent()
/*     */   {
/* 244 */     return this.parent;
/*     */   }
/*     */   
/*     */   public ElementKind getKind()
/*     */   {
/* 249 */     return this.kind;
/*     */   }
/*     */   
/*     */   public <T extends Path.Node> T as(Class<T> nodeType)
/*     */   {
/* 254 */     if (((this.kind == ElementKind.BEAN) && (nodeType == Path.BeanNode.class)) || ((this.kind == ElementKind.CONSTRUCTOR) && (nodeType == Path.ConstructorNode.class)) || ((this.kind == ElementKind.CROSS_PARAMETER) && (nodeType == Path.CrossParameterNode.class)) || ((this.kind == ElementKind.METHOD) && (nodeType == Path.MethodNode.class)) || ((this.kind == ElementKind.PARAMETER) && (nodeType == Path.ParameterNode.class)) || ((this.kind == ElementKind.PROPERTY) && ((nodeType == Path.PropertyNode.class) || (nodeType == PropertyNode.class))) || ((this.kind == ElementKind.RETURN_VALUE) && (nodeType == Path.ReturnValueNode.class)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 261 */       return (Path.Node)nodeType.cast(this);
/*     */     }
/*     */     
/* 264 */     throw log.getUnableToNarrowNodeTypeException(getClass().getName(), this.kind, nodeType.getName());
/*     */   }
/*     */   
/*     */   public List<Class<?>> getParameterTypes()
/*     */   {
/* 269 */     return Arrays.asList(this.parameterTypes);
/*     */   }
/*     */   
/*     */   public int getParameterIndex()
/*     */   {
/* 274 */     Contracts.assertTrue(this.kind == ElementKind.PARAMETER, "getParameterIndex() may only be invoked for nodes of ElementKind.PARAMETER.");
/*     */     
/*     */ 
/*     */ 
/* 278 */     return this.parameterIndex.intValue();
/*     */   }
/*     */   
/*     */   public Object getValue()
/*     */   {
/* 283 */     return this.value;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 288 */     return asString();
/*     */   }
/*     */   
/*     */   public final String asString() {
/* 292 */     if (this.asString == null) {
/* 293 */       this.asString = buildToString();
/*     */     }
/* 295 */     return this.asString;
/*     */   }
/*     */   
/*     */   private String buildToString() {
/* 299 */     StringBuilder builder = new StringBuilder();
/*     */     
/* 301 */     if (ElementKind.BEAN.equals(getKind()))
/*     */     {
/* 303 */       builder.append("");
/*     */     }
/*     */     else {
/* 306 */       builder.append(getName());
/*     */     }
/*     */     
/* 309 */     if (isIterable()) {
/* 310 */       builder.append("[");
/* 311 */       if (this.index != null) {
/* 312 */         builder.append(this.index);
/*     */       }
/* 314 */       else if (this.key != null) {
/* 315 */         builder.append(this.key);
/*     */       }
/* 317 */       builder.append("]");
/*     */     }
/* 319 */     return builder.toString();
/*     */   }
/*     */   
/*     */   public int buildHashCode() {
/* 323 */     int prime = 31;
/* 324 */     int result = 1;
/* 325 */     result = 31 * result + (this.index == null ? 0 : this.index.hashCode());
/* 326 */     result = 31 * result + (this.isIterable ? 1231 : 1237);
/* 327 */     result = 31 * result + (this.key == null ? 0 : this.key.hashCode());
/* 328 */     result = 31 * result + (this.kind == null ? 0 : this.kind.hashCode());
/* 329 */     result = 31 * result + (this.name == null ? 0 : this.name.hashCode());
/* 330 */     result = 31 * result + (this.parameterIndex == null ? 0 : this.parameterIndex.hashCode());
/* 331 */     result = 31 * result + (this.parameterTypes == null ? 0 : this.parameterTypes.hashCode());
/* 332 */     result = 31 * result + (this.parent == null ? 0 : this.parent.hashCode());
/* 333 */     return result;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 338 */     return this.hashCode;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 343 */     if (this == obj) {
/* 344 */       return true;
/*     */     }
/* 346 */     if (obj == null) {
/* 347 */       return false;
/*     */     }
/* 349 */     if (getClass() != obj.getClass()) {
/* 350 */       return false;
/*     */     }
/* 352 */     NodeImpl other = (NodeImpl)obj;
/* 353 */     if (this.index == null) {
/* 354 */       if (other.index != null) {
/* 355 */         return false;
/*     */       }
/*     */     }
/* 358 */     else if (!this.index.equals(other.index)) {
/* 359 */       return false;
/*     */     }
/* 361 */     if (this.isIterable != other.isIterable) {
/* 362 */       return false;
/*     */     }
/* 364 */     if (this.key == null) {
/* 365 */       if (other.key != null) {
/* 366 */         return false;
/*     */       }
/*     */     }
/* 369 */     else if (!this.key.equals(other.key)) {
/* 370 */       return false;
/*     */     }
/* 372 */     if (this.kind != other.kind) {
/* 373 */       return false;
/*     */     }
/* 375 */     if (this.name == null) {
/* 376 */       if (other.name != null) {
/* 377 */         return false;
/*     */       }
/*     */     }
/* 380 */     else if (!this.name.equals(other.name)) {
/* 381 */       return false;
/*     */     }
/* 383 */     if (this.parameterIndex == null) {
/* 384 */       if (other.parameterIndex != null) {
/* 385 */         return false;
/*     */       }
/*     */     }
/* 388 */     else if (!this.parameterIndex.equals(other.parameterIndex)) {
/* 389 */       return false;
/*     */     }
/* 391 */     if (this.parameterTypes == null) {
/* 392 */       if (other.parameterTypes != null) {
/* 393 */         return false;
/*     */       }
/*     */     }
/* 396 */     else if (!this.parameterTypes.equals(other.parameterTypes)) {
/* 397 */       return false;
/*     */     }
/* 399 */     if (this.parent == null) {
/* 400 */       if (other.parent != null) {
/* 401 */         return false;
/*     */       }
/*     */     }
/* 404 */     else if (!this.parent.equals(other.parent)) {
/* 405 */       return false;
/*     */     }
/* 407 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\engine\path\NodeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */