/*     */ package org.hibernate.validator.internal.metadata.aggregated;
/*     */ 
/*     */ import java.lang.annotation.ElementType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.validation.ElementKind;
/*     */ import javax.validation.metadata.GroupConversionDescriptor;
/*     */ import javax.validation.metadata.ReturnValueDescriptor;
/*     */ import org.hibernate.validator.internal.engine.valuehandling.UnwrapMode;
/*     */ import org.hibernate.validator.internal.metadata.core.MetaConstraint;
/*     */ import org.hibernate.validator.internal.metadata.descriptor.ReturnValueDescriptorImpl;
/*     */ import org.hibernate.validator.internal.metadata.facets.Cascadable;
/*     */ import org.hibernate.validator.internal.metadata.facets.Validatable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReturnValueMetaData
/*     */   extends AbstractConstraintMetaData
/*     */   implements Validatable, Cascadable
/*     */ {
/*  35 */   private static final String RETURN_VALUE_NODE_NAME = null;
/*     */   
/*     */ 
/*     */ 
/*     */   private final List<Cascadable> cascadables;
/*     */   
/*     */ 
/*     */   private final GroupConversionHelper groupConversionHelper;
/*     */   
/*     */ 
/*     */   private final Set<MetaConstraint<?>> typeArgumentsConstraints;
/*     */   
/*     */ 
/*     */ 
/*     */   public ReturnValueMetaData(Type type, Set<MetaConstraint<?>> constraints, Set<MetaConstraint<?>> typeArgumentsConstraints, boolean isCascading, Map<Class<?>, Class<?>> groupConversions, UnwrapMode unwrapMode)
/*     */   {
/*  51 */     super(RETURN_VALUE_NODE_NAME, type, constraints, ElementKind.RETURN_VALUE, isCascading, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  57 */       (!constraints.isEmpty()) || (isCascading) || (!typeArgumentsConstraints.isEmpty()), unwrapMode);
/*     */     
/*     */ 
/*     */ 
/*  61 */     this.typeArgumentsConstraints = Collections.unmodifiableSet(typeArgumentsConstraints);
/*  62 */     this.cascadables = Collections.unmodifiableList(isCascading ? Arrays.asList(new ReturnValueMetaData[] { this }) : Collections.emptyList());
/*  63 */     this.groupConversionHelper = new GroupConversionHelper(groupConversions);
/*  64 */     this.groupConversionHelper.validateGroupConversions(isCascading(), toString());
/*     */   }
/*     */   
/*     */   public Iterable<Cascadable> getCascadables()
/*     */   {
/*  69 */     return this.cascadables;
/*     */   }
/*     */   
/*     */   public Class<?> convertGroup(Class<?> originalGroup)
/*     */   {
/*  74 */     return this.groupConversionHelper.convertGroup(originalGroup);
/*     */   }
/*     */   
/*     */   public Set<GroupConversionDescriptor> getGroupConversionDescriptors()
/*     */   {
/*  79 */     return this.groupConversionHelper.asDescriptors();
/*     */   }
/*     */   
/*     */   public ElementType getElementType()
/*     */   {
/*  84 */     return ElementType.METHOD;
/*     */   }
/*     */   
/*     */   public Set<MetaConstraint<?>> getTypeArgumentsConstraints()
/*     */   {
/*  89 */     return this.typeArgumentsConstraints;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReturnValueDescriptor asDescriptor(boolean defaultGroupSequenceRedefined, List<Class<?>> defaultGroupSequence)
/*     */   {
/* 100 */     return new ReturnValueDescriptorImpl(getType(), asDescriptors(getConstraints()), isCascading(), defaultGroupSequenceRedefined, defaultGroupSequence, this.groupConversionHelper.asDescriptors());
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\metadata\aggregated\ReturnValueMetaData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */