/*     */ package org.hibernate.validator.internal.metadata.aggregated;
/*     */ 
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.validation.ElementKind;
/*     */ import javax.validation.metadata.ParameterDescriptor;
/*     */ import org.hibernate.validator.internal.engine.valuehandling.UnwrapMode;
/*     */ import org.hibernate.validator.internal.metadata.aggregated.rule.MethodConfigurationRule;
/*     */ import org.hibernate.validator.internal.metadata.aggregated.rule.OverridingMethodMustNotAlterParameterConstraints;
/*     */ import org.hibernate.validator.internal.metadata.aggregated.rule.ParallelMethodsMustNotDefineGroupConversionForCascadedReturnValue;
/*     */ import org.hibernate.validator.internal.metadata.aggregated.rule.ParallelMethodsMustNotDefineParameterConstraints;
/*     */ import org.hibernate.validator.internal.metadata.aggregated.rule.ReturnValueMayOnlyBeMarkedOnceAsCascadedPerHierarchyLine;
/*     */ import org.hibernate.validator.internal.metadata.aggregated.rule.VoidMethodsMustNotBeReturnValueConstrained;
/*     */ import org.hibernate.validator.internal.metadata.core.ConstraintHelper;
/*     */ import org.hibernate.validator.internal.metadata.core.MetaConstraint;
/*     */ import org.hibernate.validator.internal.metadata.descriptor.ExecutableDescriptorImpl;
/*     */ import org.hibernate.validator.internal.metadata.location.ConstraintLocation;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedElement;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedElement.ConstrainedElementKind;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedExecutable;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedParameter;
/*     */ import org.hibernate.validator.internal.metadata.raw.ExecutableElement;
/*     */ import org.hibernate.validator.internal.util.CollectionHelper;
/*     */ import org.hibernate.validator.internal.util.ExecutableHelper;
/*     */ import org.hibernate.validator.internal.util.ReflectionHelper;
/*     */ import org.hibernate.validator.internal.util.logging.Log;
/*     */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExecutableMetaData
/*     */   extends AbstractConstraintMetaData
/*     */ {
/*  63 */   private static final Log log = ;
/*     */   
/*     */ 
/*     */ 
/*     */   private final Class<?>[] parameterTypes;
/*     */   
/*     */ 
/*     */ 
/*     */   private final List<ParameterMetaData> parameterMetaDataList;
/*     */   
/*     */ 
/*     */ 
/*     */   private final Set<MetaConstraint<?>> crossParameterConstraints;
/*     */   
/*     */ 
/*     */ 
/*     */   private final boolean isGetter;
/*     */   
/*     */ 
/*     */ 
/*     */   private final Set<String> signatures;
/*     */   
/*     */ 
/*     */ 
/*     */   private final ReturnValueMetaData returnValueMetaData;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ExecutableMetaData(String name, Type returnType, Class<?>[] parameterTypes, ElementKind kind, Set<String> signatures, Set<MetaConstraint<?>> returnValueConstraints, List<ParameterMetaData> parameterMetaData, Set<MetaConstraint<?>> crossParameterConstraints, Set<MetaConstraint<?>> typeArgumentsConstraints, Map<Class<?>, Class<?>> returnValueGroupConversions, boolean isCascading, boolean isConstrained, boolean isGetter, UnwrapMode unwrapMode)
/*     */   {
/*  94 */     super(name, returnType, returnValueConstraints, kind, isCascading, isConstrained, unwrapMode);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 104 */     this.parameterTypes = parameterTypes;
/* 105 */     this.parameterMetaDataList = Collections.unmodifiableList(parameterMetaData);
/* 106 */     this.crossParameterConstraints = Collections.unmodifiableSet(crossParameterConstraints);
/* 107 */     this.signatures = signatures;
/* 108 */     this.returnValueMetaData = new ReturnValueMetaData(returnType, returnValueConstraints, typeArgumentsConstraints, isCascading, returnValueGroupConversions, unwrapMode);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 116 */     this.isGetter = isGetter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ParameterMetaData getParameterMetaData(int parameterIndex)
/*     */   {
/* 127 */     if ((parameterIndex < 0) || (parameterIndex > this.parameterMetaDataList.size() - 1)) {
/* 128 */       throw log.getInvalidExecutableParameterIndexException(
/* 129 */         ExecutableElement.getExecutableAsString(
/* 130 */         getType().toString() + "#" + getName(), this.parameterTypes), this.parameterTypes.length);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 136 */     return (ParameterMetaData)this.parameterMetaDataList.get(parameterIndex);
/*     */   }
/*     */   
/*     */   public Class<?>[] getParameterTypes() {
/* 140 */     return this.parameterTypes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<String> getSignatures()
/*     */   {
/* 152 */     return this.signatures;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<MetaConstraint<?>> getCrossParameterConstraints()
/*     */   {
/* 164 */     return this.crossParameterConstraints;
/*     */   }
/*     */   
/*     */   public ValidatableParametersMetaData getValidatableParametersMetaData() {
/* 168 */     Set<ParameterMetaData> cascadedParameters = CollectionHelper.newHashSet();
/*     */     
/* 170 */     for (ParameterMetaData parameterMetaData : this.parameterMetaDataList) {
/* 171 */       if (parameterMetaData.isCascading()) {
/* 172 */         cascadedParameters.add(parameterMetaData);
/*     */       }
/*     */     }
/*     */     
/* 176 */     return new ValidatableParametersMetaData(cascadedParameters);
/*     */   }
/*     */   
/*     */   public ReturnValueMetaData getReturnValueMetaData() {
/* 180 */     return this.returnValueMetaData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExecutableDescriptorImpl asDescriptor(boolean defaultGroupSequenceRedefined, List<Class<?>> defaultGroupSequence)
/*     */   {
/* 193 */     return new ExecutableDescriptorImpl(getType(), getName(), asDescriptors(getCrossParameterConstraints()), this.returnValueMetaData.asDescriptor(defaultGroupSequenceRedefined, defaultGroupSequence), parametersAsDescriptors(defaultGroupSequenceRedefined, defaultGroupSequence), defaultGroupSequenceRedefined, this.isGetter, defaultGroupSequence);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<ParameterDescriptor> parametersAsDescriptors(boolean defaultGroupSequenceRedefined, List<Class<?>> defaultGroupSequence)
/*     */   {
/* 201 */     List<ParameterDescriptor> parameterDescriptorList = CollectionHelper.newArrayList();
/*     */     
/* 203 */     for (ParameterMetaData parameterMetaData : this.parameterMetaDataList) {
/* 204 */       parameterDescriptorList.add(parameterMetaData
/* 205 */         .asDescriptor(defaultGroupSequenceRedefined, defaultGroupSequence));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 212 */     return parameterDescriptorList;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 217 */     StringBuilder parameterBuilder = new StringBuilder();
/*     */     
/* 219 */     for (Class<?> oneParameterType : getParameterTypes()) {
/* 220 */       parameterBuilder.append(oneParameterType.getSimpleName());
/* 221 */       parameterBuilder.append(", ");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 227 */     String parameters = parameterBuilder.length() > 0 ? parameterBuilder.substring(0, parameterBuilder.length() - 2) : parameterBuilder.toString();
/*     */     
/*     */ 
/* 230 */     return "ExecutableMetaData [executable=" + getType() + " " + getName() + "(" + parameters + "), isCascading=" + isCascading() + ", isConstrained=" + isConstrained() + "]";
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 235 */     int prime = 31;
/* 236 */     int result = super.hashCode();
/* 237 */     result = 31 * result + Arrays.hashCode(this.parameterTypes);
/* 238 */     return result;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 243 */     if (this == obj) {
/* 244 */       return true;
/*     */     }
/* 246 */     if (!super.equals(obj)) {
/* 247 */       return false;
/*     */     }
/* 249 */     if (getClass() != obj.getClass()) {
/* 250 */       return false;
/*     */     }
/* 252 */     ExecutableMetaData other = (ExecutableMetaData)obj;
/* 253 */     if (!Arrays.equals(this.parameterTypes, other.parameterTypes)) {
/* 254 */       return false;
/*     */     }
/* 256 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Builder
/*     */     extends MetaDataBuilder
/*     */   {
/* 270 */     private static final Set<MethodConfigurationRule> rules = Collections.unmodifiableSet(
/* 271 */       CollectionHelper.asSet(new MethodConfigurationRule[] { new OverridingMethodMustNotAlterParameterConstraints(), new ParallelMethodsMustNotDefineParameterConstraints(), new VoidMethodsMustNotBeReturnValueConstrained(), new ReturnValueMayOnlyBeMarkedOnceAsCascadedPerHierarchyLine(), new ParallelMethodsMustNotDefineGroupConversionForCascadedReturnValue() }));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 280 */     private final Set<String> signatures = CollectionHelper.newHashSet();
/*     */     
/*     */ 
/*     */     private final ConstrainedElement.ConstrainedElementKind kind;
/*     */     
/*     */ 
/* 286 */     private final Set<ConstrainedExecutable> constrainedExecutables = CollectionHelper.newHashSet();
/*     */     private ExecutableElement executable;
/* 288 */     private final Set<MetaConstraint<?>> crossParameterConstraints = CollectionHelper.newHashSet();
/* 289 */     private final Set<MetaConstraint<?>> typeArgumentsConstraints = CollectionHelper.newHashSet();
/* 290 */     private boolean isConstrained = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 298 */     private final Map<Class<?>, ConstrainedExecutable> executablesByDeclaringType = CollectionHelper.newHashMap();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private final ExecutableHelper executableHelper;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Builder(Class<?> beanClass, ConstrainedExecutable constrainedExecutable, ConstraintHelper constraintHelper, ExecutableHelper executableHelper)
/*     */     {
/* 312 */       super(constraintHelper);
/*     */       
/* 314 */       this.executableHelper = executableHelper;
/* 315 */       this.kind = constrainedExecutable.getKind();
/* 316 */       this.executable = constrainedExecutable.getExecutable();
/* 317 */       add(constrainedExecutable);
/*     */     }
/*     */     
/*     */     public boolean accepts(ConstrainedElement constrainedElement)
/*     */     {
/* 322 */       if (this.kind != constrainedElement.getKind()) {
/* 323 */         return false;
/*     */       }
/*     */       
/* 326 */       ExecutableElement executableElement = ((ConstrainedExecutable)constrainedElement).getExecutable();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 332 */       return (this.executable.equals(executableElement)) || (this.executableHelper.overrides(this.executable, executableElement)) || (this.executableHelper.overrides(executableElement, this.executable));
/*     */     }
/*     */     
/*     */     public void add(ConstrainedElement constrainedElement)
/*     */     {
/* 337 */       super.add(constrainedElement);
/* 338 */       ConstrainedExecutable constrainedExecutable = (ConstrainedExecutable)constrainedElement;
/*     */       
/* 340 */       this.signatures.add(constrainedExecutable.getExecutable().getSignature());
/*     */       
/* 342 */       this.constrainedExecutables.add(constrainedExecutable);
/* 343 */       this.isConstrained = ((this.isConstrained) || (constrainedExecutable.isConstrained()));
/* 344 */       this.crossParameterConstraints.addAll(constrainedExecutable.getCrossParameterConstraints());
/* 345 */       this.typeArgumentsConstraints.addAll(constrainedExecutable.getTypeArgumentsConstraints());
/*     */       
/* 347 */       addToExecutablesByDeclaringType(constrainedExecutable);
/*     */       
/*     */ 
/*     */ 
/* 351 */       if ((this.executable != null) && (this.executableHelper.overrides(constrainedExecutable.getExecutable(), this.executable))) {
/* 352 */         this.executable = constrainedExecutable.getExecutable();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void addToExecutablesByDeclaringType(ConstrainedExecutable executable)
/*     */     {
/* 363 */       Class<?> beanClass = executable.getLocation().getDeclaringClass();
/* 364 */       ConstrainedExecutable mergedExecutable = (ConstrainedExecutable)this.executablesByDeclaringType.get(beanClass);
/*     */       
/* 366 */       if (mergedExecutable != null) {
/* 367 */         mergedExecutable = mergedExecutable.merge(executable);
/*     */       }
/*     */       else {
/* 370 */         mergedExecutable = executable;
/*     */       }
/*     */       
/* 373 */       this.executablesByDeclaringType.put(beanClass, mergedExecutable.merge(executable));
/*     */     }
/*     */     
/*     */     public ExecutableMetaData build()
/*     */     {
/* 378 */       assertCorrectnessOfConfiguration();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 394 */       return new ExecutableMetaData(this.executable.getSimpleName(), ReflectionHelper.typeOf(this.executable.getMember()), this.executable.getParameterTypes(), this.kind == ConstrainedElement.ConstrainedElementKind.CONSTRUCTOR ? ElementKind.CONSTRUCTOR : ElementKind.METHOD, this.kind == ConstrainedElement.ConstrainedElementKind.CONSTRUCTOR ? Collections.singleton(this.executable.getSignature()) : this.signatures, adaptOriginsAndImplicitGroups(getConstraints()), findParameterMetaData(), adaptOriginsAndImplicitGroups(this.crossParameterConstraints), this.typeArgumentsConstraints, getGroupConversions(), isCascading(), this.isConstrained, this.executable.isGetterMethod(), unwrapMode(), null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private List<ParameterMetaData> findParameterMetaData()
/*     */     {
/* 406 */       List<ParameterMetaData.Builder> parameterBuilders = null;
/*     */       
/* 408 */       for (Iterator localIterator1 = this.constrainedExecutables.iterator(); localIterator1.hasNext();) { oneExecutable = (ConstrainedExecutable)localIterator1.next();
/* 409 */         Iterator localIterator2; if (parameterBuilders == null) {
/* 410 */           parameterBuilders = CollectionHelper.newArrayList();
/*     */           
/* 412 */           for (localIterator2 = oneExecutable.getAllParameterMetaData().iterator(); localIterator2.hasNext();) { oneParameter = (ConstrainedParameter)localIterator2.next();
/* 413 */             parameterBuilders.add(new ParameterMetaData.Builder(this.executable
/*     */             
/* 415 */               .getMember().getDeclaringClass(), oneParameter, this.constraintHelper));
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/* 423 */           i = 0;
/* 424 */           for (ConstrainedParameter oneParameter : oneExecutable.getAllParameterMetaData()) {
/* 425 */             ((ParameterMetaData.Builder)parameterBuilders.get(i)).add(oneParameter);
/* 426 */             i++;
/*     */           } } }
/*     */       ConstrainedExecutable oneExecutable;
/*     */       ConstrainedParameter oneParameter;
/*     */       int i;
/* 431 */       Object parameterMetaDatas = CollectionHelper.newArrayList();
/*     */       
/* 433 */       for (ParameterMetaData.Builder oneBuilder : parameterBuilders) {
/* 434 */         ((List)parameterMetaDatas).add(oneBuilder.build());
/*     */       }
/*     */       
/* 437 */       return (List<ParameterMetaData>)parameterMetaDatas;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void assertCorrectnessOfConfiguration()
/*     */     {
/* 457 */       for (Iterator localIterator1 = this.executablesByDeclaringType.entrySet().iterator(); localIterator1.hasNext();) { entry = (Map.Entry)localIterator1.next();
/* 458 */         for (localIterator2 = this.executablesByDeclaringType.entrySet().iterator(); localIterator2.hasNext();) { otherEntry = (Map.Entry)localIterator2.next();
/* 459 */           for (MethodConfigurationRule rule : rules) {
/* 460 */             rule.apply((ConstrainedExecutable)entry.getValue(), (ConstrainedExecutable)otherEntry.getValue());
/*     */           }
/*     */         }
/*     */       }
/*     */       Map.Entry<Class<?>, ConstrainedExecutable> entry;
/*     */       Iterator localIterator2;
/*     */       Map.Entry<Class<?>, ConstrainedExecutable> otherEntry;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\metadata\aggregated\ExecutableMetaData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */