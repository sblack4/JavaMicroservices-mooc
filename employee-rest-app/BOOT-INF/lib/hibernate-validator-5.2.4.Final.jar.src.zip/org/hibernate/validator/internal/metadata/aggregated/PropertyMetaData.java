/*     */ package org.hibernate.validator.internal.metadata.aggregated;
/*     */ 
/*     */ import java.lang.annotation.ElementType;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.validation.ElementKind;
/*     */ import javax.validation.metadata.GroupConversionDescriptor;
/*     */ import org.hibernate.validator.internal.engine.valuehandling.UnwrapMode;
/*     */ import org.hibernate.validator.internal.metadata.core.ConstraintHelper;
/*     */ import org.hibernate.validator.internal.metadata.core.MetaConstraint;
/*     */ import org.hibernate.validator.internal.metadata.descriptor.PropertyDescriptorImpl;
/*     */ import org.hibernate.validator.internal.metadata.facets.Cascadable;
/*     */ import org.hibernate.validator.internal.metadata.location.ConstraintLocation;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedElement;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedElement.ConstrainedElementKind;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedExecutable;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedField;
/*     */ import org.hibernate.validator.internal.metadata.raw.ConstrainedType;
/*     */ import org.hibernate.validator.internal.util.CollectionHelper;
/*     */ import org.hibernate.validator.internal.util.ReflectionHelper;
/*     */ import org.hibernate.validator.internal.util.logging.Log;
/*     */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyMetaData
/*     */   extends AbstractConstraintMetaData
/*     */   implements Cascadable
/*     */ {
/*  54 */   private static final Log log = ;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Member cascadingMember;
/*     */   
/*     */ 
/*     */ 
/*     */   private final ElementType elementType;
/*     */   
/*     */ 
/*     */ 
/*     */   private final GroupConversionHelper groupConversionHelper;
/*     */   
/*     */ 
/*     */ 
/*     */   private final Set<MetaConstraint<?>> typeArgumentsConstraints;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private PropertyMetaData(String propertyName, Type type, Set<MetaConstraint<?>> constraints, Set<MetaConstraint<?>> typeArgumentsConstraints, Map<Class<?>, Class<?>> groupConversions, Member cascadingMember, UnwrapMode unwrapMode)
/*     */   {
/*  78 */     super(propertyName, type, constraints, ElementKind.PROPERTY, cascadingMember != null, (cascadingMember != null) || 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  84 */       (!constraints.isEmpty()) || (!typeArgumentsConstraints.isEmpty()), unwrapMode);
/*     */     
/*     */ 
/*     */ 
/*  88 */     if (cascadingMember != null) {
/*  89 */       this.cascadingMember = cascadingMember;
/*  90 */       this.elementType = ((cascadingMember instanceof Field) ? ElementType.FIELD : ElementType.METHOD);
/*     */     }
/*     */     else {
/*  93 */       this.cascadingMember = null;
/*  94 */       this.elementType = ElementType.TYPE;
/*     */     }
/*     */     
/*  97 */     this.typeArgumentsConstraints = Collections.unmodifiableSet(typeArgumentsConstraints);
/*  98 */     this.groupConversionHelper = new GroupConversionHelper(groupConversions);
/*  99 */     this.groupConversionHelper.validateGroupConversions(isCascading(), toString());
/*     */   }
/*     */   
/*     */   public Member getCascadingMember() {
/* 103 */     return this.cascadingMember;
/*     */   }
/*     */   
/*     */   public ElementType getElementType()
/*     */   {
/* 108 */     return this.elementType;
/*     */   }
/*     */   
/*     */   public Class<?> convertGroup(Class<?> from)
/*     */   {
/* 113 */     return this.groupConversionHelper.convertGroup(from);
/*     */   }
/*     */   
/*     */   public Set<GroupConversionDescriptor> getGroupConversionDescriptors()
/*     */   {
/* 118 */     return this.groupConversionHelper.asDescriptors();
/*     */   }
/*     */   
/*     */   public Set<MetaConstraint<?>> getTypeArgumentsConstraints()
/*     */   {
/* 123 */     return this.typeArgumentsConstraints;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PropertyDescriptorImpl asDescriptor(boolean defaultGroupSequenceRedefined, List<Class<?>> defaultGroupSequence)
/*     */   {
/* 135 */     return new PropertyDescriptorImpl(getType(), getName(), asDescriptors(getConstraints()), isCascading(), defaultGroupSequenceRedefined, defaultGroupSequence, getGroupConversionDescriptors());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 143 */     return "PropertyMetaData [type=" + getType() + ", propertyName=" + getName() + ", cascadingMember=[" + this.cascadingMember + "]]";
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 148 */     return super.hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 153 */     if (this == obj) {
/* 154 */       return true;
/*     */     }
/* 156 */     if (!super.equals(obj)) {
/* 157 */       return false;
/*     */     }
/* 159 */     if (getClass() != obj.getClass()) {
/* 160 */       return false;
/*     */     }
/* 162 */     return true;
/*     */   }
/*     */   
/*     */   public static class Builder extends MetaDataBuilder
/*     */   {
/* 167 */     private static final EnumSet<ConstrainedElement.ConstrainedElementKind> SUPPORTED_ELEMENT_KINDS = EnumSet.of(ConstrainedElement.ConstrainedElementKind.TYPE, ConstrainedElement.ConstrainedElementKind.FIELD, ConstrainedElement.ConstrainedElementKind.METHOD);
/*     */     
/*     */ 
/*     */     private final String propertyName;
/*     */     
/*     */     private final Type propertyType;
/*     */     
/*     */     private Member cascadingMember;
/*     */     
/* 176 */     private final Set<MetaConstraint<?>> typeArgumentsConstraints = CollectionHelper.newHashSet();
/* 177 */     private UnwrapMode unwrapMode = UnwrapMode.AUTOMATIC;
/* 178 */     private boolean unwrapModeExplicitlyConfigured = false;
/*     */     
/*     */     public Builder(Class<?> beanClass, ConstrainedField constrainedField, ConstraintHelper constraintHelper) {
/* 181 */       super(constraintHelper);
/*     */       
/* 183 */       this.propertyName = ReflectionHelper.getPropertyName(constrainedField.getLocation().getMember());
/* 184 */       this.propertyType = ReflectionHelper.typeOf(constrainedField.getLocation().getMember());
/* 185 */       add(constrainedField);
/*     */     }
/*     */     
/*     */     public Builder(Class<?> beanClass, ConstrainedType constrainedType, ConstraintHelper constraintHelper) {
/* 189 */       super(constraintHelper);
/*     */       
/* 191 */       this.propertyName = null;
/* 192 */       this.propertyType = null;
/* 193 */       add(constrainedType);
/*     */     }
/*     */     
/*     */     public Builder(Class<?> beanClass, ConstrainedExecutable constrainedMethod, ConstraintHelper constraintHelper) {
/* 197 */       super(constraintHelper);
/*     */       
/* 199 */       this.propertyName = ReflectionHelper.getPropertyName(constrainedMethod.getLocation().getMember());
/* 200 */       this.propertyType = ReflectionHelper.typeOf(constrainedMethod.getLocation().getMember());
/* 201 */       add(constrainedMethod);
/*     */     }
/*     */     
/*     */     public boolean accepts(ConstrainedElement constrainedElement)
/*     */     {
/* 206 */       if (!SUPPORTED_ELEMENT_KINDS.contains(constrainedElement.getKind())) {
/* 207 */         return false;
/*     */       }
/*     */       
/* 210 */       if ((constrainedElement.getKind() == ConstrainedElement.ConstrainedElementKind.METHOD) && 
/* 211 */         (!((ConstrainedExecutable)constrainedElement).isGetterMethod())) {
/* 212 */         return false;
/*     */       }
/*     */       
/* 215 */       return equals(
/* 216 */         ReflectionHelper.getPropertyName(constrainedElement.getLocation().getMember()), this.propertyName);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void add(ConstrainedElement constrainedElement)
/*     */     {
/* 223 */       super.add(constrainedElement);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 229 */       UnwrapMode newUnwrapMode = constrainedElement.unwrapMode();
/* 230 */       if (this.unwrapModeExplicitlyConfigured) {
/* 231 */         if ((!UnwrapMode.AUTOMATIC.equals(newUnwrapMode)) && (!newUnwrapMode.equals(this.unwrapMode))) {
/* 232 */           throw PropertyMetaData.log.getInconsistentValueUnwrappingConfigurationBetweenFieldAndItsGetterException(this.propertyName, 
/*     */           
/* 234 */             getBeanClass().getName());
/*     */         }
/*     */         
/*     */ 
/*     */       }
/* 239 */       else if (!UnwrapMode.AUTOMATIC.equals(newUnwrapMode)) {
/* 240 */         this.unwrapMode = constrainedElement.unwrapMode();
/* 241 */         this.unwrapModeExplicitlyConfigured = true;
/*     */       }
/*     */       
/*     */ 
/* 245 */       if (constrainedElement.getKind() == ConstrainedElement.ConstrainedElementKind.FIELD) {
/* 246 */         this.typeArgumentsConstraints.addAll(((ConstrainedField)constrainedElement).getTypeArgumentsConstraints());
/*     */       }
/* 248 */       else if (constrainedElement.getKind() == ConstrainedElement.ConstrainedElementKind.METHOD) {
/* 249 */         this.typeArgumentsConstraints.addAll(((ConstrainedExecutable)constrainedElement).getTypeArgumentsConstraints());
/*     */       }
/*     */       
/* 252 */       if ((constrainedElement.isCascading()) && (this.cascadingMember == null)) {
/* 253 */         this.cascadingMember = constrainedElement.getLocation().getMember();
/*     */       }
/*     */     }
/*     */     
/*     */     public UnwrapMode unwrapMode() {
/* 258 */       return this.unwrapMode;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public PropertyMetaData build()
/*     */     {
/* 270 */       return new PropertyMetaData(this.propertyName, this.propertyType, adaptOriginsAndImplicitGroups(getConstraints()), this.typeArgumentsConstraints, getGroupConversions(), this.cascadingMember, unwrapMode(), null);
/*     */     }
/*     */     
/*     */     private boolean equals(String s1, String s2)
/*     */     {
/* 275 */       return ((s1 != null) && (s1.equals(s2))) || ((s1 == null) && (s2 == null));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\metadata\aggregated\PropertyMetaData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */