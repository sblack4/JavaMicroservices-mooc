/*    */ package org.hibernate.validator.internal.constraintvalidators.bv;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import javax.validation.ConstraintValidator;
/*    */ import javax.validation.ConstraintValidatorContext;
/*    */ import javax.validation.constraints.DecimalMin;
/*    */ import org.hibernate.validator.internal.util.logging.Log;
/*    */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DecimalMinValidatorForCharSequence
/*    */   implements ConstraintValidator<DecimalMin, CharSequence>
/*    */ {
/* 22 */   private static final Log log = ;
/*    */   private BigDecimal minValue;
/*    */   private boolean inclusive;
/*    */   
/*    */   public void initialize(DecimalMin minValue)
/*    */   {
/*    */     try {
/* 29 */       this.minValue = new BigDecimal(minValue.value());
/*    */     }
/*    */     catch (NumberFormatException nfe) {
/* 32 */       throw log.getInvalidBigDecimalFormatException(minValue.value(), nfe);
/*    */     }
/* 34 */     this.inclusive = minValue.inclusive();
/*    */   }
/*    */   
/*    */   public boolean isValid(CharSequence value, ConstraintValidatorContext constraintValidatorContext)
/*    */   {
/* 39 */     if (value == null) {
/* 40 */       return true;
/*    */     }
/*    */     try {
/* 43 */       int comparisonResult = new BigDecimal(value.toString()).compareTo(this.minValue);
/* 44 */       return comparisonResult >= 0;
/*    */     }
/*    */     catch (NumberFormatException nfe) {}
/* 47 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\constraintvalidators\bv\DecimalMinValidatorForCharSequence.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */