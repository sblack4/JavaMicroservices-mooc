/*    */ package org.hibernate.validator.internal.constraintvalidators.bv;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import javax.validation.ConstraintValidator;
/*    */ import javax.validation.ConstraintValidatorContext;
/*    */ import javax.validation.constraints.Digits;
/*    */ import org.hibernate.validator.internal.util.logging.Log;
/*    */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DigitsValidatorForNumber
/*    */   implements ConstraintValidator<Digits, Number>
/*    */ {
/* 26 */   private static final Log log = ;
/*    */   private int maxIntegerLength;
/*    */   private int maxFractionLength;
/*    */   
/*    */   public void initialize(Digits constraintAnnotation)
/*    */   {
/* 32 */     this.maxIntegerLength = constraintAnnotation.integer();
/* 33 */     this.maxFractionLength = constraintAnnotation.fraction();
/* 34 */     validateParameters();
/*    */   }
/*    */   
/*    */   public boolean isValid(Number num, ConstraintValidatorContext constraintValidatorContext)
/*    */   {
/* 39 */     if (num == null) {
/* 40 */       return true;
/*    */     }
/*    */     BigDecimal bigNum;
/*    */     BigDecimal bigNum;
/* 44 */     if ((num instanceof BigDecimal)) {
/* 45 */       bigNum = (BigDecimal)num;
/*    */     }
/*    */     else {
/* 48 */       bigNum = new BigDecimal(num.toString()).stripTrailingZeros();
/*    */     }
/*    */     
/* 51 */     int integerPartLength = bigNum.precision() - bigNum.scale();
/* 52 */     int fractionPartLength = bigNum.scale() < 0 ? 0 : bigNum.scale();
/*    */     
/* 54 */     return (this.maxIntegerLength >= integerPartLength) && (this.maxFractionLength >= fractionPartLength);
/*    */   }
/*    */   
/*    */   private void validateParameters() {
/* 58 */     if (this.maxIntegerLength < 0) {
/* 59 */       throw log.getInvalidLengthForIntegerPartException();
/*    */     }
/* 61 */     if (this.maxFractionLength < 0) {
/* 62 */       throw log.getInvalidLengthForFractionPartException();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\constraintvalidators\bv\DigitsValidatorForNumber.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */