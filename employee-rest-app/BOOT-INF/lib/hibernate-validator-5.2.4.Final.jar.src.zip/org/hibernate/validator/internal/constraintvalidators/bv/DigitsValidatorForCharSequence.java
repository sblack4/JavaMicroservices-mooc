/*    */ package org.hibernate.validator.internal.constraintvalidators.bv;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import javax.validation.ConstraintValidator;
/*    */ import javax.validation.ConstraintValidatorContext;
/*    */ import javax.validation.constraints.Digits;
/*    */ import org.hibernate.validator.internal.util.logging.Log;
/*    */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DigitsValidatorForCharSequence
/*    */   implements ConstraintValidator<Digits, CharSequence>
/*    */ {
/* 26 */   private static final Log log = ;
/*    */   private int maxIntegerLength;
/*    */   private int maxFractionLength;
/*    */   
/*    */   public void initialize(Digits constraintAnnotation)
/*    */   {
/* 32 */     this.maxIntegerLength = constraintAnnotation.integer();
/* 33 */     this.maxFractionLength = constraintAnnotation.fraction();
/* 34 */     validateParameters();
/*    */   }
/*    */   
/*    */   public boolean isValid(CharSequence charSequence, ConstraintValidatorContext constraintValidatorContext)
/*    */   {
/* 39 */     if (charSequence == null) {
/* 40 */       return true;
/*    */     }
/*    */     
/* 43 */     BigDecimal bigNum = getBigDecimalValue(charSequence);
/* 44 */     if (bigNum == null) {
/* 45 */       return false;
/*    */     }
/*    */     
/* 48 */     int integerPartLength = bigNum.precision() - bigNum.scale();
/* 49 */     int fractionPartLength = bigNum.scale() < 0 ? 0 : bigNum.scale();
/*    */     
/* 51 */     return (this.maxIntegerLength >= integerPartLength) && (this.maxFractionLength >= fractionPartLength);
/*    */   }
/*    */   
/*    */   private BigDecimal getBigDecimalValue(CharSequence charSequence)
/*    */   {
/*    */     try {
/* 57 */       bd = new BigDecimal(charSequence.toString());
/*    */     } catch (NumberFormatException nfe) {
/*    */       BigDecimal bd;
/* 60 */       return null; }
/*    */     BigDecimal bd;
/* 62 */     return bd;
/*    */   }
/*    */   
/*    */   private void validateParameters() {
/* 66 */     if (this.maxIntegerLength < 0) {
/* 67 */       throw log.getInvalidLengthForIntegerPartException();
/*    */     }
/* 69 */     if (this.maxFractionLength < 0) {
/* 70 */       throw log.getInvalidLengthForFractionPartException();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\constraintvalidators\bv\DigitsValidatorForCharSequence.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */