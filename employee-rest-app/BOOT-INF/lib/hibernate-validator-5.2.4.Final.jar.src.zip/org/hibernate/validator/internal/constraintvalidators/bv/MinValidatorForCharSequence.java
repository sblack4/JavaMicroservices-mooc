/*    */ package org.hibernate.validator.internal.constraintvalidators.bv;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import javax.validation.ConstraintValidator;
/*    */ import javax.validation.ConstraintValidatorContext;
/*    */ import javax.validation.constraints.Min;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MinValidatorForCharSequence
/*    */   implements ConstraintValidator<Min, CharSequence>
/*    */ {
/*    */   private BigDecimal minValue;
/*    */   
/*    */   public void initialize(Min minValue)
/*    */   {
/* 26 */     this.minValue = BigDecimal.valueOf(minValue.value());
/*    */   }
/*    */   
/*    */   public boolean isValid(CharSequence value, ConstraintValidatorContext constraintValidatorContext)
/*    */   {
/* 31 */     if (value == null) {
/* 32 */       return true;
/*    */     }
/*    */     try {
/* 35 */       return new BigDecimal(value.toString()).compareTo(this.minValue) != -1;
/*    */     }
/*    */     catch (NumberFormatException nfe) {}
/* 38 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\constraintvalidators\bv\MinValidatorForCharSequence.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */