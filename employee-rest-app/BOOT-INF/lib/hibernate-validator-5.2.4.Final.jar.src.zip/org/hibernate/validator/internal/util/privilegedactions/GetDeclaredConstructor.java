/*    */ package org.hibernate.validator.internal.util.privilegedactions;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GetDeclaredConstructor<T>
/*    */   implements PrivilegedAction<Constructor<T>>
/*    */ {
/*    */   private final Class<T> clazz;
/*    */   private final Class<?>[] params;
/*    */   
/*    */   public static <T> GetDeclaredConstructor<T> action(Class<T> clazz, Class<?>... params)
/*    */   {
/* 22 */     return new GetDeclaredConstructor(clazz, params);
/*    */   }
/*    */   
/*    */   private GetDeclaredConstructor(Class<T> clazz, Class<?>... params) {
/* 26 */     this.clazz = clazz;
/* 27 */     this.params = params;
/*    */   }
/*    */   
/*    */   public Constructor<T> run()
/*    */   {
/*    */     try {
/* 33 */       return this.clazz.getDeclaredConstructor(this.params);
/*    */     }
/*    */     catch (NoSuchMethodException e) {}
/* 36 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\util\privilegedactions\GetDeclaredConstructor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */