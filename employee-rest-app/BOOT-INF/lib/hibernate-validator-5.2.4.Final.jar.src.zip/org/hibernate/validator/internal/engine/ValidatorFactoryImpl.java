/*     */ package org.hibernate.validator.internal.engine;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Collections;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.validation.ConstraintValidatorFactory;
/*     */ import javax.validation.MessageInterpolator;
/*     */ import javax.validation.ParameterNameProvider;
/*     */ import javax.validation.TraversableResolver;
/*     */ import javax.validation.Validator;
/*     */ import javax.validation.spi.ConfigurationState;
/*     */ import org.hibernate.validator.HibernateValidatorContext;
/*     */ import org.hibernate.validator.HibernateValidatorFactory;
/*     */ import org.hibernate.validator.cfg.ConstraintMapping;
/*     */ import org.hibernate.validator.internal.cfg.context.DefaultConstraintMapping;
/*     */ import org.hibernate.validator.internal.engine.constraintdefinition.ConstraintDefinitionBuilderImpl;
/*     */ import org.hibernate.validator.internal.engine.constraintdefinition.ConstraintDefinitionContribution;
/*     */ import org.hibernate.validator.internal.engine.constraintvalidation.ConstraintValidatorManager;
/*     */ import org.hibernate.validator.internal.engine.time.DefaultTimeProvider;
/*     */ import org.hibernate.validator.internal.metadata.BeanMetaDataManager;
/*     */ import org.hibernate.validator.internal.metadata.core.ConstraintHelper;
/*     */ import org.hibernate.validator.internal.metadata.provider.MetaDataProvider;
/*     */ import org.hibernate.validator.internal.metadata.provider.ProgrammaticMetaDataProvider;
/*     */ import org.hibernate.validator.internal.metadata.provider.XmlMetaDataProvider;
/*     */ import org.hibernate.validator.internal.util.CollectionHelper;
/*     */ import org.hibernate.validator.internal.util.ExecutableHelper;
/*     */ import org.hibernate.validator.internal.util.TypeResolutionHelper;
/*     */ import org.hibernate.validator.internal.util.logging.Log;
/*     */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*     */ import org.hibernate.validator.internal.util.privilegedactions.LoadClass;
/*     */ import org.hibernate.validator.internal.util.privilegedactions.NewInstance;
/*     */ import org.hibernate.validator.messageinterpolation.ResourceBundleMessageInterpolator;
/*     */ import org.hibernate.validator.spi.cfg.ConstraintMappingContributor;
/*     */ import org.hibernate.validator.spi.cfg.ConstraintMappingContributor.ConstraintMappingBuilder;
/*     */ import org.hibernate.validator.spi.constraintdefinition.ConstraintDefinitionContributor;
/*     */ import org.hibernate.validator.spi.time.TimeProvider;
/*     */ import org.hibernate.validator.spi.valuehandling.ValidatedValueUnwrapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidatorFactoryImpl
/*     */   implements HibernateValidatorFactory
/*     */ {
/*  65 */   private static final Log log = ;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final MessageInterpolator messageInterpolator;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final TraversableResolver traversableResolver;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ParameterNameProvider parameterNameProvider;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final TimeProvider timeProvider;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ConstraintValidatorManager constraintValidatorManager;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Set<DefaultConstraintMapping> constraintMappings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ConstraintHelper constraintHelper;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final TypeResolutionHelper typeResolutionHelper;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ExecutableHelper executableHelper;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final boolean failFast;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private XmlMetaDataProvider xmlMetaDataProvider;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Map<ParameterNameProvider, BeanMetaDataManager> beanMetaDataManagerMap;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final List<ValidatedValueUnwrapper<?>> validatedValueHandlers;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ValidatorFactoryImpl(ConfigurationState configurationState)
/*     */   {
/* 138 */     ClassLoader externalClassLoader = getExternalClassLoader(configurationState);
/*     */     
/* 140 */     this.messageInterpolator = configurationState.getMessageInterpolator();
/* 141 */     this.traversableResolver = configurationState.getTraversableResolver();
/* 142 */     this.parameterNameProvider = configurationState.getParameterNameProvider();
/* 143 */     this.timeProvider = getTimeProvider(configurationState, externalClassLoader);
/* 144 */     this.beanMetaDataManagerMap = Collections.synchronizedMap(new IdentityHashMap());
/* 145 */     this.constraintHelper = new ConstraintHelper();
/* 146 */     this.typeResolutionHelper = new TypeResolutionHelper();
/* 147 */     this.executableHelper = new ExecutableHelper(this.typeResolutionHelper);
/*     */     
/*     */ 
/*     */ 
/* 151 */     if (configurationState.getMappingStreams().isEmpty()) {
/* 152 */       this.xmlMetaDataProvider = null;
/*     */     }
/*     */     else
/*     */     {
/* 156 */       this.xmlMetaDataProvider = new XmlMetaDataProvider(this.constraintHelper, this.parameterNameProvider, configurationState.getMappingStreams(), externalClassLoader);
/*     */     }
/*     */     
/*     */ 
/* 160 */     Map<String, String> properties = configurationState.getProperties();
/*     */     
/* 162 */     boolean tmpFailFast = false;
/* 163 */     List<ValidatedValueUnwrapper<?>> tmpValidatedValueHandlers = CollectionHelper.newArrayList(5);
/*     */     
/* 165 */     if ((configurationState instanceof ConfigurationImpl)) {
/* 166 */       ConfigurationImpl hibernateSpecificConfig = (ConfigurationImpl)configurationState;
/*     */       
/*     */ 
/* 169 */       tmpFailFast = hibernateSpecificConfig.getFailFast();
/*     */       
/* 171 */       tmpValidatedValueHandlers.addAll(hibernateSpecificConfig.getValidatedValueHandlers());
/*     */       
/* 173 */       registerCustomConstraintValidators(hibernateSpecificConfig, properties, externalClassLoader, this.constraintHelper);
/*     */     }
/*     */     
/* 176 */     this.constraintMappings = Collections.unmodifiableSet(getConstraintMappings(configurationState, externalClassLoader));
/*     */     
/* 178 */     tmpFailFast = checkPropertiesForFailFast(properties, tmpFailFast);
/*     */     
/*     */ 
/* 181 */     this.failFast = tmpFailFast;
/*     */     
/* 183 */     tmpValidatedValueHandlers.addAll(getPropertyConfiguredValidatedValueHandlers(properties, externalClassLoader));
/* 184 */     this.validatedValueHandlers = Collections.unmodifiableList(tmpValidatedValueHandlers);
/*     */     
/* 186 */     this.constraintValidatorManager = new ConstraintValidatorManager(configurationState.getConstraintValidatorFactory());
/*     */   }
/*     */   
/*     */   private static ClassLoader getExternalClassLoader(ConfigurationState configurationState) {
/* 190 */     return (configurationState instanceof ConfigurationImpl) ? ((ConfigurationImpl)configurationState).getExternalClassLoader() : null;
/*     */   }
/*     */   
/*     */   private static Set<DefaultConstraintMapping> getConstraintMappings(ConfigurationState configurationState, ClassLoader externalClassLoader)
/*     */   {
/*     */     Set<DefaultConstraintMapping> constraintMappings;
/*     */     Set<DefaultConstraintMapping> constraintMappings;
/* 197 */     if ((configurationState instanceof ConfigurationImpl)) {
/* 198 */       constraintMappings = ((ConfigurationImpl)configurationState).getProgrammaticMappings();
/*     */     }
/*     */     else {
/* 201 */       constraintMappings = CollectionHelper.newHashSet();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 206 */     String constraintMappingContributorClassName = (String)configurationState.getProperties().get("hibernate.validator.constraint_mapping_contributor");
/*     */     
/* 208 */     if (constraintMappingContributorClassName != null)
/*     */     {
/* 210 */       Class<? extends ConstraintMappingContributor> contributorType = (Class)run(
/*     */       
/* 212 */         LoadClass.action(constraintMappingContributorClassName, externalClassLoader));
/*     */       
/*     */ 
/* 215 */       ConstraintMappingContributor contributor = (ConstraintMappingContributor)run(
/* 216 */         NewInstance.action(contributorType, "constraint mapping contributor class"));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 221 */       DefaultConstraintMappingBuilder builder = new DefaultConstraintMappingBuilder(null);
/* 222 */       contributor.createConstraintMappings(builder);
/*     */       
/* 224 */       constraintMappings.addAll(builder.mappings);
/*     */     }
/*     */     
/* 227 */     return constraintMappings;
/*     */   }
/*     */   
/*     */   private static TimeProvider getTimeProvider(ConfigurationState configurationState, ClassLoader externalClassLoader) {
/* 231 */     TimeProvider timeProvider = null;
/*     */     
/*     */ 
/* 234 */     if ((configurationState instanceof ConfigurationImpl)) {
/* 235 */       ConfigurationImpl hvConfig = (ConfigurationImpl)configurationState;
/* 236 */       timeProvider = hvConfig.getTimeProvider();
/*     */     }
/*     */     
/*     */ 
/* 240 */     if (timeProvider == null) {
/* 241 */       String timeProviderClassName = (String)configurationState.getProperties().get("hibernate.validator.time_provider");
/*     */       
/* 243 */       if (timeProviderClassName != null)
/*     */       {
/* 245 */         Class<? extends TimeProvider> handlerType = (Class)run(
/* 246 */           LoadClass.action(timeProviderClassName, externalClassLoader));
/* 247 */         timeProvider = (TimeProvider)run(NewInstance.action(handlerType, "time provider class"));
/*     */       }
/*     */     }
/*     */     
/* 251 */     return timeProvider != null ? timeProvider : DefaultTimeProvider.getInstance();
/*     */   }
/*     */   
/*     */   public Validator getValidator()
/*     */   {
/* 256 */     return createValidator(this.constraintValidatorManager
/* 257 */       .getDefaultConstraintValidatorFactory(), this.messageInterpolator, this.traversableResolver, this.parameterNameProvider, this.failFast, this.validatedValueHandlers, this.timeProvider);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MessageInterpolator getMessageInterpolator()
/*     */   {
/* 269 */     return this.messageInterpolator;
/*     */   }
/*     */   
/*     */   public TraversableResolver getTraversableResolver()
/*     */   {
/* 274 */     return this.traversableResolver;
/*     */   }
/*     */   
/*     */   public ConstraintValidatorFactory getConstraintValidatorFactory()
/*     */   {
/* 279 */     return this.constraintValidatorManager.getDefaultConstraintValidatorFactory();
/*     */   }
/*     */   
/*     */   public ParameterNameProvider getParameterNameProvider()
/*     */   {
/* 284 */     return this.parameterNameProvider;
/*     */   }
/*     */   
/*     */   public boolean isFailFast() {
/* 288 */     return this.failFast;
/*     */   }
/*     */   
/*     */   public List<ValidatedValueUnwrapper<?>> getValidatedValueHandlers() {
/* 292 */     return this.validatedValueHandlers;
/*     */   }
/*     */   
/*     */   TimeProvider getTimeProvider() {
/* 296 */     return this.timeProvider;
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> T unwrap(Class<T> type)
/*     */   {
/* 302 */     if (type.isAssignableFrom(HibernateValidatorFactory.class)) {
/* 303 */       return (T)type.cast(this);
/*     */     }
/* 305 */     throw log.getTypeNotSupportedForUnwrappingException(type);
/*     */   }
/*     */   
/*     */   public HibernateValidatorContext usingContext()
/*     */   {
/* 310 */     return new ValidatorContextImpl(this);
/*     */   }
/*     */   
/*     */   public void close()
/*     */   {
/* 315 */     this.constraintValidatorManager.clear();
/* 316 */     for (BeanMetaDataManager beanMetaDataManager : this.beanMetaDataManagerMap.values()) {
/* 317 */       beanMetaDataManager.clear();
/*     */     }
/*     */     
/*     */ 
/* 321 */     this.xmlMetaDataProvider = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Validator createValidator(ConstraintValidatorFactory constraintValidatorFactory, MessageInterpolator messageInterpolator, TraversableResolver traversableResolver, ParameterNameProvider parameterNameProvider, boolean failFast, List<ValidatedValueUnwrapper<?>> validatedValueHandlers, TimeProvider timeProvider)
/*     */   {
/* 334 */     if ((messageInterpolator instanceof ResourceBundleMessageInterpolator)) {
/*     */       try {
/* 336 */         ResourceBundleMessageInterpolator.class.getClassLoader().loadClass("javax.el.ExpressionFactory");
/*     */       }
/*     */       catch (ClassNotFoundException e) {
/* 339 */         throw log.getMissingELDependenciesException();
/*     */       }
/*     */     }
/*     */     
/*     */     BeanMetaDataManager beanMetaDataManager;
/* 344 */     if (!this.beanMetaDataManagerMap.containsKey(parameterNameProvider))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 349 */       BeanMetaDataManager beanMetaDataManager = new BeanMetaDataManager(this.constraintHelper, this.executableHelper, parameterNameProvider, buildDataProviders(parameterNameProvider));
/*     */       
/* 351 */       this.beanMetaDataManagerMap.put(parameterNameProvider, beanMetaDataManager);
/*     */     }
/*     */     else {
/* 354 */       beanMetaDataManager = (BeanMetaDataManager)this.beanMetaDataManagerMap.get(parameterNameProvider);
/*     */     }
/*     */     
/* 357 */     return new ValidatorImpl(constraintValidatorFactory, messageInterpolator, traversableResolver, beanMetaDataManager, parameterNameProvider, timeProvider, this.typeResolutionHelper, validatedValueHandlers, this.constraintValidatorManager, failFast);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<MetaDataProvider> buildDataProviders(ParameterNameProvider parameterNameProvider)
/*     */   {
/* 372 */     List<MetaDataProvider> metaDataProviders = CollectionHelper.newArrayList();
/* 373 */     if (this.xmlMetaDataProvider != null) {
/* 374 */       metaDataProviders.add(this.xmlMetaDataProvider);
/*     */     }
/*     */     
/* 377 */     if (!this.constraintMappings.isEmpty()) {
/* 378 */       metaDataProviders.add(new ProgrammaticMetaDataProvider(this.constraintHelper, parameterNameProvider, this.constraintMappings));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 386 */     return metaDataProviders;
/*     */   }
/*     */   
/*     */   private boolean checkPropertiesForFailFast(Map<String, String> properties, boolean programmaticConfiguredFailFast) {
/* 390 */     boolean failFast = programmaticConfiguredFailFast;
/* 391 */     String failFastPropValue = (String)properties.get("hibernate.validator.fail_fast");
/* 392 */     if (failFastPropValue != null) {
/* 393 */       boolean tmpFailFast = Boolean.valueOf(failFastPropValue).booleanValue();
/* 394 */       if ((programmaticConfiguredFailFast) && (!tmpFailFast)) {
/* 395 */         throw log.getInconsistentFailFastConfigurationException();
/*     */       }
/* 397 */       failFast = tmpFailFast;
/*     */     }
/* 399 */     return failFast;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static List<ValidatedValueUnwrapper<?>> getPropertyConfiguredValidatedValueHandlers(Map<String, String> properties, ClassLoader externalClassLoader)
/*     */   {
/* 412 */     String propertyValue = (String)properties.get("hibernate.validator.validated_value_handlers");
/*     */     
/* 414 */     if ((propertyValue == null) || (propertyValue.isEmpty())) {
/* 415 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 418 */     String[] handlerNames = propertyValue.split(",");
/* 419 */     List<ValidatedValueUnwrapper<?>> handlers = CollectionHelper.newArrayList(handlerNames.length);
/*     */     
/* 421 */     for (String handlerName : handlerNames)
/*     */     {
/*     */ 
/* 424 */       Class<? extends ValidatedValueUnwrapper<?>> handlerType = (Class)run(LoadClass.action(handlerName, externalClassLoader));
/* 425 */       handlers.add(run(NewInstance.action(handlerType, "validated value handler class")));
/*     */     }
/*     */     
/* 428 */     return handlers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static List<ConstraintDefinitionContributor> getPropertyConfiguredConstraintDefinitionContributors(Map<String, String> properties, ClassLoader externalClassLoader)
/*     */   {
/* 441 */     String propertyValue = (String)properties.get("hibernate.validator.constraint_definition_contributors");
/*     */     
/* 443 */     if ((propertyValue == null) || (propertyValue.isEmpty())) {
/* 444 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 447 */     String[] constraintDefinitionContributorNames = propertyValue.split(",");
/* 448 */     List<ConstraintDefinitionContributor> constraintDefinitionContributors = CollectionHelper.newArrayList(constraintDefinitionContributorNames.length);
/*     */     
/*     */ 
/*     */ 
/* 452 */     for (String fqcn : constraintDefinitionContributorNames)
/*     */     {
/*     */ 
/* 455 */       Class<ConstraintDefinitionContributor> contributorType = (Class)run(LoadClass.action(fqcn, externalClassLoader));
/* 456 */       constraintDefinitionContributors.add(
/* 457 */         run(NewInstance.action(contributorType, "constraint definition contributor class")));
/*     */     }
/*     */     
/*     */ 
/* 461 */     return constraintDefinitionContributors;
/*     */   }
/*     */   
/*     */   private static void registerCustomConstraintValidators(ConfigurationImpl hibernateSpecificConfig, Map<String, String> properties, ClassLoader externalClassLoader, ConstraintHelper constraintHelper)
/*     */   {
/* 466 */     for (ConstraintDefinitionContributor contributor : hibernateSpecificConfig.getConstraintDefinitionContributors()) {
/* 467 */       registerConstraintValidators(contributor, constraintHelper);
/*     */     }
/*     */     
/* 470 */     for (ConstraintDefinitionContributor contributor : getPropertyConfiguredConstraintDefinitionContributors(properties, externalClassLoader))
/*     */     {
/*     */ 
/* 473 */       registerConstraintValidators(contributor, constraintHelper);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void registerConstraintValidators(ConstraintDefinitionContributor contributor, ConstraintHelper constraintHelper) {
/* 478 */     ConstraintDefinitionBuilderImpl builder = new ConstraintDefinitionBuilderImpl();
/* 479 */     contributor.collectConstraintDefinitions(builder);
/*     */     
/* 481 */     for (ConstraintDefinitionContribution<?> constraintDefinitionContribution : builder.getConstraintValidatorContributions()) {
/* 482 */       processConstraintDefinitionContribution(constraintDefinitionContribution, constraintHelper);
/*     */     }
/*     */   }
/*     */   
/*     */   private static <A extends Annotation> void processConstraintDefinitionContribution(ConstraintDefinitionContribution<A> constraintDefinitionContribution, ConstraintHelper constraintHelper) {
/* 487 */     constraintHelper.putValidatorClasses(constraintDefinitionContribution
/* 488 */       .getConstraintType(), constraintDefinitionContribution
/* 489 */       .getConstraintValidators(), constraintDefinitionContribution
/* 490 */       .keepDefaults());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static <T> T run(PrivilegedAction<T> action)
/*     */   {
/* 501 */     return (T)(System.getSecurityManager() != null ? AccessController.doPrivileged(action) : action.run());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class DefaultConstraintMappingBuilder
/*     */     implements ConstraintMappingContributor.ConstraintMappingBuilder
/*     */   {
/* 509 */     private final Set<DefaultConstraintMapping> mappings = CollectionHelper.newHashSet();
/*     */     
/*     */     public ConstraintMapping addConstraintMapping()
/*     */     {
/* 513 */       DefaultConstraintMapping mapping = new DefaultConstraintMapping();
/* 514 */       this.mappings.add(mapping);
/* 515 */       return mapping;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\internal\engine\ValidatorFactoryImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */