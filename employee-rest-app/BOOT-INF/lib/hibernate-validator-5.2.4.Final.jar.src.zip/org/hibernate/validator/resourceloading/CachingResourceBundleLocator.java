/*    */ package org.hibernate.validator.resourceloading;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.ResourceBundle;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ import org.hibernate.validator.spi.resourceloading.ResourceBundleLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CachingResourceBundleLocator
/*    */   extends DelegatingResourceBundleLocator
/*    */ {
/* 25 */   private final ConcurrentMap<Locale, ResourceBundle> bundleCache = new ConcurrentHashMap();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CachingResourceBundleLocator(ResourceBundleLocator delegate)
/*    */   {
/* 33 */     super(delegate);
/*    */   }
/*    */   
/*    */   public ResourceBundle getResourceBundle(Locale locale) {
/* 37 */     ResourceBundle cachedResourceBundle = (ResourceBundle)this.bundleCache.get(locale);
/* 38 */     if (cachedResourceBundle == null) {
/* 39 */       ResourceBundle bundle = super.getResourceBundle(locale);
/* 40 */       if (bundle != null) {
/* 41 */         cachedResourceBundle = (ResourceBundle)this.bundleCache.putIfAbsent(locale, bundle);
/* 42 */         if (cachedResourceBundle == null) {
/* 43 */           return bundle;
/*    */         }
/*    */       }
/*    */     }
/* 47 */     return cachedResourceBundle;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\resourceloading\CachingResourceBundleLocator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */