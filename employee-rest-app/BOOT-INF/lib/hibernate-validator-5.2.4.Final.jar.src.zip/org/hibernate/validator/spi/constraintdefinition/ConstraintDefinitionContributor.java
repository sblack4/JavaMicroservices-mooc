package org.hibernate.validator.spi.constraintdefinition;

import java.lang.annotation.Annotation;
import javax.validation.ConstraintValidator;

public abstract interface ConstraintDefinitionContributor
{
  public abstract void collectConstraintDefinitions(ConstraintDefinitionBuilder paramConstraintDefinitionBuilder);
  
  public static abstract interface ConstraintDefinitionBuilderContext<A extends Annotation>
  {
    public abstract ConstraintDefinitionBuilderContext<A> validatedBy(Class<? extends ConstraintValidator<A, ?>> paramClass);
    
    public abstract ConstraintDefinitionBuilderContext<A> includeExistingValidators(boolean paramBoolean);
    
    public abstract <B extends Annotation> ConstraintDefinitionBuilderContext<B> constraint(Class<B> paramClass);
  }
  
  public static abstract interface ConstraintDefinitionBuilder
  {
    public abstract <A extends Annotation> ConstraintDefinitionContributor.ConstraintDefinitionBuilderContext<A> constraint(Class<A> paramClass);
  }
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\spi\constraintdefinition\ConstraintDefinitionContributor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */