/*     */ package org.hibernate.validator.messageinterpolation;
/*     */ 
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.validation.MessageInterpolator;
/*     */ import javax.validation.MessageInterpolator.Context;
/*     */ import javax.xml.bind.ValidationException;
/*     */ import org.hibernate.validator.internal.engine.messageinterpolation.InterpolationTermType;
/*     */ import org.hibernate.validator.internal.engine.messageinterpolation.LocalizedMessage;
/*     */ import org.hibernate.validator.internal.engine.messageinterpolation.parser.MessageDescriptorFormatException;
/*     */ import org.hibernate.validator.internal.engine.messageinterpolation.parser.Token;
/*     */ import org.hibernate.validator.internal.engine.messageinterpolation.parser.TokenCollector;
/*     */ import org.hibernate.validator.internal.engine.messageinterpolation.parser.TokenIterator;
/*     */ import org.hibernate.validator.internal.util.ConcurrentReferenceHashMap;
/*     */ import org.hibernate.validator.internal.util.ConcurrentReferenceHashMap.Option;
/*     */ import org.hibernate.validator.internal.util.ConcurrentReferenceHashMap.ReferenceType;
/*     */ import org.hibernate.validator.internal.util.logging.Log;
/*     */ import org.hibernate.validator.internal.util.logging.LoggerFactory;
/*     */ import org.hibernate.validator.resourceloading.PlatformResourceBundleLocator;
/*     */ import org.hibernate.validator.spi.resourceloading.ResourceBundleLocator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractMessageInterpolator
/*     */   implements MessageInterpolator
/*     */ {
/*  44 */   private static final Log log = ;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int DEFAULT_INITIAL_CAPACITY = 100;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final float DEFAULT_LOAD_FACTOR = 0.75F;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int DEFAULT_CONCURRENCY_LEVEL = 16;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String DEFAULT_VALIDATION_MESSAGES = "org.hibernate.validator.ValidationMessages";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String USER_VALIDATION_MESSAGES = "ValidationMessages";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String CONTRIBUTOR_VALIDATION_MESSAGES = "ContributorValidationMessages";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Locale defaultLocale;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ResourceBundleLocator userResourceBundleLocator;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ResourceBundleLocator defaultResourceBundleLocator;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ResourceBundleLocator contributorResourceBundleLocator;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ConcurrentReferenceHashMap<LocalizedMessage, String> resolvedMessages;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ConcurrentReferenceHashMap<String, List<Token>> tokenizedParameterMessages;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ConcurrentReferenceHashMap<String, List<Token>> tokenizedELMessages;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final boolean cachingEnabled;
/*     */   
/*     */ 
/*     */ 
/* 118 */   private static final Pattern LEFT_BRACE = Pattern.compile("\\{", 16);
/* 119 */   private static final Pattern RIGHT_BRACE = Pattern.compile("\\}", 16);
/* 120 */   private static final Pattern SLASH = Pattern.compile("\\\\", 16);
/* 121 */   private static final Pattern DOLLAR = Pattern.compile("\\$", 16);
/*     */   
/*     */   public AbstractMessageInterpolator() {
/* 124 */     this(null);
/*     */   }
/*     */   
/*     */   public AbstractMessageInterpolator(ResourceBundleLocator userResourceBundleLocator) {
/* 128 */     this(userResourceBundleLocator, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractMessageInterpolator(ResourceBundleLocator userResourceBundleLocator, ResourceBundleLocator contributorResourceBundleLocator)
/*     */   {
/* 140 */     this(userResourceBundleLocator, contributorResourceBundleLocator, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractMessageInterpolator(ResourceBundleLocator userResourceBundleLocator, ResourceBundleLocator contributorResourceBundleLocator, boolean cacheMessages)
/*     */   {
/* 154 */     this.defaultLocale = Locale.getDefault();
/*     */     
/* 156 */     if (userResourceBundleLocator == null) {
/* 157 */       this.userResourceBundleLocator = new PlatformResourceBundleLocator("ValidationMessages");
/*     */     }
/*     */     else {
/* 160 */       this.userResourceBundleLocator = userResourceBundleLocator;
/*     */     }
/*     */     
/* 163 */     if (contributorResourceBundleLocator == null) {
/* 164 */       this.contributorResourceBundleLocator = new PlatformResourceBundleLocator("ContributorValidationMessages", null, true);
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 171 */       this.contributorResourceBundleLocator = contributorResourceBundleLocator;
/*     */     }
/*     */     
/* 174 */     this.defaultResourceBundleLocator = new PlatformResourceBundleLocator("org.hibernate.validator.ValidationMessages");
/*     */     
/* 176 */     this.cachingEnabled = cacheMessages;
/* 177 */     if (this.cachingEnabled)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 184 */       this.resolvedMessages = new ConcurrentReferenceHashMap(100, 0.75F, 16, ConcurrentReferenceHashMap.ReferenceType.SOFT, ConcurrentReferenceHashMap.ReferenceType.SOFT, EnumSet.noneOf(ConcurrentReferenceHashMap.Option.class));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 192 */       this.tokenizedParameterMessages = new ConcurrentReferenceHashMap(100, 0.75F, 16, ConcurrentReferenceHashMap.ReferenceType.SOFT, ConcurrentReferenceHashMap.ReferenceType.SOFT, EnumSet.noneOf(ConcurrentReferenceHashMap.Option.class));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 200 */       this.tokenizedELMessages = new ConcurrentReferenceHashMap(100, 0.75F, 16, ConcurrentReferenceHashMap.ReferenceType.SOFT, ConcurrentReferenceHashMap.ReferenceType.SOFT, EnumSet.noneOf(ConcurrentReferenceHashMap.Option.class));
/*     */     }
/*     */     else
/*     */     {
/* 204 */       this.resolvedMessages = null;
/* 205 */       this.tokenizedParameterMessages = null;
/* 206 */       this.tokenizedELMessages = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String interpolate(String message, MessageInterpolator.Context context)
/*     */   {
/* 214 */     String interpolatedMessage = message;
/*     */     try {
/* 216 */       interpolatedMessage = interpolateMessage(message, context, this.defaultLocale);
/*     */     }
/*     */     catch (MessageDescriptorFormatException e) {
/* 219 */       log.warn(e.getMessage());
/*     */     }
/* 221 */     return interpolatedMessage;
/*     */   }
/*     */   
/*     */   public String interpolate(String message, MessageInterpolator.Context context, Locale locale)
/*     */   {
/* 226 */     String interpolatedMessage = message;
/*     */     try {
/* 228 */       interpolatedMessage = interpolateMessage(message, context, locale);
/*     */     }
/*     */     catch (ValidationException e) {
/* 231 */       log.warn(e.getMessage());
/*     */     }
/* 233 */     return interpolatedMessage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String interpolateMessage(String message, MessageInterpolator.Context context, Locale locale)
/*     */     throws MessageDescriptorFormatException
/*     */   {
/* 251 */     LocalizedMessage localisedMessage = new LocalizedMessage(message, locale);
/* 252 */     String resolvedMessage = null;
/*     */     
/* 254 */     if (this.cachingEnabled) {
/* 255 */       resolvedMessage = (String)this.resolvedMessages.get(localisedMessage);
/*     */     }
/*     */     
/*     */ 
/* 259 */     if (resolvedMessage == null)
/*     */     {
/* 261 */       ResourceBundle userResourceBundle = this.userResourceBundleLocator.getResourceBundle(locale);
/*     */       
/*     */ 
/* 264 */       ResourceBundle constraintContributorResourceBundle = this.contributorResourceBundleLocator.getResourceBundle(locale);
/*     */       
/*     */ 
/* 267 */       ResourceBundle defaultResourceBundle = this.defaultResourceBundleLocator.getResourceBundle(locale);
/*     */       
/*     */ 
/* 270 */       resolvedMessage = message;
/* 271 */       boolean evaluatedDefaultBundleOnce = false;
/*     */       for (;;)
/*     */       {
/* 274 */         String userBundleResolvedMessage = interpolateBundleMessage(resolvedMessage, userResourceBundle, locale, true);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 279 */         if (!hasReplacementTakenPlace(userBundleResolvedMessage, resolvedMessage)) {
/* 280 */           userBundleResolvedMessage = interpolateBundleMessage(resolvedMessage, constraintContributorResourceBundle, locale, true);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 287 */         if ((evaluatedDefaultBundleOnce) && 
/* 288 */           (!hasReplacementTakenPlace(userBundleResolvedMessage, resolvedMessage))) {
/*     */           break;
/*     */         }
/*     */         
/*     */ 
/* 293 */         resolvedMessage = interpolateBundleMessage(userBundleResolvedMessage, defaultResourceBundle, locale, false);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 299 */         evaluatedDefaultBundleOnce = true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 304 */     if (this.cachingEnabled) {
/* 305 */       String cachedResolvedMessage = (String)this.resolvedMessages.putIfAbsent(localisedMessage, resolvedMessage);
/* 306 */       if (cachedResolvedMessage != null) {
/* 307 */         resolvedMessage = cachedResolvedMessage;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 312 */     List<Token> tokens = null;
/* 313 */     if (this.cachingEnabled) {
/* 314 */       tokens = (List)this.tokenizedParameterMessages.get(resolvedMessage);
/*     */     }
/* 316 */     if (tokens == null) {
/* 317 */       TokenCollector tokenCollector = new TokenCollector(resolvedMessage, InterpolationTermType.PARAMETER);
/* 318 */       tokens = tokenCollector.getTokenList();
/*     */       
/* 320 */       if (this.cachingEnabled) {
/* 321 */         this.tokenizedParameterMessages.putIfAbsent(resolvedMessage, tokens);
/*     */       }
/*     */     }
/* 324 */     resolvedMessage = interpolateExpression(new TokenIterator(tokens), context, locale);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 331 */     tokens = null;
/* 332 */     if (this.cachingEnabled) {
/* 333 */       tokens = (List)this.tokenizedELMessages.get(resolvedMessage);
/*     */     }
/* 335 */     if (tokens == null) {
/* 336 */       TokenCollector tokenCollector = new TokenCollector(resolvedMessage, InterpolationTermType.EL);
/* 337 */       tokens = tokenCollector.getTokenList();
/*     */       
/* 339 */       if (this.cachingEnabled) {
/* 340 */         this.tokenizedELMessages.putIfAbsent(resolvedMessage, tokens);
/*     */       }
/*     */     }
/* 343 */     resolvedMessage = interpolateExpression(new TokenIterator(tokens), context, locale);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 350 */     resolvedMessage = replaceEscapedLiterals(resolvedMessage);
/*     */     
/* 352 */     return resolvedMessage;
/*     */   }
/*     */   
/*     */   private String replaceEscapedLiterals(String resolvedMessage) {
/* 356 */     resolvedMessage = LEFT_BRACE.matcher(resolvedMessage).replaceAll("{");
/* 357 */     resolvedMessage = RIGHT_BRACE.matcher(resolvedMessage).replaceAll("}");
/* 358 */     resolvedMessage = SLASH.matcher(resolvedMessage).replaceAll(Matcher.quoteReplacement("\\"));
/* 359 */     resolvedMessage = DOLLAR.matcher(resolvedMessage).replaceAll(Matcher.quoteReplacement("$"));
/* 360 */     return resolvedMessage;
/*     */   }
/*     */   
/*     */   private boolean hasReplacementTakenPlace(String origMessage, String newMessage) {
/* 364 */     return !origMessage.equals(newMessage);
/*     */   }
/*     */   
/*     */   private String interpolateBundleMessage(String message, ResourceBundle bundle, Locale locale, boolean recursive) throws MessageDescriptorFormatException
/*     */   {
/* 369 */     TokenCollector tokenCollector = new TokenCollector(message, InterpolationTermType.PARAMETER);
/* 370 */     TokenIterator tokenIterator = new TokenIterator(tokenCollector.getTokenList());
/* 371 */     while (tokenIterator.hasMoreInterpolationTerms()) {
/* 372 */       String term = tokenIterator.nextInterpolationTerm();
/* 373 */       String resolvedParameterValue = resolveParameter(term, bundle, locale, recursive);
/*     */       
/*     */ 
/* 376 */       tokenIterator.replaceCurrentInterpolationTerm(resolvedParameterValue);
/*     */     }
/* 378 */     return tokenIterator.getInterpolatedMessage();
/*     */   }
/*     */   
/*     */   private String interpolateExpression(TokenIterator tokenIterator, MessageInterpolator.Context context, Locale locale) throws MessageDescriptorFormatException
/*     */   {
/* 383 */     while (tokenIterator.hasMoreInterpolationTerms()) {
/* 384 */       String term = tokenIterator.nextInterpolationTerm();
/*     */       
/* 386 */       String resolvedExpression = interpolate(context, locale, term);
/* 387 */       tokenIterator.replaceCurrentInterpolationTerm(resolvedExpression);
/*     */     }
/* 389 */     return tokenIterator.getInterpolatedMessage();
/*     */   }
/*     */   
/*     */   public abstract String interpolate(MessageInterpolator.Context paramContext, Locale paramLocale, String paramString);
/*     */   
/*     */   private String resolveParameter(String parameterName, ResourceBundle bundle, Locale locale, boolean recursive) throws MessageDescriptorFormatException
/*     */   {
/*     */     String parameterValue;
/*     */     try {
/* 398 */       if (bundle != null) {
/* 399 */         String parameterValue = bundle.getString(removeCurlyBraces(parameterName));
/* 400 */         if (recursive) {
/* 401 */           parameterValue = interpolateBundleMessage(parameterValue, bundle, locale, recursive);
/*     */         }
/*     */       }
/*     */       else {
/* 405 */         parameterValue = parameterName;
/*     */       }
/*     */     }
/*     */     catch (MissingResourceException e) {
/*     */       String parameterValue;
/* 410 */       parameterValue = parameterName;
/*     */     }
/* 412 */     return parameterValue;
/*     */   }
/*     */   
/*     */   private String removeCurlyBraces(String parameter) {
/* 416 */     return parameter.substring(1, parameter.length() - 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\messageinterpolation\AbstractMessageInterpolator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */