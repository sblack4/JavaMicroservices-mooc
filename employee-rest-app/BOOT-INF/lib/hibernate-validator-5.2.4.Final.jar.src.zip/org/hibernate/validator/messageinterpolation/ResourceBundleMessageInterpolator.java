/*    */ package org.hibernate.validator.messageinterpolation;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import javax.validation.MessageInterpolator.Context;
/*    */ import org.hibernate.validator.internal.engine.messageinterpolation.InterpolationTerm;
/*    */ import org.hibernate.validator.spi.resourceloading.ResourceBundleLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceBundleMessageInterpolator
/*    */   extends AbstractMessageInterpolator
/*    */ {
/*    */   public ResourceBundleMessageInterpolator() {}
/*    */   
/*    */   public ResourceBundleMessageInterpolator(ResourceBundleLocator userResourceBundleLocator)
/*    */   {
/* 29 */     super(userResourceBundleLocator);
/*    */   }
/*    */   
/*    */   public ResourceBundleMessageInterpolator(ResourceBundleLocator userResourceBundleLocator, ResourceBundleLocator contributorResourceBundleLocator)
/*    */   {
/* 34 */     super(userResourceBundleLocator, contributorResourceBundleLocator);
/*    */   }
/*    */   
/*    */ 
/*    */   public ResourceBundleMessageInterpolator(ResourceBundleLocator userResourceBundleLocator, ResourceBundleLocator contributorResourceBundleLocator, boolean cachingEnabled)
/*    */   {
/* 40 */     super(userResourceBundleLocator, contributorResourceBundleLocator, cachingEnabled);
/*    */   }
/*    */   
/*    */   public ResourceBundleMessageInterpolator(ResourceBundleLocator userResourceBundleLocator, boolean cachingEnabled) {
/* 44 */     super(userResourceBundleLocator, null, cachingEnabled);
/*    */   }
/*    */   
/*    */   public String interpolate(MessageInterpolator.Context context, Locale locale, String term)
/*    */   {
/* 49 */     InterpolationTerm expression = new InterpolationTerm(term, locale);
/* 50 */     return expression.interpolate(context);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\hibernate-validator-5.2.4.Final.jar!\org\hibernate\validator\messageinterpolation\ResourceBundleMessageInterpolator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */