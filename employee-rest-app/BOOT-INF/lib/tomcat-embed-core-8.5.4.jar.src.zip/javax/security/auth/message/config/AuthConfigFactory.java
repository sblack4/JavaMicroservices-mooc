/*     */ package javax.security.auth.message.config;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.Permission;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.security.Security;
/*     */ import java.security.SecurityPermission;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AuthConfigFactory
/*     */ {
/*     */   public static final String DEFAULT_FACTORY_SECURITY_PROPERTY = "authconfigprovider.factory";
/*     */   public static final String GET_FACTORY_PERMISSION_NAME = "getProperty.authconfigprovider.factory";
/*     */   public static final String SET_FACTORY_PERMISSION_NAME = "setProperty.authconfigprovider.factory";
/*     */   public static final String PROVIDER_REGISTRATION_PERMISSION_NAME = "setProperty.authconfigfactory.provider";
/*  39 */   public static final SecurityPermission getFactorySecurityPermission = new SecurityPermission("getProperty.authconfigprovider.factory");
/*     */   
/*     */ 
/*  42 */   public static final SecurityPermission setFactorySecurityPermission = new SecurityPermission("setProperty.authconfigprovider.factory");
/*     */   
/*     */ 
/*  45 */   public static final SecurityPermission providerRegistrationSecurityPermission = new SecurityPermission("setProperty.authconfigfactory.provider");
/*     */   
/*     */ 
/*     */   private static final String DEFAULT_JASPI_AUTHCONFIGFACTORYIMPL = "org.apache.catalina.authenticator.jaspic.AuthConfigFactoryImpl";
/*     */   
/*     */ 
/*     */   private static AuthConfigFactory factory;
/*     */   
/*     */ 
/*     */ 
/*     */   public static synchronized AuthConfigFactory getFactory()
/*     */   {
/*  57 */     checkPermission(getFactorySecurityPermission);
/*  58 */     if (factory != null) {
/*  59 */       return factory;
/*     */     }
/*     */     
/*  62 */     String className = getFactoryClassName();
/*     */     try {
/*  64 */       factory = (AuthConfigFactory)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */       {
/*     */ 
/*     */ 
/*     */         public AuthConfigFactory run()
/*     */           throws ClassNotFoundException, InstantiationException, IllegalAccessException
/*     */         {
/*     */ 
/*     */ 
/*  73 */           Class<?> clazz = Class.forName(this.val$className);
/*  74 */           return (AuthConfigFactory)clazz.newInstance();
/*     */         }
/*     */       });
/*     */     } catch (PrivilegedActionException e) {
/*  78 */       Exception inner = e.getException();
/*  79 */       if ((inner instanceof InstantiationException)) {
/*  80 */         throw ((SecurityException)new SecurityException("AuthConfigFactory error:" + inner.getCause().getMessage()).initCause(inner.getCause()));
/*     */       }
/*     */       
/*  83 */       throw ((SecurityException)new SecurityException("AuthConfigFactory error: " + inner).initCause(inner));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  88 */     return factory;
/*     */   }
/*     */   
/*     */   public static synchronized void setFactory(AuthConfigFactory factory) {
/*  92 */     checkPermission(setFactorySecurityPermission);
/*  93 */     factory = factory;
/*     */   }
/*     */   
/*     */ 
/*     */   public abstract AuthConfigProvider getConfigProvider(String paramString1, String paramString2, RegistrationListener paramRegistrationListener);
/*     */   
/*     */ 
/*     */   public abstract String registerConfigProvider(String paramString1, Map paramMap, String paramString2, String paramString3, String paramString4);
/*     */   
/*     */ 
/*     */   public abstract String registerConfigProvider(AuthConfigProvider paramAuthConfigProvider, String paramString1, String paramString2, String paramString3);
/*     */   
/*     */ 
/*     */   public abstract boolean removeRegistration(String paramString);
/*     */   
/*     */   public abstract String[] detachListener(RegistrationListener paramRegistrationListener, String paramString1, String paramString2);
/*     */   
/*     */   public abstract String[] getRegistrationIDs(AuthConfigProvider paramAuthConfigProvider);
/*     */   
/*     */   public abstract RegistrationContext getRegistrationContext(String paramString);
/*     */   
/*     */   public abstract void refresh();
/*     */   
/*     */   private static void checkPermission(Permission permission)
/*     */   {
/* 118 */     SecurityManager securityManager = System.getSecurityManager();
/* 119 */     if (securityManager != null) {
/* 120 */       securityManager.checkPermission(permission);
/*     */     }
/*     */   }
/*     */   
/*     */   private static String getFactoryClassName() {
/* 125 */     String className = (String)AccessController.doPrivileged(new PrivilegedAction()
/*     */     {
/*     */       public String run() {
/* 128 */         return Security.getProperty("authconfigprovider.factory");
/*     */       }
/*     */     });
/*     */     
/* 132 */     if (className != null) {
/* 133 */       return className;
/*     */     }
/*     */     
/* 136 */     return "org.apache.catalina.authenticator.jaspic.AuthConfigFactoryImpl";
/*     */   }
/*     */   
/*     */   public static abstract interface RegistrationContext
/*     */   {
/*     */     public abstract String getMessageLayer();
/*     */     
/*     */     public abstract String getAppContext();
/*     */     
/*     */     public abstract String getDescription();
/*     */     
/*     */     public abstract boolean isPersistent();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\javax\security\auth\message\config\AuthConfigFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */