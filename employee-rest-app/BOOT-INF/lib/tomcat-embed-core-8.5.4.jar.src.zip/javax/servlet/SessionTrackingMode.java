package javax.servlet;

public enum SessionTrackingMode
{
  COOKIE,  URL,  SSL;
  
  private SessionTrackingMode() {}
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\javax\servlet\SessionTrackingMode.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */