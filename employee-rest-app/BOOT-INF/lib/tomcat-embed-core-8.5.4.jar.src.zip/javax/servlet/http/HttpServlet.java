/*     */ package javax.servlet.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Enumeration;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.servlet.DispatcherType;
/*     */ import javax.servlet.GenericServlet;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HttpServlet
/*     */   extends GenericServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String METHOD_DELETE = "DELETE";
/*     */   private static final String METHOD_HEAD = "HEAD";
/*     */   private static final String METHOD_GET = "GET";
/*     */   private static final String METHOD_OPTIONS = "OPTIONS";
/*     */   private static final String METHOD_POST = "POST";
/*     */   private static final String METHOD_PUT = "PUT";
/*     */   private static final String METHOD_TRACE = "TRACE";
/*     */   private static final String HEADER_IFMODSINCE = "If-Modified-Since";
/*     */   private static final String HEADER_LASTMOD = "Last-Modified";
/*     */   private static final String LSTRING_FILE = "javax.servlet.http.LocalStrings";
/*  91 */   private static final ResourceBundle lStrings = ResourceBundle.getBundle("javax.servlet.http.LocalStrings");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doGet(HttpServletRequest req, HttpServletResponse resp)
/*     */     throws ServletException, IOException
/*     */   {
/* 170 */     String protocol = req.getProtocol();
/* 171 */     String msg = lStrings.getString("http.method_get_not_supported");
/* 172 */     if (protocol.endsWith("1.1")) {
/* 173 */       resp.sendError(405, msg);
/*     */     } else {
/* 175 */       resp.sendError(400, msg);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected long getLastModified(HttpServletRequest req)
/*     */   {
/* 202 */     return -1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doHead(HttpServletRequest req, HttpServletResponse resp)
/*     */     throws ServletException, IOException
/*     */   {
/* 240 */     if (DispatcherType.INCLUDE.equals(req.getDispatcherType())) {
/* 241 */       doGet(req, resp);
/*     */     } else {
/* 243 */       NoBodyResponse response = new NoBodyResponse(resp);
/* 244 */       doGet(req, response);
/* 245 */       response.setContentLength();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doPost(HttpServletRequest req, HttpServletResponse resp)
/*     */     throws ServletException, IOException
/*     */   {
/* 310 */     String protocol = req.getProtocol();
/* 311 */     String msg = lStrings.getString("http.method_post_not_supported");
/* 312 */     if (protocol.endsWith("1.1")) {
/* 313 */       resp.sendError(405, msg);
/*     */     } else {
/* 315 */       resp.sendError(400, msg);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doPut(HttpServletRequest req, HttpServletResponse resp)
/*     */     throws ServletException, IOException
/*     */   {
/* 365 */     String protocol = req.getProtocol();
/* 366 */     String msg = lStrings.getString("http.method_put_not_supported");
/* 367 */     if (protocol.endsWith("1.1")) {
/* 368 */       resp.sendError(405, msg);
/*     */     } else {
/* 370 */       resp.sendError(400, msg);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doDelete(HttpServletRequest req, HttpServletResponse resp)
/*     */     throws ServletException, IOException
/*     */   {
/* 413 */     String protocol = req.getProtocol();
/* 414 */     String msg = lStrings.getString("http.method_delete_not_supported");
/* 415 */     if (protocol.endsWith("1.1")) {
/* 416 */       resp.sendError(405, msg);
/*     */     } else {
/* 418 */       resp.sendError(400, msg);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static Method[] getAllDeclaredMethods(Class<?> c)
/*     */   {
/* 425 */     if (c.equals(HttpServlet.class)) {
/* 426 */       return null;
/*     */     }
/*     */     
/* 429 */     Method[] parentMethods = getAllDeclaredMethods(c.getSuperclass());
/* 430 */     Method[] thisMethods = c.getDeclaredMethods();
/*     */     
/* 432 */     if ((parentMethods != null) && (parentMethods.length > 0)) {
/* 433 */       Method[] allMethods = new Method[parentMethods.length + thisMethods.length];
/*     */       
/* 435 */       System.arraycopy(parentMethods, 0, allMethods, 0, parentMethods.length);
/*     */       
/* 437 */       System.arraycopy(thisMethods, 0, allMethods, parentMethods.length, thisMethods.length);
/*     */       
/*     */ 
/* 440 */       thisMethods = allMethods;
/*     */     }
/*     */     
/* 443 */     return thisMethods;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doOptions(HttpServletRequest req, HttpServletResponse resp)
/*     */     throws ServletException, IOException
/*     */   {
/* 482 */     Method[] methods = getAllDeclaredMethods(getClass());
/*     */     
/* 484 */     boolean ALLOW_GET = false;
/* 485 */     boolean ALLOW_HEAD = false;
/* 486 */     boolean ALLOW_POST = false;
/* 487 */     boolean ALLOW_PUT = false;
/* 488 */     boolean ALLOW_DELETE = false;
/* 489 */     boolean ALLOW_TRACE = true;
/* 490 */     boolean ALLOW_OPTIONS = true;
/*     */     
/* 492 */     for (int i = 0; i < methods.length; i++) {
/* 493 */       Method m = methods[i];
/*     */       
/* 495 */       if (m.getName().equals("doGet")) {
/* 496 */         ALLOW_GET = true;
/* 497 */         ALLOW_HEAD = true;
/*     */       }
/* 499 */       if (m.getName().equals("doPost"))
/* 500 */         ALLOW_POST = true;
/* 501 */       if (m.getName().equals("doPut"))
/* 502 */         ALLOW_PUT = true;
/* 503 */       if (m.getName().equals("doDelete")) {
/* 504 */         ALLOW_DELETE = true;
/*     */       }
/*     */     }
/* 507 */     String allow = null;
/* 508 */     if (ALLOW_GET)
/* 509 */       allow = "GET";
/* 510 */     if (ALLOW_HEAD)
/* 511 */       if (allow == null) allow = "HEAD"; else
/* 512 */         allow = allow + ", HEAD";
/* 513 */     if (ALLOW_POST)
/* 514 */       if (allow == null) allow = "POST"; else
/* 515 */         allow = allow + ", POST";
/* 516 */     if (ALLOW_PUT)
/* 517 */       if (allow == null) allow = "PUT"; else
/* 518 */         allow = allow + ", PUT";
/* 519 */     if (ALLOW_DELETE)
/* 520 */       if (allow == null) allow = "DELETE"; else
/* 521 */         allow = allow + ", DELETE";
/* 522 */     if (ALLOW_TRACE)
/* 523 */       if (allow == null) allow = "TRACE"; else
/* 524 */         allow = allow + ", TRACE";
/* 525 */     if (ALLOW_OPTIONS) {
/* 526 */       if (allow == null) allow = "OPTIONS"; else
/* 527 */         allow = allow + ", OPTIONS";
/*     */     }
/* 529 */     resp.setHeader("Allow", allow);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doTrace(HttpServletRequest req, HttpServletResponse resp)
/*     */     throws ServletException, IOException
/*     */   {
/* 562 */     String CRLF = "\r\n";
/* 563 */     StringBuilder buffer = new StringBuilder("TRACE ").append(req.getRequestURI()).append(" ").append(req.getProtocol());
/*     */     
/*     */ 
/* 566 */     Enumeration<String> reqHeaderEnum = req.getHeaderNames();
/*     */     
/* 568 */     while (reqHeaderEnum.hasMoreElements()) {
/* 569 */       String headerName = (String)reqHeaderEnum.nextElement();
/* 570 */       buffer.append(CRLF).append(headerName).append(": ").append(req.getHeader(headerName));
/*     */     }
/*     */     
/*     */ 
/* 574 */     buffer.append(CRLF);
/*     */     
/* 576 */     int responseLength = buffer.length();
/*     */     
/* 578 */     resp.setContentType("message/http");
/* 579 */     resp.setContentLength(responseLength);
/* 580 */     ServletOutputStream out = resp.getOutputStream();
/* 581 */     out.print(buffer.toString());
/* 582 */     out.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void service(HttpServletRequest req, HttpServletResponse resp)
/*     */     throws ServletException, IOException
/*     */   {
/* 615 */     String method = req.getMethod();
/*     */     
/* 617 */     if (method.equals("GET")) {
/* 618 */       long lastModified = getLastModified(req);
/* 619 */       if (lastModified == -1L)
/*     */       {
/*     */ 
/* 622 */         doGet(req, resp);
/*     */       } else {
/*     */         long ifModifiedSince;
/*     */         try {
/* 626 */           ifModifiedSince = req.getDateHeader("If-Modified-Since");
/*     */         } catch (IllegalArgumentException iae) {
/*     */           long ifModifiedSince;
/* 629 */           ifModifiedSince = -1L;
/*     */         }
/* 631 */         if (ifModifiedSince < lastModified / 1000L * 1000L)
/*     */         {
/*     */ 
/*     */ 
/* 635 */           maybeSetLastModified(resp, lastModified);
/* 636 */           doGet(req, resp);
/*     */         } else {
/* 638 */           resp.setStatus(304);
/*     */         }
/*     */       }
/*     */     }
/* 642 */     else if (method.equals("HEAD")) {
/* 643 */       long lastModified = getLastModified(req);
/* 644 */       maybeSetLastModified(resp, lastModified);
/* 645 */       doHead(req, resp);
/*     */     }
/* 647 */     else if (method.equals("POST")) {
/* 648 */       doPost(req, resp);
/*     */     }
/* 650 */     else if (method.equals("PUT")) {
/* 651 */       doPut(req, resp);
/*     */     }
/* 653 */     else if (method.equals("DELETE")) {
/* 654 */       doDelete(req, resp);
/*     */     }
/* 656 */     else if (method.equals("OPTIONS")) {
/* 657 */       doOptions(req, resp);
/*     */     }
/* 659 */     else if (method.equals("TRACE")) {
/* 660 */       doTrace(req, resp);
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/* 668 */       String errMsg = lStrings.getString("http.method_not_implemented");
/* 669 */       Object[] errArgs = new Object[1];
/* 670 */       errArgs[0] = method;
/* 671 */       errMsg = MessageFormat.format(errMsg, errArgs);
/*     */       
/* 673 */       resp.sendError(501, errMsg);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void maybeSetLastModified(HttpServletResponse resp, long lastModified)
/*     */   {
/* 687 */     if (resp.containsHeader("Last-Modified"))
/* 688 */       return;
/* 689 */     if (lastModified >= 0L) {
/* 690 */       resp.setDateHeader("Last-Modified", lastModified);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void service(ServletRequest req, ServletResponse res)
/*     */     throws ServletException, IOException
/*     */   {
/*     */     try
/*     */     {
/* 724 */       HttpServletRequest request = (HttpServletRequest)req;
/* 725 */       response = (HttpServletResponse)res;
/*     */     } catch (ClassCastException e) { HttpServletResponse response;
/* 727 */       throw new ServletException("non-HTTP request or response"); }
/*     */     HttpServletResponse response;
/* 729 */     HttpServletRequest request; service(request, response);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\javax\servlet\http\HttpServlet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */