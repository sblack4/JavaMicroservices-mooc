/*     */ package org.apache.catalina.manager.host;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.nio.file.CopyOption;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.UnavailableException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.ContainerServlet;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Wrapper;
/*     */ import org.apache.catalina.core.ContainerBase;
/*     */ import org.apache.catalina.core.StandardHost;
/*     */ import org.apache.catalina.startup.HostConfig;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HostManagerServlet
/*     */   extends HttpServlet
/*     */   implements ContainerServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/* 101 */   protected transient Context context = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */   protected int debug = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 113 */   protected transient Host installedHost = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 119 */   protected transient Engine engine = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.manager.host");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 132 */   protected transient Wrapper wrapper = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Wrapper getWrapper()
/*     */   {
/* 144 */     return this.wrapper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWrapper(Wrapper wrapper)
/*     */   {
/* 157 */     this.wrapper = wrapper;
/* 158 */     if (wrapper == null) {
/* 159 */       this.context = null;
/* 160 */       this.installedHost = null;
/* 161 */       this.engine = null;
/*     */     } else {
/* 163 */       this.context = ((Context)wrapper.getParent());
/* 164 */       this.installedHost = ((Host)this.context.getParent());
/* 165 */       this.engine = ((Engine)this.installedHost.getParent());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void destroy() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException, ServletException
/*     */   {
/* 198 */     StringManager smClient = StringManager.getManager("org.apache.catalina.manager.host", request.getLocales());
/*     */     
/*     */ 
/*     */ 
/* 202 */     String command = request.getPathInfo();
/* 203 */     if (command == null)
/* 204 */       command = request.getServletPath();
/* 205 */     String name = request.getParameter("name");
/*     */     
/*     */ 
/* 208 */     response.setContentType("text/plain; charset=utf-8");
/* 209 */     PrintWriter writer = response.getWriter();
/*     */     
/*     */ 
/* 212 */     if (command == null) {
/* 213 */       writer.println(sm.getString("hostManagerServlet.noCommand"));
/* 214 */     } else if (command.equals("/add")) {
/* 215 */       add(request, writer, name, false, smClient);
/* 216 */     } else if (command.equals("/remove")) {
/* 217 */       remove(writer, name, smClient);
/* 218 */     } else if (command.equals("/list")) {
/* 219 */       list(writer, smClient);
/* 220 */     } else if (command.equals("/start")) {
/* 221 */       start(writer, name, smClient);
/* 222 */     } else if (command.equals("/stop")) {
/* 223 */       stop(writer, name, smClient);
/* 224 */     } else if (command.equals("/persist")) {
/* 225 */       persist(writer, smClient);
/*     */     } else {
/* 227 */       writer.println(sm.getString("hostManagerServlet.unknownCommand", new Object[] { command }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 232 */     writer.flush();
/* 233 */     writer.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void add(HttpServletRequest request, PrintWriter writer, String name, boolean htmlMode, StringManager smClient)
/*     */   {
/* 248 */     String aliases = request.getParameter("aliases");
/* 249 */     String appBase = request.getParameter("appBase");
/* 250 */     boolean manager = booleanParameter(request, "manager", false, htmlMode);
/* 251 */     boolean autoDeploy = booleanParameter(request, "autoDeploy", true, htmlMode);
/* 252 */     boolean deployOnStartup = booleanParameter(request, "deployOnStartup", true, htmlMode);
/* 253 */     boolean deployXML = booleanParameter(request, "deployXML", true, htmlMode);
/* 254 */     boolean unpackWARs = booleanParameter(request, "unpackWARs", true, htmlMode);
/* 255 */     boolean copyXML = booleanParameter(request, "copyXML", false, htmlMode);
/* 256 */     add(writer, name, aliases, appBase, manager, autoDeploy, deployOnStartup, deployXML, unpackWARs, copyXML, smClient);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean booleanParameter(HttpServletRequest request, String parameter, boolean theDefault, boolean htmlMode)
/*     */   {
/* 276 */     String value = request.getParameter(parameter);
/* 277 */     boolean booleanValue = theDefault;
/* 278 */     if (value != null) {
/* 279 */       if (htmlMode) {
/* 280 */         if (value.equals("on")) {
/* 281 */           booleanValue = true;
/*     */         }
/* 283 */       } else if (theDefault) {
/* 284 */         if (value.equals("false")) {
/* 285 */           booleanValue = false;
/*     */         }
/* 287 */       } else if (value.equals("true")) {
/* 288 */         booleanValue = true;
/*     */       }
/* 290 */     } else if (htmlMode)
/* 291 */       booleanValue = false;
/* 292 */     return booleanValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void init()
/*     */     throws ServletException
/*     */   {
/* 300 */     if ((this.wrapper == null) || (this.context == null)) {
/* 301 */       throw new UnavailableException(sm.getString("hostManagerServlet.noWrapper"));
/*     */     }
/*     */     
/*     */ 
/* 305 */     String value = null;
/*     */     try {
/* 307 */       value = getServletConfig().getInitParameter("debug");
/* 308 */       this.debug = Integer.parseInt(value);
/*     */     } catch (Throwable t) {
/* 310 */       ExceptionUtils.handleThrowable(t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void add(PrintWriter writer, String name, String aliases, String appBase, boolean manager, boolean autoDeploy, boolean deployOnStartup, boolean deployXML, boolean unpackWARs, boolean copyXML, StringManager smClient)
/*     */   {
/* 344 */     if (this.debug >= 1) {
/* 345 */       log(sm.getString("hostManagerServlet.add", new Object[] { name }));
/*     */     }
/*     */     
/*     */ 
/* 349 */     if ((name == null) || (name.length() == 0)) {
/* 350 */       writer.println(smClient.getString("hostManagerServlet.invalidHostName", new Object[] { name }));
/*     */       
/* 352 */       return;
/*     */     }
/*     */     
/*     */ 
/* 356 */     if (this.engine.findChild(name) != null) {
/* 357 */       writer.println(smClient.getString("hostManagerServlet.alreadyHost", new Object[] { name }));
/*     */       
/* 359 */       return;
/*     */     }
/*     */     
/*     */ 
/* 363 */     File appBaseFile = null;
/* 364 */     File file = null;
/* 365 */     String applicationBase = appBase;
/* 366 */     if ((applicationBase == null) || (applicationBase.length() == 0)) {
/* 367 */       applicationBase = name;
/*     */     }
/* 369 */     file = new File(applicationBase);
/* 370 */     if (!file.isAbsolute())
/* 371 */       file = new File(this.engine.getCatalinaBase(), file.getPath());
/*     */     try {
/* 373 */       appBaseFile = file.getCanonicalFile();
/*     */     } catch (IOException e) {
/* 375 */       appBaseFile = file;
/*     */     }
/* 377 */     if ((!appBaseFile.mkdirs()) && (!appBaseFile.isDirectory())) {
/* 378 */       writer.println(smClient.getString("hostManagerServlet.appBaseCreateFail", new Object[] { appBaseFile.toString(), name }));
/*     */       
/*     */ 
/* 381 */       return;
/*     */     }
/*     */     
/*     */ 
/* 385 */     File configBaseFile = getConfigBase(name);
/*     */     
/*     */ 
/* 388 */     if (manager) {
/* 389 */       if (configBaseFile == null) {
/* 390 */         writer.println(smClient.getString("hostManagerServlet.configBaseCreateFail", new Object[] { name }));
/*     */         
/* 392 */         return;
/*     */       }
/* 394 */       try { InputStream is = getServletContext().getResourceAsStream("/manager.xml");Throwable localThrowable2 = null;
/* 395 */         try { Path dest = new File(configBaseFile, "manager.xml").toPath();
/* 396 */           Files.copy(is, dest, new CopyOption[0]);
/*     */         }
/*     */         catch (Throwable localThrowable1)
/*     */         {
/* 394 */           localThrowable2 = localThrowable1;throw localThrowable1;
/*     */         }
/*     */         finally {
/* 397 */           if (is != null) if (localThrowable2 != null) try { is.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else is.close();
/* 398 */         } } catch (IOException e) { writer.println(smClient.getString("hostManagerServlet.managerXml"));
/* 399 */         return;
/*     */       }
/*     */     }
/*     */     
/* 403 */     StandardHost host = new StandardHost();
/* 404 */     host.setAppBase(applicationBase);
/* 405 */     host.setName(name);
/*     */     
/* 407 */     host.addLifecycleListener(new HostConfig());
/*     */     
/*     */ 
/* 410 */     if ((aliases != null) && (!"".equals(aliases))) {
/* 411 */       StringTokenizer tok = new StringTokenizer(aliases, ", ");
/* 412 */       while (tok.hasMoreTokens()) {
/* 413 */         host.addAlias(tok.nextToken());
/*     */       }
/*     */     }
/* 416 */     host.setAutoDeploy(autoDeploy);
/* 417 */     host.setDeployOnStartup(deployOnStartup);
/* 418 */     host.setDeployXML(deployXML);
/* 419 */     host.setUnpackWARs(unpackWARs);
/* 420 */     host.setCopyXML(copyXML);
/*     */     
/*     */     try
/*     */     {
/* 424 */       this.engine.addChild(host);
/*     */     } catch (Exception e) {
/* 426 */       writer.println(smClient.getString("hostManagerServlet.exception", new Object[] { e.toString() }));
/*     */       
/* 428 */       return;
/*     */     }
/*     */     
/* 431 */     host = (StandardHost)this.engine.findChild(name);
/* 432 */     if (host != null) {
/* 433 */       writer.println(smClient.getString("hostManagerServlet.add", new Object[] { name }));
/*     */     }
/*     */     else {
/* 436 */       writer.println(smClient.getString("hostManagerServlet.addFailed", new Object[] { name }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void remove(PrintWriter writer, String name, StringManager smClient)
/*     */   {
/* 453 */     if (this.debug >= 1) {
/* 454 */       log(sm.getString("hostManagerServlet.remove", new Object[] { name }));
/*     */     }
/*     */     
/*     */ 
/* 458 */     if ((name == null) || (name.length() == 0)) {
/* 459 */       writer.println(smClient.getString("hostManagerServlet.invalidHostName", new Object[] { name }));
/*     */       
/* 461 */       return;
/*     */     }
/*     */     
/*     */ 
/* 465 */     if (this.engine.findChild(name) == null) {
/* 466 */       writer.println(smClient.getString("hostManagerServlet.noHost", new Object[] { name }));
/*     */       
/* 468 */       return;
/*     */     }
/*     */     
/*     */ 
/* 472 */     if (this.engine.findChild(name) == this.installedHost) {
/* 473 */       writer.println(smClient.getString("hostManagerServlet.cannotRemoveOwnHost", new Object[] { name }));
/*     */       
/* 475 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 481 */       Container child = this.engine.findChild(name);
/* 482 */       this.engine.removeChild(child);
/* 483 */       if ((child instanceof ContainerBase)) ((ContainerBase)child).destroy();
/*     */     } catch (Exception e) {
/* 485 */       writer.println(smClient.getString("hostManagerServlet.exception", new Object[] { e.toString() }));
/*     */       
/* 487 */       return;
/*     */     }
/*     */     
/* 490 */     Host host = (StandardHost)this.engine.findChild(name);
/* 491 */     if (host == null) {
/* 492 */       writer.println(smClient.getString("hostManagerServlet.remove", new Object[] { name }));
/*     */     }
/*     */     else
/*     */     {
/* 496 */       writer.println(smClient.getString("hostManagerServlet.removeFailed", new Object[] { name }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void list(PrintWriter writer, StringManager smClient)
/*     */   {
/* 511 */     if (this.debug >= 1) {
/* 512 */       log(sm.getString("hostManagerServlet.list", new Object[] { this.engine.getName() }));
/*     */     }
/*     */     
/* 515 */     writer.println(smClient.getString("hostManagerServlet.listed", new Object[] { this.engine.getName() }));
/*     */     
/* 517 */     Container[] hosts = this.engine.findChildren();
/* 518 */     for (int i = 0; i < hosts.length; i++) {
/* 519 */       Host host = (Host)hosts[i];
/* 520 */       String name = host.getName();
/* 521 */       String[] aliases = host.findAliases();
/* 522 */       StringBuilder buf = new StringBuilder();
/* 523 */       if (aliases.length > 0) {
/* 524 */         buf.append(aliases[0]);
/* 525 */         for (int j = 1; j < aliases.length; j++) {
/* 526 */           buf.append(',').append(aliases[j]);
/*     */         }
/*     */       }
/* 529 */       writer.println(smClient.getString("hostManagerServlet.listitem", new Object[] { name, buf.toString() }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void start(PrintWriter writer, String name, StringManager smClient)
/*     */   {
/* 545 */     if (this.debug >= 1) {
/* 546 */       log(sm.getString("hostManagerServlet.start", new Object[] { name }));
/*     */     }
/*     */     
/*     */ 
/* 550 */     if ((name == null) || (name.length() == 0)) {
/* 551 */       writer.println(smClient.getString("hostManagerServlet.invalidHostName", new Object[] { name }));
/*     */       
/* 553 */       return;
/*     */     }
/*     */     
/* 556 */     Container host = this.engine.findChild(name);
/*     */     
/*     */ 
/* 559 */     if (host == null) {
/* 560 */       writer.println(smClient.getString("hostManagerServlet.noHost", new Object[] { name }));
/*     */       
/* 562 */       return;
/*     */     }
/*     */     
/*     */ 
/* 566 */     if (host == this.installedHost) {
/* 567 */       writer.println(smClient.getString("hostManagerServlet.cannotStartOwnHost", new Object[] { name }));
/*     */       
/* 569 */       return;
/*     */     }
/*     */     
/*     */ 
/* 573 */     if (host.getState().isAvailable()) {
/* 574 */       writer.println(smClient.getString("hostManagerServlet.alreadyStarted", new Object[] { name }));
/*     */       
/* 576 */       return;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 581 */       host.start();
/* 582 */       writer.println(smClient.getString("hostManagerServlet.started", new Object[] { name }));
/*     */     }
/*     */     catch (Exception e) {
/* 585 */       getServletContext().log(sm.getString("hostManagerServlet.startFailed", new Object[] { name }), e);
/*     */       
/* 587 */       writer.println(smClient.getString("hostManagerServlet.startFailed", new Object[] { name }));
/*     */       
/* 589 */       writer.println(smClient.getString("hostManagerServlet.exception", new Object[] { e.toString() }));
/*     */       
/* 591 */       return;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void stop(PrintWriter writer, String name, StringManager smClient)
/*     */   {
/* 607 */     if (this.debug >= 1) {
/* 608 */       log(sm.getString("hostManagerServlet.stop", new Object[] { name }));
/*     */     }
/*     */     
/*     */ 
/* 612 */     if ((name == null) || (name.length() == 0)) {
/* 613 */       writer.println(smClient.getString("hostManagerServlet.invalidHostName", new Object[] { name }));
/*     */       
/* 615 */       return;
/*     */     }
/*     */     
/* 618 */     Container host = this.engine.findChild(name);
/*     */     
/*     */ 
/* 621 */     if (host == null) {
/* 622 */       writer.println(smClient.getString("hostManagerServlet.noHost", new Object[] { name }));
/*     */       
/* 624 */       return;
/*     */     }
/*     */     
/*     */ 
/* 628 */     if (host == this.installedHost) {
/* 629 */       writer.println(smClient.getString("hostManagerServlet.cannotStopOwnHost", new Object[] { name }));
/*     */       
/* 631 */       return;
/*     */     }
/*     */     
/*     */ 
/* 635 */     if (!host.getState().isAvailable()) {
/* 636 */       writer.println(smClient.getString("hostManagerServlet.alreadyStopped", new Object[] { name }));
/*     */       
/* 638 */       return;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 643 */       host.stop();
/* 644 */       writer.println(smClient.getString("hostManagerServlet.stopped", new Object[] { name }));
/*     */     }
/*     */     catch (Exception e) {
/* 647 */       getServletContext().log(sm.getString("hostManagerServlet.stopFailed", new Object[] { name }), e);
/*     */       
/* 649 */       writer.println(smClient.getString("hostManagerServlet.stopFailed", new Object[] { name }));
/*     */       
/* 651 */       writer.println(smClient.getString("hostManagerServlet.exception", new Object[] { e.toString() }));
/*     */       
/* 653 */       return;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void persist(PrintWriter writer, StringManager smClient)
/*     */   {
/* 667 */     if (this.debug >= 1) {
/* 668 */       log(sm.getString("hostManagerServlet.persist"));
/*     */     }
/*     */     try
/*     */     {
/* 672 */       MBeanServer platformMBeanServer = ManagementFactory.getPlatformMBeanServer();
/* 673 */       ObjectName oname = new ObjectName(this.engine.getDomain() + ":type=StoreConfig");
/* 674 */       platformMBeanServer.invoke(oname, "storeConfig", null, null);
/* 675 */       writer.println(smClient.getString("hostManagerServlet.persisted"));
/*     */     } catch (Exception e) {
/* 677 */       getServletContext().log(sm.getString("hostManagerServlet.persistFailed"), e);
/* 678 */       writer.println(smClient.getString("hostManagerServlet.persistFailed"));
/*     */       
/*     */ 
/* 681 */       if ((e instanceof InstanceNotFoundException)) {
/* 682 */         writer.println("Please enable StoreConfig to use this feature.");
/*     */       } else {
/* 684 */         writer.println(smClient.getString("hostManagerServlet.exception", new Object[] { e.toString() }));
/*     */       }
/* 686 */       return;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected File getConfigBase(String hostName)
/*     */   {
/* 699 */     File configBase = new File(this.context.getCatalinaBase(), "conf");
/* 700 */     if (!configBase.exists()) {
/* 701 */       return null;
/*     */     }
/* 703 */     if (this.engine != null) {
/* 704 */       configBase = new File(configBase, this.engine.getName());
/*     */     }
/* 706 */     if (this.installedHost != null) {
/* 707 */       configBase = new File(configBase, hostName);
/*     */     }
/* 709 */     if ((!configBase.mkdirs()) && (!configBase.isDirectory())) {
/* 710 */       return null;
/*     */     }
/* 712 */     return configBase;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\manager\host\HostManagerServlet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */