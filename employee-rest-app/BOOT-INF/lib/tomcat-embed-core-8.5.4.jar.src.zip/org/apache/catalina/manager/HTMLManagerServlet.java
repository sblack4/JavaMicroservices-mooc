/*      */ package org.apache.catalina.manager;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.StringWriter;
/*      */ import java.net.InetAddress;
/*      */ import java.net.UnknownHostException;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.Date;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Set;
/*      */ import javax.servlet.RequestDispatcher;
/*      */ import javax.servlet.ServletConfig;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import javax.servlet.http.HttpSession;
/*      */ import javax.servlet.http.Part;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.DistributedManager;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.catalina.manager.util.BaseSessionComparator;
/*      */ import org.apache.catalina.manager.util.SessionUtils;
/*      */ import org.apache.catalina.util.ContextName;
/*      */ import org.apache.catalina.util.RequestUtil;
/*      */ import org.apache.catalina.util.ServerInfo;
/*      */ import org.apache.catalina.util.URLEncoder;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class HTMLManagerServlet
/*      */   extends ManagerServlet
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   90 */   static final URLEncoder URL_ENCODER = new URLEncoder();
/*      */   static final String APPLICATION_MESSAGE = "message"; static final String APPLICATION_ERROR = "error";
/*   92 */   static { URL_ENCODER.addSafeCharacter('/'); }
/*      */   
/*      */   static final String sessionsListJspPath = "/WEB-INF/jsp/sessionsList.jsp";
/*   95 */   static final String sessionDetailJspPath = "/WEB-INF/jsp/sessionDetail.jsp"; static final String connectorCiphersJspPath = "/WEB-INF/jsp/connectorCiphers.jsp"; private boolean showProxySessions = false;
/*      */   
/*      */   private static final String APPS_HEADER_SECTION = "<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"6\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td class=\"header-left\"><small>{1}</small></td>\n <td class=\"header-left\"><small>{2}</small></td>\n <td class=\"header-center\"><small>{3}</small></td>\n <td class=\"header-center\"><small>{4}</small></td>\n <td class=\"header-left\"><small>{5}</small></td>\n <td class=\"header-left\"><small>{6}</small></td>\n</tr>\n";
/*      */   
/*      */   private static final String APPS_ROW_DETAILS_SECTION = "<tr>\n <td class=\"row-left\" bgcolor=\"{6}\" rowspan=\"2\"><small>{0}</small></td>\n <td class=\"row-left\" bgcolor=\"{6}\" rowspan=\"2\"><small>{1}</small></td>\n <td class=\"row-left\" bgcolor=\"{6}\" rowspan=\"2\"><small>{2}</small></td>\n <td class=\"row-center\" bgcolor=\"{6}\" rowspan=\"2\"><small>{3}</small></td>\n <td class=\"row-center\" bgcolor=\"{6}\" rowspan=\"2\"><small><a href=\"{4}\">{5}</a></small></td>\n";
/*      */   
/*      */   private static final String MANAGER_APP_ROW_BUTTON_SECTION = " <td class=\"row-left\" bgcolor=\"{13}\">\n  <small>\n  &nbsp;{1}&nbsp;\n  &nbsp;{3}&nbsp;\n  &nbsp;{5}&nbsp;\n  &nbsp;{7}&nbsp;\n  </small>\n </td>\n</tr><tr>\n <td class=\"row-left\" bgcolor=\"{13}\">\n  <form method=\"POST\" action=\"{8}\">\n  <small>\n  &nbsp;<input type=\"submit\" value=\"{9}\">&nbsp;{10}&nbsp;<input type=\"text\" name=\"idle\" size=\"5\" value=\"{11}\">&nbsp;{12}&nbsp;\n  </small>\n  </form>\n </td>\n</tr>\n";
/*      */   private static final String STARTED_DEPLOYED_APPS_ROW_BUTTON_SECTION = " <td class=\"row-left\" bgcolor=\"{13}\">\n  &nbsp;<small>{1}</small>&nbsp;\n  <form class=\"inline\" method=\"POST\" action=\"{2}\">  <small><input type=\"submit\" value=\"{3}\"></small>  </form>\n  <form class=\"inline\" method=\"POST\" action=\"{4}\">  <small><input type=\"submit\" value=\"{5}\"></small>  </form>\n  <form class=\"inline\" method=\"POST\" action=\"{6}\">  <small><input type=\"submit\" value=\"{7}\"></small>  </form>\n </td>\n </tr><tr>\n <td class=\"row-left\" bgcolor=\"{13}\">\n  <form method=\"POST\" action=\"{8}\">\n  <small>\n  &nbsp;<input type=\"submit\" value=\"{9}\">&nbsp;{10}&nbsp;<input type=\"text\" name=\"idle\" size=\"5\" value=\"{11}\">&nbsp;{12}&nbsp;\n  </small>\n  </form>\n </td>\n</tr>\n";
/*      */   private static final String STOPPED_DEPLOYED_APPS_ROW_BUTTON_SECTION = " <td class=\"row-left\" bgcolor=\"{13}\" rowspan=\"2\">\n  <form class=\"inline\" method=\"POST\" action=\"{0}\">  <small><input type=\"submit\" value=\"{1}\"></small>  </form>\n  &nbsp;<small>{3}</small>&nbsp;\n  &nbsp;<small>{5}</small>&nbsp;\n  <form class=\"inline\" method=\"POST\" action=\"{6}\">  <small><input type=\"submit\" value=\"{7}\"></small>  </form>\n </td>\n</tr>\n<tr></tr>\n";
/*      */   private static final String STARTED_NONDEPLOYED_APPS_ROW_BUTTON_SECTION = " <td class=\"row-left\" bgcolor=\"{13}\">\n  &nbsp;<small>{1}</small>&nbsp;\n  <form class=\"inline\" method=\"POST\" action=\"{2}\">  <small><input type=\"submit\" value=\"{3}\"></small>  </form>\n  <form class=\"inline\" method=\"POST\" action=\"{4}\">  <small><input type=\"submit\" value=\"{5}\"></small>  </form>\n  &nbsp;<small>{7}</small>&nbsp;\n </td>\n </tr><tr>\n <td class=\"row-left\" bgcolor=\"{13}\">\n  <form method=\"POST\" action=\"{8}\">\n  <small>\n  &nbsp;<input type=\"submit\" value=\"{9}\">&nbsp;{10}&nbsp;<input type=\"text\" name=\"idle\" size=\"5\" value=\"{11}\">&nbsp;{12}&nbsp;\n  </small>\n  </form>\n </td>\n</tr>\n";
/*      */   private static final String STOPPED_NONDEPLOYED_APPS_ROW_BUTTON_SECTION = " <td class=\"row-left\" bgcolor=\"{13}\" rowspan=\"2\">\n  <form class=\"inline\" method=\"POST\" action=\"{0}\">  <small><input type=\"submit\" value=\"{1}\"></small>  </form>\n  &nbsp;<small>{3}</small>&nbsp;\n  &nbsp;<small>{5}</small>&nbsp;\n  &nbsp;<small>{7}</small>&nbsp;\n </td>\n</tr>\n<tr></tr>\n";
/*      */   private static final String DEPLOY_SECTION = "</table>\n<br>\n<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"2\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{1}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{2}\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-right\">\n  <small>{3}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"deployPath\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{4}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"deployConfig\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{5}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"deployWar\" size=\"40\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  &nbsp;\n </td>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{6}\">\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n";
/*      */   private static final String UPLOAD_SECTION = "<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{0}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{1}\" enctype=\"multipart/form-data\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-right\">\n  <small>{2}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"file\" name=\"deployWar\" size=\"40\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  &nbsp;\n </td>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{3}\">\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n</table>\n<br>\n\n";
/*      */   private static final String DIAGNOSTICS_SECTION = "<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"2\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{1}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{2}\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{4}\">\n </td>\n <td class=\"row-left\">\n  <small>{3}</small>\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{5}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{6}\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{7}\">\n </td>\n <td class=\"row-left\">\n  <small>{8}</small>\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n</table>\n<br>";
/*      */   
/*      */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*      */     throws IOException, ServletException
/*      */   {
/*  113 */     StringManager smClient = StringManager.getManager("org.apache.catalina.manager", request.getLocales());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  119 */     String command = request.getPathInfo();
/*      */     
/*  121 */     String path = request.getParameter("path");
/*  122 */     ContextName cn = null;
/*  123 */     if (path != null) {
/*  124 */       cn = new ContextName(path, request.getParameter("version"));
/*      */     }
/*      */     
/*      */ 
/*  128 */     response.setContentType("text/html; charset=utf-8");
/*      */     
/*  130 */     String message = "";
/*      */     
/*  132 */     if ((command != null) && (!command.equals("/")))
/*      */     {
/*  134 */       if (!command.equals("/list"))
/*      */       {
/*  136 */         if (command.equals("/sessions")) {
/*      */           try {
/*  138 */             doSessions(cn, request, response, smClient);
/*  139 */             return;
/*      */           } catch (Exception e) {
/*  141 */             log("HTMLManagerServlet.sessions[" + cn + "]", e);
/*  142 */             message = smClient.getString("managerServlet.exception", new Object[] { e.toString() });
/*      */           }
/*      */           
/*  145 */         } else if (command.equals("/sslConnectorCiphers")) {
/*  146 */           sslConnectorCiphers(request, response);
/*  147 */         } else if ((command.equals("/upload")) || (command.equals("/deploy")) || (command.equals("/reload")) || (command.equals("/undeploy")) || (command.equals("/expire")) || (command.equals("/start")) || (command.equals("/stop")))
/*      */         {
/*      */ 
/*      */ 
/*  151 */           message = smClient.getString("managerServlet.postCommand", new Object[] { command });
/*      */         }
/*      */         else {
/*  154 */           message = smClient.getString("managerServlet.unknownCommand", new Object[] { command });
/*      */         }
/*      */       }
/*      */     }
/*  158 */     list(request, response, message, smClient);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void doPost(HttpServletRequest request, HttpServletResponse response)
/*      */     throws IOException, ServletException
/*      */   {
/*  175 */     StringManager smClient = StringManager.getManager("org.apache.catalina.manager", request.getLocales());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  181 */     String command = request.getPathInfo();
/*      */     
/*  183 */     String path = request.getParameter("path");
/*  184 */     ContextName cn = null;
/*  185 */     if (path != null) {
/*  186 */       cn = new ContextName(path, request.getParameter("version"));
/*      */     }
/*  188 */     String deployPath = request.getParameter("deployPath");
/*  189 */     ContextName deployCn = null;
/*  190 */     if (deployPath != null) {
/*  191 */       deployCn = new ContextName(deployPath, request.getParameter("deployVersion"));
/*      */     }
/*      */     
/*  194 */     String deployConfig = request.getParameter("deployConfig");
/*  195 */     String deployWar = request.getParameter("deployWar");
/*      */     
/*      */ 
/*  198 */     response.setContentType("text/html; charset=utf-8");
/*      */     
/*  200 */     String message = "";
/*      */     
/*  202 */     if ((command != null) && (command.length() != 0))
/*      */     {
/*      */ 
/*  205 */       if (command.equals("/upload")) {
/*  206 */         message = upload(request, smClient);
/*  207 */       } else if (command.equals("/deploy")) {
/*  208 */         message = deployInternal(deployConfig, deployCn, deployWar, smClient);
/*      */       }
/*  210 */       else if (command.equals("/reload")) {
/*  211 */         message = reload(cn, smClient);
/*  212 */       } else if (command.equals("/undeploy")) {
/*  213 */         message = undeploy(cn, smClient);
/*  214 */       } else if (command.equals("/expire")) {
/*  215 */         message = expireSessions(cn, request, smClient);
/*  216 */       } else if (command.equals("/start")) {
/*  217 */         message = start(cn, smClient);
/*  218 */       } else if (command.equals("/stop")) {
/*  219 */         message = stop(cn, smClient);
/*  220 */       } else if (command.equals("/findleaks")) {
/*  221 */         message = findleaks(smClient);
/*      */       }
/*      */       else {
/*  224 */         doGet(request, response);
/*  225 */         return;
/*      */       }
/*      */     }
/*  228 */     list(request, response, message, smClient);
/*      */   }
/*      */   
/*      */   protected String upload(HttpServletRequest request, StringManager smClient) {
/*  232 */     String message = "";
/*      */     
/*      */     try
/*      */     {
/*  236 */       Part warPart = request.getPart("deployWar");
/*  237 */       if (warPart == null) {
/*  238 */         message = smClient.getString("htmlManagerServlet.deployUploadNoFile");
/*      */       }
/*      */       else
/*      */       {
/*  242 */         String filename = warPart.getSubmittedFileName();
/*  243 */         if (!filename.toLowerCase(Locale.ENGLISH).endsWith(".war")) {
/*  244 */           message = smClient.getString("htmlManagerServlet.deployUploadNotWar", new Object[] { filename });
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*  249 */           if (filename.lastIndexOf('\\') >= 0) {
/*  250 */             filename = filename.substring(filename.lastIndexOf('\\') + 1);
/*      */           }
/*      */           
/*  253 */           if (filename.lastIndexOf('/') >= 0) {
/*  254 */             filename = filename.substring(filename.lastIndexOf('/') + 1);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  260 */           File file = new File(this.host.getAppBaseFile(), filename);
/*  261 */           if (file.exists()) {
/*  262 */             message = smClient.getString("htmlManagerServlet.deployUploadWarExists", new Object[] { filename });
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*  268 */             ContextName cn = new ContextName(filename, true);
/*  269 */             String name = cn.getName();
/*      */             
/*  271 */             if ((this.host.findChild(name) != null) && (!isDeployed(name))) {
/*  272 */               message = smClient.getString("htmlManagerServlet.deployUploadInServerXml", new Object[] { filename });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             }
/*  278 */             else if (isServiced(name)) {
/*  279 */               message = smClient.getString("managerServlet.inService", new Object[] { name });
/*      */             } else {
/*  281 */               addServiced(name);
/*      */               try {
/*  283 */                 warPart.write(file.getAbsolutePath());
/*      */                 
/*  285 */                 check(name);
/*      */               } finally {
/*  287 */                 removeServiced(name);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*  293 */     } catch (Exception e) { message = smClient.getString("htmlManagerServlet.deployUploadFail", new Object[] { e.getMessage() });
/*      */       
/*  295 */       log(message, e);
/*      */     }
/*  297 */     return message;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String deployInternal(String config, ContextName cn, String war, StringManager smClient)
/*      */   {
/*  313 */     StringWriter stringWriter = new StringWriter();
/*  314 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  316 */     super.deploy(printWriter, config, cn, war, false, smClient);
/*      */     
/*  318 */     return stringWriter.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void list(HttpServletRequest request, HttpServletResponse response, String message, StringManager smClient)
/*      */     throws IOException
/*      */   {
/*  336 */     if (this.debug >= 1) {
/*  337 */       log("list: Listing contexts for virtual host '" + this.host.getName() + "'");
/*      */     }
/*      */     
/*  340 */     PrintWriter writer = response.getWriter();
/*      */     
/*      */ 
/*  343 */     writer.print(Constants.HTML_HEADER_SECTION);
/*      */     
/*      */ 
/*  346 */     Object[] args = new Object[2];
/*  347 */     args[0] = request.getContextPath();
/*  348 */     args[1] = smClient.getString("htmlManagerServlet.title");
/*  349 */     writer.print(MessageFormat.format(Constants.BODY_HEADER_SECTION, args));
/*      */     
/*      */ 
/*      */ 
/*  353 */     args = new Object[3];
/*  354 */     args[0] = smClient.getString("htmlManagerServlet.messageLabel");
/*  355 */     if ((message == null) || (message.length() == 0)) {
/*  356 */       args[1] = "OK";
/*      */     } else {
/*  358 */       args[1] = RequestUtil.filter(message);
/*      */     }
/*  360 */     writer.print(MessageFormat.format(Constants.MESSAGE_SECTION, args));
/*      */     
/*      */ 
/*  363 */     args = new Object[9];
/*  364 */     args[0] = smClient.getString("htmlManagerServlet.manager");
/*  365 */     args[1] = response.encodeURL(request.getContextPath() + "/html/list");
/*  366 */     args[2] = smClient.getString("htmlManagerServlet.list");
/*  367 */     args[3] = response.encodeURL(request.getContextPath() + "/" + smClient.getString("htmlManagerServlet.helpHtmlManagerFile"));
/*      */     
/*      */ 
/*  370 */     args[4] = smClient.getString("htmlManagerServlet.helpHtmlManager");
/*  371 */     args[5] = response.encodeURL(request.getContextPath() + "/" + smClient.getString("htmlManagerServlet.helpManagerFile"));
/*      */     
/*      */ 
/*  374 */     args[6] = smClient.getString("htmlManagerServlet.helpManager");
/*  375 */     args[7] = response.encodeURL(request.getContextPath() + "/status");
/*      */     
/*  377 */     args[8] = smClient.getString("statusServlet.title");
/*  378 */     writer.print(MessageFormat.format(Constants.MANAGER_SECTION, args));
/*      */     
/*      */ 
/*  381 */     args = new Object[7];
/*  382 */     args[0] = smClient.getString("htmlManagerServlet.appsTitle");
/*  383 */     args[1] = smClient.getString("htmlManagerServlet.appsPath");
/*  384 */     args[2] = smClient.getString("htmlManagerServlet.appsVersion");
/*  385 */     args[3] = smClient.getString("htmlManagerServlet.appsName");
/*  386 */     args[4] = smClient.getString("htmlManagerServlet.appsAvailable");
/*  387 */     args[5] = smClient.getString("htmlManagerServlet.appsSessions");
/*  388 */     args[6] = smClient.getString("htmlManagerServlet.appsTasks");
/*  389 */     writer.print(MessageFormat.format("<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"6\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td class=\"header-left\"><small>{1}</small></td>\n <td class=\"header-left\"><small>{2}</small></td>\n <td class=\"header-center\"><small>{3}</small></td>\n <td class=\"header-center\"><small>{4}</small></td>\n <td class=\"header-left\"><small>{5}</small></td>\n <td class=\"header-left\"><small>{6}</small></td>\n</tr>\n", args));
/*      */     
/*      */ 
/*      */ 
/*  393 */     Container[] children = this.host.findChildren();
/*  394 */     String[] contextNames = new String[children.length];
/*  395 */     for (int i = 0; i < children.length; i++) {
/*  396 */       contextNames[i] = children[i].getName();
/*      */     }
/*  398 */     Arrays.sort(contextNames);
/*      */     
/*  400 */     String appsStart = smClient.getString("htmlManagerServlet.appsStart");
/*  401 */     String appsStop = smClient.getString("htmlManagerServlet.appsStop");
/*  402 */     String appsReload = smClient.getString("htmlManagerServlet.appsReload");
/*  403 */     String appsUndeploy = smClient.getString("htmlManagerServlet.appsUndeploy");
/*      */     
/*  405 */     String appsExpire = smClient.getString("htmlManagerServlet.appsExpire");
/*  406 */     String noVersion = "<i>" + smClient.getString("htmlManagerServlet.noVersion") + "</i>";
/*      */     
/*      */ 
/*  409 */     boolean isHighlighted = true;
/*  410 */     boolean isDeployed = true;
/*  411 */     String highlightColor = null;
/*      */     
/*  413 */     for (String contextName : contextNames) {
/*  414 */       Context ctxt = (Context)this.host.findChild(contextName);
/*      */       
/*  416 */       if (ctxt != null)
/*      */       {
/*  418 */         isHighlighted = !isHighlighted;
/*  419 */         if (isHighlighted) {
/*  420 */           highlightColor = "#C3F3C3";
/*      */         } else {
/*  422 */           highlightColor = "#FFFFFF";
/*      */         }
/*      */         
/*  425 */         String contextPath = ctxt.getPath();
/*  426 */         String displayPath = contextPath;
/*  427 */         if (displayPath.equals("")) {
/*  428 */           displayPath = "/";
/*      */         }
/*      */         
/*  431 */         StringBuilder tmp = new StringBuilder();
/*  432 */         tmp.append("path=");
/*  433 */         tmp.append(URL_ENCODER.encode(displayPath));
/*  434 */         if (ctxt.getWebappVersion().length() > 0) {
/*  435 */           tmp.append("&version=");
/*  436 */           tmp.append(URL_ENCODER.encode(ctxt.getWebappVersion()));
/*      */         }
/*  438 */         String pathVersion = tmp.toString();
/*      */         try
/*      */         {
/*  441 */           isDeployed = isDeployed(contextName);
/*      */         }
/*      */         catch (Exception e) {
/*  444 */           isDeployed = false;
/*      */         }
/*      */         
/*  447 */         args = new Object[7];
/*  448 */         args[0] = ("<a href=\"" + URL_ENCODER.encode(new StringBuilder().append(contextPath).append("/").toString()) + "\">" + RequestUtil.filter(displayPath) + "</a>");
/*      */         
/*  450 */         if ("".equals(ctxt.getWebappVersion())) {
/*  451 */           args[1] = noVersion;
/*      */         } else {
/*  453 */           args[1] = RequestUtil.filter(ctxt.getWebappVersion());
/*      */         }
/*  455 */         if (ctxt.getDisplayName() == null) {
/*  456 */           args[2] = "&nbsp;";
/*      */         } else {
/*  458 */           args[2] = RequestUtil.filter(ctxt.getDisplayName());
/*      */         }
/*  460 */         args[3] = Boolean.valueOf(ctxt.getState().isAvailable());
/*  461 */         args[4] = RequestUtil.filter(response.encodeURL(request.getContextPath() + "/html/sessions?" + pathVersion));
/*      */         
/*  463 */         Manager manager = ctxt.getManager();
/*  464 */         if (((manager instanceof DistributedManager)) && (this.showProxySessions)) {
/*  465 */           args[5] = Integer.valueOf(((DistributedManager)manager).getActiveSessionsFull());
/*      */         }
/*  467 */         else if (manager != null) {
/*  468 */           args[5] = Integer.valueOf(manager.getActiveSessions());
/*      */         } else {
/*  470 */           args[5] = Integer.valueOf(0);
/*      */         }
/*      */         
/*  473 */         args[6] = highlightColor;
/*      */         
/*  475 */         writer.print(MessageFormat.format("<tr>\n <td class=\"row-left\" bgcolor=\"{6}\" rowspan=\"2\"><small>{0}</small></td>\n <td class=\"row-left\" bgcolor=\"{6}\" rowspan=\"2\"><small>{1}</small></td>\n <td class=\"row-left\" bgcolor=\"{6}\" rowspan=\"2\"><small>{2}</small></td>\n <td class=\"row-center\" bgcolor=\"{6}\" rowspan=\"2\"><small>{3}</small></td>\n <td class=\"row-center\" bgcolor=\"{6}\" rowspan=\"2\"><small><a href=\"{4}\">{5}</a></small></td>\n", args));
/*      */         
/*      */ 
/*  478 */         args = new Object[14];
/*  479 */         args[0] = RequestUtil.filter(response.encodeURL(request.getContextPath() + "/html/start?" + pathVersion));
/*      */         
/*  481 */         args[1] = appsStart;
/*  482 */         args[2] = RequestUtil.filter(response.encodeURL(request.getContextPath() + "/html/stop?" + pathVersion));
/*      */         
/*  484 */         args[3] = appsStop;
/*  485 */         args[4] = RequestUtil.filter(response.encodeURL(request.getContextPath() + "/html/reload?" + pathVersion));
/*      */         
/*  487 */         args[5] = appsReload;
/*  488 */         args[6] = RequestUtil.filter(response.encodeURL(request.getContextPath() + "/html/undeploy?" + pathVersion));
/*      */         
/*  490 */         args[7] = appsUndeploy;
/*  491 */         args[8] = RequestUtil.filter(response.encodeURL(request.getContextPath() + "/html/expire?" + pathVersion));
/*      */         
/*  493 */         args[9] = appsExpire;
/*  494 */         args[10] = smClient.getString("htmlManagerServlet.expire.explain");
/*  495 */         if (manager == null) {
/*  496 */           args[11] = smClient.getString("htmlManagerServlet.noManager");
/*      */         } else {
/*  498 */           args[11] = Integer.valueOf(ctxt.getSessionTimeout());
/*      */         }
/*  500 */         args[12] = smClient.getString("htmlManagerServlet.expire.unit");
/*  501 */         args[13] = highlightColor;
/*      */         
/*  503 */         if (ctxt.getName().equals(this.context.getName())) {
/*  504 */           writer.print(MessageFormat.format(" <td class=\"row-left\" bgcolor=\"{13}\">\n  <small>\n  &nbsp;{1}&nbsp;\n  &nbsp;{3}&nbsp;\n  &nbsp;{5}&nbsp;\n  &nbsp;{7}&nbsp;\n  </small>\n </td>\n</tr><tr>\n <td class=\"row-left\" bgcolor=\"{13}\">\n  <form method=\"POST\" action=\"{8}\">\n  <small>\n  &nbsp;<input type=\"submit\" value=\"{9}\">&nbsp;{10}&nbsp;<input type=\"text\" name=\"idle\" size=\"5\" value=\"{11}\">&nbsp;{12}&nbsp;\n  </small>\n  </form>\n </td>\n</tr>\n", args));
/*      */         }
/*  506 */         else if ((ctxt.getState().isAvailable()) && (isDeployed)) {
/*  507 */           writer.print(MessageFormat.format(" <td class=\"row-left\" bgcolor=\"{13}\">\n  &nbsp;<small>{1}</small>&nbsp;\n  <form class=\"inline\" method=\"POST\" action=\"{2}\">  <small><input type=\"submit\" value=\"{3}\"></small>  </form>\n  <form class=\"inline\" method=\"POST\" action=\"{4}\">  <small><input type=\"submit\" value=\"{5}\"></small>  </form>\n  <form class=\"inline\" method=\"POST\" action=\"{6}\">  <small><input type=\"submit\" value=\"{7}\"></small>  </form>\n </td>\n </tr><tr>\n <td class=\"row-left\" bgcolor=\"{13}\">\n  <form method=\"POST\" action=\"{8}\">\n  <small>\n  &nbsp;<input type=\"submit\" value=\"{9}\">&nbsp;{10}&nbsp;<input type=\"text\" name=\"idle\" size=\"5\" value=\"{11}\">&nbsp;{12}&nbsp;\n  </small>\n  </form>\n </td>\n</tr>\n", args));
/*      */         }
/*  509 */         else if ((ctxt.getState().isAvailable()) && (!isDeployed)) {
/*  510 */           writer.print(MessageFormat.format(" <td class=\"row-left\" bgcolor=\"{13}\">\n  &nbsp;<small>{1}</small>&nbsp;\n  <form class=\"inline\" method=\"POST\" action=\"{2}\">  <small><input type=\"submit\" value=\"{3}\"></small>  </form>\n  <form class=\"inline\" method=\"POST\" action=\"{4}\">  <small><input type=\"submit\" value=\"{5}\"></small>  </form>\n  &nbsp;<small>{7}</small>&nbsp;\n </td>\n </tr><tr>\n <td class=\"row-left\" bgcolor=\"{13}\">\n  <form method=\"POST\" action=\"{8}\">\n  <small>\n  &nbsp;<input type=\"submit\" value=\"{9}\">&nbsp;{10}&nbsp;<input type=\"text\" name=\"idle\" size=\"5\" value=\"{11}\">&nbsp;{12}&nbsp;\n  </small>\n  </form>\n </td>\n</tr>\n", args));
/*      */         }
/*  512 */         else if ((!ctxt.getState().isAvailable()) && (isDeployed)) {
/*  513 */           writer.print(MessageFormat.format(" <td class=\"row-left\" bgcolor=\"{13}\" rowspan=\"2\">\n  <form class=\"inline\" method=\"POST\" action=\"{0}\">  <small><input type=\"submit\" value=\"{1}\"></small>  </form>\n  &nbsp;<small>{3}</small>&nbsp;\n  &nbsp;<small>{5}</small>&nbsp;\n  <form class=\"inline\" method=\"POST\" action=\"{6}\">  <small><input type=\"submit\" value=\"{7}\"></small>  </form>\n </td>\n</tr>\n<tr></tr>\n", args));
/*      */         }
/*      */         else {
/*  516 */           writer.print(MessageFormat.format(" <td class=\"row-left\" bgcolor=\"{13}\" rowspan=\"2\">\n  <form class=\"inline\" method=\"POST\" action=\"{0}\">  <small><input type=\"submit\" value=\"{1}\"></small>  </form>\n  &nbsp;<small>{3}</small>&nbsp;\n  &nbsp;<small>{5}</small>&nbsp;\n  &nbsp;<small>{7}</small>&nbsp;\n </td>\n</tr>\n<tr></tr>\n", args));
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  524 */     args = new Object[7];
/*  525 */     args[0] = smClient.getString("htmlManagerServlet.deployTitle");
/*  526 */     args[1] = smClient.getString("htmlManagerServlet.deployServer");
/*  527 */     args[2] = response.encodeURL(request.getContextPath() + "/html/deploy");
/*  528 */     args[3] = smClient.getString("htmlManagerServlet.deployPath");
/*  529 */     args[4] = smClient.getString("htmlManagerServlet.deployConfig");
/*  530 */     args[5] = smClient.getString("htmlManagerServlet.deployWar");
/*  531 */     args[6] = smClient.getString("htmlManagerServlet.deployButton");
/*  532 */     writer.print(MessageFormat.format("</table>\n<br>\n<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"2\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{1}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{2}\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-right\">\n  <small>{3}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"deployPath\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{4}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"deployConfig\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{5}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"deployWar\" size=\"40\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  &nbsp;\n </td>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{6}\">\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n", args));
/*      */     
/*  534 */     args = new Object[4];
/*  535 */     args[0] = smClient.getString("htmlManagerServlet.deployUpload");
/*  536 */     args[1] = response.encodeURL(request.getContextPath() + "/html/upload");
/*  537 */     args[2] = smClient.getString("htmlManagerServlet.deployUploadFile");
/*  538 */     args[3] = smClient.getString("htmlManagerServlet.deployButton");
/*  539 */     writer.print(MessageFormat.format("<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{0}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{1}\" enctype=\"multipart/form-data\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-right\">\n  <small>{2}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"file\" name=\"deployWar\" size=\"40\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  &nbsp;\n </td>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{3}\">\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n</table>\n<br>\n\n", args));
/*      */     
/*      */ 
/*  542 */     args = new Object[9];
/*  543 */     args[0] = smClient.getString("htmlManagerServlet.diagnosticsTitle");
/*  544 */     args[1] = smClient.getString("htmlManagerServlet.diagnosticsLeak");
/*  545 */     args[2] = response.encodeURL(request.getContextPath() + "/html/findleaks");
/*      */     
/*  547 */     args[3] = smClient.getString("htmlManagerServlet.diagnosticsLeakWarning");
/*  548 */     args[4] = smClient.getString("htmlManagerServlet.diagnosticsLeakButton");
/*  549 */     args[5] = smClient.getString("htmlManagerServlet.diagnosticsSsl");
/*  550 */     args[6] = response.encodeURL(request.getContextPath() + "/html/sslConnectorCiphers");
/*      */     
/*  552 */     args[7] = smClient.getString("htmlManagerServlet.diagnosticsSslConnectorCipherButton");
/*  553 */     args[8] = smClient.getString("htmlManagerServlet.diagnosticsSslConnectorCipherText");
/*  554 */     writer.print(MessageFormat.format("<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"2\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{1}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{2}\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{4}\">\n </td>\n <td class=\"row-left\">\n  <small>{3}</small>\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{5}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{6}\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{7}\">\n </td>\n <td class=\"row-left\">\n  <small>{8}</small>\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n</table>\n<br>", args));
/*      */     
/*      */ 
/*  557 */     args = new Object[9];
/*  558 */     args[0] = smClient.getString("htmlManagerServlet.serverTitle");
/*  559 */     args[1] = smClient.getString("htmlManagerServlet.serverVersion");
/*  560 */     args[2] = smClient.getString("htmlManagerServlet.serverJVMVersion");
/*  561 */     args[3] = smClient.getString("htmlManagerServlet.serverJVMVendor");
/*  562 */     args[4] = smClient.getString("htmlManagerServlet.serverOSName");
/*  563 */     args[5] = smClient.getString("htmlManagerServlet.serverOSVersion");
/*  564 */     args[6] = smClient.getString("htmlManagerServlet.serverOSArch");
/*  565 */     args[7] = sm.getString("htmlManagerServlet.serverHostname");
/*  566 */     args[8] = sm.getString("htmlManagerServlet.serverIPAddress");
/*  567 */     writer.print(MessageFormat.format(Constants.SERVER_HEADER_SECTION, args));
/*      */     
/*      */ 
/*      */ 
/*  571 */     args = new Object[8];
/*  572 */     args[0] = ServerInfo.getServerInfo();
/*  573 */     args[1] = System.getProperty("java.runtime.version");
/*  574 */     args[2] = System.getProperty("java.vm.vendor");
/*  575 */     args[3] = System.getProperty("os.name");
/*  576 */     args[4] = System.getProperty("os.version");
/*  577 */     args[5] = System.getProperty("os.arch");
/*      */     try {
/*  579 */       InetAddress address = InetAddress.getLocalHost();
/*  580 */       args[6] = address.getHostName();
/*  581 */       args[7] = address.getHostAddress();
/*      */     } catch (UnknownHostException e) {
/*  583 */       args[6] = "-";
/*  584 */       args[7] = "-";
/*      */     }
/*  586 */     writer.print(MessageFormat.format(Constants.SERVER_ROW_SECTION, args));
/*      */     
/*      */ 
/*  589 */     writer.print(Constants.HTML_TAIL_SECTION);
/*      */     
/*      */ 
/*  592 */     writer.flush();
/*  593 */     writer.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String reload(ContextName cn, StringManager smClient)
/*      */   {
/*  607 */     StringWriter stringWriter = new StringWriter();
/*  608 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  610 */     super.reload(printWriter, cn, smClient);
/*      */     
/*  612 */     return stringWriter.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String undeploy(ContextName cn, StringManager smClient)
/*      */   {
/*  626 */     StringWriter stringWriter = new StringWriter();
/*  627 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  629 */     super.undeploy(printWriter, cn, smClient);
/*      */     
/*  631 */     return stringWriter.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String sessions(ContextName cn, int idle, StringManager smClient)
/*      */   {
/*  647 */     StringWriter stringWriter = new StringWriter();
/*  648 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  650 */     super.sessions(printWriter, cn, idle, smClient);
/*      */     
/*  652 */     return stringWriter.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String start(ContextName cn, StringManager smClient)
/*      */   {
/*  666 */     StringWriter stringWriter = new StringWriter();
/*  667 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  669 */     super.start(printWriter, cn, smClient);
/*      */     
/*  671 */     return stringWriter.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String stop(ContextName cn, StringManager smClient)
/*      */   {
/*  685 */     StringWriter stringWriter = new StringWriter();
/*  686 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  688 */     super.stop(printWriter, cn, smClient);
/*      */     
/*  690 */     return stringWriter.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String findleaks(StringManager smClient)
/*      */   {
/*  704 */     StringBuilder msg = new StringBuilder();
/*      */     
/*  706 */     StringWriter stringWriter = new StringWriter();
/*  707 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  709 */     super.findleaks(false, printWriter, smClient);
/*      */     
/*  711 */     String writerText = stringWriter.toString();
/*      */     
/*  713 */     if (writerText.length() > 0) {
/*  714 */       if (!writerText.startsWith("FAIL -")) {
/*  715 */         msg.append(smClient.getString("htmlManagerServlet.findleaksList"));
/*      */       }
/*      */       
/*  718 */       msg.append(writerText);
/*      */     } else {
/*  720 */       msg.append(smClient.getString("htmlManagerServlet.findleaksNone"));
/*      */     }
/*      */     
/*  723 */     return msg.toString();
/*      */   }
/*      */   
/*      */   protected void sslConnectorCiphers(HttpServletRequest request, HttpServletResponse response)
/*      */     throws ServletException, IOException
/*      */   {
/*  729 */     request.setAttribute("cipherList", getConnectorCiphers());
/*  730 */     getServletContext().getRequestDispatcher("/WEB-INF/jsp/connectorCiphers.jsp").forward(request, response);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getServletInfo()
/*      */   {
/*  739 */     return "HTMLManagerServlet, Copyright (c) 1999-2016, The Apache Software Foundation";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void init()
/*      */     throws ServletException
/*      */   {
/*  747 */     super.init();
/*      */     
/*      */ 
/*  750 */     String value = null;
/*  751 */     value = getServletConfig().getInitParameter("showProxySessions");
/*  752 */     this.showProxySessions = Boolean.parseBoolean(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String expireSessions(ContextName cn, HttpServletRequest req, StringManager smClient)
/*      */   {
/*  768 */     int idle = -1;
/*  769 */     String idleParam = req.getParameter("idle");
/*  770 */     if (idleParam != null) {
/*      */       try {
/*  772 */         idle = Integer.parseInt(idleParam);
/*      */       } catch (NumberFormatException e) {
/*  774 */         log("Could not parse idle parameter to an int: " + idleParam);
/*      */       }
/*      */     }
/*  777 */     return sessions(cn, idle, smClient);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doSessions(ContextName cn, HttpServletRequest req, HttpServletResponse resp, StringManager smClient)
/*      */     throws ServletException, IOException
/*      */   {
/*  793 */     req.setAttribute("path", cn.getPath());
/*  794 */     req.setAttribute("version", cn.getVersion());
/*  795 */     String action = req.getParameter("action");
/*  796 */     if (this.debug >= 1) {
/*  797 */       log("sessions: Session action '" + action + "' for web application '" + cn.getDisplayName() + "'");
/*      */     }
/*      */     
/*  800 */     if ("sessionDetail".equals(action)) {
/*  801 */       String sessionId = req.getParameter("sessionId");
/*  802 */       displaySessionDetailPage(req, resp, cn, sessionId, smClient);
/*  803 */       return; }
/*  804 */     if ("invalidateSessions".equals(action)) {
/*  805 */       String[] sessionIds = req.getParameterValues("sessionIds");
/*  806 */       int i = invalidateSessions(cn, sessionIds, smClient);
/*  807 */       req.setAttribute("message", "" + i + " sessions invalidated.");
/*  808 */     } else if ("removeSessionAttribute".equals(action)) {
/*  809 */       String sessionId = req.getParameter("sessionId");
/*  810 */       String name = req.getParameter("attributeName");
/*  811 */       boolean removed = removeSessionAttribute(cn, sessionId, name, smClient);
/*      */       
/*  813 */       String outMessage = "Session did not contain any attribute named '" + name + "'";
/*  814 */       req.setAttribute("message", outMessage);
/*  815 */       displaySessionDetailPage(req, resp, cn, sessionId, smClient);
/*  816 */       return;
/*      */     }
/*  818 */     displaySessionsListPage(cn, req, resp, smClient);
/*      */   }
/*      */   
/*      */   protected List<Session> getSessionsForName(ContextName cn, StringManager smClient)
/*      */   {
/*  823 */     if ((cn == null) || ((!cn.getPath().startsWith("/")) && (!cn.getPath().equals(""))))
/*      */     {
/*  825 */       String path = null;
/*  826 */       if (cn != null) {
/*  827 */         path = cn.getPath();
/*      */       }
/*  829 */       throw new IllegalArgumentException(smClient.getString("managerServlet.invalidPath", new Object[] { RequestUtil.filter(path) }));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  834 */     Context ctxt = (Context)this.host.findChild(cn.getName());
/*  835 */     if (null == ctxt) {
/*  836 */       throw new IllegalArgumentException(smClient.getString("managerServlet.noContext", new Object[] { RequestUtil.filter(cn.getDisplayName()) }));
/*      */     }
/*      */     
/*      */ 
/*  840 */     Manager manager = ctxt.getManager();
/*  841 */     List<Session> sessions = new ArrayList();
/*  842 */     sessions.addAll(Arrays.asList(manager.findSessions()));
/*  843 */     if (((manager instanceof DistributedManager)) && (this.showProxySessions))
/*      */     {
/*  845 */       Set<String> sessionIds = ((DistributedManager)manager).getSessionIdsFull();
/*      */       
/*      */ 
/*  848 */       for (Session session : sessions) {
/*  849 */         sessionIds.remove(session.getId());
/*      */       }
/*      */       
/*  852 */       for (String sessionId : sessionIds) {
/*  853 */         sessions.add(new DummyProxySession(sessionId));
/*      */       }
/*      */     }
/*  856 */     return sessions;
/*      */   }
/*      */   
/*      */ 
/*      */   protected Session getSessionForNameAndId(ContextName cn, String id, StringManager smClient)
/*      */   {
/*  862 */     List<Session> sessions = getSessionsForName(cn, smClient);
/*  863 */     if (sessions.isEmpty()) return null;
/*  864 */     for (Session session : sessions) {
/*  865 */       if (session.getId().equals(id)) {
/*  866 */         return session;
/*      */       }
/*      */     }
/*  869 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void displaySessionsListPage(ContextName cn, HttpServletRequest req, HttpServletResponse resp, StringManager smClient)
/*      */     throws ServletException, IOException
/*      */   {
/*  885 */     List<Session> sessions = getSessionsForName(cn, smClient);
/*  886 */     String sortBy = req.getParameter("sort");
/*  887 */     String orderBy = null;
/*  888 */     if ((null != sortBy) && (!"".equals(sortBy.trim()))) {
/*  889 */       Comparator<Session> comparator = getComparator(sortBy);
/*  890 */       if (comparator != null) {
/*  891 */         orderBy = req.getParameter("order");
/*  892 */         if ("DESC".equalsIgnoreCase(orderBy)) {
/*  893 */           comparator = Collections.reverseOrder(comparator);
/*  894 */           orderBy = "ASC";
/*      */         } else {
/*  896 */           orderBy = "DESC";
/*      */         }
/*      */         try {
/*  899 */           Collections.sort(sessions, comparator);
/*      */         }
/*      */         catch (IllegalStateException ise) {
/*  902 */           req.setAttribute("error", "Can't sort session list: one session is invalidated");
/*      */         }
/*      */       } else {
/*  905 */         log("WARNING: unknown sort order: " + sortBy);
/*      */       }
/*      */     }
/*      */     
/*  909 */     req.setAttribute("sort", sortBy);
/*  910 */     req.setAttribute("order", orderBy);
/*  911 */     req.setAttribute("activeSessions", sessions);
/*      */     
/*      */ 
/*      */ 
/*  915 */     resp.setHeader("Pragma", "No-cache");
/*  916 */     resp.setHeader("Cache-Control", "no-cache,no-store,max-age=0");
/*  917 */     resp.setDateHeader("Expires", 0L);
/*  918 */     getServletContext().getRequestDispatcher("/WEB-INF/jsp/sessionsList.jsp").include(req, resp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void displaySessionDetailPage(HttpServletRequest req, HttpServletResponse resp, ContextName cn, String sessionId, StringManager smClient)
/*      */     throws ServletException, IOException
/*      */   {
/*  935 */     Session session = getSessionForNameAndId(cn, sessionId, smClient);
/*      */     
/*      */ 
/*      */ 
/*  939 */     resp.setHeader("Pragma", "No-cache");
/*  940 */     resp.setHeader("Cache-Control", "no-cache,no-store,max-age=0");
/*  941 */     resp.setDateHeader("Expires", 0L);
/*  942 */     req.setAttribute("currentSession", session);
/*  943 */     getServletContext().getRequestDispatcher(resp.encodeURL("/WEB-INF/jsp/sessionDetail.jsp")).include(req, resp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int invalidateSessions(ContextName cn, String[] sessionIds, StringManager smClient)
/*      */   {
/*  957 */     if (null == sessionIds) {
/*  958 */       return 0;
/*      */     }
/*  960 */     int nbAffectedSessions = 0;
/*  961 */     for (int i = 0; i < sessionIds.length; i++) {
/*  962 */       String sessionId = sessionIds[i];
/*  963 */       HttpSession session = getSessionForNameAndId(cn, sessionId, smClient).getSession();
/*      */       
/*  965 */       if (null == session)
/*      */       {
/*  967 */         if (this.debug >= 1) {
/*  968 */           log("WARNING: can't invalidate null session " + sessionId);
/*      */         }
/*      */       }
/*      */       else {
/*      */         try {
/*  973 */           session.invalidate();
/*  974 */           nbAffectedSessions++;
/*  975 */           if (this.debug >= 1) {
/*  976 */             log("Invalidating session id " + sessionId);
/*      */           }
/*      */         } catch (IllegalStateException ise) {
/*  979 */           if (this.debug >= 1)
/*  980 */             log("Can't invalidate already invalidated session id " + sessionId);
/*      */         }
/*      */       }
/*      */     }
/*  984 */     return nbAffectedSessions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean removeSessionAttribute(ContextName cn, String sessionId, String attributeName, StringManager smClient)
/*      */   {
/*  998 */     HttpSession session = getSessionForNameAndId(cn, sessionId, smClient).getSession();
/*      */     
/* 1000 */     if (null == session)
/*      */     {
/* 1002 */       if (this.debug >= 1) {
/* 1003 */         log("WARNING: can't remove attribute '" + attributeName + "' for null session " + sessionId);
/*      */       }
/* 1005 */       return false;
/*      */     }
/* 1007 */     boolean wasPresent = null != session.getAttribute(attributeName);
/*      */     try {
/* 1009 */       session.removeAttribute(attributeName);
/*      */     } catch (IllegalStateException ise) {
/* 1011 */       if (this.debug >= 1) {
/* 1012 */         log("Can't remote attribute '" + attributeName + "' for invalidated session id " + sessionId);
/*      */       }
/*      */     }
/* 1015 */     return wasPresent;
/*      */   }
/*      */   
/*      */   protected Comparator<Session> getComparator(String sortBy) {
/* 1019 */     Comparator<Session> comparator = null;
/* 1020 */     if ("CreationTime".equalsIgnoreCase(sortBy)) {
/* 1021 */       comparator = new BaseSessionComparator()
/*      */       {
/*      */         public Comparable<Date> getComparableObject(Session session) {
/* 1024 */           return new Date(session.getCreationTime());
/*      */         }
/*      */       };
/* 1027 */     } else if ("id".equalsIgnoreCase(sortBy)) {
/* 1028 */       comparator = new BaseSessionComparator()
/*      */       {
/*      */         public Comparable<String> getComparableObject(Session session) {
/* 1031 */           return session.getId();
/*      */         }
/*      */       };
/* 1034 */     } else if ("LastAccessedTime".equalsIgnoreCase(sortBy)) {
/* 1035 */       comparator = new BaseSessionComparator()
/*      */       {
/*      */         public Comparable<Date> getComparableObject(Session session) {
/* 1038 */           return new Date(session.getLastAccessedTime());
/*      */         }
/*      */       };
/* 1041 */     } else if ("MaxInactiveInterval".equalsIgnoreCase(sortBy)) {
/* 1042 */       comparator = new BaseSessionComparator()
/*      */       {
/*      */         public Comparable<Integer> getComparableObject(Session session) {
/* 1045 */           return Integer.valueOf(session.getMaxInactiveInterval());
/*      */         }
/*      */       };
/* 1048 */     } else if ("new".equalsIgnoreCase(sortBy)) {
/* 1049 */       comparator = new BaseSessionComparator()
/*      */       {
/*      */         public Comparable<Boolean> getComparableObject(Session session) {
/* 1052 */           return Boolean.valueOf(session.getSession().isNew());
/*      */         }
/*      */       };
/* 1055 */     } else if ("locale".equalsIgnoreCase(sortBy)) {
/* 1056 */       comparator = new BaseSessionComparator()
/*      */       {
/*      */         public Comparable<String> getComparableObject(Session session) {
/* 1059 */           return JspHelper.guessDisplayLocaleFromSession(session);
/*      */         }
/*      */       };
/* 1062 */     } else if ("user".equalsIgnoreCase(sortBy)) {
/* 1063 */       comparator = new BaseSessionComparator()
/*      */       {
/*      */         public Comparable<String> getComparableObject(Session session) {
/* 1066 */           return JspHelper.guessDisplayUserFromSession(session);
/*      */         }
/*      */       };
/* 1069 */     } else if ("UsedTime".equalsIgnoreCase(sortBy)) {
/* 1070 */       comparator = new BaseSessionComparator()
/*      */       {
/*      */         public Comparable<Date> getComparableObject(Session session) {
/* 1073 */           return new Date(SessionUtils.getUsedTimeForSession(session));
/*      */         }
/*      */       };
/* 1076 */     } else if ("InactiveTime".equalsIgnoreCase(sortBy)) {
/* 1077 */       comparator = new BaseSessionComparator()
/*      */       {
/*      */         public Comparable<Date> getComparableObject(Session session) {
/* 1080 */           return new Date(SessionUtils.getInactiveTimeForSession(session));
/*      */         }
/*      */       };
/* 1083 */     } else if ("TTL".equalsIgnoreCase(sortBy)) {
/* 1084 */       comparator = new BaseSessionComparator()
/*      */       {
/*      */         public Comparable<Date> getComparableObject(Session session) {
/* 1087 */           return new Date(SessionUtils.getTTLForSession(session));
/*      */         }
/*      */       };
/*      */     }
/*      */     
/* 1092 */     return comparator;
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\manager\HTMLManagerServlet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */