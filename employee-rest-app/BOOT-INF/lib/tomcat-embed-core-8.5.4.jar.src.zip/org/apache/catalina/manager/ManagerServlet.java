/*      */ package org.apache.catalina.manager;
/*      */ 
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import javax.management.MBeanServer;
/*      */ import javax.management.MalformedObjectNameException;
/*      */ import javax.management.ObjectName;
/*      */ import javax.naming.Binding;
/*      */ import javax.naming.NamingEnumeration;
/*      */ import javax.servlet.ServletConfig;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletInputStream;
/*      */ import javax.servlet.UnavailableException;
/*      */ import javax.servlet.http.HttpServlet;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.ContainerServlet;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.Server;
/*      */ import org.apache.catalina.Service;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.connector.Connector;
/*      */ import org.apache.catalina.core.StandardHost;
/*      */ import org.apache.catalina.startup.ExpandWar;
/*      */ import org.apache.catalina.util.ContextName;
/*      */ import org.apache.catalina.util.RequestUtil;
/*      */ import org.apache.catalina.util.ServerInfo;
/*      */ import org.apache.coyote.ProtocolHandler;
/*      */ import org.apache.tomcat.util.Diagnostics;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.modeler.Registry;
/*      */ import org.apache.tomcat.util.net.SSLHostConfig;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ManagerServlet
/*      */   extends HttpServlet
/*      */   implements ContainerServlet
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*  167 */   protected File configBase = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  173 */   protected transient org.apache.catalina.Context context = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  179 */   protected int debug = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  185 */   protected File versioned = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  191 */   protected transient Host host = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  197 */   protected transient MBeanServer mBeanServer = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  203 */   protected ObjectName oname = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  210 */   protected transient javax.naming.Context global = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  216 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.manager");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  223 */   protected transient Wrapper wrapper = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Wrapper getWrapper()
/*      */   {
/*  235 */     return this.wrapper;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWrapper(Wrapper wrapper)
/*      */   {
/*  248 */     this.wrapper = wrapper;
/*  249 */     if (wrapper == null) {
/*  250 */       this.context = null;
/*  251 */       this.host = null;
/*  252 */       this.oname = null;
/*      */     } else {
/*  254 */       this.context = ((org.apache.catalina.Context)wrapper.getParent());
/*  255 */       this.host = ((Host)this.context.getParent());
/*  256 */       Engine engine = (Engine)this.host.getParent();
/*  257 */       String name = engine.getName() + ":type=Deployer,host=" + this.host.getName();
/*      */       try
/*      */       {
/*  260 */         this.oname = new ObjectName(name);
/*      */       } catch (Exception e) {
/*  262 */         log(sm.getString("managerServlet.objectNameFail", new Object[] { name }), e);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  267 */     this.mBeanServer = Registry.getRegistry(null, null).getMBeanServer();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void destroy() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*      */     throws IOException, ServletException
/*      */   {
/*  300 */     StringManager smClient = StringManager.getManager("org.apache.catalina.manager", request.getLocales());
/*      */     
/*      */ 
/*      */ 
/*  304 */     String command = request.getPathInfo();
/*  305 */     if (command == null)
/*  306 */       command = request.getServletPath();
/*  307 */     String config = request.getParameter("config");
/*  308 */     String path = request.getParameter("path");
/*  309 */     ContextName cn = null;
/*  310 */     if (path != null) {
/*  311 */       cn = new ContextName(path, request.getParameter("version"));
/*      */     }
/*  313 */     String type = request.getParameter("type");
/*  314 */     String war = request.getParameter("war");
/*  315 */     String tag = request.getParameter("tag");
/*  316 */     boolean update = false;
/*  317 */     if ((request.getParameter("update") != null) && (request.getParameter("update").equals("true")))
/*      */     {
/*  319 */       update = true;
/*      */     }
/*      */     
/*  322 */     boolean statusLine = false;
/*  323 */     if ("true".equals(request.getParameter("statusLine"))) {
/*  324 */       statusLine = true;
/*      */     }
/*      */     
/*      */ 
/*  328 */     response.setContentType("text/plain; charset=utf-8");
/*  329 */     PrintWriter writer = response.getWriter();
/*      */     
/*      */ 
/*  332 */     if (command == null) {
/*  333 */       writer.println(smClient.getString("managerServlet.noCommand"));
/*  334 */     } else if (command.equals("/deploy")) {
/*  335 */       if ((war != null) || (config != null)) {
/*  336 */         deploy(writer, config, cn, war, update, smClient);
/*  337 */       } else if (tag != null) {
/*  338 */         deploy(writer, cn, tag, smClient);
/*      */       } else {
/*  340 */         writer.println(smClient.getString("managerServlet.invalidCommand", new Object[] { command }));
/*      */       }
/*      */     }
/*  343 */     else if (command.equals("/list")) {
/*  344 */       list(writer, smClient);
/*  345 */     } else if (command.equals("/reload")) {
/*  346 */       reload(writer, cn, smClient);
/*  347 */     } else if (command.equals("/resources")) {
/*  348 */       resources(writer, type, smClient);
/*  349 */     } else if (command.equals("/save")) {
/*  350 */       save(writer, path, smClient);
/*  351 */     } else if (command.equals("/serverinfo")) {
/*  352 */       serverinfo(writer, smClient);
/*  353 */     } else if (command.equals("/sessions")) {
/*  354 */       expireSessions(writer, cn, request, smClient);
/*  355 */     } else if (command.equals("/expire")) {
/*  356 */       expireSessions(writer, cn, request, smClient);
/*  357 */     } else if (command.equals("/start")) {
/*  358 */       start(writer, cn, smClient);
/*  359 */     } else if (command.equals("/stop")) {
/*  360 */       stop(writer, cn, smClient);
/*  361 */     } else if (command.equals("/undeploy")) {
/*  362 */       undeploy(writer, cn, smClient);
/*  363 */     } else if (command.equals("/findleaks")) {
/*  364 */       findleaks(statusLine, writer, smClient);
/*  365 */     } else if (command.equals("/vminfo")) {
/*  366 */       vmInfo(writer, smClient, request.getLocales());
/*  367 */     } else if (command.equals("/threaddump")) {
/*  368 */       threadDump(writer, smClient, request.getLocales());
/*  369 */     } else if (command.equals("/sslConnectorCiphers")) {
/*  370 */       sslConnectorCiphers(writer, smClient);
/*      */     } else {
/*  372 */       writer.println(smClient.getString("managerServlet.unknownCommand", new Object[] { command }));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  377 */     writer.flush();
/*  378 */     writer.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void doPut(HttpServletRequest request, HttpServletResponse response)
/*      */     throws IOException, ServletException
/*      */   {
/*  397 */     StringManager smClient = StringManager.getManager("org.apache.catalina.manager", request.getLocales());
/*      */     
/*      */ 
/*      */ 
/*  401 */     String command = request.getPathInfo();
/*  402 */     if (command == null)
/*  403 */       command = request.getServletPath();
/*  404 */     String path = request.getParameter("path");
/*  405 */     ContextName cn = null;
/*  406 */     if (path != null) {
/*  407 */       cn = new ContextName(path, request.getParameter("version"));
/*      */     }
/*  409 */     String tag = request.getParameter("tag");
/*  410 */     boolean update = false;
/*  411 */     if ((request.getParameter("update") != null) && (request.getParameter("update").equals("true")))
/*      */     {
/*  413 */       update = true;
/*      */     }
/*      */     
/*      */ 
/*  417 */     response.setContentType("text/plain;charset=utf-8");
/*  418 */     PrintWriter writer = response.getWriter();
/*      */     
/*      */ 
/*  421 */     if (command == null) {
/*  422 */       writer.println(smClient.getString("managerServlet.noCommand"));
/*  423 */     } else if (command.equals("/deploy")) {
/*  424 */       deploy(writer, cn, tag, update, request, smClient);
/*      */     } else {
/*  426 */       writer.println(smClient.getString("managerServlet.unknownCommand", new Object[] { command }));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  431 */     writer.flush();
/*  432 */     writer.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void init()
/*      */     throws ServletException
/*      */   {
/*  444 */     if ((this.wrapper == null) || (this.context == null)) {
/*  445 */       throw new UnavailableException(sm.getString("managerServlet.noWrapper"));
/*      */     }
/*      */     
/*      */ 
/*  449 */     String value = null;
/*      */     try {
/*  451 */       value = getServletConfig().getInitParameter("debug");
/*  452 */       this.debug = Integer.parseInt(value);
/*      */     } catch (Throwable t) {
/*  454 */       ExceptionUtils.handleThrowable(t);
/*      */     }
/*      */     
/*      */ 
/*  458 */     Server server = ((Engine)this.host.getParent()).getService().getServer();
/*  459 */     if (server != null) {
/*  460 */       this.global = server.getGlobalNamingContext();
/*      */     }
/*      */     
/*      */ 
/*  464 */     this.versioned = ((File)getServletContext().getAttribute("javax.servlet.context.tempdir"));
/*      */     
/*      */ 
/*  467 */     this.configBase = new File(this.context.getCatalinaBase(), "conf");
/*  468 */     Container container = this.context;
/*  469 */     Container host = null;
/*  470 */     Container engine = null;
/*  471 */     while (container != null) {
/*  472 */       if ((container instanceof Host))
/*  473 */         host = container;
/*  474 */       if ((container instanceof Engine))
/*  475 */         engine = container;
/*  476 */       container = container.getParent();
/*      */     }
/*  478 */     if (engine != null) {
/*  479 */       this.configBase = new File(this.configBase, engine.getName());
/*      */     }
/*  481 */     if (host != null) {
/*  482 */       this.configBase = new File(this.configBase, host.getName());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  487 */     if (this.debug >= 1) {
/*  488 */       log("init: Associated with Deployer '" + this.oname + "'");
/*      */       
/*  490 */       if (this.global != null) {
/*  491 */         log("init: Global resources are available");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void findleaks(boolean statusLine, PrintWriter writer, StringManager smClient)
/*      */   {
/*  512 */     if (!(this.host instanceof StandardHost)) {
/*  513 */       writer.println(smClient.getString("managerServlet.findleaksFail"));
/*  514 */       return;
/*      */     }
/*      */     
/*  517 */     String[] results = ((StandardHost)this.host).findReloadedContextMemoryLeaks();
/*      */     
/*      */ 
/*  520 */     if (results.length > 0) {
/*  521 */       if (statusLine) {
/*  522 */         writer.println(smClient.getString("managerServlet.findleaksList"));
/*      */       }
/*      */       
/*  525 */       for (String result : results) {
/*  526 */         if ("".equals(result)) {
/*  527 */           result = "/";
/*      */         }
/*  529 */         writer.println(result);
/*      */       }
/*  531 */     } else if (statusLine) {
/*  532 */       writer.println(smClient.getString("managerServlet.findleaksNone"));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void vmInfo(PrintWriter writer, StringManager smClient, Enumeration<Locale> requestedLocales)
/*      */   {
/*  546 */     writer.println(smClient.getString("managerServlet.vminfo"));
/*  547 */     writer.print(Diagnostics.getVMInfo(requestedLocales));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void threadDump(PrintWriter writer, StringManager smClient, Enumeration<Locale> requestedLocales)
/*      */   {
/*  559 */     writer.println(smClient.getString("managerServlet.threaddump"));
/*  560 */     writer.print(Diagnostics.getThreadDump(requestedLocales));
/*      */   }
/*      */   
/*      */   protected void sslConnectorCiphers(PrintWriter writer, StringManager smClient)
/*      */   {
/*  565 */     writer.println(smClient.getString("managerServlet.sslConnectorCiphers"));
/*      */     
/*  567 */     Map<String, Set<String>> connectorCiphers = getConnectorCiphers();
/*  568 */     for (Map.Entry<String, Set<String>> entry : connectorCiphers.entrySet()) {
/*  569 */       writer.println((String)entry.getKey());
/*  570 */       for (String cipher : (Set)entry.getValue()) {
/*  571 */         writer.print("  ");
/*  572 */         writer.println(cipher);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void save(PrintWriter writer, String path, StringManager smClient)
/*      */   {
/*      */     try
/*      */     {
/*  590 */       storeConfigOname = new ObjectName("Catalina:type=StoreConfig");
/*      */     } catch (MalformedObjectNameException e) {
/*      */       ObjectName storeConfigOname;
/*  593 */       log(sm.getString("managerServlet.exception"), e);
/*  594 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { e.toString() })); return;
/*      */     }
/*      */     
/*      */     ObjectName storeConfigOname;
/*  598 */     if (!this.mBeanServer.isRegistered(storeConfigOname)) {
/*  599 */       writer.println(smClient.getString("managerServlet.storeConfig.noMBean", new Object[] { storeConfigOname }));
/*      */       
/*  601 */       return;
/*      */     }
/*      */     
/*  604 */     if ((path == null) || (path.length() == 0) || (!path.startsWith("/"))) {
/*      */       try {
/*  606 */         this.mBeanServer.invoke(storeConfigOname, "storeConfig", null, null);
/*  607 */         writer.println(smClient.getString("managerServlet.saved"));
/*      */       } catch (Exception e) {
/*  609 */         log("managerServlet.storeConfig", e);
/*  610 */         writer.println(smClient.getString("managerServlet.exception", new Object[] { e.toString() }));
/*      */         
/*  612 */         return;
/*      */       }
/*      */     } else {
/*  615 */       String contextPath = path;
/*  616 */       if (path.equals("/")) {
/*  617 */         contextPath = "";
/*      */       }
/*  619 */       org.apache.catalina.Context context = (org.apache.catalina.Context)this.host.findChild(contextPath);
/*  620 */       if (context == null) {
/*  621 */         writer.println(smClient.getString("managerServlet.noContext", new Object[] { path }));
/*      */         
/*  623 */         return;
/*      */       }
/*      */       try {
/*  626 */         this.mBeanServer.invoke(storeConfigOname, "store", new Object[] { context }, new String[] { "java.lang.String" });
/*      */         
/*      */ 
/*  629 */         writer.println(smClient.getString("managerServlet.savedContext", new Object[] { path }));
/*      */       }
/*      */       catch (Exception e) {
/*  632 */         log("managerServlet.save[" + path + "]", e);
/*  633 */         writer.println(smClient.getString("managerServlet.exception", new Object[] { e.toString() }));
/*      */         
/*  635 */         return;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void deploy(PrintWriter writer, ContextName cn, String tag, boolean update, HttpServletRequest request, StringManager smClient)
/*      */   {
/*  658 */     if (this.debug >= 1) {
/*  659 */       log("deploy: Deploying web application '" + cn + "'");
/*      */     }
/*      */     
/*      */ 
/*  663 */     if (!validateContextName(cn, writer, smClient)) {
/*  664 */       return;
/*      */     }
/*  666 */     String name = cn.getName();
/*  667 */     String baseName = cn.getBaseName();
/*  668 */     String displayPath = cn.getDisplayName();
/*      */     
/*      */ 
/*      */ 
/*  672 */     org.apache.catalina.Context context = (org.apache.catalina.Context)this.host.findChild(name);
/*  673 */     if ((context != null) && (!update)) {
/*  674 */       writer.println(smClient.getString("managerServlet.alreadyContext", new Object[] { displayPath }));
/*      */       
/*  676 */       return;
/*      */     }
/*      */     
/*  679 */     File deployedWar = new File(this.host.getAppBaseFile(), baseName + ".war");
/*      */     
/*      */     File uploadedWar;
/*      */     File uploadedWar;
/*  683 */     if (tag == null) {
/*  684 */       if (update)
/*      */       {
/*      */ 
/*      */ 
/*  688 */         File uploadedWar = new File(deployedWar.getAbsolutePath() + ".tmp");
/*  689 */         if ((uploadedWar.exists()) && (!uploadedWar.delete())) {
/*  690 */           writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { uploadedWar }));
/*      */         }
/*      */       }
/*      */       else {
/*  694 */         uploadedWar = deployedWar;
/*      */       }
/*      */     } else {
/*  697 */       File uploadPath = new File(this.versioned, tag);
/*  698 */       if ((!uploadPath.mkdirs()) && (!uploadPath.isDirectory())) {
/*  699 */         writer.println(smClient.getString("managerServlet.mkdirFail", new Object[] { uploadPath }));
/*      */         
/*  701 */         return;
/*      */       }
/*  703 */       uploadedWar = new File(uploadPath, baseName + ".war");
/*      */     }
/*  705 */     if (this.debug >= 2) {
/*  706 */       log("Uploading WAR file to " + uploadedWar);
/*      */     }
/*      */     try
/*      */     {
/*  710 */       if (isServiced(name)) {
/*  711 */         writer.println(smClient.getString("managerServlet.inService", new Object[] { displayPath }));
/*      */       } else {
/*  713 */         addServiced(name);
/*      */         try
/*      */         {
/*  716 */           uploadWar(writer, request, uploadedWar, smClient);
/*  717 */           if ((update) && (tag == null)) {
/*  718 */             if ((deployedWar.exists()) && (!deployedWar.delete())) {
/*  719 */               writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { deployedWar })); return;
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*  724 */             uploadedWar.renameTo(deployedWar);
/*      */           }
/*  726 */           if (tag != null)
/*      */           {
/*  728 */             copy(uploadedWar, deployedWar);
/*      */           }
/*      */           
/*  731 */           check(name);
/*      */         } finally {
/*  733 */           removeServiced(name);
/*      */         }
/*      */       }
/*      */     } catch (Exception e) {
/*  737 */       log("managerServlet.check[" + displayPath + "]", e);
/*  738 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { e.toString() }));
/*      */       
/*  740 */       return;
/*      */     }
/*      */     
/*  743 */     writeDeployResult(writer, smClient, name, displayPath);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void deploy(PrintWriter writer, ContextName cn, String tag, StringManager smClient)
/*      */   {
/*  762 */     if (!validateContextName(cn, writer, smClient)) {
/*  763 */       return;
/*      */     }
/*      */     
/*  766 */     String baseName = cn.getBaseName();
/*  767 */     String name = cn.getName();
/*  768 */     String displayPath = cn.getDisplayName();
/*      */     
/*      */ 
/*  771 */     File localWar = new File(new File(this.versioned, tag), baseName + ".war");
/*      */     
/*  773 */     File deployedWar = new File(this.host.getAppBaseFile(), baseName + ".war");
/*      */     
/*      */     try
/*      */     {
/*  777 */       if (isServiced(name)) {
/*  778 */         writer.println(smClient.getString("managerServlet.inService", new Object[] { displayPath }));
/*      */       } else {
/*  780 */         addServiced(name);
/*      */         try {
/*  782 */           if (!deployedWar.delete()) {
/*  783 */             writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { deployedWar })); return;
/*      */           }
/*      */           
/*      */ 
/*  787 */           copy(localWar, deployedWar);
/*      */           
/*  789 */           check(name);
/*      */         } finally {
/*  791 */           removeServiced(name);
/*      */         }
/*      */       }
/*      */     } catch (Exception e) {
/*  795 */       log("managerServlet.check[" + displayPath + "]", e);
/*  796 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { e.toString() }));
/*      */       
/*  798 */       return;
/*      */     }
/*      */     
/*  801 */     writeDeployResult(writer, smClient, name, displayPath);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void deploy(PrintWriter writer, String config, ContextName cn, String war, boolean update, StringManager smClient)
/*      */   {
/*  819 */     if ((config != null) && (config.length() == 0)) {
/*  820 */       config = null;
/*      */     }
/*  822 */     if ((war != null) && (war.length() == 0)) {
/*  823 */       war = null;
/*      */     }
/*      */     
/*  826 */     if (this.debug >= 1) {
/*  827 */       if ((config != null) && (config.length() > 0)) {
/*  828 */         if (war != null) {
/*  829 */           log("install: Installing context configuration at '" + config + "' from '" + war + "'");
/*      */         }
/*      */         else {
/*  832 */           log("install: Installing context configuration at '" + config + "'");
/*      */         }
/*      */         
/*      */       }
/*  836 */       else if (cn != null) {
/*  837 */         log("install: Installing web application '" + cn + "' from '" + war + "'");
/*      */       }
/*      */       else {
/*  840 */         log("install: Installing web application from '" + war + "'");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  845 */     if (!validateContextName(cn, writer, smClient)) {
/*  846 */       return;
/*      */     }
/*      */     
/*  849 */     String name = cn.getName();
/*  850 */     String baseName = cn.getBaseName();
/*  851 */     String displayPath = cn.getDisplayName();
/*      */     
/*      */ 
/*      */ 
/*  855 */     org.apache.catalina.Context context = (org.apache.catalina.Context)this.host.findChild(name);
/*  856 */     if ((context != null) && (!update)) {
/*  857 */       writer.println(smClient.getString("managerServlet.alreadyContext", new Object[] { displayPath }));
/*      */       
/*  859 */       return;
/*      */     }
/*      */     
/*  862 */     if ((config != null) && (config.startsWith("file:"))) {
/*  863 */       config = config.substring("file:".length());
/*      */     }
/*  865 */     if ((war != null) && (war.startsWith("file:"))) {
/*  866 */       war = war.substring("file:".length());
/*      */     }
/*      */     try
/*      */     {
/*  870 */       if (isServiced(name)) {
/*  871 */         writer.println(smClient.getString("managerServlet.inService", new Object[] { displayPath }));
/*      */       } else {
/*  873 */         addServiced(name);
/*      */         try {
/*  875 */           if (config != null) {
/*  876 */             if ((!this.configBase.mkdirs()) && (!this.configBase.isDirectory())) {
/*  877 */               writer.println(smClient.getString("managerServlet.mkdirFail", new Object[] { this.configBase })); return;
/*      */             }
/*      */             
/*      */ 
/*  881 */             File localConfig = new File(this.configBase, baseName + ".xml");
/*  882 */             if ((localConfig.isFile()) && (!localConfig.delete())) {
/*  883 */               writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { localConfig })); return;
/*      */             }
/*      */             
/*      */ 
/*  887 */             copy(new File(config), localConfig);
/*      */           }
/*  889 */           if (war != null) { File localWar;
/*      */             File localWar;
/*  891 */             if (war.endsWith(".war")) {
/*  892 */               localWar = new File(this.host.getAppBaseFile(), baseName + ".war");
/*      */             } else {
/*  894 */               localWar = new File(this.host.getAppBaseFile(), baseName);
/*      */             }
/*  896 */             if ((localWar.exists()) && (!ExpandWar.delete(localWar))) {
/*  897 */               writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { localWar })); return;
/*      */             }
/*      */             
/*      */ 
/*  901 */             copy(new File(war), localWar);
/*      */           }
/*      */           
/*  904 */           check(name);
/*      */         } finally {
/*  906 */           removeServiced(name);
/*      */         }
/*      */       }
/*  909 */       writeDeployResult(writer, smClient, name, displayPath);
/*      */     } catch (Throwable t) {
/*  911 */       ExceptionUtils.handleThrowable(t);
/*  912 */       log("ManagerServlet.install[" + displayPath + "]", t);
/*  913 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { t.toString() }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeDeployResult(PrintWriter writer, StringManager smClient, String name, String displayPath)
/*      */   {
/*  922 */     org.apache.catalina.Context deployed = (org.apache.catalina.Context)this.host.findChild(name);
/*  923 */     if ((deployed != null) && (deployed.getConfigured()) && (deployed.getState().isAvailable()))
/*      */     {
/*  925 */       writer.println(smClient.getString("managerServlet.deployed", new Object[] { displayPath }));
/*      */     }
/*  927 */     else if ((deployed != null) && (!deployed.getState().isAvailable())) {
/*  928 */       writer.println(smClient.getString("managerServlet.deployedButNotStarted", new Object[] { displayPath }));
/*      */     }
/*      */     else
/*      */     {
/*  932 */       writer.println(smClient.getString("managerServlet.deployFailed", new Object[] { displayPath }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void list(PrintWriter writer, StringManager smClient)
/*      */   {
/*  946 */     if (this.debug >= 1) {
/*  947 */       log("list: Listing contexts for virtual host '" + this.host.getName() + "'");
/*      */     }
/*      */     
/*  950 */     writer.println(smClient.getString("managerServlet.listed", new Object[] { this.host.getName() }));
/*      */     
/*  952 */     Container[] contexts = this.host.findChildren();
/*  953 */     for (int i = 0; i < contexts.length; i++) {
/*  954 */       org.apache.catalina.Context context = (org.apache.catalina.Context)contexts[i];
/*  955 */       if (context != null) {
/*  956 */         String displayPath = context.getPath();
/*  957 */         if (displayPath.equals(""))
/*  958 */           displayPath = "/";
/*  959 */         if (context.getState().isAvailable()) {
/*  960 */           writer.println(smClient.getString("managerServlet.listitem", new Object[] { displayPath, "running", "" + context.getManager().findSessions().length, context.getDocBase() }));
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*  966 */           writer.println(smClient.getString("managerServlet.listitem", new Object[] { displayPath, "stopped", "0", context.getDocBase() }));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void reload(PrintWriter writer, ContextName cn, StringManager smClient)
/*      */   {
/*  987 */     if (this.debug >= 1) {
/*  988 */       log("restart: Reloading web application '" + cn + "'");
/*      */     }
/*  990 */     if (!validateContextName(cn, writer, smClient)) {
/*  991 */       return;
/*      */     }
/*      */     try
/*      */     {
/*  995 */       org.apache.catalina.Context context = (org.apache.catalina.Context)this.host.findChild(cn.getName());
/*  996 */       if (context == null) {
/*  997 */         writer.println(smClient.getString("managerServlet.noContext", new Object[] { RequestUtil.filter(cn.getDisplayName()) }));
/*      */         
/*  999 */         return;
/*      */       }
/*      */       
/* 1002 */       if (context.getName().equals(this.context.getName())) {
/* 1003 */         writer.println(smClient.getString("managerServlet.noSelf"));
/* 1004 */         return;
/*      */       }
/* 1006 */       context.reload();
/* 1007 */       writer.println(smClient.getString("managerServlet.reloaded", new Object[] { cn.getDisplayName() }));
/*      */     }
/*      */     catch (Throwable t) {
/* 1010 */       ExceptionUtils.handleThrowable(t);
/* 1011 */       log("ManagerServlet.reload[" + cn.getDisplayName() + "]", t);
/* 1012 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { t.toString() }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void resources(PrintWriter writer, String type, StringManager smClient)
/*      */   {
/* 1030 */     if (this.debug >= 1) {
/* 1031 */       if (type != null) {
/* 1032 */         log("resources:  Listing resources of type " + type);
/*      */       } else {
/* 1034 */         log("resources:  Listing resources of all types");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1039 */     if (this.global == null) {
/* 1040 */       writer.println(smClient.getString("managerServlet.noGlobal"));
/* 1041 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1045 */     if (type != null) {
/* 1046 */       writer.println(smClient.getString("managerServlet.resourcesType", new Object[] { type }));
/*      */     }
/*      */     else {
/* 1049 */       writer.println(smClient.getString("managerServlet.resourcesAll"));
/*      */     }
/*      */     
/* 1052 */     Class<?> clazz = null;
/*      */     try {
/* 1054 */       if (type != null) {
/* 1055 */         clazz = Class.forName(type);
/*      */       }
/*      */     } catch (Throwable t) {
/* 1058 */       ExceptionUtils.handleThrowable(t);
/* 1059 */       log("ManagerServlet.resources[" + type + "]", t);
/* 1060 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { t.toString() }));
/*      */       
/* 1062 */       return;
/*      */     }
/*      */     
/* 1065 */     printResources(writer, "", this.global, type, clazz, smClient);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void printResources(PrintWriter writer, String prefix, javax.naming.Context namingContext, String type, Class<?> clazz, StringManager smClient)
/*      */   {
/*      */     try
/*      */     {
/* 1087 */       NamingEnumeration<Binding> items = namingContext.listBindings("");
/* 1088 */       while (items.hasMore()) {
/* 1089 */         Binding item = (Binding)items.next();
/* 1090 */         if ((item.getObject() instanceof javax.naming.Context)) {
/* 1091 */           printResources(writer, prefix + item.getName() + "/", (javax.naming.Context)item.getObject(), type, clazz, smClient);
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/* 1096 */         else if ((clazz == null) || (clazz.isInstance(item.getObject())))
/*      */         {
/*      */ 
/*      */ 
/* 1100 */           writer.print(prefix + item.getName());
/* 1101 */           writer.print(':');
/* 1102 */           writer.print(item.getClassName());
/*      */           
/* 1104 */           writer.println();
/*      */         }
/*      */       }
/*      */     } catch (Throwable t) {
/* 1108 */       ExceptionUtils.handleThrowable(t);
/* 1109 */       log("ManagerServlet.resources[" + type + "]", t);
/* 1110 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { t.toString() }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void serverinfo(PrintWriter writer, StringManager smClient)
/*      */   {
/* 1123 */     if (this.debug >= 1)
/* 1124 */       log("serverinfo");
/*      */     try {
/* 1126 */       StringBuilder props = new StringBuilder();
/* 1127 */       props.append("OK - Server info");
/* 1128 */       props.append("\nTomcat Version: ");
/* 1129 */       props.append(ServerInfo.getServerInfo());
/* 1130 */       props.append("\nOS Name: ");
/* 1131 */       props.append(System.getProperty("os.name"));
/* 1132 */       props.append("\nOS Version: ");
/* 1133 */       props.append(System.getProperty("os.version"));
/* 1134 */       props.append("\nOS Architecture: ");
/* 1135 */       props.append(System.getProperty("os.arch"));
/* 1136 */       props.append("\nJVM Version: ");
/* 1137 */       props.append(System.getProperty("java.runtime.version"));
/* 1138 */       props.append("\nJVM Vendor: ");
/* 1139 */       props.append(System.getProperty("java.vm.vendor"));
/* 1140 */       writer.println(props.toString());
/*      */     } catch (Throwable t) {
/* 1142 */       ExceptionUtils.handleThrowable(t);
/* 1143 */       getServletContext().log("ManagerServlet.serverinfo", t);
/* 1144 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { t.toString() }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void sessions(PrintWriter writer, ContextName cn, int idle, StringManager smClient)
/*      */   {
/* 1162 */     if (this.debug >= 1) {
/* 1163 */       log("sessions: Session information for web application '" + cn + "'");
/* 1164 */       if (idle >= 0) {
/* 1165 */         log("sessions: Session expiration for " + idle + " minutes '" + cn + "'");
/*      */       }
/*      */     }
/* 1168 */     if (!validateContextName(cn, writer, smClient)) {
/* 1169 */       return;
/*      */     }
/*      */     
/* 1172 */     String displayPath = cn.getDisplayName();
/*      */     try
/*      */     {
/* 1175 */       org.apache.catalina.Context context = (org.apache.catalina.Context)this.host.findChild(cn.getName());
/* 1176 */       if (context == null) {
/* 1177 */         writer.println(smClient.getString("managerServlet.noContext", new Object[] { RequestUtil.filter(displayPath) }));
/*      */         
/* 1179 */         return;
/*      */       }
/* 1181 */       Manager manager = context.getManager();
/* 1182 */       if (manager == null) {
/* 1183 */         writer.println(smClient.getString("managerServlet.noManager", new Object[] { RequestUtil.filter(displayPath) }));
/*      */         
/* 1185 */         return;
/*      */       }
/* 1187 */       int maxCount = 60;
/* 1188 */       int histoInterval = 1;
/* 1189 */       int maxInactiveInterval = context.getSessionTimeout();
/* 1190 */       if (maxInactiveInterval > 0) {
/* 1191 */         histoInterval = maxInactiveInterval / maxCount;
/* 1192 */         if (histoInterval * maxCount < maxInactiveInterval)
/* 1193 */           histoInterval++;
/* 1194 */         if (0 == histoInterval)
/* 1195 */           histoInterval = 1;
/* 1196 */         maxCount = maxInactiveInterval / histoInterval;
/* 1197 */         if (histoInterval * maxCount < maxInactiveInterval) {
/* 1198 */           maxCount++;
/*      */         }
/*      */       }
/* 1201 */       writer.println(smClient.getString("managerServlet.sessions", new Object[] { displayPath }));
/*      */       
/* 1203 */       writer.println(smClient.getString("managerServlet.sessiondefaultmax", new Object[] { "" + maxInactiveInterval }));
/*      */       
/*      */ 
/* 1206 */       Session[] sessions = manager.findSessions();
/* 1207 */       int[] timeout = new int[maxCount + 1];
/* 1208 */       int notimeout = 0;
/* 1209 */       int expired = 0;
/* 1210 */       for (int i = 0; i < sessions.length; i++) {
/* 1211 */         int time = (int)(sessions[i].getIdleTimeInternal() / 1000L);
/* 1212 */         if ((idle >= 0) && (time >= idle * 60)) {
/* 1213 */           sessions[i].expire();
/* 1214 */           expired++;
/*      */         }
/* 1216 */         time = time / 60 / histoInterval;
/* 1217 */         if (time < 0) {
/* 1218 */           notimeout++;
/* 1219 */         } else if (time >= maxCount) {
/* 1220 */           timeout[maxCount] += 1;
/*      */         } else
/* 1222 */           timeout[time] += 1;
/*      */       }
/* 1224 */       if (timeout[0] > 0) {
/* 1225 */         writer.println(smClient.getString("managerServlet.sessiontimeout", new Object[] { "<" + histoInterval, "" + timeout[0] }));
/*      */       }
/*      */       
/* 1228 */       for (int i = 1; i < maxCount; i++) {
/* 1229 */         if (timeout[i] > 0) {
/* 1230 */           writer.println(smClient.getString("managerServlet.sessiontimeout", new Object[] { "" + i * histoInterval + " - <" + (i + 1) * histoInterval, "" + timeout[i] }));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1235 */       if (timeout[maxCount] > 0) {
/* 1236 */         writer.println(smClient.getString("managerServlet.sessiontimeout", new Object[] { ">=" + maxCount * histoInterval, "" + timeout[maxCount] }));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1241 */       if (notimeout > 0) {
/* 1242 */         writer.println(smClient.getString("managerServlet.sessiontimeout.unlimited", new Object[] { "" + notimeout }));
/*      */       }
/*      */       
/* 1245 */       if (idle >= 0) {
/* 1246 */         writer.println(smClient.getString("managerServlet.sessiontimeout.expired", new Object[] { ">" + idle, "" + expired }));
/*      */       }
/*      */     }
/*      */     catch (Throwable t) {
/* 1250 */       ExceptionUtils.handleThrowable(t);
/* 1251 */       log("ManagerServlet.sessions[" + displayPath + "]", t);
/* 1252 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { t.toString() }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void expireSessions(PrintWriter writer, ContextName cn, HttpServletRequest req, StringManager smClient)
/*      */   {
/* 1269 */     int idle = -1;
/* 1270 */     String idleParam = req.getParameter("idle");
/* 1271 */     if (idleParam != null) {
/*      */       try {
/* 1273 */         idle = Integer.parseInt(idleParam);
/*      */       } catch (NumberFormatException e) {
/* 1275 */         log("Could not parse idle parameter to an int: " + idleParam);
/*      */       }
/*      */     }
/* 1278 */     sessions(writer, cn, idle, smClient);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void start(PrintWriter writer, ContextName cn, StringManager smClient)
/*      */   {
/* 1291 */     if (this.debug >= 1) {
/* 1292 */       log("start: Starting web application '" + cn + "'");
/*      */     }
/* 1294 */     if (!validateContextName(cn, writer, smClient)) {
/* 1295 */       return;
/*      */     }
/*      */     
/* 1298 */     String displayPath = cn.getDisplayName();
/*      */     try
/*      */     {
/* 1301 */       org.apache.catalina.Context context = (org.apache.catalina.Context)this.host.findChild(cn.getName());
/* 1302 */       if (context == null) {
/* 1303 */         writer.println(smClient.getString("managerServlet.noContext", new Object[] { RequestUtil.filter(displayPath) }));
/*      */         
/* 1305 */         return;
/*      */       }
/* 1307 */       context.start();
/* 1308 */       if (context.getState().isAvailable()) {
/* 1309 */         writer.println(smClient.getString("managerServlet.started", new Object[] { displayPath }));
/*      */       }
/*      */       else {
/* 1312 */         writer.println(smClient.getString("managerServlet.startFailed", new Object[] { displayPath }));
/*      */       }
/*      */     } catch (Throwable t) {
/* 1315 */       ExceptionUtils.handleThrowable(t);
/* 1316 */       getServletContext().log(sm.getString("managerServlet.startFailed", new Object[] { displayPath }), t);
/*      */       
/* 1318 */       writer.println(smClient.getString("managerServlet.startFailed", new Object[] { displayPath }));
/*      */       
/* 1320 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { t.toString() }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void stop(PrintWriter writer, ContextName cn, StringManager smClient)
/*      */   {
/* 1337 */     if (this.debug >= 1) {
/* 1338 */       log("stop: Stopping web application '" + cn + "'");
/*      */     }
/* 1340 */     if (!validateContextName(cn, writer, smClient)) {
/* 1341 */       return;
/*      */     }
/*      */     
/* 1344 */     String displayPath = cn.getDisplayName();
/*      */     try
/*      */     {
/* 1347 */       org.apache.catalina.Context context = (org.apache.catalina.Context)this.host.findChild(cn.getName());
/* 1348 */       if (context == null) {
/* 1349 */         writer.println(smClient.getString("managerServlet.noContext", new Object[] { RequestUtil.filter(displayPath) }));
/*      */         
/* 1351 */         return;
/*      */       }
/*      */       
/* 1354 */       if (context.getName().equals(this.context.getName())) {
/* 1355 */         writer.println(smClient.getString("managerServlet.noSelf"));
/* 1356 */         return;
/*      */       }
/* 1358 */       context.stop();
/* 1359 */       writer.println(smClient.getString("managerServlet.stopped", new Object[] { displayPath }));
/*      */     }
/*      */     catch (Throwable t) {
/* 1362 */       ExceptionUtils.handleThrowable(t);
/* 1363 */       log("ManagerServlet.stop[" + displayPath + "]", t);
/* 1364 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { t.toString() }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void undeploy(PrintWriter writer, ContextName cn, StringManager smClient)
/*      */   {
/* 1381 */     if (this.debug >= 1) {
/* 1382 */       log("undeploy: Undeploying web application at '" + cn + "'");
/*      */     }
/* 1384 */     if (!validateContextName(cn, writer, smClient)) {
/* 1385 */       return;
/*      */     }
/*      */     
/* 1388 */     String name = cn.getName();
/* 1389 */     String baseName = cn.getBaseName();
/* 1390 */     String displayPath = cn.getDisplayName();
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1395 */       org.apache.catalina.Context context = (org.apache.catalina.Context)this.host.findChild(name);
/* 1396 */       if (context == null) {
/* 1397 */         writer.println(smClient.getString("managerServlet.noContext", new Object[] { RequestUtil.filter(displayPath) }));
/*      */         
/* 1399 */         return;
/*      */       }
/*      */       
/* 1402 */       if (!isDeployed(name)) {
/* 1403 */         writer.println(smClient.getString("managerServlet.notDeployed", new Object[] { RequestUtil.filter(displayPath) }));
/*      */         
/* 1405 */         return;
/*      */       }
/*      */       
/* 1408 */       if (isServiced(name)) {
/* 1409 */         writer.println(smClient.getString("managerServlet.inService", new Object[] { displayPath }));
/*      */       } else {
/* 1411 */         addServiced(name);
/*      */         try
/*      */         {
/* 1414 */           context.stop();
/*      */         } catch (Throwable t) {
/* 1416 */           ExceptionUtils.handleThrowable(t);
/*      */         }
/*      */         try {
/* 1419 */           File war = new File(this.host.getAppBaseFile(), baseName + ".war");
/* 1420 */           File dir = new File(this.host.getAppBaseFile(), baseName);
/* 1421 */           File xml = new File(this.configBase, baseName + ".xml");
/* 1422 */           if ((war.exists()) && (!war.delete())) {
/* 1423 */             writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { war })); return;
/*      */           }
/*      */           
/* 1426 */           if ((dir.exists()) && (!undeployDir(dir))) {
/* 1427 */             writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { dir })); return;
/*      */           }
/*      */           
/* 1430 */           if ((xml.exists()) && (!xml.delete())) {
/* 1431 */             writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { xml })); return;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1436 */           check(name);
/*      */         } finally {
/* 1438 */           removeServiced(name);
/*      */         }
/*      */       }
/* 1441 */       writer.println(smClient.getString("managerServlet.undeployed", new Object[] { displayPath }));
/*      */     }
/*      */     catch (Throwable t) {
/* 1444 */       ExceptionUtils.handleThrowable(t);
/* 1445 */       log("ManagerServlet.undeploy[" + displayPath + "]", t);
/* 1446 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { t.toString() }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isDeployed(String name)
/*      */     throws Exception
/*      */   {
/* 1465 */     String[] params = { name };
/* 1466 */     String[] signature = { "java.lang.String" };
/* 1467 */     Boolean result = (Boolean)this.mBeanServer.invoke(this.oname, "isDeployed", params, signature);
/*      */     
/* 1469 */     return result.booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void check(String name)
/*      */     throws Exception
/*      */   {
/* 1481 */     String[] params = { name };
/* 1482 */     String[] signature = { "java.lang.String" };
/* 1483 */     this.mBeanServer.invoke(this.oname, "check", params, signature);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isServiced(String name)
/*      */     throws Exception
/*      */   {
/* 1496 */     String[] params = { name };
/* 1497 */     String[] signature = { "java.lang.String" };
/* 1498 */     Boolean result = (Boolean)this.mBeanServer.invoke(this.oname, "isServiced", params, signature);
/*      */     
/* 1500 */     return result.booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void addServiced(String name)
/*      */     throws Exception
/*      */   {
/* 1512 */     String[] params = { name };
/* 1513 */     String[] signature = { "java.lang.String" };
/* 1514 */     this.mBeanServer.invoke(this.oname, "addServiced", params, signature);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void removeServiced(String name)
/*      */     throws Exception
/*      */   {
/* 1526 */     String[] params = { name };
/* 1527 */     String[] signature = { "java.lang.String" };
/* 1528 */     this.mBeanServer.invoke(this.oname, "removeServiced", params, signature);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean undeployDir(File dir)
/*      */   {
/* 1541 */     String[] files = dir.list();
/* 1542 */     if (files == null) {
/* 1543 */       files = new String[0];
/*      */     }
/* 1545 */     for (int i = 0; i < files.length; i++) {
/* 1546 */       File file = new File(dir, files[i]);
/* 1547 */       if (file.isDirectory()) {
/* 1548 */         if (!undeployDir(file)) {
/* 1549 */           return false;
/*      */         }
/*      */       }
/* 1552 */       else if (!file.delete()) {
/* 1553 */         return false;
/*      */       }
/*      */     }
/*      */     
/* 1557 */     return dir.delete();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void uploadWar(PrintWriter writer, HttpServletRequest request, File war, StringManager smClient)
/*      */     throws IOException
/*      */   {
/* 1576 */     if ((war.exists()) && (!war.delete())) {
/* 1577 */       String msg = smClient.getString("managerServlet.deleteFail", new Object[] { war });
/* 1578 */       throw new IOException(msg);
/*      */     }
/*      */     try {
/* 1581 */       ServletInputStream istream = request.getInputStream();Throwable localThrowable3 = null;
/* 1582 */       try { BufferedOutputStream ostream = new BufferedOutputStream(new FileOutputStream(war), 1024);Throwable localThrowable4 = null;
/*      */         try {
/* 1584 */           byte[] buffer = new byte['Ѐ'];
/*      */           for (;;) {
/* 1586 */             int n = istream.read(buffer);
/* 1587 */             if (n < 0) {
/*      */               break;
/*      */             }
/* 1590 */             ostream.write(buffer, 0, n);
/*      */           }
/*      */         }
/*      */         catch (Throwable localThrowable1)
/*      */         {
/* 1581 */           localThrowable4 = localThrowable1;throw localThrowable1; } finally {} } catch (Throwable localThrowable2) { localThrowable3 = localThrowable2;throw localThrowable2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1592 */         if (istream != null) if (localThrowable3 != null) try { istream.close(); } catch (Throwable x2) { localThrowable3.addSuppressed(x2); } else istream.close();
/* 1593 */       } } catch (IOException e) { if ((war.exists()) && (!war.delete())) {
/* 1594 */         writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { war }));
/*      */       }
/*      */       
/* 1597 */       throw e;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static boolean validateContextName(ContextName cn, PrintWriter writer, StringManager sm)
/*      */   {
/* 1608 */     if ((cn != null) && ((cn.getPath().startsWith("/")) || (cn.getPath().equals(""))))
/*      */     {
/* 1610 */       return true;
/*      */     }
/*      */     
/* 1613 */     String path = null;
/* 1614 */     if (cn != null) {
/* 1615 */       path = RequestUtil.filter(cn.getPath());
/*      */     }
/* 1617 */     writer.println(sm.getString("managerServlet.invalidPath", new Object[] { path }));
/* 1618 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean copy(File src, File dest)
/*      */   {
/* 1629 */     boolean result = false;
/*      */     try {
/* 1631 */       if ((src != null) && (!src.getCanonicalPath().equals(dest.getCanonicalPath())))
/*      */       {
/* 1633 */         result = copyInternal(src, dest, new byte['က']);
/*      */       }
/*      */     } catch (IOException e) {
/* 1636 */       e.printStackTrace();
/*      */     }
/* 1638 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean copyInternal(File src, File dest, byte[] buf)
/*      */   {
/* 1652 */     boolean result = true;
/*      */     
/* 1654 */     String[] files = null;
/* 1655 */     if (src.isDirectory()) {
/* 1656 */       files = src.list();
/* 1657 */       result = dest.mkdir();
/*      */     } else {
/* 1659 */       files = new String[1];
/* 1660 */       files[0] = "";
/*      */     }
/* 1662 */     if (files == null) {
/* 1663 */       files = new String[0];
/*      */     }
/* 1665 */     for (int i = 0; (i < files.length) && (result); i++) {
/* 1666 */       File fileSrc = new File(src, files[i]);
/* 1667 */       File fileDest = new File(dest, files[i]);
/* 1668 */       if (fileSrc.isDirectory())
/* 1669 */         result = copyInternal(fileSrc, fileDest, buf); else {
/*      */         try {
/* 1671 */           FileInputStream is = new FileInputStream(fileSrc);Throwable localThrowable3 = null;
/* 1672 */           try { FileOutputStream os = new FileOutputStream(fileDest);Throwable localThrowable4 = null;
/* 1673 */             try { int len = 0;
/*      */               for (;;) {
/* 1675 */                 len = is.read(buf);
/* 1676 */                 if (len == -1)
/*      */                   break;
/* 1678 */                 os.write(buf, 0, len);
/*      */               }
/*      */             }
/*      */             catch (Throwable localThrowable1)
/*      */             {
/* 1671 */               localThrowable4 = localThrowable1;throw localThrowable1; } finally {} } catch (Throwable localThrowable2) { localThrowable3 = localThrowable2;throw localThrowable2;
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           finally
/*      */           {
/*      */ 
/*      */ 
/* 1680 */             if (is != null) if (localThrowable3 != null) try { is.close(); } catch (Throwable x2) { localThrowable3.addSuppressed(x2); } else is.close();
/* 1681 */           } } catch (IOException e) { e.printStackTrace();
/* 1682 */           result = false;
/*      */         }
/*      */       }
/*      */     }
/* 1686 */     return result;
/*      */   }
/*      */   
/*      */   protected Map<String, Set<String>> getConnectorCiphers()
/*      */   {
/* 1691 */     Map<String, Set<String>> result = new HashMap();
/*      */     
/* 1693 */     Engine e = (Engine)this.host.getParent();
/* 1694 */     Service s = e.getService();
/* 1695 */     Connector[] connectors = s.findConnectors();
/* 1696 */     for (Connector connector : connectors) {
/* 1697 */       if (Boolean.TRUE.equals(connector.getProperty("SSLEnabled"))) {
/* 1698 */         SSLHostConfig[] sslHostConfigs = connector.getProtocolHandler().findSslHostConfigs();
/* 1699 */         for (SSLHostConfig sslHostConfig : sslHostConfigs) {
/* 1700 */           String name = connector.toString() + "-" + sslHostConfig.getHostName();
/* 1701 */           Set<String> cipherList = new HashSet();
/* 1702 */           String[] cipherNames = sslHostConfig.getEnabledCiphers();
/* 1703 */           for (String cipherName : cipherNames) {
/* 1704 */             cipherList.add(cipherName);
/*      */           }
/* 1706 */           result.put(name, cipherList);
/*      */         }
/*      */       } else {
/* 1709 */         Set<String> cipherList = new HashSet();
/* 1710 */         cipherList.add(sm.getString("managerServlet.notSslConnector"));
/* 1711 */         result.put(connector.toString(), cipherList);
/*      */       }
/*      */     }
/* 1714 */     return result;
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\manager\ManagerServlet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */