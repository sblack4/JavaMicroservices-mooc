/*    */ package org.apache.catalina.loader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceEntry
/*    */ {
/* 30 */   public long lastModified = -1L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 36 */   public volatile Class<?> loadedClass = null;
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\loader\ResourceEntry.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */