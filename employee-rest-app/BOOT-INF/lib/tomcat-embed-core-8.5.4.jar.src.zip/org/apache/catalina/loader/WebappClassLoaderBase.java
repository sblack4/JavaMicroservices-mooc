/*      */ package org.apache.catalina.loader;
/*      */ 
/*      */ import java.beans.Introspector;
/*      */ import java.io.File;
/*      */ import java.io.FilePermission;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.lang.instrument.ClassFileTransformer;
/*      */ import java.lang.instrument.IllegalClassFormatException;
/*      */ import java.lang.ref.Reference;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Method;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URL;
/*      */ import java.net.URLClassLoader;
/*      */ import java.security.AccessControlException;
/*      */ import java.security.AccessController;
/*      */ import java.security.AllPermission;
/*      */ import java.security.CodeSource;
/*      */ import java.security.Permission;
/*      */ import java.security.PermissionCollection;
/*      */ import java.security.Policy;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.security.ProtectionDomain;
/*      */ import java.security.cert.Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.ConcurrentModificationException;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.CopyOnWriteArrayList;
/*      */ import java.util.concurrent.ThreadPoolExecutor;
/*      */ import java.util.jar.Attributes;
/*      */ import java.util.jar.Attributes.Name;
/*      */ import java.util.jar.Manifest;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.Lifecycle;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleListener;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.WebResource;
/*      */ import org.apache.catalina.WebResourceRoot;
/*      */ import org.apache.catalina.webresources.TomcatURLStreamHandlerFactory;
/*      */ import org.apache.juli.WebappProperties;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.InstrumentableClassLoader;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.IntrospectionUtils;
/*      */ import org.apache.tomcat.util.compat.JreCompat;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class WebappClassLoaderBase
/*      */   extends URLClassLoader
/*      */   implements Lifecycle, InstrumentableClassLoader, WebappProperties
/*      */ {
/*  125 */   private static final Log log = LogFactory.getLog(WebappClassLoaderBase.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  131 */   private static final List<String> JVM_THREAD_GROUP_NAMES = new ArrayList();
/*      */   
/*      */   private static final String JVM_THREAD_GROUP_SYSTEM = "system";
/*      */   private static final String CLASS_FILE_SUFFIX = ".class";
/*      */   
/*      */   static
/*      */   {
/*  138 */     ClassLoader.registerAsParallelCapable();
/*  139 */     JVM_THREAD_GROUP_NAMES.add("system");
/*  140 */     JVM_THREAD_GROUP_NAMES.add("RMI Runtime");
/*      */   }
/*      */   
/*      */   protected class PrivilegedFindClassByName implements PrivilegedAction<Class<?>>
/*      */   {
/*      */     protected final String name;
/*      */     
/*      */     PrivilegedFindClassByName(String name)
/*      */     {
/*  149 */       this.name = name;
/*      */     }
/*      */     
/*      */     public Class<?> run()
/*      */     {
/*  154 */       return WebappClassLoaderBase.this.findClassInternal(this.name);
/*      */     }
/*      */   }
/*      */   
/*      */   protected static final class PrivilegedGetClassLoader
/*      */     implements PrivilegedAction<ClassLoader>
/*      */   {
/*      */     public final Class<?> clazz;
/*      */     
/*      */     public PrivilegedGetClassLoader(Class<?> clazz)
/*      */     {
/*  165 */       this.clazz = clazz;
/*      */     }
/*      */     
/*      */     public ClassLoader run()
/*      */     {
/*  170 */       return this.clazz.getClassLoader();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  180 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.loader");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected WebappClassLoaderBase()
/*      */   {
/*  192 */     super(new URL[0]);
/*      */     
/*  194 */     ClassLoader p = getParent();
/*  195 */     if (p == null) {
/*  196 */       p = getSystemClassLoader();
/*      */     }
/*  198 */     this.parent = p;
/*      */     
/*  200 */     ClassLoader j = String.class.getClassLoader();
/*  201 */     if (j == null) {
/*  202 */       j = getSystemClassLoader();
/*  203 */       while (j.getParent() != null) {
/*  204 */         j = j.getParent();
/*      */       }
/*      */     }
/*  207 */     this.javaseClassLoader = j;
/*      */     
/*  209 */     this.securityManager = System.getSecurityManager();
/*  210 */     if (this.securityManager != null) {
/*  211 */       refreshPolicy();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected WebappClassLoaderBase(ClassLoader parent)
/*      */   {
/*  227 */     super(new URL[0], parent);
/*      */     
/*  229 */     ClassLoader p = getParent();
/*  230 */     if (p == null) {
/*  231 */       p = getSystemClassLoader();
/*      */     }
/*  233 */     this.parent = p;
/*      */     
/*  235 */     ClassLoader j = String.class.getClassLoader();
/*  236 */     if (j == null) {
/*  237 */       j = getSystemClassLoader();
/*  238 */       while (j.getParent() != null) {
/*  239 */         j = j.getParent();
/*      */       }
/*      */     }
/*  242 */     this.javaseClassLoader = j;
/*      */     
/*  244 */     this.securityManager = System.getSecurityManager();
/*  245 */     if (this.securityManager != null) {
/*  246 */       refreshPolicy();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  256 */   protected WebResourceRoot resources = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  266 */   protected final Map<String, ResourceEntry> resourceEntries = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  279 */   protected boolean delegate = false;
/*      */   
/*      */ 
/*  282 */   private final HashMap<String, Long> jarModificationTimes = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  289 */   protected final ArrayList<Permission> permissionList = new ArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  296 */   protected final HashMap<String, PermissionCollection> loaderPC = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final SecurityManager securityManager;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final ClassLoader parent;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ClassLoader javaseClassLoader;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*  324 */   protected final Permission allPermission = new AllPermission();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  333 */   private boolean clearReferencesRmiTargets = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  344 */   private boolean clearReferencesStopThreads = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  351 */   private boolean clearReferencesStopTimerThreads = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  359 */   private boolean clearReferencesLogFactoryRelease = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  369 */   private boolean clearReferencesHttpClientKeepAliveThread = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  378 */   private final List<ClassFileTransformer> transformers = new CopyOnWriteArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  386 */   private boolean hasExternalRepositories = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  392 */   private List<URL> localRepositories = new ArrayList();
/*      */   
/*      */ 
/*  395 */   private volatile LifecycleState state = LifecycleState.NEW;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WebResourceRoot getResources()
/*      */   {
/*  404 */     return this.resources;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setResources(WebResourceRoot resources)
/*      */   {
/*  414 */     this.resources = resources;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getContextName()
/*      */   {
/*  422 */     if (this.resources == null) {
/*  423 */       return "Unknown";
/*      */     }
/*  425 */     return this.resources.getContext().getBaseName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getDelegate()
/*      */   {
/*  437 */     return this.delegate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDelegate(boolean delegate)
/*      */   {
/*  456 */     this.delegate = delegate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void addPermission(URL url)
/*      */   {
/*  467 */     if (url == null) {
/*  468 */       return;
/*      */     }
/*  470 */     if (this.securityManager != null) {
/*  471 */       String protocol = url.getProtocol();
/*  472 */       if ("file".equalsIgnoreCase(protocol))
/*      */       {
/*      */ 
/*      */         try
/*      */         {
/*  477 */           URI uri = url.toURI();
/*  478 */           File f = new File(uri);
/*  479 */           path = f.getCanonicalPath();
/*      */         } catch (IOException|URISyntaxException e) { String path;
/*  481 */           log.warn(sm.getString("webappClassLoader.addPermisionNoCanonicalFile", new Object[] { url.toExternalForm() })); return;
/*      */         }
/*      */         String path;
/*      */         File f;
/*      */         URI uri;
/*  486 */         if (f.isFile())
/*      */         {
/*  488 */           addPermission(new FilePermission(path, "read"));
/*  489 */         } else if (f.isDirectory()) {
/*  490 */           addPermission(new FilePermission(path, "read"));
/*  491 */           addPermission(new FilePermission(path + File.separator + "-", "read"));
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  498 */         log.warn(sm.getString("webappClassLoader.addPermisionNoProtocol", new Object[] { protocol, url.toExternalForm() }));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void addPermission(Permission permission)
/*      */   {
/*  512 */     if ((this.securityManager != null) && (permission != null)) {
/*  513 */       this.permissionList.add(permission);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean getClearReferencesRmiTargets()
/*      */   {
/*  519 */     return this.clearReferencesRmiTargets;
/*      */   }
/*      */   
/*      */   public void setClearReferencesRmiTargets(boolean clearReferencesRmiTargets)
/*      */   {
/*  524 */     this.clearReferencesRmiTargets = clearReferencesRmiTargets;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getClearReferencesStopThreads()
/*      */   {
/*  532 */     return this.clearReferencesStopThreads;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClearReferencesStopThreads(boolean clearReferencesStopThreads)
/*      */   {
/*  543 */     this.clearReferencesStopThreads = clearReferencesStopThreads;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getClearReferencesStopTimerThreads()
/*      */   {
/*  551 */     return this.clearReferencesStopTimerThreads;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClearReferencesStopTimerThreads(boolean clearReferencesStopTimerThreads)
/*      */   {
/*  562 */     this.clearReferencesStopTimerThreads = clearReferencesStopTimerThreads;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getClearReferencesLogFactoryRelease()
/*      */   {
/*  570 */     return this.clearReferencesLogFactoryRelease;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClearReferencesLogFactoryRelease(boolean clearReferencesLogFactoryRelease)
/*      */   {
/*  581 */     this.clearReferencesLogFactoryRelease = clearReferencesLogFactoryRelease;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getClearReferencesHttpClientKeepAliveThread()
/*      */   {
/*  591 */     return this.clearReferencesHttpClientKeepAliveThread;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClearReferencesHttpClientKeepAliveThread(boolean clearReferencesHttpClientKeepAliveThread)
/*      */   {
/*  603 */     this.clearReferencesHttpClientKeepAliveThread = clearReferencesHttpClientKeepAliveThread;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addTransformer(ClassFileTransformer transformer)
/*      */   {
/*  620 */     if (transformer == null) {
/*  621 */       throw new IllegalArgumentException(sm.getString("webappClassLoader.addTransformer.illegalArgument", new Object[] { getContextName() }));
/*      */     }
/*      */     
/*      */ 
/*  625 */     if (this.transformers.contains(transformer))
/*      */     {
/*  627 */       log.warn(sm.getString("webappClassLoader.addTransformer.duplicate", new Object[] { transformer, getContextName() }));
/*      */       
/*  629 */       return;
/*      */     }
/*  631 */     this.transformers.add(transformer);
/*      */     
/*  633 */     log.info(sm.getString("webappClassLoader.addTransformer", new Object[] { transformer, getContextName() }));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeTransformer(ClassFileTransformer transformer)
/*      */   {
/*  648 */     if (transformer == null) {
/*  649 */       return;
/*      */     }
/*      */     
/*  652 */     if (this.transformers.remove(transformer)) {
/*  653 */       log.info(sm.getString("webappClassLoader.removeTransformer", new Object[] { transformer, getContextName() }));
/*      */       
/*  655 */       return;
/*      */     }
/*      */   }
/*      */   
/*      */   protected void copyStateWithoutTransformers(WebappClassLoaderBase base)
/*      */   {
/*  661 */     base.resources = this.resources;
/*  662 */     base.delegate = this.delegate;
/*  663 */     base.state = LifecycleState.NEW;
/*  664 */     base.clearReferencesStopThreads = this.clearReferencesStopThreads;
/*  665 */     base.clearReferencesStopTimerThreads = this.clearReferencesStopTimerThreads;
/*  666 */     base.clearReferencesLogFactoryRelease = this.clearReferencesLogFactoryRelease;
/*  667 */     base.clearReferencesHttpClientKeepAliveThread = this.clearReferencesHttpClientKeepAliveThread;
/*  668 */     base.jarModificationTimes.putAll(this.jarModificationTimes);
/*  669 */     base.permissionList.addAll(this.permissionList);
/*  670 */     base.loaderPC.putAll(this.loaderPC);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean modified()
/*      */   {
/*  680 */     if (log.isDebugEnabled()) {
/*  681 */       log.debug("modified()");
/*      */     }
/*  683 */     for (Map.Entry<String, ResourceEntry> entry : this.resourceEntries.entrySet()) {
/*  684 */       long cachedLastModified = ((ResourceEntry)entry.getValue()).lastModified;
/*  685 */       long lastModified = this.resources.getClassLoaderResource((String)entry.getKey()).getLastModified();
/*      */       
/*  687 */       if (lastModified != cachedLastModified) {
/*  688 */         if (log.isDebugEnabled()) {
/*  689 */           log.debug(sm.getString("webappClassLoader.resourceModified", new Object[] { entry.getKey(), new Date(cachedLastModified), new Date(lastModified) }));
/*      */         }
/*      */         
/*      */ 
/*  693 */         return true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  698 */     WebResource[] jars = this.resources.listResources("/WEB-INF/lib");
/*      */     
/*      */ 
/*  701 */     int jarCount = 0;
/*  702 */     for (WebResource jar : jars) {
/*  703 */       if ((jar.getName().endsWith(".jar")) && (jar.isFile()) && (jar.canRead())) {
/*  704 */         jarCount++;
/*  705 */         Long recordedLastModified = (Long)this.jarModificationTimes.get(jar.getName());
/*  706 */         if (recordedLastModified == null)
/*      */         {
/*  708 */           log.info(sm.getString("webappClassLoader.jarsAdded", new Object[] { this.resources.getContext().getName() }));
/*      */           
/*  710 */           return true;
/*      */         }
/*  712 */         if (recordedLastModified.longValue() != jar.getLastModified())
/*      */         {
/*  714 */           log.info(sm.getString("webappClassLoader.jarsModified", new Object[] { this.resources.getContext().getName() }));
/*      */           
/*  716 */           return true;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  721 */     if (jarCount < this.jarModificationTimes.size()) {
/*  722 */       log.info(sm.getString("webappClassLoader.jarsRemoved", new Object[] { this.resources.getContext().getName() }));
/*      */       
/*  724 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  729 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/*  736 */     StringBuilder sb = new StringBuilder(getClass().getSimpleName());
/*  737 */     sb.append("\r\n  context: ");
/*  738 */     sb.append(getContextName());
/*  739 */     sb.append("\r\n  delegate: ");
/*  740 */     sb.append(this.delegate);
/*  741 */     sb.append("\r\n");
/*  742 */     if (this.parent != null) {
/*  743 */       sb.append("----------> Parent Classloader:\r\n");
/*  744 */       sb.append(this.parent.toString());
/*  745 */       sb.append("\r\n");
/*      */     }
/*  747 */     if (this.transformers.size() > 0) {
/*  748 */       sb.append("----------> Class file transformers:\r\n");
/*  749 */       for (ClassFileTransformer transformer : this.transformers) {
/*  750 */         sb.append(transformer).append("\r\n");
/*      */       }
/*      */     }
/*  753 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final Class<?> doDefineClass(String name, byte[] b, int off, int len, ProtectionDomain protectionDomain)
/*      */   {
/*  763 */     return super.defineClass(name, b, off, len, protectionDomain);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Class<?> findClass(String name)
/*      */     throws ClassNotFoundException
/*      */   {
/*  777 */     if (log.isDebugEnabled()) {
/*  778 */       log.debug("    findClass(" + name + ")");
/*      */     }
/*  780 */     checkStateForClassLoading(name);
/*      */     
/*      */ 
/*  783 */     if (this.securityManager != null) {
/*  784 */       int i = name.lastIndexOf('.');
/*  785 */       if (i >= 0) {
/*      */         try {
/*  787 */           if (log.isTraceEnabled())
/*  788 */             log.trace("      securityManager.checkPackageDefinition");
/*  789 */           this.securityManager.checkPackageDefinition(name.substring(0, i));
/*      */         } catch (Exception se) {
/*  791 */           if (log.isTraceEnabled())
/*  792 */             log.trace("      -->Exception-->ClassNotFoundException", se);
/*  793 */           throw new ClassNotFoundException(name, se);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  800 */     Class<?> clazz = null;
/*      */     try {
/*  802 */       if (log.isTraceEnabled())
/*  803 */         log.trace("      findClassInternal(" + name + ")");
/*      */       try {
/*  805 */         if (this.securityManager != null) {
/*  806 */           PrivilegedAction<Class<?>> dp = new PrivilegedFindClassByName(name);
/*      */           
/*  808 */           clazz = (Class)AccessController.doPrivileged(dp);
/*      */         } else {
/*  810 */           clazz = findClassInternal(name);
/*      */         }
/*      */       } catch (AccessControlException ace) {
/*  813 */         log.warn("WebappClassLoader.findClassInternal(" + name + ") security exception: " + ace.getMessage(), ace);
/*      */         
/*  815 */         throw new ClassNotFoundException(name, ace);
/*      */       } catch (RuntimeException e) {
/*  817 */         if (log.isTraceEnabled())
/*  818 */           log.trace("      -->RuntimeException Rethrown", e);
/*  819 */         throw e;
/*      */       }
/*  821 */       if ((clazz == null) && (this.hasExternalRepositories)) {
/*      */         try {
/*  823 */           clazz = super.findClass(name);
/*      */         } catch (AccessControlException ace) {
/*  825 */           log.warn("WebappClassLoader.findClassInternal(" + name + ") security exception: " + ace.getMessage(), ace);
/*      */           
/*  827 */           throw new ClassNotFoundException(name, ace);
/*      */         } catch (RuntimeException e) {
/*  829 */           if (log.isTraceEnabled())
/*  830 */             log.trace("      -->RuntimeException Rethrown", e);
/*  831 */           throw e;
/*      */         }
/*      */       }
/*  834 */       if (clazz == null) {
/*  835 */         if (log.isDebugEnabled())
/*  836 */           log.debug("    --> Returning ClassNotFoundException");
/*  837 */         throw new ClassNotFoundException(name);
/*      */       }
/*      */     } catch (ClassNotFoundException e) {
/*  840 */       if (log.isTraceEnabled())
/*  841 */         log.trace("    --> Passing on ClassNotFoundException");
/*  842 */       throw e;
/*      */     }
/*      */     
/*      */ 
/*  846 */     if (log.isTraceEnabled()) {
/*  847 */       log.debug("      Returning class " + clazz);
/*      */     }
/*  849 */     if (log.isTraceEnabled()) { ClassLoader cl;
/*      */       ClassLoader cl;
/*  851 */       if (Globals.IS_SECURITY_ENABLED) {
/*  852 */         cl = (ClassLoader)AccessController.doPrivileged(new PrivilegedGetClassLoader(clazz));
/*      */       }
/*      */       else {
/*  855 */         cl = clazz.getClassLoader();
/*      */       }
/*  857 */       log.debug("      Loaded by " + cl.toString());
/*      */     }
/*  859 */     return clazz;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URL findResource(String name)
/*      */   {
/*  874 */     if (log.isDebugEnabled()) {
/*  875 */       log.debug("    findResource(" + name + ")");
/*      */     }
/*  877 */     checkStateForResourceLoading(name);
/*      */     
/*  879 */     URL url = null;
/*      */     
/*  881 */     String path = nameToPath(name);
/*      */     
/*  883 */     WebResource resource = this.resources.getClassLoaderResource(path);
/*  884 */     if (resource.exists()) {
/*  885 */       url = resource.getURL();
/*  886 */       trackLastModified(path, resource);
/*      */     }
/*      */     
/*  889 */     if ((url == null) && (this.hasExternalRepositories)) {
/*  890 */       url = super.findResource(name);
/*      */     }
/*      */     
/*  893 */     if (log.isDebugEnabled()) {
/*  894 */       if (url != null) {
/*  895 */         log.debug("    --> Returning '" + url.toString() + "'");
/*      */       } else
/*  897 */         log.debug("    --> Resource not found, returning null");
/*      */     }
/*  899 */     return url;
/*      */   }
/*      */   
/*      */   private void trackLastModified(String path, WebResource resource)
/*      */   {
/*  904 */     if (this.resourceEntries.containsKey(path)) {
/*  905 */       return;
/*      */     }
/*  907 */     ResourceEntry entry = new ResourceEntry();
/*  908 */     entry.lastModified = resource.getLastModified();
/*  909 */     synchronized (this.resourceEntries) {
/*  910 */       if (!this.resourceEntries.containsKey(path)) {
/*  911 */         this.resourceEntries.put(path, entry);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Enumeration<URL> findResources(String name)
/*      */     throws IOException
/*      */   {
/*  929 */     if (log.isDebugEnabled()) {
/*  930 */       log.debug("    findResources(" + name + ")");
/*      */     }
/*  932 */     checkStateForResourceLoading(name);
/*      */     
/*  934 */     LinkedHashSet<URL> result = new LinkedHashSet();
/*      */     
/*  936 */     String path = nameToPath(name);
/*      */     
/*  938 */     WebResource[] webResources = this.resources.getClassLoaderResources(path);
/*  939 */     for (WebResource webResource : webResources) {
/*  940 */       if (webResource.exists()) {
/*  941 */         result.add(webResource.getURL());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  946 */     if (this.hasExternalRepositories) {
/*  947 */       Enumeration<URL> otherResourcePaths = super.findResources(name);
/*  948 */       while (otherResourcePaths.hasMoreElements()) {
/*  949 */         result.add(otherResourcePaths.nextElement());
/*      */       }
/*      */     }
/*      */     
/*  953 */     return Collections.enumeration(result);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URL getResource(String name)
/*      */   {
/*  982 */     if (log.isDebugEnabled()) {
/*  983 */       log.debug("getResource(" + name + ")");
/*      */     }
/*  985 */     checkStateForResourceLoading(name);
/*      */     
/*  987 */     URL url = null;
/*      */     
/*  989 */     boolean delegateFirst = (this.delegate) || (filter(name, false));
/*      */     
/*      */ 
/*  992 */     if (delegateFirst) {
/*  993 */       if (log.isDebugEnabled())
/*  994 */         log.debug("  Delegating to parent classloader " + this.parent);
/*  995 */       url = this.parent.getResource(name);
/*  996 */       if (url != null) {
/*  997 */         if (log.isDebugEnabled())
/*  998 */           log.debug("  --> Returning '" + url.toString() + "'");
/*  999 */         return url;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1004 */     url = findResource(name);
/* 1005 */     if (url != null) {
/* 1006 */       if (log.isDebugEnabled())
/* 1007 */         log.debug("  --> Returning '" + url.toString() + "'");
/* 1008 */       return url;
/*      */     }
/*      */     
/*      */ 
/* 1012 */     if (!delegateFirst) {
/* 1013 */       url = this.parent.getResource(name);
/* 1014 */       if (url != null) {
/* 1015 */         if (log.isDebugEnabled())
/* 1016 */           log.debug("  --> Returning '" + url.toString() + "'");
/* 1017 */         return url;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1022 */     if (log.isDebugEnabled())
/* 1023 */       log.debug("  --> Resource not found, returning null");
/* 1024 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getResourceAsStream(String name)
/*      */   {
/* 1041 */     if (log.isDebugEnabled()) {
/* 1042 */       log.debug("getResourceAsStream(" + name + ")");
/*      */     }
/* 1044 */     checkStateForResourceLoading(name);
/*      */     
/* 1046 */     InputStream stream = null;
/*      */     
/* 1048 */     boolean delegateFirst = (this.delegate) || (filter(name, false));
/*      */     
/*      */ 
/* 1051 */     if (delegateFirst) {
/* 1052 */       if (log.isDebugEnabled())
/* 1053 */         log.debug("  Delegating to parent classloader " + this.parent);
/* 1054 */       stream = this.parent.getResourceAsStream(name);
/* 1055 */       if (stream != null) {
/* 1056 */         if (log.isDebugEnabled())
/* 1057 */           log.debug("  --> Returning stream from parent");
/* 1058 */         return stream;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1063 */     if (log.isDebugEnabled())
/* 1064 */       log.debug("  Searching local repositories");
/* 1065 */     String path = nameToPath(name);
/* 1066 */     WebResource resource = this.resources.getClassLoaderResource(path);
/* 1067 */     if (resource.exists()) {
/* 1068 */       stream = resource.getInputStream();
/* 1069 */       trackLastModified(path, resource);
/*      */     }
/*      */     try {
/* 1072 */       if ((this.hasExternalRepositories) && (stream == null)) {
/* 1073 */         URL url = super.findResource(name);
/* 1074 */         if (url != null) {
/* 1075 */           stream = url.openStream();
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException) {}
/*      */     
/* 1081 */     if (stream != null) {
/* 1082 */       if (log.isDebugEnabled())
/* 1083 */         log.debug("  --> Returning stream from local");
/* 1084 */       return stream;
/*      */     }
/*      */     
/*      */ 
/* 1088 */     if (!delegateFirst) {
/* 1089 */       if (log.isDebugEnabled())
/* 1090 */         log.debug("  Delegating to parent classloader unconditionally " + this.parent);
/* 1091 */       stream = this.parent.getResourceAsStream(name);
/* 1092 */       if (stream != null) {
/* 1093 */         if (log.isDebugEnabled())
/* 1094 */           log.debug("  --> Returning stream from parent");
/* 1095 */         return stream;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1100 */     if (log.isDebugEnabled())
/* 1101 */       log.debug("  --> Resource not found, returning null");
/* 1102 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Class<?> loadClass(String name)
/*      */     throws ClassNotFoundException
/*      */   {
/* 1118 */     return loadClass(name, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Class<?> loadClass(String name, boolean resolve)
/*      */     throws ClassNotFoundException
/*      */   {
/* 1151 */     synchronized (getClassLoadingLock(name)) {
/* 1152 */       if (log.isDebugEnabled())
/* 1153 */         log.debug("loadClass(" + name + ", " + resolve + ")");
/* 1154 */       Class<?> clazz = null;
/*      */       
/*      */ 
/* 1157 */       checkStateForClassLoading(name);
/*      */       
/*      */ 
/* 1160 */       clazz = findLoadedClass0(name);
/* 1161 */       if (clazz != null) {
/* 1162 */         if (log.isDebugEnabled())
/* 1163 */           log.debug("  Returning class from cache");
/* 1164 */         if (resolve)
/* 1165 */           resolveClass(clazz);
/* 1166 */         return clazz;
/*      */       }
/*      */       
/*      */ 
/* 1170 */       clazz = findLoadedClass(name);
/* 1171 */       if (clazz != null) {
/* 1172 */         if (log.isDebugEnabled())
/* 1173 */           log.debug("  Returning class from cache");
/* 1174 */         if (resolve)
/* 1175 */           resolveClass(clazz);
/* 1176 */         return clazz;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1182 */       String resourceName = binaryNameToPath(name, false);
/*      */       
/* 1184 */       ClassLoader javaseLoader = getJavaseClassLoader();
/*      */       
/*      */ 
/*      */ 
/*      */       boolean tryLoadingFromJavaseLoader;
/*      */       
/*      */ 
/*      */       try
/*      */       {
/* 1193 */         tryLoadingFromJavaseLoader = javaseLoader.getResource(resourceName) != null;
/*      */       }
/*      */       catch (ClassCircularityError cce)
/*      */       {
/*      */         boolean tryLoadingFromJavaseLoader;
/* 1198 */         tryLoadingFromJavaseLoader = true;
/*      */       }
/*      */       
/* 1201 */       if (tryLoadingFromJavaseLoader) {
/*      */         try {
/* 1203 */           clazz = javaseLoader.loadClass(name);
/* 1204 */           if (clazz != null) {
/* 1205 */             if (resolve)
/* 1206 */               resolveClass(clazz);
/* 1207 */             return clazz;
/*      */           }
/*      */         }
/*      */         catch (ClassNotFoundException localClassNotFoundException) {}
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1215 */       if (this.securityManager != null) {
/* 1216 */         int i = name.lastIndexOf('.');
/* 1217 */         if (i >= 0) {
/*      */           try {
/* 1219 */             this.securityManager.checkPackageAccess(name.substring(0, i));
/*      */           } catch (SecurityException se) {
/* 1221 */             String error = "Security Violation, attempt to use Restricted Class: " + name;
/*      */             
/* 1223 */             log.info(error, se);
/* 1224 */             throw new ClassNotFoundException(error, se);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 1229 */       boolean delegateLoad = (this.delegate) || (filter(name, true));
/*      */       
/*      */ 
/* 1232 */       if (delegateLoad) {
/* 1233 */         if (log.isDebugEnabled())
/* 1234 */           log.debug("  Delegating to parent classloader1 " + this.parent);
/*      */         try {
/* 1236 */           clazz = Class.forName(name, false, this.parent);
/* 1237 */           if (clazz != null) {
/* 1238 */             if (log.isDebugEnabled())
/* 1239 */               log.debug("  Loading class from parent");
/* 1240 */             if (resolve)
/* 1241 */               resolveClass(clazz);
/* 1242 */             return clazz;
/*      */           }
/*      */         }
/*      */         catch (ClassNotFoundException localClassNotFoundException1) {}
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1250 */       if (log.isDebugEnabled())
/* 1251 */         log.debug("  Searching local repositories");
/*      */       try {
/* 1253 */         clazz = findClass(name);
/* 1254 */         if (clazz != null) {
/* 1255 */           if (log.isDebugEnabled())
/* 1256 */             log.debug("  Loading class from local repository");
/* 1257 */           if (resolve)
/* 1258 */             resolveClass(clazz);
/* 1259 */           return clazz;
/*      */         }
/*      */       }
/*      */       catch (ClassNotFoundException localClassNotFoundException2) {}
/*      */       
/*      */ 
/*      */ 
/* 1266 */       if (!delegateLoad) {
/* 1267 */         if (log.isDebugEnabled())
/* 1268 */           log.debug("  Delegating to parent classloader at end: " + this.parent);
/*      */         try {
/* 1270 */           clazz = Class.forName(name, false, this.parent);
/* 1271 */           if (clazz != null) {
/* 1272 */             if (log.isDebugEnabled())
/* 1273 */               log.debug("  Loading class from parent");
/* 1274 */             if (resolve)
/* 1275 */               resolveClass(clazz);
/* 1276 */             return clazz;
/*      */           }
/*      */         }
/*      */         catch (ClassNotFoundException localClassNotFoundException3) {}
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1284 */     throw new ClassNotFoundException(name);
/*      */   }
/*      */   
/*      */   protected void checkStateForClassLoading(String className)
/*      */     throws ClassNotFoundException
/*      */   {
/*      */     try
/*      */     {
/* 1292 */       checkStateForResourceLoading(className);
/*      */     } catch (IllegalStateException ise) {
/* 1294 */       throw new ClassNotFoundException(ise.getMessage(), ise);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected void checkStateForResourceLoading(String resource)
/*      */     throws IllegalStateException
/*      */   {
/* 1302 */     if (!this.state.isAvailable()) {
/* 1303 */       String msg = sm.getString("webappClassLoader.stopped", new Object[] { resource });
/* 1304 */       IllegalStateException ise = new IllegalStateException(msg);
/* 1305 */       log.info(msg, ise);
/* 1306 */       throw ise;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PermissionCollection getPermissions(CodeSource codeSource)
/*      */   {
/* 1323 */     String codeUrl = codeSource.getLocation().toString();
/*      */     PermissionCollection pc;
/* 1325 */     if ((pc = (PermissionCollection)this.loaderPC.get(codeUrl)) == null) {
/* 1326 */       pc = super.getPermissions(codeSource);
/* 1327 */       if (pc != null) {
/* 1328 */         Iterator<Permission> perms = this.permissionList.iterator();
/* 1329 */         while (perms.hasNext()) {
/* 1330 */           Permission p = (Permission)perms.next();
/* 1331 */           pc.add(p);
/*      */         }
/* 1333 */         this.loaderPC.put(codeUrl, pc);
/*      */       }
/*      */     }
/* 1336 */     return pc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URL[] getURLs()
/*      */   {
/* 1353 */     ArrayList<URL> result = new ArrayList();
/* 1354 */     result.addAll(this.localRepositories);
/* 1355 */     result.addAll(Arrays.asList(super.getURLs()));
/* 1356 */     return (URL[])result.toArray(new URL[result.size()]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public LifecycleListener[] findLifecycleListeners()
/*      */   {
/* 1380 */     return new LifecycleListener[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public LifecycleState getState()
/*      */   {
/* 1402 */     return this.state;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getStateName()
/*      */   {
/* 1411 */     return getState().toString();
/*      */   }
/*      */   
/*      */ 
/*      */   public void init()
/*      */   {
/* 1417 */     this.state = LifecycleState.INITIALIZED;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void start()
/*      */     throws LifecycleException
/*      */   {
/* 1429 */     this.state = LifecycleState.STARTING_PREP;
/*      */     
/* 1431 */     WebResource classes = this.resources.getResource("/WEB-INF/classes");
/* 1432 */     if ((classes.isDirectory()) && (classes.canRead())) {
/* 1433 */       this.localRepositories.add(classes.getURL());
/*      */     }
/* 1435 */     WebResource[] jars = this.resources.listResources("/WEB-INF/lib");
/* 1436 */     for (WebResource jar : jars) {
/* 1437 */       if ((jar.getName().endsWith(".jar")) && (jar.isFile()) && (jar.canRead())) {
/* 1438 */         this.localRepositories.add(jar.getURL());
/* 1439 */         this.jarModificationTimes.put(jar.getName(), Long.valueOf(jar.getLastModified()));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1444 */     this.state = LifecycleState.STARTED;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void stop()
/*      */     throws LifecycleException
/*      */   {
/* 1456 */     this.state = LifecycleState.STOPPING_PREP;
/*      */     
/*      */ 
/*      */ 
/* 1460 */     clearReferences();
/*      */     
/* 1462 */     this.state = LifecycleState.STOPPING;
/*      */     
/* 1464 */     this.resourceEntries.clear();
/* 1465 */     this.jarModificationTimes.clear();
/* 1466 */     this.resources = null;
/*      */     
/* 1468 */     this.permissionList.clear();
/* 1469 */     this.loaderPC.clear();
/*      */     
/* 1471 */     this.state = LifecycleState.STOPPED;
/*      */   }
/*      */   
/*      */ 
/*      */   public void destroy()
/*      */   {
/* 1477 */     this.state = LifecycleState.DESTROYING;
/*      */     try
/*      */     {
/* 1480 */       super.close();
/*      */     } catch (IOException ioe) {
/* 1482 */       log.warn(sm.getString("webappClassLoader.superCloseFail"), ioe);
/*      */     }
/* 1484 */     this.state = LifecycleState.DESTROYED;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected ClassLoader getJavaseClassLoader()
/*      */   {
/* 1491 */     return this.javaseClassLoader;
/*      */   }
/*      */   
/*      */   protected void setJavaseClassLoader(ClassLoader classLoader) {
/* 1495 */     if (classLoader == null) {
/* 1496 */       throw new IllegalArgumentException(sm.getString("webappClassLoader.javaseClassLoaderNull"));
/*      */     }
/*      */     
/* 1499 */     this.javaseClassLoader = classLoader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void clearReferences()
/*      */   {
/* 1508 */     clearReferencesJdbc();
/*      */     
/*      */ 
/* 1511 */     clearReferencesThreads();
/*      */     
/*      */ 
/* 1514 */     checkThreadLocalsForLeaks();
/*      */     
/*      */ 
/* 1517 */     if (this.clearReferencesRmiTargets) {
/* 1518 */       clearReferencesRmiTargets();
/*      */     }
/*      */     
/*      */ 
/* 1522 */     IntrospectionUtils.clear();
/*      */     
/*      */ 
/* 1525 */     if (this.clearReferencesLogFactoryRelease) {
/* 1526 */       LogFactory.release(this);
/*      */     }
/*      */     
/*      */ 
/* 1530 */     Introspector.flushCaches();
/*      */     
/*      */ 
/* 1533 */     TomcatURLStreamHandlerFactory.release(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void clearReferencesJdbc()
/*      */   {
/* 1558 */     byte[] classBytes = new byte['ࠀ'];
/* 1559 */     int offset = 0;
/* 1560 */     try { InputStream is = getResourceAsStream("org/apache/catalina/loader/JdbcLeakPrevention.class");Throwable localThrowable2 = null;
/*      */       try {
/* 1562 */         int read = is.read(classBytes, offset, classBytes.length - offset);
/* 1563 */         while (read > -1) {
/* 1564 */           offset += read;
/* 1565 */           if (offset == classBytes.length)
/*      */           {
/* 1567 */             byte[] tmp = new byte[classBytes.length * 2];
/* 1568 */             System.arraycopy(classBytes, 0, tmp, 0, classBytes.length);
/* 1569 */             classBytes = tmp;
/*      */           }
/* 1571 */           read = is.read(classBytes, offset, classBytes.length - offset);
/*      */         }
/* 1573 */         Class<?> lpClass = defineClass("org.apache.catalina.loader.JdbcLeakPrevention", classBytes, 0, offset, getClass().getProtectionDomain());
/*      */         
/*      */ 
/* 1576 */         Object obj = lpClass.newInstance();
/*      */         
/* 1578 */         List<String> driverNames = (List)obj.getClass().getMethod("clearJdbcDriverRegistrations", new Class[0]).invoke(obj, new Object[0]);
/*      */         
/* 1580 */         for (String name : driverNames) {
/* 1581 */           log.warn(sm.getString("webappClassLoader.clearJdbc", new Object[] { getContextName(), name }));
/*      */         }
/*      */       }
/*      */       catch (Throwable localThrowable1)
/*      */       {
/* 1560 */         localThrowable2 = localThrowable1;throw localThrowable1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1584 */         if (is != null) if (localThrowable2 != null) try { is.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else is.close();
/*      */       }
/* 1586 */     } catch (Exception e) { Throwable t = ExceptionUtils.unwrapInvocationTargetException(e);
/* 1587 */       ExceptionUtils.handleThrowable(t);
/* 1588 */       log.warn(sm.getString("webappClassLoader.jdbcRemoveFailed", new Object[] { getContextName() }), t);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void clearReferencesThreads()
/*      */   {
/* 1596 */     Thread[] threads = getThreads();
/* 1597 */     List<Thread> executorThreadsToStop = new ArrayList();
/*      */     
/*      */ 
/* 1600 */     for (Thread thread : threads) {
/* 1601 */       if (thread != null) {
/* 1602 */         ClassLoader ccl = thread.getContextClassLoader();
/* 1603 */         if (ccl == this)
/*      */         {
/* 1605 */           if (thread != Thread.currentThread())
/*      */           {
/*      */ 
/*      */ 
/* 1609 */             String threadName = thread.getName();
/*      */             
/*      */ 
/* 1612 */             ThreadGroup tg = thread.getThreadGroup();
/* 1613 */             if ((tg != null) && (JVM_THREAD_GROUP_NAMES.contains(tg.getName())))
/*      */             {
/* 1615 */               if ((this.clearReferencesHttpClientKeepAliveThread) && (threadName.equals("Keep-Alive-Timer")))
/*      */               {
/* 1617 */                 thread.setContextClassLoader(this.parent);
/* 1618 */                 log.debug(sm.getString("webappClassLoader.checkThreadsHttpClient"));
/*      */ 
/*      */ 
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */             }
/* 1626 */             else if (thread.isAlive())
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1633 */               if ((thread.getClass().getName().startsWith("java.util.Timer")) && (this.clearReferencesStopTimerThreads))
/*      */               {
/* 1635 */                 clearReferencesStopTimerThread(thread);
/*      */               }
/*      */               else
/*      */               {
/* 1639 */                 if (isRequestThread(thread)) {
/* 1640 */                   log.warn(sm.getString("webappClassLoader.stackTraceRequestThread", new Object[] { getContextName(), threadName, getStackTrace(thread) }));
/*      */                 }
/*      */                 else {
/* 1643 */                   log.warn(sm.getString("webappClassLoader.stackTrace", new Object[] { getContextName(), threadName, getStackTrace(thread) }));
/*      */                 }
/*      */                 
/*      */ 
/*      */ 
/*      */ 
/* 1649 */                 if (this.clearReferencesStopThreads)
/*      */                 {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1655 */                   boolean usingExecutor = false;
/*      */                   
/*      */ 
/*      */ 
/*      */ 
/*      */                   try
/*      */                   {
/* 1662 */                     Object target = null;
/* 1663 */                     for (String fieldName : new String[] { "target", "runnable", "action" }) {
/*      */                       try {
/* 1665 */                         Field targetField = thread.getClass().getDeclaredField(fieldName);
/* 1666 */                         targetField.setAccessible(true);
/* 1667 */                         target = targetField.get(thread);
/*      */                       }
/*      */                       catch (NoSuchFieldException nfe) {}
/*      */                     }
/*      */                     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1676 */                     if ((target != null) && (target.getClass().getCanonicalName() != null) && (target.getClass().getCanonicalName().equals("java.util.concurrent.ThreadPoolExecutor.Worker")))
/*      */                     {
/*      */ 
/* 1679 */                       Field executorField = target.getClass().getDeclaredField("this$0");
/* 1680 */                       executorField.setAccessible(true);
/* 1681 */                       Object executor = executorField.get(target);
/* 1682 */                       if ((executor instanceof ThreadPoolExecutor)) {
/* 1683 */                         ((ThreadPoolExecutor)executor).shutdownNow();
/* 1684 */                         usingExecutor = true;
/*      */                       }
/*      */                     }
/*      */                   }
/*      */                   catch (SecurityException|NoSuchFieldException|IllegalArgumentException|IllegalAccessException e) {
/* 1689 */                     log.warn(sm.getString("webappClassLoader.stopThreadFail", new Object[] { thread.getName(), getContextName() }), e);
/*      */                   }
/*      */                   
/*      */ 
/* 1693 */                   if (usingExecutor)
/*      */                   {
/*      */ 
/*      */ 
/* 1697 */                     executorThreadsToStop.add(thread);
/*      */ 
/*      */                   }
/*      */                   else
/*      */                   {
/*      */ 
/* 1703 */                     thread.stop();
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1714 */     int count = 0;
/* 1715 */     for (Thread t : executorThreadsToStop) {
/* 1716 */       while ((t.isAlive()) && (count < 100)) {
/*      */         try {
/* 1718 */           Thread.sleep(20L);
/*      */         }
/*      */         catch (InterruptedException e) {
/*      */           break;
/*      */         }
/* 1723 */         count++;
/*      */       }
/* 1725 */       if (t.isAlive())
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1730 */         t.stop();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isRequestThread(Thread thread)
/*      */   {
/* 1742 */     StackTraceElement[] elements = thread.getStackTrace();
/*      */     
/* 1744 */     if ((elements == null) || (elements.length == 0))
/*      */     {
/*      */ 
/* 1747 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1754 */     for (int i = 0; i < elements.length; i++) {
/* 1755 */       StackTraceElement element = elements[(elements.length - (i + 1))];
/* 1756 */       if ("org.apache.catalina.connector.CoyoteAdapter".equals(element.getClassName()))
/*      */       {
/* 1758 */         return true;
/*      */       }
/*      */     }
/* 1761 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void clearReferencesStopTimerThread(Thread thread)
/*      */   {
/*      */     try
/*      */     {
/*      */       try
/*      */       {
/* 1778 */         Field newTasksMayBeScheduledField = thread.getClass().getDeclaredField("newTasksMayBeScheduled");
/*      */         
/* 1780 */         newTasksMayBeScheduledField.setAccessible(true);
/* 1781 */         Field queueField = thread.getClass().getDeclaredField("queue");
/* 1782 */         queueField.setAccessible(true);
/*      */         
/* 1784 */         Object queue = queueField.get(thread);
/*      */         
/* 1786 */         Method clearMethod = queue.getClass().getDeclaredMethod("clear", new Class[0]);
/* 1787 */         clearMethod.setAccessible(true);
/*      */         
/* 1789 */         synchronized (queue) {
/* 1790 */           newTasksMayBeScheduledField.setBoolean(thread, false);
/* 1791 */           clearMethod.invoke(queue, new Object[0]);
/* 1792 */           queue.notify();
/*      */         }
/*      */       }
/*      */       catch (NoSuchFieldException nfe) {
/* 1796 */         Method cancelMethod = thread.getClass().getDeclaredMethod("cancel", new Class[0]);
/* 1797 */         synchronized (thread) {
/* 1798 */           cancelMethod.setAccessible(true);
/* 1799 */           cancelMethod.invoke(thread, new Object[0]);
/*      */         }
/*      */       }
/*      */       
/* 1803 */       log.warn(sm.getString("webappClassLoader.warnTimerThread", new Object[] { getContextName(), thread.getName() }));
/*      */ 
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1808 */       Throwable t = ExceptionUtils.unwrapInvocationTargetException(e);
/* 1809 */       ExceptionUtils.handleThrowable(t);
/* 1810 */       log.warn(sm.getString("webappClassLoader.stopTimerThreadFail", new Object[] { thread.getName(), getContextName() }), t);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void checkThreadLocalsForLeaks()
/*      */   {
/* 1817 */     Thread[] threads = getThreads();
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1822 */       Field threadLocalsField = Thread.class.getDeclaredField("threadLocals");
/*      */       
/* 1824 */       threadLocalsField.setAccessible(true);
/* 1825 */       Field inheritableThreadLocalsField = Thread.class.getDeclaredField("inheritableThreadLocals");
/*      */       
/* 1827 */       inheritableThreadLocalsField.setAccessible(true);
/*      */       
/*      */ 
/* 1830 */       Class<?> tlmClass = Class.forName("java.lang.ThreadLocal$ThreadLocalMap");
/* 1831 */       Field tableField = tlmClass.getDeclaredField("table");
/* 1832 */       tableField.setAccessible(true);
/* 1833 */       Method expungeStaleEntriesMethod = tlmClass.getDeclaredMethod("expungeStaleEntries", new Class[0]);
/* 1834 */       expungeStaleEntriesMethod.setAccessible(true);
/*      */       
/* 1836 */       for (int i = 0; i < threads.length; i++)
/*      */       {
/* 1838 */         if (threads[i] != null)
/*      */         {
/*      */ 
/* 1841 */           Object threadLocalMap = threadLocalsField.get(threads[i]);
/* 1842 */           if (null != threadLocalMap) {
/* 1843 */             expungeStaleEntriesMethod.invoke(threadLocalMap, new Object[0]);
/* 1844 */             checkThreadLocalMapForLeaks(threadLocalMap, tableField);
/*      */           }
/*      */           
/*      */ 
/* 1848 */           threadLocalMap = inheritableThreadLocalsField.get(threads[i]);
/* 1849 */           if (null != threadLocalMap) {
/* 1850 */             expungeStaleEntriesMethod.invoke(threadLocalMap, new Object[0]);
/* 1851 */             checkThreadLocalMapForLeaks(threadLocalMap, tableField);
/*      */           }
/*      */         }
/*      */       }
/*      */     } catch (Throwable t) {
/* 1856 */       ExceptionUtils.handleThrowable(t);
/* 1857 */       log.warn(sm.getString("webappClassLoader.checkThreadLocalsForLeaksFail", new Object[] { getContextName() }), t);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkThreadLocalMapForLeaks(Object map, Field internalTableField)
/*      */     throws IllegalAccessException, NoSuchFieldException
/*      */   {
/* 1872 */     if (map != null) {
/* 1873 */       Object[] table = (Object[])internalTableField.get(map);
/* 1874 */       if (table != null) {
/* 1875 */         for (int j = 0; j < table.length; j++) {
/* 1876 */           Object obj = table[j];
/* 1877 */           if (obj != null) {
/* 1878 */             boolean keyLoadedByWebapp = false;
/* 1879 */             boolean valueLoadedByWebapp = false;
/*      */             
/* 1881 */             Object key = ((Reference)obj).get();
/* 1882 */             if ((equals(key)) || (loadedByThisOrChild(key))) {
/* 1883 */               keyLoadedByWebapp = true;
/*      */             }
/*      */             
/* 1886 */             Field valueField = obj.getClass().getDeclaredField("value");
/*      */             
/* 1888 */             valueField.setAccessible(true);
/* 1889 */             Object value = valueField.get(obj);
/* 1890 */             if ((equals(value)) || (loadedByThisOrChild(value))) {
/* 1891 */               valueLoadedByWebapp = true;
/*      */             }
/* 1893 */             if ((keyLoadedByWebapp) || (valueLoadedByWebapp)) {
/* 1894 */               Object[] args = new Object[5];
/* 1895 */               args[0] = getContextName();
/* 1896 */               if (key != null) {
/* 1897 */                 args[1] = getPrettyClassName(key.getClass());
/*      */                 try {
/* 1899 */                   args[2] = key.toString();
/*      */                 } catch (Exception e) {
/* 1901 */                   log.warn(sm.getString("webappClassLoader.checkThreadLocalsForLeaks.badKey", new Object[] { args[1] }), e);
/*      */                   
/*      */ 
/* 1904 */                   args[2] = sm.getString("webappClassLoader.checkThreadLocalsForLeaks.unknown");
/*      */                 }
/*      */               }
/*      */               
/* 1908 */               if (value != null) {
/* 1909 */                 args[3] = getPrettyClassName(value.getClass());
/*      */                 try {
/* 1911 */                   args[4] = value.toString();
/*      */                 } catch (Exception e) {
/* 1913 */                   log.warn(sm.getString("webappClassLoader.checkThreadLocalsForLeaks.badValue", new Object[] { args[3] }), e);
/*      */                   
/*      */ 
/* 1916 */                   args[4] = sm.getString("webappClassLoader.checkThreadLocalsForLeaks.unknown");
/*      */                 }
/*      */               }
/*      */               
/* 1920 */               if (valueLoadedByWebapp) {
/* 1921 */                 log.error(sm.getString("webappClassLoader.checkThreadLocalsForLeaks", args));
/*      */ 
/*      */               }
/* 1924 */               else if (value == null) {
/* 1925 */                 if (log.isDebugEnabled()) {
/* 1926 */                   log.debug(sm.getString("webappClassLoader.checkThreadLocalsForLeaksNull", args));
/*      */                 }
/*      */                 
/*      */ 
/*      */               }
/* 1931 */               else if (log.isDebugEnabled()) {
/* 1932 */                 log.debug(sm.getString("webappClassLoader.checkThreadLocalsForLeaksNone", args));
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private String getPrettyClassName(Class<?> clazz)
/*      */   {
/* 1945 */     String name = clazz.getCanonicalName();
/* 1946 */     if (name == null) {
/* 1947 */       name = clazz.getName();
/*      */     }
/* 1949 */     return name;
/*      */   }
/*      */   
/*      */   private String getStackTrace(Thread thread) {
/* 1953 */     StringBuilder builder = new StringBuilder();
/* 1954 */     for (StackTraceElement ste : thread.getStackTrace()) {
/* 1955 */       builder.append("\n ").append(ste);
/*      */     }
/* 1957 */     return builder.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean loadedByThisOrChild(Object o)
/*      */   {
/* 1966 */     if (o == null) {
/* 1967 */       return false;
/*      */     }
/*      */     Class<?> clazz;
/*      */     Class<?> clazz;
/* 1971 */     if ((o instanceof Class)) {
/* 1972 */       clazz = (Class)o;
/*      */     } else {
/* 1974 */       clazz = o.getClass();
/*      */     }
/*      */     
/* 1977 */     ClassLoader cl = clazz.getClassLoader();
/* 1978 */     while (cl != null) {
/* 1979 */       if (cl == this) {
/* 1980 */         return true;
/*      */       }
/* 1982 */       cl = cl.getParent();
/*      */     }
/*      */     
/* 1985 */     if ((o instanceof Collection)) {
/* 1986 */       Iterator<?> iter = ((Collection)o).iterator();
/*      */       try {
/* 1988 */         while (iter.hasNext()) {
/* 1989 */           Object entry = iter.next();
/* 1990 */           if (loadedByThisOrChild(entry)) {
/* 1991 */             return true;
/*      */           }
/*      */         }
/*      */       } catch (ConcurrentModificationException e) {
/* 1995 */         log.warn(sm.getString("webappClassLoader.loadedByThisOrChildFail", new Object[] { clazz.getName(), getContextName() }), e);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2000 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Thread[] getThreads()
/*      */   {
/* 2008 */     ThreadGroup tg = Thread.currentThread().getThreadGroup();
/*      */     try
/*      */     {
/* 2011 */       while (tg.getParent() != null) {
/* 2012 */         tg = tg.getParent();
/*      */       }
/*      */     } catch (SecurityException se) {
/* 2015 */       String msg = sm.getString("webappClassLoader.getThreadGroupError", new Object[] { tg.getName() });
/*      */       
/* 2017 */       if (log.isDebugEnabled()) {
/* 2018 */         log.debug(msg, se);
/*      */       } else {
/* 2020 */         log.warn(msg);
/*      */       }
/*      */     }
/*      */     
/* 2024 */     int threadCountGuess = tg.activeCount() + 50;
/* 2025 */     Thread[] threads = new Thread[threadCountGuess];
/* 2026 */     int threadCountActual = tg.enumerate(threads);
/*      */     
/* 2028 */     while (threadCountActual == threadCountGuess) {
/* 2029 */       threadCountGuess *= 2;
/* 2030 */       threads = new Thread[threadCountGuess];
/*      */       
/*      */ 
/* 2033 */       threadCountActual = tg.enumerate(threads);
/*      */     }
/*      */     
/* 2036 */     return threads;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void clearReferencesRmiTargets()
/*      */   {
/*      */     try
/*      */     {
/* 2048 */       Class<?> objectTargetClass = Class.forName("sun.rmi.transport.Target");
/*      */       
/* 2050 */       Field cclField = objectTargetClass.getDeclaredField("ccl");
/* 2051 */       cclField.setAccessible(true);
/*      */       
/* 2053 */       Field stubField = objectTargetClass.getDeclaredField("stub");
/* 2054 */       stubField.setAccessible(true);
/*      */       
/*      */ 
/* 2057 */       Class<?> objectTableClass = Class.forName("sun.rmi.transport.ObjectTable");
/*      */       
/* 2059 */       Field objTableField = objectTableClass.getDeclaredField("objTable");
/* 2060 */       objTableField.setAccessible(true);
/* 2061 */       Object objTable = objTableField.get(null);
/* 2062 */       if (objTable == null) {
/* 2063 */         return;
/*      */       }
/*      */       
/*      */ 
/* 2067 */       if ((objTable instanceof Map)) {
/* 2068 */         Iterator<?> iter = ((Map)objTable).values().iterator();
/* 2069 */         while (iter.hasNext()) {
/* 2070 */           Object obj = iter.next();
/* 2071 */           Object cclObject = cclField.get(obj);
/* 2072 */           if (this == cclObject) {
/* 2073 */             iter.remove();
/* 2074 */             Object stubObject = stubField.get(obj);
/* 2075 */             log.error(sm.getString("webappClassLoader.clearRmi", new Object[] { stubObject.getClass().getName(), stubObject }));
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2082 */       Field implTableField = objectTableClass.getDeclaredField("implTable");
/* 2083 */       implTableField.setAccessible(true);
/* 2084 */       Object implTable = implTableField.get(null);
/* 2085 */       if (implTable == null) {
/* 2086 */         return;
/*      */       }
/*      */       
/*      */ 
/* 2090 */       if ((implTable instanceof Map)) {
/* 2091 */         Iterator<?> iter = ((Map)implTable).values().iterator();
/* 2092 */         while (iter.hasNext()) {
/* 2093 */           Object obj = iter.next();
/* 2094 */           Object cclObject = cclField.get(obj);
/* 2095 */           if (this == cclObject) {
/* 2096 */             iter.remove();
/*      */           }
/*      */         }
/*      */       }
/*      */     } catch (ClassNotFoundException e) {
/* 2101 */       log.info(sm.getString("webappClassLoader.clearRmiInfo", new Object[] { getContextName() }), e);
/*      */     }
/*      */     catch (SecurityException|NoSuchFieldException|IllegalArgumentException|IllegalAccessException e)
/*      */     {
/* 2105 */       log.warn(sm.getString("webappClassLoader.clearRmiFail", new Object[] { getContextName() }), e);
/*      */     }
/*      */     catch (Exception e) {
/* 2108 */       JreCompat jreCompat = JreCompat.getInstance();
/* 2109 */       if (jreCompat.isInstanceOfInaccessibleObjectException(e))
/*      */       {
/*      */ 
/* 2112 */         log.warn(sm.getString("webappClassLoader.addExports"));
/*      */       }
/*      */       else {
/* 2115 */         throw e;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Class<?> findClassInternal(String name)
/*      */   {
/* 2130 */     checkStateForResourceLoading(name);
/*      */     
/* 2132 */     if (name == null) {
/* 2133 */       return null;
/*      */     }
/* 2135 */     String path = binaryNameToPath(name, true);
/*      */     
/* 2137 */     ResourceEntry entry = (ResourceEntry)this.resourceEntries.get(path);
/* 2138 */     WebResource resource = null;
/*      */     
/* 2140 */     if (entry == null) {
/* 2141 */       resource = this.resources.getClassLoaderResource(path);
/*      */       
/* 2143 */       if (!resource.exists()) {
/* 2144 */         return null;
/*      */       }
/*      */       
/* 2147 */       entry = new ResourceEntry();
/* 2148 */       entry.lastModified = resource.getLastModified();
/*      */       
/*      */ 
/* 2151 */       synchronized (this.resourceEntries)
/*      */       {
/*      */ 
/*      */ 
/* 2155 */         ResourceEntry entry2 = (ResourceEntry)this.resourceEntries.get(path);
/* 2156 */         if (entry2 == null) {
/* 2157 */           this.resourceEntries.put(path, entry);
/*      */         } else {
/* 2159 */           entry = entry2;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2164 */     Class<?> clazz = entry.loadedClass;
/* 2165 */     if (clazz != null) {
/* 2166 */       return clazz;
/*      */     }
/* 2168 */     synchronized (getClassLoadingLock(name)) {
/* 2169 */       clazz = entry.loadedClass;
/* 2170 */       if (clazz != null) {
/* 2171 */         return clazz;
/*      */       }
/* 2173 */       if (resource == null) {
/* 2174 */         resource = this.resources.getClassLoaderResource(path);
/*      */       }
/*      */       
/* 2177 */       if (!resource.exists()) {
/* 2178 */         return null;
/*      */       }
/*      */       
/* 2181 */       byte[] binaryContent = resource.getContent();
/* 2182 */       Manifest manifest = resource.getManifest();
/* 2183 */       URL codeBase = resource.getCodeBase();
/* 2184 */       Certificate[] certificates = resource.getCertificates();
/*      */       String internalName;
/* 2186 */       if (this.transformers.size() > 0)
/*      */       {
/*      */ 
/* 2189 */         String className = name.endsWith(".class") ? name.substring(0, name.length() - ".class".length()) : name;
/*      */         
/* 2191 */         internalName = className.replace(".", "/");
/*      */         
/* 2193 */         for (ClassFileTransformer transformer : this.transformers) {
/*      */           try {
/* 2195 */             byte[] transformed = transformer.transform(this, internalName, null, null, binaryContent);
/*      */             
/* 2197 */             if (transformed != null) {
/* 2198 */               binaryContent = transformed;
/*      */             }
/*      */           } catch (IllegalClassFormatException e) {
/* 2201 */             log.error(sm.getString("webappClassLoader.transformError", new Object[] { name }), e);
/* 2202 */             return null;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 2208 */       String packageName = null;
/* 2209 */       int pos = name.lastIndexOf('.');
/* 2210 */       if (pos != -1) {
/* 2211 */         packageName = name.substring(0, pos);
/*      */       }
/* 2213 */       Package pkg = null;
/*      */       
/* 2215 */       if (packageName != null) {
/* 2216 */         pkg = getPackage(packageName);
/*      */         
/* 2218 */         if (pkg == null) {
/*      */           try {
/* 2220 */             if (manifest == null) {
/* 2221 */               definePackage(packageName, null, null, null, null, null, null, null);
/*      */             } else {
/* 2223 */               definePackage(packageName, manifest, codeBase);
/*      */             }
/*      */           }
/*      */           catch (IllegalArgumentException localIllegalArgumentException) {}
/*      */           
/* 2228 */           pkg = getPackage(packageName);
/*      */         }
/*      */       }
/*      */       
/* 2232 */       if (this.securityManager != null)
/*      */       {
/*      */ 
/* 2235 */         if (pkg != null) {
/* 2236 */           boolean sealCheck = true;
/* 2237 */           if (pkg.isSealed()) {
/* 2238 */             sealCheck = pkg.isSealed(codeBase);
/*      */           } else {
/* 2240 */             sealCheck = (manifest == null) || (!isPackageSealed(packageName, manifest));
/*      */           }
/* 2242 */           if (!sealCheck) {
/* 2243 */             throw new SecurityException("Sealing violation loading " + name + " : Package " + packageName + " is sealed.");
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */       try
/*      */       {
/* 2251 */         clazz = defineClass(name, binaryContent, 0, binaryContent.length, new CodeSource(codeBase, certificates));
/*      */       }
/*      */       catch (UnsupportedClassVersionError ucve) {
/* 2254 */         throw new UnsupportedClassVersionError(ucve.getLocalizedMessage() + " " + sm.getString("webappClassLoader.wrongVersion", new Object[] { name }));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2259 */       entry.loadedClass = clazz;
/*      */     }
/*      */     
/* 2262 */     return clazz;
/*      */   }
/*      */   
/*      */ 
/*      */   private String binaryNameToPath(String binaryName, boolean withLeadingSlash)
/*      */   {
/* 2268 */     StringBuilder path = new StringBuilder(7 + binaryName.length());
/* 2269 */     if (withLeadingSlash) {
/* 2270 */       path.append('/');
/*      */     }
/* 2272 */     path.append(binaryName.replace('.', '/'));
/* 2273 */     path.append(".class");
/* 2274 */     return path.toString();
/*      */   }
/*      */   
/*      */   private String nameToPath(String name)
/*      */   {
/* 2279 */     if (name.startsWith("/")) {
/* 2280 */       return name;
/*      */     }
/* 2282 */     StringBuilder path = new StringBuilder(1 + name.length());
/*      */     
/* 2284 */     path.append('/');
/* 2285 */     path.append(name);
/* 2286 */     return path.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isPackageSealed(String name, Manifest man)
/*      */   {
/* 2300 */     String path = name.replace('.', '/') + '/';
/* 2301 */     Attributes attr = man.getAttributes(path);
/* 2302 */     String sealed = null;
/* 2303 */     if (attr != null) {
/* 2304 */       sealed = attr.getValue(Attributes.Name.SEALED);
/*      */     }
/* 2306 */     if ((sealed == null) && 
/* 2307 */       ((attr = man.getMainAttributes()) != null)) {
/* 2308 */       sealed = attr.getValue(Attributes.Name.SEALED);
/*      */     }
/*      */     
/* 2311 */     return "true".equalsIgnoreCase(sealed);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Class<?> findLoadedClass0(String name)
/*      */   {
/* 2326 */     String path = binaryNameToPath(name, true);
/*      */     
/* 2328 */     ResourceEntry entry = (ResourceEntry)this.resourceEntries.get(path);
/* 2329 */     if (entry != null) {
/* 2330 */       return entry.loadedClass;
/*      */     }
/* 2332 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void refreshPolicy()
/*      */   {
/*      */     try
/*      */     {
/* 2345 */       Policy policy = Policy.getPolicy();
/* 2346 */       policy.refresh();
/*      */     }
/*      */     catch (AccessControlException localAccessControlException) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean filter(String name, boolean isClassName)
/*      */   {
/* 2365 */     if (name == null) {
/* 2366 */       return false;
/*      */     }
/*      */     
/* 2369 */     if (name.startsWith("javax"))
/*      */     {
/* 2371 */       if (name.length() == 5) {
/* 2372 */         return false;
/*      */       }
/* 2374 */       char ch = name.charAt(5);
/* 2375 */       if ((isClassName) && (ch == '.'))
/*      */       {
/* 2377 */         if (name.startsWith("servlet.jsp.jstl.", 6)) {
/* 2378 */           return false;
/*      */         }
/* 2380 */         if ((name.startsWith("el.", 6)) || (name.startsWith("servlet.", 6)) || (name.startsWith("websocket.", 6)) || (name.startsWith("security.auth.message.", 6)))
/*      */         {
/*      */ 
/*      */ 
/* 2384 */           return true;
/*      */         }
/* 2386 */       } else if ((!isClassName) && (ch == '/'))
/*      */       {
/* 2388 */         if (name.startsWith("servlet/jsp/jstl/", 6)) {
/* 2389 */           return false;
/*      */         }
/* 2391 */         if ((name.startsWith("el/", 6)) || (name.startsWith("servlet/", 6)) || (name.startsWith("websocket/", 6)) || (name.startsWith("security/auth/message/", 6)))
/*      */         {
/*      */ 
/*      */ 
/* 2395 */           return true;
/*      */         }
/*      */       }
/* 2398 */     } else if (name.startsWith("org"))
/*      */     {
/* 2400 */       if (name.length() == 3) {
/* 2401 */         return false;
/*      */       }
/* 2403 */       char ch = name.charAt(3);
/* 2404 */       if ((isClassName) && (ch == '.'))
/*      */       {
/* 2406 */         if (name.startsWith("apache.", 4))
/*      */         {
/* 2408 */           if (name.startsWith("tomcat.jdbc.", 11)) {
/* 2409 */             return false;
/*      */           }
/* 2411 */           if ((name.startsWith("el.", 11)) || (name.startsWith("catalina.", 11)) || (name.startsWith("jasper.", 11)) || (name.startsWith("juli.", 11)) || (name.startsWith("tomcat.", 11)) || (name.startsWith("naming.", 11)) || (name.startsWith("coyote.", 11)))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2418 */             return true;
/*      */           }
/*      */         }
/* 2421 */       } else if ((!isClassName) && (ch == '/'))
/*      */       {
/* 2423 */         if (name.startsWith("apache/", 4))
/*      */         {
/* 2425 */           if (name.startsWith("tomcat/jdbc/", 11)) {
/* 2426 */             return false;
/*      */           }
/* 2428 */           if ((name.startsWith("el/", 11)) || (name.startsWith("catalina/", 11)) || (name.startsWith("jasper/", 11)) || (name.startsWith("juli/", 11)) || (name.startsWith("tomcat/", 11)) || (name.startsWith("naming/", 11)) || (name.startsWith("coyote/", 11)))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2435 */             return true;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 2440 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected boolean filter(String name)
/*      */   {
/* 2454 */     return (filter(name, true)) || (filter(name, false));
/*      */   }
/*      */   
/*      */ 
/*      */   protected void addURL(URL url)
/*      */   {
/* 2460 */     super.addURL(url);
/* 2461 */     this.hasExternalRepositories = true;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getWebappName()
/*      */   {
/* 2467 */     return getContextName();
/*      */   }
/*      */   
/*      */ 
/*      */   public String getHostName()
/*      */   {
/* 2473 */     if (this.resources != null) {
/* 2474 */       Container host = this.resources.getContext().getParent();
/* 2475 */       if (host != null) {
/* 2476 */         return host.getName();
/*      */       }
/*      */     }
/* 2479 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getServiceName()
/*      */   {
/* 2485 */     if (this.resources != null) {
/* 2486 */       Container host = this.resources.getContext().getParent();
/* 2487 */       if (host != null) {
/* 2488 */         Container engine = host.getParent();
/* 2489 */         if (engine != null) {
/* 2490 */           return engine.getName();
/*      */         }
/*      */       }
/*      */     }
/* 2494 */     return null;
/*      */   }
/*      */   
/*      */   public void addLifecycleListener(LifecycleListener listener) {}
/*      */   
/*      */   public void removeLifecycleListener(LifecycleListener listener) {}
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\loader\WebappClassLoaderBase.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */