/*     */ package org.apache.catalina.loader;
/*     */ 
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import java.io.File;
/*     */ import java.io.FilePermission;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.net.URLDecoder;
/*     */ import javax.management.ObjectName;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.Lifecycle;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Loader;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.catalina.util.LifecycleMBeanBase;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebappLoader
/*     */   extends LifecycleMBeanBase
/*     */   implements Loader, PropertyChangeListener
/*     */ {
/*     */   public WebappLoader()
/*     */   {
/*  74 */     this(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WebappLoader(ClassLoader parent)
/*     */   {
/*  86 */     this.parentClassLoader = parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  95 */   private WebappClassLoaderBase classLoader = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */   private Context context = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 108 */   private boolean delegate = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 116 */   private String loaderClass = ParallelWebappClassLoader.class.getName();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 122 */   private ClassLoader parentClassLoader = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 128 */   private boolean reloadable = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 134 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.loader");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 141 */   protected final PropertyChangeSupport support = new PropertyChangeSupport(this);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 147 */   private String classpath = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClassLoader getClassLoader()
/*     */   {
/* 157 */     return this.classLoader;
/*     */   }
/*     */   
/*     */ 
/*     */   public Context getContext()
/*     */   {
/* 163 */     return this.context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setContext(Context context)
/*     */   {
/* 170 */     if (this.context == context) {
/* 171 */       return;
/*     */     }
/*     */     
/* 174 */     if (getState().isAvailable()) {
/* 175 */       throw new IllegalStateException(sm.getString("webappLoader.setContext.ise"));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 180 */     if (this.context != null) {
/* 181 */       this.context.removePropertyChangeListener(this);
/*     */     }
/*     */     
/*     */ 
/* 185 */     Context oldContext = this.context;
/* 186 */     this.context = context;
/* 187 */     this.support.firePropertyChange("context", oldContext, this.context);
/*     */     
/*     */ 
/* 190 */     if (this.context != null) {
/* 191 */       setReloadable(this.context.getReloadable());
/* 192 */       this.context.addPropertyChangeListener(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getDelegate()
/*     */   {
/* 203 */     return this.delegate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDelegate(boolean delegate)
/*     */   {
/* 215 */     boolean oldDelegate = this.delegate;
/* 216 */     this.delegate = delegate;
/* 217 */     this.support.firePropertyChange("delegate", Boolean.valueOf(oldDelegate), Boolean.valueOf(this.delegate));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLoaderClass()
/*     */   {
/* 226 */     return this.loaderClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLoaderClass(String loaderClass)
/*     */   {
/* 236 */     this.loaderClass = loaderClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getReloadable()
/*     */   {
/* 245 */     return this.reloadable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReloadable(boolean reloadable)
/*     */   {
/* 257 */     boolean oldReloadable = this.reloadable;
/* 258 */     this.reloadable = reloadable;
/* 259 */     this.support.firePropertyChange("reloadable", Boolean.valueOf(oldReloadable), Boolean.valueOf(this.reloadable));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addPropertyChangeListener(PropertyChangeListener listener)
/*     */   {
/* 275 */     this.support.addPropertyChangeListener(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void backgroundProcess()
/*     */   {
/* 287 */     if ((this.reloadable) && (modified())) {
/*     */       try {
/* 289 */         Thread.currentThread().setContextClassLoader(WebappLoader.class.getClassLoader());
/*     */         
/* 291 */         if (this.context != null) {
/* 292 */           this.context.reload();
/*     */         }
/*     */       } finally {
/* 295 */         if ((this.context != null) && (this.context.getLoader() != null)) {
/* 296 */           Thread.currentThread().setContextClassLoader(this.context.getLoader().getClassLoader());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String[] getLoaderRepositories()
/*     */   {
/* 305 */     if (this.classLoader == null) {
/* 306 */       return new String[0];
/*     */     }
/* 308 */     URL[] urls = this.classLoader.getURLs();
/* 309 */     String[] result = new String[urls.length];
/* 310 */     for (int i = 0; i < urls.length; i++) {
/* 311 */       result[i] = urls[i].toExternalForm();
/*     */     }
/* 313 */     return result;
/*     */   }
/*     */   
/*     */   public String getLoaderRepositoriesString() {
/* 317 */     String[] repositories = getLoaderRepositories();
/* 318 */     StringBuilder sb = new StringBuilder();
/* 319 */     for (int i = 0; i < repositories.length; i++) {
/* 320 */       sb.append(repositories[i]).append(":");
/*     */     }
/* 322 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getClasspath()
/*     */   {
/* 333 */     return this.classpath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean modified()
/*     */   {
/* 343 */     return this.classLoader != null ? this.classLoader.modified() : false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removePropertyChangeListener(PropertyChangeListener listener)
/*     */   {
/* 354 */     this.support.removePropertyChangeListener(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 363 */     StringBuilder sb = new StringBuilder("WebappLoader[");
/* 364 */     if (this.context != null)
/* 365 */       sb.append(this.context.getName());
/* 366 */     sb.append("]");
/* 367 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 381 */     if (log.isDebugEnabled()) {
/* 382 */       log.debug(sm.getString("webappLoader.starting"));
/*     */     }
/* 384 */     if (this.context.getResources() == null) {
/* 385 */       log.info("No resources for " + this.context);
/* 386 */       setState(LifecycleState.STARTING);
/* 387 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 393 */       this.classLoader = createClassLoader();
/* 394 */       this.classLoader.setResources(this.context.getResources());
/* 395 */       this.classLoader.setDelegate(this.delegate);
/*     */       
/*     */ 
/* 398 */       setClassPath();
/*     */       
/* 400 */       setPermissions();
/*     */       
/* 402 */       this.classLoader.start();
/*     */       
/* 404 */       String contextName = this.context.getName();
/* 405 */       if (!contextName.startsWith("/")) {
/* 406 */         contextName = "/" + contextName;
/*     */       }
/* 408 */       ObjectName cloname = new ObjectName(this.context.getDomain() + ":type=" + this.classLoader.getClass().getSimpleName() + ",host=" + this.context.getParent().getName() + ",context=" + contextName);
/*     */       
/*     */ 
/* 411 */       Registry.getRegistry(null, null).registerComponent(this.classLoader, cloname, null);
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 415 */       t = ExceptionUtils.unwrapInvocationTargetException(t);
/* 416 */       ExceptionUtils.handleThrowable(t);
/* 417 */       log.error("LifecycleException ", t);
/* 418 */       throw new LifecycleException("start: ", t);
/*     */     }
/*     */     
/* 421 */     setState(LifecycleState.STARTING);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void stopInternal()
/*     */     throws LifecycleException
/*     */   {
/* 435 */     if (log.isDebugEnabled()) {
/* 436 */       log.debug(sm.getString("webappLoader.stopping"));
/*     */     }
/* 438 */     setState(LifecycleState.STOPPING);
/*     */     
/*     */ 
/* 441 */     ServletContext servletContext = this.context.getServletContext();
/* 442 */     servletContext.removeAttribute("org.apache.catalina.jsp_classpath");
/*     */     
/*     */ 
/* 445 */     if (this.classLoader != null) {
/*     */       try {
/* 447 */         this.classLoader.stop();
/*     */       } finally {
/* 449 */         this.classLoader.destroy();
/*     */       }
/*     */       
/*     */       try
/*     */       {
/* 454 */         String contextName = this.context.getName();
/* 455 */         if (!contextName.startsWith("/")) {
/* 456 */           contextName = "/" + contextName;
/*     */         }
/* 458 */         ObjectName cloname = new ObjectName(this.context.getDomain() + ":type=" + this.classLoader.getClass().getSimpleName() + ",host=" + this.context.getParent().getName() + ",context=" + contextName);
/*     */         
/*     */ 
/* 461 */         Registry.getRegistry(null, null).unregisterComponent(cloname);
/*     */       } catch (Exception e) {
/* 463 */         log.error("LifecycleException ", e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 468 */     this.classLoader = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void propertyChange(PropertyChangeEvent event)
/*     */   {
/* 484 */     if (!(event.getSource() instanceof Context)) {
/* 485 */       return;
/*     */     }
/*     */     
/* 488 */     if (event.getPropertyName().equals("reloadable")) {
/*     */       try {
/* 490 */         setReloadable(((Boolean)event.getNewValue()).booleanValue());
/*     */       }
/*     */       catch (NumberFormatException e) {
/* 493 */         log.error(sm.getString("webappLoader.reloadable", new Object[] { event.getNewValue().toString() }));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private WebappClassLoaderBase createClassLoader()
/*     */     throws Exception
/*     */   {
/* 508 */     Class<?> clazz = Class.forName(this.loaderClass);
/* 509 */     WebappClassLoaderBase classLoader = null;
/*     */     
/* 511 */     if (this.parentClassLoader == null) {
/* 512 */       this.parentClassLoader = this.context.getParentClassLoader();
/*     */     }
/* 514 */     Class<?>[] argTypes = { ClassLoader.class };
/* 515 */     Object[] args = { this.parentClassLoader };
/* 516 */     Constructor<?> constr = clazz.getConstructor(argTypes);
/* 517 */     classLoader = (WebappClassLoaderBase)constr.newInstance(args);
/*     */     
/* 519 */     return classLoader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setPermissions()
/*     */   {
/* 528 */     if (!Globals.IS_SECURITY_ENABLED)
/* 529 */       return;
/* 530 */     if (this.context == null) {
/* 531 */       return;
/*     */     }
/*     */     
/* 534 */     ServletContext servletContext = this.context.getServletContext();
/*     */     
/*     */ 
/* 537 */     File workDir = (File)servletContext.getAttribute("javax.servlet.context.tempdir");
/*     */     
/* 539 */     if (workDir != null) {
/*     */       try {
/* 541 */         String workDirPath = workDir.getCanonicalPath();
/* 542 */         this.classLoader.addPermission(new FilePermission(workDirPath, "read,write"));
/*     */         
/* 544 */         this.classLoader.addPermission(new FilePermission(workDirPath + File.separator + "-", "read,write,delete"));
/*     */       }
/*     */       catch (IOException localIOException) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 552 */     for (URL url : this.context.getResources().getBaseUrls()) {
/* 553 */       this.classLoader.addPermission(url);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setClassPath()
/*     */   {
/* 565 */     if (this.context == null)
/* 566 */       return;
/* 567 */     ServletContext servletContext = this.context.getServletContext();
/* 568 */     if (servletContext == null) {
/* 569 */       return;
/*     */     }
/* 571 */     StringBuilder classpath = new StringBuilder();
/*     */     
/*     */ 
/* 574 */     ClassLoader loader = getClassLoader();
/*     */     
/* 576 */     if ((this.delegate) && (loader != null))
/*     */     {
/* 578 */       loader = loader.getParent();
/*     */     }
/*     */     
/* 581 */     while ((loader != null) && 
/* 582 */       (buildClassPath(classpath, loader)))
/*     */     {
/*     */ 
/* 585 */       loader = loader.getParent();
/*     */     }
/*     */     
/* 588 */     if (this.delegate)
/*     */     {
/* 590 */       loader = getClassLoader();
/* 591 */       if (loader != null) {
/* 592 */         buildClassPath(classpath, loader);
/*     */       }
/*     */     }
/*     */     
/* 596 */     this.classpath = classpath.toString();
/*     */     
/*     */ 
/* 599 */     servletContext.setAttribute("org.apache.catalina.jsp_classpath", this.classpath);
/*     */   }
/*     */   
/*     */   private boolean buildClassPath(StringBuilder classpath, ClassLoader loader)
/*     */   {
/* 604 */     if ((loader instanceof URLClassLoader)) {
/* 605 */       URL[] repositories = ((URLClassLoader)loader).getURLs();
/* 606 */       for (int i = 0; i < repositories.length; i++) {
/* 607 */         String repository = repositories[i].toString();
/* 608 */         if (repository.startsWith("file://")) {
/* 609 */           repository = utf8Decode(repository.substring(7));
/* 610 */         } else { if (!repository.startsWith("file:")) continue;
/* 611 */           repository = utf8Decode(repository.substring(5));
/*     */         }
/*     */         
/* 614 */         if (repository != null)
/*     */         {
/* 616 */           if (classpath.length() > 0)
/* 617 */             classpath.append(File.pathSeparator);
/* 618 */           classpath.append(repository);
/*     */         }
/* 620 */       } } else { if (loader == ClassLoader.getSystemClassLoader())
/*     */       {
/*     */ 
/* 623 */         String cp = System.getProperty("java.class.path");
/* 624 */         if ((cp != null) && (cp.length() > 0)) {
/* 625 */           if (classpath.length() > 0) {
/* 626 */             classpath.append(File.pathSeparator);
/*     */           }
/* 628 */           classpath.append(cp);
/*     */         }
/* 630 */         return false;
/*     */       }
/* 632 */       log.info("Unknown loader " + loader + " " + loader.getClass());
/* 633 */       return false;
/*     */     }
/* 635 */     return true;
/*     */   }
/*     */   
/*     */   private String utf8Decode(String input) {
/* 639 */     String result = null;
/*     */     try {
/* 641 */       result = URLDecoder.decode(input, "UTF-8");
/*     */     }
/*     */     catch (UnsupportedEncodingException localUnsupportedEncodingException) {}
/*     */     
/* 645 */     return result;
/*     */   }
/*     */   
/*     */ 
/* 649 */   private static final Log log = LogFactory.getLog(WebappLoader.class);
/*     */   
/*     */ 
/*     */   protected String getDomainInternal()
/*     */   {
/* 654 */     return this.context.getDomain();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String getObjectNameKeyProperties()
/*     */   {
/* 661 */     StringBuilder name = new StringBuilder("type=Loader");
/*     */     
/* 663 */     name.append(",host=");
/* 664 */     name.append(this.context.getParent().getName());
/*     */     
/* 666 */     name.append(",context=");
/*     */     
/* 668 */     String contextName = this.context.getName();
/* 669 */     if (!contextName.startsWith("/")) {
/* 670 */       name.append("/");
/*     */     }
/* 672 */     name.append(contextName);
/*     */     
/* 674 */     return name.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\loader\WebappLoader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */