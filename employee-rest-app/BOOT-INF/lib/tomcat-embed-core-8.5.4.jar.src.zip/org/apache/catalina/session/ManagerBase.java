/*      */ package org.apache.catalina.session;
/*      */ 
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.Deque;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import java.util.regex.PatternSyntaxException;
/*      */ import javax.servlet.http.HttpSession;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.Lifecycle;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.catalina.SessionIdGenerator;
/*      */ import org.apache.catalina.util.LifecycleMBeanBase;
/*      */ import org.apache.catalina.util.SessionIdGeneratorBase;
/*      */ import org.apache.catalina.util.StandardSessionIdGenerator;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class ManagerBase
/*      */   extends LifecycleMBeanBase
/*      */   implements Manager
/*      */ {
/*   64 */   private final Log log = LogFactory.getLog(ManagerBase.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Context context;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final String name = "ManagerBase";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   87 */   protected String secureRandomClass = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   98 */   protected String secureRandomAlgorithm = "SHA1PRNG";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  108 */   protected String secureRandomProvider = null;
/*      */   
/*  110 */   protected SessionIdGenerator sessionIdGenerator = null;
/*  111 */   protected Class<? extends SessionIdGenerator> sessionIdGeneratorClass = null;
/*      */   
/*      */ 
/*      */   protected volatile int sessionMaxAliveTime;
/*      */   
/*      */ 
/*  117 */   private final Object sessionMaxAliveTimeUpdateLock = new Object();
/*      */   
/*      */ 
/*      */   protected static final int TIMING_STATS_CACHE_SIZE = 100;
/*      */   
/*  122 */   protected final Deque<SessionTiming> sessionCreationTiming = new LinkedList();
/*      */   
/*      */ 
/*  125 */   protected final Deque<SessionTiming> sessionExpirationTiming = new LinkedList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  131 */   protected final AtomicLong expiredSessions = new AtomicLong(0L);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  138 */   protected Map<String, Session> sessions = new ConcurrentHashMap();
/*      */   
/*      */ 
/*  141 */   protected long sessionCounter = 0L;
/*      */   
/*  143 */   protected volatile int maxActive = 0;
/*      */   
/*  145 */   private final Object maxActiveUpdateLock = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  150 */   protected int maxActiveSessions = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  155 */   protected int rejectedSessions = 0;
/*      */   
/*      */ 
/*  158 */   protected volatile int duplicates = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  163 */   protected long processingTime = 0L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  168 */   private int count = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  177 */   protected int processExpiresFrequency = 6;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  182 */   protected static final StringManager sm = StringManager.getManager(ManagerBase.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  187 */   protected final PropertyChangeSupport support = new PropertyChangeSupport(this);
/*      */   
/*      */ 
/*      */   private Pattern sessionAttributeNamePattern;
/*      */   
/*      */ 
/*      */   private Pattern sessionAttributeValueClassNamePattern;
/*      */   
/*      */   private boolean warnOnSessionAttributeFilterFailure;
/*      */   
/*      */ 
/*      */   public ManagerBase()
/*      */   {
/*  200 */     if (Globals.IS_SECURITY_ENABLED)
/*      */     {
/*      */ 
/*  203 */       setSessionAttributeValueClassNameFilter("java\\.lang\\.(?:Boolean|Integer|Long|Number|String)");
/*      */       
/*  205 */       setWarnOnSessionAttributeFilterFailure(true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionAttributeNameFilter()
/*      */   {
/*  223 */     if (this.sessionAttributeNamePattern == null) {
/*  224 */       return null;
/*      */     }
/*  226 */     return this.sessionAttributeNamePattern.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionAttributeNameFilter(String sessionAttributeNameFilter)
/*      */     throws PatternSyntaxException
/*      */   {
/*  244 */     if ((sessionAttributeNameFilter == null) || (sessionAttributeNameFilter.length() == 0)) {
/*  245 */       this.sessionAttributeNamePattern = null;
/*      */     } else {
/*  247 */       this.sessionAttributeNamePattern = Pattern.compile(sessionAttributeNameFilter);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Pattern getSessionAttributeNamePattern()
/*      */   {
/*  260 */     return this.sessionAttributeNamePattern;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionAttributeValueClassNameFilter()
/*      */   {
/*  275 */     if (this.sessionAttributeValueClassNamePattern == null) {
/*  276 */       return null;
/*      */     }
/*  278 */     return this.sessionAttributeValueClassNamePattern.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Pattern getSessionAttributeValueClassNamePattern()
/*      */   {
/*  291 */     return this.sessionAttributeValueClassNamePattern;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionAttributeValueClassNameFilter(String sessionAttributeValueClassNameFilter)
/*      */     throws PatternSyntaxException
/*      */   {
/*  310 */     if ((sessionAttributeValueClassNameFilter == null) || (sessionAttributeValueClassNameFilter.length() == 0))
/*      */     {
/*  312 */       this.sessionAttributeValueClassNamePattern = null;
/*      */     } else {
/*  314 */       this.sessionAttributeValueClassNamePattern = Pattern.compile(sessionAttributeValueClassNameFilter);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getWarnOnSessionAttributeFilterFailure()
/*      */   {
/*  327 */     return this.warnOnSessionAttributeFilterFailure;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWarnOnSessionAttributeFilterFailure(boolean warnOnSessionAttributeFilterFailure)
/*      */   {
/*  341 */     this.warnOnSessionAttributeFilterFailure = warnOnSessionAttributeFilterFailure;
/*      */   }
/*      */   
/*      */ 
/*      */   public Context getContext()
/*      */   {
/*  347 */     return this.context;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setContext(Context context)
/*      */   {
/*  353 */     if (this.context == context)
/*      */     {
/*  355 */       return;
/*      */     }
/*  357 */     if (!getState().equals(LifecycleState.NEW)) {
/*  358 */       throw new IllegalStateException(sm.getString("managerBase.setContextNotNew"));
/*      */     }
/*  360 */     Context oldContext = this.context;
/*  361 */     this.context = context;
/*  362 */     this.support.firePropertyChange("context", oldContext, this.context);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getClassName()
/*      */   {
/*  370 */     return getClass().getName();
/*      */   }
/*      */   
/*      */ 
/*      */   public SessionIdGenerator getSessionIdGenerator()
/*      */   {
/*  376 */     if (this.sessionIdGenerator != null)
/*  377 */       return this.sessionIdGenerator;
/*  378 */     if (this.sessionIdGeneratorClass != null) {
/*      */       try {
/*  380 */         this.sessionIdGenerator = ((SessionIdGenerator)this.sessionIdGeneratorClass.newInstance());
/*  381 */         return this.sessionIdGenerator;
/*      */       }
/*      */       catch (IllegalAccessException localIllegalAccessException) {}catch (InstantiationException localInstantiationException) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  388 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setSessionIdGenerator(SessionIdGenerator sessionIdGenerator)
/*      */   {
/*  394 */     this.sessionIdGenerator = sessionIdGenerator;
/*  395 */     this.sessionIdGeneratorClass = sessionIdGenerator.getClass();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getName()
/*      */   {
/*  404 */     return "ManagerBase";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSecureRandomClass()
/*      */   {
/*  413 */     return this.secureRandomClass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecureRandomClass(String secureRandomClass)
/*      */   {
/*  426 */     String oldSecureRandomClass = this.secureRandomClass;
/*  427 */     this.secureRandomClass = secureRandomClass;
/*  428 */     this.support.firePropertyChange("secureRandomClass", oldSecureRandomClass, this.secureRandomClass);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSecureRandomAlgorithm()
/*      */   {
/*  438 */     return this.secureRandomAlgorithm;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecureRandomAlgorithm(String secureRandomAlgorithm)
/*      */   {
/*  449 */     this.secureRandomAlgorithm = secureRandomAlgorithm;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSecureRandomProvider()
/*      */   {
/*  457 */     return this.secureRandomProvider;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecureRandomProvider(String secureRandomProvider)
/*      */   {
/*  468 */     this.secureRandomProvider = secureRandomProvider;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getRejectedSessions()
/*      */   {
/*  474 */     return this.rejectedSessions;
/*      */   }
/*      */   
/*      */ 
/*      */   public long getExpiredSessions()
/*      */   {
/*  480 */     return this.expiredSessions.get();
/*      */   }
/*      */   
/*      */ 
/*      */   public void setExpiredSessions(long expiredSessions)
/*      */   {
/*  486 */     this.expiredSessions.set(expiredSessions);
/*      */   }
/*      */   
/*      */   public long getProcessingTime() {
/*  490 */     return this.processingTime;
/*      */   }
/*      */   
/*      */   public void setProcessingTime(long processingTime)
/*      */   {
/*  495 */     this.processingTime = processingTime;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getProcessExpiresFrequency()
/*      */   {
/*  503 */     return this.processExpiresFrequency;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProcessExpiresFrequency(int processExpiresFrequency)
/*      */   {
/*  514 */     if (processExpiresFrequency <= 0) {
/*  515 */       return;
/*      */     }
/*      */     
/*  518 */     int oldProcessExpiresFrequency = this.processExpiresFrequency;
/*  519 */     this.processExpiresFrequency = processExpiresFrequency;
/*  520 */     this.support.firePropertyChange("processExpiresFrequency", Integer.valueOf(oldProcessExpiresFrequency), Integer.valueOf(this.processExpiresFrequency));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void backgroundProcess()
/*      */   {
/*  535 */     this.count = ((this.count + 1) % this.processExpiresFrequency);
/*  536 */     if (this.count == 0) {
/*  537 */       processExpires();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void processExpires()
/*      */   {
/*  545 */     long timeNow = System.currentTimeMillis();
/*  546 */     Session[] sessions = findSessions();
/*  547 */     int expireHere = 0;
/*      */     
/*  549 */     if (this.log.isDebugEnabled())
/*  550 */       this.log.debug("Start expire sessions " + getName() + " at " + timeNow + " sessioncount " + sessions.length);
/*  551 */     for (int i = 0; i < sessions.length; i++) {
/*  552 */       if ((sessions[i] != null) && (!sessions[i].isValid())) {
/*  553 */         expireHere++;
/*      */       }
/*      */     }
/*  556 */     long timeEnd = System.currentTimeMillis();
/*  557 */     if (this.log.isDebugEnabled())
/*  558 */       this.log.debug("End expire sessions " + getName() + " processingTime " + (timeEnd - timeNow) + " expired sessions: " + expireHere);
/*  559 */     this.processingTime += timeEnd - timeNow;
/*      */   }
/*      */   
/*      */ 
/*      */   protected void initInternal()
/*      */     throws LifecycleException
/*      */   {
/*  566 */     super.initInternal();
/*      */     
/*  568 */     if (this.context == null) {
/*  569 */       throw new LifecycleException(sm.getString("managerBase.contextNull"));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void startInternal()
/*      */     throws LifecycleException
/*      */   {
/*  579 */     while (this.sessionCreationTiming.size() < 100) {
/*  580 */       this.sessionCreationTiming.add(null);
/*      */     }
/*  582 */     while (this.sessionExpirationTiming.size() < 100) {
/*  583 */       this.sessionExpirationTiming.add(null);
/*      */     }
/*      */     
/*      */ 
/*  587 */     SessionIdGenerator sessionIdGenerator = getSessionIdGenerator();
/*  588 */     if (sessionIdGenerator == null) {
/*  589 */       sessionIdGenerator = new StandardSessionIdGenerator();
/*  590 */       setSessionIdGenerator(sessionIdGenerator);
/*      */     }
/*      */     
/*  593 */     sessionIdGenerator.setJvmRoute(getJvmRoute());
/*  594 */     if ((sessionIdGenerator instanceof SessionIdGeneratorBase)) {
/*  595 */       SessionIdGeneratorBase sig = (SessionIdGeneratorBase)sessionIdGenerator;
/*  596 */       sig.setSecureRandomAlgorithm(getSecureRandomAlgorithm());
/*  597 */       sig.setSecureRandomClass(getSecureRandomClass());
/*  598 */       sig.setSecureRandomProvider(getSecureRandomProvider());
/*      */     }
/*      */     
/*  601 */     if ((sessionIdGenerator instanceof Lifecycle)) {
/*  602 */       ((Lifecycle)sessionIdGenerator).start();
/*      */     }
/*      */     else {
/*  605 */       if (this.log.isDebugEnabled())
/*  606 */         this.log.debug("Force random number initialization starting");
/*  607 */       sessionIdGenerator.generateSessionId();
/*  608 */       if (this.log.isDebugEnabled()) {
/*  609 */         this.log.debug("Force random number initialization completed");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected void stopInternal() throws LifecycleException
/*      */   {
/*  616 */     if ((this.sessionIdGenerator instanceof Lifecycle)) {
/*  617 */       ((Lifecycle)this.sessionIdGenerator).stop();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void add(Session session)
/*      */   {
/*  624 */     this.sessions.put(session.getIdInternal(), session);
/*  625 */     int size = getActiveSessions();
/*  626 */     if (size > this.maxActive) {
/*  627 */       synchronized (this.maxActiveUpdateLock) {
/*  628 */         if (size > this.maxActive) {
/*  629 */           this.maxActive = size;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void addPropertyChangeListener(PropertyChangeListener listener)
/*      */   {
/*  638 */     this.support.addPropertyChangeListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Session createSession(String sessionId)
/*      */   {
/*  645 */     if ((this.maxActiveSessions >= 0) && (getActiveSessions() >= this.maxActiveSessions))
/*      */     {
/*  647 */       this.rejectedSessions += 1;
/*  648 */       throw new TooManyActiveSessionsException(sm.getString("managerBase.createSession.ise"), this.maxActiveSessions);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  654 */     Session session = createEmptySession();
/*      */     
/*      */ 
/*  657 */     session.setNew(true);
/*  658 */     session.setValid(true);
/*  659 */     session.setCreationTime(System.currentTimeMillis());
/*  660 */     session.setMaxInactiveInterval(getContext().getSessionTimeout() * 60);
/*  661 */     String id = sessionId;
/*  662 */     if (id == null) {
/*  663 */       id = generateSessionId();
/*      */     }
/*  665 */     session.setId(id);
/*  666 */     this.sessionCounter += 1L;
/*      */     
/*  668 */     SessionTiming timing = new SessionTiming(session.getCreationTime(), 0);
/*  669 */     synchronized (this.sessionCreationTiming) {
/*  670 */       this.sessionCreationTiming.add(timing);
/*  671 */       this.sessionCreationTiming.poll();
/*      */     }
/*  673 */     return session;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Session createEmptySession()
/*      */   {
/*  680 */     return getNewSession();
/*      */   }
/*      */   
/*      */   public Session findSession(String id)
/*      */     throws IOException
/*      */   {
/*  686 */     if (id == null) {
/*  687 */       return null;
/*      */     }
/*  689 */     return (Session)this.sessions.get(id);
/*      */   }
/*      */   
/*      */ 
/*      */   public Session[] findSessions()
/*      */   {
/*  695 */     return (Session[])this.sessions.values().toArray(new Session[0]);
/*      */   }
/*      */   
/*      */ 
/*      */   public void remove(Session session)
/*      */   {
/*  701 */     remove(session, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void remove(Session session, boolean update)
/*      */   {
/*  709 */     if (update) {
/*  710 */       long timeNow = System.currentTimeMillis();
/*  711 */       int timeAlive = (int)(timeNow - session.getCreationTimeInternal()) / 1000;
/*      */       
/*  713 */       updateSessionMaxAliveTime(timeAlive);
/*  714 */       this.expiredSessions.incrementAndGet();
/*  715 */       SessionTiming timing = new SessionTiming(timeNow, timeAlive);
/*  716 */       synchronized (this.sessionExpirationTiming) {
/*  717 */         this.sessionExpirationTiming.add(timing);
/*  718 */         this.sessionExpirationTiming.poll();
/*      */       }
/*      */     }
/*      */     
/*  722 */     if (session.getIdInternal() != null) {
/*  723 */       this.sessions.remove(session.getIdInternal());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void removePropertyChangeListener(PropertyChangeListener listener)
/*      */   {
/*  730 */     this.support.removePropertyChangeListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */   public void changeSessionId(Session session)
/*      */   {
/*  736 */     String newId = generateSessionId();
/*  737 */     changeSessionId(session, newId, true, true);
/*      */   }
/*      */   
/*      */ 
/*      */   public void changeSessionId(Session session, String newId)
/*      */   {
/*  743 */     changeSessionId(session, newId, true, true);
/*      */   }
/*      */   
/*      */ 
/*      */   protected void changeSessionId(Session session, String newId, boolean notifySessionListeners, boolean notifyContainerListeners)
/*      */   {
/*  749 */     String oldId = session.getIdInternal();
/*  750 */     session.setId(newId, false);
/*  751 */     session.tellChangedSessionId(newId, oldId, notifySessionListeners, notifyContainerListeners);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean willAttributeDistribute(String name, Object value)
/*      */   {
/*  766 */     Pattern sessionAttributeNamePattern = getSessionAttributeNamePattern();
/*  767 */     if ((sessionAttributeNamePattern != null) && 
/*  768 */       (!sessionAttributeNamePattern.matcher(name).matches())) {
/*  769 */       if ((getWarnOnSessionAttributeFilterFailure()) || (this.log.isDebugEnabled())) {
/*  770 */         String msg = sm.getString("managerBase.sessionAttributeNameFilter", new Object[] { name, sessionAttributeNamePattern });
/*      */         
/*  772 */         if (getWarnOnSessionAttributeFilterFailure()) {
/*  773 */           this.log.warn(msg);
/*      */         } else {
/*  775 */           this.log.debug(msg);
/*      */         }
/*      */       }
/*  778 */       return false;
/*      */     }
/*      */     
/*      */ 
/*  782 */     Pattern sessionAttributeValueClassNamePattern = getSessionAttributeValueClassNamePattern();
/*  783 */     if ((value != null) && (sessionAttributeValueClassNamePattern != null) && 
/*  784 */       (!sessionAttributeValueClassNamePattern.matcher(value.getClass().getName()).matches()))
/*      */     {
/*  786 */       if ((getWarnOnSessionAttributeFilterFailure()) || (this.log.isDebugEnabled())) {
/*  787 */         String msg = sm.getString("managerBase.sessionAttributeValueClassNameFilter", new Object[] { name, value.getClass().getName(), sessionAttributeNamePattern });
/*      */         
/*  789 */         if (getWarnOnSessionAttributeFilterFailure()) {
/*  790 */           this.log.warn(msg);
/*      */         } else {
/*  792 */           this.log.debug(msg);
/*      */         }
/*      */       }
/*  795 */       return false;
/*      */     }
/*      */     
/*      */ 
/*  799 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected StandardSession getNewSession()
/*      */   {
/*  811 */     return new StandardSession(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String generateSessionId()
/*      */   {
/*  821 */     String result = null;
/*      */     do
/*      */     {
/*  824 */       if (result != null)
/*      */       {
/*      */ 
/*      */ 
/*  828 */         this.duplicates += 1;
/*      */       }
/*      */       
/*  831 */       result = this.sessionIdGenerator.generateSessionId();
/*      */     }
/*  833 */     while (this.sessions.containsKey(result));
/*      */     
/*  835 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Engine getEngine()
/*      */   {
/*  848 */     Engine e = null;
/*  849 */     for (Container c = getContext(); (e == null) && (c != null); c = c.getParent()) {
/*  850 */       if ((c instanceof Engine)) {
/*  851 */         e = (Engine)c;
/*      */       }
/*      */     }
/*  854 */     return e;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getJvmRoute()
/*      */   {
/*  863 */     Engine e = getEngine();
/*  864 */     return e == null ? null : e.getJvmRoute();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionCounter(long sessionCounter)
/*      */   {
/*  873 */     this.sessionCounter = sessionCounter;
/*      */   }
/*      */   
/*      */ 
/*      */   public long getSessionCounter()
/*      */   {
/*  879 */     return this.sessionCounter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getDuplicates()
/*      */   {
/*  890 */     return this.duplicates;
/*      */   }
/*      */   
/*      */   public void setDuplicates(int duplicates)
/*      */   {
/*  895 */     this.duplicates = duplicates;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getActiveSessions()
/*      */   {
/*  901 */     return this.sessions.size();
/*      */   }
/*      */   
/*      */ 
/*      */   public int getMaxActive()
/*      */   {
/*  907 */     return this.maxActive;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setMaxActive(int maxActive)
/*      */   {
/*  913 */     synchronized (this.maxActiveUpdateLock) {
/*  914 */       this.maxActive = maxActive;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxActiveSessions()
/*      */   {
/*  925 */     return this.maxActiveSessions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxActiveSessions(int max)
/*      */   {
/*  938 */     int oldMaxActiveSessions = this.maxActiveSessions;
/*  939 */     this.maxActiveSessions = max;
/*  940 */     this.support.firePropertyChange("maxActiveSessions", Integer.valueOf(oldMaxActiveSessions), Integer.valueOf(this.maxActiveSessions));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSessionMaxAliveTime()
/*      */   {
/*  949 */     return this.sessionMaxAliveTime;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setSessionMaxAliveTime(int sessionMaxAliveTime)
/*      */   {
/*  955 */     synchronized (this.sessionMaxAliveTimeUpdateLock) {
/*  956 */       this.sessionMaxAliveTime = sessionMaxAliveTime;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateSessionMaxAliveTime(int sessionAliveTime)
/*      */   {
/*  969 */     if (sessionAliveTime > this.sessionMaxAliveTime) {
/*  970 */       synchronized (this.sessionMaxAliveTimeUpdateLock) {
/*  971 */         if (sessionAliveTime > this.sessionMaxAliveTime) {
/*  972 */           this.sessionMaxAliveTime = sessionAliveTime;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSessionAverageAliveTime()
/*      */   {
/*  987 */     List<SessionTiming> copy = new ArrayList();
/*  988 */     synchronized (this.sessionExpirationTiming) {
/*  989 */       copy.addAll(this.sessionExpirationTiming);
/*      */     }
/*      */     
/*      */ 
/*  993 */     int counter = 0;
/*  994 */     int result = 0;
/*  995 */     Iterator<SessionTiming> iter = copy.iterator();
/*      */     
/*      */ 
/*  998 */     while (iter.hasNext()) {
/*  999 */       SessionTiming timing = (SessionTiming)iter.next();
/* 1000 */       if (timing != null) {
/* 1001 */         int timeAlive = timing.getDuration();
/* 1002 */         counter++;
/*      */         
/* 1004 */         result = result * ((counter - 1) / counter) + timeAlive / counter;
/*      */       }
/*      */     }
/*      */     
/* 1008 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSessionCreateRate()
/*      */   {
/* 1020 */     List<SessionTiming> copy = new ArrayList();
/* 1021 */     synchronized (this.sessionCreationTiming) {
/* 1022 */       copy.addAll(this.sessionCreationTiming);
/*      */     }
/*      */     
/* 1025 */     return calculateRate(copy);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSessionExpireRate()
/*      */   {
/* 1040 */     List<SessionTiming> copy = new ArrayList();
/* 1041 */     synchronized (this.sessionExpirationTiming) {
/* 1042 */       copy.addAll(this.sessionExpirationTiming);
/*      */     }
/*      */     
/* 1045 */     return calculateRate(copy);
/*      */   }
/*      */   
/*      */ 
/*      */   private static int calculateRate(List<SessionTiming> sessionTiming)
/*      */   {
/* 1051 */     long now = System.currentTimeMillis();
/* 1052 */     long oldest = now;
/* 1053 */     int counter = 0;
/* 1054 */     int result = 0;
/* 1055 */     Iterator<SessionTiming> iter = sessionTiming.iterator();
/*      */     
/*      */ 
/* 1058 */     while (iter.hasNext()) {
/* 1059 */       SessionTiming timing = (SessionTiming)iter.next();
/* 1060 */       if (timing != null) {
/* 1061 */         counter++;
/* 1062 */         if (timing.getTimestamp() < oldest) {
/* 1063 */           oldest = timing.getTimestamp();
/*      */         }
/*      */       }
/*      */     }
/* 1067 */     if (counter > 0) {
/* 1068 */       if (oldest < now) {
/* 1069 */         result = 60000 * counter / (int)(now - oldest);
/*      */       }
/*      */       else {
/* 1072 */         result = Integer.MAX_VALUE;
/*      */       }
/*      */     }
/* 1075 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String listSessionIds()
/*      */   {
/* 1085 */     StringBuilder sb = new StringBuilder();
/* 1086 */     Iterator<String> keys = this.sessions.keySet().iterator();
/* 1087 */     while (keys.hasNext()) {
/* 1088 */       sb.append((String)keys.next()).append(" ");
/*      */     }
/* 1090 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionAttribute(String sessionId, String key)
/*      */   {
/* 1104 */     Session s = (Session)this.sessions.get(sessionId);
/* 1105 */     if (s == null) {
/* 1106 */       if (this.log.isInfoEnabled())
/* 1107 */         this.log.info("Session not found " + sessionId);
/* 1108 */       return null;
/*      */     }
/* 1110 */     Object o = s.getSession().getAttribute(key);
/* 1111 */     if (o == null) return null;
/* 1112 */     return o.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HashMap<String, String> getSession(String sessionId)
/*      */   {
/* 1129 */     Session s = (Session)this.sessions.get(sessionId);
/* 1130 */     if (s == null) {
/* 1131 */       if (this.log.isInfoEnabled()) {
/* 1132 */         this.log.info("Session not found " + sessionId);
/*      */       }
/* 1134 */       return null;
/*      */     }
/*      */     
/* 1137 */     Enumeration<String> ee = s.getSession().getAttributeNames();
/* 1138 */     if ((ee == null) || (!ee.hasMoreElements())) {
/* 1139 */       return null;
/*      */     }
/*      */     
/* 1142 */     HashMap<String, String> map = new HashMap();
/* 1143 */     while (ee.hasMoreElements()) {
/* 1144 */       String attrName = (String)ee.nextElement();
/* 1145 */       map.put(attrName, getSessionAttribute(sessionId, attrName));
/*      */     }
/*      */     
/* 1148 */     return map;
/*      */   }
/*      */   
/*      */   public void expireSession(String sessionId)
/*      */   {
/* 1153 */     Session s = (Session)this.sessions.get(sessionId);
/* 1154 */     if (s == null) {
/* 1155 */       if (this.log.isInfoEnabled())
/* 1156 */         this.log.info("Session not found " + sessionId);
/* 1157 */       return;
/*      */     }
/* 1159 */     s.expire();
/*      */   }
/*      */   
/*      */   public long getThisAccessedTimestamp(String sessionId) {
/* 1163 */     Session s = (Session)this.sessions.get(sessionId);
/* 1164 */     if (s == null)
/* 1165 */       return -1L;
/* 1166 */     return s.getThisAccessedTime();
/*      */   }
/*      */   
/*      */   public String getThisAccessedTime(String sessionId) {
/* 1170 */     Session s = (Session)this.sessions.get(sessionId);
/* 1171 */     if (s == null) {
/* 1172 */       if (this.log.isInfoEnabled())
/* 1173 */         this.log.info("Session not found " + sessionId);
/* 1174 */       return "";
/*      */     }
/* 1176 */     return new Date(s.getThisAccessedTime()).toString();
/*      */   }
/*      */   
/*      */   public long getLastAccessedTimestamp(String sessionId) {
/* 1180 */     Session s = (Session)this.sessions.get(sessionId);
/* 1181 */     if (s == null)
/* 1182 */       return -1L;
/* 1183 */     return s.getLastAccessedTime();
/*      */   }
/*      */   
/*      */   public String getLastAccessedTime(String sessionId) {
/* 1187 */     Session s = (Session)this.sessions.get(sessionId);
/* 1188 */     if (s == null) {
/* 1189 */       if (this.log.isInfoEnabled())
/* 1190 */         this.log.info("Session not found " + sessionId);
/* 1191 */       return "";
/*      */     }
/* 1193 */     return new Date(s.getLastAccessedTime()).toString();
/*      */   }
/*      */   
/*      */   public String getCreationTime(String sessionId) {
/* 1197 */     Session s = (Session)this.sessions.get(sessionId);
/* 1198 */     if (s == null) {
/* 1199 */       if (this.log.isInfoEnabled())
/* 1200 */         this.log.info("Session not found " + sessionId);
/* 1201 */       return "";
/*      */     }
/* 1203 */     return new Date(s.getCreationTime()).toString();
/*      */   }
/*      */   
/*      */   public long getCreationTimestamp(String sessionId) {
/* 1207 */     Session s = (Session)this.sessions.get(sessionId);
/* 1208 */     if (s == null)
/* 1209 */       return -1L;
/* 1210 */     return s.getCreationTime();
/*      */   }
/*      */   
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1216 */     StringBuilder sb = new StringBuilder(getClass().getName());
/* 1217 */     sb.append('[');
/* 1218 */     if (this.context == null) {
/* 1219 */       sb.append("Context is null");
/*      */     } else {
/* 1221 */       sb.append(this.context.getName());
/*      */     }
/* 1223 */     sb.append(']');
/* 1224 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getObjectNameKeyProperties()
/*      */   {
/* 1232 */     StringBuilder name = new StringBuilder("type=Manager");
/*      */     
/* 1234 */     name.append(",host=");
/* 1235 */     name.append(this.context.getParent().getName());
/*      */     
/* 1237 */     name.append(",context=");
/* 1238 */     String contextName = this.context.getName();
/* 1239 */     if (!contextName.startsWith("/")) {
/* 1240 */       name.append('/');
/*      */     }
/* 1242 */     name.append(contextName);
/*      */     
/* 1244 */     return name.toString();
/*      */   }
/*      */   
/*      */   public String getDomainInternal()
/*      */   {
/* 1249 */     return this.context.getDomain();
/*      */   }
/*      */   
/*      */ 
/*      */   protected static final class SessionTiming
/*      */   {
/*      */     private final long timestamp;
/*      */     private final int duration;
/*      */     
/*      */     public SessionTiming(long timestamp, int duration)
/*      */     {
/* 1260 */       this.timestamp = timestamp;
/* 1261 */       this.duration = duration;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public long getTimestamp()
/*      */     {
/* 1269 */       return this.timestamp;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public int getDuration()
/*      */     {
/* 1277 */       return this.duration;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\session\ManagerBase.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */