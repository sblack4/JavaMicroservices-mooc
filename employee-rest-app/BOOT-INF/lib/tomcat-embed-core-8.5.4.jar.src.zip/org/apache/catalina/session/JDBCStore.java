/*      */ package org.apache.catalina.session;
/*      */ 
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Driver;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Properties;
/*      */ import javax.naming.InitialContext;
/*      */ import javax.naming.NamingException;
/*      */ import javax.sql.DataSource;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JDBCStore
/*      */   extends StoreBase
/*      */ {
/*   61 */   private String name = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final String storeName = "JDBCStore";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final String threadName = "JDBCStore";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   76 */   protected String connectionName = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   82 */   protected String connectionPassword = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   87 */   protected String connectionURL = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   92 */   private Connection dbConnection = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   97 */   protected Driver driver = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  102 */   protected String driverName = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  107 */   protected String dataSourceName = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  112 */   protected DataSource dataSource = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  120 */   protected String sessionTable = "tomcat$sessions";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  125 */   protected String sessionAppCol = "app";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  130 */   protected String sessionIdCol = "id";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  135 */   protected String sessionDataCol = "data";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  140 */   protected String sessionValidCol = "valid";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  145 */   protected String sessionMaxInactiveCol = "maxinactive";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  150 */   protected String sessionLastAccessedCol = "lastaccess";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  158 */   protected PreparedStatement preparedSizeSql = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  163 */   protected PreparedStatement preparedSaveSql = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  168 */   protected PreparedStatement preparedClearSql = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  173 */   protected PreparedStatement preparedRemoveSql = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  178 */   protected PreparedStatement preparedLoadSql = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getName()
/*      */   {
/*  187 */     if (this.name == null) {
/*  188 */       Container container = this.manager.getContext();
/*  189 */       String contextName = container.getName();
/*  190 */       if (!contextName.startsWith("/")) {
/*  191 */         contextName = "/" + contextName;
/*      */       }
/*  193 */       String hostName = "";
/*  194 */       String engineName = "";
/*      */       
/*  196 */       if (container.getParent() != null) {
/*  197 */         Container host = container.getParent();
/*  198 */         hostName = host.getName();
/*  199 */         if (host.getParent() != null) {
/*  200 */           engineName = host.getParent().getName();
/*      */         }
/*      */       }
/*  203 */       this.name = ("/" + engineName + "/" + hostName + contextName);
/*      */     }
/*  205 */     return this.name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getThreadName()
/*      */   {
/*  212 */     return "JDBCStore";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getStoreName()
/*      */   {
/*  220 */     return "JDBCStore";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDriverName(String driverName)
/*      */   {
/*  229 */     String oldDriverName = this.driverName;
/*  230 */     this.driverName = driverName;
/*  231 */     this.support.firePropertyChange("driverName", oldDriverName, this.driverName);
/*      */     
/*      */ 
/*  234 */     this.driverName = driverName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getDriverName()
/*      */   {
/*  241 */     return this.driverName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getConnectionName()
/*      */   {
/*  248 */     return this.connectionName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectionName(String connectionName)
/*      */   {
/*  257 */     this.connectionName = connectionName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getConnectionPassword()
/*      */   {
/*  264 */     return this.connectionPassword;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectionPassword(String connectionPassword)
/*      */   {
/*  273 */     this.connectionPassword = connectionPassword;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectionURL(String connectionURL)
/*      */   {
/*  282 */     String oldConnString = this.connectionURL;
/*  283 */     this.connectionURL = connectionURL;
/*  284 */     this.support.firePropertyChange("connectionURL", oldConnString, this.connectionURL);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getConnectionURL()
/*      */   {
/*  293 */     return this.connectionURL;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionTable(String sessionTable)
/*      */   {
/*  302 */     String oldSessionTable = this.sessionTable;
/*  303 */     this.sessionTable = sessionTable;
/*  304 */     this.support.firePropertyChange("sessionTable", oldSessionTable, this.sessionTable);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionTable()
/*      */   {
/*  313 */     return this.sessionTable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionAppCol(String sessionAppCol)
/*      */   {
/*  322 */     String oldSessionAppCol = this.sessionAppCol;
/*  323 */     this.sessionAppCol = sessionAppCol;
/*  324 */     this.support.firePropertyChange("sessionAppCol", oldSessionAppCol, this.sessionAppCol);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionAppCol()
/*      */   {
/*  333 */     return this.sessionAppCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionIdCol(String sessionIdCol)
/*      */   {
/*  342 */     String oldSessionIdCol = this.sessionIdCol;
/*  343 */     this.sessionIdCol = sessionIdCol;
/*  344 */     this.support.firePropertyChange("sessionIdCol", oldSessionIdCol, this.sessionIdCol);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionIdCol()
/*      */   {
/*  353 */     return this.sessionIdCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionDataCol(String sessionDataCol)
/*      */   {
/*  362 */     String oldSessionDataCol = this.sessionDataCol;
/*  363 */     this.sessionDataCol = sessionDataCol;
/*  364 */     this.support.firePropertyChange("sessionDataCol", oldSessionDataCol, this.sessionDataCol);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionDataCol()
/*      */   {
/*  373 */     return this.sessionDataCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionValidCol(String sessionValidCol)
/*      */   {
/*  382 */     String oldSessionValidCol = this.sessionValidCol;
/*  383 */     this.sessionValidCol = sessionValidCol;
/*  384 */     this.support.firePropertyChange("sessionValidCol", oldSessionValidCol, this.sessionValidCol);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionValidCol()
/*      */   {
/*  393 */     return this.sessionValidCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionMaxInactiveCol(String sessionMaxInactiveCol)
/*      */   {
/*  402 */     String oldSessionMaxInactiveCol = this.sessionMaxInactiveCol;
/*  403 */     this.sessionMaxInactiveCol = sessionMaxInactiveCol;
/*  404 */     this.support.firePropertyChange("sessionMaxInactiveCol", oldSessionMaxInactiveCol, this.sessionMaxInactiveCol);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionMaxInactiveCol()
/*      */   {
/*  413 */     return this.sessionMaxInactiveCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionLastAccessedCol(String sessionLastAccessedCol)
/*      */   {
/*  422 */     String oldSessionLastAccessedCol = this.sessionLastAccessedCol;
/*  423 */     this.sessionLastAccessedCol = sessionLastAccessedCol;
/*  424 */     this.support.firePropertyChange("sessionLastAccessedCol", oldSessionLastAccessedCol, this.sessionLastAccessedCol);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionLastAccessedCol()
/*      */   {
/*  433 */     return this.sessionLastAccessedCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDataSourceName(String dataSourceName)
/*      */   {
/*  442 */     if ((dataSourceName == null) || ("".equals(dataSourceName.trim()))) {
/*  443 */       this.manager.getContext().getLogger().warn(sm.getString(getStoreName() + ".missingDataSourceName"));
/*      */       
/*  445 */       return;
/*      */     }
/*  447 */     this.dataSourceName = dataSourceName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getDataSourceName()
/*      */   {
/*  454 */     return this.dataSourceName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String[] expiredKeys()
/*      */     throws IOException
/*      */   {
/*  462 */     return keys(true);
/*      */   }
/*      */   
/*      */   public String[] keys() throws IOException
/*      */   {
/*  467 */     return keys(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String[] keys(boolean expiredOnly)
/*      */     throws IOException
/*      */   {
/*  482 */     String[] keys = null;
/*  483 */     synchronized (this) {
/*  484 */       int numberOfTries = 2;
/*  485 */       while (numberOfTries > 0)
/*      */       {
/*  487 */         Connection _conn = getConnection();
/*  488 */         if (_conn == null) {
/*  489 */           return new String[0];
/*      */         }
/*      */         try
/*      */         {
/*  493 */           String keysSql = "SELECT " + this.sessionIdCol + " FROM " + this.sessionTable + " WHERE " + this.sessionAppCol + " = ?";
/*      */           
/*  495 */           if (expiredOnly) {
/*  496 */             keysSql = keysSql + " AND (" + this.sessionLastAccessedCol + " + " + this.sessionMaxInactiveCol + " * 1000 < ?)";
/*      */           }
/*      */           
/*  499 */           PreparedStatement preparedKeysSql = _conn.prepareStatement(keysSql);Throwable localThrowable3 = null;
/*  500 */           try { preparedKeysSql.setString(1, getName());
/*  501 */             if (expiredOnly) {
/*  502 */               preparedKeysSql.setLong(2, System.currentTimeMillis());
/*      */             }
/*  504 */             ResultSet rst = preparedKeysSql.executeQuery();Throwable localThrowable4 = null;
/*  505 */             try { ArrayList<String> tmpkeys = new ArrayList();
/*  506 */               if (rst != null) {
/*  507 */                 while (rst.next()) {
/*  508 */                   tmpkeys.add(rst.getString(1));
/*      */                 }
/*      */               }
/*  511 */               keys = (String[])tmpkeys.toArray(new String[tmpkeys.size()]);
/*      */               
/*  513 */               numberOfTries = 0;
/*      */             }
/*      */             catch (Throwable localThrowable1)
/*      */             {
/*  504 */               localThrowable4 = localThrowable1;throw localThrowable1;
/*      */             }
/*      */             finally {}
/*      */           }
/*      */           catch (Throwable localThrowable2)
/*      */           {
/*  499 */             localThrowable3 = localThrowable2;throw localThrowable2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           finally
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  515 */             if (preparedKeysSql != null) if (localThrowable3 != null) try { preparedKeysSql.close(); } catch (Throwable x2) {} else preparedKeysSql.close();
/*      */           }
/*  517 */         } catch (SQLException e) { this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".SQLException", new Object[] { e }));
/*  518 */           keys = new String[0];
/*      */           
/*  520 */           if (this.dbConnection != null)
/*  521 */             close(this.dbConnection);
/*      */         } finally {
/*  523 */           release(_conn);
/*      */         }
/*  525 */         numberOfTries--;
/*      */       }
/*      */     }
/*  528 */     return keys;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSize()
/*      */     throws IOException
/*      */   {
/*  542 */     int size = 0;
/*      */     
/*  544 */     synchronized (this) {
/*  545 */       int numberOfTries = 2;
/*  546 */       while (numberOfTries > 0) {
/*  547 */         Connection _conn = getConnection();
/*      */         
/*  549 */         if (_conn == null) {
/*  550 */           return size;
/*      */         }
/*      */         try
/*      */         {
/*  554 */           if (this.preparedSizeSql == null) {
/*  555 */             String sizeSql = "SELECT COUNT(" + this.sessionIdCol + ") FROM " + this.sessionTable + " WHERE " + this.sessionAppCol + " = ?";
/*      */             
/*      */ 
/*  558 */             this.preparedSizeSql = _conn.prepareStatement(sizeSql);
/*      */           }
/*      */           
/*  561 */           this.preparedSizeSql.setString(1, getName());
/*  562 */           ResultSet rst = this.preparedSizeSql.executeQuery();Throwable localThrowable2 = null;
/*  563 */           try { if (rst.next()) {
/*  564 */               size = rst.getInt(1);
/*      */             }
/*      */             
/*  567 */             numberOfTries = 0;
/*      */           }
/*      */           catch (Throwable localThrowable1)
/*      */           {
/*  562 */             localThrowable2 = localThrowable1;throw localThrowable1;
/*      */ 
/*      */           }
/*      */           finally
/*      */           {
/*      */ 
/*  568 */             if (rst != null) if (localThrowable2 != null) try { rst.close(); } catch (Throwable x2) {} else rst.close();
/*      */           }
/*  570 */         } catch (SQLException e) { this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".SQLException", new Object[] { e }));
/*  571 */           if (this.dbConnection != null)
/*  572 */             close(this.dbConnection);
/*      */         } finally {
/*  574 */           release(_conn);
/*      */         }
/*  576 */         numberOfTries--;
/*      */       }
/*      */     }
/*  579 */     return size;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Session load(String id)
/*      */     throws ClassNotFoundException, IOException
/*      */   {
/*  593 */     StandardSession _session = null;
/*  594 */     org.apache.catalina.Context context = getManager().getContext();
/*  595 */     Log contextLog = context.getLogger();
/*      */     
/*  597 */     synchronized (this) {
/*  598 */       int numberOfTries = 2;
/*  599 */       while (numberOfTries > 0) {
/*  600 */         Connection _conn = getConnection();
/*  601 */         if (_conn == null) {
/*  602 */           return null;
/*      */         }
/*      */         
/*  605 */         ClassLoader oldThreadContextCL = context.bind(Globals.IS_SECURITY_ENABLED, null);
/*      */         try
/*      */         {
/*  608 */           if (this.preparedLoadSql == null) {
/*  609 */             String loadSql = "SELECT " + this.sessionIdCol + ", " + this.sessionDataCol + " FROM " + this.sessionTable + " WHERE " + this.sessionIdCol + " = ? AND " + this.sessionAppCol + " = ?";
/*      */             
/*      */ 
/*      */ 
/*  613 */             this.preparedLoadSql = _conn.prepareStatement(loadSql);
/*      */           }
/*      */           
/*  616 */           this.preparedLoadSql.setString(1, id);
/*  617 */           this.preparedLoadSql.setString(2, getName());
/*  618 */           ResultSet rst = this.preparedLoadSql.executeQuery();Throwable localThrowable3 = null;
/*  619 */           try { if (rst.next()) {
/*  620 */               ObjectInputStream ois = getObjectInputStream(rst.getBinaryStream(2));Throwable localThrowable4 = null;
/*      */               try {
/*  622 */                 if (contextLog.isDebugEnabled()) {
/*  623 */                   contextLog.debug(sm.getString(getStoreName() + ".loading", new Object[] { id, this.sessionTable }));
/*      */                 }
/*      */                 
/*      */ 
/*  627 */                 _session = (StandardSession)this.manager.createEmptySession();
/*  628 */                 _session.readObjectData(ois);
/*  629 */                 _session.setManager(this.manager);
/*      */               }
/*      */               catch (Throwable localThrowable1)
/*      */               {
/*  620 */                 localThrowable4 = localThrowable1;throw localThrowable1;
/*      */ 
/*      */ 
/*      */ 
/*      */               }
/*      */               finally
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/*  630 */                 if (ois != null) if (localThrowable4 != null) try { ois.close(); } catch (Throwable x2) { localThrowable4.addSuppressed(x2); } else ois.close();
/*  631 */               } } else if (context.getLogger().isDebugEnabled()) {
/*  632 */               contextLog.debug(getStoreName() + ": No persisted data object found");
/*      */             }
/*      */             
/*  635 */             numberOfTries = 0;
/*      */           }
/*      */           catch (Throwable localThrowable2)
/*      */           {
/*  618 */             localThrowable3 = localThrowable2;throw localThrowable2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           finally
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  636 */             if (rst != null) if (localThrowable3 != null) try { rst.close(); } catch (Throwable x2) { localThrowable3.addSuppressed(x2); } else rst.close();
/*      */           }
/*  638 */         } catch (SQLException e) { contextLog.error(sm.getString(getStoreName() + ".SQLException", new Object[] { e }));
/*  639 */           if (this.dbConnection != null)
/*  640 */             close(this.dbConnection);
/*      */         } finally {
/*  642 */           context.unbind(Globals.IS_SECURITY_ENABLED, oldThreadContextCL);
/*  643 */           release(_conn);
/*      */         }
/*  645 */         numberOfTries--;
/*      */       }
/*      */     }
/*      */     
/*  649 */     return _session;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void remove(String id)
/*      */     throws IOException
/*      */   {
/*  664 */     synchronized (this) {
/*  665 */       int numberOfTries = 2;
/*  666 */       while (numberOfTries > 0) {
/*  667 */         Connection _conn = getConnection();
/*      */         
/*  669 */         if (_conn == null) {
/*  670 */           return;
/*      */         }
/*      */         try
/*      */         {
/*  674 */           remove(id, _conn);
/*      */           
/*  676 */           numberOfTries = 0;
/*      */         } catch (SQLException e) {
/*  678 */           this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".SQLException", new Object[] { e }));
/*  679 */           if (this.dbConnection != null)
/*  680 */             close(this.dbConnection);
/*      */         } finally {
/*  682 */           release(_conn);
/*      */         }
/*  684 */         numberOfTries--;
/*      */       }
/*      */     }
/*      */     
/*  688 */     if (this.manager.getContext().getLogger().isDebugEnabled()) {
/*  689 */       this.manager.getContext().getLogger().debug(sm.getString(getStoreName() + ".removing", new Object[] { id, this.sessionTable }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void remove(String id, Connection _conn)
/*      */     throws SQLException
/*      */   {
/*  703 */     if (this.preparedRemoveSql == null) {
/*  704 */       String removeSql = "DELETE FROM " + this.sessionTable + " WHERE " + this.sessionIdCol + " = ?  AND " + this.sessionAppCol + " = ?";
/*      */       
/*      */ 
/*  707 */       this.preparedRemoveSql = _conn.prepareStatement(removeSql);
/*      */     }
/*      */     
/*  710 */     this.preparedRemoveSql.setString(1, id);
/*  711 */     this.preparedRemoveSql.setString(2, getName());
/*  712 */     this.preparedRemoveSql.execute();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clear()
/*      */     throws IOException
/*      */   {
/*  723 */     synchronized (this) {
/*  724 */       int numberOfTries = 2;
/*  725 */       while (numberOfTries > 0) {
/*  726 */         Connection _conn = getConnection();
/*  727 */         if (_conn == null) {
/*  728 */           return;
/*      */         }
/*      */         try
/*      */         {
/*  732 */           if (this.preparedClearSql == null) {
/*  733 */             String clearSql = "DELETE FROM " + this.sessionTable + " WHERE " + this.sessionAppCol + " = ?";
/*      */             
/*  735 */             this.preparedClearSql = _conn.prepareStatement(clearSql);
/*      */           }
/*      */           
/*  738 */           this.preparedClearSql.setString(1, getName());
/*  739 */           this.preparedClearSql.execute();
/*      */           
/*  741 */           numberOfTries = 0;
/*      */         } catch (SQLException e) {
/*  743 */           this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".SQLException", new Object[] { e }));
/*  744 */           if (this.dbConnection != null)
/*  745 */             close(this.dbConnection);
/*      */         } finally {
/*  747 */           release(_conn);
/*      */         }
/*  749 */         numberOfTries--;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void save(Session session)
/*      */     throws IOException
/*      */   {
/*  762 */     ByteArrayOutputStream bos = null;
/*      */     
/*  764 */     synchronized (this) {
/*  765 */       int numberOfTries = 2;
/*  766 */       while (numberOfTries > 0) {
/*  767 */         Connection _conn = getConnection();
/*  768 */         if (_conn == null) {
/*  769 */           return;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/*  776 */           remove(session.getIdInternal(), _conn);
/*      */           
/*  778 */           bos = new ByteArrayOutputStream();
/*  779 */           ObjectOutputStream oos = new ObjectOutputStream(new BufferedOutputStream(bos));Throwable localThrowable4 = null;
/*      */           try {
/*  781 */             ((StandardSession)session).writeObjectData(oos);
/*      */           }
/*      */           catch (Throwable localThrowable1)
/*      */           {
/*  779 */             localThrowable4 = localThrowable1;throw localThrowable1;
/*      */           }
/*      */           finally {
/*  782 */             if (oos != null) if (localThrowable4 != null) try { oos.close(); } catch (Throwable x2) {} else oos.close(); }
/*  783 */           byte[] obs = bos.toByteArray();
/*  784 */           int size = obs.length;
/*  785 */           ByteArrayInputStream bis = new ByteArrayInputStream(obs, 0, size);Throwable localThrowable5 = null;
/*  786 */           try { InputStream in = new BufferedInputStream(bis, size);Throwable localThrowable6 = null;
/*  787 */             try { if (this.preparedSaveSql == null) {
/*  788 */                 String saveSql = "INSERT INTO " + this.sessionTable + " (" + this.sessionIdCol + ", " + this.sessionAppCol + ", " + this.sessionDataCol + ", " + this.sessionValidCol + ", " + this.sessionMaxInactiveCol + ", " + this.sessionLastAccessedCol + ") VALUES (?, ?, ?, ?, ?, ?)";
/*      */                 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  794 */                 this.preparedSaveSql = _conn.prepareStatement(saveSql);
/*      */               }
/*      */               
/*  797 */               this.preparedSaveSql.setString(1, session.getIdInternal());
/*  798 */               this.preparedSaveSql.setString(2, getName());
/*  799 */               this.preparedSaveSql.setBinaryStream(3, in, size);
/*  800 */               this.preparedSaveSql.setString(4, session.isValid() ? "1" : "0");
/*  801 */               this.preparedSaveSql.setInt(5, session.getMaxInactiveInterval());
/*  802 */               this.preparedSaveSql.setLong(6, session.getLastAccessedTime());
/*  803 */               this.preparedSaveSql.execute();
/*      */               
/*  805 */               numberOfTries = 0;
/*      */             }
/*      */             catch (Throwable localThrowable2)
/*      */             {
/*  785 */               localThrowable6 = localThrowable2;throw localThrowable2; } finally {} } catch (Throwable localThrowable3) { localThrowable5 = localThrowable3;throw localThrowable3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           finally
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  806 */             if (bis != null) if (localThrowable5 != null) try { bis.close(); } catch (Throwable x2) {} else bis.close();
/*      */           }
/*  808 */         } catch (SQLException e) { this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".SQLException", new Object[] { e }));
/*  809 */           if (this.dbConnection != null) {
/*  810 */             close(this.dbConnection);
/*      */           }
/*      */         }
/*      */         catch (IOException localIOException) {}finally {
/*  814 */           release(_conn);
/*      */         }
/*  816 */         numberOfTries--;
/*      */       }
/*      */     }
/*      */     
/*  820 */     if (this.manager.getContext().getLogger().isDebugEnabled()) {
/*  821 */       this.manager.getContext().getLogger().debug(sm.getString(getStoreName() + ".saving", new Object[] { session.getIdInternal(), this.sessionTable }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Connection getConnection()
/*      */   {
/*  837 */     Connection conn = null;
/*      */     try {
/*  839 */       conn = open();
/*  840 */       if ((conn == null) || (conn.isClosed())) {
/*  841 */         this.manager.getContext().getLogger().info(sm.getString(getStoreName() + ".checkConnectionDBClosed"));
/*  842 */         conn = open();
/*  843 */         if ((conn == null) || (conn.isClosed())) {
/*  844 */           this.manager.getContext().getLogger().info(sm.getString(getStoreName() + ".checkConnectionDBReOpenFail"));
/*      */         }
/*      */       }
/*      */     } catch (SQLException ex) {
/*  848 */       this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".checkConnectionSQLException", new Object[] { ex.toString() }));
/*      */     }
/*      */     
/*      */ 
/*  852 */     return conn;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Connection open()
/*      */     throws SQLException
/*      */   {
/*  866 */     if (this.dbConnection != null) {
/*  867 */       return this.dbConnection;
/*      */     }
/*  869 */     if ((this.dataSourceName != null) && (this.dataSource == null)) {
/*      */       try
/*      */       {
/*  872 */         javax.naming.Context initCtx = new InitialContext();
/*  873 */         javax.naming.Context envCtx = (javax.naming.Context)initCtx.lookup("java:comp/env");
/*  874 */         this.dataSource = ((DataSource)envCtx.lookup(this.dataSourceName));
/*      */       } catch (NamingException e) {
/*  876 */         this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".wrongDataSource", new Object[] { this.dataSourceName }), e);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  882 */     if (this.dataSource != null) {
/*  883 */       return this.dataSource.getConnection();
/*      */     }
/*      */     
/*      */ 
/*  887 */     if (this.driver == null) {
/*      */       try {
/*  889 */         Class<?> clazz = Class.forName(this.driverName);
/*  890 */         this.driver = ((Driver)clazz.newInstance());
/*      */       } catch (ClassNotFoundException|InstantiationException|IllegalAccessException e) {
/*  892 */         this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".checkConnectionClassNotFoundException", new Object[] { e.toString() }));
/*      */         
/*      */ 
/*  895 */         throw new SQLException(e);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  900 */     Properties props = new Properties();
/*  901 */     if (this.connectionName != null)
/*  902 */       props.put("user", this.connectionName);
/*  903 */     if (this.connectionPassword != null)
/*  904 */       props.put("password", this.connectionPassword);
/*  905 */     this.dbConnection = this.driver.connect(this.connectionURL, props);
/*  906 */     this.dbConnection.setAutoCommit(true);
/*  907 */     return this.dbConnection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void close(Connection dbConnection)
/*      */   {
/*  919 */     if (dbConnection == null) {
/*  920 */       return;
/*      */     }
/*      */     try
/*      */     {
/*  924 */       this.preparedSizeSql.close();
/*      */     } catch (Throwable f) {
/*  926 */       ExceptionUtils.handleThrowable(f);
/*      */     }
/*  928 */     this.preparedSizeSql = null;
/*      */     try
/*      */     {
/*  931 */       this.preparedSaveSql.close();
/*      */     } catch (Throwable f) {
/*  933 */       ExceptionUtils.handleThrowable(f);
/*      */     }
/*  935 */     this.preparedSaveSql = null;
/*      */     try
/*      */     {
/*  938 */       this.preparedClearSql.close();
/*      */     } catch (Throwable f) {
/*  940 */       ExceptionUtils.handleThrowable(f);
/*      */     }
/*      */     try
/*      */     {
/*  944 */       this.preparedRemoveSql.close();
/*      */     } catch (Throwable f) {
/*  946 */       ExceptionUtils.handleThrowable(f);
/*      */     }
/*  948 */     this.preparedRemoveSql = null;
/*      */     try
/*      */     {
/*  951 */       this.preparedLoadSql.close();
/*      */     } catch (Throwable f) {
/*  953 */       ExceptionUtils.handleThrowable(f);
/*      */     }
/*  955 */     this.preparedLoadSql = null;
/*      */     
/*      */     try
/*      */     {
/*  959 */       if (!dbConnection.getAutoCommit()) {
/*  960 */         dbConnection.commit();
/*      */       }
/*      */     } catch (SQLException e) {
/*  963 */       this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".commitSQLException"), e);
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  968 */       dbConnection.close();
/*      */     } catch (SQLException e) {
/*  970 */       this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".close", new Object[] { e.toString() }));
/*      */     } finally {
/*  972 */       this.dbConnection = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void release(Connection conn)
/*      */   {
/*  984 */     if (this.dataSource != null) {
/*  985 */       close(conn);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void startInternal()
/*      */     throws LifecycleException
/*      */   {
/*  999 */     if (this.dataSourceName == null)
/*      */     {
/* 1001 */       this.dbConnection = getConnection();
/*      */     }
/*      */     
/* 1004 */     super.startInternal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void stopInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1017 */     super.stopInternal();
/*      */     
/*      */ 
/* 1020 */     if (this.dbConnection != null) {
/*      */       try {
/* 1022 */         this.dbConnection.commit();
/*      */       }
/*      */       catch (SQLException localSQLException) {}
/*      */       
/* 1026 */       close(this.dbConnection);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\session\JDBCStore.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */