/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.LinkOption;
/*     */ import java.nio.file.attribute.BasicFileAttributes;
/*     */ import java.nio.file.attribute.FileTime;
/*     */ import java.security.cert.Certificate;
/*     */ import java.util.jar.Manifest;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileResource
/*     */   extends AbstractResource
/*     */ {
/*  43 */   private static final Log log = LogFactory.getLog(FileResource.class);
/*     */   private static final boolean PROPERTIES_NEED_CONVERT;
/*     */   
/*     */   static {
/*  47 */     boolean isEBCDIC = false;
/*     */     try {
/*  49 */       String encoding = System.getProperty("file.encoding");
/*  50 */       if (encoding.indexOf("EBCDIC") != -1) {
/*  51 */         isEBCDIC = true;
/*     */       }
/*     */     }
/*     */     catch (SecurityException localSecurityException) {}
/*     */     
/*  56 */     PROPERTIES_NEED_CONVERT = isEBCDIC;
/*     */   }
/*     */   
/*     */ 
/*     */   private final File resource;
/*     */   
/*     */   private final String name;
/*     */   private final boolean readOnly;
/*     */   private final Manifest manifest;
/*     */   private final boolean needConvert;
/*     */   public FileResource(WebResourceRoot root, String webAppPath, File resource, boolean readOnly, Manifest manifest)
/*     */   {
/*  68 */     super(root, webAppPath);
/*  69 */     this.resource = resource;
/*     */     
/*  71 */     if (webAppPath.charAt(webAppPath.length() - 1) == '/') {
/*  72 */       String realName = resource.getName() + '/';
/*  73 */       if (webAppPath.endsWith(realName)) {
/*  74 */         this.name = resource.getName();
/*     */       }
/*     */       else
/*     */       {
/*  78 */         int endOfName = webAppPath.length() - 1;
/*  79 */         this.name = webAppPath.substring(webAppPath.lastIndexOf('/', endOfName - 1) + 1, endOfName);
/*     */       }
/*     */       
/*     */     }
/*     */     else
/*     */     {
/*  85 */       this.name = resource.getName();
/*     */     }
/*     */     
/*  88 */     this.readOnly = readOnly;
/*  89 */     this.manifest = manifest;
/*  90 */     this.needConvert = ((PROPERTIES_NEED_CONVERT) && (this.name.endsWith(".properties")));
/*     */   }
/*     */   
/*     */   public long getLastModified()
/*     */   {
/*  95 */     return this.resource.lastModified();
/*     */   }
/*     */   
/*     */   public boolean exists()
/*     */   {
/* 100 */     return this.resource.exists();
/*     */   }
/*     */   
/*     */   public boolean isVirtual()
/*     */   {
/* 105 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isDirectory()
/*     */   {
/* 110 */     return this.resource.isDirectory();
/*     */   }
/*     */   
/*     */   public boolean isFile()
/*     */   {
/* 115 */     return this.resource.isFile();
/*     */   }
/*     */   
/*     */   public boolean delete()
/*     */   {
/* 120 */     if (this.readOnly) {
/* 121 */       return false;
/*     */     }
/* 123 */     return this.resource.delete();
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/* 128 */     return this.name;
/*     */   }
/*     */   
/*     */   public long getContentLength()
/*     */   {
/* 133 */     if (this.needConvert) {
/* 134 */       byte[] content = getContent();
/* 135 */       if (content == null) {
/* 136 */         return -1L;
/*     */       }
/* 138 */       return content.length;
/*     */     }
/*     */     
/* 141 */     return this.resource.length();
/*     */   }
/*     */   
/*     */   public String getCanonicalPath()
/*     */   {
/*     */     try {
/* 147 */       return this.resource.getCanonicalPath();
/*     */     } catch (IOException ioe) {
/* 149 */       if (log.isDebugEnabled()) {
/* 150 */         log.debug(sm.getString("fileResource.getCanonicalPathFail", new Object[] { this.resource.getPath() }), ioe);
/*     */       }
/*     */     }
/* 153 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean canRead()
/*     */   {
/* 159 */     return this.resource.canRead();
/*     */   }
/*     */   
/*     */   protected InputStream doGetInputStream()
/*     */   {
/* 164 */     if (this.needConvert) {
/* 165 */       byte[] content = getContent();
/* 166 */       if (content == null) {
/* 167 */         return null;
/*     */       }
/* 169 */       return new ByteArrayInputStream(content);
/*     */     }
/*     */     try
/*     */     {
/* 173 */       return new FileInputStream(this.resource);
/*     */     }
/*     */     catch (FileNotFoundException fnfe) {}
/* 176 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public final byte[] getContent()
/*     */   {
/* 182 */     long len = getContentLength();
/*     */     
/* 184 */     if (len > 2147483647L)
/*     */     {
/* 186 */       throw new ArrayIndexOutOfBoundsException(sm.getString("abstractResource.getContentTooLarge", new Object[] { getWebappPath(), Long.valueOf(len) }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 191 */     int size = (int)len;
/* 192 */     byte[] result = new byte[size];
/*     */     
/* 194 */     int pos = 0;
/* 195 */     try { InputStream is = new FileInputStream(this.resource);Throwable localThrowable2 = null;
/* 196 */       try { while (pos < size) {
/* 197 */           int n = is.read(result, pos, size - pos);
/* 198 */           if (n < 0) {
/*     */             break;
/*     */           }
/* 201 */           pos += n;
/*     */         }
/*     */       }
/*     */       catch (Throwable localThrowable1)
/*     */       {
/* 195 */         localThrowable2 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */       }
/*     */       finally
/*     */       {
/*     */ 
/*     */ 
/* 203 */         if (is != null) if (localThrowable2 != null) try { is.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else is.close();
/* 204 */       } } catch (IOException ioe) { if (getLog().isDebugEnabled()) {
/* 205 */         getLog().debug(sm.getString("abstractResource.getContentFail", new Object[] { getWebappPath() }), ioe);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 210 */     if (this.needConvert)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 215 */       String str = new String(result);
/*     */       try {
/* 217 */         result = str.getBytes(StandardCharsets.UTF_8);
/*     */       } catch (Exception e) {
/* 219 */         result = null;
/*     */       }
/*     */     }
/* 222 */     return result;
/*     */   }
/*     */   
/*     */   public long getCreation()
/*     */   {
/*     */     try
/*     */     {
/* 229 */       BasicFileAttributes attrs = Files.readAttributes(this.resource.toPath(), BasicFileAttributes.class, new LinkOption[0]);
/*     */       
/* 231 */       return attrs.creationTime().toMillis();
/*     */     } catch (IOException e) {
/* 233 */       if (log.isDebugEnabled()) {
/* 234 */         log.debug(sm.getString("fileResource.getCreationFail", new Object[] { this.resource.getPath() }), e);
/*     */       }
/*     */     }
/* 237 */     return 0L;
/*     */   }
/*     */   
/*     */ 
/*     */   public URL getURL()
/*     */   {
/* 243 */     if (this.resource.exists()) {
/*     */       try {
/* 245 */         return this.resource.toURI().toURL();
/*     */       } catch (MalformedURLException e) {
/* 247 */         if (log.isDebugEnabled()) {
/* 248 */           log.debug(sm.getString("fileResource.getUrlFail", new Object[] { this.resource.getPath() }), e);
/*     */         }
/*     */         
/* 251 */         return null;
/*     */       }
/*     */     }
/* 254 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public URL getCodeBase()
/*     */   {
/* 260 */     if ((getWebappPath().startsWith("/WEB-INF/classes/")) && (this.name.endsWith(".class"))) {
/* 261 */       return getWebResourceRoot().getResource("/WEB-INF/classes/").getURL();
/*     */     }
/* 263 */     return getURL();
/*     */   }
/*     */   
/*     */ 
/*     */   public Certificate[] getCertificates()
/*     */   {
/* 269 */     return null;
/*     */   }
/*     */   
/*     */   public Manifest getManifest()
/*     */   {
/* 274 */     return this.manifest;
/*     */   }
/*     */   
/*     */   protected Log getLog()
/*     */   {
/* 279 */     return log;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\webresources\FileResource.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */