/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.jar.JarInputStream;
/*     */ import java.util.jar.Manifest;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.tomcat.util.buf.UriUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JarWarResourceSet
/*     */   extends AbstractArchiveResourceSet
/*     */ {
/*     */   private final String archivePath;
/*     */   
/*     */   public JarWarResourceSet(WebResourceRoot root, String webAppMount, String base, String archivePath, String internalPath)
/*     */     throws IllegalArgumentException
/*     */   {
/*  68 */     setRoot(root);
/*  69 */     setWebAppMount(webAppMount);
/*  70 */     setBase(base);
/*  71 */     this.archivePath = archivePath;
/*  72 */     setInternalPath(internalPath);
/*     */     
/*  74 */     if (getRoot().getState().isAvailable()) {
/*     */       try {
/*  76 */         start();
/*     */       } catch (LifecycleException e) {
/*  78 */         throw new IllegalStateException(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected WebResource createArchiveResource(JarEntry jarEntry, String webAppPath, Manifest manifest)
/*     */   {
/*  86 */     return new JarWarResource(this, webAppPath, getBaseUrlString(), jarEntry, this.archivePath);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected HashMap<String, JarEntry> getArchiveEntries(boolean single)
/*     */   {
/*  98 */     synchronized (this.archiveLock) {
/*  99 */       if (this.archiveEntries == null) {
/* 100 */         JarFile warFile = null;
/* 101 */         InputStream jarFileIs = null;
/* 102 */         this.archiveEntries = new HashMap();
/*     */         try {
/* 104 */           warFile = openJarFile();
/* 105 */           JarEntry jarFileInWar = warFile.getJarEntry(this.archivePath);
/* 106 */           jarFileIs = warFile.getInputStream(jarFileInWar);
/*     */           
/* 108 */           JarInputStream jarIs = new JarInputStream(jarFileIs);Throwable localThrowable2 = null;
/* 109 */           try { JarEntry entry = jarIs.getNextJarEntry();
/* 110 */             while (entry != null) {
/* 111 */               this.archiveEntries.put(entry.getName(), entry);
/* 112 */               entry = jarIs.getNextJarEntry();
/*     */             }
/* 114 */             setManifest(jarIs.getManifest());
/*     */           }
/*     */           catch (Throwable localThrowable1)
/*     */           {
/* 108 */             localThrowable2 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */           }
/*     */           finally
/*     */           {
/*     */ 
/* 115 */             if (jarIs != null) { if (localThrowable2 != null) try { jarIs.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else { jarIs.close();
/*     */               }
/*     */             }
/*     */           }
/*     */           
/*     */ 
/* 121 */           if (warFile != null) {
/* 122 */             closeJarFile();
/*     */           }
/* 124 */           if (jarFileIs != null) {
/*     */             try {
/* 126 */               jarFileIs.close();
/*     */             }
/*     */             catch (IOException localIOException1) {}
/*     */           }
/*     */         }
/*     */         catch (IOException ioe)
/*     */         {
/* 118 */           this.archiveEntries = null;
/* 119 */           throw new IllegalStateException(ioe);
/*     */         } finally {
/* 121 */           if (warFile != null) {
/* 122 */             closeJarFile();
/*     */           }
/* 124 */           if (jarFileIs != null) {
/*     */             try {
/* 126 */               jarFileIs.close();
/*     */             }
/*     */             catch (IOException localIOException2) {}
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 133 */       return this.archiveEntries;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JarEntry getArchiveEntry(String pathInArchive)
/*     */   {
/* 146 */     throw new IllegalStateException("Coding error");
/*     */   }
/*     */   
/*     */   protected void initInternal()
/*     */     throws LifecycleException
/*     */   {
/*     */     try
/*     */     {
/* 154 */       JarFile warFile = new JarFile(getBase());Throwable localThrowable3 = null;
/* 155 */       try { JarEntry jarFileInWar = warFile.getJarEntry(this.archivePath);
/* 156 */         InputStream jarFileIs = warFile.getInputStream(jarFileInWar);
/*     */         
/* 158 */         JarInputStream jarIs = new JarInputStream(jarFileIs);Throwable localThrowable4 = null;
/* 159 */         try { setManifest(jarIs.getManifest());
/*     */         }
/*     */         catch (Throwable localThrowable1)
/*     */         {
/* 158 */           localThrowable4 = localThrowable1;throw localThrowable1;
/*     */         }
/*     */         finally {}
/*     */       }
/*     */       catch (Throwable localThrowable2)
/*     */       {
/* 154 */         localThrowable3 = localThrowable2;throw localThrowable2;
/*     */ 
/*     */ 
/*     */       }
/*     */       finally
/*     */       {
/*     */ 
/* 161 */         if (warFile != null) if (localThrowable3 != null) try { warFile.close(); } catch (Throwable x2) { localThrowable3.addSuppressed(x2); } else warFile.close();
/* 162 */       } } catch (IOException ioe) { throw new IllegalArgumentException(ioe);
/*     */     }
/*     */     try
/*     */     {
/* 166 */       setBaseUrl(UriUtil.buildJarSafeUrl(new File(getBase())));
/*     */     } catch (MalformedURLException e) {
/* 168 */       throw new IllegalArgumentException(e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\webresources\JarWarResourceSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */