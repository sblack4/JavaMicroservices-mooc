/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.security.cert.Certificate;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.Manifest;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractArchiveResource
/*     */   extends AbstractResource
/*     */ {
/*     */   private final AbstractArchiveResourceSet archiveResourceSet;
/*     */   private final String baseUrl;
/*     */   private final JarEntry resource;
/*     */   private final String codeBaseUrl;
/*     */   private final String name;
/*  34 */   private boolean readCerts = false;
/*     */   private Certificate[] certificates;
/*     */   
/*     */   protected AbstractArchiveResource(AbstractArchiveResourceSet archiveResourceSet, String webAppPath, String baseUrl, JarEntry jarEntry, String codeBaseUrl)
/*     */   {
/*  39 */     super(archiveResourceSet.getRoot(), webAppPath);
/*  40 */     this.archiveResourceSet = archiveResourceSet;
/*  41 */     this.baseUrl = baseUrl;
/*  42 */     this.resource = jarEntry;
/*  43 */     this.codeBaseUrl = codeBaseUrl;
/*     */     
/*  45 */     String resourceName = this.resource.getName();
/*  46 */     if (resourceName.charAt(resourceName.length() - 1) == '/') {
/*  47 */       resourceName = resourceName.substring(0, resourceName.length() - 1);
/*     */     }
/*  49 */     String internalPath = archiveResourceSet.getInternalPath();
/*  50 */     if ((internalPath.length() > 0) && (resourceName.equals(internalPath.subSequence(1, internalPath.length()))))
/*     */     {
/*  52 */       this.name = "";
/*     */     } else {
/*  54 */       int index = resourceName.lastIndexOf('/');
/*  55 */       if (index == -1) {
/*  56 */         this.name = resourceName;
/*     */       } else {
/*  58 */         this.name = resourceName.substring(index + 1);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected AbstractArchiveResourceSet getArchiveResourceSet() {
/*  64 */     return this.archiveResourceSet;
/*     */   }
/*     */   
/*     */   protected final String getBase() {
/*  68 */     return this.archiveResourceSet.getBase();
/*     */   }
/*     */   
/*     */   protected final String getBaseUrl() {
/*  72 */     return this.baseUrl;
/*     */   }
/*     */   
/*     */   protected final JarEntry getResource() {
/*  76 */     return this.resource;
/*     */   }
/*     */   
/*     */   public long getLastModified()
/*     */   {
/*  81 */     return this.resource.getTime();
/*     */   }
/*     */   
/*     */   public boolean exists()
/*     */   {
/*  86 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isVirtual()
/*     */   {
/*  91 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isDirectory()
/*     */   {
/*  96 */     return this.resource.isDirectory();
/*     */   }
/*     */   
/*     */   public boolean isFile()
/*     */   {
/* 101 */     return !this.resource.isDirectory();
/*     */   }
/*     */   
/*     */   public boolean delete()
/*     */   {
/* 106 */     return false;
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/* 111 */     return this.name;
/*     */   }
/*     */   
/*     */   public long getContentLength()
/*     */   {
/* 116 */     return this.resource.getSize();
/*     */   }
/*     */   
/*     */   public String getCanonicalPath()
/*     */   {
/* 121 */     return null;
/*     */   }
/*     */   
/*     */   public boolean canRead()
/*     */   {
/* 126 */     return true;
/*     */   }
/*     */   
/*     */   public long getCreation()
/*     */   {
/* 131 */     return this.resource.getTime();
/*     */   }
/*     */   
/*     */   public URL getURL()
/*     */   {
/* 136 */     String url = this.baseUrl + "!/" + this.resource.getName();
/*     */     try {
/* 138 */       return new URL(url);
/*     */     } catch (MalformedURLException e) {
/* 140 */       if (getLog().isDebugEnabled())
/* 141 */         getLog().debug(sm.getString("fileResource.getUrlFail", new Object[] { url }), e);
/*     */     }
/* 143 */     return null;
/*     */   }
/*     */   
/*     */   public URL getCodeBase()
/*     */   {
/*     */     try
/*     */     {
/* 150 */       return new URL(this.codeBaseUrl);
/*     */     } catch (MalformedURLException e) {
/* 152 */       if (getLog().isDebugEnabled())
/* 153 */         getLog().debug(sm.getString("fileResource.getUrlFail", new Object[] { this.codeBaseUrl }), e);
/*     */     }
/* 155 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public final byte[] getContent()
/*     */   {
/* 161 */     long len = getContentLength();
/*     */     
/* 163 */     if (len > 2147483647L)
/*     */     {
/* 165 */       throw new ArrayIndexOutOfBoundsException(sm.getString("abstractResource.getContentTooLarge", new Object[] { getWebappPath(), Long.valueOf(len) }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 170 */     int size = (int)len;
/* 171 */     byte[] result = new byte[size];
/*     */     
/* 173 */     int pos = 0;
/* 174 */     try { JarInputStreamWrapper jisw = getJarInputStreamWrapper();Throwable localThrowable2 = null;
/* 175 */       try { if (jisw == null)
/*     */         {
/* 177 */           return null;
/*     */         }
/* 179 */         while (pos < size) {
/* 180 */           int n = jisw.read(result, pos, size - pos);
/* 181 */           if (n < 0) {
/*     */             break;
/*     */           }
/* 184 */           pos += n;
/*     */         }
/*     */         
/* 187 */         this.certificates = jisw.getCertificates();
/* 188 */         this.readCerts = true;
/*     */       }
/*     */       catch (Throwable localThrowable3)
/*     */       {
/* 174 */         localThrowable2 = localThrowable3;throw localThrowable3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       finally
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 189 */         if (jisw != null) if (localThrowable2 != null) try { jisw.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else jisw.close();
/* 190 */       } } catch (IOException ioe) { if (getLog().isDebugEnabled()) {
/* 191 */         getLog().debug(sm.getString("abstractResource.getContentFail", new Object[] { getWebappPath() }), ioe);
/*     */       }
/*     */       
/*     */ 
/* 195 */       return null;
/*     */     }
/*     */     
/* 198 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public Certificate[] getCertificates()
/*     */   {
/* 204 */     if (!this.readCerts)
/*     */     {
/* 206 */       throw new IllegalStateException();
/*     */     }
/* 208 */     return this.certificates;
/*     */   }
/*     */   
/*     */   public Manifest getManifest()
/*     */   {
/* 213 */     return this.archiveResourceSet.getManifest();
/*     */   }
/*     */   
/*     */   protected final InputStream doGetInputStream()
/*     */   {
/* 218 */     return getJarInputStreamWrapper();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract JarInputStreamWrapper getJarInputStreamWrapper();
/*     */   
/*     */ 
/*     */   protected class JarInputStreamWrapper
/*     */     extends InputStream
/*     */   {
/*     */     private final JarEntry jarEntry;
/*     */     
/*     */     private final InputStream is;
/*     */     
/*     */ 
/*     */     public JarInputStreamWrapper(JarEntry jarEntry, InputStream is)
/*     */     {
/* 236 */       this.jarEntry = jarEntry;
/* 237 */       this.is = is;
/*     */     }
/*     */     
/*     */     public int read()
/*     */       throws IOException
/*     */     {
/* 243 */       return this.is.read();
/*     */     }
/*     */     
/*     */     public int read(byte[] b)
/*     */       throws IOException
/*     */     {
/* 249 */       return this.is.read(b);
/*     */     }
/*     */     
/*     */     public int read(byte[] b, int off, int len)
/*     */       throws IOException
/*     */     {
/* 255 */       return this.is.read(b, off, len);
/*     */     }
/*     */     
/*     */     public long skip(long n)
/*     */       throws IOException
/*     */     {
/* 261 */       return this.is.skip(n);
/*     */     }
/*     */     
/*     */     public int available()
/*     */       throws IOException
/*     */     {
/* 267 */       return this.is.available();
/*     */     }
/*     */     
/*     */     public void close()
/*     */       throws IOException
/*     */     {
/* 273 */       AbstractArchiveResource.this.archiveResourceSet.closeJarFile();
/*     */     }
/*     */     
/*     */ 
/*     */     public synchronized void mark(int readlimit)
/*     */     {
/* 279 */       this.is.mark(readlimit);
/*     */     }
/*     */     
/*     */     public synchronized void reset()
/*     */       throws IOException
/*     */     {
/* 285 */       this.is.reset();
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean markSupported()
/*     */     {
/* 291 */       return this.is.markSupported();
/*     */     }
/*     */     
/*     */     public Certificate[] getCertificates() {
/* 295 */       return this.jarEntry.getCertificates();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\webresources\AbstractArchiveResource.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */