/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.TrackedWebResource;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.catalina.WebResourceRoot.ResourceSetType;
/*     */ import org.apache.catalina.WebResourceSet;
/*     */ import org.apache.catalina.util.LifecycleMBeanBase;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.http.RequestUtil;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardRoot
/*     */   extends LifecycleMBeanBase
/*     */   implements WebResourceRoot
/*     */ {
/*  64 */   private static final Log log = LogFactory.getLog(StandardRoot.class);
/*  65 */   protected static final StringManager sm = StringManager.getManager(StandardRoot.class);
/*     */   
/*     */   private Context context;
/*  68 */   private boolean allowLinking = false;
/*  69 */   private final List<WebResourceSet> preResources = new ArrayList();
/*     */   private WebResourceSet main;
/*  71 */   private final List<WebResourceSet> classResources = new ArrayList();
/*  72 */   private final List<WebResourceSet> jarResources = new ArrayList();
/*  73 */   private final List<WebResourceSet> postResources = new ArrayList();
/*     */   
/*  75 */   private final Cache cache = new Cache(this);
/*  76 */   private boolean cachingAllowed = true;
/*  77 */   private ObjectName cacheJmxName = null;
/*     */   
/*  79 */   private boolean trackLockedFiles = false;
/*  80 */   private final Set<TrackedWebResource> trackedResources = Collections.newSetFromMap(new ConcurrentHashMap());
/*     */   
/*     */ 
/*     */ 
/*  84 */   private final List<WebResourceSet> mainResources = new ArrayList();
/*  85 */   private final List<List<WebResourceSet>> allResources = new ArrayList();
/*     */   
/*     */   public StandardRoot() {
/*  88 */     this.allResources.add(this.preResources);
/*  89 */     this.allResources.add(this.mainResources);
/*  90 */     this.allResources.add(this.classResources);
/*  91 */     this.allResources.add(this.jarResources);
/*  92 */     this.allResources.add(this.postResources);
/*     */   }
/*     */   
/*     */   public StandardRoot(Context context)
/*     */   {
/*  88 */     this.allResources.add(this.preResources);
/*  89 */     this.allResources.add(this.mainResources);
/*  90 */     this.allResources.add(this.classResources);
/*  91 */     this.allResources.add(this.jarResources);
/*  92 */     this.allResources.add(this.postResources);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */     this.context = context;
/*     */   }
/*     */   
/*     */   public String[] list(String path)
/*     */   {
/* 112 */     return list(path, true);
/*     */   }
/*     */   
/*     */   private String[] list(String path, boolean validate) {
/* 116 */     if (validate) {
/* 117 */       path = validate(path);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 124 */     HashSet<String> result = new LinkedHashSet();
/* 125 */     for (List<WebResourceSet> list : this.allResources) {
/* 126 */       for (WebResourceSet webResourceSet : list) {
/* 127 */         if (!webResourceSet.getClassLoaderOnly()) {
/* 128 */           String[] entries = webResourceSet.list(path);
/* 129 */           for (String entry : entries) {
/* 130 */             result.add(entry);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 135 */     return (String[])result.toArray(new String[result.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */   public Set<String> listWebAppPaths(String path)
/*     */   {
/* 141 */     path = validate(path);
/*     */     
/*     */ 
/* 144 */     HashSet<String> result = new HashSet();
/* 145 */     for (List<WebResourceSet> list : this.allResources) {
/* 146 */       for (WebResourceSet webResourceSet : list) {
/* 147 */         if (!webResourceSet.getClassLoaderOnly()) {
/* 148 */           result.addAll(webResourceSet.listWebAppPaths(path));
/*     */         }
/*     */       }
/*     */     }
/* 152 */     if (result.size() == 0) {
/* 153 */       return null;
/*     */     }
/* 155 */     return result;
/*     */   }
/*     */   
/*     */   public boolean mkdir(String path)
/*     */   {
/* 160 */     path = validate(path);
/*     */     
/* 162 */     if (preResourceExists(path)) {
/* 163 */       return false;
/*     */     }
/*     */     
/* 166 */     boolean mkdirResult = this.main.mkdir(path);
/*     */     
/* 168 */     if ((mkdirResult) && (isCachingAllowed()))
/*     */     {
/* 170 */       this.cache.removeCacheEntry(path);
/*     */     }
/* 172 */     return mkdirResult;
/*     */   }
/*     */   
/*     */   public boolean write(String path, InputStream is, boolean overwrite)
/*     */   {
/* 177 */     path = validate(path);
/*     */     
/* 179 */     if ((!overwrite) && (preResourceExists(path))) {
/* 180 */       return false;
/*     */     }
/*     */     
/* 183 */     boolean writeResult = this.main.write(path, is, overwrite);
/*     */     
/* 185 */     if ((writeResult) && (isCachingAllowed()))
/*     */     {
/* 187 */       this.cache.removeCacheEntry(path);
/*     */     }
/*     */     
/* 190 */     return writeResult;
/*     */   }
/*     */   
/*     */   private boolean preResourceExists(String path) {
/* 194 */     for (WebResourceSet webResourceSet : this.preResources) {
/* 195 */       WebResource webResource = webResourceSet.getResource(path);
/* 196 */       if (webResource.exists()) {
/* 197 */         return true;
/*     */       }
/*     */     }
/* 200 */     return false;
/*     */   }
/*     */   
/*     */   public WebResource getResource(String path)
/*     */   {
/* 205 */     return getResource(path, true, false);
/*     */   }
/*     */   
/*     */   private WebResource getResource(String path, boolean validate, boolean useClassLoaderResources)
/*     */   {
/* 210 */     if (validate) {
/* 211 */       path = validate(path);
/*     */     }
/*     */     
/* 214 */     if (isCachingAllowed()) {
/* 215 */       return this.cache.getResource(path, useClassLoaderResources);
/*     */     }
/* 217 */     return getResourceInternal(path, useClassLoaderResources);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public WebResource getClassLoaderResource(String path)
/*     */   {
/* 224 */     return getResource("/WEB-INF/classes" + path, true, true);
/*     */   }
/*     */   
/*     */ 
/*     */   public WebResource[] getClassLoaderResources(String path)
/*     */   {
/* 230 */     return getResources("/WEB-INF/classes" + path, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String validate(String path)
/*     */   {
/* 243 */     if (!getState().isAvailable()) {
/* 244 */       throw new IllegalStateException(sm.getString("standardRoot.checkStateNotStarted"));
/*     */     }
/*     */     
/*     */ 
/* 248 */     if ((path == null) || (path.length() == 0) || (!path.startsWith("/"))) {
/* 249 */       throw new IllegalArgumentException(sm.getString("standardRoot.invalidPath", new Object[] { path }));
/*     */     }
/*     */     
/*     */     String result;
/*     */     String result;
/* 254 */     if (File.separatorChar == '\\')
/*     */     {
/*     */ 
/* 257 */       result = RequestUtil.normalize(path, true);
/*     */     }
/*     */     else
/*     */     {
/* 261 */       result = RequestUtil.normalize(path, false);
/*     */     }
/* 263 */     if ((result == null) || (result.length() == 0) || (!result.startsWith("/"))) {
/* 264 */       throw new IllegalArgumentException(sm.getString("standardRoot.invalidPathNormal", new Object[] { path, result }));
/*     */     }
/*     */     
/*     */ 
/* 268 */     return result;
/*     */   }
/*     */   
/*     */   protected final WebResource getResourceInternal(String path, boolean useClassLoaderResources)
/*     */   {
/* 273 */     WebResource result = null;
/* 274 */     WebResource virtual = null;
/* 275 */     WebResource mainEmpty = null;
/* 276 */     for (List<WebResourceSet> list : this.allResources) {
/* 277 */       for (WebResourceSet webResourceSet : list) {
/* 278 */         if (((!useClassLoaderResources) && (!webResourceSet.getClassLoaderOnly())) || ((useClassLoaderResources) && (!webResourceSet.getStaticOnly())))
/*     */         {
/* 280 */           result = webResourceSet.getResource(path);
/* 281 */           if (result.exists()) {
/* 282 */             return result;
/*     */           }
/* 284 */           if (virtual == null) {
/* 285 */             if (result.isVirtual()) {
/* 286 */               virtual = result;
/* 287 */             } else if (this.main.equals(webResourceSet)) {
/* 288 */               mainEmpty = result;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 296 */     if (virtual != null) {
/* 297 */       return virtual;
/*     */     }
/*     */     
/*     */ 
/* 301 */     return mainEmpty;
/*     */   }
/*     */   
/*     */   public WebResource[] getResources(String path)
/*     */   {
/* 306 */     return getResources(path, false);
/*     */   }
/*     */   
/*     */   private WebResource[] getResources(String path, boolean useClassLoaderResources)
/*     */   {
/* 311 */     path = validate(path);
/*     */     
/* 313 */     if (isCachingAllowed()) {
/* 314 */       return this.cache.getResources(path, useClassLoaderResources);
/*     */     }
/* 316 */     return getResourcesInternal(path, useClassLoaderResources);
/*     */   }
/*     */   
/*     */ 
/*     */   protected WebResource[] getResourcesInternal(String path, boolean useClassLoaderResources)
/*     */   {
/* 322 */     List<WebResource> result = new ArrayList();
/* 323 */     for (List<WebResourceSet> list : this.allResources) {
/* 324 */       for (WebResourceSet webResourceSet : list) {
/* 325 */         if ((useClassLoaderResources) || (!webResourceSet.getClassLoaderOnly())) {
/* 326 */           WebResource webResource = webResourceSet.getResource(path);
/* 327 */           if (webResource.exists()) {
/* 328 */             result.add(webResource);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 334 */     if (result.size() == 0) {
/* 335 */       result.add(this.main.getResource(path));
/*     */     }
/*     */     
/* 338 */     return (WebResource[])result.toArray(new WebResource[result.size()]);
/*     */   }
/*     */   
/*     */   public WebResource[] listResources(String path)
/*     */   {
/* 343 */     return listResources(path, true);
/*     */   }
/*     */   
/*     */   private WebResource[] listResources(String path, boolean validate) {
/* 347 */     if (validate) {
/* 348 */       path = validate(path);
/*     */     }
/*     */     
/* 351 */     String[] resources = list(path, false);
/* 352 */     WebResource[] result = new WebResource[resources.length];
/* 353 */     for (int i = 0; i < resources.length; i++) {
/* 354 */       if (path.charAt(path.length() - 1) == '/') {
/* 355 */         result[i] = getResource(path + resources[i], false, false);
/*     */       } else {
/* 357 */         result[i] = getResource(path + '/' + resources[i], false, false);
/*     */       }
/*     */     }
/* 360 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void createWebResourceSet(WebResourceRoot.ResourceSetType type, String webAppMount, URL url, String internalPath)
/*     */   {
/* 369 */     BaseLocation baseLocation = new BaseLocation(url);
/* 370 */     createWebResourceSet(type, webAppMount, baseLocation.getBasePath(), baseLocation.getArchivePath(), internalPath);
/*     */   }
/*     */   
/*     */ 
/*     */   public void createWebResourceSet(WebResourceRoot.ResourceSetType type, String webAppMount, String base, String archivePath, String internalPath)
/*     */   {
/*     */     List<WebResourceSet> resourceList;
/*     */     List<WebResourceSet> resourceList;
/*     */     List<WebResourceSet> resourceList;
/*     */     List<WebResourceSet> resourceList;
/* 380 */     switch (type) {
/*     */     case PRE: 
/* 382 */       resourceList = this.preResources;
/* 383 */       break;
/*     */     case CLASSES_JAR: 
/* 385 */       resourceList = this.classResources;
/* 386 */       break;
/*     */     case RESOURCE_JAR: 
/* 388 */       resourceList = this.jarResources;
/* 389 */       break;
/*     */     case POST: 
/* 391 */       resourceList = this.postResources;
/* 392 */       break;
/*     */     default: 
/* 394 */       throw new IllegalArgumentException(sm.getString("standardRoot.createUnknownType", new Object[] { type }));
/*     */     }
/*     */     
/*     */     
/*     */     List<WebResourceSet> resourceList;
/*     */     
/* 400 */     File file = new File(base);
/*     */     WebResourceSet resourceSet;
/* 402 */     if (file.isFile()) { WebResourceSet resourceSet;
/* 403 */       if (archivePath != null)
/*     */       {
/* 405 */         resourceSet = new JarWarResourceSet(this, webAppMount, base, archivePath, internalPath);
/*     */       } else { WebResourceSet resourceSet;
/* 407 */         if (file.getName().toLowerCase(Locale.ENGLISH).endsWith(".jar")) {
/* 408 */           resourceSet = new JarResourceSet(this, webAppMount, base, internalPath);
/*     */         }
/*     */         else
/* 411 */           resourceSet = new FileResourceSet(this, webAppMount, base, internalPath);
/*     */       }
/*     */     } else { WebResourceSet resourceSet;
/* 414 */       if (file.isDirectory()) {
/* 415 */         resourceSet = new DirResourceSet(this, webAppMount, base, internalPath);
/*     */       }
/*     */       else {
/* 418 */         throw new IllegalArgumentException(sm.getString("standardRoot.createInvalidFile", new Object[] { file }));
/*     */       }
/*     */     }
/*     */     WebResourceSet resourceSet;
/* 422 */     if (type.equals(WebResourceRoot.ResourceSetType.CLASSES_JAR)) {
/* 423 */       resourceSet.setClassLoaderOnly(true);
/* 424 */     } else if (type.equals(WebResourceRoot.ResourceSetType.RESOURCE_JAR)) {
/* 425 */       resourceSet.setStaticOnly(true);
/*     */     }
/*     */     
/* 428 */     resourceList.add(resourceSet);
/*     */   }
/*     */   
/*     */   public void addPreResources(WebResourceSet webResourceSet)
/*     */   {
/* 433 */     webResourceSet.setRoot(this);
/* 434 */     this.preResources.add(webResourceSet);
/*     */   }
/*     */   
/*     */   public WebResourceSet[] getPreResources()
/*     */   {
/* 439 */     return (WebResourceSet[])this.preResources.toArray(new WebResourceSet[this.preResources.size()]);
/*     */   }
/*     */   
/*     */   public void addJarResources(WebResourceSet webResourceSet)
/*     */   {
/* 444 */     webResourceSet.setRoot(this);
/* 445 */     this.jarResources.add(webResourceSet);
/*     */   }
/*     */   
/*     */   public WebResourceSet[] getJarResources()
/*     */   {
/* 450 */     return (WebResourceSet[])this.jarResources.toArray(new WebResourceSet[this.jarResources.size()]);
/*     */   }
/*     */   
/*     */   public void addPostResources(WebResourceSet webResourceSet)
/*     */   {
/* 455 */     webResourceSet.setRoot(this);
/* 456 */     this.postResources.add(webResourceSet);
/*     */   }
/*     */   
/*     */   public WebResourceSet[] getPostResources()
/*     */   {
/* 461 */     return (WebResourceSet[])this.postResources.toArray(new WebResourceSet[this.postResources.size()]);
/*     */   }
/*     */   
/*     */   protected WebResourceSet[] getClassResources() {
/* 465 */     return (WebResourceSet[])this.classResources.toArray(new WebResourceSet[this.classResources.size()]);
/*     */   }
/*     */   
/*     */   protected void addClassResources(WebResourceSet webResourceSet) {
/* 469 */     webResourceSet.setRoot(this);
/* 470 */     this.classResources.add(webResourceSet);
/*     */   }
/*     */   
/*     */   public void setAllowLinking(boolean allowLinking)
/*     */   {
/* 475 */     this.allowLinking = allowLinking;
/*     */   }
/*     */   
/*     */   public boolean getAllowLinking()
/*     */   {
/* 480 */     return this.allowLinking;
/*     */   }
/*     */   
/*     */   public void setCachingAllowed(boolean cachingAllowed)
/*     */   {
/* 485 */     this.cachingAllowed = cachingAllowed;
/* 486 */     if (!cachingAllowed) {
/* 487 */       this.cache.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isCachingAllowed()
/*     */   {
/* 493 */     return this.cachingAllowed;
/*     */   }
/*     */   
/*     */   public long getCacheTtl()
/*     */   {
/* 498 */     return this.cache.getTtl();
/*     */   }
/*     */   
/*     */   public void setCacheTtl(long cacheTtl)
/*     */   {
/* 503 */     this.cache.setTtl(cacheTtl);
/*     */   }
/*     */   
/*     */   public long getCacheMaxSize()
/*     */   {
/* 508 */     return this.cache.getMaxSize();
/*     */   }
/*     */   
/*     */   public void setCacheMaxSize(long cacheMaxSize)
/*     */   {
/* 513 */     this.cache.setMaxSize(cacheMaxSize);
/*     */   }
/*     */   
/*     */   public void setCacheObjectMaxSize(int cacheObjectMaxSize)
/*     */   {
/* 518 */     this.cache.setObjectMaxSize(cacheObjectMaxSize);
/*     */     
/*     */ 
/* 521 */     if (getState().isAvailable()) {
/* 522 */       this.cache.enforceObjectMaxSizeLimit();
/*     */     }
/*     */   }
/*     */   
/*     */   public int getCacheObjectMaxSize()
/*     */   {
/* 528 */     return this.cache.getObjectMaxSize();
/*     */   }
/*     */   
/*     */   public void setTrackLockedFiles(boolean trackLockedFiles)
/*     */   {
/* 533 */     this.trackLockedFiles = trackLockedFiles;
/* 534 */     if (!trackLockedFiles) {
/* 535 */       this.trackedResources.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean getTrackLockedFiles()
/*     */   {
/* 541 */     return this.trackLockedFiles;
/*     */   }
/*     */   
/*     */   public List<String> getTrackedResources() {
/* 545 */     List<String> result = new ArrayList(this.trackedResources.size());
/* 546 */     for (TrackedWebResource resource : this.trackedResources) {
/* 547 */       result.add(resource.toString());
/*     */     }
/* 549 */     return result;
/*     */   }
/*     */   
/*     */   public Context getContext()
/*     */   {
/* 554 */     return this.context;
/*     */   }
/*     */   
/*     */   public void setContext(Context context)
/*     */   {
/* 559 */     this.context = context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void processWebInfLib()
/*     */   {
/* 574 */     WebResource[] possibleJars = listResources("/WEB-INF/lib", false);
/*     */     
/* 576 */     for (WebResource possibleJar : possibleJars) {
/* 577 */       if ((possibleJar.isFile()) && (possibleJar.getName().endsWith(".jar"))) {
/* 578 */         createWebResourceSet(WebResourceRoot.ResourceSetType.CLASSES_JAR, "/WEB-INF/classes", possibleJar.getURL(), "/");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void setMainResources(WebResourceSet main)
/*     */   {
/* 589 */     this.main = main;
/* 590 */     this.mainResources.clear();
/* 591 */     this.mainResources.add(main);
/*     */   }
/*     */   
/*     */ 
/*     */   public void backgroundProcess()
/*     */   {
/* 597 */     this.cache.backgroundProcess();
/* 598 */     gc();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void gc()
/*     */   {
/* 605 */     for (List<WebResourceSet> list : this.allResources) {
/* 606 */       for (WebResourceSet webResourceSet : list) {
/* 607 */         webResourceSet.gc();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void registerTrackedResource(TrackedWebResource trackedResource)
/*     */   {
/* 614 */     this.trackedResources.add(trackedResource);
/*     */   }
/*     */   
/*     */ 
/*     */   public void deregisterTrackedResource(TrackedWebResource trackedResource)
/*     */   {
/* 620 */     this.trackedResources.remove(trackedResource);
/*     */   }
/*     */   
/*     */ 
/*     */   public List<URL> getBaseUrls()
/*     */   {
/* 626 */     List<URL> result = new ArrayList();
/* 627 */     for (List<WebResourceSet> list : this.allResources) {
/* 628 */       for (WebResourceSet webResourceSet : list) {
/* 629 */         if (!webResourceSet.getClassLoaderOnly()) {
/* 630 */           URL url = webResourceSet.getBaseUrl();
/* 631 */           if (url != null) {
/* 632 */             result.add(url);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 637 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   protected String getDomainInternal()
/*     */   {
/* 643 */     return this.context.getDomain();
/*     */   }
/*     */   
/*     */   protected String getObjectNameKeyProperties()
/*     */   {
/* 648 */     StringBuilder keyProperties = new StringBuilder("type=WebResourceRoot");
/* 649 */     keyProperties.append(this.context.getMBeanKeyProperties());
/*     */     
/* 651 */     return keyProperties.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   protected void initInternal()
/*     */     throws LifecycleException
/*     */   {
/* 658 */     super.initInternal();
/*     */     
/* 660 */     this.cacheJmxName = register(this.cache, getObjectNameKeyProperties() + ",name=Cache");
/*     */     
/* 662 */     registerURLStreamHandlerFactory();
/*     */     
/* 664 */     if (this.context == null) {
/* 665 */       throw new IllegalStateException(sm.getString("standardRoot.noContext"));
/*     */     }
/*     */     
/*     */ 
/* 669 */     for (List<WebResourceSet> list : this.allResources) {
/* 670 */       for (WebResourceSet webResourceSet : list) {
/* 671 */         webResourceSet.init();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void registerURLStreamHandlerFactory()
/*     */   {
/* 679 */     TomcatURLStreamHandlerFactory.register();
/*     */   }
/*     */   
/*     */   protected void startInternal() throws LifecycleException
/*     */   {
/* 684 */     this.mainResources.clear();
/*     */     
/* 686 */     this.main = createMainResourceSet();
/*     */     
/* 688 */     this.mainResources.add(this.main);
/*     */     
/* 690 */     for (List<WebResourceSet> list : this.allResources) {
/* 691 */       for (WebResourceSet webResourceSet : list) {
/* 692 */         webResourceSet.start();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 698 */     processWebInfLib();
/*     */     
/* 700 */     for (WebResourceSet classResource : this.classResources) {
/* 701 */       classResource.start();
/*     */     }
/*     */     
/* 704 */     this.cache.enforceObjectMaxSizeLimit();
/*     */     
/* 706 */     setState(LifecycleState.STARTING);
/*     */   }
/*     */   
/*     */   protected WebResourceSet createMainResourceSet() {
/* 710 */     String docBase = this.context.getDocBase();
/*     */     
/*     */     WebResourceSet mainResourceSet;
/* 713 */     if (docBase == null) {
/* 714 */       mainResourceSet = new EmptyResourceSet(this);
/*     */     } else {
/* 716 */       File f = new File(docBase);
/* 717 */       if (!f.isAbsolute())
/* 718 */         f = new File(((Host)this.context.getParent()).getAppBaseFile(), f.getPath());
/*     */       WebResourceSet mainResourceSet;
/* 720 */       if (f.isDirectory()) {
/* 721 */         mainResourceSet = new DirResourceSet(this, "/", f.getAbsolutePath(), "/"); } else { WebResourceSet mainResourceSet;
/* 722 */         if ((f.isFile()) && (docBase.endsWith(".war"))) {
/* 723 */           mainResourceSet = new JarResourceSet(this, "/", f.getAbsolutePath(), "/");
/*     */         } else {
/* 725 */           throw new IllegalArgumentException(sm.getString("standardRoot.startInvalidMain", new Object[] { f.getAbsolutePath() }));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     WebResourceSet mainResourceSet;
/* 731 */     return mainResourceSet;
/*     */   }
/*     */   
/*     */   protected void stopInternal() throws LifecycleException
/*     */   {
/* 736 */     for (List<WebResourceSet> list : this.allResources) {
/* 737 */       for (WebResourceSet webResourceSet : list) {
/* 738 */         webResourceSet.stop();
/*     */       }
/*     */     }
/*     */     
/* 742 */     if (this.main != null) {
/* 743 */       this.main.destroy();
/*     */     }
/* 745 */     this.mainResources.clear();
/*     */     
/* 747 */     for (WebResourceSet webResourceSet : this.jarResources) {
/* 748 */       webResourceSet.destroy();
/*     */     }
/* 750 */     this.jarResources.clear();
/*     */     
/* 752 */     for (WebResourceSet webResourceSet : this.classResources) {
/* 753 */       webResourceSet.destroy();
/*     */     }
/* 755 */     this.classResources.clear();
/*     */     
/* 757 */     for (TrackedWebResource trackedResource : this.trackedResources) {
/* 758 */       log.error(sm.getString("standardRoot.lockedFile", new Object[] { this.context.getName(), trackedResource.getName() }), trackedResource.getCreatedBy());
/*     */       
/*     */ 
/*     */       try
/*     */       {
/* 763 */         trackedResource.close();
/*     */       }
/*     */       catch (IOException localIOException) {}
/*     */     }
/*     */     
/* 768 */     this.cache.clear();
/*     */     
/* 770 */     setState(LifecycleState.STOPPING);
/*     */   }
/*     */   
/*     */   protected void destroyInternal() throws LifecycleException
/*     */   {
/* 775 */     for (List<WebResourceSet> list : this.allResources) {
/* 776 */       for (WebResourceSet webResourceSet : list) {
/* 777 */         webResourceSet.destroy();
/*     */       }
/*     */     }
/*     */     
/* 781 */     unregister(this.cacheJmxName);
/*     */     
/* 783 */     super.destroyInternal();
/*     */   }
/*     */   
/*     */ 
/*     */   static class BaseLocation
/*     */   {
/*     */     private final String basePath;
/*     */     private final String archivePath;
/*     */     
/*     */     BaseLocation(URL url)
/*     */     {
/* 794 */       File f = null;
/*     */       
/* 796 */       if ("jar".equals(url.getProtocol())) {
/* 797 */         String jarUrl = url.toString();
/* 798 */         int endOfFileUrl = jarUrl.indexOf("!/");
/* 799 */         String fileUrl = jarUrl.substring(4, endOfFileUrl);
/*     */         try {
/* 801 */           f = new File(new URL(fileUrl).toURI());
/*     */         } catch (MalformedURLException|URISyntaxException e) {
/* 803 */           throw new IllegalArgumentException(e);
/*     */         }
/* 805 */         int startOfArchivePath = endOfFileUrl + 2;
/* 806 */         if (jarUrl.length() > startOfArchivePath) {
/* 807 */           this.archivePath = jarUrl.substring(startOfArchivePath);
/*     */         } else {
/* 809 */           this.archivePath = null;
/*     */         }
/* 811 */       } else if ("file".equals(url.getProtocol())) {
/*     */         try {
/* 813 */           f = new File(url.toURI());
/*     */         } catch (URISyntaxException e) {
/* 815 */           throw new IllegalArgumentException(e);
/*     */         }
/* 817 */         this.archivePath = null;
/*     */       } else {
/* 819 */         throw new IllegalArgumentException(StandardRoot.sm.getString("standardRoot.unsupportedProtocol", new Object[] { url.getProtocol() }));
/*     */       }
/*     */       
/*     */ 
/* 823 */       this.basePath = f.getAbsolutePath();
/*     */     }
/*     */     
/*     */     String getBasePath()
/*     */     {
/* 828 */       return this.basePath;
/*     */     }
/*     */     
/*     */     String getArchivePath()
/*     */     {
/* 833 */       return this.archivePath;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\webresources\StandardRoot.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */