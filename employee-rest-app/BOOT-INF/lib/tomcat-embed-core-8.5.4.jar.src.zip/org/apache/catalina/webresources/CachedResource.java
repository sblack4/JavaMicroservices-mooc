/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.security.cert.Certificate;
/*     */ import java.util.jar.Manifest;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CachedResource
/*     */   implements WebResource
/*     */ {
/*     */   private static final long CACHE_ENTRY_SIZE = 500L;
/*     */   private final Cache cache;
/*     */   private final StandardRoot root;
/*     */   private final String webAppPath;
/*     */   private final long ttl;
/*     */   private final int objectMaxSizeBytes;
/*     */   private volatile WebResource webResource;
/*     */   private volatile WebResource[] webResources;
/*     */   private volatile long nextCheck;
/*  49 */   private volatile Long cachedLastModified = null;
/*  50 */   private volatile String cachedLastModifiedHttp = null;
/*  51 */   private volatile byte[] cachedContent = null;
/*  52 */   private volatile Boolean cachedIsFile = null;
/*  53 */   private volatile Boolean cachedIsDirectory = null;
/*  54 */   private volatile Boolean cachedExists = null;
/*  55 */   private volatile Boolean cachedIsVirtual = null;
/*  56 */   private volatile Long cachedContentLength = null;
/*     */   
/*     */ 
/*     */   public CachedResource(Cache cache, StandardRoot root, String path, long ttl, int objectMaxSizeBytes)
/*     */   {
/*  61 */     this.cache = cache;
/*  62 */     this.root = root;
/*  63 */     this.webAppPath = path;
/*  64 */     this.ttl = ttl;
/*  65 */     this.objectMaxSizeBytes = objectMaxSizeBytes;
/*     */   }
/*     */   
/*     */   protected boolean validateResource(boolean useClassLoaderResources) {
/*  69 */     long now = System.currentTimeMillis();
/*     */     
/*  71 */     if (this.webResource == null) {
/*  72 */       synchronized (this) {
/*  73 */         if (this.webResource == null) {
/*  74 */           this.webResource = this.root.getResourceInternal(this.webAppPath, useClassLoaderResources);
/*     */           
/*  76 */           getLastModified();
/*  77 */           getContentLength();
/*  78 */           this.nextCheck = (this.ttl + now);
/*     */           
/*     */ 
/*  81 */           if ((this.webResource instanceof EmptyResource)) {
/*  82 */             this.cachedExists = Boolean.FALSE;
/*     */           } else {
/*  84 */             this.cachedExists = Boolean.TRUE;
/*     */           }
/*  86 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  91 */     if (now < this.nextCheck) {
/*  92 */       return true;
/*     */     }
/*     */     
/*  95 */     WebResource webResourceInternal = this.root.getResourceInternal(this.webAppPath, useClassLoaderResources);
/*     */     
/*  97 */     if ((!this.webResource.exists()) && (webResourceInternal.exists())) {
/*  98 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 103 */     if ((this.webResource.getLastModified() != getLastModified()) || (this.webResource.getContentLength() != getContentLength()))
/*     */     {
/* 105 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 109 */     if ((this.webResource.getLastModified() != webResourceInternal.getLastModified()) || (this.webResource.getContentLength() != webResourceInternal.getContentLength()))
/*     */     {
/* 111 */       return false;
/*     */     }
/*     */     
/* 114 */     this.nextCheck = (this.ttl + now);
/* 115 */     return true;
/*     */   }
/*     */   
/*     */   protected boolean validateResources(boolean useClassLoaderResources) {
/* 119 */     long now = System.currentTimeMillis();
/*     */     
/* 121 */     if (this.webResources == null) {
/* 122 */       synchronized (this) {
/* 123 */         if (this.webResources == null) {
/* 124 */           this.webResources = this.root.getResourcesInternal(this.webAppPath, useClassLoaderResources);
/*     */           
/* 126 */           this.nextCheck = (this.ttl + now);
/* 127 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 132 */     if (now < this.nextCheck) {
/* 133 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 138 */     return false;
/*     */   }
/*     */   
/*     */   protected long getNextCheck() {
/* 142 */     return this.nextCheck;
/*     */   }
/*     */   
/*     */   public long getLastModified()
/*     */   {
/* 147 */     Long cachedLastModified = this.cachedLastModified;
/* 148 */     if (cachedLastModified == null) {
/* 149 */       cachedLastModified = Long.valueOf(this.webResource.getLastModified());
/*     */       
/* 151 */       this.cachedLastModified = cachedLastModified;
/*     */     }
/* 153 */     return cachedLastModified.longValue();
/*     */   }
/*     */   
/*     */   public String getLastModifiedHttp()
/*     */   {
/* 158 */     String cachedLastModifiedHttp = this.cachedLastModifiedHttp;
/* 159 */     if (cachedLastModifiedHttp == null) {
/* 160 */       cachedLastModifiedHttp = this.webResource.getLastModifiedHttp();
/* 161 */       this.cachedLastModifiedHttp = cachedLastModifiedHttp;
/*     */     }
/* 163 */     return cachedLastModifiedHttp;
/*     */   }
/*     */   
/*     */   public boolean exists()
/*     */   {
/* 168 */     Boolean cachedExists = this.cachedExists;
/* 169 */     if (cachedExists == null) {
/* 170 */       cachedExists = Boolean.valueOf(this.webResource.exists());
/* 171 */       this.cachedExists = cachedExists;
/*     */     }
/* 173 */     return cachedExists.booleanValue();
/*     */   }
/*     */   
/*     */   public boolean isVirtual()
/*     */   {
/* 178 */     Boolean cachedIsVirtual = this.cachedIsVirtual;
/* 179 */     if (cachedIsVirtual == null) {
/* 180 */       cachedIsVirtual = Boolean.valueOf(this.webResource.isVirtual());
/* 181 */       this.cachedIsVirtual = cachedIsVirtual;
/*     */     }
/* 183 */     return cachedIsVirtual.booleanValue();
/*     */   }
/*     */   
/*     */   public boolean isDirectory()
/*     */   {
/* 188 */     Boolean cachedIsDirectory = this.cachedIsDirectory;
/* 189 */     if (cachedIsDirectory == null) {
/* 190 */       cachedIsDirectory = Boolean.valueOf(this.webResource.isDirectory());
/* 191 */       this.cachedIsDirectory = cachedIsDirectory;
/*     */     }
/* 193 */     return cachedIsDirectory.booleanValue();
/*     */   }
/*     */   
/*     */   public boolean isFile()
/*     */   {
/* 198 */     Boolean cachedIsFile = this.cachedIsFile;
/* 199 */     if (cachedIsFile == null) {
/* 200 */       cachedIsFile = Boolean.valueOf(this.webResource.isFile());
/* 201 */       this.cachedIsFile = cachedIsFile;
/*     */     }
/* 203 */     return cachedIsFile.booleanValue();
/*     */   }
/*     */   
/*     */   public boolean delete()
/*     */   {
/* 208 */     boolean deleteResult = this.webResource.delete();
/* 209 */     if (deleteResult) {
/* 210 */       this.cache.removeCacheEntry(this.webAppPath);
/*     */     }
/* 212 */     return deleteResult;
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/* 217 */     return this.webResource.getName();
/*     */   }
/*     */   
/*     */   public long getContentLength()
/*     */   {
/* 222 */     Long cachedContentLength = this.cachedContentLength;
/* 223 */     if (cachedContentLength == null) {
/* 224 */       long result = 0L;
/* 225 */       if (this.webResource != null) {
/* 226 */         result = this.webResource.getContentLength();
/* 227 */         cachedContentLength = Long.valueOf(result);
/* 228 */         this.cachedContentLength = cachedContentLength;
/*     */       }
/* 230 */       return result;
/*     */     }
/* 232 */     return cachedContentLength.longValue();
/*     */   }
/*     */   
/*     */   public String getCanonicalPath()
/*     */   {
/* 237 */     return this.webResource.getCanonicalPath();
/*     */   }
/*     */   
/*     */   public boolean canRead()
/*     */   {
/* 242 */     return this.webResource.canRead();
/*     */   }
/*     */   
/*     */   public String getWebappPath()
/*     */   {
/* 247 */     return this.webAppPath;
/*     */   }
/*     */   
/*     */   public String getETag()
/*     */   {
/* 252 */     return this.webResource.getETag();
/*     */   }
/*     */   
/*     */   public void setMimeType(String mimeType)
/*     */   {
/* 257 */     this.webResource.setMimeType(mimeType);
/*     */   }
/*     */   
/*     */   public String getMimeType()
/*     */   {
/* 262 */     return this.webResource.getMimeType();
/*     */   }
/*     */   
/*     */   public InputStream getInputStream()
/*     */   {
/* 267 */     byte[] content = this.cachedContent;
/* 268 */     if (content == null)
/*     */     {
/* 270 */       return this.webResource.getInputStream();
/*     */     }
/* 272 */     return new ByteArrayInputStream(content);
/*     */   }
/*     */   
/*     */   public byte[] getContent()
/*     */   {
/* 277 */     byte[] cachedContent = this.cachedContent;
/* 278 */     if (cachedContent == null) {
/* 279 */       if (getContentLength() > this.objectMaxSizeBytes) {
/* 280 */         return null;
/*     */       }
/* 282 */       cachedContent = this.webResource.getContent();
/* 283 */       this.cachedContent = cachedContent;
/*     */     }
/* 285 */     return cachedContent;
/*     */   }
/*     */   
/*     */   public long getCreation()
/*     */   {
/* 290 */     return this.webResource.getCreation();
/*     */   }
/*     */   
/*     */   public URL getURL()
/*     */   {
/* 295 */     return this.webResource.getURL();
/*     */   }
/*     */   
/*     */   public URL getCodeBase()
/*     */   {
/* 300 */     return this.webResource.getCodeBase();
/*     */   }
/*     */   
/*     */   public Certificate[] getCertificates()
/*     */   {
/* 305 */     return this.webResource.getCertificates();
/*     */   }
/*     */   
/*     */   public Manifest getManifest()
/*     */   {
/* 310 */     return this.webResource.getManifest();
/*     */   }
/*     */   
/*     */   public WebResourceRoot getWebResourceRoot()
/*     */   {
/* 315 */     return this.webResource.getWebResourceRoot();
/*     */   }
/*     */   
/*     */   WebResource getWebResource() {
/* 319 */     return this.webResource;
/*     */   }
/*     */   
/*     */   WebResource[] getWebResources() {
/* 323 */     return this.webResources;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   long getSize()
/*     */   {
/* 330 */     long result = 500L;
/* 331 */     if (getContentLength() <= this.objectMaxSizeBytes) {
/* 332 */       result += getContentLength();
/*     */     }
/* 334 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\webresources\CachedResource.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */