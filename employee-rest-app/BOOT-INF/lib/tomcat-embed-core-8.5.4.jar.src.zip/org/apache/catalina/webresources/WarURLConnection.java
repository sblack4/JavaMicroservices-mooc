/*    */ package org.apache.catalina.webresources;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WarURLConnection
/*    */   extends URLConnection
/*    */ {
/*    */   private final URLConnection innerJarUrlConnection;
/*    */   private boolean connected;
/*    */   
/*    */   protected WarURLConnection(URL url)
/*    */     throws IOException
/*    */   {
/* 31 */     super(url);
/* 32 */     URL innerJarUrl = new URL(url.getFile());
/* 33 */     this.innerJarUrlConnection = innerJarUrl.openConnection();
/*    */   }
/*    */   
/*    */   public void connect() throws IOException
/*    */   {
/* 38 */     if (!this.connected) {
/* 39 */       this.innerJarUrlConnection.connect();
/* 40 */       this.connected = true;
/*    */     }
/*    */   }
/*    */   
/*    */   public InputStream getInputStream() throws IOException
/*    */   {
/* 46 */     connect();
/* 47 */     return this.innerJarUrlConnection.getInputStream();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\webresources\WarURLConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */