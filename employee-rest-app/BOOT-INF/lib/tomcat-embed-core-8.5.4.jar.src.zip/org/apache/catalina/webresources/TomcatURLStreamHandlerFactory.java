/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.net.URLStreamHandler;
/*     */ import java.net.URLStreamHandlerFactory;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TomcatURLStreamHandlerFactory
/*     */   implements URLStreamHandlerFactory
/*     */ {
/*     */   private static final String WAR_PROTOCOL = "war";
/*     */   private static final String CLASSPTH_PROTOCOL = "classpath";
/*  31 */   private static volatile TomcatURLStreamHandlerFactory instance = null;
/*     */   
/*     */ 
/*     */ 
/*     */   private final boolean registered;
/*     */   
/*     */ 
/*     */ 
/*     */   public static TomcatURLStreamHandlerFactory getInstance()
/*     */   {
/*  41 */     getInstanceInternal(true);
/*  42 */     return instance;
/*     */   }
/*     */   
/*     */ 
/*     */   private static TomcatURLStreamHandlerFactory getInstanceInternal(boolean register)
/*     */   {
/*  48 */     if (instance == null) {
/*  49 */       synchronized (TomcatURLStreamHandlerFactory.class) {
/*  50 */         if (instance == null) {
/*  51 */           instance = new TomcatURLStreamHandlerFactory(register);
/*     */         }
/*     */       }
/*     */     }
/*  55 */     return instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  62 */   private final List<URLStreamHandlerFactory> userFactories = new CopyOnWriteArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean register()
/*     */   {
/*  75 */     return getInstanceInternal(true).isRegistered();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean disable()
/*     */   {
/*  90 */     return !getInstanceInternal(false).isRegistered();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void release(ClassLoader classLoader)
/*     */   {
/* 102 */     if (instance == null) {
/* 103 */       return;
/*     */     }
/* 105 */     List<URLStreamHandlerFactory> factories = instance.userFactories;
/* 106 */     for (URLStreamHandlerFactory factory : factories) {
/* 107 */       ClassLoader factoryLoader = factory.getClass().getClassLoader();
/* 108 */       while (factoryLoader != null) {
/* 109 */         if (classLoader.equals(factoryLoader))
/*     */         {
/*     */ 
/*     */ 
/* 113 */           factories.remove(factory);
/* 114 */           break;
/*     */         }
/* 116 */         factoryLoader = factoryLoader.getParent();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private TomcatURLStreamHandlerFactory(boolean register)
/*     */   {
/* 126 */     this.registered = register;
/* 127 */     if (register) {
/* 128 */       URL.setURLStreamHandlerFactory(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isRegistered()
/*     */   {
/* 134 */     return this.registered;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addUserFactory(URLStreamHandlerFactory factory)
/*     */   {
/* 148 */     this.userFactories.add(factory);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URLStreamHandler createURLStreamHandler(String protocol)
/*     */   {
/* 157 */     if ("war".equals(protocol))
/* 158 */       return new WarURLStreamHandler();
/* 159 */     if ("classpath".equals(protocol)) {
/* 160 */       return new ClasspathURLStreamHandler();
/*     */     }
/*     */     
/*     */ 
/* 164 */     for (URLStreamHandlerFactory factory : this.userFactories) {
/* 165 */       URLStreamHandler handler = factory.createURLStreamHandler(protocol);
/*     */       
/* 167 */       if (handler != null) {
/* 168 */         return handler;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 173 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\webresources\TomcatURLStreamHandlerFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */