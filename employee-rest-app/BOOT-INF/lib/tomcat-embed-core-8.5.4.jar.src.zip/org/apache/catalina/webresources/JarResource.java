/*    */ package org.apache.catalina.webresources;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.jar.JarEntry;
/*    */ import java.util.jar.JarFile;
/*    */ import org.apache.juli.logging.Log;
/*    */ import org.apache.juli.logging.LogFactory;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JarResource
/*    */   extends AbstractArchiveResource
/*    */ {
/* 33 */   private static final Log log = LogFactory.getLog(JarResource.class);
/*    */   
/*    */   public JarResource(AbstractArchiveResourceSet archiveResourceSet, String webAppPath, String baseUrl, JarEntry jarEntry)
/*    */   {
/* 37 */     super(archiveResourceSet, webAppPath, "jar:" + baseUrl, jarEntry, baseUrl);
/*    */   }
/*    */   
/*    */   protected AbstractArchiveResource.JarInputStreamWrapper getJarInputStreamWrapper()
/*    */   {
/* 42 */     JarFile jarFile = null;
/*    */     try {
/* 44 */       jarFile = getArchiveResourceSet().openJarFile();
/*    */       
/* 46 */       JarEntry jarEntry = jarFile.getJarEntry(getResource().getName());
/* 47 */       InputStream is = jarFile.getInputStream(jarEntry);
/* 48 */       return new AbstractArchiveResource.JarInputStreamWrapper(this, jarEntry, is);
/*    */     } catch (IOException e) {
/* 50 */       if (log.isDebugEnabled()) {
/* 51 */         log.debug(sm.getString("jarResource.getInputStreamFail", new Object[] { getResource().getName(), getBaseUrl() }), e);
/*    */       }
/*    */       
/* 54 */       if (jarFile != null)
/* 55 */         getArchiveResourceSet().closeJarFile();
/*    */     }
/* 57 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   protected Log getLog()
/*    */   {
/* 63 */     return log;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\webresources\JarResource.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */