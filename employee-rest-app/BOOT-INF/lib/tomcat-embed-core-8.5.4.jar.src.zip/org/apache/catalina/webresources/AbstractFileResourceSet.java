/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.tomcat.util.http.RequestUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractFileResourceSet
/*     */   extends AbstractResourceSet
/*     */ {
/*  29 */   protected static final String[] EMPTY_STRING_ARRAY = new String[0];
/*     */   
/*     */   private File fileBase;
/*     */   private String absoluteBase;
/*     */   private String canonicalBase;
/*  34 */   private boolean readOnly = false;
/*     */   
/*     */   protected AbstractFileResourceSet(String internalPath) {
/*  37 */     setInternalPath(internalPath);
/*     */   }
/*     */   
/*     */   protected final File getFileBase() {
/*  41 */     return this.fileBase;
/*     */   }
/*     */   
/*     */   public void setReadOnly(boolean readOnly)
/*     */   {
/*  46 */     this.readOnly = readOnly;
/*     */   }
/*     */   
/*     */   public boolean isReadOnly()
/*     */   {
/*  51 */     return this.readOnly;
/*     */   }
/*     */   
/*     */   protected final File file(String name, boolean mustExist)
/*     */   {
/*  56 */     if (name.equals("/")) {
/*  57 */       name = "";
/*     */     }
/*  59 */     File file = new File(this.fileBase, name);
/*  60 */     if ((!mustExist) || (file.canRead()))
/*     */     {
/*  62 */       if (getRoot().getAllowLinking()) {
/*  63 */         return file;
/*     */       }
/*     */       
/*     */ 
/*  67 */       String canPath = null;
/*     */       try {
/*  69 */         canPath = file.getCanonicalPath();
/*     */       }
/*     */       catch (IOException localIOException) {}
/*     */       
/*  73 */       if (canPath == null) {
/*  74 */         return null;
/*     */       }
/*  76 */       if (!canPath.startsWith(this.canonicalBase)) {
/*  77 */         return null;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */       String fileAbsPath = file.getAbsolutePath();
/*  86 */       if (fileAbsPath.endsWith("."))
/*  87 */         fileAbsPath = fileAbsPath + '/';
/*  88 */       String absPath = normalize(fileAbsPath);
/*  89 */       if ((this.absoluteBase.length() < absPath.length()) && (this.canonicalBase.length() < canPath.length()))
/*     */       {
/*  91 */         absPath = absPath.substring(this.absoluteBase.length() + 1);
/*  92 */         if (absPath.equals(""))
/*  93 */           absPath = "/";
/*  94 */         canPath = canPath.substring(this.canonicalBase.length() + 1);
/*  95 */         if (canPath.equals(""))
/*  96 */           canPath = "/";
/*  97 */         if (!canPath.equals(absPath)) {
/*  98 */           return null;
/*     */         }
/*     */       }
/*     */     } else {
/* 102 */       return null;
/*     */     }
/* 104 */     return file;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String normalize(String path)
/*     */   {
/* 117 */     return RequestUtil.normalize(path, File.separatorChar == '/');
/*     */   }
/*     */   
/*     */   public URL getBaseUrl()
/*     */   {
/*     */     try {
/* 123 */       return getFileBase().toURI().toURL();
/*     */     } catch (MalformedURLException e) {}
/* 125 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void gc() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initInternal()
/*     */     throws LifecycleException
/*     */   {
/* 144 */     this.fileBase = new File(getBase(), getInternalPath());
/* 145 */     checkType(this.fileBase);
/*     */     
/* 147 */     String absolutePath = this.fileBase.getAbsolutePath();
/* 148 */     if (absolutePath.endsWith(".")) {
/* 149 */       absolutePath = absolutePath + '/';
/*     */     }
/* 151 */     this.absoluteBase = normalize(absolutePath);
/*     */     try
/*     */     {
/* 154 */       this.canonicalBase = this.fileBase.getCanonicalPath();
/*     */     } catch (IOException e) {
/* 156 */       throw new IllegalArgumentException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract void checkType(File paramFile);
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\webresources\AbstractFileResourceSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */