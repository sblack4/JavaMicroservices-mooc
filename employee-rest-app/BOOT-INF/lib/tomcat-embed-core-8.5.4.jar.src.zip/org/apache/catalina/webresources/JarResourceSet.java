/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.jar.Manifest;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.tomcat.util.buf.UriUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JarResourceSet
/*     */   extends AbstractArchiveResourceSet
/*     */ {
/*     */   public JarResourceSet() {}
/*     */   
/*     */   public JarResourceSet(WebResourceRoot root, String webAppMount, String base, String internalPath)
/*     */     throws IllegalArgumentException
/*     */   {
/*  66 */     setRoot(root);
/*  67 */     setWebAppMount(webAppMount);
/*  68 */     setBase(base);
/*  69 */     setInternalPath(internalPath);
/*     */     
/*  71 */     if (getRoot().getState().isAvailable()) {
/*     */       try {
/*  73 */         start();
/*     */       } catch (LifecycleException e) {
/*  75 */         throw new IllegalStateException(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected WebResource createArchiveResource(JarEntry jarEntry, String webAppPath, Manifest manifest)
/*     */   {
/*  83 */     return new JarResource(this, webAppPath, getBaseUrlString(), jarEntry);
/*     */   }
/*     */   
/*     */ 
/*     */   protected HashMap<String, JarEntry> getArchiveEntries(boolean single)
/*     */   {
/*  89 */     synchronized (this.archiveLock) {
/*  90 */       if ((this.archiveEntries == null) && (!single)) {
/*  91 */         JarFile jarFile = null;
/*  92 */         this.archiveEntries = new HashMap();
/*     */         try {
/*  94 */           jarFile = openJarFile();
/*  95 */           Enumeration<JarEntry> entries = jarFile.entries();
/*  96 */           while (entries.hasMoreElements()) {
/*  97 */             JarEntry entry = (JarEntry)entries.nextElement();
/*  98 */             this.archiveEntries.put(entry.getName(), entry);
/*     */           }
/*     */         }
/*     */         catch (IOException ioe) {
/* 102 */           this.archiveEntries = null;
/* 103 */           throw new IllegalStateException(ioe);
/*     */         } finally {
/* 105 */           if (jarFile != null) {
/* 106 */             closeJarFile();
/*     */           }
/*     */         }
/*     */       }
/* 110 */       return this.archiveEntries;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected JarEntry getArchiveEntry(String pathInArchive)
/*     */   {
/* 117 */     JarFile jarFile = null;
/*     */     try {
/* 119 */       jarFile = openJarFile();
/* 120 */       return jarFile.getJarEntry(pathInArchive);
/*     */     }
/*     */     catch (IOException ioe) {
/* 123 */       throw new IllegalStateException(ioe);
/*     */     } finally {
/* 125 */       if (jarFile != null) {
/* 126 */         closeJarFile();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void initInternal()
/*     */     throws LifecycleException
/*     */   {
/*     */     try
/*     */     {
/* 136 */       JarFile jarFile = new JarFile(getBase());Throwable localThrowable2 = null;
/* 137 */       try { setManifest(jarFile.getManifest());
/*     */       }
/*     */       catch (Throwable localThrowable1)
/*     */       {
/* 136 */         localThrowable2 = localThrowable1;throw localThrowable1;
/*     */       } finally {
/* 138 */         if (jarFile != null) if (localThrowable2 != null) try { jarFile.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else jarFile.close();
/* 139 */       } } catch (IOException ioe) { throw new IllegalArgumentException(ioe);
/*     */     }
/*     */     try
/*     */     {
/* 143 */       setBaseUrl(UriUtil.buildJarSafeUrl(new File(getBase())));
/*     */     } catch (MalformedURLException e) {
/* 145 */       throw new IllegalArgumentException(e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\webresources\JarResourceSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */