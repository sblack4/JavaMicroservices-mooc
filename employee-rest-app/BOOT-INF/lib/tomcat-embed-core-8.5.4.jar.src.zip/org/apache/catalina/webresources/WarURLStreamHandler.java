/*    */ package org.apache.catalina.webresources;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import java.net.URLStreamHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WarURLStreamHandler
/*    */   extends URLStreamHandler
/*    */ {
/*    */   protected void parseURL(URL u, String spec, int start, int limit)
/*    */   {
/* 32 */     String path = "jar:" + spec.substring(4);
/* 33 */     if (path.contains("*/")) {
/* 34 */       path = path.replaceFirst("\\*/", "!/");
/*    */     } else {
/* 36 */       path = path.replaceFirst("\\^/", "!/");
/*    */     }
/*    */     
/* 39 */     setURL(u, u.getProtocol(), "", -1, null, null, path, null, null);
/*    */   }
/*    */   
/*    */   protected URLConnection openConnection(URL u)
/*    */     throws IOException
/*    */   {
/* 45 */     return new WarURLConnection(u);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\webresources\WarURLStreamHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */