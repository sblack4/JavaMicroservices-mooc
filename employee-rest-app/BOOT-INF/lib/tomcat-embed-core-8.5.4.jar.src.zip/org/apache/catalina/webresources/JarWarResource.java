/*    */ package org.apache.catalina.webresources;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.jar.JarEntry;
/*    */ import java.util.jar.JarFile;
/*    */ import java.util.jar.JarInputStream;
/*    */ import org.apache.juli.logging.Log;
/*    */ import org.apache.juli.logging.LogFactory;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JarWarResource
/*    */   extends AbstractArchiveResource
/*    */ {
/* 34 */   private static final Log log = LogFactory.getLog(JarWarResource.class);
/*    */   
/*    */   private final String archivePath;
/*    */   
/*    */   public JarWarResource(AbstractArchiveResourceSet archiveResourceSet, String webAppPath, String baseUrl, JarEntry jarEntry, String archivePath)
/*    */   {
/* 40 */     super(archiveResourceSet, webAppPath, "jar:war:" + baseUrl + "*/" + archivePath, jarEntry, "jar:" + baseUrl + "!/" + archivePath);
/*    */     
/* 42 */     this.archivePath = archivePath;
/*    */   }
/*    */   
/*    */   protected AbstractArchiveResource.JarInputStreamWrapper getJarInputStreamWrapper()
/*    */   {
/* 47 */     JarFile warFile = null;
/* 48 */     JarInputStream jarIs = null;
/* 49 */     JarEntry entry = null;
/*    */     try {
/* 51 */       warFile = getArchiveResourceSet().openJarFile();
/* 52 */       JarEntry jarFileInWar = warFile.getJarEntry(this.archivePath);
/* 53 */       isInWar = warFile.getInputStream(jarFileInWar);
/*    */       
/* 55 */       jarIs = new JarInputStream(isInWar);
/* 56 */       entry = jarIs.getNextJarEntry();
/* 57 */       while ((entry != null) && (!entry.getName().equals(getResource().getName())))
/*    */       {
/* 59 */         entry = jarIs.getNextJarEntry();
/*    */       }
/*    */       AbstractArchiveResource.JarInputStreamWrapper localJarInputStreamWrapper;
/* 62 */       if (entry == null) {
/* 63 */         return null;
/*    */       }
/*    */       
/* 66 */       return new AbstractArchiveResource.JarInputStreamWrapper(this, entry, jarIs);
/*    */     } catch (IOException e) { InputStream isInWar;
/* 68 */       if (log.isDebugEnabled()) {
/* 69 */         log.debug(sm.getString("jarResource.getInputStreamFail", new Object[] { getResource().getName(), getBaseUrl() }), e);
/*    */       }
/*    */       
/* 72 */       return null;
/*    */     } finally {
/* 74 */       if (entry == null) {
/* 75 */         if (jarIs != null) {
/*    */           try {
/* 77 */             jarIs.close();
/*    */           }
/*    */           catch (IOException localIOException4) {}
/*    */         }
/*    */         
/* 82 */         if (warFile != null) {
/* 83 */           getArchiveResourceSet().closeJarFile();
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   protected Log getLog()
/*    */   {
/* 91 */     return log;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\webresources\JarWarResource.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */