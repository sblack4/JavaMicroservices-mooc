/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.jar.Manifest;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.catalina.util.ResourceSet;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractArchiveResourceSet
/*     */   extends AbstractResourceSet
/*     */ {
/*     */   private URL baseUrl;
/*     */   private String baseUrlString;
/*  41 */   private JarFile archive = null;
/*  42 */   protected HashMap<String, JarEntry> archiveEntries = null;
/*  43 */   protected final Object archiveLock = new Object();
/*  44 */   private long archiveUseCount = 0L;
/*     */   
/*     */   protected final void setBaseUrl(URL baseUrl)
/*     */   {
/*  48 */     this.baseUrl = baseUrl;
/*  49 */     if (baseUrl == null) {
/*  50 */       this.baseUrlString = null;
/*     */     } else {
/*  52 */       this.baseUrlString = baseUrl.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   public final URL getBaseUrl()
/*     */   {
/*  58 */     return this.baseUrl;
/*     */   }
/*     */   
/*     */   protected final String getBaseUrlString() {
/*  62 */     return this.baseUrlString;
/*     */   }
/*     */   
/*     */ 
/*     */   public final String[] list(String path)
/*     */   {
/*  68 */     checkPath(path);
/*  69 */     String webAppMount = getWebAppMount();
/*     */     
/*  71 */     ArrayList<String> result = new ArrayList();
/*  72 */     if (path.startsWith(webAppMount)) {
/*  73 */       String pathInJar = getInternalPath() + path.substring(webAppMount.length());
/*     */       
/*     */ 
/*  76 */       if ((pathInJar.length() > 0) && (pathInJar.charAt(0) == '/')) {
/*  77 */         pathInJar = pathInJar.substring(1);
/*     */       }
/*  79 */       Iterator<String> entries = getArchiveEntries(false).keySet().iterator();
/*  80 */       while (entries.hasNext()) {
/*  81 */         String name = (String)entries.next();
/*  82 */         if ((name.length() > pathInJar.length()) && (name.startsWith(pathInJar)))
/*     */         {
/*  84 */           if (name.charAt(name.length() - 1) == '/') {
/*  85 */             name = name.substring(pathInJar.length(), name.length() - 1);
/*     */           }
/*     */           else {
/*  88 */             name = name.substring(pathInJar.length());
/*     */           }
/*  90 */           if (name.length() != 0)
/*     */           {
/*     */ 
/*  93 */             if (name.charAt(0) == '/') {
/*  94 */               name = name.substring(1);
/*     */             }
/*  96 */             if ((name.length() > 0) && (name.lastIndexOf('/') == -1))
/*  97 */               result.add(name);
/*     */           }
/*     */         }
/*     */       }
/*     */     } else {
/* 102 */       if (!path.endsWith("/")) {
/* 103 */         path = path + "/";
/*     */       }
/* 105 */       if (webAppMount.startsWith(path)) {
/* 106 */         int i = webAppMount.indexOf('/', path.length());
/* 107 */         if (i == -1) {
/* 108 */           return new String[] { webAppMount.substring(path.length()) };
/*     */         }
/* 110 */         return new String[] { webAppMount.substring(path.length(), i) };
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 115 */     return (String[])result.toArray(new String[result.size()]);
/*     */   }
/*     */   
/*     */   public final Set<String> listWebAppPaths(String path)
/*     */   {
/* 120 */     checkPath(path);
/* 121 */     String webAppMount = getWebAppMount();
/*     */     
/* 123 */     ResourceSet<String> result = new ResourceSet();
/* 124 */     if (path.startsWith(webAppMount)) {
/* 125 */       String pathInJar = getInternalPath() + path.substring(webAppMount.length());
/*     */       
/*     */ 
/*     */ 
/* 129 */       if (pathInJar.length() > 0) {
/* 130 */         if (pathInJar.charAt(pathInJar.length() - 1) != '/') {
/* 131 */           pathInJar = pathInJar.substring(1) + '/';
/*     */         }
/* 133 */         if (pathInJar.charAt(0) == '/') {
/* 134 */           pathInJar = pathInJar.substring(1);
/*     */         }
/*     */       }
/*     */       
/* 138 */       Iterator<String> entries = getArchiveEntries(false).keySet().iterator();
/* 139 */       while (entries.hasNext()) {
/* 140 */         String name = (String)entries.next();
/* 141 */         if ((name.length() > pathInJar.length()) && (name.startsWith(pathInJar)))
/*     */         {
/* 143 */           int nextSlash = name.indexOf('/', pathInJar.length());
/* 144 */           if (((nextSlash == -1) || (nextSlash == name.length() - 1)) && 
/* 145 */             (name.startsWith(pathInJar))) {
/* 146 */             result.add(webAppMount + '/' + name.substring(getInternalPath().length()));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 153 */       if (!path.endsWith("/")) {
/* 154 */         path = path + "/";
/*     */       }
/* 156 */       if (webAppMount.startsWith(path)) {
/* 157 */         int i = webAppMount.indexOf('/', path.length());
/* 158 */         if (i == -1) {
/* 159 */           result.add(webAppMount + "/");
/*     */         } else {
/* 161 */           result.add(webAppMount.substring(0, i + 1));
/*     */         }
/*     */       }
/*     */     }
/* 165 */     result.setLocked(true);
/* 166 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract HashMap<String, JarEntry> getArchiveEntries(boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract JarEntry getArchiveEntry(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean mkdir(String path)
/*     */   {
/* 199 */     checkPath(path);
/*     */     
/* 201 */     return false;
/*     */   }
/*     */   
/*     */   public final boolean write(String path, InputStream is, boolean overwrite)
/*     */   {
/* 206 */     checkPath(path);
/*     */     
/* 208 */     if (is == null) {
/* 209 */       throw new NullPointerException(sm.getString("dirResourceSet.writeNpe"));
/*     */     }
/*     */     
/*     */ 
/* 213 */     return false;
/*     */   }
/*     */   
/*     */   public final WebResource getResource(String path)
/*     */   {
/* 218 */     checkPath(path);
/* 219 */     String webAppMount = getWebAppMount();
/* 220 */     WebResourceRoot root = getRoot();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 240 */     if (path.startsWith(webAppMount)) {
/* 241 */       String pathInJar = getInternalPath() + path.substring(webAppMount.length(), path.length());
/*     */       
/*     */ 
/* 244 */       if ((pathInJar.length() > 0) && (pathInJar.charAt(0) == '/')) {
/* 245 */         pathInJar = pathInJar.substring(1);
/*     */       }
/* 247 */       if (pathInJar.equals(""))
/*     */       {
/*     */ 
/* 250 */         if (!path.endsWith("/")) {
/* 251 */           path = path + "/";
/*     */         }
/* 253 */         return new JarResourceRoot(root, new File(getBase()), this.baseUrlString, path);
/*     */       }
/*     */       
/* 256 */       Map<String, JarEntry> jarEntries = getArchiveEntries(true);
/* 257 */       JarEntry jarEntry = null;
/* 258 */       if (pathInJar.charAt(pathInJar.length() - 1) != '/') {
/* 259 */         if (jarEntries == null) {
/* 260 */           jarEntry = getArchiveEntry(pathInJar + '/');
/*     */         } else {
/* 262 */           jarEntry = (JarEntry)jarEntries.get(pathInJar + '/');
/*     */         }
/* 264 */         if (jarEntry != null) {
/* 265 */           path = path + '/';
/*     */         }
/*     */       }
/* 268 */       if (jarEntry == null) {
/* 269 */         if (jarEntries == null) {
/* 270 */           jarEntry = getArchiveEntry(pathInJar);
/*     */         } else {
/* 272 */           jarEntry = (JarEntry)jarEntries.get(pathInJar);
/*     */         }
/*     */       }
/* 275 */       if (jarEntry == null) {
/* 276 */         return new EmptyResource(root, path);
/*     */       }
/* 278 */       return createArchiveResource(jarEntry, path, getManifest());
/*     */     }
/*     */     
/*     */ 
/* 282 */     return new EmptyResource(root, path);
/*     */   }
/*     */   
/*     */ 
/*     */   protected abstract WebResource createArchiveResource(JarEntry paramJarEntry, String paramString, Manifest paramManifest);
/*     */   
/*     */ 
/*     */   public final boolean isReadOnly()
/*     */   {
/* 291 */     return true;
/*     */   }
/*     */   
/*     */   public void setReadOnly(boolean readOnly)
/*     */   {
/* 296 */     if (readOnly)
/*     */     {
/* 298 */       return;
/*     */     }
/*     */     
/* 301 */     throw new IllegalArgumentException(sm.getString("abstractArchiveResourceSet.setReadOnlyFalse"));
/*     */   }
/*     */   
/*     */   protected JarFile openJarFile() throws IOException
/*     */   {
/* 306 */     synchronized (this.archiveLock) {
/* 307 */       if (this.archive == null) {
/* 308 */         this.archive = new JarFile(getBase());
/*     */       }
/* 310 */       this.archiveUseCount += 1L;
/* 311 */       return this.archive;
/*     */     }
/*     */   }
/*     */   
/*     */   protected void closeJarFile() {
/* 316 */     synchronized (this.archiveLock) {
/* 317 */       this.archiveUseCount -= 1L;
/*     */     }
/*     */   }
/*     */   
/*     */   public void gc()
/*     */   {
/* 323 */     synchronized (this.archiveLock) {
/* 324 */       if ((this.archive != null) && (this.archiveUseCount == 0L)) {
/*     */         try {
/* 326 */           this.archive.close();
/*     */         }
/*     */         catch (IOException localIOException) {}
/*     */         
/* 330 */         this.archive = null;
/* 331 */         this.archiveEntries = null;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\webresources\AbstractArchiveResourceSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */