/*      */ package org.apache.catalina.startup;
/*      */ 
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.net.URI;
/*      */ import java.nio.file.CopyOption;
/*      */ import java.nio.file.Files;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.SortedSet;
/*      */ import java.util.TreeSet;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ExecutorService;
/*      */ import java.util.concurrent.Future;
/*      */ import java.util.jar.JarEntry;
/*      */ import java.util.jar.JarFile;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import javax.management.ObjectName;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.DistributedManager;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.LifecycleEvent;
/*      */ import org.apache.catalina.LifecycleListener;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.core.StandardContext;
/*      */ import org.apache.catalina.core.StandardHost;
/*      */ import org.apache.catalina.util.ContextName;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.buf.UriUtil;
/*      */ import org.apache.tomcat.util.digester.Digester;
/*      */ import org.apache.tomcat.util.modeler.Registry;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HostConfig
/*      */   implements LifecycleListener
/*      */ {
/*   75 */   private static final Log log = LogFactory.getLog(HostConfig.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   80 */   protected static final StringManager sm = StringManager.getManager(HostConfig.class);
/*      */   
/*      */   protected static final long FILE_MODIFICATION_RESOLUTION_MS = 1000L;
/*      */   
/*      */   protected String contextClass;
/*      */   
/*      */   protected Host host;
/*      */   protected ObjectName oname;
/*      */   protected boolean deployXML;
/*      */   protected boolean copyXML;
/*      */   
/*      */   public HostConfig()
/*      */   {
/*   93 */     this.contextClass = "org.apache.catalina.core.StandardContext";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   99 */     this.host = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  105 */     this.oname = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  112 */     this.deployXML = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  120 */     this.copyXML = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  127 */     this.unpackWARs = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  133 */     this.deployed = new ConcurrentHashMap();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  141 */     this.serviced = new ArrayList();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  147 */     this.digester = createDigester(this.contextClass);
/*  148 */     this.digesterLock = new Object();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  154 */     this.invalidWars = new HashSet();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getContextClass()
/*      */   {
/*  164 */     return this.contextClass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setContextClass(String contextClass)
/*      */   {
/*  176 */     String oldContextClass = this.contextClass;
/*  177 */     this.contextClass = contextClass;
/*      */     
/*  179 */     if (!oldContextClass.equals(contextClass)) {
/*  180 */       synchronized (this.digesterLock) {
/*  181 */         this.digester = createDigester(getContextClass());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isDeployXML()
/*      */   {
/*  192 */     return this.deployXML;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDeployXML(boolean deployXML)
/*      */   {
/*  204 */     this.deployXML = deployXML;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isCopyXML()
/*      */   {
/*  214 */     return this.copyXML;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCopyXML(boolean copyXML)
/*      */   {
/*  226 */     this.copyXML = copyXML;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUnpackWARs()
/*      */   {
/*  236 */     return this.unpackWARs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUnpackWARs(boolean unpackWARs)
/*      */   {
/*  248 */     this.unpackWARs = unpackWARs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void lifecycleEvent(LifecycleEvent event)
/*      */   {
/*      */     try
/*      */     {
/*  266 */       this.host = ((Host)event.getLifecycle());
/*  267 */       if ((this.host instanceof StandardHost)) {
/*  268 */         setCopyXML(((StandardHost)this.host).isCopyXML());
/*  269 */         setDeployXML(((StandardHost)this.host).isDeployXML());
/*  270 */         setUnpackWARs(((StandardHost)this.host).isUnpackWARs());
/*  271 */         setContextClass(((StandardHost)this.host).getContextClass());
/*      */       }
/*      */     } catch (ClassCastException e) {
/*  274 */       log.error(sm.getString("hostConfig.cce", new Object[] { event.getLifecycle() }), e);
/*  275 */       return;
/*      */     }
/*      */     
/*      */ 
/*  279 */     if (event.getType().equals("periodic")) {
/*  280 */       check();
/*  281 */     } else if (event.getType().equals("before_start")) {
/*  282 */       beforeStart();
/*  283 */     } else if (event.getType().equals("start")) {
/*  284 */       start();
/*  285 */     } else if (event.getType().equals("stop")) {
/*  286 */       stop();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void addServiced(String name)
/*      */   {
/*  296 */     this.serviced.add(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isServiced(String name)
/*      */   {
/*  306 */     return this.serviced.contains(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void removeServiced(String name)
/*      */   {
/*  315 */     this.serviced.remove(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getDeploymentTime(String name)
/*      */   {
/*  326 */     DeployedApplication app = (DeployedApplication)this.deployed.get(name);
/*  327 */     if (app == null) {
/*  328 */       return 0L;
/*      */     }
/*      */     
/*  331 */     return app.timestamp;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isDeployed(String name)
/*      */   {
/*  344 */     DeployedApplication app = (DeployedApplication)this.deployed.get(name);
/*  345 */     if (app == null) {
/*  346 */       return false;
/*      */     }
/*      */     
/*  349 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static Digester createDigester(String contextClassName)
/*      */   {
/*  363 */     Digester digester = new Digester();
/*  364 */     digester.setValidating(false);
/*      */     
/*  366 */     digester.addObjectCreate("Context", contextClassName, "className");
/*      */     
/*      */ 
/*  369 */     digester.addSetProperties("Context");
/*  370 */     return digester;
/*      */   }
/*      */   
/*      */   protected File returnCanonicalPath(String path) {
/*  374 */     File file = new File(path);
/*  375 */     if (!file.isAbsolute())
/*  376 */       file = new File(this.host.getCatalinaBase(), path);
/*      */     try {
/*  378 */       return file.getCanonicalFile();
/*      */     } catch (IOException e) {}
/*  380 */     return file;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getConfigBaseName()
/*      */   {
/*  391 */     return this.host.getConfigBaseFile().getAbsolutePath();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void deployApps()
/*      */   {
/*  401 */     File appBase = this.host.getAppBaseFile();
/*  402 */     File configBase = this.host.getConfigBaseFile();
/*  403 */     String[] filteredAppPaths = filterAppPaths(appBase.list());
/*      */     
/*  405 */     deployDescriptors(configBase, configBase.list());
/*      */     
/*  407 */     deployWARs(appBase, filteredAppPaths);
/*      */     
/*  409 */     deployDirectories(appBase, filteredAppPaths);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String[] filterAppPaths(String[] unfilteredAppPaths)
/*      */   {
/*  423 */     Pattern filter = this.host.getDeployIgnorePattern();
/*  424 */     if ((filter == null) || (unfilteredAppPaths == null)) {
/*  425 */       return unfilteredAppPaths;
/*      */     }
/*      */     
/*  428 */     List<String> filteredList = new ArrayList();
/*  429 */     Matcher matcher = null;
/*  430 */     for (String appPath : unfilteredAppPaths) {
/*  431 */       if (matcher == null) {
/*  432 */         matcher = filter.matcher(appPath);
/*      */       } else {
/*  434 */         matcher.reset(appPath);
/*      */       }
/*  436 */       if (matcher.matches()) {
/*  437 */         if (log.isDebugEnabled()) {
/*  438 */           log.debug(sm.getString("hostConfig.ignorePath", new Object[] { appPath }));
/*      */         }
/*      */       } else {
/*  441 */         filteredList.add(appPath);
/*      */       }
/*      */     }
/*  444 */     return (String[])filteredList.toArray(new String[filteredList.size()]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void deployApps(String name)
/*      */   {
/*  455 */     File appBase = this.host.getAppBaseFile();
/*  456 */     File configBase = this.host.getConfigBaseFile();
/*  457 */     ContextName cn = new ContextName(name, false);
/*  458 */     String baseName = cn.getBaseName();
/*      */     
/*  460 */     if (deploymentExists(cn.getName())) {
/*  461 */       return;
/*      */     }
/*      */     
/*      */ 
/*  465 */     File xml = new File(configBase, baseName + ".xml");
/*  466 */     if (xml.exists()) {
/*  467 */       deployDescriptor(cn, xml);
/*  468 */       return;
/*      */     }
/*      */     
/*  471 */     File war = new File(appBase, baseName + ".war");
/*  472 */     if (war.exists()) {
/*  473 */       deployWAR(cn, war);
/*  474 */       return;
/*      */     }
/*      */     
/*  477 */     File dir = new File(appBase, baseName);
/*  478 */     if (dir.exists()) {
/*  479 */       deployDirectory(cn, dir);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void deployDescriptors(File configBase, String[] files)
/*      */   {
/*  490 */     if (files == null) {
/*  491 */       return;
/*      */     }
/*  493 */     ExecutorService es = this.host.getStartStopExecutor();
/*  494 */     List<Future<?>> results = new ArrayList();
/*      */     
/*  496 */     for (int i = 0; i < files.length; i++) {
/*  497 */       File contextXml = new File(configBase, files[i]);
/*      */       
/*  499 */       if (files[i].toLowerCase(Locale.ENGLISH).endsWith(".xml")) {
/*  500 */         ContextName cn = new ContextName(files[i], true);
/*      */         
/*  502 */         if ((!isServiced(cn.getName())) && (!deploymentExists(cn.getName())))
/*      */         {
/*      */ 
/*  505 */           results.add(es.submit(new DeployDescriptor(this, cn, contextXml)));
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  510 */     for (Future<?> result : results) {
/*      */       try {
/*  512 */         result.get();
/*      */       } catch (Exception e) {
/*  514 */         log.error(sm.getString("hostConfig.deployDescriptor.threaded.error"), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void deployDescriptor(ContextName cn, File contextXml)
/*      */   {
/*  529 */     DeployedApplication deployedApp = new DeployedApplication(cn.getName(), true);
/*      */     
/*      */ 
/*  532 */     long startTime = 0L;
/*      */     
/*  534 */     if (log.isInfoEnabled()) {
/*  535 */       startTime = System.currentTimeMillis();
/*  536 */       log.info(sm.getString("hostConfig.deployDescriptor", new Object[] { contextXml.getAbsolutePath() }));
/*      */     }
/*      */     
/*      */ 
/*  540 */     Context context = null;
/*  541 */     boolean isExternalWar = false;
/*  542 */     boolean isExternal = false;
/*  543 */     File expandedDocBase = null;
/*      */     try {
/*  545 */       FileInputStream fis = new FileInputStream(contextXml);Throwable localThrowable2 = null;
/*  546 */       try { synchronized (this.digesterLock) {
/*      */           try {
/*  548 */             context = (Context)this.digester.parse(fis);
/*      */           } catch (Exception e) {
/*  550 */             log.error(sm.getString("hostConfig.deployDescriptor.error", new Object[] { contextXml.getAbsolutePath() }), e);
/*      */           }
/*      */           finally
/*      */           {
/*  554 */             this.digester.reset();
/*  555 */             if (context == null) {
/*  556 */               context = new FailedContext();
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*  561 */         Class<?> clazz = Class.forName(this.host.getConfigClass());
/*  562 */         LifecycleListener listener = (LifecycleListener)clazz.newInstance();
/*      */         
/*  564 */         context.addLifecycleListener(listener);
/*      */         
/*  566 */         context.setConfigFile(contextXml.toURI().toURL());
/*  567 */         context.setName(cn.getName());
/*  568 */         context.setPath(cn.getPath());
/*  569 */         context.setWebappVersion(cn.getVersion());
/*      */         
/*  571 */         if (context.getDocBase() != null) {
/*  572 */           File docBase = new File(context.getDocBase());
/*  573 */           if (!docBase.isAbsolute()) {
/*  574 */             docBase = new File(this.host.getAppBaseFile(), context.getDocBase());
/*      */           }
/*      */           
/*  577 */           if (!docBase.getCanonicalPath().startsWith(this.host.getAppBaseFile().getAbsolutePath() + File.separator))
/*      */           {
/*  579 */             isExternal = true;
/*  580 */             deployedApp.redeployResources.put(contextXml.getAbsolutePath(), Long.valueOf(contextXml.lastModified()));
/*      */             
/*      */ 
/*  583 */             deployedApp.redeployResources.put(docBase.getAbsolutePath(), Long.valueOf(docBase.lastModified()));
/*      */             
/*  585 */             if (docBase.getAbsolutePath().toLowerCase(Locale.ENGLISH).endsWith(".war")) {
/*  586 */               isExternalWar = true;
/*      */             }
/*      */           } else {
/*  589 */             log.warn(sm.getString("hostConfig.deployDescriptor.localDocBaseSpecified", new Object[] { docBase }));
/*      */             
/*      */ 
/*  592 */             context.setDocBase(null);
/*      */           }
/*      */         }
/*      */         
/*  596 */         this.host.addChild(context);
/*      */       }
/*      */       catch (Throwable localThrowable1)
/*      */       {
/*  545 */         localThrowable2 = localThrowable1;throw localThrowable1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  597 */         if (fis != null) if (localThrowable2 != null) try { fis.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else fis.close(); } } catch (Throwable t) { boolean unpackWAR;
/*  598 */       File warDocBase; ExceptionUtils.handleThrowable(t);
/*  599 */       log.error(sm.getString("hostConfig.deployDescriptor.error", new Object[] { contextXml.getAbsolutePath() }), t);
/*      */     }
/*      */     finally
/*      */     {
/*      */       boolean unpackWAR;
/*      */       File warDocBase;
/*  605 */       expandedDocBase = new File(this.host.getAppBaseFile(), cn.getBaseName());
/*  606 */       if ((context.getDocBase() != null) && (!context.getDocBase().toLowerCase(Locale.ENGLISH).endsWith(".war")))
/*      */       {
/*      */ 
/*  609 */         expandedDocBase = new File(context.getDocBase());
/*  610 */         if (!expandedDocBase.isAbsolute())
/*      */         {
/*  612 */           expandedDocBase = new File(this.host.getAppBaseFile(), context.getDocBase());
/*      */         }
/*      */       }
/*      */       
/*  616 */       boolean unpackWAR = this.unpackWARs;
/*  617 */       if ((unpackWAR) && ((context instanceof StandardContext))) {
/*  618 */         unpackWAR = ((StandardContext)context).getUnpackWAR();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  623 */       if (isExternalWar) {
/*  624 */         if (unpackWAR) {
/*  625 */           deployedApp.redeployResources.put(expandedDocBase.getAbsolutePath(), Long.valueOf(expandedDocBase.lastModified()));
/*      */           
/*  627 */           addWatchedResources(deployedApp, expandedDocBase.getAbsolutePath(), context);
/*      */         } else {
/*  629 */           addWatchedResources(deployedApp, null, context);
/*      */         }
/*      */       }
/*      */       else {
/*  633 */         if (!isExternal) {
/*  634 */           File warDocBase = new File(expandedDocBase.getAbsolutePath() + ".war");
/*  635 */           if (warDocBase.exists()) {
/*  636 */             deployedApp.redeployResources.put(warDocBase.getAbsolutePath(), Long.valueOf(warDocBase.lastModified()));
/*      */           }
/*      */           else
/*      */           {
/*  640 */             deployedApp.redeployResources.put(warDocBase.getAbsolutePath(), Long.valueOf(0L));
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*  645 */         if (unpackWAR) {
/*  646 */           deployedApp.redeployResources.put(expandedDocBase.getAbsolutePath(), Long.valueOf(expandedDocBase.lastModified()));
/*      */           
/*  648 */           addWatchedResources(deployedApp, expandedDocBase.getAbsolutePath(), context);
/*      */         }
/*      */         else {
/*  651 */           addWatchedResources(deployedApp, null, context);
/*      */         }
/*  653 */         if (!isExternal)
/*      */         {
/*      */ 
/*  656 */           deployedApp.redeployResources.put(contextXml.getAbsolutePath(), Long.valueOf(contextXml.lastModified()));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  663 */       addGlobalRedeployResources(deployedApp);
/*      */     }
/*      */     
/*  666 */     if (this.host.findChild(context.getName()) != null) {
/*  667 */       this.deployed.put(context.getName(), deployedApp);
/*      */     }
/*      */     
/*  670 */     if (log.isInfoEnabled()) {
/*  671 */       log.info(sm.getString("hostConfig.deployDescriptor.finished", new Object[] { contextXml.getAbsolutePath(), Long.valueOf(System.currentTimeMillis() - startTime) }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void deployWARs(File appBase, String[] files)
/*      */   {
/*  684 */     if (files == null) {
/*  685 */       return;
/*      */     }
/*  687 */     ExecutorService es = this.host.getStartStopExecutor();
/*  688 */     List<Future<?>> results = new ArrayList();
/*      */     
/*  690 */     for (int i = 0; i < files.length; i++)
/*      */     {
/*  692 */       if (!files[i].equalsIgnoreCase("META-INF"))
/*      */       {
/*  694 */         if (!files[i].equalsIgnoreCase("WEB-INF"))
/*      */         {
/*  696 */           File war = new File(appBase, files[i]);
/*  697 */           if ((files[i].toLowerCase(Locale.ENGLISH).endsWith(".war")) && (war.isFile()) && (!this.invalidWars.contains(files[i])))
/*      */           {
/*      */ 
/*  700 */             ContextName cn = new ContextName(files[i], true);
/*      */             
/*  702 */             if (!isServiced(cn.getName()))
/*      */             {
/*      */ 
/*  705 */               if (deploymentExists(cn.getName())) {
/*  706 */                 DeployedApplication app = (DeployedApplication)this.deployed.get(cn.getName());
/*  707 */                 boolean unpackWAR = this.unpackWARs;
/*  708 */                 if ((unpackWAR) && ((this.host.findChild(cn.getName()) instanceof StandardContext))) {
/*  709 */                   unpackWAR = ((StandardContext)this.host.findChild(cn.getName())).getUnpackWAR();
/*      */                 }
/*  711 */                 if ((!unpackWAR) && (app != null))
/*      */                 {
/*      */ 
/*  714 */                   File dir = new File(appBase, cn.getBaseName());
/*  715 */                   if (dir.exists()) {
/*  716 */                     if (!app.loggedDirWarning) {
/*  717 */                       log.warn(sm.getString("hostConfig.deployWar.hiddenDir", new Object[] { dir.getAbsoluteFile(), war.getAbsoluteFile() }));
/*      */                       
/*      */ 
/*      */ 
/*  721 */                       app.loggedDirWarning = true;
/*      */                     }
/*      */                   } else {
/*  724 */                     app.loggedDirWarning = false;
/*      */                   }
/*      */                   
/*      */                 }
/*      */                 
/*      */ 
/*      */               }
/*  731 */               else if (!validateContextPath(appBase, cn.getBaseName())) {
/*  732 */                 log.error(sm.getString("hostConfig.illegalWarName", new Object[] { files[i] }));
/*      */                 
/*  734 */                 this.invalidWars.add(files[i]);
/*      */               }
/*      */               else
/*      */               {
/*  738 */                 results.add(es.submit(new DeployWar(this, cn, war)));
/*      */               } }
/*      */           }
/*      */         } } }
/*  742 */     for (Future<?> result : results) {
/*      */       try {
/*  744 */         result.get();
/*      */       } catch (Exception e) {
/*  746 */         log.error(sm.getString("hostConfig.deployWar.threaded.error"), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean validateContextPath(File appBase, String contextPath)
/*      */   {
/*  758 */     String canonicalDocBase = null;
/*      */     try
/*      */     {
/*  761 */       String canonicalAppBase = appBase.getCanonicalPath();
/*  762 */       StringBuilder docBase = new StringBuilder(canonicalAppBase);
/*  763 */       if (canonicalAppBase.endsWith(File.separator)) {
/*  764 */         docBase.append(contextPath.substring(1).replace('/', File.separatorChar));
/*      */       }
/*      */       else {
/*  767 */         docBase.append(contextPath.replace('/', File.separatorChar));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  772 */       canonicalDocBase = new File(docBase.toString()).getCanonicalPath();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  777 */       if (canonicalDocBase.endsWith(File.separator)) {
/*  778 */         docBase.append(File.separator);
/*      */       }
/*      */     } catch (IOException ioe) {
/*  781 */       return false;
/*      */     }
/*      */     
/*      */     StringBuilder docBase;
/*      */     
/*  786 */     return canonicalDocBase.equals(docBase.toString());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void deployWAR(ContextName cn, File war)
/*      */   {
/*  796 */     File xml = new File(this.host.getAppBaseFile(), cn.getBaseName() + "/" + "META-INF/context.xml");
/*      */     
/*      */ 
/*  799 */     File warTracker = new File(this.host.getAppBaseFile(), cn.getBaseName() + "/" + "/META-INF/war-tracker");
/*      */     
/*      */ 
/*  802 */     boolean xmlInWar = false;
/*  803 */     try { JarFile jar = new JarFile(war);Throwable localThrowable8 = null;
/*  804 */       try { JarEntry entry = jar.getJarEntry("META-INF/context.xml");
/*  805 */         if (entry != null) {
/*  806 */           xmlInWar = true;
/*      */         }
/*      */       }
/*      */       catch (Throwable localThrowable1)
/*      */       {
/*  803 */         localThrowable8 = localThrowable1;throw localThrowable1;
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*  808 */         if (jar != null) { if (localThrowable8 != null) try { jar.close(); } catch (Throwable x2) { localThrowable8.addSuppressed(x2); } else { jar.close();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException) {}
/*      */     
/*  815 */     boolean useXml = false;
/*      */     
/*      */ 
/*  818 */     if ((xml.exists()) && (this.unpackWARs) && ((!warTracker.exists()) || (warTracker.lastModified() == war.lastModified())))
/*      */     {
/*  820 */       useXml = true;
/*      */     }
/*      */     
/*  823 */     Object context = null;
/*      */     Throwable localThrowable11;
/*  825 */     try { if ((this.deployXML) && (useXml) && (!this.copyXML)) {
/*  826 */         synchronized (this.digesterLock) {
/*      */           try {
/*  828 */             context = (Context)this.digester.parse(xml);
/*      */           } catch (Exception e) {
/*  830 */             log.error(sm.getString("hostConfig.deployDescriptor.error", new Object[] { war.getAbsolutePath() }), e);
/*      */           }
/*      */           finally
/*      */           {
/*  834 */             this.digester.reset();
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  840 */         ((Context)context).setConfigFile(xml.toURI().toURL());
/*  841 */       } else if ((this.deployXML) && (xmlInWar)) {
/*  842 */         synchronized (this.digesterLock) {
/*  843 */           try { JarFile jar = new JarFile(war);x2 = null;
/*  844 */             try { JarEntry entry = jar.getJarEntry("META-INF/context.xml");
/*  845 */               InputStream istream = jar.getInputStream(entry);localThrowable11 = null;
/*  846 */               try { context = (Context)this.digester.parse(istream);
/*      */               }
/*      */               catch (Throwable localThrowable2)
/*      */               {
/*  845 */                 localThrowable11 = localThrowable2;throw localThrowable2;
/*      */               }
/*      */               finally {}
/*      */             }
/*      */             catch (Throwable localThrowable9)
/*      */             {
/*  843 */               x2 = localThrowable9;throw localThrowable9;
/*      */ 
/*      */             }
/*      */             finally
/*      */             {
/*  848 */               if (jar != null) if (x2 != null) try { jar.close(); } catch (Throwable x2) { x2.addSuppressed(x2); } else jar.close();
/*  849 */             } } catch (Exception e) { log.error(sm.getString("hostConfig.deployDescriptor.error", new Object[] { war.getAbsolutePath() }), e);
/*      */           }
/*      */           finally
/*      */           {
/*  853 */             this.digester.reset();
/*  854 */             if (context == null) {
/*  855 */               context = new FailedContext();
/*      */             }
/*  857 */             ((Context)context).setConfigFile(UriUtil.buildJarUrl(war, "META-INF/context.xml"));
/*      */           }
/*      */         }
/*      */       }
/*  861 */       else if ((!this.deployXML) && (xmlInWar))
/*      */       {
/*      */ 
/*  864 */         log.error(sm.getString("hostConfig.deployDescriptor.blocked", new Object[] { cn.getPath(), "META-INF/context.xml", new File(this.host.getConfigBaseFile(), cn.getBaseName() + ".xml") }));
/*      */       }
/*      */       else
/*      */       {
/*  868 */         context = (Context)Class.forName(this.contextClass).newInstance();
/*      */       }
/*      */     } catch (Throwable t) {
/*  871 */       ExceptionUtils.handleThrowable(t);
/*  872 */       log.error(sm.getString("hostConfig.deployWar.error", new Object[] { war.getAbsolutePath() }), t);
/*      */     }
/*      */     finally {
/*  875 */       if (context == null) {
/*  876 */         context = new FailedContext();
/*      */       }
/*      */     }
/*      */     
/*  880 */     boolean copyThisXml = false;
/*  881 */     if (this.deployXML) {
/*  882 */       if ((this.host instanceof StandardHost)) {
/*  883 */         copyThisXml = ((StandardHost)this.host).isCopyXML();
/*      */       }
/*      */       
/*      */ 
/*  887 */       if ((!copyThisXml) && ((context instanceof StandardContext))) {
/*  888 */         copyThisXml = ((StandardContext)context).getCopyXML();
/*      */       }
/*      */       
/*  891 */       if ((xmlInWar) && (copyThisXml))
/*      */       {
/*  893 */         xml = new File(this.host.getConfigBaseFile(), cn.getBaseName() + ".xml");
/*      */         try {
/*  895 */           JarFile jar = new JarFile(war);x2 = null;
/*  896 */           try { JarEntry entry = jar.getJarEntry("META-INF/context.xml");
/*  897 */             InputStream istream = jar.getInputStream(entry);localThrowable11 = null;
/*  898 */             try { FileOutputStream fos = new FileOutputStream(xml);Throwable localThrowable12 = null;
/*  899 */               try { BufferedOutputStream ostream = new BufferedOutputStream(fos, 1024);Throwable localThrowable13 = null;
/*  900 */                 try { byte[] buffer = new byte['Ѐ'];
/*      */                   for (;;) {
/*  902 */                     int n = istream.read(buffer);
/*  903 */                     if (n < 0) {
/*      */                       break;
/*      */                     }
/*  906 */                     ostream.write(buffer, 0, n);
/*      */                   }
/*  908 */                   ostream.flush();
/*      */                 }
/*      */                 catch (Throwable localThrowable4)
/*      */                 {
/*  897 */                   localThrowable13 = localThrowable4;throw localThrowable4; } finally {} } catch (Throwable localThrowable5) { localThrowable12 = localThrowable5;throw localThrowable5; } finally {} } catch (Throwable localThrowable6) { localThrowable11 = localThrowable6;throw localThrowable6;
/*      */             }
/*      */             finally {}
/*      */           }
/*      */           catch (Throwable localThrowable10)
/*      */           {
/*  895 */             x2 = localThrowable10;throw localThrowable10;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           finally
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  910 */             if (jar != null) if (x2 != null) try { jar.close(); } catch (Throwable x2) { x2.addSuppressed(x2); } else jar.close();
/*      */           }
/*      */         }
/*      */         catch (IOException localIOException2) {}
/*      */       }
/*      */     }
/*  916 */     DeployedApplication deployedApp = new DeployedApplication(cn.getName(), (xml.exists()) && (this.deployXML) && (copyThisXml));
/*      */     
/*      */ 
/*  919 */     long startTime = 0L;
/*      */     
/*  921 */     if (log.isInfoEnabled()) {
/*  922 */       startTime = System.currentTimeMillis();
/*  923 */       log.info(sm.getString("hostConfig.deployWar", new Object[] { war.getAbsolutePath() }));
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  929 */       deployedApp.redeployResources.put(war.getAbsolutePath(), Long.valueOf(war.lastModified()));
/*      */       
/*      */ 
/*  932 */       if ((this.deployXML) && (xml.exists()) && (copyThisXml)) {
/*  933 */         deployedApp.redeployResources.put(xml.getAbsolutePath(), Long.valueOf(xml.lastModified()));
/*      */       }
/*      */       else
/*      */       {
/*  937 */         deployedApp.redeployResources.put(new File(this.host.getConfigBaseFile(), cn.getBaseName() + ".xml").getAbsolutePath(), Long.valueOf(0L));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  943 */       Object clazz = Class.forName(this.host.getConfigClass());
/*  944 */       LifecycleListener listener = (LifecycleListener)((Class)clazz).newInstance();
/*      */       
/*  946 */       ((Context)context).addLifecycleListener(listener);
/*      */       
/*  948 */       ((Context)context).setName(cn.getName());
/*  949 */       ((Context)context).setPath(cn.getPath());
/*  950 */       ((Context)context).setWebappVersion(cn.getVersion());
/*  951 */       ((Context)context).setDocBase(cn.getBaseName() + ".war");
/*  952 */       this.host.addChild((Container)context); } catch (Throwable t) { boolean unpackWAR;
/*      */       File docBase;
/*  954 */       ExceptionUtils.handleThrowable(t);
/*  955 */       log.error(sm.getString("hostConfig.deployWar.error", new Object[] { war.getAbsolutePath() }), t);
/*      */     }
/*      */     finally {
/*      */       boolean unpackWAR;
/*      */       File docBase;
/*  960 */       boolean unpackWAR = this.unpackWARs;
/*  961 */       if ((unpackWAR) && ((context instanceof StandardContext))) {
/*  962 */         unpackWAR = ((StandardContext)context).getUnpackWAR();
/*      */       }
/*  964 */       if ((unpackWAR) && (((Context)context).getDocBase() != null)) {
/*  965 */         File docBase = new File(this.host.getAppBaseFile(), cn.getBaseName());
/*  966 */         deployedApp.redeployResources.put(docBase.getAbsolutePath(), Long.valueOf(docBase.lastModified()));
/*      */         
/*  968 */         addWatchedResources(deployedApp, docBase.getAbsolutePath(), (Context)context);
/*      */         
/*  970 */         if ((this.deployXML) && (!copyThisXml) && ((xmlInWar) || (xml.exists()))) {
/*  971 */           deployedApp.redeployResources.put(xml.getAbsolutePath(), Long.valueOf(xml.lastModified()));
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/*  977 */         addWatchedResources(deployedApp, null, (Context)context);
/*      */       }
/*      */       
/*      */ 
/*  981 */       addGlobalRedeployResources(deployedApp);
/*      */     }
/*      */     
/*  984 */     this.deployed.put(cn.getName(), deployedApp);
/*      */     
/*  986 */     if (log.isInfoEnabled()) {
/*  987 */       log.info(sm.getString("hostConfig.deployWar.finished", new Object[] { war.getAbsolutePath(), Long.valueOf(System.currentTimeMillis() - startTime) }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void deployDirectories(File appBase, String[] files)
/*      */   {
/* 1000 */     if (files == null) {
/* 1001 */       return;
/*      */     }
/* 1003 */     ExecutorService es = this.host.getStartStopExecutor();
/* 1004 */     List<Future<?>> results = new ArrayList();
/*      */     
/* 1006 */     for (int i = 0; i < files.length; i++)
/*      */     {
/* 1008 */       if (!files[i].equalsIgnoreCase("META-INF"))
/*      */       {
/* 1010 */         if (!files[i].equalsIgnoreCase("WEB-INF"))
/*      */         {
/* 1012 */           File dir = new File(appBase, files[i]);
/* 1013 */           if (dir.isDirectory()) {
/* 1014 */             ContextName cn = new ContextName(files[i], false);
/*      */             
/* 1016 */             if ((!isServiced(cn.getName())) && (!deploymentExists(cn.getName())))
/*      */             {
/*      */ 
/* 1019 */               results.add(es.submit(new DeployDirectory(this, cn, dir))); }
/*      */           }
/*      */         } }
/*      */     }
/* 1023 */     for (Future<?> result : results) {
/*      */       try {
/* 1025 */         result.get();
/*      */       } catch (Exception e) {
/* 1027 */         log.error(sm.getString("hostConfig.deployDir.threaded.error"), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void deployDirectory(ContextName cn, File dir)
/*      */   {
/* 1042 */     long startTime = 0L;
/*      */     
/* 1044 */     if (log.isInfoEnabled()) {
/* 1045 */       startTime = System.currentTimeMillis();
/* 1046 */       log.info(sm.getString("hostConfig.deployDir", new Object[] { dir.getAbsolutePath() }));
/*      */     }
/*      */     
/*      */ 
/* 1050 */     Context context = null;
/* 1051 */     File xml = new File(dir, "META-INF/context.xml");
/* 1052 */     File xmlCopy = new File(this.host.getConfigBaseFile(), cn.getBaseName() + ".xml");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1057 */     boolean copyThisXml = this.copyXML;
/*      */     DeployedApplication deployedApp;
/*      */     try {
/* 1060 */       if ((this.deployXML) && (xml.exists())) {
/* 1061 */         synchronized (this.digesterLock) {
/*      */           try {
/* 1063 */             context = (Context)this.digester.parse(xml);
/*      */           } catch (Exception e) {
/* 1065 */             log.error(sm.getString("hostConfig.deployDescriptor.error", new Object[] { xml }), e);
/*      */             
/*      */ 
/* 1068 */             context = new FailedContext();
/*      */           } finally {
/* 1070 */             this.digester.reset();
/* 1071 */             if (context == null) {
/* 1072 */               context = new FailedContext();
/*      */             }
/*      */           }
/*      */         }
/*      */         
/* 1077 */         if ((!copyThisXml) && ((context instanceof StandardContext)))
/*      */         {
/* 1079 */           copyThisXml = ((StandardContext)context).getCopyXML();
/*      */         }
/*      */         
/* 1082 */         if (copyThisXml) {
/* 1083 */           Files.copy(xml.toPath(), xmlCopy.toPath(), new CopyOption[0]);
/* 1084 */           context.setConfigFile(xmlCopy.toURI().toURL());
/*      */         } else {
/* 1086 */           context.setConfigFile(xml.toURI().toURL());
/*      */         }
/* 1088 */       } else if ((!this.deployXML) && (xml.exists()))
/*      */       {
/*      */ 
/* 1091 */         log.error(sm.getString("hostConfig.deployDescriptor.blocked", new Object[] { cn.getPath(), xml, xmlCopy }));
/*      */         
/* 1093 */         context = new FailedContext();
/*      */       } else {
/* 1095 */         context = (Context)Class.forName(this.contextClass).newInstance();
/*      */       }
/*      */       
/* 1098 */       Class<?> clazz = Class.forName(this.host.getConfigClass());
/* 1099 */       LifecycleListener listener = (LifecycleListener)clazz.newInstance();
/*      */       
/* 1101 */       context.addLifecycleListener(listener);
/*      */       
/* 1103 */       context.setName(cn.getName());
/* 1104 */       context.setPath(cn.getPath());
/* 1105 */       context.setWebappVersion(cn.getVersion());
/* 1106 */       context.setDocBase(cn.getBaseName());
/* 1107 */       this.host.addChild(context);
/*      */     } catch (Throwable t) { DeployedApplication deployedApp;
/* 1109 */       ExceptionUtils.handleThrowable(t);
/* 1110 */       log.error(sm.getString("hostConfig.deployDir.error", new Object[] { dir.getAbsolutePath() }), t);
/*      */     } finally {
/*      */       DeployedApplication deployedApp;
/* 1113 */       deployedApp = new DeployedApplication(cn.getName(), (xml.exists()) && (this.deployXML) && (copyThisXml));
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1118 */       deployedApp.redeployResources.put(dir.getAbsolutePath() + ".war", Long.valueOf(0L));
/*      */       
/* 1120 */       deployedApp.redeployResources.put(dir.getAbsolutePath(), Long.valueOf(dir.lastModified()));
/*      */       
/* 1122 */       if ((this.deployXML) && (xml.exists())) {
/* 1123 */         if (copyThisXml) {
/* 1124 */           deployedApp.redeployResources.put(xmlCopy.getAbsolutePath(), Long.valueOf(xmlCopy.lastModified()));
/*      */         }
/*      */         else
/*      */         {
/* 1128 */           deployedApp.redeployResources.put(xml.getAbsolutePath(), Long.valueOf(xml.lastModified()));
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 1133 */           deployedApp.redeployResources.put(xmlCopy.getAbsolutePath(), Long.valueOf(0L));
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1140 */         deployedApp.redeployResources.put(xmlCopy.getAbsolutePath(), Long.valueOf(0L));
/*      */         
/*      */ 
/* 1143 */         if (!xml.exists()) {
/* 1144 */           deployedApp.redeployResources.put(xml.getAbsolutePath(), Long.valueOf(0L));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1149 */       addWatchedResources(deployedApp, dir.getAbsolutePath(), context);
/*      */       
/*      */ 
/* 1152 */       addGlobalRedeployResources(deployedApp);
/*      */     }
/*      */     
/* 1155 */     this.deployed.put(cn.getName(), deployedApp);
/*      */     
/* 1157 */     if (log.isInfoEnabled()) {
/* 1158 */       log.info(sm.getString("hostConfig.deployDir.finished", new Object[] { dir.getAbsolutePath(), Long.valueOf(System.currentTimeMillis() - startTime) }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean deploymentExists(String contextName)
/*      */   {
/* 1171 */     return (this.deployed.containsKey(contextName)) || (this.host.findChild(contextName) != null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void addWatchedResources(DeployedApplication app, String docBase, Context context)
/*      */   {
/* 1187 */     File docBaseFile = null;
/* 1188 */     if (docBase != null) {
/* 1189 */       docBaseFile = new File(docBase);
/* 1190 */       if (!docBaseFile.isAbsolute()) {
/* 1191 */         docBaseFile = new File(this.host.getAppBaseFile(), docBase);
/*      */       }
/*      */     }
/* 1194 */     String[] watchedResources = context.findWatchedResources();
/* 1195 */     for (int i = 0; i < watchedResources.length; i++) {
/* 1196 */       File resource = new File(watchedResources[i]);
/* 1197 */       if (!resource.isAbsolute()) {
/* 1198 */         if (docBase != null) {
/* 1199 */           resource = new File(docBaseFile, watchedResources[i]);
/*      */         } else {
/* 1201 */           if (!log.isDebugEnabled()) continue;
/* 1202 */           log.debug("Ignoring non-existent WatchedResource '" + resource.getAbsolutePath() + "'"); continue;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1207 */       if (log.isDebugEnabled()) {
/* 1208 */         log.debug("Watching WatchedResource '" + resource.getAbsolutePath() + "'");
/*      */       }
/* 1210 */       app.reloadResources.put(resource.getAbsolutePath(), Long.valueOf(resource.lastModified()));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void addGlobalRedeployResources(DeployedApplication app)
/*      */   {
/* 1218 */     File hostContextXml = new File(getConfigBaseName(), "context.xml.default");
/*      */     
/* 1220 */     if (hostContextXml.isFile()) {
/* 1221 */       app.redeployResources.put(hostContextXml.getAbsolutePath(), Long.valueOf(hostContextXml.lastModified()));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1226 */     File globalContextXml = returnCanonicalPath("conf/context.xml");
/*      */     
/* 1228 */     if (globalContextXml.isFile()) {
/* 1229 */       app.redeployResources.put(globalContextXml.getAbsolutePath(), Long.valueOf(globalContextXml.lastModified()));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected boolean unpackWARs;
/*      */   
/*      */   protected final Map<String, DeployedApplication> deployed;
/*      */   
/*      */   protected final ArrayList<String> serviced;
/*      */   
/*      */   protected Digester digester;
/*      */   
/*      */   private final Object digesterLock;
/*      */   
/*      */   protected final Set<String> invalidWars;
/*      */   protected synchronized void checkResources(DeployedApplication app, boolean skipFileModificationResolutionCheck)
/*      */   {
/* 1247 */     String[] resources = (String[])app.redeployResources.keySet().toArray(new String[0]);
/*      */     
/*      */ 
/* 1250 */     long currentTimeWithResolutionOffset = System.currentTimeMillis() - 1000L;
/*      */     
/* 1252 */     for (int i = 0; i < resources.length; i++) {
/* 1253 */       File resource = new File(resources[i]);
/* 1254 */       if (log.isDebugEnabled()) {
/* 1255 */         log.debug("Checking context[" + app.name + "] redeploy resource " + resource);
/*      */       }
/* 1257 */       long lastModified = ((Long)app.redeployResources.get(resources[i])).longValue();
/*      */       
/* 1259 */       if ((resource.exists()) || (lastModified == 0L))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1264 */         if ((resource.lastModified() != lastModified) && ((!this.host.getAutoDeploy()) || (resource.lastModified() < currentTimeWithResolutionOffset) || (skipFileModificationResolutionCheck)))
/*      */         {
/*      */ 
/* 1267 */           if (resource.isDirectory())
/*      */           {
/* 1269 */             app.redeployResources.put(resources[i], Long.valueOf(resource.lastModified()));
/*      */           } else {
/* 1271 */             if ((app.hasDescriptor) && (resource.getName().toLowerCase(Locale.ENGLISH).endsWith(".war")))
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1278 */               Context context = (Context)this.host.findChild(app.name);
/* 1279 */               String docBase = context.getDocBase();
/* 1280 */               if (!docBase.toLowerCase(Locale.ENGLISH).endsWith(".war"))
/*      */               {
/* 1282 */                 File docBaseFile = new File(docBase);
/* 1283 */                 if (!docBaseFile.isAbsolute()) {
/* 1284 */                   docBaseFile = new File(this.host.getAppBaseFile(), docBase);
/*      */                 }
/*      */                 
/* 1287 */                 reload(app, docBaseFile, resource.getAbsolutePath());
/*      */               } else {
/* 1289 */                 reload(app, null, null);
/*      */               }
/*      */               
/* 1292 */               app.redeployResources.put(resources[i], Long.valueOf(resource.lastModified()));
/*      */               
/* 1294 */               app.timestamp = System.currentTimeMillis();
/* 1295 */               boolean unpackWAR = this.unpackWARs;
/* 1296 */               if ((unpackWAR) && ((context instanceof StandardContext))) {
/* 1297 */                 unpackWAR = ((StandardContext)context).getUnpackWAR();
/*      */               }
/* 1299 */               if (unpackWAR) {
/* 1300 */                 addWatchedResources(app, context.getDocBase(), context);
/*      */               } else {
/* 1302 */                 addWatchedResources(app, null, context);
/*      */               }
/* 1304 */               return;
/*      */             }
/*      */             
/*      */ 
/* 1308 */             undeploy(app);
/* 1309 */             deleteRedeployResources(app, resources, i, false);
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*      */         try
/*      */         {
/* 1317 */           Thread.sleep(500L);
/*      */         }
/*      */         catch (InterruptedException localInterruptedException) {}
/*      */         
/*      */ 
/* 1322 */         if (!resource.exists())
/*      */         {
/*      */ 
/*      */ 
/* 1326 */           undeploy(app);
/* 1327 */           deleteRedeployResources(app, resources, i, true);
/* 1328 */           return;
/*      */         }
/*      */       } }
/* 1331 */     resources = (String[])app.reloadResources.keySet().toArray(new String[0]);
/* 1332 */     boolean update = false;
/* 1333 */     for (int i = 0; i < resources.length; i++) {
/* 1334 */       File resource = new File(resources[i]);
/* 1335 */       if (log.isDebugEnabled()) {
/* 1336 */         log.debug("Checking context[" + app.name + "] reload resource " + resource);
/*      */       }
/* 1338 */       long lastModified = ((Long)app.reloadResources.get(resources[i])).longValue();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1343 */       if (((resource.lastModified() != lastModified) && ((!this.host.getAutoDeploy()) || (resource.lastModified() < currentTimeWithResolutionOffset) || (skipFileModificationResolutionCheck))) || (update))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1348 */         if (!update)
/*      */         {
/* 1350 */           reload(app, null, null);
/* 1351 */           update = true;
/*      */         }
/*      */         
/*      */ 
/* 1355 */         app.reloadResources.put(resources[i], Long.valueOf(resource.lastModified()));
/*      */       }
/*      */       
/* 1358 */       app.timestamp = System.currentTimeMillis();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void reload(DeployedApplication app, File fileToRemove, String newDocBase)
/*      */   {
/* 1368 */     if (log.isInfoEnabled())
/* 1369 */       log.info(sm.getString("hostConfig.reload", new Object[] { app.name }));
/* 1370 */     Context context = (Context)this.host.findChild(app.name);
/* 1371 */     if (context.getState().isAvailable()) {
/* 1372 */       if ((fileToRemove != null) && (newDocBase != null)) {
/* 1373 */         context.addLifecycleListener(new ExpandedDirectoryRemovalListener(fileToRemove, newDocBase));
/*      */       }
/*      */       
/*      */ 
/* 1377 */       context.reload();
/*      */     }
/*      */     else
/*      */     {
/* 1381 */       if ((fileToRemove != null) && (newDocBase != null)) {
/* 1382 */         ExpandWar.delete(fileToRemove);
/* 1383 */         context.setDocBase(newDocBase);
/*      */       }
/*      */       try {
/* 1386 */         context.start();
/*      */       } catch (Exception e) {
/* 1388 */         log.warn(sm.getString("hostConfig.context.restart", new Object[] { app.name }), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void undeploy(DeployedApplication app)
/*      */   {
/* 1396 */     if (log.isInfoEnabled())
/* 1397 */       log.info(sm.getString("hostConfig.undeploy", new Object[] { app.name }));
/* 1398 */     Container context = this.host.findChild(app.name);
/*      */     try {
/* 1400 */       this.host.removeChild(context);
/*      */     } catch (Throwable t) {
/* 1402 */       ExceptionUtils.handleThrowable(t);
/* 1403 */       log.warn(sm.getString("hostConfig.context.remove", new Object[] { app.name }), t);
/*      */     }
/*      */     
/* 1406 */     this.deployed.remove(app.name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void deleteRedeployResources(DeployedApplication app, String[] resources, int i, boolean deleteReloadResources)
/*      */   {
/* 1414 */     for (int j = i + 1; j < resources.length; j++) {
/* 1415 */       File current = new File(resources[j]);
/*      */       
/* 1417 */       if (!"context.xml.default".equals(current.getName()))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1422 */         if (isDeletableResource(app, current)) {
/* 1423 */           if (log.isDebugEnabled()) {
/* 1424 */             log.debug("Delete " + current);
/*      */           }
/* 1426 */           ExpandWar.delete(current);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1431 */     if (deleteReloadResources) {
/* 1432 */       String[] resources2 = (String[])app.reloadResources.keySet().toArray(new String[0]);
/* 1433 */       for (int j = 0; j < resources2.length; j++) {
/* 1434 */         File current = new File(resources2[j]);
/*      */         
/* 1436 */         if (!"context.xml.default".equals(current.getName()))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 1441 */           if (isDeletableResource(app, current)) {
/* 1442 */             if (log.isDebugEnabled()) {
/* 1443 */               log.debug("Delete " + current);
/*      */             }
/* 1445 */             ExpandWar.delete(current);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isDeletableResource(DeployedApplication app, File resource)
/*      */   {
/* 1464 */     if (!resource.isAbsolute()) {
/* 1465 */       log.warn(sm.getString("hostConfig.resourceNotAbsolute", new Object[] { app.name, resource }));
/* 1466 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1472 */       canonicalLocation = resource.getParentFile().getCanonicalPath();
/*      */     } catch (IOException e) { String canonicalLocation;
/* 1474 */       log.warn(sm.getString("hostConfig.canonicalizing", new Object[] { resource.getParentFile(), app.name }), e);
/*      */       
/* 1476 */       return false;
/*      */     }
/*      */     String canonicalLocation;
/*      */     try
/*      */     {
/* 1481 */       canonicalAppBase = this.host.getAppBaseFile().getCanonicalPath();
/*      */     } catch (IOException e) { String canonicalAppBase;
/* 1483 */       log.warn(sm.getString("hostConfig.canonicalizing", new Object[] { this.host.getAppBaseFile(), app.name }), e);
/*      */       
/* 1485 */       return false;
/*      */     }
/*      */     String canonicalAppBase;
/* 1488 */     if (canonicalLocation.equals(canonicalAppBase))
/*      */     {
/* 1490 */       return true;
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1495 */       canonicalConfigBase = this.host.getConfigBaseFile().getCanonicalPath();
/*      */     } catch (IOException e) { String canonicalConfigBase;
/* 1497 */       log.warn(sm.getString("hostConfig.canonicalizing", new Object[] { this.host.getConfigBaseFile(), app.name }), e);
/*      */       
/* 1499 */       return false;
/*      */     }
/*      */     String canonicalConfigBase;
/* 1502 */     if ((canonicalLocation.equals(canonicalConfigBase)) && (resource.getName().endsWith(".xml")))
/*      */     {
/*      */ 
/* 1505 */       return true;
/*      */     }
/*      */     
/*      */ 
/* 1509 */     return false;
/*      */   }
/*      */   
/*      */   public void beforeStart()
/*      */   {
/* 1514 */     if (this.host.getCreateDirs()) {
/* 1515 */       File[] dirs = { this.host.getAppBaseFile(), this.host.getConfigBaseFile() };
/* 1516 */       for (int i = 0; i < dirs.length; i++) {
/* 1517 */         if ((!dirs[i].mkdirs()) && (!dirs[i].isDirectory())) {
/* 1518 */           log.error(sm.getString("hostConfig.createDirs", new Object[] { dirs[i] }));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void start()
/*      */   {
/* 1530 */     if (log.isDebugEnabled()) {
/* 1531 */       log.debug(sm.getString("hostConfig.start"));
/*      */     }
/*      */     try {
/* 1534 */       ObjectName hostON = this.host.getObjectName();
/* 1535 */       this.oname = new ObjectName(hostON.getDomain() + ":type=Deployer,host=" + this.host.getName());
/*      */       
/* 1537 */       Registry.getRegistry(null, null).registerComponent(this, this.oname, getClass().getName());
/*      */     }
/*      */     catch (Exception e) {
/* 1540 */       log.error(sm.getString("hostConfig.jmx.register", new Object[] { this.oname }), e);
/*      */     }
/*      */     
/* 1543 */     if (!this.host.getAppBaseFile().isDirectory()) {
/* 1544 */       log.error(sm.getString("hostConfig.appBase", new Object[] { this.host.getName(), this.host.getAppBaseFile().getPath() }));
/*      */       
/* 1546 */       this.host.setDeployOnStartup(false);
/* 1547 */       this.host.setAutoDeploy(false);
/*      */     }
/*      */     
/* 1550 */     if (this.host.getDeployOnStartup()) {
/* 1551 */       deployApps();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void stop()
/*      */   {
/* 1561 */     if (log.isDebugEnabled()) {
/* 1562 */       log.debug(sm.getString("hostConfig.stop"));
/*      */     }
/* 1564 */     if (this.oname != null) {
/*      */       try {
/* 1566 */         Registry.getRegistry(null, null).unregisterComponent(this.oname);
/*      */       } catch (Exception e) {
/* 1568 */         log.error(sm.getString("hostConfig.jmx.unregister", new Object[] { this.oname }), e);
/*      */       }
/*      */     }
/* 1571 */     this.oname = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void check()
/*      */   {
/* 1580 */     if (this.host.getAutoDeploy())
/*      */     {
/* 1582 */       DeployedApplication[] apps = (DeployedApplication[])this.deployed.values().toArray(new DeployedApplication[0]);
/*      */       
/* 1584 */       for (int i = 0; i < apps.length; i++) {
/* 1585 */         if (!isServiced(apps[i].name)) {
/* 1586 */           checkResources(apps[i], false);
/*      */         }
/*      */       }
/*      */       
/* 1590 */       if (this.host.getUndeployOldVersions()) {
/* 1591 */         checkUndeploy();
/*      */       }
/*      */       
/*      */ 
/* 1595 */       deployApps();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void check(String name)
/*      */   {
/* 1613 */     DeployedApplication app = (DeployedApplication)this.deployed.get(name);
/* 1614 */     if (app != null) {
/* 1615 */       checkResources(app, true);
/*      */     }
/* 1617 */     deployApps(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void checkUndeploy()
/*      */   {
/* 1626 */     SortedSet<String> sortedAppNames = new TreeSet();
/* 1627 */     sortedAppNames.addAll(this.deployed.keySet());
/*      */     
/* 1629 */     if (sortedAppNames.size() < 2) {
/* 1630 */       return;
/*      */     }
/* 1632 */     Iterator<String> iter = sortedAppNames.iterator();
/*      */     
/* 1634 */     ContextName previous = new ContextName((String)iter.next(), false);
/*      */     do {
/* 1636 */       ContextName current = new ContextName((String)iter.next(), false);
/*      */       
/* 1638 */       if (current.getPath().equals(previous.getPath()))
/*      */       {
/*      */ 
/* 1641 */         Context previousContext = (Context)this.host.findChild(previous.getName());
/* 1642 */         Context currentContext = (Context)this.host.findChild(current.getName());
/* 1643 */         if ((previousContext != null) && (currentContext != null) && (currentContext.getState().isAvailable()) && (!isServiced(previous.getName())))
/*      */         {
/*      */ 
/* 1646 */           Manager manager = previousContext.getManager();
/* 1647 */           if (manager != null) { int sessionCount;
/*      */             int sessionCount;
/* 1649 */             if ((manager instanceof DistributedManager)) {
/* 1650 */               sessionCount = ((DistributedManager)manager).getActiveSessionsFull();
/*      */             } else {
/* 1652 */               sessionCount = manager.getActiveSessions();
/*      */             }
/* 1654 */             if (sessionCount == 0) {
/* 1655 */               if (log.isInfoEnabled()) {
/* 1656 */                 log.info(sm.getString("hostConfig.undeployVersion", new Object[] { previous.getName() }));
/*      */               }
/*      */               
/* 1659 */               DeployedApplication app = (DeployedApplication)this.deployed.get(previous.getName());
/* 1660 */               String[] resources = (String[])app.redeployResources.keySet().toArray(new String[0]);
/*      */               
/*      */ 
/*      */ 
/* 1664 */               undeploy(app);
/* 1665 */               deleteRedeployResources(app, resources, -1, true);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1670 */       previous = current;
/* 1671 */     } while (iter.hasNext());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void manageApp(Context context)
/*      */   {
/* 1681 */     String contextName = context.getName();
/*      */     
/* 1683 */     if (this.deployed.containsKey(contextName)) {
/* 1684 */       return;
/*      */     }
/* 1686 */     DeployedApplication deployedApp = new DeployedApplication(contextName, false);
/*      */     
/*      */ 
/*      */ 
/* 1690 */     boolean isWar = false;
/* 1691 */     if (context.getDocBase() != null) {
/* 1692 */       File docBase = new File(context.getDocBase());
/* 1693 */       if (!docBase.isAbsolute()) {
/* 1694 */         docBase = new File(this.host.getAppBaseFile(), context.getDocBase());
/*      */       }
/* 1696 */       deployedApp.redeployResources.put(docBase.getAbsolutePath(), Long.valueOf(docBase.lastModified()));
/*      */       
/* 1698 */       if (docBase.getAbsolutePath().toLowerCase(Locale.ENGLISH).endsWith(".war")) {
/* 1699 */         isWar = true;
/*      */       }
/*      */     }
/* 1702 */     this.host.addChild(context);
/*      */     
/*      */ 
/* 1705 */     boolean unpackWAR = this.unpackWARs;
/* 1706 */     if ((unpackWAR) && ((context instanceof StandardContext))) {
/* 1707 */       unpackWAR = ((StandardContext)context).getUnpackWAR();
/*      */     }
/* 1709 */     if ((isWar) && (unpackWAR)) {
/* 1710 */       File docBase = new File(this.host.getAppBaseFile(), context.getBaseName());
/* 1711 */       deployedApp.redeployResources.put(docBase.getAbsolutePath(), Long.valueOf(docBase.lastModified()));
/*      */       
/* 1713 */       addWatchedResources(deployedApp, docBase.getAbsolutePath(), context);
/*      */     } else {
/* 1715 */       addWatchedResources(deployedApp, null, context);
/*      */     }
/* 1717 */     this.deployed.put(contextName, deployedApp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void unmanageApp(String contextName)
/*      */   {
/* 1726 */     if (isServiced(contextName)) {
/* 1727 */       this.deployed.remove(contextName);
/* 1728 */       this.host.removeChild(this.host.findChild(contextName));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected static class DeployedApplication
/*      */   {
/*      */     public final String name;
/*      */     
/*      */     public final boolean hasDescriptor;
/*      */     
/*      */     public DeployedApplication(String name, boolean hasDescriptor)
/*      */     {
/* 1741 */       this.name = name;
/* 1742 */       this.hasDescriptor = hasDescriptor;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1764 */     public final LinkedHashMap<String, Long> redeployResources = new LinkedHashMap();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1774 */     public final HashMap<String, Long> reloadResources = new HashMap();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1779 */     public long timestamp = System.currentTimeMillis();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1787 */     public boolean loggedDirWarning = false;
/*      */   }
/*      */   
/*      */   private static class DeployDescriptor implements Runnable
/*      */   {
/*      */     private HostConfig config;
/*      */     private ContextName cn;
/*      */     private File descriptor;
/*      */     
/*      */     public DeployDescriptor(HostConfig config, ContextName cn, File descriptor)
/*      */     {
/* 1798 */       this.config = config;
/* 1799 */       this.cn = cn;
/* 1800 */       this.descriptor = descriptor;
/*      */     }
/*      */     
/*      */     public void run()
/*      */     {
/* 1805 */       this.config.deployDescriptor(this.cn, this.descriptor);
/*      */     }
/*      */   }
/*      */   
/*      */   private static class DeployWar implements Runnable
/*      */   {
/*      */     private HostConfig config;
/*      */     private ContextName cn;
/*      */     private File war;
/*      */     
/*      */     public DeployWar(HostConfig config, ContextName cn, File war) {
/* 1816 */       this.config = config;
/* 1817 */       this.cn = cn;
/* 1818 */       this.war = war;
/*      */     }
/*      */     
/*      */     public void run()
/*      */     {
/* 1823 */       this.config.deployWAR(this.cn, this.war);
/*      */     }
/*      */   }
/*      */   
/*      */   private static class DeployDirectory implements Runnable
/*      */   {
/*      */     private HostConfig config;
/*      */     private ContextName cn;
/*      */     private File dir;
/*      */     
/*      */     public DeployDirectory(HostConfig config, ContextName cn, File dir) {
/* 1834 */       this.config = config;
/* 1835 */       this.cn = cn;
/* 1836 */       this.dir = dir;
/*      */     }
/*      */     
/*      */     public void run()
/*      */     {
/* 1841 */       this.config.deployDirectory(this.cn, this.dir);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class ExpandedDirectoryRemovalListener
/*      */     implements LifecycleListener
/*      */   {
/*      */     private final File toDelete;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private final String newDocBase;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public ExpandedDirectoryRemovalListener(File toDelete, String newDocBase)
/*      */     {
/* 1872 */       this.toDelete = toDelete;
/* 1873 */       this.newDocBase = newDocBase;
/*      */     }
/*      */     
/*      */     public void lifecycleEvent(LifecycleEvent event)
/*      */     {
/* 1878 */       if ("after_stop".equals(event.getType()))
/*      */       {
/* 1880 */         Context context = (Context)event.getLifecycle();
/*      */         
/*      */ 
/* 1883 */         ExpandWar.delete(this.toDelete);
/*      */         
/*      */ 
/* 1886 */         context.setDocBase(this.newDocBase);
/*      */         
/*      */ 
/*      */ 
/* 1890 */         context.removeLifecycleListener(this);
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\startup\HostConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */