/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.JarURLConnection;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.util.Enumeration;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.zip.ZipException;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpandWar
/*     */ {
/*  48 */   private static final Log log = LogFactory.getLog(ExpandWar.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  53 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.startup");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String expand(Host host, URL war, String pathname)
/*     */     throws IOException
/*     */   {
/*  80 */     JarURLConnection juc = (JarURLConnection)war.openConnection();
/*  81 */     juc.setUseCaches(false);
/*  82 */     URL jarFileUrl = juc.getJarFileURL();
/*  83 */     URLConnection jfuc = jarFileUrl.openConnection();
/*     */     
/*  85 */     boolean success = false;
/*  86 */     File docBase = new File(host.getAppBaseFile(), pathname);
/*  87 */     File warTracker = new File(host.getAppBaseFile(), pathname + "/META-INF/war-tracker");
/*  88 */     long warLastModified = -1L;
/*     */     
/*  90 */     InputStream is = jfuc.getInputStream();Throwable localThrowable4 = null;
/*     */     try {
/*  92 */       warLastModified = jfuc.getLastModified();
/*     */     }
/*     */     catch (Throwable localThrowable1)
/*     */     {
/*  90 */       localThrowable4 = localThrowable1;throw localThrowable1;
/*     */     }
/*     */     finally {
/*  93 */       if (is != null) if (localThrowable4 != null) try { is.close(); } catch (Throwable x2) { localThrowable4.addSuppressed(x2); } else { is.close();
/*     */         }
/*     */     }
/*  96 */     if (docBase.exists())
/*     */     {
/*     */ 
/*     */ 
/* 100 */       if ((!warTracker.exists()) || (warTracker.lastModified() == warLastModified))
/*     */       {
/* 102 */         success = true;
/* 103 */         return docBase.getAbsolutePath();
/*     */       }
/*     */       
/*     */ 
/* 107 */       log.info(sm.getString("expandWar.deleteOld", new Object[] { docBase }));
/* 108 */       if (!delete(docBase)) {
/* 109 */         throw new IOException(sm.getString("expandWar.deleteFailed", new Object[] { docBase }));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 114 */     if ((!docBase.mkdir()) && (!docBase.isDirectory())) {
/* 115 */       throw new IOException(sm.getString("expandWar.createFailed", new Object[] { docBase }));
/*     */     }
/*     */     
/*     */ 
/* 119 */     String canonicalDocBasePrefix = docBase.getCanonicalPath();
/* 120 */     if (!canonicalDocBasePrefix.endsWith(File.separator)) {
/* 121 */       canonicalDocBasePrefix = canonicalDocBasePrefix + File.separator;
/*     */     }
/*     */     
/*     */ 
/* 125 */     File warTrackerParent = warTracker.getParentFile();
/* 126 */     if ((!warTrackerParent.isDirectory()) && (!warTrackerParent.mkdirs())) {
/* 127 */       throw new IOException(sm.getString("expandWar.createFailed", new Object[] { warTrackerParent.getAbsolutePath() }));
/*     */     }
/*     */     try {
/* 130 */       JarFile jarFile = juc.getJarFile();Throwable localThrowable5 = null;
/*     */       try {
/* 132 */         Enumeration<JarEntry> jarEntries = jarFile.entries();
/* 133 */         while (jarEntries.hasMoreElements()) {
/* 134 */           JarEntry jarEntry = (JarEntry)jarEntries.nextElement();
/* 135 */           String name = jarEntry.getName();
/* 136 */           File expandedFile = new File(docBase, name);
/* 137 */           if (!expandedFile.getCanonicalPath().startsWith(canonicalDocBasePrefix))
/*     */           {
/*     */ 
/*     */ 
/* 141 */             throw new IllegalArgumentException(sm.getString("expandWar.illegalPath", new Object[] { war, name, expandedFile.getCanonicalPath(), canonicalDocBasePrefix }));
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 146 */           int last = name.lastIndexOf('/');
/* 147 */           if (last >= 0) {
/* 148 */             File parent = new File(docBase, name.substring(0, last));
/*     */             
/* 150 */             if ((!parent.mkdirs()) && (!parent.isDirectory())) {
/* 151 */               throw new IOException(sm.getString("expandWar.createFailed", new Object[] { parent }));
/*     */             }
/*     */           }
/*     */           
/* 155 */           if (!name.endsWith("/"))
/*     */           {
/*     */ 
/*     */ 
/* 159 */             InputStream input = jarFile.getInputStream(jarEntry);Throwable localThrowable6 = null;
/* 160 */             try { if (null == input) {
/* 161 */                 throw new ZipException(sm.getString("expandWar.missingJarEntry", new Object[] { jarEntry.getName() }));
/*     */               }
/*     */               
/*     */ 
/* 165 */               expand(input, expandedFile);
/* 166 */               long lastModified = jarEntry.getTime();
/* 167 */               if ((lastModified != -1L) && (lastModified != 0L)) {
/* 168 */                 expandedFile.setLastModified(lastModified);
/*     */               }
/*     */             }
/*     */             catch (Throwable localThrowable2)
/*     */             {
/* 159 */               localThrowable6 = localThrowable2;throw localThrowable2;
/*     */             }
/*     */             finally {}
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 174 */             warTracker.createNewFile();
/* 175 */             warTracker.setLastModified(warLastModified);
/*     */           } }
/* 177 */         success = true;
/*     */       }
/*     */       catch (Throwable localThrowable3)
/*     */       {
/* 130 */         localThrowable5 = localThrowable3;throw localThrowable3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       finally
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 178 */         if (jarFile != null) if (localThrowable5 != null) try { jarFile.close(); } catch (Throwable x2) { localThrowable5.addSuppressed(x2); } else jarFile.close();
/* 179 */       } } catch (IOException e) { throw e;
/*     */     } finally {
/* 181 */       if (!success)
/*     */       {
/*     */ 
/* 184 */         deleteDir(docBase);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 189 */     return docBase.getAbsolutePath();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void validate(Host host, URL war, String pathname)
/*     */     throws IOException
/*     */   {
/* 208 */     File docBase = new File(host.getAppBaseFile(), pathname);
/*     */     
/*     */ 
/* 211 */     String canonicalDocBasePrefix = docBase.getCanonicalPath();
/* 212 */     if (!canonicalDocBasePrefix.endsWith(File.separator)) {
/* 213 */       canonicalDocBasePrefix = canonicalDocBasePrefix + File.separator;
/*     */     }
/* 215 */     JarURLConnection juc = (JarURLConnection)war.openConnection();
/* 216 */     juc.setUseCaches(false);
/* 217 */     try { JarFile jarFile = juc.getJarFile();Throwable localThrowable2 = null;
/* 218 */       try { Enumeration<JarEntry> jarEntries = jarFile.entries();
/* 219 */         while (jarEntries.hasMoreElements()) {
/* 220 */           JarEntry jarEntry = (JarEntry)jarEntries.nextElement();
/* 221 */           String name = jarEntry.getName();
/* 222 */           File expandedFile = new File(docBase, name);
/* 223 */           if (!expandedFile.getCanonicalPath().startsWith(canonicalDocBasePrefix))
/*     */           {
/*     */ 
/*     */ 
/* 227 */             throw new IllegalArgumentException(sm.getString("expandWar.illegalPath", new Object[] { war, name, expandedFile.getCanonicalPath(), canonicalDocBasePrefix }));
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Throwable localThrowable1)
/*     */       {
/* 217 */         localThrowable2 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       finally
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 233 */         if (jarFile != null) if (localThrowable2 != null) try { jarFile.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else jarFile.close();
/* 234 */       } } catch (IOException e) { throw e;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean copy(File src, File dest)
/*     */   {
/* 248 */     boolean result = true;
/*     */     
/* 250 */     String[] files = null;
/* 251 */     if (src.isDirectory()) {
/* 252 */       files = src.list();
/* 253 */       result = dest.mkdir();
/*     */     } else {
/* 255 */       files = new String[1];
/* 256 */       files[0] = "";
/*     */     }
/* 258 */     if (files == null) {
/* 259 */       files = new String[0];
/*     */     }
/* 261 */     for (int i = 0; (i < files.length) && (result); i++) {
/* 262 */       File fileSrc = new File(src, files[i]);
/* 263 */       File fileDest = new File(dest, files[i]);
/* 264 */       if (fileSrc.isDirectory())
/* 265 */         result = copy(fileSrc, fileDest); else {
/*     */         try {
/* 267 */           FileChannel ic = new FileInputStream(fileSrc).getChannel();Throwable localThrowable3 = null;
/* 268 */           try { FileChannel oc = new FileOutputStream(fileDest).getChannel();Throwable localThrowable4 = null;
/* 269 */             try { ic.transferTo(0L, ic.size(), oc);
/*     */             }
/*     */             catch (Throwable localThrowable1)
/*     */             {
/* 267 */               localThrowable4 = localThrowable1;throw localThrowable1; } finally {} } catch (Throwable localThrowable2) { localThrowable3 = localThrowable2;throw localThrowable2;
/*     */           }
/*     */           finally {
/* 270 */             if (ic != null) if (localThrowable3 != null) try { ic.close(); } catch (Throwable x2) { localThrowable3.addSuppressed(x2); } else ic.close();
/* 271 */           } } catch (IOException e) { log.error(sm.getString("expandWar.copy", new Object[] { fileSrc, fileDest }), e);
/* 272 */           result = false;
/*     */         }
/*     */       }
/*     */     }
/* 276 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean delete(File dir)
/*     */   {
/* 289 */     return delete(dir, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean delete(File dir, boolean logFailure)
/*     */   {
/*     */     boolean result;
/*     */     
/*     */ 
/*     */ 
/*     */     boolean result;
/*     */     
/*     */ 
/* 304 */     if (dir.isDirectory()) {
/* 305 */       result = deleteDir(dir, logFailure);
/*     */     } else { boolean result;
/* 307 */       if (dir.exists()) {
/* 308 */         result = dir.delete();
/*     */       } else {
/* 310 */         result = true;
/*     */       }
/*     */     }
/* 313 */     if ((logFailure) && (!result)) {
/* 314 */       log.error(sm.getString("expandWar.deleteFailed", new Object[] { dir.getAbsolutePath() }));
/*     */     }
/*     */     
/* 317 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean deleteDir(File dir)
/*     */   {
/* 329 */     return deleteDir(dir, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean deleteDir(File dir, boolean logFailure)
/*     */   {
/* 344 */     String[] files = dir.list();
/* 345 */     if (files == null) {
/* 346 */       files = new String[0];
/*     */     }
/* 348 */     for (int i = 0; i < files.length; i++) {
/* 349 */       File file = new File(dir, files[i]);
/* 350 */       if (file.isDirectory()) {
/* 351 */         deleteDir(file, logFailure);
/*     */       } else {
/* 353 */         file.delete();
/*     */       }
/*     */     }
/*     */     boolean result;
/*     */     boolean result;
/* 358 */     if (dir.exists()) {
/* 359 */       result = dir.delete();
/*     */     } else {
/* 361 */       result = true;
/*     */     }
/*     */     
/* 364 */     if ((logFailure) && (!result)) {
/* 365 */       log.error(sm.getString("expandWar.deleteFailed", new Object[] { dir.getAbsolutePath() }));
/*     */     }
/*     */     
/*     */ 
/* 369 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void expand(InputStream input, File file)
/*     */     throws IOException
/*     */   {
/* 382 */     BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(file));Throwable localThrowable2 = null;
/*     */     try {
/* 384 */       byte[] buffer = new byte['ࠀ'];
/*     */       for (;;) {
/* 386 */         int n = input.read(buffer);
/* 387 */         if (n <= 0)
/*     */           break;
/* 389 */         output.write(buffer, 0, n);
/*     */       }
/*     */     }
/*     */     catch (Throwable localThrowable1)
/*     */     {
/* 382 */       localThrowable2 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/*     */ 
/* 391 */       if (output != null) if (localThrowable2 != null) try { output.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else output.close();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\startup\ExpandWar.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */