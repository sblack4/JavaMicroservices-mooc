/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.catalina.security.SecurityClassLoad;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Bootstrap
/*     */ {
/*  52 */   private static final Log log = LogFactory.getLog(Bootstrap.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  57 */   private static Bootstrap daemon = null;
/*     */   
/*     */   private static final File catalinaBaseFile;
/*     */   
/*     */   private static final File catalinaHomeFile;
/*  62 */   private static final Pattern PATH_PATTERN = Pattern.compile("(\".*?\")|(([^,])*)");
/*     */   
/*     */   static
/*     */   {
/*  66 */     String userDir = System.getProperty("user.dir");
/*     */     
/*     */ 
/*  69 */     String home = System.getProperty("catalina.home");
/*  70 */     File homeFile = null;
/*     */     
/*  72 */     if (home != null) {
/*  73 */       File f = new File(home);
/*     */       try {
/*  75 */         homeFile = f.getCanonicalFile();
/*     */       } catch (IOException ioe) {
/*  77 */         homeFile = f.getAbsoluteFile();
/*     */       }
/*     */     }
/*     */     
/*  81 */     if (homeFile == null)
/*     */     {
/*     */ 
/*  84 */       File bootstrapJar = new File(userDir, "bootstrap.jar");
/*     */       
/*  86 */       if (bootstrapJar.exists()) {
/*  87 */         File f = new File(userDir, "..");
/*     */         try {
/*  89 */           homeFile = f.getCanonicalFile();
/*     */         } catch (IOException ioe) {
/*  91 */           homeFile = f.getAbsoluteFile();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  96 */     if (homeFile == null)
/*     */     {
/*  98 */       File f = new File(userDir);
/*     */       try {
/* 100 */         homeFile = f.getCanonicalFile();
/*     */       } catch (IOException ioe) {
/* 102 */         homeFile = f.getAbsoluteFile();
/*     */       }
/*     */     }
/*     */     
/* 106 */     catalinaHomeFile = homeFile;
/* 107 */     System.setProperty("catalina.home", catalinaHomeFile.getPath());
/*     */     
/*     */ 
/*     */ 
/* 111 */     String base = System.getProperty("catalina.base");
/* 112 */     if (base == null) {
/* 113 */       catalinaBaseFile = catalinaHomeFile;
/*     */     } else {
/* 115 */       File baseFile = new File(base);
/*     */       try {
/* 117 */         baseFile = baseFile.getCanonicalFile();
/*     */       } catch (IOException ioe) {
/* 119 */         baseFile = baseFile.getAbsoluteFile();
/*     */       }
/* 121 */       catalinaBaseFile = baseFile;
/*     */     }
/* 123 */     System.setProperty("catalina.base", catalinaBaseFile.getPath());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 133 */   private Object catalinaDaemon = null;
/*     */   
/*     */ 
/* 136 */   ClassLoader commonLoader = null;
/* 137 */   ClassLoader catalinaLoader = null;
/* 138 */   ClassLoader sharedLoader = null;
/*     */   
/*     */ 
/*     */ 
/*     */   private void initClassLoaders()
/*     */   {
/*     */     try
/*     */     {
/* 146 */       this.commonLoader = createClassLoader("common", null);
/* 147 */       if (this.commonLoader == null)
/*     */       {
/* 149 */         this.commonLoader = getClass().getClassLoader();
/*     */       }
/* 151 */       this.catalinaLoader = createClassLoader("server", this.commonLoader);
/* 152 */       this.sharedLoader = createClassLoader("shared", this.commonLoader);
/*     */     } catch (Throwable t) {
/* 154 */       handleThrowable(t);
/* 155 */       log.error("Class loader creation threw exception", t);
/* 156 */       System.exit(1);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private ClassLoader createClassLoader(String name, ClassLoader parent)
/*     */     throws Exception
/*     */   {
/* 164 */     String value = CatalinaProperties.getProperty(name + ".loader");
/* 165 */     if ((value == null) || (value.equals(""))) {
/* 166 */       return parent;
/*     */     }
/* 168 */     value = replace(value);
/*     */     
/* 170 */     List<ClassLoaderFactory.Repository> repositories = new ArrayList();
/*     */     
/* 172 */     String[] repositoryPaths = getPaths(value);
/*     */     
/* 174 */     for (String repository : repositoryPaths)
/*     */     {
/*     */       try
/*     */       {
/* 178 */         URL url = new URL(repository);
/* 179 */         repositories.add(new ClassLoaderFactory.Repository(repository, ClassLoaderFactory.RepositoryType.URL));
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (MalformedURLException localMalformedURLException)
/*     */       {
/*     */ 
/*     */ 
/* 187 */         if (repository.endsWith("*.jar")) {
/* 188 */           repository = repository.substring(0, repository.length() - "*.jar".length());
/*     */           
/* 190 */           repositories.add(new ClassLoaderFactory.Repository(repository, ClassLoaderFactory.RepositoryType.GLOB));
/*     */         }
/* 192 */         else if (repository.endsWith(".jar")) {
/* 193 */           repositories.add(new ClassLoaderFactory.Repository(repository, ClassLoaderFactory.RepositoryType.JAR));
/*     */         }
/*     */         else {
/* 196 */           repositories.add(new ClassLoaderFactory.Repository(repository, ClassLoaderFactory.RepositoryType.DIR));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 201 */     return ClassLoaderFactory.createClassLoader(repositories, parent);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String replace(String str)
/*     */   {
/* 214 */     String result = str;
/* 215 */     int pos_start = str.indexOf("${");
/* 216 */     if (pos_start >= 0) {
/* 217 */       StringBuilder builder = new StringBuilder();
/* 218 */       int pos_end = -1;
/* 219 */       while (pos_start >= 0) {
/* 220 */         builder.append(str, pos_end + 1, pos_start);
/* 221 */         pos_end = str.indexOf('}', pos_start + 2);
/* 222 */         if (pos_end < 0) {
/* 223 */           pos_end = pos_start - 1;
/* 224 */           break;
/*     */         }
/* 226 */         String propName = str.substring(pos_start + 2, pos_end);
/*     */         String replacement;
/* 228 */         String replacement; if (propName.length() == 0) {
/* 229 */           replacement = null; } else { String replacement;
/* 230 */           if ("catalina.home".equals(propName)) {
/* 231 */             replacement = getCatalinaHome(); } else { String replacement;
/* 232 */             if ("catalina.base".equals(propName)) {
/* 233 */               replacement = getCatalinaBase();
/*     */             } else
/* 235 */               replacement = System.getProperty(propName);
/*     */           } }
/* 237 */         if (replacement != null) {
/* 238 */           builder.append(replacement);
/*     */         } else {
/* 240 */           builder.append(str, pos_start, pos_end + 1);
/*     */         }
/* 242 */         pos_start = str.indexOf("${", pos_end + 1);
/*     */       }
/* 244 */       builder.append(str, pos_end + 1, str.length());
/* 245 */       result = builder.toString();
/*     */     }
/* 247 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void init()
/*     */     throws Exception
/*     */   {
/* 257 */     initClassLoaders();
/*     */     
/* 259 */     Thread.currentThread().setContextClassLoader(this.catalinaLoader);
/*     */     
/* 261 */     SecurityClassLoad.securityClassLoad(this.catalinaLoader);
/*     */     
/*     */ 
/* 264 */     if (log.isDebugEnabled())
/* 265 */       log.debug("Loading startup class");
/* 266 */     Class<?> startupClass = this.catalinaLoader.loadClass("org.apache.catalina.startup.Catalina");
/*     */     
/*     */ 
/* 269 */     Object startupInstance = startupClass.newInstance();
/*     */     
/*     */ 
/* 272 */     if (log.isDebugEnabled())
/* 273 */       log.debug("Setting startup class properties");
/* 274 */     String methodName = "setParentClassLoader";
/* 275 */     Class<?>[] paramTypes = new Class[1];
/* 276 */     paramTypes[0] = Class.forName("java.lang.ClassLoader");
/* 277 */     Object[] paramValues = new Object[1];
/* 278 */     paramValues[0] = this.sharedLoader;
/* 279 */     Method method = startupInstance.getClass().getMethod(methodName, paramTypes);
/*     */     
/* 281 */     method.invoke(startupInstance, paramValues);
/*     */     
/* 283 */     this.catalinaDaemon = startupInstance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void load(String[] arguments)
/*     */     throws Exception
/*     */   {
/* 295 */     String methodName = "load";
/*     */     Object[] param;
/*     */     Class<?>[] paramTypes;
/* 298 */     Object[] param; if ((arguments == null) || (arguments.length == 0)) {
/* 299 */       Class<?>[] paramTypes = null;
/* 300 */       param = null;
/*     */     } else {
/* 302 */       paramTypes = new Class[1];
/* 303 */       paramTypes[0] = arguments.getClass();
/* 304 */       param = new Object[1];
/* 305 */       param[0] = arguments;
/*     */     }
/* 307 */     Method method = this.catalinaDaemon.getClass().getMethod(methodName, paramTypes);
/*     */     
/* 309 */     if (log.isDebugEnabled())
/* 310 */       log.debug("Calling startup class " + method);
/* 311 */     method.invoke(this.catalinaDaemon, param);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object getServer()
/*     */     throws Exception
/*     */   {
/* 321 */     String methodName = "getServer";
/* 322 */     Method method = this.catalinaDaemon.getClass().getMethod(methodName, new Class[0]);
/*     */     
/* 324 */     return method.invoke(this.catalinaDaemon, new Object[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void init(String[] arguments)
/*     */     throws Exception
/*     */   {
/* 340 */     init();
/* 341 */     load(arguments);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void start()
/*     */     throws Exception
/*     */   {
/* 352 */     if (this.catalinaDaemon == null) { init();
/*     */     }
/* 354 */     Method method = this.catalinaDaemon.getClass().getMethod("start", (Class[])null);
/* 355 */     method.invoke(this.catalinaDaemon, (Object[])null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stop()
/*     */     throws Exception
/*     */   {
/* 367 */     Method method = this.catalinaDaemon.getClass().getMethod("stop", (Class[])null);
/* 368 */     method.invoke(this.catalinaDaemon, (Object[])null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stopServer()
/*     */     throws Exception
/*     */   {
/* 380 */     Method method = this.catalinaDaemon.getClass().getMethod("stopServer", (Class[])null);
/*     */     
/* 382 */     method.invoke(this.catalinaDaemon, (Object[])null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void stopServer(String[] arguments)
/*     */     throws Exception
/*     */   {
/*     */     Object[] param;
/*     */     
/*     */ 
/*     */     Class<?>[] paramTypes;
/*     */     
/*     */     Object[] param;
/*     */     
/* 397 */     if ((arguments == null) || (arguments.length == 0)) {
/* 398 */       Class<?>[] paramTypes = null;
/* 399 */       param = null;
/*     */     } else {
/* 401 */       paramTypes = new Class[1];
/* 402 */       paramTypes[0] = arguments.getClass();
/* 403 */       param = new Object[1];
/* 404 */       param[0] = arguments;
/*     */     }
/* 406 */     Method method = this.catalinaDaemon.getClass().getMethod("stopServer", paramTypes);
/*     */     
/* 408 */     method.invoke(this.catalinaDaemon, param);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAwait(boolean await)
/*     */     throws Exception
/*     */   {
/* 421 */     Class<?>[] paramTypes = new Class[1];
/* 422 */     paramTypes[0] = Boolean.TYPE;
/* 423 */     Object[] paramValues = new Object[1];
/* 424 */     paramValues[0] = Boolean.valueOf(await);
/* 425 */     Method method = this.catalinaDaemon.getClass().getMethod("setAwait", paramTypes);
/*     */     
/* 427 */     method.invoke(this.catalinaDaemon, paramValues);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean getAwait()
/*     */     throws Exception
/*     */   {
/* 434 */     Class<?>[] paramTypes = new Class[0];
/* 435 */     Object[] paramValues = new Object[0];
/* 436 */     Method method = this.catalinaDaemon.getClass().getMethod("getAwait", paramTypes);
/*     */     
/* 438 */     Boolean b = (Boolean)method.invoke(this.catalinaDaemon, paramValues);
/* 439 */     return b.booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 461 */     if (daemon == null)
/*     */     {
/* 463 */       Bootstrap bootstrap = new Bootstrap();
/*     */       try {
/* 465 */         bootstrap.init();
/*     */       } catch (Throwable t) {
/* 467 */         handleThrowable(t);
/* 468 */         t.printStackTrace();
/* 469 */         return;
/*     */       }
/* 471 */       daemon = bootstrap;
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 476 */       Thread.currentThread().setContextClassLoader(daemon.catalinaLoader);
/*     */     }
/*     */     try
/*     */     {
/* 480 */       String command = "start";
/* 481 */       if (args.length > 0) {
/* 482 */         command = args[(args.length - 1)];
/*     */       }
/*     */       
/* 485 */       if (command.equals("startd")) {
/* 486 */         args[(args.length - 1)] = "start";
/* 487 */         daemon.load(args);
/* 488 */         daemon.start();
/* 489 */       } else if (command.equals("stopd")) {
/* 490 */         args[(args.length - 1)] = "stop";
/* 491 */         daemon.stop();
/* 492 */       } else if (command.equals("start")) {
/* 493 */         daemon.setAwait(true);
/* 494 */         daemon.load(args);
/* 495 */         daemon.start();
/* 496 */       } else if (command.equals("stop")) {
/* 497 */         daemon.stopServer(args);
/* 498 */       } else if (command.equals("configtest")) {
/* 499 */         daemon.load(args);
/* 500 */         if (null == daemon.getServer()) {
/* 501 */           System.exit(1);
/*     */         }
/* 503 */         System.exit(0);
/*     */       } else {
/* 505 */         log.warn("Bootstrap: command \"" + command + "\" does not exist.");
/*     */       }
/*     */     }
/*     */     catch (Throwable t) {
/* 509 */       if (((t instanceof InvocationTargetException)) && (t.getCause() != null))
/*     */       {
/* 511 */         t = t.getCause();
/*     */       }
/* 513 */       handleThrowable(t);
/* 514 */       t.printStackTrace();
/* 515 */       System.exit(1);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCatalinaHome()
/*     */   {
/* 527 */     return catalinaHomeFile.getPath();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCatalinaBase()
/*     */   {
/* 538 */     return catalinaBaseFile.getPath();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static File getCatalinaHomeFile()
/*     */   {
/* 548 */     return catalinaHomeFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static File getCatalinaBaseFile()
/*     */   {
/* 559 */     return catalinaBaseFile;
/*     */   }
/*     */   
/*     */ 
/*     */   private static void handleThrowable(Throwable t)
/*     */   {
/* 565 */     if ((t instanceof ThreadDeath)) {
/* 566 */       throw ((ThreadDeath)t);
/*     */     }
/* 568 */     if ((t instanceof VirtualMachineError)) {
/* 569 */       throw ((VirtualMachineError)t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static String[] getPaths(String value)
/*     */   {
/* 578 */     List<String> result = new ArrayList();
/* 579 */     Matcher matcher = PATH_PATTERN.matcher(value);
/*     */     
/* 581 */     while (matcher.find()) {
/* 582 */       String path = value.substring(matcher.start(), matcher.end());
/*     */       
/* 584 */       path = path.trim();
/* 585 */       if (path.length() != 0)
/*     */       {
/*     */ 
/*     */ 
/* 589 */         char first = path.charAt(0);
/* 590 */         char last = path.charAt(path.length() - 1);
/*     */         
/* 592 */         if ((first == '"') && (last == '"') && (path.length() > 1)) {
/* 593 */           path = path.substring(1, path.length() - 1);
/* 594 */           path = path.trim();
/* 595 */           if (path.length() != 0) {}
/*     */ 
/*     */         }
/* 598 */         else if (path.contains("\""))
/*     */         {
/*     */ 
/*     */ 
/* 602 */           throw new IllegalArgumentException("The double quote [\"] character only be used to quote paths. It must not appear in a path. This loader path is not valid: [" + value + "]");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 609 */         result.add(path);
/*     */       } }
/* 611 */     return (String[])result.toArray(new String[result.size()]);
/*     */   }
/*     */   
/*     */   public void destroy() {}
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\startup\Bootstrap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */