/*      */ package org.apache.catalina.startup;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URI;
/*      */ import java.net.URL;
/*      */ import java.security.Principal;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Stack;
/*      */ import java.util.jar.JarEntry;
/*      */ import java.util.jar.JarFile;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import javax.servlet.Servlet;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.SingleThreadModel;
/*      */ import javax.servlet.annotation.WebServlet;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.LifecycleEvent;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleListener;
/*      */ import org.apache.catalina.Pipeline;
/*      */ import org.apache.catalina.Realm;
/*      */ import org.apache.catalina.Server;
/*      */ import org.apache.catalina.Service;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.authenticator.NonLoginAuthenticator;
/*      */ import org.apache.catalina.connector.Connector;
/*      */ import org.apache.catalina.core.ContainerBase;
/*      */ import org.apache.catalina.core.NamingContextListener;
/*      */ import org.apache.catalina.core.StandardContext;
/*      */ import org.apache.catalina.core.StandardEngine;
/*      */ import org.apache.catalina.core.StandardHost;
/*      */ import org.apache.catalina.core.StandardServer;
/*      */ import org.apache.catalina.core.StandardService;
/*      */ import org.apache.catalina.core.StandardWrapper;
/*      */ import org.apache.catalina.realm.GenericPrincipal;
/*      */ import org.apache.catalina.realm.RealmBase;
/*      */ import org.apache.tomcat.util.buf.UriUtil;
/*      */ import org.apache.tomcat.util.descriptor.web.LoginConfig;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Tomcat
/*      */ {
/*  134 */   private final Map<String, Logger> pinnedLoggers = new HashMap();
/*      */   
/*      */ 
/*      */   protected Server server;
/*      */   
/*      */ 
/*      */   protected Service service;
/*      */   
/*      */ 
/*      */   protected Engine engine;
/*      */   
/*      */ 
/*      */   protected Connector connector;
/*      */   
/*      */ 
/*      */   protected Host host;
/*      */   
/*      */ 
/*  152 */   protected int port = 8080;
/*  153 */   protected String hostname = "localhost";
/*      */   
/*      */   protected String basedir;
/*  156 */   private final Map<String, String> userPass = new HashMap();
/*  157 */   private final Map<String, List<String>> userRoles = new HashMap();
/*  158 */   private final Map<String, Principal> userPrincipals = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBaseDir(String basedir)
/*      */   {
/*  179 */     this.basedir = basedir;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPort(int port)
/*      */   {
/*  188 */     this.port = port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHostname(String s)
/*      */   {
/*  197 */     this.hostname = s;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Context addWebapp(String contextPath, String docBase)
/*      */     throws ServletException
/*      */   {
/*  215 */     return addWebapp(getHost(), contextPath, docBase);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Context addContext(String contextPath, String docBase)
/*      */   {
/*  256 */     return addContext(getHost(), contextPath, docBase);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Wrapper addServlet(String contextPath, String servletName, String servletClass)
/*      */   {
/*  279 */     Container ctx = getHost().findChild(contextPath);
/*  280 */     return addServlet((Context)ctx, servletName, servletClass);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Wrapper addServlet(Context ctx, String servletName, String servletClass)
/*      */   {
/*  294 */     Wrapper sw = ctx.createWrapper();
/*  295 */     sw.setServletClass(servletClass);
/*  296 */     sw.setName(servletName);
/*  297 */     ctx.addChild(sw);
/*      */     
/*  299 */     return sw;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Wrapper addServlet(String contextPath, String servletName, Servlet servlet)
/*      */   {
/*  313 */     Container ctx = getHost().findChild(contextPath);
/*  314 */     return addServlet((Context)ctx, servletName, servlet);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Wrapper addServlet(Context ctx, String servletName, Servlet servlet)
/*      */   {
/*  328 */     Wrapper sw = new ExistingStandardWrapper(servlet);
/*  329 */     sw.setName(servletName);
/*  330 */     ctx.addChild(sw);
/*      */     
/*  332 */     return sw;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void init()
/*      */     throws LifecycleException
/*      */   {
/*  342 */     getServer();
/*  343 */     getConnector();
/*  344 */     this.server.init();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void start()
/*      */     throws LifecycleException
/*      */   {
/*  354 */     getServer();
/*  355 */     getConnector();
/*  356 */     this.server.start();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void stop()
/*      */     throws LifecycleException
/*      */   {
/*  365 */     getServer();
/*  366 */     this.server.stop();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void destroy()
/*      */     throws LifecycleException
/*      */   {
/*  377 */     getServer();
/*  378 */     this.server.destroy();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addUser(String user, String pass)
/*      */   {
/*  389 */     this.userPass.put(user, pass);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addRole(String user, String role)
/*      */   {
/*  399 */     List<String> roles = (List)this.userRoles.get(user);
/*  400 */     if (roles == null) {
/*  401 */       roles = new ArrayList();
/*  402 */       this.userRoles.put(user, roles);
/*      */     }
/*  404 */     roles.add(role);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Connector getConnector()
/*      */   {
/*  420 */     getServer();
/*  421 */     if (this.connector != null) {
/*  422 */       return this.connector;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  429 */     this.connector = new Connector("HTTP/1.1");
/*  430 */     this.connector.setPort(this.port);
/*  431 */     this.service.addConnector(this.connector);
/*  432 */     return this.connector;
/*      */   }
/*      */   
/*      */   public void setConnector(Connector connector) {
/*  436 */     this.connector = connector;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Service getService()
/*      */   {
/*  445 */     getServer();
/*  446 */     return this.service;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHost(Host host)
/*      */   {
/*  457 */     this.host = host;
/*      */   }
/*      */   
/*      */   public Host getHost() {
/*  461 */     if (this.host == null) {
/*  462 */       this.host = new StandardHost();
/*  463 */       this.host.setName(this.hostname);
/*      */       
/*  465 */       getEngine().addChild(this.host);
/*      */     }
/*  467 */     return this.host;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Engine getEngine()
/*      */   {
/*  475 */     if (this.engine == null) {
/*  476 */       getServer();
/*  477 */       this.engine = new StandardEngine();
/*  478 */       this.engine.setName("Tomcat");
/*  479 */       this.engine.setDefaultHost(this.hostname);
/*  480 */       this.engine.setRealm(createDefaultRealm());
/*  481 */       this.service.setContainer(this.engine);
/*      */     }
/*  483 */     return this.engine;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Server getServer()
/*      */   {
/*  493 */     if (this.server != null) {
/*  494 */       return this.server;
/*      */     }
/*      */     
/*  497 */     System.setProperty("catalina.useNaming", "false");
/*      */     
/*  499 */     this.server = new StandardServer();
/*      */     
/*  501 */     initBaseDir();
/*      */     
/*  503 */     this.server.setPort(-1);
/*      */     
/*  505 */     this.service = new StandardService();
/*  506 */     this.service.setName("Tomcat");
/*  507 */     this.server.addService(this.service);
/*  508 */     return this.server;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Context addContext(Host host, String contextPath, String dir)
/*      */   {
/*  520 */     return addContext(host, contextPath, contextPath, dir);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Context addContext(Host host, String contextPath, String contextName, String dir)
/*      */   {
/*  534 */     silence(host, contextName);
/*  535 */     Context ctx = createContext(host, contextPath);
/*  536 */     ctx.setName(contextName);
/*  537 */     ctx.setPath(contextPath);
/*  538 */     ctx.setDocBase(dir);
/*  539 */     ctx.addLifecycleListener(new FixContextListener());
/*      */     
/*  541 */     if (host == null) {
/*  542 */       getHost().addChild(ctx);
/*      */     } else {
/*  544 */       host.addChild(ctx);
/*      */     }
/*  546 */     return ctx;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Context addWebapp(Host host, String contextPath, String docBase)
/*      */   {
/*  558 */     return addWebapp(host, contextPath, docBase, new ContextConfig());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Context addWebapp(Host host, String contextPath, String docBase, ContextConfig config)
/*      */   {
/*  572 */     silence(host, contextPath);
/*      */     
/*  574 */     Context ctx = createContext(host, contextPath);
/*  575 */     ctx.setPath(contextPath);
/*  576 */     ctx.setDocBase(docBase);
/*  577 */     ctx.addLifecycleListener(new DefaultWebXmlListener());
/*  578 */     ctx.setConfigFile(getWebappConfigFile(docBase, contextPath));
/*      */     
/*  580 */     ctx.addLifecycleListener(config);
/*      */     
/*      */ 
/*  583 */     config.setDefaultWebXml(noDefaultWebXmlPath());
/*      */     
/*  585 */     if (host == null) {
/*  586 */       getHost().addChild(ctx);
/*      */     } else {
/*  588 */       host.addChild(ctx);
/*      */     }
/*      */     
/*  591 */     return ctx;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public LifecycleListener getDefaultWebXmlListener()
/*      */   {
/*  603 */     return new DefaultWebXmlListener();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String noDefaultWebXmlPath()
/*      */   {
/*  612 */     return "org/apache/catalina/startup/NO_DEFAULT_XML";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Realm createDefaultRealm()
/*      */   {
/*  625 */     new RealmBase()
/*      */     {
/*      */       protected String getName() {
/*  628 */         return "Simple";
/*      */       }
/*      */       
/*      */       protected String getPassword(String username)
/*      */       {
/*  633 */         return (String)Tomcat.this.userPass.get(username);
/*      */       }
/*      */       
/*      */       protected Principal getPrincipal(String username)
/*      */       {
/*  638 */         Principal p = (Principal)Tomcat.this.userPrincipals.get(username);
/*  639 */         if (p == null) {
/*  640 */           String pass = (String)Tomcat.this.userPass.get(username);
/*  641 */           if (pass != null) {
/*  642 */             p = new GenericPrincipal(username, pass, (List)Tomcat.this.userRoles.get(username));
/*      */             
/*  644 */             Tomcat.this.userPrincipals.put(username, p);
/*      */           }
/*      */         }
/*  647 */         return p;
/*      */       }
/*      */     };
/*      */   }
/*      */   
/*      */   protected void initBaseDir()
/*      */   {
/*  654 */     String catalinaHome = System.getProperty("catalina.home");
/*  655 */     if (this.basedir == null) {
/*  656 */       this.basedir = System.getProperty("catalina.base");
/*      */     }
/*  658 */     if (this.basedir == null) {
/*  659 */       this.basedir = catalinaHome;
/*      */     }
/*  661 */     if (this.basedir == null)
/*      */     {
/*  663 */       this.basedir = (System.getProperty("user.dir") + "/tomcat." + this.port);
/*      */     }
/*      */     
/*      */ 
/*  667 */     File baseFile = new File(this.basedir);
/*  668 */     baseFile.mkdirs();
/*      */     try {
/*  670 */       baseFile = baseFile.getCanonicalFile();
/*      */     } catch (IOException e) {
/*  672 */       baseFile = baseFile.getAbsoluteFile();
/*      */     }
/*  674 */     this.server.setCatalinaBase(baseFile);
/*  675 */     System.setProperty("catalina.base", baseFile.getPath());
/*  676 */     this.basedir = baseFile.getPath();
/*      */     
/*  678 */     if (catalinaHome == null) {
/*  679 */       this.server.setCatalinaHome(baseFile);
/*      */     } else {
/*  681 */       File homeFile = new File(catalinaHome);
/*  682 */       homeFile.mkdirs();
/*      */       try {
/*  684 */         homeFile = homeFile.getCanonicalFile();
/*      */       } catch (IOException e) {
/*  686 */         homeFile = homeFile.getAbsoluteFile();
/*      */       }
/*  688 */       this.server.setCatalinaHome(homeFile);
/*      */     }
/*  690 */     System.setProperty("catalina.home", this.server.getCatalinaHome().getPath());
/*      */   }
/*      */   
/*      */ 
/*  694 */   static final String[] silences = { "org.apache.coyote.http11.Http11NioProtocol", "org.apache.catalina.core.StandardService", "org.apache.catalina.core.StandardEngine", "org.apache.catalina.startup.ContextConfig", "org.apache.catalina.core.ApplicationContext", "org.apache.catalina.core.AprLifecycleListener" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  703 */   private boolean silent = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSilent(boolean silent)
/*      */   {
/*  714 */     this.silent = silent;
/*  715 */     for (String s : silences) {
/*  716 */       Logger logger = Logger.getLogger(s);
/*  717 */       this.pinnedLoggers.put(s, logger);
/*  718 */       if (silent) {
/*  719 */         logger.setLevel(Level.WARNING);
/*      */       } else {
/*  721 */         logger.setLevel(Level.INFO);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void silence(Host host, String contextPath) {
/*  727 */     String loggerName = getLoggerName(host, contextPath);
/*  728 */     Logger logger = Logger.getLogger(loggerName);
/*  729 */     this.pinnedLoggers.put(loggerName, logger);
/*  730 */     if (this.silent) {
/*  731 */       logger.setLevel(Level.WARNING);
/*      */     } else {
/*  733 */       logger.setLevel(Level.INFO);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getLoggerName(Host host, String contextName)
/*      */   {
/*  742 */     if (host == null) {
/*  743 */       host = getHost();
/*      */     }
/*  745 */     StringBuilder loggerName = new StringBuilder();
/*  746 */     loggerName.append(ContainerBase.class.getName());
/*  747 */     loggerName.append(".[");
/*      */     
/*  749 */     loggerName.append(host.getParent().getName());
/*  750 */     loggerName.append("].[");
/*      */     
/*  752 */     loggerName.append(host.getName());
/*  753 */     loggerName.append("].[");
/*      */     
/*  755 */     if ((contextName == null) || (contextName.equals(""))) {
/*  756 */       loggerName.append("/");
/*  757 */     } else if (contextName.startsWith("##")) {
/*  758 */       loggerName.append("/");
/*  759 */       loggerName.append(contextName);
/*      */     }
/*  761 */     loggerName.append(']');
/*      */     
/*  763 */     return loggerName.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Context createContext(Host host, String url)
/*      */   {
/*  779 */     String contextClass = StandardContext.class.getName();
/*  780 */     if (host == null) {
/*  781 */       host = getHost();
/*      */     }
/*  783 */     if ((host instanceof StandardHost)) {
/*  784 */       contextClass = ((StandardHost)host).getContextClass();
/*      */     }
/*      */     try {
/*  787 */       return (Context)Class.forName(contextClass).getConstructor(new Class[0]).newInstance(new Object[0]);
/*      */ 
/*      */     }
/*      */     catch (InstantiationException|IllegalAccessException|IllegalArgumentException|InvocationTargetException|NoSuchMethodException|SecurityException|ClassNotFoundException e)
/*      */     {
/*      */ 
/*  793 */       throw new IllegalArgumentException("Can't instantiate context-class " + contextClass + " for host " + host + " and url " + url, e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void enableNaming()
/*      */   {
/*  809 */     getServer();
/*  810 */     this.server.addLifecycleListener(new NamingContextListener());
/*      */     
/*  812 */     System.setProperty("catalina.useNaming", "true");
/*      */     
/*  814 */     String value = "org.apache.naming";
/*  815 */     String oldValue = System.getProperty("java.naming.factory.url.pkgs");
/*      */     
/*  817 */     if (oldValue != null) {
/*  818 */       if (oldValue.contains(value)) {
/*  819 */         value = oldValue;
/*      */       } else {
/*  821 */         value = value + ":" + oldValue;
/*      */       }
/*      */     }
/*  824 */     System.setProperty("java.naming.factory.url.pkgs", value);
/*      */     
/*  826 */     value = System.getProperty("java.naming.factory.initial");
/*      */     
/*  828 */     if (value == null) {
/*  829 */       System.setProperty("java.naming.factory.initial", "org.apache.naming.java.javaURLContextFactory");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void initWebappDefaults(String contextPath)
/*      */   {
/*  845 */     Container ctx = getHost().findChild(contextPath);
/*  846 */     initWebappDefaults((Context)ctx);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void initWebappDefaults(Context ctx)
/*      */   {
/*  855 */     Wrapper servlet = addServlet(ctx, "default", "org.apache.catalina.servlets.DefaultServlet");
/*      */     
/*  857 */     servlet.setLoadOnStartup(1);
/*  858 */     servlet.setOverridable(true);
/*      */     
/*      */ 
/*  861 */     servlet = addServlet(ctx, "jsp", "org.apache.jasper.servlet.JspServlet");
/*      */     
/*  863 */     servlet.addInitParameter("fork", "false");
/*  864 */     servlet.setLoadOnStartup(3);
/*  865 */     servlet.setOverridable(true);
/*      */     
/*      */ 
/*  868 */     ctx.addServletMapping("/", "default");
/*  869 */     ctx.addServletMapping("*.jsp", "jsp");
/*  870 */     ctx.addServletMapping("*.jspx", "jsp");
/*      */     
/*      */ 
/*  873 */     ctx.setSessionTimeout(30);
/*      */     
/*      */ 
/*  876 */     for (int i = 0; i < DEFAULT_MIME_MAPPINGS.length;) {
/*  877 */       ctx.addMimeMapping(DEFAULT_MIME_MAPPINGS[(i++)], DEFAULT_MIME_MAPPINGS[(i++)]);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  882 */     ctx.addWelcomeFile("index.html");
/*  883 */     ctx.addWelcomeFile("index.htm");
/*  884 */     ctx.addWelcomeFile("index.jsp");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class FixContextListener
/*      */     implements LifecycleListener
/*      */   {
/*      */     public void lifecycleEvent(LifecycleEvent event)
/*      */     {
/*      */       try
/*      */       {
/*  899 */         Context context = (Context)event.getLifecycle();
/*  900 */         if (event.getType().equals("configure_start")) {
/*  901 */           context.setConfigured(true);
/*      */         }
/*      */         
/*      */ 
/*  905 */         if (context.getLoginConfig() == null) {
/*  906 */           context.setLoginConfig(new LoginConfig("NONE", null, null, null));
/*      */           
/*  908 */           context.getPipeline().addValve(new NonLoginAuthenticator());
/*      */         }
/*      */       }
/*      */       catch (ClassCastException e) {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class DefaultWebXmlListener
/*      */     implements LifecycleListener
/*      */   {
/*      */     public void lifecycleEvent(LifecycleEvent event)
/*      */     {
/*  926 */       if ("before_start".equals(event.getType())) {
/*  927 */         Tomcat.initWebappDefaults((Context)event.getLifecycle());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static class ExistingStandardWrapper
/*      */     extends StandardWrapper
/*      */   {
/*      */     private final Servlet existing;
/*      */     
/*      */ 
/*      */ 
/*      */     public ExistingStandardWrapper(Servlet existing)
/*      */     {
/*  943 */       this.existing = existing;
/*  944 */       if ((existing instanceof SingleThreadModel)) {
/*  945 */         this.singleThreadModel = true;
/*  946 */         this.instancePool = new Stack();
/*      */       }
/*  948 */       this.asyncSupported = hasAsync(existing);
/*      */     }
/*      */     
/*      */     private static boolean hasAsync(Servlet existing) {
/*  952 */       boolean result = false;
/*  953 */       Class<?> clazz = existing.getClass();
/*  954 */       WebServlet ws = (WebServlet)clazz.getAnnotation(WebServlet.class);
/*  955 */       if (ws != null) {
/*  956 */         result = ws.asyncSupported();
/*      */       }
/*  958 */       return result;
/*      */     }
/*      */     
/*      */     public synchronized Servlet loadServlet() throws ServletException
/*      */     {
/*  963 */       if (this.singleThreadModel)
/*      */       {
/*      */         try {
/*  966 */           instance = (Servlet)this.existing.getClass().newInstance();
/*      */         } catch (InstantiationException e) { Servlet instance;
/*  968 */           throw new ServletException(e);
/*      */         } catch (IllegalAccessException e) {
/*  970 */           throw new ServletException(e); }
/*      */         Servlet instance;
/*  972 */         instance.init(this.facade);
/*  973 */         return instance;
/*      */       }
/*  975 */       if (!this.instanceInitialized) {
/*  976 */         this.existing.init(this.facade);
/*  977 */         this.instanceInitialized = true;
/*      */       }
/*  979 */       return this.existing;
/*      */     }
/*      */     
/*      */     public long getAvailable()
/*      */     {
/*  984 */       return 0L;
/*      */     }
/*      */     
/*      */     public boolean isUnavailable() {
/*  988 */       return false;
/*      */     }
/*      */     
/*      */     public Servlet getServlet() {
/*  992 */       return this.existing;
/*      */     }
/*      */     
/*      */     public String getServletClass() {
/*  996 */       return this.existing.getClass().getName();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1006 */   private static final String[] DEFAULT_MIME_MAPPINGS = { "abs", "audio/x-mpeg", "ai", "application/postscript", "aif", "audio/x-aiff", "aifc", "audio/x-aiff", "aiff", "audio/x-aiff", "aim", "application/x-aim", "art", "image/x-jg", "asf", "video/x-ms-asf", "asx", "video/x-ms-asf", "au", "audio/basic", "avi", "video/x-msvideo", "avx", "video/x-rad-screenplay", "bcpio", "application/x-bcpio", "bin", "application/octet-stream", "bmp", "image/bmp", "body", "text/html", "cdf", "application/x-cdf", "cer", "application/pkix-cert", "class", "application/java", "cpio", "application/x-cpio", "csh", "application/x-csh", "css", "text/css", "dib", "image/bmp", "doc", "application/msword", "dtd", "application/xml-dtd", "dv", "video/x-dv", "dvi", "application/x-dvi", "eps", "application/postscript", "etx", "text/x-setext", "exe", "application/octet-stream", "gif", "image/gif", "gtar", "application/x-gtar", "gz", "application/x-gzip", "hdf", "application/x-hdf", "hqx", "application/mac-binhex40", "htc", "text/x-component", "htm", "text/html", "html", "text/html", "ief", "image/ief", "jad", "text/vnd.sun.j2me.app-descriptor", "jar", "application/java-archive", "java", "text/x-java-source", "jnlp", "application/x-java-jnlp-file", "jpe", "image/jpeg", "jpeg", "image/jpeg", "jpg", "image/jpeg", "js", "application/javascript", "jsf", "text/plain", "jspf", "text/plain", "kar", "audio/midi", "latex", "application/x-latex", "m3u", "audio/x-mpegurl", "mac", "image/x-macpaint", "man", "text/troff", "mathml", "application/mathml+xml", "me", "text/troff", "mid", "audio/midi", "midi", "audio/midi", "mif", "application/x-mif", "mov", "video/quicktime", "movie", "video/x-sgi-movie", "mp1", "audio/mpeg", "mp2", "audio/mpeg", "mp3", "audio/mpeg", "mp4", "video/mp4", "mpa", "audio/mpeg", "mpe", "video/mpeg", "mpeg", "video/mpeg", "mpega", "audio/x-mpeg", "mpg", "video/mpeg", "mpv2", "video/mpeg2", "nc", "application/x-netcdf", "oda", "application/oda", "odb", "application/vnd.oasis.opendocument.database", "odc", "application/vnd.oasis.opendocument.chart", "odf", "application/vnd.oasis.opendocument.formula", "odg", "application/vnd.oasis.opendocument.graphics", "odi", "application/vnd.oasis.opendocument.image", "odm", "application/vnd.oasis.opendocument.text-master", "odp", "application/vnd.oasis.opendocument.presentation", "ods", "application/vnd.oasis.opendocument.spreadsheet", "odt", "application/vnd.oasis.opendocument.text", "otg", "application/vnd.oasis.opendocument.graphics-template", "oth", "application/vnd.oasis.opendocument.text-web", "otp", "application/vnd.oasis.opendocument.presentation-template", "ots", "application/vnd.oasis.opendocument.spreadsheet-template ", "ott", "application/vnd.oasis.opendocument.text-template", "ogx", "application/ogg", "ogv", "video/ogg", "oga", "audio/ogg", "ogg", "audio/ogg", "spx", "audio/ogg", "flac", "audio/flac", "anx", "application/annodex", "axa", "audio/annodex", "axv", "video/annodex", "xspf", "application/xspf+xml", "pbm", "image/x-portable-bitmap", "pct", "image/pict", "pdf", "application/pdf", "pgm", "image/x-portable-graymap", "pic", "image/pict", "pict", "image/pict", "pls", "audio/x-scpls", "png", "image/png", "pnm", "image/x-portable-anymap", "pnt", "image/x-macpaint", "ppm", "image/x-portable-pixmap", "ppt", "application/vnd.ms-powerpoint", "pps", "application/vnd.ms-powerpoint", "ps", "application/postscript", "psd", "image/vnd.adobe.photoshop", "qt", "video/quicktime", "qti", "image/x-quicktime", "qtif", "image/x-quicktime", "ras", "image/x-cmu-raster", "rdf", "application/rdf+xml", "rgb", "image/x-rgb", "rm", "application/vnd.rn-realmedia", "roff", "text/troff", "rtf", "application/rtf", "rtx", "text/richtext", "sh", "application/x-sh", "shar", "application/x-shar", "sit", "application/x-stuffit", "snd", "audio/basic", "src", "application/x-wais-source", "sv4cpio", "application/x-sv4cpio", "sv4crc", "application/x-sv4crc", "svg", "image/svg+xml", "svgz", "image/svg+xml", "swf", "application/x-shockwave-flash", "t", "text/troff", "tar", "application/x-tar", "tcl", "application/x-tcl", "tex", "application/x-tex", "texi", "application/x-texinfo", "texinfo", "application/x-texinfo", "tif", "image/tiff", "tiff", "image/tiff", "tr", "text/troff", "tsv", "text/tab-separated-values", "txt", "text/plain", "ulw", "audio/basic", "ustar", "application/x-ustar", "vxml", "application/voicexml+xml", "xbm", "image/x-xbitmap", "xht", "application/xhtml+xml", "xhtml", "application/xhtml+xml", "xls", "application/vnd.ms-excel", "xml", "application/xml", "xpm", "image/x-xpixmap", "xsl", "application/xml", "xslt", "application/xslt+xml", "xul", "application/vnd.mozilla.xul+xml", "xwd", "image/x-xwindowdump", "vsd", "application/vnd.visio", "wav", "audio/x-wav", "wbmp", "image/vnd.wap.wbmp", "wml", "text/vnd.wap.wml", "wmlc", "application/vnd.wap.wmlc", "wmls", "text/vnd.wap.wmlsc", "wmlscriptc", "application/vnd.wap.wmlscriptc", "wmv", "video/x-ms-wmv", "wrl", "model/vrml", "wspolicy", "application/wspolicy+xml", "Z", "application/x-compress", "z", "application/x-compress", "zip", "application/zip" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected URL getWebappConfigFile(String path, String contextName)
/*      */   {
/* 1180 */     File docBase = new File(path);
/* 1181 */     if (docBase.isDirectory()) {
/* 1182 */       return getWebappConfigFileFromDirectory(docBase, contextName);
/*      */     }
/* 1184 */     return getWebappConfigFileFromJar(docBase, contextName);
/*      */   }
/*      */   
/*      */   private URL getWebappConfigFileFromDirectory(File docBase, String contextName)
/*      */   {
/* 1189 */     URL result = null;
/* 1190 */     File webAppContextXml = new File(docBase, "META-INF/context.xml");
/* 1191 */     if (webAppContextXml.exists()) {
/*      */       try {
/* 1193 */         result = webAppContextXml.toURI().toURL();
/*      */       } catch (MalformedURLException e) {
/* 1195 */         Logger.getLogger(getLoggerName(getHost(), contextName)).log(Level.WARNING, "Unable to determine web application context.xml " + docBase, e);
/*      */       }
/*      */     }
/*      */     
/* 1199 */     return result;
/*      */   }
/*      */   
/*      */   private URL getWebappConfigFileFromJar(File docBase, String contextName) {
/* 1203 */     URL result = null;
/* 1204 */     try { JarFile jar = new JarFile(docBase);Throwable localThrowable2 = null;
/* 1205 */       try { JarEntry entry = jar.getJarEntry("META-INF/context.xml");
/* 1206 */         if (entry != null) {
/* 1207 */           result = UriUtil.buildJarUrl(docBase, "META-INF/context.xml");
/*      */         }
/*      */       }
/*      */       catch (Throwable localThrowable1)
/*      */       {
/* 1204 */         localThrowable2 = localThrowable1;throw localThrowable1;
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/* 1209 */         if (jar != null) if (localThrowable2 != null) try { jar.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else jar.close();
/* 1210 */       } } catch (IOException e) { Logger.getLogger(getLoggerName(getHost(), contextName)).log(Level.WARNING, "Unable to determine web application context.xml " + docBase, e);
/*      */     }
/*      */     
/* 1213 */     return result;
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\startup\Tomcat.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */