/*      */ package org.apache.catalina.startup;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URL;
/*      */ import java.net.URLConnection;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.EnumSet;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import javax.servlet.MultipartConfigElement;
/*      */ import javax.servlet.ServletContainerInitializer;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.SessionCookieConfig;
/*      */ import javax.servlet.annotation.HandlesTypes;
/*      */ import org.apache.catalina.Authenticator;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.LifecycleEvent;
/*      */ import org.apache.catalina.LifecycleListener;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Loader;
/*      */ import org.apache.catalina.Pipeline;
/*      */ import org.apache.catalina.Server;
/*      */ import org.apache.catalina.Service;
/*      */ import org.apache.catalina.Valve;
/*      */ import org.apache.catalina.WebResource;
/*      */ import org.apache.catalina.WebResourceRoot;
/*      */ import org.apache.catalina.WebResourceRoot.ResourceSetType;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.core.StandardContext;
/*      */ import org.apache.catalina.core.StandardHost;
/*      */ import org.apache.catalina.deploy.NamingResourcesImpl;
/*      */ import org.apache.catalina.util.ContextName;
/*      */ import org.apache.catalina.util.Introspection;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.Jar;
/*      */ import org.apache.tomcat.JarScanType;
/*      */ import org.apache.tomcat.JarScanner;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.bcel.classfile.AnnotationElementValue;
/*      */ import org.apache.tomcat.util.bcel.classfile.AnnotationEntry;
/*      */ import org.apache.tomcat.util.bcel.classfile.ArrayElementValue;
/*      */ import org.apache.tomcat.util.bcel.classfile.ClassFormatException;
/*      */ import org.apache.tomcat.util.bcel.classfile.ClassParser;
/*      */ import org.apache.tomcat.util.bcel.classfile.ElementValue;
/*      */ import org.apache.tomcat.util.bcel.classfile.ElementValuePair;
/*      */ import org.apache.tomcat.util.bcel.classfile.JavaClass;
/*      */ import org.apache.tomcat.util.buf.UriUtil;
/*      */ import org.apache.tomcat.util.descriptor.XmlErrorHandler;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextEjb;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextEnvironment;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextLocalEjb;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextResource;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextResourceEnvRef;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextService;
/*      */ import org.apache.tomcat.util.descriptor.web.ErrorPage;
/*      */ import org.apache.tomcat.util.descriptor.web.FilterDef;
/*      */ import org.apache.tomcat.util.descriptor.web.FilterMap;
/*      */ import org.apache.tomcat.util.descriptor.web.FragmentJarScannerCallback;
/*      */ import org.apache.tomcat.util.descriptor.web.JspPropertyGroup;
/*      */ import org.apache.tomcat.util.descriptor.web.LoginConfig;
/*      */ import org.apache.tomcat.util.descriptor.web.MessageDestinationRef;
/*      */ import org.apache.tomcat.util.descriptor.web.MultipartDef;
/*      */ import org.apache.tomcat.util.descriptor.web.SecurityConstraint;
/*      */ import org.apache.tomcat.util.descriptor.web.SecurityRoleRef;
/*      */ import org.apache.tomcat.util.descriptor.web.ServletDef;
/*      */ import org.apache.tomcat.util.descriptor.web.SessionConfig;
/*      */ import org.apache.tomcat.util.descriptor.web.WebXml;
/*      */ import org.apache.tomcat.util.descriptor.web.WebXmlParser;
/*      */ import org.apache.tomcat.util.digester.Digester;
/*      */ import org.apache.tomcat.util.digester.RuleSet;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.util.scan.JarFactory;
/*      */ import org.xml.sax.InputSource;
/*      */ import org.xml.sax.SAXParseException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ContextConfig
/*      */   implements LifecycleListener
/*      */ {
/*  119 */   private static final Log log = LogFactory.getLog(ContextConfig.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  125 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.startup");
/*      */   
/*      */ 
/*      */ 
/*  129 */   protected static final LoginConfig DUMMY_LOGIN_CONFIG = new LoginConfig("NONE", null, null, null);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final Properties authenticators;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static
/*      */   {
/*  142 */     Properties props = new Properties();
/*  143 */     try { InputStream is = ContextConfig.class.getClassLoader().getResourceAsStream("org/apache/catalina/startup/Authenticators.properties");Throwable localThrowable2 = null;
/*      */       try {
/*  145 */         if (is != null) {
/*  146 */           props.load(is);
/*      */         }
/*      */       }
/*      */       catch (Throwable localThrowable1)
/*      */       {
/*  143 */         localThrowable2 = localThrowable1;throw localThrowable1;
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*  148 */         if (is != null) if (localThrowable2 != null) try { is.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else is.close();
/*  149 */       } } catch (IOException ioe) { props = null;
/*      */     }
/*  151 */     authenticators = props;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  157 */   protected static long deploymentCount = 0L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  163 */   protected static final Map<Host, DefaultWebXmlCacheEntry> hostWebXmlCache = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  171 */   private static final Set<ServletContainerInitializer> EMPTY_SCI_SET = Collections.emptySet();
/*      */   protected Map<String, Authenticator> customAuthenticators;
/*      */   protected Context context;
/*      */   protected String defaultWebXml;
/*      */   protected boolean ok;
/*      */   protected String originalDocBase;
/*      */   private File antiLockingDocBase;
/*      */   protected final Map<ServletContainerInitializer, Set<Class<?>>> initializerClassMap;
/*      */   protected final Map<Class<?>, Set<ServletContainerInitializer>> typeInitializerMap;
/*      */   protected boolean handlesTypesAnnotations;
/*      */   protected boolean handlesTypesNonAnnotations;
/*      */   
/*      */   public ContextConfig() {
/*  184 */     this.context = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  190 */     this.defaultWebXml = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  196 */     this.ok = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  202 */     this.originalDocBase = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  209 */     this.antiLockingDocBase = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  215 */     this.initializerClassMap = new LinkedHashMap();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  222 */     this.typeInitializerMap = new HashMap();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  229 */     this.handlesTypesAnnotations = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  235 */     this.handlesTypesNonAnnotations = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDefaultWebXml()
/*      */   {
/*  247 */     if (this.defaultWebXml == null) {
/*  248 */       this.defaultWebXml = "conf/web.xml";
/*      */     }
/*  250 */     return this.defaultWebXml;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDefaultWebXml(String path)
/*      */   {
/*  261 */     this.defaultWebXml = path;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCustomAuthenticators(Map<String, Authenticator> customAuthenticators)
/*      */   {
/*  273 */     this.customAuthenticators = customAuthenticators;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void lifecycleEvent(LifecycleEvent event)
/*      */   {
/*      */     try
/*      */     {
/*  290 */       this.context = ((Context)event.getLifecycle());
/*      */     } catch (ClassCastException e) {
/*  292 */       log.error(sm.getString("contextConfig.cce", new Object[] { event.getLifecycle() }), e);
/*  293 */       return;
/*      */     }
/*      */     
/*      */ 
/*  297 */     if (event.getType().equals("configure_start")) {
/*  298 */       configureStart();
/*  299 */     } else if (event.getType().equals("before_start")) {
/*  300 */       beforeStart();
/*  301 */     } else if (event.getType().equals("after_start"))
/*      */     {
/*  303 */       if (this.originalDocBase != null) {
/*  304 */         this.context.setDocBase(this.originalDocBase);
/*      */       }
/*  306 */     } else if (event.getType().equals("configure_stop")) {
/*  307 */       configureStop();
/*  308 */     } else if (event.getType().equals("after_init")) {
/*  309 */       init();
/*  310 */     } else if (event.getType().equals("after_destroy")) {
/*  311 */       destroy();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void applicationAnnotationsConfig()
/*      */   {
/*  325 */     long t1 = System.currentTimeMillis();
/*      */     
/*  327 */     WebAnnotationSet.loadApplicationAnnotations(this.context);
/*      */     
/*  329 */     long t2 = System.currentTimeMillis();
/*  330 */     if ((this.context instanceof StandardContext)) {
/*  331 */       ((StandardContext)this.context).setStartupTime(t2 - t1 + ((StandardContext)this.context).getStartupTime());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void authenticatorConfig()
/*      */   {
/*  343 */     LoginConfig loginConfig = this.context.getLoginConfig();
/*      */     
/*  345 */     SecurityConstraint[] constraints = this.context.findConstraints();
/*  346 */     if ((this.context.getIgnoreAnnotations()) && ((constraints == null) || (constraints.length == 0)) && (!this.context.getPreemptiveAuthentication()))
/*      */     {
/*      */ 
/*  349 */       return;
/*      */     }
/*  351 */     if (loginConfig == null)
/*      */     {
/*      */ 
/*      */ 
/*  355 */       loginConfig = DUMMY_LOGIN_CONFIG;
/*  356 */       this.context.setLoginConfig(loginConfig);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  361 */     if (this.context.getAuthenticator() != null) {
/*  362 */       return;
/*      */     }
/*      */     
/*      */ 
/*  366 */     if (this.context.getRealm() == null) {
/*  367 */       log.error(sm.getString("contextConfig.missingRealm"));
/*  368 */       this.ok = false;
/*  369 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  377 */     Valve authenticator = null;
/*  378 */     if (this.customAuthenticators != null) {
/*  379 */       authenticator = (Valve)this.customAuthenticators.get(loginConfig.getAuthMethod());
/*      */     }
/*      */     
/*  382 */     if (authenticator == null) {
/*  383 */       if (authenticators == null) {
/*  384 */         log.error(sm.getString("contextConfig.authenticatorResources"));
/*  385 */         this.ok = false;
/*  386 */         return;
/*      */       }
/*      */       
/*      */ 
/*  390 */       String authenticatorName = authenticators.getProperty(loginConfig.getAuthMethod());
/*  391 */       if (authenticatorName == null) {
/*  392 */         log.error(sm.getString("contextConfig.authenticatorMissing", new Object[] { loginConfig.getAuthMethod() }));
/*      */         
/*  394 */         this.ok = false;
/*  395 */         return;
/*      */       }
/*      */       
/*      */       try
/*      */       {
/*  400 */         Class<?> authenticatorClass = Class.forName(authenticatorName);
/*  401 */         authenticator = (Valve)authenticatorClass.newInstance();
/*      */       } catch (Throwable t) {
/*  403 */         ExceptionUtils.handleThrowable(t);
/*  404 */         log.error(sm.getString("contextConfig.authenticatorInstantiate", new Object[] { authenticatorName }), t);
/*      */         
/*      */ 
/*      */ 
/*  408 */         this.ok = false;
/*      */       }
/*      */     }
/*      */     
/*  412 */     if (authenticator != null) {
/*  413 */       Pipeline pipeline = this.context.getPipeline();
/*  414 */       if (pipeline != null) {
/*  415 */         pipeline.addValve(authenticator);
/*  416 */         if (log.isDebugEnabled()) {
/*  417 */           log.debug(sm.getString("contextConfig.authenticatorConfigured", new Object[] { loginConfig.getAuthMethod() }));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Digester createContextDigester()
/*      */   {
/*  432 */     Digester digester = new Digester();
/*  433 */     digester.setValidating(false);
/*  434 */     digester.setRulesValidation(true);
/*  435 */     HashMap<Class<?>, List<String>> fakeAttributes = new HashMap();
/*  436 */     ArrayList<String> attrs = new ArrayList();
/*  437 */     attrs.add("className");
/*  438 */     fakeAttributes.put(Object.class, attrs);
/*  439 */     digester.setFakeAttributes(fakeAttributes);
/*  440 */     RuleSet contextRuleSet = new ContextRuleSet("", false);
/*  441 */     digester.addRuleSet(contextRuleSet);
/*  442 */     RuleSet namingRuleSet = new NamingRuleSet("Context/");
/*  443 */     digester.addRuleSet(namingRuleSet);
/*  444 */     return digester;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void contextConfig(Digester digester)
/*      */   {
/*  454 */     String defaultContextXml = null;
/*      */     
/*      */ 
/*  457 */     if ((this.context instanceof StandardContext)) {
/*  458 */       defaultContextXml = ((StandardContext)this.context).getDefaultContextXml();
/*      */     }
/*      */     
/*  461 */     if (defaultContextXml == null) {
/*  462 */       defaultContextXml = "conf/context.xml";
/*      */     }
/*      */     
/*  465 */     if (!this.context.getOverride()) {
/*  466 */       File defaultContextFile = new File(defaultContextXml);
/*  467 */       if (!defaultContextFile.isAbsolute()) {
/*  468 */         defaultContextFile = new File(this.context.getCatalinaBase(), defaultContextXml);
/*      */       }
/*      */       
/*  471 */       if (defaultContextFile.exists()) {
/*      */         try {
/*  473 */           URL defaultContextUrl = defaultContextFile.toURI().toURL();
/*  474 */           processContextConfig(digester, defaultContextUrl);
/*      */         } catch (MalformedURLException e) {
/*  476 */           log.error(sm.getString("contextConfig.badUrl", new Object[] { defaultContextFile }), e);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  481 */       File hostContextFile = new File(getHostConfigBase(), "context.xml.default");
/*  482 */       if (hostContextFile.exists()) {
/*      */         try {
/*  484 */           URL hostContextUrl = hostContextFile.toURI().toURL();
/*  485 */           processContextConfig(digester, hostContextUrl);
/*      */         } catch (MalformedURLException e) {
/*  487 */           log.error(sm.getString("contextConfig.badUrl", new Object[] { hostContextFile }), e);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  492 */     if (this.context.getConfigFile() != null) {
/*  493 */       processContextConfig(digester, this.context.getConfigFile());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void processContextConfig(Digester digester, URL contextXml)
/*      */   {
/*  506 */     if (log.isDebugEnabled()) {
/*  507 */       log.debug("Processing context [" + this.context.getName() + "] configuration file [" + contextXml + "]");
/*      */     }
/*      */     
/*      */ 
/*  511 */     InputSource source = null;
/*  512 */     InputStream stream = null;
/*      */     try
/*      */     {
/*  515 */       source = new InputSource(contextXml.toString());
/*  516 */       URLConnection xmlConn = contextXml.openConnection();
/*  517 */       xmlConn.setUseCaches(false);
/*  518 */       stream = xmlConn.getInputStream();
/*      */     } catch (Exception e) {
/*  520 */       log.error(sm.getString("contextConfig.contextMissing", new Object[] { contextXml }), e);
/*      */     }
/*      */     
/*      */ 
/*  524 */     if (source == null) {
/*  525 */       return;
/*      */     }
/*      */     try
/*      */     {
/*  529 */       source.setByteStream(stream);
/*  530 */       digester.setClassLoader(getClass().getClassLoader());
/*  531 */       digester.setUseContextClassLoader(false);
/*  532 */       digester.push(this.context.getParent());
/*  533 */       digester.push(this.context);
/*  534 */       XmlErrorHandler errorHandler = new XmlErrorHandler();
/*  535 */       digester.setErrorHandler(errorHandler);
/*  536 */       digester.parse(source);
/*  537 */       if ((errorHandler.getWarnings().size() > 0) || (errorHandler.getErrors().size() > 0))
/*      */       {
/*  539 */         errorHandler.logFindings(log, contextXml.toString());
/*  540 */         this.ok = false;
/*      */       }
/*  542 */       if (log.isDebugEnabled()) {
/*  543 */         log.debug("Successfully processed context [" + this.context.getName() + "] configuration file [" + contextXml + "]");
/*      */       }
/*      */       return;
/*      */     } catch (SAXParseException e) {
/*  547 */       log.error(sm.getString("contextConfig.contextParse", new Object[] { this.context.getName() }), e);
/*      */       
/*  549 */       log.error(sm.getString("contextConfig.defaultPosition", new Object[] { "" + e.getLineNumber(), "" + e.getColumnNumber() }));
/*      */       
/*      */ 
/*  552 */       this.ok = false;
/*      */     } catch (Exception e) {
/*  554 */       log.error(sm.getString("contextConfig.contextParse", new Object[] { this.context.getName() }), e);
/*      */       
/*  556 */       this.ok = false;
/*      */     } finally {
/*      */       try {
/*  559 */         if (stream != null) {
/*  560 */           stream.close();
/*      */         }
/*      */       } catch (IOException e) {
/*  563 */         log.error(sm.getString("contextConfig.contextClose"), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void fixDocBase()
/*      */     throws IOException
/*      */   {
/*  575 */     Host host = (Host)this.context.getParent();
/*  576 */     File appBase = host.getAppBaseFile();
/*      */     
/*  578 */     String docBase = this.context.getDocBase();
/*  579 */     if (docBase == null)
/*      */     {
/*  581 */       String path = this.context.getPath();
/*  582 */       if (path == null) {
/*  583 */         return;
/*      */       }
/*  585 */       ContextName cn = new ContextName(path, this.context.getWebappVersion());
/*  586 */       docBase = cn.getBaseName();
/*      */     }
/*      */     
/*  589 */     File file = new File(docBase);
/*  590 */     if (!file.isAbsolute()) {
/*  591 */       docBase = new File(appBase, docBase).getPath();
/*      */     } else {
/*  593 */       docBase = file.getCanonicalPath();
/*      */     }
/*  595 */     file = new File(docBase);
/*  596 */     String origDocBase = docBase;
/*      */     
/*  598 */     ContextName cn = new ContextName(this.context.getPath(), this.context.getWebappVersion());
/*  599 */     String pathName = cn.getBaseName();
/*      */     
/*  601 */     boolean unpackWARs = true;
/*  602 */     if ((host instanceof StandardHost)) {
/*  603 */       unpackWARs = ((StandardHost)host).isUnpackWARs();
/*  604 */       if ((unpackWARs) && ((this.context instanceof StandardContext))) {
/*  605 */         unpackWARs = ((StandardContext)this.context).getUnpackWAR();
/*      */       }
/*      */     }
/*      */     
/*  609 */     boolean docBaseInAppBase = docBase.startsWith(appBase.getPath() + File.separatorChar);
/*      */     
/*  611 */     if ((docBase.toLowerCase(Locale.ENGLISH).endsWith(".war")) && (!file.isDirectory())) {
/*  612 */       URL war = UriUtil.buildJarUrl(new File(docBase));
/*  613 */       if (unpackWARs) {
/*  614 */         docBase = ExpandWar.expand(host, war, pathName);
/*  615 */         file = new File(docBase);
/*  616 */         docBase = file.getCanonicalPath();
/*  617 */         if ((this.context instanceof StandardContext)) {
/*  618 */           ((StandardContext)this.context).setOriginalDocBase(origDocBase);
/*      */         }
/*      */       } else {
/*  621 */         ExpandWar.validate(host, war, pathName);
/*      */       }
/*      */     } else {
/*  624 */       File docDir = new File(docBase);
/*  625 */       File warFile = new File(docBase + ".war");
/*  626 */       URL war = null;
/*  627 */       if ((warFile.exists()) && (docBaseInAppBase)) {
/*  628 */         war = UriUtil.buildJarUrl(warFile);
/*      */       }
/*  630 */       if (docDir.exists()) {
/*  631 */         if ((war != null) && (unpackWARs))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  636 */           ExpandWar.expand(host, war, pathName);
/*      */         }
/*      */       } else {
/*  639 */         if (war != null) {
/*  640 */           if (unpackWARs) {
/*  641 */             docBase = ExpandWar.expand(host, war, pathName);
/*  642 */             file = new File(docBase);
/*  643 */             docBase = file.getCanonicalPath();
/*      */           } else {
/*  645 */             docBase = warFile.getCanonicalPath();
/*  646 */             ExpandWar.validate(host, war, pathName);
/*      */           }
/*      */         }
/*  649 */         if ((this.context instanceof StandardContext)) {
/*  650 */           ((StandardContext)this.context).setOriginalDocBase(origDocBase);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  655 */     if (docBaseInAppBase) {
/*  656 */       docBase = docBase.substring(appBase.getPath().length());
/*  657 */       docBase = docBase.replace(File.separatorChar, '/');
/*  658 */       if (docBase.startsWith("/")) {
/*  659 */         docBase = docBase.substring(1);
/*      */       }
/*      */     } else {
/*  662 */       docBase = docBase.replace(File.separatorChar, '/');
/*      */     }
/*      */     
/*  665 */     this.context.setDocBase(docBase);
/*      */   }
/*      */   
/*      */ 
/*      */   protected void antiLocking()
/*      */   {
/*  671 */     if (((this.context instanceof StandardContext)) && (((StandardContext)this.context).getAntiResourceLocking()))
/*      */     {
/*      */ 
/*  674 */       Host host = (Host)this.context.getParent();
/*  675 */       String docBase = this.context.getDocBase();
/*  676 */       if (docBase == null) {
/*  677 */         return;
/*      */       }
/*  679 */       this.originalDocBase = docBase;
/*      */       
/*  681 */       File docBaseFile = new File(docBase);
/*  682 */       if (!docBaseFile.isAbsolute()) {
/*  683 */         docBaseFile = new File(host.getAppBaseFile(), docBase);
/*      */       }
/*      */       
/*  686 */       String path = this.context.getPath();
/*  687 */       if (path == null) {
/*  688 */         return;
/*      */       }
/*  690 */       ContextName cn = new ContextName(path, this.context.getWebappVersion());
/*  691 */       docBase = cn.getBaseName();
/*      */       
/*  693 */       if (this.originalDocBase.toLowerCase(Locale.ENGLISH).endsWith(".war")) {
/*  694 */         this.antiLockingDocBase = new File(System.getProperty("java.io.tmpdir"), deploymentCount++ + "-" + docBase + ".war");
/*      */       }
/*      */       else
/*      */       {
/*  698 */         this.antiLockingDocBase = new File(System.getProperty("java.io.tmpdir"), deploymentCount++ + "-" + docBase);
/*      */       }
/*      */       
/*      */ 
/*  702 */       this.antiLockingDocBase = this.antiLockingDocBase.getAbsoluteFile();
/*      */       
/*  704 */       if (log.isDebugEnabled()) {
/*  705 */         log.debug("Anti locking context[" + this.context.getName() + "] setting docBase to " + this.antiLockingDocBase.getPath());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  711 */       ExpandWar.delete(this.antiLockingDocBase);
/*  712 */       if (ExpandWar.copy(docBaseFile, this.antiLockingDocBase)) {
/*  713 */         this.context.setDocBase(this.antiLockingDocBase.getPath());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void init()
/*      */   {
/*  725 */     Digester contextDigester = createContextDigester();
/*  726 */     contextDigester.getParser();
/*      */     
/*  728 */     if (log.isDebugEnabled()) {
/*  729 */       log.debug(sm.getString("contextConfig.init"));
/*      */     }
/*  731 */     this.context.setConfigured(false);
/*  732 */     this.ok = true;
/*      */     
/*  734 */     contextConfig(contextDigester);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void beforeStart()
/*      */   {
/*      */     try
/*      */     {
/*  744 */       fixDocBase();
/*      */     } catch (IOException e) {
/*  746 */       log.error(sm.getString("contextConfig.fixDocBase", new Object[] { this.context.getName() }), e);
/*      */     }
/*      */     
/*      */ 
/*  750 */     antiLocking();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void configureStart()
/*      */   {
/*  760 */     if (log.isDebugEnabled()) {
/*  761 */       log.debug(sm.getString("contextConfig.start"));
/*      */     }
/*      */     
/*  764 */     if (log.isDebugEnabled()) {
/*  765 */       log.debug(sm.getString("contextConfig.xmlSettings", new Object[] { this.context.getName(), Boolean.valueOf(this.context.getXmlValidation()), Boolean.valueOf(this.context.getXmlNamespaceAware()) }));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  771 */     webConfig();
/*      */     
/*  773 */     if (!this.context.getIgnoreAnnotations()) {
/*  774 */       applicationAnnotationsConfig();
/*      */     }
/*  776 */     if (this.ok) {
/*  777 */       validateSecurityRoles();
/*      */     }
/*      */     
/*      */ 
/*  781 */     if (this.ok) {
/*  782 */       authenticatorConfig();
/*      */     }
/*      */     
/*      */ 
/*  786 */     if (log.isDebugEnabled()) {
/*  787 */       log.debug("Pipeline Configuration:");
/*  788 */       Pipeline pipeline = this.context.getPipeline();
/*  789 */       Valve[] valves = null;
/*  790 */       if (pipeline != null) {
/*  791 */         valves = pipeline.getValves();
/*      */       }
/*  793 */       if (valves != null) {
/*  794 */         for (int i = 0; i < valves.length; i++) {
/*  795 */           log.debug("  " + valves[i].getClass().getName());
/*      */         }
/*      */       }
/*  798 */       log.debug("======================");
/*      */     }
/*      */     
/*      */ 
/*  802 */     if (this.ok) {
/*  803 */       this.context.setConfigured(true);
/*      */     } else {
/*  805 */       log.error(sm.getString("contextConfig.unavailable"));
/*  806 */       this.context.setConfigured(false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void configureStop()
/*      */   {
/*  817 */     if (log.isDebugEnabled()) {
/*  818 */       log.debug(sm.getString("contextConfig.stop"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  824 */     Container[] children = this.context.findChildren();
/*  825 */     for (int i = 0; i < children.length; i++) {
/*  826 */       this.context.removeChild(children[i]);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  840 */     SecurityConstraint[] securityConstraints = this.context.findConstraints();
/*  841 */     for (i = 0; i < securityConstraints.length; i++) {
/*  842 */       this.context.removeConstraint(securityConstraints[i]);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  862 */     ErrorPage[] errorPages = this.context.findErrorPages();
/*  863 */     for (i = 0; i < errorPages.length; i++) {
/*  864 */       this.context.removeErrorPage(errorPages[i]);
/*      */     }
/*      */     
/*      */ 
/*  868 */     FilterDef[] filterDefs = this.context.findFilterDefs();
/*  869 */     for (i = 0; i < filterDefs.length; i++) {
/*  870 */       this.context.removeFilterDef(filterDefs[i]);
/*      */     }
/*      */     
/*      */ 
/*  874 */     FilterMap[] filterMaps = this.context.findFilterMaps();
/*  875 */     for (i = 0; i < filterMaps.length; i++) {
/*  876 */       this.context.removeFilterMap(filterMaps[i]);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  888 */     String[] mimeMappings = this.context.findMimeMappings();
/*  889 */     for (i = 0; i < mimeMappings.length; i++) {
/*  890 */       this.context.removeMimeMapping(mimeMappings[i]);
/*      */     }
/*      */     
/*      */ 
/*  894 */     String[] parameters = this.context.findParameters();
/*  895 */     for (i = 0; i < parameters.length; i++) {
/*  896 */       this.context.removeParameter(parameters[i]);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  925 */     String[] securityRoles = this.context.findSecurityRoles();
/*  926 */     for (i = 0; i < securityRoles.length; i++) {
/*  927 */       this.context.removeSecurityRole(securityRoles[i]);
/*      */     }
/*      */     
/*      */ 
/*  931 */     String[] servletMappings = this.context.findServletMappings();
/*  932 */     for (i = 0; i < servletMappings.length; i++) {
/*  933 */       this.context.removeServletMapping(servletMappings[i]);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  939 */     String[] welcomeFiles = this.context.findWelcomeFiles();
/*  940 */     for (i = 0; i < welcomeFiles.length; i++) {
/*  941 */       this.context.removeWelcomeFile(welcomeFiles[i]);
/*      */     }
/*      */     
/*      */ 
/*  945 */     String[] wrapperLifecycles = this.context.findWrapperLifecycles();
/*  946 */     for (i = 0; i < wrapperLifecycles.length; i++) {
/*  947 */       this.context.removeWrapperLifecycle(wrapperLifecycles[i]);
/*      */     }
/*      */     
/*      */ 
/*  951 */     String[] wrapperListeners = this.context.findWrapperListeners();
/*  952 */     for (i = 0; i < wrapperListeners.length; i++) {
/*  953 */       this.context.removeWrapperListener(wrapperListeners[i]);
/*      */     }
/*      */     
/*      */ 
/*  957 */     if (this.antiLockingDocBase != null)
/*      */     {
/*  959 */       ExpandWar.delete(this.antiLockingDocBase, false);
/*      */     }
/*      */     
/*      */ 
/*  963 */     this.initializerClassMap.clear();
/*  964 */     this.typeInitializerMap.clear();
/*      */     
/*  966 */     this.ok = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void destroy()
/*      */   {
/*  976 */     if (log.isDebugEnabled()) {
/*  977 */       log.debug(sm.getString("contextConfig.destroy"));
/*      */     }
/*      */     
/*      */ 
/*  981 */     Server s = getServer();
/*  982 */     if ((s != null) && (!s.getState().isAvailable())) {
/*  983 */       return;
/*      */     }
/*      */     
/*      */ 
/*  987 */     if ((this.context instanceof StandardContext)) {
/*  988 */       String workDir = ((StandardContext)this.context).getWorkPath();
/*  989 */       if (workDir != null) {
/*  990 */         ExpandWar.delete(new File(workDir));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private Server getServer()
/*      */   {
/*  997 */     Container c = this.context;
/*  998 */     while ((c != null) && (!(c instanceof Engine))) {
/*  999 */       c = c.getParent();
/*      */     }
/*      */     
/* 1002 */     if (c == null) {
/* 1003 */       return null;
/*      */     }
/*      */     
/* 1006 */     Service s = ((Engine)c).getService();
/*      */     
/* 1008 */     if (s == null) {
/* 1009 */       return null;
/*      */     }
/*      */     
/* 1012 */     return s.getServer();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void validateSecurityRoles()
/*      */   {
/* 1025 */     SecurityConstraint[] constraints = this.context.findConstraints();
/* 1026 */     for (int i = 0; i < constraints.length; i++) {
/* 1027 */       String[] roles = constraints[i].findAuthRoles();
/* 1028 */       for (int j = 0; j < roles.length; j++) {
/* 1029 */         if ((!"*".equals(roles[j])) && (!this.context.findSecurityRole(roles[j])))
/*      */         {
/* 1031 */           log.warn(sm.getString("contextConfig.role.auth", new Object[] { roles[j] }));
/* 1032 */           this.context.addSecurityRole(roles[j]);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1038 */     Container[] wrappers = this.context.findChildren();
/* 1039 */     for (int i = 0; i < wrappers.length; i++) {
/* 1040 */       Wrapper wrapper = (Wrapper)wrappers[i];
/* 1041 */       String runAs = wrapper.getRunAs();
/* 1042 */       if ((runAs != null) && (!this.context.findSecurityRole(runAs))) {
/* 1043 */         log.warn(sm.getString("contextConfig.role.runas", new Object[] { runAs }));
/* 1044 */         this.context.addSecurityRole(runAs);
/*      */       }
/* 1046 */       String[] names = wrapper.findSecurityReferences();
/* 1047 */       for (int j = 0; j < names.length; j++) {
/* 1048 */         String link = wrapper.findSecurityReference(names[j]);
/* 1049 */         if ((link != null) && (!this.context.findSecurityRole(link))) {
/* 1050 */           log.warn(sm.getString("contextConfig.role.link", new Object[] { link }));
/* 1051 */           this.context.addSecurityRole(link);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected File getHostConfigBase()
/*      */   {
/* 1060 */     File file = null;
/* 1061 */     if ((this.context.getParent() instanceof Host)) {
/* 1062 */       file = ((Host)this.context.getParent()).getConfigBaseFile();
/*      */     }
/* 1064 */     return file;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void webConfig()
/*      */   {
/* 1100 */     WebXmlParser webXmlParser = new WebXmlParser(this.context.getXmlNamespaceAware(), this.context.getXmlValidation(), this.context.getXmlBlockExternal());
/*      */     
/*      */ 
/* 1103 */     Set<WebXml> defaults = new HashSet();
/* 1104 */     defaults.add(getDefaultWebXmlFragment(webXmlParser));
/*      */     
/* 1106 */     WebXml webXml = createWebXml();
/*      */     
/*      */ 
/* 1109 */     InputSource contextWebXml = getContextWebXmlSource();
/* 1110 */     if (!webXmlParser.parseWebXml(contextWebXml, webXml, false)) {
/* 1111 */       this.ok = false;
/*      */     }
/*      */     
/* 1114 */     ServletContext sContext = this.context.getServletContext();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1122 */     Map<String, WebXml> fragments = processJarsForWebFragments(webXml, webXmlParser);
/*      */     
/*      */ 
/* 1125 */     Set<WebXml> orderedFragments = null;
/* 1126 */     orderedFragments = WebXml.orderWebFragments(webXml, fragments, sContext);
/*      */     
/*      */ 
/*      */ 
/* 1130 */     if (this.ok) {
/* 1131 */       processServletContainerInitializers();
/*      */     }
/*      */     
/* 1134 */     if ((!webXml.isMetadataComplete()) || (this.typeInitializerMap.size() > 0))
/*      */     {
/*      */ 
/* 1137 */       Map<String, JavaClassCacheEntry> javaClassCache = new HashMap();
/*      */       
/* 1139 */       if (this.ok) {
/* 1140 */         WebResource[] webResources = this.context.getResources().listResources("/WEB-INF/classes");
/*      */         
/*      */ 
/* 1143 */         for (WebResource webResource : webResources) {
/* 1144 */           processAnnotationsWebResource(webResource, webXml, webXml.isMetadataComplete(), javaClassCache);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1153 */       if (this.ok) {
/* 1154 */         processAnnotations(orderedFragments, webXml.isMetadataComplete(), javaClassCache);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1159 */       javaClassCache.clear();
/*      */     }
/*      */     
/* 1162 */     if (!webXml.isMetadataComplete())
/*      */     {
/*      */ 
/* 1165 */       if (this.ok) {
/* 1166 */         this.ok = webXml.merge(orderedFragments);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1172 */       webXml.merge(defaults);
/*      */       
/*      */ 
/* 1175 */       if (this.ok) {
/* 1176 */         convertJsps(webXml);
/*      */       }
/*      */       
/*      */ 
/* 1180 */       if (this.ok) {
/* 1181 */         configureContext(webXml);
/*      */       }
/*      */     } else {
/* 1184 */       webXml.merge(defaults);
/* 1185 */       convertJsps(webXml);
/* 1186 */       configureContext(webXml);
/*      */     }
/*      */     
/* 1189 */     if (this.context.getLogEffectiveWebXml()) {
/* 1190 */       log.info("web.xml:\n" + webXml.toXml());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1195 */     if (this.ok)
/*      */     {
/*      */ 
/* 1198 */       Set<WebXml> resourceJars = new LinkedHashSet();
/* 1199 */       for (WebXml fragment : orderedFragments) {
/* 1200 */         resourceJars.add(fragment);
/*      */       }
/* 1202 */       for (WebXml fragment : fragments.values()) {
/* 1203 */         if (!resourceJars.contains(fragment)) {
/* 1204 */           resourceJars.add(fragment);
/*      */         }
/*      */       }
/* 1207 */       processResourceJARs(resourceJars);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1214 */     if (this.ok)
/*      */     {
/*      */ 
/* 1217 */       for (Map.Entry<ServletContainerInitializer, Set<Class<?>>> entry : this.initializerClassMap.entrySet()) {
/* 1218 */         if (((Set)entry.getValue()).isEmpty()) {
/* 1219 */           this.context.addServletContainerInitializer((ServletContainerInitializer)entry.getKey(), null);
/*      */         }
/*      */         else {
/* 1222 */           this.context.addServletContainerInitializer((ServletContainerInitializer)entry.getKey(), (Set)entry.getValue());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void configureContext(WebXml webxml)
/*      */   {
/* 1234 */     this.context.setPublicId(webxml.getPublicId());
/*      */     
/*      */ 
/* 1237 */     this.context.setEffectiveMajorVersion(webxml.getMajorVersion());
/* 1238 */     this.context.setEffectiveMinorVersion(webxml.getMinorVersion());
/*      */     
/* 1240 */     for (Map.Entry<String, String> entry : webxml.getContextParams().entrySet()) {
/* 1241 */       this.context.addParameter((String)entry.getKey(), (String)entry.getValue());
/*      */     }
/* 1243 */     this.context.setDenyUncoveredHttpMethods(webxml.getDenyUncoveredHttpMethods());
/*      */     
/* 1245 */     this.context.setDisplayName(webxml.getDisplayName());
/* 1246 */     this.context.setDistributable(webxml.isDistributable());
/* 1247 */     for (ContextLocalEjb ejbLocalRef : webxml.getEjbLocalRefs().values()) {
/* 1248 */       this.context.getNamingResources().addLocalEjb(ejbLocalRef);
/*      */     }
/* 1250 */     for (ContextEjb ejbRef : webxml.getEjbRefs().values()) {
/* 1251 */       this.context.getNamingResources().addEjb(ejbRef);
/*      */     }
/* 1253 */     for (ContextEnvironment environment : webxml.getEnvEntries().values()) {
/* 1254 */       this.context.getNamingResources().addEnvironment(environment);
/*      */     }
/* 1256 */     for (ErrorPage errorPage : webxml.getErrorPages().values()) {
/* 1257 */       this.context.addErrorPage(errorPage);
/*      */     }
/* 1259 */     for (FilterDef filter : webxml.getFilters().values()) {
/* 1260 */       if (filter.getAsyncSupported() == null) {
/* 1261 */         filter.setAsyncSupported("false");
/*      */       }
/* 1263 */       this.context.addFilterDef(filter);
/*      */     }
/* 1265 */     for (FilterMap filterMap : webxml.getFilterMappings()) {
/* 1266 */       this.context.addFilterMap(filterMap);
/*      */     }
/* 1268 */     this.context.setJspConfigDescriptor(webxml.getJspConfigDescriptor());
/* 1269 */     for (String listener : webxml.getListeners()) {
/* 1270 */       this.context.addApplicationListener(listener);
/*      */     }
/*      */     
/* 1273 */     for (Map.Entry<String, String> entry : webxml.getLocaleEncodingMappings().entrySet()) {
/* 1274 */       this.context.addLocaleEncodingMappingParameter((String)entry.getKey(), (String)entry.getValue());
/*      */     }
/*      */     
/*      */ 
/* 1278 */     if (webxml.getLoginConfig() != null) {
/* 1279 */       this.context.setLoginConfig(webxml.getLoginConfig());
/*      */     }
/*      */     
/* 1282 */     for (MessageDestinationRef mdr : webxml.getMessageDestinationRefs().values()) {
/* 1283 */       this.context.getNamingResources().addMessageDestinationRef(mdr);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1288 */     this.context.setIgnoreAnnotations(webxml.isMetadataComplete());
/*      */     
/* 1290 */     for (Map.Entry<String, String> entry : webxml.getMimeMappings().entrySet()) {
/* 1291 */       this.context.addMimeMapping((String)entry.getKey(), (String)entry.getValue());
/*      */     }
/*      */     
/*      */ 
/* 1295 */     for (ContextResourceEnvRef resource : webxml.getResourceEnvRefs().values()) {
/* 1296 */       this.context.getNamingResources().addResourceEnvRef(resource);
/*      */     }
/* 1298 */     for (ContextResource resource : webxml.getResourceRefs().values()) {
/* 1299 */       this.context.getNamingResources().addResource(resource);
/*      */     }
/* 1301 */     boolean allAuthenticatedUsersIsAppRole = webxml.getSecurityRoles().contains("**");
/*      */     
/*      */ 
/* 1304 */     for (SecurityConstraint constraint : webxml.getSecurityConstraints()) {
/* 1305 */       if (allAuthenticatedUsersIsAppRole) {
/* 1306 */         constraint.treatAllAuthenticatedUsersAsApplicationRole();
/*      */       }
/* 1308 */       this.context.addConstraint(constraint);
/*      */     }
/* 1310 */     for (String role : webxml.getSecurityRoles()) {
/* 1311 */       this.context.addSecurityRole(role);
/*      */     }
/* 1313 */     for (ContextService service : webxml.getServiceRefs().values()) {
/* 1314 */       this.context.getNamingResources().addService(service);
/*      */     }
/* 1316 */     for (ServletDef servlet : webxml.getServlets().values()) {
/* 1317 */       Wrapper wrapper = this.context.createWrapper();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1324 */       if (servlet.getLoadOnStartup() != null) {
/* 1325 */         wrapper.setLoadOnStartup(servlet.getLoadOnStartup().intValue());
/*      */       }
/* 1327 */       if (servlet.getEnabled() != null) {
/* 1328 */         wrapper.setEnabled(servlet.getEnabled().booleanValue());
/*      */       }
/* 1330 */       wrapper.setName(servlet.getServletName());
/* 1331 */       Map<String, String> params = servlet.getParameterMap();
/* 1332 */       for (Map.Entry<String, String> entry : params.entrySet()) {
/* 1333 */         wrapper.addInitParameter((String)entry.getKey(), (String)entry.getValue());
/*      */       }
/* 1335 */       wrapper.setRunAs(servlet.getRunAs());
/* 1336 */       Set<SecurityRoleRef> roleRefs = servlet.getSecurityRoleRefs();
/* 1337 */       for (SecurityRoleRef roleRef : roleRefs) {
/* 1338 */         wrapper.addSecurityReference(roleRef.getName(), roleRef.getLink());
/*      */       }
/*      */       
/* 1341 */       wrapper.setServletClass(servlet.getServletClass());
/* 1342 */       MultipartDef multipartdef = servlet.getMultipartDef();
/* 1343 */       if (multipartdef != null) {
/* 1344 */         if ((multipartdef.getMaxFileSize() != null) && (multipartdef.getMaxRequestSize() != null) && (multipartdef.getFileSizeThreshold() != null))
/*      */         {
/*      */ 
/* 1347 */           wrapper.setMultipartConfigElement(new MultipartConfigElement(multipartdef.getLocation(), Long.parseLong(multipartdef.getMaxFileSize()), Long.parseLong(multipartdef.getMaxRequestSize()), Integer.parseInt(multipartdef.getFileSizeThreshold())));
/*      */ 
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/* 1354 */           wrapper.setMultipartConfigElement(new MultipartConfigElement(multipartdef.getLocation()));
/*      */         }
/*      */       }
/*      */       
/* 1358 */       if (servlet.getAsyncSupported() != null) {
/* 1359 */         wrapper.setAsyncSupported(servlet.getAsyncSupported().booleanValue());
/*      */       }
/*      */       
/* 1362 */       wrapper.setOverridable(servlet.isOverridable());
/* 1363 */       this.context.addChild(wrapper);
/*      */     }
/*      */     
/* 1366 */     for (Map.Entry<String, String> entry : webxml.getServletMappings().entrySet()) {
/* 1367 */       this.context.addServletMapping((String)entry.getKey(), (String)entry.getValue());
/*      */     }
/* 1369 */     SessionConfig sessionConfig = webxml.getSessionConfig();
/* 1370 */     if (sessionConfig != null) {
/* 1371 */       if (sessionConfig.getSessionTimeout() != null) {
/* 1372 */         this.context.setSessionTimeout(sessionConfig.getSessionTimeout().intValue());
/*      */       }
/*      */       
/* 1375 */       SessionCookieConfig scc = this.context.getServletContext().getSessionCookieConfig();
/*      */       
/* 1377 */       scc.setName(sessionConfig.getCookieName());
/* 1378 */       scc.setDomain(sessionConfig.getCookieDomain());
/* 1379 */       scc.setPath(sessionConfig.getCookiePath());
/* 1380 */       scc.setComment(sessionConfig.getCookieComment());
/* 1381 */       if (sessionConfig.getCookieHttpOnly() != null) {
/* 1382 */         scc.setHttpOnly(sessionConfig.getCookieHttpOnly().booleanValue());
/*      */       }
/* 1384 */       if (sessionConfig.getCookieSecure() != null) {
/* 1385 */         scc.setSecure(sessionConfig.getCookieSecure().booleanValue());
/*      */       }
/* 1387 */       if (sessionConfig.getCookieMaxAge() != null) {
/* 1388 */         scc.setMaxAge(sessionConfig.getCookieMaxAge().intValue());
/*      */       }
/* 1390 */       if (sessionConfig.getSessionTrackingModes().size() > 0) {
/* 1391 */         this.context.getServletContext().setSessionTrackingModes(sessionConfig.getSessionTrackingModes());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1398 */     for (String welcomeFile : webxml.getWelcomeFiles())
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1406 */       if ((welcomeFile != null) && (welcomeFile.length() > 0)) {
/* 1407 */         this.context.addWelcomeFile(welcomeFile);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1413 */     for (JspPropertyGroup jspPropertyGroup : webxml.getJspPropertyGroups()) {
/* 1414 */       jspServletName = this.context.findServletMapping("*.jsp");
/* 1415 */       if (jspServletName == null) {
/* 1416 */         jspServletName = "jsp";
/*      */       }
/* 1418 */       if (this.context.findChild(jspServletName) != null) {
/* 1419 */         for (String urlPattern : jspPropertyGroup.getUrlPatterns()) {
/* 1420 */           this.context.addServletMapping(urlPattern, jspServletName, true);
/*      */         }
/*      */         
/* 1423 */       } else if (log.isDebugEnabled()) {
/* 1424 */         for (String urlPattern : jspPropertyGroup.getUrlPatterns()) {
/* 1425 */           log.debug("Skiping " + urlPattern + " , no servlet " + jspServletName);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     String jspServletName;
/*      */     
/* 1433 */     for (Map.Entry<String, String> entry : webxml.getPostConstructMethods().entrySet()) {
/* 1434 */       this.context.addPostConstructMethod((String)entry.getKey(), (String)entry.getValue());
/*      */     }
/*      */     
/*      */ 
/* 1438 */     for (Map.Entry<String, String> entry : webxml.getPreDestroyMethods().entrySet()) {
/* 1439 */       this.context.addPreDestroyMethod((String)entry.getKey(), (String)entry.getValue());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private WebXml getDefaultWebXmlFragment(WebXmlParser webXmlParser)
/*      */   {
/* 1447 */     Host host = (Host)this.context.getParent();
/*      */     
/* 1449 */     DefaultWebXmlCacheEntry entry = (DefaultWebXmlCacheEntry)hostWebXmlCache.get(host);
/*      */     
/* 1451 */     InputSource globalWebXml = getGlobalWebXmlSource();
/* 1452 */     InputSource hostWebXml = getHostWebXmlSource();
/*      */     
/* 1454 */     long globalTimeStamp = 0L;
/* 1455 */     long hostTimeStamp = 0L;
/*      */     
/* 1457 */     if (globalWebXml != null) {
/* 1458 */       URLConnection uc = null;
/*      */       try {
/* 1460 */         URL url = new URL(globalWebXml.getSystemId());
/* 1461 */         uc = url.openConnection();
/* 1462 */         globalTimeStamp = uc.getLastModified();
/*      */         
/*      */ 
/*      */ 
/* 1466 */         if (uc != null) {
/*      */           try {
/* 1468 */             uc.getInputStream().close();
/*      */           } catch (IOException e) {
/* 1470 */             ExceptionUtils.handleThrowable(e);
/* 1471 */             globalTimeStamp = -1L;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1477 */         if (hostWebXml == null) {
/*      */           break label320;
/*      */         }
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/* 1464 */         globalTimeStamp = -1L;
/*      */       } finally {
/* 1466 */         if (uc != null) {
/*      */           try {
/* 1468 */             uc.getInputStream().close();
/*      */           } catch (IOException e) {
/* 1470 */             ExceptionUtils.handleThrowable(e);
/* 1471 */             globalTimeStamp = -1L;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1478 */     URLConnection uc = null;
/*      */     try {
/* 1480 */       URL url = new URL(hostWebXml.getSystemId());
/* 1481 */       uc = url.openConnection();
/* 1482 */       hostTimeStamp = uc.getLastModified();
/*      */       
/*      */ 
/*      */ 
/* 1486 */       if (uc != null) {
/*      */         try {
/* 1488 */           uc.getInputStream().close();
/*      */         } catch (IOException e) {
/* 1490 */           ExceptionUtils.handleThrowable(e);
/* 1491 */           hostTimeStamp = -1L;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1497 */       if (entry == null) {
/*      */         break label349;
/*      */       }
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/* 1484 */       hostTimeStamp = -1L;
/*      */     } finally {
/* 1486 */       if (uc != null) {
/*      */         try {
/* 1488 */           uc.getInputStream().close();
/*      */         } catch (IOException e) {
/* 1490 */           ExceptionUtils.handleThrowable(e);
/* 1491 */           hostTimeStamp = -1L;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     label320:
/* 1497 */     if ((entry.getGlobalTimeStamp() == globalTimeStamp) && (entry.getHostTimeStamp() == hostTimeStamp))
/*      */     {
/* 1499 */       return entry.getWebXml();
/*      */     }
/*      */     
/*      */ 
/*      */     label349:
/*      */     
/* 1505 */     synchronized (host.getPipeline()) {
/* 1506 */       entry = (DefaultWebXmlCacheEntry)hostWebXmlCache.get(host);
/* 1507 */       if ((entry != null) && (entry.getGlobalTimeStamp() == globalTimeStamp) && (entry.getHostTimeStamp() == hostTimeStamp))
/*      */       {
/* 1509 */         return entry.getWebXml();
/*      */       }
/*      */       
/* 1512 */       WebXml webXmlDefaultFragment = createWebXml();
/* 1513 */       webXmlDefaultFragment.setOverridable(true);
/*      */       
/*      */ 
/*      */ 
/* 1517 */       webXmlDefaultFragment.setDistributable(true);
/*      */       
/*      */ 
/* 1520 */       webXmlDefaultFragment.setAlwaysAddWelcomeFiles(false);
/*      */       
/*      */ 
/* 1523 */       if (globalWebXml == null)
/*      */       {
/* 1525 */         log.info(sm.getString("contextConfig.defaultMissing"));
/*      */       }
/* 1527 */       else if (!webXmlParser.parseWebXml(globalWebXml, webXmlDefaultFragment, false))
/*      */       {
/* 1529 */         this.ok = false;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1535 */       webXmlDefaultFragment.setReplaceWelcomeFiles(true);
/*      */       
/* 1537 */       if (!webXmlParser.parseWebXml(hostWebXml, webXmlDefaultFragment, false))
/*      */       {
/* 1539 */         this.ok = false;
/*      */       }
/*      */       
/*      */ 
/* 1543 */       if ((globalTimeStamp != -1L) && (hostTimeStamp != -1L)) {
/* 1544 */         entry = new DefaultWebXmlCacheEntry(webXmlDefaultFragment, globalTimeStamp, hostTimeStamp);
/*      */         
/* 1546 */         hostWebXmlCache.put(host, entry);
/*      */       }
/*      */       
/* 1549 */       return webXmlDefaultFragment;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void convertJsps(WebXml webXml)
/*      */   {
/* 1556 */     ServletDef jspServlet = (ServletDef)webXml.getServlets().get("jsp");
/* 1557 */     Map<String, String> jspInitParams; if (jspServlet == null) {
/* 1558 */       Map<String, String> jspInitParams = new HashMap();
/* 1559 */       Wrapper w = (Wrapper)this.context.findChild("jsp");
/* 1560 */       if (w != null) {
/* 1561 */         String[] params = w.findInitParameters();
/* 1562 */         for (String param : params) {
/* 1563 */           jspInitParams.put(param, w.findInitParameter(param));
/*      */         }
/*      */       }
/*      */     } else {
/* 1567 */       jspInitParams = jspServlet.getParameterMap();
/*      */     }
/* 1569 */     for (ServletDef servletDef : webXml.getServlets().values()) {
/* 1570 */       if (servletDef.getJspFile() != null) {
/* 1571 */         convertJsp(servletDef, jspInitParams);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void convertJsp(ServletDef servletDef, Map<String, String> jspInitParams)
/*      */   {
/* 1578 */     servletDef.setServletClass("org.apache.jasper.servlet.JspServlet");
/* 1579 */     String jspFile = servletDef.getJspFile();
/* 1580 */     if ((jspFile != null) && (!jspFile.startsWith("/"))) {
/* 1581 */       if (this.context.isServlet22()) {
/* 1582 */         if (log.isDebugEnabled()) {
/* 1583 */           log.debug(sm.getString("contextConfig.jspFile.warning", new Object[] { jspFile }));
/*      */         }
/*      */         
/* 1586 */         jspFile = "/" + jspFile;
/*      */       } else {
/* 1588 */         throw new IllegalArgumentException(sm.getString("contextConfig.jspFile.error", new Object[] { jspFile }));
/*      */       }
/*      */     }
/*      */     
/* 1592 */     servletDef.getParameterMap().put("jspFile", jspFile);
/* 1593 */     servletDef.setJspFile(null);
/* 1594 */     for (Map.Entry<String, String> initParam : jspInitParams.entrySet()) {
/* 1595 */       servletDef.addInitParameter((String)initParam.getKey(), (String)initParam.getValue());
/*      */     }
/*      */   }
/*      */   
/*      */   protected WebXml createWebXml() {
/* 1600 */     return new WebXml();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void processServletContainerInitializers()
/*      */   {
/*      */     try
/*      */     {
/* 1610 */       WebappServiceLoader<ServletContainerInitializer> loader = new WebappServiceLoader(this.context);
/* 1611 */       detectedScis = loader.load(ServletContainerInitializer.class);
/*      */     } catch (IOException e) { List<ServletContainerInitializer> detectedScis;
/* 1613 */       log.error(sm.getString("contextConfig.servletContainerInitializerFail", new Object[] { this.context.getName() }), e);
/*      */       
/*      */ 
/*      */ 
/* 1617 */       this.ok = false; return;
/*      */     }
/*      */     
/*      */     List<ServletContainerInitializer> detectedScis;
/* 1621 */     for (ServletContainerInitializer sci : detectedScis) {
/* 1622 */       this.initializerClassMap.put(sci, new HashSet());
/*      */       
/*      */       try
/*      */       {
/* 1626 */         ht = (HandlesTypes)sci.getClass().getAnnotation(HandlesTypes.class);
/*      */       } catch (Exception e) { HandlesTypes ht;
/* 1628 */         if (log.isDebugEnabled()) {
/* 1629 */           log.info(sm.getString("contextConfig.sci.debug", new Object[] { sci.getClass().getName() }), e);
/*      */         }
/*      */         else
/*      */         {
/* 1633 */           log.info(sm.getString("contextConfig.sci.info", new Object[] { sci.getClass().getName() }));
/*      */         }
/*      */       }
/* 1636 */       continue;
/*      */       HandlesTypes ht;
/* 1638 */       if (ht != null)
/*      */       {
/*      */ 
/* 1641 */         Class<?>[] types = ht.value();
/* 1642 */         if (types != null)
/*      */         {
/*      */ 
/*      */ 
/* 1646 */           for (Class<?> type : types) {
/* 1647 */             if (type.isAnnotation()) {
/* 1648 */               this.handlesTypesAnnotations = true;
/*      */             } else {
/* 1650 */               this.handlesTypesNonAnnotations = true;
/*      */             }
/* 1652 */             Set<ServletContainerInitializer> scis = (Set)this.typeInitializerMap.get(type);
/*      */             
/* 1654 */             if (scis == null) {
/* 1655 */               scis = new HashSet();
/* 1656 */               this.typeInitializerMap.put(type, scis);
/*      */             }
/* 1658 */             scis.add(sci);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void processResourceJARs(Set<WebXml> fragments)
/*      */   {
/* 1672 */     for (WebXml fragment : fragments) {
/* 1673 */       URL url = fragment.getURL();
/*      */       try {
/* 1675 */         if (("jar".equals(url.getProtocol())) || (url.toString().endsWith(".jar"))) {
/* 1676 */           Jar jar = JarFactory.newInstance(url);Throwable localThrowable2 = null;
/* 1677 */           try { jar.nextEntry();
/* 1678 */             String entryName = jar.getEntryName();
/* 1679 */             while (entryName != null) {
/* 1680 */               if (entryName.startsWith("META-INF/resources/")) {
/* 1681 */                 this.context.getResources().createWebResourceSet(WebResourceRoot.ResourceSetType.RESOURCE_JAR, "/", url, "/META-INF/resources");
/*      */                 
/*      */ 
/* 1684 */                 break;
/*      */               }
/* 1686 */               jar.nextEntry();
/* 1687 */               entryName = jar.getEntryName();
/*      */             }
/*      */           }
/*      */           catch (Throwable localThrowable1)
/*      */           {
/* 1676 */             localThrowable2 = localThrowable1;throw localThrowable1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           finally
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1689 */             if (jar != null) if (localThrowable2 != null) try { jar.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else jar.close();
/* 1690 */           } } else if ("file".equals(url.getProtocol())) {
/* 1691 */           File file = new File(url.toURI());
/* 1692 */           File resources = new File(file, "META-INF/resources/");
/* 1693 */           if (resources.isDirectory()) {
/* 1694 */             this.context.getResources().createWebResourceSet(WebResourceRoot.ResourceSetType.RESOURCE_JAR, "/", resources.getAbsolutePath(), null, "/");
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (IOException ioe)
/*      */       {
/* 1700 */         log.error(sm.getString("contextConfig.resourceJarFail", new Object[] { url, this.context.getName() }));
/*      */       }
/*      */       catch (URISyntaxException e) {
/* 1703 */         log.error(sm.getString("contextConfig.resourceJarFail", new Object[] { url, this.context.getName() }));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InputSource getGlobalWebXmlSource()
/*      */   {
/* 1717 */     if ((this.defaultWebXml == null) && ((this.context instanceof StandardContext))) {
/* 1718 */       this.defaultWebXml = ((StandardContext)this.context).getDefaultWebXml();
/*      */     }
/*      */     
/* 1721 */     if (this.defaultWebXml == null) {
/* 1722 */       getDefaultWebXml();
/*      */     }
/*      */     
/*      */ 
/* 1726 */     if ("org/apache/catalina/startup/NO_DEFAULT_XML".equals(this.defaultWebXml)) {
/* 1727 */       return null;
/*      */     }
/* 1729 */     return getWebXmlSource(this.defaultWebXml, this.context.getCatalinaBase().getPath());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InputSource getHostWebXmlSource()
/*      */   {
/* 1739 */     File hostConfigBase = getHostConfigBase();
/* 1740 */     if (hostConfigBase == null) {
/* 1741 */       return null;
/*      */     }
/* 1743 */     return getWebXmlSource("web.xml.default", hostConfigBase.getPath());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InputSource getContextWebXmlSource()
/*      */   {
/* 1752 */     InputStream stream = null;
/* 1753 */     source = null;
/* 1754 */     URL url = null;
/*      */     
/* 1756 */     String altDDName = null;
/*      */     
/*      */ 
/* 1759 */     ServletContext servletContext = this.context.getServletContext();
/*      */     try {
/* 1761 */       if (servletContext != null) {
/* 1762 */         altDDName = (String)servletContext.getAttribute("org.apache.catalina.deploy.alt_dd");
/* 1763 */         if (altDDName != null) {
/*      */           try {
/* 1765 */             stream = new FileInputStream(altDDName);
/* 1766 */             url = new File(altDDName).toURI().toURL();
/*      */           } catch (FileNotFoundException e) {
/* 1768 */             log.error(sm.getString("contextConfig.altDDNotFound", new Object[] { altDDName }));
/*      */           }
/*      */           catch (MalformedURLException e) {
/* 1771 */             log.error(sm.getString("contextConfig.applicationUrl"));
/*      */           }
/*      */         }
/*      */         else {
/* 1775 */           stream = servletContext.getResourceAsStream("/WEB-INF/web.xml");
/*      */           try
/*      */           {
/* 1778 */             url = servletContext.getResource("/WEB-INF/web.xml");
/*      */           }
/*      */           catch (MalformedURLException e) {
/* 1781 */             log.error(sm.getString("contextConfig.applicationUrl"));
/*      */           }
/*      */         }
/*      */       }
/* 1785 */       if ((stream == null) || (url == null)) {
/* 1786 */         if (log.isDebugEnabled()) {
/* 1787 */           log.debug(sm.getString("contextConfig.applicationMissing") + " " + this.context);
/*      */         }
/*      */       } else {
/* 1790 */         source = new InputSource(url.toExternalForm());
/* 1791 */         source.setByteStream(stream);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1803 */       return source;
/*      */     }
/*      */     finally
/*      */     {
/* 1794 */       if ((source == null) && (stream != null)) {
/*      */         try {
/* 1796 */           stream.close();
/*      */         }
/*      */         catch (IOException localIOException1) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InputSource getWebXmlSource(String filename, String path)
/*      */   {
/* 1814 */     File file = new File(filename);
/* 1815 */     if (!file.isAbsolute()) {
/* 1816 */       file = new File(path, filename);
/*      */     }
/*      */     
/* 1819 */     InputStream stream = null;
/* 1820 */     source = null;
/*      */     try
/*      */     {
/* 1823 */       if (!file.exists())
/*      */       {
/* 1825 */         stream = getClass().getClassLoader().getResourceAsStream(filename);
/*      */         
/* 1827 */         if (stream != null) {
/* 1828 */           source = new InputSource(getClass().getClassLoader().getResource(filename).toURI().toString());
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1833 */         source = new InputSource(file.getAbsoluteFile().toURI().toString());
/* 1834 */         stream = new FileInputStream(file);
/*      */       }
/*      */       
/* 1837 */       if ((stream != null) && (source != null)) {
/* 1838 */         source.setByteStream(stream);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1853 */       return source;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1841 */       log.error(sm.getString("contextConfig.defaultError", new Object[] { filename, file }), e);
/*      */     }
/*      */     finally {
/* 1844 */       if ((source == null) && (stream != null)) {
/*      */         try {
/* 1846 */           stream.close();
/*      */         }
/*      */         catch (IOException localIOException2) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Map<String, WebXml> processJarsForWebFragments(WebXml application, WebXmlParser webXmlParser)
/*      */   {
/* 1871 */     JarScanner jarScanner = this.context.getJarScanner();
/* 1872 */     boolean delegate = false;
/* 1873 */     if ((this.context instanceof StandardContext)) {
/* 1874 */       delegate = ((StandardContext)this.context).getDelegate();
/*      */     }
/* 1876 */     boolean parseRequired = true;
/* 1877 */     Set<String> absoluteOrder = application.getAbsoluteOrdering();
/* 1878 */     if ((absoluteOrder != null) && (absoluteOrder.isEmpty()) && (!this.context.getXmlValidation()))
/*      */     {
/*      */ 
/*      */ 
/* 1882 */       parseRequired = false;
/*      */     }
/* 1884 */     FragmentJarScannerCallback callback = new FragmentJarScannerCallback(webXmlParser, delegate, parseRequired);
/*      */     
/*      */ 
/* 1887 */     jarScanner.scan(JarScanType.PLUGGABILITY, this.context.getServletContext(), callback);
/*      */     
/*      */ 
/* 1890 */     if (!callback.isOk()) {
/* 1891 */       this.ok = false;
/*      */     }
/* 1893 */     return callback.getFragments();
/*      */   }
/*      */   
/*      */   protected void processAnnotations(Set<WebXml> fragments, boolean handlesTypesOnly, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */   {
/* 1898 */     for (WebXml fragment : fragments)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1905 */       boolean htOnly = (handlesTypesOnly) || (!fragment.getWebappJar()) || (fragment.isMetadataComplete());
/*      */       
/*      */ 
/* 1908 */       WebXml annotations = new WebXml();
/*      */       
/* 1910 */       annotations.setDistributable(true);
/* 1911 */       URL url = fragment.getURL();
/* 1912 */       processAnnotationsUrl(url, annotations, htOnly, javaClassCache);
/* 1913 */       Set<WebXml> set = new HashSet();
/* 1914 */       set.add(annotations);
/*      */       
/* 1916 */       fragment.merge(set);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void processAnnotationsWebResource(WebResource webResource, WebXml fragment, boolean handlesTypesOnly, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */   {
/* 1924 */     if (webResource.isDirectory()) {
/* 1925 */       WebResource[] webResources = webResource.getWebResourceRoot().listResources(webResource.getWebappPath());
/*      */       
/*      */ 
/* 1928 */       if (webResources.length > 0) {
/* 1929 */         if (log.isDebugEnabled()) {
/* 1930 */           log.debug(sm.getString("contextConfig.processAnnotationsWebDir.debug", new Object[] { webResource.getURL() }));
/*      */         }
/*      */         
/*      */ 
/* 1934 */         for (WebResource r : webResources) {
/* 1935 */           processAnnotationsWebResource(r, fragment, handlesTypesOnly, javaClassCache);
/*      */         }
/*      */       }
/* 1938 */     } else if ((webResource.isFile()) && (webResource.getName().endsWith(".class"))) {
/*      */       try {
/* 1940 */         InputStream is = webResource.getInputStream();??? = null;
/* 1941 */         try { processAnnotationsStream(is, fragment, handlesTypesOnly, javaClassCache);
/*      */         }
/*      */         catch (Throwable localThrowable1)
/*      */         {
/* 1940 */           ??? = localThrowable1;throw localThrowable1;
/*      */         } finally {
/* 1942 */           if (is != null) if (??? != null) try { is.close(); } catch (Throwable x2) { ???.addSuppressed(x2); } else is.close();
/* 1943 */         } } catch (IOException e) { log.error(sm.getString("contextConfig.inputStreamWebResource", new Object[] { webResource.getWebappPath() }), e);
/*      */       }
/*      */       catch (ClassFormatException e) {
/* 1946 */         log.error(sm.getString("contextConfig.inputStreamWebResource", new Object[] { webResource.getWebappPath() }), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void processAnnotationsUrl(URL url, WebXml fragment, boolean handlesTypesOnly, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */   {
/* 1955 */     if (url == null)
/*      */     {
/* 1957 */       return; }
/* 1958 */     if (("jar".equals(url.getProtocol())) || (url.toString().endsWith(".jar"))) {
/* 1959 */       processAnnotationsJar(url, fragment, handlesTypesOnly, javaClassCache);
/* 1960 */     } else if ("file".equals(url.getProtocol())) {
/*      */       try {
/* 1962 */         processAnnotationsFile(new File(url.toURI()), fragment, handlesTypesOnly, javaClassCache);
/*      */       }
/*      */       catch (URISyntaxException e) {
/* 1965 */         log.error(sm.getString("contextConfig.fileUrl", new Object[] { url }), e);
/*      */       }
/*      */     } else {
/* 1968 */       log.error(sm.getString("contextConfig.unknownUrlProtocol", new Object[] { url.getProtocol(), url }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void processAnnotationsJar(URL url, WebXml fragment, boolean handlesTypesOnly, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */   {
/*      */     try
/*      */     {
/* 1978 */       Jar jar = JarFactory.newInstance(url);Throwable localThrowable3 = null;
/* 1979 */       try { if (log.isDebugEnabled()) {
/* 1980 */           log.debug(sm.getString("contextConfig.processAnnotationsJar.debug", new Object[] { url }));
/*      */         }
/*      */         
/*      */ 
/* 1984 */         jar.nextEntry();
/* 1985 */         String entryName = jar.getEntryName();
/* 1986 */         while (entryName != null) {
/* 1987 */           if (entryName.endsWith(".class")) {
/* 1988 */             try { InputStream is = jar.getEntryInputStream();Throwable localThrowable4 = null;
/* 1989 */               try { processAnnotationsStream(is, fragment, handlesTypesOnly, javaClassCache);
/*      */               }
/*      */               catch (Throwable localThrowable1)
/*      */               {
/* 1988 */                 localThrowable4 = localThrowable1;throw localThrowable1;
/*      */               } finally {
/* 1990 */                 if (is != null) if (localThrowable4 != null) try { is.close(); } catch (Throwable x2) { localThrowable4.addSuppressed(x2); } else is.close();
/* 1991 */               } } catch (IOException e) { log.error(sm.getString("contextConfig.inputStreamJar", new Object[] { entryName, url }), e);
/*      */             }
/*      */             catch (ClassFormatException e) {
/* 1994 */               log.error(sm.getString("contextConfig.inputStreamJar", new Object[] { entryName, url }), e);
/*      */             }
/*      */           }
/*      */           
/* 1998 */           jar.nextEntry();
/* 1999 */           entryName = jar.getEntryName();
/*      */         }
/*      */       }
/*      */       catch (Throwable localThrowable2)
/*      */       {
/* 1978 */         localThrowable3 = localThrowable2;throw localThrowable2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2001 */         if (jar != null) if (localThrowable3 != null) try { jar.close(); } catch (Throwable x2) { localThrowable3.addSuppressed(x2); } else jar.close();
/* 2002 */       } } catch (IOException e) { log.error(sm.getString("contextConfig.jarFile", new Object[] { url }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void processAnnotationsFile(File file, WebXml fragment, boolean handlesTypesOnly, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */   {
/* 2010 */     if (file.isDirectory())
/*      */     {
/* 2012 */       String[] dirs = file.list();
/* 2013 */       if (dirs != null) {
/* 2014 */         if (log.isDebugEnabled()) {
/* 2015 */           log.debug(sm.getString("contextConfig.processAnnotationsDir.debug", new Object[] { file }));
/*      */         }
/*      */         
/* 2018 */         for (String dir : dirs) {
/* 2019 */           processAnnotationsFile(new File(file, dir), fragment, handlesTypesOnly, javaClassCache);
/*      */         }
/*      */       }
/*      */     }
/* 2023 */     else if ((file.getName().endsWith(".class")) && (file.canRead())) {
/* 2024 */       try { FileInputStream fis = new FileInputStream(file);??? = null;
/* 2025 */         try { processAnnotationsStream(fis, fragment, handlesTypesOnly, javaClassCache);
/*      */         }
/*      */         catch (Throwable localThrowable1)
/*      */         {
/* 2024 */           ??? = localThrowable1;throw localThrowable1;
/*      */         } finally {
/* 2026 */           if (fis != null) if (??? != null) try { fis.close(); } catch (Throwable x2) { ???.addSuppressed(x2); } else fis.close();
/* 2027 */         } } catch (IOException e) { log.error(sm.getString("contextConfig.inputStreamFile", new Object[] { file.getAbsolutePath() }), e);
/*      */       }
/*      */       catch (ClassFormatException e) {
/* 2030 */         log.error(sm.getString("contextConfig.inputStreamFile", new Object[] { file.getAbsolutePath() }), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void processAnnotationsStream(InputStream is, WebXml fragment, boolean handlesTypesOnly, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */     throws ClassFormatException, IOException
/*      */   {
/* 2041 */     ClassParser parser = new ClassParser(is);
/* 2042 */     JavaClass clazz = parser.parse();
/* 2043 */     checkHandlesTypes(clazz, javaClassCache);
/*      */     
/* 2045 */     if (handlesTypesOnly) {
/* 2046 */       return;
/*      */     }
/*      */     
/* 2049 */     AnnotationEntry[] annotationsEntries = clazz.getAnnotationEntries();
/* 2050 */     if (annotationsEntries != null) {
/* 2051 */       String className = clazz.getClassName();
/* 2052 */       for (AnnotationEntry ae : annotationsEntries) {
/* 2053 */         String type = ae.getAnnotationType();
/* 2054 */         if ("Ljavax/servlet/annotation/WebServlet;".equals(type)) {
/* 2055 */           processAnnotationWebServlet(className, ae, fragment);
/* 2056 */         } else if ("Ljavax/servlet/annotation/WebFilter;".equals(type)) {
/* 2057 */           processAnnotationWebFilter(className, ae, fragment);
/* 2058 */         } else if ("Ljavax/servlet/annotation/WebListener;".equals(type)) {
/* 2059 */           fragment.addListener(className);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void checkHandlesTypes(JavaClass javaClass, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */   {
/* 2078 */     if (this.typeInitializerMap.size() == 0) {
/* 2079 */       return;
/*      */     }
/*      */     
/* 2082 */     if ((javaClass.getAccessFlags() & 0x2000) > 0)
/*      */     {
/*      */ 
/* 2085 */       return;
/*      */     }
/*      */     
/* 2088 */     String className = javaClass.getClassName();
/*      */     
/* 2090 */     Class<?> clazz = null;
/* 2091 */     if (this.handlesTypesNonAnnotations)
/*      */     {
/* 2093 */       populateJavaClassCache(className, javaClass, javaClassCache);
/* 2094 */       JavaClassCacheEntry entry = (JavaClassCacheEntry)javaClassCache.get(className);
/* 2095 */       if (entry.getSciSet() == null) {
/*      */         try {
/* 2097 */           populateSCIsForCacheEntry(entry, javaClassCache);
/*      */         } catch (StackOverflowError soe) {
/* 2099 */           throw new IllegalStateException(sm.getString("contextConfig.annotationsStackOverflow", new Object[] { this.context.getName(), classHierarchyToString(className, entry, javaClassCache) }));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2105 */       if (!entry.getSciSet().isEmpty())
/*      */       {
/* 2107 */         clazz = Introspection.loadClass(this.context, className);
/* 2108 */         if (clazz == null)
/*      */         {
/* 2110 */           return;
/*      */         }
/*      */         
/* 2113 */         for (ServletContainerInitializer sci : entry.getSciSet()) {
/* 2114 */           Set<Class<?>> classes = (Set)this.initializerClassMap.get(sci);
/* 2115 */           if (classes == null) {
/* 2116 */             classes = new HashSet();
/* 2117 */             this.initializerClassMap.put(sci, classes);
/*      */           }
/* 2119 */           classes.add(clazz);
/*      */         }
/*      */       }
/*      */     }
/*      */     AnnotationEntry[] annotationEntries;
/* 2124 */     if (this.handlesTypesAnnotations) {
/* 2125 */       annotationEntries = javaClass.getAnnotationEntries();
/* 2126 */       if (annotationEntries != null)
/*      */       {
/* 2128 */         for (Map.Entry<Class<?>, Set<ServletContainerInitializer>> entry : this.typeInitializerMap.entrySet()) {
/* 2129 */           if (((Class)entry.getKey()).isAnnotation()) {
/* 2130 */             String entryClassName = ((Class)entry.getKey()).getName();
/* 2131 */             for (AnnotationEntry annotationEntry : annotationEntries) {
/* 2132 */               if (entryClassName.equals(getClassName(annotationEntry.getAnnotationType())))
/*      */               {
/* 2134 */                 if (clazz == null) {
/* 2135 */                   clazz = Introspection.loadClass(this.context, className);
/*      */                   
/* 2137 */                   if (clazz == null)
/*      */                   {
/*      */ 
/* 2140 */                     return;
/*      */                   }
/*      */                 }
/* 2143 */                 for (ServletContainerInitializer sci : (Set)entry.getValue()) {
/* 2144 */                   ((Set)this.initializerClassMap.get(sci)).add(clazz);
/*      */                 }
/* 2146 */                 break;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private String classHierarchyToString(String className, JavaClassCacheEntry entry, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */   {
/* 2158 */     JavaClassCacheEntry start = entry;
/* 2159 */     StringBuilder msg = new StringBuilder(className);
/* 2160 */     msg.append("->");
/*      */     
/* 2162 */     String parentName = entry.getSuperclassName();
/* 2163 */     JavaClassCacheEntry parent = (JavaClassCacheEntry)javaClassCache.get(parentName);
/* 2164 */     int count = 0;
/*      */     
/* 2166 */     while ((count < 100) && (parent != null) && (parent != start)) {
/* 2167 */       msg.append(parentName);
/* 2168 */       msg.append("->");
/*      */       
/* 2170 */       count++;
/* 2171 */       parentName = parent.getSuperclassName();
/* 2172 */       parent = (JavaClassCacheEntry)javaClassCache.get(parentName);
/*      */     }
/*      */     
/* 2175 */     msg.append(parentName);
/*      */     
/* 2177 */     return msg.toString();
/*      */   }
/*      */   
/*      */   private void populateJavaClassCache(String className, JavaClass javaClass, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */   {
/* 2182 */     if (javaClassCache.containsKey(className)) {
/* 2183 */       return;
/*      */     }
/*      */     
/*      */ 
/* 2187 */     javaClassCache.put(className, new JavaClassCacheEntry(javaClass));
/*      */     
/* 2189 */     populateJavaClassCache(javaClass.getSuperclassName(), javaClassCache);
/*      */     
/* 2191 */     for (String iterface : javaClass.getInterfaceNames()) {
/* 2192 */       populateJavaClassCache(iterface, javaClassCache);
/*      */     }
/*      */   }
/*      */   
/*      */   private void populateJavaClassCache(String className, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */   {
/* 2198 */     if (!javaClassCache.containsKey(className)) {
/* 2199 */       String name = className.replace('.', '/') + ".class";
/* 2200 */       try { InputStream is = this.context.getLoader().getClassLoader().getResourceAsStream(name);Throwable localThrowable2 = null;
/* 2201 */         try { if (is == null) {
/*      */             return;
/*      */           }
/* 2204 */           ClassParser parser = new ClassParser(is);
/* 2205 */           JavaClass clazz = parser.parse();
/* 2206 */           populateJavaClassCache(clazz.getClassName(), clazz, javaClassCache);
/*      */         }
/*      */         catch (Throwable localThrowable1)
/*      */         {
/* 2200 */           localThrowable2 = localThrowable1;throw localThrowable1;
/*      */ 
/*      */ 
/*      */         }
/*      */         finally
/*      */         {
/*      */ 
/* 2207 */           if (is != null) if (localThrowable2 != null) try { is.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else is.close();
/* 2208 */         } } catch (ClassFormatException e) { log.debug(sm.getString("contextConfig.invalidSciHandlesTypes", new Object[] { className }), e);
/*      */       }
/*      */       catch (IOException e) {
/* 2211 */         log.debug(sm.getString("contextConfig.invalidSciHandlesTypes", new Object[] { className }), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void populateSCIsForCacheEntry(JavaClassCacheEntry cacheEntry, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */   {
/* 2219 */     Set<ServletContainerInitializer> result = new HashSet();
/*      */     
/*      */ 
/* 2222 */     String superClassName = cacheEntry.getSuperclassName();
/* 2223 */     JavaClassCacheEntry superClassCacheEntry = (JavaClassCacheEntry)javaClassCache.get(superClassName);
/*      */     
/*      */ 
/*      */ 
/* 2227 */     if (cacheEntry.equals(superClassCacheEntry)) {
/* 2228 */       cacheEntry.setSciSet(EMPTY_SCI_SET);
/* 2229 */       return;
/*      */     }
/*      */     
/*      */ 
/* 2233 */     if (superClassCacheEntry != null) {
/* 2234 */       if (superClassCacheEntry.getSciSet() == null) {
/* 2235 */         populateSCIsForCacheEntry(superClassCacheEntry, javaClassCache);
/*      */       }
/* 2237 */       result.addAll(superClassCacheEntry.getSciSet());
/*      */     }
/* 2239 */     result.addAll(getSCIsForClass(superClassName));
/*      */     
/*      */ 
/* 2242 */     for (String interfaceName : cacheEntry.getInterfaceNames()) {
/* 2243 */       JavaClassCacheEntry interfaceEntry = (JavaClassCacheEntry)javaClassCache.get(interfaceName);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2248 */       if (interfaceEntry != null) {
/* 2249 */         if (interfaceEntry.getSciSet() == null) {
/* 2250 */           populateSCIsForCacheEntry(interfaceEntry, javaClassCache);
/*      */         }
/* 2252 */         result.addAll(interfaceEntry.getSciSet());
/*      */       }
/* 2254 */       result.addAll(getSCIsForClass(interfaceName));
/*      */     }
/*      */     
/* 2257 */     cacheEntry.setSciSet(result.isEmpty() ? EMPTY_SCI_SET : result);
/*      */   }
/*      */   
/*      */   private Set<ServletContainerInitializer> getSCIsForClass(String className)
/*      */   {
/* 2262 */     for (Map.Entry<Class<?>, Set<ServletContainerInitializer>> entry : this.typeInitializerMap.entrySet()) {
/* 2263 */       Class<?> clazz = (Class)entry.getKey();
/* 2264 */       if ((!clazz.isAnnotation()) && 
/* 2265 */         (clazz.getName().equals(className))) {
/* 2266 */         return (Set)entry.getValue();
/*      */       }
/*      */     }
/*      */     
/* 2270 */     return EMPTY_SCI_SET;
/*      */   }
/*      */   
/*      */   private static final String getClassName(String internalForm) {
/* 2274 */     if (!internalForm.startsWith("L")) {
/* 2275 */       return internalForm;
/*      */     }
/*      */     
/*      */ 
/* 2279 */     return internalForm.substring(1, internalForm.length() - 1).replace('/', '.');
/*      */   }
/*      */   
/*      */ 
/*      */   protected void processAnnotationWebServlet(String className, AnnotationEntry ae, WebXml fragment)
/*      */   {
/* 2285 */     String servletName = null;
/*      */     
/* 2287 */     List<ElementValuePair> evps = ae.getElementValuePairs();
/* 2288 */     for (ElementValuePair evp : evps) {
/* 2289 */       String name = evp.getNameString();
/* 2290 */       if ("name".equals(name)) {
/* 2291 */         servletName = evp.getValue().stringifyValue();
/* 2292 */         break;
/*      */       }
/*      */     }
/* 2295 */     if (servletName == null)
/*      */     {
/* 2297 */       servletName = className;
/*      */     }
/* 2299 */     ServletDef servletDef = (ServletDef)fragment.getServlets().get(servletName);
/*      */     boolean isWebXMLservletDef;
/*      */     boolean isWebXMLservletDef;
/* 2302 */     if (servletDef == null) {
/* 2303 */       servletDef = new ServletDef();
/* 2304 */       servletDef.setServletName(servletName);
/* 2305 */       servletDef.setServletClass(className);
/* 2306 */       isWebXMLservletDef = false;
/*      */     } else {
/* 2308 */       isWebXMLservletDef = true;
/*      */     }
/*      */     
/* 2311 */     boolean urlPatternsSet = false;
/* 2312 */     String[] urlPatterns = null;
/*      */     
/*      */ 
/* 2315 */     for (ElementValuePair evp : evps) {
/* 2316 */       String name = evp.getNameString();
/* 2317 */       if (("value".equals(name)) || ("urlPatterns".equals(name))) {
/* 2318 */         if (urlPatternsSet) {
/* 2319 */           throw new IllegalArgumentException(sm.getString("contextConfig.urlPatternValue", new Object[] { "WebServlet", className }));
/*      */         }
/*      */         
/* 2322 */         urlPatternsSet = true;
/* 2323 */         urlPatterns = processAnnotationsStringArray(evp.getValue());
/* 2324 */       } else if ("description".equals(name)) {
/* 2325 */         if (servletDef.getDescription() == null) {
/* 2326 */           servletDef.setDescription(evp.getValue().stringifyValue());
/*      */         }
/* 2328 */       } else if ("displayName".equals(name)) {
/* 2329 */         if (servletDef.getDisplayName() == null) {
/* 2330 */           servletDef.setDisplayName(evp.getValue().stringifyValue());
/*      */         }
/* 2332 */       } else if ("largeIcon".equals(name)) {
/* 2333 */         if (servletDef.getLargeIcon() == null) {
/* 2334 */           servletDef.setLargeIcon(evp.getValue().stringifyValue());
/*      */         }
/* 2336 */       } else if ("smallIcon".equals(name)) {
/* 2337 */         if (servletDef.getSmallIcon() == null) {
/* 2338 */           servletDef.setSmallIcon(evp.getValue().stringifyValue());
/*      */         }
/* 2340 */       } else if ("asyncSupported".equals(name)) {
/* 2341 */         if (servletDef.getAsyncSupported() == null) {
/* 2342 */           servletDef.setAsyncSupported(evp.getValue().stringifyValue());
/*      */         }
/*      */       }
/* 2345 */       else if ("loadOnStartup".equals(name)) {
/* 2346 */         if (servletDef.getLoadOnStartup() == null) {
/* 2347 */           servletDef.setLoadOnStartup(evp.getValue().stringifyValue());
/*      */         }
/*      */       }
/* 2350 */       else if ("initParams".equals(name)) {
/* 2351 */         Map<String, String> initParams = processAnnotationWebInitParams(evp.getValue());
/*      */         Map<String, String> webXMLInitParams;
/* 2353 */         if (isWebXMLservletDef) {
/* 2354 */           webXMLInitParams = servletDef.getParameterMap();
/*      */           
/* 2356 */           for (Map.Entry<String, String> entry : initParams.entrySet())
/*      */           {
/* 2358 */             if (webXMLInitParams.get(entry.getKey()) == null) {
/* 2359 */               servletDef.addInitParameter((String)entry.getKey(), (String)entry.getValue());
/*      */             }
/*      */           }
/*      */         }
/*      */         else {
/* 2364 */           for (Map.Entry<String, String> entry : initParams.entrySet())
/*      */           {
/* 2366 */             servletDef.addInitParameter((String)entry.getKey(), (String)entry.getValue());
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2372 */     if ((!isWebXMLservletDef) && (urlPatterns != null)) {
/* 2373 */       fragment.addServlet(servletDef);
/*      */     }
/* 2375 */     if ((urlPatterns != null) && 
/* 2376 */       (!fragment.getServletMappings().containsValue(servletName))) {
/* 2377 */       for (String urlPattern : urlPatterns) {
/* 2378 */         fragment.addServletMapping(urlPattern, servletName);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void processAnnotationWebFilter(String className, AnnotationEntry ae, WebXml fragment)
/*      */   {
/* 2395 */     String filterName = null;
/*      */     
/* 2397 */     List<ElementValuePair> evps = ae.getElementValuePairs();
/* 2398 */     for (ElementValuePair evp : evps) {
/* 2399 */       String name = evp.getNameString();
/* 2400 */       if ("filterName".equals(name)) {
/* 2401 */         filterName = evp.getValue().stringifyValue();
/* 2402 */         break;
/*      */       }
/*      */     }
/* 2405 */     if (filterName == null)
/*      */     {
/* 2407 */       filterName = className;
/*      */     }
/* 2409 */     FilterDef filterDef = (FilterDef)fragment.getFilters().get(filterName);
/* 2410 */     FilterMap filterMap = new FilterMap();
/*      */     boolean isWebXMLfilterDef;
/*      */     boolean isWebXMLfilterDef;
/* 2413 */     if (filterDef == null) {
/* 2414 */       filterDef = new FilterDef();
/* 2415 */       filterDef.setFilterName(filterName);
/* 2416 */       filterDef.setFilterClass(className);
/* 2417 */       isWebXMLfilterDef = false;
/*      */     } else {
/* 2419 */       isWebXMLfilterDef = true;
/*      */     }
/*      */     
/* 2422 */     boolean urlPatternsSet = false;
/* 2423 */     boolean servletNamesSet = false;
/* 2424 */     boolean dispatchTypesSet = false;
/* 2425 */     String[] urlPatterns = null;
/*      */     
/* 2427 */     for (ElementValuePair evp : evps) {
/* 2428 */       String name = evp.getNameString();
/* 2429 */       if (("value".equals(name)) || ("urlPatterns".equals(name))) {
/* 2430 */         if (urlPatternsSet) {
/* 2431 */           throw new IllegalArgumentException(sm.getString("contextConfig.urlPatternValue", new Object[] { "WebFilter", className }));
/*      */         }
/*      */         
/* 2434 */         urlPatterns = processAnnotationsStringArray(evp.getValue());
/* 2435 */         urlPatternsSet = urlPatterns.length > 0;
/* 2436 */         for (String urlPattern : urlPatterns) {
/* 2437 */           filterMap.addURLPattern(urlPattern);
/*      */         }
/* 2439 */       } else if ("servletNames".equals(name)) {
/* 2440 */         String[] servletNames = processAnnotationsStringArray(evp.getValue());
/*      */         
/* 2442 */         servletNamesSet = servletNames.length > 0;
/* 2443 */         for (String servletName : servletNames) {
/* 2444 */           filterMap.addServletName(servletName);
/*      */         }
/* 2446 */       } else if ("dispatcherTypes".equals(name)) {
/* 2447 */         String[] dispatcherTypes = processAnnotationsStringArray(evp.getValue());
/*      */         
/* 2449 */         dispatchTypesSet = dispatcherTypes.length > 0;
/* 2450 */         for (String dispatcherType : dispatcherTypes) {
/* 2451 */           filterMap.setDispatcher(dispatcherType);
/*      */         }
/* 2453 */       } else if ("description".equals(name)) {
/* 2454 */         if (filterDef.getDescription() == null) {
/* 2455 */           filterDef.setDescription(evp.getValue().stringifyValue());
/*      */         }
/* 2457 */       } else if ("displayName".equals(name)) {
/* 2458 */         if (filterDef.getDisplayName() == null) {
/* 2459 */           filterDef.setDisplayName(evp.getValue().stringifyValue());
/*      */         }
/* 2461 */       } else if ("largeIcon".equals(name)) {
/* 2462 */         if (filterDef.getLargeIcon() == null) {
/* 2463 */           filterDef.setLargeIcon(evp.getValue().stringifyValue());
/*      */         }
/* 2465 */       } else if ("smallIcon".equals(name)) {
/* 2466 */         if (filterDef.getSmallIcon() == null) {
/* 2467 */           filterDef.setSmallIcon(evp.getValue().stringifyValue());
/*      */         }
/* 2469 */       } else if ("asyncSupported".equals(name)) {
/* 2470 */         if (filterDef.getAsyncSupported() == null) {
/* 2471 */           filterDef.setAsyncSupported(evp.getValue().stringifyValue());
/*      */         }
/*      */       }
/* 2474 */       else if ("initParams".equals(name)) {
/* 2475 */         Map<String, String> initParams = processAnnotationWebInitParams(evp.getValue());
/*      */         Map<String, String> webXMLInitParams;
/* 2477 */         if (isWebXMLfilterDef) {
/* 2478 */           webXMLInitParams = filterDef.getParameterMap();
/*      */           
/* 2480 */           for (Map.Entry<String, String> entry : initParams.entrySet())
/*      */           {
/* 2482 */             if (webXMLInitParams.get(entry.getKey()) == null) {
/* 2483 */               filterDef.addInitParameter((String)entry.getKey(), (String)entry.getValue());
/*      */             }
/*      */           }
/*      */         }
/*      */         else {
/* 2488 */           for (Map.Entry<String, String> entry : initParams.entrySet())
/*      */           {
/* 2490 */             filterDef.addInitParameter((String)entry.getKey(), (String)entry.getValue());
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2497 */     if (!isWebXMLfilterDef) {
/* 2498 */       fragment.addFilter(filterDef);
/* 2499 */       if ((urlPatternsSet) || (servletNamesSet)) {
/* 2500 */         filterMap.setFilterName(filterName);
/* 2501 */         fragment.addFilterMapping(filterMap);
/*      */       }
/*      */     }
/* 2504 */     if ((urlPatternsSet) || (dispatchTypesSet)) {
/* 2505 */       Set<FilterMap> fmap = fragment.getFilterMappings();
/* 2506 */       FilterMap descMap = null;
/* 2507 */       for (FilterMap map : fmap) {
/* 2508 */         if (filterName.equals(map.getFilterName())) {
/* 2509 */           descMap = map;
/* 2510 */           break;
/*      */         }
/*      */       }
/* 2513 */       if (descMap != null) {
/* 2514 */         String[] urlsPatterns = descMap.getURLPatterns();
/* 2515 */         if ((urlPatternsSet) && ((urlsPatterns == null) || (urlsPatterns.length == 0)))
/*      */         {
/* 2517 */           for (String urlPattern : filterMap.getURLPatterns()) {
/* 2518 */             descMap.addURLPattern(urlPattern);
/*      */           }
/*      */         }
/* 2521 */         String[] dispatcherNames = descMap.getDispatcherNames();
/* 2522 */         if ((dispatchTypesSet) && ((dispatcherNames == null) || (dispatcherNames.length == 0)))
/*      */         {
/* 2524 */           for (String dis : filterMap.getDispatcherNames()) {
/* 2525 */             descMap.setDispatcher(dis);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected String[] processAnnotationsStringArray(ElementValue ev)
/*      */   {
/* 2534 */     ArrayList<String> values = new ArrayList();
/* 2535 */     if ((ev instanceof ArrayElementValue)) {
/* 2536 */       ElementValue[] arrayValues = ((ArrayElementValue)ev).getElementValuesArray();
/*      */       
/* 2538 */       for (ElementValue value : arrayValues) {
/* 2539 */         values.add(value.stringifyValue());
/*      */       }
/*      */     } else {
/* 2542 */       values.add(ev.stringifyValue());
/*      */     }
/* 2544 */     String[] result = new String[values.size()];
/* 2545 */     return (String[])values.toArray(result);
/*      */   }
/*      */   
/*      */   protected Map<String, String> processAnnotationWebInitParams(ElementValue ev)
/*      */   {
/* 2550 */     Map<String, String> result = new HashMap();
/* 2551 */     if ((ev instanceof ArrayElementValue)) {
/* 2552 */       ElementValue[] arrayValues = ((ArrayElementValue)ev).getElementValuesArray();
/*      */       
/* 2554 */       for (ElementValue value : arrayValues) {
/* 2555 */         if ((value instanceof AnnotationElementValue)) {
/* 2556 */           List<ElementValuePair> evps = ((AnnotationElementValue)value).getAnnotationEntry().getElementValuePairs();
/*      */           
/* 2558 */           String initParamName = null;
/* 2559 */           String initParamValue = null;
/* 2560 */           for (ElementValuePair evp : evps) {
/* 2561 */             if ("name".equals(evp.getNameString())) {
/* 2562 */               initParamName = evp.getValue().stringifyValue();
/* 2563 */             } else if ("value".equals(evp.getNameString())) {
/* 2564 */               initParamValue = evp.getValue().stringifyValue();
/*      */             }
/*      */           }
/*      */           
/*      */ 
/* 2569 */           result.put(initParamName, initParamValue);
/*      */         }
/*      */       }
/*      */     }
/* 2573 */     return result;
/*      */   }
/*      */   
/*      */   private static class DefaultWebXmlCacheEntry
/*      */   {
/*      */     private final WebXml webXml;
/*      */     private final long globalTimeStamp;
/*      */     private final long hostTimeStamp;
/*      */     
/*      */     public DefaultWebXmlCacheEntry(WebXml webXml, long globalTimeStamp, long hostTimeStamp) {
/* 2583 */       this.webXml = webXml;
/* 2584 */       this.globalTimeStamp = globalTimeStamp;
/* 2585 */       this.hostTimeStamp = hostTimeStamp;
/*      */     }
/*      */     
/*      */     public WebXml getWebXml() {
/* 2589 */       return this.webXml;
/*      */     }
/*      */     
/*      */     public long getGlobalTimeStamp() {
/* 2593 */       return this.globalTimeStamp;
/*      */     }
/*      */     
/*      */     public long getHostTimeStamp() {
/* 2597 */       return this.hostTimeStamp;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   static class JavaClassCacheEntry
/*      */   {
/*      */     public final String superclassName;
/*      */     public final String[] interfaceNames;
/* 2606 */     private Set<ServletContainerInitializer> sciSet = null;
/*      */     
/*      */     public JavaClassCacheEntry(JavaClass javaClass) {
/* 2609 */       this.superclassName = javaClass.getSuperclassName();
/* 2610 */       this.interfaceNames = javaClass.getInterfaceNames();
/*      */     }
/*      */     
/*      */     public String getSuperclassName() {
/* 2614 */       return this.superclassName;
/*      */     }
/*      */     
/*      */     public String[] getInterfaceNames() {
/* 2618 */       return this.interfaceNames;
/*      */     }
/*      */     
/*      */     public Set<ServletContainerInitializer> getSciSet() {
/* 2622 */       return this.sciSet;
/*      */     }
/*      */     
/*      */     public void setSciSet(Set<ServletContainerInitializer> sciSet) {
/* 2626 */       this.sciSet = sciSet;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\startup\ContextConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */