/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PasswdUserDatabase
/*     */   implements UserDatabase
/*     */ {
/*     */   private static final String PASSWORD_FILE = "/etc/passwd";
/*  64 */   private final Hashtable<String, String> homes = new Hashtable();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  70 */   private UserConfig userConfig = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UserConfig getUserConfig()
/*     */   {
/*  82 */     return this.userConfig;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserConfig(UserConfig userConfig)
/*     */   {
/*  95 */     this.userConfig = userConfig;
/*  96 */     init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHome(String user)
/*     */   {
/* 112 */     return (String)this.homes.get(user);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Enumeration<String> getUsers()
/*     */   {
/* 123 */     return this.homes.keys();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init()
/*     */   {
/* 136 */     BufferedReader reader = null;
/*     */     try
/*     */     {
/* 139 */       reader = new BufferedReader(new FileReader("/etc/passwd"));
/*     */       
/*     */ 
/*     */       for (;;)
/*     */       {
/* 144 */         StringBuilder buffer = new StringBuilder();
/*     */         for (;;) {
/* 146 */           int ch = reader.read();
/* 147 */           if ((ch < 0) || (ch == 10))
/*     */             break;
/* 149 */           buffer.append((char)ch);
/*     */         }
/* 151 */         String line = buffer.toString();
/* 152 */         if (line.length() < 1) {
/*     */           break;
/*     */         }
/*     */         
/* 156 */         int n = 0;
/* 157 */         String[] tokens = new String[7];
/* 158 */         for (int i = 0; i < tokens.length; i++)
/* 159 */           tokens[i] = null;
/* 160 */         while (n < tokens.length) {
/* 161 */           String token = null;
/* 162 */           int colon = line.indexOf(':');
/* 163 */           if (colon >= 0) {
/* 164 */             token = line.substring(0, colon);
/* 165 */             line = line.substring(colon + 1);
/*     */           } else {
/* 167 */             token = line;
/* 168 */             line = "";
/*     */           }
/* 170 */           tokens[(n++)] = token;
/*     */         }
/*     */         
/*     */ 
/* 174 */         if ((tokens[0] != null) && (tokens[5] != null)) {
/* 175 */           this.homes.put(tokens[0], tokens[5]);
/*     */         }
/*     */       }
/*     */       
/* 179 */       reader.close();
/* 180 */       reader = null;
/*     */     }
/*     */     catch (Exception e) {
/* 183 */       if (reader != null) {
/*     */         try {
/* 185 */           reader.close();
/*     */         }
/*     */         catch (IOException localIOException) {}
/*     */         
/* 189 */         reader = null;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\startup\PasswdUserDatabase.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */