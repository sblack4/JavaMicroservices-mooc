/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.net.ConnectException;
/*     */ import java.net.Socket;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.logging.LogManager;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Server;
/*     */ import org.apache.catalina.security.SecurityConfig;
/*     */ import org.apache.juli.ClassLoaderLogManager;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.digester.Digester;
/*     */ import org.apache.tomcat.util.digester.RuleSet;
/*     */ import org.apache.tomcat.util.log.SystemLogHandler;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Catalina
/*     */ {
/*  76 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.startup");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */   protected boolean await = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  90 */   protected String configFile = "conf/server.xml";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */   protected ClassLoader parentClassLoader = Catalina.class.getClassLoader();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 103 */   protected Server server = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 109 */   protected boolean useShutdownHook = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 115 */   protected Thread shutdownHook = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 121 */   protected boolean useNaming = true;
/*     */   
/*     */ 
/*     */ 
/*     */   public Catalina()
/*     */   {
/* 127 */     setSecurityProtection();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setConfigFile(String file)
/*     */   {
/* 134 */     this.configFile = file;
/*     */   }
/*     */   
/*     */   public String getConfigFile()
/*     */   {
/* 139 */     return this.configFile;
/*     */   }
/*     */   
/*     */   public void setUseShutdownHook(boolean useShutdownHook)
/*     */   {
/* 144 */     this.useShutdownHook = useShutdownHook;
/*     */   }
/*     */   
/*     */   public boolean getUseShutdownHook()
/*     */   {
/* 149 */     return this.useShutdownHook;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParentClassLoader(ClassLoader parentClassLoader)
/*     */   {
/* 159 */     this.parentClassLoader = parentClassLoader;
/*     */   }
/*     */   
/*     */   public ClassLoader getParentClassLoader() {
/* 163 */     if (this.parentClassLoader != null) {
/* 164 */       return this.parentClassLoader;
/*     */     }
/* 166 */     return ClassLoader.getSystemClassLoader();
/*     */   }
/*     */   
/*     */   public void setServer(Server server) {
/* 170 */     this.server = server;
/*     */   }
/*     */   
/*     */   public Server getServer()
/*     */   {
/* 175 */     return this.server;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isUseNaming()
/*     */   {
/* 183 */     return this.useNaming;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUseNaming(boolean useNaming)
/*     */   {
/* 193 */     this.useNaming = useNaming;
/*     */   }
/*     */   
/*     */   public void setAwait(boolean b) {
/* 197 */     this.await = b;
/*     */   }
/*     */   
/*     */   public boolean isAwait() {
/* 201 */     return this.await;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean arguments(String[] args)
/*     */   {
/* 215 */     boolean isConfig = false;
/*     */     
/* 217 */     if (args.length < 1) {
/* 218 */       usage();
/* 219 */       return false;
/*     */     }
/*     */     
/* 222 */     for (int i = 0; i < args.length; i++) {
/* 223 */       if (isConfig) {
/* 224 */         this.configFile = args[i];
/* 225 */         isConfig = false;
/* 226 */       } else if (args[i].equals("-config")) {
/* 227 */         isConfig = true;
/* 228 */       } else if (args[i].equals("-nonaming")) {
/* 229 */         setUseNaming(false);
/* 230 */       } else { if (args[i].equals("-help")) {
/* 231 */           usage();
/* 232 */           return false; }
/* 233 */         if (!args[i].equals("start"))
/*     */         {
/* 235 */           if (!args[i].equals("configtest"))
/*     */           {
/* 237 */             if (!args[i].equals("stop"))
/*     */             {
/*     */ 
/* 240 */               usage();
/* 241 */               return false;
/*     */             } } }
/*     */       }
/*     */     }
/* 245 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected File configFile()
/*     */   {
/* 255 */     File file = new File(this.configFile);
/* 256 */     if (!file.isAbsolute()) {
/* 257 */       file = new File(Bootstrap.getCatalinaBase(), this.configFile);
/*     */     }
/* 259 */     return file;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Digester createStartDigester()
/*     */   {
/* 269 */     long t1 = System.currentTimeMillis();
/*     */     
/* 271 */     Digester digester = new Digester();
/* 272 */     digester.setValidating(false);
/* 273 */     digester.setRulesValidation(true);
/* 274 */     HashMap<Class<?>, List<String>> fakeAttributes = new HashMap();
/* 275 */     ArrayList<String> attrs = new ArrayList();
/* 276 */     attrs.add("className");
/* 277 */     fakeAttributes.put(Object.class, attrs);
/* 278 */     digester.setFakeAttributes(fakeAttributes);
/* 279 */     digester.setUseContextClassLoader(true);
/*     */     
/*     */ 
/* 282 */     digester.addObjectCreate("Server", "org.apache.catalina.core.StandardServer", "className");
/*     */     
/*     */ 
/* 285 */     digester.addSetProperties("Server");
/* 286 */     digester.addSetNext("Server", "setServer", "org.apache.catalina.Server");
/*     */     
/*     */ 
/*     */ 
/* 290 */     digester.addObjectCreate("Server/GlobalNamingResources", "org.apache.catalina.deploy.NamingResourcesImpl");
/*     */     
/* 292 */     digester.addSetProperties("Server/GlobalNamingResources");
/* 293 */     digester.addSetNext("Server/GlobalNamingResources", "setGlobalNamingResources", "org.apache.catalina.deploy.NamingResourcesImpl");
/*     */     
/*     */ 
/*     */ 
/* 297 */     digester.addObjectCreate("Server/Listener", null, "className");
/*     */     
/*     */ 
/* 300 */     digester.addSetProperties("Server/Listener");
/* 301 */     digester.addSetNext("Server/Listener", "addLifecycleListener", "org.apache.catalina.LifecycleListener");
/*     */     
/*     */ 
/*     */ 
/* 305 */     digester.addObjectCreate("Server/Service", "org.apache.catalina.core.StandardService", "className");
/*     */     
/*     */ 
/* 308 */     digester.addSetProperties("Server/Service");
/* 309 */     digester.addSetNext("Server/Service", "addService", "org.apache.catalina.Service");
/*     */     
/*     */ 
/*     */ 
/* 313 */     digester.addObjectCreate("Server/Service/Listener", null, "className");
/*     */     
/*     */ 
/* 316 */     digester.addSetProperties("Server/Service/Listener");
/* 317 */     digester.addSetNext("Server/Service/Listener", "addLifecycleListener", "org.apache.catalina.LifecycleListener");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 322 */     digester.addObjectCreate("Server/Service/Executor", "org.apache.catalina.core.StandardThreadExecutor", "className");
/*     */     
/*     */ 
/* 325 */     digester.addSetProperties("Server/Service/Executor");
/*     */     
/* 327 */     digester.addSetNext("Server/Service/Executor", "addExecutor", "org.apache.catalina.Executor");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 332 */     digester.addRule("Server/Service/Connector", new ConnectorCreateRule());
/*     */     
/* 334 */     digester.addRule("Server/Service/Connector", new SetAllPropertiesRule(new String[] { "executor", "sslImplementationName" }));
/*     */     
/* 336 */     digester.addSetNext("Server/Service/Connector", "addConnector", "org.apache.catalina.connector.Connector");
/*     */     
/*     */ 
/*     */ 
/* 340 */     digester.addObjectCreate("Server/Service/Connector/SSLHostConfig", "org.apache.tomcat.util.net.SSLHostConfig");
/*     */     
/* 342 */     digester.addSetProperties("Server/Service/Connector/SSLHostConfig");
/* 343 */     digester.addSetNext("Server/Service/Connector/SSLHostConfig", "addSslHostConfig", "org.apache.tomcat.util.net.SSLHostConfig");
/*     */     
/*     */ 
/*     */ 
/* 347 */     digester.addRule("Server/Service/Connector/SSLHostConfig/Certificate", new CertificateCreateRule());
/*     */     
/* 349 */     digester.addRule("Server/Service/Connector/SSLHostConfig/Certificate", new SetAllPropertiesRule(new String[] { "type" }));
/*     */     
/* 351 */     digester.addSetNext("Server/Service/Connector/SSLHostConfig/Certificate", "addCertificate", "org.apache.tomcat.util.net.SSLHostConfigCertificate");
/*     */     
/*     */ 
/*     */ 
/* 355 */     digester.addObjectCreate("Server/Service/Connector/Listener", null, "className");
/*     */     
/*     */ 
/* 358 */     digester.addSetProperties("Server/Service/Connector/Listener");
/* 359 */     digester.addSetNext("Server/Service/Connector/Listener", "addLifecycleListener", "org.apache.catalina.LifecycleListener");
/*     */     
/*     */ 
/*     */ 
/* 363 */     digester.addObjectCreate("Server/Service/Connector/UpgradeProtocol", null, "className");
/*     */     
/*     */ 
/* 366 */     digester.addSetProperties("Server/Service/Connector/UpgradeProtocol");
/* 367 */     digester.addSetNext("Server/Service/Connector/UpgradeProtocol", "addUpgradeProtocol", "org.apache.coyote.UpgradeProtocol");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 372 */     digester.addRuleSet(new NamingRuleSet("Server/GlobalNamingResources/"));
/* 373 */     digester.addRuleSet(new EngineRuleSet("Server/Service/"));
/* 374 */     digester.addRuleSet(new HostRuleSet("Server/Service/Engine/"));
/* 375 */     digester.addRuleSet(new ContextRuleSet("Server/Service/Engine/Host/"));
/* 376 */     addClusterRuleSet(digester, "Server/Service/Engine/Host/Cluster/");
/* 377 */     digester.addRuleSet(new NamingRuleSet("Server/Service/Engine/Host/Context/"));
/*     */     
/*     */ 
/* 380 */     digester.addRule("Server/Service/Engine", new SetParentClassLoaderRule(this.parentClassLoader));
/*     */     
/* 382 */     addClusterRuleSet(digester, "Server/Service/Engine/Cluster/");
/*     */     
/* 384 */     long t2 = System.currentTimeMillis();
/* 385 */     if (log.isDebugEnabled()) {
/* 386 */       log.debug("Digester for server.xml created " + (t2 - t1));
/*     */     }
/* 388 */     return digester;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addClusterRuleSet(Digester digester, String prefix)
/*     */   {
/* 396 */     Class<?> clazz = null;
/* 397 */     Constructor<?> constructor = null;
/*     */     try {
/* 399 */       clazz = Class.forName("org.apache.catalina.ha.ClusterRuleSet");
/* 400 */       constructor = clazz.getConstructor(new Class[] { String.class });
/* 401 */       RuleSet ruleSet = (RuleSet)constructor.newInstance(new Object[] { prefix });
/* 402 */       digester.addRuleSet(ruleSet);
/*     */     } catch (Exception e) {
/* 404 */       if (log.isDebugEnabled()) {
/* 405 */         log.debug(sm.getString("catalina.noCluster", new Object[] { e.getClass().getName() + ": " + e.getMessage() }), e);
/*     */       }
/* 407 */       else if (log.isInfoEnabled()) {
/* 408 */         log.info(sm.getString("catalina.noCluster", new Object[] { e.getClass().getName() + ": " + e.getMessage() }));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Digester createStopDigester()
/*     */   {
/* 421 */     Digester digester = new Digester();
/* 422 */     digester.setUseContextClassLoader(true);
/*     */     
/*     */ 
/* 425 */     digester.addObjectCreate("Server", "org.apache.catalina.core.StandardServer", "className");
/*     */     
/*     */ 
/* 428 */     digester.addSetProperties("Server");
/* 429 */     digester.addSetNext("Server", "setServer", "org.apache.catalina.Server");
/*     */     
/*     */ 
/*     */ 
/* 433 */     return digester;
/*     */   }
/*     */   
/*     */ 
/*     */   public void stopServer()
/*     */   {
/* 439 */     stopServer(null);
/*     */   }
/*     */   
/*     */   public void stopServer(String[] arguments)
/*     */   {
/* 444 */     if (arguments != null) {
/* 445 */       arguments(arguments);
/*     */     }
/*     */     
/* 448 */     Server s = getServer();
/* 449 */     File file; Throwable localThrowable4; if (s == null)
/*     */     {
/* 451 */       Digester digester = createStopDigester();
/* 452 */       file = configFile();
/* 453 */       try { FileInputStream fis = new FileInputStream(file);localThrowable4 = null;
/* 454 */         try { InputSource is = new InputSource(file.toURI().toURL().toString());
/*     */           
/* 456 */           is.setByteStream(fis);
/* 457 */           digester.push(this);
/* 458 */           digester.parse(is);
/*     */         }
/*     */         catch (Throwable localThrowable1)
/*     */         {
/* 453 */           localThrowable4 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/*     */ 
/* 459 */           if (fis != null) if (localThrowable4 != null) try { fis.close(); } catch (Throwable x2) { localThrowable4.addSuppressed(x2); } else fis.close();
/* 460 */         } } catch (Exception e) { log.error("Catalina.stop: ", e);
/* 461 */         System.exit(1);
/*     */       }
/*     */     }
/*     */     else {
/*     */       try {
/* 466 */         s.stop();
/*     */       } catch (LifecycleException e) {
/* 468 */         log.error("Catalina.stop: ", e);
/*     */       }
/* 470 */       return;
/*     */     }
/*     */     
/*     */ 
/* 474 */     s = getServer();
/* 475 */     if (s.getPort() > 0) {
/* 476 */       try { Socket socket = new Socket(s.getAddress(), s.getPort());file = null;
/* 477 */         try { OutputStream stream = socket.getOutputStream();localThrowable4 = null;
/* 478 */           try { String shutdown = s.getShutdown();
/* 479 */             for (int i = 0; i < shutdown.length(); i++) {
/* 480 */               stream.write(shutdown.charAt(i));
/*     */             }
/* 482 */             stream.flush();
/*     */           }
/*     */           catch (Throwable localThrowable2)
/*     */           {
/* 476 */             localThrowable4 = localThrowable2;throw localThrowable2; } finally {} } catch (Throwable localThrowable3) { file = localThrowable3;throw localThrowable3;
/*     */ 
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/*     */ 
/* 483 */           if (socket != null) if (file != null) try { socket.close(); } catch (Throwable x2) { file.addSuppressed(x2); } else socket.close();
/* 484 */         } } catch (ConnectException ce) { log.error(sm.getString("catalina.stopServer.connectException", new Object[] { s.getAddress(), String.valueOf(s.getPort()) }));
/*     */         
/*     */ 
/* 487 */         log.error("Catalina.stop: ", ce);
/* 488 */         System.exit(1);
/*     */       } catch (IOException e) {
/* 490 */         log.error("Catalina.stop: ", e);
/* 491 */         System.exit(1);
/*     */       }
/*     */     } else {
/* 494 */       log.error(sm.getString("catalina.stopServer"));
/* 495 */       System.exit(1);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void load()
/*     */   {
/* 505 */     long t1 = System.nanoTime();
/*     */     
/* 507 */     initDirs();
/*     */     
/*     */ 
/* 510 */     initNaming();
/*     */     
/*     */ 
/* 513 */     Digester digester = createStartDigester();
/*     */     
/* 515 */     InputSource inputSource = null;
/* 516 */     InputStream inputStream = null;
/* 517 */     File file = null;
/*     */     try {
/*     */       try {
/* 520 */         file = configFile();
/* 521 */         inputStream = new FileInputStream(file);
/* 522 */         inputSource = new InputSource(file.toURI().toURL().toString());
/*     */       } catch (Exception e) {
/* 524 */         if (log.isDebugEnabled()) {
/* 525 */           log.debug(sm.getString("catalina.configFail", new Object[] { file }), e);
/*     */         }
/*     */       }
/* 528 */       if (inputStream == null) {
/*     */         try {
/* 530 */           inputStream = getClass().getClassLoader().getResourceAsStream(getConfigFile());
/*     */           
/* 532 */           inputSource = new InputSource(getClass().getClassLoader().getResource(getConfigFile()).toString());
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 536 */           if (log.isDebugEnabled()) {
/* 537 */             log.debug(sm.getString("catalina.configFail", new Object[] { getConfigFile() }), e);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 545 */       if (inputStream == null) {
/*     */         try {
/* 547 */           inputStream = getClass().getClassLoader().getResourceAsStream("server-embed.xml");
/*     */           
/* 549 */           inputSource = new InputSource(getClass().getClassLoader().getResource("server-embed.xml").toString());
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 553 */           if (log.isDebugEnabled()) {
/* 554 */             log.debug(sm.getString("catalina.configFail", new Object[] { "server-embed.xml" }), e);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 561 */       if ((inputStream == null) || (inputSource == null)) {
/* 562 */         if (file == null) {
/* 563 */           log.warn(sm.getString("catalina.configFail", new Object[] { getConfigFile() + "] or [server-embed.xml]" }));
/*     */         }
/*     */         else {
/* 566 */           log.warn(sm.getString("catalina.configFail", new Object[] { file.getAbsolutePath() }));
/*     */           
/* 568 */           if ((file.exists()) && (!file.canRead())) {
/* 569 */             log.warn("Permissions incorrect, read permission is not allowed on the file.");
/*     */           }
/*     */         }
/*     */         return;
/*     */       }
/*     */       try
/*     */       {
/* 576 */         inputSource.setByteStream(inputStream);
/* 577 */         digester.push(this);
/* 578 */         digester.parse(inputSource);
/*     */       } catch (SAXParseException spe) {
/* 580 */         log.warn("Catalina.start using " + getConfigFile() + ": " + spe.getMessage()); return;
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 584 */         log.warn("Catalina.start using " + getConfigFile() + ": ", e); return;
/*     */       }
/*     */       
/*     */ 
/* 588 */       if (inputStream != null) {
/*     */         try {
/* 590 */           inputStream.close();
/*     */         }
/*     */         catch (IOException localIOException3) {}
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 597 */       getServer().setCatalina(this);
/*     */     }
/*     */     finally
/*     */     {
/* 588 */       if (inputStream != null) {
/*     */         try {
/* 590 */           inputStream.close();
/*     */         }
/*     */         catch (IOException localIOException4) {}
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 598 */     getServer().setCatalinaHome(Bootstrap.getCatalinaHomeFile());
/* 599 */     getServer().setCatalinaBase(Bootstrap.getCatalinaBaseFile());
/*     */     
/*     */ 
/* 602 */     initStreams();
/*     */     
/*     */     try
/*     */     {
/* 606 */       getServer().init();
/*     */     } catch (LifecycleException e) {
/* 608 */       if (Boolean.getBoolean("org.apache.catalina.startup.EXIT_ON_INIT_FAILURE")) {
/* 609 */         throw new Error(e);
/*     */       }
/* 611 */       log.error("Catalina.start", e);
/*     */     }
/*     */     
/*     */ 
/* 615 */     long t2 = System.nanoTime();
/* 616 */     if (log.isInfoEnabled()) {
/* 617 */       log.info("Initialization processed in " + (t2 - t1) / 1000000L + " ms");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void load(String[] args)
/*     */   {
/*     */     try
/*     */     {
/* 628 */       if (arguments(args)) {
/* 629 */         load();
/*     */       }
/*     */     } catch (Exception e) {
/* 632 */       e.printStackTrace(System.out);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void start()
/*     */   {
/* 642 */     if (getServer() == null) {
/* 643 */       load();
/*     */     }
/*     */     
/* 646 */     if (getServer() == null) {
/* 647 */       log.fatal("Cannot start server. Server instance is not configured.");
/* 648 */       return;
/*     */     }
/*     */     
/* 651 */     long t1 = System.nanoTime();
/*     */     
/*     */     try
/*     */     {
/* 655 */       getServer().start();
/*     */     } catch (LifecycleException e) {
/* 657 */       log.fatal(sm.getString("catalina.serverStartFail"), e);
/*     */       try {
/* 659 */         getServer().destroy();
/*     */       } catch (LifecycleException e1) {
/* 661 */         log.debug("destroy() failed for failed Server ", e1);
/*     */       }
/* 663 */       return;
/*     */     }
/*     */     
/* 666 */     long t2 = System.nanoTime();
/* 667 */     if (log.isInfoEnabled()) {
/* 668 */       log.info("Server startup in " + (t2 - t1) / 1000000L + " ms");
/*     */     }
/*     */     
/*     */ 
/* 672 */     if (this.useShutdownHook) {
/* 673 */       if (this.shutdownHook == null) {
/* 674 */         this.shutdownHook = new CatalinaShutdownHook();
/*     */       }
/* 676 */       Runtime.getRuntime().addShutdownHook(this.shutdownHook);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 681 */       LogManager logManager = LogManager.getLogManager();
/* 682 */       if ((logManager instanceof ClassLoaderLogManager)) {
/* 683 */         ((ClassLoaderLogManager)logManager).setUseShutdownHook(false);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 688 */     if (this.await) {
/* 689 */       await();
/* 690 */       stop();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stop()
/*     */   {
/*     */     try
/*     */     {
/* 703 */       if (this.useShutdownHook) {
/* 704 */         Runtime.getRuntime().removeShutdownHook(this.shutdownHook);
/*     */         
/*     */ 
/*     */ 
/* 708 */         LogManager logManager = LogManager.getLogManager();
/* 709 */         if ((logManager instanceof ClassLoaderLogManager)) {
/* 710 */           ((ClassLoaderLogManager)logManager).setUseShutdownHook(true);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Throwable t) {
/* 715 */       ExceptionUtils.handleThrowable(t);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 722 */       Server s = getServer();
/* 723 */       LifecycleState state = s.getState();
/* 724 */       if ((LifecycleState.STOPPING_PREP.compareTo(state) > 0) || (LifecycleState.DESTROYED.compareTo(state) < 0))
/*     */       {
/*     */ 
/*     */ 
/* 728 */         s.stop();
/* 729 */         s.destroy();
/*     */       }
/*     */     } catch (LifecycleException e) {
/* 732 */       log.error("Catalina.stop", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void await()
/*     */   {
/* 743 */     getServer().await();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void usage()
/*     */   {
/* 753 */     System.out.println("usage: java org.apache.catalina.startup.Catalina [ -config {pathname} ] [ -nonaming ]  { -help | start | stop }");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initDirs()
/*     */   {
/* 763 */     String temp = System.getProperty("java.io.tmpdir");
/* 764 */     if ((temp == null) || (!new File(temp).isDirectory())) {
/* 765 */       log.error(sm.getString("embedded.notmp", new Object[] { temp }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void initStreams()
/*     */   {
/* 772 */     System.setOut(new SystemLogHandler(System.out));
/* 773 */     System.setErr(new SystemLogHandler(System.err));
/*     */   }
/*     */   
/*     */ 
/*     */   protected void initNaming()
/*     */   {
/* 779 */     if (!this.useNaming) {
/* 780 */       log.info("Catalina naming disabled");
/* 781 */       System.setProperty("catalina.useNaming", "false");
/*     */     } else {
/* 783 */       System.setProperty("catalina.useNaming", "true");
/* 784 */       String value = "org.apache.naming";
/* 785 */       String oldValue = System.getProperty("java.naming.factory.url.pkgs");
/*     */       
/* 787 */       if (oldValue != null) {
/* 788 */         value = value + ":" + oldValue;
/*     */       }
/* 790 */       System.setProperty("java.naming.factory.url.pkgs", value);
/* 791 */       if (log.isDebugEnabled()) {
/* 792 */         log.debug("Setting naming prefix=" + value);
/*     */       }
/* 794 */       value = System.getProperty("java.naming.factory.initial");
/*     */       
/* 796 */       if (value == null) {
/* 797 */         System.setProperty("java.naming.factory.initial", "org.apache.naming.java.javaURLContextFactory");
/*     */       }
/*     */       else
/*     */       {
/* 801 */         log.debug("INITIAL_CONTEXT_FACTORY already set " + value);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setSecurityProtection()
/*     */   {
/* 811 */     SecurityConfig securityConfig = SecurityConfig.newInstance();
/* 812 */     securityConfig.setPackageDefinition();
/* 813 */     securityConfig.setPackageAccess();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected class CatalinaShutdownHook
/*     */     extends Thread
/*     */   {
/*     */     protected CatalinaShutdownHook() {}
/*     */     
/*     */ 
/*     */     public void run()
/*     */     {
/*     */       try
/*     */       {
/* 828 */         if (Catalina.this.getServer() != null)
/* 829 */           Catalina.this.stop();
/*     */       } catch (Throwable ex) {
/*     */         LogManager logManager;
/* 832 */         ExceptionUtils.handleThrowable(ex);
/* 833 */         Catalina.log.error(Catalina.sm.getString("catalina.shutdownHookFail"), ex);
/*     */       }
/*     */       finally {
/*     */         LogManager logManager;
/* 837 */         LogManager logManager = LogManager.getLogManager();
/* 838 */         if ((logManager instanceof ClassLoaderLogManager)) {
/* 839 */           ((ClassLoaderLogManager)logManager).shutdown();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/* 846 */   private static final Log log = LogFactory.getLog(Catalina.class);
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\startup\Catalina.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */