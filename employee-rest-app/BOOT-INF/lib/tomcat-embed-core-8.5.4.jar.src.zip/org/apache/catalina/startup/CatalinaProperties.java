/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CatalinaProperties
/*     */ {
/*  38 */   private static final Log log = LogFactory.getLog(CatalinaProperties.class);
/*     */   
/*  40 */   private static Properties properties = null;
/*     */   
/*     */   static
/*     */   {
/*  44 */     loadProperties();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getProperty(String name)
/*     */   {
/*  53 */     return properties.getProperty(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void loadProperties()
/*     */   {
/*  62 */     InputStream is = null;
/*  63 */     Throwable error = null;
/*     */     try
/*     */     {
/*  66 */       String configUrl = System.getProperty("catalina.config");
/*  67 */       if (configUrl != null) {
/*  68 */         is = new URL(configUrl).openStream();
/*     */       }
/*     */     } catch (Throwable t) {
/*  71 */       handleThrowable(t);
/*     */     }
/*     */     
/*  74 */     if (is == null) {
/*     */       try {
/*  76 */         File home = new File(Bootstrap.getCatalinaBase());
/*  77 */         File conf = new File(home, "conf");
/*  78 */         File propsFile = new File(conf, "catalina.properties");
/*  79 */         is = new FileInputStream(propsFile);
/*     */       } catch (Throwable t) {
/*  81 */         handleThrowable(t);
/*     */       }
/*     */     }
/*     */     
/*  85 */     if (is == null) {
/*     */       try {
/*  87 */         is = CatalinaProperties.class.getResourceAsStream("/org/apache/catalina/startup/catalina.properties");
/*     */       }
/*     */       catch (Throwable t) {
/*  90 */         handleThrowable(t);
/*     */       }
/*     */     }
/*     */     
/*  94 */     if (is != null) {
/*     */       try {
/*  96 */         properties = new Properties();
/*  97 */         properties.load(is);
/*     */         
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/* 103 */           is.close();
/*     */         } catch (IOException ioe) {
/* 105 */           log.warn("Could not close catalina.properties", ioe);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 110 */         if (is == null) {
/*     */           break label217;
/*     */         }
/*     */       }
/*     */       catch (Throwable t)
/*     */       {
/*  99 */         handleThrowable(t);
/* 100 */         error = t;
/*     */       } finally {
/*     */         try {
/* 103 */           is.close();
/*     */         } catch (IOException ioe) {
/* 105 */           log.warn("Could not close catalina.properties", ioe);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 110 */     if (error != null) {
/*     */       label217:
/* 112 */       log.warn("Failed to load catalina.properties", error);
/*     */       
/* 114 */       properties = new Properties();
/*     */     }
/*     */     
/*     */ 
/* 118 */     Enumeration<?> enumeration = properties.propertyNames();
/* 119 */     while (enumeration.hasMoreElements()) {
/* 120 */       String name = (String)enumeration.nextElement();
/* 121 */       String value = properties.getProperty(name);
/* 122 */       if (value != null) {
/* 123 */         System.setProperty(name, value);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static void handleThrowable(Throwable t)
/*     */   {
/* 131 */     if ((t instanceof ThreadDeath)) {
/* 132 */       throw ((ThreadDeath)t);
/*     */     }
/* 134 */     if ((t instanceof VirtualMachineError)) {
/* 135 */       throw ((VirtualMachineError)t);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\startup\CatalinaProperties.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */