/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Lifecycle;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.Realm;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.ietf.jgss.GSSContext;
/*     */ import org.ietf.jgss.GSSException;
/*     */ import org.ietf.jgss.GSSName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CombinedRealm
/*     */   extends RealmBase
/*     */ {
/*  46 */   private static final Log log = LogFactory.getLog(CombinedRealm.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  51 */   protected final List<Realm> realms = new LinkedList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static final String name = "CombinedRealm";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addRealm(Realm theRealm)
/*     */   {
/*  64 */     this.realms.add(theRealm);
/*     */     
/*  66 */     if (log.isDebugEnabled()) {
/*  67 */       sm.getString("combinedRealm.addRealm", new Object[] { theRealm.getClass().getName(), Integer.toString(this.realms.size()) });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName[] getRealms()
/*     */   {
/*  78 */     ObjectName[] result = new ObjectName[this.realms.size()];
/*  79 */     for (Realm realm : this.realms) {
/*  80 */       if ((realm instanceof RealmBase)) {
/*  81 */         result[this.realms.indexOf(realm)] = ((RealmBase)realm).getObjectName();
/*     */       }
/*     */     }
/*     */     
/*  85 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Realm[] getNestedRealms()
/*     */   {
/*  92 */     return (Realm[])this.realms.toArray(new Realm[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal authenticate(String username, String clientDigest, String nonce, String nc, String cnonce, String qop, String realmName, String md5a2)
/*     */   {
/* 112 */     Principal authenticatedUser = null;
/*     */     
/* 114 */     for (Realm realm : this.realms) {
/* 115 */       if (log.isDebugEnabled()) {
/* 116 */         log.debug(sm.getString("combinedRealm.authStart", new Object[] { username, realm.getClass().getName() }));
/*     */       }
/*     */       
/*     */ 
/* 120 */       authenticatedUser = realm.authenticate(username, clientDigest, nonce, nc, cnonce, qop, realmName, md5a2);
/*     */       
/*     */ 
/* 123 */       if (authenticatedUser == null) {
/* 124 */         if (log.isDebugEnabled()) {
/* 125 */           log.debug(sm.getString("combinedRealm.authFail", new Object[] { username, realm.getClass().getName() }));
/*     */         }
/*     */       }
/*     */       else {
/* 129 */         if (!log.isDebugEnabled()) break;
/* 130 */         log.debug(sm.getString("combinedRealm.authSuccess", new Object[] { username, realm.getClass().getName() })); break;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 136 */     return authenticatedUser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal authenticate(String username)
/*     */   {
/* 148 */     Principal authenticatedUser = null;
/*     */     
/* 150 */     for (Realm realm : this.realms) {
/* 151 */       if (log.isDebugEnabled()) {
/* 152 */         log.debug(sm.getString("combinedRealm.authStart", new Object[] { username, realm.getClass().getName() }));
/*     */       }
/*     */       
/*     */ 
/* 156 */       authenticatedUser = realm.authenticate(username);
/*     */       
/* 158 */       if (authenticatedUser == null) {
/* 159 */         if (log.isDebugEnabled()) {
/* 160 */           log.debug(sm.getString("combinedRealm.authFail", new Object[] { username, realm.getClass().getName() }));
/*     */         }
/*     */       }
/*     */       else {
/* 164 */         if (!log.isDebugEnabled()) break;
/* 165 */         log.debug(sm.getString("combinedRealm.authSuccess", new Object[] { username, realm.getClass().getName() })); break;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 171 */     return authenticatedUser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal authenticate(String username, String credentials)
/*     */   {
/* 185 */     Principal authenticatedUser = null;
/*     */     
/* 187 */     for (Realm realm : this.realms) {
/* 188 */       if (log.isDebugEnabled()) {
/* 189 */         log.debug(sm.getString("combinedRealm.authStart", new Object[] { username, realm.getClass().getName() }));
/*     */       }
/*     */       
/*     */ 
/* 193 */       authenticatedUser = realm.authenticate(username, credentials);
/*     */       
/* 195 */       if (authenticatedUser == null) {
/* 196 */         if (log.isDebugEnabled()) {
/* 197 */           log.debug(sm.getString("combinedRealm.authFail", new Object[] { username, realm.getClass().getName() }));
/*     */         }
/*     */       }
/*     */       else {
/* 201 */         if (!log.isDebugEnabled()) break;
/* 202 */         log.debug(sm.getString("combinedRealm.authSuccess", new Object[] { username, realm.getClass().getName() })); break;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 208 */     return authenticatedUser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContainer(Container container)
/*     */   {
/* 219 */     for (Realm realm : this.realms)
/*     */     {
/* 221 */       if ((realm instanceof RealmBase)) {
/* 222 */         ((RealmBase)realm).setRealmPath(getRealmPath() + "/realm" + this.realms.indexOf(realm));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 227 */       realm.setContainer(container);
/*     */     }
/* 229 */     super.setContainer(container);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 244 */     Iterator<Realm> iter = this.realms.iterator();
/*     */     
/* 246 */     while (iter.hasNext()) {
/* 247 */       Realm realm = (Realm)iter.next();
/* 248 */       if ((realm instanceof Lifecycle)) {
/*     */         try {
/* 250 */           ((Lifecycle)realm).start();
/*     */         }
/*     */         catch (LifecycleException e) {
/* 253 */           iter.remove();
/* 254 */           log.error(sm.getString("combinedRealm.realmStartFail", new Object[] { realm.getClass().getName() }), e);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 259 */     super.startInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void stopInternal()
/*     */     throws LifecycleException
/*     */   {
/* 274 */     super.stopInternal();
/* 275 */     for (Realm realm : this.realms) {
/* 276 */       if ((realm instanceof Lifecycle)) {
/* 277 */         ((Lifecycle)realm).stop();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void destroyInternal()
/*     */     throws LifecycleException
/*     */   {
/* 288 */     for (Realm realm : this.realms) {
/* 289 */       if ((realm instanceof Lifecycle)) {
/* 290 */         ((Lifecycle)realm).destroy();
/*     */       }
/*     */     }
/* 293 */     super.destroyInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void backgroundProcess()
/*     */   {
/* 301 */     super.backgroundProcess();
/*     */     
/* 303 */     for (Realm r : this.realms) {
/* 304 */       r.backgroundProcess();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal authenticate(X509Certificate[] certs)
/*     */   {
/* 317 */     Principal authenticatedUser = null;
/* 318 */     String username = null;
/* 319 */     if ((certs != null) && (certs.length > 0)) {
/* 320 */       username = certs[0].getSubjectDN().getName();
/*     */     }
/*     */     
/* 323 */     for (Realm realm : this.realms) {
/* 324 */       if (log.isDebugEnabled()) {
/* 325 */         log.debug(sm.getString("combinedRealm.authStart", new Object[] { username, realm.getClass().getName() }));
/*     */       }
/*     */       
/*     */ 
/* 329 */       authenticatedUser = realm.authenticate(certs);
/*     */       
/* 331 */       if (authenticatedUser == null) {
/* 332 */         if (log.isDebugEnabled()) {
/* 333 */           log.debug(sm.getString("combinedRealm.authFail", new Object[] { username, realm.getClass().getName() }));
/*     */         }
/*     */       }
/*     */       else {
/* 337 */         if (!log.isDebugEnabled()) break;
/* 338 */         log.debug(sm.getString("combinedRealm.authSuccess", new Object[] { username, realm.getClass().getName() })); break;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 344 */     return authenticatedUser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal authenticate(GSSContext gssContext, boolean storeCreds)
/*     */   {
/* 352 */     if (gssContext.isEstablished()) {
/* 353 */       Principal authenticatedUser = null;
/* 354 */       String username = null;
/*     */       
/* 356 */       GSSName name = null;
/*     */       try {
/* 358 */         name = gssContext.getSrcName();
/*     */       } catch (GSSException e) {
/* 360 */         log.warn(sm.getString("realmBase.gssNameFail"), e);
/* 361 */         return null;
/*     */       }
/*     */       
/* 364 */       username = name.toString();
/*     */       
/* 366 */       for (Realm realm : this.realms) {
/* 367 */         if (log.isDebugEnabled()) {
/* 368 */           log.debug(sm.getString("combinedRealm.authStart", new Object[] { username, realm.getClass().getName() }));
/*     */         }
/*     */         
/*     */ 
/* 372 */         authenticatedUser = realm.authenticate(gssContext, storeCreds);
/*     */         
/* 374 */         if (authenticatedUser == null) {
/* 375 */           if (log.isDebugEnabled()) {
/* 376 */             log.debug(sm.getString("combinedRealm.authFail", new Object[] { username, realm.getClass().getName() }));
/*     */           }
/*     */         }
/*     */         else {
/* 380 */           if (!log.isDebugEnabled()) break;
/* 381 */           log.debug(sm.getString("combinedRealm.authSuccess", new Object[] { username, realm.getClass().getName() })); break;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 387 */       return authenticatedUser;
/*     */     }
/*     */     
/*     */ 
/* 391 */     return null;
/*     */   }
/*     */   
/*     */   protected String getName()
/*     */   {
/* 396 */     return "CombinedRealm";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String getPassword(String username)
/*     */   {
/* 403 */     UnsupportedOperationException uoe = new UnsupportedOperationException(sm.getString("combinedRealm.getPassword"));
/*     */     
/*     */ 
/* 406 */     log.error(sm.getString("combinedRealm.unexpectedMethod"), uoe);
/* 407 */     throw uoe;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Principal getPrincipal(String username)
/*     */   {
/* 414 */     UnsupportedOperationException uoe = new UnsupportedOperationException(sm.getString("combinedRealm.getPrincipal"));
/*     */     
/*     */ 
/* 417 */     log.error(sm.getString("combinedRealm.unexpectedMethod"), uoe);
/* 418 */     throw uoe;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\realm\CombinedRealm.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */