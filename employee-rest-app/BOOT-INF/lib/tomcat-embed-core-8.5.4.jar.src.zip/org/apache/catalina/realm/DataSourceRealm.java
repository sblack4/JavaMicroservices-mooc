/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import javax.naming.Context;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.catalina.CredentialHandler;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.Server;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.naming.ContextBindings;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSourceRealm
/*     */   extends RealmBase
/*     */ {
/*  53 */   private String preparedRoles = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  59 */   private String preparedCredentials = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  65 */   protected String dataSourceName = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  71 */   protected boolean localDataSource = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static final String name = "DataSourceRealm";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */   protected String roleNameCol = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  89 */   protected String userCredCol = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  95 */   protected String userNameCol = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */   protected String userRoleTable = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */   protected String userTable = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDataSourceName()
/*     */   {
/* 117 */     return this.dataSourceName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDataSourceName(String dataSourceName)
/*     */   {
/* 126 */     this.dataSourceName = dataSourceName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean getLocalDataSource()
/*     */   {
/* 133 */     return this.localDataSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocalDataSource(boolean localDataSource)
/*     */   {
/* 143 */     this.localDataSource = localDataSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getRoleNameCol()
/*     */   {
/* 150 */     return this.roleNameCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRoleNameCol(String roleNameCol)
/*     */   {
/* 159 */     this.roleNameCol = roleNameCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getUserCredCol()
/*     */   {
/* 166 */     return this.userCredCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserCredCol(String userCredCol)
/*     */   {
/* 175 */     this.userCredCol = userCredCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getUserNameCol()
/*     */   {
/* 182 */     return this.userNameCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserNameCol(String userNameCol)
/*     */   {
/* 191 */     this.userNameCol = userNameCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getUserRoleTable()
/*     */   {
/* 198 */     return this.userRoleTable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserRoleTable(String userRoleTable)
/*     */   {
/* 207 */     this.userRoleTable = userRoleTable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getUserTable()
/*     */   {
/* 214 */     return this.userTable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserTable(String userTable)
/*     */   {
/* 223 */     this.userTable = userTable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal authenticate(String username, String credentials)
/*     */   {
/* 248 */     if ((username == null) || (credentials == null)) {
/* 249 */       return null;
/*     */     }
/*     */     
/* 252 */     Connection dbConnection = null;
/*     */     
/*     */ 
/* 255 */     dbConnection = open();
/* 256 */     if (dbConnection == null)
/*     */     {
/* 258 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 264 */       return authenticate(dbConnection, username, credentials);
/*     */     }
/*     */     finally
/*     */     {
/* 268 */       close(dbConnection);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Principal authenticate(Connection dbConnection, String username, String credentials)
/*     */   {
/* 293 */     String dbCredentials = getPassword(dbConnection, username);
/*     */     
/* 295 */     if ((credentials == null) || (dbCredentials == null)) {
/* 296 */       if (this.containerLog.isTraceEnabled()) {
/* 297 */         this.containerLog.trace(sm.getString("dataSourceRealm.authenticateFailure", new Object[] { username }));
/*     */       }
/*     */       
/* 300 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 304 */     boolean validated = getCredentialHandler().matches(credentials, dbCredentials);
/*     */     
/* 306 */     if (validated) {
/* 307 */       if (this.containerLog.isTraceEnabled()) {
/* 308 */         this.containerLog.trace(sm.getString("dataSourceRealm.authenticateSuccess", new Object[] { username }));
/*     */       }
/*     */     }
/*     */     else {
/* 312 */       if (this.containerLog.isTraceEnabled()) {
/* 313 */         this.containerLog.trace(sm.getString("dataSourceRealm.authenticateFailure", new Object[] { username }));
/*     */       }
/*     */       
/* 316 */       return null;
/*     */     }
/*     */     
/* 319 */     ArrayList<String> list = getRoles(dbConnection, username);
/*     */     
/*     */ 
/* 322 */     return new GenericPrincipal(username, credentials, list);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void close(Connection dbConnection)
/*     */   {
/* 334 */     if (dbConnection == null) {
/* 335 */       return;
/*     */     }
/*     */     try
/*     */     {
/* 339 */       if (!dbConnection.getAutoCommit()) {
/* 340 */         dbConnection.commit();
/*     */       }
/*     */     } catch (SQLException e) {
/* 343 */       this.containerLog.error("Exception committing connection before closing:", e);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 348 */       dbConnection.close();
/*     */     } catch (SQLException e) {
/* 350 */       this.containerLog.error(sm.getString("dataSourceRealm.close"), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Connection open()
/*     */   {
/*     */     try
/*     */     {
/* 363 */       Context context = null;
/* 364 */       if (this.localDataSource) {
/* 365 */         context = ContextBindings.getClassLoader();
/* 366 */         context = (Context)context.lookup("comp/env");
/*     */       } else {
/* 368 */         context = getServer().getGlobalNamingContext();
/*     */       }
/* 370 */       DataSource dataSource = (DataSource)context.lookup(this.dataSourceName);
/* 371 */       return dataSource.getConnection();
/*     */     }
/*     */     catch (Exception e) {
/* 374 */       this.containerLog.error(sm.getString("dataSourceRealm.exception"), e);
/*     */     }
/* 376 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getName()
/*     */   {
/* 385 */     return "DataSourceRealm";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getPassword(String username)
/*     */   {
/* 395 */     Connection dbConnection = null;
/*     */     
/*     */ 
/* 398 */     dbConnection = open();
/* 399 */     if (dbConnection == null) {
/* 400 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 404 */       return getPassword(dbConnection, username);
/*     */     } finally {
/* 406 */       close(dbConnection);
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected String getPassword(Connection dbConnection, String username)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_3
/*     */     //   2: aload_0
/*     */     //   3: aload_1
/*     */     //   4: aload_2
/*     */     //   5: invokespecial 47	org/apache/catalina/realm/DataSourceRealm:credentials	(Ljava/sql/Connection;Ljava/lang/String;)Ljava/sql/PreparedStatement;
/*     */     //   8: astore 4
/*     */     //   10: aconst_null
/*     */     //   11: astore 5
/*     */     //   13: aload 4
/*     */     //   15: invokeinterface 48 1 0
/*     */     //   20: astore 6
/*     */     //   22: aconst_null
/*     */     //   23: astore 7
/*     */     //   25: aload 6
/*     */     //   27: invokeinterface 49 1 0
/*     */     //   32: ifeq +12 -> 44
/*     */     //   35: aload 6
/*     */     //   37: iconst_1
/*     */     //   38: invokeinterface 50 2 0
/*     */     //   43: astore_3
/*     */     //   44: aload_3
/*     */     //   45: ifnull +10 -> 55
/*     */     //   48: aload_3
/*     */     //   49: invokevirtual 51	java/lang/String:trim	()Ljava/lang/String;
/*     */     //   52: goto +4 -> 56
/*     */     //   55: aconst_null
/*     */     //   56: astore 8
/*     */     //   58: aload 6
/*     */     //   60: ifnull +37 -> 97
/*     */     //   63: aload 7
/*     */     //   65: ifnull +25 -> 90
/*     */     //   68: aload 6
/*     */     //   70: invokeinterface 52 1 0
/*     */     //   75: goto +22 -> 97
/*     */     //   78: astore 9
/*     */     //   80: aload 7
/*     */     //   82: aload 9
/*     */     //   84: invokevirtual 54	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   87: goto +10 -> 97
/*     */     //   90: aload 6
/*     */     //   92: invokeinterface 52 1 0
/*     */     //   97: aload 4
/*     */     //   99: ifnull +37 -> 136
/*     */     //   102: aload 5
/*     */     //   104: ifnull +25 -> 129
/*     */     //   107: aload 4
/*     */     //   109: invokeinterface 55 1 0
/*     */     //   114: goto +22 -> 136
/*     */     //   117: astore 9
/*     */     //   119: aload 5
/*     */     //   121: aload 9
/*     */     //   123: invokevirtual 54	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   126: goto +10 -> 136
/*     */     //   129: aload 4
/*     */     //   131: invokeinterface 55 1 0
/*     */     //   136: aload 8
/*     */     //   138: areturn
/*     */     //   139: astore 8
/*     */     //   141: aload 8
/*     */     //   143: astore 7
/*     */     //   145: aload 8
/*     */     //   147: athrow
/*     */     //   148: astore 10
/*     */     //   150: aload 6
/*     */     //   152: ifnull +37 -> 189
/*     */     //   155: aload 7
/*     */     //   157: ifnull +25 -> 182
/*     */     //   160: aload 6
/*     */     //   162: invokeinterface 52 1 0
/*     */     //   167: goto +22 -> 189
/*     */     //   170: astore 11
/*     */     //   172: aload 7
/*     */     //   174: aload 11
/*     */     //   176: invokevirtual 54	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   179: goto +10 -> 189
/*     */     //   182: aload 6
/*     */     //   184: invokeinterface 52 1 0
/*     */     //   189: aload 10
/*     */     //   191: athrow
/*     */     //   192: astore 6
/*     */     //   194: aload 6
/*     */     //   196: astore 5
/*     */     //   198: aload 6
/*     */     //   200: athrow
/*     */     //   201: astore 12
/*     */     //   203: aload 4
/*     */     //   205: ifnull +37 -> 242
/*     */     //   208: aload 5
/*     */     //   210: ifnull +25 -> 235
/*     */     //   213: aload 4
/*     */     //   215: invokeinterface 55 1 0
/*     */     //   220: goto +22 -> 242
/*     */     //   223: astore 13
/*     */     //   225: aload 5
/*     */     //   227: aload 13
/*     */     //   229: invokevirtual 54	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   232: goto +10 -> 242
/*     */     //   235: aload 4
/*     */     //   237: invokeinterface 55 1 0
/*     */     //   242: aload 12
/*     */     //   244: athrow
/*     */     //   245: astore 4
/*     */     //   247: aload_0
/*     */     //   248: getfield 15	org/apache/catalina/realm/DataSourceRealm:containerLog	Lorg/apache/juli/logging/Log;
/*     */     //   251: getstatic 17	org/apache/catalina/realm/DataSourceRealm:sm	Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   254: ldc 56
/*     */     //   256: iconst_1
/*     */     //   257: anewarray 19	java/lang/Object
/*     */     //   260: dup
/*     */     //   261: iconst_0
/*     */     //   262: aload_2
/*     */     //   263: aastore
/*     */     //   264: invokevirtual 20	org/apache/tomcat/util/res/StringManager:getString	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   267: aload 4
/*     */     //   269: invokeinterface 32 3 0
/*     */     //   274: aconst_null
/*     */     //   275: areturn
/*     */     // Line number table:
/*     */     //   Java source line #419	-> byte code offset #0
/*     */     //   Java source line #421	-> byte code offset #2
/*     */     //   Java source line #422	-> byte code offset #13
/*     */     //   Java source line #421	-> byte code offset #22
/*     */     //   Java source line #423	-> byte code offset #25
/*     */     //   Java source line #424	-> byte code offset #35
/*     */     //   Java source line #427	-> byte code offset #44
/*     */     //   Java source line #429	-> byte code offset #58
/*     */     //   Java source line #421	-> byte code offset #139
/*     */     //   Java source line #429	-> byte code offset #148
/*     */     //   Java source line #421	-> byte code offset #192
/*     */     //   Java source line #429	-> byte code offset #201
/*     */     //   Java source line #430	-> byte code offset #247
/*     */     //   Java source line #435	-> byte code offset #274
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	276	0	this	DataSourceRealm
/*     */     //   0	276	1	dbConnection	Connection
/*     */     //   0	276	2	username	String
/*     */     //   1	48	3	dbCredentials	String
/*     */     //   8	228	4	stmt	PreparedStatement
/*     */     //   245	23	4	e	SQLException
/*     */     //   11	215	5	localThrowable3	Throwable
/*     */     //   20	163	6	rs	java.sql.ResultSet
/*     */     //   192	7	6	localThrowable2	Throwable
/*     */     //   23	150	7	localThrowable4	Throwable
/*     */     //   139	7	8	localThrowable1	Throwable
/*     */     //   139	7	8	localThrowable5	Throwable
/*     */     //   78	5	9	x2	Throwable
/*     */     //   117	5	9	x2	Throwable
/*     */     //   148	42	10	localObject1	Object
/*     */     //   170	5	11	x2	Throwable
/*     */     //   201	42	12	localObject2	Object
/*     */     //   223	5	13	x2	Throwable
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   68	75	78	java/lang/Throwable
/*     */     //   107	114	117	java/lang/Throwable
/*     */     //   25	58	139	java/lang/Throwable
/*     */     //   25	58	148	finally
/*     */     //   139	150	148	finally
/*     */     //   160	167	170	java/lang/Throwable
/*     */     //   13	97	192	java/lang/Throwable
/*     */     //   139	192	192	java/lang/Throwable
/*     */     //   13	97	201	finally
/*     */     //   139	203	201	finally
/*     */     //   213	220	223	java/lang/Throwable
/*     */     //   2	136	245	java/sql/SQLException
/*     */     //   139	245	245	java/sql/SQLException
/*     */   }
/*     */   
/*     */   protected Principal getPrincipal(String username)
/*     */   {
/* 446 */     Connection dbConnection = open();
/* 447 */     if (dbConnection == null) {
/* 448 */       return new GenericPrincipal(username, null, null);
/*     */     }
/*     */     try {
/* 451 */       return new GenericPrincipal(username, getPassword(dbConnection, username), getRoles(dbConnection, username));
/*     */     }
/*     */     finally
/*     */     {
/* 455 */       close(dbConnection);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ArrayList<String> getRoles(String username)
/*     */   {
/* 467 */     Connection dbConnection = null;
/*     */     
/*     */ 
/* 470 */     dbConnection = open();
/* 471 */     if (dbConnection == null) {
/* 472 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 476 */       return getRoles(dbConnection, username);
/*     */     } finally {
/* 478 */       close(dbConnection);
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected ArrayList<String> getRoles(Connection dbConnection, String username)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 57	org/apache/catalina/realm/DataSourceRealm:allRolesMode	Lorg/apache/catalina/realm/RealmBase$AllRolesMode;
/*     */     //   4: getstatic 58	org/apache/catalina/realm/RealmBase$AllRolesMode:STRICT_MODE	Lorg/apache/catalina/realm/RealmBase$AllRolesMode;
/*     */     //   7: if_acmpeq +12 -> 19
/*     */     //   10: aload_0
/*     */     //   11: invokespecial 59	org/apache/catalina/realm/DataSourceRealm:isRoleStoreDefined	()Z
/*     */     //   14: ifne +5 -> 19
/*     */     //   17: aconst_null
/*     */     //   18: areturn
/*     */     //   19: aconst_null
/*     */     //   20: astore_3
/*     */     //   21: aload_0
/*     */     //   22: aload_1
/*     */     //   23: aload_2
/*     */     //   24: invokespecial 60	org/apache/catalina/realm/DataSourceRealm:roles	(Ljava/sql/Connection;Ljava/lang/String;)Ljava/sql/PreparedStatement;
/*     */     //   27: astore 4
/*     */     //   29: aconst_null
/*     */     //   30: astore 5
/*     */     //   32: aload 4
/*     */     //   34: invokeinterface 48 1 0
/*     */     //   39: astore 6
/*     */     //   41: aconst_null
/*     */     //   42: astore 7
/*     */     //   44: new 61	java/util/ArrayList
/*     */     //   47: dup
/*     */     //   48: invokespecial 62	java/util/ArrayList:<init>	()V
/*     */     //   51: astore_3
/*     */     //   52: aload 6
/*     */     //   54: invokeinterface 49 1 0
/*     */     //   59: ifeq +31 -> 90
/*     */     //   62: aload 6
/*     */     //   64: iconst_1
/*     */     //   65: invokeinterface 50 2 0
/*     */     //   70: astore 8
/*     */     //   72: aload 8
/*     */     //   74: ifnull +13 -> 87
/*     */     //   77: aload_3
/*     */     //   78: aload 8
/*     */     //   80: invokevirtual 51	java/lang/String:trim	()Ljava/lang/String;
/*     */     //   83: invokevirtual 63	java/util/ArrayList:add	(Ljava/lang/Object;)Z
/*     */     //   86: pop
/*     */     //   87: goto -35 -> 52
/*     */     //   90: aload_3
/*     */     //   91: astore 8
/*     */     //   93: aload 6
/*     */     //   95: ifnull +37 -> 132
/*     */     //   98: aload 7
/*     */     //   100: ifnull +25 -> 125
/*     */     //   103: aload 6
/*     */     //   105: invokeinterface 52 1 0
/*     */     //   110: goto +22 -> 132
/*     */     //   113: astore 9
/*     */     //   115: aload 7
/*     */     //   117: aload 9
/*     */     //   119: invokevirtual 54	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   122: goto +10 -> 132
/*     */     //   125: aload 6
/*     */     //   127: invokeinterface 52 1 0
/*     */     //   132: aload 4
/*     */     //   134: ifnull +37 -> 171
/*     */     //   137: aload 5
/*     */     //   139: ifnull +25 -> 164
/*     */     //   142: aload 4
/*     */     //   144: invokeinterface 55 1 0
/*     */     //   149: goto +22 -> 171
/*     */     //   152: astore 9
/*     */     //   154: aload 5
/*     */     //   156: aload 9
/*     */     //   158: invokevirtual 54	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   161: goto +10 -> 171
/*     */     //   164: aload 4
/*     */     //   166: invokeinterface 55 1 0
/*     */     //   171: aload 8
/*     */     //   173: areturn
/*     */     //   174: astore 8
/*     */     //   176: aload 8
/*     */     //   178: astore 7
/*     */     //   180: aload 8
/*     */     //   182: athrow
/*     */     //   183: astore 10
/*     */     //   185: aload 6
/*     */     //   187: ifnull +37 -> 224
/*     */     //   190: aload 7
/*     */     //   192: ifnull +25 -> 217
/*     */     //   195: aload 6
/*     */     //   197: invokeinterface 52 1 0
/*     */     //   202: goto +22 -> 224
/*     */     //   205: astore 11
/*     */     //   207: aload 7
/*     */     //   209: aload 11
/*     */     //   211: invokevirtual 54	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   214: goto +10 -> 224
/*     */     //   217: aload 6
/*     */     //   219: invokeinterface 52 1 0
/*     */     //   224: aload 10
/*     */     //   226: athrow
/*     */     //   227: astore 6
/*     */     //   229: aload 6
/*     */     //   231: astore 5
/*     */     //   233: aload 6
/*     */     //   235: athrow
/*     */     //   236: astore 12
/*     */     //   238: aload 4
/*     */     //   240: ifnull +37 -> 277
/*     */     //   243: aload 5
/*     */     //   245: ifnull +25 -> 270
/*     */     //   248: aload 4
/*     */     //   250: invokeinterface 55 1 0
/*     */     //   255: goto +22 -> 277
/*     */     //   258: astore 13
/*     */     //   260: aload 5
/*     */     //   262: aload 13
/*     */     //   264: invokevirtual 54	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   267: goto +10 -> 277
/*     */     //   270: aload 4
/*     */     //   272: invokeinterface 55 1 0
/*     */     //   277: aload 12
/*     */     //   279: athrow
/*     */     //   280: astore 4
/*     */     //   282: aload_0
/*     */     //   283: getfield 15	org/apache/catalina/realm/DataSourceRealm:containerLog	Lorg/apache/juli/logging/Log;
/*     */     //   286: getstatic 17	org/apache/catalina/realm/DataSourceRealm:sm	Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   289: ldc 64
/*     */     //   291: iconst_1
/*     */     //   292: anewarray 19	java/lang/Object
/*     */     //   295: dup
/*     */     //   296: iconst_0
/*     */     //   297: aload_2
/*     */     //   298: aastore
/*     */     //   299: invokevirtual 20	org/apache/tomcat/util/res/StringManager:getString	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   302: aload 4
/*     */     //   304: invokeinterface 32 3 0
/*     */     //   309: aconst_null
/*     */     //   310: areturn
/*     */     // Line number table:
/*     */     //   Java source line #491	-> byte code offset #0
/*     */     //   Java source line #494	-> byte code offset #17
/*     */     //   Java source line #497	-> byte code offset #19
/*     */     //   Java source line #499	-> byte code offset #21
/*     */     //   Java source line #500	-> byte code offset #32
/*     */     //   Java source line #499	-> byte code offset #41
/*     */     //   Java source line #501	-> byte code offset #44
/*     */     //   Java source line #503	-> byte code offset #52
/*     */     //   Java source line #504	-> byte code offset #62
/*     */     //   Java source line #505	-> byte code offset #72
/*     */     //   Java source line #506	-> byte code offset #77
/*     */     //   Java source line #508	-> byte code offset #87
/*     */     //   Java source line #509	-> byte code offset #90
/*     */     //   Java source line #510	-> byte code offset #93
/*     */     //   Java source line #499	-> byte code offset #174
/*     */     //   Java source line #510	-> byte code offset #183
/*     */     //   Java source line #499	-> byte code offset #227
/*     */     //   Java source line #510	-> byte code offset #236
/*     */     //   Java source line #511	-> byte code offset #282
/*     */     //   Java source line #515	-> byte code offset #309
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	311	0	this	DataSourceRealm
/*     */     //   0	311	1	dbConnection	Connection
/*     */     //   0	311	2	username	String
/*     */     //   20	71	3	list	ArrayList<String>
/*     */     //   27	244	4	stmt	PreparedStatement
/*     */     //   280	23	4	e	SQLException
/*     */     //   30	231	5	localThrowable3	Throwable
/*     */     //   39	179	6	rs	java.sql.ResultSet
/*     */     //   227	7	6	localThrowable2	Throwable
/*     */     //   42	166	7	localThrowable4	Throwable
/*     */     //   70	102	8	role	String
/*     */     //   174	7	8	localThrowable1	Throwable
/*     */     //   113	5	9	x2	Throwable
/*     */     //   152	5	9	x2	Throwable
/*     */     //   183	42	10	localObject1	Object
/*     */     //   205	5	11	x2	Throwable
/*     */     //   236	42	12	localObject2	Object
/*     */     //   258	5	13	x2	Throwable
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   103	110	113	java/lang/Throwable
/*     */     //   142	149	152	java/lang/Throwable
/*     */     //   44	93	174	java/lang/Throwable
/*     */     //   44	93	183	finally
/*     */     //   174	185	183	finally
/*     */     //   195	202	205	java/lang/Throwable
/*     */     //   32	132	227	java/lang/Throwable
/*     */     //   174	227	227	java/lang/Throwable
/*     */     //   32	132	236	finally
/*     */     //   174	238	236	finally
/*     */     //   248	255	258	java/lang/Throwable
/*     */     //   21	171	280	java/sql/SQLException
/*     */     //   174	280	280	java/sql/SQLException
/*     */   }
/*     */   
/*     */   private PreparedStatement credentials(Connection dbConnection, String username)
/*     */     throws SQLException
/*     */   {
/* 531 */     PreparedStatement credentials = dbConnection.prepareStatement(this.preparedCredentials);
/*     */     
/*     */ 
/* 534 */     credentials.setString(1, username);
/* 535 */     return credentials;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private PreparedStatement roles(Connection dbConnection, String username)
/*     */     throws SQLException
/*     */   {
/* 551 */     PreparedStatement roles = dbConnection.prepareStatement(this.preparedRoles);
/*     */     
/*     */ 
/* 554 */     roles.setString(1, username);
/* 555 */     return roles;
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean isRoleStoreDefined()
/*     */   {
/* 561 */     return (this.userRoleTable != null) || (this.roleNameCol != null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 579 */     StringBuilder temp = new StringBuilder("SELECT ");
/* 580 */     temp.append(this.roleNameCol);
/* 581 */     temp.append(" FROM ");
/* 582 */     temp.append(this.userRoleTable);
/* 583 */     temp.append(" WHERE ");
/* 584 */     temp.append(this.userNameCol);
/* 585 */     temp.append(" = ?");
/* 586 */     this.preparedRoles = temp.toString();
/*     */     
/*     */ 
/* 589 */     temp = new StringBuilder("SELECT ");
/* 590 */     temp.append(this.userCredCol);
/* 591 */     temp.append(" FROM ");
/* 592 */     temp.append(this.userTable);
/* 593 */     temp.append(" WHERE ");
/* 594 */     temp.append(this.userNameCol);
/* 595 */     temp.append(" = ?");
/* 596 */     this.preparedCredentials = temp.toString();
/*     */     
/* 598 */     super.startInternal();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\realm\DataSourceRealm.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */