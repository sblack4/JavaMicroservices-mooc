/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.security.Principal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.catalina.CredentialHandler;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.digester.Digester;
/*     */ import org.apache.tomcat.util.file.ConfigFileLoader;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MemoryRealm
/*     */   extends RealmBase
/*     */ {
/*  47 */   private static final Log log = LogFactory.getLog(MemoryRealm.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  55 */   private static Digester digester = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static final String name = "MemoryRealm";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  68 */   private String pathname = "conf/tomcat-users.xml";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  74 */   private final Map<String, GenericPrincipal> principals = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPathname()
/*     */   {
/*  84 */     return this.pathname;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPathname(String pathname)
/*     */   {
/*  97 */     this.pathname = pathname;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal authenticate(String username, String credentials)
/*     */   {
/* 117 */     GenericPrincipal principal = (GenericPrincipal)this.principals.get(username);
/*     */     boolean validated;
/*     */     boolean validated;
/* 120 */     if (principal == null) {
/* 121 */       validated = false;
/*     */     } else {
/* 123 */       if ((credentials == null) || (principal.getPassword() == null)) {
/* 124 */         if (log.isDebugEnabled())
/* 125 */           log.debug(sm.getString("memoryRealm.authenticateFailure", new Object[] { username }));
/* 126 */         return null;
/*     */       }
/* 128 */       validated = getCredentialHandler().matches(credentials, principal.getPassword());
/*     */     }
/*     */     
/* 131 */     if (validated) {
/* 132 */       if (log.isDebugEnabled())
/* 133 */         log.debug(sm.getString("memoryRealm.authenticateSuccess", new Object[] { username }));
/* 134 */       return principal;
/*     */     }
/* 136 */     if (log.isDebugEnabled())
/* 137 */       log.debug(sm.getString("memoryRealm.authenticateFailure", new Object[] { username }));
/* 138 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void addUser(String username, String password, String roles)
/*     */   {
/* 157 */     ArrayList<String> list = new ArrayList();
/* 158 */     roles = roles + ",";
/*     */     for (;;) {
/* 160 */       int comma = roles.indexOf(',');
/* 161 */       if (comma < 0)
/*     */         break;
/* 163 */       String role = roles.substring(0, comma).trim();
/* 164 */       list.add(role);
/* 165 */       roles = roles.substring(comma + 1);
/*     */     }
/*     */     
/*     */ 
/* 169 */     GenericPrincipal principal = new GenericPrincipal(username, password, list);
/*     */     
/* 171 */     this.principals.put(username, principal);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized Digester getDigester()
/*     */   {
/* 185 */     if (digester == null) {
/* 186 */       digester = new Digester();
/* 187 */       digester.setValidating(false);
/*     */       try {
/* 189 */         digester.setFeature("http://apache.org/xml/features/allow-java-encodings", true);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 193 */         log.warn(sm.getString("memoryRealm.xmlFeatureEncoding"), e);
/*     */       }
/* 195 */       digester.addRuleSet(new MemoryRuleSet());
/*     */     }
/* 197 */     return digester;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getName()
/*     */   {
/* 208 */     return "MemoryRealm";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getPassword(String username)
/*     */   {
/* 219 */     GenericPrincipal principal = (GenericPrincipal)this.principals.get(username);
/* 220 */     if (principal != null) {
/* 221 */       return principal.getPassword();
/*     */     }
/* 223 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Principal getPrincipal(String username)
/*     */   {
/* 235 */     return (Principal)this.principals.get(username);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 252 */     String pathName = getPathname();
/* 253 */     try { InputStream is = ConfigFileLoader.getInputStream(pathName);Throwable localThrowable2 = null;
/*     */       try {
/* 255 */         if (log.isDebugEnabled()) {
/* 256 */           log.debug(sm.getString("memoryRealm.loadPath", new Object[] { pathName }));
/*     */         }
/*     */         
/* 259 */         Digester digester = getDigester();
/*     */         try {
/* 261 */           synchronized (digester) {
/* 262 */             digester.push(this);
/* 263 */             digester.parse(is);
/*     */           }
/*     */         } catch (Exception e) {
/* 266 */           throw new LifecycleException(sm.getString("memoryRealm.readXml"), e);
/*     */         } finally {
/* 268 */           digester.reset();
/*     */         }
/*     */       }
/*     */       catch (Throwable localThrowable1)
/*     */       {
/* 253 */         localThrowable2 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       finally
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 270 */         if (is != null) if (localThrowable2 != null) try { is.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else is.close();
/* 271 */       } } catch (IOException ioe) { throw new LifecycleException(sm.getString("memoryRealm.loadExist", new Object[] { pathName }), ioe);
/*     */     }
/*     */     
/* 274 */     super.startInternal();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\realm\MemoryRealm.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */