/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Driver;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Properties;
/*     */ import org.apache.catalina.CredentialHandler;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDBCRealm
/*     */   extends RealmBase
/*     */ {
/*  61 */   protected String connectionName = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */   protected String connectionPassword = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  73 */   protected String connectionURL = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */   protected Connection dbConnection = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */   protected Driver driver = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  91 */   protected String driverName = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static final String name = "JDBCRealm";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 103 */   protected PreparedStatement preparedCredentials = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 110 */   protected PreparedStatement preparedRoles = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 116 */   protected String roleNameCol = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 122 */   protected String userCredCol = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 128 */   protected String userNameCol = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 134 */   protected String userRoleTable = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 140 */   protected String userTable = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getConnectionName()
/*     */   {
/* 149 */     return this.connectionName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectionName(String connectionName)
/*     */   {
/* 158 */     this.connectionName = connectionName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getConnectionPassword()
/*     */   {
/* 165 */     return this.connectionPassword;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectionPassword(String connectionPassword)
/*     */   {
/* 174 */     this.connectionPassword = connectionPassword;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getConnectionURL()
/*     */   {
/* 181 */     return this.connectionURL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectionURL(String connectionURL)
/*     */   {
/* 190 */     this.connectionURL = connectionURL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getDriverName()
/*     */   {
/* 197 */     return this.driverName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDriverName(String driverName)
/*     */   {
/* 206 */     this.driverName = driverName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getRoleNameCol()
/*     */   {
/* 213 */     return this.roleNameCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRoleNameCol(String roleNameCol)
/*     */   {
/* 222 */     this.roleNameCol = roleNameCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getUserCredCol()
/*     */   {
/* 229 */     return this.userCredCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserCredCol(String userCredCol)
/*     */   {
/* 238 */     this.userCredCol = userCredCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getUserNameCol()
/*     */   {
/* 245 */     return this.userNameCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserNameCol(String userNameCol)
/*     */   {
/* 254 */     this.userNameCol = userNameCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getUserRoleTable()
/*     */   {
/* 261 */     return this.userRoleTable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserRoleTable(String userRoleTable)
/*     */   {
/* 270 */     this.userRoleTable = userRoleTable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getUserTable()
/*     */   {
/* 277 */     return this.userTable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserTable(String userTable)
/*     */   {
/* 286 */     this.userTable = userTable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Principal authenticate(String username, String credentials)
/*     */   {
/* 318 */     int numberOfTries = 2;
/* 319 */     while (numberOfTries > 0)
/*     */     {
/*     */       try
/*     */       {
/* 323 */         open();
/*     */         
/*     */ 
/* 326 */         return authenticate(this.dbConnection, username, credentials);
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (SQLException e)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 336 */         this.containerLog.error(sm.getString("jdbcRealm.exception"), e);
/*     */         
/*     */ 
/* 339 */         if (this.dbConnection != null) {
/* 340 */           close(this.dbConnection);
/*     */         }
/*     */       }
/*     */       
/* 344 */       numberOfTries--;
/*     */     }
/*     */     
/*     */ 
/* 348 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Principal authenticate(Connection dbConnection, String username, String credentials)
/*     */   {
/* 376 */     if ((username == null) || (credentials == null)) {
/* 377 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 381 */     String dbCredentials = getPassword(username);
/*     */     
/* 383 */     if (dbCredentials == null) {
/* 384 */       if (this.containerLog.isTraceEnabled()) {
/* 385 */         this.containerLog.trace(sm.getString("jdbcRealm.authenticateFailure", new Object[] { username }));
/*     */       }
/* 387 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 391 */     boolean validated = getCredentialHandler().matches(credentials, dbCredentials);
/*     */     
/* 393 */     if (validated) {
/* 394 */       if (this.containerLog.isTraceEnabled()) {
/* 395 */         this.containerLog.trace(sm.getString("jdbcRealm.authenticateSuccess", new Object[] { username }));
/*     */       }
/*     */     } else {
/* 398 */       if (this.containerLog.isTraceEnabled()) {
/* 399 */         this.containerLog.trace(sm.getString("jdbcRealm.authenticateFailure", new Object[] { username }));
/*     */       }
/* 401 */       return null;
/*     */     }
/*     */     
/* 404 */     ArrayList<String> roles = getRoles(username);
/*     */     
/*     */ 
/* 407 */     return new GenericPrincipal(username, credentials, roles);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void close(Connection dbConnection)
/*     */   {
/* 420 */     if (dbConnection == null) {
/* 421 */       return;
/*     */     }
/*     */     try
/*     */     {
/* 425 */       this.preparedCredentials.close();
/*     */     } catch (Throwable f) {
/* 427 */       ExceptionUtils.handleThrowable(f);
/*     */     }
/* 429 */     this.preparedCredentials = null;
/*     */     
/*     */     try
/*     */     {
/* 433 */       this.preparedRoles.close();
/*     */     } catch (Throwable f) {
/* 435 */       ExceptionUtils.handleThrowable(f);
/*     */     }
/* 437 */     this.preparedRoles = null;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 442 */       dbConnection.close();
/*     */     } catch (SQLException e) {
/* 444 */       this.containerLog.warn(sm.getString("jdbcRealm.close"), e);
/*     */     } finally {
/* 446 */       this.dbConnection = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PreparedStatement credentials(Connection dbConnection, String username)
/*     */     throws SQLException
/*     */   {
/* 465 */     if (this.preparedCredentials == null) {
/* 466 */       StringBuilder sb = new StringBuilder("SELECT ");
/* 467 */       sb.append(this.userCredCol);
/* 468 */       sb.append(" FROM ");
/* 469 */       sb.append(this.userTable);
/* 470 */       sb.append(" WHERE ");
/* 471 */       sb.append(this.userNameCol);
/* 472 */       sb.append(" = ?");
/*     */       
/* 474 */       if (this.containerLog.isDebugEnabled()) {
/* 475 */         this.containerLog.debug("credentials query: " + sb.toString());
/*     */       }
/*     */       
/* 478 */       this.preparedCredentials = dbConnection.prepareStatement(sb.toString());
/*     */     }
/*     */     
/*     */ 
/* 482 */     if (username == null) {
/* 483 */       this.preparedCredentials.setNull(1, 12);
/*     */     } else {
/* 485 */       this.preparedCredentials.setString(1, username);
/*     */     }
/*     */     
/* 488 */     return this.preparedCredentials;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getName()
/*     */   {
/* 498 */     return "JDBCRealm";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized String getPassword(String username)
/*     */   {
/* 512 */     String dbCredentials = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 522 */     int numberOfTries = 2;
/* 523 */     while (numberOfTries > 0) {
/*     */       try
/*     */       {
/* 526 */         open();
/*     */         
/* 528 */         PreparedStatement stmt = credentials(this.dbConnection, username);
/* 529 */         ResultSet rs = stmt.executeQuery();Throwable localThrowable2 = null;
/* 530 */         try { if (rs.next()) {
/* 531 */             dbCredentials = rs.getString(1);
/*     */           }
/*     */           
/* 534 */           this.dbConnection.commit();
/*     */           
/* 536 */           if (dbCredentials != null) {
/* 537 */             dbCredentials = dbCredentials.trim();
/*     */           }
/*     */           
/* 540 */           return dbCredentials;
/*     */         }
/*     */         catch (Throwable localThrowable3)
/*     */         {
/* 529 */           localThrowable2 = localThrowable3;throw localThrowable3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 541 */           if (rs != null) { if (localThrowable2 != null) try { rs.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else { rs.close();
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 552 */         numberOfTries--;
/*     */       }
/*     */       catch (SQLException e)
/*     */       {
/* 544 */         this.containerLog.error(sm.getString("jdbcRealm.exception"), e);
/*     */         
/*     */ 
/*     */ 
/* 548 */         if (this.dbConnection != null) {
/* 549 */           close(this.dbConnection);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 555 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized Principal getPrincipal(String username)
/*     */   {
/* 566 */     return new GenericPrincipal(username, getPassword(username), getRoles(username));
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected ArrayList<String> getRoles(String username)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 66	org/apache/catalina/realm/JDBCRealm:allRolesMode	Lorg/apache/catalina/realm/RealmBase$AllRolesMode;
/*     */     //   4: getstatic 67	org/apache/catalina/realm/RealmBase$AllRolesMode:STRICT_MODE	Lorg/apache/catalina/realm/RealmBase$AllRolesMode;
/*     */     //   7: if_acmpeq +12 -> 19
/*     */     //   10: aload_0
/*     */     //   11: invokespecial 68	org/apache/catalina/realm/JDBCRealm:isRoleStoreDefined	()Z
/*     */     //   14: ifne +5 -> 19
/*     */     //   17: aconst_null
/*     */     //   18: areturn
/*     */     //   19: iconst_2
/*     */     //   20: istore_2
/*     */     //   21: iload_2
/*     */     //   22: ifle +240 -> 262
/*     */     //   25: aload_0
/*     */     //   26: invokevirtual 15	org/apache/catalina/realm/JDBCRealm:open	()Ljava/sql/Connection;
/*     */     //   29: pop
/*     */     //   30: aload_0
/*     */     //   31: aload_0
/*     */     //   32: getfield 5	org/apache/catalina/realm/JDBCRealm:dbConnection	Ljava/sql/Connection;
/*     */     //   35: aload_1
/*     */     //   36: invokevirtual 69	org/apache/catalina/realm/JDBCRealm:roles	(Ljava/sql/Connection;Ljava/lang/String;)Ljava/sql/PreparedStatement;
/*     */     //   39: astore_3
/*     */     //   40: aload_3
/*     */     //   41: invokeinterface 59 1 0
/*     */     //   46: astore 4
/*     */     //   48: aconst_null
/*     */     //   49: astore 5
/*     */     //   51: new 70	java/util/ArrayList
/*     */     //   54: dup
/*     */     //   55: invokespecial 71	java/util/ArrayList:<init>	()V
/*     */     //   58: astore 6
/*     */     //   60: aload 4
/*     */     //   62: invokeinterface 60 1 0
/*     */     //   67: ifeq +33 -> 100
/*     */     //   70: aload 4
/*     */     //   72: iconst_1
/*     */     //   73: invokeinterface 61 2 0
/*     */     //   78: astore 7
/*     */     //   80: aconst_null
/*     */     //   81: aload 7
/*     */     //   83: if_acmpeq +14 -> 97
/*     */     //   86: aload 6
/*     */     //   88: aload 7
/*     */     //   90: invokevirtual 63	java/lang/String:trim	()Ljava/lang/String;
/*     */     //   93: invokevirtual 72	java/util/ArrayList:add	(Ljava/lang/Object;)Z
/*     */     //   96: pop
/*     */     //   97: goto -37 -> 60
/*     */     //   100: aload 6
/*     */     //   102: astore 7
/*     */     //   104: aload 4
/*     */     //   106: ifnull +37 -> 143
/*     */     //   109: aload 5
/*     */     //   111: ifnull +25 -> 136
/*     */     //   114: aload 4
/*     */     //   116: invokeinterface 64 1 0
/*     */     //   121: goto +22 -> 143
/*     */     //   124: astore 8
/*     */     //   126: aload 5
/*     */     //   128: aload 8
/*     */     //   130: invokevirtual 65	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   133: goto +10 -> 143
/*     */     //   136: aload 4
/*     */     //   138: invokeinterface 64 1 0
/*     */     //   143: aload_0
/*     */     //   144: getfield 5	org/apache/catalina/realm/JDBCRealm:dbConnection	Ljava/sql/Connection;
/*     */     //   147: invokeinterface 62 1 0
/*     */     //   152: aload 7
/*     */     //   154: areturn
/*     */     //   155: astore 6
/*     */     //   157: aload 6
/*     */     //   159: astore 5
/*     */     //   161: aload 6
/*     */     //   163: athrow
/*     */     //   164: astore 9
/*     */     //   166: aload 4
/*     */     //   168: ifnull +37 -> 205
/*     */     //   171: aload 5
/*     */     //   173: ifnull +25 -> 198
/*     */     //   176: aload 4
/*     */     //   178: invokeinterface 64 1 0
/*     */     //   183: goto +22 -> 205
/*     */     //   186: astore 10
/*     */     //   188: aload 5
/*     */     //   190: aload 10
/*     */     //   192: invokevirtual 65	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   195: goto +10 -> 205
/*     */     //   198: aload 4
/*     */     //   200: invokeinterface 64 1 0
/*     */     //   205: aload 9
/*     */     //   207: athrow
/*     */     //   208: astore 11
/*     */     //   210: aload_0
/*     */     //   211: getfield 5	org/apache/catalina/realm/JDBCRealm:dbConnection	Ljava/sql/Connection;
/*     */     //   214: invokeinterface 62 1 0
/*     */     //   219: aload 11
/*     */     //   221: athrow
/*     */     //   222: astore_3
/*     */     //   223: aload_0
/*     */     //   224: getfield 18	org/apache/catalina/realm/JDBCRealm:containerLog	Lorg/apache/juli/logging/Log;
/*     */     //   227: getstatic 19	org/apache/catalina/realm/JDBCRealm:sm	Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   230: ldc 20
/*     */     //   232: invokevirtual 21	org/apache/tomcat/util/res/StringManager:getString	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   235: aload_3
/*     */     //   236: invokeinterface 22 3 0
/*     */     //   241: aload_0
/*     */     //   242: getfield 5	org/apache/catalina/realm/JDBCRealm:dbConnection	Ljava/sql/Connection;
/*     */     //   245: ifnull +11 -> 256
/*     */     //   248: aload_0
/*     */     //   249: aload_0
/*     */     //   250: getfield 5	org/apache/catalina/realm/JDBCRealm:dbConnection	Ljava/sql/Connection;
/*     */     //   253: invokevirtual 23	org/apache/catalina/realm/JDBCRealm:close	(Ljava/sql/Connection;)V
/*     */     //   256: iinc 2 -1
/*     */     //   259: goto -238 -> 21
/*     */     //   262: aconst_null
/*     */     //   263: areturn
/*     */     // Line number table:
/*     */     //   Java source line #580	-> byte code offset #0
/*     */     //   Java source line #583	-> byte code offset #17
/*     */     //   Java source line #594	-> byte code offset #19
/*     */     //   Java source line #595	-> byte code offset #21
/*     */     //   Java source line #598	-> byte code offset #25
/*     */     //   Java source line #600	-> byte code offset #30
/*     */     //   Java source line #601	-> byte code offset #40
/*     */     //   Java source line #603	-> byte code offset #51
/*     */     //   Java source line #605	-> byte code offset #60
/*     */     //   Java source line #606	-> byte code offset #70
/*     */     //   Java source line #607	-> byte code offset #80
/*     */     //   Java source line #608	-> byte code offset #86
/*     */     //   Java source line #610	-> byte code offset #97
/*     */     //   Java source line #612	-> byte code offset #100
/*     */     //   Java source line #613	-> byte code offset #104
/*     */     //   Java source line #614	-> byte code offset #143
/*     */     //   Java source line #601	-> byte code offset #155
/*     */     //   Java source line #613	-> byte code offset #164
/*     */     //   Java source line #614	-> byte code offset #208
/*     */     //   Java source line #616	-> byte code offset #222
/*     */     //   Java source line #618	-> byte code offset #223
/*     */     //   Java source line #621	-> byte code offset #241
/*     */     //   Java source line #622	-> byte code offset #248
/*     */     //   Java source line #625	-> byte code offset #256
/*     */     //   Java source line #628	-> byte code offset #262
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	264	0	this	JDBCRealm
/*     */     //   0	264	1	username	String
/*     */     //   20	237	2	numberOfTries	int
/*     */     //   39	2	3	stmt	PreparedStatement
/*     */     //   222	14	3	e	SQLException
/*     */     //   46	153	4	rs	ResultSet
/*     */     //   49	140	5	localThrowable2	Throwable
/*     */     //   58	43	6	roleList	ArrayList<String>
/*     */     //   155	7	6	localThrowable1	Throwable
/*     */     //   78	75	7	role	String
/*     */     //   124	5	8	x2	Throwable
/*     */     //   164	42	9	localObject1	Object
/*     */     //   186	5	10	x2	Throwable
/*     */     //   208	12	11	localObject2	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   114	121	124	java/lang/Throwable
/*     */     //   51	104	155	java/lang/Throwable
/*     */     //   51	104	164	finally
/*     */     //   155	166	164	finally
/*     */     //   176	183	186	java/lang/Throwable
/*     */     //   40	143	208	finally
/*     */     //   155	210	208	finally
/*     */     //   25	152	222	java/sql/SQLException
/*     */     //   155	222	222	java/sql/SQLException
/*     */   }
/*     */   
/*     */   protected Connection open()
/*     */     throws SQLException
/*     */   {
/* 641 */     if (this.dbConnection != null) {
/* 642 */       return this.dbConnection;
/*     */     }
/*     */     
/* 645 */     if (this.driver == null) {
/*     */       try {
/* 647 */         Class<?> clazz = Class.forName(this.driverName);
/* 648 */         this.driver = ((Driver)clazz.newInstance());
/*     */       } catch (Throwable e) {
/* 650 */         ExceptionUtils.handleThrowable(e);
/* 651 */         throw new SQLException(e.getMessage(), e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 656 */     Properties props = new Properties();
/* 657 */     if (this.connectionName != null)
/* 658 */       props.put("user", this.connectionName);
/* 659 */     if (this.connectionPassword != null)
/* 660 */       props.put("password", this.connectionPassword);
/* 661 */     this.dbConnection = this.driver.connect(this.connectionURL, props);
/* 662 */     if (this.dbConnection == null) {
/* 663 */       throw new SQLException(sm.getString("jdbcRealm.open.invalidurl", new Object[] { this.driverName, this.connectionURL }));
/*     */     }
/*     */     
/* 666 */     this.dbConnection.setAutoCommit(false);
/* 667 */     return this.dbConnection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized PreparedStatement roles(Connection dbConnection, String username)
/*     */     throws SQLException
/*     */   {
/* 685 */     if (this.preparedRoles == null) {
/* 686 */       StringBuilder sb = new StringBuilder("SELECT ");
/* 687 */       sb.append(this.roleNameCol);
/* 688 */       sb.append(" FROM ");
/* 689 */       sb.append(this.userRoleTable);
/* 690 */       sb.append(" WHERE ");
/* 691 */       sb.append(this.userNameCol);
/* 692 */       sb.append(" = ?");
/* 693 */       this.preparedRoles = dbConnection.prepareStatement(sb.toString());
/*     */     }
/*     */     
/*     */ 
/* 697 */     this.preparedRoles.setString(1, username);
/* 698 */     return this.preparedRoles;
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean isRoleStoreDefined()
/*     */   {
/* 704 */     return (this.userRoleTable != null) || (this.roleNameCol != null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void startInternal()
/*     */     throws LifecycleException
/*     */   {
/*     */     try
/*     */     {
/* 724 */       open();
/*     */     } catch (SQLException e) {
/* 726 */       this.containerLog.error(sm.getString("jdbcRealm.open"), e);
/*     */     }
/*     */     
/* 729 */     super.startInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void stopInternal()
/*     */     throws LifecycleException
/*     */   {
/* 744 */     super.stopInternal();
/*     */     
/*     */ 
/* 747 */     close(this.dbConnection);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\realm\JDBCRealm.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */