/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Random;
/*     */ import org.apache.catalina.CredentialHandler;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.buf.HexUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DigestCredentialHandlerBase
/*     */   implements CredentialHandler
/*     */ {
/*  33 */   protected static final StringManager sm = StringManager.getManager(DigestCredentialHandlerBase.class);
/*     */   
/*     */ 
/*     */   public static final int DEFAULT_SALT_LENGTH = 32;
/*     */   
/*  38 */   private int iterations = getDefaultIterations();
/*  39 */   private int saltLength = getDefaultSaltLength();
/*  40 */   private final Object randomLock = new Object();
/*  41 */   private volatile Random random = null;
/*  42 */   private boolean logInvalidStoredCredentials = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getIterations()
/*     */   {
/*  50 */     return this.iterations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIterations(int iterations)
/*     */   {
/*  60 */     this.iterations = iterations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSaltLength()
/*     */   {
/*  69 */     return this.saltLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSaltLength(int saltLength)
/*     */   {
/*  79 */     this.saltLength = saltLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getLogInvalidStoredCredentials()
/*     */   {
/*  89 */     return this.logInvalidStoredCredentials;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLogInvalidStoredCredentials(boolean logInvalidStoredCredentials)
/*     */   {
/* 101 */     this.logInvalidStoredCredentials = logInvalidStoredCredentials;
/*     */   }
/*     */   
/*     */ 
/*     */   public String mutate(String userCredential)
/*     */   {
/* 107 */     byte[] salt = null;
/* 108 */     int iterations = getIterations();
/* 109 */     int saltLength = getSaltLength();
/* 110 */     if (saltLength == 0) {
/* 111 */       salt = new byte[0];
/* 112 */     } else if (saltLength > 0)
/*     */     {
/* 114 */       if (this.random == null) {
/* 115 */         synchronized (this.randomLock) {
/* 116 */           if (this.random == null) {
/* 117 */             this.random = new SecureRandom();
/*     */           }
/*     */         }
/*     */       }
/* 121 */       salt = new byte[saltLength];
/*     */       
/*     */ 
/* 124 */       this.random.nextBytes(salt);
/*     */     }
/*     */     
/* 127 */     String serverCredential = mutate(userCredential, salt, iterations);
/*     */     
/* 129 */     if ((saltLength == 0) && (iterations == 1))
/*     */     {
/* 131 */       return serverCredential;
/*     */     }
/* 133 */     StringBuilder result = new StringBuilder((saltLength << 1) + 10 + serverCredential.length() + 2);
/*     */     
/* 135 */     result.append(HexUtils.toHexString(salt));
/* 136 */     result.append('$');
/* 137 */     result.append(iterations);
/* 138 */     result.append('$');
/* 139 */     result.append(serverCredential);
/*     */     
/* 141 */     return result.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean matchesSaltIterationsEncoded(String inputCredentials, String storedCredentials)
/*     */   {
/* 158 */     int sep1 = storedCredentials.indexOf('$');
/* 159 */     int sep2 = storedCredentials.indexOf('$', sep1 + 1);
/*     */     
/* 161 */     if ((sep1 < 0) || (sep2 < 0))
/*     */     {
/*     */ 
/* 164 */       logInvalidStoredCredentials(storedCredentials);
/* 165 */       return false;
/*     */     }
/*     */     
/* 168 */     String hexSalt = storedCredentials.substring(0, sep1);
/*     */     
/* 170 */     int iterations = Integer.parseInt(storedCredentials.substring(sep1 + 1, sep2));
/*     */     
/* 172 */     String storedHexEncoded = storedCredentials.substring(sep2 + 1);
/*     */     try
/*     */     {
/* 175 */       salt = HexUtils.fromHexString(hexSalt);
/*     */     } catch (IllegalArgumentException iae) { byte[] salt;
/* 177 */       logInvalidStoredCredentials(storedCredentials);
/* 178 */       return false;
/*     */     }
/*     */     byte[] salt;
/* 181 */     String inputHexEncoded = mutate(inputCredentials, salt, iterations);
/*     */     
/* 183 */     return storedHexEncoded.equalsIgnoreCase(inputHexEncoded);
/*     */   }
/*     */   
/*     */   private void logInvalidStoredCredentials(String storedCredentials)
/*     */   {
/* 188 */     if (this.logInvalidStoredCredentials)
/*     */     {
/*     */ 
/* 191 */       getLog().warn(sm.getString("credentialHandler.invalidStoredCredential", new Object[] { storedCredentials }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getDefaultSaltLength()
/*     */   {
/* 201 */     return 32;
/*     */   }
/*     */   
/*     */   protected abstract String mutate(String paramString, byte[] paramArrayOfByte, int paramInt);
/*     */   
/*     */   public abstract void setAlgorithm(String paramString)
/*     */     throws NoSuchAlgorithmException;
/*     */   
/*     */   public abstract String getAlgorithm();
/*     */   
/*     */   protected abstract int getDefaultIterations();
/*     */   
/*     */   protected abstract Log getLog();
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\realm\DigestCredentialHandlerBase.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */