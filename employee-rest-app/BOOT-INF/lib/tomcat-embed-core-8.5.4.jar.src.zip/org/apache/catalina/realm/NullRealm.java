/*    */ package org.apache.catalina.realm;
/*    */ 
/*    */ import java.security.Principal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullRealm
/*    */   extends RealmBase
/*    */ {
/*    */   private static final String NAME = "NullRealm";
/*    */   
/*    */   protected String getName()
/*    */   {
/* 32 */     return "NullRealm";
/*    */   }
/*    */   
/*    */ 
/*    */   protected String getPassword(String username)
/*    */   {
/* 38 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   protected Principal getPrincipal(String username)
/*    */   {
/* 44 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\realm\NullRealm.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */