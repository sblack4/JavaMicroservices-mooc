/*      */ package org.apache.catalina.realm;
/*      */ 
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.security.MessageDigest;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.security.Principal;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import javax.servlet.annotation.ServletSecurity.TransportGuarantee;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.CredentialHandler;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Realm;
/*      */ import org.apache.catalina.Server;
/*      */ import org.apache.catalina.Service;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.connector.Connector;
/*      */ import org.apache.catalina.connector.Request;
/*      */ import org.apache.catalina.connector.Response;
/*      */ import org.apache.catalina.util.LifecycleMBeanBase;
/*      */ import org.apache.catalina.util.SessionConfig;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.IntrospectionUtils;
/*      */ import org.apache.tomcat.util.buf.B2CConverter;
/*      */ import org.apache.tomcat.util.buf.HexUtils;
/*      */ import org.apache.tomcat.util.buf.MessageBytes;
/*      */ import org.apache.tomcat.util.descriptor.web.SecurityCollection;
/*      */ import org.apache.tomcat.util.descriptor.web.SecurityConstraint;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.util.security.ConcurrentMessageDigest;
/*      */ import org.apache.tomcat.util.security.MD5Encoder;
/*      */ import org.ietf.jgss.GSSContext;
/*      */ import org.ietf.jgss.GSSCredential;
/*      */ import org.ietf.jgss.GSSException;
/*      */ import org.ietf.jgss.GSSName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class RealmBase
/*      */   extends LifecycleMBeanBase
/*      */   implements Realm
/*      */ {
/*   76 */   private static final Log log = LogFactory.getLog(RealmBase.class);
/*      */   
/*   78 */   private static final List<Class<? extends DigestCredentialHandlerBase>> credentialHandlerClasses = new ArrayList();
/*      */   protected Container container;
/*      */   protected Log containerLog;
/*      */   private CredentialHandler credentialHandler;
/*      */   
/*      */   static
/*      */   {
/*   85 */     credentialHandlerClasses.add(MessageDigestCredentialHandler.class);
/*   86 */     credentialHandlerClasses.add(SecretKeyCredentialHandler.class);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  110 */   protected static final StringManager sm = StringManager.getManager(RealmBase.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final PropertyChangeSupport support;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean validate;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String x509UsernameRetrieverClassName;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected X509UsernameRetriever x509UsernameRetriever;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected AllRolesMode allRolesMode;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean stripRealmForGss;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int transportGuaranteeRedirectStatus;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String realmPath;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTransportGuaranteeRedirectStatus()
/*      */   {
/*  160 */     return this.transportGuaranteeRedirectStatus;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTransportGuaranteeRedirectStatus(int transportGuaranteeRedirectStatus)
/*      */   {
/*  172 */     this.transportGuaranteeRedirectStatus = transportGuaranteeRedirectStatus;
/*      */   }
/*      */   
/*      */ 
/*      */   public CredentialHandler getCredentialHandler()
/*      */   {
/*  178 */     return this.credentialHandler;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setCredentialHandler(CredentialHandler credentialHandler)
/*      */   {
/*  184 */     this.credentialHandler = credentialHandler;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Container getContainer()
/*      */   {
/*  194 */     return this.container;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setContainer(Container container)
/*      */   {
/*  207 */     Container oldContainer = this.container;
/*  208 */     this.container = container;
/*  209 */     this.support.firePropertyChange("container", oldContainer, this.container);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAllRolesMode()
/*      */   {
/*  218 */     return this.allRolesMode.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAllRolesMode(String allRolesMode)
/*      */   {
/*  227 */     this.allRolesMode = AllRolesMode.toMode(allRolesMode);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getValidate()
/*      */   {
/*  236 */     return this.validate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setValidate(boolean validate)
/*      */   {
/*  247 */     this.validate = validate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getX509UsernameRetrieverClassName()
/*      */   {
/*  258 */     return this.x509UsernameRetrieverClassName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setX509UsernameRetrieverClassName(String className)
/*      */   {
/*  271 */     this.x509UsernameRetrieverClassName = className;
/*      */   }
/*      */   
/*      */   public boolean isStripRealmForGss() {
/*  275 */     return this.stripRealmForGss;
/*      */   }
/*      */   
/*      */   public void setStripRealmForGss(boolean stripRealmForGss)
/*      */   {
/*  280 */     this.stripRealmForGss = stripRealmForGss;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addPropertyChangeListener(PropertyChangeListener listener)
/*      */   {
/*  295 */     this.support.addPropertyChangeListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal authenticate(String username)
/*      */   {
/*  309 */     if (username == null) {
/*  310 */       return null;
/*      */     }
/*      */     
/*  313 */     if (this.containerLog.isTraceEnabled()) {
/*  314 */       this.containerLog.trace(sm.getString("realmBase.authenticateSuccess", new Object[] { username }));
/*      */     }
/*      */     
/*  317 */     return getPrincipal(username);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal authenticate(String username, String credentials)
/*      */   {
/*  333 */     String serverCredentials = getPassword(username);
/*      */     
/*  335 */     if ((credentials == null) || (serverCredentials == null)) {
/*  336 */       if (this.containerLog.isTraceEnabled()) {
/*  337 */         this.containerLog.trace(sm.getString("realmBase.authenticateFailure", new Object[] { username }));
/*      */       }
/*      */       
/*  340 */       return null;
/*      */     }
/*      */     
/*  343 */     boolean validated = getCredentialHandler().matches(credentials, serverCredentials);
/*  344 */     if (!validated) {
/*  345 */       if (this.containerLog.isTraceEnabled()) {
/*  346 */         this.containerLog.trace(sm.getString("realmBase.authenticateFailure", new Object[] { username }));
/*      */       }
/*      */       
/*  349 */       return null;
/*      */     }
/*  351 */     if (this.containerLog.isTraceEnabled()) {
/*  352 */       this.containerLog.trace(sm.getString("realmBase.authenticateSuccess", new Object[] { username }));
/*      */     }
/*      */     
/*      */ 
/*  356 */     return getPrincipal(username);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal authenticate(String username, String clientDigest, String nonce, String nc, String cnonce, String qop, String realm, String md5a2)
/*      */   {
/*  384 */     String md5a1 = getDigest(username, realm);
/*  385 */     if (md5a1 == null)
/*  386 */       return null;
/*  387 */     md5a1 = md5a1.toLowerCase(Locale.ENGLISH);
/*      */     String serverDigestValue;
/*  389 */     String serverDigestValue; if (qop == null) {
/*  390 */       serverDigestValue = md5a1 + ":" + nonce + ":" + md5a2;
/*      */     } else {
/*  392 */       serverDigestValue = md5a1 + ":" + nonce + ":" + nc + ":" + cnonce + ":" + qop + ":" + md5a2;
/*      */     }
/*      */     
/*      */ 
/*  396 */     byte[] valueBytes = null;
/*      */     try {
/*  398 */       valueBytes = serverDigestValue.getBytes(getDigestCharset());
/*      */     } catch (UnsupportedEncodingException uee) {
/*  400 */       log.error("Illegal digestEncoding: " + getDigestEncoding(), uee);
/*  401 */       throw new IllegalArgumentException(uee.getMessage());
/*      */     }
/*      */     
/*  404 */     String serverDigest = MD5Encoder.encode(ConcurrentMessageDigest.digestMD5(new byte[][] { valueBytes }));
/*      */     
/*  406 */     if (log.isDebugEnabled()) {
/*  407 */       log.debug("Digest : " + clientDigest + " Username:" + username + " ClientSigest:" + clientDigest + " nonce:" + nonce + " nc:" + nc + " cnonce:" + cnonce + " qop:" + qop + " realm:" + realm + "md5a2:" + md5a2 + " Server digest:" + serverDigest);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  414 */     if (serverDigest.equals(clientDigest)) {
/*  415 */       return getPrincipal(username);
/*      */     }
/*      */     
/*  418 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal authenticate(X509Certificate[] certs)
/*      */   {
/*  432 */     if ((certs == null) || (certs.length < 1)) {
/*  433 */       return null;
/*      */     }
/*      */     
/*  436 */     if (log.isDebugEnabled())
/*  437 */       log.debug("Authenticating client certificate chain");
/*  438 */     if (this.validate) {
/*  439 */       for (int i = 0; i < certs.length; i++) {
/*  440 */         if (log.isDebugEnabled()) {
/*  441 */           log.debug(" Checking validity for '" + certs[i].getSubjectDN().getName() + "'");
/*      */         }
/*      */         try {
/*  444 */           certs[i].checkValidity();
/*      */         } catch (Exception e) {
/*  446 */           if (log.isDebugEnabled())
/*  447 */             log.debug("  Validity exception", e);
/*  448 */           return null;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  454 */     return getPrincipal(certs[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal authenticate(GSSContext gssContext, boolean storeCred)
/*      */   {
/*  464 */     if (gssContext.isEstablished()) {
/*  465 */       GSSName gssName = null;
/*      */       try {
/*  467 */         gssName = gssContext.getSrcName();
/*      */       } catch (GSSException e) {
/*  469 */         log.warn(sm.getString("realmBase.gssNameFail"), e);
/*      */       }
/*      */       
/*  472 */       if (gssName != null) {
/*  473 */         String name = gssName.toString();
/*      */         
/*  475 */         if (isStripRealmForGss()) {
/*  476 */           int i = name.indexOf('@');
/*  477 */           if (i > 0)
/*      */           {
/*  479 */             name = name.substring(0, i);
/*      */           }
/*      */         }
/*  482 */         GSSCredential gssCredential = null;
/*  483 */         if ((storeCred) && (gssContext.getCredDelegState())) {
/*      */           try {
/*  485 */             gssCredential = gssContext.getDelegCred();
/*      */           } catch (GSSException e) {
/*  487 */             if (log.isDebugEnabled()) {
/*  488 */               log.debug(sm.getString("realmBase.delegatedCredentialFail", new Object[] { name }), e);
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*  494 */         return getPrincipal(name, gssCredential);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  499 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SecurityConstraint[] findSecurityConstraints(Request request, Context context)
/*      */   {
/*  525 */     ArrayList<SecurityConstraint> results = null;
/*      */     
/*  527 */     SecurityConstraint[] constraints = context.findConstraints();
/*  528 */     if ((constraints == null) || (constraints.length == 0)) {
/*  529 */       if (log.isDebugEnabled())
/*  530 */         log.debug("  No applicable constraints defined");
/*  531 */       return null;
/*      */     }
/*      */     
/*      */ 
/*  535 */     String uri = request.getRequestPathMB().toString();
/*      */     
/*      */ 
/*  538 */     if (uri == null) {
/*  539 */       uri = "/";
/*      */     }
/*      */     
/*  542 */     String method = request.getMethod();
/*      */     
/*  544 */     boolean found = false;
/*  545 */     for (int i = 0; i < constraints.length; i++) {
/*  546 */       SecurityCollection[] collection = constraints[i].findCollections();
/*      */       
/*      */ 
/*      */ 
/*  550 */       if (collection != null)
/*      */       {
/*      */ 
/*      */ 
/*  554 */         if (log.isDebugEnabled()) {
/*  555 */           log.debug("  Checking constraint '" + constraints[i] + "' against " + method + " " + uri + " --> " + constraints[i].included(uri, method));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  560 */         for (int j = 0; j < collection.length; j++) {
/*  561 */           String[] patterns = collection[j].findPatterns();
/*      */           
/*      */ 
/*      */ 
/*  565 */           if (patterns != null)
/*      */           {
/*      */ 
/*      */ 
/*  569 */             for (int k = 0; k < patterns.length; k++)
/*  570 */               if (uri.equals(patterns[k])) {
/*  571 */                 found = true;
/*  572 */                 if (collection[j].findMethod(method)) {
/*  573 */                   if (results == null) {
/*  574 */                     results = new ArrayList();
/*      */                   }
/*  576 */                   results.add(constraints[i]);
/*      */                 }
/*      */               }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  583 */     if (found) {
/*  584 */       return resultsToArray(results);
/*      */     }
/*      */     
/*  587 */     int longest = -1;
/*      */     
/*  589 */     for (i = 0; i < constraints.length; i++) {
/*  590 */       SecurityCollection[] collection = constraints[i].findCollections();
/*      */       
/*      */ 
/*      */ 
/*  594 */       if (collection != null)
/*      */       {
/*      */ 
/*      */ 
/*  598 */         if (log.isDebugEnabled()) {
/*  599 */           log.debug("  Checking constraint '" + constraints[i] + "' against " + method + " " + uri + " --> " + constraints[i].included(uri, method));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  604 */         for (int j = 0; j < collection.length; j++) {
/*  605 */           String[] patterns = collection[j].findPatterns();
/*      */           
/*      */ 
/*      */ 
/*  609 */           if (patterns != null)
/*      */           {
/*      */ 
/*      */ 
/*  613 */             boolean matched = false;
/*  614 */             int length = -1;
/*  615 */             for (int k = 0; k < patterns.length; k++) {
/*  616 */               String pattern = patterns[k];
/*  617 */               if ((pattern.startsWith("/")) && (pattern.endsWith("/*")) && (pattern.length() >= longest))
/*      */               {
/*      */ 
/*  620 */                 if (pattern.length() == 2) {
/*  621 */                   matched = true;
/*  622 */                   length = pattern.length();
/*  623 */                 } else if ((pattern.regionMatches(0, uri, 0, pattern.length() - 1)) || ((pattern.length() - 2 == uri.length()) && (pattern.regionMatches(0, uri, 0, pattern.length() - 2))))
/*      */                 {
/*      */ 
/*      */ 
/*      */ 
/*  628 */                   matched = true;
/*  629 */                   length = pattern.length();
/*      */                 }
/*      */               }
/*      */             }
/*  633 */             if (matched) {
/*  634 */               if (length > longest) {
/*  635 */                 found = false;
/*  636 */                 if (results != null) {
/*  637 */                   results.clear();
/*      */                 }
/*  639 */                 longest = length;
/*      */               }
/*  641 */               if (collection[j].findMethod(method)) {
/*  642 */                 found = true;
/*  643 */                 if (results == null) {
/*  644 */                   results = new ArrayList();
/*      */                 }
/*  646 */                 results.add(constraints[i]);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       } }
/*  652 */     if (found) {
/*  653 */       return resultsToArray(results);
/*      */     }
/*      */     
/*  656 */     for (i = 0; i < constraints.length; i++) {
/*  657 */       SecurityCollection[] collection = constraints[i].findCollections();
/*      */       
/*      */ 
/*      */ 
/*  661 */       if (collection != null)
/*      */       {
/*      */ 
/*      */ 
/*  665 */         if (log.isDebugEnabled()) {
/*  666 */           log.debug("  Checking constraint '" + constraints[i] + "' against " + method + " " + uri + " --> " + constraints[i].included(uri, method));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  671 */         boolean matched = false;
/*  672 */         int pos = -1;
/*  673 */         for (int j = 0; j < collection.length; j++) {
/*  674 */           String[] patterns = collection[j].findPatterns();
/*      */           
/*      */ 
/*      */ 
/*  678 */           if (patterns != null)
/*      */           {
/*      */ 
/*      */ 
/*  682 */             for (int k = 0; (k < patterns.length) && (!matched); k++) {
/*  683 */               String pattern = patterns[k];
/*  684 */               if (pattern.startsWith("*.")) {
/*  685 */                 int slash = uri.lastIndexOf('/');
/*  686 */                 int dot = uri.lastIndexOf('.');
/*  687 */                 if ((slash >= 0) && (dot > slash) && (dot != uri.length() - 1) && (uri.length() - dot == pattern.length() - 1))
/*      */                 {
/*      */ 
/*  690 */                   if (pattern.regionMatches(1, uri, dot, uri.length() - dot)) {
/*  691 */                     matched = true;
/*  692 */                     pos = j;
/*      */                   } }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*  698 */         if (matched) {
/*  699 */           found = true;
/*  700 */           if (collection[pos].findMethod(method)) {
/*  701 */             if (results == null) {
/*  702 */               results = new ArrayList();
/*      */             }
/*  704 */             results.add(constraints[i]);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  709 */     if (found) {
/*  710 */       return resultsToArray(results);
/*      */     }
/*      */     
/*  713 */     for (i = 0; i < constraints.length; i++) {
/*  714 */       SecurityCollection[] collection = constraints[i].findCollections();
/*      */       
/*      */ 
/*      */ 
/*  718 */       if (collection != null)
/*      */       {
/*      */ 
/*      */ 
/*  722 */         if (log.isDebugEnabled()) {
/*  723 */           log.debug("  Checking constraint '" + constraints[i] + "' against " + method + " " + uri + " --> " + constraints[i].included(uri, method));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  728 */         for (int j = 0; j < collection.length; j++) {
/*  729 */           String[] patterns = collection[j].findPatterns();
/*      */           
/*      */ 
/*      */ 
/*  733 */           if (patterns != null)
/*      */           {
/*      */ 
/*      */ 
/*  737 */             boolean matched = false;
/*  738 */             for (int k = 0; (k < patterns.length) && (!matched); k++) {
/*  739 */               String pattern = patterns[k];
/*  740 */               if (pattern.equals("/")) {
/*  741 */                 matched = true;
/*      */               }
/*      */             }
/*  744 */             if (matched) {
/*  745 */               if (results == null) {
/*  746 */                 results = new ArrayList();
/*      */               }
/*  748 */               results.add(constraints[i]);
/*      */             }
/*      */           }
/*      */         }
/*      */       } }
/*  753 */     if (results == null)
/*      */     {
/*  755 */       if (log.isDebugEnabled())
/*  756 */         log.debug("  No applicable constraint located");
/*      */     }
/*  758 */     return resultsToArray(results);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private SecurityConstraint[] resultsToArray(ArrayList<SecurityConstraint> results)
/*      */   {
/*  766 */     if ((results == null) || (results.size() == 0)) {
/*  767 */       return null;
/*      */     }
/*  769 */     SecurityConstraint[] array = new SecurityConstraint[results.size()];
/*  770 */     results.toArray(array);
/*  771 */     return array;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasResourcePermission(Request request, Response response, SecurityConstraint[] constraints, Context context)
/*      */     throws IOException
/*      */   {
/*  794 */     if ((constraints == null) || (constraints.length == 0)) {
/*  795 */       return true;
/*      */     }
/*      */     
/*  798 */     Principal principal = request.getPrincipal();
/*  799 */     boolean status = false;
/*  800 */     boolean denyfromall = false;
/*  801 */     for (int i = 0; i < constraints.length; i++) {
/*  802 */       SecurityConstraint constraint = constraints[i];
/*      */       String[] roles;
/*      */       String[] roles;
/*  805 */       if (constraint.getAllRoles())
/*      */       {
/*  807 */         roles = request.getContext().findSecurityRoles();
/*      */       } else {
/*  809 */         roles = constraint.findAuthRoles();
/*      */       }
/*      */       
/*  812 */       if (roles == null) {
/*  813 */         roles = new String[0];
/*      */       }
/*  815 */       if (log.isDebugEnabled()) {
/*  816 */         log.debug("  Checking roles " + principal);
/*      */       }
/*  818 */       if ((constraint.getAuthenticatedUsers()) && (principal != null)) {
/*  819 */         if (log.isDebugEnabled()) {
/*  820 */           log.debug("Passing all authenticated users");
/*      */         }
/*  822 */         status = true;
/*  823 */       } else if ((roles.length == 0) && (!constraint.getAllRoles()) && (!constraint.getAuthenticatedUsers()))
/*      */       {
/*  825 */         if (constraint.getAuthConstraint()) {
/*  826 */           if (log.isDebugEnabled())
/*  827 */             log.debug("No roles");
/*  828 */           status = false;
/*  829 */           denyfromall = true;
/*  830 */           break;
/*      */         }
/*      */         
/*  833 */         if (log.isDebugEnabled())
/*  834 */           log.debug("Passing all access");
/*  835 */         status = true;
/*  836 */       } else if (principal == null) {
/*  837 */         if (log.isDebugEnabled())
/*  838 */           log.debug("  No user authenticated, cannot grant access");
/*      */       } else {
/*  840 */         for (int j = 0; j < roles.length; j++) {
/*  841 */           if (hasRole(null, principal, roles[j])) {
/*  842 */             status = true;
/*  843 */             if (log.isDebugEnabled()) {
/*  844 */               log.debug("Role found:  " + roles[j]);
/*      */             }
/*  846 */           } else if (log.isDebugEnabled()) {
/*  847 */             log.debug("No role found:  " + roles[j]);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  852 */     if ((!denyfromall) && (this.allRolesMode != AllRolesMode.STRICT_MODE) && (!status) && (principal != null))
/*      */     {
/*  854 */       if (log.isDebugEnabled()) {
/*  855 */         log.debug("Checking for all roles mode: " + this.allRolesMode);
/*      */       }
/*      */       
/*  858 */       for (int i = 0; i < constraints.length; i++) {
/*  859 */         SecurityConstraint constraint = constraints[i];
/*      */         
/*      */ 
/*  862 */         if (constraint.getAllRoles()) {
/*  863 */           if (this.allRolesMode == AllRolesMode.AUTH_ONLY_MODE) {
/*  864 */             if (log.isDebugEnabled()) {
/*  865 */               log.debug("Granting access for role-name=*, auth-only");
/*      */             }
/*  867 */             status = true;
/*  868 */             break;
/*      */           }
/*      */           
/*      */ 
/*  872 */           String[] roles = request.getContext().findSecurityRoles();
/*  873 */           if ((roles.length == 0) && (this.allRolesMode == AllRolesMode.STRICT_AUTH_ONLY_MODE)) {
/*  874 */             if (log.isDebugEnabled()) {
/*  875 */               log.debug("Granting access for role-name=*, strict auth-only");
/*      */             }
/*  877 */             status = true;
/*  878 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  885 */     if (!status) {
/*  886 */       response.sendError(403, sm.getString("realmBase.forbidden"));
/*      */     }
/*      */     
/*      */ 
/*  890 */     return status;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasRole(Wrapper wrapper, Principal principal, String role)
/*      */   {
/*  909 */     if (wrapper != null) {
/*  910 */       String realRole = wrapper.findSecurityReference(role);
/*  911 */       if (realRole != null) {
/*  912 */         role = realRole;
/*      */       }
/*      */     }
/*      */     
/*  916 */     if ((principal == null) || (role == null) || (!(principal instanceof GenericPrincipal)))
/*      */     {
/*  918 */       return false;
/*      */     }
/*  920 */     GenericPrincipal gp = (GenericPrincipal)principal;
/*  921 */     boolean result = gp.hasRole(role);
/*  922 */     if (log.isDebugEnabled()) {
/*  923 */       String name = principal.getName();
/*  924 */       if (result) {
/*  925 */         log.debug(sm.getString("realmBase.hasRoleSuccess", new Object[] { name, role }));
/*      */       } else
/*  927 */         log.debug(sm.getString("realmBase.hasRoleFailure", new Object[] { name, role }));
/*      */     }
/*  929 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasUserDataPermission(Request request, Response response, SecurityConstraint[] constraints)
/*      */     throws IOException
/*      */   {
/*  953 */     if ((constraints == null) || (constraints.length == 0)) {
/*  954 */       if (log.isDebugEnabled())
/*  955 */         log.debug("  No applicable security constraint defined");
/*  956 */       return true;
/*      */     }
/*  958 */     for (int i = 0; i < constraints.length; i++) {
/*  959 */       SecurityConstraint constraint = constraints[i];
/*  960 */       String userConstraint = constraint.getUserConstraint();
/*  961 */       if (userConstraint == null) {
/*  962 */         if (log.isDebugEnabled())
/*  963 */           log.debug("  No applicable user data constraint defined");
/*  964 */         return true;
/*      */       }
/*  966 */       if (userConstraint.equals(ServletSecurity.TransportGuarantee.NONE.name())) {
/*  967 */         if (log.isDebugEnabled())
/*  968 */           log.debug("  User data constraint has no restrictions");
/*  969 */         return true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  974 */     if (request.getRequest().isSecure()) {
/*  975 */       if (log.isDebugEnabled())
/*  976 */         log.debug("  User data constraint already satisfied");
/*  977 */       return true;
/*      */     }
/*      */     
/*  980 */     int redirectPort = request.getConnector().getRedirectPort();
/*      */     
/*      */ 
/*  983 */     if (redirectPort <= 0) {
/*  984 */       if (log.isDebugEnabled())
/*  985 */         log.debug("  SSL redirect is disabled");
/*  986 */       response.sendError(403, request.getRequestURI());
/*      */       
/*      */ 
/*  989 */       return false;
/*      */     }
/*      */     
/*      */ 
/*  993 */     StringBuilder file = new StringBuilder();
/*  994 */     String protocol = "https";
/*  995 */     String host = request.getServerName();
/*      */     
/*  997 */     file.append(protocol).append("://").append(host);
/*      */     
/*  999 */     if (redirectPort != 443) {
/* 1000 */       file.append(":").append(redirectPort);
/*      */     }
/*      */     
/* 1003 */     file.append(request.getRequestURI());
/* 1004 */     String requestedSessionId = request.getRequestedSessionId();
/* 1005 */     if ((requestedSessionId != null) && (request.isRequestedSessionIdFromURL()))
/*      */     {
/* 1007 */       file.append(";");
/* 1008 */       file.append(SessionConfig.getSessionUriParamName(request.getContext()));
/*      */       
/* 1010 */       file.append("=");
/* 1011 */       file.append(requestedSessionId);
/*      */     }
/* 1013 */     String queryString = request.getQueryString();
/* 1014 */     if (queryString != null) {
/* 1015 */       file.append('?');
/* 1016 */       file.append(queryString);
/*      */     }
/* 1018 */     if (log.isDebugEnabled())
/* 1019 */       log.debug("  Redirecting to " + file.toString());
/* 1020 */     response.sendRedirect(file.toString(), this.transportGuaranteeRedirectStatus);
/* 1021 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removePropertyChangeListener(PropertyChangeListener listener)
/*      */   {
/* 1034 */     this.support.removePropertyChangeListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void initInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1042 */     super.initInternal();
/*      */     
/*      */ 
/* 1045 */     if (this.container != null) {
/* 1046 */       this.containerLog = this.container.getLogger();
/*      */     }
/*      */     
/* 1049 */     this.x509UsernameRetriever = createUsernameRetriever(this.x509UsernameRetrieverClassName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void startInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1062 */     if (this.credentialHandler == null) {
/* 1063 */       this.credentialHandler = new MessageDigestCredentialHandler();
/*      */     }
/*      */     
/* 1066 */     setState(LifecycleState.STARTING);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void stopInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1080 */     setState(LifecycleState.STOPPING);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1089 */     StringBuilder sb = new StringBuilder("Realm[");
/* 1090 */     sb.append(getName());
/* 1091 */     sb.append(']');
/* 1092 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected boolean hasMessageDigest()
/*      */   {
/* 1099 */     CredentialHandler ch = this.credentialHandler;
/* 1100 */     if ((ch instanceof MessageDigestCredentialHandler)) {
/* 1101 */       return ((MessageDigestCredentialHandler)ch).getAlgorithm() != null;
/*      */     }
/* 1103 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getDigest(String username, String realmName)
/*      */   {
/* 1114 */     if (hasMessageDigest())
/*      */     {
/* 1116 */       return getPassword(username);
/*      */     }
/*      */     
/* 1119 */     String digestValue = username + ":" + realmName + ":" + getPassword(username);
/*      */     
/*      */ 
/* 1122 */     byte[] valueBytes = null;
/*      */     try {
/* 1124 */       valueBytes = digestValue.getBytes(getDigestCharset());
/*      */     } catch (UnsupportedEncodingException uee) {
/* 1126 */       log.error("Illegal digestEncoding: " + getDigestEncoding(), uee);
/* 1127 */       throw new IllegalArgumentException(uee.getMessage());
/*      */     }
/*      */     
/* 1130 */     return MD5Encoder.encode(ConcurrentMessageDigest.digestMD5(new byte[][] { valueBytes }));
/*      */   }
/*      */   
/*      */   private String getDigestEncoding()
/*      */   {
/* 1135 */     CredentialHandler ch = this.credentialHandler;
/* 1136 */     if ((ch instanceof MessageDigestCredentialHandler)) {
/* 1137 */       return ((MessageDigestCredentialHandler)ch).getEncoding();
/*      */     }
/* 1139 */     return null;
/*      */   }
/*      */   
/*      */   private Charset getDigestCharset() throws UnsupportedEncodingException
/*      */   {
/* 1144 */     String charset = getDigestEncoding();
/* 1145 */     if (charset == null) {
/* 1146 */       return StandardCharsets.ISO_8859_1;
/*      */     }
/* 1148 */     return B2CConverter.getCharset(charset);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Principal getPrincipal(X509Certificate usercert)
/*      */   {
/* 1174 */     String username = this.x509UsernameRetriever.getUsername(usercert);
/*      */     
/* 1176 */     if (log.isDebugEnabled()) {
/* 1177 */       log.debug(sm.getString("realmBase.gotX509Username", new Object[] { username }));
/*      */     }
/* 1179 */     return getPrincipal(username);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Principal getPrincipal(String username, GSSCredential gssCredential)
/*      */   {
/* 1193 */     Principal p = getPrincipal(username);
/*      */     
/* 1195 */     if ((p instanceof GenericPrincipal)) {
/* 1196 */       ((GenericPrincipal)p).setGssCredential(gssCredential);
/*      */     }
/*      */     
/* 1199 */     return p;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Server getServer()
/*      */   {
/* 1210 */     Container c = this.container;
/* 1211 */     if ((c instanceof Context)) {
/* 1212 */       c = c.getParent();
/*      */     }
/* 1214 */     if ((c instanceof Host)) {
/* 1215 */       c = c.getParent();
/*      */     }
/* 1217 */     if ((c instanceof Engine)) {
/* 1218 */       Service s = ((Engine)c).getService();
/* 1219 */       if (s != null) {
/* 1220 */         return s.getServer();
/*      */       }
/*      */     }
/* 1223 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String Digest(String credentials, String algorithm, String encoding)
/*      */   {
/*      */     try
/*      */     {
/* 1246 */       MessageDigest md = (MessageDigest)MessageDigest.getInstance(algorithm).clone();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1251 */       if (encoding == null) {
/* 1252 */         md.update(credentials.getBytes());
/*      */       } else {
/* 1254 */         md.update(credentials.getBytes(encoding));
/*      */       }
/*      */       
/*      */ 
/* 1258 */       return HexUtils.toHexString(md.digest());
/*      */     } catch (Exception ex) {
/* 1260 */       log.error(ex); }
/* 1261 */     return credentials;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void main(String[] args)
/*      */   {
/* 1305 */     int saltLength = -1;
/* 1306 */     int iterations = -1;
/* 1307 */     int keyLength = -1;
/*      */     
/* 1309 */     String encoding = Charset.defaultCharset().name();
/*      */     
/*      */ 
/* 1312 */     String algorithm = null;
/* 1313 */     String handlerClassName = null;
/*      */     
/* 1315 */     if (args.length == 0) {
/* 1316 */       usage();
/* 1317 */       return;
/*      */     }
/*      */     
/* 1320 */     int argIndex = 0;
/*      */     
/* 1322 */     while ((args.length > argIndex + 2) && (args[argIndex].length() == 2) && (args[argIndex].charAt(0) == '-'))
/*      */     {
/* 1324 */       switch (args[argIndex].charAt(1)) {
/*      */       case 'a': 
/* 1326 */         algorithm = args[(argIndex + 1)];
/* 1327 */         break;
/*      */       
/*      */       case 'e': 
/* 1330 */         encoding = args[(argIndex + 1)];
/* 1331 */         break;
/*      */       
/*      */       case 'i': 
/* 1334 */         iterations = Integer.parseInt(args[(argIndex + 1)]);
/* 1335 */         break;
/*      */       
/*      */       case 's': 
/* 1338 */         saltLength = Integer.parseInt(args[(argIndex + 1)]);
/* 1339 */         break;
/*      */       
/*      */       case 'k': 
/* 1342 */         keyLength = Integer.parseInt(args[(argIndex + 1)]);
/* 1343 */         break;
/*      */       
/*      */       case 'h': 
/* 1346 */         handlerClassName = args[(argIndex + 1)];
/* 1347 */         break;
/*      */       case 'b': case 'c': case 'd': case 'f': case 'g': case 'j': case 'l': 
/*      */       case 'm': case 'n': case 'o': case 'p': case 'q': case 'r': default: 
/* 1350 */         usage();
/* 1351 */         return;
/*      */       }
/*      */       
/* 1354 */       argIndex += 2;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1366 */     if ((algorithm == null) && (handlerClassName == null)) {
/* 1367 */       algorithm = "SHA-512";
/*      */     }
/*      */     
/* 1370 */     CredentialHandler handler = null;
/*      */     
/* 1372 */     if (handlerClassName == null) {
/* 1373 */       for (Class<? extends DigestCredentialHandlerBase> clazz : credentialHandlerClasses) {
/*      */         try {
/* 1375 */           handler = (CredentialHandler)clazz.newInstance();
/* 1376 */           if (IntrospectionUtils.setProperty(handler, "algorithm", algorithm)) {
/*      */             break;
/*      */           }
/*      */         }
/*      */         catch (InstantiationException|IllegalAccessException e) {
/* 1381 */           throw new RuntimeException(e);
/*      */         }
/*      */       }
/*      */     } else {
/*      */       try {
/* 1386 */         Class<?> clazz = Class.forName(handlerClassName);
/* 1387 */         handler = (DigestCredentialHandlerBase)clazz.newInstance();
/* 1388 */         IntrospectionUtils.setProperty(handler, "algorithm", algorithm);
/*      */       }
/*      */       catch (InstantiationException|IllegalAccessException|ClassNotFoundException e) {
/* 1391 */         throw new RuntimeException(e);
/*      */       }
/*      */     }
/*      */     
/* 1395 */     if (handler == null) {
/* 1396 */       throw new RuntimeException(new NoSuchAlgorithmException(algorithm));
/*      */     }
/*      */     
/* 1399 */     IntrospectionUtils.setProperty(handler, "encoding", encoding);
/* 1400 */     if (iterations > 0) {
/* 1401 */       IntrospectionUtils.setProperty(handler, "iterations", Integer.toString(iterations));
/*      */     }
/* 1403 */     if (saltLength > -1) {
/* 1404 */       IntrospectionUtils.setProperty(handler, "saltLength", Integer.toString(saltLength));
/*      */     }
/* 1406 */     if (keyLength > 0) {
/* 1407 */       IntrospectionUtils.setProperty(handler, "keyLength", Integer.toString(keyLength));
/*      */     }
/* 1410 */     for (; 
/* 1410 */         argIndex < args.length; argIndex++) {
/* 1411 */       String credential = args[argIndex];
/* 1412 */       System.out.print(credential + ":");
/* 1413 */       System.out.println(handler.mutate(credential));
/*      */     }
/*      */   }
/*      */   
/*      */   private static void usage()
/*      */   {
/* 1419 */     System.out.println("Usage: RealmBase [-a <algorithm>] [-e <encoding>] [-i <iterations>] [-s <salt-length>] [-k <key-length>] [-h <handler-class-name>] <credentials>");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getObjectNameKeyProperties()
/*      */   {
/* 1430 */     StringBuilder keyProperties = new StringBuilder("type=Realm");
/* 1431 */     keyProperties.append(getRealmSuffix());
/* 1432 */     keyProperties.append(this.container.getMBeanKeyProperties());
/*      */     
/* 1434 */     return keyProperties.toString();
/*      */   }
/*      */   
/*      */   public String getDomainInternal()
/*      */   {
/* 1439 */     return this.container.getDomain();
/*      */   }
/*      */   
/*      */   public RealmBase()
/*      */   {
/*   95 */     this.container = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  101 */     this.containerLog = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  116 */     this.support = new PropertyChangeSupport(this);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  122 */     this.validate = true;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  138 */     this.allRolesMode = AllRolesMode.STRICT_MODE;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  145 */     this.stripRealmForGss = true;
/*      */     
/*      */ 
/*  148 */     this.transportGuaranteeRedirectStatus = 302;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1442 */     this.realmPath = "/realm0";
/*      */   }
/*      */   
/* 1445 */   public String getRealmPath() { return this.realmPath; }
/*      */   
/*      */   public void setRealmPath(String theRealmPath)
/*      */   {
/* 1449 */     this.realmPath = theRealmPath;
/*      */   }
/*      */   
/*      */   protected String getRealmSuffix() {
/* 1453 */     return ",realmPath=" + getRealmPath();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static class AllRolesMode
/*      */   {
/*      */     private final String name;
/*      */     
/*      */ 
/* 1463 */     public static final AllRolesMode STRICT_MODE = new AllRolesMode("strict");
/*      */     
/*      */ 
/* 1466 */     public static final AllRolesMode AUTH_ONLY_MODE = new AllRolesMode("authOnly");
/*      */     
/*      */ 
/* 1469 */     public static final AllRolesMode STRICT_AUTH_ONLY_MODE = new AllRolesMode("strictAuthOnly");
/*      */     
/*      */     static AllRolesMode toMode(String name)
/*      */     {
/*      */       AllRolesMode mode;
/* 1474 */       if (name.equalsIgnoreCase(STRICT_MODE.name)) {
/* 1475 */         mode = STRICT_MODE; } else { AllRolesMode mode;
/* 1476 */         if (name.equalsIgnoreCase(AUTH_ONLY_MODE.name)) {
/* 1477 */           mode = AUTH_ONLY_MODE; } else { AllRolesMode mode;
/* 1478 */           if (name.equalsIgnoreCase(STRICT_AUTH_ONLY_MODE.name)) {
/* 1479 */             mode = STRICT_AUTH_ONLY_MODE;
/*      */           } else
/* 1481 */             throw new IllegalStateException("Unknown mode, must be one of: strict, authOnly, strictAuthOnly"); } }
/* 1482 */       AllRolesMode mode; return mode;
/*      */     }
/*      */     
/*      */     private AllRolesMode(String name)
/*      */     {
/* 1487 */       this.name = name;
/*      */     }
/*      */     
/*      */ 
/*      */     public boolean equals(Object o)
/*      */     {
/* 1493 */       boolean equals = false;
/* 1494 */       if ((o instanceof AllRolesMode))
/*      */       {
/* 1496 */         AllRolesMode mode = (AllRolesMode)o;
/* 1497 */         equals = this.name.equals(mode.name);
/*      */       }
/* 1499 */       return equals;
/*      */     }
/*      */     
/*      */     public int hashCode()
/*      */     {
/* 1504 */       return this.name.hashCode();
/*      */     }
/*      */     
/*      */     public String toString()
/*      */     {
/* 1509 */       return this.name;
/*      */     }
/*      */   }
/*      */   
/*      */   private static X509UsernameRetriever createUsernameRetriever(String className) throws LifecycleException
/*      */   {
/* 1515 */     if ((null == className) || ("".equals(className.trim()))) {
/* 1516 */       return new X509SubjectDnRetriever();
/*      */     }
/*      */     try
/*      */     {
/* 1520 */       Class<? extends X509UsernameRetriever> clazz = Class.forName(className);
/* 1521 */       return (X509UsernameRetriever)clazz.newInstance();
/*      */     } catch (ClassNotFoundException e) {
/* 1523 */       throw new LifecycleException(sm.getString("realmBase.createUsernameRetriever.ClassNotFoundException", new Object[] { className }), e);
/*      */     } catch (InstantiationException e) {
/* 1525 */       throw new LifecycleException(sm.getString("realmBase.createUsernameRetriever.InstantiationException", new Object[] { className }), e);
/*      */     } catch (IllegalAccessException e) {
/* 1527 */       throw new LifecycleException(sm.getString("realmBase.createUsernameRetriever.IllegalAccessException", new Object[] { className }), e);
/*      */     } catch (ClassCastException e) {
/* 1529 */       throw new LifecycleException(sm.getString("realmBase.createUsernameRetriever.ClassCastException", new Object[] { className }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public String[] getRoles(Principal principal)
/*      */   {
/* 1536 */     if ((principal instanceof GenericPrincipal)) {
/* 1537 */       return ((GenericPrincipal)principal).getRoles();
/*      */     }
/*      */     
/* 1540 */     String className = principal.getClass().getSimpleName();
/* 1541 */     throw new IllegalStateException(sm.getString("realmBase.cannotGetRoles", new Object[] { className }));
/*      */   }
/*      */   
/*      */   public void backgroundProcess() {}
/*      */   
/*      */   protected abstract String getName();
/*      */   
/*      */   protected abstract String getPassword(String paramString);
/*      */   
/*      */   protected abstract Principal getPrincipal(String paramString);
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\realm\RealmBase.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */