/*      */ package org.apache.catalina.realm;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.security.GeneralSecurityException;
/*      */ import java.security.KeyManagementException;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.security.Principal;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import javax.naming.AuthenticationException;
/*      */ import javax.naming.CommunicationException;
/*      */ import javax.naming.CompositeName;
/*      */ import javax.naming.InvalidNameException;
/*      */ import javax.naming.Name;
/*      */ import javax.naming.NameNotFoundException;
/*      */ import javax.naming.NameParser;
/*      */ import javax.naming.NamingEnumeration;
/*      */ import javax.naming.NamingException;
/*      */ import javax.naming.PartialResultException;
/*      */ import javax.naming.ServiceUnavailableException;
/*      */ import javax.naming.directory.Attribute;
/*      */ import javax.naming.directory.Attributes;
/*      */ import javax.naming.directory.DirContext;
/*      */ import javax.naming.directory.InitialDirContext;
/*      */ import javax.naming.directory.SearchControls;
/*      */ import javax.naming.directory.SearchResult;
/*      */ import javax.naming.ldap.InitialLdapContext;
/*      */ import javax.naming.ldap.LdapContext;
/*      */ import javax.naming.ldap.StartTlsRequest;
/*      */ import javax.naming.ldap.StartTlsResponse;
/*      */ import javax.net.ssl.HostnameVerifier;
/*      */ import javax.net.ssl.SSLContext;
/*      */ import javax.net.ssl.SSLParameters;
/*      */ import javax.net.ssl.SSLSession;
/*      */ import javax.net.ssl.SSLSocketFactory;
/*      */ import org.apache.catalina.CredentialHandler;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.ietf.jgss.GSSCredential;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JNDIRealm
/*      */   extends RealmBase
/*      */ {
/*      */   protected String authentication;
/*      */   protected String connectionName;
/*      */   protected String connectionPassword;
/*      */   protected String connectionURL;
/*      */   protected DirContext context;
/*      */   protected String contextFactory;
/*      */   protected String derefAliases;
/*      */   public static final String DEREF_ALIASES = "java.naming.ldap.derefAliases";
/*      */   protected static final String name = "JNDIRealm";
/*      */   protected String protocol;
/*      */   protected boolean adCompat;
/*      */   protected String referrals;
/*      */   protected String userBase;
/*      */   protected String userSearch;
/*      */   private boolean userSearchAsUser;
/*      */   protected MessageFormat userSearchFormat;
/*      */   protected boolean userSubtree;
/*      */   protected String userPassword;
/*      */   protected String userRoleAttribute;
/*      */   protected String[] userPatternArray;
/*      */   protected String userPattern;
/*      */   protected MessageFormat[] userPatternFormatArray;
/*      */   protected String roleBase;
/*      */   protected MessageFormat roleBaseFormat;
/*      */   protected MessageFormat roleFormat;
/*      */   protected String userRoleName;
/*      */   protected String roleName;
/*      */   protected String roleSearch;
/*      */   protected boolean roleSubtree;
/*      */   protected boolean roleNested;
/*      */   protected boolean roleSearchAsUser;
/*      */   protected String alternateURL;
/*      */   protected int connectionAttempt;
/*      */   protected String commonRole;
/*      */   protected String connectionTimeout;
/*      */   protected long sizeLimit;
/*      */   protected int timeLimit;
/*      */   protected boolean useDelegatedCredential;
/*      */   protected String spnegoDelegationQop;
/*      */   private boolean useStartTls;
/*      */   private StartTlsResponse tls;
/*      */   private String[] cipherSuitesArray;
/*      */   private HostnameVerifier hostnameVerifier;
/*      */   private SSLSocketFactory sslSocketFactory;
/*      */   private String sslSocketFactoryClassName;
/*      */   private String cipherSuites;
/*      */   private String hostNameVerifierClassName;
/*      */   private String sslProtocol;
/*      */   
/*      */   public JNDIRealm()
/*      */   {
/*  192 */     this.authentication = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  197 */     this.connectionName = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  203 */     this.connectionPassword = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  209 */     this.connectionURL = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  215 */     this.context = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  223 */     this.contextFactory = "com.sun.jndi.ldap.LdapCtxFactory";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  229 */     this.derefAliases = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  248 */     this.protocol = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  258 */     this.adCompat = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  267 */     this.referrals = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  273 */     this.userBase = "";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  280 */     this.userSearch = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  289 */     this.userSearchAsUser = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  296 */     this.userSearchFormat = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  302 */     this.userSubtree = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  308 */     this.userPassword = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  316 */     this.userRoleAttribute = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  327 */     this.userPatternArray = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  335 */     this.userPattern = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  342 */     this.userPatternFormatArray = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  347 */     this.roleBase = "";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  354 */     this.roleBaseFormat = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  361 */     this.roleFormat = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  368 */     this.userRoleName = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  374 */     this.roleName = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  382 */     this.roleSearch = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  388 */     this.roleSubtree = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  393 */     this.roleNested = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  401 */     this.roleSearchAsUser = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  412 */     this.connectionAttempt = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  417 */     this.commonRole = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  424 */     this.connectionTimeout = "5000";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  430 */     this.sizeLimit = 0L;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  436 */     this.timeLimit = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  443 */     this.useDelegatedCredential = true;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  452 */     this.spnegoDelegationQop = "auth-conf";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  457 */     this.useStartTls = false;
/*      */     
/*  459 */     this.tls = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  465 */     this.cipherSuitesArray = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  471 */     this.hostnameVerifier = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  476 */     this.sslSocketFactory = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAuthentication()
/*      */   {
/*  508 */     return this.authentication;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAuthentication(String authentication)
/*      */   {
/*  519 */     this.authentication = authentication;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getConnectionName()
/*      */   {
/*  528 */     return this.connectionName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectionName(String connectionName)
/*      */   {
/*  540 */     this.connectionName = connectionName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getConnectionPassword()
/*      */   {
/*  550 */     return this.connectionPassword;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectionPassword(String connectionPassword)
/*      */   {
/*  562 */     this.connectionPassword = connectionPassword;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getConnectionURL()
/*      */   {
/*  572 */     return this.connectionURL;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectionURL(String connectionURL)
/*      */   {
/*  584 */     this.connectionURL = connectionURL;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getContextFactory()
/*      */   {
/*  594 */     return this.contextFactory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setContextFactory(String contextFactory)
/*      */   {
/*  606 */     this.contextFactory = contextFactory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDerefAliases()
/*      */   {
/*  614 */     return this.derefAliases;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDerefAliases(String derefAliases)
/*      */   {
/*  623 */     this.derefAliases = derefAliases;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProtocol()
/*      */   {
/*  631 */     return this.protocol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProtocol(String protocol)
/*      */   {
/*  642 */     this.protocol = protocol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getAdCompat()
/*      */   {
/*  651 */     return this.adCompat;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAdCompat(boolean adCompat)
/*      */   {
/*  661 */     this.adCompat = adCompat;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getReferrals()
/*      */   {
/*  669 */     return this.referrals;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReferrals(String referrals)
/*      */   {
/*  679 */     this.referrals = referrals;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getUserBase()
/*      */   {
/*  688 */     return this.userBase;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserBase(String userBase)
/*      */   {
/*  700 */     this.userBase = userBase;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getUserSearch()
/*      */   {
/*  710 */     return this.userSearch;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserSearch(String userSearch)
/*      */   {
/*  722 */     this.userSearch = userSearch;
/*  723 */     if (userSearch == null) {
/*  724 */       this.userSearchFormat = null;
/*      */     } else {
/*  726 */       this.userSearchFormat = new MessageFormat(userSearch);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isUserSearchAsUser()
/*      */   {
/*  732 */     return this.userSearchAsUser;
/*      */   }
/*      */   
/*      */   public void setUserSearchAsUser(boolean userSearchAsUser)
/*      */   {
/*  737 */     this.userSearchAsUser = userSearchAsUser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUserSubtree()
/*      */   {
/*  746 */     return this.userSubtree;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserSubtree(boolean userSubtree)
/*      */   {
/*  758 */     this.userSubtree = userSubtree;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getUserRoleName()
/*      */   {
/*  768 */     return this.userRoleName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserRoleName(String userRoleName)
/*      */   {
/*  779 */     this.userRoleName = userRoleName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRoleBase()
/*      */   {
/*  789 */     return this.roleBase;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRoleBase(String roleBase)
/*      */   {
/*  801 */     this.roleBase = roleBase;
/*  802 */     if (roleBase == null) {
/*  803 */       this.roleBaseFormat = null;
/*      */     } else {
/*  805 */       this.roleBaseFormat = new MessageFormat(roleBase);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRoleName()
/*      */   {
/*  815 */     return this.roleName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRoleName(String roleName)
/*      */   {
/*  827 */     this.roleName = roleName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRoleSearch()
/*      */   {
/*  837 */     return this.roleSearch;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRoleSearch(String roleSearch)
/*      */   {
/*  849 */     this.roleSearch = roleSearch;
/*  850 */     if (roleSearch == null) {
/*  851 */       this.roleFormat = null;
/*      */     } else {
/*  853 */       this.roleFormat = new MessageFormat(roleSearch);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isRoleSearchAsUser()
/*      */   {
/*  859 */     return this.roleSearchAsUser;
/*      */   }
/*      */   
/*      */   public void setRoleSearchAsUser(boolean roleSearchAsUser)
/*      */   {
/*  864 */     this.roleSearchAsUser = roleSearchAsUser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getRoleSubtree()
/*      */   {
/*  873 */     return this.roleSubtree;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRoleSubtree(boolean roleSubtree)
/*      */   {
/*  885 */     this.roleSubtree = roleSubtree;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getRoleNested()
/*      */   {
/*  894 */     return this.roleNested;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRoleNested(boolean roleNested)
/*      */   {
/*  906 */     this.roleNested = roleNested;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getUserPassword()
/*      */   {
/*  916 */     return this.userPassword;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserPassword(String userPassword)
/*      */   {
/*  928 */     this.userPassword = userPassword;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getUserRoleAttribute()
/*      */   {
/*  934 */     return this.userRoleAttribute;
/*      */   }
/*      */   
/*      */   public void setUserRoleAttribute(String userRoleAttribute) {
/*  938 */     this.userRoleAttribute = userRoleAttribute;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getUserPattern()
/*      */   {
/*  946 */     return this.userPattern;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserPattern(String userPattern)
/*      */   {
/*  965 */     this.userPattern = userPattern;
/*  966 */     if (userPattern == null) {
/*  967 */       this.userPatternArray = null;
/*      */     } else {
/*  969 */       this.userPatternArray = parseUserPatternString(userPattern);
/*  970 */       int len = this.userPatternArray.length;
/*  971 */       this.userPatternFormatArray = new MessageFormat[len];
/*  972 */       for (int i = 0; i < len; i++) {
/*  973 */         this.userPatternFormatArray[i] = new MessageFormat(this.userPatternArray[i]);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAlternateURL()
/*      */   {
/*  987 */     return this.alternateURL;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAlternateURL(String alternateURL)
/*      */   {
/*  999 */     this.alternateURL = alternateURL;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCommonRole()
/*      */   {
/* 1009 */     return this.commonRole;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCommonRole(String commonRole)
/*      */   {
/* 1021 */     this.commonRole = commonRole;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getConnectionTimeout()
/*      */   {
/* 1031 */     return this.connectionTimeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectionTimeout(String timeout)
/*      */   {
/* 1043 */     this.connectionTimeout = timeout;
/*      */   }
/*      */   
/*      */ 
/*      */   public long getSizeLimit()
/*      */   {
/* 1049 */     return this.sizeLimit;
/*      */   }
/*      */   
/*      */   public void setSizeLimit(long sizeLimit)
/*      */   {
/* 1054 */     this.sizeLimit = sizeLimit;
/*      */   }
/*      */   
/*      */   public int getTimeLimit()
/*      */   {
/* 1059 */     return this.timeLimit;
/*      */   }
/*      */   
/*      */   public void setTimeLimit(int timeLimit)
/*      */   {
/* 1064 */     this.timeLimit = timeLimit;
/*      */   }
/*      */   
/*      */   public boolean isUseDelegatedCredential()
/*      */   {
/* 1069 */     return this.useDelegatedCredential;
/*      */   }
/*      */   
/*      */   public void setUseDelegatedCredential(boolean useDelegatedCredential) {
/* 1073 */     this.useDelegatedCredential = useDelegatedCredential;
/*      */   }
/*      */   
/*      */   public String getSpnegoDelegationQop()
/*      */   {
/* 1078 */     return this.spnegoDelegationQop;
/*      */   }
/*      */   
/*      */   public void setSpnegoDelegationQop(String spnegoDelegationQop) {
/* 1082 */     this.spnegoDelegationQop = spnegoDelegationQop;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUseStartTls()
/*      */   {
/* 1090 */     return this.useStartTls;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseStartTls(boolean useStartTls)
/*      */   {
/* 1101 */     this.useStartTls = useStartTls;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String[] getCipherSuitesArray()
/*      */   {
/* 1109 */     if ((this.cipherSuites == null) || (this.cipherSuitesArray != null)) {
/* 1110 */       return this.cipherSuitesArray;
/*      */     }
/* 1112 */     if (this.cipherSuites.trim().isEmpty()) {
/* 1113 */       this.containerLog.warn(sm.getString("jndiRealm.emptyCipherSuites"));
/* 1114 */       this.cipherSuitesArray = null;
/*      */     } else {
/* 1116 */       this.cipherSuitesArray = this.cipherSuites.trim().split("\\s*,\\s*");
/* 1117 */       this.containerLog.debug(sm.getString("jndiRealm.cipherSuites", new Object[] { Arrays.asList(this.cipherSuitesArray) }));
/*      */     }
/*      */     
/* 1120 */     return this.cipherSuitesArray;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCipherSuites(String suites)
/*      */   {
/* 1131 */     this.cipherSuites = suites;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getHostnameVerifierClassName()
/*      */   {
/* 1140 */     if (this.hostnameVerifier == null) {
/* 1141 */       return "";
/*      */     }
/* 1143 */     return this.hostnameVerifier.getClass().getCanonicalName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHostnameVerifierClassName(String verifierClassName)
/*      */   {
/* 1155 */     if (verifierClassName != null) {
/* 1156 */       this.hostNameVerifierClassName = verifierClassName.trim();
/*      */     } else {
/* 1158 */       this.hostNameVerifierClassName = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public HostnameVerifier getHostnameVerifier()
/*      */   {
/* 1167 */     if (this.hostnameVerifier != null) {
/* 1168 */       return this.hostnameVerifier;
/*      */     }
/* 1170 */     if ((this.hostNameVerifierClassName == null) || (this.hostNameVerifierClassName.equals("")))
/*      */     {
/* 1172 */       return null;
/*      */     }
/*      */     try {
/* 1175 */       Object o = constructInstance(this.hostNameVerifierClassName);
/* 1176 */       if ((o instanceof HostnameVerifier)) {
/* 1177 */         this.hostnameVerifier = ((HostnameVerifier)o);
/* 1178 */         return this.hostnameVerifier;
/*      */       }
/* 1180 */       throw new IllegalArgumentException(sm.getString("jndiRealm.invalidHostnameVerifier", new Object[] { this.hostNameVerifierClassName }));
/*      */ 
/*      */     }
/*      */     catch (ClassNotFoundException|SecurityException|InstantiationException|IllegalAccessException e)
/*      */     {
/*      */ 
/* 1186 */       throw new IllegalArgumentException(sm.getString("jndiRealm.invalidHostnameVerifier", new Object[] { this.hostNameVerifierClassName }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSslSocketFactoryClassName(String factoryClassName)
/*      */   {
/* 1202 */     this.sslSocketFactoryClassName = factoryClassName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSslProtocol(String protocol)
/*      */   {
/* 1212 */     this.sslProtocol = protocol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private String[] getSupportedSslProtocols()
/*      */   {
/*      */     try
/*      */     {
/* 1221 */       SSLContext sslContext = SSLContext.getDefault();
/* 1222 */       return sslContext.getSupportedSSLParameters().getProtocols();
/*      */     } catch (NoSuchAlgorithmException e) {
/* 1224 */       throw new RuntimeException(sm.getString("jndiRealm.exception"), e);
/*      */     }
/*      */   }
/*      */   
/*      */   private Object constructInstance(String className)
/*      */     throws ClassNotFoundException, InstantiationException, IllegalAccessException
/*      */   {
/* 1231 */     Class<?> clazz = Class.forName(className);
/* 1232 */     return clazz.newInstance();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal authenticate(String username, String credentials)
/*      */   {
/* 1254 */     DirContext context = null;
/* 1255 */     Principal principal = null;
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1260 */       context = open();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/* 1267 */         principal = authenticate(context, username, credentials);
/*      */ 
/*      */ 
/*      */       }
/*      */       catch (NullPointerException|CommunicationException|ServiceUnavailableException e)
/*      */       {
/*      */ 
/*      */ 
/* 1275 */         this.containerLog.info(sm.getString("jndiRealm.exception.retry"), e);
/*      */         
/*      */ 
/* 1278 */         if (context != null) {
/* 1279 */           close(context);
/*      */         }
/*      */         
/* 1282 */         context = open();
/*      */         
/*      */ 
/* 1285 */         principal = authenticate(context, username, credentials);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1290 */       release(context);
/*      */       
/*      */ 
/* 1293 */       return principal;
/*      */ 
/*      */     }
/*      */     catch (NamingException e)
/*      */     {
/* 1298 */       this.containerLog.error(sm.getString("jndiRealm.exception"), e);
/*      */       
/*      */ 
/* 1301 */       if (context != null) {
/* 1302 */         close(context);
/*      */       }
/*      */       
/* 1305 */       if (this.containerLog.isDebugEnabled())
/* 1306 */         this.containerLog.debug("Returning null principal."); }
/* 1307 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized Principal authenticate(DirContext context, String username, String credentials)
/*      */     throws NamingException
/*      */   {
/* 1337 */     if ((username == null) || (username.equals("")) || (credentials == null) || (credentials.equals("")))
/*      */     {
/* 1339 */       if (this.containerLog.isDebugEnabled())
/* 1340 */         this.containerLog.debug("username null or empty: returning null principal.");
/* 1341 */       return null;
/*      */     }
/*      */     
/* 1344 */     if (this.userPatternArray != null) {
/* 1345 */       for (int curUserPattern = 0; 
/* 1346 */           curUserPattern < this.userPatternFormatArray.length; 
/* 1347 */           curUserPattern++)
/*      */       {
/* 1349 */         User user = getUser(context, username, credentials, curUserPattern);
/* 1350 */         if (user != null) {
/*      */           try
/*      */           {
/* 1353 */             if (checkCredentials(context, user, credentials))
/*      */             {
/* 1355 */               List<String> roles = getRoles(context, user);
/* 1356 */               if (this.containerLog.isDebugEnabled()) {
/* 1357 */                 Iterator<String> it = roles.iterator();
/*      */                 
/* 1359 */                 while (it.hasNext()) {
/* 1360 */                   this.containerLog.debug("Found role: " + (String)it.next());
/*      */                 }
/*      */               }
/* 1363 */               return new GenericPrincipal(username, credentials, roles);
/*      */             }
/*      */             
/*      */           }
/*      */           catch (InvalidNameException ine)
/*      */           {
/* 1369 */             this.containerLog.warn(sm.getString("jndiRealm.exception"), ine);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1377 */       return null;
/*      */     }
/*      */     
/* 1380 */     User user = getUser(context, username, credentials);
/* 1381 */     if (user == null) {
/* 1382 */       return null;
/*      */     }
/*      */     
/* 1385 */     if (!checkCredentials(context, user, credentials)) {
/* 1386 */       return null;
/*      */     }
/*      */     
/* 1389 */     List<String> roles = getRoles(context, user);
/* 1390 */     if (this.containerLog.isDebugEnabled()) {
/* 1391 */       Iterator<String> it = roles.iterator();
/*      */       
/* 1393 */       while (it.hasNext()) {
/* 1394 */         this.containerLog.debug("Found role: " + (String)it.next());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1399 */     return new GenericPrincipal(username, credentials, roles);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected User getUser(DirContext context, String username)
/*      */     throws NamingException
/*      */   {
/* 1419 */     return getUser(context, username, null, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected User getUser(DirContext context, String username, String credentials)
/*      */     throws NamingException
/*      */   {
/* 1439 */     return getUser(context, username, credentials, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected User getUser(DirContext context, String username, String credentials, int curUserPattern)
/*      */     throws NamingException
/*      */   {
/* 1465 */     User user = null;
/*      */     
/*      */ 
/* 1468 */     ArrayList<String> list = new ArrayList();
/* 1469 */     if (this.userPassword != null)
/* 1470 */       list.add(this.userPassword);
/* 1471 */     if (this.userRoleName != null)
/* 1472 */       list.add(this.userRoleName);
/* 1473 */     if (this.userRoleAttribute != null) {
/* 1474 */       list.add(this.userRoleAttribute);
/*      */     }
/* 1476 */     String[] attrIds = new String[list.size()];
/* 1477 */     list.toArray(attrIds);
/*      */     
/*      */ 
/* 1480 */     if ((this.userPatternFormatArray != null) && (curUserPattern >= 0)) {
/* 1481 */       user = getUserByPattern(context, username, credentials, attrIds, curUserPattern);
/* 1482 */       if (this.containerLog.isDebugEnabled()) {
/* 1483 */         this.containerLog.debug("Found user by pattern [" + user + "]");
/*      */       }
/*      */     } else {
/* 1486 */       boolean thisUserSearchAsUser = isUserSearchAsUser();
/*      */       try {
/* 1488 */         if (thisUserSearchAsUser) {
/* 1489 */           userCredentialsAdd(context, username, credentials);
/*      */         }
/* 1491 */         user = getUserBySearch(context, username, attrIds);
/*      */       } finally {
/* 1493 */         if (thisUserSearchAsUser) {
/* 1494 */           userCredentialsRemove(context);
/*      */         }
/*      */       }
/* 1497 */       if (this.containerLog.isDebugEnabled()) {
/* 1498 */         this.containerLog.debug("Found user by search [" + user + "]");
/*      */       }
/*      */     }
/*      */     
/* 1502 */     if ((this.userPassword == null) && (credentials != null) && (user != null))
/*      */     {
/*      */ 
/* 1505 */       return new User(user.getUserName(), user.getDN(), credentials, user.getRoles(), user.getUserRoleId());
/*      */     }
/*      */     
/*      */ 
/* 1509 */     return user;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected User getUserByPattern(DirContext context, String username, String[] attrIds, String dn)
/*      */     throws NamingException
/*      */   {
/* 1533 */     if ((attrIds == null) || (attrIds.length == 0)) {
/* 1534 */       return new User(username, dn, null, null, null);
/*      */     }
/*      */     
/*      */ 
/* 1538 */     Attributes attrs = null;
/*      */     try {
/* 1540 */       attrs = context.getAttributes(dn, attrIds);
/*      */     } catch (NameNotFoundException e) {
/* 1542 */       return null;
/*      */     }
/* 1544 */     if (attrs == null) {
/* 1545 */       return null;
/*      */     }
/*      */     
/* 1548 */     String password = null;
/* 1549 */     if (this.userPassword != null) {
/* 1550 */       password = getAttributeValue(this.userPassword, attrs);
/*      */     }
/* 1552 */     String userRoleAttrValue = null;
/* 1553 */     if (this.userRoleAttribute != null) {
/* 1554 */       userRoleAttrValue = getAttributeValue(this.userRoleAttribute, attrs);
/*      */     }
/*      */     
/*      */ 
/* 1558 */     ArrayList<String> roles = null;
/* 1559 */     if (this.userRoleName != null) {
/* 1560 */       roles = addAttributeValues(this.userRoleName, attrs, roles);
/*      */     }
/* 1562 */     return new User(username, dn, password, roles, userRoleAttrValue);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected User getUserByPattern(DirContext context, String username, String credentials, String[] attrIds, int curUserPattern)
/*      */     throws NamingException
/*      */   {
/* 1588 */     User user = null;
/*      */     
/* 1590 */     if ((username == null) || (this.userPatternFormatArray[curUserPattern] == null)) {
/* 1591 */       return null;
/*      */     }
/*      */     
/* 1594 */     String dn = this.userPatternFormatArray[curUserPattern].format(new String[] { username });
/*      */     try
/*      */     {
/* 1597 */       user = getUserByPattern(context, username, attrIds, dn);
/*      */     } catch (NameNotFoundException e) {
/* 1599 */       return null;
/*      */     }
/*      */     catch (NamingException e)
/*      */     {
/*      */       try {
/* 1604 */         userCredentialsAdd(context, dn, credentials);
/*      */         
/* 1606 */         user = getUserByPattern(context, username, attrIds, dn);
/*      */       } finally {
/* 1608 */         userCredentialsRemove(context);
/*      */       }
/*      */     }
/* 1611 */     return user;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected User getUserBySearch(DirContext context, String username, String[] attrIds)
/*      */     throws NamingException
/*      */   {
/* 1631 */     if ((username == null) || (this.userSearchFormat == null)) {
/* 1632 */       return null;
/*      */     }
/*      */     
/* 1635 */     String filter = this.userSearchFormat.format(new String[] { username });
/*      */     
/*      */ 
/* 1638 */     SearchControls constraints = new SearchControls();
/*      */     
/* 1640 */     if (this.userSubtree) {
/* 1641 */       constraints.setSearchScope(2);
/*      */     }
/*      */     else {
/* 1644 */       constraints.setSearchScope(1);
/*      */     }
/*      */     
/* 1647 */     constraints.setCountLimit(this.sizeLimit);
/* 1648 */     constraints.setTimeLimit(this.timeLimit);
/*      */     
/*      */ 
/* 1651 */     if (attrIds == null)
/* 1652 */       attrIds = new String[0];
/* 1653 */     constraints.setReturningAttributes(attrIds);
/*      */     
/* 1655 */     NamingEnumeration<SearchResult> results = context.search(this.userBase, filter, constraints);
/*      */     try
/*      */     {
/*      */       User localUser2;
/*      */       try
/*      */       {
/* 1661 */         if ((results == null) || (!results.hasMore())) {
/* 1662 */           return null;
/*      */         }
/*      */       } catch (PartialResultException ex) {
/* 1665 */         if (!this.adCompat) {
/* 1666 */           throw ex;
/*      */         }
/* 1668 */         return null;
/*      */       }
/*      */       
/*      */ 
/* 1672 */       SearchResult result = (SearchResult)results.next();
/*      */       
/*      */       try
/*      */       {
/* 1676 */         if (results.hasMore()) {
/* 1677 */           if (this.containerLog.isInfoEnabled())
/* 1678 */             this.containerLog.info("username " + username + " has multiple entries");
/* 1679 */           return null;
/*      */         }
/*      */       } catch (PartialResultException ex) {
/* 1682 */         if (!this.adCompat) {
/* 1683 */           throw ex;
/*      */         }
/*      */       }
/* 1686 */       String dn = getDistinguishedName(context, this.userBase, result);
/*      */       
/* 1688 */       if (this.containerLog.isTraceEnabled()) {
/* 1689 */         this.containerLog.trace("  entry found for " + username + " with dn " + dn);
/*      */       }
/*      */       
/* 1692 */       Attributes attrs = result.getAttributes();
/* 1693 */       if (attrs == null) {
/* 1694 */         return null;
/*      */       }
/*      */       
/* 1697 */       String password = null;
/* 1698 */       if (this.userPassword != null) {
/* 1699 */         password = getAttributeValue(this.userPassword, attrs);
/*      */       }
/* 1701 */       String userRoleAttrValue = null;
/* 1702 */       if (this.userRoleAttribute != null) {
/* 1703 */         userRoleAttrValue = getAttributeValue(this.userRoleAttribute, attrs);
/*      */       }
/*      */       
/*      */ 
/* 1707 */       ArrayList<String> roles = null;
/* 1708 */       if (this.userRoleName != null) {
/* 1709 */         roles = addAttributeValues(this.userRoleName, attrs, roles);
/*      */       }
/* 1711 */       return new User(username, dn, password, roles, userRoleAttrValue);
/*      */     } finally {
/* 1713 */       if (results != null) {
/* 1714 */         results.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean checkCredentials(DirContext context, User user, String credentials)
/*      */     throws NamingException
/*      */   {
/* 1740 */     boolean validated = false;
/*      */     
/* 1742 */     if (this.userPassword == null) {
/* 1743 */       validated = bindAsUser(context, user, credentials);
/*      */     } else {
/* 1745 */       validated = compareCredentials(context, user, credentials);
/*      */     }
/*      */     
/* 1748 */     if (this.containerLog.isTraceEnabled()) {
/* 1749 */       if (validated) {
/* 1750 */         this.containerLog.trace(sm.getString("jndiRealm.authenticateSuccess", new Object[] { user.getUserName() }));
/*      */       }
/*      */       else {
/* 1753 */         this.containerLog.trace(sm.getString("jndiRealm.authenticateFailure", new Object[] { user.getUserName() }));
/*      */       }
/*      */     }
/*      */     
/* 1757 */     return validated;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean compareCredentials(DirContext context, User info, String credentials)
/*      */     throws NamingException
/*      */   {
/* 1777 */     if (this.containerLog.isTraceEnabled()) {
/* 1778 */       this.containerLog.trace("  validating credentials");
/*      */     }
/* 1780 */     if ((info == null) || (credentials == null)) {
/* 1781 */       return false;
/*      */     }
/* 1783 */     String password = info.getPassword();
/*      */     
/* 1785 */     return getCredentialHandler().matches(credentials, password);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean bindAsUser(DirContext context, User user, String credentials)
/*      */     throws NamingException
/*      */   {
/* 1803 */     if ((credentials == null) || (user == null)) {
/* 1804 */       return false;
/*      */     }
/* 1806 */     String dn = user.getDN();
/* 1807 */     if (dn == null) {
/* 1808 */       return false;
/*      */     }
/*      */     
/* 1811 */     if (this.containerLog.isTraceEnabled()) {
/* 1812 */       this.containerLog.trace("  validating credentials by binding as the user");
/*      */     }
/*      */     
/* 1815 */     userCredentialsAdd(context, dn, credentials);
/*      */     
/*      */ 
/* 1818 */     boolean validated = false;
/*      */     try {
/* 1820 */       if (this.containerLog.isTraceEnabled()) {
/* 1821 */         this.containerLog.trace("  binding as " + dn);
/*      */       }
/* 1823 */       context.getAttributes("", null);
/* 1824 */       validated = true;
/*      */     }
/*      */     catch (AuthenticationException e) {
/* 1827 */       if (this.containerLog.isTraceEnabled()) {
/* 1828 */         this.containerLog.trace("  bind attempt failed");
/*      */       }
/*      */     }
/*      */     
/* 1832 */     userCredentialsRemove(context);
/*      */     
/* 1834 */     return validated;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void userCredentialsAdd(DirContext context, String dn, String credentials)
/*      */     throws NamingException
/*      */   {
/* 1849 */     context.addToEnvironment("java.naming.security.principal", dn);
/* 1850 */     context.addToEnvironment("java.naming.security.credentials", credentials);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void userCredentialsRemove(DirContext context)
/*      */     throws NamingException
/*      */   {
/* 1864 */     if (this.connectionName != null) {
/* 1865 */       context.addToEnvironment("java.naming.security.principal", this.connectionName);
/*      */     }
/*      */     else {
/* 1868 */       context.removeFromEnvironment("java.naming.security.principal");
/*      */     }
/*      */     
/* 1871 */     if (this.connectionPassword != null) {
/* 1872 */       context.addToEnvironment("java.naming.security.credentials", this.connectionPassword);
/*      */     }
/*      */     else
/*      */     {
/* 1876 */       context.removeFromEnvironment("java.naming.security.credentials");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected List<String> getRoles(DirContext context, User user)
/*      */     throws NamingException
/*      */   {
/* 1894 */     if (user == null) {
/* 1895 */       return null;
/*      */     }
/* 1897 */     String dn = user.getDN();
/* 1898 */     String username = user.getUserName();
/* 1899 */     String userRoleId = user.getUserRoleId();
/*      */     
/* 1901 */     if ((dn == null) || (username == null)) {
/* 1902 */       return null;
/*      */     }
/* 1904 */     if (this.containerLog.isTraceEnabled()) {
/* 1905 */       this.containerLog.trace("  getRoles(" + dn + ")");
/*      */     }
/*      */     
/* 1908 */     List<String> list = new ArrayList();
/* 1909 */     List<String> userRoles = user.getRoles();
/* 1910 */     if (userRoles != null) {
/* 1911 */       list.addAll(userRoles);
/*      */     }
/* 1913 */     if (this.commonRole != null) {
/* 1914 */       list.add(this.commonRole);
/*      */     }
/* 1916 */     if (this.containerLog.isTraceEnabled()) {
/* 1917 */       this.containerLog.trace("  Found " + list.size() + " user internal roles");
/* 1918 */       for (int i = 0; i < list.size(); i++) {
/* 1919 */         this.containerLog.trace("  Found user internal role " + (String)list.get(i));
/*      */       }
/*      */     }
/*      */     
/* 1923 */     if ((this.roleFormat == null) || (this.roleName == null)) {
/* 1924 */       return list;
/*      */     }
/*      */     
/* 1927 */     String filter = this.roleFormat.format(new String[] { doRFC2254Encoding(dn), username, userRoleId });
/* 1928 */     SearchControls controls = new SearchControls();
/* 1929 */     if (this.roleSubtree) {
/* 1930 */       controls.setSearchScope(2);
/*      */     } else
/* 1932 */       controls.setSearchScope(1);
/* 1933 */     controls.setReturningAttributes(new String[] { this.roleName });
/*      */     
/* 1935 */     String base = null;
/* 1936 */     if (this.roleBaseFormat != null) {
/* 1937 */       NameParser np = context.getNameParser("");
/* 1938 */       Name name = np.parse(dn);
/* 1939 */       String[] nameParts = new String[name.size()];
/* 1940 */       for (int i = 0; i < name.size(); i++) {
/* 1941 */         nameParts[i] = name.get(i);
/*      */       }
/* 1943 */       base = this.roleBaseFormat.format(nameParts);
/*      */     } else {
/* 1945 */       base = "";
/*      */     }
/*      */     
/*      */ 
/* 1949 */     NamingEnumeration<SearchResult> results = null;
/* 1950 */     boolean thisRoleSearchAsUser = isRoleSearchAsUser();
/*      */     try {
/* 1952 */       if (thisRoleSearchAsUser) {
/* 1953 */         userCredentialsAdd(context, dn, user.getPassword());
/*      */       }
/* 1955 */       results = context.search(base, filter, controls);
/*      */     } finally {
/* 1957 */       if (thisRoleSearchAsUser) {
/* 1958 */         userCredentialsRemove(context);
/*      */       }
/*      */     }
/*      */     
/* 1962 */     if (results == null) {
/* 1963 */       return list;
/*      */     }
/* 1965 */     HashMap<String, String> groupMap = new HashMap();
/*      */     try {
/* 1967 */       while (results.hasMore()) {
/* 1968 */         SearchResult result = (SearchResult)results.next();
/* 1969 */         Attributes attrs = result.getAttributes();
/* 1970 */         if (attrs != null)
/*      */         {
/* 1972 */           String dname = getDistinguishedName(context, this.roleBase, result);
/* 1973 */           String name = getAttributeValue(this.roleName, attrs);
/* 1974 */           if ((name != null) && (dname != null))
/* 1975 */             groupMap.put(dname, name);
/*      */         }
/*      */       }
/*      */     } catch (PartialResultException ex) {
/* 1979 */       if (!this.adCompat)
/* 1980 */         throw ex;
/*      */     } finally {
/* 1982 */       results.close();
/*      */     }
/*      */     
/* 1985 */     if (this.containerLog.isTraceEnabled()) {
/* 1986 */       Set<Map.Entry<String, String>> entries = groupMap.entrySet();
/* 1987 */       this.containerLog.trace("  Found " + entries.size() + " direct roles");
/* 1988 */       for (Map.Entry<String, String> entry : entries) {
/* 1989 */         this.containerLog.trace("  Found direct role " + (String)entry.getKey() + " -> " + (String)entry.getValue());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1994 */     if (getRoleNested())
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2000 */       Map<String, String> newGroups = new HashMap(groupMap);
/* 2001 */       while (!newGroups.isEmpty()) {
/* 2002 */         Object newThisRound = new HashMap();
/*      */         
/* 2004 */         for (Map.Entry<String, String> group : newGroups.entrySet()) {
/* 2005 */           filter = this.roleFormat.format(new String[] { (String)group.getKey(), (String)group.getValue(), (String)group.getValue() });
/*      */           
/* 2007 */           if (this.containerLog.isTraceEnabled()) {
/* 2008 */             this.containerLog.trace("Perform a nested group search with base " + this.roleBase + " and filter " + filter);
/*      */           }
/*      */           
/* 2011 */           results = context.search(this.roleBase, filter, controls);
/*      */           try
/*      */           {
/* 2014 */             while (results.hasMore()) {
/* 2015 */               SearchResult result = (SearchResult)results.next();
/* 2016 */               Attributes attrs = result.getAttributes();
/* 2017 */               if (attrs != null)
/*      */               {
/* 2019 */                 String dname = getDistinguishedName(context, this.roleBase, result);
/* 2020 */                 String name = getAttributeValue(this.roleName, attrs);
/* 2021 */                 if ((name != null) && (dname != null) && (!groupMap.keySet().contains(dname))) {
/* 2022 */                   groupMap.put(dname, name);
/* 2023 */                   ((Map)newThisRound).put(dname, name);
/*      */                   
/* 2025 */                   if (this.containerLog.isTraceEnabled()) {
/* 2026 */                     this.containerLog.trace("  Found nested role " + dname + " -> " + name);
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */           } catch (PartialResultException ex) {
/* 2032 */             if (!this.adCompat)
/* 2033 */               throw ex;
/*      */           } finally {
/* 2035 */             results.close();
/*      */           }
/*      */         }
/*      */         
/* 2039 */         newGroups = (Map<String, String>)newThisRound;
/*      */       }
/*      */     }
/*      */     
/* 2043 */     list.addAll(groupMap.values());
/* 2044 */     return list;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getAttributeValue(String attrId, Attributes attrs)
/*      */     throws NamingException
/*      */   {
/* 2059 */     if (this.containerLog.isTraceEnabled()) {
/* 2060 */       this.containerLog.trace("  retrieving attribute " + attrId);
/*      */     }
/* 2062 */     if ((attrId == null) || (attrs == null)) {
/* 2063 */       return null;
/*      */     }
/* 2065 */     Attribute attr = attrs.get(attrId);
/* 2066 */     if (attr == null)
/* 2067 */       return null;
/* 2068 */     Object value = attr.get();
/* 2069 */     if (value == null)
/* 2070 */       return null;
/* 2071 */     String valueString = null;
/* 2072 */     if ((value instanceof byte[])) {
/* 2073 */       valueString = new String((byte[])value);
/*      */     } else {
/* 2075 */       valueString = value.toString();
/*      */     }
/* 2077 */     return valueString;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList<String> addAttributeValues(String attrId, Attributes attrs, ArrayList<String> values)
/*      */     throws NamingException
/*      */   {
/* 2095 */     if (this.containerLog.isTraceEnabled())
/* 2096 */       this.containerLog.trace("  retrieving values for attribute " + attrId);
/* 2097 */     if ((attrId == null) || (attrs == null))
/* 2098 */       return values;
/* 2099 */     if (values == null)
/* 2100 */       values = new ArrayList();
/* 2101 */     Attribute attr = attrs.get(attrId);
/* 2102 */     if (attr == null)
/* 2103 */       return values;
/* 2104 */     NamingEnumeration<?> e = attr.getAll();
/*      */     try {
/* 2106 */       while (e.hasMore()) {
/* 2107 */         String value = (String)e.next();
/* 2108 */         values.add(value);
/*      */       }
/*      */     } catch (PartialResultException ex) {
/* 2111 */       if (!this.adCompat)
/* 2112 */         throw ex;
/*      */     } finally {
/* 2114 */       e.close();
/*      */     }
/* 2116 */     return values;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void close(DirContext context)
/*      */   {
/* 2128 */     if (context == null) {
/* 2129 */       return;
/*      */     }
/*      */     
/* 2132 */     if (this.tls != null) {
/*      */       try {
/* 2134 */         this.tls.close();
/*      */       } catch (IOException e) {
/* 2136 */         this.containerLog.error(sm.getString("jndiRealm.tlsClose"), e);
/*      */       }
/*      */     }
/*      */     try
/*      */     {
/* 2141 */       if (this.containerLog.isDebugEnabled())
/* 2142 */         this.containerLog.debug("Closing directory context");
/* 2143 */       context.close();
/*      */     } catch (NamingException e) {
/* 2145 */       this.containerLog.error(sm.getString("jndiRealm.close"), e);
/*      */     }
/* 2147 */     this.context = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getName()
/*      */   {
/* 2158 */     return "JNDIRealm";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getPassword(String username)
/*      */   {
/* 2170 */     String userPassword = getUserPassword();
/* 2171 */     if ((userPassword == null) || (userPassword.isEmpty())) {
/* 2172 */       return null;
/*      */     }
/*      */     try
/*      */     {
/* 2176 */       User user = getUser(open(), username, null);
/* 2177 */       if (user == null)
/*      */       {
/* 2179 */         return null;
/*      */       }
/*      */       
/* 2182 */       return user.getPassword();
/*      */     }
/*      */     catch (NamingException e) {}
/* 2185 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Principal getPrincipal(String username)
/*      */   {
/* 2197 */     return getPrincipal(username, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected Principal getPrincipal(String username, GSSCredential gssCredential)
/*      */   {
/* 2204 */     DirContext context = null;
/* 2205 */     Principal principal = null;
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 2210 */       context = open();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/* 2217 */         principal = getPrincipal(context, username, gssCredential);
/*      */ 
/*      */       }
/*      */       catch (CommunicationException|ServiceUnavailableException e)
/*      */       {
/* 2222 */         this.containerLog.info(sm.getString("jndiRealm.exception.retry"), e);
/*      */         
/*      */ 
/* 2225 */         if (context != null) {
/* 2226 */           close(context);
/*      */         }
/*      */         
/* 2229 */         context = open();
/*      */         
/*      */ 
/* 2232 */         principal = getPrincipal(context, username, gssCredential);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2238 */       release(context);
/*      */       
/*      */ 
/* 2241 */       return principal;
/*      */ 
/*      */     }
/*      */     catch (NamingException e)
/*      */     {
/* 2246 */       this.containerLog.error(sm.getString("jndiRealm.exception"), e);
/*      */       
/*      */ 
/* 2249 */       if (context != null) {
/* 2250 */         close(context);
/*      */       }
/*      */     }
/* 2253 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized Principal getPrincipal(DirContext context, String username, GSSCredential gssCredential)
/*      */     throws NamingException
/*      */   {
/* 2273 */     User user = null;
/* 2274 */     List<String> roles = null;
/* 2275 */     Hashtable<?, ?> preservedEnvironment = null;
/*      */     try
/*      */     {
/* 2278 */       if ((gssCredential != null) && (isUseDelegatedCredential()))
/*      */       {
/* 2280 */         preservedEnvironment = context.getEnvironment();
/*      */         
/* 2282 */         context.addToEnvironment("java.naming.security.authentication", "GSSAPI");
/*      */         
/* 2284 */         context.addToEnvironment("javax.security.sasl.server.authentication", "true");
/*      */         
/* 2286 */         context.addToEnvironment("javax.security.sasl.qop", this.spnegoDelegationQop);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2291 */       user = getUser(context, username);
/* 2292 */       if (user != null) {
/* 2293 */         roles = getRoles(context, user);
/*      */       }
/*      */     } finally {
/* 2296 */       restoreEnvironmentParameter(context, "java.naming.security.authentication", preservedEnvironment);
/*      */       
/* 2298 */       restoreEnvironmentParameter(context, "javax.security.sasl.server.authentication", preservedEnvironment);
/*      */       
/* 2300 */       restoreEnvironmentParameter(context, "javax.security.sasl.qop", preservedEnvironment);
/*      */     }
/*      */     
/*      */ 
/* 2304 */     if (user != null) {
/* 2305 */       return new GenericPrincipal(user.getUserName(), user.getPassword(), roles, null, null, gssCredential);
/*      */     }
/*      */     
/*      */ 
/* 2309 */     return null;
/*      */   }
/*      */   
/*      */   private void restoreEnvironmentParameter(DirContext context, String parameterName, Hashtable<?, ?> preservedEnvironment)
/*      */   {
/*      */     try {
/* 2315 */       context.removeFromEnvironment(parameterName);
/* 2316 */       if ((preservedEnvironment != null) && (preservedEnvironment.containsKey(parameterName))) {
/* 2317 */         context.addToEnvironment(parameterName, preservedEnvironment.get(parameterName));
/*      */       }
/*      */     }
/*      */     catch (NamingException localNamingException) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected DirContext open()
/*      */     throws NamingException
/*      */   {
/* 2334 */     if (this.context != null) {
/* 2335 */       return this.context;
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 2340 */       this.context = createDirContext(getDirectoryContextEnvironment());
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 2344 */       this.connectionAttempt = 1;
/*      */       
/*      */ 
/* 2347 */       this.containerLog.info(sm.getString("jndiRealm.exception.retry"), e);
/*      */       
/*      */ 
/* 2350 */       this.context = createDirContext(getDirectoryContextEnvironment());
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */ 
/* 2356 */       this.connectionAttempt = 0;
/*      */     }
/*      */     
/*      */ 
/* 2360 */     return this.context;
/*      */   }
/*      */   
/*      */   private DirContext createDirContext(Hashtable<String, String> env) throws NamingException
/*      */   {
/* 2365 */     if (this.useStartTls) {
/* 2366 */       return createTlsDirContext(env);
/*      */     }
/* 2368 */     return new InitialDirContext(env);
/*      */   }
/*      */   
/*      */   private SSLSocketFactory getSSLSocketFactory()
/*      */   {
/* 2373 */     if (this.sslSocketFactory != null)
/* 2374 */       return this.sslSocketFactory;
/*      */     SSLSocketFactory result;
/*      */     SSLSocketFactory result;
/* 2377 */     if ((this.sslSocketFactoryClassName != null) && (!this.sslSocketFactoryClassName.trim().equals("")))
/*      */     {
/* 2379 */       result = createSSLSocketFactoryFromClassName(this.sslSocketFactoryClassName);
/*      */     } else {
/* 2381 */       result = createSSLContextFactoryFromProtocol(this.sslProtocol);
/*      */     }
/* 2383 */     this.sslSocketFactory = result;
/* 2384 */     return result;
/*      */   }
/*      */   
/*      */   private SSLSocketFactory createSSLSocketFactoryFromClassName(String className) {
/*      */     try {
/* 2389 */       Object o = constructInstance(className);
/* 2390 */       if ((o instanceof SSLSocketFactory)) {
/* 2391 */         return this.sslSocketFactory;
/*      */       }
/* 2393 */       throw new IllegalArgumentException(sm.getString("jndiRealm.invalidSslSocketFactory", new Object[] { className }));
/*      */ 
/*      */     }
/*      */     catch (ClassNotFoundException|SecurityException|InstantiationException|IllegalAccessException e)
/*      */     {
/*      */ 
/* 2399 */       throw new IllegalArgumentException(sm.getString("jndiRealm.invalidSslSocketFactory", new Object[] { className }), e);
/*      */     }
/*      */   }
/*      */   
/*      */   private SSLSocketFactory createSSLContextFactoryFromProtocol(String protocol)
/*      */   {
/*      */     try
/*      */     {
/*      */       SSLContext sslContext;
/* 2408 */       if (protocol != null) {
/* 2409 */         SSLContext sslContext = SSLContext.getInstance(protocol);
/* 2410 */         sslContext.init(null, null, null);
/*      */       } else {
/* 2412 */         sslContext = SSLContext.getDefault();
/*      */       }
/* 2414 */       return sslContext.getSocketFactory();
/*      */     } catch (NoSuchAlgorithmException|KeyManagementException e) {
/* 2416 */       List<String> allowedProtocols = Arrays.asList(getSupportedSslProtocols());
/*      */       
/* 2418 */       throw new IllegalArgumentException(sm.getString("jndiRealm.invalidSslProtocol", new Object[] { protocol, allowedProtocols }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private DirContext createTlsDirContext(Hashtable<String, String> env)
/*      */     throws NamingException
/*      */   {
/* 2436 */     Map<String, Object> savedEnv = new HashMap();
/* 2437 */     for (String key : Arrays.asList(new String[] { "java.naming.security.authentication", "java.naming.security.credentials", "java.naming.security.principal", "java.naming.security.protocol" }))
/*      */     {
/*      */ 
/* 2440 */       Object entry = env.remove(key);
/* 2441 */       if (entry != null) {
/* 2442 */         savedEnv.put(key, entry);
/*      */       }
/*      */     }
/* 2445 */     LdapContext result = null;
/*      */     try {
/* 2447 */       result = new InitialLdapContext(env, null);
/* 2448 */       this.tls = ((StartTlsResponse)result.extendedOperation(new StartTlsRequest()));
/*      */       
/* 2450 */       if (getHostnameVerifier() != null) {
/* 2451 */         this.tls.setHostnameVerifier(getHostnameVerifier());
/*      */       }
/* 2453 */       if (getCipherSuitesArray() != null) {
/* 2454 */         this.tls.setEnabledCipherSuites(getCipherSuitesArray());
/*      */       }
/*      */       try {
/* 2457 */         SSLSession negotiate = this.tls.negotiate(getSSLSocketFactory());
/* 2458 */         this.containerLog.debug(sm.getString("jndiRealm.negotiatedTls", new Object[] { negotiate.getProtocol() }));
/*      */       }
/*      */       catch (IOException e) {
/* 2461 */         throw new NamingException(e.getMessage());
/*      */       } } finally { Iterator i$;
/*      */       Map.Entry<String, Object> savedEntry;
/* 2464 */       if (result != null) {
/* 2465 */         for (Map.Entry<String, Object> savedEntry : savedEnv.entrySet()) {
/* 2466 */           result.addToEnvironment((String)savedEntry.getKey(), savedEntry.getValue());
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2471 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Hashtable<String, String> getDirectoryContextEnvironment()
/*      */   {
/* 2481 */     Hashtable<String, String> env = new Hashtable();
/*      */     
/*      */ 
/* 2484 */     if ((this.containerLog.isDebugEnabled()) && (this.connectionAttempt == 0)) {
/* 2485 */       this.containerLog.debug("Connecting to URL " + this.connectionURL);
/* 2486 */     } else if ((this.containerLog.isDebugEnabled()) && (this.connectionAttempt > 0))
/* 2487 */       this.containerLog.debug("Connecting to URL " + this.alternateURL);
/* 2488 */     env.put("java.naming.factory.initial", this.contextFactory);
/* 2489 */     if (this.connectionName != null)
/* 2490 */       env.put("java.naming.security.principal", this.connectionName);
/* 2491 */     if (this.connectionPassword != null)
/* 2492 */       env.put("java.naming.security.credentials", this.connectionPassword);
/* 2493 */     if ((this.connectionURL != null) && (this.connectionAttempt == 0)) {
/* 2494 */       env.put("java.naming.provider.url", this.connectionURL);
/* 2495 */     } else if ((this.alternateURL != null) && (this.connectionAttempt > 0))
/* 2496 */       env.put("java.naming.provider.url", this.alternateURL);
/* 2497 */     if (this.authentication != null)
/* 2498 */       env.put("java.naming.security.authentication", this.authentication);
/* 2499 */     if (this.protocol != null)
/* 2500 */       env.put("java.naming.security.protocol", this.protocol);
/* 2501 */     if (this.referrals != null)
/* 2502 */       env.put("java.naming.referral", this.referrals);
/* 2503 */     if (this.derefAliases != null)
/* 2504 */       env.put("java.naming.ldap.derefAliases", this.derefAliases);
/* 2505 */     if (this.connectionTimeout != null) {
/* 2506 */       env.put("com.sun.jndi.ldap.connect.timeout", this.connectionTimeout);
/*      */     }
/* 2508 */     return env;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void release(DirContext context) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void startInternal()
/*      */     throws LifecycleException
/*      */   {
/*      */     try
/*      */     {
/* 2541 */       open();
/*      */ 
/*      */     }
/*      */     catch (NamingException e)
/*      */     {
/*      */ 
/* 2547 */       this.containerLog.error(sm.getString("jndiRealm.open"), e);
/*      */     }
/*      */     
/* 2550 */     super.startInternal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void stopInternal()
/*      */     throws LifecycleException
/*      */   {
/* 2565 */     super.stopInternal();
/*      */     
/*      */ 
/* 2568 */     close(this.context);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String[] parseUserPatternString(String userPatternString)
/*      */   {
/* 2584 */     if (userPatternString != null) {
/* 2585 */       ArrayList<String> pathList = new ArrayList();
/* 2586 */       int startParenLoc = userPatternString.indexOf('(');
/* 2587 */       if (startParenLoc == -1)
/*      */       {
/* 2589 */         return new String[] { userPatternString };
/*      */       }
/* 2591 */       int startingPoint = 0;
/* 2592 */       while (startParenLoc > -1) {
/* 2593 */         int endParenLoc = 0;
/*      */         
/*      */ 
/*      */ 
/* 2597 */         while ((userPatternString.charAt(startParenLoc + 1) == '|') || ((startParenLoc != 0) && (userPatternString.charAt(startParenLoc - 1) == '\\')))
/*      */         {
/* 2599 */           startParenLoc = userPatternString.indexOf('(', startParenLoc + 1);
/*      */         }
/* 2601 */         endParenLoc = userPatternString.indexOf(')', startParenLoc + 1);
/*      */         
/* 2603 */         while (userPatternString.charAt(endParenLoc - 1) == '\\') {
/* 2604 */           endParenLoc = userPatternString.indexOf(')', endParenLoc + 1);
/*      */         }
/* 2606 */         String nextPathPart = userPatternString.substring(startParenLoc + 1, endParenLoc);
/*      */         
/* 2608 */         pathList.add(nextPathPart);
/* 2609 */         startingPoint = endParenLoc + 1;
/* 2610 */         startParenLoc = userPatternString.indexOf('(', startingPoint);
/*      */       }
/* 2612 */       return (String[])pathList.toArray(new String[0]);
/*      */     }
/* 2614 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String doRFC2254Encoding(String inString)
/*      */   {
/* 2634 */     StringBuilder buf = new StringBuilder(inString.length());
/* 2635 */     for (int i = 0; i < inString.length(); i++) {
/* 2636 */       char c = inString.charAt(i);
/* 2637 */       switch (c) {
/*      */       case '\\': 
/* 2639 */         buf.append("\\5c");
/* 2640 */         break;
/*      */       case '*': 
/* 2642 */         buf.append("\\2a");
/* 2643 */         break;
/*      */       case '(': 
/* 2645 */         buf.append("\\28");
/* 2646 */         break;
/*      */       case ')': 
/* 2648 */         buf.append("\\29");
/* 2649 */         break;
/*      */       case '\000': 
/* 2651 */         buf.append("\\00");
/* 2652 */         break;
/*      */       default: 
/* 2654 */         buf.append(c);
/*      */       }
/*      */       
/*      */     }
/* 2658 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getDistinguishedName(DirContext context, String base, SearchResult result)
/*      */     throws NamingException
/*      */   {
/* 2676 */     if (result.isRelative()) {
/* 2677 */       if (this.containerLog.isTraceEnabled()) {
/* 2678 */         this.containerLog.trace("  search returned relative name: " + result.getName());
/*      */       }
/*      */       
/* 2681 */       NameParser parser = context.getNameParser("");
/* 2682 */       Name contextName = parser.parse(context.getNameInNamespace());
/* 2683 */       Name baseName = parser.parse(base);
/*      */       
/*      */ 
/* 2686 */       Name entryName = parser.parse(new CompositeName(result.getName()).get(0));
/*      */       
/*      */ 
/* 2689 */       Name name = contextName.addAll(baseName);
/* 2690 */       name = name.addAll(entryName);
/* 2691 */       return name.toString();
/*      */     }
/* 2693 */     String absoluteName = result.getName();
/* 2694 */     if (this.containerLog.isTraceEnabled()) {
/* 2695 */       this.containerLog.trace("  search returned absolute name: " + result.getName());
/*      */     }
/*      */     try
/*      */     {
/* 2699 */       NameParser parser = context.getNameParser("");
/* 2700 */       URI userNameUri = new URI(absoluteName);
/* 2701 */       String pathComponent = userNameUri.getPath();
/*      */       
/* 2703 */       if (pathComponent.length() < 1) {
/* 2704 */         throw new InvalidNameException("Search returned unparseable absolute name: " + absoluteName);
/*      */       }
/*      */       
/*      */ 
/* 2708 */       Name name = parser.parse(pathComponent.substring(1));
/* 2709 */       return name.toString();
/*      */     } catch (URISyntaxException e) {
/* 2711 */       throw new InvalidNameException("Search returned unparseable absolute name: " + absoluteName);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static class User
/*      */   {
/*      */     private final String username;
/*      */     
/*      */ 
/*      */     private final String dn;
/*      */     
/*      */ 
/*      */     private final String password;
/*      */     
/*      */ 
/*      */     private final List<String> roles;
/*      */     
/*      */     private final String userRoleId;
/*      */     
/*      */ 
/*      */     public User(String username, String dn, String password, List<String> roles, String userRoleId)
/*      */     {
/* 2735 */       this.username = username;
/* 2736 */       this.dn = dn;
/* 2737 */       this.password = password;
/* 2738 */       if (roles == null) {
/* 2739 */         this.roles = Collections.emptyList();
/*      */       } else {
/* 2741 */         this.roles = Collections.unmodifiableList(roles);
/*      */       }
/* 2743 */       this.userRoleId = userRoleId;
/*      */     }
/*      */     
/*      */     public String getUserName() {
/* 2747 */       return this.username;
/*      */     }
/*      */     
/*      */     public String getDN() {
/* 2751 */       return this.dn;
/*      */     }
/*      */     
/*      */     public String getPassword() {
/* 2755 */       return this.password;
/*      */     }
/*      */     
/*      */     public List<String> getRoles() {
/* 2759 */       return this.roles;
/*      */     }
/*      */     
/*      */     public String getUserRoleId() {
/* 2763 */       return this.userRoleId;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\realm\JNDIRealm.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */