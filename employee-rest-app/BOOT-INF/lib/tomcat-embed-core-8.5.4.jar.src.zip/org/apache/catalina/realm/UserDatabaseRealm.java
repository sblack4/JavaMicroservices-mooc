/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.naming.Context;
/*     */ import org.apache.catalina.Group;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.Server;
/*     */ import org.apache.catalina.User;
/*     */ import org.apache.catalina.UserDatabase;
/*     */ import org.apache.catalina.Wrapper;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UserDatabaseRealm
/*     */   extends RealmBase
/*     */ {
/*  59 */   protected UserDatabase database = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static final String name = "UserDatabaseRealm";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */   protected String resourceName = "UserDatabase";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getResourceName()
/*     */   {
/*  83 */     return this.resourceName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResourceName(String resourceName)
/*     */   {
/*  96 */     this.resourceName = resourceName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasRole(Wrapper wrapper, Principal principal, String role)
/*     */   {
/* 117 */     if (wrapper != null) {
/* 118 */       String realRole = wrapper.findSecurityReference(role);
/* 119 */       if (realRole != null)
/* 120 */         role = realRole;
/*     */     }
/* 122 */     if ((principal instanceof GenericPrincipal)) {
/* 123 */       GenericPrincipal gp = (GenericPrincipal)principal;
/* 124 */       if ((gp.getUserPrincipal() instanceof User)) {
/* 125 */         principal = gp.getUserPrincipal();
/*     */       }
/*     */     }
/* 128 */     if (!(principal instanceof User))
/*     */     {
/* 130 */       return super.hasRole(null, principal, role);
/*     */     }
/* 132 */     if ("*".equals(role))
/* 133 */       return true;
/* 134 */     if (role == null) {
/* 135 */       return false;
/*     */     }
/* 137 */     User user = (User)principal;
/* 138 */     Role dbrole = this.database.findRole(role);
/* 139 */     if (dbrole == null) {
/* 140 */       return false;
/*     */     }
/* 142 */     if (user.isInRole(dbrole)) {
/* 143 */       return true;
/*     */     }
/* 145 */     Iterator<Group> groups = user.getGroups();
/* 146 */     while (groups.hasNext()) {
/* 147 */       Group group = (Group)groups.next();
/* 148 */       if (group.isInRole(dbrole)) {
/* 149 */         return true;
/*     */       }
/*     */     }
/* 152 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getName()
/*     */   {
/* 164 */     return "UserDatabaseRealm";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getPassword(String username)
/*     */   {
/* 175 */     User user = this.database.findUser(username);
/*     */     
/* 177 */     if (user == null) {
/* 178 */       return null;
/*     */     }
/*     */     
/* 181 */     return user.getPassword();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Principal getPrincipal(String username)
/*     */   {
/* 192 */     User user = this.database.findUser(username);
/* 193 */     if (user == null) {
/* 194 */       return null;
/*     */     }
/*     */     
/* 197 */     List<String> roles = new ArrayList();
/* 198 */     Iterator<Role> uroles = user.getRoles();
/* 199 */     while (uroles.hasNext()) {
/* 200 */       Role role = (Role)uroles.next();
/* 201 */       roles.add(role.getName());
/*     */     }
/* 203 */     Iterator<Group> groups = user.getGroups();
/* 204 */     while (groups.hasNext()) {
/* 205 */       Group group = (Group)groups.next();
/* 206 */       uroles = group.getRoles();
/* 207 */       while (uroles.hasNext()) {
/* 208 */         Role role = (Role)uroles.next();
/* 209 */         roles.add(role.getName());
/*     */       }
/*     */     }
/* 212 */     return new GenericPrincipal(username, user.getPassword(), roles, user);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void startInternal()
/*     */     throws LifecycleException
/*     */   {
/*     */     try
/*     */     {
/* 231 */       Context context = getServer().getGlobalNamingContext();
/* 232 */       this.database = ((UserDatabase)context.lookup(this.resourceName));
/*     */     } catch (Throwable e) {
/* 234 */       ExceptionUtils.handleThrowable(e);
/* 235 */       this.containerLog.error(sm.getString("userDatabaseRealm.lookup", new Object[] { this.resourceName }), e);
/*     */       
/*     */ 
/* 238 */       this.database = null;
/*     */     }
/* 240 */     if (this.database == null) {
/* 241 */       throw new LifecycleException(sm.getString("userDatabaseRealm.noDatabase", new Object[] { this.resourceName }));
/*     */     }
/*     */     
/*     */ 
/* 245 */     super.startInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void stopInternal()
/*     */     throws LifecycleException
/*     */   {
/* 261 */     super.stopInternal();
/*     */     
/*     */ 
/* 264 */     this.database = null;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\realm\UserDatabaseRealm.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */