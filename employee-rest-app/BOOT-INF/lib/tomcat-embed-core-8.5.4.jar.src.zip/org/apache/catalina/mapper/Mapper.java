/*      */ package org.apache.catalina.mapper;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.CopyOnWriteArrayList;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.WebResource;
/*      */ import org.apache.catalina.WebResourceRoot;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.servlet4preview.http.MappingMatch;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.buf.Ascii;
/*      */ import org.apache.tomcat.util.buf.CharChunk;
/*      */ import org.apache.tomcat.util.buf.MessageBytes;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Mapper
/*      */ {
/*   50 */   private static final Log log = LogFactory.getLog(Mapper.class);
/*      */   
/*   52 */   private static final StringManager sm = StringManager.getManager(Mapper.class);
/*      */   
/*      */   volatile MappedHost[] hosts;
/*      */   
/*      */   private String defaultHostName;
/*      */   private final Map<Context, ContextVersion> contextObjectToContextVersionMap;
/*      */   
/*      */   public Mapper()
/*      */   {
/*   61 */     this.hosts = new MappedHost[0];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   67 */     this.defaultHostName = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   74 */     this.contextObjectToContextVersionMap = new ConcurrentHashMap();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDefaultHostName(String defaultHostName)
/*      */   {
/*   86 */     this.defaultHostName = defaultHostName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void addHost(String name, String[] aliases, Host host)
/*      */   {
/*   98 */     MappedHost[] newHosts = new MappedHost[this.hosts.length + 1];
/*   99 */     MappedHost newHost = new MappedHost(name, host);
/*  100 */     if (insertMap(this.hosts, newHosts, newHost)) {
/*  101 */       this.hosts = newHosts;
/*  102 */       if (log.isDebugEnabled()) {
/*  103 */         log.debug(sm.getString("mapper.addHost.success", new Object[] { name }));
/*      */       }
/*      */     } else {
/*  106 */       MappedHost duplicate = this.hosts[find(this.hosts, name)];
/*  107 */       if (duplicate.object == host)
/*      */       {
/*      */ 
/*  110 */         if (log.isDebugEnabled()) {
/*  111 */           log.debug(sm.getString("mapper.addHost.sameHost", new Object[] { name }));
/*      */         }
/*  113 */         newHost = duplicate;
/*      */       } else {
/*  115 */         log.error(sm.getString("mapper.duplicateHost", new Object[] { name, duplicate.getRealHostName() }));
/*      */         
/*      */ 
/*      */ 
/*  119 */         return;
/*      */       }
/*      */     }
/*  122 */     List<MappedHost> newAliases = new ArrayList(aliases.length);
/*  123 */     for (String alias : aliases) {
/*  124 */       MappedHost newAlias = new MappedHost(alias, newHost);
/*  125 */       if (addHostAliasImpl(newAlias)) {
/*  126 */         newAliases.add(newAlias);
/*      */       }
/*      */     }
/*  129 */     newHost.addAliases(newAliases);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void removeHost(String name)
/*      */   {
/*  140 */     MappedHost host = (MappedHost)exactFind(this.hosts, name);
/*  141 */     if ((host == null) || (host.isAlias())) {
/*  142 */       return;
/*      */     }
/*  144 */     MappedHost[] newHosts = (MappedHost[])this.hosts.clone();
/*      */     
/*  146 */     int j = 0;
/*  147 */     for (int i = 0; i < newHosts.length; i++) {
/*  148 */       if (newHosts[i].getRealHost() != host) {
/*  149 */         newHosts[(j++)] = newHosts[i];
/*      */       }
/*      */     }
/*  152 */     this.hosts = ((MappedHost[])Arrays.copyOf(newHosts, j));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void addHostAlias(String name, String alias)
/*      */   {
/*  161 */     MappedHost realHost = (MappedHost)exactFind(this.hosts, name);
/*  162 */     if (realHost == null)
/*      */     {
/*      */ 
/*  165 */       return;
/*      */     }
/*  167 */     MappedHost newAlias = new MappedHost(alias, realHost);
/*  168 */     if (addHostAliasImpl(newAlias)) {
/*  169 */       realHost.addAlias(newAlias);
/*      */     }
/*      */   }
/*      */   
/*      */   private synchronized boolean addHostAliasImpl(MappedHost newAlias) {
/*  174 */     MappedHost[] newHosts = new MappedHost[this.hosts.length + 1];
/*  175 */     if (insertMap(this.hosts, newHosts, newAlias)) {
/*  176 */       this.hosts = newHosts;
/*  177 */       if (log.isDebugEnabled()) {
/*  178 */         log.debug(sm.getString("mapper.addHostAlias.success", new Object[] { newAlias.name, newAlias.getRealHostName() }));
/*      */       }
/*      */       
/*  181 */       return true;
/*      */     }
/*  183 */     MappedHost duplicate = this.hosts[find(this.hosts, newAlias.name)];
/*  184 */     if (duplicate.getRealHost() == newAlias.getRealHost())
/*      */     {
/*      */ 
/*      */ 
/*  188 */       if (log.isDebugEnabled()) {
/*  189 */         log.debug(sm.getString("mapper.addHostAlias.sameHost", new Object[] { newAlias.name, newAlias.getRealHostName() }));
/*      */       }
/*      */       
/*  192 */       return false;
/*      */     }
/*  194 */     log.error(sm.getString("mapper.duplicateHostAlias", new Object[] { newAlias.name, newAlias.getRealHostName(), duplicate.getRealHostName() }));
/*      */     
/*  196 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void removeHostAlias(String alias)
/*      */   {
/*  206 */     MappedHost hostMapping = (MappedHost)exactFind(this.hosts, alias);
/*  207 */     if ((hostMapping == null) || (!hostMapping.isAlias())) {
/*  208 */       return;
/*      */     }
/*  210 */     MappedHost[] newHosts = new MappedHost[this.hosts.length - 1];
/*  211 */     if (removeMap(this.hosts, newHosts, alias)) {
/*  212 */       this.hosts = newHosts;
/*  213 */       hostMapping.getRealHost().removeAlias(hostMapping);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void updateContextList(MappedHost realHost, ContextList newContextList)
/*      */   {
/*  225 */     realHost.contextList = newContextList;
/*  226 */     for (MappedHost alias : realHost.getAliases()) {
/*  227 */       alias.contextList = newContextList;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addContextVersion(String hostName, Host host, String path, String version, Context context, String[] welcomeResources, WebResourceRoot resources, Collection<WrapperMappingInfo> wrappers)
/*      */   {
/*  247 */     MappedHost mappedHost = (MappedHost)exactFind(this.hosts, hostName);
/*  248 */     if (mappedHost == null) {
/*  249 */       addHost(hostName, new String[0], host);
/*  250 */       mappedHost = (MappedHost)exactFind(this.hosts, hostName);
/*  251 */       if (mappedHost == null) {
/*  252 */         log.error("No host found: " + hostName);
/*  253 */         return;
/*      */       }
/*      */     }
/*  256 */     if (mappedHost.isAlias()) {
/*  257 */       log.error("No host found: " + hostName);
/*  258 */       return;
/*      */     }
/*  260 */     int slashCount = slashCount(path);
/*  261 */     synchronized (mappedHost) {
/*  262 */       ContextVersion newContextVersion = new ContextVersion(version, path, slashCount, context, resources, welcomeResources);
/*      */       
/*  264 */       if (wrappers != null) {
/*  265 */         addWrappers(newContextVersion, wrappers);
/*      */       }
/*      */       
/*  268 */       ContextList contextList = mappedHost.contextList;
/*  269 */       MappedContext mappedContext = (MappedContext)exactFind(contextList.contexts, path);
/*  270 */       if (mappedContext == null) {
/*  271 */         mappedContext = new MappedContext(path, newContextVersion);
/*  272 */         ContextList newContextList = contextList.addContext(mappedContext, slashCount);
/*      */         
/*  274 */         if (newContextList != null) {
/*  275 */           updateContextList(mappedHost, newContextList);
/*  276 */           this.contextObjectToContextVersionMap.put(context, newContextVersion);
/*      */         }
/*      */       } else {
/*  279 */         ContextVersion[] contextVersions = mappedContext.versions;
/*  280 */         ContextVersion[] newContextVersions = new ContextVersion[contextVersions.length + 1];
/*  281 */         if (insertMap(contextVersions, newContextVersions, newContextVersion))
/*      */         {
/*  283 */           mappedContext.versions = newContextVersions;
/*  284 */           this.contextObjectToContextVersionMap.put(context, newContextVersion);
/*      */         }
/*      */         else
/*      */         {
/*  288 */           int pos = find(contextVersions, version);
/*  289 */           if ((pos >= 0) && (contextVersions[pos].name.equals(version))) {
/*  290 */             contextVersions[pos] = newContextVersion;
/*  291 */             this.contextObjectToContextVersionMap.put(context, newContextVersion);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeContextVersion(Context ctxt, String hostName, String path, String version)
/*      */   {
/*  311 */     this.contextObjectToContextVersionMap.remove(ctxt);
/*      */     
/*  313 */     MappedHost host = (MappedHost)exactFind(this.hosts, hostName);
/*  314 */     if ((host == null) || (host.isAlias())) {
/*  315 */       return;
/*      */     }
/*      */     
/*  318 */     synchronized (host) {
/*  319 */       ContextList contextList = host.contextList;
/*  320 */       MappedContext context = (MappedContext)exactFind(contextList.contexts, path);
/*  321 */       if (context == null) {
/*  322 */         return;
/*      */       }
/*      */       
/*  325 */       ContextVersion[] contextVersions = context.versions;
/*  326 */       ContextVersion[] newContextVersions = new ContextVersion[contextVersions.length - 1];
/*      */       
/*  328 */       if (removeMap(contextVersions, newContextVersions, version)) {
/*  329 */         if (newContextVersions.length == 0)
/*      */         {
/*  331 */           ContextList newContextList = contextList.removeContext(path);
/*  332 */           if (newContextList != null) {
/*  333 */             updateContextList(host, newContextList);
/*      */           }
/*      */         } else {
/*  336 */           context.versions = newContextVersions;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void pauseContextVersion(Context ctxt, String hostName, String contextPath, String version)
/*      */   {
/*  355 */     ContextVersion contextVersion = findContextVersion(hostName, contextPath, version, true);
/*      */     
/*  357 */     if ((contextVersion == null) || (!ctxt.equals(contextVersion.object))) {
/*  358 */       return;
/*      */     }
/*  360 */     contextVersion.markPaused();
/*      */   }
/*      */   
/*      */ 
/*      */   private ContextVersion findContextVersion(String hostName, String contextPath, String version, boolean silent)
/*      */   {
/*  366 */     MappedHost host = (MappedHost)exactFind(this.hosts, hostName);
/*  367 */     if ((host == null) || (host.isAlias())) {
/*  368 */       if (!silent) {
/*  369 */         log.error("No host found: " + hostName);
/*      */       }
/*  371 */       return null;
/*      */     }
/*  373 */     MappedContext context = (MappedContext)exactFind(host.contextList.contexts, contextPath);
/*      */     
/*  375 */     if (context == null) {
/*  376 */       if (!silent) {
/*  377 */         log.error("No context found: " + contextPath);
/*      */       }
/*  379 */       return null;
/*      */     }
/*  381 */     ContextVersion contextVersion = (ContextVersion)exactFind(context.versions, version);
/*  382 */     if (contextVersion == null) {
/*  383 */       if (!silent) {
/*  384 */         log.error("No context version found: " + contextPath + " " + version);
/*      */       }
/*      */       
/*  387 */       return null;
/*      */     }
/*  389 */     return contextVersion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void addWrapper(String hostName, String contextPath, String version, String path, Wrapper wrapper, boolean jspWildCard, boolean resourceOnly)
/*      */   {
/*  396 */     ContextVersion contextVersion = findContextVersion(hostName, contextPath, version, false);
/*      */     
/*  398 */     if (contextVersion == null) {
/*  399 */       return;
/*      */     }
/*  401 */     addWrapper(contextVersion, path, wrapper, jspWildCard, resourceOnly);
/*      */   }
/*      */   
/*      */   public void addWrappers(String hostName, String contextPath, String version, Collection<WrapperMappingInfo> wrappers)
/*      */   {
/*  406 */     ContextVersion contextVersion = findContextVersion(hostName, contextPath, version, false);
/*      */     
/*  408 */     if (contextVersion == null) {
/*  409 */       return;
/*      */     }
/*  411 */     addWrappers(contextVersion, wrappers);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addWrappers(ContextVersion contextVersion, Collection<WrapperMappingInfo> wrappers)
/*      */   {
/*  422 */     for (WrapperMappingInfo wrapper : wrappers) {
/*  423 */       addWrapper(contextVersion, wrapper.getMapping(), wrapper.getWrapper(), wrapper.isJspWildCard(), wrapper.isResourceOnly());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void addWrapper(ContextVersion context, String path, Wrapper wrapper, boolean jspWildCard, boolean resourceOnly)
/*      */   {
/*  443 */     synchronized (context) {
/*  444 */       if (path.endsWith("/*"))
/*      */       {
/*  446 */         String name = path.substring(0, path.length() - 2);
/*  447 */         MappedWrapper newWrapper = new MappedWrapper(name, wrapper, jspWildCard, resourceOnly);
/*      */         
/*  449 */         MappedWrapper[] oldWrappers = context.wildcardWrappers;
/*  450 */         MappedWrapper[] newWrappers = new MappedWrapper[oldWrappers.length + 1];
/*  451 */         if (insertMap(oldWrappers, newWrappers, newWrapper)) {
/*  452 */           context.wildcardWrappers = newWrappers;
/*  453 */           int slashCount = slashCount(newWrapper.name);
/*  454 */           if (slashCount > context.nesting) {
/*  455 */             context.nesting = slashCount;
/*      */           }
/*      */         }
/*  458 */       } else if (path.startsWith("*."))
/*      */       {
/*  460 */         String name = path.substring(2);
/*  461 */         MappedWrapper newWrapper = new MappedWrapper(name, wrapper, jspWildCard, resourceOnly);
/*      */         
/*  463 */         MappedWrapper[] oldWrappers = context.extensionWrappers;
/*  464 */         MappedWrapper[] newWrappers = new MappedWrapper[oldWrappers.length + 1];
/*      */         
/*  466 */         if (insertMap(oldWrappers, newWrappers, newWrapper)) {
/*  467 */           context.extensionWrappers = newWrappers;
/*      */         }
/*  469 */       } else if (path.equals("/"))
/*      */       {
/*  471 */         MappedWrapper newWrapper = new MappedWrapper("", wrapper, jspWildCard, resourceOnly);
/*      */         
/*  473 */         context.defaultWrapper = newWrapper;
/*      */       } else {
/*      */         String name;
/*      */         String name;
/*  477 */         if (path.length() == 0)
/*      */         {
/*      */ 
/*  480 */           name = "/";
/*      */         } else {
/*  482 */           name = path;
/*      */         }
/*  484 */         MappedWrapper newWrapper = new MappedWrapper(name, wrapper, jspWildCard, resourceOnly);
/*      */         
/*  486 */         MappedWrapper[] oldWrappers = context.exactWrappers;
/*  487 */         MappedWrapper[] newWrappers = new MappedWrapper[oldWrappers.length + 1];
/*  488 */         if (insertMap(oldWrappers, newWrappers, newWrapper)) {
/*  489 */           context.exactWrappers = newWrappers;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeWrapper(String hostName, String contextPath, String version, String path)
/*      */   {
/*  506 */     ContextVersion contextVersion = findContextVersion(hostName, contextPath, version, true);
/*      */     
/*  508 */     if ((contextVersion == null) || (contextVersion.isPaused())) {
/*  509 */       return;
/*      */     }
/*  511 */     removeWrapper(contextVersion, path);
/*      */   }
/*      */   
/*      */   protected void removeWrapper(ContextVersion context, String path)
/*      */   {
/*  516 */     if (log.isDebugEnabled()) {
/*  517 */       log.debug(sm.getString("mapper.removeWrapper", new Object[] { context.name, path }));
/*      */     }
/*      */     
/*  520 */     synchronized (context) {
/*  521 */       if (path.endsWith("/*"))
/*      */       {
/*  523 */         String name = path.substring(0, path.length() - 2);
/*  524 */         MappedWrapper[] oldWrappers = context.wildcardWrappers;
/*  525 */         if (oldWrappers.length == 0) {
/*  526 */           return;
/*      */         }
/*  528 */         MappedWrapper[] newWrappers = new MappedWrapper[oldWrappers.length - 1];
/*      */         
/*  530 */         if (removeMap(oldWrappers, newWrappers, name))
/*      */         {
/*  532 */           context.nesting = 0;
/*  533 */           for (int i = 0; i < newWrappers.length; i++) {
/*  534 */             int slashCount = slashCount(newWrappers[i].name);
/*  535 */             if (slashCount > context.nesting) {
/*  536 */               context.nesting = slashCount;
/*      */             }
/*      */           }
/*  539 */           context.wildcardWrappers = newWrappers;
/*      */         }
/*  541 */       } else if (path.startsWith("*."))
/*      */       {
/*  543 */         String name = path.substring(2);
/*  544 */         MappedWrapper[] oldWrappers = context.extensionWrappers;
/*  545 */         if (oldWrappers.length == 0) {
/*  546 */           return;
/*      */         }
/*  548 */         MappedWrapper[] newWrappers = new MappedWrapper[oldWrappers.length - 1];
/*      */         
/*  550 */         if (removeMap(oldWrappers, newWrappers, name)) {
/*  551 */           context.extensionWrappers = newWrappers;
/*      */         }
/*  553 */       } else if (path.equals("/"))
/*      */       {
/*  555 */         context.defaultWrapper = null;
/*      */       } else {
/*      */         String name;
/*      */         String name;
/*  559 */         if (path.length() == 0)
/*      */         {
/*      */ 
/*  562 */           name = "/";
/*      */         } else {
/*  564 */           name = path;
/*      */         }
/*  566 */         MappedWrapper[] oldWrappers = context.exactWrappers;
/*  567 */         if (oldWrappers.length == 0) {
/*  568 */           return;
/*      */         }
/*  570 */         MappedWrapper[] newWrappers = new MappedWrapper[oldWrappers.length - 1];
/*      */         
/*  572 */         if (removeMap(oldWrappers, newWrappers, name)) {
/*  573 */           context.exactWrappers = newWrappers;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addWelcomeFile(String hostName, String contextPath, String version, String welcomeFile)
/*      */   {
/*  590 */     ContextVersion contextVersion = findContextVersion(hostName, contextPath, version, false);
/*  591 */     if (contextVersion == null) {
/*  592 */       return;
/*      */     }
/*  594 */     int len = contextVersion.welcomeResources.length + 1;
/*  595 */     String[] newWelcomeResources = new String[len];
/*  596 */     System.arraycopy(contextVersion.welcomeResources, 0, newWelcomeResources, 0, len - 1);
/*  597 */     newWelcomeResources[(len - 1)] = welcomeFile;
/*  598 */     contextVersion.welcomeResources = newWelcomeResources;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeWelcomeFile(String hostName, String contextPath, String version, String welcomeFile)
/*      */   {
/*  612 */     ContextVersion contextVersion = findContextVersion(hostName, contextPath, version, false);
/*  613 */     if ((contextVersion == null) || (contextVersion.isPaused())) {
/*  614 */       return;
/*      */     }
/*  616 */     int match = -1;
/*  617 */     for (int i = 0; i < contextVersion.welcomeResources.length; i++) {
/*  618 */       if (welcomeFile.equals(contextVersion.welcomeResources[i])) {
/*  619 */         match = i;
/*  620 */         break;
/*      */       }
/*      */     }
/*  623 */     if (match > -1) {
/*  624 */       int len = contextVersion.welcomeResources.length - 1;
/*  625 */       String[] newWelcomeResources = new String[len];
/*  626 */       System.arraycopy(contextVersion.welcomeResources, 0, newWelcomeResources, 0, match);
/*  627 */       if (match < len) {
/*  628 */         System.arraycopy(contextVersion.welcomeResources, match + 1, newWelcomeResources, match, len - match);
/*      */       }
/*      */       
/*  631 */       contextVersion.welcomeResources = newWelcomeResources;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearWelcomeFiles(String hostName, String contextPath, String version)
/*      */   {
/*  644 */     ContextVersion contextVersion = findContextVersion(hostName, contextPath, version, false);
/*  645 */     if (contextVersion == null) {
/*  646 */       return;
/*      */     }
/*  648 */     contextVersion.welcomeResources = new String[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void map(MessageBytes host, MessageBytes uri, String version, MappingData mappingData)
/*      */     throws IOException
/*      */   {
/*  666 */     if (host.isNull()) {
/*  667 */       host.getCharChunk().append(this.defaultHostName);
/*      */     }
/*  669 */     host.toChars();
/*  670 */     uri.toChars();
/*  671 */     internalMap(host.getCharChunk(), uri.getCharChunk(), version, mappingData);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void map(Context context, MessageBytes uri, MappingData mappingData)
/*      */     throws IOException
/*      */   {
/*  690 */     ContextVersion contextVersion = (ContextVersion)this.contextObjectToContextVersionMap.get(context);
/*      */     
/*  692 */     uri.toChars();
/*  693 */     CharChunk uricc = uri.getCharChunk();
/*  694 */     uricc.setLimit(-1);
/*  695 */     internalMapWrapper(contextVersion, uricc, mappingData);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void internalMap(CharChunk host, CharChunk uri, String version, MappingData mappingData)
/*      */     throws IOException
/*      */   {
/*  708 */     if (mappingData.host != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  713 */       throw new AssertionError();
/*      */     }
/*      */     
/*  716 */     uri.setLimit(-1);
/*      */     
/*      */ 
/*  719 */     MappedHost[] hosts = this.hosts;
/*  720 */     MappedHost mappedHost = (MappedHost)exactFindIgnoreCase(hosts, host);
/*  721 */     if (mappedHost == null) {
/*  722 */       if (this.defaultHostName == null) {
/*  723 */         return;
/*      */       }
/*  725 */       mappedHost = (MappedHost)exactFind(hosts, this.defaultHostName);
/*  726 */       if (mappedHost == null) {
/*  727 */         return;
/*      */       }
/*      */     }
/*  730 */     mappingData.host = ((Host)mappedHost.object);
/*      */     
/*      */ 
/*  733 */     ContextList contextList = mappedHost.contextList;
/*  734 */     MappedContext[] contexts = contextList.contexts;
/*  735 */     int pos = find(contexts, uri);
/*  736 */     if (pos == -1) {
/*  737 */       return;
/*      */     }
/*      */     
/*  740 */     int lastSlash = -1;
/*  741 */     int uriEnd = uri.getEnd();
/*  742 */     int length = -1;
/*  743 */     boolean found = false;
/*  744 */     MappedContext context = null;
/*  745 */     while (pos >= 0) {
/*  746 */       context = contexts[pos];
/*  747 */       if (uri.startsWith(context.name)) {
/*  748 */         length = context.name.length();
/*  749 */         if (uri.getLength() == length) {
/*  750 */           found = true;
/*  751 */           break; }
/*  752 */         if (uri.startsWithIgnoreCase("/", length)) {
/*  753 */           found = true;
/*  754 */           break;
/*      */         }
/*      */       }
/*  757 */       if (lastSlash == -1) {
/*  758 */         lastSlash = nthSlash(uri, contextList.nesting + 1);
/*      */       } else {
/*  760 */         lastSlash = lastSlash(uri);
/*      */       }
/*  762 */       uri.setEnd(lastSlash);
/*  763 */       pos = find(contexts, uri);
/*      */     }
/*  765 */     uri.setEnd(uriEnd);
/*      */     
/*  767 */     if (!found) {
/*  768 */       if (contexts[0].name.equals("")) {
/*  769 */         context = contexts[0];
/*      */       } else {
/*  771 */         context = null;
/*      */       }
/*      */     }
/*  774 */     if (context == null) {
/*  775 */       return;
/*      */     }
/*      */     
/*  778 */     mappingData.contextPath.setString(context.name);
/*      */     
/*  780 */     ContextVersion contextVersion = null;
/*  781 */     ContextVersion[] contextVersions = context.versions;
/*  782 */     int versionCount = contextVersions.length;
/*  783 */     if (versionCount > 1) {
/*  784 */       Context[] contextObjects = new Context[contextVersions.length];
/*  785 */       for (int i = 0; i < contextObjects.length; i++) {
/*  786 */         contextObjects[i] = ((Context)contextVersions[i].object);
/*      */       }
/*  788 */       mappingData.contexts = contextObjects;
/*  789 */       if (version != null) {
/*  790 */         contextVersion = (ContextVersion)exactFind(contextVersions, version);
/*      */       }
/*      */     }
/*  793 */     if (contextVersion == null)
/*      */     {
/*      */ 
/*  796 */       contextVersion = contextVersions[(versionCount - 1)];
/*      */     }
/*  798 */     mappingData.context = ((Context)contextVersion.object);
/*  799 */     mappingData.contextSlashCount = contextVersion.slashCount;
/*      */     
/*      */ 
/*  802 */     if (!contextVersion.isPaused()) {
/*  803 */       internalMapWrapper(contextVersion, uri, mappingData);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void internalMapWrapper(ContextVersion contextVersion, CharChunk path, MappingData mappingData)
/*      */     throws IOException
/*      */   {
/*  818 */     int pathOffset = path.getOffset();
/*  819 */     int pathEnd = path.getEnd();
/*  820 */     boolean noServletPath = false;
/*      */     
/*  822 */     int length = contextVersion.path.length();
/*  823 */     if (length == pathEnd - pathOffset) {
/*  824 */       noServletPath = true;
/*      */     }
/*  826 */     int servletPath = pathOffset + length;
/*  827 */     path.setOffset(servletPath);
/*      */     
/*      */ 
/*  830 */     MappedWrapper[] exactWrappers = contextVersion.exactWrappers;
/*  831 */     internalMapExactWrapper(exactWrappers, path, mappingData);
/*      */     
/*      */ 
/*  834 */     boolean checkJspWelcomeFiles = false;
/*  835 */     MappedWrapper[] wildcardWrappers = contextVersion.wildcardWrappers;
/*  836 */     if (mappingData.wrapper == null) {
/*  837 */       internalMapWildcardWrapper(wildcardWrappers, contextVersion.nesting, path, mappingData);
/*      */       
/*  839 */       if ((mappingData.wrapper != null) && (mappingData.jspWildCard)) {
/*  840 */         char[] buf = path.getBuffer();
/*  841 */         if (buf[(pathEnd - 1)] == '/')
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  850 */           mappingData.wrapper = null;
/*  851 */           checkJspWelcomeFiles = true;
/*      */         }
/*      */         else {
/*  854 */           mappingData.wrapperPath.setChars(buf, path.getStart(), path.getLength());
/*      */           
/*  856 */           mappingData.pathInfo.recycle();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  861 */     if ((mappingData.wrapper == null) && (noServletPath) && (((Context)contextVersion.object).getMapperContextRootRedirectEnabled()))
/*      */     {
/*      */ 
/*  864 */       path.append('/');
/*  865 */       pathEnd = path.getEnd();
/*  866 */       mappingData.redirectPath.setChars(path.getBuffer(), pathOffset, pathEnd - pathOffset);
/*      */       
/*  868 */       path.setEnd(pathEnd - 1);
/*  869 */       return;
/*      */     }
/*      */     
/*      */ 
/*  873 */     MappedWrapper[] extensionWrappers = contextVersion.extensionWrappers;
/*  874 */     if ((mappingData.wrapper == null) && (!checkJspWelcomeFiles)) {
/*  875 */       internalMapExtensionWrapper(extensionWrappers, path, mappingData, true);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  880 */     if (mappingData.wrapper == null) {
/*  881 */       boolean checkWelcomeFiles = checkJspWelcomeFiles;
/*  882 */       if (!checkWelcomeFiles) {
/*  883 */         char[] buf = path.getBuffer();
/*  884 */         checkWelcomeFiles = buf[(pathEnd - 1)] == '/';
/*      */       }
/*  886 */       if (checkWelcomeFiles) {
/*  887 */         for (int i = 0; 
/*  888 */             (i < contextVersion.welcomeResources.length) && (mappingData.wrapper == null); i++) {
/*  889 */           path.setOffset(pathOffset);
/*  890 */           path.setEnd(pathEnd);
/*  891 */           path.append(contextVersion.welcomeResources[i], 0, contextVersion.welcomeResources[i].length());
/*      */           
/*  893 */           path.setOffset(servletPath);
/*      */           
/*      */ 
/*  896 */           internalMapExactWrapper(exactWrappers, path, mappingData);
/*      */           
/*      */ 
/*  899 */           if (mappingData.wrapper == null) {
/*  900 */             internalMapWildcardWrapper(wildcardWrappers, contextVersion.nesting, path, mappingData);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  907 */           if ((mappingData.wrapper == null) && (contextVersion.resources != null))
/*      */           {
/*  909 */             String pathStr = path.toString();
/*  910 */             WebResource file = contextVersion.resources.getResource(pathStr);
/*      */             
/*  912 */             if ((file != null) && (file.isFile())) {
/*  913 */               internalMapExtensionWrapper(extensionWrappers, path, mappingData, true);
/*      */               
/*  915 */               if ((mappingData.wrapper == null) && (contextVersion.defaultWrapper != null))
/*      */               {
/*  917 */                 mappingData.wrapper = ((Wrapper)contextVersion.defaultWrapper.object);
/*      */                 
/*  919 */                 mappingData.requestPath.setChars(path.getBuffer(), path.getStart(), path.getLength());
/*      */                 
/*      */ 
/*  922 */                 mappingData.wrapperPath.setChars(path.getBuffer(), path.getStart(), path.getLength());
/*      */                 
/*      */ 
/*  925 */                 mappingData.requestPath.setString(pathStr);
/*  926 */                 mappingData.wrapperPath.setString(pathStr);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*  932 */         path.setOffset(servletPath);
/*  933 */         path.setEnd(pathEnd);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  945 */     if (mappingData.wrapper == null) {
/*  946 */       boolean checkWelcomeFiles = checkJspWelcomeFiles;
/*  947 */       if (!checkWelcomeFiles) {
/*  948 */         char[] buf = path.getBuffer();
/*  949 */         checkWelcomeFiles = buf[(pathEnd - 1)] == '/';
/*      */       }
/*  951 */       if (checkWelcomeFiles) {
/*  952 */         for (int i = 0; 
/*  953 */             (i < contextVersion.welcomeResources.length) && (mappingData.wrapper == null); i++) {
/*  954 */           path.setOffset(pathOffset);
/*  955 */           path.setEnd(pathEnd);
/*  956 */           path.append(contextVersion.welcomeResources[i], 0, contextVersion.welcomeResources[i].length());
/*      */           
/*  958 */           path.setOffset(servletPath);
/*  959 */           internalMapExtensionWrapper(extensionWrappers, path, mappingData, false);
/*      */         }
/*      */         
/*      */ 
/*  963 */         path.setOffset(servletPath);
/*  964 */         path.setEnd(pathEnd);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  970 */     if ((mappingData.wrapper == null) && (!checkJspWelcomeFiles)) {
/*  971 */       if (contextVersion.defaultWrapper != null) {
/*  972 */         mappingData.wrapper = ((Wrapper)contextVersion.defaultWrapper.object);
/*  973 */         mappingData.requestPath.setChars(path.getBuffer(), path.getStart(), path.getLength());
/*      */         
/*  975 */         mappingData.wrapperPath.setChars(path.getBuffer(), path.getStart(), path.getLength());
/*      */         
/*  977 */         mappingData.matchType = MappingMatch.DEFAULT;
/*      */       }
/*      */       
/*  980 */       char[] buf = path.getBuffer();
/*  981 */       if ((contextVersion.resources != null) && (buf[(pathEnd - 1)] != '/')) {
/*  982 */         String pathStr = path.toString();
/*      */         WebResource file;
/*      */         WebResource file;
/*  985 */         if (pathStr.length() == 0) {
/*  986 */           file = contextVersion.resources.getResource("/");
/*      */         } else {
/*  988 */           file = contextVersion.resources.getResource(pathStr);
/*      */         }
/*  990 */         if ((file != null) && (file.isDirectory()) && (((Context)contextVersion.object).getMapperDirectoryRedirectEnabled()))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  995 */           path.setOffset(pathOffset);
/*  996 */           path.append('/');
/*  997 */           mappingData.redirectPath.setChars(path.getBuffer(), path.getStart(), path.getLength());
/*      */         }
/*      */         else {
/* 1000 */           mappingData.requestPath.setString(pathStr);
/* 1001 */           mappingData.wrapperPath.setString(pathStr);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1006 */     path.setOffset(pathOffset);
/* 1007 */     path.setEnd(pathEnd);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void internalMapExactWrapper(MappedWrapper[] wrappers, CharChunk path, MappingData mappingData)
/*      */   {
/* 1016 */     MappedWrapper wrapper = (MappedWrapper)exactFind(wrappers, path);
/* 1017 */     if (wrapper != null) {
/* 1018 */       mappingData.requestPath.setString(wrapper.name);
/* 1019 */       mappingData.wrapper = ((Wrapper)wrapper.object);
/* 1020 */       if (path.equals("/"))
/*      */       {
/* 1022 */         mappingData.pathInfo.setString("/");
/* 1023 */         mappingData.wrapperPath.setString("");
/*      */         
/* 1025 */         mappingData.contextPath.setString("");
/* 1026 */         mappingData.matchType = MappingMatch.CONTEXT_ROOT;
/*      */       } else {
/* 1028 */         mappingData.wrapperPath.setString(wrapper.name);
/* 1029 */         mappingData.matchType = MappingMatch.EXACT;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void internalMapWildcardWrapper(MappedWrapper[] wrappers, int nesting, CharChunk path, MappingData mappingData)
/*      */   {
/* 1042 */     int pathEnd = path.getEnd();
/*      */     
/* 1044 */     int lastSlash = -1;
/* 1045 */     int length = -1;
/* 1046 */     int pos = find(wrappers, path);
/* 1047 */     if (pos != -1) {
/* 1048 */       boolean found = false;
/* 1049 */       while (pos >= 0) {
/* 1050 */         if (path.startsWith(wrappers[pos].name)) {
/* 1051 */           length = wrappers[pos].name.length();
/* 1052 */           if (path.getLength() == length) {
/* 1053 */             found = true;
/* 1054 */             break; }
/* 1055 */           if (path.startsWithIgnoreCase("/", length)) {
/* 1056 */             found = true;
/* 1057 */             break;
/*      */           }
/*      */         }
/* 1060 */         if (lastSlash == -1) {
/* 1061 */           lastSlash = nthSlash(path, nesting + 1);
/*      */         } else {
/* 1063 */           lastSlash = lastSlash(path);
/*      */         }
/* 1065 */         path.setEnd(lastSlash);
/* 1066 */         pos = find(wrappers, path);
/*      */       }
/* 1068 */       path.setEnd(pathEnd);
/* 1069 */       if (found) {
/* 1070 */         mappingData.wrapperPath.setString(wrappers[pos].name);
/* 1071 */         if (path.getLength() > length) {
/* 1072 */           mappingData.pathInfo.setChars(path.getBuffer(), path.getOffset() + length, path.getLength() - length);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1077 */         mappingData.requestPath.setChars(path.getBuffer(), path.getOffset(), path.getLength());
/*      */         
/* 1079 */         mappingData.wrapper = ((Wrapper)wrappers[pos].object);
/* 1080 */         mappingData.jspWildCard = wrappers[pos].jspWildCard;
/* 1081 */         mappingData.matchType = MappingMatch.PATH;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void internalMapExtensionWrapper(MappedWrapper[] wrappers, CharChunk path, MappingData mappingData, boolean resourceExpected)
/*      */   {
/* 1097 */     char[] buf = path.getBuffer();
/* 1098 */     int pathEnd = path.getEnd();
/* 1099 */     int servletPath = path.getOffset();
/* 1100 */     int slash = -1;
/* 1101 */     for (int i = pathEnd - 1; i >= servletPath; i--) {
/* 1102 */       if (buf[i] == '/') {
/* 1103 */         slash = i;
/* 1104 */         break;
/*      */       }
/*      */     }
/* 1107 */     if (slash >= 0) {
/* 1108 */       int period = -1;
/* 1109 */       for (int i = pathEnd - 1; i > slash; i--) {
/* 1110 */         if (buf[i] == '.') {
/* 1111 */           period = i;
/* 1112 */           break;
/*      */         }
/*      */       }
/* 1115 */       if (period >= 0) {
/* 1116 */         path.setOffset(period + 1);
/* 1117 */         path.setEnd(pathEnd);
/* 1118 */         MappedWrapper wrapper = (MappedWrapper)exactFind(wrappers, path);
/* 1119 */         if ((wrapper != null) && ((resourceExpected) || (!wrapper.resourceOnly)))
/*      */         {
/* 1121 */           mappingData.wrapperPath.setChars(buf, servletPath, pathEnd - servletPath);
/*      */           
/* 1123 */           mappingData.requestPath.setChars(buf, servletPath, pathEnd - servletPath);
/*      */           
/* 1125 */           mappingData.wrapper = ((Wrapper)wrapper.object);
/* 1126 */           mappingData.matchType = MappingMatch.EXTENSION;
/*      */         }
/* 1128 */         path.setOffset(servletPath);
/* 1129 */         path.setEnd(pathEnd);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final <T> int find(MapElement<T>[] map, CharChunk name)
/*      */   {
/* 1141 */     return find(map, name, name.getStart(), name.getEnd());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final <T> int find(MapElement<T>[] map, CharChunk name, int start, int end)
/*      */   {
/* 1153 */     int a = 0;
/* 1154 */     int b = map.length - 1;
/*      */     
/*      */ 
/* 1157 */     if (b == -1) {
/* 1158 */       return -1;
/*      */     }
/*      */     
/* 1161 */     if (compare(name, start, end, map[0].name) < 0) {
/* 1162 */       return -1;
/*      */     }
/* 1164 */     if (b == 0) {
/* 1165 */       return 0;
/*      */     }
/*      */     
/* 1168 */     int i = 0;
/*      */     for (;;) {
/* 1170 */       i = (b + a) / 2;
/* 1171 */       int result = compare(name, start, end, map[i].name);
/* 1172 */       if (result == 1) {
/* 1173 */         a = i;
/* 1174 */       } else { if (result == 0) {
/* 1175 */           return i;
/*      */         }
/* 1177 */         b = i;
/*      */       }
/* 1179 */       if (b - a == 1) {
/* 1180 */         int result2 = compare(name, start, end, map[b].name);
/* 1181 */         if (result2 < 0) {
/* 1182 */           return a;
/*      */         }
/* 1184 */         return b;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final <T> int findIgnoreCase(MapElement<T>[] map, CharChunk name)
/*      */   {
/* 1197 */     return findIgnoreCase(map, name, name.getStart(), name.getEnd());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final <T> int findIgnoreCase(MapElement<T>[] map, CharChunk name, int start, int end)
/*      */   {
/* 1209 */     int a = 0;
/* 1210 */     int b = map.length - 1;
/*      */     
/*      */ 
/* 1213 */     if (b == -1) {
/* 1214 */       return -1;
/*      */     }
/* 1216 */     if (compareIgnoreCase(name, start, end, map[0].name) < 0) {
/* 1217 */       return -1;
/*      */     }
/* 1219 */     if (b == 0) {
/* 1220 */       return 0;
/*      */     }
/*      */     
/* 1223 */     int i = 0;
/*      */     for (;;) {
/* 1225 */       i = (b + a) / 2;
/* 1226 */       int result = compareIgnoreCase(name, start, end, map[i].name);
/* 1227 */       if (result == 1) {
/* 1228 */         a = i;
/* 1229 */       } else { if (result == 0) {
/* 1230 */           return i;
/*      */         }
/* 1232 */         b = i;
/*      */       }
/* 1234 */       if (b - a == 1) {
/* 1235 */         int result2 = compareIgnoreCase(name, start, end, map[b].name);
/* 1236 */         if (result2 < 0) {
/* 1237 */           return a;
/*      */         }
/* 1239 */         return b;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final <T> int find(MapElement<T>[] map, String name)
/*      */   {
/* 1255 */     int a = 0;
/* 1256 */     int b = map.length - 1;
/*      */     
/*      */ 
/* 1259 */     if (b == -1) {
/* 1260 */       return -1;
/*      */     }
/*      */     
/* 1263 */     if (name.compareTo(map[0].name) < 0) {
/* 1264 */       return -1;
/*      */     }
/* 1266 */     if (b == 0) {
/* 1267 */       return 0;
/*      */     }
/*      */     
/* 1270 */     int i = 0;
/*      */     for (;;) {
/* 1272 */       i = (b + a) / 2;
/* 1273 */       int result = name.compareTo(map[i].name);
/* 1274 */       if (result > 0) {
/* 1275 */         a = i;
/* 1276 */       } else { if (result == 0) {
/* 1277 */           return i;
/*      */         }
/* 1279 */         b = i;
/*      */       }
/* 1281 */       if (b - a == 1) {
/* 1282 */         int result2 = name.compareTo(map[b].name);
/* 1283 */         if (result2 < 0) {
/* 1284 */           return a;
/*      */         }
/* 1286 */         return b;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final <T, E extends MapElement<T>> E exactFind(E[] map, String name)
/*      */   {
/* 1302 */     int pos = find(map, name);
/* 1303 */     if (pos >= 0) {
/* 1304 */       E result = map[pos];
/* 1305 */       if (name.equals(result.name)) {
/* 1306 */         return result;
/*      */       }
/*      */     }
/* 1309 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final <T, E extends MapElement<T>> E exactFind(E[] map, CharChunk name)
/*      */   {
/* 1319 */     int pos = find(map, name);
/* 1320 */     if (pos >= 0) {
/* 1321 */       E result = map[pos];
/* 1322 */       if (name.equals(result.name)) {
/* 1323 */         return result;
/*      */       }
/*      */     }
/* 1326 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final <T, E extends MapElement<T>> E exactFindIgnoreCase(E[] map, CharChunk name)
/*      */   {
/* 1337 */     int pos = findIgnoreCase(map, name);
/* 1338 */     if (pos >= 0) {
/* 1339 */       E result = map[pos];
/* 1340 */       if (name.equalsIgnoreCase(result.name)) {
/* 1341 */         return result;
/*      */       }
/*      */     }
/* 1344 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int compare(CharChunk name, int start, int end, String compareTo)
/*      */   {
/* 1354 */     int result = 0;
/* 1355 */     char[] c = name.getBuffer();
/* 1356 */     int len = compareTo.length();
/* 1357 */     if (end - start < len) {
/* 1358 */       len = end - start;
/*      */     }
/* 1360 */     for (int i = 0; (i < len) && (result == 0); i++) {
/* 1361 */       if (c[(i + start)] > compareTo.charAt(i)) {
/* 1362 */         result = 1;
/* 1363 */       } else if (c[(i + start)] < compareTo.charAt(i)) {
/* 1364 */         result = -1;
/*      */       }
/*      */     }
/* 1367 */     if (result == 0) {
/* 1368 */       if (compareTo.length() > end - start) {
/* 1369 */         result = -1;
/* 1370 */       } else if (compareTo.length() < end - start) {
/* 1371 */         result = 1;
/*      */       }
/*      */     }
/* 1374 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int compareIgnoreCase(CharChunk name, int start, int end, String compareTo)
/*      */   {
/* 1384 */     int result = 0;
/* 1385 */     char[] c = name.getBuffer();
/* 1386 */     int len = compareTo.length();
/* 1387 */     if (end - start < len) {
/* 1388 */       len = end - start;
/*      */     }
/* 1390 */     for (int i = 0; (i < len) && (result == 0); i++) {
/* 1391 */       if (Ascii.toLower(c[(i + start)]) > Ascii.toLower(compareTo.charAt(i))) {
/* 1392 */         result = 1;
/* 1393 */       } else if (Ascii.toLower(c[(i + start)]) < Ascii.toLower(compareTo.charAt(i))) {
/* 1394 */         result = -1;
/*      */       }
/*      */     }
/* 1397 */     if (result == 0) {
/* 1398 */       if (compareTo.length() > end - start) {
/* 1399 */         result = -1;
/* 1400 */       } else if (compareTo.length() < end - start) {
/* 1401 */         result = 1;
/*      */       }
/*      */     }
/* 1404 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int lastSlash(CharChunk name)
/*      */   {
/* 1413 */     char[] c = name.getBuffer();
/* 1414 */     int end = name.getEnd();
/* 1415 */     int start = name.getStart();
/* 1416 */     int pos = end;
/*      */     
/* 1418 */     while (pos > start) {
/* 1419 */       if (c[(--pos)] == '/') {
/*      */         break;
/*      */       }
/*      */     }
/*      */     
/* 1424 */     return pos;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int nthSlash(CharChunk name, int n)
/*      */   {
/* 1434 */     char[] c = name.getBuffer();
/* 1435 */     int end = name.getEnd();
/* 1436 */     int start = name.getStart();
/* 1437 */     int pos = start;
/* 1438 */     int count = 0;
/*      */     
/* 1440 */     while (pos < end) {
/* 1441 */       if (c[(pos++)] == '/') { count++; if (count == n) {
/* 1442 */           pos--;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1447 */     return pos;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int slashCount(String name)
/*      */   {
/* 1456 */     int pos = -1;
/* 1457 */     int count = 0;
/* 1458 */     while ((pos = name.indexOf('/', pos + 1)) != -1) {
/* 1459 */       count++;
/*      */     }
/* 1461 */     return count;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final <T> boolean insertMap(MapElement<T>[] oldMap, MapElement<T>[] newMap, MapElement<T> newElement)
/*      */   {
/* 1471 */     int pos = find(oldMap, newElement.name);
/* 1472 */     if ((pos != -1) && (newElement.name.equals(oldMap[pos].name))) {
/* 1473 */       return false;
/*      */     }
/* 1475 */     System.arraycopy(oldMap, 0, newMap, 0, pos + 1);
/* 1476 */     newMap[(pos + 1)] = newElement;
/* 1477 */     System.arraycopy(oldMap, pos + 1, newMap, pos + 2, oldMap.length - pos - 1);
/*      */     
/* 1479 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final <T> boolean removeMap(MapElement<T>[] oldMap, MapElement<T>[] newMap, String name)
/*      */   {
/* 1488 */     int pos = find(oldMap, name);
/* 1489 */     if ((pos != -1) && (name.equals(oldMap[pos].name))) {
/* 1490 */       System.arraycopy(oldMap, 0, newMap, 0, pos);
/* 1491 */       System.arraycopy(oldMap, pos + 1, newMap, pos, oldMap.length - pos - 1);
/*      */       
/* 1493 */       return true;
/*      */     }
/* 1495 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   protected static abstract class MapElement<T>
/*      */   {
/*      */     public final String name;
/*      */     
/*      */     public final T object;
/*      */     
/*      */ 
/*      */     public MapElement(String name, T object)
/*      */     {
/* 1508 */       this.name = name;
/* 1509 */       this.object = object;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final class MappedHost
/*      */     extends Mapper.MapElement<Host>
/*      */   {
/*      */     public volatile Mapper.ContextList contextList;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private final MappedHost realHost;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private final List<MappedHost> aliases;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public MappedHost(String name, Host host)
/*      */     {
/* 1540 */       super(host);
/* 1541 */       this.realHost = this;
/* 1542 */       this.contextList = new Mapper.ContextList();
/* 1543 */       this.aliases = new CopyOnWriteArrayList();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public MappedHost(String alias, MappedHost realHost)
/*      */     {
/* 1553 */       super(realHost.object);
/* 1554 */       this.realHost = realHost;
/* 1555 */       this.contextList = realHost.contextList;
/* 1556 */       this.aliases = null;
/*      */     }
/*      */     
/*      */     public boolean isAlias() {
/* 1560 */       return this.realHost != this;
/*      */     }
/*      */     
/*      */     public MappedHost getRealHost() {
/* 1564 */       return this.realHost;
/*      */     }
/*      */     
/*      */     public String getRealHostName() {
/* 1568 */       return this.realHost.name;
/*      */     }
/*      */     
/*      */     public Collection<MappedHost> getAliases() {
/* 1572 */       return this.aliases;
/*      */     }
/*      */     
/*      */     public void addAlias(MappedHost alias) {
/* 1576 */       this.aliases.add(alias);
/*      */     }
/*      */     
/*      */     public void addAliases(Collection<? extends MappedHost> c) {
/* 1580 */       this.aliases.addAll(c);
/*      */     }
/*      */     
/*      */     public void removeAlias(MappedHost alias) {
/* 1584 */       this.aliases.remove(alias);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected static final class ContextList
/*      */   {
/*      */     public final Mapper.MappedContext[] contexts;
/*      */     
/*      */     public final int nesting;
/*      */     
/*      */ 
/*      */     public ContextList()
/*      */     {
/* 1598 */       this(new Mapper.MappedContext[0], 0);
/*      */     }
/*      */     
/*      */     private ContextList(Mapper.MappedContext[] contexts, int nesting) {
/* 1602 */       this.contexts = contexts;
/* 1603 */       this.nesting = nesting;
/*      */     }
/*      */     
/*      */     public ContextList addContext(Mapper.MappedContext mappedContext, int slashCount)
/*      */     {
/* 1608 */       Mapper.MappedContext[] newContexts = new Mapper.MappedContext[this.contexts.length + 1];
/* 1609 */       if (Mapper.insertMap(this.contexts, newContexts, mappedContext)) {
/* 1610 */         return new ContextList(newContexts, Math.max(this.nesting, slashCount));
/*      */       }
/*      */       
/* 1613 */       return null;
/*      */     }
/*      */     
/*      */     public ContextList removeContext(String path) {
/* 1617 */       Mapper.MappedContext[] newContexts = new Mapper.MappedContext[this.contexts.length - 1];
/* 1618 */       if (Mapper.removeMap(this.contexts, newContexts, path)) {
/* 1619 */         int newNesting = 0;
/* 1620 */         for (Mapper.MappedContext context : newContexts) {
/* 1621 */           newNesting = Math.max(newNesting, Mapper.slashCount(context.name));
/*      */         }
/* 1623 */         return new ContextList(newContexts, newNesting);
/*      */       }
/* 1625 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected static final class MappedContext
/*      */     extends Mapper.MapElement<Void>
/*      */   {
/*      */     public volatile Mapper.ContextVersion[] versions;
/*      */     
/*      */     public MappedContext(String name, Mapper.ContextVersion firstVersion)
/*      */     {
/* 1637 */       super(null);
/* 1638 */       this.versions = new Mapper.ContextVersion[] { firstVersion };
/*      */     }
/*      */   }
/*      */   
/*      */   protected static final class ContextVersion extends Mapper.MapElement<Context> {
/*      */     public final String path;
/*      */     public final int slashCount;
/*      */     public final WebResourceRoot resources;
/*      */     public String[] welcomeResources;
/* 1647 */     public Mapper.MappedWrapper defaultWrapper = null;
/* 1648 */     public Mapper.MappedWrapper[] exactWrappers = new Mapper.MappedWrapper[0];
/* 1649 */     public Mapper.MappedWrapper[] wildcardWrappers = new Mapper.MappedWrapper[0];
/* 1650 */     public Mapper.MappedWrapper[] extensionWrappers = new Mapper.MappedWrapper[0];
/* 1651 */     public int nesting = 0;
/*      */     
/*      */     private volatile boolean paused;
/*      */     
/*      */     public ContextVersion(String version, String path, int slashCount, Context context, WebResourceRoot resources, String[] welcomeResources)
/*      */     {
/* 1657 */       super(context);
/* 1658 */       this.path = path;
/* 1659 */       this.slashCount = slashCount;
/* 1660 */       this.resources = resources;
/* 1661 */       this.welcomeResources = welcomeResources;
/*      */     }
/*      */     
/*      */     public boolean isPaused() {
/* 1665 */       return this.paused;
/*      */     }
/*      */     
/*      */     public void markPaused() {
/* 1669 */       this.paused = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected static class MappedWrapper
/*      */     extends Mapper.MapElement<Wrapper>
/*      */   {
/*      */     public final boolean jspWildCard;
/*      */     
/*      */     public final boolean resourceOnly;
/*      */     
/*      */     public MappedWrapper(String name, Wrapper wrapper, boolean jspWildCard, boolean resourceOnly)
/*      */     {
/* 1683 */       super(wrapper);
/* 1684 */       this.jspWildCard = jspWildCard;
/* 1685 */       this.resourceOnly = resourceOnly;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\mapper\Mapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */