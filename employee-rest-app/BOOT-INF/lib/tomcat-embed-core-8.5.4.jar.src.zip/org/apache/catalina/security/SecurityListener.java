/*     */ package org.apache.catalina.security;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SecurityListener
/*     */   implements LifecycleListener
/*     */ {
/*  33 */   private static final Log log = LogFactory.getLog(SecurityListener.class);
/*     */   
/*  35 */   private static final StringManager sm = StringManager.getManager("org.apache.catalina.security");
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String UMASK_PROPERTY_NAME = "org.apache.catalina.security.SecurityListener.UMASK";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String UMASK_FORMAT = "%04o";
/*     */   
/*     */ 
/*  46 */   private final Set<String> checkedOsUsers = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  52 */   private Integer minimumUmask = Integer.valueOf(7);
/*     */   
/*     */   public SecurityListener()
/*     */   {
/*  56 */     this.checkedOsUsers.add("root");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void lifecycleEvent(LifecycleEvent event)
/*     */   {
/*  63 */     if (event.getType().equals("before_init")) {
/*  64 */       doChecks();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCheckedOsUsers(String userNameList)
/*     */   {
/*  80 */     if ((userNameList == null) || (userNameList.length() == 0)) {
/*  81 */       this.checkedOsUsers.clear();
/*     */     } else {
/*  83 */       String[] userNames = userNameList.split(",");
/*  84 */       for (String userName : userNames) {
/*  85 */         if (userName.length() > 0) {
/*  86 */           this.checkedOsUsers.add(userName.toLowerCase(Locale.getDefault()));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCheckedOsUsers()
/*     */   {
/* 100 */     if (this.checkedOsUsers.size() == 0) {
/* 101 */       return "";
/*     */     }
/*     */     
/* 104 */     StringBuilder result = new StringBuilder();
/* 105 */     Iterator<String> iter = this.checkedOsUsers.iterator();
/* 106 */     result.append((String)iter.next());
/* 107 */     while (iter.hasNext()) {
/* 108 */       result.append(',');
/* 109 */       result.append((String)iter.next());
/*     */     }
/* 111 */     return result.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMinimumUmask(String umask)
/*     */   {
/* 121 */     if ((umask == null) || (umask.length() == 0)) {
/* 122 */       this.minimumUmask = Integer.valueOf(0);
/*     */     } else {
/* 124 */       this.minimumUmask = Integer.valueOf(umask, 8);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMinimumUmask()
/*     */   {
/* 135 */     return String.format("%04o", new Object[] { this.minimumUmask });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doChecks()
/*     */   {
/* 143 */     checkOsUser();
/* 144 */     checkUmask();
/*     */   }
/*     */   
/*     */   protected void checkOsUser()
/*     */   {
/* 149 */     String userName = System.getProperty("user.name");
/* 150 */     if (userName != null) {
/* 151 */       String userNameLC = userName.toLowerCase(Locale.getDefault());
/*     */       
/* 153 */       if (this.checkedOsUsers.contains(userNameLC))
/*     */       {
/* 155 */         throw new Error(sm.getString("SecurityListener.checkUserWarning", new Object[] { userName }));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void checkUmask()
/*     */   {
/* 163 */     String prop = System.getProperty("org.apache.catalina.security.SecurityListener.UMASK");
/* 164 */     Integer umask = null;
/* 165 */     if (prop != null) {
/*     */       try {
/* 167 */         umask = Integer.valueOf(prop, 8);
/*     */       } catch (NumberFormatException nfe) {
/* 169 */         log.warn(sm.getString("SecurityListener.checkUmaskParseFail", new Object[] { prop }));
/*     */       }
/*     */     }
/*     */     
/* 173 */     if (umask == null) {
/* 174 */       if ("\r\n".equals(System.lineSeparator()))
/*     */       {
/* 176 */         if (log.isDebugEnabled()) {
/* 177 */           log.debug(sm.getString("SecurityListener.checkUmaskSkip"));
/*     */         }
/* 179 */         return;
/*     */       }
/* 181 */       if (this.minimumUmask.intValue() > 0) {
/* 182 */         log.warn(sm.getString("SecurityListener.checkUmaskNone", new Object[] { "org.apache.catalina.security.SecurityListener.UMASK", getMinimumUmask() }));
/*     */       }
/*     */       
/*     */ 
/* 186 */       return;
/*     */     }
/*     */     
/*     */ 
/* 190 */     if ((umask.intValue() & this.minimumUmask.intValue()) != this.minimumUmask.intValue())
/*     */     {
/* 192 */       throw new Error(sm.getString("SecurityListener.checkUmaskFail", new Object[] { String.format("%04o", new Object[] { umask }), getMinimumUmask() }));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\security\SecurityListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */