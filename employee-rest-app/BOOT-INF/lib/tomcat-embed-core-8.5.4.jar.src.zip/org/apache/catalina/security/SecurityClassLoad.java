/*     */ package org.apache.catalina.security;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SecurityClassLoad
/*     */ {
/*     */   public static void securityClassLoad(ClassLoader loader)
/*     */     throws Exception
/*     */   {
/*  31 */     securityClassLoad(loader, true);
/*     */   }
/*     */   
/*     */ 
/*     */   static void securityClassLoad(ClassLoader loader, boolean requireSecurityManager)
/*     */     throws Exception
/*     */   {
/*  38 */     if ((requireSecurityManager) && (System.getSecurityManager() == null)) {
/*  39 */       return;
/*     */     }
/*     */     
/*  42 */     loadCorePackage(loader);
/*  43 */     loadCoyotePackage(loader);
/*  44 */     loadLoaderPackage(loader);
/*  45 */     loadRealmPackage(loader);
/*  46 */     loadServletsPackage(loader);
/*  47 */     loadSessionPackage(loader);
/*  48 */     loadUtilPackage(loader);
/*  49 */     loadValvesPackage(loader);
/*  50 */     loadJavaxPackage(loader);
/*  51 */     loadConnectorPackage(loader);
/*  52 */     loadTomcatPackage(loader);
/*     */   }
/*     */   
/*     */   private static final void loadCorePackage(ClassLoader loader)
/*     */     throws Exception
/*     */   {
/*  58 */     String basePackage = "org.apache.catalina.core.";
/*  59 */     loader.loadClass("org.apache.catalina.core.AccessLogAdapter");
/*     */     
/*     */ 
/*  62 */     loader.loadClass("org.apache.catalina.core.ApplicationContextFacade$PrivilegedExecuteMethod");
/*     */     
/*     */ 
/*  65 */     loader.loadClass("org.apache.catalina.core.ApplicationDispatcher$PrivilegedForward");
/*     */     
/*     */ 
/*  68 */     loader.loadClass("org.apache.catalina.core.ApplicationDispatcher$PrivilegedInclude");
/*     */     
/*     */ 
/*  71 */     loader.loadClass("org.apache.catalina.core.ApplicationPushBuilder");
/*     */     
/*     */ 
/*  74 */     loader.loadClass("org.apache.catalina.core.AsyncContextImpl");
/*     */     
/*     */ 
/*  77 */     loader.loadClass("org.apache.catalina.core.AsyncContextImpl$AsyncRunnable");
/*     */     
/*     */ 
/*  80 */     loader.loadClass("org.apache.catalina.core.AsyncContextImpl$DebugException");
/*     */     
/*     */ 
/*  83 */     loader.loadClass("org.apache.catalina.core.AsyncListenerWrapper");
/*     */     
/*     */ 
/*  86 */     loader.loadClass("org.apache.catalina.core.ContainerBase$PrivilegedAddChild");
/*     */     
/*     */ 
/*  89 */     loader.loadClass("org.apache.catalina.core.DefaultInstanceManager$1");
/*     */     
/*     */ 
/*  92 */     loader.loadClass("org.apache.catalina.core.DefaultInstanceManager$2");
/*     */     
/*     */ 
/*  95 */     loader.loadClass("org.apache.catalina.core.DefaultInstanceManager$3");
/*     */     
/*     */ 
/*  98 */     loader.loadClass("org.apache.catalina.core.DefaultInstanceManager$AnnotationCacheEntry");
/*     */     
/*     */ 
/* 101 */     loader.loadClass("org.apache.catalina.core.DefaultInstanceManager$AnnotationCacheEntryType");
/*     */     
/*     */ 
/* 104 */     loader.loadClass("org.apache.catalina.core.ApplicationHttpRequest$AttributeNamesEnumerator");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final void loadLoaderPackage(ClassLoader loader)
/*     */     throws Exception
/*     */   {
/* 112 */     String basePackage = "org.apache.catalina.loader.";
/* 113 */     loader.loadClass("org.apache.catalina.loader.WebappClassLoaderBase$PrivilegedFindClassByName");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final void loadRealmPackage(ClassLoader loader)
/*     */     throws Exception
/*     */   {
/* 121 */     String basePackage = "org.apache.catalina.realm.";
/* 122 */     loader.loadClass("org.apache.catalina.realm.LockOutRealm$LockRecord");
/*     */   }
/*     */   
/*     */ 
/*     */   private static final void loadServletsPackage(ClassLoader loader)
/*     */     throws Exception
/*     */   {
/* 129 */     String basePackage = "org.apache.catalina.servlets.";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 135 */     loader.loadClass("org.apache.catalina.servlets.DefaultServlet");
/*     */   }
/*     */   
/*     */   private static final void loadSessionPackage(ClassLoader loader)
/*     */     throws Exception
/*     */   {
/* 141 */     String basePackage = "org.apache.catalina.session.";
/* 142 */     loader.loadClass("org.apache.catalina.session.StandardSession");
/*     */     
/* 144 */     loader.loadClass("org.apache.catalina.session.StandardSession$1");
/*     */     
/* 146 */     loader.loadClass("org.apache.catalina.session.StandardManager$PrivilegedDoUnload");
/*     */   }
/*     */   
/*     */ 
/*     */   private static final void loadUtilPackage(ClassLoader loader)
/*     */     throws Exception
/*     */   {
/* 153 */     String basePackage = "org.apache.catalina.util.";
/* 154 */     loader.loadClass("org.apache.catalina.util.ParameterMap");
/* 155 */     loader.loadClass("org.apache.catalina.util.RequestUtil");
/*     */   }
/*     */   
/*     */   private static final void loadValvesPackage(ClassLoader loader)
/*     */     throws Exception
/*     */   {
/* 161 */     String basePackage = "org.apache.catalina.valves.";
/* 162 */     loader.loadClass("org.apache.catalina.valves.AbstractAccessLogValve$3");
/*     */   }
/*     */   
/*     */   private static final void loadCoyotePackage(ClassLoader loader)
/*     */     throws Exception
/*     */   {
/* 168 */     String basePackage = "org.apache.coyote.";
/* 169 */     loader.loadClass("org.apache.coyote.PushToken");
/* 170 */     loader.loadClass("org.apache.coyote.http11.Constants");
/*     */     
/* 172 */     Class<?> clazz = loader.loadClass("org.apache.coyote.Constants");
/* 173 */     clazz.newInstance();
/* 174 */     loader.loadClass("org.apache.coyote.http2.Stream$1");
/*     */   }
/*     */   
/*     */   private static final void loadJavaxPackage(ClassLoader loader)
/*     */     throws Exception
/*     */   {
/* 180 */     loader.loadClass("javax.servlet.http.Cookie");
/*     */   }
/*     */   
/*     */   private static final void loadConnectorPackage(ClassLoader loader)
/*     */     throws Exception
/*     */   {
/* 186 */     String basePackage = "org.apache.catalina.connector.";
/* 187 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetAttributePrivilegedAction");
/*     */     
/*     */ 
/* 190 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetParameterMapPrivilegedAction");
/*     */     
/*     */ 
/* 193 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetRequestDispatcherPrivilegedAction");
/*     */     
/*     */ 
/* 196 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetParameterPrivilegedAction");
/*     */     
/*     */ 
/* 199 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetParameterNamesPrivilegedAction");
/*     */     
/*     */ 
/* 202 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetParameterValuePrivilegedAction");
/*     */     
/*     */ 
/* 205 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetCharacterEncodingPrivilegedAction");
/*     */     
/*     */ 
/* 208 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetHeadersPrivilegedAction");
/*     */     
/*     */ 
/* 211 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetHeaderNamesPrivilegedAction");
/*     */     
/*     */ 
/* 214 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetCookiesPrivilegedAction");
/*     */     
/*     */ 
/* 217 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetLocalePrivilegedAction");
/*     */     
/*     */ 
/* 220 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetLocalesPrivilegedAction");
/*     */     
/*     */ 
/* 223 */     loader.loadClass("org.apache.catalina.connector.ResponseFacade$SetContentTypePrivilegedAction");
/*     */     
/*     */ 
/* 226 */     loader.loadClass("org.apache.catalina.connector.ResponseFacade$DateHeaderPrivilegedAction");
/*     */     
/*     */ 
/* 229 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetSessionPrivilegedAction");
/*     */     
/*     */ 
/* 232 */     loader.loadClass("org.apache.catalina.connector.ResponseFacade$1");
/*     */     
/*     */ 
/* 235 */     loader.loadClass("org.apache.catalina.connector.OutputBuffer$1");
/*     */     
/*     */ 
/* 238 */     loader.loadClass("org.apache.catalina.connector.OutputBuffer$2");
/*     */     
/*     */ 
/* 241 */     loader.loadClass("org.apache.catalina.connector.CoyoteInputStream$1");
/*     */     
/*     */ 
/* 244 */     loader.loadClass("org.apache.catalina.connector.CoyoteInputStream$2");
/*     */     
/*     */ 
/* 247 */     loader.loadClass("org.apache.catalina.connector.CoyoteInputStream$3");
/*     */     
/*     */ 
/* 250 */     loader.loadClass("org.apache.catalina.connector.CoyoteInputStream$4");
/*     */     
/*     */ 
/* 253 */     loader.loadClass("org.apache.catalina.connector.CoyoteInputStream$5");
/*     */     
/*     */ 
/* 256 */     loader.loadClass("org.apache.catalina.connector.InputBuffer$1");
/*     */     
/*     */ 
/* 259 */     loader.loadClass("org.apache.catalina.connector.Response$1");
/*     */     
/*     */ 
/* 262 */     loader.loadClass("org.apache.catalina.connector.Response$2");
/*     */     
/*     */ 
/* 265 */     loader.loadClass("org.apache.catalina.connector.Response$3");
/*     */   }
/*     */   
/*     */ 
/*     */   private static final void loadTomcatPackage(ClassLoader loader)
/*     */     throws Exception
/*     */   {
/* 272 */     String basePackage = "org.apache.tomcat.";
/*     */     
/* 274 */     loader.loadClass("org.apache.tomcat.util.buf.ByteBufferUtils");
/* 275 */     loader.loadClass("org.apache.tomcat.util.buf.HexUtils");
/* 276 */     loader.loadClass("org.apache.tomcat.util.buf.StringCache");
/* 277 */     loader.loadClass("org.apache.tomcat.util.buf.StringCache$ByteEntry");
/* 278 */     loader.loadClass("org.apache.tomcat.util.buf.StringCache$CharEntry");
/* 279 */     loader.loadClass("org.apache.tomcat.util.buf.UriUtil");
/*     */     
/* 281 */     Class<?> clazz = loader.loadClass("org.apache.tomcat.util.collections.CaseInsensitiveKeyMap");
/*     */     
/* 283 */     clazz.newInstance();
/* 284 */     loader.loadClass("org.apache.tomcat.util.collections.CaseInsensitiveKeyMap$EntryImpl");
/* 285 */     loader.loadClass("org.apache.tomcat.util.collections.CaseInsensitiveKeyMap$EntryIterator");
/* 286 */     loader.loadClass("org.apache.tomcat.util.collections.CaseInsensitiveKeyMap$EntrySet");
/* 287 */     loader.loadClass("org.apache.tomcat.util.collections.CaseInsensitiveKeyMap$Key");
/*     */     
/* 289 */     loader.loadClass("org.apache.tomcat.util.http.CookieProcessor");
/* 290 */     loader.loadClass("org.apache.tomcat.util.http.NamesEnumerator");
/*     */     
/* 292 */     clazz = loader.loadClass("org.apache.tomcat.util.http.FastHttpDateFormat");
/* 293 */     clazz.newInstance();
/* 294 */     loader.loadClass("org.apache.tomcat.util.http.parser.HttpParser");
/* 295 */     loader.loadClass("org.apache.tomcat.util.http.parser.MediaType");
/* 296 */     loader.loadClass("org.apache.tomcat.util.http.parser.MediaTypeCache");
/* 297 */     loader.loadClass("org.apache.tomcat.util.http.parser.SkipResult");
/*     */     
/* 299 */     loader.loadClass("org.apache.tomcat.util.net.Constants");
/* 300 */     loader.loadClass("org.apache.tomcat.util.net.DispatchType");
/* 301 */     loader.loadClass("org.apache.tomcat.util.net.NioBlockingSelector$BlockPoller$1");
/*     */     
/* 303 */     loader.loadClass("org.apache.tomcat.util.net.NioBlockingSelector$BlockPoller$2");
/*     */     
/* 305 */     loader.loadClass("org.apache.tomcat.util.net.NioBlockingSelector$BlockPoller$3");
/*     */     
/*     */ 
/* 308 */     loader.loadClass("org.apache.tomcat.util.security.PrivilegedGetTccl");
/* 309 */     loader.loadClass("org.apache.tomcat.util.security.PrivilegedSetTccl");
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\security\SecurityClassLoad.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */