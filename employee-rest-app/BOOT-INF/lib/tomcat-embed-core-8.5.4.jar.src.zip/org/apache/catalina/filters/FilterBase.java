/*    */ package org.apache.catalina.filters;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import org.apache.juli.logging.Log;
/*    */ import org.apache.tomcat.util.IntrospectionUtils;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FilterBase
/*    */   implements Filter
/*    */ {
/* 38 */   protected static final StringManager sm = StringManager.getManager(FilterBase.class);
/*    */   
/*    */   protected abstract Log getLogger();
/*    */   
/*    */   public void init(FilterConfig filterConfig) throws ServletException
/*    */   {
/* 44 */     Enumeration<String> paramNames = filterConfig.getInitParameterNames();
/* 45 */     while (paramNames.hasMoreElements()) {
/* 46 */       String paramName = (String)paramNames.nextElement();
/* 47 */       if (!IntrospectionUtils.setProperty(this, paramName, filterConfig.getInitParameter(paramName)))
/*    */       {
/* 49 */         String msg = sm.getString("filterbase.noSuchProperty", new Object[] { paramName, getClass().getName() });
/*    */         
/* 51 */         if (isConfigProblemFatal()) {
/* 52 */           throw new ServletException(msg);
/*    */         }
/* 54 */         getLogger().warn(msg);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void destroy() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected boolean isConfigProblemFatal()
/*    */   {
/* 74 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\filters\FilterBase.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */