/*     */ package org.apache.catalina.filters;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpHeaderSecurityFilter
/*     */   extends FilterBase
/*     */ {
/*  39 */   private static final Log log = LogFactory.getLog(HttpHeaderSecurityFilter.class);
/*     */   private static final String HSTS_HEADER_NAME = "Strict-Transport-Security";
/*     */   private boolean hstsEnabled;
/*     */   
/*  43 */   public HttpHeaderSecurityFilter() { this.hstsEnabled = true;
/*  44 */     this.hstsMaxAgeSeconds = 0;
/*  45 */     this.hstsIncludeSubDomains = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  50 */     this.antiClickJackingEnabled = true;
/*  51 */     this.antiClickJackingOption = XFrameOption.DENY;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  58 */     this.blockContentTypeSniffingEnabled = true;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  63 */     this.xssProtectionEnabled = true;
/*     */   }
/*     */   
/*     */   public void init(FilterConfig filterConfig) throws ServletException {
/*  67 */     super.init(filterConfig);
/*     */     
/*     */ 
/*  70 */     StringBuilder hstsValue = new StringBuilder("max-age=");
/*  71 */     hstsValue.append(this.hstsMaxAgeSeconds);
/*  72 */     if (this.hstsIncludeSubDomains) {
/*  73 */       hstsValue.append(";includeSubDomains");
/*     */     }
/*  75 */     this.hstsHeaderValue = hstsValue.toString();
/*     */     
/*     */ 
/*  78 */     StringBuilder cjValue = new StringBuilder(this.antiClickJackingOption.headerValue);
/*  79 */     if (this.antiClickJackingOption == XFrameOption.ALLOW_FROM) {
/*  80 */       cjValue.append(' ');
/*  81 */       cjValue.append(this.antiClickJackingUri);
/*     */     }
/*  83 */     this.antiClickJackingHeaderValue = cjValue.toString();
/*     */   }
/*     */   
/*     */   private int hstsMaxAgeSeconds;
/*     */   private boolean hstsIncludeSubDomains;
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/*  91 */     if ((response instanceof HttpServletResponse)) {
/*  92 */       HttpServletResponse httpResponse = (HttpServletResponse)response;
/*     */       
/*  94 */       if (response.isCommitted()) {
/*  95 */         throw new ServletException(sm.getString("httpHeaderSecurityFilter.committed"));
/*     */       }
/*     */       
/*     */ 
/*  99 */       if ((this.hstsEnabled) && (request.isSecure())) {
/* 100 */         httpResponse.setHeader("Strict-Transport-Security", this.hstsHeaderValue);
/*     */       }
/*     */       
/*     */ 
/* 104 */       if (this.antiClickJackingEnabled) {
/* 105 */         httpResponse.setHeader("X-Frame-Options", this.antiClickJackingHeaderValue);
/*     */       }
/*     */       
/*     */ 
/* 109 */       if (this.blockContentTypeSniffingEnabled) {
/* 110 */         httpResponse.setHeader("X-Content-Type-Options", "nosniff");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 115 */       if (this.xssProtectionEnabled) {
/* 116 */         httpResponse.setHeader("X-XSS-Protection", "1; mode=block");
/*     */       }
/*     */     }
/*     */     
/* 120 */     chain.doFilter(request, response); }
/*     */   
/*     */   private String hstsHeaderValue;
/*     */   private static final String ANTI_CLICK_JACKING_HEADER_NAME = "X-Frame-Options";
/*     */   private boolean antiClickJackingEnabled;
/*     */   private XFrameOption antiClickJackingOption;
/* 126 */   protected Log getLogger() { return log; }
/*     */   
/*     */   private URI antiClickJackingUri;
/*     */   private String antiClickJackingHeaderValue;
/*     */   private static final String BLOCK_CONTENT_TYPE_SNIFFING_HEADER_NAME = "X-Content-Type-Options";
/*     */   private static final String BLOCK_CONTENT_TYPE_SNIFFING_HEADER_VALUE = "nosniff";
/*     */   
/*     */   protected boolean isConfigProblemFatal() {
/* 134 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isHstsEnabled()
/*     */   {
/* 139 */     return this.hstsEnabled;
/*     */   }
/*     */   
/*     */   public void setHstsEnabled(boolean hstsEnabled)
/*     */   {
/* 144 */     this.hstsEnabled = hstsEnabled;
/*     */   }
/*     */   
/*     */   public int getHstsMaxAgeSeconds()
/*     */   {
/* 149 */     return this.hstsMaxAgeSeconds;
/*     */   }
/*     */   
/*     */   public void setHstsMaxAgeSeconds(int hstsMaxAgeSeconds)
/*     */   {
/* 154 */     if (hstsMaxAgeSeconds < 0) {
/* 155 */       this.hstsMaxAgeSeconds = 0;
/*     */     } else {
/* 157 */       this.hstsMaxAgeSeconds = hstsMaxAgeSeconds;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isHstsIncludeSubDomains()
/*     */   {
/* 163 */     return this.hstsIncludeSubDomains;
/*     */   }
/*     */   
/*     */   public void setHstsIncludeSubDomains(boolean hstsIncludeSubDomains)
/*     */   {
/* 168 */     this.hstsIncludeSubDomains = hstsIncludeSubDomains;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isAntiClickJackingEnabled()
/*     */   {
/* 174 */     return this.antiClickJackingEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setAntiClickJackingEnabled(boolean antiClickJackingEnabled)
/*     */   {
/* 180 */     this.antiClickJackingEnabled = antiClickJackingEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getAntiClickJackingOption()
/*     */   {
/* 186 */     return this.antiClickJackingOption.toString();
/*     */   }
/*     */   
/*     */   public void setAntiClickJackingOption(String antiClickJackingOption)
/*     */   {
/* 191 */     for (XFrameOption option : ) {
/* 192 */       if (option.getHeaderValue().equalsIgnoreCase(antiClickJackingOption)) {
/* 193 */         this.antiClickJackingOption = option;
/* 194 */         return;
/*     */       }
/*     */     }
/* 197 */     throw new IllegalArgumentException(sm.getString("httpHeaderSecurityFilter.clickjack.invalid", new Object[] { antiClickJackingOption }));
/*     */   }
/*     */   
/*     */   private boolean blockContentTypeSniffingEnabled;
/*     */   private static final String XSS_PROTECTION_HEADER_NAME = "X-XSS-Protection";
/*     */   private static final String XSS_PROTECTION_HEADER_VALUE = "1; mode=block";
/*     */   private boolean xssProtectionEnabled;
/* 204 */   public String getAntiClickJackingUri() { return this.antiClickJackingUri.toString(); }
/*     */   
/*     */ 
/*     */   public boolean isBlockContentTypeSniffingEnabled()
/*     */   {
/* 209 */     return this.blockContentTypeSniffingEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setBlockContentTypeSniffingEnabled(boolean blockContentTypeSniffingEnabled)
/*     */   {
/* 215 */     this.blockContentTypeSniffingEnabled = blockContentTypeSniffingEnabled;
/*     */   }
/*     */   
/*     */   public void setAntiClickJackingUri(String antiClickJackingUri)
/*     */   {
/*     */     try
/*     */     {
/* 222 */       uri = new URI(antiClickJackingUri);
/*     */     } catch (URISyntaxException e) { URI uri;
/* 224 */       throw new IllegalArgumentException(e); }
/*     */     URI uri;
/* 226 */     this.antiClickJackingUri = uri;
/*     */   }
/*     */   
/*     */   public boolean isXssProtectionEnabled() {
/* 230 */     return this.xssProtectionEnabled;
/*     */   }
/*     */   
/*     */   public void setXssProtectionEnabled(boolean xssProtectionEnabled) {
/* 234 */     this.xssProtectionEnabled = xssProtectionEnabled;
/*     */   }
/*     */   
/*     */   private static enum XFrameOption {
/* 238 */     DENY("DENY"), 
/* 239 */     SAME_ORIGIN("SAMEORIGIN"), 
/* 240 */     ALLOW_FROM("ALLOW-FROM");
/*     */     
/*     */     private final String headerValue;
/*     */     
/*     */     private XFrameOption(String headerValue)
/*     */     {
/* 246 */       this.headerValue = headerValue;
/*     */     }
/*     */     
/*     */     public String getHeaderValue() {
/* 250 */       return this.headerValue;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\filters\HttpHeaderSecurityFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */