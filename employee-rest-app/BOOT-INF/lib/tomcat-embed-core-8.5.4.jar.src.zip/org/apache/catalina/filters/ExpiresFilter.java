/*      */ package org.apache.catalina.filters;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.regex.Pattern;
/*      */ import javax.servlet.FilterChain;
/*      */ import javax.servlet.FilterConfig;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletOutputStream;
/*      */ import javax.servlet.ServletRequest;
/*      */ import javax.servlet.ServletResponse;
/*      */ import javax.servlet.WriteListener;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import javax.servlet.http.HttpServletResponseWrapper;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ExpiresFilter
/*      */   extends FilterBase
/*      */ {
/*      */   protected static class Duration
/*      */   {
/*      */     protected final int amount;
/*      */     protected final ExpiresFilter.DurationUnit unit;
/*      */     
/*      */     public Duration(int amount, ExpiresFilter.DurationUnit unit)
/*      */     {
/*  442 */       this.amount = amount;
/*  443 */       this.unit = unit;
/*      */     }
/*      */     
/*      */     public int getAmount() {
/*  447 */       return this.amount;
/*      */     }
/*      */     
/*      */     public ExpiresFilter.DurationUnit getUnit() {
/*  451 */       return this.unit;
/*      */     }
/*      */     
/*      */     public String toString()
/*      */     {
/*  456 */       return this.amount + " " + this.unit;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static enum DurationUnit
/*      */   {
/*  464 */     DAY(6),  HOUR(10),  MINUTE(12),  MONTH(2), 
/*  465 */     SECOND(13),  WEEK(3), 
/*  466 */     YEAR(1);
/*      */     
/*      */     private final int calendardField;
/*      */     
/*  470 */     private DurationUnit(int calendardField) { this.calendardField = calendardField; }
/*      */     
/*      */     public int getCalendardField()
/*      */     {
/*  474 */       return this.calendardField;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static class ExpiresConfiguration
/*      */   {
/*      */     private final List<ExpiresFilter.Duration> durations;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private final ExpiresFilter.StartingPoint startingPoint;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public ExpiresConfiguration(ExpiresFilter.StartingPoint startingPoint, List<ExpiresFilter.Duration> durations)
/*      */     {
/*  501 */       this.startingPoint = startingPoint;
/*  502 */       this.durations = durations;
/*      */     }
/*      */     
/*      */     public List<ExpiresFilter.Duration> getDurations() {
/*  506 */       return this.durations;
/*      */     }
/*      */     
/*      */     public ExpiresFilter.StartingPoint getStartingPoint() {
/*  510 */       return this.startingPoint;
/*      */     }
/*      */     
/*      */     public String toString()
/*      */     {
/*  515 */       return "ExpiresConfiguration[startingPoint=" + this.startingPoint + ", duration=" + this.durations + "]";
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static enum StartingPoint
/*      */   {
/*  527 */     ACCESS_TIME,  LAST_MODIFICATION_TIME;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private StartingPoint() {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public class XHttpServletResponse
/*      */     extends HttpServletResponseWrapper
/*      */   {
/*      */     private String cacheControlHeader;
/*      */     
/*      */ 
/*      */ 
/*      */     private long lastModifiedHeader;
/*      */     
/*      */ 
/*      */ 
/*      */     private boolean lastModifiedHeaderSet;
/*      */     
/*      */ 
/*      */ 
/*      */     private PrintWriter printWriter;
/*      */     
/*      */ 
/*      */ 
/*      */     private final HttpServletRequest request;
/*      */     
/*      */ 
/*      */ 
/*      */     private ServletOutputStream servletOutputStream;
/*      */     
/*      */ 
/*      */ 
/*      */     private boolean writeResponseBodyStarted;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public XHttpServletResponse(HttpServletRequest request, HttpServletResponse response)
/*      */     {
/*  573 */       super();
/*  574 */       this.request = request;
/*      */     }
/*      */     
/*      */     public void addDateHeader(String name, long date)
/*      */     {
/*  579 */       super.addDateHeader(name, date);
/*  580 */       if (!this.lastModifiedHeaderSet) {
/*  581 */         this.lastModifiedHeader = date;
/*  582 */         this.lastModifiedHeaderSet = true;
/*      */       }
/*      */     }
/*      */     
/*      */     public void addHeader(String name, String value)
/*      */     {
/*  588 */       super.addHeader(name, value);
/*  589 */       if (("Cache-Control".equalsIgnoreCase(name)) && (this.cacheControlHeader == null))
/*      */       {
/*  591 */         this.cacheControlHeader = value;
/*      */       }
/*      */     }
/*      */     
/*      */     public String getCacheControlHeader() {
/*  596 */       return this.cacheControlHeader;
/*      */     }
/*      */     
/*      */     public long getLastModifiedHeader() {
/*  600 */       return this.lastModifiedHeader;
/*      */     }
/*      */     
/*      */     public ServletOutputStream getOutputStream() throws IOException
/*      */     {
/*  605 */       if (this.servletOutputStream == null) {
/*  606 */         this.servletOutputStream = new ExpiresFilter.XServletOutputStream(ExpiresFilter.this, super.getOutputStream(), this.request, this);
/*      */       }
/*      */       
/*  609 */       return this.servletOutputStream;
/*      */     }
/*      */     
/*      */     public PrintWriter getWriter() throws IOException
/*      */     {
/*  614 */       if (this.printWriter == null) {
/*  615 */         this.printWriter = new ExpiresFilter.XPrintWriter(ExpiresFilter.this, super.getWriter(), this.request, this);
/*      */       }
/*  617 */       return this.printWriter;
/*      */     }
/*      */     
/*      */     public boolean isLastModifiedHeaderSet() {
/*  621 */       return this.lastModifiedHeaderSet;
/*      */     }
/*      */     
/*      */     public boolean isWriteResponseBodyStarted() {
/*  625 */       return this.writeResponseBodyStarted;
/*      */     }
/*      */     
/*      */     public void reset()
/*      */     {
/*  630 */       super.reset();
/*  631 */       this.lastModifiedHeader = 0L;
/*  632 */       this.lastModifiedHeaderSet = false;
/*  633 */       this.cacheControlHeader = null;
/*      */     }
/*      */     
/*      */     public void setDateHeader(String name, long date)
/*      */     {
/*  638 */       super.setDateHeader(name, date);
/*  639 */       if ("Last-Modified".equalsIgnoreCase(name)) {
/*  640 */         this.lastModifiedHeader = date;
/*  641 */         this.lastModifiedHeaderSet = true;
/*      */       }
/*      */     }
/*      */     
/*      */     public void setHeader(String name, String value)
/*      */     {
/*  647 */       super.setHeader(name, value);
/*  648 */       if ("Cache-Control".equalsIgnoreCase(name)) {
/*  649 */         this.cacheControlHeader = value;
/*      */       }
/*      */     }
/*      */     
/*      */     public void setWriteResponseBodyStarted(boolean writeResponseBodyStarted) {
/*  654 */       this.writeResponseBodyStarted = writeResponseBodyStarted;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public class XPrintWriter
/*      */     extends PrintWriter
/*      */   {
/*      */     private final PrintWriter out;
/*      */     
/*      */     private final HttpServletRequest request;
/*      */     
/*      */     private final ExpiresFilter.XHttpServletResponse response;
/*      */     
/*      */ 
/*      */     public XPrintWriter(PrintWriter out, HttpServletRequest request, ExpiresFilter.XHttpServletResponse response)
/*      */     {
/*  671 */       super();
/*  672 */       this.out = out;
/*  673 */       this.request = request;
/*  674 */       this.response = response;
/*      */     }
/*      */     
/*      */     public PrintWriter append(char c)
/*      */     {
/*  679 */       fireBeforeWriteResponseBodyEvent();
/*  680 */       return this.out.append(c);
/*      */     }
/*      */     
/*      */     public PrintWriter append(CharSequence csq)
/*      */     {
/*  685 */       fireBeforeWriteResponseBodyEvent();
/*  686 */       return this.out.append(csq);
/*      */     }
/*      */     
/*      */     public PrintWriter append(CharSequence csq, int start, int end)
/*      */     {
/*  691 */       fireBeforeWriteResponseBodyEvent();
/*  692 */       return this.out.append(csq, start, end);
/*      */     }
/*      */     
/*      */     public void close()
/*      */     {
/*  697 */       fireBeforeWriteResponseBodyEvent();
/*  698 */       this.out.close();
/*      */     }
/*      */     
/*      */     private void fireBeforeWriteResponseBodyEvent() {
/*  702 */       if (!this.response.isWriteResponseBodyStarted()) {
/*  703 */         this.response.setWriteResponseBodyStarted(true);
/*  704 */         ExpiresFilter.this.onBeforeWriteResponseBody(this.request, this.response);
/*      */       }
/*      */     }
/*      */     
/*      */     public void flush()
/*      */     {
/*  710 */       fireBeforeWriteResponseBodyEvent();
/*  711 */       this.out.flush();
/*      */     }
/*      */     
/*      */     public void print(boolean b)
/*      */     {
/*  716 */       fireBeforeWriteResponseBodyEvent();
/*  717 */       this.out.print(b);
/*      */     }
/*      */     
/*      */     public void print(char c)
/*      */     {
/*  722 */       fireBeforeWriteResponseBodyEvent();
/*  723 */       this.out.print(c);
/*      */     }
/*      */     
/*      */     public void print(char[] s)
/*      */     {
/*  728 */       fireBeforeWriteResponseBodyEvent();
/*  729 */       this.out.print(s);
/*      */     }
/*      */     
/*      */     public void print(double d)
/*      */     {
/*  734 */       fireBeforeWriteResponseBodyEvent();
/*  735 */       this.out.print(d);
/*      */     }
/*      */     
/*      */     public void print(float f)
/*      */     {
/*  740 */       fireBeforeWriteResponseBodyEvent();
/*  741 */       this.out.print(f);
/*      */     }
/*      */     
/*      */     public void print(int i)
/*      */     {
/*  746 */       fireBeforeWriteResponseBodyEvent();
/*  747 */       this.out.print(i);
/*      */     }
/*      */     
/*      */     public void print(long l)
/*      */     {
/*  752 */       fireBeforeWriteResponseBodyEvent();
/*  753 */       this.out.print(l);
/*      */     }
/*      */     
/*      */     public void print(Object obj)
/*      */     {
/*  758 */       fireBeforeWriteResponseBodyEvent();
/*  759 */       this.out.print(obj);
/*      */     }
/*      */     
/*      */     public void print(String s)
/*      */     {
/*  764 */       fireBeforeWriteResponseBodyEvent();
/*  765 */       this.out.print(s);
/*      */     }
/*      */     
/*      */     public PrintWriter printf(Locale l, String format, Object... args)
/*      */     {
/*  770 */       fireBeforeWriteResponseBodyEvent();
/*  771 */       return this.out.printf(l, format, args);
/*      */     }
/*      */     
/*      */     public PrintWriter printf(String format, Object... args)
/*      */     {
/*  776 */       fireBeforeWriteResponseBodyEvent();
/*  777 */       return this.out.printf(format, args);
/*      */     }
/*      */     
/*      */     public void println()
/*      */     {
/*  782 */       fireBeforeWriteResponseBodyEvent();
/*  783 */       this.out.println();
/*      */     }
/*      */     
/*      */     public void println(boolean x)
/*      */     {
/*  788 */       fireBeforeWriteResponseBodyEvent();
/*  789 */       this.out.println(x);
/*      */     }
/*      */     
/*      */     public void println(char x)
/*      */     {
/*  794 */       fireBeforeWriteResponseBodyEvent();
/*  795 */       this.out.println(x);
/*      */     }
/*      */     
/*      */     public void println(char[] x)
/*      */     {
/*  800 */       fireBeforeWriteResponseBodyEvent();
/*  801 */       this.out.println(x);
/*      */     }
/*      */     
/*      */     public void println(double x)
/*      */     {
/*  806 */       fireBeforeWriteResponseBodyEvent();
/*  807 */       this.out.println(x);
/*      */     }
/*      */     
/*      */     public void println(float x)
/*      */     {
/*  812 */       fireBeforeWriteResponseBodyEvent();
/*  813 */       this.out.println(x);
/*      */     }
/*      */     
/*      */     public void println(int x)
/*      */     {
/*  818 */       fireBeforeWriteResponseBodyEvent();
/*  819 */       this.out.println(x);
/*      */     }
/*      */     
/*      */     public void println(long x)
/*      */     {
/*  824 */       fireBeforeWriteResponseBodyEvent();
/*  825 */       this.out.println(x);
/*      */     }
/*      */     
/*      */     public void println(Object x)
/*      */     {
/*  830 */       fireBeforeWriteResponseBodyEvent();
/*  831 */       this.out.println(x);
/*      */     }
/*      */     
/*      */     public void println(String x)
/*      */     {
/*  836 */       fireBeforeWriteResponseBodyEvent();
/*  837 */       this.out.println(x);
/*      */     }
/*      */     
/*      */     public void write(char[] buf)
/*      */     {
/*  842 */       fireBeforeWriteResponseBodyEvent();
/*  843 */       this.out.write(buf);
/*      */     }
/*      */     
/*      */     public void write(char[] buf, int off, int len)
/*      */     {
/*  848 */       fireBeforeWriteResponseBodyEvent();
/*  849 */       this.out.write(buf, off, len);
/*      */     }
/*      */     
/*      */     public void write(int c)
/*      */     {
/*  854 */       fireBeforeWriteResponseBodyEvent();
/*  855 */       this.out.write(c);
/*      */     }
/*      */     
/*      */     public void write(String s)
/*      */     {
/*  860 */       fireBeforeWriteResponseBodyEvent();
/*  861 */       this.out.write(s);
/*      */     }
/*      */     
/*      */     public void write(String s, int off, int len)
/*      */     {
/*  866 */       fireBeforeWriteResponseBodyEvent();
/*  867 */       this.out.write(s, off, len);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public class XServletOutputStream
/*      */     extends ServletOutputStream
/*      */   {
/*      */     private final HttpServletRequest request;
/*      */     
/*      */ 
/*      */     private final ExpiresFilter.XHttpServletResponse response;
/*      */     
/*      */ 
/*      */     private final ServletOutputStream servletOutputStream;
/*      */     
/*      */ 
/*      */     public XServletOutputStream(ServletOutputStream servletOutputStream, HttpServletRequest request, ExpiresFilter.XHttpServletResponse response)
/*      */     {
/*  887 */       this.servletOutputStream = servletOutputStream;
/*  888 */       this.response = response;
/*  889 */       this.request = request;
/*      */     }
/*      */     
/*      */     public void close() throws IOException
/*      */     {
/*  894 */       fireOnBeforeWriteResponseBodyEvent();
/*  895 */       this.servletOutputStream.close();
/*      */     }
/*      */     
/*      */     private void fireOnBeforeWriteResponseBodyEvent() {
/*  899 */       if (!this.response.isWriteResponseBodyStarted()) {
/*  900 */         this.response.setWriteResponseBodyStarted(true);
/*  901 */         ExpiresFilter.this.onBeforeWriteResponseBody(this.request, this.response);
/*      */       }
/*      */     }
/*      */     
/*      */     public void flush() throws IOException
/*      */     {
/*  907 */       fireOnBeforeWriteResponseBodyEvent();
/*  908 */       this.servletOutputStream.flush();
/*      */     }
/*      */     
/*      */     public void print(boolean b) throws IOException
/*      */     {
/*  913 */       fireOnBeforeWriteResponseBodyEvent();
/*  914 */       this.servletOutputStream.print(b);
/*      */     }
/*      */     
/*      */     public void print(char c) throws IOException
/*      */     {
/*  919 */       fireOnBeforeWriteResponseBodyEvent();
/*  920 */       this.servletOutputStream.print(c);
/*      */     }
/*      */     
/*      */     public void print(double d) throws IOException
/*      */     {
/*  925 */       fireOnBeforeWriteResponseBodyEvent();
/*  926 */       this.servletOutputStream.print(d);
/*      */     }
/*      */     
/*      */     public void print(float f) throws IOException
/*      */     {
/*  931 */       fireOnBeforeWriteResponseBodyEvent();
/*  932 */       this.servletOutputStream.print(f);
/*      */     }
/*      */     
/*      */     public void print(int i) throws IOException
/*      */     {
/*  937 */       fireOnBeforeWriteResponseBodyEvent();
/*  938 */       this.servletOutputStream.print(i);
/*      */     }
/*      */     
/*      */     public void print(long l) throws IOException
/*      */     {
/*  943 */       fireOnBeforeWriteResponseBodyEvent();
/*  944 */       this.servletOutputStream.print(l);
/*      */     }
/*      */     
/*      */     public void print(String s) throws IOException
/*      */     {
/*  949 */       fireOnBeforeWriteResponseBodyEvent();
/*  950 */       this.servletOutputStream.print(s);
/*      */     }
/*      */     
/*      */     public void println() throws IOException
/*      */     {
/*  955 */       fireOnBeforeWriteResponseBodyEvent();
/*  956 */       this.servletOutputStream.println();
/*      */     }
/*      */     
/*      */     public void println(boolean b) throws IOException
/*      */     {
/*  961 */       fireOnBeforeWriteResponseBodyEvent();
/*  962 */       this.servletOutputStream.println(b);
/*      */     }
/*      */     
/*      */     public void println(char c) throws IOException
/*      */     {
/*  967 */       fireOnBeforeWriteResponseBodyEvent();
/*  968 */       this.servletOutputStream.println(c);
/*      */     }
/*      */     
/*      */     public void println(double d) throws IOException
/*      */     {
/*  973 */       fireOnBeforeWriteResponseBodyEvent();
/*  974 */       this.servletOutputStream.println(d);
/*      */     }
/*      */     
/*      */     public void println(float f) throws IOException
/*      */     {
/*  979 */       fireOnBeforeWriteResponseBodyEvent();
/*  980 */       this.servletOutputStream.println(f);
/*      */     }
/*      */     
/*      */     public void println(int i) throws IOException
/*      */     {
/*  985 */       fireOnBeforeWriteResponseBodyEvent();
/*  986 */       this.servletOutputStream.println(i);
/*      */     }
/*      */     
/*      */     public void println(long l) throws IOException
/*      */     {
/*  991 */       fireOnBeforeWriteResponseBodyEvent();
/*  992 */       this.servletOutputStream.println(l);
/*      */     }
/*      */     
/*      */     public void println(String s) throws IOException
/*      */     {
/*  997 */       fireOnBeforeWriteResponseBodyEvent();
/*  998 */       this.servletOutputStream.println(s);
/*      */     }
/*      */     
/*      */     public void write(byte[] b) throws IOException
/*      */     {
/* 1003 */       fireOnBeforeWriteResponseBodyEvent();
/* 1004 */       this.servletOutputStream.write(b);
/*      */     }
/*      */     
/*      */     public void write(byte[] b, int off, int len) throws IOException
/*      */     {
/* 1009 */       fireOnBeforeWriteResponseBodyEvent();
/* 1010 */       this.servletOutputStream.write(b, off, len);
/*      */     }
/*      */     
/*      */     public void write(int b) throws IOException
/*      */     {
/* 1015 */       fireOnBeforeWriteResponseBodyEvent();
/* 1016 */       this.servletOutputStream.write(b);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean isReady()
/*      */     {
/* 1025 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void setWriteListener(WriteListener listener) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1045 */   private static final Pattern commaSeparatedValuesPattern = Pattern.compile("\\s*,\\s*");
/*      */   
/*      */   private static final String HEADER_CACHE_CONTROL = "Cache-Control";
/*      */   
/*      */   private static final String HEADER_EXPIRES = "Expires";
/*      */   
/*      */   private static final String HEADER_LAST_MODIFIED = "Last-Modified";
/*      */   
/* 1053 */   private static final Log log = LogFactory.getLog(ExpiresFilter.class);
/*      */   
/*      */ 
/*      */   private static final String PARAMETER_EXPIRES_BY_TYPE = "ExpiresByType";
/*      */   
/*      */ 
/*      */   private static final String PARAMETER_EXPIRES_DEFAULT = "ExpiresDefault";
/*      */   
/*      */ 
/*      */   private static final String PARAMETER_EXPIRES_EXCLUDED_RESPONSE_STATUS_CODES = "ExpiresExcludedResponseStatusCodes";
/*      */   
/*      */ 
/*      */   private ExpiresConfiguration defaultExpiresConfiguration;
/*      */   
/*      */ 
/*      */   protected static int[] commaDelimitedListToIntArray(String commaDelimitedInts)
/*      */   {
/* 1070 */     String[] intsAsStrings = commaDelimitedListToStringArray(commaDelimitedInts);
/* 1071 */     int[] ints = new int[intsAsStrings.length];
/* 1072 */     for (int i = 0; i < intsAsStrings.length; i++) {
/* 1073 */       String intAsString = intsAsStrings[i];
/*      */       try {
/* 1075 */         ints[i] = Integer.parseInt(intAsString);
/*      */       } catch (NumberFormatException e) {
/* 1077 */         throw new RuntimeException("Exception parsing number '" + i + "' (zero based) of comma delimited list '" + commaDelimitedInts + "'");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1082 */     return ints;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static String[] commaDelimitedListToStringArray(String commaDelimitedStrings)
/*      */   {
/* 1093 */     return (commaDelimitedStrings == null) || (commaDelimitedStrings.length() == 0) ? new String[0] : commaSeparatedValuesPattern.split(commaDelimitedStrings);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static boolean contains(String str, String searchStr)
/*      */   {
/* 1104 */     if ((str == null) || (searchStr == null)) {
/* 1105 */       return false;
/*      */     }
/* 1107 */     return str.indexOf(searchStr) >= 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static String intsToCommaDelimitedString(int[] ints)
/*      */   {
/* 1116 */     if (ints == null) {
/* 1117 */       return "";
/*      */     }
/*      */     
/* 1120 */     StringBuilder result = new StringBuilder();
/*      */     
/* 1122 */     for (int i = 0; i < ints.length; i++) {
/* 1123 */       result.append(ints[i]);
/* 1124 */       if (i < ints.length - 1) {
/* 1125 */         result.append(", ");
/*      */       }
/*      */     }
/* 1128 */     return result.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static boolean isEmpty(String str)
/*      */   {
/* 1137 */     return (str == null) || (str.length() == 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static boolean isNotEmpty(String str)
/*      */   {
/* 1146 */     return !isEmpty(str);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static boolean startsWithIgnoreCase(String string, String prefix)
/*      */   {
/* 1159 */     if ((string == null) || (prefix == null)) {
/* 1160 */       return (string == null) && (prefix == null);
/*      */     }
/* 1162 */     if (prefix.length() > string.length()) {
/* 1163 */       return false;
/*      */     }
/*      */     
/* 1166 */     return string.regionMatches(true, 0, prefix, 0, prefix.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static String substringBefore(String str, String separator)
/*      */   {
/* 1181 */     if ((str == null) || (str.isEmpty()) || (separator == null)) {
/* 1182 */       return null;
/*      */     }
/*      */     
/* 1185 */     if (separator.isEmpty()) {
/* 1186 */       return "";
/*      */     }
/*      */     
/* 1189 */     int separatorIndex = str.indexOf(separator);
/* 1190 */     if (separatorIndex == -1) {
/* 1191 */       return str;
/*      */     }
/* 1193 */     return str.substring(0, separatorIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1205 */   private int[] excludedResponseStatusCodes = { 304 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1210 */   private Map<String, ExpiresConfiguration> expiresConfigurationByContentType = new LinkedHashMap();
/*      */   
/*      */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*      */     throws IOException, ServletException
/*      */   {
/* 1215 */     if (((request instanceof HttpServletRequest)) && ((response instanceof HttpServletResponse)))
/*      */     {
/* 1217 */       HttpServletRequest httpRequest = (HttpServletRequest)request;
/* 1218 */       HttpServletResponse httpResponse = (HttpServletResponse)response;
/*      */       
/* 1220 */       if (response.isCommitted()) {
/* 1221 */         if (log.isDebugEnabled()) {
/* 1222 */           log.debug(sm.getString("expiresFilter.responseAlreadyCommited", new Object[] { httpRequest.getRequestURL() }));
/*      */         }
/*      */         
/*      */ 
/* 1226 */         chain.doFilter(request, response);
/*      */       } else {
/* 1228 */         XHttpServletResponse xResponse = new XHttpServletResponse(httpRequest, httpResponse);
/*      */         
/* 1230 */         chain.doFilter(request, xResponse);
/* 1231 */         if (!xResponse.isWriteResponseBodyStarted())
/*      */         {
/*      */ 
/* 1234 */           onBeforeWriteResponseBody(httpRequest, xResponse);
/*      */         }
/*      */       }
/*      */     } else {
/* 1238 */       chain.doFilter(request, response);
/*      */     }
/*      */   }
/*      */   
/*      */   public ExpiresConfiguration getDefaultExpiresConfiguration() {
/* 1243 */     return this.defaultExpiresConfiguration;
/*      */   }
/*      */   
/*      */   public String getExcludedResponseStatusCodes() {
/* 1247 */     return intsToCommaDelimitedString(this.excludedResponseStatusCodes);
/*      */   }
/*      */   
/*      */   public int[] getExcludedResponseStatusCodesAsInts() {
/* 1251 */     return this.excludedResponseStatusCodes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Date getExpirationDate(XHttpServletResponse response)
/*      */   {
/* 1269 */     String contentType = response.getContentType();
/*      */     
/*      */ 
/*      */ 
/* 1273 */     ExpiresConfiguration configuration = (ExpiresConfiguration)this.expiresConfigurationByContentType.get(contentType);
/* 1274 */     if (configuration != null) {
/* 1275 */       Date result = getExpirationDate(configuration, response);
/* 1276 */       if (log.isDebugEnabled()) {
/* 1277 */         log.debug(sm.getString("expiresFilter.useMatchingConfiguration", new Object[] { configuration, contentType, contentType, result }));
/*      */       }
/*      */       
/*      */ 
/* 1281 */       return result;
/*      */     }
/*      */     
/* 1284 */     if (contains(contentType, ";"))
/*      */     {
/* 1286 */       String contentTypeWithoutCharset = substringBefore(contentType, ";").trim();
/* 1287 */       configuration = (ExpiresConfiguration)this.expiresConfigurationByContentType.get(contentTypeWithoutCharset);
/*      */       
/* 1289 */       if (configuration != null) {
/* 1290 */         Date result = getExpirationDate(configuration, response);
/* 1291 */         if (log.isDebugEnabled()) {
/* 1292 */           log.debug(sm.getString("expiresFilter.useMatchingConfiguration", new Object[] { configuration, contentTypeWithoutCharset, contentType, result }));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1297 */         return result;
/*      */       }
/*      */     }
/*      */     
/* 1301 */     if (contains(contentType, "/"))
/*      */     {
/* 1303 */       String majorType = substringBefore(contentType, "/");
/* 1304 */       configuration = (ExpiresConfiguration)this.expiresConfigurationByContentType.get(majorType);
/* 1305 */       if (configuration != null) {
/* 1306 */         Date result = getExpirationDate(configuration, response);
/* 1307 */         if (log.isDebugEnabled()) {
/* 1308 */           log.debug(sm.getString("expiresFilter.useMatchingConfiguration", new Object[] { configuration, majorType, contentType, result }));
/*      */         }
/*      */         
/*      */ 
/* 1312 */         return result;
/*      */       }
/*      */     }
/*      */     
/* 1316 */     if (this.defaultExpiresConfiguration != null) {
/* 1317 */       Date result = getExpirationDate(this.defaultExpiresConfiguration, response);
/*      */       
/* 1319 */       if (log.isDebugEnabled()) {
/* 1320 */         log.debug(sm.getString("expiresFilter.useDefaultConfiguration", new Object[] { this.defaultExpiresConfiguration, contentType, result }));
/*      */       }
/*      */       
/* 1323 */       return result;
/*      */     }
/*      */     
/* 1326 */     if (log.isDebugEnabled()) {
/* 1327 */       log.debug(sm.getString("expiresFilter.noExpirationConfiguredForContentType", new Object[] { contentType }));
/*      */     }
/*      */     
/*      */ 
/* 1331 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Date getExpirationDate(ExpiresConfiguration configuration, XHttpServletResponse response)
/*      */   {
/*      */     Calendar calendar;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     Calendar calendar;
/*      */     
/*      */ 
/*      */ 
/* 1349 */     switch (configuration.getStartingPoint()) {
/*      */     case ACCESS_TIME: 
/* 1351 */       calendar = Calendar.getInstance();
/* 1352 */       break;
/*      */     case LAST_MODIFICATION_TIME: 
/* 1354 */       if (response.isLastModifiedHeaderSet()) {
/*      */         Calendar calendar;
/* 1356 */         try { long lastModified = response.getLastModifiedHeader();
/* 1357 */           Calendar calendar = Calendar.getInstance();
/* 1358 */           calendar.setTimeInMillis(lastModified);
/*      */         }
/*      */         catch (NumberFormatException e) {
/* 1361 */           calendar = Calendar.getInstance();
/*      */         }
/*      */       }
/*      */       else {
/* 1365 */         calendar = Calendar.getInstance();
/*      */       }
/* 1367 */       break;
/*      */     default: 
/* 1369 */       throw new IllegalStateException(sm.getString("expiresFilter.unsupportedStartingPoint", new Object[] { configuration.getStartingPoint() }));
/*      */     }
/*      */     
/*      */     Calendar calendar;
/* 1373 */     for (Duration duration : configuration.getDurations()) {
/* 1374 */       calendar.add(duration.getUnit().getCalendardField(), duration.getAmount());
/*      */     }
/*      */     
/*      */ 
/* 1378 */     return calendar.getTime();
/*      */   }
/*      */   
/*      */   public Map<String, ExpiresConfiguration> getExpiresConfigurationByContentType() {
/* 1382 */     return this.expiresConfigurationByContentType;
/*      */   }
/*      */   
/*      */   protected Log getLogger()
/*      */   {
/* 1387 */     return log;
/*      */   }
/*      */   
/*      */   public void init(FilterConfig filterConfig) throws ServletException
/*      */   {
/* 1392 */     for (Enumeration<String> names = filterConfig.getInitParameterNames(); names.hasMoreElements();) {
/* 1393 */       String name = (String)names.nextElement();
/* 1394 */       String value = filterConfig.getInitParameter(name);
/*      */       try
/*      */       {
/* 1397 */         if (name.startsWith("ExpiresByType")) {
/* 1398 */           String contentType = name.substring("ExpiresByType".length()).trim();
/*      */           
/* 1400 */           ExpiresConfiguration expiresConfiguration = parseExpiresConfiguration(value);
/* 1401 */           this.expiresConfigurationByContentType.put(contentType, expiresConfiguration);
/*      */         }
/* 1403 */         else if (name.equalsIgnoreCase("ExpiresDefault")) {
/* 1404 */           ExpiresConfiguration expiresConfiguration = parseExpiresConfiguration(value);
/* 1405 */           this.defaultExpiresConfiguration = expiresConfiguration;
/* 1406 */         } else if (name.equalsIgnoreCase("ExpiresExcludedResponseStatusCodes")) {
/* 1407 */           this.excludedResponseStatusCodes = commaDelimitedListToIntArray(value);
/*      */         } else {
/* 1409 */           log.warn(sm.getString("expiresFilter.unknownParameterIgnored", new Object[] { name, value }));
/*      */         }
/*      */       }
/*      */       catch (RuntimeException e)
/*      */       {
/* 1414 */         throw new ServletException(sm.getString("expiresFilter.exceptionProcessingParameter", new Object[] { name, value }), e);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1420 */     log.debug(sm.getString("expiresFilter.filterInitialized", new Object[] { toString() }));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isEligibleToExpirationHeaderGeneration(HttpServletRequest request, XHttpServletResponse response)
/*      */   {
/* 1434 */     boolean expirationHeaderHasBeenSet = (response.containsHeader("Expires")) || (contains(response.getCacheControlHeader(), "max-age"));
/*      */     
/* 1436 */     if (expirationHeaderHasBeenSet) {
/* 1437 */       if (log.isDebugEnabled()) {
/* 1438 */         log.debug(sm.getString("expiresFilter.expirationHeaderAlreadyDefined", new Object[] { request.getRequestURI(), Integer.valueOf(response.getStatus()), response.getContentType() }));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1444 */       return false;
/*      */     }
/*      */     
/* 1447 */     for (int skippedStatusCode : this.excludedResponseStatusCodes) {
/* 1448 */       if (response.getStatus() == skippedStatusCode) {
/* 1449 */         if (log.isDebugEnabled()) {
/* 1450 */           log.debug(sm.getString("expiresFilter.skippedStatusCode", new Object[] { request.getRequestURI(), Integer.valueOf(response.getStatus()), response.getContentType() }));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1455 */         return false;
/*      */       }
/*      */     }
/*      */     
/* 1459 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void onBeforeWriteResponseBody(HttpServletRequest request, XHttpServletResponse response)
/*      */   {
/* 1485 */     if (!isEligibleToExpirationHeaderGeneration(request, response)) {
/* 1486 */       return;
/*      */     }
/*      */     
/* 1489 */     Date expirationDate = getExpirationDate(response);
/* 1490 */     if (expirationDate == null) {
/* 1491 */       if (log.isDebugEnabled()) {
/* 1492 */         log.debug(sm.getString("expiresFilter.noExpirationConfigured", new Object[] { request.getRequestURI(), Integer.valueOf(response.getStatus()), response.getContentType() }));
/*      */       }
/*      */       
/*      */     }
/*      */     else
/*      */     {
/* 1498 */       if (log.isDebugEnabled()) {
/* 1499 */         log.debug(sm.getString("expiresFilter.setExpirationDate", new Object[] { request.getRequestURI(), Integer.valueOf(response.getStatus()), response.getContentType(), expirationDate }));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1505 */       String maxAgeDirective = "max-age=" + (expirationDate.getTime() - System.currentTimeMillis()) / 1000L;
/*      */       
/*      */ 
/* 1508 */       String cacheControlHeader = response.getCacheControlHeader();
/* 1509 */       String newCacheControlHeader = cacheControlHeader + ", " + maxAgeDirective;
/*      */       
/* 1511 */       response.setHeader("Cache-Control", newCacheControlHeader);
/* 1512 */       response.setDateHeader("Expires", expirationDate.getTime());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ExpiresConfiguration parseExpiresConfiguration(String inputLine)
/*      */   {
/* 1526 */     String line = inputLine.trim();
/*      */     
/* 1528 */     StringTokenizer tokenizer = new StringTokenizer(line, " ");
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1533 */       currentToken = tokenizer.nextToken();
/*      */     } catch (NoSuchElementException e) { String currentToken;
/* 1535 */       throw new IllegalStateException(sm.getString("expiresFilter.startingPointNotFound", new Object[] { line }));
/*      */     }
/*      */     
/*      */     String currentToken;
/*      */     StartingPoint startingPoint;
/* 1540 */     if (("access".equalsIgnoreCase(currentToken)) || ("now".equalsIgnoreCase(currentToken)))
/*      */     {
/* 1542 */       startingPoint = StartingPoint.ACCESS_TIME; } else { StartingPoint startingPoint;
/* 1543 */       if ("modification".equalsIgnoreCase(currentToken)) {
/* 1544 */         startingPoint = StartingPoint.LAST_MODIFICATION_TIME;
/* 1545 */       } else if ((!tokenizer.hasMoreTokens()) && (startsWithIgnoreCase(currentToken, "a")))
/*      */       {
/* 1547 */         StartingPoint startingPoint = StartingPoint.ACCESS_TIME;
/*      */         
/* 1549 */         tokenizer = new StringTokenizer(currentToken.substring(1) + " seconds", " ");
/*      */       }
/* 1551 */       else if ((!tokenizer.hasMoreTokens()) && (startsWithIgnoreCase(currentToken, "m")))
/*      */       {
/* 1553 */         StartingPoint startingPoint = StartingPoint.LAST_MODIFICATION_TIME;
/*      */         
/* 1555 */         tokenizer = new StringTokenizer(currentToken.substring(1) + " seconds", " ");
/*      */       }
/*      */       else {
/* 1558 */         throw new IllegalStateException(sm.getString("expiresFilter.startingPointInvalid", new Object[] { currentToken, line }));
/*      */       }
/*      */     }
/*      */     StartingPoint startingPoint;
/*      */     try {
/* 1563 */       currentToken = tokenizer.nextToken();
/*      */     } catch (NoSuchElementException e) {
/* 1565 */       throw new IllegalStateException(sm.getString("expiresFilter.noDurationFound", new Object[] { line }));
/*      */     }
/*      */     
/*      */ 
/* 1569 */     if ("plus".equalsIgnoreCase(currentToken)) {
/*      */       try
/*      */       {
/* 1572 */         currentToken = tokenizer.nextToken();
/*      */       } catch (NoSuchElementException e) {
/* 1574 */         throw new IllegalStateException(sm.getString("expiresFilter.noDurationFound", new Object[] { line }));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1579 */     List<Duration> durations = new ArrayList();
/*      */     
/* 1581 */     while (currentToken != null)
/*      */     {
/*      */       try {
/* 1584 */         amount = Integer.parseInt(currentToken);
/*      */       } catch (NumberFormatException e) { int amount;
/* 1586 */         throw new IllegalStateException(sm.getString("expiresFilter.invalidDurationNumber", new Object[] { currentToken, line }));
/*      */       }
/*      */       
/*      */       int amount;
/*      */       try
/*      */       {
/* 1592 */         currentToken = tokenizer.nextToken();
/*      */       } catch (NoSuchElementException e) {
/* 1594 */         throw new IllegalStateException(sm.getString("expiresFilter.noDurationUnitAfterAmount", new Object[] { Integer.valueOf(amount), line }));
/*      */       }
/*      */       
/*      */ 
/*      */       DurationUnit durationUnit;
/*      */       
/* 1600 */       if (("year".equalsIgnoreCase(currentToken)) || ("years".equalsIgnoreCase(currentToken)))
/*      */       {
/* 1602 */         durationUnit = DurationUnit.YEAR; } else { DurationUnit durationUnit;
/* 1603 */         if (("month".equalsIgnoreCase(currentToken)) || ("months".equalsIgnoreCase(currentToken)))
/*      */         {
/* 1605 */           durationUnit = DurationUnit.MONTH; } else { DurationUnit durationUnit;
/* 1606 */           if (("week".equalsIgnoreCase(currentToken)) || ("weeks".equalsIgnoreCase(currentToken)))
/*      */           {
/* 1608 */             durationUnit = DurationUnit.WEEK; } else { DurationUnit durationUnit;
/* 1609 */             if (("day".equalsIgnoreCase(currentToken)) || ("days".equalsIgnoreCase(currentToken)))
/*      */             {
/* 1611 */               durationUnit = DurationUnit.DAY; } else { DurationUnit durationUnit;
/* 1612 */               if (("hour".equalsIgnoreCase(currentToken)) || ("hours".equalsIgnoreCase(currentToken)))
/*      */               {
/* 1614 */                 durationUnit = DurationUnit.HOUR; } else { DurationUnit durationUnit;
/* 1615 */                 if (("minute".equalsIgnoreCase(currentToken)) || ("minutes".equalsIgnoreCase(currentToken)))
/*      */                 {
/* 1617 */                   durationUnit = DurationUnit.MINUTE; } else { DurationUnit durationUnit;
/* 1618 */                   if (("second".equalsIgnoreCase(currentToken)) || ("seconds".equalsIgnoreCase(currentToken)))
/*      */                   {
/* 1620 */                     durationUnit = DurationUnit.SECOND;
/*      */                   } else
/* 1622 */                     throw new IllegalStateException(sm.getString("expiresFilter.invalidDurationUnit", new Object[] { currentToken, line }));
/*      */                 }
/*      */               }
/*      */             }
/*      */           } } }
/*      */       DurationUnit durationUnit;
/* 1628 */       Duration duration = new Duration(amount, durationUnit);
/* 1629 */       durations.add(duration);
/*      */       
/* 1631 */       if (tokenizer.hasMoreTokens()) {
/* 1632 */         currentToken = tokenizer.nextToken();
/*      */       } else {
/* 1634 */         currentToken = null;
/*      */       }
/*      */     }
/*      */     
/* 1638 */     return new ExpiresConfiguration(startingPoint, durations);
/*      */   }
/*      */   
/*      */   public void setDefaultExpiresConfiguration(ExpiresConfiguration defaultExpiresConfiguration)
/*      */   {
/* 1643 */     this.defaultExpiresConfiguration = defaultExpiresConfiguration;
/*      */   }
/*      */   
/*      */   public void setExcludedResponseStatusCodes(int[] excludedResponseStatusCodes) {
/* 1647 */     this.excludedResponseStatusCodes = excludedResponseStatusCodes;
/*      */   }
/*      */   
/*      */   public void setExpiresConfigurationByContentType(Map<String, ExpiresConfiguration> expiresConfigurationByContentType)
/*      */   {
/* 1652 */     this.expiresConfigurationByContentType = expiresConfigurationByContentType;
/*      */   }
/*      */   
/*      */   public String toString()
/*      */   {
/* 1657 */     return getClass().getSimpleName() + "[excludedResponseStatusCode=[" + intsToCommaDelimitedString(this.excludedResponseStatusCodes) + "], default=" + this.defaultExpiresConfiguration + ", byType=" + this.expiresConfigurationByContentType + "]";
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\filters\ExpiresFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */