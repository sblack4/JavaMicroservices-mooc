/*      */ package org.apache.catalina.filters;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Set;
/*      */ import javax.servlet.Filter;
/*      */ import javax.servlet.FilterChain;
/*      */ import javax.servlet.FilterConfig;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletRequest;
/*      */ import javax.servlet.ServletResponse;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class CorsFilter
/*      */   implements Filter
/*      */ {
/*   81 */   private static final Log log = LogFactory.getLog(CorsFilter.class);
/*   82 */   private static final StringManager sm = StringManager.getManager(CorsFilter.class);
/*      */   private final Collection<String> allowedOrigins;
/*      */   private boolean anyOriginAllowed;
/*      */   private final Collection<String> allowedHttpMethods;
/*      */   private final Collection<String> allowedHttpHeaders;
/*      */   private final Collection<String> exposedHeaders;
/*      */   
/*   89 */   public CorsFilter() { this.allowedOrigins = new HashSet();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  100 */     this.allowedHttpMethods = new HashSet();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  106 */     this.allowedHttpHeaders = new HashSet();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  113 */     this.exposedHeaders = new HashSet();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
/*      */     throws IOException, ServletException
/*      */   {
/*  138 */     if ((!(servletRequest instanceof HttpServletRequest)) || (!(servletResponse instanceof HttpServletResponse)))
/*      */     {
/*  140 */       throw new ServletException(sm.getString("corsFilter.onlyHttp"));
/*      */     }
/*      */     
/*      */ 
/*  144 */     HttpServletRequest request = (HttpServletRequest)servletRequest;
/*  145 */     HttpServletResponse response = (HttpServletResponse)servletResponse;
/*      */     
/*      */ 
/*  148 */     CORSRequestType requestType = checkRequestType(request);
/*      */     
/*      */ 
/*  151 */     if (this.decorateRequest) {
/*  152 */       decorateCORSProperties(request, requestType);
/*      */     }
/*  154 */     switch (requestType)
/*      */     {
/*      */     case SIMPLE: 
/*  157 */       handleSimpleCORS(request, response, filterChain);
/*  158 */       break;
/*      */     
/*      */     case ACTUAL: 
/*  161 */       handleSimpleCORS(request, response, filterChain);
/*  162 */       break;
/*      */     
/*      */     case PRE_FLIGHT: 
/*  165 */       handlePreflightCORS(request, response, filterChain);
/*  166 */       break;
/*      */     
/*      */     case NOT_CORS: 
/*  169 */       handleNonCORS(request, response, filterChain);
/*  170 */       break;
/*      */     
/*      */     default: 
/*  173 */       handleInvalidCORS(request, response, filterChain);
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */   public void init(FilterConfig filterConfig)
/*      */     throws ServletException
/*      */   {
/*  182 */     parseAndStore("*", "GET,POST,HEAD,OPTIONS", "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers", "", "true", "1800", "true");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  187 */     if (filterConfig != null) {
/*  188 */       String configAllowedOrigins = filterConfig.getInitParameter("cors.allowed.origins");
/*      */       
/*  190 */       String configAllowedHttpMethods = filterConfig.getInitParameter("cors.allowed.methods");
/*      */       
/*  192 */       String configAllowedHttpHeaders = filterConfig.getInitParameter("cors.allowed.headers");
/*      */       
/*  194 */       String configExposedHeaders = filterConfig.getInitParameter("cors.exposed.headers");
/*      */       
/*  196 */       String configSupportsCredentials = filterConfig.getInitParameter("cors.support.credentials");
/*      */       
/*  198 */       String configPreflightMaxAge = filterConfig.getInitParameter("cors.preflight.maxage");
/*      */       
/*  200 */       String configDecorateRequest = filterConfig.getInitParameter("cors.request.decorate");
/*      */       
/*      */ 
/*  203 */       parseAndStore(configAllowedOrigins, configAllowedHttpMethods, configAllowedHttpHeaders, configExposedHeaders, configSupportsCredentials, configPreflightMaxAge, configDecorateRequest);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void handleSimpleCORS(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*      */     throws IOException, ServletException
/*      */   {
/*  226 */     CORSRequestType requestType = checkRequestType(request);
/*  227 */     if ((requestType != CORSRequestType.SIMPLE) && (requestType != CORSRequestType.ACTUAL))
/*      */     {
/*  229 */       throw new IllegalArgumentException(sm.getString("corsFilter.wrongType2", new Object[] { CORSRequestType.SIMPLE, CORSRequestType.ACTUAL }));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  235 */     String origin = request.getHeader("Origin");
/*      */     
/*  237 */     String method = request.getMethod();
/*      */     
/*      */ 
/*  240 */     if (!isOriginAllowed(origin)) {
/*  241 */       handleInvalidCORS(request, response, filterChain);
/*  242 */       return;
/*      */     }
/*      */     
/*  245 */     if (!this.allowedHttpMethods.contains(method)) {
/*  246 */       handleInvalidCORS(request, response, filterChain);
/*  247 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  252 */     if ((this.anyOriginAllowed) && (!this.supportsCredentials))
/*      */     {
/*      */ 
/*      */ 
/*  256 */       response.addHeader("Access-Control-Allow-Origin", "*");
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*  263 */       response.addHeader("Access-Control-Allow-Origin", origin);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  272 */     if (this.supportsCredentials) {
/*  273 */       response.addHeader("Access-Control-Allow-Credentials", "true");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  282 */     if ((this.exposedHeaders != null) && (this.exposedHeaders.size() > 0)) {
/*  283 */       String exposedHeadersString = join(this.exposedHeaders, ",");
/*  284 */       response.addHeader("Access-Control-Expose-Headers", exposedHeadersString);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  290 */     filterChain.doFilter(request, response);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void handlePreflightCORS(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*      */     throws IOException, ServletException
/*      */   {
/*  307 */     CORSRequestType requestType = checkRequestType(request);
/*  308 */     if (requestType != CORSRequestType.PRE_FLIGHT) {
/*  309 */       throw new IllegalArgumentException(sm.getString("corsFilter.wrongType1", new Object[] { CORSRequestType.PRE_FLIGHT.name().toLowerCase(Locale.ENGLISH) }));
/*      */     }
/*      */     
/*      */ 
/*  313 */     String origin = request.getHeader("Origin");
/*      */     
/*      */ 
/*      */ 
/*  317 */     if (!isOriginAllowed(origin)) {
/*  318 */       handleInvalidCORS(request, response, filterChain);
/*  319 */       return;
/*      */     }
/*      */     
/*      */ 
/*  323 */     String accessControlRequestMethod = request.getHeader("Access-Control-Request-Method");
/*      */     
/*  325 */     if (accessControlRequestMethod == null) {
/*  326 */       handleInvalidCORS(request, response, filterChain);
/*  327 */       return;
/*      */     }
/*  329 */     accessControlRequestMethod = accessControlRequestMethod.trim();
/*      */     
/*      */ 
/*      */ 
/*  333 */     String accessControlRequestHeadersHeader = request.getHeader("Access-Control-Request-Headers");
/*      */     
/*  335 */     List<String> accessControlRequestHeaders = new LinkedList();
/*  336 */     if ((accessControlRequestHeadersHeader != null) && (!accessControlRequestHeadersHeader.trim().isEmpty()))
/*      */     {
/*  338 */       String[] headers = accessControlRequestHeadersHeader.trim().split(",");
/*      */       
/*  340 */       for (String header : headers) {
/*  341 */         accessControlRequestHeaders.add(header.trim().toLowerCase(Locale.ENGLISH));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  346 */     if (!this.allowedHttpMethods.contains(accessControlRequestMethod)) {
/*  347 */       handleInvalidCORS(request, response, filterChain);
/*  348 */       return;
/*      */     }
/*      */     
/*      */ 
/*  352 */     if (!accessControlRequestHeaders.isEmpty()) {
/*  353 */       for (String header : accessControlRequestHeaders) {
/*  354 */         if (!this.allowedHttpHeaders.contains(header)) {
/*  355 */           handleInvalidCORS(request, response, filterChain);
/*  356 */           return;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  362 */     if (this.supportsCredentials) {
/*  363 */       response.addHeader("Access-Control-Allow-Origin", origin);
/*      */       
/*      */ 
/*  366 */       response.addHeader("Access-Control-Allow-Credentials", "true");
/*      */ 
/*      */ 
/*      */     }
/*  370 */     else if (this.anyOriginAllowed) {
/*  371 */       response.addHeader("Access-Control-Allow-Origin", "*");
/*      */     }
/*      */     else
/*      */     {
/*  375 */       response.addHeader("Access-Control-Allow-Origin", origin);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  382 */     if (this.preflightMaxAge > 0L) {
/*  383 */       response.addHeader("Access-Control-Max-Age", String.valueOf(this.preflightMaxAge));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  389 */     response.addHeader("Access-Control-Allow-Methods", accessControlRequestMethod);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  394 */     if ((this.allowedHttpHeaders != null) && (!this.allowedHttpHeaders.isEmpty())) {
/*  395 */       response.addHeader("Access-Control-Allow-Headers", join(this.allowedHttpHeaders, ","));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void handleNonCORS(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*      */     throws IOException, ServletException
/*      */   {
/*  419 */     filterChain.doFilter(request, response);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void handleInvalidCORS(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*      */   {
/*  432 */     String origin = request.getHeader("Origin");
/*  433 */     String method = request.getMethod();
/*  434 */     String accessControlRequestHeaders = request.getHeader("Access-Control-Request-Headers");
/*      */     
/*      */ 
/*  437 */     response.setContentType("text/plain");
/*  438 */     response.setStatus(403);
/*  439 */     response.resetBuffer();
/*      */     
/*  441 */     if (log.isDebugEnabled())
/*      */     {
/*  443 */       StringBuilder message = new StringBuilder("Invalid CORS request; Origin=");
/*      */       
/*  445 */       message.append(origin);
/*  446 */       message.append(";Method=");
/*  447 */       message.append(method);
/*  448 */       if (accessControlRequestHeaders != null) {
/*  449 */         message.append(";Access-Control-Request-Headers=");
/*  450 */         message.append(accessControlRequestHeaders);
/*      */       }
/*  452 */       log.debug(message.toString());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void destroy() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static void decorateCORSProperties(HttpServletRequest request, CORSRequestType corsRequestType)
/*      */   {
/*  483 */     if (request == null) {
/*  484 */       throw new IllegalArgumentException(sm.getString("corsFilter.nullRequest"));
/*      */     }
/*      */     
/*      */ 
/*  488 */     if (corsRequestType == null) {
/*  489 */       throw new IllegalArgumentException(sm.getString("corsFilter.nullRequestType"));
/*      */     }
/*      */     
/*      */ 
/*  493 */     switch (corsRequestType) {
/*      */     case SIMPLE: 
/*  495 */       request.setAttribute("cors.isCorsRequest", Boolean.TRUE);
/*      */       
/*      */ 
/*  498 */       request.setAttribute("cors.request.origin", request.getHeader("Origin"));
/*      */       
/*  500 */       request.setAttribute("cors.request.type", corsRequestType.name().toLowerCase(Locale.ENGLISH));
/*      */       
/*      */ 
/*  503 */       break;
/*      */     case ACTUAL: 
/*  505 */       request.setAttribute("cors.isCorsRequest", Boolean.TRUE);
/*      */       
/*      */ 
/*  508 */       request.setAttribute("cors.request.origin", request.getHeader("Origin"));
/*      */       
/*  510 */       request.setAttribute("cors.request.type", corsRequestType.name().toLowerCase(Locale.ENGLISH));
/*      */       
/*      */ 
/*  513 */       break;
/*      */     case PRE_FLIGHT: 
/*  515 */       request.setAttribute("cors.isCorsRequest", Boolean.TRUE);
/*      */       
/*      */ 
/*  518 */       request.setAttribute("cors.request.origin", request.getHeader("Origin"));
/*      */       
/*  520 */       request.setAttribute("cors.request.type", corsRequestType.name().toLowerCase(Locale.ENGLISH));
/*      */       
/*      */ 
/*  523 */       String headers = request.getHeader("Access-Control-Request-Headers");
/*      */       
/*  525 */       if (headers == null) {
/*  526 */         headers = "";
/*      */       }
/*  528 */       request.setAttribute("cors.request.headers", headers);
/*      */       
/*  530 */       break;
/*      */     case NOT_CORS: 
/*  532 */       request.setAttribute("cors.isCorsRequest", Boolean.FALSE);
/*      */       
/*      */ 
/*  535 */       break;
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static String join(Collection<String> elements, String joinSeparator)
/*      */   {
/*  554 */     String separator = ",";
/*  555 */     if (elements == null) {
/*  556 */       return null;
/*      */     }
/*  558 */     if (joinSeparator != null) {
/*  559 */       separator = joinSeparator;
/*      */     }
/*  561 */     StringBuilder buffer = new StringBuilder();
/*  562 */     boolean isFirst = true;
/*  563 */     for (String element : elements) {
/*  564 */       if (!isFirst) {
/*  565 */         buffer.append(separator);
/*      */       } else {
/*  567 */         isFirst = false;
/*      */       }
/*      */       
/*  570 */       if (element != null) {
/*  571 */         buffer.append(element);
/*      */       }
/*      */     }
/*      */     
/*  575 */     return buffer.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected CORSRequestType checkRequestType(HttpServletRequest request)
/*      */   {
/*  586 */     CORSRequestType requestType = CORSRequestType.INVALID_CORS;
/*  587 */     if (request == null) {
/*  588 */       throw new IllegalArgumentException(sm.getString("corsFilter.nullRequest"));
/*      */     }
/*      */     
/*  591 */     String originHeader = request.getHeader("Origin");
/*      */     
/*  593 */     if (originHeader != null) {
/*  594 */       if (originHeader.isEmpty()) {
/*  595 */         requestType = CORSRequestType.INVALID_CORS;
/*  596 */       } else if (!isValidOrigin(originHeader)) {
/*  597 */         requestType = CORSRequestType.INVALID_CORS;
/*  598 */       } else { if (isLocalOrigin(request, originHeader)) {
/*  599 */           return CORSRequestType.NOT_CORS;
/*      */         }
/*  601 */         String method = request.getMethod();
/*  602 */         if (method != null) {
/*  603 */           if ("OPTIONS".equals(method)) {
/*  604 */             String accessControlRequestMethodHeader = request.getHeader("Access-Control-Request-Method");
/*      */             
/*      */ 
/*  607 */             if ((accessControlRequestMethodHeader != null) && (!accessControlRequestMethodHeader.isEmpty()))
/*      */             {
/*  609 */               requestType = CORSRequestType.PRE_FLIGHT;
/*  610 */             } else if ((accessControlRequestMethodHeader != null) && (accessControlRequestMethodHeader.isEmpty()))
/*      */             {
/*  612 */               requestType = CORSRequestType.INVALID_CORS;
/*      */             } else {
/*  614 */               requestType = CORSRequestType.ACTUAL;
/*      */             }
/*  616 */           } else if (("GET".equals(method)) || ("HEAD".equals(method))) {
/*  617 */             requestType = CORSRequestType.SIMPLE;
/*  618 */           } else if ("POST".equals(method)) {
/*  619 */             String mediaType = getMediaType(request.getContentType());
/*  620 */             if (mediaType != null) {
/*  621 */               if (SIMPLE_HTTP_REQUEST_CONTENT_TYPE_VALUES.contains(mediaType))
/*      */               {
/*  623 */                 requestType = CORSRequestType.SIMPLE;
/*      */               } else {
/*  625 */                 requestType = CORSRequestType.ACTUAL;
/*      */               }
/*      */             }
/*      */           } else {
/*  629 */             requestType = CORSRequestType.ACTUAL;
/*      */           }
/*      */         }
/*      */       }
/*      */     } else {
/*  634 */       requestType = CORSRequestType.NOT_CORS;
/*      */     }
/*      */     
/*  637 */     return requestType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean isLocalOrigin(HttpServletRequest request, String origin)
/*      */   {
/*  644 */     StringBuilder target = new StringBuilder();
/*  645 */     String scheme = request.getScheme();
/*  646 */     if (scheme == null) {
/*  647 */       return false;
/*      */     }
/*  649 */     scheme = scheme.toLowerCase(Locale.ENGLISH);
/*      */     
/*  651 */     target.append(scheme);
/*  652 */     target.append("://");
/*      */     
/*  654 */     String host = request.getServerName();
/*  655 */     if (host == null) {
/*  656 */       return false;
/*      */     }
/*  658 */     target.append(host);
/*      */     
/*  660 */     int port = request.getServerPort();
/*  661 */     if ((("http".equals(scheme)) && (port != 80)) || (("https".equals(scheme)) && (port != 443)))
/*      */     {
/*  663 */       target.append(':');
/*  664 */       target.append(port);
/*      */     }
/*      */     
/*  667 */     return origin.equalsIgnoreCase(target.toString());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getMediaType(String contentType)
/*      */   {
/*  676 */     if (contentType == null) {
/*  677 */       return null;
/*      */     }
/*  679 */     String result = contentType.toLowerCase(Locale.ENGLISH);
/*  680 */     int firstSemiColonIndex = result.indexOf(';');
/*  681 */     if (firstSemiColonIndex > -1) {
/*  682 */       result = result.substring(0, firstSemiColonIndex);
/*      */     }
/*  684 */     result = result.trim();
/*  685 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isOriginAllowed(String origin)
/*      */   {
/*  697 */     if (this.anyOriginAllowed) {
/*  698 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  703 */     return this.allowedOrigins.contains(origin);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void parseAndStore(String allowedOrigins, String allowedHttpMethods, String allowedHttpHeaders, String exposedHeaders, String supportsCredentials, String preflightMaxAge, String decorateRequest)
/*      */     throws ServletException
/*      */   {
/*  732 */     if (allowedOrigins != null) {
/*  733 */       if (allowedOrigins.trim().equals("*")) {
/*  734 */         this.anyOriginAllowed = true;
/*      */       } else {
/*  736 */         this.anyOriginAllowed = false;
/*  737 */         Set<String> setAllowedOrigins = parseStringToSet(allowedOrigins);
/*      */         
/*  739 */         this.allowedOrigins.clear();
/*  740 */         this.allowedOrigins.addAll(setAllowedOrigins);
/*      */       }
/*      */     }
/*      */     
/*  744 */     if (allowedHttpMethods != null) {
/*  745 */       Set<String> setAllowedHttpMethods = parseStringToSet(allowedHttpMethods);
/*      */       
/*  747 */       this.allowedHttpMethods.clear();
/*  748 */       this.allowedHttpMethods.addAll(setAllowedHttpMethods);
/*      */     }
/*      */     
/*  751 */     if (allowedHttpHeaders != null) {
/*  752 */       Set<String> setAllowedHttpHeaders = parseStringToSet(allowedHttpHeaders);
/*      */       
/*  754 */       Set<String> lowerCaseHeaders = new HashSet();
/*  755 */       for (String header : setAllowedHttpHeaders) {
/*  756 */         String lowerCase = header.toLowerCase(Locale.ENGLISH);
/*  757 */         lowerCaseHeaders.add(lowerCase);
/*      */       }
/*  759 */       this.allowedHttpHeaders.clear();
/*  760 */       this.allowedHttpHeaders.addAll(lowerCaseHeaders);
/*      */     }
/*      */     
/*  763 */     if (exposedHeaders != null) {
/*  764 */       Set<String> setExposedHeaders = parseStringToSet(exposedHeaders);
/*  765 */       this.exposedHeaders.clear();
/*  766 */       this.exposedHeaders.addAll(setExposedHeaders);
/*      */     }
/*      */     
/*  769 */     if (supportsCredentials != null)
/*      */     {
/*  771 */       this.supportsCredentials = Boolean.parseBoolean(supportsCredentials);
/*      */     }
/*      */     
/*      */ 
/*  775 */     if (preflightMaxAge != null) {
/*      */       try {
/*  777 */         if (!preflightMaxAge.isEmpty()) {
/*  778 */           this.preflightMaxAge = Long.parseLong(preflightMaxAge);
/*      */         } else {
/*  780 */           this.preflightMaxAge = 0L;
/*      */         }
/*      */       } catch (NumberFormatException e) {
/*  783 */         throw new ServletException(sm.getString("corsFilter.invalidPreflightMaxAge"), e);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  788 */     if (decorateRequest != null)
/*      */     {
/*  790 */       this.decorateRequest = Boolean.parseBoolean(decorateRequest);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private Set<String> parseStringToSet(String data)
/*      */   {
/*      */     String[] splits;
/*      */     
/*      */ 
/*      */     String[] splits;
/*      */     
/*      */ 
/*  804 */     if ((data != null) && (data.length() > 0)) {
/*  805 */       splits = data.split(",");
/*      */     } else {
/*  807 */       splits = new String[0];
/*      */     }
/*      */     
/*  810 */     Set<String> set = new HashSet();
/*  811 */     if (splits.length > 0) {
/*  812 */       for (String split : splits) {
/*  813 */         set.add(split.trim());
/*      */       }
/*      */     }
/*      */     
/*  817 */     return set;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static boolean isValidOrigin(String origin)
/*      */   {
/*  835 */     if (origin.contains("%")) {
/*  836 */       return false;
/*      */     }
/*      */     
/*      */ 
/*  840 */     if ("null".equals(origin)) {
/*  841 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  847 */       originURI = new URI(origin);
/*      */     } catch (URISyntaxException e) { URI originURI;
/*  849 */       return false;
/*      */     }
/*      */     URI originURI;
/*  852 */     return originURI.getScheme() != null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isAnyOriginAllowed()
/*      */   {
/*  863 */     return this.anyOriginAllowed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Collection<String> getExposedHeaders()
/*      */   {
/*  873 */     return this.exposedHeaders;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isSupportsCredentials()
/*      */   {
/*  884 */     return this.supportsCredentials;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getPreflightMaxAge()
/*      */   {
/*  894 */     return this.preflightMaxAge;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Collection<String> getAllowedOrigins()
/*      */   {
/*  905 */     return this.allowedOrigins;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Collection<String> getAllowedHttpMethods()
/*      */   {
/*  915 */     return this.allowedHttpMethods;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Collection<String> getAllowedHttpHeaders()
/*      */   {
/*  925 */     return this.allowedHttpHeaders;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean supportsCredentials;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private long preflightMaxAge;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean decorateRequest;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String RESPONSE_HEADER_ACCESS_CONTROL_ALLOW_ORIGIN = "Access-Control-Allow-Origin";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String RESPONSE_HEADER_ACCESS_CONTROL_ALLOW_CREDENTIALS = "Access-Control-Allow-Credentials";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String RESPONSE_HEADER_ACCESS_CONTROL_EXPOSE_HEADERS = "Access-Control-Expose-Headers";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String RESPONSE_HEADER_ACCESS_CONTROL_MAX_AGE = "Access-Control-Max-Age";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String RESPONSE_HEADER_ACCESS_CONTROL_ALLOW_METHODS = "Access-Control-Allow-Methods";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String RESPONSE_HEADER_ACCESS_CONTROL_ALLOW_HEADERS = "Access-Control-Allow-Headers";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String REQUEST_HEADER_ORIGIN = "Origin";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String REQUEST_HEADER_ACCESS_CONTROL_REQUEST_METHOD = "Access-Control-Request-Method";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String REQUEST_HEADER_ACCESS_CONTROL_REQUEST_HEADERS = "Access-Control-Request-Headers";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String HTTP_REQUEST_ATTRIBUTE_PREFIX = "cors.";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String HTTP_REQUEST_ATTRIBUTE_ORIGIN = "cors.request.origin";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String HTTP_REQUEST_ATTRIBUTE_IS_CORS_REQUEST = "cors.isCorsRequest";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String HTTP_REQUEST_ATTRIBUTE_REQUEST_TYPE = "cors.request.type";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String HTTP_REQUEST_ATTRIBUTE_REQUEST_HEADERS = "cors.request.headers";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static enum CORSRequestType
/*      */   {
/* 1038 */     SIMPLE, 
/*      */     
/*      */ 
/*      */ 
/* 1042 */     ACTUAL, 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1047 */     PRE_FLIGHT, 
/*      */     
/*      */ 
/*      */ 
/* 1051 */     NOT_CORS, 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1056 */     INVALID_CORS;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private CORSRequestType() {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1067 */   public static final Collection<String> SIMPLE_HTTP_REQUEST_CONTENT_TYPE_VALUES = new HashSet(Arrays.asList(new String[] { "application/x-www-form-urlencoded", "multipart/form-data", "text/plain" }));
/*      */   public static final String DEFAULT_ALLOWED_ORIGINS = "*";
/*      */   public static final String DEFAULT_ALLOWED_HTTP_METHODS = "GET,POST,HEAD,OPTIONS";
/*      */   public static final String DEFAULT_PREFLIGHT_MAXAGE = "1800";
/*      */   public static final String DEFAULT_SUPPORTS_CREDENTIALS = "true";
/*      */   public static final String DEFAULT_ALLOWED_HTTP_HEADERS = "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers";
/*      */   public static final String DEFAULT_EXPOSED_HEADERS = "";
/*      */   public static final String DEFAULT_DECORATE_REQUEST = "true";
/*      */   public static final String PARAM_CORS_ALLOWED_ORIGINS = "cors.allowed.origins";
/*      */   public static final String PARAM_CORS_SUPPORT_CREDENTIALS = "cors.support.credentials";
/*      */   public static final String PARAM_CORS_EXPOSED_HEADERS = "cors.exposed.headers";
/*      */   public static final String PARAM_CORS_ALLOWED_HEADERS = "cors.allowed.headers";
/*      */   public static final String PARAM_CORS_ALLOWED_METHODS = "cors.allowed.methods";
/*      */   public static final String PARAM_CORS_PREFLIGHT_MAXAGE = "cors.preflight.maxage";
/*      */   public static final String PARAM_CORS_REQUEST_DECORATE = "cors.request.decorate";
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\filters\CorsFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */