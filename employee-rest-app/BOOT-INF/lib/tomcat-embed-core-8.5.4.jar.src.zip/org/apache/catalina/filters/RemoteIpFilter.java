/*      */ package org.apache.catalina.filters;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.text.DateFormat;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import javax.servlet.Filter;
/*      */ import javax.servlet.FilterChain;
/*      */ import javax.servlet.FilterConfig;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletRequest;
/*      */ import javax.servlet.ServletResponse;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletRequestWrapper;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import org.apache.catalina.core.ApplicationPushBuilder;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class RemoteIpFilter
/*      */   implements Filter
/*      */ {
/*      */   public static class XForwardedRequest
/*      */     extends HttpServletRequestWrapper
/*      */   {
/*  442 */     static final ThreadLocal<SimpleDateFormat[]> threadLocalDateFormats = new ThreadLocal()
/*      */     {
/*      */       protected SimpleDateFormat[] initialValue() {
/*  445 */         return new SimpleDateFormat[] { new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US), new SimpleDateFormat("EEEEEE, dd-MMM-yy HH:mm:ss zzz", Locale.US), new SimpleDateFormat("EEE MMMM d HH:mm:ss yyyy", Locale.US) };
/*      */       }
/*      */     };
/*      */     
/*      */ 
/*      */     protected final Map<String, List<String>> headers;
/*      */     
/*      */ 
/*      */     protected int localPort;
/*      */     
/*      */ 
/*      */     protected String remoteAddr;
/*      */     
/*      */     protected String remoteHost;
/*      */     
/*      */     protected String scheme;
/*      */     
/*      */     protected boolean secure;
/*      */     
/*      */     protected int serverPort;
/*      */     
/*      */ 
/*      */     public XForwardedRequest(HttpServletRequest request)
/*      */     {
/*  469 */       super();
/*  470 */       this.localPort = request.getLocalPort();
/*  471 */       this.remoteAddr = request.getRemoteAddr();
/*  472 */       this.remoteHost = request.getRemoteHost();
/*  473 */       this.scheme = request.getScheme();
/*  474 */       this.secure = request.isSecure();
/*  475 */       this.serverPort = request.getServerPort();
/*      */       
/*  477 */       this.headers = new HashMap();
/*  478 */       for (Enumeration<String> headerNames = request.getHeaderNames(); headerNames.hasMoreElements();) {
/*  479 */         String header = (String)headerNames.nextElement();
/*  480 */         this.headers.put(header, Collections.list(request.getHeaders(header)));
/*      */       }
/*      */     }
/*      */     
/*      */     public long getDateHeader(String name)
/*      */     {
/*  486 */       String value = getHeader(name);
/*  487 */       if (value == null) {
/*  488 */         return -1L;
/*      */       }
/*  490 */       DateFormat[] dateFormats = (DateFormat[])threadLocalDateFormats.get();
/*  491 */       Date date = null;
/*  492 */       for (int i = 0; (i < dateFormats.length) && (date == null); i++) {
/*  493 */         DateFormat dateFormat = dateFormats[i];
/*      */         try {
/*  495 */           date = dateFormat.parse(value);
/*      */         }
/*      */         catch (Exception localException) {}
/*      */       }
/*      */       
/*  500 */       if (date == null) {
/*  501 */         throw new IllegalArgumentException(value);
/*      */       }
/*  503 */       return date.getTime();
/*      */     }
/*      */     
/*      */     public String getHeader(String name)
/*      */     {
/*  508 */       Map.Entry<String, List<String>> header = getHeaderEntry(name);
/*  509 */       if ((header == null) || (header.getValue() == null) || (((List)header.getValue()).isEmpty())) {
/*  510 */         return null;
/*      */       }
/*  512 */       return (String)((List)header.getValue()).get(0);
/*      */     }
/*      */     
/*      */     protected Map.Entry<String, List<String>> getHeaderEntry(String name) {
/*  516 */       for (Map.Entry<String, List<String>> entry : this.headers.entrySet()) {
/*  517 */         if (((String)entry.getKey()).equalsIgnoreCase(name)) {
/*  518 */           return entry;
/*      */         }
/*      */       }
/*  521 */       return null;
/*      */     }
/*      */     
/*      */     public Enumeration<String> getHeaderNames()
/*      */     {
/*  526 */       return Collections.enumeration(this.headers.keySet());
/*      */     }
/*      */     
/*      */     public Enumeration<String> getHeaders(String name)
/*      */     {
/*  531 */       Map.Entry<String, List<String>> header = getHeaderEntry(name);
/*  532 */       if ((header == null) || (header.getValue() == null)) {
/*  533 */         return Collections.enumeration(Collections.emptyList());
/*      */       }
/*  535 */       return Collections.enumeration((Collection)header.getValue());
/*      */     }
/*      */     
/*      */     public int getIntHeader(String name)
/*      */     {
/*  540 */       String value = getHeader(name);
/*  541 */       if (value == null) {
/*  542 */         return -1;
/*      */       }
/*  544 */       return Integer.parseInt(value);
/*      */     }
/*      */     
/*      */     public int getLocalPort()
/*      */     {
/*  549 */       return this.localPort;
/*      */     }
/*      */     
/*      */     public String getRemoteAddr()
/*      */     {
/*  554 */       return this.remoteAddr;
/*      */     }
/*      */     
/*      */     public String getRemoteHost()
/*      */     {
/*  559 */       return this.remoteHost;
/*      */     }
/*      */     
/*      */     public String getScheme()
/*      */     {
/*  564 */       return this.scheme;
/*      */     }
/*      */     
/*      */     public int getServerPort()
/*      */     {
/*  569 */       return this.serverPort;
/*      */     }
/*      */     
/*      */     public boolean isSecure()
/*      */     {
/*  574 */       return this.secure;
/*      */     }
/*      */     
/*      */     public void removeHeader(String name) {
/*  578 */       Map.Entry<String, List<String>> header = getHeaderEntry(name);
/*  579 */       if (header != null) {
/*  580 */         this.headers.remove(header.getKey());
/*      */       }
/*      */     }
/*      */     
/*      */     public void setHeader(String name, String value) {
/*  585 */       List<String> values = Arrays.asList(new String[] { value });
/*  586 */       Map.Entry<String, List<String>> header = getHeaderEntry(name);
/*  587 */       if (header == null) {
/*  588 */         this.headers.put(name, values);
/*      */       } else {
/*  590 */         header.setValue(values);
/*      */       }
/*      */     }
/*      */     
/*      */     public void setLocalPort(int localPort)
/*      */     {
/*  596 */       this.localPort = localPort;
/*      */     }
/*      */     
/*      */     public void setRemoteAddr(String remoteAddr) {
/*  600 */       this.remoteAddr = remoteAddr;
/*      */     }
/*      */     
/*      */     public void setRemoteHost(String remoteHost) {
/*  604 */       this.remoteHost = remoteHost;
/*      */     }
/*      */     
/*      */     public void setScheme(String scheme) {
/*  608 */       this.scheme = scheme;
/*      */     }
/*      */     
/*      */     public void setSecure(boolean secure) {
/*  612 */       this.secure = secure;
/*      */     }
/*      */     
/*      */     public void setServerPort(int serverPort) {
/*  616 */       this.serverPort = serverPort;
/*      */     }
/*      */     
/*      */     public StringBuffer getRequestURL()
/*      */     {
/*  621 */       StringBuffer url = new StringBuffer();
/*  622 */       String scheme = getScheme();
/*  623 */       int port = getServerPort();
/*  624 */       if (port < 0) {
/*  625 */         port = 80;
/*      */       }
/*  627 */       url.append(scheme);
/*  628 */       url.append("://");
/*  629 */       url.append(getServerName());
/*  630 */       if (((scheme.equals("http")) && (port != 80)) || ((scheme.equals("https")) && (port != 443)))
/*      */       {
/*  632 */         url.append(':');
/*  633 */         url.append(port);
/*      */       }
/*  635 */       url.append(getRequestURI());
/*      */       
/*  637 */       return url;
/*      */     }
/*      */     
/*      */     public ApplicationPushBuilder getPushBuilder() {
/*  641 */       return new ApplicationPushBuilder(this);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  649 */   private static final Pattern commaSeparatedValuesPattern = Pattern.compile("\\s*,\\s*");
/*      */   
/*      */ 
/*      */   protected static final String HTTP_SERVER_PORT_PARAMETER = "httpServerPort";
/*      */   
/*      */ 
/*      */   protected static final String HTTPS_SERVER_PORT_PARAMETER = "httpsServerPort";
/*      */   
/*      */ 
/*      */   protected static final String INTERNAL_PROXIES_PARAMETER = "internalProxies";
/*      */   
/*  660 */   private static final Log log = LogFactory.getLog(RemoteIpFilter.class);
/*      */   
/*      */ 
/*      */   protected static final String PROTOCOL_HEADER_PARAMETER = "protocolHeader";
/*      */   
/*      */ 
/*      */   protected static final String PROTOCOL_HEADER_HTTPS_VALUE_PARAMETER = "protocolHeaderHttpsValue";
/*      */   
/*      */ 
/*      */   protected static final String PORT_HEADER_PARAMETER = "portHeader";
/*      */   
/*      */ 
/*      */   protected static final String CHANGE_LOCAL_PORT_PARAMETER = "changeLocalPort";
/*      */   
/*      */   protected static final String PROXIES_HEADER_PARAMETER = "proxiesHeader";
/*      */   
/*      */   protected static final String REMOTE_IP_HEADER_PARAMETER = "remoteIpHeader";
/*      */   
/*      */   protected static final String TRUSTED_PROXIES_PARAMETER = "trustedProxies";
/*      */   
/*      */ 
/*      */   protected static String[] commaDelimitedListToStringArray(String commaDelimitedStrings)
/*      */   {
/*  683 */     return (commaDelimitedStrings == null) || (commaDelimitedStrings.length() == 0) ? new String[0] : commaSeparatedValuesPattern.split(commaDelimitedStrings);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static String listToCommaDelimitedString(List<String> stringList)
/*      */   {
/*  694 */     if (stringList == null) {
/*  695 */       return "";
/*      */     }
/*  697 */     StringBuilder result = new StringBuilder();
/*  698 */     for (Iterator<String> it = stringList.iterator(); it.hasNext();) {
/*  699 */       Object element = it.next();
/*  700 */       if (element != null) {
/*  701 */         result.append(element);
/*  702 */         if (it.hasNext()) {
/*  703 */           result.append(", ");
/*      */         }
/*      */       }
/*      */     }
/*  707 */     return result.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  713 */   private int httpServerPort = 80;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  718 */   private int httpsServerPort = 443;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  723 */   private Pattern internalProxies = Pattern.compile("10\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|192\\.168\\.\\d{1,3}\\.\\d{1,3}|169\\.254\\.\\d{1,3}\\.\\d{1,3}|127\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|172\\.1[6-9]{1}\\.\\d{1,3}\\.\\d{1,3}|172\\.2[0-9]{1}\\.\\d{1,3}\\.\\d{1,3}|172\\.3[0-1]{1}\\.\\d{1,3}\\.\\d{1,3}");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  735 */   private String protocolHeader = null;
/*      */   
/*  737 */   private String protocolHeaderHttpsValue = "https";
/*      */   
/*  739 */   private String portHeader = null;
/*      */   
/*  741 */   private boolean changeLocalPort = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  746 */   private String proxiesHeader = "X-Forwarded-By";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  751 */   private String remoteIpHeader = "X-Forwarded-For";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  756 */   private boolean requestAttributesEnabled = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  761 */   private Pattern trustedProxies = null;
/*      */   
/*      */ 
/*      */   public void destroy() {}
/*      */   
/*      */ 
/*      */   public void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
/*      */     throws IOException, ServletException
/*      */   {
/*  770 */     if ((this.internalProxies != null) && (this.internalProxies.matcher(request.getRemoteAddr()).matches()))
/*      */     {
/*  772 */       String remoteIp = null;
/*      */       
/*  774 */       LinkedList<String> proxiesHeaderValue = new LinkedList();
/*  775 */       StringBuilder concatRemoteIpHeaderValue = new StringBuilder();
/*      */       
/*  777 */       for (Enumeration<String> e = request.getHeaders(this.remoteIpHeader); e.hasMoreElements();) {
/*  778 */         if (concatRemoteIpHeaderValue.length() > 0) {
/*  779 */           concatRemoteIpHeaderValue.append(", ");
/*      */         }
/*      */         
/*  782 */         concatRemoteIpHeaderValue.append((String)e.nextElement());
/*      */       }
/*      */       
/*  785 */       String[] remoteIpHeaderValue = commaDelimitedListToStringArray(concatRemoteIpHeaderValue.toString());
/*      */       
/*      */ 
/*  788 */       for (int idx = remoteIpHeaderValue.length - 1; idx >= 0; idx--) {
/*  789 */         String currentRemoteIp = remoteIpHeaderValue[idx];
/*  790 */         remoteIp = currentRemoteIp;
/*  791 */         if (!this.internalProxies.matcher(currentRemoteIp).matches())
/*      */         {
/*  793 */           if ((this.trustedProxies != null) && (this.trustedProxies.matcher(currentRemoteIp).matches()))
/*      */           {
/*  795 */             proxiesHeaderValue.addFirst(currentRemoteIp);
/*      */           } else {
/*  797 */             idx--;
/*  798 */             break;
/*      */           }
/*      */         }
/*      */       }
/*  802 */       LinkedList<String> newRemoteIpHeaderValue = new LinkedList();
/*  803 */       for (; idx >= 0; idx--) {
/*  804 */         String currentRemoteIp = remoteIpHeaderValue[idx];
/*  805 */         newRemoteIpHeaderValue.addFirst(currentRemoteIp);
/*      */       }
/*      */       
/*  808 */       XForwardedRequest xRequest = new XForwardedRequest(request);
/*  809 */       if (remoteIp != null)
/*      */       {
/*  811 */         xRequest.setRemoteAddr(remoteIp);
/*  812 */         xRequest.setRemoteHost(remoteIp);
/*      */         
/*  814 */         if (proxiesHeaderValue.size() == 0) {
/*  815 */           xRequest.removeHeader(this.proxiesHeader);
/*      */         } else {
/*  817 */           String commaDelimitedListOfProxies = listToCommaDelimitedString(proxiesHeaderValue);
/*  818 */           xRequest.setHeader(this.proxiesHeader, commaDelimitedListOfProxies);
/*      */         }
/*  820 */         if (newRemoteIpHeaderValue.size() == 0) {
/*  821 */           xRequest.removeHeader(this.remoteIpHeader);
/*      */         } else {
/*  823 */           String commaDelimitedRemoteIpHeaderValue = listToCommaDelimitedString(newRemoteIpHeaderValue);
/*  824 */           xRequest.setHeader(this.remoteIpHeader, commaDelimitedRemoteIpHeaderValue);
/*      */         }
/*      */       }
/*      */       
/*  828 */       if (this.protocolHeader != null) {
/*  829 */         String protocolHeaderValue = request.getHeader(this.protocolHeader);
/*  830 */         if (protocolHeaderValue != null)
/*      */         {
/*  832 */           if (this.protocolHeaderHttpsValue.equalsIgnoreCase(protocolHeaderValue)) {
/*  833 */             xRequest.setSecure(true);
/*  834 */             xRequest.setScheme("https");
/*  835 */             setPorts(xRequest, this.httpsServerPort);
/*      */           } else {
/*  837 */             xRequest.setSecure(false);
/*  838 */             xRequest.setScheme("http");
/*  839 */             setPorts(xRequest, this.httpServerPort);
/*      */           }
/*      */         }
/*      */       }
/*  843 */       if (log.isDebugEnabled()) {
/*  844 */         log.debug("Incoming request " + request.getRequestURI() + " with originalRemoteAddr '" + request.getRemoteAddr() + "', originalRemoteHost='" + request.getRemoteHost() + "', originalSecure='" + request.isSecure() + "', originalScheme='" + request.getScheme() + "', original[" + this.remoteIpHeader + "]='" + concatRemoteIpHeaderValue + "', original[" + this.protocolHeader + "]='" + (this.protocolHeader == null ? null : request.getHeader(this.protocolHeader)) + "' will be seen as newRemoteAddr='" + xRequest.getRemoteAddr() + "', newRemoteHost='" + xRequest.getRemoteHost() + "', newScheme='" + xRequest.getScheme() + "', newSecure='" + xRequest.isSecure() + "', new[" + this.remoteIpHeader + "]='" + xRequest.getHeader(this.remoteIpHeader) + "', new[" + this.proxiesHeader + "]='" + xRequest.getHeader(this.proxiesHeader) + "'");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  853 */       if (this.requestAttributesEnabled) {
/*  854 */         request.setAttribute("org.apache.catalina.AccessLog.RemoteAddr", xRequest.getRemoteAddr());
/*      */         
/*  856 */         request.setAttribute("org.apache.tomcat.remoteAddr", xRequest.getRemoteAddr());
/*      */         
/*  858 */         request.setAttribute("org.apache.catalina.AccessLog.RemoteHost", xRequest.getRemoteHost());
/*      */         
/*  860 */         request.setAttribute("org.apache.catalina.AccessLog.Protocol", xRequest.getProtocol());
/*      */         
/*  862 */         request.setAttribute("org.apache.catalina.AccessLog.ServerPort", Integer.valueOf(xRequest.getServerPort()));
/*      */       }
/*      */       
/*  865 */       chain.doFilter(xRequest, response);
/*      */     } else {
/*  867 */       if (log.isDebugEnabled()) {
/*  868 */         log.debug("Skip RemoteIpFilter for request " + request.getRequestURI() + " with originalRemoteAddr '" + request.getRemoteAddr() + "'");
/*      */       }
/*      */       
/*  871 */       chain.doFilter(request, response);
/*      */     }
/*      */   }
/*      */   
/*      */   private void setPorts(XForwardedRequest xrequest, int defaultPort)
/*      */   {
/*  877 */     int port = defaultPort;
/*  878 */     if (getPortHeader() != null) {
/*  879 */       String portHeaderValue = xrequest.getHeader(getPortHeader());
/*  880 */       if (portHeaderValue != null) {
/*      */         try {
/*  882 */           port = Integer.parseInt(portHeaderValue);
/*      */         } catch (NumberFormatException nfe) {
/*  884 */           log.debug("Invalid port value [" + portHeaderValue + "] provided in header [" + getPortHeader() + "]");
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  889 */     xrequest.setServerPort(port);
/*  890 */     if (isChangeLocalPort()) {
/*  891 */       xrequest.setLocalPort(port);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*      */     throws IOException, ServletException
/*      */   {
/*  901 */     if (((request instanceof HttpServletRequest)) && ((response instanceof HttpServletResponse))) {
/*  902 */       doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
/*      */     } else {
/*  904 */       chain.doFilter(request, response);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isChangeLocalPort() {
/*  909 */     return this.changeLocalPort;
/*      */   }
/*      */   
/*      */   public int getHttpsServerPort() {
/*  913 */     return this.httpsServerPort;
/*      */   }
/*      */   
/*      */   public Pattern getInternalProxies() {
/*  917 */     return this.internalProxies;
/*      */   }
/*      */   
/*      */   public String getProtocolHeader() {
/*  921 */     return this.protocolHeader;
/*      */   }
/*      */   
/*      */   public String getPortHeader() {
/*  925 */     return this.portHeader;
/*      */   }
/*      */   
/*      */   public String getProtocolHeaderHttpsValue() {
/*  929 */     return this.protocolHeaderHttpsValue;
/*      */   }
/*      */   
/*      */   public String getProxiesHeader() {
/*  933 */     return this.proxiesHeader;
/*      */   }
/*      */   
/*      */   public String getRemoteIpHeader() {
/*  937 */     return this.remoteIpHeader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getRequestAttributesEnabled()
/*      */   {
/*  946 */     return this.requestAttributesEnabled;
/*      */   }
/*      */   
/*      */   public Pattern getTrustedProxies() {
/*  950 */     return this.trustedProxies;
/*      */   }
/*      */   
/*      */   public void init(FilterConfig filterConfig) throws ServletException
/*      */   {
/*  955 */     if (filterConfig.getInitParameter("internalProxies") != null) {
/*  956 */       setInternalProxies(filterConfig.getInitParameter("internalProxies"));
/*      */     }
/*      */     
/*  959 */     if (filterConfig.getInitParameter("protocolHeader") != null) {
/*  960 */       setProtocolHeader(filterConfig.getInitParameter("protocolHeader"));
/*      */     }
/*      */     
/*  963 */     if (filterConfig.getInitParameter("protocolHeaderHttpsValue") != null) {
/*  964 */       setProtocolHeaderHttpsValue(filterConfig.getInitParameter("protocolHeaderHttpsValue"));
/*      */     }
/*      */     
/*  967 */     if (filterConfig.getInitParameter("portHeader") != null) {
/*  968 */       setPortHeader(filterConfig.getInitParameter("portHeader"));
/*      */     }
/*      */     
/*  971 */     if (filterConfig.getInitParameter("changeLocalPort") != null) {
/*  972 */       setChangeLocalPort(Boolean.parseBoolean(filterConfig.getInitParameter("changeLocalPort")));
/*      */     }
/*      */     
/*  975 */     if (filterConfig.getInitParameter("proxiesHeader") != null) {
/*  976 */       setProxiesHeader(filterConfig.getInitParameter("proxiesHeader"));
/*      */     }
/*      */     
/*  979 */     if (filterConfig.getInitParameter("remoteIpHeader") != null) {
/*  980 */       setRemoteIpHeader(filterConfig.getInitParameter("remoteIpHeader"));
/*      */     }
/*      */     
/*  983 */     if (filterConfig.getInitParameter("trustedProxies") != null) {
/*  984 */       setTrustedProxies(filterConfig.getInitParameter("trustedProxies"));
/*      */     }
/*      */     
/*  987 */     if (filterConfig.getInitParameter("httpServerPort") != null) {
/*      */       try {
/*  989 */         setHttpServerPort(Integer.parseInt(filterConfig.getInitParameter("httpServerPort")));
/*      */       } catch (NumberFormatException e) {
/*  991 */         throw new NumberFormatException("Illegal httpServerPort : " + e.getMessage());
/*      */       }
/*      */     }
/*      */     
/*  995 */     if (filterConfig.getInitParameter("httpsServerPort") != null) {
/*      */       try {
/*  997 */         setHttpsServerPort(Integer.parseInt(filterConfig.getInitParameter("httpsServerPort")));
/*      */       } catch (NumberFormatException e) {
/*  999 */         throw new NumberFormatException("Illegal httpsServerPort : " + e.getMessage());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setChangeLocalPort(boolean changeLocalPort)
/*      */   {
/* 1017 */     this.changeLocalPort = changeLocalPort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHttpServerPort(int httpServerPort)
/*      */   {
/* 1031 */     this.httpServerPort = httpServerPort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHttpsServerPort(int httpsServerPort)
/*      */   {
/* 1044 */     this.httpsServerPort = httpsServerPort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInternalProxies(String internalProxies)
/*      */   {
/* 1057 */     if ((internalProxies == null) || (internalProxies.length() == 0)) {
/* 1058 */       this.internalProxies = null;
/*      */     } else {
/* 1060 */       this.internalProxies = Pattern.compile(internalProxies);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPortHeader(String portHeader)
/*      */   {
/* 1076 */     this.portHeader = portHeader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProtocolHeader(String protocolHeader)
/*      */   {
/* 1090 */     this.protocolHeader = protocolHeader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProtocolHeaderHttpsValue(String protocolHeaderHttpsValue)
/*      */   {
/* 1103 */     this.protocolHeaderHttpsValue = protocolHeaderHttpsValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProxiesHeader(String proxiesHeader)
/*      */   {
/* 1124 */     this.proxiesHeader = proxiesHeader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRemoteIpHeader(String remoteIpHeader)
/*      */   {
/* 1140 */     this.remoteIpHeader = remoteIpHeader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRequestAttributesEnabled(boolean requestAttributesEnabled)
/*      */   {
/* 1163 */     this.requestAttributesEnabled = requestAttributesEnabled;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTrustedProxies(String trustedProxies)
/*      */   {
/* 1177 */     if ((trustedProxies == null) || (trustedProxies.length() == 0)) {
/* 1178 */       this.trustedProxies = null;
/*      */     } else {
/* 1180 */       this.trustedProxies = Pattern.compile(trustedProxies);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\filters\RemoteIpFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */