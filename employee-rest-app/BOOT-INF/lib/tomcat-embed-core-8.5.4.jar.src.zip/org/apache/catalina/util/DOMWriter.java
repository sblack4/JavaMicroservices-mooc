/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Writer;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMWriter
/*     */ {
/*     */   private static final String PRINTWRITER_ENCODING = "UTF8";
/*     */   @Deprecated
/*     */   protected final PrintWriter out;
/*     */   @Deprecated
/*     */   protected final boolean canonical;
/*     */   
/*     */   public DOMWriter(Writer writer, boolean canonical)
/*     */   {
/*  53 */     this.out = new PrintWriter(writer);
/*  54 */     this.canonical = canonical;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static String getWriterEncoding()
/*     */   {
/*  65 */     return "UTF8";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void print(Node node)
/*     */   {
/*  76 */     if (node == null) {
/*  77 */       return;
/*     */     }
/*     */     
/*  80 */     int type = node.getNodeType();
/*  81 */     switch (type)
/*     */     {
/*     */     case 9: 
/*  84 */       if (!this.canonical) {
/*  85 */         this.out.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
/*     */       }
/*  87 */       print(((Document)node).getDocumentElement());
/*  88 */       this.out.flush();
/*  89 */       break;
/*     */     
/*     */ 
/*     */     case 1: 
/*  93 */       this.out.print('<');
/*  94 */       this.out.print(node.getLocalName());
/*  95 */       Attr[] attrs = sortAttributes(node.getAttributes());
/*  96 */       for (int i = 0; i < attrs.length; i++) {
/*  97 */         Attr attr = attrs[i];
/*  98 */         this.out.print(' ');
/*  99 */         this.out.print(attr.getLocalName());
/*     */         
/* 101 */         this.out.print("=\"");
/* 102 */         this.out.print(normalize(attr.getNodeValue()));
/* 103 */         this.out.print('"');
/*     */       }
/* 105 */       this.out.print('>');
/* 106 */       printChildren(node);
/* 107 */       break;
/*     */     
/*     */ 
/*     */     case 5: 
/* 111 */       if (this.canonical) {
/* 112 */         printChildren(node);
/*     */       } else {
/* 114 */         this.out.print('&');
/* 115 */         this.out.print(node.getLocalName());
/* 116 */         this.out.print(';');
/*     */       }
/* 118 */       break;
/*     */     
/*     */ 
/*     */     case 4: 
/* 122 */       if (this.canonical) {
/* 123 */         this.out.print(normalize(node.getNodeValue()));
/*     */       } else {
/* 125 */         this.out.print("<![CDATA[");
/* 126 */         this.out.print(node.getNodeValue());
/* 127 */         this.out.print("]]>");
/*     */       }
/* 129 */       break;
/*     */     
/*     */ 
/*     */     case 3: 
/* 133 */       this.out.print(normalize(node.getNodeValue()));
/* 134 */       break;
/*     */     
/*     */ 
/*     */     case 7: 
/* 138 */       this.out.print("<?");
/* 139 */       this.out.print(node.getLocalName());
/*     */       
/* 141 */       String data = node.getNodeValue();
/* 142 */       if ((data != null) && (data.length() > 0)) {
/* 143 */         this.out.print(' ');
/* 144 */         this.out.print(data);
/*     */       }
/* 146 */       this.out.print("?>");
/*     */     }
/*     */     
/*     */     
/* 150 */     if (type == 1) {
/* 151 */       this.out.print("</");
/* 152 */       this.out.print(node.getLocalName());
/* 153 */       this.out.print('>');
/*     */     }
/*     */     
/* 156 */     this.out.flush();
/*     */   }
/*     */   
/*     */ 
/*     */   private void printChildren(Node node)
/*     */   {
/* 162 */     NodeList children = node.getChildNodes();
/* 163 */     if (children != null) {
/* 164 */       int len = children.getLength();
/* 165 */       for (int i = 0; i < len; i++) {
/* 166 */         print(children.item(i));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected Attr[] sortAttributes(NamedNodeMap attrs)
/*     */   {
/* 181 */     if (attrs == null) {
/* 182 */       return new Attr[0];
/*     */     }
/*     */     
/* 185 */     int len = attrs.getLength();
/* 186 */     Attr[] array = new Attr[len];
/* 187 */     for (int i = 0; i < len; i++) {
/* 188 */       array[i] = ((Attr)attrs.item(i));
/*     */     }
/* 190 */     for (int i = 0; i < len - 1; i++) {
/* 191 */       String name = null;
/* 192 */       name = array[i].getLocalName();
/* 193 */       int index = i;
/* 194 */       for (int j = i + 1; j < len; j++) {
/* 195 */         String curName = null;
/* 196 */         curName = array[j].getLocalName();
/* 197 */         if (curName.compareTo(name) < 0) {
/* 198 */           name = curName;
/* 199 */           index = j;
/*     */         }
/*     */       }
/* 202 */       if (index != i) {
/* 203 */         Attr temp = array[i];
/* 204 */         array[i] = array[index];
/* 205 */         array[index] = temp;
/*     */       }
/*     */     }
/*     */     
/* 209 */     return array;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected String normalize(String s)
/*     */   {
/* 222 */     if (s == null) {
/* 223 */       return "";
/*     */     }
/*     */     
/* 226 */     StringBuilder str = new StringBuilder();
/*     */     
/* 228 */     int len = s.length();
/* 229 */     for (int i = 0; i < len; i++) {
/* 230 */       char ch = s.charAt(i);
/* 231 */       switch (ch) {
/*     */       case '<': 
/* 233 */         str.append("&lt;");
/* 234 */         break;
/*     */       case '>': 
/* 236 */         str.append("&gt;");
/* 237 */         break;
/*     */       case '&': 
/* 239 */         str.append("&amp;");
/* 240 */         break;
/*     */       case '"': 
/* 242 */         str.append("&quot;");
/* 243 */         break;
/*     */       case '\n': 
/*     */       case '\r': 
/* 246 */         if (this.canonical) {
/* 247 */           str.append("&#");
/* 248 */           str.append(Integer.toString(ch));
/* 249 */           str.append(';'); }
/* 250 */         break;
/*     */       }
/*     */       
/*     */       
/*     */ 
/* 255 */       str.append(ch);
/*     */     }
/*     */     
/*     */ 
/* 259 */     return str.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\util\DOMWriter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */