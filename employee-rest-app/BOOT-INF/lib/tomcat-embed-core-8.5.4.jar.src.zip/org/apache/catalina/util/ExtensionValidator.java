/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.jar.JarInputStream;
/*     */ import java.util.jar.Manifest;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExtensionValidator
/*     */ {
/*  51 */   private static final Log log = LogFactory.getLog(ExtensionValidator.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  56 */   private static final StringManager sm = StringManager.getManager("org.apache.catalina.util");
/*     */   
/*     */ 
/*  59 */   private static volatile ArrayList<Extension> containerAvailableExtensions = null;
/*     */   
/*  61 */   private static final ArrayList<ManifestResource> containerManifestResources = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  79 */     String systemClasspath = System.getProperty("java.class.path");
/*     */     
/*  81 */     StringTokenizer strTok = new StringTokenizer(systemClasspath, File.pathSeparator);
/*     */     
/*     */ 
/*     */ 
/*  85 */     while (strTok.hasMoreTokens()) {
/*  86 */       String classpathItem = strTok.nextToken();
/*  87 */       if (classpathItem.toLowerCase(Locale.ENGLISH).endsWith(".jar")) {
/*  88 */         File item = new File(classpathItem);
/*  89 */         if (item.isFile()) {
/*     */           try {
/*  91 */             addSystemResource(item);
/*     */           } catch (IOException e) {
/*  93 */             log.error(sm.getString("extensionValidator.failload", new Object[] { item }), e);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 101 */     addFolderList("java.ext.dirs");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized boolean validateApplication(WebResourceRoot resources, Context context)
/*     */     throws IOException
/*     */   {
/* 131 */     String appName = context.getName();
/* 132 */     ArrayList<ManifestResource> appManifestResources = new ArrayList();
/*     */     
/*     */ 
/* 135 */     WebResource resource = resources.getResource("/META-INF/MANIFEST.MF");
/* 136 */     if (resource.isFile()) {
/* 137 */       InputStream inputStream = resource.getInputStream();Throwable localThrowable3 = null;
/* 138 */       try { Manifest manifest = new Manifest(inputStream);
/* 139 */         ManifestResource mre = new ManifestResource(sm.getString("extensionValidator.web-application-manifest"), manifest, 2);
/*     */         
/*     */ 
/* 142 */         appManifestResources.add(mre);
/*     */       }
/*     */       catch (Throwable localThrowable1)
/*     */       {
/* 137 */         localThrowable3 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */       }
/*     */       finally
/*     */       {
/*     */ 
/* 143 */         if (inputStream != null) if (localThrowable3 != null) try { inputStream.close(); } catch (Throwable x2) { localThrowable3.addSuppressed(x2); } else { inputStream.close();
/*     */           }
/*     */       }
/*     */     }
/* 147 */     WebResource[] manifestResources = resources.getClassLoaderResources("/META-INF/MANIFEST.MF");
/*     */     
/* 149 */     for (WebResource manifestResource : manifestResources) {
/* 150 */       if (manifestResource.isFile())
/*     */       {
/* 152 */         String jarName = manifestResource.getURL().toExternalForm();
/* 153 */         Manifest jmanifest = null;
/* 154 */         InputStream is = manifestResource.getInputStream();Throwable localThrowable4 = null;
/* 155 */         try { jmanifest = new Manifest(is);
/* 156 */           ManifestResource mre = new ManifestResource(jarName, jmanifest, 3);
/*     */           
/* 158 */           appManifestResources.add(mre);
/*     */         }
/*     */         catch (Throwable localThrowable2)
/*     */         {
/* 154 */           localThrowable4 = localThrowable2;throw localThrowable2;
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/* 159 */           if (is != null) if (localThrowable4 != null) try { is.close(); } catch (Throwable x2) { localThrowable4.addSuppressed(x2); } else is.close();
/*     */         }
/*     */       }
/*     */     }
/* 163 */     return validateManifestResources(appName, appManifestResources);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void addSystemResource(File jarFile)
/*     */     throws IOException
/*     */   {
/* 175 */     InputStream is = new FileInputStream(jarFile);Throwable localThrowable2 = null;
/* 176 */     try { Manifest manifest = getManifest(is);
/* 177 */       if (manifest != null) {
/* 178 */         ManifestResource mre = new ManifestResource(jarFile.getAbsolutePath(), manifest, 1);
/*     */         
/* 180 */         containerManifestResources.add(mre);
/*     */       }
/*     */     }
/*     */     catch (Throwable localThrowable1)
/*     */     {
/* 175 */       localThrowable2 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/* 182 */       if (is != null) { if (localThrowable2 != null) try { is.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else { is.close();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean validateManifestResources(String appName, ArrayList<ManifestResource> resources)
/*     */   {
/* 210 */     boolean passes = true;
/* 211 */     int failureCount = 0;
/* 212 */     ArrayList<Extension> availableExtensions = null;
/*     */     
/* 214 */     Iterator<ManifestResource> it = resources.iterator();
/* 215 */     while (it.hasNext()) {
/* 216 */       ManifestResource mre = (ManifestResource)it.next();
/* 217 */       ArrayList<Extension> requiredList = mre.getRequiredExtensions();
/* 218 */       if (requiredList != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 223 */         if (availableExtensions == null) {
/* 224 */           availableExtensions = buildAvailableExtensionsList(resources);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 229 */         if (containerAvailableExtensions == null) {
/* 230 */           containerAvailableExtensions = buildAvailableExtensionsList(containerManifestResources);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 235 */         Iterator<Extension> rit = requiredList.iterator();
/* 236 */         while (rit.hasNext()) {
/* 237 */           boolean found = false;
/* 238 */           Extension requiredExt = (Extension)rit.next();
/*     */           
/* 240 */           if (availableExtensions != null) {
/* 241 */             Iterator<Extension> ait = availableExtensions.iterator();
/* 242 */             while (ait.hasNext()) {
/* 243 */               Extension targetExt = (Extension)ait.next();
/* 244 */               if (targetExt.isCompatibleWith(requiredExt)) {
/* 245 */                 requiredExt.setFulfilled(true);
/* 246 */                 found = true;
/* 247 */                 break;
/*     */               }
/*     */             }
/*     */           }
/*     */           
/* 252 */           if ((!found) && (containerAvailableExtensions != null)) {
/* 253 */             Iterator<Extension> cit = containerAvailableExtensions.iterator();
/*     */             
/* 255 */             while (cit.hasNext()) {
/* 256 */               Extension targetExt = (Extension)cit.next();
/* 257 */               if (targetExt.isCompatibleWith(requiredExt)) {
/* 258 */                 requiredExt.setFulfilled(true);
/* 259 */                 found = true;
/* 260 */                 break;
/*     */               }
/*     */             }
/*     */           }
/* 264 */           if (!found)
/*     */           {
/* 266 */             log.info(sm.getString("extensionValidator.extension-not-found-error", new Object[] { appName, mre.getResourceName(), requiredExt.getExtensionName() }));
/*     */             
/*     */ 
/*     */ 
/* 270 */             passes = false;
/* 271 */             failureCount++;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 276 */     if (!passes) {
/* 277 */       log.info(sm.getString("extensionValidator.extension-validation-error", new Object[] { appName, failureCount + "" }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 282 */     return passes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ArrayList<Extension> buildAvailableExtensionsList(ArrayList<ManifestResource> resources)
/*     */   {
/* 305 */     ArrayList<Extension> availableList = null;
/*     */     
/* 307 */     Iterator<ManifestResource> it = resources.iterator();
/* 308 */     while (it.hasNext()) {
/* 309 */       ManifestResource mre = (ManifestResource)it.next();
/* 310 */       ArrayList<Extension> list = mre.getAvailableExtensions();
/* 311 */       if (list != null) {
/* 312 */         Iterator<Extension> values = list.iterator();
/* 313 */         while (values.hasNext()) {
/* 314 */           Extension ext = (Extension)values.next();
/* 315 */           if (availableList == null) {
/* 316 */             availableList = new ArrayList();
/* 317 */             availableList.add(ext);
/*     */           } else {
/* 319 */             availableList.add(ext);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 325 */     return availableList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Manifest getManifest(InputStream inStream)
/*     */     throws IOException
/*     */   {
/* 335 */     Manifest manifest = null;
/* 336 */     JarInputStream jin = new JarInputStream(inStream);Throwable localThrowable2 = null;
/* 337 */     try { manifest = jin.getManifest();
/*     */     }
/*     */     catch (Throwable localThrowable1)
/*     */     {
/* 336 */       localThrowable2 = localThrowable1;throw localThrowable1;
/*     */     } finally {
/* 338 */       if (jin != null) if (localThrowable2 != null) try { jin.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else jin.close(); }
/* 339 */     return manifest;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void addFolderList(String property)
/*     */   {
/* 349 */     String extensionsDir = System.getProperty(property);
/* 350 */     if (extensionsDir != null) {
/* 351 */       StringTokenizer extensionsTok = new StringTokenizer(extensionsDir, File.pathSeparator);
/*     */       
/* 353 */       while (extensionsTok.hasMoreTokens()) {
/* 354 */         File targetDir = new File(extensionsTok.nextToken());
/* 355 */         if (targetDir.isDirectory())
/*     */         {
/*     */ 
/* 358 */           File[] files = targetDir.listFiles();
/* 359 */           if (files != null)
/*     */           {
/*     */ 
/* 362 */             for (int i = 0; i < files.length; i++) {
/* 363 */               if ((files[i].getName().toLowerCase(Locale.ENGLISH).endsWith(".jar")) && (files[i].isFile())) {
/*     */                 try
/*     */                 {
/* 366 */                   addSystemResource(files[i]);
/*     */                 } catch (IOException e) {
/* 368 */                   log.error(sm.getString("extensionValidator.failload", new Object[] { files[i] }), e);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\util\ExtensionValidator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */