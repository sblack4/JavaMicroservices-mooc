/*    */ package org.apache.catalina.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RequestUtil
/*    */ {
/*    */   public static String filter(String message)
/*    */   {
/* 38 */     if (message == null) {
/* 39 */       return null;
/*    */     }
/*    */     
/* 42 */     char[] content = new char[message.length()];
/* 43 */     message.getChars(0, message.length(), content, 0);
/* 44 */     StringBuilder result = new StringBuilder(content.length + 50);
/* 45 */     for (int i = 0; i < content.length; i++) {
/* 46 */       switch (content[i]) {
/*    */       case '<': 
/* 48 */         result.append("&lt;");
/* 49 */         break;
/*    */       case '>': 
/* 51 */         result.append("&gt;");
/* 52 */         break;
/*    */       case '&': 
/* 54 */         result.append("&amp;");
/* 55 */         break;
/*    */       case '"': 
/* 57 */         result.append("&quot;");
/* 58 */         break;
/*    */       default: 
/* 60 */         result.append(content[i]);
/*    */       }
/*    */     }
/* 63 */     return result.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\util\RequestUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */