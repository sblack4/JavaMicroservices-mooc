/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import org.apache.catalina.Lifecycle;
/*     */ import org.apache.catalina.Lifecycle.SingleUse;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LifecycleBase
/*     */   implements Lifecycle
/*     */ {
/*  41 */   private static final Log log = LogFactory.getLog(LifecycleBase.class);
/*     */   
/*  43 */   private static final StringManager sm = StringManager.getManager(LifecycleBase.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  49 */   private final List<LifecycleListener> lifecycleListeners = new CopyOnWriteArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  55 */   private volatile LifecycleState state = LifecycleState.NEW;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addLifecycleListener(LifecycleListener listener)
/*     */   {
/*  63 */     this.lifecycleListeners.add(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LifecycleListener[] findLifecycleListeners()
/*     */   {
/*  72 */     return (LifecycleListener[])this.lifecycleListeners.toArray(new LifecycleListener[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeLifecycleListener(LifecycleListener listener)
/*     */   {
/*  81 */     this.lifecycleListeners.remove(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void fireLifecycleEvent(String type, Object data)
/*     */   {
/*  92 */     LifecycleEvent event = new LifecycleEvent(this, type, data);
/*  93 */     for (LifecycleListener listener : this.lifecycleListeners) {
/*  94 */       listener.lifecycleEvent(event);
/*     */     }
/*     */   }
/*     */   
/*     */   public final synchronized void init()
/*     */     throws LifecycleException
/*     */   {
/* 101 */     if (!this.state.equals(LifecycleState.NEW)) {
/* 102 */       invalidTransition("before_init");
/*     */     }
/* 104 */     setStateInternal(LifecycleState.INITIALIZING, null, false);
/*     */     try
/*     */     {
/* 107 */       initInternal();
/*     */     } catch (Throwable t) {
/* 109 */       ExceptionUtils.handleThrowable(t);
/* 110 */       setStateInternal(LifecycleState.FAILED, null, false);
/* 111 */       throw new LifecycleException(sm.getString("lifecycleBase.initFail", new Object[] { toString() }), t);
/*     */     }
/*     */     
/*     */ 
/* 115 */     setStateInternal(LifecycleState.INITIALIZED, null, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract void initInternal()
/*     */     throws LifecycleException;
/*     */   
/*     */ 
/*     */   public final synchronized void start()
/*     */     throws LifecycleException
/*     */   {
/* 127 */     if ((LifecycleState.STARTING_PREP.equals(this.state)) || (LifecycleState.STARTING.equals(this.state)) || (LifecycleState.STARTED.equals(this.state)))
/*     */     {
/*     */ 
/* 130 */       if (log.isDebugEnabled()) {
/* 131 */         Exception e = new LifecycleException();
/* 132 */         log.debug(sm.getString("lifecycleBase.alreadyStarted", new Object[] { toString() }), e);
/* 133 */       } else if (log.isInfoEnabled()) {
/* 134 */         log.info(sm.getString("lifecycleBase.alreadyStarted", new Object[] { toString() }));
/*     */       }
/*     */       
/* 137 */       return;
/*     */     }
/*     */     
/* 140 */     if (this.state.equals(LifecycleState.NEW)) {
/* 141 */       init();
/* 142 */     } else if (this.state.equals(LifecycleState.FAILED)) {
/* 143 */       stop();
/* 144 */     } else if ((!this.state.equals(LifecycleState.INITIALIZED)) && (!this.state.equals(LifecycleState.STOPPED)))
/*     */     {
/* 146 */       invalidTransition("before_start");
/*     */     }
/*     */     
/* 149 */     setStateInternal(LifecycleState.STARTING_PREP, null, false);
/*     */     try
/*     */     {
/* 152 */       startInternal();
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 156 */       ExceptionUtils.handleThrowable(t);
/* 157 */       setStateInternal(LifecycleState.FAILED, null, false);
/* 158 */       throw new LifecycleException(sm.getString("lifecycleBase.startFail", new Object[] { toString() }), t);
/*     */     }
/*     */     
/* 161 */     if (this.state.equals(LifecycleState.FAILED))
/*     */     {
/*     */ 
/* 164 */       stop();
/* 165 */     } else if (!this.state.equals(LifecycleState.STARTING))
/*     */     {
/*     */ 
/* 168 */       invalidTransition("after_start");
/*     */     } else {
/* 170 */       setStateInternal(LifecycleState.STARTED, null, false);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void startInternal()
/*     */     throws LifecycleException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final synchronized void stop()
/*     */     throws LifecycleException
/*     */   {
/* 197 */     if ((LifecycleState.STOPPING_PREP.equals(this.state)) || (LifecycleState.STOPPING.equals(this.state)) || (LifecycleState.STOPPED.equals(this.state)))
/*     */     {
/*     */ 
/* 200 */       if (log.isDebugEnabled()) {
/* 201 */         Exception e = new LifecycleException();
/* 202 */         log.debug(sm.getString("lifecycleBase.alreadyStopped", new Object[] { toString() }), e);
/* 203 */       } else if (log.isInfoEnabled()) {
/* 204 */         log.info(sm.getString("lifecycleBase.alreadyStopped", new Object[] { toString() }));
/*     */       }
/*     */       
/* 207 */       return;
/*     */     }
/*     */     
/* 210 */     if (this.state.equals(LifecycleState.NEW)) {
/* 211 */       this.state = LifecycleState.STOPPED;
/* 212 */       return;
/*     */     }
/*     */     
/* 215 */     if ((!this.state.equals(LifecycleState.STARTED)) && (!this.state.equals(LifecycleState.FAILED))) {
/* 216 */       invalidTransition("before_stop");
/*     */     }
/*     */     
/* 219 */     if (this.state.equals(LifecycleState.FAILED))
/*     */     {
/*     */ 
/*     */ 
/* 223 */       fireLifecycleEvent("before_stop", null);
/*     */     } else {
/* 225 */       setStateInternal(LifecycleState.STOPPING_PREP, null, false);
/*     */     }
/*     */     try
/*     */     {
/* 229 */       stopInternal();
/*     */     } catch (Throwable t) {
/* 231 */       ExceptionUtils.handleThrowable(t);
/* 232 */       setStateInternal(LifecycleState.FAILED, null, false);
/* 233 */       throw new LifecycleException(sm.getString("lifecycleBase.stopFail", new Object[] { toString() }), t);
/*     */     } finally {
/* 235 */       if ((this instanceof Lifecycle.SingleUse))
/*     */       {
/* 237 */         setStateInternal(LifecycleState.STOPPED, null, false);
/* 238 */         destroy();
/* 239 */         return;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 245 */     if ((!this.state.equals(LifecycleState.STOPPING)) && (!this.state.equals(LifecycleState.FAILED))) {
/* 246 */       invalidTransition("after_stop");
/*     */     }
/*     */     
/* 249 */     setStateInternal(LifecycleState.STOPPED, null, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void stopInternal()
/*     */     throws LifecycleException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final synchronized void destroy()
/*     */     throws LifecycleException
/*     */   {
/* 265 */     if (LifecycleState.FAILED.equals(this.state)) {
/*     */       try
/*     */       {
/* 268 */         stop();
/*     */       }
/*     */       catch (LifecycleException e) {
/* 271 */         log.warn(sm.getString("lifecycleBase.destroyStopFail", new Object[] { toString() }), e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 276 */     if ((LifecycleState.DESTROYING.equals(this.state)) || (LifecycleState.DESTROYED.equals(this.state)))
/*     */     {
/*     */ 
/* 279 */       if (log.isDebugEnabled()) {
/* 280 */         Exception e = new LifecycleException();
/* 281 */         log.debug(sm.getString("lifecycleBase.alreadyDestroyed", new Object[] { toString() }), e);
/* 282 */       } else if ((log.isInfoEnabled()) && (!(this instanceof Lifecycle.SingleUse)))
/*     */       {
/*     */ 
/*     */ 
/* 286 */         log.info(sm.getString("lifecycleBase.alreadyDestroyed", new Object[] { toString() }));
/*     */       }
/*     */       
/* 289 */       return;
/*     */     }
/*     */     
/* 292 */     if ((!this.state.equals(LifecycleState.STOPPED)) && (!this.state.equals(LifecycleState.FAILED)) && (!this.state.equals(LifecycleState.NEW)) && (!this.state.equals(LifecycleState.INITIALIZED)))
/*     */     {
/*     */ 
/*     */ 
/* 296 */       invalidTransition("before_destroy");
/*     */     }
/*     */     
/* 299 */     setStateInternal(LifecycleState.DESTROYING, null, false);
/*     */     try
/*     */     {
/* 302 */       destroyInternal();
/*     */     } catch (Throwable t) {
/* 304 */       ExceptionUtils.handleThrowable(t);
/* 305 */       setStateInternal(LifecycleState.FAILED, null, false);
/* 306 */       throw new LifecycleException(sm.getString("lifecycleBase.destroyFail", new Object[] { toString() }), t);
/*     */     }
/*     */     
/*     */ 
/* 310 */     setStateInternal(LifecycleState.DESTROYED, null, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract void destroyInternal()
/*     */     throws LifecycleException;
/*     */   
/*     */ 
/*     */   public LifecycleState getState()
/*     */   {
/* 321 */     return this.state;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getStateName()
/*     */   {
/* 330 */     return getState().toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void setState(LifecycleState state)
/*     */     throws LifecycleException
/*     */   {
/* 345 */     setStateInternal(state, null, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void setState(LifecycleState state, Object data)
/*     */     throws LifecycleException
/*     */   {
/* 361 */     setStateInternal(state, data, true);
/*     */   }
/*     */   
/*     */   private synchronized void setStateInternal(LifecycleState state, Object data, boolean check)
/*     */     throws LifecycleException
/*     */   {
/* 367 */     if (log.isDebugEnabled()) {
/* 368 */       log.debug(sm.getString("lifecycleBase.setState", new Object[] { this, state }));
/*     */     }
/*     */     
/* 371 */     if (check)
/*     */     {
/*     */ 
/*     */ 
/* 375 */       if (state == null) {
/* 376 */         invalidTransition("null");
/*     */         
/*     */ 
/* 379 */         return;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 386 */       if ((state != LifecycleState.FAILED) && ((this.state != LifecycleState.STARTING_PREP) || (state != LifecycleState.STARTING)) && ((this.state != LifecycleState.STOPPING_PREP) || (state != LifecycleState.STOPPING)) && ((this.state != LifecycleState.FAILED) || (state != LifecycleState.STOPPING)))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 394 */         invalidTransition(state.name());
/*     */       }
/*     */     }
/*     */     
/* 398 */     this.state = state;
/* 399 */     String lifecycleEvent = state.getLifecycleEvent();
/* 400 */     if (lifecycleEvent != null) {
/* 401 */       fireLifecycleEvent(lifecycleEvent, data);
/*     */     }
/*     */   }
/*     */   
/*     */   private void invalidTransition(String type) throws LifecycleException {
/* 406 */     String msg = sm.getString("lifecycleBase.invalidTransition", new Object[] { type, toString(), this.state });
/*     */     
/* 408 */     throw new LifecycleException(msg);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\util\LifecycleBase.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */