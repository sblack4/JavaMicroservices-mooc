/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.util.BitSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class URLEncoder
/*     */ {
/*  37 */   private static final char[] hexadecimal = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*     */   
/*     */ 
/*     */ 
/*  41 */   public static final URLEncoder DEFAULT = new URLEncoder();
/*     */   
/*  43 */   static { DEFAULT.addSafeCharacter('~');
/*  44 */     DEFAULT.addSafeCharacter('-');
/*  45 */     DEFAULT.addSafeCharacter('_');
/*  46 */     DEFAULT.addSafeCharacter('.');
/*  47 */     DEFAULT.addSafeCharacter('*');
/*  48 */     DEFAULT.addSafeCharacter('/');
/*     */   }
/*     */   
/*     */ 
/*  52 */   protected final BitSet safeCharacters = new BitSet(256);
/*     */   
/*     */   public URLEncoder() {
/*  55 */     for (char i = 'a'; i <= 'z'; i = (char)(i + '\001')) {
/*  56 */       addSafeCharacter(i);
/*     */     }
/*  58 */     for (char i = 'A'; i <= 'Z'; i = (char)(i + '\001')) {
/*  59 */       addSafeCharacter(i);
/*     */     }
/*  61 */     for (char i = '0'; i <= '9'; i = (char)(i + '\001')) {
/*  62 */       addSafeCharacter(i);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addSafeCharacter(char c) {
/*  67 */     this.safeCharacters.set(c);
/*     */   }
/*     */   
/*     */   public String encode(String path) {
/*  71 */     int maxBytesPerChar = 10;
/*  72 */     StringBuilder rewrittenPath = new StringBuilder(path.length());
/*  73 */     ByteArrayOutputStream buf = new ByteArrayOutputStream(maxBytesPerChar);
/*  74 */     OutputStreamWriter writer = null;
/*     */     try {
/*  76 */       writer = new OutputStreamWriter(buf, "UTF8");
/*     */     } catch (Exception e) {
/*  78 */       e.printStackTrace();
/*  79 */       writer = new OutputStreamWriter(buf);
/*     */     }
/*     */     
/*  82 */     for (int i = 0; i < path.length(); i++) {
/*  83 */       int c = path.charAt(i);
/*  84 */       if (this.safeCharacters.get(c)) {
/*  85 */         rewrittenPath.append((char)c);
/*     */       }
/*     */       else {
/*     */         try {
/*  89 */           writer.write((char)c);
/*  90 */           writer.flush();
/*     */         } catch (IOException e) {
/*  92 */           buf.reset();
/*  93 */           continue;
/*     */         }
/*  95 */         byte[] ba = buf.toByteArray();
/*  96 */         for (int j = 0; j < ba.length; j++)
/*     */         {
/*  98 */           byte toEncode = ba[j];
/*  99 */           rewrittenPath.append('%');
/* 100 */           int low = toEncode & 0xF;
/* 101 */           int high = (toEncode & 0xF0) >> 4;
/* 102 */           rewrittenPath.append(hexadecimal[high]);
/* 103 */           rewrittenPath.append(hexadecimal[low]);
/*     */         }
/* 105 */         buf.reset();
/*     */       }
/*     */     }
/* 108 */     return rewrittenPath.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\util\URLEncoder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */