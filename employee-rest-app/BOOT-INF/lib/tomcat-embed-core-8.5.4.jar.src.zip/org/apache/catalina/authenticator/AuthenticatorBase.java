/*      */ package org.apache.catalina.authenticator;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.security.Principal;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.Date;
/*      */ import java.util.Iterator;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javax.security.auth.Subject;
/*      */ import javax.security.auth.message.AuthException;
/*      */ import javax.security.auth.message.AuthStatus;
/*      */ import javax.security.auth.message.MessageInfo;
/*      */ import javax.security.auth.message.config.AuthConfigFactory;
/*      */ import javax.security.auth.message.config.AuthConfigProvider;
/*      */ import javax.security.auth.message.config.RegistrationListener;
/*      */ import javax.security.auth.message.config.ServerAuthConfig;
/*      */ import javax.security.auth.message.config.ServerAuthContext;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.SessionCookieConfig;
/*      */ import javax.servlet.http.Cookie;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import org.apache.catalina.Authenticator;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.Pipeline;
/*      */ import org.apache.catalina.Realm;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.catalina.Valve;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.authenticator.jaspic.CallbackHandlerImpl;
/*      */ import org.apache.catalina.authenticator.jaspic.MessageInfoImpl;
/*      */ import org.apache.catalina.connector.Response;
/*      */ import org.apache.catalina.mapper.MappingData;
/*      */ import org.apache.catalina.realm.GenericPrincipal;
/*      */ import org.apache.catalina.util.SessionIdGeneratorBase;
/*      */ import org.apache.catalina.util.StandardSessionIdGenerator;
/*      */ import org.apache.catalina.valves.ValveBase;
/*      */ import org.apache.coyote.ActionCode;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.buf.MessageBytes;
/*      */ import org.apache.tomcat.util.descriptor.web.LoginConfig;
/*      */ import org.apache.tomcat.util.descriptor.web.SecurityConstraint;
/*      */ import org.apache.tomcat.util.http.MimeHeaders;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AuthenticatorBase
/*      */   extends ValveBase
/*      */   implements Authenticator, RegistrationListener
/*      */ {
/*   90 */   private static final Log log = LogFactory.getLog(AuthenticatorBase.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   95 */   private static final String DATE_ONE = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US).format(new Date(1L));
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  101 */   protected static final StringManager sm = StringManager.getManager(AuthenticatorBase.class);
/*      */   
/*      */ 
/*      */ 
/*      */   protected static final String AUTH_HEADER_NAME = "WWW-Authenticate";
/*      */   
/*      */ 
/*      */   protected static final String REALM_NAME = "Authentication required";
/*      */   
/*      */ 
/*      */ 
/*      */   protected static String getRealmName(Context context)
/*      */   {
/*  114 */     if (context == null)
/*      */     {
/*  116 */       return "Authentication required";
/*      */     }
/*      */     
/*  119 */     LoginConfig config = context.getLoginConfig();
/*  120 */     if (config == null) {
/*  121 */       return "Authentication required";
/*      */     }
/*      */     
/*  124 */     String result = config.getRealmName();
/*  125 */     if (result == null) {
/*  126 */       return "Authentication required";
/*      */     }
/*      */     
/*  129 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */   public AuthenticatorBase()
/*      */   {
/*  135 */     super(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  150 */   protected boolean alwaysUseSession = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  156 */   protected boolean cache = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  162 */   protected boolean changeSessionIdOnAuthentication = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  167 */   protected Context context = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  173 */   protected boolean disableProxyCaching = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  179 */   protected boolean securePagesWithPragma = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  188 */   protected String secureRandomClass = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  199 */   protected String secureRandomAlgorithm = "SHA1PRNG";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  209 */   protected String secureRandomProvider = null;
/*      */   
/*  211 */   protected SessionIdGeneratorBase sessionIdGenerator = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  217 */   protected SingleSignOn sso = null;
/*      */   
/*  219 */   private volatile String jaspicAppContextID = null;
/*  220 */   private volatile AuthConfigProvider jaspicProvider = null;
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getAlwaysUseSession()
/*      */   {
/*  226 */     return this.alwaysUseSession;
/*      */   }
/*      */   
/*      */   public void setAlwaysUseSession(boolean alwaysUseSession) {
/*  230 */     this.alwaysUseSession = alwaysUseSession;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getCache()
/*      */   {
/*  240 */     return this.cache;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCache(boolean cache)
/*      */   {
/*  250 */     this.cache = cache;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Container getContainer()
/*      */   {
/*  258 */     return this.context;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setContainer(Container container)
/*      */   {
/*  270 */     if ((container != null) && (!(container instanceof Context))) {
/*  271 */       throw new IllegalArgumentException(sm.getString("authenticator.notContext"));
/*      */     }
/*      */     
/*  274 */     super.setContainer(container);
/*  275 */     this.context = ((Context)container);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getDisableProxyCaching()
/*      */   {
/*  287 */     return this.disableProxyCaching;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDisableProxyCaching(boolean nocache)
/*      */   {
/*  299 */     this.disableProxyCaching = nocache;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getSecurePagesWithPragma()
/*      */   {
/*  310 */     return this.securePagesWithPragma;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecurePagesWithPragma(boolean securePagesWithPragma)
/*      */   {
/*  323 */     this.securePagesWithPragma = securePagesWithPragma;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getChangeSessionIdOnAuthentication()
/*      */   {
/*  334 */     return this.changeSessionIdOnAuthentication;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setChangeSessionIdOnAuthentication(boolean changeSessionIdOnAuthentication)
/*      */   {
/*  346 */     this.changeSessionIdOnAuthentication = changeSessionIdOnAuthentication;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSecureRandomClass()
/*      */   {
/*  356 */     return this.secureRandomClass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecureRandomClass(String secureRandomClass)
/*      */   {
/*  366 */     this.secureRandomClass = secureRandomClass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSecureRandomAlgorithm()
/*      */   {
/*  375 */     return this.secureRandomAlgorithm;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecureRandomAlgorithm(String secureRandomAlgorithm)
/*      */   {
/*  385 */     this.secureRandomAlgorithm = secureRandomAlgorithm;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSecureRandomProvider()
/*      */   {
/*  394 */     return this.secureRandomProvider;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecureRandomProvider(String secureRandomProvider)
/*      */   {
/*  404 */     this.secureRandomProvider = secureRandomProvider;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void invoke(org.apache.catalina.connector.Request request, Response response)
/*      */     throws IOException, ServletException
/*      */   {
/*  426 */     if (log.isDebugEnabled()) {
/*  427 */       log.debug("Security checking request " + request.getMethod() + " " + request.getRequestURI());
/*      */     }
/*      */     
/*      */ 
/*  431 */     AuthConfigProvider jaspicProvider = getJaspicProvider();
/*  432 */     MessageInfo messageInfo = null;
/*  433 */     ServerAuthContext serverAuthContext = null;
/*      */     
/*      */ 
/*  436 */     if (this.cache) {
/*  437 */       Principal principal = request.getUserPrincipal();
/*  438 */       if (principal == null) {
/*  439 */         Session session = request.getSessionInternal(false);
/*  440 */         if (session != null) {
/*  441 */           principal = session.getPrincipal();
/*  442 */           if (principal != null) {
/*  443 */             if (log.isDebugEnabled()) {
/*  444 */               log.debug("We have cached auth type " + session.getAuthType() + " for principal " + session.getPrincipal());
/*      */             }
/*      */             
/*  447 */             request.setAuthType(session.getAuthType());
/*  448 */             request.setUserPrincipal(principal);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  454 */     if (jaspicProvider != null) {
/*  455 */       messageInfo = new MessageInfoImpl(request.getRequest(), response.getResponse(), true);
/*      */       try {
/*  457 */         ServerAuthConfig serverAuthConfig = jaspicProvider.getServerAuthConfig("HttpServlet", this.jaspicAppContextID, CallbackHandlerImpl.getInstance());
/*      */         
/*  459 */         String authContextID = serverAuthConfig.getAuthContextID(messageInfo);
/*  460 */         serverAuthContext = serverAuthConfig.getAuthContext(authContextID, null, null);
/*      */       } catch (AuthException e) {
/*  462 */         log.warn(sm.getString("authenticator.jaspicServerAuthContextFail"), e);
/*  463 */         response.sendError(500);
/*  464 */         return;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  471 */     String contextPath = this.context.getPath();
/*  472 */     String decodedRequestURI = request.getDecodedRequestURI();
/*  473 */     if ((decodedRequestURI.startsWith(contextPath)) && (decodedRequestURI.endsWith("/j_security_check")))
/*      */     {
/*  475 */       if (!authenticate(request, response, serverAuthContext, messageInfo)) {
/*  476 */         if (log.isDebugEnabled()) {
/*  477 */           log.debug(" Failed authenticate() test ??" + decodedRequestURI);
/*      */         }
/*  479 */         return;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  489 */     Session session = request.getSessionInternal(false);
/*  490 */     if (session != null) {
/*  491 */       SavedRequest savedRequest = (SavedRequest)session.getNote("org.apache.catalina.authenticator.REQUEST");
/*  492 */       if ((savedRequest != null) && (decodedRequestURI.equals(savedRequest.getDecodedRequestURI())) && (!authenticate(request, response)))
/*      */       {
/*      */ 
/*  495 */         if (log.isDebugEnabled()) {
/*  496 */           log.debug(" Failed authenticate() test");
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  502 */         return;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  508 */     Wrapper wrapper = request.getMappingData().wrapper;
/*  509 */     if (wrapper != null) {
/*  510 */       wrapper.servletSecurityAnnotationScan();
/*      */     }
/*      */     
/*  513 */     Realm realm = this.context.getRealm();
/*      */     
/*  515 */     SecurityConstraint[] constraints = realm.findSecurityConstraints(request, this.context);
/*      */     
/*  517 */     if ((constraints == null) && (!this.context.getPreemptiveAuthentication()) && (jaspicProvider == null))
/*      */     {
/*  519 */       if (log.isDebugEnabled()) {
/*  520 */         log.debug(" Not subject to any constraint");
/*      */       }
/*  522 */       getNext().invoke(request, response);
/*  523 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  528 */     if ((constraints != null) && (this.disableProxyCaching) && (!"POST".equalsIgnoreCase(request.getMethod())))
/*      */     {
/*  530 */       if (this.securePagesWithPragma)
/*      */       {
/*  532 */         response.setHeader("Pragma", "No-cache");
/*  533 */         response.setHeader("Cache-Control", "no-cache");
/*      */       } else {
/*  535 */         response.setHeader("Cache-Control", "private");
/*      */       }
/*  537 */       response.setHeader("Expires", DATE_ONE);
/*      */     }
/*      */     
/*      */ 
/*  541 */     if (constraints != null)
/*      */     {
/*  543 */       if (log.isDebugEnabled()) {
/*  544 */         log.debug(" Calling hasUserDataPermission()");
/*      */       }
/*  546 */       if (!realm.hasUserDataPermission(request, response, constraints)) {
/*  547 */         if (log.isDebugEnabled()) {
/*  548 */           log.debug(" Failed hasUserDataPermission() test");
/*      */         }
/*      */         
/*      */ 
/*      */         return;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     boolean authRequired;
/*      */     
/*      */     boolean authRequired;
/*      */     
/*  561 */     if (constraints == null) {
/*  562 */       authRequired = false;
/*      */     } else {
/*  564 */       authRequired = true;
/*  565 */       for (int i = 0; (i < constraints.length) && (authRequired); i++) {
/*  566 */         if (!constraints[i].getAuthConstraint()) {
/*  567 */           authRequired = false;
/*  568 */           break; }
/*  569 */         if ((!constraints[i].getAllRoles()) && (!constraints[i].getAuthenticatedUsers()))
/*      */         {
/*  571 */           String[] roles = constraints[i].findAuthRoles();
/*  572 */           if ((roles == null) || (roles.length == 0)) {
/*  573 */             authRequired = false;
/*  574 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  580 */     if ((!authRequired) && (this.context.getPreemptiveAuthentication())) {
/*  581 */       authRequired = request.getCoyoteRequest().getMimeHeaders().getValue("authorization") != null;
/*      */     }
/*      */     
/*      */ 
/*  585 */     if ((!authRequired) && (this.context.getPreemptiveAuthentication()) && ("CLIENT_CERT".equals(getAuthMethod())))
/*      */     {
/*  587 */       X509Certificate[] certs = getRequestCertificates(request);
/*  588 */       authRequired = (certs != null) && (certs.length > 0);
/*      */     }
/*      */     
/*  591 */     if ((!authRequired) && (jaspicProvider != null)) {
/*  592 */       authRequired = true;
/*      */     }
/*      */     
/*  595 */     if (authRequired) {
/*  596 */       if (log.isDebugEnabled()) {
/*  597 */         log.debug(" Calling authenticate()");
/*      */       }
/*  599 */       if (!authenticate(request, response, serverAuthContext, messageInfo)) {
/*  600 */         if (log.isDebugEnabled()) {
/*  601 */           log.debug(" Failed authenticate() test");
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  607 */         return;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  612 */     if (constraints != null) {
/*  613 */       if (log.isDebugEnabled()) {
/*  614 */         log.debug(" Calling accessControl()");
/*      */       }
/*  616 */       if (!realm.hasResourcePermission(request, response, constraints, this.context)) {
/*  617 */         if (log.isDebugEnabled()) {
/*  618 */           log.debug(" Failed accessControl() test");
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  624 */         return;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  629 */     if (log.isDebugEnabled()) {
/*  630 */       log.debug(" Successfully passed all security constraints");
/*      */     }
/*  632 */     getNext().invoke(request, response);
/*      */     
/*  634 */     if ((serverAuthContext != null) && (messageInfo != null)) {
/*      */       try {
/*  636 */         serverAuthContext.secureResponse(messageInfo, null);
/*  637 */         request.setRequest((HttpServletRequest)messageInfo.getRequestMessage());
/*  638 */         response.setResponse((HttpServletResponse)messageInfo.getResponseMessage());
/*      */       } catch (AuthException e) {
/*  640 */         log.warn(sm.getString("authenticator.jaspicSecureResponseFail"), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected X509Certificate[] getRequestCertificates(org.apache.catalina.connector.Request request)
/*      */     throws IllegalStateException
/*      */   {
/*  660 */     X509Certificate[] certs = (X509Certificate[])request.getAttribute("javax.servlet.request.X509Certificate");
/*      */     
/*      */ 
/*  663 */     if ((certs == null) || (certs.length < 1)) {
/*      */       try {
/*  665 */         request.getCoyoteRequest().action(ActionCode.REQ_SSL_CERTIFICATE, null);
/*  666 */         certs = (X509Certificate[])request.getAttribute("javax.servlet.request.X509Certificate");
/*      */       }
/*      */       catch (IllegalStateException localIllegalStateException) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  673 */     return certs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void associate(String ssoId, Session session)
/*      */   {
/*  687 */     if (this.sso == null) {
/*  688 */       return;
/*      */     }
/*  690 */     this.sso.associate(ssoId, session);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean authenticate(org.apache.catalina.connector.Request request, Response response, ServerAuthContext serverAuthContext, MessageInfo messageInfo)
/*      */     throws IOException
/*      */   {
/*  698 */     if (serverAuthContext == null)
/*      */     {
/*  700 */       return authenticate(request, response);
/*      */     }
/*  702 */     boolean cachedAuth = checkForCachedAuthentication(request, response, false);
/*  703 */     Subject client = new Subject();
/*      */     try
/*      */     {
/*  706 */       authStatus = serverAuthContext.validateRequest(messageInfo, client, null);
/*      */     } catch (AuthException e) { AuthStatus authStatus;
/*  708 */       log.debug(sm.getString("authenticator.loginFail"), e);
/*  709 */       return false;
/*      */     }
/*      */     AuthStatus authStatus;
/*  712 */     request.setRequest((HttpServletRequest)messageInfo.getRequestMessage());
/*  713 */     response.setResponse((HttpServletResponse)messageInfo.getResponseMessage());
/*      */     
/*  715 */     if (authStatus == AuthStatus.SUCCESS) {
/*  716 */       GenericPrincipal principal = getPrincipal(client);
/*  717 */       if (log.isDebugEnabled()) {
/*  718 */         log.debug("Authenticated user: " + principal);
/*      */       }
/*  720 */       if (principal == null) {
/*  721 */         request.setUserPrincipal(null);
/*  722 */         request.setAuthType(null);
/*  723 */       } else if ((!cachedAuth) || (!principal.getUserPrincipal().equals(request.getUserPrincipal())))
/*      */       {
/*      */ 
/*      */ 
/*  727 */         request.setNote("org.apache.catalina.authenticator.jaspic.SUBJECT", client);
/*      */         
/*  729 */         Map map = messageInfo.getMap();
/*  730 */         if ((map != null) && (map.containsKey("javax.servlet.http.registerSession"))) {
/*  731 */           register(request, response, principal, "JASPIC", null, null, true, true);
/*      */         } else {
/*  733 */           register(request, response, principal, "JASPIC", null, null);
/*      */         }
/*      */       }
/*  736 */       return true;
/*      */     }
/*  738 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   private GenericPrincipal getPrincipal(Subject subject)
/*      */   {
/*  744 */     if (subject == null) {
/*  745 */       return null;
/*      */     }
/*      */     
/*  748 */     Set<GenericPrincipal> principals = subject.getPrivateCredentials(GenericPrincipal.class);
/*  749 */     if (principals.isEmpty()) {
/*  750 */       return null;
/*      */     }
/*      */     
/*  753 */     return (GenericPrincipal)principals.iterator().next();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean checkForCachedAuthentication(org.apache.catalina.connector.Request request, HttpServletResponse response, boolean useSSO)
/*      */   {
/*  776 */     Principal principal = request.getUserPrincipal();
/*  777 */     String ssoId = (String)request.getNote("org.apache.catalina.request.SSOID");
/*  778 */     if (principal != null) {
/*  779 */       if (log.isDebugEnabled()) {
/*  780 */         log.debug(sm.getString("authenticator.check.found", new Object[] { principal.getName() }));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  785 */       if (ssoId != null) {
/*  786 */         associate(ssoId, request.getSessionInternal(true));
/*      */       }
/*  788 */       return true;
/*      */     }
/*      */     
/*      */ 
/*  792 */     if ((useSSO) && (ssoId != null)) {
/*  793 */       if (log.isDebugEnabled()) {
/*  794 */         log.debug(sm.getString("authenticator.check.sso", new Object[] { ssoId }));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  804 */       if (reauthenticateFromSSO(ssoId, request)) {
/*  805 */         return true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  811 */     if (request.getCoyoteRequest().getRemoteUserNeedsAuthorization()) {
/*  812 */       String username = request.getCoyoteRequest().getRemoteUser().toString();
/*  813 */       if (username != null) {
/*  814 */         if (log.isDebugEnabled()) {
/*  815 */           log.debug(sm.getString("authenticator.check.authorize", new Object[] { username }));
/*      */         }
/*  817 */         Principal authorized = this.context.getRealm().authenticate(username);
/*  818 */         if (authorized == null)
/*      */         {
/*      */ 
/*  821 */           if (log.isDebugEnabled()) {
/*  822 */             log.debug(sm.getString("authenticator.check.authorizeFail", new Object[] { username }));
/*      */           }
/*  824 */           authorized = new GenericPrincipal(username, null, null);
/*      */         }
/*  826 */         String authType = request.getAuthType();
/*  827 */         if ((authType == null) || (authType.length() == 0)) {
/*  828 */           authType = getAuthMethod();
/*      */         }
/*  830 */         register(request, response, authorized, authType, username, null);
/*  831 */         return true;
/*      */       }
/*      */     }
/*  834 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean reauthenticateFromSSO(String ssoId, org.apache.catalina.connector.Request request)
/*      */   {
/*  850 */     if ((this.sso == null) || (ssoId == null)) {
/*  851 */       return false;
/*      */     }
/*      */     
/*  854 */     boolean reauthenticated = false;
/*      */     
/*  856 */     Container parent = getContainer();
/*  857 */     if (parent != null) {
/*  858 */       Realm realm = parent.getRealm();
/*  859 */       if (realm != null) {
/*  860 */         reauthenticated = this.sso.reauthenticate(ssoId, realm, request);
/*      */       }
/*      */     }
/*      */     
/*  864 */     if (reauthenticated) {
/*  865 */       associate(ssoId, request.getSessionInternal(true));
/*      */       
/*  867 */       if (log.isDebugEnabled()) {
/*  868 */         log.debug(" Reauthenticated cached principal '" + request.getUserPrincipal().getName() + "' with auth type '" + request.getAuthType() + "'");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  874 */     return reauthenticated;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void register(org.apache.catalina.connector.Request request, HttpServletResponse response, Principal principal, String authType, String username, String password)
/*      */   {
/*  898 */     register(request, response, principal, authType, username, password, this.alwaysUseSession, this.cache);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void register(org.apache.catalina.connector.Request request, HttpServletResponse response, Principal principal, String authType, String username, String password, boolean alwaysUseSession, boolean cache)
/*      */   {
/*  906 */     if (log.isDebugEnabled()) {
/*  907 */       String name = principal == null ? "none" : principal.getName();
/*  908 */       log.debug("Authenticated '" + name + "' with type '" + authType + "'");
/*      */     }
/*      */     
/*      */ 
/*  912 */     request.setAuthType(authType);
/*  913 */     request.setUserPrincipal(principal);
/*      */     
/*  915 */     Session session = request.getSessionInternal(false);
/*      */     
/*  917 */     if (session != null)
/*      */     {
/*      */ 
/*  920 */       if ((this.changeSessionIdOnAuthentication) && (principal != null)) {
/*  921 */         String oldId = null;
/*  922 */         if (log.isDebugEnabled()) {
/*  923 */           oldId = session.getId();
/*      */         }
/*  925 */         Manager manager = request.getContext().getManager();
/*  926 */         manager.changeSessionId(session);
/*  927 */         request.changeSessionId(session.getId());
/*  928 */         if (log.isDebugEnabled()) {
/*  929 */           log.debug(sm.getString("authenticator.changeSessionId", new Object[] { oldId, session.getId() }));
/*      */         }
/*      */       }
/*      */     }
/*  933 */     else if (alwaysUseSession) {
/*  934 */       session = request.getSessionInternal(true);
/*      */     }
/*      */     
/*      */ 
/*  938 */     if ((cache) && 
/*  939 */       (session != null)) {
/*  940 */       session.setAuthType(authType);
/*  941 */       session.setPrincipal(principal);
/*  942 */       if (username != null) {
/*  943 */         session.setNote("org.apache.catalina.session.USERNAME", username);
/*      */       } else {
/*  945 */         session.removeNote("org.apache.catalina.session.USERNAME");
/*      */       }
/*  947 */       if (password != null) {
/*  948 */         session.setNote("org.apache.catalina.session.PASSWORD", password);
/*      */       } else {
/*  950 */         session.removeNote("org.apache.catalina.session.PASSWORD");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  956 */     if (this.sso == null) {
/*  957 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  963 */     String ssoId = (String)request.getNote("org.apache.catalina.request.SSOID");
/*  964 */     if (ssoId == null)
/*      */     {
/*  966 */       ssoId = this.sessionIdGenerator.generateSessionId();
/*  967 */       Cookie cookie = new Cookie(Constants.SINGLE_SIGN_ON_COOKIE, ssoId);
/*  968 */       cookie.setMaxAge(-1);
/*  969 */       cookie.setPath("/");
/*      */       
/*      */ 
/*  972 */       cookie.setSecure(request.isSecure());
/*      */       
/*      */ 
/*  975 */       String ssoDomain = this.sso.getCookieDomain();
/*  976 */       if (ssoDomain != null) {
/*  977 */         cookie.setDomain(ssoDomain);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  982 */       if ((request.getServletContext().getSessionCookieConfig().isHttpOnly()) || (request.getContext().getUseHttpOnly()))
/*      */       {
/*  984 */         cookie.setHttpOnly(true);
/*      */       }
/*      */       
/*  987 */       response.addCookie(cookie);
/*      */       
/*      */ 
/*  990 */       this.sso.register(ssoId, principal, authType, username, password);
/*  991 */       request.setNote("org.apache.catalina.request.SSOID", ssoId);
/*      */     }
/*      */     else {
/*  994 */       if (principal == null)
/*      */       {
/*  996 */         this.sso.deregister(ssoId);
/*  997 */         request.removeNote("org.apache.catalina.request.SSOID");
/*  998 */         return;
/*      */       }
/*      */       
/* 1001 */       this.sso.update(ssoId, principal, authType, username, password);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1011 */     if (session == null) {
/* 1012 */       session = request.getSessionInternal(true);
/*      */     }
/* 1014 */     this.sso.associate(ssoId, session);
/*      */   }
/*      */   
/*      */   public void login(String username, String password, org.apache.catalina.connector.Request request)
/*      */     throws ServletException
/*      */   {
/* 1020 */     Principal principal = doLogin(request, username, password);
/* 1021 */     register(request, request.getResponse(), principal, getAuthMethod(), username, password);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected abstract String getAuthMethod();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Principal doLogin(org.apache.catalina.connector.Request request, String username, String password)
/*      */     throws ServletException
/*      */   {
/* 1041 */     Principal p = this.context.getRealm().authenticate(username, password);
/* 1042 */     if (p == null) {
/* 1043 */       throw new ServletException(sm.getString("authenticator.loginFail"));
/*      */     }
/* 1045 */     return p;
/*      */   }
/*      */   
/*      */   public void logout(org.apache.catalina.connector.Request request)
/*      */   {
/* 1050 */     AuthConfigProvider provider = getJaspicProvider();
/* 1051 */     if (provider != null) {
/* 1052 */       MessageInfo messageInfo = new MessageInfoImpl(request, request.getResponse(), true);
/* 1053 */       Subject client = (Subject)request.getNote("org.apache.catalina.authenticator.jaspic.SUBJECT");
/* 1054 */       if (client == null) {
/* 1055 */         return;
/*      */       }
/*      */       
/*      */       try
/*      */       {
/* 1060 */         ServerAuthConfig serverAuthConfig = provider.getServerAuthConfig("HttpServlet", this.jaspicAppContextID, CallbackHandlerImpl.getInstance());
/*      */         
/* 1062 */         String authContextID = serverAuthConfig.getAuthContextID(messageInfo);
/* 1063 */         ServerAuthContext serverAuthContext = serverAuthConfig.getAuthContext(authContextID, null, null);
/* 1064 */         serverAuthContext.cleanSubject(messageInfo, client);
/*      */       } catch (AuthException e) {
/* 1066 */         log.debug(sm.getString("authenticator.jaspicCleanSubjectFail"), e);
/*      */       }
/*      */     }
/*      */     
/* 1070 */     register(request, request.getResponse(), null, null, null, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void startInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1084 */     ServletContext servletContext = this.context.getServletContext();
/* 1085 */     this.jaspicAppContextID = (servletContext.getVirtualServerName() + " " + servletContext.getContextPath());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1090 */     Container parent = this.context.getParent();
/* 1091 */     while ((this.sso == null) && (parent != null)) {
/* 1092 */       Valve[] valves = parent.getPipeline().getValves();
/* 1093 */       for (int i = 0; i < valves.length; i++) {
/* 1094 */         if ((valves[i] instanceof SingleSignOn)) {
/* 1095 */           this.sso = ((SingleSignOn)valves[i]);
/* 1096 */           break;
/*      */         }
/*      */       }
/* 1099 */       if (this.sso == null) {
/* 1100 */         parent = parent.getParent();
/*      */       }
/*      */     }
/* 1103 */     if (log.isDebugEnabled()) {
/* 1104 */       if (this.sso != null) {
/* 1105 */         log.debug("Found SingleSignOn Valve at " + this.sso);
/*      */       } else {
/* 1107 */         log.debug("No SingleSignOn Valve is present");
/*      */       }
/*      */     }
/*      */     
/* 1111 */     this.sessionIdGenerator = new StandardSessionIdGenerator();
/* 1112 */     this.sessionIdGenerator.setSecureRandomAlgorithm(getSecureRandomAlgorithm());
/* 1113 */     this.sessionIdGenerator.setSecureRandomClass(getSecureRandomClass());
/* 1114 */     this.sessionIdGenerator.setSecureRandomProvider(getSecureRandomProvider());
/*      */     
/* 1116 */     super.startInternal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void stopInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1130 */     super.stopInternal();
/*      */     
/* 1132 */     this.sso = null;
/*      */   }
/*      */   
/*      */   private AuthConfigProvider getJaspicProvider()
/*      */   {
/* 1137 */     AuthConfigProvider provider = this.jaspicProvider;
/* 1138 */     if (provider == null) {
/* 1139 */       AuthConfigFactory factory = AuthConfigFactory.getFactory();
/* 1140 */       provider = factory.getConfigProvider("HttpServlet", this.jaspicAppContextID, this);
/* 1141 */       if (provider != null) {
/* 1142 */         this.jaspicProvider = provider;
/*      */       }
/*      */     }
/* 1145 */     return provider;
/*      */   }
/*      */   
/*      */ 
/*      */   public void notify(String layer, String appContext)
/*      */   {
/* 1151 */     AuthConfigFactory factory = AuthConfigFactory.getFactory();
/* 1152 */     AuthConfigProvider provider = factory.getConfigProvider("HttpServlet", this.jaspicAppContextID, this);
/*      */     
/* 1154 */     this.jaspicProvider = provider;
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\authenticator\AuthenticatorBase.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */