/*     */ package org.apache.catalina.authenticator.jaspic;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PersistentProviderRegistrations
/*     */ {
/*  46 */   private static final Log log = LogFactory.getLog(PersistentProviderRegistrations.class);
/*  47 */   private static final StringManager sm = StringManager.getManager(PersistentProviderRegistrations.class);
/*     */   
/*     */   /* Error */
/*     */   static Providers loadProviders(File configFile)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 2	java/io/FileInputStream
/*     */     //   3: dup
/*     */     //   4: aload_0
/*     */     //   5: invokespecial 3	java/io/FileInputStream:<init>	(Ljava/io/File;)V
/*     */     //   8: astore_1
/*     */     //   9: aconst_null
/*     */     //   10: astore_2
/*     */     //   11: new 4	org/apache/tomcat/util/digester/Digester
/*     */     //   14: dup
/*     */     //   15: invokespecial 5	org/apache/tomcat/util/digester/Digester:<init>	()V
/*     */     //   18: astore_3
/*     */     //   19: aload_3
/*     */     //   20: ldc 6
/*     */     //   22: iconst_1
/*     */     //   23: invokevirtual 7	org/apache/tomcat/util/digester/Digester:setFeature	(Ljava/lang/String;Z)V
/*     */     //   26: aload_3
/*     */     //   27: iconst_1
/*     */     //   28: invokevirtual 8	org/apache/tomcat/util/digester/Digester:setValidating	(Z)V
/*     */     //   31: aload_3
/*     */     //   32: iconst_1
/*     */     //   33: invokevirtual 9	org/apache/tomcat/util/digester/Digester:setNamespaceAware	(Z)V
/*     */     //   36: goto +15 -> 51
/*     */     //   39: astore 4
/*     */     //   41: new 11	java/lang/SecurityException
/*     */     //   44: dup
/*     */     //   45: aload 4
/*     */     //   47: invokespecial 12	java/lang/SecurityException:<init>	(Ljava/lang/Throwable;)V
/*     */     //   50: athrow
/*     */     //   51: new 13	org/apache/catalina/authenticator/jaspic/PersistentProviderRegistrations$Providers
/*     */     //   54: dup
/*     */     //   55: invokespecial 14	org/apache/catalina/authenticator/jaspic/PersistentProviderRegistrations$Providers:<init>	()V
/*     */     //   58: astore 4
/*     */     //   60: aload_3
/*     */     //   61: aload 4
/*     */     //   63: invokevirtual 15	org/apache/tomcat/util/digester/Digester:push	(Ljava/lang/Object;)V
/*     */     //   66: aload_3
/*     */     //   67: ldc 16
/*     */     //   69: ldc_w 17
/*     */     //   72: invokevirtual 18	java/lang/Class:getName	()Ljava/lang/String;
/*     */     //   75: invokevirtual 19	org/apache/tomcat/util/digester/Digester:addObjectCreate	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   78: aload_3
/*     */     //   79: ldc 16
/*     */     //   81: invokevirtual 20	org/apache/tomcat/util/digester/Digester:addSetProperties	(Ljava/lang/String;)V
/*     */     //   84: aload_3
/*     */     //   85: ldc 16
/*     */     //   87: ldc 21
/*     */     //   89: ldc_w 17
/*     */     //   92: invokevirtual 18	java/lang/Class:getName	()Ljava/lang/String;
/*     */     //   95: invokevirtual 22	org/apache/tomcat/util/digester/Digester:addSetNext	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   98: aload_3
/*     */     //   99: ldc 23
/*     */     //   101: ldc_w 24
/*     */     //   104: invokevirtual 18	java/lang/Class:getName	()Ljava/lang/String;
/*     */     //   107: invokevirtual 19	org/apache/tomcat/util/digester/Digester:addObjectCreate	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   110: aload_3
/*     */     //   111: ldc 23
/*     */     //   113: invokevirtual 20	org/apache/tomcat/util/digester/Digester:addSetProperties	(Ljava/lang/String;)V
/*     */     //   116: aload_3
/*     */     //   117: ldc 23
/*     */     //   119: ldc 25
/*     */     //   121: ldc_w 24
/*     */     //   124: invokevirtual 18	java/lang/Class:getName	()Ljava/lang/String;
/*     */     //   127: invokevirtual 22	org/apache/tomcat/util/digester/Digester:addSetNext	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   130: aload_3
/*     */     //   131: aload_1
/*     */     //   132: invokevirtual 26	org/apache/tomcat/util/digester/Digester:parse	(Ljava/io/InputStream;)Ljava/lang/Object;
/*     */     //   135: pop
/*     */     //   136: aload 4
/*     */     //   138: astore 5
/*     */     //   140: aload_1
/*     */     //   141: ifnull +29 -> 170
/*     */     //   144: aload_2
/*     */     //   145: ifnull +21 -> 166
/*     */     //   148: aload_1
/*     */     //   149: invokevirtual 27	java/io/InputStream:close	()V
/*     */     //   152: goto +18 -> 170
/*     */     //   155: astore 6
/*     */     //   157: aload_2
/*     */     //   158: aload 6
/*     */     //   160: invokevirtual 29	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   163: goto +7 -> 170
/*     */     //   166: aload_1
/*     */     //   167: invokevirtual 27	java/io/InputStream:close	()V
/*     */     //   170: aload 5
/*     */     //   172: areturn
/*     */     //   173: astore_3
/*     */     //   174: aload_3
/*     */     //   175: astore_2
/*     */     //   176: aload_3
/*     */     //   177: athrow
/*     */     //   178: astore 7
/*     */     //   180: aload_1
/*     */     //   181: ifnull +29 -> 210
/*     */     //   184: aload_2
/*     */     //   185: ifnull +21 -> 206
/*     */     //   188: aload_1
/*     */     //   189: invokevirtual 27	java/io/InputStream:close	()V
/*     */     //   192: goto +18 -> 210
/*     */     //   195: astore 8
/*     */     //   197: aload_2
/*     */     //   198: aload 8
/*     */     //   200: invokevirtual 29	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   203: goto +7 -> 210
/*     */     //   206: aload_1
/*     */     //   207: invokevirtual 27	java/io/InputStream:close	()V
/*     */     //   210: aload 7
/*     */     //   212: athrow
/*     */     //   213: astore_1
/*     */     //   214: new 11	java/lang/SecurityException
/*     */     //   217: dup
/*     */     //   218: aload_1
/*     */     //   219: invokespecial 12	java/lang/SecurityException:<init>	(Ljava/lang/Throwable;)V
/*     */     //   222: athrow
/*     */     // Line number table:
/*     */     //   Java source line #57	-> byte code offset #0
/*     */     //   Java source line #59	-> byte code offset #11
/*     */     //   Java source line #62	-> byte code offset #19
/*     */     //   Java source line #63	-> byte code offset #26
/*     */     //   Java source line #64	-> byte code offset #31
/*     */     //   Java source line #67	-> byte code offset #36
/*     */     //   Java source line #65	-> byte code offset #39
/*     */     //   Java source line #66	-> byte code offset #41
/*     */     //   Java source line #71	-> byte code offset #51
/*     */     //   Java source line #72	-> byte code offset #60
/*     */     //   Java source line #75	-> byte code offset #66
/*     */     //   Java source line #76	-> byte code offset #78
/*     */     //   Java source line #77	-> byte code offset #84
/*     */     //   Java source line #79	-> byte code offset #98
/*     */     //   Java source line #80	-> byte code offset #110
/*     */     //   Java source line #81	-> byte code offset #116
/*     */     //   Java source line #84	-> byte code offset #130
/*     */     //   Java source line #86	-> byte code offset #136
/*     */     //   Java source line #87	-> byte code offset #140
/*     */     //   Java source line #57	-> byte code offset #173
/*     */     //   Java source line #87	-> byte code offset #178
/*     */     //   Java source line #88	-> byte code offset #214
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	223	0	configFile	File
/*     */     //   8	199	1	is	java.io.InputStream
/*     */     //   213	6	1	e	Exception
/*     */     //   10	188	2	localThrowable2	Throwable
/*     */     //   18	113	3	digester	org.apache.tomcat.util.digester.Digester
/*     */     //   173	4	3	localThrowable1	Throwable
/*     */     //   39	7	4	e	Exception
/*     */     //   58	79	4	result	Providers
/*     */     //   155	4	6	x2	Throwable
/*     */     //   178	33	7	localObject	Object
/*     */     //   195	4	8	x2	Throwable
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   19	36	39	java/lang/Exception
/*     */     //   148	152	155	java/lang/Throwable
/*     */     //   11	140	173	java/lang/Throwable
/*     */     //   11	140	178	finally
/*     */     //   173	180	178	finally
/*     */     //   188	192	195	java/lang/Throwable
/*     */     //   0	170	213	java/io/IOException
/*     */     //   0	170	213	org/xml/sax/SAXException
/*     */     //   173	213	213	java/io/IOException
/*     */     //   173	213	213	org/xml/sax/SAXException
/*     */   }
/*     */   
/*     */   static void writeProviders(Providers providers, File configFile)
/*     */   {
/*  94 */     File configFileOld = new File(configFile.getAbsolutePath() + ".old");
/*  95 */     File configFileNew = new File(configFile.getAbsolutePath() + ".new");
/*     */     
/*     */ 
/*  98 */     if ((configFileOld.exists()) && 
/*  99 */       (configFileOld.delete())) {
/* 100 */       throw new SecurityException(sm.getString("persistentProviderRegistrations.existsDeleteFail", new Object[] { configFileOld.getAbsolutePath() }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 105 */     if ((configFileNew.exists()) && 
/* 106 */       (configFileNew.delete())) {
/* 107 */       throw new SecurityException(sm.getString("persistentProviderRegistrations.existsDeleteFail", new Object[] { configFileNew.getAbsolutePath() }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 114 */       OutputStream fos = new FileOutputStream(configFileNew);Throwable localThrowable3 = null;
/* 115 */       try { Writer writer = new OutputStreamWriter(fos, StandardCharsets.UTF_8);Throwable localThrowable4 = null;
/* 116 */         try { writer.write("<?xml version='1.0' encoding='utf-8'?>\n<jaspic-providers\n    xmlns=\"http://tomcat.apache.org/xml\"\n    xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n    xsi:schemaLocation=\"http://tomcat.apache.org/xml jaspic-providers.xsd\"\n    version=\"1.0\">\n");
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 123 */           for (Provider provider : providers.providers) {
/* 124 */             writer.write("  <provider className=\"");
/* 125 */             writer.write(provider.getClassName());
/* 126 */             writer.write("\" layer=\"");
/* 127 */             writer.write(provider.getLayer());
/* 128 */             writer.write("\" appContext=\"");
/* 129 */             writer.write(provider.getAppContext());
/* 130 */             if (provider.getDescription() != null) {
/* 131 */               writer.write("\" description=\"");
/* 132 */               writer.write(provider.getDescription());
/*     */             }
/* 134 */             writer.write("\">\n");
/* 135 */             for (Map.Entry<String, String> entry : provider.getProperties().entrySet()) {
/* 136 */               writer.write("    <property name=\"");
/* 137 */               writer.write((String)entry.getKey());
/* 138 */               writer.write("\" value=\"");
/* 139 */               writer.write((String)entry.getValue());
/* 140 */               writer.write("\"/>\n");
/*     */             }
/* 142 */             writer.write("  </provider>\n");
/*     */           }
/* 144 */           writer.write("</jaspic-providers>\n");
/*     */         }
/*     */         catch (Throwable localThrowable1)
/*     */         {
/* 114 */           localThrowable4 = localThrowable1;throw localThrowable1; } finally {} } catch (Throwable localThrowable2) { localThrowable3 = localThrowable2;throw localThrowable2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       finally
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 145 */         if (fos != null) if (localThrowable3 != null) try { fos.close(); } catch (Throwable x2) { localThrowable3.addSuppressed(x2); } else fos.close();
/* 146 */       } } catch (IOException e) { configFileNew.delete();
/* 147 */       throw new SecurityException(e);
/*     */     }
/*     */     
/*     */ 
/* 151 */     if ((configFile.isFile()) && 
/* 152 */       (!configFile.renameTo(configFileOld))) {
/* 153 */       throw new SecurityException(sm.getString("persistentProviderRegistrations.moveFail", new Object[] { configFile.getAbsolutePath(), configFileOld.getAbsolutePath() }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 159 */     if (!configFileNew.renameTo(configFile)) {
/* 160 */       throw new SecurityException(sm.getString("persistentProviderRegistrations.moveFail", new Object[] { configFileNew.getAbsolutePath(), configFile.getAbsolutePath() }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 165 */     if ((configFileOld.exists()) && (!configFileOld.delete())) {
/* 166 */       log.warn(sm.getString("persistentProviderRegistrations.deleteFail", new Object[] { configFileOld.getAbsolutePath() }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class Providers
/*     */   {
/* 173 */     private final List<PersistentProviderRegistrations.Provider> providers = new ArrayList();
/*     */     
/*     */     public void addProvider(PersistentProviderRegistrations.Provider provider) {
/* 176 */       this.providers.add(provider);
/*     */     }
/*     */     
/*     */     public List<PersistentProviderRegistrations.Provider> getProviders() {
/* 180 */       return this.providers;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Provider
/*     */   {
/*     */     private String className;
/*     */     private String layer;
/*     */     private String appContext;
/*     */     private String description;
/* 190 */     private final Map<String, String> properties = new HashMap();
/*     */     
/*     */     public String getClassName()
/*     */     {
/* 194 */       return this.className;
/*     */     }
/*     */     
/* 197 */     public void setClassName(String className) { this.className = className; }
/*     */     
/*     */ 
/*     */     public String getLayer()
/*     */     {
/* 202 */       return this.layer;
/*     */     }
/*     */     
/* 205 */     public void setLayer(String layer) { this.layer = layer; }
/*     */     
/*     */ 
/*     */     public String getAppContext()
/*     */     {
/* 210 */       return this.appContext;
/*     */     }
/*     */     
/* 213 */     public void setAppContext(String appContext) { this.appContext = appContext; }
/*     */     
/*     */ 
/*     */     public String getDescription()
/*     */     {
/* 218 */       return this.description;
/*     */     }
/*     */     
/* 221 */     public void setDescription(String description) { this.description = description; }
/*     */     
/*     */ 
/*     */     public void addProperty(PersistentProviderRegistrations.Property property)
/*     */     {
/* 226 */       this.properties.put(property.getName(), property.getValue());
/*     */     }
/*     */     
/* 229 */     void addProperty(String name, String value) { this.properties.put(name, value); }
/*     */     
/*     */     public Map<String, String> getProperties() {
/* 232 */       return this.properties;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Property
/*     */   {
/*     */     private String name;
/*     */     private String value;
/*     */     
/*     */     public String getName()
/*     */     {
/* 243 */       return this.name;
/*     */     }
/*     */     
/* 246 */     public void setName(String name) { this.name = name; }
/*     */     
/*     */ 
/*     */     public String getValue()
/*     */     {
/* 251 */       return this.value;
/*     */     }
/*     */     
/* 254 */     public void setValue(String value) { this.value = value; }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\authenticator\jaspic\PersistentProviderRegistrations.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */