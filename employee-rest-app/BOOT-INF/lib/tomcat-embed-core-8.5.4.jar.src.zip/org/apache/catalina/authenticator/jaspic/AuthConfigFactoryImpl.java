/*     */ package org.apache.catalina.authenticator.jaspic;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import javax.security.auth.message.config.AuthConfigFactory;
/*     */ import javax.security.auth.message.config.AuthConfigFactory.RegistrationContext;
/*     */ import javax.security.auth.message.config.AuthConfigProvider;
/*     */ import javax.security.auth.message.config.RegistrationListener;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthConfigFactoryImpl
/*     */   extends AuthConfigFactory
/*     */ {
/*  45 */   private static final Log log = LogFactory.getLog(AuthConfigFactoryImpl.class);
/*  46 */   private static final StringManager sm = StringManager.getManager(AuthConfigFactoryImpl.class);
/*     */   
/*     */   private static final String CONFIG_PATH = "conf/jaspic-providers.xml";
/*  49 */   private static final File CONFIG_FILE = new File(System.getProperty("catalina.base"), "conf/jaspic-providers.xml");
/*     */   
/*  51 */   private static final Object CONFIG_FILE_LOCK = new Object();
/*     */   
/*  53 */   private static final String[] EMPTY_STRING_ARRAY = new String[0];
/*     */   
/*  55 */   private final Map<String, RegistrationContextImpl> registrations = new ConcurrentHashMap();
/*     */   
/*     */   public AuthConfigFactoryImpl()
/*     */   {
/*  59 */     loadPersistentRegistrations();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public AuthConfigProvider getConfigProvider(String layer, String appContext, RegistrationListener listener)
/*     */   {
/*  66 */     String registrationID = getRegistrarionID(layer, appContext);
/*  67 */     RegistrationContextImpl registrationContext = (RegistrationContextImpl)this.registrations.get(registrationID);
/*  68 */     if (registrationContext != null) {
/*  69 */       registrationContext.addListener(null);
/*  70 */       return registrationContext.getProvider();
/*     */     }
/*  72 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String registerConfigProvider(String className, Map properties, String layer, String appContext, String description)
/*     */   {
/*  80 */     String registrationID = doRegisterConfigProvider(className, properties, layer, appContext, description);
/*     */     
/*  82 */     savePersistentRegistrations();
/*  83 */     return registrationID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String doRegisterConfigProvider(String className, Map properties, String layer, String appContext, String description)
/*     */   {
/*  91 */     if (log.isDebugEnabled()) {
/*  92 */       log.debug(sm.getString("authConfigFactoryImpl.registerClass", new Object[] { className, layer, appContext }));
/*     */     }
/*     */     
/*     */ 
/*  96 */     AuthConfigProvider provider = null;
/*     */     Class<?> clazz;
/*  98 */     try { clazz = Class.forName(className, true, Thread.currentThread().getContextClassLoader());
/*     */     }
/*     */     catch (ClassNotFoundException localClassNotFoundException) {}
/*     */     try
/*     */     {
/* 103 */       Class<?> clazz = Class.forName(className);
/* 104 */       Constructor<?> constructor = clazz.getConstructor(new Class[] { Map.class, AuthConfigFactory.class });
/* 105 */       provider = (AuthConfigProvider)constructor.newInstance(new Object[] { properties, null });
/*     */     }
/*     */     catch (ClassNotFoundException|NoSuchMethodException|InstantiationException|IllegalAccessException|IllegalArgumentException|InvocationTargetException e) {
/* 108 */       throw new SecurityException(e);
/*     */     }
/*     */     Class<?> clazz;
/* 111 */     String registrationID = getRegistrarionID(layer, appContext);
/* 112 */     this.registrations.put(registrationID, new RegistrationContextImpl(layer, appContext, description, true, provider, properties, null));
/*     */     
/* 114 */     return registrationID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String registerConfigProvider(AuthConfigProvider provider, String layer, String appContext, String description)
/*     */   {
/* 121 */     if (log.isDebugEnabled()) {
/* 122 */       log.debug(sm.getString("authConfigFactoryImpl.registerInstance", new Object[] { provider.getClass().getName(), layer, appContext }));
/*     */     }
/*     */     
/* 125 */     String registrationID = getRegistrarionID(layer, appContext);
/* 126 */     this.registrations.put(registrationID, new RegistrationContextImpl(layer, appContext, description, false, provider, null, null));
/*     */     
/* 128 */     return registrationID;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean removeRegistration(String registrationID)
/*     */   {
/* 134 */     return this.registrations.remove(registrationID) != null;
/*     */   }
/*     */   
/*     */ 
/*     */   public String[] detachListener(RegistrationListener listener, String layer, String appContext)
/*     */   {
/* 140 */     String registrationID = getRegistrarionID(layer, appContext);
/* 141 */     RegistrationContextImpl registrationContext = (RegistrationContextImpl)this.registrations.get(registrationID);
/* 142 */     if (registrationContext.removeListener(listener)) {
/* 143 */       return new String[] { registrationID };
/*     */     }
/* 145 */     return EMPTY_STRING_ARRAY;
/*     */   }
/*     */   
/*     */ 
/*     */   public String[] getRegistrationIDs(AuthConfigProvider provider)
/*     */   {
/* 151 */     if (provider == null) {
/* 152 */       return (String[])this.registrations.keySet().toArray(EMPTY_STRING_ARRAY);
/*     */     }
/* 154 */     List<String> results = new ArrayList();
/* 155 */     for (Map.Entry<String, RegistrationContextImpl> entry : this.registrations.entrySet()) {
/* 156 */       if (provider.equals(((RegistrationContextImpl)entry.getValue()).getProvider())) {
/* 157 */         results.add(entry.getKey());
/*     */       }
/*     */     }
/* 160 */     return (String[])results.toArray(EMPTY_STRING_ARRAY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public AuthConfigFactory.RegistrationContext getRegistrationContext(String registrationID)
/*     */   {
/* 167 */     return (AuthConfigFactory.RegistrationContext)this.registrations.get(registrationID);
/*     */   }
/*     */   
/*     */ 
/*     */   public void refresh()
/*     */   {
/* 173 */     loadPersistentRegistrations();
/*     */   }
/*     */   
/*     */   private String getRegistrarionID(String layer, String appContext)
/*     */   {
/* 178 */     return layer + ":" + appContext;
/*     */   }
/*     */   
/*     */   private void loadPersistentRegistrations()
/*     */   {
/* 183 */     synchronized (CONFIG_FILE_LOCK) {
/* 184 */       if (log.isDebugEnabled()) {
/* 185 */         log.debug(sm.getString("authConfigFactoryImpl.load", new Object[] { CONFIG_FILE.getAbsolutePath() }));
/*     */       }
/*     */       
/* 188 */       if (!CONFIG_FILE.isFile()) {
/* 189 */         return;
/*     */       }
/* 191 */       PersistentProviderRegistrations.Providers providers = PersistentProviderRegistrations.loadProviders(CONFIG_FILE);
/* 192 */       for (PersistentProviderRegistrations.Provider provider : providers.getProviders()) {
/* 193 */         doRegisterConfigProvider(provider.getClassName(), provider.getProperties(), provider.getLayer(), provider.getAppContext(), provider.getDescription());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void savePersistentRegistrations()
/*     */   {
/* 201 */     synchronized (CONFIG_FILE_LOCK) {
/* 202 */       PersistentProviderRegistrations.Providers providers = new PersistentProviderRegistrations.Providers();
/* 203 */       for (Map.Entry<String, RegistrationContextImpl> entry : this.registrations.entrySet()) {
/* 204 */         if (((RegistrationContextImpl)entry.getValue()).isPersistent()) {
/* 205 */           PersistentProviderRegistrations.Provider provider = new PersistentProviderRegistrations.Provider();
/* 206 */           provider.setAppContext(((RegistrationContextImpl)entry.getValue()).getAppContext());
/* 207 */           provider.setClassName(((RegistrationContextImpl)entry.getValue()).getProvider().getClass().getName());
/* 208 */           provider.setDescription(((RegistrationContextImpl)entry.getValue()).getDescription());
/* 209 */           provider.setLayer(((RegistrationContextImpl)entry.getValue()).getMessageLayer());
/* 210 */           for (Map.Entry<String, String> property : ((RegistrationContextImpl)entry.getValue()).getProperties().entrySet()) {
/* 211 */             provider.addProperty((String)property.getKey(), (String)property.getValue());
/*     */           }
/* 213 */           providers.addProvider(provider);
/*     */         }
/*     */       }
/* 216 */       PersistentProviderRegistrations.writeProviders(providers, CONFIG_FILE); } }
/*     */   
/*     */   private static class RegistrationContextImpl implements AuthConfigFactory.RegistrationContext { private final String messageLayer;
/*     */     private final String appContext;
/*     */     private final String description;
/*     */     private final boolean persistent;
/*     */     private final AuthConfigProvider provider;
/*     */     private final Map<String, String> properties;
/*     */     
/* 225 */     private RegistrationContextImpl(String messageLayer, String appContext, String description, boolean persistent, AuthConfigProvider provider, Map<String, String> properties) { this.messageLayer = messageLayer;
/* 226 */       this.appContext = appContext;
/* 227 */       this.description = description;
/* 228 */       this.persistent = persistent;
/* 229 */       this.provider = provider;
/* 230 */       Map<String, String> propertiesCopy = new HashMap();
/* 231 */       if (properties != null) {
/* 232 */         propertiesCopy.putAll(properties);
/*     */       }
/* 234 */       this.properties = Collections.unmodifiableMap(propertiesCopy);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 243 */     private final List<RegistrationListener> listeners = new CopyOnWriteArrayList();
/*     */     
/*     */     public String getMessageLayer()
/*     */     {
/* 247 */       return this.messageLayer;
/*     */     }
/*     */     
/*     */ 
/*     */     public String getAppContext()
/*     */     {
/* 253 */       return this.appContext;
/*     */     }
/*     */     
/*     */     public String getDescription()
/*     */     {
/* 258 */       return this.description;
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean isPersistent()
/*     */     {
/* 264 */       return this.persistent;
/*     */     }
/*     */     
/*     */     private AuthConfigProvider getProvider()
/*     */     {
/* 269 */       return this.provider;
/*     */     }
/*     */     
/*     */     private void addListener(RegistrationListener listener)
/*     */     {
/* 274 */       if (listener != null) {
/* 275 */         this.listeners.add(listener);
/*     */       }
/*     */     }
/*     */     
/*     */     private Map<String, String> getProperties()
/*     */     {
/* 281 */       return this.properties;
/*     */     }
/*     */     
/*     */     private boolean removeListener(RegistrationListener listener)
/*     */     {
/* 286 */       boolean result = false;
/* 287 */       Iterator<RegistrationListener> iter = this.listeners.iterator();
/* 288 */       while (iter.hasNext()) {
/* 289 */         if (((RegistrationListener)iter.next()).equals(listener)) {
/* 290 */           iter.remove();
/*     */         }
/*     */       }
/* 293 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\authenticator\jaspic\AuthConfigFactoryImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */