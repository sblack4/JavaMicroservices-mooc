/*     */ package org.apache.catalina.authenticator;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.security.Principal;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.security.auth.login.LoginContext;
/*     */ import javax.security.auth.login.LoginException;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.Realm;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.buf.ByteChunk;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.codec.binary.Base64;
/*     */ import org.apache.tomcat.util.compat.JreVendor;
/*     */ import org.apache.tomcat.util.http.MimeHeaders;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.ietf.jgss.GSSContext;
/*     */ import org.ietf.jgss.GSSCredential;
/*     */ import org.ietf.jgss.GSSException;
/*     */ import org.ietf.jgss.GSSManager;
/*     */ import org.ietf.jgss.Oid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpnegoAuthenticator
/*     */   extends AuthenticatorBase
/*     */ {
/*  58 */   private static final Log log = LogFactory.getLog(SpnegoAuthenticator.class);
/*     */   private String loginConfigName;
/*     */   private boolean storeDelegatedCredential;
/*     */   
/*  62 */   public String getLoginConfigName() { return this.loginConfigName; }
/*     */   
/*     */   public void setLoginConfigName(String loginConfigName) {
/*  65 */     this.loginConfigName = loginConfigName;
/*     */   }
/*     */   
/*     */   public boolean isStoreDelegatedCredential()
/*     */   {
/*  70 */     return this.storeDelegatedCredential;
/*     */   }
/*     */   
/*     */   public void setStoreDelegatedCredential(boolean storeDelegatedCredential) {
/*  74 */     this.storeDelegatedCredential = storeDelegatedCredential;
/*     */   }
/*     */   
/*     */   public String getNoKeepAliveUserAgents()
/*     */   {
/*  79 */     Pattern p = this.noKeepAliveUserAgents;
/*  80 */     if (p == null) {
/*  81 */       return null;
/*     */     }
/*  83 */     return p.pattern();
/*     */   }
/*     */   
/*     */   public void setNoKeepAliveUserAgents(String noKeepAliveUserAgents) {
/*  87 */     if ((noKeepAliveUserAgents == null) || (noKeepAliveUserAgents.length() == 0))
/*     */     {
/*  89 */       this.noKeepAliveUserAgents = null;
/*     */     } else {
/*  91 */       this.noKeepAliveUserAgents = Pattern.compile(noKeepAliveUserAgents);
/*     */     }
/*     */   }
/*     */   
/*     */   public SpnegoAuthenticator()
/*     */   {
/*  60 */     this.loginConfigName = "com.sun.security.jgss.krb5.accept";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  68 */     this.storeDelegatedCredential = true;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  77 */     this.noKeepAliveUserAgents = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  95 */     this.applyJava8u40Fix = true; }
/*     */   
/*  97 */   public boolean getApplyJava8u40Fix() { return this.applyJava8u40Fix; }
/*     */   
/*     */   public void setApplyJava8u40Fix(boolean applyJava8u40Fix) {
/* 100 */     this.applyJava8u40Fix = applyJava8u40Fix;
/*     */   }
/*     */   
/*     */ 
/*     */   protected String getAuthMethod()
/*     */   {
/* 106 */     return "SPNEGO";
/*     */   }
/*     */   
/*     */   protected void initInternal()
/*     */     throws LifecycleException
/*     */   {
/* 112 */     super.initInternal();
/*     */     
/*     */ 
/* 115 */     String krb5Conf = System.getProperty("java.security.krb5.conf");
/* 116 */     if (krb5Conf == null)
/*     */     {
/* 118 */       File krb5ConfFile = new File(this.container.getCatalinaBase(), "conf/krb5.ini");
/*     */       
/* 120 */       System.setProperty("java.security.krb5.conf", krb5ConfFile.getAbsolutePath());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 125 */     String jaasConf = System.getProperty("java.security.auth.login.config");
/* 126 */     if (jaasConf == null)
/*     */     {
/* 128 */       File jaasConfFile = new File(this.container.getCatalinaBase(), "conf/jaas.conf");
/*     */       
/* 130 */       System.setProperty("java.security.auth.login.config", jaasConfFile.getAbsolutePath());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean authenticate(org.apache.catalina.connector.Request request, HttpServletResponse response)
/*     */     throws IOException
/*     */   {
/* 140 */     if (checkForCachedAuthentication(request, response, true)) {
/* 141 */       return true;
/*     */     }
/*     */     
/* 144 */     MessageBytes authorization = request.getCoyoteRequest().getMimeHeaders().getValue("authorization");
/*     */     
/*     */ 
/*     */ 
/* 148 */     if (authorization == null) {
/* 149 */       if (log.isDebugEnabled()) {
/* 150 */         log.debug(sm.getString("authenticator.noAuthHeader"));
/*     */       }
/* 152 */       response.setHeader("WWW-Authenticate", "Negotiate");
/* 153 */       response.sendError(401);
/* 154 */       return false;
/*     */     }
/*     */     
/* 157 */     authorization.toBytes();
/* 158 */     ByteChunk authorizationBC = authorization.getByteChunk();
/*     */     
/* 160 */     if (!authorizationBC.startsWithIgnoreCase("negotiate ", 0)) {
/* 161 */       if (log.isDebugEnabled()) {
/* 162 */         log.debug(sm.getString("spnegoAuthenticator.authHeaderNotNego"));
/*     */       }
/*     */       
/* 165 */       response.setHeader("WWW-Authenticate", "Negotiate");
/* 166 */       response.sendError(401);
/* 167 */       return false;
/*     */     }
/*     */     
/* 170 */     authorizationBC.setOffset(authorizationBC.getOffset() + 10);
/*     */     
/* 172 */     byte[] decoded = Base64.decodeBase64(authorizationBC.getBuffer(), authorizationBC.getOffset(), authorizationBC.getLength());
/*     */     
/*     */ 
/*     */ 
/* 176 */     if (getApplyJava8u40Fix()) {
/* 177 */       SpnegoTokenFixer.fix(decoded);
/*     */     }
/*     */     
/* 180 */     if (decoded.length == 0) {
/* 181 */       if (log.isDebugEnabled()) {
/* 182 */         log.debug(sm.getString("spnegoAuthenticator.authHeaderNoToken"));
/*     */       }
/*     */       
/* 185 */       response.setHeader("WWW-Authenticate", "Negotiate");
/* 186 */       response.sendError(401);
/* 187 */       return false;
/*     */     }
/*     */     
/* 190 */     LoginContext lc = null;
/* 191 */     GSSContext gssContext = null;
/* 192 */     byte[] outToken = null;
/* 193 */     Principal principal = null;
/*     */     try {
/*     */       try {
/* 196 */         lc = new LoginContext(getLoginConfigName());
/* 197 */         lc.login();
/*     */       } catch (LoginException e) {
/* 199 */         log.error(sm.getString("spnegoAuthenticator.serviceLoginFail"), e);
/*     */         
/* 201 */         response.sendError(500);
/*     */         
/* 203 */         return false;
/*     */       }
/*     */       
/* 206 */       Subject subject = lc.getSubject();
/*     */       
/*     */ 
/*     */ 
/* 210 */       final GSSManager manager = GSSManager.getInstance();
/*     */       int credentialLifetime;
/*     */       final int credentialLifetime;
/* 213 */       if (JreVendor.IS_IBM_JVM) {
/* 214 */         credentialLifetime = Integer.MAX_VALUE;
/*     */       } else {
/* 216 */         credentialLifetime = 0;
/*     */       }
/* 218 */       PrivilegedExceptionAction<GSSCredential> action = new PrivilegedExceptionAction()
/*     */       {
/*     */         public GSSCredential run() throws GSSException
/*     */         {
/* 222 */           return manager.createCredential(null, credentialLifetime, new Oid("1.3.6.1.5.5.2"), 2);
/*     */ 
/*     */         }
/*     */         
/*     */ 
/* 227 */       };
/* 228 */       gssContext = manager.createContext((GSSCredential)Subject.doAs(subject, action));
/*     */       
/* 230 */       outToken = (byte[])Subject.doAs(lc.getSubject(), new AcceptAction(gssContext, decoded));
/*     */       
/* 232 */       if (outToken == null) {
/* 233 */         if (log.isDebugEnabled()) {
/* 234 */           log.debug(sm.getString("spnegoAuthenticator.ticketValidateFail"));
/*     */         }
/*     */         
/*     */ 
/* 238 */         response.setHeader("WWW-Authenticate", "Negotiate");
/* 239 */         response.sendError(401);
/* 240 */         return false;
/*     */       }
/*     */       
/* 243 */       principal = (Principal)Subject.doAs(subject, new AuthenticateAction(this.context.getRealm(), gssContext, this.storeDelegatedCredential));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 266 */       if (gssContext != null) {
/*     */         try {
/* 268 */           gssContext.dispose();
/*     */         }
/*     */         catch (GSSException localGSSException3) {}
/*     */       }
/*     */       
/* 273 */       if (lc != null) {
/*     */         try {
/* 275 */           lc.logout();
/*     */         }
/*     */         catch (LoginException localLoginException3) {}
/*     */       }
/*     */       
/*     */ 
/*     */       Throwable cause;
/*     */       
/* 283 */       response.setHeader("WWW-Authenticate", "Negotiate " + Base64.encodeBase64String(outToken));
/*     */     }
/*     */     catch (GSSException e)
/*     */     {
/* 247 */       if (log.isDebugEnabled()) {
/* 248 */         log.debug(sm.getString("spnegoAuthenticator.ticketValidateFail"), e);
/*     */       }
/* 250 */       response.setHeader("WWW-Authenticate", "Negotiate");
/* 251 */       response.sendError(401);
/* 252 */       return false;
/*     */     } catch (PrivilegedActionException e) {
/* 254 */       cause = e.getCause();
/* 255 */       if ((cause instanceof GSSException)) {
/* 256 */         if (log.isDebugEnabled()) {
/* 257 */           log.debug(sm.getString("spnegoAuthenticator.serviceLoginFail"), e);
/*     */         }
/*     */       } else {
/* 260 */         log.error(sm.getString("spnegoAuthenticator.serviceLoginFail"), e);
/*     */       }
/* 262 */       response.setHeader("WWW-Authenticate", "Negotiate");
/* 263 */       response.sendError(401);
/* 264 */       return 0;
/*     */     } finally {
/* 266 */       if (gssContext != null) {
/*     */         try {
/* 268 */           gssContext.dispose();
/*     */         }
/*     */         catch (GSSException localGSSException6) {}
/*     */       }
/*     */       
/* 273 */       if (lc != null) {
/*     */         try {
/* 275 */           lc.logout();
/*     */         }
/*     */         catch (LoginException localLoginException6) {}
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 286 */     if (principal != null) {
/* 287 */       register(request, response, principal, "SPNEGO", principal.getName(), null);
/*     */       
/*     */ 
/* 290 */       Pattern p = this.noKeepAliveUserAgents;
/* 291 */       if (p != null) {
/* 292 */         MessageBytes ua = request.getCoyoteRequest().getMimeHeaders().getValue("user-agent");
/*     */         
/*     */ 
/* 295 */         if ((ua != null) && (p.matcher(ua.toString()).matches())) {
/* 296 */           response.setHeader("Connection", "close");
/*     */         }
/*     */       }
/* 299 */       return true;
/*     */     }
/*     */     
/* 302 */     response.sendError(401);
/* 303 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public static class AcceptAction
/*     */     implements PrivilegedExceptionAction<byte[]>
/*     */   {
/*     */     GSSContext gssContext;
/*     */     
/*     */     byte[] decoded;
/*     */     
/*     */ 
/*     */     public AcceptAction(GSSContext context, byte[] decodedToken)
/*     */     {
/* 317 */       this.gssContext = context;
/* 318 */       this.decoded = decodedToken;
/*     */     }
/*     */     
/*     */     public byte[] run() throws GSSException
/*     */     {
/* 323 */       return this.gssContext.acceptSecContext(this.decoded, 0, this.decoded.length);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class AuthenticateAction
/*     */     implements PrivilegedAction<Principal>
/*     */   {
/*     */     private final Realm realm;
/*     */     private final GSSContext gssContext;
/*     */     private final boolean storeDelegatedCredential;
/*     */     
/*     */     public AuthenticateAction(Realm realm, GSSContext gssContext, boolean storeDelegatedCredential)
/*     */     {
/* 337 */       this.realm = realm;
/* 338 */       this.gssContext = gssContext;
/* 339 */       this.storeDelegatedCredential = storeDelegatedCredential;
/*     */     }
/*     */     
/*     */     public Principal run()
/*     */     {
/* 344 */       return this.realm.authenticate(this.gssContext, this.storeDelegatedCredential);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Pattern noKeepAliveUserAgents;
/*     */   
/*     */ 
/*     */   private boolean applyJava8u40Fix;
/*     */   
/*     */ 
/*     */   public static class SpnegoTokenFixer
/*     */   {
/*     */     private final byte[] token;
/*     */     
/*     */ 
/*     */ 
/*     */     public static void fix(byte[] token)
/*     */     {
/* 365 */       SpnegoTokenFixer fixer = new SpnegoTokenFixer(token);
/* 366 */       fixer.fix();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 371 */     private int pos = 0;
/*     */     
/*     */     private SpnegoTokenFixer(byte[] token)
/*     */     {
/* 375 */       this.token = token;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void fix()
/*     */     {
/* 390 */       if (!tag(96)) return;
/* 391 */       if (!length()) return;
/* 392 */       if (!oid("1.3.6.1.5.5.2")) return;
/* 393 */       if (!tag(160)) return;
/* 394 */       if (!length()) return;
/* 395 */       if (!tag(48)) return;
/* 396 */       if (!length()) return;
/* 397 */       if (!tag(160)) return;
/* 398 */       lengthAsInt();
/* 399 */       if (!tag(48)) { return;
/*     */       }
/*     */       
/* 402 */       int mechTypesLen = lengthAsInt();
/* 403 */       int mechTypesStart = this.pos;
/* 404 */       LinkedHashMap<String, int[]> mechTypeEntries = new LinkedHashMap();
/* 405 */       while (this.pos < mechTypesStart + mechTypesLen) {
/* 406 */         int[] value = new int[2];
/* 407 */         value[0] = this.pos;
/* 408 */         String key = oidAsString();
/* 409 */         value[1] = (this.pos - value[0]);
/* 410 */         mechTypeEntries.put(key, value);
/*     */       }
/*     */       
/* 413 */       byte[] replacement = new byte[mechTypesLen];
/* 414 */       int replacementPos = 0;
/*     */       
/* 416 */       int[] first = (int[])mechTypeEntries.remove("1.2.840.113554.1.2.2");
/* 417 */       if (first != null) {
/* 418 */         System.arraycopy(this.token, first[0], replacement, replacementPos, first[1]);
/* 419 */         replacementPos += first[1];
/*     */       }
/* 421 */       for (int[] markers : mechTypeEntries.values()) {
/* 422 */         System.arraycopy(this.token, markers[0], replacement, replacementPos, markers[1]);
/* 423 */         replacementPos += markers[1];
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 428 */       System.arraycopy(replacement, 0, this.token, mechTypesStart, mechTypesLen);
/*     */     }
/*     */     
/*     */     private boolean tag(int expected)
/*     */     {
/* 433 */       return (this.token[(this.pos++)] & 0xFF) == expected;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private boolean length()
/*     */     {
/* 440 */       int len = lengthAsInt();
/* 441 */       return this.pos + len == this.token.length;
/*     */     }
/*     */     
/*     */     private int lengthAsInt()
/*     */     {
/* 446 */       int len = this.token[(this.pos++)] & 0xFF;
/* 447 */       if (len > 127) {
/* 448 */         int bytes = len - 128;
/* 449 */         len = 0;
/* 450 */         for (int i = 0; i < bytes; i++) {
/* 451 */           len <<= 8;
/* 452 */           len += (this.token[(this.pos++)] & 0xFF);
/*     */         }
/*     */       }
/* 455 */       return len;
/*     */     }
/*     */     
/*     */     private boolean oid(String expected)
/*     */     {
/* 460 */       return expected.equals(oidAsString());
/*     */     }
/*     */     
/*     */     private String oidAsString()
/*     */     {
/* 465 */       if (!tag(6)) return null;
/* 466 */       StringBuilder result = new StringBuilder();
/* 467 */       int len = lengthAsInt();
/*     */       
/* 469 */       int v = this.token[(this.pos++)] & 0xFF;
/* 470 */       int c2 = v % 40;
/* 471 */       int c1 = (v - c2) / 40;
/* 472 */       result.append(c1);
/* 473 */       result.append('.');
/* 474 */       result.append(c2);
/* 475 */       int c = 0;
/* 476 */       boolean write = false;
/* 477 */       for (int i = 1; i < len; i++) {
/* 478 */         int b = this.token[(this.pos++)] & 0xFF;
/* 479 */         if (b > 127) {
/* 480 */           b -= 128;
/*     */         } else {
/* 482 */           write = true;
/*     */         }
/* 484 */         c <<= 7;
/* 485 */         c += b;
/* 486 */         if (write) {
/* 487 */           result.append('.');
/* 488 */           result.append(c);
/* 489 */           c = 0;
/* 490 */           write = false;
/*     */         }
/*     */       }
/* 493 */       return result.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\authenticator\SpnegoAuthenticator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */