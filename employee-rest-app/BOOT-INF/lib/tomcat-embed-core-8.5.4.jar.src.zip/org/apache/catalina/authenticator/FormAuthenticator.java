/*     */ package org.apache.catalina.authenticator;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.security.Principal;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Manager;
/*     */ import org.apache.catalina.Realm;
/*     */ import org.apache.catalina.Session;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.buf.ByteChunk;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.descriptor.web.LoginConfig;
/*     */ import org.apache.tomcat.util.http.MimeHeaders;
/*     */ import org.apache.tomcat.util.http.Parameters;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormAuthenticator
/*     */   extends AuthenticatorBase
/*     */ {
/*  55 */   private static final Log log = LogFactory.getLog(FormAuthenticator.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  65 */   protected String characterEncoding = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */   protected String landingPage = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCharacterEncoding()
/*     */   {
/*  83 */     return this.characterEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCharacterEncoding(String encoding)
/*     */   {
/*  93 */     this.characterEncoding = encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLandingPage()
/*     */   {
/* 103 */     return this.landingPage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLandingPage(String landingPage)
/*     */   {
/* 114 */     this.landingPage = landingPage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean authenticate(org.apache.catalina.connector.Request request, HttpServletResponse response)
/*     */     throws IOException
/*     */   {
/* 136 */     if (checkForCachedAuthentication(request, response, true)) {
/* 137 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 141 */     Session session = null;
/* 142 */     Principal principal = null;
/*     */     
/*     */ 
/* 145 */     if (!this.cache) {
/* 146 */       session = request.getSessionInternal(true);
/* 147 */       if (log.isDebugEnabled()) {
/* 148 */         log.debug("Checking for reauthenticate in session " + session);
/*     */       }
/* 150 */       String username = (String)session.getNote("org.apache.catalina.session.USERNAME");
/*     */       
/* 152 */       String password = (String)session.getNote("org.apache.catalina.session.PASSWORD");
/*     */       
/* 154 */       if ((username != null) && (password != null)) {
/* 155 */         if (log.isDebugEnabled()) {
/* 156 */           log.debug("Reauthenticating username '" + username + "'");
/*     */         }
/* 158 */         principal = this.context.getRealm().authenticate(username, password);
/*     */         
/* 160 */         if (principal != null) {
/* 161 */           session.setNote("org.apache.catalina.authenticator.PRINCIPAL", principal);
/* 162 */           if (!matchRequest(request)) {
/* 163 */             register(request, response, principal, "FORM", username, password);
/*     */             
/*     */ 
/* 166 */             return true;
/*     */           }
/*     */         }
/* 169 */         if (log.isDebugEnabled()) {
/* 170 */           log.debug("Reauthentication failed, proceed normally");
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 177 */     if (matchRequest(request)) {
/* 178 */       session = request.getSessionInternal(true);
/* 179 */       if (log.isDebugEnabled()) {
/* 180 */         log.debug("Restore request from session '" + session.getIdInternal() + "'");
/*     */       }
/*     */       
/*     */ 
/* 184 */       principal = (Principal)session.getNote("org.apache.catalina.authenticator.PRINCIPAL");
/*     */       
/* 186 */       register(request, response, principal, "FORM", (String)session.getNote("org.apache.catalina.session.USERNAME"), (String)session.getNote("org.apache.catalina.session.PASSWORD"));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 191 */       if (this.cache) {
/* 192 */         session.removeNote("org.apache.catalina.session.USERNAME");
/* 193 */         session.removeNote("org.apache.catalina.session.PASSWORD");
/*     */       }
/* 195 */       if (restoreRequest(request, session)) {
/* 196 */         if (log.isDebugEnabled()) {
/* 197 */           log.debug("Proceed to restored request");
/*     */         }
/* 199 */         return true;
/*     */       }
/* 201 */       if (log.isDebugEnabled()) {
/* 202 */         log.debug("Restore of original request failed");
/*     */       }
/* 204 */       response.sendError(400);
/* 205 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 210 */     String contextPath = request.getContextPath();
/* 211 */     String requestURI = request.getDecodedRequestURI();
/*     */     
/*     */ 
/* 214 */     boolean loginAction = (requestURI.startsWith(contextPath)) && (requestURI.endsWith("/j_security_check"));
/*     */     
/*     */ 
/*     */ 
/* 218 */     LoginConfig config = this.context.getLoginConfig();
/*     */     
/*     */ 
/* 221 */     if (!loginAction)
/*     */     {
/*     */ 
/*     */ 
/* 225 */       if ((request.getServletPath().length() == 0) && (request.getPathInfo() == null)) {
/* 226 */         StringBuilder location = new StringBuilder(requestURI);
/* 227 */         location.append('/');
/* 228 */         if (request.getQueryString() != null) {
/* 229 */           location.append('?');
/* 230 */           location.append(request.getQueryString());
/*     */         }
/* 232 */         response.sendRedirect(response.encodeRedirectURL(location.toString()));
/* 233 */         return false;
/*     */       }
/*     */       
/* 236 */       session = request.getSessionInternal(true);
/* 237 */       if (log.isDebugEnabled()) {
/* 238 */         log.debug("Save request in session '" + session.getIdInternal() + "'");
/*     */       }
/*     */       try {
/* 241 */         saveRequest(request, session);
/*     */       } catch (IOException ioe) {
/* 243 */         log.debug("Request body too big to save during authentication");
/* 244 */         response.sendError(403, sm.getString("authenticator.requestBodyTooBig"));
/*     */         
/* 246 */         return false;
/*     */       }
/* 248 */       forwardToLoginPage(request, response, config);
/* 249 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 254 */     request.getResponse().sendAcknowledgement();
/* 255 */     Realm realm = this.context.getRealm();
/* 256 */     if (this.characterEncoding != null) {
/* 257 */       request.setCharacterEncoding(this.characterEncoding);
/*     */     }
/* 259 */     String username = request.getParameter("j_username");
/* 260 */     String password = request.getParameter("j_password");
/* 261 */     if (log.isDebugEnabled()) {
/* 262 */       log.debug("Authenticating username '" + username + "'");
/*     */     }
/* 264 */     principal = realm.authenticate(username, password);
/* 265 */     if (principal == null) {
/* 266 */       forwardToErrorPage(request, response, config);
/* 267 */       return false;
/*     */     }
/*     */     
/* 270 */     if (log.isDebugEnabled()) {
/* 271 */       log.debug("Authentication of '" + username + "' was successful");
/*     */     }
/*     */     
/* 274 */     if (session == null) {
/* 275 */       session = request.getSessionInternal(false);
/*     */     }
/* 277 */     if (session == null) {
/* 278 */       if (this.containerLog.isDebugEnabled()) {
/* 279 */         this.containerLog.debug("User took so long to log on the session expired");
/*     */       }
/*     */       
/* 282 */       if (this.landingPage == null) {
/* 283 */         response.sendError(408, sm.getString("authenticator.sessionExpired"));
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 288 */         String uri = request.getContextPath() + this.landingPage;
/* 289 */         SavedRequest saved = new SavedRequest();
/* 290 */         saved.setMethod("GET");
/* 291 */         saved.setRequestURI(uri);
/* 292 */         saved.setDecodedRequestURI(uri);
/* 293 */         request.getSessionInternal(true).setNote("org.apache.catalina.authenticator.REQUEST", saved);
/*     */         
/* 295 */         response.sendRedirect(response.encodeRedirectURL(uri));
/*     */       }
/* 297 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 301 */     session.setNote("org.apache.catalina.authenticator.PRINCIPAL", principal);
/*     */     
/*     */ 
/* 304 */     session.setNote("org.apache.catalina.session.USERNAME", username);
/* 305 */     session.setNote("org.apache.catalina.session.PASSWORD", password);
/*     */     
/*     */ 
/*     */ 
/* 309 */     requestURI = savedRequestURL(session);
/* 310 */     if (log.isDebugEnabled()) {
/* 311 */       log.debug("Redirecting to original '" + requestURI + "'");
/*     */     }
/* 313 */     if (requestURI == null) {
/* 314 */       if (this.landingPage == null) {
/* 315 */         response.sendError(400, sm.getString("authenticator.formlogin"));
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 320 */         String uri = request.getContextPath() + this.landingPage;
/* 321 */         SavedRequest saved = new SavedRequest();
/* 322 */         saved.setMethod("GET");
/* 323 */         saved.setRequestURI(uri);
/* 324 */         saved.setDecodedRequestURI(uri);
/* 325 */         session.setNote("org.apache.catalina.authenticator.REQUEST", saved);
/* 326 */         response.sendRedirect(response.encodeRedirectURL(uri));
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 331 */       Response internalResponse = request.getResponse();
/* 332 */       String location = response.encodeRedirectURL(requestURI);
/* 333 */       if ("HTTP/1.1".equals(request.getProtocol())) {
/* 334 */         internalResponse.sendRedirect(location, 303);
/*     */       }
/*     */       else {
/* 337 */         internalResponse.sendRedirect(location, 302);
/*     */       }
/*     */     }
/*     */     
/* 341 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String getAuthMethod()
/*     */   {
/* 348 */     return "FORM";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void forwardToLoginPage(org.apache.catalina.connector.Request request, HttpServletResponse response, LoginConfig config)
/*     */     throws IOException
/*     */   {
/* 370 */     if (log.isDebugEnabled()) {
/* 371 */       log.debug(sm.getString("formAuthenticator.forwardLogin", new Object[] { request.getRequestURI(), request.getMethod(), config.getLoginPage(), this.context.getName() }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 376 */     String loginPage = config.getLoginPage();
/* 377 */     if ((loginPage == null) || (loginPage.length() == 0)) {
/* 378 */       String msg = sm.getString("formAuthenticator.noLoginPage", new Object[] { this.context.getName() });
/*     */       
/* 380 */       log.warn(msg);
/* 381 */       response.sendError(500, msg);
/*     */       
/* 383 */       return;
/*     */     }
/*     */     
/* 386 */     if (getChangeSessionIdOnAuthentication()) {
/* 387 */       Session session = request.getSessionInternal(false);
/* 388 */       if (session != null) {
/* 389 */         Manager manager = request.getContext().getManager();
/* 390 */         manager.changeSessionId(session);
/* 391 */         request.changeSessionId(session.getId());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 396 */     String oldMethod = request.getMethod();
/* 397 */     request.getCoyoteRequest().method().setString("GET");
/*     */     
/* 399 */     RequestDispatcher disp = this.context.getServletContext().getRequestDispatcher(loginPage);
/*     */     try
/*     */     {
/* 402 */       if (this.context.fireRequestInitEvent(request)) {
/* 403 */         disp.forward(request.getRequest(), response);
/* 404 */         this.context.fireRequestDestroyEvent(request);
/*     */       }
/*     */     } catch (Throwable t) {
/* 407 */       ExceptionUtils.handleThrowable(t);
/* 408 */       String msg = sm.getString("formAuthenticator.forwardLoginFail");
/* 409 */       log.warn(msg, t);
/* 410 */       request.setAttribute("javax.servlet.error.exception", t);
/* 411 */       response.sendError(500, msg);
/*     */     }
/*     */     finally
/*     */     {
/* 415 */       request.getCoyoteRequest().method().setString(oldMethod);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void forwardToErrorPage(org.apache.catalina.connector.Request request, HttpServletResponse response, LoginConfig config)
/*     */     throws IOException
/*     */   {
/* 435 */     String errorPage = config.getErrorPage();
/* 436 */     if ((errorPage == null) || (errorPage.length() == 0)) {
/* 437 */       String msg = sm.getString("formAuthenticator.noErrorPage", new Object[] { this.context.getName() });
/*     */       
/* 439 */       log.warn(msg);
/* 440 */       response.sendError(500, msg);
/*     */       
/* 442 */       return;
/*     */     }
/*     */     
/* 445 */     RequestDispatcher disp = this.context.getServletContext().getRequestDispatcher(config.getErrorPage());
/*     */     
/*     */     try
/*     */     {
/* 449 */       if (this.context.fireRequestInitEvent(request)) {
/* 450 */         disp.forward(request.getRequest(), response);
/* 451 */         this.context.fireRequestDestroyEvent(request);
/*     */       }
/*     */     } catch (Throwable t) {
/* 454 */       ExceptionUtils.handleThrowable(t);
/* 455 */       String msg = sm.getString("formAuthenticator.forwardErrorFail");
/* 456 */       log.warn(msg, t);
/* 457 */       request.setAttribute("javax.servlet.error.exception", t);
/* 458 */       response.sendError(500, msg);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean matchRequest(org.apache.catalina.connector.Request request)
/*     */   {
/* 473 */     Session session = request.getSessionInternal(false);
/* 474 */     if (session == null) {
/* 475 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 479 */     SavedRequest sreq = (SavedRequest)session.getNote("org.apache.catalina.authenticator.REQUEST");
/*     */     
/* 481 */     if (sreq == null) {
/* 482 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 486 */     if (session.getNote("org.apache.catalina.authenticator.PRINCIPAL") == null) {
/* 487 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 491 */     String decodedRequestURI = request.getDecodedRequestURI();
/* 492 */     if (decodedRequestURI == null) {
/* 493 */       return false;
/*     */     }
/* 495 */     return decodedRequestURI.equals(sreq.getDecodedRequestURI());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean restoreRequest(org.apache.catalina.connector.Request request, Session session)
/*     */     throws IOException
/*     */   {
/* 514 */     SavedRequest saved = (SavedRequest)session.getNote("org.apache.catalina.authenticator.REQUEST");
/*     */     
/* 516 */     session.removeNote("org.apache.catalina.authenticator.REQUEST");
/* 517 */     session.removeNote("org.apache.catalina.authenticator.PRINCIPAL");
/* 518 */     if (saved == null) {
/* 519 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 526 */     byte[] buffer = new byte['က'];
/* 527 */     InputStream is = request.createInputStream();
/* 528 */     while (is.read(buffer) >= 0) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 533 */     request.clearCookies();
/* 534 */     Iterator<Cookie> cookies = saved.getCookies();
/* 535 */     while (cookies.hasNext()) {
/* 536 */       request.addCookie((Cookie)cookies.next());
/*     */     }
/*     */     
/* 539 */     String method = saved.getMethod();
/* 540 */     MimeHeaders rmh = request.getCoyoteRequest().getMimeHeaders();
/* 541 */     rmh.recycle();
/* 542 */     boolean cachable = ("GET".equalsIgnoreCase(method)) || ("HEAD".equalsIgnoreCase(method));
/*     */     
/* 544 */     Iterator<String> names = saved.getHeaderNames();
/* 545 */     while (names.hasNext()) {
/* 546 */       String name = (String)names.next();
/*     */       
/*     */ 
/*     */ 
/* 550 */       if ((!"If-Modified-Since".equalsIgnoreCase(name)) && ((!cachable) || (!"If-None-Match".equalsIgnoreCase(name))))
/*     */       {
/* 552 */         Iterator<String> values = saved.getHeaderValues(name);
/* 553 */         while (values.hasNext()) {
/* 554 */           rmh.addValue(name).setString((String)values.next());
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 559 */     request.clearLocales();
/* 560 */     Iterator<Locale> locales = saved.getLocales();
/* 561 */     while (locales.hasNext()) {
/* 562 */       request.addLocale((Locale)locales.next());
/*     */     }
/*     */     
/* 565 */     request.getCoyoteRequest().getParameters().recycle();
/* 566 */     request.getCoyoteRequest().getParameters().setQueryStringEncoding(request.getConnector().getURIEncoding());
/*     */     
/*     */ 
/* 569 */     ByteChunk body = saved.getBody();
/*     */     
/* 571 */     if (body != null) {
/* 572 */       request.getCoyoteRequest().action(ActionCode.REQ_SET_BODY_REPLAY, body);
/*     */       
/*     */ 
/*     */ 
/* 576 */       MessageBytes contentType = MessageBytes.newInstance();
/*     */       
/*     */ 
/* 579 */       String savedContentType = saved.getContentType();
/* 580 */       if ((savedContentType == null) && ("POST".equalsIgnoreCase(method))) {
/* 581 */         savedContentType = "application/x-www-form-urlencoded";
/*     */       }
/*     */       
/* 584 */       contentType.setString(savedContentType);
/* 585 */       request.getCoyoteRequest().setContentType(contentType);
/*     */     }
/*     */     
/* 588 */     request.getCoyoteRequest().method().setString(method);
/*     */     
/* 590 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void saveRequest(org.apache.catalina.connector.Request request, Session session)
/*     */     throws IOException
/*     */   {
/* 605 */     SavedRequest saved = new SavedRequest();
/* 606 */     Cookie[] cookies = request.getCookies();
/* 607 */     if (cookies != null) {
/* 608 */       for (int i = 0; i < cookies.length; i++) {
/* 609 */         saved.addCookie(cookies[i]);
/*     */       }
/*     */     }
/* 612 */     Enumeration<String> names = request.getHeaderNames();
/* 613 */     while (names.hasMoreElements()) {
/* 614 */       String name = (String)names.nextElement();
/* 615 */       Enumeration<String> values = request.getHeaders(name);
/* 616 */       while (values.hasMoreElements()) {
/* 617 */         String value = (String)values.nextElement();
/* 618 */         saved.addHeader(name, value);
/*     */       }
/*     */     }
/* 621 */     Enumeration<Locale> locales = request.getLocales();
/* 622 */     while (locales.hasMoreElements()) {
/* 623 */       Locale locale = (Locale)locales.nextElement();
/* 624 */       saved.addLocale(locale);
/*     */     }
/*     */     
/*     */ 
/* 628 */     request.getResponse().sendAcknowledgement();
/*     */     
/* 630 */     ByteChunk body = new ByteChunk();
/* 631 */     body.setLimit(request.getConnector().getMaxSavePostSize());
/*     */     
/* 633 */     byte[] buffer = new byte['က'];
/*     */     
/* 635 */     InputStream is = request.getInputStream();
/*     */     int bytesRead;
/* 637 */     while ((bytesRead = is.read(buffer)) >= 0) {
/* 638 */       body.append(buffer, 0, bytesRead);
/*     */     }
/*     */     
/*     */ 
/* 642 */     if (body.getLength() > 0) {
/* 643 */       saved.setContentType(request.getContentType());
/* 644 */       saved.setBody(body);
/*     */     }
/*     */     
/* 647 */     saved.setMethod(request.getMethod());
/* 648 */     saved.setQueryString(request.getQueryString());
/* 649 */     saved.setRequestURI(request.getRequestURI());
/* 650 */     saved.setDecodedRequestURI(request.getDecodedRequestURI());
/*     */     
/*     */ 
/* 653 */     session.setNote("org.apache.catalina.authenticator.REQUEST", saved);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String savedRequestURL(Session session)
/*     */   {
/* 666 */     SavedRequest saved = (SavedRequest)session.getNote("org.apache.catalina.authenticator.REQUEST");
/*     */     
/* 668 */     if (saved == null) {
/* 669 */       return null;
/*     */     }
/* 671 */     StringBuilder sb = new StringBuilder(saved.getRequestURI());
/* 672 */     if (saved.getQueryString() != null) {
/* 673 */       sb.append('?');
/* 674 */       sb.append(saved.getQueryString());
/*     */     }
/* 676 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\authenticator\FormAuthenticator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */