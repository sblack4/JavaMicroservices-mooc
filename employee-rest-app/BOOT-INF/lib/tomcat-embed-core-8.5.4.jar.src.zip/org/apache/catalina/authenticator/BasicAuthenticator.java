/*     */ package org.apache.catalina.authenticator;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.Principal;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Realm;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.buf.ByteChunk;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.codec.binary.Base64;
/*     */ import org.apache.tomcat.util.http.MimeHeaders;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicAuthenticator
/*     */   extends AuthenticatorBase
/*     */ {
/*  46 */   private static final Log log = LogFactory.getLog(BasicAuthenticator.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean authenticate(org.apache.catalina.connector.Request request, HttpServletResponse response)
/*     */     throws IOException
/*     */   {
/*  66 */     if (checkForCachedAuthentication(request, response, true)) {
/*  67 */       return true;
/*     */     }
/*     */     
/*     */ 
/*  71 */     MessageBytes authorization = request.getCoyoteRequest().getMimeHeaders().getValue("authorization");
/*     */     
/*     */ 
/*     */ 
/*  75 */     if (authorization != null) {
/*  76 */       authorization.toBytes();
/*  77 */       ByteChunk authorizationBC = authorization.getByteChunk();
/*  78 */       BasicCredentials credentials = null;
/*     */       try {
/*  80 */         credentials = new BasicCredentials(authorizationBC);
/*  81 */         String username = credentials.getUsername();
/*  82 */         String password = credentials.getPassword();
/*     */         
/*  84 */         Principal principal = this.context.getRealm().authenticate(username, password);
/*  85 */         if (principal != null) {
/*  86 */           register(request, response, principal, "BASIC", username, password);
/*     */           
/*  88 */           return true;
/*     */         }
/*     */       }
/*     */       catch (IllegalArgumentException iae) {
/*  92 */         if (log.isDebugEnabled()) {
/*  93 */           log.debug("Invalid Authorization" + iae.getMessage());
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  99 */     StringBuilder value = new StringBuilder(16);
/* 100 */     value.append("Basic realm=\"");
/* 101 */     value.append(getRealmName(this.context));
/* 102 */     value.append('"');
/* 103 */     response.setHeader("WWW-Authenticate", value.toString());
/* 104 */     response.sendError(401);
/* 105 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   protected String getAuthMethod()
/*     */   {
/* 111 */     return "BASIC";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class BasicCredentials
/*     */   {
/*     */     private static final String METHOD = "basic ";
/*     */     
/*     */ 
/*     */     private ByteChunk authorization;
/*     */     
/*     */ 
/*     */     private int initialOffset;
/*     */     
/*     */ 
/*     */     private int base64blobOffset;
/*     */     
/*     */     private int base64blobLength;
/*     */     
/* 131 */     private String username = null;
/* 132 */     private String password = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public BasicCredentials(ByteChunk input)
/*     */       throws IllegalArgumentException
/*     */     {
/* 146 */       this.authorization = input;
/* 147 */       this.initialOffset = input.getOffset();
/* 148 */       parseMethod();
/* 149 */       byte[] decoded = parseBase64();
/* 150 */       parseCredentials(decoded);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getUsername()
/*     */     {
/* 160 */       return this.username;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getPassword()
/*     */     {
/* 170 */       return this.password;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private void parseMethod()
/*     */       throws IllegalArgumentException
/*     */     {
/* 178 */       if (this.authorization.startsWithIgnoreCase("basic ", 0))
/*     */       {
/* 180 */         this.base64blobOffset = (this.initialOffset + "basic ".length());
/* 181 */         this.base64blobLength = (this.authorization.getLength() - "basic ".length());
/*     */       }
/*     */       else
/*     */       {
/* 185 */         throw new IllegalArgumentException("Authorization header method is not \"Basic\"");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private byte[] parseBase64()
/*     */       throws IllegalArgumentException
/*     */     {
/* 196 */       byte[] decoded = Base64.decodeBase64(this.authorization.getBuffer(), this.base64blobOffset, this.base64blobLength);
/*     */       
/*     */ 
/*     */ 
/* 200 */       this.authorization.setOffset(this.initialOffset);
/* 201 */       if (decoded == null) {
/* 202 */         throw new IllegalArgumentException("Basic Authorization credentials are not Base64");
/*     */       }
/*     */       
/* 205 */       return decoded;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void parseCredentials(byte[] decoded)
/*     */       throws IllegalArgumentException
/*     */     {
/* 215 */       int colon = -1;
/* 216 */       for (int i = 0; i < decoded.length; i++) {
/* 217 */         if (decoded[i] == 58) {
/* 218 */           colon = i;
/* 219 */           break;
/*     */         }
/*     */       }
/*     */       
/* 223 */       if (colon < 0) {
/* 224 */         this.username = new String(decoded, StandardCharsets.ISO_8859_1);
/*     */       }
/*     */       else
/*     */       {
/* 228 */         this.username = new String(decoded, 0, colon, StandardCharsets.ISO_8859_1);
/*     */         
/* 230 */         this.password = new String(decoded, colon + 1, decoded.length - colon - 1, StandardCharsets.ISO_8859_1);
/*     */         
/*     */ 
/*     */ 
/* 234 */         if (this.password.length() > 1) {
/* 235 */           this.password = this.password.trim();
/*     */         }
/*     */       }
/*     */       
/* 239 */       if (this.username.length() > 1) {
/* 240 */         this.username = this.username.trim();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\authenticator\BasicAuthenticator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */