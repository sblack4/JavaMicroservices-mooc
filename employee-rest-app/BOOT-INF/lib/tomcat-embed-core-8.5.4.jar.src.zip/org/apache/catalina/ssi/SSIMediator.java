/*     */ package org.apache.catalina.ssi;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import java.util.TimeZone;
/*     */ import org.apache.catalina.util.RequestUtil;
/*     */ import org.apache.catalina.util.Strftime;
/*     */ import org.apache.catalina.util.URLEncoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SSIMediator
/*     */ {
/*  47 */   protected String configErrMsg = "[an error occurred while processing this directive]";
/*  48 */   protected String configTimeFmt = "%A, %d-%b-%Y %T %Z";
/*  49 */   protected String configSizeFmt = "abbrev";
/*  50 */   protected final String className = getClass().getName();
/*     */   
/*     */ 
/*     */ 
/*  54 */   protected final SSIConditionalState conditionalState = new SSIConditionalState();
/*     */   
/*     */ 
/*  57 */   protected static final URLEncoder urlEncoder = new URLEncoder();
/*  58 */   static { urlEncoder.addSafeCharacter(',');
/*  59 */     urlEncoder.addSafeCharacter(':');
/*  60 */     urlEncoder.addSafeCharacter('-');
/*  61 */     urlEncoder.addSafeCharacter('_');
/*  62 */     urlEncoder.addSafeCharacter('.');
/*  63 */     urlEncoder.addSafeCharacter('*');
/*  64 */     urlEncoder.addSafeCharacter('/');
/*  65 */     urlEncoder.addSafeCharacter('!');
/*  66 */     urlEncoder.addSafeCharacter('~');
/*  67 */     urlEncoder.addSafeCharacter('\'');
/*  68 */     urlEncoder.addSafeCharacter('(');
/*  69 */     urlEncoder.addSafeCharacter(')');
/*     */   }
/*     */   
/*     */ 
/*     */   public SSIMediator(SSIExternalResolver ssiExternalResolver, long lastModifiedDate)
/*     */   {
/*  75 */     this.ssiExternalResolver = ssiExternalResolver;
/*  76 */     this.lastModifiedDate = lastModifiedDate;
/*  77 */     setConfigTimeFmt("%A, %d-%b-%Y %T %Z", true);
/*     */   }
/*     */   
/*     */   public void setConfigErrMsg(String configErrMsg)
/*     */   {
/*  82 */     this.configErrMsg = configErrMsg;
/*     */   }
/*     */   
/*     */   public void setConfigTimeFmt(String configTimeFmt)
/*     */   {
/*  87 */     setConfigTimeFmt(configTimeFmt, false);
/*     */   }
/*     */   
/*     */   public void setConfigTimeFmt(String configTimeFmt, boolean fromConstructor)
/*     */   {
/*  92 */     this.configTimeFmt = configTimeFmt;
/*  93 */     this.strftime = new Strftime(configTimeFmt, Locale.US);
/*     */     
/*     */ 
/*     */ 
/*  97 */     setDateVariables(fromConstructor);
/*     */   }
/*     */   
/*     */   public void setConfigSizeFmt(String configSizeFmt)
/*     */   {
/* 102 */     this.configSizeFmt = configSizeFmt;
/*     */   }
/*     */   
/*     */   public String getConfigErrMsg()
/*     */   {
/* 107 */     return this.configErrMsg;
/*     */   }
/*     */   
/*     */   public String getConfigTimeFmt()
/*     */   {
/* 112 */     return this.configTimeFmt;
/*     */   }
/*     */   
/*     */   public String getConfigSizeFmt()
/*     */   {
/* 117 */     return this.configSizeFmt;
/*     */   }
/*     */   
/*     */   public SSIConditionalState getConditionalState()
/*     */   {
/* 122 */     return this.conditionalState;
/*     */   }
/*     */   
/*     */   public Collection<String> getVariableNames()
/*     */   {
/* 127 */     Set<String> variableNames = new HashSet();
/*     */     
/*     */ 
/*     */ 
/* 131 */     variableNames.add("DATE_GMT");
/* 132 */     variableNames.add("DATE_LOCAL");
/* 133 */     variableNames.add("LAST_MODIFIED");
/* 134 */     this.ssiExternalResolver.addVariableNames(variableNames);
/*     */     
/* 136 */     Iterator<String> iter = variableNames.iterator();
/* 137 */     while (iter.hasNext()) {
/* 138 */       String name = (String)iter.next();
/* 139 */       if (isNameReserved(name)) {
/* 140 */         iter.remove();
/*     */       }
/*     */     }
/* 143 */     return variableNames;
/*     */   }
/*     */   
/*     */   public long getFileSize(String path, boolean virtual) throws IOException
/*     */   {
/* 148 */     return this.ssiExternalResolver.getFileSize(path, virtual);
/*     */   }
/*     */   
/*     */   public long getFileLastModified(String path, boolean virtual)
/*     */     throws IOException
/*     */   {
/* 154 */     return this.ssiExternalResolver.getFileLastModified(path, virtual);
/*     */   }
/*     */   
/*     */   public String getFileText(String path, boolean virtual) throws IOException
/*     */   {
/* 159 */     return this.ssiExternalResolver.getFileText(path, virtual);
/*     */   }
/*     */   
/*     */   protected boolean isNameReserved(String name)
/*     */   {
/* 164 */     return name.startsWith(this.className + ".");
/*     */   }
/*     */   
/*     */   public String getVariableValue(String variableName)
/*     */   {
/* 169 */     return getVariableValue(variableName, "none");
/*     */   }
/*     */   
/*     */   public void setVariableValue(String variableName, String variableValue)
/*     */   {
/* 174 */     if (!isNameReserved(variableName)) {
/* 175 */       this.ssiExternalResolver.setVariableValue(variableName, variableValue);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getVariableValue(String variableName, String encoding)
/*     */   {
/* 181 */     String lowerCaseVariableName = variableName.toLowerCase(Locale.ENGLISH);
/* 182 */     String variableValue = null;
/* 183 */     if (!isNameReserved(lowerCaseVariableName))
/*     */     {
/*     */ 
/*     */ 
/* 187 */       variableValue = this.ssiExternalResolver.getVariableValue(variableName);
/* 188 */       if (variableValue == null) {
/* 189 */         variableName = variableName.toUpperCase(Locale.ENGLISH);
/* 190 */         variableValue = this.ssiExternalResolver.getVariableValue(this.className + "." + variableName);
/*     */       }
/*     */       
/* 193 */       if (variableValue != null) {
/* 194 */         variableValue = encode(variableValue, encoding);
/*     */       }
/*     */     }
/* 197 */     return variableValue;
/*     */   }
/*     */   
/*     */ 
/*     */   protected static final String DEFAULT_CONFIG_ERR_MSG = "[an error occurred while processing this directive]";
/*     */   
/*     */   protected static final String DEFAULT_CONFIG_TIME_FMT = "%A, %d-%b-%Y %T %Z";
/*     */   protected static final String DEFAULT_CONFIG_SIZE_FMT = "abbrev";
/*     */   protected final SSIExternalResolver ssiExternalResolver;
/*     */   protected final long lastModifiedDate;
/*     */   protected Strftime strftime;
/*     */   public String substituteVariables(String val)
/*     */   {
/* 210 */     if ((val.indexOf('$') < 0) && (val.indexOf('&') < 0)) { return val;
/*     */     }
/*     */     
/* 213 */     val = val.replace("&lt;", "<");
/* 214 */     val = val.replace("&gt;", ">");
/* 215 */     val = val.replace("&quot;", "\"");
/* 216 */     val = val.replace("&amp;", "&");
/*     */     
/* 218 */     StringBuilder sb = new StringBuilder(val);
/* 219 */     int charStart = sb.indexOf("&#");
/* 220 */     while (charStart > -1) {
/* 221 */       int charEnd = sb.indexOf(";", charStart);
/* 222 */       if (charEnd <= -1) break;
/* 223 */       char c = (char)Integer.parseInt(sb.substring(charStart + 2, charEnd));
/*     */       
/* 225 */       sb.delete(charStart, charEnd + 1);
/* 226 */       sb.insert(charStart, c);
/* 227 */       charStart = sb.indexOf("&#");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 233 */     for (int i = 0; i < sb.length();)
/*     */     {
/* 235 */       for (; i < sb.length(); i++) {
/* 236 */         if (sb.charAt(i) == '$') {
/* 237 */           i++;
/* 238 */           break;
/*     */         }
/*     */       }
/* 241 */       if (i == sb.length())
/*     */         break;
/* 243 */       if ((i > 1) && (sb.charAt(i - 2) == '\\')) {
/* 244 */         sb.deleteCharAt(i - 2);
/* 245 */         i--;
/*     */       }
/*     */       else {
/* 248 */         int nameStart = i;
/* 249 */         int start = i - 1;
/* 250 */         int end = -1;
/* 251 */         int nameEnd = -1;
/* 252 */         char endChar = ' ';
/*     */         
/* 254 */         if (sb.charAt(i) == '{') {
/* 255 */           nameStart++;
/* 256 */           endChar = '}';
/*     */         }
/* 259 */         for (; 
/* 259 */             i < sb.length(); i++)
/* 260 */           if (sb.charAt(i) == endChar)
/*     */             break;
/* 262 */         end = i;
/* 263 */         nameEnd = end;
/* 264 */         if (endChar == '}') { end++;
/*     */         }
/* 266 */         String varName = sb.substring(nameStart, nameEnd);
/* 267 */         String value = getVariableValue(varName);
/* 268 */         if (value == null) { value = "";
/*     */         }
/* 270 */         sb.replace(start, end, value);
/*     */         
/*     */ 
/* 273 */         i = start + value.length();
/*     */       } }
/* 275 */     return sb.toString();
/*     */   }
/*     */   
/*     */   protected String formatDate(Date date, TimeZone timeZone)
/*     */   {
/*     */     String retVal;
/* 281 */     if (timeZone != null)
/*     */     {
/*     */ 
/*     */ 
/* 285 */       TimeZone oldTimeZone = this.strftime.getTimeZone();
/* 286 */       this.strftime.setTimeZone(timeZone);
/* 287 */       String retVal = this.strftime.format(date);
/* 288 */       this.strftime.setTimeZone(oldTimeZone);
/*     */     } else {
/* 290 */       retVal = this.strftime.format(date);
/*     */     }
/* 292 */     return retVal;
/*     */   }
/*     */   
/*     */   protected String encode(String value, String encoding)
/*     */   {
/* 297 */     String retVal = null;
/* 298 */     if (encoding.equalsIgnoreCase("url")) {
/* 299 */       retVal = urlEncoder.encode(value);
/* 300 */     } else if (encoding.equalsIgnoreCase("none")) {
/* 301 */       retVal = value;
/* 302 */     } else if (encoding.equalsIgnoreCase("entity")) {
/* 303 */       retVal = RequestUtil.filter(value);
/*     */     }
/*     */     else {
/* 306 */       throw new IllegalArgumentException("Unknown encoding: " + encoding);
/*     */     }
/* 308 */     return retVal;
/*     */   }
/*     */   
/*     */   public void log(String message)
/*     */   {
/* 313 */     this.ssiExternalResolver.log(message, null);
/*     */   }
/*     */   
/*     */   public void log(String message, Throwable throwable)
/*     */   {
/* 318 */     this.ssiExternalResolver.log(message, throwable);
/*     */   }
/*     */   
/*     */   protected void setDateVariables(boolean fromConstructor)
/*     */   {
/* 323 */     boolean alreadySet = this.ssiExternalResolver.getVariableValue(this.className + ".alreadyset") != null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 328 */     if ((!fromConstructor) || (!alreadySet)) {
/* 329 */       this.ssiExternalResolver.setVariableValue(this.className + ".alreadyset", "true");
/*     */       
/* 331 */       Date date = new Date();
/* 332 */       TimeZone timeZone = TimeZone.getTimeZone("GMT");
/* 333 */       String retVal = formatDate(date, timeZone);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 338 */       setVariableValue("DATE_GMT", null);
/* 339 */       this.ssiExternalResolver.setVariableValue(this.className + ".DATE_GMT", retVal);
/*     */       
/* 341 */       retVal = formatDate(date, null);
/* 342 */       setVariableValue("DATE_LOCAL", null);
/* 343 */       this.ssiExternalResolver.setVariableValue(this.className + ".DATE_LOCAL", retVal);
/*     */       
/* 345 */       retVal = formatDate(new Date(this.lastModifiedDate), null);
/* 346 */       setVariableValue("LAST_MODIFIED", null);
/* 347 */       this.ssiExternalResolver.setVariableValue(this.className + ".LAST_MODIFIED", retVal);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\ssi\SSIMediator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */