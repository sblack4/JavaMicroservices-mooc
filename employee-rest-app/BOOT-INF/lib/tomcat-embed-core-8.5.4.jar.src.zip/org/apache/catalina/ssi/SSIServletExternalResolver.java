/*     */ package org.apache.catalina.ssi;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLDecoder;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Locale;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.tomcat.util.buf.B2CConverter;
/*     */ import org.apache.tomcat.util.http.RequestUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SSIServletExternalResolver
/*     */   implements SSIExternalResolver
/*     */ {
/*  48 */   protected final String[] VARIABLE_NAMES = { "AUTH_TYPE", "CONTENT_LENGTH", "CONTENT_TYPE", "DOCUMENT_NAME", "DOCUMENT_URI", "GATEWAY_INTERFACE", "HTTP_ACCEPT", "HTTP_ACCEPT_ENCODING", "HTTP_ACCEPT_LANGUAGE", "HTTP_CONNECTION", "HTTP_HOST", "HTTP_REFERER", "HTTP_USER_AGENT", "PATH_INFO", "PATH_TRANSLATED", "QUERY_STRING", "QUERY_STRING_UNESCAPED", "REMOTE_ADDR", "REMOTE_HOST", "REMOTE_PORT", "REMOTE_USER", "REQUEST_METHOD", "REQUEST_URI", "SCRIPT_FILENAME", "SCRIPT_NAME", "SERVER_ADDR", "SERVER_NAME", "SERVER_PORT", "SERVER_PROTOCOL", "SERVER_SOFTWARE", "UNIQUE_ID" };
/*     */   
/*     */ 
/*     */   protected final ServletContext context;
/*     */   
/*     */ 
/*     */   protected final HttpServletRequest req;
/*     */   
/*     */ 
/*     */   protected final HttpServletResponse res;
/*     */   
/*     */   protected final boolean isVirtualWebappRelative;
/*     */   
/*     */   protected final int debug;
/*     */   
/*     */   protected final String inputEncoding;
/*     */   
/*     */ 
/*     */   public SSIServletExternalResolver(ServletContext context, HttpServletRequest req, HttpServletResponse res, boolean isVirtualWebappRelative, int debug, String inputEncoding)
/*     */   {
/*  68 */     this.context = context;
/*  69 */     this.req = req;
/*  70 */     this.res = res;
/*  71 */     this.isVirtualWebappRelative = isVirtualWebappRelative;
/*  72 */     this.debug = debug;
/*  73 */     this.inputEncoding = inputEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void log(String message, Throwable throwable)
/*     */   {
/*  82 */     if (throwable != null) {
/*  83 */       this.context.log(message, throwable);
/*     */     } else {
/*  85 */       this.context.log(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void addVariableNames(Collection<String> variableNames)
/*     */   {
/*  92 */     for (int i = 0; i < this.VARIABLE_NAMES.length; i++) {
/*  93 */       String variableName = this.VARIABLE_NAMES[i];
/*  94 */       String variableValue = getVariableValue(variableName);
/*  95 */       if (variableValue != null) {
/*  96 */         variableNames.add(variableName);
/*     */       }
/*     */     }
/*  99 */     Enumeration<String> e = this.req.getAttributeNames();
/* 100 */     while (e.hasMoreElements()) {
/* 101 */       String name = (String)e.nextElement();
/* 102 */       if (!isNameReserved(name)) {
/* 103 */         variableNames.add(name);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected Object getReqAttributeIgnoreCase(String targetName)
/*     */   {
/* 110 */     Object object = null;
/* 111 */     if (!isNameReserved(targetName)) {
/* 112 */       object = this.req.getAttribute(targetName);
/* 113 */       if (object == null) {
/* 114 */         Enumeration<String> e = this.req.getAttributeNames();
/* 115 */         while (e.hasMoreElements()) {
/* 116 */           String name = (String)e.nextElement();
/* 117 */           if ((targetName.equalsIgnoreCase(name)) && (!isNameReserved(name)))
/*     */           {
/* 119 */             object = this.req.getAttribute(name);
/* 120 */             if (object != null) {
/*     */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 127 */     return object;
/*     */   }
/*     */   
/*     */   protected boolean isNameReserved(String name)
/*     */   {
/* 132 */     return (name.startsWith("java.")) || (name.startsWith("javax.")) || (name.startsWith("sun."));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setVariableValue(String name, String value)
/*     */   {
/* 139 */     if (!isNameReserved(name)) {
/* 140 */       this.req.setAttribute(name, value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String getVariableValue(String name)
/*     */   {
/* 147 */     String retVal = null;
/* 148 */     Object object = getReqAttributeIgnoreCase(name);
/* 149 */     if (object != null) {
/* 150 */       retVal = object.toString();
/*     */     } else {
/* 152 */       retVal = getCGIVariable(name);
/*     */     }
/* 154 */     return retVal;
/*     */   }
/*     */   
/*     */   protected String getCGIVariable(String name)
/*     */   {
/* 159 */     String retVal = null;
/* 160 */     String[] nameParts = name.toUpperCase(Locale.ENGLISH).split("_");
/* 161 */     int requiredParts = 2;
/* 162 */     if (nameParts.length == 1) {
/* 163 */       if (nameParts[0].equals("PATH")) {
/* 164 */         requiredParts = 1;
/*     */       }
/*     */     }
/* 167 */     else if (nameParts[0].equals("AUTH")) {
/* 168 */       if (nameParts[1].equals("TYPE")) {
/* 169 */         retVal = this.req.getAuthType();
/*     */       }
/* 171 */     } else if (nameParts[0].equals("CONTENT")) {
/* 172 */       if (nameParts[1].equals("LENGTH")) {
/* 173 */         long contentLength = this.req.getContentLengthLong();
/* 174 */         if (contentLength >= 0L) {
/* 175 */           retVal = Long.toString(contentLength);
/*     */         }
/* 177 */       } else if (nameParts[1].equals("TYPE")) {
/* 178 */         retVal = this.req.getContentType();
/*     */       }
/* 180 */     } else if (nameParts[0].equals("DOCUMENT")) {
/* 181 */       if (nameParts[1].equals("NAME")) {
/* 182 */         String requestURI = this.req.getRequestURI();
/* 183 */         retVal = requestURI.substring(requestURI.lastIndexOf('/') + 1);
/* 184 */       } else if (nameParts[1].equals("URI")) {
/* 185 */         retVal = this.req.getRequestURI();
/*     */       }
/* 187 */     } else if (name.equalsIgnoreCase("GATEWAY_INTERFACE")) {
/* 188 */       retVal = "CGI/1.1";
/* 189 */     } else if (nameParts[0].equals("HTTP")) {
/* 190 */       if (nameParts[1].equals("ACCEPT")) {
/* 191 */         String accept = null;
/* 192 */         if (nameParts.length == 2) {
/* 193 */           accept = "Accept";
/* 194 */         } else if (nameParts[2].equals("ENCODING")) {
/* 195 */           requiredParts = 3;
/* 196 */           accept = "Accept-Encoding";
/* 197 */         } else if (nameParts[2].equals("LANGUAGE")) {
/* 198 */           requiredParts = 3;
/* 199 */           accept = "Accept-Language";
/*     */         }
/* 201 */         if (accept != null) {
/* 202 */           Enumeration<String> acceptHeaders = this.req.getHeaders(accept);
/* 203 */           if ((acceptHeaders != null) && 
/* 204 */             (acceptHeaders.hasMoreElements())) {
/* 205 */             StringBuilder rv = new StringBuilder((String)acceptHeaders.nextElement());
/*     */             
/* 207 */             while (acceptHeaders.hasMoreElements()) {
/* 208 */               rv.append(", ");
/* 209 */               rv.append((String)acceptHeaders.nextElement());
/*     */             }
/* 211 */             retVal = rv.toString();
/*     */           }
/*     */         }
/*     */       }
/* 215 */       else if (nameParts[1].equals("CONNECTION")) {
/* 216 */         retVal = this.req.getHeader("Connection");
/*     */       }
/* 218 */       else if (nameParts[1].equals("HOST")) {
/* 219 */         retVal = this.req.getHeader("Host");
/*     */       }
/* 221 */       else if (nameParts[1].equals("REFERER")) {
/* 222 */         retVal = this.req.getHeader("Referer");
/*     */       }
/* 224 */       else if ((nameParts[1].equals("USER")) && 
/* 225 */         (nameParts.length == 3) && 
/* 226 */         (nameParts[2].equals("AGENT"))) {
/* 227 */         requiredParts = 3;
/* 228 */         retVal = this.req.getHeader("User-Agent");
/*     */       }
/*     */     }
/* 231 */     else if (nameParts[0].equals("PATH")) {
/* 232 */       if (nameParts[1].equals("INFO")) {
/* 233 */         retVal = this.req.getPathInfo();
/* 234 */       } else if (nameParts[1].equals("TRANSLATED")) {
/* 235 */         retVal = this.req.getPathTranslated();
/*     */       }
/* 237 */     } else if (nameParts[0].equals("QUERY")) {
/* 238 */       if (nameParts[1].equals("STRING")) {
/* 239 */         String queryString = this.req.getQueryString();
/* 240 */         if (nameParts.length == 2)
/*     */         {
/* 242 */           retVal = nullToEmptyString(queryString);
/* 243 */         } else if (nameParts[2].equals("UNESCAPED")) {
/* 244 */           requiredParts = 3;
/* 245 */           if (queryString != null)
/*     */           {
/* 247 */             String queryStringEncoding = "ISO-8859-1";
/*     */             
/*     */ 
/* 250 */             String uriEncoding = null;
/* 251 */             boolean useBodyEncodingForURI = false;
/*     */             
/*     */ 
/*     */ 
/* 255 */             String requestEncoding = this.req.getCharacterEncoding();
/* 256 */             if ((this.req instanceof Request)) {
/* 257 */               uriEncoding = ((Request)this.req).getConnector().getURIEncoding();
/*     */               
/* 259 */               useBodyEncodingForURI = ((Request)this.req).getConnector().getUseBodyEncodingForURI();
/*     */             }
/*     */             
/*     */ 
/*     */ 
/* 264 */             if (uriEncoding != null) {
/* 265 */               queryStringEncoding = uriEncoding;
/* 266 */             } else if ((useBodyEncodingForURI) && 
/* 267 */               (requestEncoding != null)) {
/* 268 */               queryStringEncoding = requestEncoding;
/*     */             }
/*     */             
/*     */             try
/*     */             {
/* 273 */               retVal = URLDecoder.decode(queryString, queryStringEncoding);
/*     */             }
/*     */             catch (UnsupportedEncodingException e) {
/* 276 */               retVal = queryString;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 281 */     } else if (nameParts[0].equals("REMOTE")) {
/* 282 */       if (nameParts[1].equals("ADDR")) {
/* 283 */         retVal = this.req.getRemoteAddr();
/* 284 */       } else if (nameParts[1].equals("HOST")) {
/* 285 */         retVal = this.req.getRemoteHost();
/* 286 */       } else if (!nameParts[1].equals("IDENT"))
/*     */       {
/* 288 */         if (nameParts[1].equals("PORT")) {
/* 289 */           retVal = Integer.toString(this.req.getRemotePort());
/* 290 */         } else if (nameParts[1].equals("USER"))
/* 291 */           retVal = this.req.getRemoteUser();
/*     */       }
/* 293 */     } else if (nameParts[0].equals("REQUEST")) {
/* 294 */       if (nameParts[1].equals("METHOD")) {
/* 295 */         retVal = this.req.getMethod();
/*     */       }
/* 297 */       else if (nameParts[1].equals("URI"))
/*     */       {
/* 299 */         retVal = (String)this.req.getAttribute("javax.servlet.forward.request_uri");
/*     */         
/* 301 */         if (retVal == null) retVal = this.req.getRequestURI();
/*     */       }
/* 303 */     } else if (nameParts[0].equals("SCRIPT")) {
/* 304 */       String scriptName = this.req.getServletPath();
/* 305 */       if (nameParts[1].equals("FILENAME")) {
/* 306 */         retVal = this.context.getRealPath(scriptName);
/*     */       }
/* 308 */       else if (nameParts[1].equals("NAME")) {
/* 309 */         retVal = scriptName;
/*     */       }
/* 311 */     } else if (nameParts[0].equals("SERVER")) {
/* 312 */       if (nameParts[1].equals("ADDR")) {
/* 313 */         retVal = this.req.getLocalAddr();
/*     */       }
/* 315 */       if (nameParts[1].equals("NAME")) {
/* 316 */         retVal = this.req.getServerName();
/* 317 */       } else if (nameParts[1].equals("PORT")) {
/* 318 */         retVal = Integer.toString(this.req.getServerPort());
/* 319 */       } else if (nameParts[1].equals("PROTOCOL")) {
/* 320 */         retVal = this.req.getProtocol();
/* 321 */       } else if (nameParts[1].equals("SOFTWARE")) {
/* 322 */         StringBuilder rv = new StringBuilder(this.context.getServerInfo());
/* 323 */         rv.append(" ");
/* 324 */         rv.append(System.getProperty("java.vm.name"));
/* 325 */         rv.append("/");
/* 326 */         rv.append(System.getProperty("java.vm.version"));
/* 327 */         rv.append(" ");
/* 328 */         rv.append(System.getProperty("os.name"));
/* 329 */         retVal = rv.toString();
/*     */       }
/* 331 */     } else if (name.equalsIgnoreCase("UNIQUE_ID")) {
/* 332 */       retVal = this.req.getRequestedSessionId();
/*     */     }
/* 334 */     if (requiredParts != nameParts.length) return null;
/* 335 */     return retVal;
/*     */   }
/*     */   
/*     */   public Date getCurrentDate()
/*     */   {
/* 340 */     return new Date();
/*     */   }
/*     */   
/*     */   protected String nullToEmptyString(String string)
/*     */   {
/* 345 */     String retVal = string;
/* 346 */     if (retVal == null) {
/* 347 */       retVal = "";
/*     */     }
/* 349 */     return retVal;
/*     */   }
/*     */   
/*     */   protected String getPathWithoutFileName(String servletPath)
/*     */   {
/* 354 */     String retVal = null;
/* 355 */     int lastSlash = servletPath.lastIndexOf('/');
/* 356 */     if (lastSlash >= 0)
/*     */     {
/* 358 */       retVal = servletPath.substring(0, lastSlash + 1);
/*     */     }
/* 360 */     return retVal;
/*     */   }
/*     */   
/*     */ 
/*     */   protected String getPathWithoutContext(String contextPath, String servletPath)
/*     */   {
/* 366 */     if (servletPath.startsWith(contextPath)) {
/* 367 */       return servletPath.substring(contextPath.length());
/*     */     }
/* 369 */     return servletPath;
/*     */   }
/*     */   
/*     */   protected String getAbsolutePath(String path) throws IOException
/*     */   {
/* 374 */     String pathWithoutContext = SSIServletRequestUtil.getRelativePath(this.req);
/* 375 */     String prefix = getPathWithoutFileName(pathWithoutContext);
/* 376 */     if (prefix == null) {
/* 377 */       throw new IOException("Couldn't remove filename from path: " + pathWithoutContext);
/*     */     }
/*     */     
/* 380 */     String fullPath = prefix + path;
/* 381 */     String retVal = RequestUtil.normalize(fullPath);
/* 382 */     if (retVal == null) {
/* 383 */       throw new IOException("Normalization yielded null on path: " + fullPath);
/*     */     }
/*     */     
/* 386 */     return retVal;
/*     */   }
/*     */   
/*     */   protected ServletContextAndPath getServletContextAndPathFromNonVirtualPath(String nonVirtualPath)
/*     */     throws IOException
/*     */   {
/* 392 */     if ((nonVirtualPath.startsWith("/")) || (nonVirtualPath.startsWith("\\"))) {
/* 393 */       throw new IOException("A non-virtual path can't be absolute: " + nonVirtualPath);
/*     */     }
/*     */     
/* 396 */     if (nonVirtualPath.indexOf("../") >= 0) {
/* 397 */       throw new IOException("A non-virtual path can't contain '../' : " + nonVirtualPath);
/*     */     }
/*     */     
/* 400 */     String path = getAbsolutePath(nonVirtualPath);
/* 401 */     ServletContextAndPath csAndP = new ServletContextAndPath(this.context, path);
/*     */     
/* 403 */     return csAndP;
/*     */   }
/*     */   
/*     */ 
/*     */   protected ServletContextAndPath getServletContextAndPathFromVirtualPath(String virtualPath)
/*     */     throws IOException
/*     */   {
/* 410 */     if ((!virtualPath.startsWith("/")) && (!virtualPath.startsWith("\\"))) {
/* 411 */       return new ServletContextAndPath(this.context, getAbsolutePath(virtualPath));
/*     */     }
/*     */     
/*     */ 
/* 415 */     String normalized = RequestUtil.normalize(virtualPath);
/* 416 */     if (this.isVirtualWebappRelative) {
/* 417 */       return new ServletContextAndPath(this.context, normalized);
/*     */     }
/*     */     
/* 420 */     ServletContext normContext = this.context.getContext(normalized);
/* 421 */     if (normContext == null) {
/* 422 */       throw new IOException("Couldn't get context for path: " + normalized);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 429 */     if (!isRootContext(normContext)) {
/* 430 */       String noContext = getPathWithoutContext(normContext.getContextPath(), normalized);
/*     */       
/* 432 */       if (noContext == null) {
/* 433 */         throw new IOException("Couldn't remove context from path: " + normalized);
/*     */       }
/*     */       
/*     */ 
/* 437 */       return new ServletContextAndPath(normContext, noContext);
/*     */     }
/*     */     
/* 440 */     return new ServletContextAndPath(normContext, normalized);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isRootContext(ServletContext servletContext)
/*     */   {
/* 453 */     return servletContext == servletContext.getContext("/");
/*     */   }
/*     */   
/*     */   protected ServletContextAndPath getServletContextAndPath(String originalPath, boolean virtual)
/*     */     throws IOException
/*     */   {
/* 459 */     ServletContextAndPath csAndP = null;
/* 460 */     if (this.debug > 0) {
/* 461 */       log("SSIServletExternalResolver.getServletContextAndPath( " + originalPath + ", " + virtual + ")", null);
/*     */     }
/*     */     
/* 464 */     if (virtual) {
/* 465 */       csAndP = getServletContextAndPathFromVirtualPath(originalPath);
/*     */     } else {
/* 467 */       csAndP = getServletContextAndPathFromNonVirtualPath(originalPath);
/*     */     }
/* 469 */     return csAndP;
/*     */   }
/*     */   
/*     */   protected URLConnection getURLConnection(String originalPath, boolean virtual)
/*     */     throws IOException
/*     */   {
/* 475 */     ServletContextAndPath csAndP = getServletContextAndPath(originalPath, virtual);
/*     */     
/* 477 */     ServletContext context = csAndP.getServletContext();
/* 478 */     String path = csAndP.getPath();
/* 479 */     URL url = context.getResource(path);
/* 480 */     if (url == null) {
/* 481 */       throw new IOException("Context did not contain resource: " + path);
/*     */     }
/* 483 */     URLConnection urlConnection = url.openConnection();
/* 484 */     return urlConnection;
/*     */   }
/*     */   
/*     */ 
/*     */   public long getFileLastModified(String path, boolean virtual)
/*     */     throws IOException
/*     */   {
/* 491 */     long lastModified = 0L;
/*     */     try {
/* 493 */       URLConnection urlConnection = getURLConnection(path, virtual);
/* 494 */       lastModified = urlConnection.getLastModified();
/*     */     }
/*     */     catch (IOException localIOException) {}
/*     */     
/* 498 */     return lastModified;
/*     */   }
/*     */   
/*     */   public long getFileSize(String path, boolean virtual)
/*     */     throws IOException
/*     */   {
/* 504 */     long fileSize = -1L;
/*     */     try {
/* 506 */       URLConnection urlConnection = getURLConnection(path, virtual);
/* 507 */       fileSize = urlConnection.getContentLengthLong();
/*     */     }
/*     */     catch (IOException localIOException) {}
/*     */     
/* 511 */     return fileSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFileText(String originalPath, boolean virtual)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 522 */       ServletContextAndPath csAndP = getServletContextAndPath(originalPath, virtual);
/*     */       
/* 524 */       ServletContext context = csAndP.getServletContext();
/* 525 */       String path = csAndP.getPath();
/* 526 */       RequestDispatcher rd = context.getRequestDispatcher(path);
/* 527 */       if (rd == null) {
/* 528 */         throw new IOException("Couldn't get request dispatcher for path: " + path);
/*     */       }
/*     */       
/* 531 */       ByteArrayServletOutputStream basos = new ByteArrayServletOutputStream();
/*     */       
/* 533 */       ResponseIncludeWrapper responseIncludeWrapper = new ResponseIncludeWrapper(context, this.req, this.res, basos);
/*     */       
/* 535 */       rd.include(this.req, responseIncludeWrapper);
/*     */       
/* 537 */       responseIncludeWrapper.flushOutputStreamOrWriter();
/* 538 */       byte[] bytes = basos.toByteArray();
/*     */       
/*     */       String retVal;
/*     */       String retVal;
/* 542 */       if (this.inputEncoding == null) {
/* 543 */         retVal = new String(bytes);
/*     */       } else {
/* 545 */         retVal = new String(bytes, B2CConverter.getCharset(this.inputEncoding));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 553 */       if ((retVal.equals("")) && (!this.req.getMethod().equalsIgnoreCase("HEAD"))) {
/* 554 */         throw new IOException("Couldn't find file: " + path);
/*     */       }
/* 556 */       return retVal;
/*     */     } catch (ServletException e) {
/* 558 */       throw new IOException("Couldn't include file: " + originalPath + " because of ServletException: " + e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected static class ServletContextAndPath
/*     */   {
/*     */     protected final ServletContext servletContext;
/*     */     protected final String path;
/*     */     
/*     */     public ServletContextAndPath(ServletContext servletContext, String path)
/*     */     {
/* 570 */       this.servletContext = servletContext;
/* 571 */       this.path = path;
/*     */     }
/*     */     
/*     */     public ServletContext getServletContext()
/*     */     {
/* 576 */       return this.servletContext;
/*     */     }
/*     */     
/*     */     public String getPath()
/*     */     {
/* 581 */       return this.path;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\ssi\SSIServletExternalResolver.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */