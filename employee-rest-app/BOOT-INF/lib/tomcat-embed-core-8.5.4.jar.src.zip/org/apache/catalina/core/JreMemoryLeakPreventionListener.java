/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.awt.Toolkit;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.security.Security;
/*     */ import java.sql.DriverManager;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.compat.JreVendor;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.ls.DOMImplementationLS;
/*     */ import org.w3c.dom.ls.LSSerializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JreMemoryLeakPreventionListener
/*     */   implements LifecycleListener
/*     */ {
/*  61 */   private static final Log log = LogFactory.getLog(JreMemoryLeakPreventionListener.class);
/*     */   
/*  63 */   private static final StringManager sm = StringManager.getManager("org.apache.catalina.core");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  74 */   private boolean appContextProtection = false;
/*  75 */   public boolean isAppContextProtection() { return this.appContextProtection; }
/*     */   
/*  77 */   public void setAppContextProtection(boolean appContextProtection) { this.appContextProtection = appContextProtection; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  86 */   private boolean awtThreadProtection = false;
/*  87 */   public boolean isAWTThreadProtection() { return this.awtThreadProtection; }
/*     */   
/*  89 */   public void setAWTThreadProtection(boolean awtThreadProtection) { this.awtThreadProtection = awtThreadProtection; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */   private boolean gcDaemonProtection = true;
/* 100 */   public boolean isGcDaemonProtection() { return this.gcDaemonProtection; }
/*     */   
/* 102 */   public void setGcDaemonProtection(boolean gcDaemonProtection) { this.gcDaemonProtection = gcDaemonProtection; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 111 */   private boolean securityPolicyProtection = true;
/*     */   
/* 113 */   public boolean isSecurityPolicyProtection() { return this.securityPolicyProtection; }
/*     */   
/*     */   public void setSecurityPolicyProtection(boolean securityPolicyProtection) {
/* 116 */     this.securityPolicyProtection = securityPolicyProtection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */   private boolean securityLoginConfigurationProtection = true;
/*     */   
/* 127 */   public boolean isSecurityLoginConfigurationProtection() { return this.securityLoginConfigurationProtection; }
/*     */   
/*     */   public void setSecurityLoginConfigurationProtection(boolean securityLoginConfigurationProtection)
/*     */   {
/* 131 */     this.securityLoginConfigurationProtection = securityLoginConfigurationProtection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 143 */   private boolean tokenPollerProtection = true;
/* 144 */   public boolean isTokenPollerProtection() { return this.tokenPollerProtection; }
/*     */   
/* 146 */   public void setTokenPollerProtection(boolean tokenPollerProtection) { this.tokenPollerProtection = tokenPollerProtection; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 155 */   private boolean urlCacheProtection = true;
/* 156 */   public boolean isUrlCacheProtection() { return this.urlCacheProtection; }
/*     */   
/* 158 */   public void setUrlCacheProtection(boolean urlCacheProtection) { this.urlCacheProtection = urlCacheProtection; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 168 */   private boolean xmlParsingProtection = true;
/* 169 */   public boolean isXmlParsingProtection() { return this.xmlParsingProtection; }
/*     */   
/* 171 */   public void setXmlParsingProtection(boolean xmlParsingProtection) { this.xmlParsingProtection = xmlParsingProtection; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 182 */   private boolean ldapPoolProtection = true;
/* 183 */   public boolean isLdapPoolProtection() { return this.ldapPoolProtection; }
/*     */   
/* 185 */   public void setLdapPoolProtection(boolean ldapPoolProtection) { this.ldapPoolProtection = ldapPoolProtection; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 194 */   private boolean driverManagerProtection = true;
/*     */   
/* 196 */   public boolean isDriverManagerProtection() { return this.driverManagerProtection; }
/*     */   
/*     */   public void setDriverManagerProtection(boolean driverManagerProtection) {
/* 199 */     this.driverManagerProtection = driverManagerProtection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 207 */   private String classesToInitialize = null;
/*     */   
/* 209 */   public String getClassesToInitialize() { return this.classesToInitialize; }
/*     */   
/*     */   public void setClassesToInitialize(String classesToInitialize) {
/* 212 */     this.classesToInitialize = classesToInitialize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void lifecycleEvent(LifecycleEvent event)
/*     */   {
/* 220 */     if ("before_init".equals(event.getType()))
/*     */     {
/* 222 */       ClassLoader loader = Thread.currentThread().getContextClassLoader();
/*     */       
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/* 228 */         Thread.currentThread().setContextClassLoader(ClassLoader.getSystemClassLoader());
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 235 */         if (this.driverManagerProtection) {
/* 236 */           DriverManager.getDrivers();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 261 */         if (this.appContextProtection) {
/* 262 */           ImageIO.getCacheDirectory();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 267 */         if (this.awtThreadProtection) {
/* 268 */           Toolkit.getDefaultToolkit();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 284 */         if (this.gcDaemonProtection) {
/*     */           try {
/* 286 */             Class<?> clazz = Class.forName("sun.misc.GC");
/* 287 */             Method method = clazz.getDeclaredMethod("requestLatency", new Class[] { Long.TYPE });
/*     */             
/*     */ 
/* 290 */             method.invoke(null, new Object[] { Long.valueOf(9223372036854775806L) });
/*     */           } catch (ClassNotFoundException e) {
/* 292 */             if (JreVendor.IS_ORACLE_JVM) {
/* 293 */               log.error(sm.getString("jreLeakListener.gcDaemonFail"), e);
/*     */             }
/*     */             else {
/* 296 */               log.debug(sm.getString("jreLeakListener.gcDaemonFail"), e);
/*     */             }
/*     */           }
/*     */           catch (SecurityException|NoSuchMethodException|IllegalArgumentException|IllegalAccessException e)
/*     */           {
/* 301 */             log.error(sm.getString("jreLeakListener.gcDaemonFail"), e);
/*     */           }
/*     */           catch (InvocationTargetException e) {
/* 304 */             ExceptionUtils.handleThrowable(e.getCause());
/* 305 */             log.error(sm.getString("jreLeakListener.gcDaemonFail"), e);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 314 */         if (this.securityPolicyProtection) {
/*     */           try
/*     */           {
/* 317 */             Class<?> policyClass = Class.forName("javax.security.auth.Policy");
/*     */             
/* 319 */             Method method = policyClass.getMethod("getPolicy", new Class[0]);
/* 320 */             method.invoke(null, new Object[0]);
/*     */ 
/*     */ 
/*     */           }
/*     */           catch (ClassNotFoundException localClassNotFoundException1) {}catch (SecurityException localSecurityException) {}catch (NoSuchMethodException e)
/*     */           {
/*     */ 
/* 327 */             log.warn(sm.getString("jreLeakListener.authPolicyFail"), e);
/*     */           }
/*     */           catch (IllegalArgumentException e) {
/* 330 */             log.warn(sm.getString("jreLeakListener.authPolicyFail"), e);
/*     */           }
/*     */           catch (IllegalAccessException e) {
/* 333 */             log.warn(sm.getString("jreLeakListener.authPolicyFail"), e);
/*     */           }
/*     */           catch (InvocationTargetException e) {
/* 336 */             ExceptionUtils.handleThrowable(e.getCause());
/* 337 */             log.warn(sm.getString("jreLeakListener.authPolicyFail"), e);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 347 */         if (this.securityLoginConfigurationProtection) {
/*     */           try {
/* 349 */             Class.forName("javax.security.auth.login.Configuration", true, ClassLoader.getSystemClassLoader());
/*     */           }
/*     */           catch (ClassNotFoundException localClassNotFoundException2) {}
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 363 */         if (this.tokenPollerProtection) {
/* 364 */           Security.getProviders();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 380 */         if (this.urlCacheProtection)
/*     */         {
/*     */           try
/*     */           {
/* 384 */             URL url = new URL("jar:file://dummy.jar!/");
/* 385 */             URLConnection uConn = url.openConnection();
/* 386 */             uConn.setDefaultUseCaches(false);
/*     */           } catch (MalformedURLException e) {
/* 388 */             log.error(sm.getString("jreLeakListener.jarUrlConnCacheFail"), e);
/*     */           }
/*     */           catch (IOException e) {
/* 391 */             log.error(sm.getString("jreLeakListener.jarUrlConnCacheFail"), e);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 396 */         if (this.xmlParsingProtection)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 403 */           DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/*     */           try {
/* 405 */             DocumentBuilder documentBuilder = factory.newDocumentBuilder();
/*     */             
/*     */ 
/* 408 */             Document document = documentBuilder.newDocument();
/* 409 */             document.createElement("dummy");
/* 410 */             DOMImplementationLS implementation = (DOMImplementationLS)document.getImplementation();
/*     */             
/* 412 */             implementation.createLSSerializer().writeToString(document);
/*     */             
/*     */ 
/* 415 */             document.normalize();
/*     */           } catch (ParserConfigurationException e) {
/* 417 */             log.error(sm.getString("jreLeakListener.xmlParseFail"), e);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 422 */         if (this.ldapPoolProtection) {
/*     */           try {
/* 424 */             Class.forName("com.sun.jndi.ldap.LdapPoolManager");
/*     */           } catch (ClassNotFoundException e) {
/* 426 */             if (JreVendor.IS_ORACLE_JVM) {
/* 427 */               log.error(sm.getString("jreLeakListener.ldapPoolManagerFail"), e);
/*     */             }
/*     */             else {
/* 430 */               log.debug(sm.getString("jreLeakListener.ldapPoolManagerFail"), e);
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 436 */         if (this.classesToInitialize != null) {
/* 437 */           StringTokenizer strTok = new StringTokenizer(this.classesToInitialize, ", \r\n\t");
/*     */           
/* 439 */           while (strTok.hasMoreTokens()) {
/* 440 */             String classNameToLoad = strTok.nextToken();
/*     */             try {
/* 442 */               Class.forName(classNameToLoad);
/*     */             } catch (ClassNotFoundException e) {
/* 444 */               log.error(sm.getString("jreLeakListener.classToInitializeFail", new Object[] { classNameToLoad }), e);
/*     */             }
/*     */             
/*     */           }
/*     */           
/*     */         }
/*     */       }
/*     */       finally
/*     */       {
/* 453 */         Thread.currentThread().setContextClassLoader(loader);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\core\JreMemoryLeakPreventionListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */