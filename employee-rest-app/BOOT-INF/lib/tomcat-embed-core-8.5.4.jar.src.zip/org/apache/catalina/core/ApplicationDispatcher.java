/*      */ package org.apache.catalina.core;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import javax.servlet.AsyncContext;
/*      */ import javax.servlet.DispatcherType;
/*      */ import javax.servlet.RequestDispatcher;
/*      */ import javax.servlet.Servlet;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletOutputStream;
/*      */ import javax.servlet.ServletRequest;
/*      */ import javax.servlet.ServletRequestWrapper;
/*      */ import javax.servlet.ServletResponse;
/*      */ import javax.servlet.ServletResponseWrapper;
/*      */ import javax.servlet.UnavailableException;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import org.apache.catalina.AsyncDispatcher;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.connector.ClientAbortException;
/*      */ import org.apache.catalina.connector.Request;
/*      */ import org.apache.catalina.connector.RequestFacade;
/*      */ import org.apache.catalina.connector.Response;
/*      */ import org.apache.catalina.connector.ResponseFacade;
/*      */ import org.apache.catalina.servlet4preview.http.Mapping;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class ApplicationDispatcher
/*      */   implements AsyncDispatcher, RequestDispatcher
/*      */ {
/*   71 */   static final boolean STRICT_SERVLET_COMPLIANCE = Globals.STRICT_SERVLET_COMPLIANCE;
/*      */   
/*   73 */   static { String wrapSameObject = System.getProperty("org.apache.catalina.core.ApplicationDispatcher.WRAP_SAME_OBJECT");
/*      */     
/*   75 */     if (wrapSameObject == null) {
/*   76 */       WRAP_SAME_OBJECT = STRICT_SERVLET_COMPLIANCE;
/*      */     } else {
/*   78 */       WRAP_SAME_OBJECT = Boolean.parseBoolean(wrapSameObject);
/*      */     }
/*      */   }
/*      */   
/*      */   protected class PrivilegedForward implements PrivilegedExceptionAction<Void>
/*      */   {
/*      */     private final ServletRequest request;
/*      */     private final ServletResponse response;
/*      */     
/*      */     PrivilegedForward(ServletRequest request, ServletResponse response)
/*      */     {
/*   89 */       this.request = request;
/*   90 */       this.response = response;
/*      */     }
/*      */     
/*      */     public Void run() throws Exception
/*      */     {
/*   95 */       ApplicationDispatcher.this.doForward(this.request, this.response);
/*   96 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */   protected class PrivilegedInclude implements PrivilegedExceptionAction<Void>
/*      */   {
/*      */     private final ServletRequest request;
/*      */     private final ServletResponse response;
/*      */     
/*      */     PrivilegedInclude(ServletRequest request, ServletResponse response) {
/*  106 */       this.request = request;
/*  107 */       this.response = response;
/*      */     }
/*      */     
/*      */     public Void run() throws ServletException, IOException
/*      */     {
/*  112 */       ApplicationDispatcher.this.doInclude(this.request, this.response);
/*  113 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */   protected class PrivilegedDispatch implements PrivilegedExceptionAction<Void>
/*      */   {
/*      */     private final ServletRequest request;
/*      */     private final ServletResponse response;
/*      */     
/*      */     PrivilegedDispatch(ServletRequest request, ServletResponse response) {
/*  123 */       this.request = request;
/*  124 */       this.response = response;
/*      */     }
/*      */     
/*      */     public Void run() throws ServletException, IOException
/*      */     {
/*  129 */       ApplicationDispatcher.this.doDispatch(this.request, this.response);
/*  130 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class State
/*      */   {
/*      */     State(ServletRequest request, ServletResponse response, boolean including)
/*      */     {
/*  143 */       this.outerRequest = request;
/*  144 */       this.outerResponse = response;
/*  145 */       this.including = including;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  151 */     ServletRequest outerRequest = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  157 */     ServletResponse outerResponse = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  162 */     ServletRequest wrapRequest = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  168 */     ServletResponse wrapResponse = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  173 */     boolean including = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  178 */     javax.servlet.http.HttpServletRequest hrequest = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  183 */     HttpServletResponse hresponse = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final boolean WRAP_SAME_OBJECT;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final Context context;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final String name;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final String pathInfo;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ApplicationDispatcher(Wrapper wrapper, String requestURI, String servletPath, String pathInfo, String queryString, Mapping mapping, String name)
/*      */   {
/*  214 */     this.wrapper = wrapper;
/*  215 */     this.context = ((Context)wrapper.getParent());
/*  216 */     this.requestURI = requestURI;
/*  217 */     this.servletPath = servletPath;
/*  218 */     this.pathInfo = pathInfo;
/*  219 */     this.queryString = queryString;
/*  220 */     this.mapping = mapping;
/*  221 */     this.name = name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final String queryString;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final String requestURI;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final String servletPath;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final Mapping mapping;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  272 */   private static final StringManager sm = StringManager.getManager("org.apache.catalina.core");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final Wrapper wrapper;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void forward(ServletRequest request, ServletResponse response)
/*      */     throws ServletException, IOException
/*      */   {
/*  300 */     if (Globals.IS_SECURITY_ENABLED) {
/*      */       try {
/*  302 */         PrivilegedForward dp = new PrivilegedForward(request, response);
/*  303 */         AccessController.doPrivileged(dp);
/*      */       } catch (PrivilegedActionException pe) {
/*  305 */         Exception e = pe.getException();
/*  306 */         if ((e instanceof ServletException))
/*  307 */           throw ((ServletException)e);
/*  308 */         throw ((IOException)e);
/*      */       }
/*      */     } else {
/*  311 */       doForward(request, response);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void doForward(ServletRequest request, ServletResponse response)
/*      */     throws ServletException, IOException
/*      */   {
/*  320 */     if (response.isCommitted()) {
/*  321 */       throw new IllegalStateException(sm.getString("applicationDispatcher.forward.ise"));
/*      */     }
/*      */     try
/*      */     {
/*  325 */       response.resetBuffer();
/*      */     } catch (IllegalStateException e) {
/*  327 */       throw e;
/*      */     }
/*      */     
/*      */ 
/*  331 */     State state = new State(request, response, false);
/*      */     
/*  333 */     if (WRAP_SAME_OBJECT)
/*      */     {
/*  335 */       checkSameObjects(request, response);
/*      */     }
/*      */     
/*  338 */     wrapResponse(state);
/*      */     
/*  340 */     if ((this.servletPath == null) && (this.pathInfo == null))
/*      */     {
/*  342 */       ApplicationHttpRequest wrequest = (ApplicationHttpRequest)wrapRequest(state);
/*      */       
/*  344 */       javax.servlet.http.HttpServletRequest hrequest = state.hrequest;
/*  345 */       wrequest.setRequestURI(hrequest.getRequestURI());
/*  346 */       wrequest.setContextPath(hrequest.getContextPath());
/*  347 */       wrequest.setServletPath(hrequest.getServletPath());
/*  348 */       wrequest.setPathInfo(hrequest.getPathInfo());
/*  349 */       wrequest.setQueryString(hrequest.getQueryString());
/*      */       
/*  351 */       processRequest(request, response, state);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*  357 */       ApplicationHttpRequest wrequest = (ApplicationHttpRequest)wrapRequest(state);
/*      */       
/*  359 */       String contextPath = this.context.getPath();
/*  360 */       javax.servlet.http.HttpServletRequest hrequest = state.hrequest;
/*  361 */       if (hrequest.getAttribute("javax.servlet.forward.request_uri") == null) {
/*  362 */         wrequest.setAttribute("javax.servlet.forward.request_uri", hrequest.getRequestURI());
/*      */         
/*  364 */         wrequest.setAttribute("javax.servlet.forward.context_path", hrequest.getContextPath());
/*      */         
/*  366 */         wrequest.setAttribute("javax.servlet.forward.servlet_path", hrequest.getServletPath());
/*      */         
/*  368 */         wrequest.setAttribute("javax.servlet.forward.path_info", hrequest.getPathInfo());
/*      */         
/*  370 */         wrequest.setAttribute("javax.servlet.forward.query_string", hrequest.getQueryString());
/*      */         Mapping mapping;
/*      */         Mapping mapping;
/*  373 */         if ((hrequest instanceof org.apache.catalina.servlet4preview.http.HttpServletRequest)) {
/*  374 */           mapping = ((org.apache.catalina.servlet4preview.http.HttpServletRequest)hrequest).getMapping();
/*      */         }
/*      */         else {
/*  377 */           mapping = new ApplicationMapping(null).getMapping();
/*      */         }
/*  379 */         wrequest.setAttribute("javax.servlet.forward.mapping", mapping);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  384 */       wrequest.setContextPath(contextPath);
/*  385 */       wrequest.setRequestURI(this.requestURI);
/*  386 */       wrequest.setServletPath(this.servletPath);
/*  387 */       wrequest.setPathInfo(this.pathInfo);
/*  388 */       if (this.queryString != null) {
/*  389 */         wrequest.setQueryString(this.queryString);
/*  390 */         wrequest.setQueryParams(this.queryString);
/*      */       }
/*  392 */       wrequest.setMapping(this.mapping);
/*      */       
/*  394 */       processRequest(request, response, state);
/*      */     }
/*      */     
/*  397 */     if (request.isAsyncStarted())
/*      */     {
/*      */ 
/*  400 */       return;
/*      */     }
/*      */     
/*      */ 
/*  404 */     if (this.wrapper.getLogger().isDebugEnabled()) {
/*  405 */       this.wrapper.getLogger().debug(" Disabling the response for futher output");
/*      */     }
/*  407 */     if ((response instanceof ResponseFacade)) {
/*  408 */       ((ResponseFacade)response).finish();
/*      */     }
/*      */     else
/*      */     {
/*  412 */       if (this.wrapper.getLogger().isDebugEnabled()) {
/*  413 */         this.wrapper.getLogger().debug(" The Response is vehiculed using a wrapper: " + response.getClass().getName());
/*      */       }
/*      */       
/*      */ 
/*      */       try
/*      */       {
/*  419 */         PrintWriter writer = response.getWriter();
/*  420 */         writer.close();
/*      */       } catch (IllegalStateException e) {
/*      */         try {
/*  423 */           ServletOutputStream stream = response.getOutputStream();
/*  424 */           stream.close();
/*      */         }
/*      */         catch (IllegalStateException localIllegalStateException1) {}catch (IOException localIOException) {}
/*      */       }
/*      */       catch (IOException localIOException1) {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void processRequest(ServletRequest request, ServletResponse response, State state)
/*      */     throws IOException, ServletException
/*      */   {
/*  452 */     DispatcherType disInt = (DispatcherType)request.getAttribute("org.apache.catalina.core.DISPATCHER_TYPE");
/*  453 */     if (disInt != null) {
/*  454 */       boolean doInvoke = true;
/*      */       
/*  456 */       if ((this.context.getFireRequestListenersOnForwards()) && (!this.context.fireRequestInitEvent(request)))
/*      */       {
/*  458 */         doInvoke = false;
/*      */       }
/*      */       
/*  461 */       if (doInvoke) {
/*  462 */         if (disInt != DispatcherType.ERROR) {
/*  463 */           state.outerRequest.setAttribute("org.apache.catalina.core.DISPATCHER_REQUEST_PATH", getCombinedPath());
/*      */           
/*      */ 
/*  466 */           state.outerRequest.setAttribute("org.apache.catalina.core.DISPATCHER_TYPE", DispatcherType.FORWARD);
/*      */           
/*      */ 
/*  469 */           invoke(state.outerRequest, response, state);
/*      */         } else {
/*  471 */           invoke(state.outerRequest, response, state);
/*      */         }
/*      */         
/*  474 */         if (this.context.getFireRequestListenersOnForwards()) {
/*  475 */           this.context.fireRequestDestroyEvent(request);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getCombinedPath()
/*      */   {
/*  489 */     if (this.servletPath == null) {
/*  490 */       return null;
/*      */     }
/*  492 */     if (this.pathInfo == null) {
/*  493 */       return this.servletPath;
/*      */     }
/*  495 */     return this.servletPath + this.pathInfo;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void include(ServletRequest request, ServletResponse response)
/*      */     throws ServletException, IOException
/*      */   {
/*  514 */     if (Globals.IS_SECURITY_ENABLED) {
/*      */       try {
/*  516 */         PrivilegedInclude dp = new PrivilegedInclude(request, response);
/*  517 */         AccessController.doPrivileged(dp);
/*      */       } catch (PrivilegedActionException pe) {
/*  519 */         Exception e = pe.getException();
/*      */         
/*  521 */         if ((e instanceof ServletException))
/*  522 */           throw ((ServletException)e);
/*  523 */         throw ((IOException)e);
/*      */       }
/*      */     } else {
/*  526 */       doInclude(request, response);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void doInclude(ServletRequest request, ServletResponse response)
/*      */     throws ServletException, IOException
/*      */   {
/*  534 */     State state = new State(request, response, true);
/*      */     
/*  536 */     if (WRAP_SAME_OBJECT)
/*      */     {
/*  538 */       checkSameObjects(request, response);
/*      */     }
/*      */     
/*      */ 
/*  542 */     wrapResponse(state);
/*      */     
/*      */ 
/*  545 */     if (this.name != null)
/*      */     {
/*  547 */       ApplicationHttpRequest wrequest = (ApplicationHttpRequest)wrapRequest(state);
/*      */       
/*  549 */       wrequest.setAttribute("org.apache.catalina.NAMED", this.name);
/*  550 */       if (this.servletPath != null)
/*  551 */         wrequest.setServletPath(this.servletPath);
/*  552 */       wrequest.setAttribute("org.apache.catalina.core.DISPATCHER_TYPE", DispatcherType.INCLUDE);
/*      */       
/*  554 */       wrequest.setAttribute("org.apache.catalina.core.DISPATCHER_REQUEST_PATH", getCombinedPath());
/*      */       
/*  556 */       invoke(state.outerRequest, state.outerResponse, state);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*  562 */       ApplicationHttpRequest wrequest = (ApplicationHttpRequest)wrapRequest(state);
/*      */       
/*  564 */       String contextPath = this.context.getPath();
/*  565 */       if (this.requestURI != null) {
/*  566 */         wrequest.setAttribute("javax.servlet.include.request_uri", this.requestURI);
/*      */       }
/*  568 */       if (contextPath != null) {
/*  569 */         wrequest.setAttribute("javax.servlet.include.context_path", contextPath);
/*      */       }
/*  571 */       if (this.servletPath != null) {
/*  572 */         wrequest.setAttribute("javax.servlet.include.servlet_path", this.servletPath);
/*      */       }
/*  574 */       if (this.pathInfo != null) {
/*  575 */         wrequest.setAttribute("javax.servlet.include.path_info", this.pathInfo);
/*      */       }
/*  577 */       if (this.queryString != null) {
/*  578 */         wrequest.setAttribute("javax.servlet.include.query_string", this.queryString);
/*      */         
/*  580 */         wrequest.setQueryParams(this.queryString);
/*      */       }
/*  582 */       if (this.mapping != null) {
/*  583 */         wrequest.setAttribute("javax.servlet.include.mapping", this.mapping);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  588 */       wrequest.setAttribute("org.apache.catalina.core.DISPATCHER_TYPE", DispatcherType.INCLUDE);
/*      */       
/*  590 */       wrequest.setAttribute("org.apache.catalina.core.DISPATCHER_REQUEST_PATH", getCombinedPath());
/*      */       
/*  592 */       invoke(state.outerRequest, state.outerResponse, state);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void dispatch(ServletRequest request, ServletResponse response)
/*      */     throws ServletException, IOException
/*      */   {
/*  601 */     if (Globals.IS_SECURITY_ENABLED) {
/*      */       try {
/*  603 */         PrivilegedDispatch dp = new PrivilegedDispatch(request, response);
/*  604 */         AccessController.doPrivileged(dp);
/*      */       } catch (PrivilegedActionException pe) {
/*  606 */         Exception e = pe.getException();
/*      */         
/*  608 */         if ((e instanceof ServletException))
/*  609 */           throw ((ServletException)e);
/*  610 */         throw ((IOException)e);
/*      */       }
/*      */     } else {
/*  613 */       doDispatch(request, response);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void doDispatch(ServletRequest request, ServletResponse response)
/*      */     throws ServletException, IOException
/*      */   {
/*  621 */     State state = new State(request, response, false);
/*      */     
/*      */ 
/*  624 */     wrapResponse(state);
/*      */     
/*  626 */     ApplicationHttpRequest wrequest = (ApplicationHttpRequest)wrapRequest(state);
/*      */     
/*      */ 
/*  629 */     if (this.queryString != null) {
/*  630 */       wrequest.setQueryParams(this.queryString);
/*      */     }
/*      */     
/*  633 */     wrequest.setAttribute("org.apache.catalina.core.DISPATCHER_TYPE", DispatcherType.ASYNC);
/*      */     
/*  635 */     wrequest.setAttribute("org.apache.catalina.core.DISPATCHER_REQUEST_PATH", getCombinedPath());
/*      */     
/*      */ 
/*  638 */     wrequest.setContextPath(this.context.getPath());
/*  639 */     wrequest.setRequestURI(this.requestURI);
/*  640 */     wrequest.setServletPath(this.servletPath);
/*  641 */     wrequest.setPathInfo(this.pathInfo);
/*  642 */     if (this.queryString != null) {
/*  643 */       wrequest.setQueryString(this.queryString);
/*  644 */       wrequest.setQueryParams(this.queryString);
/*      */     }
/*      */     
/*  647 */     invoke(state.outerRequest, state.outerResponse, state);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void invoke(ServletRequest request, ServletResponse response, State state)
/*      */     throws IOException, ServletException
/*      */   {
/*  675 */     ClassLoader oldCCL = this.context.bind(false, null);
/*      */     
/*      */ 
/*  678 */     HttpServletResponse hresponse = state.hresponse;
/*  679 */     Servlet servlet = null;
/*  680 */     IOException ioException = null;
/*  681 */     ServletException servletException = null;
/*  682 */     RuntimeException runtimeException = null;
/*  683 */     boolean unavailable = false;
/*      */     
/*      */ 
/*  686 */     if (this.wrapper.isUnavailable()) {
/*  687 */       this.wrapper.getLogger().warn(sm.getString("applicationDispatcher.isUnavailable", new Object[] { this.wrapper.getName() }));
/*      */       
/*      */ 
/*  690 */       long available = this.wrapper.getAvailable();
/*  691 */       if ((available > 0L) && (available < Long.MAX_VALUE))
/*  692 */         hresponse.setDateHeader("Retry-After", available);
/*  693 */       hresponse.sendError(503, sm.getString("applicationDispatcher.isUnavailable", new Object[] { this.wrapper.getName() }));
/*      */       
/*      */ 
/*  696 */       unavailable = true;
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  701 */       if (!unavailable) {
/*  702 */         servlet = this.wrapper.allocate();
/*      */       }
/*      */     } catch (ServletException e) {
/*  705 */       this.wrapper.getLogger().error(sm.getString("applicationDispatcher.allocateException", new Object[] { this.wrapper.getName() }), StandardWrapper.getRootCause(e));
/*      */       
/*  707 */       servletException = e;
/*      */     } catch (Throwable e) {
/*  709 */       ExceptionUtils.handleThrowable(e);
/*  710 */       this.wrapper.getLogger().error(sm.getString("applicationDispatcher.allocateException", new Object[] { this.wrapper.getName() }), e);
/*      */       
/*  712 */       servletException = new ServletException(sm.getString("applicationDispatcher.allocateException", new Object[] { this.wrapper.getName() }), e);
/*      */       
/*      */ 
/*  715 */       servlet = null;
/*      */     }
/*      */     
/*      */ 
/*  719 */     ApplicationFilterChain filterChain = ApplicationFilterFactory.createFilterChain(request, this.wrapper, servlet);
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  725 */       if ((servlet != null) && (filterChain != null)) {
/*  726 */         filterChain.doFilter(request, response);
/*      */       }
/*      */     }
/*      */     catch (ClientAbortException e) {
/*  730 */       ioException = e;
/*      */     } catch (IOException e) {
/*  732 */       this.wrapper.getLogger().error(sm.getString("applicationDispatcher.serviceException", new Object[] { this.wrapper.getName() }), e);
/*      */       
/*  734 */       ioException = e;
/*      */     } catch (UnavailableException e) {
/*  736 */       this.wrapper.getLogger().error(sm.getString("applicationDispatcher.serviceException", new Object[] { this.wrapper.getName() }), e);
/*      */       
/*  738 */       servletException = e;
/*  739 */       this.wrapper.unavailable(e);
/*      */     } catch (ServletException e) {
/*  741 */       Throwable rootCause = StandardWrapper.getRootCause(e);
/*  742 */       if (!(rootCause instanceof ClientAbortException)) {
/*  743 */         this.wrapper.getLogger().error(sm.getString("applicationDispatcher.serviceException", new Object[] { this.wrapper.getName() }), rootCause);
/*      */       }
/*      */       
/*  746 */       servletException = e;
/*      */     } catch (RuntimeException e) {
/*  748 */       this.wrapper.getLogger().error(sm.getString("applicationDispatcher.serviceException", new Object[] { this.wrapper.getName() }), e);
/*      */       
/*  750 */       runtimeException = e;
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  755 */       if (filterChain != null)
/*  756 */         filterChain.release();
/*      */     } catch (Throwable e) {
/*  758 */       ExceptionUtils.handleThrowable(e);
/*  759 */       this.wrapper.getLogger().error(sm.getString("standardWrapper.releaseFilters", new Object[] { this.wrapper.getName() }), e);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  766 */       if (servlet != null) {
/*  767 */         this.wrapper.deallocate(servlet);
/*      */       }
/*      */     } catch (ServletException e) {
/*  770 */       this.wrapper.getLogger().error(sm.getString("applicationDispatcher.deallocateException", new Object[] { this.wrapper.getName() }), e);
/*      */       
/*  772 */       servletException = e;
/*      */     } catch (Throwable e) {
/*  774 */       ExceptionUtils.handleThrowable(e);
/*  775 */       this.wrapper.getLogger().error(sm.getString("applicationDispatcher.deallocateException", new Object[] { this.wrapper.getName() }), e);
/*      */       
/*  777 */       servletException = new ServletException(sm.getString("applicationDispatcher.deallocateException", new Object[] { this.wrapper.getName() }), e);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  783 */     this.context.unbind(false, oldCCL);
/*      */     
/*      */ 
/*      */ 
/*  787 */     unwrapRequest(state);
/*  788 */     unwrapResponse(state);
/*      */     
/*  790 */     recycleRequestWrapper(state);
/*      */     
/*      */ 
/*  793 */     if (ioException != null)
/*  794 */       throw ioException;
/*  795 */     if (servletException != null)
/*  796 */       throw servletException;
/*  797 */     if (runtimeException != null) {
/*  798 */       throw runtimeException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void unwrapRequest(State state)
/*      */   {
/*  808 */     if (state.wrapRequest == null) {
/*  809 */       return;
/*      */     }
/*  811 */     if ((state.outerRequest.isAsyncStarted()) && 
/*  812 */       (!state.outerRequest.getAsyncContext().hasOriginalRequestAndResponse())) {
/*  813 */       return;
/*      */     }
/*      */     
/*      */ 
/*  817 */     ServletRequest previous = null;
/*  818 */     ServletRequest current = state.outerRequest;
/*  819 */     while (current != null)
/*      */     {
/*      */ 
/*  822 */       if (((current instanceof Request)) || ((current instanceof RequestFacade))) {
/*      */         break;
/*      */       }
/*      */       
/*      */ 
/*  827 */       if (current == state.wrapRequest) {
/*  828 */         ServletRequest next = ((ServletRequestWrapper)current).getRequest();
/*      */         
/*  830 */         if (previous == null) {
/*  831 */           state.outerRequest = next; break;
/*      */         }
/*  833 */         ((ServletRequestWrapper)previous).setRequest(next);
/*  834 */         break;
/*      */       }
/*      */       
/*      */ 
/*  838 */       previous = current;
/*  839 */       current = ((ServletRequestWrapper)current).getRequest();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void unwrapResponse(State state)
/*      */   {
/*  850 */     if (state.wrapResponse == null) {
/*  851 */       return;
/*      */     }
/*  853 */     if ((state.outerRequest.isAsyncStarted()) && 
/*  854 */       (!state.outerRequest.getAsyncContext().hasOriginalRequestAndResponse())) {
/*  855 */       return;
/*      */     }
/*      */     
/*      */ 
/*  859 */     ServletResponse previous = null;
/*  860 */     ServletResponse current = state.outerResponse;
/*  861 */     while (current != null)
/*      */     {
/*      */ 
/*  864 */       if (((current instanceof Response)) || ((current instanceof ResponseFacade))) {
/*      */         break;
/*      */       }
/*      */       
/*      */ 
/*  869 */       if (current == state.wrapResponse) {
/*  870 */         ServletResponse next = ((ServletResponseWrapper)current).getResponse();
/*      */         
/*  872 */         if (previous == null) {
/*  873 */           state.outerResponse = next; break;
/*      */         }
/*  875 */         ((ServletResponseWrapper)previous).setResponse(next);
/*  876 */         break;
/*      */       }
/*      */       
/*      */ 
/*  880 */       previous = current;
/*  881 */       current = ((ServletResponseWrapper)current).getResponse();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ServletRequest wrapRequest(State state)
/*      */   {
/*  895 */     ServletRequest previous = null;
/*  896 */     ServletRequest current = state.outerRequest;
/*  897 */     while (current != null) {
/*  898 */       if ((state.hrequest == null) && ((current instanceof javax.servlet.http.HttpServletRequest)))
/*  899 */         state.hrequest = ((javax.servlet.http.HttpServletRequest)current);
/*  900 */       if (!(current instanceof ServletRequestWrapper))
/*      */         break;
/*  902 */       if ((current instanceof ApplicationHttpRequest))
/*      */         break;
/*  904 */       if ((current instanceof ApplicationRequest))
/*      */         break;
/*  906 */       previous = current;
/*  907 */       current = ((ServletRequestWrapper)current).getRequest();
/*      */     }
/*      */     
/*      */ 
/*  911 */     ServletRequest wrapper = null;
/*  912 */     if (((current instanceof ApplicationHttpRequest)) || ((current instanceof Request)) || ((current instanceof javax.servlet.http.HttpServletRequest)))
/*      */     {
/*      */ 
/*      */ 
/*  916 */       javax.servlet.http.HttpServletRequest hcurrent = (javax.servlet.http.HttpServletRequest)current;
/*  917 */       boolean crossContext = false;
/*  918 */       if (((state.outerRequest instanceof ApplicationHttpRequest)) || ((state.outerRequest instanceof Request)) || ((state.outerRequest instanceof javax.servlet.http.HttpServletRequest)))
/*      */       {
/*      */ 
/*  921 */         javax.servlet.http.HttpServletRequest houterRequest = (javax.servlet.http.HttpServletRequest)state.outerRequest;
/*      */         
/*  923 */         Object contextPath = houterRequest.getAttribute("javax.servlet.include.context_path");
/*      */         
/*  925 */         if (contextPath == null)
/*      */         {
/*  927 */           contextPath = houterRequest.getContextPath();
/*      */         }
/*  929 */         crossContext = !this.context.getPath().equals(contextPath);
/*      */       }
/*  931 */       wrapper = new ApplicationHttpRequest(hcurrent, this.context, crossContext);
/*      */     }
/*      */     else {
/*  934 */       wrapper = new ApplicationRequest(current);
/*      */     }
/*  936 */     if (previous == null) {
/*  937 */       state.outerRequest = wrapper;
/*      */     } else
/*  939 */       ((ServletRequestWrapper)previous).setRequest(wrapper);
/*  940 */     state.wrapRequest = wrapper;
/*  941 */     return wrapper;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ServletResponse wrapResponse(State state)
/*      */   {
/*  953 */     ServletResponse previous = null;
/*  954 */     ServletResponse current = state.outerResponse;
/*  955 */     while (current != null) {
/*  956 */       if ((state.hresponse == null) && ((current instanceof HttpServletResponse))) {
/*  957 */         state.hresponse = ((HttpServletResponse)current);
/*  958 */         if (!state.including)
/*  959 */           return null;
/*      */       }
/*  961 */       if (!(current instanceof ServletResponseWrapper))
/*      */         break;
/*  963 */       if ((current instanceof ApplicationHttpResponse))
/*      */         break;
/*  965 */       if ((current instanceof ApplicationResponse))
/*      */         break;
/*  967 */       previous = current;
/*  968 */       current = ((ServletResponseWrapper)current).getResponse();
/*      */     }
/*      */     
/*      */ 
/*  972 */     ServletResponse wrapper = null;
/*  973 */     if (((current instanceof ApplicationHttpResponse)) || ((current instanceof Response)) || ((current instanceof HttpServletResponse)))
/*      */     {
/*      */ 
/*  976 */       wrapper = new ApplicationHttpResponse((HttpServletResponse)current, state.including);
/*      */     }
/*      */     else
/*      */     {
/*  980 */       wrapper = new ApplicationResponse(current, state.including); }
/*  981 */     if (previous == null) {
/*  982 */       state.outerResponse = wrapper;
/*      */     } else
/*  984 */       ((ServletResponseWrapper)previous).setResponse(wrapper);
/*  985 */     state.wrapResponse = wrapper;
/*  986 */     return wrapper;
/*      */   }
/*      */   
/*      */   private void checkSameObjects(ServletRequest appRequest, ServletResponse appResponse)
/*      */     throws ServletException
/*      */   {
/*  992 */     ServletRequest originalRequest = ApplicationFilterChain.getLastServicedRequest();
/*      */     
/*  994 */     ServletResponse originalResponse = ApplicationFilterChain.getLastServicedResponse();
/*      */     
/*      */ 
/*      */ 
/*  998 */     if ((originalRequest == null) || (originalResponse == null)) {
/*  999 */       return;
/*      */     }
/*      */     
/* 1002 */     boolean same = false;
/* 1003 */     ServletRequest dispatchedRequest = appRequest;
/*      */     
/*      */ 
/* 1006 */     while (((originalRequest instanceof ServletRequestWrapper)) && (((ServletRequestWrapper)originalRequest).getRequest() != null))
/*      */     {
/* 1008 */       originalRequest = ((ServletRequestWrapper)originalRequest).getRequest();
/*      */     }
/*      */     
/*      */ 
/* 1012 */     while (!same) {
/* 1013 */       if (originalRequest.equals(dispatchedRequest)) {
/* 1014 */         same = true;
/*      */       }
/* 1016 */       if ((same) || (!(dispatchedRequest instanceof ServletRequestWrapper))) break;
/* 1017 */       dispatchedRequest = ((ServletRequestWrapper)dispatchedRequest).getRequest();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1023 */     if (!same) {
/* 1024 */       throw new ServletException(sm.getString("applicationDispatcher.specViolation.request"));
/*      */     }
/*      */     
/*      */ 
/* 1028 */     same = false;
/* 1029 */     ServletResponse dispatchedResponse = appResponse;
/*      */     
/*      */ 
/* 1032 */     while (((originalResponse instanceof ServletResponseWrapper)) && (((ServletResponseWrapper)originalResponse).getResponse() != null))
/*      */     {
/*      */ 
/* 1035 */       originalResponse = ((ServletResponseWrapper)originalResponse).getResponse();
/*      */     }
/*      */     
/*      */ 
/* 1039 */     while (!same) {
/* 1040 */       if (originalResponse.equals(dispatchedResponse)) {
/* 1041 */         same = true;
/*      */       }
/*      */       
/* 1044 */       if ((same) || (!(dispatchedResponse instanceof ServletResponseWrapper))) break;
/* 1045 */       dispatchedResponse = ((ServletResponseWrapper)dispatchedResponse).getResponse();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1052 */     if (!same) {
/* 1053 */       throw new ServletException(sm.getString("applicationDispatcher.specViolation.response"));
/*      */     }
/*      */   }
/*      */   
/*      */   private void recycleRequestWrapper(State state)
/*      */   {
/* 1059 */     if ((state.wrapRequest instanceof ApplicationHttpRequest)) {
/* 1060 */       ((ApplicationHttpRequest)state.wrapRequest).recycle();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\core\ApplicationDispatcher.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */