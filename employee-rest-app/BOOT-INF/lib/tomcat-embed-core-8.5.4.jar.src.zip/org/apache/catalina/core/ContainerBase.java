/*      */ package org.apache.catalina.core;
/*      */ 
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.File;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.concurrent.BlockingQueue;
/*      */ import java.util.concurrent.Callable;
/*      */ import java.util.concurrent.CopyOnWriteArrayList;
/*      */ import java.util.concurrent.Future;
/*      */ import java.util.concurrent.LinkedBlockingQueue;
/*      */ import java.util.concurrent.ThreadFactory;
/*      */ import java.util.concurrent.ThreadPoolExecutor;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReadWriteLock;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*      */ import javax.management.ObjectName;
/*      */ import org.apache.catalina.AccessLog;
/*      */ import org.apache.catalina.Cluster;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.ContainerEvent;
/*      */ import org.apache.catalina.ContainerListener;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.Lifecycle;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Loader;
/*      */ import org.apache.catalina.Pipeline;
/*      */ import org.apache.catalina.Realm;
/*      */ import org.apache.catalina.Valve;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.connector.Request;
/*      */ import org.apache.catalina.connector.Response;
/*      */ import org.apache.catalina.util.ContextName;
/*      */ import org.apache.catalina.util.LifecycleMBeanBase;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class ContainerBase
/*      */   extends LifecycleMBeanBase
/*      */   implements Container
/*      */ {
/*  132 */   private static final Log log = LogFactory.getLog(ContainerBase.class);
/*      */   protected final HashMap<String, Container> children;
/*      */   protected int backgroundProcessorDelay;
/*      */   protected final List<ContainerListener> listeners;
/*      */   protected Log logger;
/*      */   protected String logName;
/*      */   protected Cluster cluster;
/*      */   
/*      */   protected class PrivilegedAddChild
/*      */     implements PrivilegedAction<Void>
/*      */   {
/*      */     PrivilegedAddChild(Container child)
/*      */     {
/*  145 */       this.child = child;
/*      */     }
/*      */     
/*      */     public Void run()
/*      */     {
/*  150 */       ContainerBase.this.addChildInternal(this.child);
/*  151 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private final Container child;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final ReadWriteLock clusterLock;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String name;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Container parent;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ClassLoader parentClassLoader;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final Pipeline pipeline;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private volatile Realm realm;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final ReadWriteLock realmLock;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  238 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.core");
/*      */   protected boolean startChildren;
/*      */   protected final PropertyChangeSupport support;
/*      */   private Thread thread;
/*      */   private volatile boolean threadDone;
/*      */   protected volatile AccessLog accessLog;
/*      */   private volatile boolean accessLogScanComplete;
/*      */   private int startStopThreads;
/*      */   protected ThreadPoolExecutor startStopExecutor;
/*      */   
/*      */   public ContainerBase()
/*      */   {
/*  163 */     this.children = new HashMap();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  169 */     this.backgroundProcessorDelay = -1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  178 */     this.listeners = new CopyOnWriteArrayList();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  183 */     this.logger = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  189 */     this.logName = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  195 */     this.cluster = null;
/*  196 */     this.clusterLock = new ReentrantReadWriteLock();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  202 */     this.name = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  208 */     this.parent = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  214 */     this.parentClassLoader = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  220 */     this.pipeline = new StandardPipeline(this);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  226 */     this.realm = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  232 */     this.realmLock = new ReentrantReadWriteLock();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  245 */     this.startChildren = true;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  250 */     this.support = new PropertyChangeSupport(this);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  257 */     this.thread = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  263 */     this.threadDone = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  270 */     this.accessLog = null;
/*  271 */     this.accessLogScanComplete = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  278 */     this.startStopThreads = 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getStartStopThreads()
/*      */   {
/*  286 */     return this.startStopThreads;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getStartStopThreadsInternal()
/*      */   {
/*  293 */     int result = getStartStopThreads();
/*      */     
/*      */ 
/*  296 */     if (result > 0) {
/*  297 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  303 */     result = Runtime.getRuntime().availableProcessors() + result;
/*  304 */     if (result < 1) {
/*  305 */       result = 1;
/*      */     }
/*  307 */     return result;
/*      */   }
/*      */   
/*      */   public void setStartStopThreads(int startStopThreads)
/*      */   {
/*  312 */     this.startStopThreads = startStopThreads;
/*      */     
/*      */ 
/*  315 */     ThreadPoolExecutor executor = this.startStopExecutor;
/*  316 */     if (executor != null) {
/*  317 */       int newThreads = getStartStopThreadsInternal();
/*  318 */       executor.setMaximumPoolSize(newThreads);
/*  319 */       executor.setCorePoolSize(newThreads);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getBackgroundProcessorDelay()
/*      */   {
/*  335 */     return this.backgroundProcessorDelay;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBackgroundProcessorDelay(int delay)
/*      */   {
/*  348 */     this.backgroundProcessorDelay = delay;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Log getLogger()
/*      */   {
/*  358 */     if (this.logger != null)
/*  359 */       return this.logger;
/*  360 */     this.logger = LogFactory.getLog(logName());
/*  361 */     return this.logger;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Cluster getCluster()
/*      */   {
/*  373 */     Lock readLock = this.clusterLock.readLock();
/*  374 */     readLock.lock();
/*      */     try { Cluster localCluster;
/*  376 */       if (this.cluster != null) {
/*  377 */         return this.cluster;
/*      */       }
/*  379 */       if (this.parent != null) {
/*  380 */         return this.parent.getCluster();
/*      */       }
/*  382 */       return null;
/*      */     } finally {
/*  384 */       readLock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Cluster getClusterInternal()
/*      */   {
/*  393 */     Lock readLock = this.clusterLock.readLock();
/*  394 */     readLock.lock();
/*      */     try {
/*  396 */       return this.cluster;
/*      */     } finally {
/*  398 */       readLock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCluster(Cluster cluster)
/*      */   {
/*  411 */     Cluster oldCluster = null;
/*  412 */     Lock writeLock = this.clusterLock.writeLock();
/*  413 */     writeLock.lock();
/*      */     try
/*      */     {
/*  416 */       oldCluster = this.cluster;
/*  417 */       if (oldCluster == cluster)
/*      */         return;
/*  419 */       this.cluster = cluster;
/*      */       
/*      */ 
/*  422 */       if ((getState().isAvailable()) && (oldCluster != null) && ((oldCluster instanceof Lifecycle))) {
/*      */         try
/*      */         {
/*  425 */           ((Lifecycle)oldCluster).stop();
/*      */         } catch (LifecycleException e) {
/*  427 */           log.error("ContainerBase.setCluster: stop: ", e);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  432 */       if (cluster != null) {
/*  433 */         cluster.setContainer(this);
/*      */       }
/*  435 */       if ((getState().isAvailable()) && (cluster != null) && ((cluster instanceof Lifecycle))) {
/*      */         try
/*      */         {
/*  438 */           ((Lifecycle)cluster).start();
/*      */         } catch (LifecycleException e) {
/*  440 */           log.error("ContainerBase.setCluster: start: ", e);
/*      */         }
/*      */       }
/*      */     } finally {
/*  444 */       writeLock.unlock();
/*      */     }
/*      */     
/*      */ 
/*  448 */     this.support.firePropertyChange("cluster", oldCluster, cluster);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getName()
/*      */   {
/*  460 */     return this.name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setName(String name)
/*      */   {
/*  479 */     String oldName = this.name;
/*  480 */     this.name = name;
/*  481 */     this.support.firePropertyChange("name", oldName, this.name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getStartChildren()
/*      */   {
/*  493 */     return this.startChildren;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStartChildren(boolean startChildren)
/*      */   {
/*  506 */     boolean oldStartChildren = this.startChildren;
/*  507 */     this.startChildren = startChildren;
/*  508 */     this.support.firePropertyChange("startChildren", oldStartChildren, this.startChildren);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Container getParent()
/*      */   {
/*  519 */     return this.parent;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParent(Container container)
/*      */   {
/*  538 */     Container oldParent = this.parent;
/*  539 */     this.parent = container;
/*  540 */     this.support.firePropertyChange("parent", oldParent, this.parent);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClassLoader getParentClassLoader()
/*      */   {
/*  552 */     if (this.parentClassLoader != null)
/*  553 */       return this.parentClassLoader;
/*  554 */     if (this.parent != null) {
/*  555 */       return this.parent.getParentClassLoader();
/*      */     }
/*  557 */     return ClassLoader.getSystemClassLoader();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParentClassLoader(ClassLoader parent)
/*      */   {
/*  573 */     ClassLoader oldParentClassLoader = this.parentClassLoader;
/*  574 */     this.parentClassLoader = parent;
/*  575 */     this.support.firePropertyChange("parentClassLoader", oldParentClassLoader, this.parentClassLoader);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Pipeline getPipeline()
/*      */   {
/*  588 */     return this.pipeline;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Realm getRealm()
/*      */   {
/*  601 */     Lock l = this.realmLock.readLock();
/*  602 */     l.lock();
/*      */     try { Realm localRealm;
/*  604 */       if (this.realm != null)
/*  605 */         return this.realm;
/*  606 */       if (this.parent != null)
/*  607 */         return this.parent.getRealm();
/*  608 */       return null;
/*      */     } finally {
/*  610 */       l.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   protected Realm getRealmInternal()
/*      */   {
/*  616 */     Lock l = this.realmLock.readLock();
/*  617 */     l.lock();
/*      */     try {
/*  619 */       return this.realm;
/*      */     } finally {
/*  621 */       l.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRealm(Realm realm)
/*      */   {
/*  633 */     Lock l = this.realmLock.writeLock();
/*  634 */     l.lock();
/*      */     try
/*      */     {
/*  637 */       Realm oldRealm = this.realm;
/*  638 */       if (oldRealm == realm)
/*      */         return;
/*  640 */       this.realm = realm;
/*      */       
/*      */ 
/*  643 */       if ((getState().isAvailable()) && (oldRealm != null) && ((oldRealm instanceof Lifecycle))) {
/*      */         try
/*      */         {
/*  646 */           ((Lifecycle)oldRealm).stop();
/*      */         } catch (LifecycleException e) {
/*  648 */           log.error("ContainerBase.setRealm: stop: ", e);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  653 */       if (realm != null)
/*  654 */         realm.setContainer(this);
/*  655 */       if ((getState().isAvailable()) && (realm != null) && ((realm instanceof Lifecycle))) {
/*      */         try
/*      */         {
/*  658 */           ((Lifecycle)realm).start();
/*      */         } catch (LifecycleException e) {
/*  660 */           log.error("ContainerBase.setRealm: start: ", e);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  665 */       this.support.firePropertyChange("realm", oldRealm, this.realm);
/*      */     } finally {
/*  667 */       l.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addChild(Container child)
/*      */   {
/*  695 */     if (Globals.IS_SECURITY_ENABLED) {
/*  696 */       PrivilegedAction<Void> dp = new PrivilegedAddChild(child);
/*      */       
/*  698 */       AccessController.doPrivileged(dp);
/*      */     } else {
/*  700 */       addChildInternal(child);
/*      */     }
/*      */   }
/*      */   
/*      */   private void addChildInternal(Container child)
/*      */   {
/*  706 */     if (log.isDebugEnabled())
/*  707 */       log.debug("Add child " + child + " " + this);
/*  708 */     synchronized (this.children) {
/*  709 */       if (this.children.get(child.getName()) != null) {
/*  710 */         throw new IllegalArgumentException("addChild:  Child name '" + child.getName() + "' is not unique");
/*      */       }
/*      */       
/*  713 */       child.setParent(this);
/*  714 */       this.children.put(child.getName(), child);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  721 */       if (((getState().isAvailable()) || (LifecycleState.STARTING_PREP.equals(getState()))) && (this.startChildren))
/*      */       {
/*      */ 
/*  724 */         child.start();
/*      */       }
/*      */     } catch (LifecycleException e) {
/*  727 */       log.error("ContainerBase.addChild: start: ", e);
/*  728 */       throw new IllegalStateException("ContainerBase.addChild: start: " + e);
/*      */     } finally {
/*  730 */       fireContainerEvent("addChild", child);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addContainerListener(ContainerListener listener)
/*      */   {
/*  742 */     this.listeners.add(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addPropertyChangeListener(PropertyChangeListener listener)
/*      */   {
/*  753 */     this.support.addPropertyChangeListener(listener);
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public Container findChild(String name)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: ifnonnull +5 -> 6
/*      */     //   4: aconst_null
/*      */     //   5: areturn
/*      */     //   6: aload_0
/*      */     //   7: getfield 7	org/apache/catalina/core/ContainerBase:children	Ljava/util/HashMap;
/*      */     //   10: dup
/*      */     //   11: astore_2
/*      */     //   12: monitorenter
/*      */     //   13: aload_0
/*      */     //   14: getfield 7	org/apache/catalina/core/ContainerBase:children	Ljava/util/HashMap;
/*      */     //   17: aload_1
/*      */     //   18: invokevirtual 86	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   21: checkcast 103	org/apache/catalina/Container
/*      */     //   24: aload_2
/*      */     //   25: monitorexit
/*      */     //   26: areturn
/*      */     //   27: astore_3
/*      */     //   28: aload_2
/*      */     //   29: monitorexit
/*      */     //   30: aload_3
/*      */     //   31: athrow
/*      */     // Line number table:
/*      */     //   Java source line #765	-> byte code offset #0
/*      */     //   Java source line #766	-> byte code offset #4
/*      */     //   Java source line #768	-> byte code offset #6
/*      */     //   Java source line #769	-> byte code offset #13
/*      */     //   Java source line #770	-> byte code offset #27
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	32	0	this	ContainerBase
/*      */     //   0	32	1	name	String
/*      */     //   11	18	2	Ljava/lang/Object;	Object
/*      */     //   27	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   13	26	27	finally
/*      */     //   27	30	27	finally
/*      */   }
/*      */   
/*      */   public Container[] findChildren()
/*      */   {
/*  780 */     synchronized (this.children) {
/*  781 */       Container[] results = new Container[this.children.size()];
/*  782 */       return (Container[])this.children.values().toArray(results);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ContainerListener[] findContainerListeners()
/*      */   {
/*  794 */     ContainerListener[] results = new ContainerListener[0];
/*      */     
/*  796 */     return (ContainerListener[])this.listeners.toArray(results);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeChild(Container child)
/*      */   {
/*  809 */     if (child == null) {
/*  810 */       return;
/*      */     }
/*      */     try
/*      */     {
/*  814 */       if (child.getState().isAvailable()) {
/*  815 */         child.stop();
/*      */       }
/*      */     } catch (LifecycleException e) {
/*  818 */       log.error("ContainerBase.removeChild: stop: ", e);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  825 */       if (!LifecycleState.DESTROYING.equals(child.getState())) {
/*  826 */         child.destroy();
/*      */       }
/*      */     } catch (LifecycleException e) {
/*  829 */       log.error("ContainerBase.removeChild: destroy: ", e);
/*      */     }
/*      */     
/*  832 */     synchronized (this.children) {
/*  833 */       if (this.children.get(child.getName()) == null)
/*  834 */         return;
/*  835 */       this.children.remove(child.getName());
/*      */     }
/*      */     
/*  838 */     fireContainerEvent("removeChild", child);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeContainerListener(ContainerListener listener)
/*      */   {
/*  849 */     this.listeners.remove(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removePropertyChangeListener(PropertyChangeListener listener)
/*      */   {
/*  861 */     this.support.removePropertyChangeListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */   protected void initInternal()
/*      */     throws LifecycleException
/*      */   {
/*  868 */     BlockingQueue<Runnable> startStopQueue = new LinkedBlockingQueue();
/*  869 */     this.startStopExecutor = new ThreadPoolExecutor(getStartStopThreadsInternal(), getStartStopThreadsInternal(), 10L, TimeUnit.SECONDS, startStopQueue, new StartStopThreadFactory(getName() + "-startStop-"));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  874 */     this.startStopExecutor.allowCoreThreadTimeOut(true);
/*  875 */     super.initInternal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void startInternal()
/*      */     throws LifecycleException
/*      */   {
/*  890 */     this.logger = null;
/*  891 */     getLogger();
/*  892 */     Cluster cluster = getClusterInternal();
/*  893 */     if ((cluster instanceof Lifecycle)) {
/*  894 */       ((Lifecycle)cluster).start();
/*      */     }
/*  896 */     Realm realm = getRealmInternal();
/*  897 */     if ((realm instanceof Lifecycle)) {
/*  898 */       ((Lifecycle)realm).start();
/*      */     }
/*      */     
/*      */ 
/*  902 */     Container[] children = findChildren();
/*  903 */     List<Future<Void>> results = new ArrayList();
/*  904 */     for (int i = 0; i < children.length; i++) {
/*  905 */       results.add(this.startStopExecutor.submit(new StartChild(children[i])));
/*      */     }
/*      */     
/*  908 */     boolean fail = false;
/*  909 */     for (Future<Void> result : results) {
/*      */       try {
/*  911 */         result.get();
/*      */       } catch (Exception e) {
/*  913 */         log.error(sm.getString("containerBase.threadedStartFailed"), e);
/*  914 */         fail = true;
/*      */       }
/*      */     }
/*      */     
/*  918 */     if (fail) {
/*  919 */       throw new LifecycleException(sm.getString("containerBase.threadedStartFailed"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  924 */     if ((this.pipeline instanceof Lifecycle)) {
/*  925 */       ((Lifecycle)this.pipeline).start();
/*      */     }
/*      */     
/*  928 */     setState(LifecycleState.STARTING);
/*      */     
/*      */ 
/*  931 */     threadStart();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void stopInternal()
/*      */     throws LifecycleException
/*      */   {
/*  947 */     threadStop();
/*      */     
/*  949 */     setState(LifecycleState.STOPPING);
/*      */     
/*      */ 
/*  952 */     if (((this.pipeline instanceof Lifecycle)) && (((Lifecycle)this.pipeline).getState().isAvailable()))
/*      */     {
/*  954 */       ((Lifecycle)this.pipeline).stop();
/*      */     }
/*      */     
/*      */ 
/*  958 */     Container[] children = findChildren();
/*  959 */     List<Future<Void>> results = new ArrayList();
/*  960 */     for (int i = 0; i < children.length; i++) {
/*  961 */       results.add(this.startStopExecutor.submit(new StopChild(children[i])));
/*      */     }
/*      */     
/*  964 */     boolean fail = false;
/*  965 */     for (Future<Void> result : results) {
/*      */       try {
/*  967 */         result.get();
/*      */       } catch (Exception e) {
/*  969 */         log.error(sm.getString("containerBase.threadedStopFailed"), e);
/*  970 */         fail = true;
/*      */       }
/*      */     }
/*  973 */     if (fail) {
/*  974 */       throw new LifecycleException(sm.getString("containerBase.threadedStopFailed"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  979 */     Realm realm = getRealmInternal();
/*  980 */     if ((realm instanceof Lifecycle)) {
/*  981 */       ((Lifecycle)realm).stop();
/*      */     }
/*  983 */     Cluster cluster = getClusterInternal();
/*  984 */     if ((cluster instanceof Lifecycle)) {
/*  985 */       ((Lifecycle)cluster).stop();
/*      */     }
/*      */   }
/*      */   
/*      */   protected void destroyInternal()
/*      */     throws LifecycleException
/*      */   {
/*  992 */     Realm realm = getRealmInternal();
/*  993 */     if ((realm instanceof Lifecycle)) {
/*  994 */       ((Lifecycle)realm).destroy();
/*      */     }
/*  996 */     Cluster cluster = getClusterInternal();
/*  997 */     if ((cluster instanceof Lifecycle)) {
/*  998 */       ((Lifecycle)cluster).destroy();
/*      */     }
/*      */     
/*      */ 
/* 1002 */     if ((this.pipeline instanceof Lifecycle)) {
/* 1003 */       ((Lifecycle)this.pipeline).destroy();
/*      */     }
/*      */     
/*      */ 
/* 1007 */     for (Container child : findChildren()) {
/* 1008 */       removeChild(child);
/*      */     }
/*      */     
/*      */ 
/* 1012 */     if (this.parent != null) {
/* 1013 */       this.parent.removeChild(this);
/*      */     }
/*      */     
/*      */ 
/* 1017 */     if (this.startStopExecutor != null) {
/* 1018 */       this.startStopExecutor.shutdownNow();
/*      */     }
/*      */     
/* 1021 */     super.destroyInternal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void logAccess(Request request, Response response, long time, boolean useDefault)
/*      */   {
/* 1034 */     boolean logged = false;
/*      */     
/* 1036 */     if (getAccessLog() != null) {
/* 1037 */       getAccessLog().log(request, response, time);
/* 1038 */       logged = true;
/*      */     }
/*      */     
/* 1041 */     if (getParent() != null)
/*      */     {
/*      */ 
/* 1044 */       getParent().logAccess(request, response, time, (useDefault) && (!logged));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public AccessLog getAccessLog()
/*      */   {
/* 1051 */     if (this.accessLogScanComplete) {
/* 1052 */       return this.accessLog;
/*      */     }
/*      */     
/* 1055 */     AccessLogAdapter adapter = null;
/* 1056 */     Valve[] valves = getPipeline().getValves();
/* 1057 */     for (Valve valve : valves) {
/* 1058 */       if ((valve instanceof AccessLog)) {
/* 1059 */         if (adapter == null) {
/* 1060 */           adapter = new AccessLogAdapter((AccessLog)valve);
/*      */         } else {
/* 1062 */           adapter.add((AccessLog)valve);
/*      */         }
/*      */       }
/*      */     }
/* 1066 */     if (adapter != null) {
/* 1067 */       this.accessLog = adapter;
/*      */     }
/* 1069 */     this.accessLogScanComplete = true;
/* 1070 */     return this.accessLog;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void addValve(Valve valve)
/*      */   {
/* 1095 */     this.pipeline.addValve(valve);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void backgroundProcess()
/*      */   {
/* 1107 */     if (!getState().isAvailable()) {
/* 1108 */       return;
/*      */     }
/* 1110 */     Cluster cluster = getClusterInternal();
/* 1111 */     if (cluster != null) {
/*      */       try {
/* 1113 */         cluster.backgroundProcess();
/*      */       } catch (Exception e) {
/* 1115 */         log.warn(sm.getString("containerBase.backgroundProcess.cluster", new Object[] { cluster }), e);
/*      */       }
/*      */     }
/*      */     
/* 1119 */     Realm realm = getRealmInternal();
/* 1120 */     if (realm != null) {
/*      */       try {
/* 1122 */         realm.backgroundProcess();
/*      */       } catch (Exception e) {
/* 1124 */         log.warn(sm.getString("containerBase.backgroundProcess.realm", new Object[] { realm }), e);
/*      */       }
/*      */     }
/* 1127 */     Valve current = this.pipeline.getFirst();
/* 1128 */     while (current != null) {
/*      */       try {
/* 1130 */         current.backgroundProcess();
/*      */       } catch (Exception e) {
/* 1132 */         log.warn(sm.getString("containerBase.backgroundProcess.valve", new Object[] { current }), e);
/*      */       }
/* 1134 */       current = current.getNext();
/*      */     }
/* 1136 */     fireLifecycleEvent("periodic", null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public File getCatalinaBase()
/*      */   {
/* 1143 */     if (this.parent == null) {
/* 1144 */       return null;
/*      */     }
/*      */     
/* 1147 */     return this.parent.getCatalinaBase();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public File getCatalinaHome()
/*      */   {
/* 1154 */     if (this.parent == null) {
/* 1155 */       return null;
/*      */     }
/*      */     
/* 1158 */     return this.parent.getCatalinaHome();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fireContainerEvent(String type, Object data)
/*      */   {
/* 1175 */     if (this.listeners.size() < 1) {
/* 1176 */       return;
/*      */     }
/* 1178 */     ContainerEvent event = new ContainerEvent(this, type, data);
/*      */     
/* 1180 */     for (ContainerListener listener : this.listeners) {
/* 1181 */       listener.containerEvent(event);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String logName()
/*      */   {
/* 1191 */     if (this.logName != null) {
/* 1192 */       return this.logName;
/*      */     }
/* 1194 */     String loggerName = null;
/* 1195 */     Container current = this;
/* 1196 */     while (current != null) {
/* 1197 */       String name = current.getName();
/* 1198 */       if ((name == null) || (name.equals(""))) {
/* 1199 */         name = "/";
/* 1200 */       } else if (name.startsWith("##")) {
/* 1201 */         name = "/" + name;
/*      */       }
/* 1203 */       loggerName = "[" + name + "]" + (loggerName != null ? "." + loggerName : "");
/*      */       
/* 1205 */       current = current.getParent();
/*      */     }
/* 1207 */     this.logName = (ContainerBase.class.getName() + "." + loggerName);
/* 1208 */     return this.logName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getDomainInternal()
/*      */   {
/* 1218 */     Container p = getParent();
/* 1219 */     if (p == null) {
/* 1220 */       return null;
/*      */     }
/* 1222 */     return p.getDomain();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getMBeanKeyProperties()
/*      */   {
/* 1229 */     Container c = this;
/* 1230 */     StringBuilder keyProperties = new StringBuilder();
/* 1231 */     int containerCount = 0;
/*      */     
/*      */ 
/*      */ 
/* 1235 */     while (!(c instanceof Engine)) {
/* 1236 */       if ((c instanceof Wrapper)) {
/* 1237 */         keyProperties.insert(0, ",servlet=");
/* 1238 */         keyProperties.insert(9, c.getName());
/* 1239 */       } else if ((c instanceof Context)) {
/* 1240 */         keyProperties.insert(0, ",context=");
/* 1241 */         ContextName cn = new ContextName(c.getName(), false);
/* 1242 */         keyProperties.insert(9, cn.getDisplayName());
/* 1243 */       } else if ((c instanceof Host)) {
/* 1244 */         keyProperties.insert(0, ",host=");
/* 1245 */         keyProperties.insert(6, c.getName());
/* 1246 */       } else { if (c == null)
/*      */         {
/* 1248 */           keyProperties.append(",container");
/* 1249 */           keyProperties.append(containerCount++);
/* 1250 */           keyProperties.append("=null");
/* 1251 */           break;
/*      */         }
/*      */         
/* 1254 */         keyProperties.append(",container");
/* 1255 */         keyProperties.append(containerCount++);
/* 1256 */         keyProperties.append('=');
/* 1257 */         keyProperties.append(c.getName());
/*      */       }
/* 1259 */       c = c.getParent();
/*      */     }
/* 1261 */     return keyProperties.toString();
/*      */   }
/*      */   
/*      */   public ObjectName[] getChildren() {
/* 1265 */     List<ObjectName> names = new ArrayList(this.children.size());
/* 1266 */     Iterator<Container> it = this.children.values().iterator();
/* 1267 */     while (it.hasNext()) {
/* 1268 */       Object next = it.next();
/* 1269 */       if ((next instanceof ContainerBase)) {
/* 1270 */         names.add(((ContainerBase)next).getObjectName());
/*      */       }
/*      */     }
/* 1273 */     return (ObjectName[])names.toArray(new ObjectName[names.size()]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void threadStart()
/*      */   {
/* 1285 */     if (this.thread != null)
/* 1286 */       return;
/* 1287 */     if (this.backgroundProcessorDelay <= 0) {
/* 1288 */       return;
/*      */     }
/* 1290 */     this.threadDone = false;
/* 1291 */     String threadName = "ContainerBackgroundProcessor[" + toString() + "]";
/* 1292 */     this.thread = new Thread(new ContainerBackgroundProcessor(), threadName);
/* 1293 */     this.thread.setDaemon(true);
/* 1294 */     this.thread.start();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void threadStop()
/*      */   {
/* 1305 */     if (this.thread == null) {
/* 1306 */       return;
/*      */     }
/* 1308 */     this.threadDone = true;
/* 1309 */     this.thread.interrupt();
/*      */     try {
/* 1311 */       this.thread.join();
/*      */     }
/*      */     catch (InterruptedException localInterruptedException) {}
/*      */     
/*      */ 
/* 1316 */     this.thread = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected class ContainerBackgroundProcessor
/*      */     implements Runnable
/*      */   {
/*      */     protected ContainerBackgroundProcessor() {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void run()
/*      */     {
/* 1332 */       Throwable t = null;
/* 1333 */       String unexpectedDeathMessage = ContainerBase.sm.getString("containerBase.backgroundProcess.unexpectedThreadDeath", new Object[] { Thread.currentThread().getName() });
/*      */       
/*      */       try
/*      */       {
/* 1337 */         while (!ContainerBase.this.threadDone) {
/*      */           try {
/* 1339 */             Thread.sleep(ContainerBase.this.backgroundProcessorDelay * 1000L);
/*      */           }
/*      */           catch (InterruptedException localInterruptedException) {}
/*      */           
/* 1343 */           if (!ContainerBase.this.threadDone) {
/* 1344 */             processChildren(ContainerBase.this);
/*      */           }
/*      */         }
/*      */       } catch (RuntimeException|Error e) {
/* 1348 */         t = e;
/* 1349 */         throw e;
/*      */       } finally {
/* 1351 */         if (!ContainerBase.this.threadDone) {
/* 1352 */           ContainerBase.log.error(unexpectedDeathMessage, t);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     protected void processChildren(Container container) {
/* 1358 */       ClassLoader originalClassLoader = null;
/*      */       try
/*      */       {
/* 1361 */         if ((container instanceof Context)) {
/* 1362 */           Loader loader = ((Context)container).getLoader();
/*      */           
/* 1364 */           if (loader == null) {
/*      */             return;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1370 */           originalClassLoader = ((Context)container).bind(false, null);
/*      */         }
/* 1372 */         container.backgroundProcess();
/* 1373 */         Container[] children = container.findChildren();
/* 1374 */         for (int i = 0; i < children.length; i++) {
/* 1375 */           if (children[i].getBackgroundProcessorDelay() <= 0) {
/* 1376 */             processChildren(children[i]);
/*      */           }
/*      */         }
/*      */       } catch (Throwable t) {
/* 1380 */         ExceptionUtils.handleThrowable(t);
/* 1381 */         ContainerBase.log.error("Exception invoking periodic operation: ", t);
/*      */       } finally {
/* 1383 */         if ((container instanceof Context)) {
/* 1384 */           ((Context)container).unbind(false, originalClassLoader);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static class StartChild
/*      */     implements Callable<Void>
/*      */   {
/*      */     private Container child;
/*      */     
/*      */     public StartChild(Container child)
/*      */     {
/* 1398 */       this.child = child;
/*      */     }
/*      */     
/*      */     public Void call() throws LifecycleException
/*      */     {
/* 1403 */       this.child.start();
/* 1404 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */   private static class StopChild implements Callable<Void>
/*      */   {
/*      */     private Container child;
/*      */     
/*      */     public StopChild(Container child) {
/* 1413 */       this.child = child;
/*      */     }
/*      */     
/*      */     public Void call() throws LifecycleException
/*      */     {
/* 1418 */       if (this.child.getState().isAvailable()) {
/* 1419 */         this.child.stop();
/*      */       }
/* 1421 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */   private static class StartStopThreadFactory implements ThreadFactory {
/*      */     private final ThreadGroup group;
/* 1427 */     private final AtomicInteger threadNumber = new AtomicInteger(1);
/*      */     private final String namePrefix;
/*      */     
/*      */     public StartStopThreadFactory(String namePrefix) {
/* 1431 */       SecurityManager s = System.getSecurityManager();
/* 1432 */       this.group = (s != null ? s.getThreadGroup() : Thread.currentThread().getThreadGroup());
/* 1433 */       this.namePrefix = namePrefix;
/*      */     }
/*      */     
/*      */     public Thread newThread(Runnable r)
/*      */     {
/* 1438 */       Thread thread = new Thread(this.group, r, this.namePrefix + this.threadNumber.getAndIncrement());
/* 1439 */       thread.setDaemon(true);
/* 1440 */       return thread;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\core\ContainerBase.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */