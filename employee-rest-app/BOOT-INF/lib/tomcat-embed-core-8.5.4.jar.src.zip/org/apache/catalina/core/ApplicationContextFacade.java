/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.Enumeration;
/*     */ import java.util.EventListener;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterRegistration;
/*     */ import javax.servlet.FilterRegistration.Dynamic;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.Servlet;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRegistration;
/*     */ import javax.servlet.ServletRegistration.Dynamic;
/*     */ import javax.servlet.SessionCookieConfig;
/*     */ import javax.servlet.SessionTrackingMode;
/*     */ import javax.servlet.descriptor.JspConfigDescriptor;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.security.SecurityUtil;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationContextFacade
/*     */   implements ServletContext
/*     */ {
/*     */   private final Map<String, Class<?>[]> classCache;
/*     */   private final Map<String, Method> objectCache;
/*     */   private final ApplicationContext context;
/*     */   
/*     */   public ApplicationContextFacade(ApplicationContext context)
/*     */   {
/*  85 */     this.context = context;
/*     */     
/*  87 */     this.classCache = new HashMap();
/*  88 */     this.objectCache = new ConcurrentHashMap();
/*  89 */     initClassCache();
/*     */   }
/*     */   
/*     */   private void initClassCache()
/*     */   {
/*  94 */     Class<?>[] clazz = { String.class };
/*  95 */     this.classCache.put("getContext", clazz);
/*  96 */     this.classCache.put("getMimeType", clazz);
/*  97 */     this.classCache.put("getResourcePaths", clazz);
/*  98 */     this.classCache.put("getResource", clazz);
/*  99 */     this.classCache.put("getResourceAsStream", clazz);
/* 100 */     this.classCache.put("getRequestDispatcher", clazz);
/* 101 */     this.classCache.put("getNamedDispatcher", clazz);
/* 102 */     this.classCache.put("getServlet", clazz);
/* 103 */     this.classCache.put("setInitParameter", new Class[] { String.class, String.class });
/* 104 */     this.classCache.put("createServlet", new Class[] { Class.class });
/* 105 */     this.classCache.put("addServlet", new Class[] { String.class, String.class });
/* 106 */     this.classCache.put("createFilter", new Class[] { Class.class });
/* 107 */     this.classCache.put("addFilter", new Class[] { String.class, String.class });
/* 108 */     this.classCache.put("createListener", new Class[] { Class.class });
/* 109 */     this.classCache.put("addListener", clazz);
/* 110 */     this.classCache.put("getFilterRegistration", clazz);
/* 111 */     this.classCache.put("getServletRegistration", clazz);
/* 112 */     this.classCache.put("getInitParameter", clazz);
/* 113 */     this.classCache.put("setAttribute", new Class[] { String.class, Object.class });
/* 114 */     this.classCache.put("removeAttribute", clazz);
/* 115 */     this.classCache.put("getRealPath", clazz);
/* 116 */     this.classCache.put("getAttribute", clazz);
/* 117 */     this.classCache.put("log", clazz);
/* 118 */     this.classCache.put("setSessionTrackingModes", new Class[] { Set.class });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletContext getContext(String uripath)
/*     */   {
/* 136 */     ServletContext theContext = null;
/* 137 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 138 */       theContext = (ServletContext)doPrivileged("getContext", new Object[] { uripath });
/*     */     }
/*     */     else {
/* 141 */       theContext = this.context.getContext(uripath);
/*     */     }
/* 143 */     if ((theContext != null) && ((theContext instanceof ApplicationContext)))
/*     */     {
/* 145 */       theContext = ((ApplicationContext)theContext).getFacade();
/*     */     }
/* 147 */     return theContext;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getMajorVersion()
/*     */   {
/* 153 */     return this.context.getMajorVersion();
/*     */   }
/*     */   
/*     */ 
/*     */   public int getMinorVersion()
/*     */   {
/* 159 */     return this.context.getMinorVersion();
/*     */   }
/*     */   
/*     */ 
/*     */   public String getMimeType(String file)
/*     */   {
/* 165 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 166 */       return (String)doPrivileged("getMimeType", new Object[] { file });
/*     */     }
/* 168 */     return this.context.getMimeType(file);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Set<String> getResourcePaths(String path)
/*     */   {
/* 175 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 176 */       return (Set)doPrivileged("getResourcePaths", new Object[] { path });
/*     */     }
/*     */     
/* 179 */     return this.context.getResourcePaths(path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public URL getResource(String path)
/*     */     throws MalformedURLException
/*     */   {
/* 187 */     if (Globals.IS_SECURITY_ENABLED) {
/*     */       try {
/* 189 */         return (URL)invokeMethod(this.context, "getResource", new Object[] { path });
/*     */       }
/*     */       catch (Throwable t) {
/* 192 */         ExceptionUtils.handleThrowable(t);
/* 193 */         if ((t instanceof MalformedURLException)) {
/* 194 */           throw ((MalformedURLException)t);
/*     */         }
/* 196 */         return null;
/*     */       }
/*     */     }
/* 199 */     return this.context.getResource(path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public InputStream getResourceAsStream(String path)
/*     */   {
/* 206 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 207 */       return (InputStream)doPrivileged("getResourceAsStream", new Object[] { path });
/*     */     }
/*     */     
/* 210 */     return this.context.getResourceAsStream(path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public RequestDispatcher getRequestDispatcher(String path)
/*     */   {
/* 217 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 218 */       return (RequestDispatcher)doPrivileged("getRequestDispatcher", new Object[] { path });
/*     */     }
/*     */     
/* 221 */     return this.context.getRequestDispatcher(path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public RequestDispatcher getNamedDispatcher(String name)
/*     */   {
/* 228 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 229 */       return (RequestDispatcher)doPrivileged("getNamedDispatcher", new Object[] { name });
/*     */     }
/*     */     
/* 232 */     return this.context.getNamedDispatcher(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public Servlet getServlet(String name)
/*     */     throws ServletException
/*     */   {
/* 244 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 246 */         return (Servlet)invokeMethod(this.context, "getServlet", new Object[] { name });
/*     */       }
/*     */       catch (Throwable t) {
/* 249 */         ExceptionUtils.handleThrowable(t);
/* 250 */         if ((t instanceof ServletException)) {
/* 251 */           throw ((ServletException)t);
/*     */         }
/* 253 */         return null;
/*     */       }
/*     */     }
/* 256 */     return this.context.getServlet(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public Enumeration<Servlet> getServlets()
/*     */   {
/* 268 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 269 */       return (Enumeration)doPrivileged("getServlets", null);
/*     */     }
/* 271 */     return this.context.getServlets();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public Enumeration<String> getServletNames()
/*     */   {
/* 283 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 284 */       return (Enumeration)doPrivileged("getServletNames", null);
/*     */     }
/* 286 */     return this.context.getServletNames();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void log(String msg)
/*     */   {
/* 293 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 294 */       doPrivileged("log", new Object[] { msg });
/*     */     } else {
/* 296 */       this.context.log(msg);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void log(Exception exception, String msg)
/*     */   {
/* 308 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 309 */       doPrivileged("log", new Class[] { Exception.class, String.class }, new Object[] { exception, msg });
/*     */     }
/*     */     else {
/* 312 */       this.context.log(exception, msg);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void log(String message, Throwable throwable)
/*     */   {
/* 319 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 320 */       doPrivileged("log", new Class[] { String.class, Throwable.class }, new Object[] { message, throwable });
/*     */     }
/*     */     else {
/* 323 */       this.context.log(message, throwable);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String getRealPath(String path)
/*     */   {
/* 330 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 331 */       return (String)doPrivileged("getRealPath", new Object[] { path });
/*     */     }
/* 333 */     return this.context.getRealPath(path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getServerInfo()
/*     */   {
/* 340 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 341 */       return (String)doPrivileged("getServerInfo", null);
/*     */     }
/* 343 */     return this.context.getServerInfo();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getInitParameter(String name)
/*     */   {
/* 350 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 351 */       return (String)doPrivileged("getInitParameter", new Object[] { name });
/*     */     }
/*     */     
/* 354 */     return this.context.getInitParameter(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Enumeration<String> getInitParameterNames()
/*     */   {
/* 362 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 363 */       return (Enumeration)doPrivileged("getInitParameterNames", null);
/*     */     }
/*     */     
/* 366 */     return this.context.getInitParameterNames();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getAttribute(String name)
/*     */   {
/* 373 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 374 */       return doPrivileged("getAttribute", new Object[] { name });
/*     */     }
/* 376 */     return this.context.getAttribute(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Enumeration<String> getAttributeNames()
/*     */   {
/* 384 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 385 */       return (Enumeration)doPrivileged("getAttributeNames", null);
/*     */     }
/*     */     
/* 388 */     return this.context.getAttributeNames();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setAttribute(String name, Object object)
/*     */   {
/* 395 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 396 */       doPrivileged("setAttribute", new Object[] { name, object });
/*     */     } else {
/* 398 */       this.context.setAttribute(name, object);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void removeAttribute(String name)
/*     */   {
/* 405 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 406 */       doPrivileged("removeAttribute", new Object[] { name });
/*     */     } else {
/* 408 */       this.context.removeAttribute(name);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String getServletContextName()
/*     */   {
/* 415 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 416 */       return (String)doPrivileged("getServletContextName", null);
/*     */     }
/* 418 */     return this.context.getServletContextName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getContextPath()
/*     */   {
/* 425 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 426 */       return (String)doPrivileged("getContextPath", null);
/*     */     }
/* 428 */     return this.context.getContextPath();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilterRegistration.Dynamic addFilter(String filterName, String className)
/*     */   {
/* 436 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 437 */       return (FilterRegistration.Dynamic)doPrivileged("addFilter", new Object[] { filterName, className });
/*     */     }
/*     */     
/* 440 */     return this.context.addFilter(filterName, className);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilterRegistration.Dynamic addFilter(String filterName, Filter filter)
/*     */   {
/* 448 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 449 */       return (FilterRegistration.Dynamic)doPrivileged("addFilter", new Class[] { String.class, Filter.class }, new Object[] { filterName, filter });
/*     */     }
/*     */     
/*     */ 
/* 453 */     return this.context.addFilter(filterName, filter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilterRegistration.Dynamic addFilter(String filterName, Class<? extends Filter> filterClass)
/*     */   {
/* 461 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 462 */       return (FilterRegistration.Dynamic)doPrivileged("addFilter", new Class[] { String.class, Class.class }, new Object[] { filterName, filterClass });
/*     */     }
/*     */     
/*     */ 
/* 466 */     return this.context.addFilter(filterName, filterClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public <T extends Filter> T createFilter(Class<T> c)
/*     */     throws ServletException
/*     */   {
/* 474 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 476 */         return (Filter)invokeMethod(this.context, "createFilter", new Object[] { c });
/*     */       }
/*     */       catch (Throwable t) {
/* 479 */         ExceptionUtils.handleThrowable(t);
/* 480 */         if ((t instanceof ServletException)) {
/* 481 */           throw ((ServletException)t);
/*     */         }
/* 483 */         return null;
/*     */       }
/*     */     }
/* 486 */     return this.context.createFilter(c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public FilterRegistration getFilterRegistration(String filterName)
/*     */   {
/* 493 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 494 */       return (FilterRegistration)doPrivileged("getFilterRegistration", new Object[] { filterName });
/*     */     }
/*     */     
/* 497 */     return this.context.getFilterRegistration(filterName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletRegistration.Dynamic addServlet(String servletName, String className)
/*     */   {
/* 505 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 506 */       return (ServletRegistration.Dynamic)doPrivileged("addServlet", new Object[] { servletName, className });
/*     */     }
/*     */     
/* 509 */     return this.context.addServlet(servletName, className);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletRegistration.Dynamic addServlet(String servletName, Servlet servlet)
/*     */   {
/* 517 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 518 */       return (ServletRegistration.Dynamic)doPrivileged("addServlet", new Class[] { String.class, Servlet.class }, new Object[] { servletName, servlet });
/*     */     }
/*     */     
/*     */ 
/* 522 */     return this.context.addServlet(servletName, servlet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletRegistration.Dynamic addServlet(String servletName, Class<? extends Servlet> servletClass)
/*     */   {
/* 530 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 531 */       return (ServletRegistration.Dynamic)doPrivileged("addServlet", new Class[] { String.class, Class.class }, new Object[] { servletName, servletClass });
/*     */     }
/*     */     
/*     */ 
/* 535 */     return this.context.addServlet(servletName, servletClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends Servlet> T createServlet(Class<T> c)
/*     */     throws ServletException
/*     */   {
/* 544 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 546 */         return (Servlet)invokeMethod(this.context, "createServlet", new Object[] { c });
/*     */       }
/*     */       catch (Throwable t) {
/* 549 */         ExceptionUtils.handleThrowable(t);
/* 550 */         if ((t instanceof ServletException)) {
/* 551 */           throw ((ServletException)t);
/*     */         }
/* 553 */         return null;
/*     */       }
/*     */     }
/* 556 */     return this.context.createServlet(c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ServletRegistration getServletRegistration(String servletName)
/*     */   {
/* 563 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 564 */       return (ServletRegistration)doPrivileged("getServletRegistration", new Object[] { servletName });
/*     */     }
/*     */     
/* 567 */     return this.context.getServletRegistration(servletName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<SessionTrackingMode> getDefaultSessionTrackingModes()
/*     */   {
/* 575 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 576 */       return (Set)doPrivileged("getDefaultSessionTrackingModes", null);
/*     */     }
/*     */     
/* 579 */     return this.context.getDefaultSessionTrackingModes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Set<SessionTrackingMode> getEffectiveSessionTrackingModes()
/*     */   {
/* 586 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 587 */       return (Set)doPrivileged("getEffectiveSessionTrackingModes", null);
/*     */     }
/*     */     
/* 590 */     return this.context.getEffectiveSessionTrackingModes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public SessionCookieConfig getSessionCookieConfig()
/*     */   {
/* 597 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 598 */       return (SessionCookieConfig)doPrivileged("getSessionCookieConfig", null);
/*     */     }
/*     */     
/* 601 */     return this.context.getSessionCookieConfig();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSessionTrackingModes(Set<SessionTrackingMode> sessionTrackingModes)
/*     */   {
/* 609 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 610 */       doPrivileged("setSessionTrackingModes", new Object[] { sessionTrackingModes });
/*     */     }
/*     */     else {
/* 613 */       this.context.setSessionTrackingModes(sessionTrackingModes);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean setInitParameter(String name, String value)
/*     */   {
/* 620 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 621 */       return ((Boolean)doPrivileged("setInitParameter", new Object[] { name, value })).booleanValue();
/*     */     }
/*     */     
/* 624 */     return this.context.setInitParameter(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addListener(Class<? extends EventListener> listenerClass)
/*     */   {
/* 631 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 632 */       doPrivileged("addListener", new Class[] { Class.class }, new Object[] { listenerClass });
/*     */     }
/*     */     else
/*     */     {
/* 636 */       this.context.addListener(listenerClass);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void addListener(String className)
/*     */   {
/* 643 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 644 */       doPrivileged("addListener", new Object[] { className });
/*     */     }
/*     */     else {
/* 647 */       this.context.addListener(className);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends EventListener> void addListener(T t)
/*     */   {
/* 654 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 655 */       doPrivileged("addListener", new Class[] { EventListener.class }, new Object[] { t });
/*     */     }
/*     */     else
/*     */     {
/* 659 */       this.context.addListener(t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public <T extends EventListener> T createListener(Class<T> c)
/*     */     throws ServletException
/*     */   {
/* 668 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 670 */         return (EventListener)invokeMethod(this.context, "createListener", new Object[] { c });
/*     */       }
/*     */       catch (Throwable t) {
/* 673 */         ExceptionUtils.handleThrowable(t);
/* 674 */         if ((t instanceof ServletException)) {
/* 675 */           throw ((ServletException)t);
/*     */         }
/* 677 */         return null;
/*     */       }
/*     */     }
/* 680 */     return this.context.createListener(c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void declareRoles(String... roleNames)
/*     */   {
/* 687 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 688 */       doPrivileged("declareRoles", new Object[] { roleNames });
/*     */     } else {
/* 690 */       this.context.declareRoles(roleNames);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public ClassLoader getClassLoader()
/*     */   {
/* 697 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 698 */       return (ClassLoader)doPrivileged("getClassLoader", null);
/*     */     }
/* 700 */     return this.context.getClassLoader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getEffectiveMajorVersion()
/*     */   {
/* 707 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 708 */       return ((Integer)doPrivileged("getEffectiveMajorVersion", null)).intValue();
/*     */     }
/*     */     
/* 711 */     return this.context.getEffectiveMajorVersion();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getEffectiveMinorVersion()
/*     */   {
/* 718 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 719 */       return ((Integer)doPrivileged("getEffectiveMinorVersion", null)).intValue();
/*     */     }
/*     */     
/* 722 */     return this.context.getEffectiveMinorVersion();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, ? extends FilterRegistration> getFilterRegistrations()
/*     */   {
/* 730 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 731 */       return (Map)doPrivileged("getFilterRegistrations", null);
/*     */     }
/*     */     
/* 734 */     return this.context.getFilterRegistrations();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JspConfigDescriptor getJspConfigDescriptor()
/*     */   {
/* 741 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 742 */       return (JspConfigDescriptor)doPrivileged("getJspConfigDescriptor", null);
/*     */     }
/*     */     
/* 745 */     return this.context.getJspConfigDescriptor();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, ? extends ServletRegistration> getServletRegistrations()
/*     */   {
/* 753 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 754 */       return (Map)doPrivileged("getServletRegistrations", null);
/*     */     }
/*     */     
/* 757 */     return this.context.getServletRegistrations();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getVirtualServerName()
/*     */   {
/* 764 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 765 */       return (String)doPrivileged("getVirtualServerName", null);
/*     */     }
/* 767 */     return this.context.getVirtualServerName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object doPrivileged(String methodName, Object[] params)
/*     */   {
/*     */     try
/*     */     {
/* 780 */       return invokeMethod(this.context, methodName, params);
/*     */     } catch (Throwable t) {
/* 782 */       ExceptionUtils.handleThrowable(t);
/* 783 */       throw new RuntimeException(t.getMessage(), t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object invokeMethod(ApplicationContext appContext, String methodName, Object[] params)
/*     */     throws Throwable
/*     */   {
/*     */     try
/*     */     {
/* 802 */       Method method = (Method)this.objectCache.get(methodName);
/* 803 */       if (method == null) {
/* 804 */         method = appContext.getClass().getMethod(methodName, (Class[])this.classCache.get(methodName));
/*     */         
/* 806 */         this.objectCache.put(methodName, method);
/*     */       }
/*     */       
/* 809 */       return executeMethod(method, appContext, params);
/*     */     } catch (Exception ex) { Object localObject1;
/* 811 */       handleException(ex);
/* 812 */       return null;
/*     */     } finally {
/* 814 */       params = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object doPrivileged(String methodName, Class<?>[] clazz, Object[] params)
/*     */   {
/*     */     try
/*     */     {
/* 830 */       Method method = this.context.getClass().getMethod(methodName, clazz);
/* 831 */       return executeMethod(method, this.context, params);
/*     */     } catch (Exception ex) {
/*     */       try {
/* 834 */         handleException(ex);
/*     */       } catch (Throwable t) {
/* 836 */         ExceptionUtils.handleThrowable(t);
/* 837 */         throw new RuntimeException(t.getMessage());
/*     */       }
/* 839 */       return null;
/*     */     } finally {
/* 841 */       params = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object executeMethod(Method method, ApplicationContext context, Object[] params)
/*     */     throws PrivilegedActionException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 860 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 861 */       return AccessController.doPrivileged(new PrivilegedExecuteMethod(method, context, params));
/*     */     }
/*     */     
/* 864 */     return method.invoke(context, params);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void handleException(Exception ex)
/*     */     throws Throwable
/*     */   {
/* 879 */     if ((ex instanceof PrivilegedActionException)) {
/* 880 */       ex = ((PrivilegedActionException)ex).getException();
/*     */     }
/*     */     Throwable realException;
/* 883 */     if ((ex instanceof InvocationTargetException)) {
/* 884 */       Throwable realException = ex.getCause();
/* 885 */       if (realException == null) {
/* 886 */         realException = ex;
/*     */       }
/*     */     } else {
/* 889 */       realException = ex;
/*     */     }
/*     */     
/* 892 */     throw realException;
/*     */   }
/*     */   
/*     */   private static class PrivilegedExecuteMethod implements PrivilegedExceptionAction<Object>
/*     */   {
/*     */     private final Method method;
/*     */     private final ApplicationContext context;
/*     */     private final Object[] params;
/*     */     
/*     */     public PrivilegedExecuteMethod(Method method, ApplicationContext context, Object[] params)
/*     */     {
/* 903 */       this.method = method;
/* 904 */       this.context = context;
/* 905 */       this.params = params;
/*     */     }
/*     */     
/*     */     public Object run() throws Exception
/*     */     {
/* 910 */       return this.method.invoke(this.context, this.params);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\core\ApplicationContextFacade.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */