/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.security.AccessController;
/*     */ import java.security.Principal;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.Servlet;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.security.SecurityUtil;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.descriptor.web.FilterDef;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ApplicationFilterChain
/*     */   implements FilterChain
/*     */ {
/*     */   private static final ThreadLocal<ServletRequest> lastServicedRequest;
/*     */   private static final ThreadLocal<ServletResponse> lastServicedResponse;
/*     */   public static final int INCREMENT = 10;
/*     */   
/*     */   static
/*     */   {
/*  53 */     if (ApplicationDispatcher.WRAP_SAME_OBJECT) {
/*  54 */       lastServicedRequest = new ThreadLocal();
/*  55 */       lastServicedResponse = new ThreadLocal();
/*     */     } else {
/*  57 */       lastServicedRequest = null;
/*  58 */       lastServicedResponse = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  73 */   private ApplicationFilterConfig[] filters = new ApplicationFilterConfig[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */   private int pos = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  86 */   private int n = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  92 */   private Servlet servlet = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  98 */   private boolean servletSupportsAsync = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 103 */   private static final StringManager sm = StringManager.getManager("org.apache.catalina.core");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 111 */   private static final Class<?>[] classType = { ServletRequest.class, ServletResponse.class, FilterChain.class };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 118 */   private static final Class<?>[] classTypeUsedInService = { ServletRequest.class, ServletResponse.class };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response)
/*     */     throws IOException, ServletException
/*     */   {
/* 139 */     if (Globals.IS_SECURITY_ENABLED) {
/* 140 */       final ServletRequest req = request;
/* 141 */       final ServletResponse res = response;
/*     */       try {
/* 143 */         AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */         {
/*     */           public Void run()
/*     */             throws ServletException, IOException
/*     */           {
/* 148 */             ApplicationFilterChain.this.internalDoFilter(req, res);
/* 149 */             return null;
/*     */           }
/*     */         });
/*     */       }
/*     */       catch (PrivilegedActionException pe) {
/* 154 */         Exception e = pe.getException();
/* 155 */         if ((e instanceof ServletException))
/* 156 */           throw ((ServletException)e);
/* 157 */         if ((e instanceof IOException))
/* 158 */           throw ((IOException)e);
/* 159 */         if ((e instanceof RuntimeException)) {
/* 160 */           throw ((RuntimeException)e);
/*     */         }
/* 162 */         throw new ServletException(e.getMessage(), e);
/*     */       }
/*     */     } else {
/* 165 */       internalDoFilter(request, response);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void internalDoFilter(ServletRequest request, ServletResponse response)
/*     */     throws IOException, ServletException
/*     */   {
/* 174 */     if (this.pos < this.n) {
/* 175 */       ApplicationFilterConfig filterConfig = this.filters[(this.pos++)];
/*     */       try {
/* 177 */         Filter filter = filterConfig.getFilter();
/*     */         
/* 179 */         if ((request.isAsyncSupported()) && ("false".equalsIgnoreCase(filterConfig.getFilterDef().getAsyncSupported())))
/*     */         {
/* 181 */           request.setAttribute("org.apache.catalina.ASYNC_SUPPORTED", Boolean.FALSE);
/*     */         }
/* 183 */         if (Globals.IS_SECURITY_ENABLED) {
/* 184 */           ServletRequest req = request;
/* 185 */           ServletResponse res = response;
/* 186 */           Principal principal = ((HttpServletRequest)req).getUserPrincipal();
/*     */           
/*     */ 
/* 189 */           Object[] args = { req, res, this };
/* 190 */           SecurityUtil.doAsPrivilege("doFilter", filter, classType, args, principal);
/*     */         } else {
/* 192 */           filter.doFilter(request, response, this);
/*     */         }
/*     */       } catch (IOException|ServletException|RuntimeException e) {
/* 195 */         throw e;
/*     */       } catch (Throwable e) {
/* 197 */         e = ExceptionUtils.unwrapInvocationTargetException(e);
/* 198 */         ExceptionUtils.handleThrowable(e);
/* 199 */         throw new ServletException(sm.getString("filterChain.filter"), e);
/*     */       }
/* 201 */       return;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 206 */       if (ApplicationDispatcher.WRAP_SAME_OBJECT) {
/* 207 */         lastServicedRequest.set(request);
/* 208 */         lastServicedResponse.set(response);
/*     */       }
/*     */       
/* 211 */       if ((request.isAsyncSupported()) && (!this.servletSupportsAsync)) {
/* 212 */         request.setAttribute("org.apache.catalina.ASYNC_SUPPORTED", Boolean.FALSE);
/*     */       }
/*     */       
/*     */ 
/* 216 */       if (((request instanceof HttpServletRequest)) && ((response instanceof HttpServletResponse)) && (Globals.IS_SECURITY_ENABLED))
/*     */       {
/*     */ 
/* 219 */         ServletRequest req = request;
/* 220 */         ServletResponse res = response;
/* 221 */         Principal principal = ((HttpServletRequest)req).getUserPrincipal();
/*     */         
/* 223 */         Object[] args = { req, res };
/* 224 */         SecurityUtil.doAsPrivilege("service", this.servlet, classTypeUsedInService, args, principal);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 230 */         this.servlet.service(request, response);
/*     */       }
/*     */     } catch (IOException|ServletException|RuntimeException e) {
/* 233 */       throw e;
/*     */     } catch (Throwable e) {
/* 235 */       e = ExceptionUtils.unwrapInvocationTargetException(e);
/* 236 */       ExceptionUtils.handleThrowable(e);
/* 237 */       throw new ServletException(sm.getString("filterChain.servlet"), e);
/*     */     } finally {
/* 239 */       if (ApplicationDispatcher.WRAP_SAME_OBJECT) {
/* 240 */         lastServicedRequest.set(null);
/* 241 */         lastServicedResponse.set(null);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ServletRequest getLastServicedRequest()
/*     */   {
/* 254 */     return (ServletRequest)lastServicedRequest.get();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ServletResponse getLastServicedResponse()
/*     */   {
/* 265 */     return (ServletResponse)lastServicedResponse.get();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void addFilter(ApplicationFilterConfig filterConfig)
/*     */   {
/* 279 */     for (ApplicationFilterConfig filter : this.filters) {
/* 280 */       if (filter == filterConfig)
/* 281 */         return;
/*     */     }
/* 283 */     if (this.n == this.filters.length) {
/* 284 */       ApplicationFilterConfig[] newFilters = new ApplicationFilterConfig[this.n + 10];
/*     */       
/* 286 */       System.arraycopy(this.filters, 0, newFilters, 0, this.n);
/* 287 */       this.filters = newFilters;
/*     */     }
/* 289 */     this.filters[(this.n++)] = filterConfig;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void release()
/*     */   {
/* 298 */     for (int i = 0; i < this.n; i++) {
/* 299 */       this.filters[i] = null;
/*     */     }
/* 301 */     this.n = 0;
/* 302 */     this.pos = 0;
/* 303 */     this.servlet = null;
/* 304 */     this.servletSupportsAsync = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void reuse()
/*     */   {
/* 312 */     this.pos = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setServlet(Servlet servlet)
/*     */   {
/* 322 */     this.servlet = servlet;
/*     */   }
/*     */   
/*     */   void setServletSupportsAsync(boolean servletSupportsAsync)
/*     */   {
/* 327 */     this.servletSupportsAsync = servletSupportsAsync;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\core\ApplicationFilterChain.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */