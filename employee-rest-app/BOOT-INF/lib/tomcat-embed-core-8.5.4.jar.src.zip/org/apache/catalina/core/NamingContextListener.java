/*      */ package org.apache.catalina.core;
/*      */ 
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.StringTokenizer;
/*      */ import javax.management.MalformedObjectNameException;
/*      */ import javax.management.ObjectName;
/*      */ import javax.naming.NameAlreadyBoundException;
/*      */ import javax.naming.NamingException;
/*      */ import javax.naming.Reference;
/*      */ import javax.naming.StringRefAddr;
/*      */ import javax.servlet.ServletContext;
/*      */ import org.apache.catalina.ContainerEvent;
/*      */ import org.apache.catalina.ContainerListener;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.LifecycleEvent;
/*      */ import org.apache.catalina.LifecycleListener;
/*      */ import org.apache.catalina.Loader;
/*      */ import org.apache.catalina.Server;
/*      */ import org.apache.catalina.deploy.NamingResourcesImpl;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.naming.ContextAccessController;
/*      */ import org.apache.naming.ContextBindings;
/*      */ import org.apache.naming.EjbRef;
/*      */ import org.apache.naming.HandlerRef;
/*      */ import org.apache.naming.NamingContext;
/*      */ import org.apache.naming.ResourceEnvRef;
/*      */ import org.apache.naming.ResourceLinkRef;
/*      */ import org.apache.naming.ResourceRef;
/*      */ import org.apache.naming.ServiceRef;
/*      */ import org.apache.naming.TransactionRef;
/*      */ import org.apache.naming.factory.ResourceLinkFactory;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextEjb;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextEnvironment;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextHandler;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextLocalEjb;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextResource;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextResourceEnvRef;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextResourceLink;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextService;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextTransaction;
/*      */ import org.apache.tomcat.util.modeler.Registry;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class NamingContextListener
/*      */   implements LifecycleListener, ContainerListener, PropertyChangeListener
/*      */ {
/*   83 */   private static final Log log = LogFactory.getLog(NamingContextListener.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   91 */   protected String name = "/";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   97 */   protected Object container = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  102 */   private Object token = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  107 */   protected boolean initialized = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  113 */   protected NamingResourcesImpl namingResources = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  119 */   protected NamingContext namingContext = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  125 */   protected javax.naming.Context compCtx = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  131 */   protected javax.naming.Context envCtx = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  137 */   protected HashMap<String, ObjectName> objectNames = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  144 */   private boolean exceptionOnFailedWrite = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  150 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.core");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getExceptionOnFailedWrite()
/*      */   {
/*  161 */     return this.exceptionOnFailedWrite;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setExceptionOnFailedWrite(boolean exceptionOnFailedWrite)
/*      */   {
/*  172 */     this.exceptionOnFailedWrite = exceptionOnFailedWrite;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getName()
/*      */   {
/*  180 */     return this.name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setName(String name)
/*      */   {
/*  190 */     this.name = name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public javax.naming.Context getEnvContext()
/*      */   {
/*  198 */     return this.envCtx;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void lifecycleEvent(LifecycleEvent event)
/*      */   {
/*  212 */     this.container = event.getLifecycle();
/*      */     
/*  214 */     if ((this.container instanceof org.apache.catalina.Context)) {
/*  215 */       this.namingResources = ((org.apache.catalina.Context)this.container).getNamingResources();
/*  216 */       this.token = ((org.apache.catalina.Context)this.container).getNamingToken();
/*  217 */     } else if ((this.container instanceof Server)) {
/*  218 */       this.namingResources = ((Server)this.container).getGlobalNamingResources();
/*  219 */       this.token = ((Server)this.container).getNamingToken();
/*      */     } else {
/*  221 */       return;
/*      */     }
/*      */     
/*  224 */     if ("configure_start".equals(event.getType()))
/*      */     {
/*  226 */       if (this.initialized) {
/*  227 */         return;
/*      */       }
/*      */       try {
/*  230 */         Hashtable<String, Object> contextEnv = new Hashtable();
/*  231 */         this.namingContext = new NamingContext(contextEnv, getName());
/*  232 */         ContextAccessController.setSecurityToken(getName(), this.token);
/*  233 */         ContextAccessController.setSecurityToken(this.container, this.token);
/*  234 */         ContextBindings.bindContext(this.container, this.namingContext, this.token);
/*  235 */         if (log.isDebugEnabled()) {
/*  236 */           log.debug("Bound " + this.container);
/*      */         }
/*      */         
/*      */ 
/*  240 */         this.namingContext.setExceptionOnFailedWrite(getExceptionOnFailedWrite());
/*      */         
/*      */ 
/*      */ 
/*  244 */         ContextAccessController.setWritable(getName(), this.token);
/*      */         try
/*      */         {
/*  247 */           createNamingContext();
/*      */         } catch (NamingException e) {
/*  249 */           log.error(sm.getString("naming.namingContextCreationFailed", new Object[] { e }));
/*      */         }
/*      */         
/*      */ 
/*  253 */         this.namingResources.addPropertyChangeListener(this);
/*      */         
/*      */ 
/*  256 */         if ((this.container instanceof org.apache.catalina.Context))
/*      */         {
/*  258 */           ContextAccessController.setReadOnly(getName());
/*      */           try {
/*  260 */             ContextBindings.bindClassLoader(this.container, this.token, ((org.apache.catalina.Context)this.container).getLoader().getClassLoader());
/*      */           }
/*      */           catch (NamingException e) {
/*  263 */             log.error(sm.getString("naming.bindFailed", new Object[] { e }));
/*      */           }
/*      */         }
/*      */         
/*  267 */         if ((this.container instanceof Server)) {
/*  268 */           ResourceLinkFactory.setGlobalContext(this.namingContext);
/*      */           try
/*      */           {
/*  271 */             ContextBindings.bindClassLoader(this.container, this.token, getClass().getClassLoader());
/*      */           }
/*      */           catch (NamingException e) {
/*  274 */             log.error(sm.getString("naming.bindFailed", new Object[] { e }));
/*      */           }
/*  276 */           if ((this.container instanceof StandardServer)) {
/*  277 */             ((StandardServer)this.container).setGlobalNamingContext(this.namingContext);
/*      */           }
/*      */           
/*      */         }
/*      */       }
/*      */       finally
/*      */       {
/*  284 */         this.initialized = true;
/*      */       }
/*      */     }
/*  287 */     else if ("configure_stop".equals(event.getType()))
/*      */     {
/*  289 */       if (!this.initialized) {
/*  290 */         return;
/*      */       }
/*      */       try
/*      */       {
/*  294 */         ContextAccessController.setWritable(getName(), this.token);
/*  295 */         ContextBindings.unbindContext(this.container, this.token);
/*      */         
/*  297 */         if ((this.container instanceof org.apache.catalina.Context)) {
/*  298 */           ContextBindings.unbindClassLoader(this.container, this.token, ((org.apache.catalina.Context)this.container).getLoader().getClassLoader());
/*      */         }
/*      */         
/*      */ 
/*  302 */         if ((this.container instanceof Server)) {
/*  303 */           this.namingResources.removePropertyChangeListener(this);
/*  304 */           ContextBindings.unbindClassLoader(this.container, this.token, getClass().getClassLoader());
/*      */         }
/*      */         
/*      */ 
/*  308 */         ContextAccessController.unsetSecurityToken(getName(), this.token);
/*  309 */         ContextAccessController.unsetSecurityToken(this.container, this.token);
/*      */         
/*      */ 
/*  312 */         if (!this.objectNames.isEmpty()) {
/*  313 */           Collection<ObjectName> names = this.objectNames.values();
/*  314 */           registry = Registry.getRegistry(null, null);
/*  315 */           for (ObjectName objectName : names)
/*  316 */             registry.unregisterComponent(objectName);
/*      */         }
/*      */       } finally {
/*      */         Registry registry;
/*  320 */         this.objectNames.clear();
/*      */         
/*  322 */         this.namingContext = null;
/*  323 */         this.envCtx = null;
/*  324 */         this.compCtx = null;
/*  325 */         this.initialized = false;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void containerEvent(ContainerEvent event)
/*      */   {
/*  346 */     if (!this.initialized) {
/*  347 */       return;
/*      */     }
/*      */     
/*  350 */     ContextAccessController.setWritable(getName(), this.token);
/*      */     
/*  352 */     String type = event.getType();
/*      */     
/*  354 */     if (type.equals("addEjb"))
/*      */     {
/*  356 */       String ejbName = (String)event.getData();
/*  357 */       if (ejbName != null) {
/*  358 */         ContextEjb ejb = this.namingResources.findEjb(ejbName);
/*  359 */         addEjb(ejb);
/*      */       }
/*      */     }
/*  362 */     else if (type.equals("addEnvironment"))
/*      */     {
/*  364 */       String environmentName = (String)event.getData();
/*  365 */       if (environmentName != null) {
/*  366 */         ContextEnvironment env = this.namingResources.findEnvironment(environmentName);
/*      */         
/*  368 */         addEnvironment(env);
/*      */       }
/*      */     }
/*  371 */     else if (type.equals("addLocalEjb"))
/*      */     {
/*  373 */       String localEjbName = (String)event.getData();
/*  374 */       if (localEjbName != null) {
/*  375 */         ContextLocalEjb localEjb = this.namingResources.findLocalEjb(localEjbName);
/*      */         
/*  377 */         addLocalEjb(localEjb);
/*      */       }
/*      */     }
/*  380 */     else if (type.equals("addResource"))
/*      */     {
/*  382 */       String resourceName = (String)event.getData();
/*  383 */       if (resourceName != null) {
/*  384 */         ContextResource resource = this.namingResources.findResource(resourceName);
/*      */         
/*  386 */         addResource(resource);
/*      */       }
/*      */     }
/*  389 */     else if (type.equals("addResourceLink"))
/*      */     {
/*  391 */       String resourceLinkName = (String)event.getData();
/*  392 */       if (resourceLinkName != null) {
/*  393 */         ContextResourceLink resourceLink = this.namingResources.findResourceLink(resourceLinkName);
/*      */         
/*  395 */         addResourceLink(resourceLink);
/*      */       }
/*      */     }
/*  398 */     else if (type.equals("addResourceEnvRef"))
/*      */     {
/*  400 */       String resourceEnvRefName = (String)event.getData();
/*  401 */       if (resourceEnvRefName != null) {
/*  402 */         ContextResourceEnvRef resourceEnvRef = this.namingResources.findResourceEnvRef(resourceEnvRefName);
/*      */         
/*  404 */         addResourceEnvRef(resourceEnvRef);
/*      */       }
/*      */     }
/*  407 */     else if (type.equals("addService"))
/*      */     {
/*  409 */       String serviceName = (String)event.getData();
/*  410 */       if (serviceName != null) {
/*  411 */         ContextService service = this.namingResources.findService(serviceName);
/*      */         
/*  413 */         addService(service);
/*      */       }
/*      */     }
/*  416 */     else if (type.equals("removeEjb"))
/*      */     {
/*  418 */       String ejbName = (String)event.getData();
/*  419 */       if (ejbName != null) {
/*  420 */         removeEjb(ejbName);
/*      */       }
/*      */     }
/*  423 */     else if (type.equals("removeEnvironment"))
/*      */     {
/*  425 */       String environmentName = (String)event.getData();
/*  426 */       if (environmentName != null) {
/*  427 */         removeEnvironment(environmentName);
/*      */       }
/*      */     }
/*  430 */     else if (type.equals("removeLocalEjb"))
/*      */     {
/*  432 */       String localEjbName = (String)event.getData();
/*  433 */       if (localEjbName != null) {
/*  434 */         removeLocalEjb(localEjbName);
/*      */       }
/*      */     }
/*  437 */     else if (type.equals("removeResource"))
/*      */     {
/*  439 */       String resourceName = (String)event.getData();
/*  440 */       if (resourceName != null) {
/*  441 */         removeResource(resourceName);
/*      */       }
/*      */     }
/*  444 */     else if (type.equals("removeResourceLink"))
/*      */     {
/*  446 */       String resourceLinkName = (String)event.getData();
/*  447 */       if (resourceLinkName != null) {
/*  448 */         removeResourceLink(resourceLinkName);
/*      */       }
/*      */     }
/*  451 */     else if (type.equals("removeResourceEnvRef"))
/*      */     {
/*  453 */       String resourceEnvRefName = (String)event.getData();
/*  454 */       if (resourceEnvRefName != null) {
/*  455 */         removeResourceEnvRef(resourceEnvRefName);
/*      */       }
/*      */     }
/*  458 */     else if (type.equals("removeService"))
/*      */     {
/*  460 */       String serviceName = (String)event.getData();
/*  461 */       if (serviceName != null) {
/*  462 */         removeService(serviceName);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  468 */     ContextAccessController.setReadOnly(getName());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void propertyChange(PropertyChangeEvent event)
/*      */   {
/*  484 */     if (!this.initialized) {
/*  485 */       return;
/*      */     }
/*  487 */     Object source = event.getSource();
/*  488 */     if (source == this.namingResources)
/*      */     {
/*      */ 
/*  491 */       ContextAccessController.setWritable(getName(), this.token);
/*      */       
/*  493 */       processGlobalResourcesChange(event.getPropertyName(), event.getOldValue(), event.getNewValue());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  498 */       ContextAccessController.setReadOnly(getName());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void processGlobalResourcesChange(String name, Object oldValue, Object newValue)
/*      */   {
/*  520 */     if (name.equals("ejb")) {
/*  521 */       if (oldValue != null) {
/*  522 */         ContextEjb ejb = (ContextEjb)oldValue;
/*  523 */         if (ejb.getName() != null) {
/*  524 */           removeEjb(ejb.getName());
/*      */         }
/*      */       }
/*  527 */       if (newValue != null) {
/*  528 */         ContextEjb ejb = (ContextEjb)newValue;
/*  529 */         if (ejb.getName() != null) {
/*  530 */           addEjb(ejb);
/*      */         }
/*      */       }
/*  533 */     } else if (name.equals("environment")) {
/*  534 */       if (oldValue != null) {
/*  535 */         ContextEnvironment env = (ContextEnvironment)oldValue;
/*  536 */         if (env.getName() != null) {
/*  537 */           removeEnvironment(env.getName());
/*      */         }
/*      */       }
/*  540 */       if (newValue != null) {
/*  541 */         ContextEnvironment env = (ContextEnvironment)newValue;
/*  542 */         if (env.getName() != null) {
/*  543 */           addEnvironment(env);
/*      */         }
/*      */       }
/*  546 */     } else if (name.equals("localEjb")) {
/*  547 */       if (oldValue != null) {
/*  548 */         ContextLocalEjb ejb = (ContextLocalEjb)oldValue;
/*  549 */         if (ejb.getName() != null) {
/*  550 */           removeLocalEjb(ejb.getName());
/*      */         }
/*      */       }
/*  553 */       if (newValue != null) {
/*  554 */         ContextLocalEjb ejb = (ContextLocalEjb)newValue;
/*  555 */         if (ejb.getName() != null) {
/*  556 */           addLocalEjb(ejb);
/*      */         }
/*      */       }
/*  559 */     } else if (name.equals("resource")) {
/*  560 */       if (oldValue != null) {
/*  561 */         ContextResource resource = (ContextResource)oldValue;
/*  562 */         if (resource.getName() != null) {
/*  563 */           removeResource(resource.getName());
/*      */         }
/*      */       }
/*  566 */       if (newValue != null) {
/*  567 */         ContextResource resource = (ContextResource)newValue;
/*  568 */         if (resource.getName() != null) {
/*  569 */           addResource(resource);
/*      */         }
/*      */       }
/*  572 */     } else if (name.equals("resourceEnvRef")) {
/*  573 */       if (oldValue != null) {
/*  574 */         ContextResourceEnvRef resourceEnvRef = (ContextResourceEnvRef)oldValue;
/*      */         
/*  576 */         if (resourceEnvRef.getName() != null) {
/*  577 */           removeResourceEnvRef(resourceEnvRef.getName());
/*      */         }
/*      */       }
/*  580 */       if (newValue != null) {
/*  581 */         ContextResourceEnvRef resourceEnvRef = (ContextResourceEnvRef)newValue;
/*      */         
/*  583 */         if (resourceEnvRef.getName() != null) {
/*  584 */           addResourceEnvRef(resourceEnvRef);
/*      */         }
/*      */       }
/*  587 */     } else if (name.equals("resourceLink")) {
/*  588 */       if (oldValue != null) {
/*  589 */         ContextResourceLink rl = (ContextResourceLink)oldValue;
/*  590 */         if (rl.getName() != null) {
/*  591 */           removeResourceLink(rl.getName());
/*      */         }
/*      */       }
/*  594 */       if (newValue != null) {
/*  595 */         ContextResourceLink rl = (ContextResourceLink)newValue;
/*  596 */         if (rl.getName() != null) {
/*  597 */           addResourceLink(rl);
/*      */         }
/*      */       }
/*  600 */     } else if (name.equals("service")) {
/*  601 */       if (oldValue != null) {
/*  602 */         ContextService service = (ContextService)oldValue;
/*  603 */         if (service.getName() != null) {
/*  604 */           removeService(service.getName());
/*      */         }
/*      */       }
/*  607 */       if (newValue != null) {
/*  608 */         ContextService service = (ContextService)newValue;
/*  609 */         if (service.getName() != null) {
/*  610 */           addService(service);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void createNamingContext()
/*      */     throws NamingException
/*      */   {
/*  626 */     if ((this.container instanceof Server)) {
/*  627 */       this.compCtx = this.namingContext;
/*  628 */       this.envCtx = this.namingContext;
/*      */     } else {
/*  630 */       this.compCtx = this.namingContext.createSubcontext("comp");
/*  631 */       this.envCtx = this.compCtx.createSubcontext("env");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  636 */     if (log.isDebugEnabled()) {
/*  637 */       log.debug("Creating JNDI naming context");
/*      */     }
/*  639 */     if (this.namingResources == null) {
/*  640 */       this.namingResources = new NamingResourcesImpl();
/*  641 */       this.namingResources.setContainer(this.container);
/*      */     }
/*      */     
/*      */ 
/*  645 */     ContextResourceLink[] resourceLinks = this.namingResources.findResourceLinks();
/*      */     
/*  647 */     for (int i = 0; i < resourceLinks.length; i++) {
/*  648 */       addResourceLink(resourceLinks[i]);
/*      */     }
/*      */     
/*      */ 
/*  652 */     ContextResource[] resources = this.namingResources.findResources();
/*  653 */     for (i = 0; i < resources.length; i++) {
/*  654 */       addResource(resources[i]);
/*      */     }
/*      */     
/*      */ 
/*  658 */     ContextResourceEnvRef[] resourceEnvRefs = this.namingResources.findResourceEnvRefs();
/*  659 */     for (i = 0; i < resourceEnvRefs.length; i++) {
/*  660 */       addResourceEnvRef(resourceEnvRefs[i]);
/*      */     }
/*      */     
/*      */ 
/*  664 */     ContextEnvironment[] contextEnvironments = this.namingResources.findEnvironments();
/*      */     
/*  666 */     for (i = 0; i < contextEnvironments.length; i++) {
/*  667 */       addEnvironment(contextEnvironments[i]);
/*      */     }
/*      */     
/*      */ 
/*  671 */     ContextEjb[] ejbs = this.namingResources.findEjbs();
/*  672 */     for (i = 0; i < ejbs.length; i++) {
/*  673 */       addEjb(ejbs[i]);
/*      */     }
/*      */     
/*      */ 
/*  677 */     ContextService[] services = this.namingResources.findServices();
/*  678 */     for (i = 0; i < services.length; i++) {
/*  679 */       addService(services[i]);
/*      */     }
/*      */     
/*      */ 
/*  683 */     if ((this.container instanceof org.apache.catalina.Context)) {
/*      */       try {
/*  685 */         Reference ref = new TransactionRef();
/*  686 */         this.compCtx.bind("UserTransaction", ref);
/*  687 */         ContextTransaction transaction = this.namingResources.getTransaction();
/*  688 */         if (transaction != null) {
/*  689 */           Iterator<String> params = transaction.listProperties();
/*  690 */           while (params.hasNext()) {
/*  691 */             String paramName = (String)params.next();
/*  692 */             String paramValue = (String)transaction.getProperty(paramName);
/*  693 */             StringRefAddr refAddr = new StringRefAddr(paramName, paramValue);
/*  694 */             ref.add(refAddr);
/*      */           }
/*      */           
/*      */         }
/*      */       }
/*      */       catch (NameAlreadyBoundException localNameAlreadyBoundException) {}catch (NamingException e)
/*      */       {
/*  701 */         log.error(sm.getString("naming.bindFailed", new Object[] { e }));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  706 */     if ((this.container instanceof org.apache.catalina.Context)) {
/*      */       try {
/*  708 */         this.compCtx.bind("Resources", ((org.apache.catalina.Context)this.container).getResources());
/*      */       }
/*      */       catch (NamingException e) {
/*  711 */         log.error(sm.getString("naming.bindFailed", new Object[] { e }));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectName createObjectName(ContextResource resource)
/*      */     throws MalformedObjectNameException
/*      */   {
/*  729 */     String domain = null;
/*  730 */     if ((this.container instanceof StandardServer)) {
/*  731 */       domain = ((StandardServer)this.container).getDomain();
/*  732 */     } else if ((this.container instanceof ContainerBase)) {
/*  733 */       domain = ((ContainerBase)this.container).getDomain();
/*      */     }
/*  735 */     if (domain == null) {
/*  736 */       domain = "Catalina";
/*      */     }
/*      */     
/*  739 */     ObjectName name = null;
/*  740 */     String quotedResourceName = ObjectName.quote(resource.getName());
/*  741 */     if ((this.container instanceof Server)) {
/*  742 */       name = new ObjectName(domain + ":type=DataSource" + ",class=" + resource.getType() + ",name=" + quotedResourceName);
/*      */ 
/*      */     }
/*  745 */     else if ((this.container instanceof org.apache.catalina.Context)) {
/*  746 */       String contextName = ((org.apache.catalina.Context)this.container).getName();
/*  747 */       if (!contextName.startsWith("/"))
/*  748 */         contextName = "/" + contextName;
/*  749 */       Host host = (Host)((org.apache.catalina.Context)this.container).getParent();
/*  750 */       name = new ObjectName(domain + ":type=DataSource" + ",host=" + host.getName() + ",context=" + contextName + ",class=" + resource.getType() + ",name=" + quotedResourceName);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  757 */     return name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addEjb(ContextEjb ejb)
/*      */   {
/*  770 */     Reference ref = new EjbRef(ejb.getType(), ejb.getHome(), ejb.getRemote(), ejb.getLink());
/*      */     
/*      */ 
/*  773 */     Iterator<String> params = ejb.listProperties();
/*  774 */     while (params.hasNext()) {
/*  775 */       String paramName = (String)params.next();
/*  776 */       String paramValue = (String)ejb.getProperty(paramName);
/*  777 */       StringRefAddr refAddr = new StringRefAddr(paramName, paramValue);
/*  778 */       ref.add(refAddr);
/*      */     }
/*      */     try {
/*  781 */       createSubcontexts(this.envCtx, ejb.getName());
/*  782 */       this.envCtx.bind(ejb.getName(), ref);
/*      */     } catch (NamingException e) {
/*  784 */       log.error(sm.getString("naming.bindFailed", new Object[] { e }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addEnvironment(ContextEnvironment env)
/*      */   {
/*  797 */     Object value = null;
/*      */     
/*      */ 
/*  800 */     String type = env.getType();
/*      */     try {
/*  802 */       if (type.equals("java.lang.String")) {
/*  803 */         value = env.getValue();
/*  804 */       } else if (type.equals("java.lang.Byte")) {
/*  805 */         if (env.getValue() == null) {
/*  806 */           value = Byte.valueOf((byte)0);
/*      */         } else {
/*  808 */           value = Byte.decode(env.getValue());
/*      */         }
/*  810 */       } else if (type.equals("java.lang.Short")) {
/*  811 */         if (env.getValue() == null) {
/*  812 */           value = Short.valueOf((short)0);
/*      */         } else {
/*  814 */           value = Short.decode(env.getValue());
/*      */         }
/*  816 */       } else if (type.equals("java.lang.Integer")) {
/*  817 */         if (env.getValue() == null) {
/*  818 */           value = Integer.valueOf(0);
/*      */         } else {
/*  820 */           value = Integer.decode(env.getValue());
/*      */         }
/*  822 */       } else if (type.equals("java.lang.Long")) {
/*  823 */         if (env.getValue() == null) {
/*  824 */           value = Long.valueOf(0L);
/*      */         } else {
/*  826 */           value = Long.decode(env.getValue());
/*      */         }
/*  828 */       } else if (type.equals("java.lang.Boolean")) {
/*  829 */         value = Boolean.valueOf(env.getValue());
/*  830 */       } else if (type.equals("java.lang.Double")) {
/*  831 */         if (env.getValue() == null) {
/*  832 */           value = Double.valueOf(0.0D);
/*      */         } else {
/*  834 */           value = Double.valueOf(env.getValue());
/*      */         }
/*  836 */       } else if (type.equals("java.lang.Float")) {
/*  837 */         if (env.getValue() == null) {
/*  838 */           value = Float.valueOf(0.0F);
/*      */         } else {
/*  840 */           value = Float.valueOf(env.getValue());
/*      */         }
/*  842 */       } else if (type.equals("java.lang.Character")) {
/*  843 */         if (env.getValue() == null) {
/*  844 */           value = Character.valueOf('\000');
/*      */         }
/*  846 */         else if (env.getValue().length() == 1) {
/*  847 */           value = Character.valueOf(env.getValue().charAt(0));
/*      */         } else {
/*  849 */           throw new IllegalArgumentException();
/*      */         }
/*      */       }
/*      */       else {
/*  853 */         value = constructEnvEntry(env.getType(), env.getValue());
/*  854 */         if (value == null) {
/*  855 */           log.error(sm.getString("naming.invalidEnvEntryType", new Object[] { env.getName() }));
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (NumberFormatException e) {
/*  860 */       log.error(sm.getString("naming.invalidEnvEntryValue", new Object[] { env.getName() }));
/*      */     } catch (IllegalArgumentException e) {
/*  862 */       log.error(sm.getString("naming.invalidEnvEntryValue", new Object[] { env.getName() }));
/*      */     }
/*      */     
/*      */ 
/*  866 */     if (value != null) {
/*      */       try {
/*  868 */         if (log.isDebugEnabled())
/*  869 */           log.debug("  Adding environment entry " + env.getName());
/*  870 */         createSubcontexts(this.envCtx, env.getName());
/*  871 */         this.envCtx.bind(env.getName(), value);
/*      */       } catch (NamingException e) {
/*  873 */         log.error(sm.getString("naming.invalidEnvEntryValue", new Object[] { e }));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private Object constructEnvEntry(String type, String value)
/*      */   {
/*      */     try
/*      */     {
/*  882 */       Class<?> clazz = Class.forName(type);
/*  883 */       Constructor<?> c = null;
/*      */       try {
/*  885 */         c = clazz.getConstructor(new Class[] { String.class });
/*  886 */         return c.newInstance(new Object[] { value });
/*      */ 
/*      */       }
/*      */       catch (NoSuchMethodException localNoSuchMethodException)
/*      */       {
/*  891 */         if (value.length() != 1) {
/*  892 */           return null;
/*      */         }
/*      */         try
/*      */         {
/*  896 */           c = clazz.getConstructor(new Class[] { Character.TYPE });
/*  897 */           return c.newInstance(new Object[] { Character.valueOf(value.charAt(0)) });
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException1) {}
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  904 */       return null;
/*      */     }
/*      */     catch (Exception localException) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addLocalEjb(ContextLocalEjb localEjb) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addService(ContextService service)
/*      */   {
/*  924 */     if (service.getWsdlfile() != null) {
/*  925 */       URL wsdlURL = null;
/*      */       try
/*      */       {
/*  928 */         wsdlURL = new URL(service.getWsdlfile());
/*      */       }
/*      */       catch (MalformedURLException localMalformedURLException1) {}
/*      */       
/*  932 */       if (wsdlURL == null) {
/*      */         try {
/*  934 */           wsdlURL = ((org.apache.catalina.Context)this.container).getServletContext().getResource(service.getWsdlfile());
/*      */         }
/*      */         catch (MalformedURLException localMalformedURLException2) {}
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  941 */       if (wsdlURL == null) {
/*      */         try {
/*  943 */           wsdlURL = ((org.apache.catalina.Context)this.container).getServletContext().getResource("/" + service.getWsdlfile());
/*      */           
/*      */ 
/*  946 */           log.debug("  Changing service ref wsdl file for /" + service.getWsdlfile());
/*      */         }
/*      */         catch (MalformedURLException e) {
/*  949 */           log.error(sm.getString("naming.wsdlFailed", new Object[] { e }));
/*      */         }
/*      */       }
/*  952 */       if (wsdlURL == null) {
/*  953 */         service.setWsdlfile(null);
/*      */       } else {
/*  955 */         service.setWsdlfile(wsdlURL.toString());
/*      */       }
/*      */     }
/*  958 */     if (service.getJaxrpcmappingfile() != null) {
/*  959 */       URL jaxrpcURL = null;
/*      */       try
/*      */       {
/*  962 */         jaxrpcURL = new URL(service.getJaxrpcmappingfile());
/*      */       }
/*      */       catch (MalformedURLException localMalformedURLException3) {}
/*      */       
/*  966 */       if (jaxrpcURL == null) {
/*      */         try {
/*  968 */           jaxrpcURL = ((org.apache.catalina.Context)this.container).getServletContext().getResource(service.getJaxrpcmappingfile());
/*      */         }
/*      */         catch (MalformedURLException localMalformedURLException4) {}
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  975 */       if (jaxrpcURL == null) {
/*      */         try {
/*  977 */           jaxrpcURL = ((org.apache.catalina.Context)this.container).getServletContext().getResource("/" + service.getJaxrpcmappingfile());
/*      */           
/*      */ 
/*  980 */           log.debug("  Changing service ref jaxrpc file for /" + service.getJaxrpcmappingfile());
/*      */         }
/*      */         catch (MalformedURLException e) {
/*  983 */           log.error(sm.getString("naming.wsdlFailed", new Object[] { e }));
/*      */         }
/*      */       }
/*  986 */       if (jaxrpcURL == null) {
/*  987 */         service.setJaxrpcmappingfile(null);
/*      */       } else {
/*  989 */         service.setJaxrpcmappingfile(jaxrpcURL.toString());
/*      */       }
/*      */     }
/*      */     
/*  993 */     Reference ref = new ServiceRef(service.getName(), service.getType(), service.getServiceqname(), service.getWsdlfile(), service.getJaxrpcmappingfile());
/*      */     
/*      */ 
/*      */ 
/*  997 */     Iterator<String> portcomponent = service.getServiceendpoints();
/*  998 */     while (portcomponent.hasNext()) {
/*  999 */       String serviceendpoint = (String)portcomponent.next();
/* 1000 */       StringRefAddr refAddr = new StringRefAddr("serviceendpointinterface", serviceendpoint);
/* 1001 */       ref.add(refAddr);
/* 1002 */       String portlink = service.getPortlink(serviceendpoint);
/* 1003 */       refAddr = new StringRefAddr("portcomponentlink", portlink);
/* 1004 */       ref.add(refAddr);
/*      */     }
/*      */     
/* 1007 */     Iterator<String> handlers = service.getHandlers();
/* 1008 */     while (handlers.hasNext()) {
/* 1009 */       String handlername = (String)handlers.next();
/* 1010 */       ContextHandler handler = service.getHandler(handlername);
/* 1011 */       HandlerRef handlerRef = new HandlerRef(handlername, handler.getHandlerclass());
/* 1012 */       Iterator<String> localParts = handler.getLocalparts();
/* 1013 */       while (localParts.hasNext()) {
/* 1014 */         String localPart = (String)localParts.next();
/* 1015 */         String namespaceURI = handler.getNamespaceuri(localPart);
/* 1016 */         handlerRef.add(new StringRefAddr("handlerlocalpart", localPart));
/* 1017 */         handlerRef.add(new StringRefAddr("handlernamespace", namespaceURI));
/*      */       }
/* 1019 */       Iterator<String> params = handler.listProperties();
/* 1020 */       while (params.hasNext()) {
/* 1021 */         String paramName = (String)params.next();
/* 1022 */         String paramValue = (String)handler.getProperty(paramName);
/* 1023 */         handlerRef.add(new StringRefAddr("handlerparamname", paramName));
/* 1024 */         handlerRef.add(new StringRefAddr("handlerparamvalue", paramValue));
/*      */       }
/* 1026 */       for (int i = 0; i < handler.getSoapRolesSize(); i++) {
/* 1027 */         handlerRef.add(new StringRefAddr("handlersoaprole", handler.getSoapRole(i)));
/*      */       }
/* 1029 */       for (int i = 0; i < handler.getPortNamesSize(); i++) {
/* 1030 */         handlerRef.add(new StringRefAddr("handlerportname", handler.getPortName(i)));
/*      */       }
/* 1032 */       ((ServiceRef)ref).addHandler(handlerRef);
/*      */     }
/*      */     try
/*      */     {
/* 1036 */       if (log.isDebugEnabled()) {
/* 1037 */         log.debug("  Adding service ref " + service.getName() + "  " + ref);
/*      */       }
/*      */       
/* 1040 */       createSubcontexts(this.envCtx, service.getName());
/* 1041 */       this.envCtx.bind(service.getName(), ref);
/*      */     } catch (NamingException e) {
/* 1043 */       log.error(sm.getString("naming.bindFailed", new Object[] { e }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addResource(ContextResource resource)
/*      */   {
/* 1057 */     Reference ref = new ResourceRef(resource.getType(), resource.getDescription(), resource.getScope(), resource.getAuth(), resource.getSingleton());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1062 */     Iterator<String> params = resource.listProperties();
/* 1063 */     while (params.hasNext()) {
/* 1064 */       String paramName = (String)params.next();
/* 1065 */       String paramValue = (String)resource.getProperty(paramName);
/* 1066 */       StringRefAddr refAddr = new StringRefAddr(paramName, paramValue);
/* 1067 */       ref.add(refAddr);
/*      */     }
/*      */     try {
/* 1070 */       if (log.isDebugEnabled()) {
/* 1071 */         log.debug("  Adding resource ref " + resource.getName() + "  " + ref);
/*      */       }
/*      */       
/* 1074 */       createSubcontexts(this.envCtx, resource.getName());
/* 1075 */       this.envCtx.bind(resource.getName(), ref);
/*      */     } catch (NamingException e) {
/* 1077 */       log.error(sm.getString("naming.bindFailed", new Object[] { e }));
/*      */     }
/*      */     
/* 1080 */     if (("javax.sql.DataSource".equals(ref.getClassName())) && (resource.getSingleton())) {
/*      */       try
/*      */       {
/* 1083 */         ObjectName on = createObjectName(resource);
/* 1084 */         Object actualResource = this.envCtx.lookup(resource.getName());
/* 1085 */         Registry.getRegistry(null, null).registerComponent(actualResource, on, null);
/* 1086 */         this.objectNames.put(resource.getName(), on);
/*      */       } catch (Exception e) {
/* 1088 */         log.warn(sm.getString("naming.jmxRegistrationFailed", new Object[] { e }));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addResourceEnvRef(ContextResourceEnvRef resourceEnvRef)
/*      */   {
/* 1103 */     Reference ref = new ResourceEnvRef(resourceEnvRef.getType());
/*      */     
/* 1105 */     Iterator<String> params = resourceEnvRef.listProperties();
/* 1106 */     while (params.hasNext()) {
/* 1107 */       String paramName = (String)params.next();
/* 1108 */       String paramValue = (String)resourceEnvRef.getProperty(paramName);
/* 1109 */       StringRefAddr refAddr = new StringRefAddr(paramName, paramValue);
/* 1110 */       ref.add(refAddr);
/*      */     }
/*      */     try {
/* 1113 */       if (log.isDebugEnabled())
/* 1114 */         log.debug("  Adding resource env ref " + resourceEnvRef.getName());
/* 1115 */       createSubcontexts(this.envCtx, resourceEnvRef.getName());
/* 1116 */       this.envCtx.bind(resourceEnvRef.getName(), ref);
/*      */     } catch (NamingException e) {
/* 1118 */       log.error(sm.getString("naming.bindFailed", new Object[] { e }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addResourceLink(ContextResourceLink resourceLink)
/*      */   {
/* 1132 */     Reference ref = new ResourceLinkRef(resourceLink.getType(), resourceLink.getGlobal(), resourceLink.getFactory(), null);
/*      */     
/* 1134 */     Iterator<String> i = resourceLink.listProperties();
/* 1135 */     while (i.hasNext()) {
/* 1136 */       String key = (String)i.next();
/* 1137 */       Object val = resourceLink.getProperty(key);
/* 1138 */       if (val != null) {
/* 1139 */         StringRefAddr refAddr = new StringRefAddr(key, val.toString());
/* 1140 */         ref.add(refAddr);
/*      */       }
/*      */     }
/* 1143 */     javax.naming.Context ctx = "UserTransaction".equals(resourceLink.getName()) ? this.compCtx : this.envCtx;
/*      */     
/*      */     try
/*      */     {
/* 1147 */       if (log.isDebugEnabled())
/* 1148 */         log.debug("  Adding resource link " + resourceLink.getName());
/* 1149 */       createSubcontexts(this.envCtx, resourceLink.getName());
/* 1150 */       ctx.bind(resourceLink.getName(), ref);
/*      */     } catch (NamingException e) {
/* 1152 */       log.error(sm.getString("naming.bindFailed", new Object[] { e }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeEjb(String name)
/*      */   {
/*      */     try
/*      */     {
/* 1166 */       this.envCtx.unbind(name);
/*      */     } catch (NamingException e) {
/* 1168 */       log.error(sm.getString("naming.unbindFailed", new Object[] { e }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeEnvironment(String name)
/*      */   {
/*      */     try
/*      */     {
/* 1182 */       this.envCtx.unbind(name);
/*      */     } catch (NamingException e) {
/* 1184 */       log.error(sm.getString("naming.unbindFailed", new Object[] { e }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeLocalEjb(String name)
/*      */   {
/*      */     try
/*      */     {
/* 1198 */       this.envCtx.unbind(name);
/*      */     } catch (NamingException e) {
/* 1200 */       log.error(sm.getString("naming.unbindFailed", new Object[] { e }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeService(String name)
/*      */   {
/*      */     try
/*      */     {
/* 1214 */       this.envCtx.unbind(name);
/*      */     } catch (NamingException e) {
/* 1216 */       log.error(sm.getString("naming.unbindFailed", new Object[] { e }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeResource(String name)
/*      */   {
/*      */     try
/*      */     {
/* 1230 */       this.envCtx.unbind(name);
/*      */     } catch (NamingException e) {
/* 1232 */       log.error(sm.getString("naming.unbindFailed", new Object[] { e }));
/*      */     }
/*      */     
/* 1235 */     ObjectName on = (ObjectName)this.objectNames.get(name);
/* 1236 */     if (on != null) {
/* 1237 */       Registry.getRegistry(null, null).unregisterComponent(on);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeResourceEnvRef(String name)
/*      */   {
/*      */     try
/*      */     {
/* 1251 */       this.envCtx.unbind(name);
/*      */     } catch (NamingException e) {
/* 1253 */       log.error(sm.getString("naming.unbindFailed", new Object[] { e }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeResourceLink(String name)
/*      */   {
/*      */     try
/*      */     {
/* 1267 */       this.envCtx.unbind(name);
/*      */     } catch (NamingException e) {
/* 1269 */       log.error(sm.getString("naming.unbindFailed", new Object[] { e }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void createSubcontexts(javax.naming.Context ctx, String name)
/*      */     throws NamingException
/*      */   {
/* 1280 */     javax.naming.Context currentContext = ctx;
/* 1281 */     StringTokenizer tokenizer = new StringTokenizer(name, "/");
/* 1282 */     while (tokenizer.hasMoreTokens()) {
/* 1283 */       String token = tokenizer.nextToken();
/* 1284 */       if ((!token.equals("")) && (tokenizer.hasMoreTokens())) {
/*      */         try {
/* 1286 */           currentContext = currentContext.createSubcontext(token);
/*      */         }
/*      */         catch (NamingException e)
/*      */         {
/* 1290 */           currentContext = (javax.naming.Context)currentContext.lookup(token);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\core\NamingContextListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */