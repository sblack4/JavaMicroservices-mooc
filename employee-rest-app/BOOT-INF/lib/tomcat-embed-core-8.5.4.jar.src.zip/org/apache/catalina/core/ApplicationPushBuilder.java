/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletRequestWrapper;
/*     */ import javax.servlet.SessionTrackingMode;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.catalina.servlet4preview.http.PushBuilder;
/*     */ import org.apache.catalina.util.SessionConfig;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.coyote.PushToken;
/*     */ import org.apache.tomcat.util.buf.B2CConverter;
/*     */ import org.apache.tomcat.util.buf.HexUtils;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.collections.CaseInsensitiveKeyMap;
/*     */ import org.apache.tomcat.util.http.CookieProcessor;
/*     */ import org.apache.tomcat.util.http.MimeHeaders;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationPushBuilder
/*     */   implements PushBuilder
/*     */ {
/*  50 */   private static final StringManager sm = StringManager.getManager(ApplicationPushBuilder.class);
/*     */   
/*     */   private final HttpServletRequest baseRequest;
/*     */   
/*     */   private final org.apache.catalina.connector.Request catalinaRequest;
/*     */   private final org.apache.coyote.Request coyoteRequest;
/*     */   private final String sessionCookieName;
/*     */   private final String sessionPathParameterName;
/*     */   private final boolean addSessionCookie;
/*     */   private final boolean addSessionPathParameter;
/*  60 */   private final Map<String, List<String>> headers = new CaseInsensitiveKeyMap();
/*  61 */   private final List<Cookie> cookies = new ArrayList();
/*  62 */   private String method = "GET";
/*     */   private String path;
/*     */   private String etag;
/*     */   private String lastModified;
/*     */   private String queryString;
/*     */   private String sessionId;
/*     */   private boolean conditional;
/*     */   
/*     */   public ApplicationPushBuilder(HttpServletRequest request)
/*     */   {
/*  72 */     this.baseRequest = request;
/*     */     
/*  74 */     ServletRequest current = request;
/*  75 */     while ((current instanceof ServletRequestWrapper)) {
/*  76 */       current = ((ServletRequestWrapper)current).getRequest();
/*     */     }
/*  78 */     if ((current instanceof org.apache.catalina.connector.Request)) {
/*  79 */       this.catalinaRequest = ((org.apache.catalina.connector.Request)current);
/*  80 */       this.coyoteRequest = this.catalinaRequest.getCoyoteRequest();
/*     */     } else {
/*  82 */       throw new UnsupportedOperationException(sm.getString("applicationPushBuilder.noCoyoteRequest", new Object[] { current.getClass().getName() }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  87 */     Enumeration<String> headerNames = request.getHeaderNames();
/*  88 */     while (headerNames.hasMoreElements()) {
/*  89 */       String headerName = (String)headerNames.nextElement();
/*  90 */       List<String> values = new ArrayList();
/*  91 */       this.headers.put(headerName, values);
/*  92 */       Enumeration<String> headerValues = request.getHeaders(headerName);
/*  93 */       while (headerValues.hasMoreElements()) {
/*  94 */         values.add(headerValues.nextElement());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  99 */     this.headers.remove("if-match");
/* 100 */     if (this.headers.remove("if-none-match") != null) {
/* 101 */       this.conditional = true;
/*     */     }
/* 103 */     if (this.headers.remove("if-modified-since") != null) {
/* 104 */       this.conditional = true;
/*     */     }
/* 106 */     this.headers.remove("if-unmodified-since");
/* 107 */     this.headers.remove("if-range");
/* 108 */     this.headers.remove("range");
/* 109 */     this.headers.remove("expect");
/* 110 */     this.headers.remove("authorization");
/* 111 */     this.headers.remove("referer");
/*     */     
/* 113 */     this.headers.remove("cookie");
/*     */     
/*     */ 
/* 116 */     StringBuffer referer = request.getRequestURL();
/* 117 */     if (request.getQueryString() != null) {
/* 118 */       referer.append('?');
/* 119 */       referer.append(request.getQueryString());
/*     */     }
/*     */     
/* 122 */     addHeader("referer", referer.toString());
/*     */     
/*     */ 
/* 125 */     Context context = this.catalinaRequest.getContext();
/* 126 */     this.sessionCookieName = SessionConfig.getSessionCookieName(context);
/* 127 */     this.sessionPathParameterName = SessionConfig.getSessionUriParamName(context);
/*     */     
/* 129 */     HttpSession session = request.getSession(false);
/* 130 */     if (session != null) {
/* 131 */       this.sessionId = session.getId();
/*     */     }
/* 133 */     if (this.sessionId == null) {
/* 134 */       this.sessionId = request.getRequestedSessionId();
/*     */     }
/* 136 */     if ((!request.isRequestedSessionIdFromCookie()) && (!request.isRequestedSessionIdFromURL()) && (this.sessionId != null))
/*     */     {
/* 138 */       Set<SessionTrackingMode> sessionTrackingModes = request.getServletContext().getEffectiveSessionTrackingModes();
/*     */       
/* 140 */       this.addSessionCookie = sessionTrackingModes.contains(SessionTrackingMode.COOKIE);
/* 141 */       this.addSessionPathParameter = sessionTrackingModes.contains(SessionTrackingMode.URL);
/*     */     } else {
/* 143 */       this.addSessionCookie = request.isRequestedSessionIdFromCookie();
/* 144 */       this.addSessionPathParameter = request.isRequestedSessionIdFromURL();
/*     */     }
/*     */     
/*     */ 
/* 148 */     if (request.getCookies() != null) {
/* 149 */       for (Cookie requestCookie : request.getCookies()) {
/* 150 */         this.cookies.add(requestCookie);
/*     */       }
/*     */     }
/* 153 */     for (Cookie responseCookie : this.catalinaRequest.getResponse().getCookies()) {
/* 154 */       if (responseCookie.getMaxAge() < 0)
/*     */       {
/*     */ 
/* 157 */         Iterator<Cookie> cookieIterator = this.cookies.iterator();
/* 158 */         while (cookieIterator.hasNext()) {
/* 159 */           Cookie cookie = (Cookie)cookieIterator.next();
/* 160 */           if (cookie.getName().equals(responseCookie.getName())) {
/* 161 */             cookieIterator.remove();
/*     */           }
/*     */         }
/*     */       } else {
/* 165 */         this.cookies.add(new Cookie(responseCookie.getName(), responseCookie.getValue()));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public ApplicationPushBuilder path(String path)
/*     */   {
/* 173 */     if (path.startsWith("/")) {
/* 174 */       this.path = path;
/*     */     } else {
/* 176 */       String contextPath = this.baseRequest.getContextPath();
/* 177 */       int len = contextPath.length() + path.length() + 1;
/* 178 */       StringBuilder sb = new StringBuilder(len);
/* 179 */       sb.append(contextPath);
/* 180 */       sb.append('/');
/* 181 */       sb.append(path);
/* 182 */       this.path = sb.toString();
/*     */     }
/* 184 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getPath()
/*     */   {
/* 190 */     return this.path;
/*     */   }
/*     */   
/*     */ 
/*     */   public ApplicationPushBuilder method(String method)
/*     */   {
/* 196 */     this.method = method;
/* 197 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getMethod()
/*     */   {
/* 203 */     return this.method;
/*     */   }
/*     */   
/*     */ 
/*     */   public ApplicationPushBuilder etag(String etag)
/*     */   {
/* 209 */     this.etag = etag;
/* 210 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getEtag()
/*     */   {
/* 216 */     return this.etag;
/*     */   }
/*     */   
/*     */ 
/*     */   public ApplicationPushBuilder lastModified(String lastModified)
/*     */   {
/* 222 */     this.lastModified = lastModified;
/* 223 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getLastModified()
/*     */   {
/* 229 */     return this.lastModified;
/*     */   }
/*     */   
/*     */ 
/*     */   public ApplicationPushBuilder queryString(String queryString)
/*     */   {
/* 235 */     this.queryString = queryString;
/* 236 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getQueryString()
/*     */   {
/* 242 */     return this.queryString;
/*     */   }
/*     */   
/*     */ 
/*     */   public ApplicationPushBuilder sessionId(String sessionId)
/*     */   {
/* 248 */     this.sessionId = sessionId;
/* 249 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getSessionId()
/*     */   {
/* 255 */     return this.sessionId;
/*     */   }
/*     */   
/*     */ 
/*     */   public ApplicationPushBuilder conditional(boolean conditional)
/*     */   {
/* 261 */     this.conditional = conditional;
/* 262 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isConditional()
/*     */   {
/* 268 */     return this.conditional;
/*     */   }
/*     */   
/*     */ 
/*     */   public ApplicationPushBuilder addHeader(String name, String value)
/*     */   {
/* 274 */     List<String> values = (List)this.headers.get(name);
/* 275 */     if (values == null) {
/* 276 */       values = new ArrayList();
/* 277 */       this.headers.put(name, values);
/*     */     }
/* 279 */     values.add(value);
/*     */     
/* 281 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   public ApplicationPushBuilder setHeader(String name, String value)
/*     */   {
/* 287 */     List<String> values = (List)this.headers.get(name);
/* 288 */     if (values == null) {
/* 289 */       values = new ArrayList();
/* 290 */       this.headers.put(name, values);
/*     */     } else {
/* 292 */       values.clear();
/*     */     }
/* 294 */     values.add(value);
/*     */     
/* 296 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   public ApplicationPushBuilder removeHeader(String name)
/*     */   {
/* 302 */     this.headers.remove(name);
/*     */     
/* 304 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   public Set<String> getHeaderNames()
/*     */   {
/* 310 */     return Collections.unmodifiableSet(this.headers.keySet());
/*     */   }
/*     */   
/*     */ 
/*     */   public String getHeader(String name)
/*     */   {
/* 316 */     List<String> values = (List)this.headers.get(name);
/* 317 */     if (values == null) {
/* 318 */       return null;
/*     */     }
/* 320 */     return (String)values.get(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean push()
/*     */   {
/* 327 */     if (this.path == null) {
/* 328 */       throw new IllegalStateException(sm.getString("pushBuilder.noPath"));
/*     */     }
/*     */     
/* 331 */     org.apache.coyote.Request pushTarget = new org.apache.coyote.Request();
/*     */     
/* 333 */     pushTarget.method().setString(this.method);
/*     */     
/* 335 */     pushTarget.serverName().setString(this.baseRequest.getServerName());
/* 336 */     pushTarget.setServerPort(this.baseRequest.getServerPort());
/* 337 */     pushTarget.scheme().setString(this.baseRequest.getScheme());
/*     */     
/*     */ 
/* 340 */     for (Iterator i$ = this.headers.entrySet().iterator(); i$.hasNext();) { header = (Map.Entry)i$.next();
/* 341 */       for (String value : (List)header.getValue()) {
/* 342 */         pushTarget.getMimeHeaders().addValue((String)header.getKey()).setString(value);
/*     */       }
/*     */     }
/*     */     
/*     */     Map.Entry<String, List<String>> header;
/* 347 */     int queryIndex = this.path.indexOf('?');
/*     */     
/* 349 */     String pushQueryString = null;
/* 350 */     String pushPath; if (queryIndex > -1) {
/* 351 */       String pushPath = this.path.substring(0, queryIndex);
/* 352 */       if (queryIndex + 1 < this.path.length()) {
/* 353 */         pushQueryString = this.path.substring(queryIndex + 1);
/*     */       }
/*     */     } else {
/* 356 */       pushPath = this.path;
/*     */     }
/*     */     
/*     */ 
/* 360 */     if (this.sessionId != null) {
/* 361 */       if (this.addSessionPathParameter) {
/* 362 */         pushPath = pushPath + ";" + this.sessionPathParameterName + "=" + this.sessionId;
/* 363 */         pushTarget.addPathParameter(this.sessionPathParameterName, this.sessionId);
/*     */       }
/* 365 */       if (this.addSessionCookie) {
/* 366 */         this.cookies.add(new Cookie(this.sessionCookieName, this.sessionId));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 371 */     pushTarget.requestURI().setString(pushPath);
/* 372 */     pushTarget.decodedURI().setString(decode(pushPath, this.catalinaRequest.getConnector().getURIEncodingLower()));
/*     */     
/*     */ 
/*     */ 
/* 376 */     if ((pushQueryString == null) && (this.queryString != null)) {
/* 377 */       pushTarget.queryString().setString(this.queryString);
/* 378 */     } else if ((pushQueryString != null) && (this.queryString == null)) {
/* 379 */       pushTarget.queryString().setString(pushQueryString);
/* 380 */     } else if ((pushQueryString != null) && (this.queryString != null)) {
/* 381 */       pushTarget.queryString().setString(pushQueryString + "&" + this.queryString);
/*     */     }
/*     */     
/* 384 */     if (this.conditional) {
/* 385 */       if (this.etag != null) {
/* 386 */         setHeader("if-none-match", this.etag);
/* 387 */       } else if (this.lastModified != null) {
/* 388 */         setHeader("if-modified-since", this.lastModified);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 393 */     setHeader("cookie", generateCookieHeader(this.cookies, this.catalinaRequest.getContext().getCookieProcessor()));
/*     */     
/*     */ 
/* 396 */     PushToken pushToken = new PushToken(pushTarget);
/* 397 */     this.coyoteRequest.action(ActionCode.PUSH_REQUEST, pushToken);
/*     */     
/*     */ 
/* 400 */     pushTarget = null;
/* 401 */     this.path = null;
/* 402 */     this.etag = null;
/* 403 */     this.lastModified = null;
/* 404 */     this.headers.remove("if-none-match");
/* 405 */     this.headers.remove("if-modified-since");
/*     */     
/* 407 */     return pushToken.getResult();
/*     */   }
/*     */   
/*     */ 
/*     */   static String decode(String input, String charsetName)
/*     */   {
/* 413 */     int start = input.indexOf('%');
/* 414 */     int end = 0;
/*     */     
/*     */ 
/* 417 */     if (start == -1) {
/* 418 */       return input;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 423 */       charset = B2CConverter.getCharsetLower(charsetName);
/*     */     }
/*     */     catch (UnsupportedEncodingException uee) {
/*     */       Charset charset;
/* 427 */       throw new IllegalStateException(uee);
/*     */     }
/*     */     Charset charset;
/* 430 */     StringBuilder result = new StringBuilder(input.length());
/* 431 */     while (start != -1)
/*     */     {
/*     */ 
/* 434 */       result.append(input.substring(end, start));
/*     */       
/* 436 */       end = start + 3;
/* 437 */       while ((end < input.length()) && (input.charAt(end) == '%')) {
/* 438 */         end += 3;
/*     */       }
/* 440 */       result.append(decode(input.substring(start, end), charset));
/* 441 */       start = input.indexOf('%', end);
/*     */     }
/*     */     
/* 444 */     result.append(input.substring(end));
/*     */     
/* 446 */     return result.toString();
/*     */   }
/*     */   
/*     */   private static String decode(String percentSequence, Charset charset)
/*     */   {
/* 451 */     byte[] bytes = new byte[percentSequence.length() / 3];
/* 452 */     for (int i = 0; i < bytes.length; i += 3) {
/* 453 */       bytes[i] = ((byte)(HexUtils.getDec(percentSequence.charAt(1 + 3 * i)) << 4 + HexUtils.getDec(percentSequence.charAt(2 + 3 * i))));
/*     */     }
/*     */     
/*     */ 
/* 457 */     return new String(bytes, charset);
/*     */   }
/*     */   
/*     */   private static String generateCookieHeader(List<Cookie> cookies, CookieProcessor cookieProcessor)
/*     */   {
/* 462 */     StringBuilder result = new StringBuilder();
/* 463 */     boolean first = true;
/* 464 */     for (Cookie cookie : cookies) {
/* 465 */       if (first) {
/* 466 */         first = false;
/*     */       } else {
/* 468 */         result.append(';');
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 475 */       result.append(cookieProcessor.generateHeader(cookie));
/*     */     }
/* 477 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\core\ApplicationPushBuilder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */