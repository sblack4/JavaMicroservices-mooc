/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.DispatcherType;
/*     */ import javax.servlet.FilterRegistration.Dynamic;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.util.ParameterMap;
/*     */ import org.apache.tomcat.util.descriptor.web.FilterDef;
/*     */ import org.apache.tomcat.util.descriptor.web.FilterMap;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationFilterRegistration
/*     */   implements FilterRegistration.Dynamic
/*     */ {
/*  41 */   private static final StringManager sm = StringManager.getManager("org.apache.catalina.core");
/*     */   
/*     */   private final FilterDef filterDef;
/*     */   
/*     */   private final Context context;
/*     */   
/*     */   public ApplicationFilterRegistration(FilterDef filterDef, Context context)
/*     */   {
/*  49 */     this.filterDef = filterDef;
/*  50 */     this.context = context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addMappingForServletNames(EnumSet<DispatcherType> dispatcherTypes, boolean isMatchAfter, String... servletNames)
/*     */   {
/*  59 */     FilterMap filterMap = new FilterMap();
/*     */     
/*  61 */     filterMap.setFilterName(this.filterDef.getFilterName());
/*     */     
/*  63 */     if (dispatcherTypes != null) {
/*  64 */       for (DispatcherType dispatcherType : dispatcherTypes) {
/*  65 */         filterMap.setDispatcher(dispatcherType.name());
/*     */       }
/*     */     }
/*     */     
/*  69 */     if (servletNames != null) {
/*  70 */       for (String servletName : servletNames) {
/*  71 */         filterMap.addServletName(servletName);
/*     */       }
/*     */       
/*  74 */       if (isMatchAfter) {
/*  75 */         this.context.addFilterMap(filterMap);
/*     */       } else {
/*  77 */         this.context.addFilterMapBefore(filterMap);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addMappingForUrlPatterns(EnumSet<DispatcherType> dispatcherTypes, boolean isMatchAfter, String... urlPatterns)
/*     */   {
/*  88 */     FilterMap filterMap = new FilterMap();
/*     */     
/*  90 */     filterMap.setFilterName(this.filterDef.getFilterName());
/*     */     
/*  92 */     if (dispatcherTypes != null) {
/*  93 */       for (DispatcherType dispatcherType : dispatcherTypes) {
/*  94 */         filterMap.setDispatcher(dispatcherType.name());
/*     */       }
/*     */     }
/*     */     
/*  98 */     if (urlPatterns != null) {
/*  99 */       for (String urlPattern : urlPatterns) {
/* 100 */         filterMap.addURLPattern(urlPattern);
/*     */       }
/*     */       
/* 103 */       if (isMatchAfter) {
/* 104 */         this.context.addFilterMap(filterMap);
/*     */       } else {
/* 106 */         this.context.addFilterMapBefore(filterMap);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Collection<String> getServletNameMappings()
/*     */   {
/* 115 */     Collection<String> result = new HashSet();
/*     */     
/* 117 */     FilterMap[] filterMaps = this.context.findFilterMaps();
/*     */     
/* 119 */     for (FilterMap filterMap : filterMaps) {
/* 120 */       if (filterMap.getFilterName().equals(this.filterDef.getFilterName())) {
/* 121 */         for (String servletName : filterMap.getServletNames()) {
/* 122 */           result.add(servletName);
/*     */         }
/*     */       }
/*     */     }
/* 126 */     return result;
/*     */   }
/*     */   
/*     */   public Collection<String> getUrlPatternMappings()
/*     */   {
/* 131 */     Collection<String> result = new HashSet();
/*     */     
/* 133 */     FilterMap[] filterMaps = this.context.findFilterMaps();
/*     */     
/* 135 */     for (FilterMap filterMap : filterMaps) {
/* 136 */       if (filterMap.getFilterName().equals(this.filterDef.getFilterName())) {
/* 137 */         for (String urlPattern : filterMap.getURLPatterns()) {
/* 138 */           result.add(urlPattern);
/*     */         }
/*     */       }
/*     */     }
/* 142 */     return result;
/*     */   }
/*     */   
/*     */   public String getClassName()
/*     */   {
/* 147 */     return this.filterDef.getFilterClass();
/*     */   }
/*     */   
/*     */   public String getInitParameter(String name)
/*     */   {
/* 152 */     return (String)this.filterDef.getParameterMap().get(name);
/*     */   }
/*     */   
/*     */   public Map<String, String> getInitParameters()
/*     */   {
/* 157 */     ParameterMap<String, String> result = new ParameterMap();
/* 158 */     result.putAll(this.filterDef.getParameterMap());
/* 159 */     result.setLocked(true);
/* 160 */     return result;
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/* 165 */     return this.filterDef.getFilterName();
/*     */   }
/*     */   
/*     */   public boolean setInitParameter(String name, String value)
/*     */   {
/* 170 */     if ((name == null) || (value == null)) {
/* 171 */       throw new IllegalArgumentException(sm.getString("applicationFilterRegistration.nullInitParam", new Object[] { name, value }));
/*     */     }
/*     */     
/*     */ 
/* 175 */     if (getInitParameter(name) != null) {
/* 176 */       return false;
/*     */     }
/*     */     
/* 179 */     this.filterDef.addInitParameter(name, value);
/*     */     
/* 181 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public Set<String> setInitParameters(Map<String, String> initParameters)
/*     */   {
/* 187 */     Set<String> conflicts = new HashSet();
/*     */     
/* 189 */     for (Map.Entry<String, String> entry : initParameters.entrySet()) {
/* 190 */       if ((entry.getKey() == null) || (entry.getValue() == null)) {
/* 191 */         throw new IllegalArgumentException(sm.getString("applicationFilterRegistration.nullInitParams", new Object[] { entry.getKey(), entry.getValue() }));
/*     */       }
/*     */       
/*     */ 
/* 195 */       if (getInitParameter((String)entry.getKey()) != null) {
/* 196 */         conflicts.add(entry.getKey());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 202 */     for (Map.Entry<String, String> entry : initParameters.entrySet()) {
/* 203 */       setInitParameter((String)entry.getKey(), (String)entry.getValue());
/*     */     }
/*     */     
/* 206 */     return conflicts;
/*     */   }
/*     */   
/*     */   public void setAsyncSupported(boolean asyncSupported)
/*     */   {
/* 211 */     this.filterDef.setAsyncSupported(Boolean.valueOf(asyncSupported).toString());
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\core\ApplicationFilterRegistration.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */