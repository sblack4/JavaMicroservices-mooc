/*      */ package org.apache.catalina.core;
/*      */ 
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Enumeration;
/*      */ import java.util.EventListener;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.Stack;
/*      */ import java.util.TreeMap;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import java.util.concurrent.CopyOnWriteArrayList;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReadWriteLock;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*      */ import javax.management.ListenerNotFoundException;
/*      */ import javax.management.MBeanNotificationInfo;
/*      */ import javax.management.Notification;
/*      */ import javax.management.NotificationBroadcasterSupport;
/*      */ import javax.management.NotificationEmitter;
/*      */ import javax.management.NotificationFilter;
/*      */ import javax.management.NotificationListener;
/*      */ import javax.naming.NamingException;
/*      */ import javax.servlet.Filter;
/*      */ import javax.servlet.FilterConfig;
/*      */ import javax.servlet.FilterRegistration;
/*      */ import javax.servlet.FilterRegistration.Dynamic;
/*      */ import javax.servlet.RequestDispatcher;
/*      */ import javax.servlet.Servlet;
/*      */ import javax.servlet.ServletContainerInitializer;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletContextAttributeListener;
/*      */ import javax.servlet.ServletContextEvent;
/*      */ import javax.servlet.ServletContextListener;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletRegistration;
/*      */ import javax.servlet.ServletRegistration.Dynamic;
/*      */ import javax.servlet.ServletRequest;
/*      */ import javax.servlet.ServletRequestAttributeListener;
/*      */ import javax.servlet.ServletRequestEvent;
/*      */ import javax.servlet.ServletRequestListener;
/*      */ import javax.servlet.ServletSecurityElement;
/*      */ import javax.servlet.SessionCookieConfig;
/*      */ import javax.servlet.SessionTrackingMode;
/*      */ import javax.servlet.descriptor.JspConfigDescriptor;
/*      */ import javax.servlet.http.HttpSessionAttributeListener;
/*      */ import javax.servlet.http.HttpSessionIdListener;
/*      */ import javax.servlet.http.HttpSessionListener;
/*      */ import org.apache.catalina.Authenticator;
/*      */ import org.apache.catalina.Cluster;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.ContainerListener;
/*      */ import org.apache.catalina.CredentialHandler;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.Lifecycle;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleListener;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Loader;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.Pipeline;
/*      */ import org.apache.catalina.Realm;
/*      */ import org.apache.catalina.ThreadBindingListener;
/*      */ import org.apache.catalina.Valve;
/*      */ import org.apache.catalina.WebResource;
/*      */ import org.apache.catalina.WebResourceRoot;
/*      */ import org.apache.catalina.WebResourceRoot.ResourceSetType;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.deploy.NamingResourcesImpl;
/*      */ import org.apache.catalina.loader.WebappLoader;
/*      */ import org.apache.catalina.session.StandardManager;
/*      */ import org.apache.catalina.util.CharsetMapper;
/*      */ import org.apache.catalina.util.ContextName;
/*      */ import org.apache.catalina.util.ExtensionValidator;
/*      */ import org.apache.catalina.util.URLEncoder;
/*      */ import org.apache.catalina.webresources.StandardRoot;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.naming.ContextBindings;
/*      */ import org.apache.tomcat.InstanceManager;
/*      */ import org.apache.tomcat.InstanceManagerBindings;
/*      */ import org.apache.tomcat.JarScanner;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.IntrospectionUtils;
/*      */ import org.apache.tomcat.util.buf.UDecoder;
/*      */ import org.apache.tomcat.util.descriptor.web.ApplicationParameter;
/*      */ import org.apache.tomcat.util.descriptor.web.ErrorPage;
/*      */ import org.apache.tomcat.util.descriptor.web.FilterDef;
/*      */ import org.apache.tomcat.util.descriptor.web.FilterMap;
/*      */ import org.apache.tomcat.util.descriptor.web.Injectable;
/*      */ import org.apache.tomcat.util.descriptor.web.InjectionTarget;
/*      */ import org.apache.tomcat.util.descriptor.web.LoginConfig;
/*      */ import org.apache.tomcat.util.descriptor.web.MessageDestination;
/*      */ import org.apache.tomcat.util.descriptor.web.MessageDestinationRef;
/*      */ import org.apache.tomcat.util.descriptor.web.SecurityCollection;
/*      */ import org.apache.tomcat.util.descriptor.web.SecurityConstraint;
/*      */ import org.apache.tomcat.util.http.CookieProcessor;
/*      */ import org.apache.tomcat.util.http.Rfc6265CookieProcessor;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.util.scan.StandardJarScanner;
/*      */ import org.apache.tomcat.util.security.PrivilegedGetTccl;
/*      */ import org.apache.tomcat.util.security.PrivilegedSetTccl;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StandardContext
/*      */   extends ContainerBase
/*      */   implements org.apache.catalina.Context, NotificationEmitter
/*      */ {
/*  148 */   private static final Log log = LogFactory.getLog(StandardContext.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StandardContext()
/*      */   {
/*  160 */     this.pipeline.setBasic(new StandardContextValve());
/*  161 */     this.broadcaster = new NotificationBroadcasterSupport();
/*      */     
/*  163 */     if (!Globals.STRICT_SERVLET_COMPLIANCE)
/*      */     {
/*      */ 
/*  166 */       this.resourceOnlyServlets.add("jsp");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  178 */   protected boolean allowCasualMultipartParsing = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  184 */   private boolean swallowAbortedUploads = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  189 */   private String altDDName = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  195 */   private InstanceManager instanceManager = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  201 */   private boolean antiResourceLocking = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  209 */   private String[] applicationListeners = new String[0];
/*      */   
/*  211 */   private final Object applicationListenersLock = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  217 */   private final Set<Object> noPluggabilityListeners = new HashSet();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  224 */   private List<Object> applicationEventListenersList = new CopyOnWriteArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  232 */   private Object[] applicationLifecycleListenersObjects = new Object[0];
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  239 */   private Map<ServletContainerInitializer, Set<Class<?>>> initializers = new LinkedHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  246 */   private ApplicationParameter[] applicationParameters = new ApplicationParameter[0];
/*      */   
/*      */ 
/*  249 */   private final Object applicationParametersLock = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  255 */   private NotificationBroadcasterSupport broadcaster = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  260 */   private CharsetMapper charsetMapper = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  266 */   private String charsetMapperClass = "org.apache.catalina.util.CharsetMapper";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  273 */   private URL configFile = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  279 */   private boolean configured = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  285 */   private volatile SecurityConstraint[] constraints = new SecurityConstraint[0];
/*      */   
/*      */ 
/*  288 */   private final Object constraintsLock = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  294 */   protected ApplicationContext context = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  301 */   private NoPluggabilityServletContext noPluggabilityServletContext = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  307 */   private boolean cookies = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  314 */   private boolean crossContext = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  320 */   private String encodedPath = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  326 */   private String path = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  333 */   private boolean delegate = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean denyUncoveredHttpMethods;
/*      */   
/*      */ 
/*      */ 
/*  342 */   private String displayName = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String defaultContextXml;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String defaultWebXml;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  360 */   private boolean distributable = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  366 */   private String docBase = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  373 */   private HashMap<String, ErrorPage> exceptionPages = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  380 */   private HashMap<String, ApplicationFilterConfig> filterConfigs = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  388 */   private HashMap<String, FilterDef> filterDefs = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  397 */   private final ContextFilterMaps filterMaps = new ContextFilterMaps(null);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  402 */   private boolean ignoreAnnotations = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  408 */   private Loader loader = null;
/*  409 */   private final ReadWriteLock loaderLock = new ReentrantReadWriteLock();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  415 */   private LoginConfig loginConfig = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  421 */   protected Manager manager = null;
/*  422 */   private final ReadWriteLock managerLock = new ReentrantReadWriteLock();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  428 */   private NamingContextListener namingContextListener = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  434 */   private NamingResourcesImpl namingResources = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  439 */   private HashMap<String, MessageDestination> messageDestinations = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  446 */   private HashMap<String, String> mimeMappings = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  453 */   private final ConcurrentMap<String, String> parameters = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  459 */   private volatile boolean paused = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  467 */   private String publicId = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  473 */   private boolean reloadable = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  479 */   private boolean unpackWAR = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  485 */   private boolean copyXML = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  491 */   private boolean override = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  497 */   private String originalDocBase = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  503 */   private boolean privileged = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  513 */   private boolean replaceWelcomeFiles = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  520 */   private HashMap<String, String> roleMappings = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  526 */   private String[] securityRoles = new String[0];
/*      */   
/*  528 */   private final Object securityRolesLock = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  535 */   private HashMap<String, String> servletMappings = new HashMap();
/*      */   
/*  537 */   private final Object servletMappingsLock = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  543 */   private int sessionTimeout = 30;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  548 */   private AtomicLong sequenceNumber = new AtomicLong(0L);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  555 */   private HashMap<Integer, ErrorPage> statusPages = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  562 */   private boolean swallowOutput = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  568 */   private long unloadDelay = 2000L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  574 */   private String[] watchedResources = new String[0];
/*      */   
/*  576 */   private final Object watchedResourcesLock = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  582 */   private String[] welcomeFiles = new String[0];
/*      */   
/*  584 */   private final Object welcomeFilesLock = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  591 */   private String[] wrapperLifecycles = new String[0];
/*      */   
/*  593 */   private final Object wrapperLifecyclesLock = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  599 */   private String[] wrapperListeners = new String[0];
/*      */   
/*  601 */   private final Object wrapperListenersLock = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  607 */   private String workDir = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  613 */   private String wrapperClassName = StandardWrapper.class.getName();
/*  614 */   private Class<?> wrapperClass = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  620 */   private boolean useNaming = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  626 */   private String namingContextName = null;
/*      */   
/*      */   private WebResourceRoot resources;
/*      */   
/*  630 */   private final ReadWriteLock resourcesLock = new ReentrantReadWriteLock();
/*      */   
/*      */ 
/*      */   private long startupTime;
/*      */   
/*      */   private long startTime;
/*      */   
/*      */   private long tldScanTime;
/*      */   
/*  639 */   private String j2EEApplication = "none";
/*  640 */   private String j2EEServer = "none";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  647 */   private boolean webXmlValidation = Globals.STRICT_SERVLET_COMPLIANCE;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  653 */   private boolean webXmlNamespaceAware = Globals.STRICT_SERVLET_COMPLIANCE;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  659 */   private boolean xmlBlockExternal = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  665 */   private boolean tldValidation = Globals.STRICT_SERVLET_COMPLIANCE;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String sessionCookieName;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  678 */   private boolean useHttpOnly = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String sessionCookieDomain;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String sessionCookiePath;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  700 */   private boolean sessionCookiePathUsesTrailingSlash = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  707 */   private JarScanner jarScanner = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  714 */   private boolean clearReferencesRmiTargets = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  725 */   private boolean clearReferencesStopThreads = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  732 */   private boolean clearReferencesStopTimerThreads = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  742 */   private boolean clearReferencesHttpClientKeepAliveThread = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  750 */   private boolean renewThreadsWhenStoppingContext = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  755 */   private boolean logEffectiveWebXml = false;
/*      */   
/*  757 */   private int effectiveMajorVersion = 3;
/*      */   
/*  759 */   private int effectiveMinorVersion = 0;
/*      */   
/*  761 */   private JspConfigDescriptor jspConfigDescriptor = null;
/*      */   
/*  763 */   private Set<String> resourceOnlyServlets = new HashSet();
/*      */   
/*  765 */   private String webappVersion = "";
/*      */   
/*  767 */   private boolean addWebinfClassesResources = false;
/*      */   
/*  769 */   private boolean fireRequestListenersOnForwards = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  775 */   private Set<Servlet> createdServlets = new HashSet();
/*      */   
/*  777 */   private boolean preemptiveAuthentication = false;
/*      */   
/*  779 */   private boolean sendRedirectBody = false;
/*      */   
/*  781 */   private boolean jndiExceptionOnFailedWrite = true;
/*      */   
/*  783 */   private Map<String, String> postConstructMethods = new HashMap();
/*  784 */   private Map<String, String> preDestroyMethods = new HashMap();
/*      */   
/*      */   private String containerSciFilter;
/*      */   
/*      */   private Boolean failCtxIfServletStartFails;
/*      */   
/*  790 */   protected static final ThreadBindingListener DEFAULT_NAMING_LISTENER = new ThreadBindingListener()
/*      */   {
/*      */     public void bind() {}
/*      */     
/*      */     public void unbind() {}
/*      */   };
/*  796 */   protected ThreadBindingListener threadBindingListener = DEFAULT_NAMING_LISTENER;
/*      */   
/*  798 */   private final Object namingToken = new Object();
/*      */   
/*      */   private CookieProcessor cookieProcessor;
/*      */   
/*  802 */   private boolean validateClientProvidedNewSessionId = true;
/*      */   
/*  804 */   private boolean mapperContextRootRedirectEnabled = true;
/*      */   
/*  806 */   private boolean mapperDirectoryRedirectEnabled = false;
/*      */   
/*  808 */   private boolean useRelativeRedirects = !Globals.STRICT_SERVLET_COMPLIANCE;
/*      */   
/*      */   private MBeanNotificationInfo[] notificationInfo;
/*      */   
/*      */ 
/*      */   public void setUseRelativeRedirects(boolean useRelativeRedirects)
/*      */   {
/*  815 */     this.useRelativeRedirects = useRelativeRedirects;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUseRelativeRedirects()
/*      */   {
/*  826 */     return this.useRelativeRedirects;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setMapperContextRootRedirectEnabled(boolean mapperContextRootRedirectEnabled)
/*      */   {
/*  832 */     this.mapperContextRootRedirectEnabled = mapperContextRootRedirectEnabled;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getMapperContextRootRedirectEnabled()
/*      */   {
/*  843 */     return this.mapperContextRootRedirectEnabled;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setMapperDirectoryRedirectEnabled(boolean mapperDirectoryRedirectEnabled)
/*      */   {
/*  849 */     this.mapperDirectoryRedirectEnabled = mapperDirectoryRedirectEnabled;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getMapperDirectoryRedirectEnabled()
/*      */   {
/*  860 */     return this.mapperDirectoryRedirectEnabled;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setValidateClientProvidedNewSessionId(boolean validateClientProvidedNewSessionId)
/*      */   {
/*  866 */     this.validateClientProvidedNewSessionId = validateClientProvidedNewSessionId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getValidateClientProvidedNewSessionId()
/*      */   {
/*  877 */     return this.validateClientProvidedNewSessionId;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setCookieProcessor(CookieProcessor cookieProcessor)
/*      */   {
/*  883 */     if (cookieProcessor == null) {
/*  884 */       throw new IllegalArgumentException(sm.getString("standardContext.cookieProcessor.null"));
/*      */     }
/*      */     
/*  887 */     this.cookieProcessor = cookieProcessor;
/*      */   }
/*      */   
/*      */ 
/*      */   public CookieProcessor getCookieProcessor()
/*      */   {
/*  893 */     return this.cookieProcessor;
/*      */   }
/*      */   
/*      */ 
/*      */   public Object getNamingToken()
/*      */   {
/*  899 */     return this.namingToken;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setContainerSciFilter(String containerSciFilter)
/*      */   {
/*  905 */     this.containerSciFilter = containerSciFilter;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getContainerSciFilter()
/*      */   {
/*  911 */     return this.containerSciFilter;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getSendRedirectBody()
/*      */   {
/*  917 */     return this.sendRedirectBody;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setSendRedirectBody(boolean sendRedirectBody)
/*      */   {
/*  923 */     this.sendRedirectBody = sendRedirectBody;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getPreemptiveAuthentication()
/*      */   {
/*  929 */     return this.preemptiveAuthentication;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setPreemptiveAuthentication(boolean preemptiveAuthentication)
/*      */   {
/*  935 */     this.preemptiveAuthentication = preemptiveAuthentication;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setFireRequestListenersOnForwards(boolean enable)
/*      */   {
/*  941 */     this.fireRequestListenersOnForwards = enable;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getFireRequestListenersOnForwards()
/*      */   {
/*  947 */     return this.fireRequestListenersOnForwards;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setAddWebinfClassesResources(boolean addWebinfClassesResources)
/*      */   {
/*  954 */     this.addWebinfClassesResources = addWebinfClassesResources;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getAddWebinfClassesResources()
/*      */   {
/*  960 */     return this.addWebinfClassesResources;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setWebappVersion(String webappVersion)
/*      */   {
/*  966 */     if (null == webappVersion) {
/*  967 */       this.webappVersion = "";
/*      */     } else {
/*  969 */       this.webappVersion = webappVersion;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public String getWebappVersion()
/*      */   {
/*  976 */     return this.webappVersion;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getBaseName()
/*      */   {
/*  982 */     return new ContextName(this.path, this.webappVersion).getBaseName();
/*      */   }
/*      */   
/*      */ 
/*      */   public String getResourceOnlyServlets()
/*      */   {
/*  988 */     StringBuilder result = new StringBuilder();
/*  989 */     boolean first = true;
/*  990 */     for (String servletName : this.resourceOnlyServlets) {
/*  991 */       if (first) {
/*  992 */         first = false;
/*      */       } else {
/*  994 */         result.append(',');
/*      */       }
/*  996 */       result.append(servletName);
/*      */     }
/*  998 */     return result.toString();
/*      */   }
/*      */   
/*      */ 
/*      */   public void setResourceOnlyServlets(String resourceOnlyServlets)
/*      */   {
/* 1004 */     this.resourceOnlyServlets.clear();
/* 1005 */     if (resourceOnlyServlets == null) {
/* 1006 */       return;
/*      */     }
/* 1008 */     for (String servletName : resourceOnlyServlets.split(",")) {
/* 1009 */       servletName = servletName.trim();
/* 1010 */       if (servletName.length() > 0) {
/* 1011 */         this.resourceOnlyServlets.add(servletName);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isResourceOnlyServlet(String servletName)
/*      */   {
/* 1019 */     return this.resourceOnlyServlets.contains(servletName);
/*      */   }
/*      */   
/*      */ 
/*      */   public int getEffectiveMajorVersion()
/*      */   {
/* 1025 */     return this.effectiveMajorVersion;
/*      */   }
/*      */   
/*      */   public void setEffectiveMajorVersion(int effectiveMajorVersion)
/*      */   {
/* 1030 */     this.effectiveMajorVersion = effectiveMajorVersion;
/*      */   }
/*      */   
/*      */   public int getEffectiveMinorVersion()
/*      */   {
/* 1035 */     return this.effectiveMinorVersion;
/*      */   }
/*      */   
/*      */   public void setEffectiveMinorVersion(int effectiveMinorVersion)
/*      */   {
/* 1040 */     this.effectiveMinorVersion = effectiveMinorVersion;
/*      */   }
/*      */   
/*      */   public void setLogEffectiveWebXml(boolean logEffectiveWebXml)
/*      */   {
/* 1045 */     this.logEffectiveWebXml = logEffectiveWebXml;
/*      */   }
/*      */   
/*      */   public boolean getLogEffectiveWebXml()
/*      */   {
/* 1050 */     return this.logEffectiveWebXml;
/*      */   }
/*      */   
/*      */   public Authenticator getAuthenticator()
/*      */   {
/* 1055 */     Pipeline pipeline = getPipeline();
/* 1056 */     if (pipeline != null) {
/* 1057 */       Valve basic = pipeline.getBasic();
/* 1058 */       if ((basic instanceof Authenticator))
/* 1059 */         return (Authenticator)basic;
/* 1060 */       for (Valve valve : pipeline.getValves()) {
/* 1061 */         if ((valve instanceof Authenticator)) {
/* 1062 */           return (Authenticator)valve;
/*      */         }
/*      */       }
/*      */     }
/* 1066 */     return null;
/*      */   }
/*      */   
/*      */   public JarScanner getJarScanner()
/*      */   {
/* 1071 */     if (this.jarScanner == null) {
/* 1072 */       this.jarScanner = new StandardJarScanner();
/*      */     }
/* 1074 */     return this.jarScanner;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setJarScanner(JarScanner jarScanner)
/*      */   {
/* 1080 */     this.jarScanner = jarScanner;
/*      */   }
/*      */   
/*      */ 
/*      */   public InstanceManager getInstanceManager()
/*      */   {
/* 1086 */     return this.instanceManager;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setInstanceManager(InstanceManager instanceManager)
/*      */   {
/* 1092 */     this.instanceManager = instanceManager;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getEncodedPath()
/*      */   {
/* 1098 */     return this.encodedPath;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAllowCasualMultipartParsing(boolean allowCasualMultipartParsing)
/*      */   {
/* 1114 */     this.allowCasualMultipartParsing = allowCasualMultipartParsing;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getAllowCasualMultipartParsing()
/*      */   {
/* 1127 */     return this.allowCasualMultipartParsing;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSwallowAbortedUploads(boolean swallowAbortedUploads)
/*      */   {
/* 1139 */     this.swallowAbortedUploads = swallowAbortedUploads;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getSwallowAbortedUploads()
/*      */   {
/* 1151 */     return this.swallowAbortedUploads;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addServletContainerInitializer(ServletContainerInitializer sci, Set<Class<?>> classes)
/*      */   {
/* 1164 */     this.initializers.put(sci, classes);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getDelegate()
/*      */   {
/* 1176 */     return this.delegate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDelegate(boolean delegate)
/*      */   {
/* 1189 */     boolean oldDelegate = this.delegate;
/* 1190 */     this.delegate = delegate;
/* 1191 */     this.support.firePropertyChange("delegate", oldDelegate, this.delegate);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUseNaming()
/*      */   {
/* 1202 */     return this.useNaming;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseNaming(boolean useNaming)
/*      */   {
/* 1213 */     this.useNaming = useNaming;
/*      */   }
/*      */   
/*      */ 
/*      */   public Object[] getApplicationEventListeners()
/*      */   {
/* 1219 */     return this.applicationEventListenersList.toArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setApplicationEventListeners(Object[] listeners)
/*      */   {
/* 1232 */     this.applicationEventListenersList.clear();
/* 1233 */     if ((listeners != null) && (listeners.length > 0)) {
/* 1234 */       this.applicationEventListenersList.addAll(Arrays.asList(listeners));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addApplicationEventListener(Object listener)
/*      */   {
/* 1246 */     this.applicationEventListenersList.add(listener);
/*      */   }
/*      */   
/*      */ 
/*      */   public Object[] getApplicationLifecycleListeners()
/*      */   {
/* 1252 */     return this.applicationLifecycleListenersObjects;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setApplicationLifecycleListeners(Object[] listeners)
/*      */   {
/* 1265 */     this.applicationLifecycleListenersObjects = listeners;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addApplicationLifecycleListener(Object listener)
/*      */   {
/* 1276 */     int len = this.applicationLifecycleListenersObjects.length;
/* 1277 */     Object[] newListeners = Arrays.copyOf(this.applicationLifecycleListenersObjects, len + 1);
/*      */     
/* 1279 */     newListeners[len] = listener;
/* 1280 */     this.applicationLifecycleListenersObjects = newListeners;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getAntiResourceLocking()
/*      */   {
/* 1289 */     return this.antiResourceLocking;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAntiResourceLocking(boolean antiResourceLocking)
/*      */   {
/* 1301 */     boolean oldAntiResourceLocking = this.antiResourceLocking;
/* 1302 */     this.antiResourceLocking = antiResourceLocking;
/* 1303 */     this.support.firePropertyChange("antiResourceLocking", oldAntiResourceLocking, this.antiResourceLocking);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CharsetMapper getCharsetMapper()
/*      */   {
/* 1316 */     if (this.charsetMapper == null) {
/*      */       try {
/* 1318 */         Class<?> clazz = Class.forName(this.charsetMapperClass);
/* 1319 */         this.charsetMapper = ((CharsetMapper)clazz.newInstance());
/*      */       } catch (Throwable t) {
/* 1321 */         ExceptionUtils.handleThrowable(t);
/* 1322 */         this.charsetMapper = new CharsetMapper();
/*      */       }
/*      */     }
/*      */     
/* 1326 */     return this.charsetMapper;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCharsetMapper(CharsetMapper mapper)
/*      */   {
/* 1338 */     CharsetMapper oldCharsetMapper = this.charsetMapper;
/* 1339 */     this.charsetMapper = mapper;
/* 1340 */     if (mapper != null)
/* 1341 */       this.charsetMapperClass = mapper.getClass().getName();
/* 1342 */     this.support.firePropertyChange("charsetMapper", oldCharsetMapper, this.charsetMapper);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCharset(Locale locale)
/*      */   {
/* 1350 */     return getCharsetMapper().getCharset(locale);
/*      */   }
/*      */   
/*      */ 
/*      */   public URL getConfigFile()
/*      */   {
/* 1356 */     return this.configFile;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setConfigFile(URL configFile)
/*      */   {
/* 1362 */     this.configFile = configFile;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getConfigured()
/*      */   {
/* 1368 */     return this.configured;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConfigured(boolean configured)
/*      */   {
/* 1382 */     boolean oldConfigured = this.configured;
/* 1383 */     this.configured = configured;
/* 1384 */     this.support.firePropertyChange("configured", oldConfigured, this.configured);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getCookies()
/*      */   {
/* 1393 */     return this.cookies;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCookies(boolean cookies)
/*      */   {
/* 1405 */     boolean oldCookies = this.cookies;
/* 1406 */     this.cookies = cookies;
/* 1407 */     this.support.firePropertyChange("cookies", oldCookies, this.cookies);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionCookieName()
/*      */   {
/* 1423 */     return this.sessionCookieName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionCookieName(String sessionCookieName)
/*      */   {
/* 1435 */     String oldSessionCookieName = this.sessionCookieName;
/* 1436 */     this.sessionCookieName = sessionCookieName;
/* 1437 */     this.support.firePropertyChange("sessionCookieName", oldSessionCookieName, sessionCookieName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUseHttpOnly()
/*      */   {
/* 1450 */     return this.useHttpOnly;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseHttpOnly(boolean useHttpOnly)
/*      */   {
/* 1462 */     boolean oldUseHttpOnly = this.useHttpOnly;
/* 1463 */     this.useHttpOnly = useHttpOnly;
/* 1464 */     this.support.firePropertyChange("useHttpOnly", oldUseHttpOnly, this.useHttpOnly);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionCookieDomain()
/*      */   {
/* 1479 */     return this.sessionCookieDomain;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionCookieDomain(String sessionCookieDomain)
/*      */   {
/* 1491 */     String oldSessionCookieDomain = this.sessionCookieDomain;
/* 1492 */     this.sessionCookieDomain = sessionCookieDomain;
/* 1493 */     this.support.firePropertyChange("sessionCookieDomain", oldSessionCookieDomain, sessionCookieDomain);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionCookiePath()
/*      */   {
/* 1507 */     return this.sessionCookiePath;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionCookiePath(String sessionCookiePath)
/*      */   {
/* 1519 */     String oldSessionCookiePath = this.sessionCookiePath;
/* 1520 */     this.sessionCookiePath = sessionCookiePath;
/* 1521 */     this.support.firePropertyChange("sessionCookiePath", oldSessionCookiePath, sessionCookiePath);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getSessionCookiePathUsesTrailingSlash()
/*      */   {
/* 1528 */     return this.sessionCookiePathUsesTrailingSlash;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setSessionCookiePathUsesTrailingSlash(boolean sessionCookiePathUsesTrailingSlash)
/*      */   {
/* 1535 */     this.sessionCookiePathUsesTrailingSlash = sessionCookiePathUsesTrailingSlash;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getCrossContext()
/*      */   {
/* 1542 */     return this.crossContext;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCrossContext(boolean crossContext)
/*      */   {
/* 1554 */     boolean oldCrossContext = this.crossContext;
/* 1555 */     this.crossContext = crossContext;
/* 1556 */     this.support.firePropertyChange("crossContext", oldCrossContext, this.crossContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getDefaultContextXml()
/*      */   {
/* 1563 */     return this.defaultContextXml;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDefaultContextXml(String defaultContextXml)
/*      */   {
/* 1574 */     this.defaultContextXml = defaultContextXml;
/*      */   }
/*      */   
/*      */   public String getDefaultWebXml() {
/* 1578 */     return this.defaultWebXml;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDefaultWebXml(String defaultWebXml)
/*      */   {
/* 1589 */     this.defaultWebXml = defaultWebXml;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getStartupTime()
/*      */   {
/* 1598 */     return this.startupTime;
/*      */   }
/*      */   
/*      */   public void setStartupTime(long startupTime) {
/* 1602 */     this.startupTime = startupTime;
/*      */   }
/*      */   
/*      */   public long getTldScanTime() {
/* 1606 */     return this.tldScanTime;
/*      */   }
/*      */   
/*      */   public void setTldScanTime(long tldScanTime) {
/* 1610 */     this.tldScanTime = tldScanTime;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getDenyUncoveredHttpMethods()
/*      */   {
/* 1616 */     return this.denyUncoveredHttpMethods;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setDenyUncoveredHttpMethods(boolean denyUncoveredHttpMethods)
/*      */   {
/* 1622 */     this.denyUncoveredHttpMethods = denyUncoveredHttpMethods;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDisplayName()
/*      */   {
/* 1632 */     return this.displayName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAltDDName()
/*      */   {
/* 1642 */     return this.altDDName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAltDDName(String altDDName)
/*      */   {
/* 1653 */     this.altDDName = altDDName;
/* 1654 */     if (this.context != null) {
/* 1655 */       this.context.setAttribute("org.apache.catalina.deploy.alt_dd", altDDName);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDisplayName(String displayName)
/*      */   {
/* 1668 */     String oldDisplayName = this.displayName;
/* 1669 */     this.displayName = displayName;
/* 1670 */     this.support.firePropertyChange("displayName", oldDisplayName, this.displayName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getDistributable()
/*      */   {
/* 1681 */     return this.distributable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDistributable(boolean distributable)
/*      */   {
/* 1692 */     boolean oldDistributable = this.distributable;
/* 1693 */     this.distributable = distributable;
/* 1694 */     this.support.firePropertyChange("distributable", oldDistributable, this.distributable);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDocBase()
/*      */   {
/* 1707 */     return this.docBase;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDocBase(String docBase)
/*      */   {
/* 1721 */     this.docBase = docBase;
/*      */   }
/*      */   
/*      */   public String getJ2EEApplication()
/*      */   {
/* 1726 */     return this.j2EEApplication;
/*      */   }
/*      */   
/*      */   public void setJ2EEApplication(String j2EEApplication) {
/* 1730 */     this.j2EEApplication = j2EEApplication;
/*      */   }
/*      */   
/*      */   public String getJ2EEServer() {
/* 1734 */     return this.j2EEServer;
/*      */   }
/*      */   
/*      */   public void setJ2EEServer(String j2EEServer) {
/* 1738 */     this.j2EEServer = j2EEServer;
/*      */   }
/*      */   
/*      */ 
/*      */   public Loader getLoader()
/*      */   {
/* 1744 */     Lock readLock = this.loaderLock.readLock();
/* 1745 */     readLock.lock();
/*      */     try {
/* 1747 */       return this.loader;
/*      */     } finally {
/* 1749 */       readLock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setLoader(Loader loader)
/*      */   {
/* 1756 */     Lock writeLock = this.loaderLock.writeLock();
/* 1757 */     writeLock.lock();
/* 1758 */     Loader oldLoader = null;
/*      */     try
/*      */     {
/* 1761 */       oldLoader = this.loader;
/* 1762 */       if (oldLoader == loader)
/*      */         return;
/* 1764 */       this.loader = loader;
/*      */       
/*      */ 
/* 1767 */       if ((getState().isAvailable()) && (oldLoader != null) && ((oldLoader instanceof Lifecycle))) {
/*      */         try
/*      */         {
/* 1770 */           ((Lifecycle)oldLoader).stop();
/*      */         } catch (LifecycleException e) {
/* 1772 */           log.error("StandardContext.setLoader: stop: ", e);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1777 */       if (loader != null)
/* 1778 */         loader.setContext(this);
/* 1779 */       if ((getState().isAvailable()) && (loader != null) && ((loader instanceof Lifecycle))) {
/*      */         try
/*      */         {
/* 1782 */           ((Lifecycle)loader).start();
/*      */         } catch (LifecycleException e) {
/* 1784 */           log.error("StandardContext.setLoader: start: ", e);
/*      */         }
/*      */       }
/*      */     } finally {
/* 1788 */       writeLock.unlock();
/*      */     }
/*      */     
/*      */ 
/* 1792 */     this.support.firePropertyChange("loader", oldLoader, loader);
/*      */   }
/*      */   
/*      */ 
/*      */   public Manager getManager()
/*      */   {
/* 1798 */     Lock readLock = this.managerLock.readLock();
/* 1799 */     readLock.lock();
/*      */     try {
/* 1801 */       return this.manager;
/*      */     } finally {
/* 1803 */       readLock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setManager(Manager manager)
/*      */   {
/* 1811 */     Lock writeLock = this.managerLock.writeLock();
/* 1812 */     writeLock.lock();
/* 1813 */     Manager oldManager = null;
/*      */     try
/*      */     {
/* 1816 */       oldManager = this.manager;
/* 1817 */       if (oldManager == manager)
/*      */         return;
/* 1819 */       this.manager = manager;
/*      */       
/*      */ 
/* 1822 */       if ((oldManager instanceof Lifecycle)) {
/*      */         try {
/* 1824 */           ((Lifecycle)oldManager).stop();
/* 1825 */           ((Lifecycle)oldManager).destroy();
/*      */         } catch (LifecycleException e) {
/* 1827 */           log.error("StandardContext.setManager: stop-destroy: ", e);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1832 */       if (manager != null) {
/* 1833 */         manager.setContext(this);
/*      */       }
/* 1835 */       if ((getState().isAvailable()) && ((manager instanceof Lifecycle))) {
/*      */         try {
/* 1837 */           ((Lifecycle)manager).start();
/*      */         } catch (LifecycleException e) {
/* 1839 */           log.error("StandardContext.setManager: start: ", e);
/*      */         }
/*      */       }
/*      */     } finally {
/* 1843 */       writeLock.unlock();
/*      */     }
/*      */     
/*      */ 
/* 1847 */     this.support.firePropertyChange("manager", oldManager, manager);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getIgnoreAnnotations()
/*      */   {
/* 1856 */     return this.ignoreAnnotations;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIgnoreAnnotations(boolean ignoreAnnotations)
/*      */   {
/* 1868 */     boolean oldIgnoreAnnotations = this.ignoreAnnotations;
/* 1869 */     this.ignoreAnnotations = ignoreAnnotations;
/* 1870 */     this.support.firePropertyChange("ignoreAnnotations", oldIgnoreAnnotations, this.ignoreAnnotations);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public LoginConfig getLoginConfig()
/*      */   {
/* 1881 */     return this.loginConfig;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLoginConfig(LoginConfig config)
/*      */   {
/* 1895 */     if (config == null) {
/* 1896 */       throw new IllegalArgumentException(sm.getString("standardContext.loginConfig.required"));
/*      */     }
/* 1898 */     String loginPage = config.getLoginPage();
/* 1899 */     if ((loginPage != null) && (!loginPage.startsWith("/"))) {
/* 1900 */       if (isServlet22()) {
/* 1901 */         if (log.isDebugEnabled()) {
/* 1902 */           log.debug(sm.getString("standardContext.loginConfig.loginWarning", new Object[] { loginPage }));
/*      */         }
/* 1904 */         config.setLoginPage("/" + loginPage);
/*      */       } else {
/* 1906 */         throw new IllegalArgumentException(sm.getString("standardContext.loginConfig.loginPage", new Object[] { loginPage }));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1911 */     String errorPage = config.getErrorPage();
/* 1912 */     if ((errorPage != null) && (!errorPage.startsWith("/"))) {
/* 1913 */       if (isServlet22()) {
/* 1914 */         if (log.isDebugEnabled()) {
/* 1915 */           log.debug(sm.getString("standardContext.loginConfig.errorWarning", new Object[] { errorPage }));
/*      */         }
/* 1917 */         config.setErrorPage("/" + errorPage);
/*      */       } else {
/* 1919 */         throw new IllegalArgumentException(sm.getString("standardContext.loginConfig.errorPage", new Object[] { errorPage }));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1926 */     LoginConfig oldLoginConfig = this.loginConfig;
/* 1927 */     this.loginConfig = config;
/* 1928 */     this.support.firePropertyChange("loginConfig", oldLoginConfig, this.loginConfig);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public NamingResourcesImpl getNamingResources()
/*      */   {
/* 1940 */     if (this.namingResources == null) {
/* 1941 */       setNamingResources(new NamingResourcesImpl());
/*      */     }
/* 1943 */     return this.namingResources;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNamingResources(NamingResourcesImpl namingResources)
/*      */   {
/* 1957 */     NamingResourcesImpl oldNamingResources = this.namingResources;
/* 1958 */     this.namingResources = namingResources;
/* 1959 */     if (namingResources != null) {
/* 1960 */       namingResources.setContainer(this);
/*      */     }
/* 1962 */     this.support.firePropertyChange("namingResources", oldNamingResources, this.namingResources);
/*      */     
/*      */ 
/* 1965 */     if ((getState() == LifecycleState.NEW) || (getState() == LifecycleState.INITIALIZING) || (getState() == LifecycleState.INITIALIZED))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1978 */       return;
/*      */     }
/*      */     
/* 1981 */     if (oldNamingResources != null) {
/*      */       try {
/* 1983 */         oldNamingResources.stop();
/* 1984 */         oldNamingResources.destroy();
/*      */       } catch (LifecycleException e) {
/* 1986 */         log.warn("standardContext.namingResource.destroy.fail", e);
/*      */       }
/*      */     }
/* 1989 */     if (namingResources != null) {
/*      */       try {
/* 1991 */         namingResources.init();
/* 1992 */         namingResources.start();
/*      */       } catch (LifecycleException e) {
/* 1994 */         log.warn("standardContext.namingResource.init.fail", e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPath()
/*      */   {
/* 2005 */     return this.path;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPath(String path)
/*      */   {
/* 2016 */     boolean invalid = false;
/* 2017 */     if ((path == null) || (path.equals("/"))) {
/* 2018 */       invalid = true;
/* 2019 */       this.path = "";
/* 2020 */     } else if (("".equals(path)) || (path.startsWith("/"))) {
/* 2021 */       this.path = path;
/*      */     } else {
/* 2023 */       invalid = true;
/* 2024 */       this.path = ("/" + path);
/*      */     }
/* 2026 */     if (this.path.endsWith("/")) {
/* 2027 */       invalid = true;
/* 2028 */       this.path = this.path.substring(0, this.path.length() - 1);
/*      */     }
/* 2030 */     if (invalid) {
/* 2031 */       log.warn(sm.getString("standardContext.pathInvalid", new Object[] { path, this.path }));
/*      */     }
/*      */     
/* 2034 */     this.encodedPath = URLEncoder.DEFAULT.encode(this.path);
/* 2035 */     if (getName() == null) {
/* 2036 */       setName(this.path);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPublicId()
/*      */   {
/* 2048 */     return this.publicId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPublicId(String publicId)
/*      */   {
/* 2062 */     if (log.isDebugEnabled()) {
/* 2063 */       log.debug("Setting deployment descriptor public ID to '" + publicId + "'");
/*      */     }
/*      */     
/* 2066 */     String oldPublicId = this.publicId;
/* 2067 */     this.publicId = publicId;
/* 2068 */     this.support.firePropertyChange("publicId", oldPublicId, publicId);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getReloadable()
/*      */   {
/* 2079 */     return this.reloadable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getOverride()
/*      */   {
/* 2090 */     return this.override;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getOriginalDocBase()
/*      */   {
/* 2102 */     return this.originalDocBase;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOriginalDocBase(String docBase)
/*      */   {
/* 2114 */     this.originalDocBase = docBase;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClassLoader getParentClassLoader()
/*      */   {
/* 2125 */     if (this.parentClassLoader != null)
/* 2126 */       return this.parentClassLoader;
/* 2127 */     if (getPrivileged())
/* 2128 */       return getClass().getClassLoader();
/* 2129 */     if (this.parent != null) {
/* 2130 */       return this.parent.getParentClassLoader();
/*      */     }
/* 2132 */     return ClassLoader.getSystemClassLoader();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getPrivileged()
/*      */   {
/* 2142 */     return this.privileged;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPrivileged(boolean privileged)
/*      */   {
/* 2155 */     boolean oldPrivileged = this.privileged;
/* 2156 */     this.privileged = privileged;
/* 2157 */     this.support.firePropertyChange("privileged", oldPrivileged, this.privileged);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReloadable(boolean reloadable)
/*      */   {
/* 2172 */     boolean oldReloadable = this.reloadable;
/* 2173 */     this.reloadable = reloadable;
/* 2174 */     this.support.firePropertyChange("reloadable", oldReloadable, this.reloadable);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOverride(boolean override)
/*      */   {
/* 2189 */     boolean oldOverride = this.override;
/* 2190 */     this.override = override;
/* 2191 */     this.support.firePropertyChange("override", oldOverride, this.override);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReplaceWelcomeFiles(boolean replaceWelcomeFiles)
/*      */   {
/* 2205 */     boolean oldReplaceWelcomeFiles = this.replaceWelcomeFiles;
/* 2206 */     this.replaceWelcomeFiles = replaceWelcomeFiles;
/* 2207 */     this.support.firePropertyChange("replaceWelcomeFiles", oldReplaceWelcomeFiles, this.replaceWelcomeFiles);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ServletContext getServletContext()
/*      */   {
/* 2220 */     if (this.context == null) {
/* 2221 */       this.context = new ApplicationContext(this);
/* 2222 */       if (this.altDDName != null)
/* 2223 */         this.context.setAttribute("org.apache.catalina.deploy.alt_dd", this.altDDName);
/*      */     }
/* 2225 */     return this.context.getFacade();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSessionTimeout()
/*      */   {
/* 2237 */     return this.sessionTimeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionTimeout(int timeout)
/*      */   {
/* 2251 */     int oldSessionTimeout = this.sessionTimeout;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2257 */     this.sessionTimeout = (timeout == 0 ? -1 : timeout);
/* 2258 */     this.support.firePropertyChange("sessionTimeout", oldSessionTimeout, this.sessionTimeout);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getSwallowOutput()
/*      */   {
/* 2271 */     return this.swallowOutput;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSwallowOutput(boolean swallowOutput)
/*      */   {
/* 2286 */     boolean oldSwallowOutput = this.swallowOutput;
/* 2287 */     this.swallowOutput = swallowOutput;
/* 2288 */     this.support.firePropertyChange("swallowOutput", oldSwallowOutput, this.swallowOutput);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getUnloadDelay()
/*      */   {
/* 2300 */     return this.unloadDelay;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUnloadDelay(long unloadDelay)
/*      */   {
/* 2315 */     long oldUnloadDelay = this.unloadDelay;
/* 2316 */     this.unloadDelay = unloadDelay;
/* 2317 */     this.support.firePropertyChange("unloadDelay", Long.valueOf(oldUnloadDelay), Long.valueOf(this.unloadDelay));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUnpackWAR()
/*      */   {
/* 2329 */     return this.unpackWAR;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUnpackWAR(boolean unpackWAR)
/*      */   {
/* 2341 */     this.unpackWAR = unpackWAR;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getCopyXML()
/*      */   {
/* 2354 */     return this.copyXML;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCopyXML(boolean copyXML)
/*      */   {
/* 2365 */     this.copyXML = copyXML;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getWrapperClass()
/*      */   {
/* 2376 */     return this.wrapperClassName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWrapperClass(String wrapperClassName)
/*      */   {
/* 2393 */     this.wrapperClassName = wrapperClassName;
/*      */     try
/*      */     {
/* 2396 */       this.wrapperClass = Class.forName(wrapperClassName);
/* 2397 */       if (!StandardWrapper.class.isAssignableFrom(this.wrapperClass)) {
/* 2398 */         throw new IllegalArgumentException(sm.getString("standardContext.invalidWrapperClass", new Object[] { wrapperClassName }));
/*      */       }
/*      */     }
/*      */     catch (ClassNotFoundException cnfe)
/*      */     {
/* 2403 */       throw new IllegalArgumentException(cnfe.getMessage());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public WebResourceRoot getResources()
/*      */   {
/* 2410 */     Lock readLock = this.resourcesLock.readLock();
/* 2411 */     readLock.lock();
/*      */     try {
/* 2413 */       return this.resources;
/*      */     } finally {
/* 2415 */       readLock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setResources(WebResourceRoot resources)
/*      */   {
/* 2423 */     Lock writeLock = this.resourcesLock.writeLock();
/* 2424 */     writeLock.lock();
/* 2425 */     WebResourceRoot oldResources = null;
/*      */     try {
/* 2427 */       if (getState().isAvailable()) {
/* 2428 */         throw new IllegalStateException(sm.getString("standardContext.resourcesStart"));
/*      */       }
/*      */       
/*      */ 
/* 2432 */       oldResources = this.resources;
/* 2433 */       if (oldResources == resources) {
/*      */         return;
/*      */       }
/* 2436 */       this.resources = resources;
/* 2437 */       if (oldResources != null) {
/* 2438 */         oldResources.setContext(null);
/*      */       }
/* 2440 */       if (resources != null) {
/* 2441 */         resources.setContext(this);
/*      */       }
/*      */       
/* 2444 */       this.support.firePropertyChange("resources", oldResources, resources);
/*      */     }
/*      */     finally {
/* 2447 */       writeLock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public JspConfigDescriptor getJspConfigDescriptor()
/*      */   {
/* 2454 */     return this.jspConfigDescriptor;
/*      */   }
/*      */   
/*      */   public void setJspConfigDescriptor(JspConfigDescriptor descriptor)
/*      */   {
/* 2459 */     this.jspConfigDescriptor = descriptor;
/*      */   }
/*      */   
/*      */   public ThreadBindingListener getThreadBindingListener()
/*      */   {
/* 2464 */     return this.threadBindingListener;
/*      */   }
/*      */   
/*      */   public void setThreadBindingListener(ThreadBindingListener threadBindingListener)
/*      */   {
/* 2469 */     this.threadBindingListener = threadBindingListener;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getJndiExceptionOnFailedWrite()
/*      */   {
/* 2480 */     return this.jndiExceptionOnFailedWrite;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setJndiExceptionOnFailedWrite(boolean jndiExceptionOnFailedWrite)
/*      */   {
/* 2492 */     this.jndiExceptionOnFailedWrite = jndiExceptionOnFailedWrite;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCharsetMapperClass()
/*      */   {
/* 2501 */     return this.charsetMapperClass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCharsetMapperClass(String mapper)
/*      */   {
/* 2513 */     String oldCharsetMapperClass = this.charsetMapperClass;
/* 2514 */     this.charsetMapperClass = mapper;
/* 2515 */     this.support.firePropertyChange("charsetMapperClass", oldCharsetMapperClass, this.charsetMapperClass);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getWorkPath()
/*      */   {
/* 2528 */     if (getWorkDir() == null) {
/* 2529 */       return null;
/*      */     }
/* 2531 */     File workDir = new File(getWorkDir());
/* 2532 */     if (!workDir.isAbsolute()) {
/*      */       try {
/* 2534 */         workDir = new File(getCatalinaBase().getCanonicalFile(), getWorkDir());
/*      */       }
/*      */       catch (IOException e) {
/* 2537 */         log.warn(sm.getString("standardContext.workPath", new Object[] { getName() }), e);
/*      */       }
/*      */     }
/*      */     
/* 2541 */     return workDir.getAbsolutePath();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getWorkDir()
/*      */   {
/* 2549 */     return this.workDir;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWorkDir(String workDir)
/*      */   {
/* 2561 */     this.workDir = workDir;
/*      */     
/* 2563 */     if (getState().isAvailable()) {
/* 2564 */       postWorkDirectory();
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean getClearReferencesRmiTargets()
/*      */   {
/* 2570 */     return this.clearReferencesRmiTargets;
/*      */   }
/*      */   
/*      */   public void setClearReferencesRmiTargets(boolean clearReferencesRmiTargets)
/*      */   {
/* 2575 */     boolean oldClearReferencesRmiTargets = this.clearReferencesRmiTargets;
/* 2576 */     this.clearReferencesRmiTargets = clearReferencesRmiTargets;
/* 2577 */     this.support.firePropertyChange("clearReferencesRmiTargets", oldClearReferencesRmiTargets, this.clearReferencesRmiTargets);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getClearReferencesStopThreads()
/*      */   {
/* 2587 */     return this.clearReferencesStopThreads;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClearReferencesStopThreads(boolean clearReferencesStopThreads)
/*      */   {
/* 2600 */     boolean oldClearReferencesStopThreads = this.clearReferencesStopThreads;
/* 2601 */     this.clearReferencesStopThreads = clearReferencesStopThreads;
/* 2602 */     this.support.firePropertyChange("clearReferencesStopThreads", oldClearReferencesStopThreads, this.clearReferencesStopThreads);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getClearReferencesStopTimerThreads()
/*      */   {
/* 2613 */     return this.clearReferencesStopTimerThreads;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClearReferencesStopTimerThreads(boolean clearReferencesStopTimerThreads)
/*      */   {
/* 2625 */     boolean oldClearReferencesStopTimerThreads = this.clearReferencesStopTimerThreads;
/*      */     
/* 2627 */     this.clearReferencesStopTimerThreads = clearReferencesStopTimerThreads;
/* 2628 */     this.support.firePropertyChange("clearReferencesStopTimerThreads", oldClearReferencesStopTimerThreads, this.clearReferencesStopTimerThreads);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getClearReferencesHttpClientKeepAliveThread()
/*      */   {
/* 2639 */     return this.clearReferencesHttpClientKeepAliveThread;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClearReferencesHttpClientKeepAliveThread(boolean clearReferencesHttpClientKeepAliveThread)
/*      */   {
/* 2651 */     this.clearReferencesHttpClientKeepAliveThread = clearReferencesHttpClientKeepAliveThread;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getRenewThreadsWhenStoppingContext()
/*      */   {
/* 2657 */     return this.renewThreadsWhenStoppingContext;
/*      */   }
/*      */   
/*      */   public void setRenewThreadsWhenStoppingContext(boolean renewThreadsWhenStoppingContext)
/*      */   {
/* 2662 */     boolean oldRenewThreadsWhenStoppingContext = this.renewThreadsWhenStoppingContext;
/*      */     
/* 2664 */     this.renewThreadsWhenStoppingContext = renewThreadsWhenStoppingContext;
/* 2665 */     this.support.firePropertyChange("renewThreadsWhenStoppingContext", oldRenewThreadsWhenStoppingContext, this.renewThreadsWhenStoppingContext);
/*      */   }
/*      */   
/*      */ 
/*      */   public Boolean getFailCtxIfServletStartFails()
/*      */   {
/* 2671 */     return this.failCtxIfServletStartFails;
/*      */   }
/*      */   
/*      */   public void setFailCtxIfServletStartFails(Boolean failCtxIfServletStartFails)
/*      */   {
/* 2676 */     Boolean oldFailCtxIfServletStartFails = this.failCtxIfServletStartFails;
/* 2677 */     this.failCtxIfServletStartFails = failCtxIfServletStartFails;
/* 2678 */     this.support.firePropertyChange("failCtxIfServletStartFails", oldFailCtxIfServletStartFails, failCtxIfServletStartFails);
/*      */   }
/*      */   
/*      */ 
/*      */   protected boolean getComputedFailCtxIfServletStartFails()
/*      */   {
/* 2684 */     if (this.failCtxIfServletStartFails != null) {
/* 2685 */       return this.failCtxIfServletStartFails.booleanValue();
/*      */     }
/*      */     
/* 2688 */     if ((getParent() instanceof StandardHost)) {
/* 2689 */       return ((StandardHost)getParent()).isFailCtxIfServletStartFails();
/*      */     }
/*      */     
/* 2692 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addApplicationListener(String listener)
/*      */   {
/* 2706 */     synchronized (this.applicationListenersLock) {
/* 2707 */       String[] results = new String[this.applicationListeners.length + 1];
/* 2708 */       for (int i = 0; i < this.applicationListeners.length; i++) {
/* 2709 */         if (listener.equals(this.applicationListeners[i])) {
/* 2710 */           log.info(sm.getString("standardContext.duplicateListener", new Object[] { listener }));
/* 2711 */           return;
/*      */         }
/* 2713 */         results[i] = this.applicationListeners[i];
/*      */       }
/* 2715 */       results[this.applicationListeners.length] = listener;
/* 2716 */       this.applicationListeners = results;
/*      */     }
/* 2718 */     fireContainerEvent("addApplicationListener", listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addApplicationParameter(ApplicationParameter parameter)
/*      */   {
/* 2732 */     synchronized (this.applicationParametersLock) {
/* 2733 */       String newName = parameter.getName();
/* 2734 */       for (ApplicationParameter p : this.applicationParameters) {
/* 2735 */         if ((newName.equals(p.getName())) && (!p.getOverride()))
/* 2736 */           return;
/*      */       }
/* 2738 */       ApplicationParameter[] results = (ApplicationParameter[])Arrays.copyOf(this.applicationParameters, this.applicationParameters.length + 1);
/*      */       
/* 2740 */       results[this.applicationParameters.length] = parameter;
/* 2741 */       this.applicationParameters = results;
/*      */     }
/* 2743 */     fireContainerEvent("addApplicationParameter", parameter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addChild(Container child)
/*      */   {
/* 2761 */     Wrapper oldJspServlet = null;
/*      */     
/* 2763 */     if (!(child instanceof Wrapper)) {
/* 2764 */       throw new IllegalArgumentException(sm.getString("standardContext.notWrapper"));
/*      */     }
/*      */     
/*      */ 
/* 2768 */     boolean isJspServlet = "jsp".equals(child.getName());
/*      */     
/*      */ 
/* 2771 */     if (isJspServlet) {
/* 2772 */       oldJspServlet = (Wrapper)findChild("jsp");
/* 2773 */       if (oldJspServlet != null) {
/* 2774 */         removeChild(oldJspServlet);
/*      */       }
/*      */     }
/*      */     
/* 2778 */     super.addChild(child);
/*      */     
/* 2780 */     if ((isJspServlet) && (oldJspServlet != null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2785 */       String[] jspMappings = oldJspServlet.findMappings();
/* 2786 */       for (int i = 0; (jspMappings != null) && (i < jspMappings.length); i++) {
/* 2787 */         addServletMapping(jspMappings[i], child.getName());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addConstraint(SecurityConstraint constraint)
/*      */   {
/* 2802 */     SecurityCollection[] collections = constraint.findCollections();
/* 2803 */     for (int i = 0; i < collections.length; i++) {
/* 2804 */       String[] patterns = collections[i].findPatterns();
/* 2805 */       for (int j = 0; j < patterns.length; j++) {
/* 2806 */         patterns[j] = adjustURLPattern(patterns[j]);
/* 2807 */         if (!validateURLPattern(patterns[j])) {
/* 2808 */           throw new IllegalArgumentException(sm.getString("standardContext.securityConstraint.pattern", new Object[] { patterns[j] }));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 2813 */       if ((collections[i].findMethods().length > 0) && (collections[i].findOmittedMethods().length > 0))
/*      */       {
/* 2815 */         throw new IllegalArgumentException(sm.getString("standardContext.securityConstraint.mixHttpMethod"));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2821 */     synchronized (this.constraintsLock) {
/* 2822 */       SecurityConstraint[] results = new SecurityConstraint[this.constraints.length + 1];
/*      */       
/* 2824 */       for (int i = 0; i < this.constraints.length; i++)
/* 2825 */         results[i] = this.constraints[i];
/* 2826 */       results[this.constraints.length] = constraint;
/* 2827 */       this.constraints = results;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addErrorPage(ErrorPage errorPage)
/*      */   {
/* 2842 */     if (errorPage == null) {
/* 2843 */       throw new IllegalArgumentException(sm.getString("standardContext.errorPage.required"));
/*      */     }
/* 2845 */     String location = errorPage.getLocation();
/* 2846 */     if ((location != null) && (!location.startsWith("/"))) {
/* 2847 */       if (isServlet22()) {
/* 2848 */         if (log.isDebugEnabled()) {
/* 2849 */           log.debug(sm.getString("standardContext.errorPage.warning", new Object[] { location }));
/*      */         }
/* 2851 */         errorPage.setLocation("/" + location);
/*      */       } else {
/* 2853 */         throw new IllegalArgumentException(sm.getString("standardContext.errorPage.error", new Object[] { location }));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2860 */     String exceptionType = errorPage.getExceptionType();
/* 2861 */     if (exceptionType != null) {
/* 2862 */       synchronized (this.exceptionPages) {
/* 2863 */         this.exceptionPages.put(exceptionType, errorPage);
/*      */       }
/*      */     } else {
/* 2866 */       synchronized (this.statusPages) {
/* 2867 */         this.statusPages.put(Integer.valueOf(errorPage.getErrorCode()), errorPage);
/*      */       }
/*      */     }
/*      */     
/* 2871 */     fireContainerEvent("addErrorPage", errorPage);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addFilterDef(FilterDef filterDef)
/*      */   {
/* 2884 */     synchronized (this.filterDefs) {
/* 2885 */       this.filterDefs.put(filterDef.getFilterName(), filterDef);
/*      */     }
/* 2887 */     fireContainerEvent("addFilterDef", filterDef);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addFilterMap(FilterMap filterMap)
/*      */   {
/* 2904 */     validateFilterMap(filterMap);
/*      */     
/* 2906 */     this.filterMaps.add(filterMap);
/* 2907 */     fireContainerEvent("addFilterMap", filterMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addFilterMapBefore(FilterMap filterMap)
/*      */   {
/* 2923 */     validateFilterMap(filterMap);
/*      */     
/* 2925 */     this.filterMaps.addBefore(filterMap);
/* 2926 */     fireContainerEvent("addFilterMap", filterMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void validateFilterMap(FilterMap filterMap)
/*      */   {
/* 2937 */     String filterName = filterMap.getFilterName();
/* 2938 */     String[] servletNames = filterMap.getServletNames();
/* 2939 */     String[] urlPatterns = filterMap.getURLPatterns();
/* 2940 */     if (findFilterDef(filterName) == null) {
/* 2941 */       throw new IllegalArgumentException(sm.getString("standardContext.filterMap.name", new Object[] { filterName }));
/*      */     }
/*      */     
/* 2944 */     if ((!filterMap.getMatchAllServletNames()) && (!filterMap.getMatchAllUrlPatterns()) && (servletNames.length == 0) && (urlPatterns.length == 0))
/*      */     {
/*      */ 
/* 2947 */       throw new IllegalArgumentException(sm.getString("standardContext.filterMap.either"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2955 */     for (int i = 0; i < urlPatterns.length; i++) {
/* 2956 */       if (!validateURLPattern(urlPatterns[i])) {
/* 2957 */         throw new IllegalArgumentException(sm.getString("standardContext.filterMap.pattern", new Object[] { urlPatterns[i] }));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addLocaleEncodingMappingParameter(String locale, String encoding)
/*      */   {
/* 2973 */     getCharsetMapper().addCharsetMappingFromDeploymentDescriptor(locale, encoding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addMessageDestination(MessageDestination md)
/*      */   {
/* 2984 */     synchronized (this.messageDestinations) {
/* 2985 */       this.messageDestinations.put(md.getName(), md);
/*      */     }
/* 2987 */     fireContainerEvent("addMessageDestination", md.getName());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addMessageDestinationRef(MessageDestinationRef mdr)
/*      */   {
/* 3000 */     this.namingResources.addMessageDestinationRef(mdr);
/* 3001 */     fireContainerEvent("addMessageDestinationRef", mdr.getName());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addMimeMapping(String extension, String mimeType)
/*      */   {
/* 3016 */     synchronized (this.mimeMappings) {
/* 3017 */       this.mimeMappings.put(extension.toLowerCase(Locale.ENGLISH), mimeType);
/*      */     }
/* 3019 */     fireContainerEvent("addMimeMapping", extension);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addParameter(String name, String value)
/*      */   {
/* 3037 */     if ((name == null) || (value == null)) {
/* 3038 */       throw new IllegalArgumentException(sm.getString("standardContext.parameter.required"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3043 */     String oldValue = (String)this.parameters.putIfAbsent(name, value);
/*      */     
/* 3045 */     if (oldValue != null) {
/* 3046 */       throw new IllegalArgumentException(sm.getString("standardContext.parameter.duplicate", new Object[] { name }));
/*      */     }
/*      */     
/*      */ 
/* 3050 */     fireContainerEvent("addParameter", name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addRoleMapping(String role, String link)
/*      */   {
/* 3063 */     synchronized (this.roleMappings) {
/* 3064 */       this.roleMappings.put(role, link);
/*      */     }
/* 3066 */     fireContainerEvent("addRoleMapping", role);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addSecurityRole(String role)
/*      */   {
/* 3079 */     synchronized (this.securityRolesLock) {
/* 3080 */       String[] results = new String[this.securityRoles.length + 1];
/* 3081 */       for (int i = 0; i < this.securityRoles.length; i++)
/* 3082 */         results[i] = this.securityRoles[i];
/* 3083 */       results[this.securityRoles.length] = role;
/* 3084 */       this.securityRoles = results;
/*      */     }
/* 3086 */     fireContainerEvent("addSecurityRole", role);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addServletMapping(String pattern, String name)
/*      */   {
/* 3103 */     addServletMapping(pattern, name, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addServletMapping(String pattern, String name, boolean jspWildCard)
/*      */   {
/* 3123 */     if (findChild(name) == null) {
/* 3124 */       throw new IllegalArgumentException(sm.getString("standardContext.servletMap.name", new Object[] { name }));
/*      */     }
/* 3126 */     String decodedPattern = adjustURLPattern(UDecoder.URLDecode(pattern));
/* 3127 */     if (!validateURLPattern(decodedPattern)) {
/* 3128 */       throw new IllegalArgumentException(sm.getString("standardContext.servletMap.pattern", new Object[] { decodedPattern }));
/*      */     }
/*      */     
/*      */ 
/* 3132 */     synchronized (this.servletMappingsLock) {
/* 3133 */       String name2 = (String)this.servletMappings.get(decodedPattern);
/* 3134 */       if (name2 != null)
/*      */       {
/* 3136 */         Wrapper wrapper = (Wrapper)findChild(name2);
/* 3137 */         wrapper.removeMapping(decodedPattern);
/*      */       }
/* 3139 */       this.servletMappings.put(decodedPattern, name);
/*      */     }
/* 3141 */     Wrapper wrapper = (Wrapper)findChild(name);
/* 3142 */     wrapper.addMapping(decodedPattern);
/*      */     
/* 3144 */     fireContainerEvent("addServletMapping", decodedPattern);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addWatchedResource(String name)
/*      */   {
/* 3156 */     synchronized (this.watchedResourcesLock) {
/* 3157 */       String[] results = new String[this.watchedResources.length + 1];
/* 3158 */       for (int i = 0; i < this.watchedResources.length; i++)
/* 3159 */         results[i] = this.watchedResources[i];
/* 3160 */       results[this.watchedResources.length] = name;
/* 3161 */       this.watchedResources = results;
/*      */     }
/* 3163 */     fireContainerEvent("addWatchedResource", name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addWelcomeFile(String name)
/*      */   {
/* 3175 */     synchronized (this.welcomeFilesLock)
/*      */     {
/*      */ 
/* 3178 */       if (this.replaceWelcomeFiles) {
/* 3179 */         fireContainerEvent("clearWelcomeFiles", null);
/* 3180 */         this.welcomeFiles = new String[0];
/* 3181 */         setReplaceWelcomeFiles(false);
/*      */       }
/* 3183 */       String[] results = new String[this.welcomeFiles.length + 1];
/* 3184 */       for (int i = 0; i < this.welcomeFiles.length; i++)
/* 3185 */         results[i] = this.welcomeFiles[i];
/* 3186 */       results[this.welcomeFiles.length] = name;
/* 3187 */       this.welcomeFiles = results;
/*      */     }
/* 3189 */     if (getState().equals(LifecycleState.STARTED)) {
/* 3190 */       fireContainerEvent("addWelcomeFile", name);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addWrapperLifecycle(String listener)
/*      */   {
/* 3203 */     synchronized (this.wrapperLifecyclesLock) {
/* 3204 */       String[] results = new String[this.wrapperLifecycles.length + 1];
/* 3205 */       for (int i = 0; i < this.wrapperLifecycles.length; i++)
/* 3206 */         results[i] = this.wrapperLifecycles[i];
/* 3207 */       results[this.wrapperLifecycles.length] = listener;
/* 3208 */       this.wrapperLifecycles = results;
/*      */     }
/* 3210 */     fireContainerEvent("addWrapperLifecycle", listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addWrapperListener(String listener)
/*      */   {
/* 3224 */     synchronized (this.wrapperListenersLock) {
/* 3225 */       String[] results = new String[this.wrapperListeners.length + 1];
/* 3226 */       for (int i = 0; i < this.wrapperListeners.length; i++)
/* 3227 */         results[i] = this.wrapperListeners[i];
/* 3228 */       results[this.wrapperListeners.length] = listener;
/* 3229 */       this.wrapperListeners = results;
/*      */     }
/* 3231 */     fireContainerEvent("addWrapperListener", listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Wrapper createWrapper()
/*      */   {
/* 3245 */     Wrapper wrapper = null;
/* 3246 */     if (this.wrapperClass != null) {
/*      */       try {
/* 3248 */         wrapper = (Wrapper)this.wrapperClass.newInstance();
/*      */       } catch (Throwable t) {
/* 3250 */         ExceptionUtils.handleThrowable(t);
/* 3251 */         log.error("createWrapper", t);
/* 3252 */         return null;
/*      */       }
/*      */     } else {
/* 3255 */       wrapper = new StandardWrapper();
/*      */     }
/*      */     
/* 3258 */     synchronized (this.wrapperLifecyclesLock) {
/* 3259 */       for (int i = 0; i < this.wrapperLifecycles.length; i++) {
/*      */         try {
/* 3261 */           Class<?> clazz = Class.forName(this.wrapperLifecycles[i]);
/* 3262 */           LifecycleListener listener = (LifecycleListener)clazz.newInstance();
/*      */           
/* 3264 */           wrapper.addLifecycleListener(listener);
/*      */         } catch (Throwable t) {
/* 3266 */           ExceptionUtils.handleThrowable(t);
/* 3267 */           log.error("createWrapper", t);
/* 3268 */           return null;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3273 */     synchronized (this.wrapperListenersLock) {
/* 3274 */       for (int i = 0; i < this.wrapperListeners.length; i++) {
/*      */         try {
/* 3276 */           Class<?> clazz = Class.forName(this.wrapperListeners[i]);
/* 3277 */           ContainerListener listener = (ContainerListener)clazz.newInstance();
/*      */           
/* 3279 */           wrapper.addContainerListener(listener);
/*      */         } catch (Throwable t) {
/* 3281 */           ExceptionUtils.handleThrowable(t);
/* 3282 */           log.error("createWrapper", t);
/* 3283 */           return null;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3288 */     return wrapper;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] findApplicationListeners()
/*      */   {
/* 3299 */     return this.applicationListeners;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public ApplicationParameter[] findApplicationParameters()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 24	org/apache/catalina/core/StandardContext:applicationParametersLock	Ljava/lang/Object;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 23	org/apache/catalina/core/StandardContext:applicationParameters	[Lorg/apache/tomcat/util/descriptor/web/ApplicationParameter;
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: areturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3309	-> byte code offset #0
/*      */     //   Java source line #3310	-> byte code offset #7
/*      */     //   Java source line #3311	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	StandardContext
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   public SecurityConstraint[] findConstraints()
/*      */   {
/* 3323 */     return this.constraints;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ErrorPage findErrorPage(int errorCode)
/*      */   {
/* 3336 */     return (ErrorPage)this.statusPages.get(Integer.valueOf(errorCode));
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public ErrorPage findErrorPage(String exceptionType)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 46	org/apache/catalina/core/StandardContext:exceptionPages	Ljava/util/HashMap;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 46	org/apache/catalina/core/StandardContext:exceptionPages	Ljava/util/HashMap;
/*      */     //   11: aload_1
/*      */     //   12: invokevirtual 408	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   15: checkcast 426	org/apache/tomcat/util/descriptor/web/ErrorPage
/*      */     //   18: aload_2
/*      */     //   19: monitorexit
/*      */     //   20: areturn
/*      */     //   21: astore_3
/*      */     //   22: aload_2
/*      */     //   23: monitorexit
/*      */     //   24: aload_3
/*      */     //   25: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3349	-> byte code offset #0
/*      */     //   Java source line #3350	-> byte code offset #7
/*      */     //   Java source line #3351	-> byte code offset #21
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	26	0	this	StandardContext
/*      */     //   0	26	1	exceptionType	String
/*      */     //   5	18	2	Ljava/lang/Object;	Object
/*      */     //   21	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	20	21	finally
/*      */     //   21	24	21	finally
/*      */   }
/*      */   
/*      */   public ErrorPage[] findErrorPages()
/*      */   {
/* 3363 */     synchronized (this.exceptionPages) {
/* 3364 */       synchronized (this.statusPages) {
/* 3365 */         ErrorPage[] results1 = new ErrorPage[this.exceptionPages.size()];
/* 3366 */         results1 = (ErrorPage[])this.exceptionPages.values().toArray(results1);
/* 3367 */         ErrorPage[] results2 = new ErrorPage[this.statusPages.size()];
/* 3368 */         results2 = (ErrorPage[])this.statusPages.values().toArray(results2);
/* 3369 */         ErrorPage[] results = new ErrorPage[results1.length + results2.length];
/*      */         
/* 3371 */         for (int i = 0; i < results1.length; i++)
/* 3372 */           results[i] = results1[i];
/* 3373 */         for (int i = results1.length; i < results.length; i++)
/* 3374 */           results[i] = results2[(i - results1.length)];
/* 3375 */         return results;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public FilterDef findFilterDef(String filterName)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 48	org/apache/catalina/core/StandardContext:filterDefs	Ljava/util/HashMap;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 48	org/apache/catalina/core/StandardContext:filterDefs	Ljava/util/HashMap;
/*      */     //   11: aload_1
/*      */     //   12: invokevirtual 408	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   15: checkcast 431	org/apache/tomcat/util/descriptor/web/FilterDef
/*      */     //   18: aload_2
/*      */     //   19: monitorexit
/*      */     //   20: areturn
/*      */     //   21: astore_3
/*      */     //   22: aload_2
/*      */     //   23: monitorexit
/*      */     //   24: aload_3
/*      */     //   25: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3391	-> byte code offset #0
/*      */     //   Java source line #3392	-> byte code offset #7
/*      */     //   Java source line #3393	-> byte code offset #21
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	26	0	this	StandardContext
/*      */     //   0	26	1	filterName	String
/*      */     //   5	18	2	Ljava/lang/Object;	Object
/*      */     //   21	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	20	21	finally
/*      */     //   21	24	21	finally
/*      */   }
/*      */   
/*      */   public FilterDef[] findFilterDefs()
/*      */   {
/* 3404 */     synchronized (this.filterDefs) {
/* 3405 */       FilterDef[] results = new FilterDef[this.filterDefs.size()];
/* 3406 */       return (FilterDef[])this.filterDefs.values().toArray(results);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FilterMap[] findFilterMaps()
/*      */   {
/* 3417 */     return this.filterMaps.asArray();
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public MessageDestination findMessageDestination(String name)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 62	org/apache/catalina/core/StandardContext:messageDestinations	Ljava/util/HashMap;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 62	org/apache/catalina/core/StandardContext:messageDestinations	Ljava/util/HashMap;
/*      */     //   11: aload_1
/*      */     //   12: invokevirtual 408	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   15: checkcast 434	org/apache/tomcat/util/descriptor/web/MessageDestination
/*      */     //   18: aload_2
/*      */     //   19: monitorexit
/*      */     //   20: areturn
/*      */     //   21: astore_3
/*      */     //   22: aload_2
/*      */     //   23: monitorexit
/*      */     //   24: aload_3
/*      */     //   25: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3429	-> byte code offset #0
/*      */     //   Java source line #3430	-> byte code offset #7
/*      */     //   Java source line #3431	-> byte code offset #21
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	26	0	this	StandardContext
/*      */     //   0	26	1	name	String
/*      */     //   5	18	2	Ljava/lang/Object;	Object
/*      */     //   21	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	20	21	finally
/*      */     //   21	24	21	finally
/*      */   }
/*      */   
/*      */   public MessageDestination[] findMessageDestinations()
/*      */   {
/* 3443 */     synchronized (this.messageDestinations) {
/* 3444 */       MessageDestination[] results = new MessageDestination[this.messageDestinations.size()];
/*      */       
/* 3446 */       return (MessageDestination[])this.messageDestinations.values().toArray(results);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MessageDestinationRef findMessageDestinationRef(String name)
/*      */   {
/* 3460 */     return this.namingResources.findMessageDestinationRef(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MessageDestinationRef[] findMessageDestinationRefs()
/*      */   {
/* 3472 */     return this.namingResources.findMessageDestinationRefs();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String findMimeMapping(String extension)
/*      */   {
/* 3486 */     return (String)this.mimeMappings.get(extension.toLowerCase(Locale.ENGLISH));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] findMimeMappings()
/*      */   {
/* 3498 */     synchronized (this.mimeMappings) {
/* 3499 */       String[] results = new String[this.mimeMappings.size()];
/* 3500 */       return (String[])this.mimeMappings.keySet().toArray(results);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String findParameter(String name)
/*      */   {
/* 3515 */     return (String)this.parameters.get(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] findParameters()
/*      */   {
/* 3526 */     List<String> parameterNames = new ArrayList(this.parameters.size());
/* 3527 */     parameterNames.addAll(this.parameters.keySet());
/* 3528 */     return (String[])parameterNames.toArray(new String[parameterNames.size()]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String findRoleMapping(String role)
/*      */   {
/* 3543 */     String realRole = null;
/* 3544 */     synchronized (this.roleMappings) {
/* 3545 */       realRole = (String)this.roleMappings.get(role);
/*      */     }
/* 3547 */     if (realRole != null) {
/* 3548 */       return realRole;
/*      */     }
/* 3550 */     return role;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean findSecurityRole(String role)
/*      */   {
/* 3564 */     synchronized (this.securityRolesLock) {
/* 3565 */       for (int i = 0; i < this.securityRoles.length; i++) {
/* 3566 */         if (role.equals(this.securityRoles[i]))
/* 3567 */           return true;
/*      */       }
/*      */     }
/* 3570 */     return false;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public String[] findSecurityRoles()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 78	org/apache/catalina/core/StandardContext:securityRolesLock	Ljava/lang/Object;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 77	org/apache/catalina/core/StandardContext:securityRoles	[Ljava/lang/String;
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: areturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3582	-> byte code offset #0
/*      */     //   Java source line #3583	-> byte code offset #7
/*      */     //   Java source line #3584	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	StandardContext
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public String findServletMapping(String pattern)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 80	org/apache/catalina/core/StandardContext:servletMappingsLock	Ljava/lang/Object;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 79	org/apache/catalina/core/StandardContext:servletMappings	Ljava/util/HashMap;
/*      */     //   11: aload_1
/*      */     //   12: invokevirtual 408	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   15: checkcast 7	java/lang/String
/*      */     //   18: aload_2
/*      */     //   19: monitorexit
/*      */     //   20: areturn
/*      */     //   21: astore_3
/*      */     //   22: aload_2
/*      */     //   23: monitorexit
/*      */     //   24: aload_3
/*      */     //   25: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3598	-> byte code offset #0
/*      */     //   Java source line #3599	-> byte code offset #7
/*      */     //   Java source line #3600	-> byte code offset #21
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	26	0	this	StandardContext
/*      */     //   0	26	1	pattern	String
/*      */     //   5	18	2	Ljava/lang/Object;	Object
/*      */     //   21	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	20	21	finally
/*      */     //   21	24	21	finally
/*      */   }
/*      */   
/*      */   public String[] findServletMappings()
/*      */   {
/* 3612 */     synchronized (this.servletMappingsLock) {
/* 3613 */       String[] results = new String[this.servletMappings.size()];
/* 3614 */       return (String[])this.servletMappings.keySet().toArray(results);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String findStatusPage(int status)
/*      */   {
/* 3630 */     ErrorPage errorPage = (ErrorPage)this.statusPages.get(Integer.valueOf(status));
/* 3631 */     if (errorPage != null) {
/* 3632 */       return errorPage.getLocation();
/*      */     }
/* 3634 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] findStatusPages()
/*      */   {
/* 3647 */     synchronized (this.statusPages) {
/* 3648 */       int[] results = new int[this.statusPages.size()];
/* 3649 */       Iterator<Integer> elements = this.statusPages.keySet().iterator();
/* 3650 */       int i = 0;
/* 3651 */       while (elements.hasNext())
/* 3652 */         results[(i++)] = ((Integer)elements.next()).intValue();
/* 3653 */       return results;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean findWelcomeFile(String name)
/*      */   {
/* 3668 */     synchronized (this.welcomeFilesLock) {
/* 3669 */       for (int i = 0; i < this.welcomeFiles.length; i++) {
/* 3670 */         if (name.equals(this.welcomeFiles[i]))
/* 3671 */           return true;
/*      */       }
/*      */     }
/* 3674 */     return false;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public String[] findWatchedResources()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 91	org/apache/catalina/core/StandardContext:watchedResourcesLock	Ljava/lang/Object;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 90	org/apache/catalina/core/StandardContext:watchedResources	[Ljava/lang/String;
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: areturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3685	-> byte code offset #0
/*      */     //   Java source line #3686	-> byte code offset #7
/*      */     //   Java source line #3687	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	StandardContext
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public String[] findWelcomeFiles()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 93	org/apache/catalina/core/StandardContext:welcomeFilesLock	Ljava/lang/Object;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 92	org/apache/catalina/core/StandardContext:welcomeFiles	[Ljava/lang/String;
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: areturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3698	-> byte code offset #0
/*      */     //   Java source line #3699	-> byte code offset #7
/*      */     //   Java source line #3700	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	StandardContext
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public String[] findWrapperLifecycles()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 95	org/apache/catalina/core/StandardContext:wrapperLifecyclesLock	Ljava/lang/Object;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 94	org/apache/catalina/core/StandardContext:wrapperLifecycles	[Ljava/lang/String;
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: areturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3712	-> byte code offset #0
/*      */     //   Java source line #3713	-> byte code offset #7
/*      */     //   Java source line #3714	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	StandardContext
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public String[] findWrapperListeners()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 97	org/apache/catalina/core/StandardContext:wrapperListenersLock	Ljava/lang/Object;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 96	org/apache/catalina/core/StandardContext:wrapperListeners	[Ljava/lang/String;
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: areturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3726	-> byte code offset #0
/*      */     //   Java source line #3727	-> byte code offset #7
/*      */     //   Java source line #3728	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	StandardContext
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   public synchronized void reload()
/*      */   {
/* 3752 */     if (!getState().isAvailable()) {
/* 3753 */       throw new IllegalStateException(sm.getString("standardContext.notStarted", new Object[] { getName() }));
/*      */     }
/*      */     
/* 3756 */     if (log.isInfoEnabled()) {
/* 3757 */       log.info(sm.getString("standardContext.reloadingStarted", new Object[] { getName() }));
/*      */     }
/*      */     
/*      */ 
/* 3761 */     setPaused(true);
/*      */     try
/*      */     {
/* 3764 */       stop();
/*      */     } catch (LifecycleException e) {
/* 3766 */       log.error(sm.getString("standardContext.stoppingContext", new Object[] { getName() }), e);
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 3771 */       start();
/*      */     } catch (LifecycleException e) {
/* 3773 */       log.error(sm.getString("standardContext.startingContext", new Object[] { getName() }), e);
/*      */     }
/*      */     
/*      */ 
/* 3777 */     setPaused(false);
/*      */     
/* 3779 */     if (log.isInfoEnabled()) {
/* 3780 */       log.info(sm.getString("standardContext.reloadingCompleted", new Object[] { getName() }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeApplicationListener(String listener)
/*      */   {
/* 3795 */     synchronized (this.applicationListenersLock)
/*      */     {
/*      */ 
/* 3798 */       int n = -1;
/* 3799 */       for (int i = 0; i < this.applicationListeners.length; i++) {
/* 3800 */         if (this.applicationListeners[i].equals(listener)) {
/* 3801 */           n = i;
/* 3802 */           break;
/*      */         }
/*      */       }
/* 3805 */       if (n < 0) {
/* 3806 */         return;
/*      */       }
/*      */       
/* 3809 */       int j = 0;
/* 3810 */       String[] results = new String[this.applicationListeners.length - 1];
/* 3811 */       for (int i = 0; i < this.applicationListeners.length; i++) {
/* 3812 */         if (i != n)
/* 3813 */           results[(j++)] = this.applicationListeners[i];
/*      */       }
/* 3815 */       this.applicationListeners = results;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3820 */     fireContainerEvent("removeApplicationListener", listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeApplicationParameter(String name)
/*      */   {
/* 3835 */     synchronized (this.applicationParametersLock)
/*      */     {
/*      */ 
/* 3838 */       int n = -1;
/* 3839 */       for (int i = 0; i < this.applicationParameters.length; i++) {
/* 3840 */         if (name.equals(this.applicationParameters[i].getName())) {
/* 3841 */           n = i;
/* 3842 */           break;
/*      */         }
/*      */       }
/* 3845 */       if (n < 0) {
/* 3846 */         return;
/*      */       }
/*      */       
/* 3849 */       int j = 0;
/* 3850 */       ApplicationParameter[] results = new ApplicationParameter[this.applicationParameters.length - 1];
/*      */       
/* 3852 */       for (int i = 0; i < this.applicationParameters.length; i++) {
/* 3853 */         if (i != n)
/* 3854 */           results[(j++)] = this.applicationParameters[i];
/*      */       }
/* 3856 */       this.applicationParameters = results;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3861 */     fireContainerEvent("removeApplicationParameter", name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeChild(Container child)
/*      */   {
/* 3878 */     if (!(child instanceof Wrapper)) {
/* 3879 */       throw new IllegalArgumentException(sm.getString("standardContext.notWrapper"));
/*      */     }
/*      */     
/*      */ 
/* 3883 */     super.removeChild(child);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeConstraint(SecurityConstraint constraint)
/*      */   {
/* 3896 */     synchronized (this.constraintsLock)
/*      */     {
/*      */ 
/* 3899 */       int n = -1;
/* 3900 */       for (int i = 0; i < this.constraints.length; i++) {
/* 3901 */         if (this.constraints[i].equals(constraint)) {
/* 3902 */           n = i;
/* 3903 */           break;
/*      */         }
/*      */       }
/* 3906 */       if (n < 0) {
/* 3907 */         return;
/*      */       }
/*      */       
/* 3910 */       int j = 0;
/* 3911 */       SecurityConstraint[] results = new SecurityConstraint[this.constraints.length - 1];
/*      */       
/* 3913 */       for (int i = 0; i < this.constraints.length; i++) {
/* 3914 */         if (i != n)
/* 3915 */           results[(j++)] = this.constraints[i];
/*      */       }
/* 3917 */       this.constraints = results;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3922 */     fireContainerEvent("removeConstraint", constraint);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeErrorPage(ErrorPage errorPage)
/*      */   {
/* 3936 */     String exceptionType = errorPage.getExceptionType();
/* 3937 */     if (exceptionType != null) {
/* 3938 */       synchronized (this.exceptionPages) {
/* 3939 */         this.exceptionPages.remove(exceptionType);
/*      */       }
/*      */     } else {
/* 3942 */       synchronized (this.statusPages) {
/* 3943 */         this.statusPages.remove(Integer.valueOf(errorPage.getErrorCode()));
/*      */       }
/*      */     }
/* 3946 */     fireContainerEvent("removeErrorPage", errorPage);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeFilterDef(FilterDef filterDef)
/*      */   {
/* 3960 */     synchronized (this.filterDefs) {
/* 3961 */       this.filterDefs.remove(filterDef.getFilterName());
/*      */     }
/* 3963 */     fireContainerEvent("removeFilterDef", filterDef);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeFilterMap(FilterMap filterMap)
/*      */   {
/* 3975 */     this.filterMaps.remove(filterMap);
/*      */     
/* 3977 */     fireContainerEvent("removeFilterMap", filterMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeMessageDestination(String name)
/*      */   {
/* 3988 */     synchronized (this.messageDestinations) {
/* 3989 */       this.messageDestinations.remove(name);
/*      */     }
/* 3991 */     fireContainerEvent("removeMessageDestination", name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeMessageDestinationRef(String name)
/*      */   {
/* 4003 */     this.namingResources.removeMessageDestinationRef(name);
/* 4004 */     fireContainerEvent("removeMessageDestinationRef", name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeMimeMapping(String extension)
/*      */   {
/* 4018 */     synchronized (this.mimeMappings) {
/* 4019 */       this.mimeMappings.remove(extension);
/*      */     }
/* 4021 */     fireContainerEvent("removeMimeMapping", extension);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeParameter(String name)
/*      */   {
/* 4034 */     this.parameters.remove(name);
/* 4035 */     fireContainerEvent("removeParameter", name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeRoleMapping(String role)
/*      */   {
/* 4047 */     synchronized (this.roleMappings) {
/* 4048 */       this.roleMappings.remove(role);
/*      */     }
/* 4050 */     fireContainerEvent("removeRoleMapping", role);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeSecurityRole(String role)
/*      */   {
/* 4063 */     synchronized (this.securityRolesLock)
/*      */     {
/*      */ 
/* 4066 */       int n = -1;
/* 4067 */       for (int i = 0; i < this.securityRoles.length; i++) {
/* 4068 */         if (role.equals(this.securityRoles[i])) {
/* 4069 */           n = i;
/* 4070 */           break;
/*      */         }
/*      */       }
/* 4073 */       if (n < 0) {
/* 4074 */         return;
/*      */       }
/*      */       
/* 4077 */       int j = 0;
/* 4078 */       String[] results = new String[this.securityRoles.length - 1];
/* 4079 */       for (int i = 0; i < this.securityRoles.length; i++) {
/* 4080 */         if (i != n)
/* 4081 */           results[(j++)] = this.securityRoles[i];
/*      */       }
/* 4083 */       this.securityRoles = results;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4088 */     fireContainerEvent("removeSecurityRole", role);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeServletMapping(String pattern)
/*      */   {
/* 4102 */     String name = null;
/* 4103 */     synchronized (this.servletMappingsLock) {
/* 4104 */       name = (String)this.servletMappings.remove(pattern);
/*      */     }
/* 4106 */     Wrapper wrapper = (Wrapper)findChild(name);
/* 4107 */     if (wrapper != null) {
/* 4108 */       wrapper.removeMapping(pattern);
/*      */     }
/* 4110 */     fireContainerEvent("removeServletMapping", pattern);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeWatchedResource(String name)
/*      */   {
/* 4123 */     synchronized (this.watchedResourcesLock)
/*      */     {
/*      */ 
/* 4126 */       int n = -1;
/* 4127 */       for (int i = 0; i < this.watchedResources.length; i++) {
/* 4128 */         if (this.watchedResources[i].equals(name)) {
/* 4129 */           n = i;
/* 4130 */           break;
/*      */         }
/*      */       }
/* 4133 */       if (n < 0) {
/* 4134 */         return;
/*      */       }
/*      */       
/* 4137 */       int j = 0;
/* 4138 */       String[] results = new String[this.watchedResources.length - 1];
/* 4139 */       for (int i = 0; i < this.watchedResources.length; i++) {
/* 4140 */         if (i != n)
/* 4141 */           results[(j++)] = this.watchedResources[i];
/*      */       }
/* 4143 */       this.watchedResources = results;
/*      */     }
/*      */     
/*      */ 
/* 4147 */     fireContainerEvent("removeWatchedResource", name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeWelcomeFile(String name)
/*      */   {
/* 4161 */     synchronized (this.welcomeFilesLock)
/*      */     {
/*      */ 
/* 4164 */       int n = -1;
/* 4165 */       for (int i = 0; i < this.welcomeFiles.length; i++) {
/* 4166 */         if (this.welcomeFiles[i].equals(name)) {
/* 4167 */           n = i;
/* 4168 */           break;
/*      */         }
/*      */       }
/* 4171 */       if (n < 0) {
/* 4172 */         return;
/*      */       }
/*      */       
/* 4175 */       int j = 0;
/* 4176 */       String[] results = new String[this.welcomeFiles.length - 1];
/* 4177 */       for (int i = 0; i < this.welcomeFiles.length; i++) {
/* 4178 */         if (i != n)
/* 4179 */           results[(j++)] = this.welcomeFiles[i];
/*      */       }
/* 4181 */       this.welcomeFiles = results;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4186 */     if (getState().equals(LifecycleState.STARTED)) {
/* 4187 */       fireContainerEvent("removeWelcomeFile", name);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeWrapperLifecycle(String listener)
/*      */   {
/* 4202 */     synchronized (this.wrapperLifecyclesLock)
/*      */     {
/*      */ 
/* 4205 */       int n = -1;
/* 4206 */       for (int i = 0; i < this.wrapperLifecycles.length; i++) {
/* 4207 */         if (this.wrapperLifecycles[i].equals(listener)) {
/* 4208 */           n = i;
/* 4209 */           break;
/*      */         }
/*      */       }
/* 4212 */       if (n < 0) {
/* 4213 */         return;
/*      */       }
/*      */       
/* 4216 */       int j = 0;
/* 4217 */       String[] results = new String[this.wrapperLifecycles.length - 1];
/* 4218 */       for (int i = 0; i < this.wrapperLifecycles.length; i++) {
/* 4219 */         if (i != n)
/* 4220 */           results[(j++)] = this.wrapperLifecycles[i];
/*      */       }
/* 4222 */       this.wrapperLifecycles = results;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4227 */     fireContainerEvent("removeWrapperLifecycle", listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeWrapperListener(String listener)
/*      */   {
/* 4242 */     synchronized (this.wrapperListenersLock)
/*      */     {
/*      */ 
/* 4245 */       int n = -1;
/* 4246 */       for (int i = 0; i < this.wrapperListeners.length; i++) {
/* 4247 */         if (this.wrapperListeners[i].equals(listener)) {
/* 4248 */           n = i;
/* 4249 */           break;
/*      */         }
/*      */       }
/* 4252 */       if (n < 0) {
/* 4253 */         return;
/*      */       }
/*      */       
/* 4256 */       int j = 0;
/* 4257 */       String[] results = new String[this.wrapperListeners.length - 1];
/* 4258 */       for (int i = 0; i < this.wrapperListeners.length; i++) {
/* 4259 */         if (i != n)
/* 4260 */           results[(j++)] = this.wrapperListeners[i];
/*      */       }
/* 4262 */       this.wrapperListeners = results;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4267 */     fireContainerEvent("removeWrapperListener", listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getProcessingTime()
/*      */   {
/* 4281 */     long result = 0L;
/*      */     
/* 4283 */     Container[] children = findChildren();
/* 4284 */     if (children != null) {
/* 4285 */       for (int i = 0; i < children.length; i++) {
/* 4286 */         result += ((StandardWrapper)children[i]).getProcessingTime();
/*      */       }
/*      */     }
/*      */     
/* 4290 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getMaxTime()
/*      */   {
/* 4302 */     long result = 0L;
/*      */     
/*      */ 
/* 4305 */     Container[] children = findChildren();
/* 4306 */     if (children != null) {
/* 4307 */       for (int i = 0; i < children.length; i++) {
/* 4308 */         long time = ((StandardWrapper)children[i]).getMaxTime();
/* 4309 */         if (time > result) {
/* 4310 */           result = time;
/*      */         }
/*      */       }
/*      */     }
/* 4314 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getMinTime()
/*      */   {
/* 4326 */     long result = -1L;
/*      */     
/*      */ 
/* 4329 */     Container[] children = findChildren();
/* 4330 */     if (children != null) {
/* 4331 */       for (int i = 0; i < children.length; i++) {
/* 4332 */         long time = ((StandardWrapper)children[i]).getMinTime();
/* 4333 */         if ((result < 0L) || (time < result)) {
/* 4334 */           result = time;
/*      */         }
/*      */       }
/*      */     }
/* 4338 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRequestCount()
/*      */   {
/* 4350 */     int result = 0;
/*      */     
/* 4352 */     Container[] children = findChildren();
/* 4353 */     if (children != null) {
/* 4354 */       for (int i = 0; i < children.length; i++) {
/* 4355 */         result += ((StandardWrapper)children[i]).getRequestCount();
/*      */       }
/*      */     }
/*      */     
/* 4359 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getErrorCount()
/*      */   {
/* 4371 */     int result = 0;
/*      */     
/* 4373 */     Container[] children = findChildren();
/* 4374 */     if (children != null) {
/* 4375 */       for (int i = 0; i < children.length; i++) {
/* 4376 */         result += ((StandardWrapper)children[i]).getErrorCount();
/*      */       }
/*      */     }
/*      */     
/* 4380 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRealPath(String path)
/*      */   {
/* 4394 */     if ("".equals(path)) {
/* 4395 */       path = "/";
/*      */     }
/* 4397 */     if (this.resources != null) {
/*      */       try {
/* 4399 */         WebResource resource = this.resources.getResource(path);
/* 4400 */         String canonicalPath = resource.getCanonicalPath();
/* 4401 */         if (canonicalPath == null)
/* 4402 */           return null;
/* 4403 */         if (((resource.isDirectory()) && (!canonicalPath.endsWith(File.separator))) || ((!resource.exists()) && (path.endsWith("/"))))
/*      */         {
/* 4405 */           return canonicalPath + File.separatorChar;
/*      */         }
/* 4407 */         return canonicalPath;
/*      */       }
/*      */       catch (IllegalArgumentException localIllegalArgumentException) {}
/*      */     }
/*      */     
/*      */ 
/* 4413 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ServletRegistration.Dynamic dynamicServletAdded(Wrapper wrapper)
/*      */   {
/* 4422 */     Servlet s = wrapper.getServlet();
/* 4423 */     if ((s != null) && (this.createdServlets.contains(s)))
/*      */     {
/* 4425 */       wrapper.setServletSecurityAnnotationScanRequired(true);
/*      */     }
/* 4427 */     return new ApplicationServletRegistration(wrapper, this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void dynamicServletCreated(Servlet servlet)
/*      */   {
/* 4435 */     this.createdServlets.add(servlet);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final class ContextFilterMaps
/*      */   {
/* 4443 */     private final Object lock = new Object();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4451 */     private FilterMap[] array = new FilterMap[0];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4462 */     private int insertPoint = 0;
/*      */     
/*      */     /* Error */
/*      */     public FilterMap[] asArray()
/*      */     {
/*      */       // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: getfield 4	org/apache/catalina/core/StandardContext$ContextFilterMaps:lock	Ljava/lang/Object;
/*      */       //   4: dup
/*      */       //   5: astore_1
/*      */       //   6: monitorenter
/*      */       //   7: aload_0
/*      */       //   8: getfield 6	org/apache/catalina/core/StandardContext$ContextFilterMaps:array	[Lorg/apache/tomcat/util/descriptor/web/FilterMap;
/*      */       //   11: aload_1
/*      */       //   12: monitorexit
/*      */       //   13: areturn
/*      */       //   14: astore_2
/*      */       //   15: aload_1
/*      */       //   16: monitorexit
/*      */       //   17: aload_2
/*      */       //   18: athrow
/*      */       // Line number table:
/*      */       //   Java source line #4468	-> byte code offset #0
/*      */       //   Java source line #4469	-> byte code offset #7
/*      */       //   Java source line #4470	-> byte code offset #14
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	signature
/*      */       //   0	19	0	this	ContextFilterMaps
/*      */       //   5	11	1	Ljava/lang/Object;	Object
/*      */       //   14	4	2	localObject1	Object
/*      */       // Exception table:
/*      */       //   from	to	target	type
/*      */       //   7	13	14	finally
/*      */       //   14	17	14	finally
/*      */     }
/*      */     
/*      */     public void add(FilterMap filterMap)
/*      */     {
/* 4481 */       synchronized (this.lock) {
/* 4482 */         FilterMap[] results = (FilterMap[])Arrays.copyOf(this.array, this.array.length + 1);
/* 4483 */         results[this.array.length] = filterMap;
/* 4484 */         this.array = results;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void addBefore(FilterMap filterMap)
/*      */     {
/* 4496 */       synchronized (this.lock) {
/* 4497 */         FilterMap[] results = new FilterMap[this.array.length + 1];
/* 4498 */         System.arraycopy(this.array, 0, results, 0, this.insertPoint);
/* 4499 */         System.arraycopy(this.array, this.insertPoint, results, this.insertPoint + 1, this.array.length - this.insertPoint);
/*      */         
/* 4501 */         results[this.insertPoint] = filterMap;
/* 4502 */         this.array = results;
/* 4503 */         this.insertPoint += 1;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void remove(FilterMap filterMap)
/*      */     {
/* 4513 */       synchronized (this.lock)
/*      */       {
/* 4515 */         int n = -1;
/* 4516 */         for (int i = 0; i < this.array.length; i++) {
/* 4517 */           if (this.array[i] == filterMap) {
/* 4518 */             n = i;
/* 4519 */             break;
/*      */           }
/*      */         }
/* 4522 */         if (n < 0) {
/* 4523 */           return;
/*      */         }
/*      */         
/* 4526 */         FilterMap[] results = new FilterMap[this.array.length - 1];
/* 4527 */         System.arraycopy(this.array, 0, results, 0, n);
/* 4528 */         System.arraycopy(this.array, n + 1, results, n, this.array.length - 1 - n);
/*      */         
/* 4530 */         this.array = results;
/* 4531 */         if (n < this.insertPoint) {
/* 4532 */           this.insertPoint -= 1;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean filterStart()
/*      */   {
/* 4548 */     if (getLogger().isDebugEnabled()) {
/* 4549 */       getLogger().debug("Starting filters");
/*      */     }
/*      */     
/* 4552 */     boolean ok = true;
/* 4553 */     synchronized (this.filterConfigs) {
/* 4554 */       this.filterConfigs.clear();
/* 4555 */       for (Map.Entry<String, FilterDef> entry : this.filterDefs.entrySet()) {
/* 4556 */         String name = (String)entry.getKey();
/* 4557 */         if (getLogger().isDebugEnabled()) {
/* 4558 */           getLogger().debug(" Starting filter '" + name + "'");
/*      */         }
/*      */         try {
/* 4561 */           ApplicationFilterConfig filterConfig = new ApplicationFilterConfig(this, (FilterDef)entry.getValue());
/*      */           
/* 4563 */           this.filterConfigs.put(name, filterConfig);
/*      */         } catch (Throwable t) {
/* 4565 */           t = ExceptionUtils.unwrapInvocationTargetException(t);
/* 4566 */           ExceptionUtils.handleThrowable(t);
/* 4567 */           getLogger().error(sm.getString("standardContext.filterStart", new Object[] { name }), t);
/*      */           
/* 4569 */           ok = false;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 4574 */     return ok;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean filterStop()
/*      */   {
/* 4585 */     if (getLogger().isDebugEnabled()) {
/* 4586 */       getLogger().debug("Stopping filters");
/*      */     }
/*      */     
/* 4589 */     synchronized (this.filterConfigs) {
/* 4590 */       for (Map.Entry<String, ApplicationFilterConfig> entry : this.filterConfigs.entrySet()) {
/* 4591 */         if (getLogger().isDebugEnabled())
/* 4592 */           getLogger().debug(" Stopping filter '" + (String)entry.getKey() + "'");
/* 4593 */         ApplicationFilterConfig filterConfig = (ApplicationFilterConfig)entry.getValue();
/* 4594 */         filterConfig.release();
/*      */       }
/* 4596 */       this.filterConfigs.clear();
/*      */     }
/* 4598 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FilterConfig findFilterConfig(String name)
/*      */   {
/* 4612 */     return (FilterConfig)this.filterConfigs.get(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean listenerStart()
/*      */   {
/* 4625 */     if (log.isDebugEnabled()) {
/* 4626 */       log.debug("Configuring application event listeners");
/*      */     }
/*      */     
/* 4629 */     String[] listeners = findApplicationListeners();
/* 4630 */     Object[] results = new Object[listeners.length];
/* 4631 */     boolean ok = true;
/* 4632 */     for (int i = 0; i < results.length; i++) {
/* 4633 */       if (getLogger().isDebugEnabled()) {
/* 4634 */         getLogger().debug(" Configuring event listener class '" + listeners[i] + "'");
/*      */       }
/*      */       try {
/* 4637 */         String listener = listeners[i];
/* 4638 */         results[i] = getInstanceManager().newInstance(listener);
/*      */       } catch (Throwable t) {
/* 4640 */         t = ExceptionUtils.unwrapInvocationTargetException(t);
/* 4641 */         ExceptionUtils.handleThrowable(t);
/* 4642 */         getLogger().error(sm.getString("standardContext.applicationListener", new Object[] { listeners[i] }), t);
/*      */         
/* 4644 */         ok = false;
/*      */       }
/*      */     }
/* 4647 */     if (!ok) {
/* 4648 */       getLogger().error(sm.getString("standardContext.applicationSkipped"));
/* 4649 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 4653 */     ArrayList<Object> eventListeners = new ArrayList();
/* 4654 */     ArrayList<Object> lifecycleListeners = new ArrayList();
/* 4655 */     for (int i = 0; i < results.length; i++) {
/* 4656 */       if (((results[i] instanceof ServletContextAttributeListener)) || ((results[i] instanceof ServletRequestAttributeListener)) || ((results[i] instanceof ServletRequestListener)) || ((results[i] instanceof HttpSessionIdListener)) || ((results[i] instanceof HttpSessionAttributeListener)))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 4661 */         eventListeners.add(results[i]);
/*      */       }
/* 4663 */       if (((results[i] instanceof ServletContextListener)) || ((results[i] instanceof HttpSessionListener)))
/*      */       {
/* 4665 */         lifecycleListeners.add(results[i]);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4674 */     for (Object eventListener : getApplicationEventListeners()) {
/* 4675 */       eventListeners.add(eventListener);
/*      */     }
/* 4677 */     setApplicationEventListeners(eventListeners.toArray());
/* 4678 */     for (Object lifecycleListener : getApplicationLifecycleListeners()) {
/* 4679 */       lifecycleListeners.add(lifecycleListener);
/* 4680 */       if ((lifecycleListener instanceof ServletContextListener)) {
/* 4681 */         this.noPluggabilityListeners.add(lifecycleListener);
/*      */       }
/*      */     }
/* 4684 */     setApplicationLifecycleListeners(lifecycleListeners.toArray());
/*      */     
/*      */ 
/*      */ 
/* 4688 */     if (getLogger().isDebugEnabled()) {
/* 4689 */       getLogger().debug("Sending application start events");
/*      */     }
/*      */     
/* 4692 */     getServletContext();
/* 4693 */     this.context.setNewServletContextListenerAllowed(false);
/*      */     
/* 4695 */     Object[] instances = getApplicationLifecycleListeners();
/* 4696 */     if ((instances == null) || (instances.length == 0)) {
/* 4697 */       return ok;
/*      */     }
/*      */     
/* 4700 */     ServletContextEvent event = new ServletContextEvent(getServletContext());
/* 4701 */     ServletContextEvent tldEvent = null;
/* 4702 */     if (this.noPluggabilityListeners.size() > 0) {
/* 4703 */       this.noPluggabilityServletContext = new NoPluggabilityServletContext(getServletContext());
/* 4704 */       tldEvent = new ServletContextEvent(this.noPluggabilityServletContext);
/*      */     }
/* 4706 */     for (int i = 0; i < instances.length; i++)
/* 4707 */       if ((instances[i] instanceof ServletContextListener))
/*      */       {
/* 4709 */         ServletContextListener listener = (ServletContextListener)instances[i];
/*      */         try
/*      */         {
/* 4712 */           fireContainerEvent("beforeContextInitialized", listener);
/* 4713 */           if (this.noPluggabilityListeners.contains(listener)) {
/* 4714 */             listener.contextInitialized(tldEvent);
/*      */           } else {
/* 4716 */             listener.contextInitialized(event);
/*      */           }
/* 4718 */           fireContainerEvent("afterContextInitialized", listener);
/*      */         } catch (Throwable t) {
/* 4720 */           ExceptionUtils.handleThrowable(t);
/* 4721 */           fireContainerEvent("afterContextInitialized", listener);
/* 4722 */           getLogger().error(sm.getString("standardContext.listenerStart", new Object[] { instances[i].getClass().getName() }), t);
/*      */           
/*      */ 
/* 4725 */           ok = false;
/*      */         }
/*      */       }
/* 4728 */     return ok;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean listenerStop()
/*      */   {
/* 4740 */     if (log.isDebugEnabled()) {
/* 4741 */       log.debug("Sending application stop events");
/*      */     }
/* 4743 */     boolean ok = true;
/* 4744 */     Object[] listeners = getApplicationLifecycleListeners();
/* 4745 */     if ((listeners != null) && (listeners.length > 0)) {
/* 4746 */       ServletContextEvent event = new ServletContextEvent(getServletContext());
/* 4747 */       ServletContextEvent tldEvent = null;
/* 4748 */       if (this.noPluggabilityServletContext != null) {
/* 4749 */         tldEvent = new ServletContextEvent(this.noPluggabilityServletContext);
/*      */       }
/* 4751 */       for (int i = 0; i < listeners.length; i++) {
/* 4752 */         int j = listeners.length - 1 - i;
/* 4753 */         if (listeners[j] != null)
/*      */         {
/* 4755 */           if ((listeners[j] instanceof ServletContextListener)) {
/* 4756 */             ServletContextListener listener = (ServletContextListener)listeners[j];
/*      */             try
/*      */             {
/* 4759 */               fireContainerEvent("beforeContextDestroyed", listener);
/* 4760 */               if (this.noPluggabilityListeners.contains(listener)) {
/* 4761 */                 listener.contextDestroyed(tldEvent);
/*      */               } else {
/* 4763 */                 listener.contextDestroyed(event);
/*      */               }
/* 4765 */               fireContainerEvent("afterContextDestroyed", listener);
/*      */             } catch (Throwable t) {
/* 4767 */               ExceptionUtils.handleThrowable(t);
/* 4768 */               fireContainerEvent("afterContextDestroyed", listener);
/* 4769 */               getLogger().error(sm.getString("standardContext.listenerStop", new Object[] { listeners[j].getClass().getName() }), t);
/*      */               
/*      */ 
/* 4772 */               ok = false;
/*      */             }
/*      */           }
/*      */           try {
/* 4776 */             if (getInstanceManager() != null) {
/* 4777 */               getInstanceManager().destroyInstance(listeners[j]);
/*      */             }
/*      */           } catch (Throwable t) {
/* 4780 */             t = ExceptionUtils.unwrapInvocationTargetException(t);
/* 4781 */             ExceptionUtils.handleThrowable(t);
/* 4782 */             getLogger().error(sm.getString("standardContext.listenerStop", new Object[] { listeners[j].getClass().getName() }), t);
/*      */             
/*      */ 
/* 4785 */             ok = false;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 4791 */     listeners = getApplicationEventListeners();
/* 4792 */     if (listeners != null) {
/* 4793 */       for (int i = 0; i < listeners.length; i++) {
/* 4794 */         int j = listeners.length - 1 - i;
/* 4795 */         if (listeners[j] != null) {
/*      */           try
/*      */           {
/* 4798 */             if (getInstanceManager() != null) {
/* 4799 */               getInstanceManager().destroyInstance(listeners[j]);
/*      */             }
/*      */           } catch (Throwable t) {
/* 4802 */             t = ExceptionUtils.unwrapInvocationTargetException(t);
/* 4803 */             ExceptionUtils.handleThrowable(t);
/* 4804 */             getLogger().error(sm.getString("standardContext.listenerStop", new Object[] { listeners[j].getClass().getName() }), t);
/*      */             
/*      */ 
/* 4807 */             ok = false;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 4812 */     setApplicationEventListeners(null);
/* 4813 */     setApplicationLifecycleListeners(null);
/*      */     
/* 4815 */     this.noPluggabilityServletContext = null;
/* 4816 */     this.noPluggabilityListeners.clear();
/*      */     
/* 4818 */     return ok;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resourcesStart()
/*      */     throws LifecycleException
/*      */   {
/* 4830 */     if (!this.resources.getState().isAvailable()) {
/* 4831 */       this.resources.start();
/*      */     }
/*      */     
/* 4834 */     if ((this.effectiveMajorVersion >= 3) && (this.addWebinfClassesResources)) {
/* 4835 */       WebResource webinfClassesResource = this.resources.getResource("/WEB-INF/classes/META-INF/resources");
/*      */       
/* 4837 */       if (webinfClassesResource.isDirectory()) {
/* 4838 */         getResources().createWebResourceSet(WebResourceRoot.ResourceSetType.RESOURCE_JAR, "/", webinfClassesResource.getURL(), "/");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean resourcesStop()
/*      */   {
/* 4852 */     boolean ok = true;
/*      */     
/* 4854 */     Lock writeLock = this.resourcesLock.writeLock();
/* 4855 */     writeLock.lock();
/*      */     try {
/* 4857 */       if (this.resources != null) {
/* 4858 */         this.resources.stop();
/*      */       }
/*      */     } catch (Throwable t) {
/* 4861 */       ExceptionUtils.handleThrowable(t);
/* 4862 */       log.error(sm.getString("standardContext.resourcesStop"), t);
/* 4863 */       ok = false;
/*      */     } finally {
/* 4865 */       writeLock.unlock();
/*      */     }
/*      */     
/* 4868 */     return ok;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean loadOnStartup(Container[] children)
/*      */   {
/* 4883 */     TreeMap<Integer, ArrayList<Wrapper>> map = new TreeMap();
/* 4884 */     for (int i = 0; i < children.length; i++) {
/* 4885 */       Wrapper wrapper = (Wrapper)children[i];
/* 4886 */       int loadOnStartup = wrapper.getLoadOnStartup();
/* 4887 */       if (loadOnStartup >= 0)
/*      */       {
/* 4889 */         Integer key = Integer.valueOf(loadOnStartup);
/* 4890 */         ArrayList<Wrapper> list = (ArrayList)map.get(key);
/* 4891 */         if (list == null) {
/* 4892 */           list = new ArrayList();
/* 4893 */           map.put(key, list);
/*      */         }
/* 4895 */         list.add(wrapper);
/*      */       }
/*      */     }
/*      */     
/* 4899 */     for (ArrayList<Wrapper> list : map.values()) {
/* 4900 */       for (Wrapper wrapper : list) {
/*      */         try {
/* 4902 */           wrapper.load();
/*      */         } catch (ServletException e) {
/* 4904 */           getLogger().error(sm.getString("standardContext.loadOnStartup.loadException", new Object[] { getName(), wrapper.getName() }), StandardWrapper.getRootCause(e));
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4910 */           if (getComputedFailCtxIfServletStartFails()) {
/* 4911 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 4916 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void startInternal()
/*      */     throws LifecycleException
/*      */   {
/* 4931 */     if (log.isDebugEnabled()) {
/* 4932 */       log.debug("Starting " + getBaseName());
/*      */     }
/*      */     
/* 4935 */     if (getObjectName() != null) {
/* 4936 */       Notification notification = new Notification("j2ee.state.starting", getObjectName(), this.sequenceNumber.getAndIncrement());
/*      */       
/* 4938 */       this.broadcaster.sendNotification(notification);
/*      */     }
/*      */     
/* 4941 */     setConfigured(false);
/* 4942 */     boolean ok = true;
/*      */     
/*      */ 
/*      */ 
/* 4946 */     if (this.namingResources != null) {
/* 4947 */       this.namingResources.start();
/*      */     }
/*      */     
/*      */ 
/* 4951 */     if (getResources() == null) {
/* 4952 */       if (log.isDebugEnabled()) {
/* 4953 */         log.debug("Configuring default Resources");
/*      */       }
/*      */       try {
/* 4956 */         setResources(new StandardRoot(this));
/*      */       } catch (IllegalArgumentException e) {
/* 4958 */         log.error(sm.getString("standardContext.resourcesInit"), e);
/* 4959 */         ok = false;
/*      */       }
/*      */     }
/* 4962 */     if (ok) {
/* 4963 */       resourcesStart();
/*      */     }
/*      */     
/* 4966 */     if (getLoader() == null) {
/* 4967 */       WebappLoader webappLoader = new WebappLoader(getParentClassLoader());
/* 4968 */       webappLoader.setDelegate(getDelegate());
/* 4969 */       setLoader(webappLoader);
/*      */     }
/*      */     
/*      */ 
/* 4973 */     if (this.cookieProcessor == null) {
/* 4974 */       this.cookieProcessor = new Rfc6265CookieProcessor();
/*      */     }
/*      */     
/*      */ 
/* 4978 */     getCharsetMapper();
/*      */     
/*      */ 
/* 4981 */     postWorkDirectory();
/*      */     
/*      */ 
/* 4984 */     boolean dependencyCheck = true;
/*      */     try {
/* 4986 */       dependencyCheck = ExtensionValidator.validateApplication(getResources(), this);
/*      */     }
/*      */     catch (IOException ioe) {
/* 4989 */       log.error(sm.getString("standardContext.extensionValidationError"), ioe);
/* 4990 */       dependencyCheck = false;
/*      */     }
/*      */     
/* 4993 */     if (!dependencyCheck)
/*      */     {
/* 4995 */       ok = false;
/*      */     }
/*      */     
/*      */ 
/* 4999 */     String useNamingProperty = System.getProperty("catalina.useNaming");
/* 5000 */     if ((useNamingProperty != null) && (useNamingProperty.equals("false")))
/*      */     {
/* 5002 */       this.useNaming = false;
/*      */     }
/*      */     
/* 5005 */     if ((ok) && (isUseNaming()) && 
/* 5006 */       (getNamingContextListener() == null)) {
/* 5007 */       NamingContextListener ncl = new NamingContextListener();
/* 5008 */       ncl.setName(getNamingContextName());
/* 5009 */       ncl.setExceptionOnFailedWrite(getJndiExceptionOnFailedWrite());
/* 5010 */       addLifecycleListener(ncl);
/* 5011 */       setNamingContextListener(ncl);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 5016 */     if (log.isDebugEnabled()) {
/* 5017 */       log.debug("Processing standard container startup");
/*      */     }
/*      */     
/*      */ 
/* 5021 */     ClassLoader oldCCL = bindThread();
/*      */     try
/*      */     {
/* 5024 */       if (ok)
/*      */       {
/* 5026 */         Loader loader = getLoader();
/* 5027 */         if ((loader instanceof Lifecycle)) {
/* 5028 */           ((Lifecycle)loader).start();
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 5033 */         setClassLoaderProperty("clearReferencesRmiTargets", getClearReferencesRmiTargets());
/*      */         
/* 5035 */         setClassLoaderProperty("clearReferencesStopThreads", getClearReferencesStopThreads());
/*      */         
/* 5037 */         setClassLoaderProperty("clearReferencesStopTimerThreads", getClearReferencesStopTimerThreads());
/*      */         
/* 5039 */         setClassLoaderProperty("clearReferencesHttpClientKeepAliveThread", getClearReferencesHttpClientKeepAliveThread());
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 5044 */         unbindThread(oldCCL);
/* 5045 */         oldCCL = bindThread();
/*      */         
/*      */ 
/*      */ 
/* 5049 */         this.logger = null;
/* 5050 */         getLogger();
/*      */         
/* 5052 */         Realm realm = getRealmInternal();
/* 5053 */         if (null != realm) {
/* 5054 */           if ((realm instanceof Lifecycle)) {
/* 5055 */             ((Lifecycle)realm).start();
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 5061 */           CredentialHandler safeHandler = new CredentialHandler()
/*      */           {
/*      */             public boolean matches(String inputCredentials, String storedCredentials) {
/* 5064 */               return StandardContext.this.getRealmInternal().getCredentialHandler().matches(inputCredentials, storedCredentials);
/*      */             }
/*      */             
/*      */             public String mutate(String inputCredentials)
/*      */             {
/* 5069 */               return StandardContext.this.getRealmInternal().getCredentialHandler().mutate(inputCredentials);
/*      */             }
/* 5071 */           };
/* 5072 */           this.context.setAttribute("org.apache.catalina.CredentialHandler", safeHandler);
/*      */         }
/*      */         
/*      */ 
/* 5076 */         fireLifecycleEvent("configure_start", null);
/*      */         
/*      */ 
/* 5079 */         for (Container child : findChildren()) {
/* 5080 */           if (!child.getState().isAvailable()) {
/* 5081 */             child.start();
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 5087 */         if ((this.pipeline instanceof Lifecycle)) {
/* 5088 */           ((Lifecycle)this.pipeline).start();
/*      */         }
/*      */         
/*      */ 
/* 5092 */         Manager contextManager = null;
/* 5093 */         Manager manager = getManager();
/* 5094 */         if (manager == null) {
/* 5095 */           if (log.isDebugEnabled()) {
/* 5096 */             log.debug(sm.getString("standardContext.cluster.noManager", new Object[] { Boolean.valueOf(getCluster() != null ? 1 : false), Boolean.valueOf(this.distributable) }));
/*      */           }
/*      */           
/*      */ 
/* 5100 */           if ((getCluster() != null) && (this.distributable)) {
/*      */             try {
/* 5102 */               contextManager = getCluster().createManager(getName());
/*      */             } catch (Exception ex) {
/* 5104 */               log.error("standardContext.clusterFail", ex);
/* 5105 */               ok = false;
/*      */             }
/*      */           } else {
/* 5108 */             contextManager = new StandardManager();
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 5113 */         if (contextManager != null) {
/* 5114 */           if (log.isDebugEnabled()) {
/* 5115 */             log.debug(sm.getString("standardContext.manager", new Object[] { contextManager.getClass().getName() }));
/*      */           }
/*      */           
/* 5118 */           setManager(contextManager);
/*      */         }
/*      */         
/* 5121 */         if ((manager != null) && (getCluster() != null) && (this.distributable))
/*      */         {
/*      */ 
/* 5124 */           getCluster().registerManager(manager);
/*      */         }
/*      */       }
/*      */       
/* 5128 */       if (!getConfigured()) {
/* 5129 */         log.error(sm.getString("standardContext.configurationFail"));
/* 5130 */         ok = false;
/*      */       }
/*      */       
/*      */ 
/* 5134 */       if (ok) {
/* 5135 */         getServletContext().setAttribute("org.apache.catalina.resources", getResources());
/*      */       }
/*      */       
/* 5138 */       if (ok) {
/* 5139 */         if (getInstanceManager() == null) {
/* 5140 */           javax.naming.Context context = null;
/* 5141 */           if ((isUseNaming()) && (getNamingContextListener() != null)) {
/* 5142 */             context = getNamingContextListener().getEnvContext();
/*      */           }
/* 5144 */           Map<String, Map<String, String>> injectionMap = buildInjectionMap(getIgnoreAnnotations() ? new NamingResourcesImpl() : getNamingResources());
/*      */           
/* 5146 */           setInstanceManager(new DefaultInstanceManager(context, injectionMap, this, getClass().getClassLoader()));
/*      */         }
/*      */         
/* 5149 */         getServletContext().setAttribute(InstanceManager.class.getName(), getInstanceManager());
/*      */         
/* 5151 */         InstanceManagerBindings.bind(getLoader().getClassLoader(), getInstanceManager());
/*      */       }
/*      */       
/*      */ 
/* 5155 */       if (ok) {
/* 5156 */         getServletContext().setAttribute(JarScanner.class.getName(), getJarScanner());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 5161 */       mergeParameters();
/*      */       
/*      */ 
/*      */ 
/* 5165 */       for (Map.Entry<ServletContainerInitializer, Set<Class<?>>> entry : this.initializers.entrySet()) {
/*      */         try {
/* 5167 */           ((ServletContainerInitializer)entry.getKey()).onStartup((Set)entry.getValue(), getServletContext());
/*      */         }
/*      */         catch (ServletException e) {
/* 5170 */           log.error(sm.getString("standardContext.sciFail"), e);
/* 5171 */           ok = false;
/* 5172 */           break;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 5177 */       if ((ok) && 
/* 5178 */         (!listenerStart())) {
/* 5179 */         log.error(sm.getString("standardContext.listenerFail"));
/* 5180 */         ok = false;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5187 */       if (ok) {
/* 5188 */         checkConstraintsForUncoveredMethods(findConstraints());
/*      */       }
/*      */       
/*      */       try
/*      */       {
/* 5193 */         Manager manager = getManager();
/* 5194 */         if ((manager instanceof Lifecycle)) {
/* 5195 */           ((Lifecycle)manager).start();
/*      */         }
/*      */       } catch (Exception e) {
/* 5198 */         log.error(sm.getString("standardContext.managerFail"), e);
/* 5199 */         ok = false;
/*      */       }
/*      */       
/*      */ 
/* 5203 */       if ((ok) && 
/* 5204 */         (!filterStart())) {
/* 5205 */         log.error(sm.getString("standardContext.filterFail"));
/* 5206 */         ok = false;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 5211 */       if ((ok) && 
/* 5212 */         (!loadOnStartup(findChildren()))) {
/* 5213 */         log.error(sm.getString("standardContext.servletFail"));
/* 5214 */         ok = false;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 5219 */       super.threadStart();
/*      */     }
/*      */     finally {
/* 5222 */       unbindThread(oldCCL);
/*      */     }
/*      */     
/*      */ 
/* 5226 */     if (ok) {
/* 5227 */       if (log.isDebugEnabled())
/* 5228 */         log.debug("Starting completed");
/*      */     } else {
/* 5230 */       log.error(sm.getString("standardContext.startFailed", new Object[] { getName() }));
/*      */     }
/*      */     
/* 5233 */     this.startTime = System.currentTimeMillis();
/*      */     
/*      */ 
/* 5236 */     if ((ok) && (getObjectName() != null)) {
/* 5237 */       Notification notification = new Notification("j2ee.state.running", getObjectName(), this.sequenceNumber.getAndIncrement());
/*      */       
/*      */ 
/* 5240 */       this.broadcaster.sendNotification(notification);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5247 */     getResources().gc();
/*      */     
/*      */ 
/* 5250 */     if (!ok) {
/* 5251 */       setState(LifecycleState.FAILED);
/*      */     } else {
/* 5253 */       setState(LifecycleState.STARTING);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void checkConstraintsForUncoveredMethods(SecurityConstraint[] constraints)
/*      */   {
/* 5260 */     SecurityConstraint[] newConstraints = SecurityConstraint.findUncoveredHttpMethods(constraints, getDenyUncoveredHttpMethods(), getLogger());
/*      */     
/*      */ 
/* 5263 */     for (SecurityConstraint constraint : newConstraints) {
/* 5264 */       addConstraint(constraint);
/*      */     }
/*      */   }
/*      */   
/*      */   private void setClassLoaderProperty(String name, boolean value)
/*      */   {
/* 5270 */     ClassLoader cl = getLoader().getClassLoader();
/* 5271 */     if (!IntrospectionUtils.setProperty(cl, name, Boolean.toString(value)))
/*      */     {
/* 5273 */       log.info(sm.getString("standardContext.webappClassLoader.missingProperty", new Object[] { name, Boolean.toString(value) }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private Map<String, Map<String, String>> buildInjectionMap(NamingResourcesImpl namingResources)
/*      */   {
/* 5280 */     Map<String, Map<String, String>> injectionMap = new HashMap();
/* 5281 */     for (Injectable resource : namingResources.findLocalEjbs()) {
/* 5282 */       addInjectionTarget(resource, injectionMap);
/*      */     }
/* 5284 */     for (Injectable resource : namingResources.findEjbs()) {
/* 5285 */       addInjectionTarget(resource, injectionMap);
/*      */     }
/* 5287 */     for (Injectable resource : namingResources.findEnvironments()) {
/* 5288 */       addInjectionTarget(resource, injectionMap);
/*      */     }
/* 5290 */     for (Injectable resource : namingResources.findMessageDestinationRefs()) {
/* 5291 */       addInjectionTarget(resource, injectionMap);
/*      */     }
/* 5293 */     for (Injectable resource : namingResources.findResourceEnvRefs()) {
/* 5294 */       addInjectionTarget(resource, injectionMap);
/*      */     }
/* 5296 */     for (Injectable resource : namingResources.findResources()) {
/* 5297 */       addInjectionTarget(resource, injectionMap);
/*      */     }
/* 5299 */     for (Injectable resource : namingResources.findServices()) {
/* 5300 */       addInjectionTarget(resource, injectionMap);
/*      */     }
/* 5302 */     return injectionMap;
/*      */   }
/*      */   
/*      */   private void addInjectionTarget(Injectable resource, Map<String, Map<String, String>> injectionMap) {
/* 5306 */     List<InjectionTarget> injectionTargets = resource.getInjectionTargets();
/* 5307 */     String jndiName; if ((injectionTargets != null) && (injectionTargets.size() > 0)) {
/* 5308 */       jndiName = resource.getName();
/* 5309 */       for (InjectionTarget injectionTarget : injectionTargets) {
/* 5310 */         String clazz = injectionTarget.getTargetClass();
/* 5311 */         Map<String, String> injections = (Map)injectionMap.get(clazz);
/* 5312 */         if (injections == null) {
/* 5313 */           injections = new HashMap();
/* 5314 */           injectionMap.put(clazz, injections);
/*      */         }
/* 5316 */         injections.put(injectionTarget.getTargetName(), jndiName);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void mergeParameters()
/*      */   {
/* 5330 */     Map<String, String> mergedParams = new HashMap();
/*      */     
/* 5332 */     String[] names = findParameters();
/* 5333 */     for (int i = 0; i < names.length; i++) {
/* 5334 */       mergedParams.put(names[i], findParameter(names[i]));
/*      */     }
/*      */     
/* 5337 */     ApplicationParameter[] params = findApplicationParameters();
/* 5338 */     for (int i = 0; i < params.length; i++) {
/* 5339 */       if (params[i].getOverride()) {
/* 5340 */         if (mergedParams.get(params[i].getName()) == null) {
/* 5341 */           mergedParams.put(params[i].getName(), params[i].getValue());
/*      */         }
/*      */       }
/*      */       else {
/* 5345 */         mergedParams.put(params[i].getName(), params[i].getValue());
/*      */       }
/*      */     }
/*      */     
/* 5349 */     ServletContext sc = getServletContext();
/* 5350 */     for (Map.Entry<String, String> entry : mergedParams.entrySet()) {
/* 5351 */       sc.setInitParameter((String)entry.getKey(), (String)entry.getValue());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void stopInternal()
/*      */     throws LifecycleException
/*      */   {
/* 5368 */     if (getObjectName() != null) {
/* 5369 */       Notification notification = new Notification("j2ee.state.stopping", getObjectName(), this.sequenceNumber.getAndIncrement());
/*      */       
/*      */ 
/* 5372 */       this.broadcaster.sendNotification(notification);
/*      */     }
/*      */     
/* 5375 */     setState(LifecycleState.STOPPING);
/*      */     
/*      */ 
/* 5378 */     ClassLoader oldCCL = bindThread();
/*      */     
/*      */     try
/*      */     {
/* 5382 */       Container[] children = findChildren();
/*      */       
/*      */ 
/* 5385 */       threadStop();
/*      */       
/* 5387 */       for (int i = 0; i < children.length; i++) {
/* 5388 */         children[i].stop();
/*      */       }
/*      */       
/*      */ 
/* 5392 */       filterStop();
/*      */       
/* 5394 */       Manager manager = getManager();
/* 5395 */       if (((manager instanceof Lifecycle)) && (((Lifecycle)manager).getState().isAvailable())) {
/* 5396 */         ((Lifecycle)manager).stop();
/*      */       }
/*      */       
/*      */ 
/* 5400 */       listenerStop();
/*      */       
/*      */ 
/* 5403 */       setCharsetMapper(null);
/*      */       
/*      */ 
/* 5406 */       if (log.isDebugEnabled()) {
/* 5407 */         log.debug("Processing standard container shutdown");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 5413 */       if (this.namingResources != null) {
/* 5414 */         this.namingResources.stop();
/*      */       }
/*      */       
/* 5417 */       fireLifecycleEvent("configure_stop", null);
/*      */       
/*      */ 
/* 5420 */       if (((this.pipeline instanceof Lifecycle)) && (((Lifecycle)this.pipeline).getState().isAvailable()))
/*      */       {
/* 5422 */         ((Lifecycle)this.pipeline).stop();
/*      */       }
/*      */       
/*      */ 
/* 5426 */       if (this.context != null) {
/* 5427 */         this.context.clearAttributes();
/*      */       }
/* 5429 */       Realm realm = getRealmInternal();
/* 5430 */       if ((realm instanceof Lifecycle)) {
/* 5431 */         ((Lifecycle)realm).stop();
/*      */       }
/* 5433 */       Loader loader = getLoader();
/* 5434 */       if ((loader instanceof Lifecycle)) {
/* 5435 */         ClassLoader classLoader = loader.getClassLoader();
/* 5436 */         ((Lifecycle)loader).stop();
/* 5437 */         if (classLoader != null) {
/* 5438 */           InstanceManagerBindings.unbind(classLoader);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 5443 */       resourcesStop();
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/* 5448 */       unbindThread(oldCCL);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 5453 */     if (getObjectName() != null) {
/* 5454 */       Notification notification = new Notification("j2ee.state.stopped", getObjectName(), this.sequenceNumber.getAndIncrement());
/*      */       
/*      */ 
/* 5457 */       this.broadcaster.sendNotification(notification);
/*      */     }
/*      */     
/*      */ 
/* 5461 */     this.context = null;
/*      */     
/*      */     try
/*      */     {
/* 5465 */       resetContext();
/*      */     } catch (Exception ex) {
/* 5467 */       log.error("Error reseting context " + this + " " + ex, ex);
/*      */     }
/*      */     
/*      */ 
/* 5471 */     setInstanceManager(null);
/*      */     
/* 5473 */     if (log.isDebugEnabled()) {
/* 5474 */       log.debug("Stopping complete");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void destroyInternal()
/*      */     throws LifecycleException
/*      */   {
/* 5495 */     if (getObjectName() != null)
/*      */     {
/* 5497 */       Notification notification = new Notification("j2ee.object.deleted", getObjectName(), this.sequenceNumber.getAndIncrement());
/*      */       
/*      */ 
/* 5500 */       this.broadcaster.sendNotification(notification);
/*      */     }
/*      */     
/* 5503 */     if (this.namingResources != null) {
/* 5504 */       this.namingResources.destroy();
/*      */     }
/*      */     
/* 5507 */     Loader loader = getLoader();
/* 5508 */     if ((loader instanceof Lifecycle)) {
/* 5509 */       ((Lifecycle)loader).destroy();
/*      */     }
/*      */     
/* 5512 */     Manager manager = getManager();
/* 5513 */     if ((manager instanceof Lifecycle)) {
/* 5514 */       ((Lifecycle)manager).destroy();
/*      */     }
/*      */     
/* 5517 */     if (this.resources != null) {
/* 5518 */       this.resources.destroy();
/*      */     }
/*      */     
/* 5521 */     super.destroyInternal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void backgroundProcess()
/*      */   {
/* 5528 */     if (!getState().isAvailable()) {
/* 5529 */       return;
/*      */     }
/* 5531 */     Loader loader = getLoader();
/* 5532 */     if (loader != null) {
/*      */       try {
/* 5534 */         loader.backgroundProcess();
/*      */       } catch (Exception e) {
/* 5536 */         log.warn(sm.getString("standardContext.backgroundProcess.loader", new Object[] { loader }), e);
/*      */       }
/*      */     }
/*      */     
/* 5540 */     Manager manager = getManager();
/* 5541 */     if (manager != null) {
/*      */       try {
/* 5543 */         manager.backgroundProcess();
/*      */       } catch (Exception e) {
/* 5545 */         log.warn(sm.getString("standardContext.backgroundProcess.manager", new Object[] { manager }), e);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 5550 */     WebResourceRoot resources = getResources();
/* 5551 */     if (resources != null) {
/*      */       try {
/* 5553 */         resources.backgroundProcess();
/*      */       } catch (Exception e) {
/* 5555 */         log.warn(sm.getString("standardContext.backgroundProcess.resources", new Object[] { resources }), e);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 5560 */     super.backgroundProcess();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void resetContext()
/*      */     throws Exception
/*      */   {
/* 5571 */     for (Container child : findChildren()) {
/* 5572 */       removeChild(child);
/*      */     }
/* 5574 */     this.startupTime = 0L;
/* 5575 */     this.startTime = 0L;
/* 5576 */     this.tldScanTime = 0L;
/*      */     
/*      */ 
/* 5579 */     this.distributable = false;
/*      */     
/* 5581 */     this.applicationListeners = new String[0];
/* 5582 */     this.applicationEventListenersList.clear();
/* 5583 */     this.applicationLifecycleListenersObjects = new Object[0];
/* 5584 */     this.jspConfigDescriptor = null;
/*      */     
/* 5586 */     this.initializers.clear();
/*      */     
/* 5588 */     this.createdServlets.clear();
/*      */     
/* 5590 */     this.postConstructMethods.clear();
/* 5591 */     this.preDestroyMethods.clear();
/*      */     
/* 5593 */     if (log.isDebugEnabled()) {
/* 5594 */       log.debug("resetContext " + getObjectName());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 5603 */     StringBuilder sb = new StringBuilder();
/* 5604 */     if (getParent() != null) {
/* 5605 */       sb.append(getParent().toString());
/* 5606 */       sb.append(".");
/*      */     }
/* 5608 */     sb.append("StandardContext[");
/* 5609 */     sb.append(getName());
/* 5610 */     sb.append("]");
/* 5611 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String adjustURLPattern(String urlPattern)
/*      */   {
/* 5630 */     if (urlPattern == null)
/* 5631 */       return urlPattern;
/* 5632 */     if ((urlPattern.startsWith("/")) || (urlPattern.startsWith("*.")))
/* 5633 */       return urlPattern;
/* 5634 */     if (!isServlet22())
/* 5635 */       return urlPattern;
/* 5636 */     if (log.isDebugEnabled()) {
/* 5637 */       log.debug(sm.getString("standardContext.urlPattern.patternWarning", new Object[] { urlPattern }));
/*      */     }
/* 5639 */     return "/" + urlPattern;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isServlet22()
/*      */   {
/* 5651 */     return "-//Sun Microsystems, Inc.//DTD Web Application 2.2//EN".equals(this.publicId);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<String> addServletSecurity(ServletRegistration.Dynamic registration, ServletSecurityElement servletSecurityElement)
/*      */   {
/* 5660 */     Set<String> conflicts = new HashSet();
/*      */     
/* 5662 */     Collection<String> urlPatterns = registration.getMappings();
/* 5663 */     for (String urlPattern : urlPatterns) {
/* 5664 */       boolean foundConflict = false;
/*      */       
/* 5666 */       SecurityConstraint[] securityConstraints = findConstraints();
/*      */       
/* 5668 */       for (SecurityConstraint securityConstraint : securityConstraints)
/*      */       {
/* 5670 */         SecurityCollection[] collections = securityConstraint.findCollections();
/*      */         
/* 5672 */         for (SecurityCollection collection : collections) {
/* 5673 */           if (collection.findPattern(urlPattern))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 5678 */             if (collection.isFromDescriptor())
/*      */             {
/* 5680 */               foundConflict = true;
/* 5681 */               conflicts.add(urlPattern);
/* 5682 */               break;
/*      */             }
/*      */             
/* 5685 */             collection.removePattern(urlPattern);
/*      */             
/* 5687 */             if (collection.findPatterns().length == 0) {
/* 5688 */               securityConstraint.removeCollection(collection);
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 5695 */         if (securityConstraint.findCollections().length == 0) {
/* 5696 */           removeConstraint(securityConstraint);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 5701 */         if (foundConflict) {
/*      */           break;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5715 */       if (!foundConflict) {
/* 5716 */         SecurityConstraint[] newSecurityConstraints = SecurityConstraint.createConstraints(servletSecurityElement, urlPattern);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 5721 */         for (SecurityConstraint securityConstraint : newSecurityConstraints) {
/* 5722 */           addConstraint(securityConstraint);
/*      */         }
/*      */         
/* 5725 */         checkConstraintsForUncoveredMethods(newSecurityConstraints);
/*      */       }
/*      */     }
/*      */     
/* 5729 */     return conflicts;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ClassLoader bindThread()
/*      */   {
/* 5741 */     ClassLoader oldContextClassLoader = bind(false, null);
/*      */     
/* 5743 */     if (isUseNaming()) {
/*      */       try {
/* 5745 */         ContextBindings.bindThread(this, getNamingToken());
/*      */       }
/*      */       catch (NamingException localNamingException) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 5752 */     return oldContextClassLoader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void unbindThread(ClassLoader oldContextClassLoader)
/*      */   {
/* 5763 */     if (isUseNaming()) {
/* 5764 */       ContextBindings.unbindThread(this, getNamingToken());
/*      */     }
/*      */     
/* 5767 */     unbind(false, oldContextClassLoader);
/*      */   }
/*      */   
/*      */ 
/*      */   public ClassLoader bind(boolean usePrivilegedAction, ClassLoader originalClassLoader)
/*      */   {
/* 5773 */     Loader loader = getLoader();
/* 5774 */     ClassLoader webApplicationClassLoader = null;
/* 5775 */     if (loader != null) {
/* 5776 */       webApplicationClassLoader = loader.getClassLoader();
/*      */     }
/*      */     
/* 5779 */     if (originalClassLoader == null) {
/* 5780 */       if (usePrivilegedAction) {
/* 5781 */         PrivilegedAction<ClassLoader> pa = new PrivilegedGetTccl();
/* 5782 */         originalClassLoader = (ClassLoader)AccessController.doPrivileged(pa);
/*      */       } else {
/* 5784 */         originalClassLoader = Thread.currentThread().getContextClassLoader();
/*      */       }
/*      */     }
/*      */     
/* 5788 */     if ((webApplicationClassLoader == null) || (webApplicationClassLoader == originalClassLoader))
/*      */     {
/*      */ 
/*      */ 
/* 5792 */       return null;
/*      */     }
/*      */     
/* 5795 */     ThreadBindingListener threadBindingListener = getThreadBindingListener();
/*      */     
/* 5797 */     if (usePrivilegedAction) {
/* 5798 */       PrivilegedAction<Void> pa = new PrivilegedSetTccl(webApplicationClassLoader);
/* 5799 */       AccessController.doPrivileged(pa);
/*      */     } else {
/* 5801 */       Thread.currentThread().setContextClassLoader(webApplicationClassLoader);
/*      */     }
/* 5803 */     if (threadBindingListener != null) {
/*      */       try {
/* 5805 */         threadBindingListener.bind();
/*      */       } catch (Throwable t) {
/* 5807 */         ExceptionUtils.handleThrowable(t);
/* 5808 */         log.error(sm.getString("standardContext.threadBindingListenerError", new Object[] { getName() }), t);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 5813 */     return originalClassLoader;
/*      */   }
/*      */   
/*      */ 
/*      */   public void unbind(boolean usePrivilegedAction, ClassLoader originalClassLoader)
/*      */   {
/* 5819 */     if (originalClassLoader == null) {
/* 5820 */       return;
/*      */     }
/*      */     
/* 5823 */     if (this.threadBindingListener != null) {
/*      */       try {
/* 5825 */         this.threadBindingListener.unbind();
/*      */       } catch (Throwable t) {
/* 5827 */         ExceptionUtils.handleThrowable(t);
/* 5828 */         log.error(sm.getString("standardContext.threadBindingListenerError", new Object[] { getName() }), t);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 5833 */     if (usePrivilegedAction) {
/* 5834 */       PrivilegedAction<Void> pa = new PrivilegedSetTccl(originalClassLoader);
/* 5835 */       AccessController.doPrivileged(pa);
/*      */     } else {
/* 5837 */       Thread.currentThread().setContextClassLoader(originalClassLoader);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getNamingContextName()
/*      */   {
/* 5848 */     if (this.namingContextName == null) {
/* 5849 */       Container parent = getParent();
/* 5850 */       if (parent == null) {
/* 5851 */         this.namingContextName = getName();
/*      */       } else {
/* 5853 */         Stack<String> stk = new Stack();
/* 5854 */         StringBuilder buff = new StringBuilder();
/* 5855 */         while (parent != null) {
/* 5856 */           stk.push(parent.getName());
/* 5857 */           parent = parent.getParent();
/*      */         }
/* 5859 */         while (!stk.empty()) {
/* 5860 */           buff.append("/" + (String)stk.pop());
/*      */         }
/* 5862 */         buff.append(getName());
/* 5863 */         this.namingContextName = buff.toString();
/*      */       }
/*      */     }
/* 5866 */     return this.namingContextName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public NamingContextListener getNamingContextListener()
/*      */   {
/* 5876 */     return this.namingContextListener;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNamingContextListener(NamingContextListener namingContextListener)
/*      */   {
/* 5886 */     this.namingContextListener = namingContextListener;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getPaused()
/*      */   {
/* 5896 */     return this.paused;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean fireRequestInitEvent(ServletRequest request)
/*      */   {
/* 5904 */     Object[] instances = getApplicationEventListeners();
/*      */     
/* 5906 */     if ((instances != null) && (instances.length > 0))
/*      */     {
/* 5908 */       ServletRequestEvent event = new ServletRequestEvent(getServletContext(), request);
/*      */       
/*      */ 
/* 5911 */       for (int i = 0; i < instances.length; i++)
/* 5912 */         if (instances[i] != null)
/*      */         {
/* 5914 */           if ((instances[i] instanceof ServletRequestListener))
/*      */           {
/* 5916 */             ServletRequestListener listener = (ServletRequestListener)instances[i];
/*      */             
/*      */             try
/*      */             {
/* 5920 */               listener.requestInitialized(event);
/*      */             } catch (Throwable t) {
/* 5922 */               ExceptionUtils.handleThrowable(t);
/* 5923 */               getLogger().error(sm.getString("standardContext.requestListener.requestInit", new Object[] { instances[i].getClass().getName() }), t);
/*      */               
/*      */ 
/* 5926 */               request.setAttribute("javax.servlet.error.exception", t);
/* 5927 */               return false;
/*      */             }
/*      */           } }
/*      */     }
/* 5931 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean fireRequestDestroyEvent(ServletRequest request)
/*      */   {
/* 5937 */     Object[] instances = getApplicationEventListeners();
/*      */     
/* 5939 */     if ((instances != null) && (instances.length > 0))
/*      */     {
/* 5941 */       ServletRequestEvent event = new ServletRequestEvent(getServletContext(), request);
/*      */       
/*      */ 
/* 5944 */       for (int i = 0; i < instances.length; i++) {
/* 5945 */         int j = instances.length - 1 - i;
/* 5946 */         if (instances[j] != null)
/*      */         {
/* 5948 */           if ((instances[j] instanceof ServletRequestListener))
/*      */           {
/* 5950 */             ServletRequestListener listener = (ServletRequestListener)instances[j];
/*      */             
/*      */             try
/*      */             {
/* 5954 */               listener.requestDestroyed(event);
/*      */             } catch (Throwable t) {
/* 5956 */               ExceptionUtils.handleThrowable(t);
/* 5957 */               getLogger().error(sm.getString("standardContext.requestListener.requestInit", new Object[] { instances[j].getClass().getName() }), t);
/*      */               
/*      */ 
/* 5960 */               request.setAttribute("javax.servlet.error.exception", t);
/* 5961 */               return false;
/*      */             }
/*      */           } }
/*      */       } }
/* 5965 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */   public void addPostConstructMethod(String clazz, String method)
/*      */   {
/* 5971 */     if ((clazz == null) || (method == null)) {
/* 5972 */       throw new IllegalArgumentException(sm.getString("standardContext.postconstruct.required"));
/*      */     }
/* 5974 */     if (this.postConstructMethods.get(clazz) != null) {
/* 5975 */       throw new IllegalArgumentException(sm.getString("standardContext.postconstruct.duplicate", new Object[] { clazz }));
/*      */     }
/*      */     
/* 5978 */     this.postConstructMethods.put(clazz, method);
/* 5979 */     fireContainerEvent("addPostConstructMethod", clazz);
/*      */   }
/*      */   
/*      */ 
/*      */   public void removePostConstructMethod(String clazz)
/*      */   {
/* 5985 */     this.postConstructMethods.remove(clazz);
/* 5986 */     fireContainerEvent("removePostConstructMethod", clazz);
/*      */   }
/*      */   
/*      */ 
/*      */   public void addPreDestroyMethod(String clazz, String method)
/*      */   {
/* 5992 */     if ((clazz == null) || (method == null)) {
/* 5993 */       throw new IllegalArgumentException(sm.getString("standardContext.predestroy.required"));
/*      */     }
/* 5995 */     if (this.preDestroyMethods.get(clazz) != null) {
/* 5996 */       throw new IllegalArgumentException(sm.getString("standardContext.predestroy.duplicate", new Object[] { clazz }));
/*      */     }
/*      */     
/* 5999 */     this.preDestroyMethods.put(clazz, method);
/* 6000 */     fireContainerEvent("addPreDestroyMethod", clazz);
/*      */   }
/*      */   
/*      */ 
/*      */   public void removePreDestroyMethod(String clazz)
/*      */   {
/* 6006 */     this.preDestroyMethods.remove(clazz);
/* 6007 */     fireContainerEvent("removePreDestroyMethod", clazz);
/*      */   }
/*      */   
/*      */ 
/*      */   public String findPostConstructMethod(String clazz)
/*      */   {
/* 6013 */     return (String)this.postConstructMethods.get(clazz);
/*      */   }
/*      */   
/*      */ 
/*      */   public String findPreDestroyMethod(String clazz)
/*      */   {
/* 6019 */     return (String)this.preDestroyMethods.get(clazz);
/*      */   }
/*      */   
/*      */ 
/*      */   public Map<String, String> findPostConstructMethods()
/*      */   {
/* 6025 */     return this.postConstructMethods;
/*      */   }
/*      */   
/*      */ 
/*      */   public Map<String, String> findPreDestroyMethods()
/*      */   {
/* 6031 */     return this.preDestroyMethods;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void postWorkDirectory()
/*      */   {
/* 6041 */     String workDir = getWorkDir();
/* 6042 */     if ((workDir == null) || (workDir.length() == 0))
/*      */     {
/*      */ 
/* 6045 */       String hostName = null;
/* 6046 */       String engineName = null;
/* 6047 */       String hostWorkDir = null;
/* 6048 */       Container parentHost = getParent();
/* 6049 */       if (parentHost != null) {
/* 6050 */         hostName = parentHost.getName();
/* 6051 */         if ((parentHost instanceof StandardHost)) {
/* 6052 */           hostWorkDir = ((StandardHost)parentHost).getWorkDir();
/*      */         }
/* 6054 */         Container parentEngine = parentHost.getParent();
/* 6055 */         if (parentEngine != null) {
/* 6056 */           engineName = parentEngine.getName();
/*      */         }
/*      */       }
/* 6059 */       if ((hostName == null) || (hostName.length() < 1))
/* 6060 */         hostName = "_";
/* 6061 */       if ((engineName == null) || (engineName.length() < 1)) {
/* 6062 */         engineName = "_";
/*      */       }
/* 6064 */       String temp = getBaseName();
/* 6065 */       if (temp.startsWith("/"))
/* 6066 */         temp = temp.substring(1);
/* 6067 */       temp = temp.replace('/', '_');
/* 6068 */       temp = temp.replace('\\', '_');
/* 6069 */       if (temp.length() < 1)
/* 6070 */         temp = "ROOT";
/* 6071 */       if (hostWorkDir != null) {
/* 6072 */         workDir = hostWorkDir + File.separator + temp;
/*      */       } else {
/* 6074 */         workDir = "work" + File.separator + engineName + File.separator + hostName + File.separator + temp;
/*      */       }
/*      */       
/* 6077 */       setWorkDir(workDir);
/*      */     }
/*      */     
/*      */ 
/* 6081 */     File dir = new File(workDir);
/* 6082 */     if (!dir.isAbsolute()) {
/* 6083 */       String catalinaHomePath = null;
/*      */       try {
/* 6085 */         catalinaHomePath = getCatalinaBase().getCanonicalPath();
/* 6086 */         dir = new File(catalinaHomePath, workDir);
/*      */       } catch (IOException e) {
/* 6088 */         log.warn(sm.getString("standardContext.workCreateException", new Object[] { workDir, catalinaHomePath, getName() }), e);
/*      */       }
/*      */     }
/*      */     
/* 6092 */     if ((!dir.mkdirs()) && (!dir.isDirectory())) {
/* 6093 */       log.warn(sm.getString("standardContext.workCreateFail", new Object[] { dir, getName() }));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 6098 */     if (this.context == null) {
/* 6099 */       getServletContext();
/*      */     }
/* 6101 */     this.context.setAttribute("javax.servlet.context.tempdir", dir);
/* 6102 */     this.context.setAttributeReadOnly("javax.servlet.context.tempdir");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void setPaused(boolean paused)
/*      */   {
/* 6113 */     this.paused = paused;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean validateURLPattern(String urlPattern)
/*      */   {
/* 6127 */     if (urlPattern == null)
/* 6128 */       return false;
/* 6129 */     if ((urlPattern.indexOf('\n') >= 0) || (urlPattern.indexOf('\r') >= 0)) {
/* 6130 */       return false;
/*      */     }
/* 6132 */     if (urlPattern.equals("")) {
/* 6133 */       return true;
/*      */     }
/* 6135 */     if (urlPattern.startsWith("*.")) {
/* 6136 */       if (urlPattern.indexOf('/') < 0) {
/* 6137 */         checkUnusualURLPattern(urlPattern);
/* 6138 */         return true;
/*      */       }
/* 6140 */       return false;
/*      */     }
/* 6142 */     if ((urlPattern.startsWith("/")) && (urlPattern.indexOf("*.") < 0))
/*      */     {
/* 6144 */       checkUnusualURLPattern(urlPattern);
/* 6145 */       return true;
/*      */     }
/* 6147 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkUnusualURLPattern(String urlPattern)
/*      */   {
/* 6157 */     if (log.isInfoEnabled())
/*      */     {
/*      */ 
/* 6160 */       if (((urlPattern.endsWith("*")) && ((urlPattern.length() < 2) || (urlPattern.charAt(urlPattern.length() - 2) != '/'))) || ((urlPattern.startsWith("*.")) && (urlPattern.length() > 2) && (urlPattern.lastIndexOf('.') > 1)))
/*      */       {
/*      */ 
/*      */ 
/* 6164 */         log.info("Suspicious url pattern: \"" + urlPattern + "\"" + " in context [" + getName() + "] - see" + " sections 12.1 and 12.2 of the Servlet specification");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getObjectNameKeyProperties()
/*      */   {
/* 6177 */     StringBuilder keyProperties = new StringBuilder("j2eeType=WebModule,");
/*      */     
/* 6179 */     keyProperties.append(getObjectKeyPropertiesNameOnly());
/* 6180 */     keyProperties.append(",J2EEApplication=");
/* 6181 */     keyProperties.append(getJ2EEApplication());
/* 6182 */     keyProperties.append(",J2EEServer=");
/* 6183 */     keyProperties.append(getJ2EEServer());
/*      */     
/* 6185 */     return keyProperties.toString();
/*      */   }
/*      */   
/*      */   private String getObjectKeyPropertiesNameOnly() {
/* 6189 */     StringBuilder result = new StringBuilder("name=//");
/* 6190 */     String hostname = getParent().getName();
/* 6191 */     if (hostname == null) {
/* 6192 */       result.append("DEFAULT");
/*      */     } else {
/* 6194 */       result.append(hostname);
/*      */     }
/*      */     
/* 6197 */     String contextName = getName();
/* 6198 */     if (!contextName.startsWith("/")) {
/* 6199 */       result.append('/');
/*      */     }
/* 6201 */     result.append(contextName);
/*      */     
/* 6203 */     return result.toString();
/*      */   }
/*      */   
/*      */   protected void initInternal() throws LifecycleException
/*      */   {
/* 6208 */     super.initInternal();
/*      */     
/*      */ 
/* 6211 */     if (this.namingResources != null) {
/* 6212 */       this.namingResources.init();
/*      */     }
/*      */     
/*      */ 
/* 6216 */     if (getObjectName() != null) {
/* 6217 */       Notification notification = new Notification("j2ee.object.created", getObjectName(), this.sequenceNumber.getAndIncrement());
/*      */       
/* 6219 */       this.broadcaster.sendNotification(notification);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeNotificationListener(NotificationListener listener, NotificationFilter filter, Object object)
/*      */     throws ListenerNotFoundException
/*      */   {
/* 6230 */     this.broadcaster.removeNotificationListener(listener, filter, object);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MBeanNotificationInfo[] getNotificationInfo()
/*      */   {
/* 6243 */     if (this.notificationInfo == null) {
/* 6244 */       this.notificationInfo = new MBeanNotificationInfo[] { new MBeanNotificationInfo(new String[] { "j2ee.object.created" }, Notification.class.getName(), "web application is created"), new MBeanNotificationInfo(new String[] { "j2ee.state.starting" }, Notification.class.getName(), "change web application is starting"), new MBeanNotificationInfo(new String[] { "j2ee.state.running" }, Notification.class.getName(), "web application is running"), new MBeanNotificationInfo(new String[] { "j2ee.state.stopping" }, Notification.class.getName(), "web application start to stopped"), new MBeanNotificationInfo(new String[] { "j2ee.object.stopped" }, Notification.class.getName(), "web application is stopped"), new MBeanNotificationInfo(new String[] { "j2ee.object.deleted" }, Notification.class.getName(), "web application is deleted") };
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6279 */     return this.notificationInfo;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addNotificationListener(NotificationListener listener, NotificationFilter filter, Object object)
/*      */     throws IllegalArgumentException
/*      */   {
/* 6290 */     this.broadcaster.addNotificationListener(listener, filter, object);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeNotificationListener(NotificationListener listener)
/*      */     throws ListenerNotFoundException
/*      */   {
/* 6301 */     this.broadcaster.removeNotificationListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getWelcomeFiles()
/*      */   {
/* 6312 */     return findWelcomeFiles();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getXmlNamespaceAware()
/*      */   {
/* 6319 */     return this.webXmlNamespaceAware;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setXmlNamespaceAware(boolean webXmlNamespaceAware)
/*      */   {
/* 6325 */     this.webXmlNamespaceAware = webXmlNamespaceAware;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setXmlValidation(boolean webXmlValidation)
/*      */   {
/* 6331 */     this.webXmlValidation = webXmlValidation;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getXmlValidation()
/*      */   {
/* 6337 */     return this.webXmlValidation;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setXmlBlockExternal(boolean xmlBlockExternal)
/*      */   {
/* 6343 */     this.xmlBlockExternal = xmlBlockExternal;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getXmlBlockExternal()
/*      */   {
/* 6349 */     return this.xmlBlockExternal;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTldValidation(boolean tldValidation)
/*      */   {
/* 6355 */     this.tldValidation = tldValidation;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getTldValidation()
/*      */   {
/* 6361 */     return this.tldValidation;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6368 */   private String server = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6373 */   private String[] javaVMs = null;
/*      */   
/*      */   public String getServer() {
/* 6376 */     return this.server;
/*      */   }
/*      */   
/*      */   public String setServer(String server) {
/* 6380 */     return this.server = server;
/*      */   }
/*      */   
/*      */   public String[] getJavaVMs() {
/* 6384 */     return this.javaVMs;
/*      */   }
/*      */   
/*      */   public String[] setJavaVMs(String[] javaVMs) {
/* 6388 */     return this.javaVMs = javaVMs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getStartTime()
/*      */   {
/* 6398 */     return this.startTime;
/*      */   }
/*      */   
/*      */   private static class NoPluggabilityServletContext
/*      */     implements ServletContext
/*      */   {
/*      */     private final ServletContext sc;
/*      */     
/*      */     public NoPluggabilityServletContext(ServletContext sc)
/*      */     {
/* 6408 */       this.sc = sc;
/*      */     }
/*      */     
/*      */     public String getContextPath()
/*      */     {
/* 6413 */       return this.sc.getContextPath();
/*      */     }
/*      */     
/*      */     public ServletContext getContext(String uripath)
/*      */     {
/* 6418 */       return this.sc.getContext(uripath);
/*      */     }
/*      */     
/*      */     public int getMajorVersion()
/*      */     {
/* 6423 */       return this.sc.getMajorVersion();
/*      */     }
/*      */     
/*      */     public int getMinorVersion()
/*      */     {
/* 6428 */       return this.sc.getMinorVersion();
/*      */     }
/*      */     
/*      */     public int getEffectiveMajorVersion()
/*      */     {
/* 6433 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public int getEffectiveMinorVersion()
/*      */     {
/* 6439 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public String getMimeType(String file)
/*      */     {
/* 6445 */       return this.sc.getMimeType(file);
/*      */     }
/*      */     
/*      */     public Set<String> getResourcePaths(String path)
/*      */     {
/* 6450 */       return this.sc.getResourcePaths(path);
/*      */     }
/*      */     
/*      */     public URL getResource(String path) throws MalformedURLException
/*      */     {
/* 6455 */       return this.sc.getResource(path);
/*      */     }
/*      */     
/*      */     public InputStream getResourceAsStream(String path)
/*      */     {
/* 6460 */       return this.sc.getResourceAsStream(path);
/*      */     }
/*      */     
/*      */     public RequestDispatcher getRequestDispatcher(String path)
/*      */     {
/* 6465 */       return this.sc.getRequestDispatcher(path);
/*      */     }
/*      */     
/*      */     public RequestDispatcher getNamedDispatcher(String name)
/*      */     {
/* 6470 */       return this.sc.getNamedDispatcher(name);
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Servlet getServlet(String name) throws ServletException
/*      */     {
/* 6476 */       return this.sc.getServlet(name);
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Enumeration<Servlet> getServlets()
/*      */     {
/* 6482 */       return this.sc.getServlets();
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Enumeration<String> getServletNames()
/*      */     {
/* 6488 */       return this.sc.getServletNames();
/*      */     }
/*      */     
/*      */     public void log(String msg)
/*      */     {
/* 6493 */       this.sc.log(msg);
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public void log(Exception exception, String msg)
/*      */     {
/* 6499 */       this.sc.log(exception, msg);
/*      */     }
/*      */     
/*      */     public void log(String message, Throwable throwable)
/*      */     {
/* 6504 */       this.sc.log(message, throwable);
/*      */     }
/*      */     
/*      */     public String getRealPath(String path)
/*      */     {
/* 6509 */       return this.sc.getRealPath(path);
/*      */     }
/*      */     
/*      */     public String getServerInfo()
/*      */     {
/* 6514 */       return this.sc.getServerInfo();
/*      */     }
/*      */     
/*      */     public String getInitParameter(String name)
/*      */     {
/* 6519 */       return this.sc.getInitParameter(name);
/*      */     }
/*      */     
/*      */     public Enumeration<String> getInitParameterNames()
/*      */     {
/* 6524 */       return this.sc.getInitParameterNames();
/*      */     }
/*      */     
/*      */     public boolean setInitParameter(String name, String value)
/*      */     {
/* 6529 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public Object getAttribute(String name)
/*      */     {
/* 6535 */       return this.sc.getAttribute(name);
/*      */     }
/*      */     
/*      */     public Enumeration<String> getAttributeNames()
/*      */     {
/* 6540 */       return this.sc.getAttributeNames();
/*      */     }
/*      */     
/*      */     public void setAttribute(String name, Object object)
/*      */     {
/* 6545 */       this.sc.setAttribute(name, object);
/*      */     }
/*      */     
/*      */     public void removeAttribute(String name)
/*      */     {
/* 6550 */       this.sc.removeAttribute(name);
/*      */     }
/*      */     
/*      */     public String getServletContextName()
/*      */     {
/* 6555 */       return this.sc.getServletContextName();
/*      */     }
/*      */     
/*      */     public ServletRegistration.Dynamic addServlet(String servletName, String className)
/*      */     {
/* 6560 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public ServletRegistration.Dynamic addServlet(String servletName, Servlet servlet)
/*      */     {
/* 6566 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public ServletRegistration.Dynamic addServlet(String servletName, Class<? extends Servlet> servletClass)
/*      */     {
/* 6573 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public <T extends Servlet> T createServlet(Class<T> c)
/*      */       throws ServletException
/*      */     {
/* 6580 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public ServletRegistration getServletRegistration(String servletName)
/*      */     {
/* 6586 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public Map<String, ? extends ServletRegistration> getServletRegistrations()
/*      */     {
/* 6592 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public FilterRegistration.Dynamic addFilter(String filterName, String className)
/*      */     {
/* 6599 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public FilterRegistration.Dynamic addFilter(String filterName, Filter filter)
/*      */     {
/* 6606 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public FilterRegistration.Dynamic addFilter(String filterName, Class<? extends Filter> filterClass)
/*      */     {
/* 6613 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public <T extends Filter> T createFilter(Class<T> c)
/*      */       throws ServletException
/*      */     {
/* 6620 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public FilterRegistration getFilterRegistration(String filterName)
/*      */     {
/* 6626 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public Map<String, ? extends FilterRegistration> getFilterRegistrations()
/*      */     {
/* 6632 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public SessionCookieConfig getSessionCookieConfig()
/*      */     {
/* 6638 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setSessionTrackingModes(Set<SessionTrackingMode> sessionTrackingModes)
/*      */     {
/* 6645 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public Set<SessionTrackingMode> getDefaultSessionTrackingModes()
/*      */     {
/* 6651 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public Set<SessionTrackingMode> getEffectiveSessionTrackingModes()
/*      */     {
/* 6657 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public void addListener(String className)
/*      */     {
/* 6663 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public <T extends EventListener> void addListener(T t)
/*      */     {
/* 6669 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public void addListener(Class<? extends EventListener> listenerClass)
/*      */     {
/* 6675 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public <T extends EventListener> T createListener(Class<T> c)
/*      */       throws ServletException
/*      */     {
/* 6682 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public JspConfigDescriptor getJspConfigDescriptor()
/*      */     {
/* 6688 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public ClassLoader getClassLoader()
/*      */     {
/* 6694 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public void declareRoles(String... roleNames)
/*      */     {
/* 6700 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public String getVirtualServerName()
/*      */     {
/* 6706 */       return this.sc.getVirtualServerName();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\core\StandardContext.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */