/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.annotation.PreDestroy;
/*     */ import javax.annotation.Resource;
/*     */ import javax.ejb.EJB;
/*     */ import javax.naming.NamingException;
/*     */ import javax.persistence.PersistenceContext;
/*     */ import javax.persistence.PersistenceUnit;
/*     */ import javax.xml.ws.WebServiceRef;
/*     */ import org.apache.catalina.ContainerServlet;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.Loader;
/*     */ import org.apache.catalina.security.SecurityUtil;
/*     */ import org.apache.catalina.util.Introspection;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.InstanceManager;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultInstanceManager
/*     */   implements InstanceManager
/*     */ {
/*  61 */   private static final AnnotationCacheEntry[] ANNOTATIONS_EMPTY = new AnnotationCacheEntry[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.core");
/*     */   
/*     */   private final javax.naming.Context context;
/*     */   
/*     */   private final Map<String, Map<String, String>> injectionMap;
/*     */   protected final ClassLoader classLoader;
/*     */   protected final ClassLoader containerClassLoader;
/*     */   protected final boolean privileged;
/*     */   protected final boolean ignoreAnnotations;
/*     */   private final Set<String> restrictedClasses;
/*  77 */   private final Map<Class<?>, AnnotationCacheEntry[]> annotationCache = new WeakHashMap();
/*     */   
/*     */   private final Map<String, String> postConstructMethods;
/*     */   
/*     */   private final Map<String, String> preDestroyMethods;
/*     */   
/*     */ 
/*     */   public DefaultInstanceManager(javax.naming.Context context, Map<String, Map<String, String>> injectionMap, org.apache.catalina.Context catalinaContext, ClassLoader containerClassLoader)
/*     */   {
/*  86 */     this.classLoader = catalinaContext.getLoader().getClassLoader();
/*  87 */     this.privileged = catalinaContext.getPrivileged();
/*  88 */     this.containerClassLoader = containerClassLoader;
/*  89 */     this.ignoreAnnotations = catalinaContext.getIgnoreAnnotations();
/*  90 */     Log log = catalinaContext.getLogger();
/*  91 */     Set<String> classNames = new HashSet();
/*  92 */     loadProperties(classNames, "org/apache/catalina/core/RestrictedServlets.properties", "defaultInstanceManager.restrictedServletsResource", log);
/*     */     
/*     */ 
/*  95 */     loadProperties(classNames, "org/apache/catalina/core/RestrictedListeners.properties", "defaultInstanceManager.restrictedListenersResource", log);
/*     */     
/*     */ 
/*  98 */     loadProperties(classNames, "org/apache/catalina/core/RestrictedFilters.properties", "defaultInstanceManager.restrictedFiltersResource", log);
/*     */     
/*     */ 
/* 101 */     this.restrictedClasses = Collections.unmodifiableSet(classNames);
/* 102 */     this.context = context;
/* 103 */     this.injectionMap = injectionMap;
/* 104 */     this.postConstructMethods = catalinaContext.findPostConstructMethods();
/* 105 */     this.preDestroyMethods = catalinaContext.findPreDestroyMethods();
/*     */   }
/*     */   
/*     */   public Object newInstance(Class<?> clazz)
/*     */     throws IllegalAccessException, InvocationTargetException, NamingException, InstantiationException
/*     */   {
/* 111 */     return newInstance(clazz.newInstance(), clazz);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object newInstance(String className)
/*     */     throws IllegalAccessException, InvocationTargetException, NamingException, InstantiationException, ClassNotFoundException
/*     */   {
/* 118 */     Class<?> clazz = loadClassMaybePrivileged(className, this.classLoader);
/* 119 */     return newInstance(clazz.newInstance(), clazz);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object newInstance(String className, ClassLoader classLoader)
/*     */     throws IllegalAccessException, NamingException, InvocationTargetException, InstantiationException, ClassNotFoundException
/*     */   {
/* 127 */     Class<?> clazz = classLoader.loadClass(className);
/* 128 */     return newInstance(clazz.newInstance(), clazz);
/*     */   }
/*     */   
/*     */   public void newInstance(Object o)
/*     */     throws IllegalAccessException, InvocationTargetException, NamingException
/*     */   {
/* 134 */     newInstance(o, o.getClass());
/*     */   }
/*     */   
/*     */   private Object newInstance(Object instance, Class<?> clazz) throws IllegalAccessException, InvocationTargetException, NamingException
/*     */   {
/* 139 */     if (!this.ignoreAnnotations) {
/* 140 */       Map<String, String> injections = assembleInjectionsFromClassHierarchy(clazz);
/* 141 */       populateAnnotationsCache(clazz, injections);
/* 142 */       processAnnotations(instance, injections);
/* 143 */       postConstruct(instance, clazz);
/*     */     }
/* 145 */     return instance;
/*     */   }
/*     */   
/*     */   private Map<String, String> assembleInjectionsFromClassHierarchy(Class<?> clazz) {
/* 149 */     Map<String, String> injections = new HashMap();
/* 150 */     Map<String, String> currentInjections = null;
/* 151 */     while (clazz != null) {
/* 152 */       currentInjections = (Map)this.injectionMap.get(clazz.getName());
/* 153 */       if (currentInjections != null) {
/* 154 */         injections.putAll(currentInjections);
/*     */       }
/* 156 */       clazz = clazz.getSuperclass();
/*     */     }
/* 158 */     return injections;
/*     */   }
/*     */   
/*     */   public void destroyInstance(Object instance)
/*     */     throws IllegalAccessException, InvocationTargetException
/*     */   {
/* 164 */     if (!this.ignoreAnnotations) {
/* 165 */       preDestroy(instance, instance.getClass());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void postConstruct(Object instance, Class<?> clazz)
/*     */     throws IllegalAccessException, InvocationTargetException
/*     */   {
/* 181 */     if (this.context == null)
/*     */     {
/* 183 */       return;
/*     */     }
/*     */     
/* 186 */     Class<?> superClass = clazz.getSuperclass();
/* 187 */     if (superClass != Object.class) {
/* 188 */       postConstruct(instance, superClass);
/*     */     }
/*     */     
/*     */ 
/*     */     AnnotationCacheEntry[] annotations;
/*     */     
/* 194 */     synchronized (this.annotationCache) {
/* 195 */       annotations = (AnnotationCacheEntry[])this.annotationCache.get(clazz); }
/*     */     AnnotationCacheEntry[] annotations;
/* 197 */     for (AnnotationCacheEntry entry : annotations) {
/* 198 */       if (entry.getType() == AnnotationCacheEntryType.POST_CONSTRUCT) {
/* 199 */         Method postConstruct = getMethod(clazz, entry);
/* 200 */         synchronized (postConstruct) {
/* 201 */           boolean accessibility = postConstruct.isAccessible();
/* 202 */           postConstruct.setAccessible(true);
/* 203 */           postConstruct.invoke(instance, new Object[0]);
/* 204 */           postConstruct.setAccessible(accessibility);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void preDestroy(Object instance, Class<?> clazz)
/*     */     throws IllegalAccessException, InvocationTargetException
/*     */   {
/* 223 */     Class<?> superClass = clazz.getSuperclass();
/* 224 */     if (superClass != Object.class) {
/* 225 */       preDestroy(instance, superClass);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 230 */     AnnotationCacheEntry[] annotations = null;
/* 231 */     synchronized (this.annotationCache) {
/* 232 */       annotations = (AnnotationCacheEntry[])this.annotationCache.get(clazz);
/*     */     }
/* 234 */     if (annotations == null)
/*     */     {
/* 236 */       return;
/*     */     }
/* 238 */     for (AnnotationCacheEntry entry : annotations) {
/* 239 */       if (entry.getType() == AnnotationCacheEntryType.PRE_DESTROY) {
/* 240 */         Method preDestroy = getMethod(clazz, entry);
/* 241 */         synchronized (preDestroy) {
/* 242 */           boolean accessibility = preDestroy.isAccessible();
/* 243 */           preDestroy.setAccessible(true);
/* 244 */           preDestroy.invoke(instance, new Object[0]);
/* 245 */           preDestroy.setAccessible(accessibility);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void populateAnnotationsCache(Class<?> clazz, Map<String, String> injections)
/*     */     throws IllegalAccessException, InvocationTargetException, NamingException
/*     */   {
/* 268 */     List<AnnotationCacheEntry> annotations = null;
/*     */     
/* 270 */     while (clazz != null) {
/* 271 */       AnnotationCacheEntry[] annotationsArray = null;
/* 272 */       synchronized (this.annotationCache) {
/* 273 */         annotationsArray = (AnnotationCacheEntry[])this.annotationCache.get(clazz);
/*     */       }
/* 275 */       if (annotationsArray == null) {
/* 276 */         if (annotations == null) {
/* 277 */           annotations = new ArrayList();
/*     */         } else {
/* 279 */           annotations.clear();
/*     */         }
/*     */         
/* 282 */         if (this.context != null)
/*     */         {
/*     */ 
/* 285 */           Field[] fields = Introspection.getDeclaredFields(clazz);
/* 286 */           for (Field field : fields)
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 292 */             if ((injections != null) && (injections.containsKey(field.getName()))) {
/* 293 */               annotations.add(new AnnotationCacheEntry(field.getName(), null, (String)injections.get(field.getName()), AnnotationCacheEntryType.FIELD));
/*     */             }
/*     */             else {
/*     */               Resource resourceAnnotation;
/* 297 */               if ((resourceAnnotation = (Resource)field.getAnnotation(Resource.class)) != null)
/*     */               {
/* 299 */                 annotations.add(new AnnotationCacheEntry(field.getName(), null, resourceAnnotation.name(), AnnotationCacheEntryType.FIELD));
/*     */               } else { EJB ejbAnnotation;
/* 301 */                 if ((ejbAnnotation = (EJB)field.getAnnotation(EJB.class)) != null)
/*     */                 {
/* 303 */                   annotations.add(new AnnotationCacheEntry(field.getName(), null, ejbAnnotation.name(), AnnotationCacheEntryType.FIELD));
/*     */                 } else { WebServiceRef webServiceRefAnnotation;
/* 305 */                   if ((webServiceRefAnnotation = (WebServiceRef)field.getAnnotation(WebServiceRef.class)) != null)
/*     */                   {
/* 307 */                     annotations.add(new AnnotationCacheEntry(field.getName(), null, webServiceRefAnnotation.name(), AnnotationCacheEntryType.FIELD));
/*     */                   } else {
/*     */                     PersistenceContext persistenceContextAnnotation;
/* 310 */                     if ((persistenceContextAnnotation = (PersistenceContext)field.getAnnotation(PersistenceContext.class)) != null)
/*     */                     {
/* 312 */                       annotations.add(new AnnotationCacheEntry(field.getName(), null, persistenceContextAnnotation.name(), AnnotationCacheEntryType.FIELD));
/*     */                     } else {
/*     */                       PersistenceUnit persistenceUnitAnnotation;
/* 315 */                       if ((persistenceUnitAnnotation = (PersistenceUnit)field.getAnnotation(PersistenceUnit.class)) != null)
/*     */                       {
/* 317 */                         annotations.add(new AnnotationCacheEntry(field.getName(), null, persistenceUnitAnnotation.name(), AnnotationCacheEntryType.FIELD)); }
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/* 325 */         Method[] methods = Introspection.getDeclaredMethods(clazz);
/* 326 */         Method postConstruct = null;
/* 327 */         String postConstructFromXml = (String)this.postConstructMethods.get(clazz.getName());
/* 328 */         Method preDestroy = null;
/* 329 */         String preDestroyFromXml = (String)this.preDestroyMethods.get(clazz.getName());
/* 330 */         for (Method method : methods) {
/* 331 */           if (this.context != null)
/*     */           {
/* 333 */             if ((injections != null) && (Introspection.isValidSetter(method)))
/*     */             {
/* 335 */               String fieldName = Introspection.getPropertyName(method);
/* 336 */               if (injections.containsKey(fieldName)) {
/* 337 */                 annotations.add(new AnnotationCacheEntry(method.getName(), method.getParameterTypes(), (String)injections.get(fieldName), AnnotationCacheEntryType.SETTER));
/*     */                 
/*     */ 
/*     */ 
/*     */ 
/* 342 */                 continue;
/*     */               }
/*     */             }
/*     */             
/*     */ 
/*     */             Resource resourceAnnotation;
/*     */             
/*     */ 
/* 350 */             if ((resourceAnnotation = (Resource)method.getAnnotation(Resource.class)) != null)
/*     */             {
/* 352 */               annotations.add(new AnnotationCacheEntry(method.getName(), method.getParameterTypes(), resourceAnnotation.name(), AnnotationCacheEntryType.SETTER));
/*     */             }
/*     */             else
/*     */             {
/*     */               EJB ejbAnnotation;
/* 357 */               if ((ejbAnnotation = (EJB)method.getAnnotation(EJB.class)) != null)
/*     */               {
/* 359 */                 annotations.add(new AnnotationCacheEntry(method.getName(), method.getParameterTypes(), ejbAnnotation.name(), AnnotationCacheEntryType.SETTER));
/*     */               }
/*     */               else
/*     */               {
/*     */                 WebServiceRef webServiceRefAnnotation;
/* 364 */                 if ((webServiceRefAnnotation = (WebServiceRef)method.getAnnotation(WebServiceRef.class)) != null)
/*     */                 {
/* 366 */                   annotations.add(new AnnotationCacheEntry(method.getName(), method.getParameterTypes(), webServiceRefAnnotation.name(), AnnotationCacheEntryType.SETTER));
/*     */                 }
/*     */                 else
/*     */                 {
/*     */                   PersistenceContext persistenceContextAnnotation;
/* 371 */                   if ((persistenceContextAnnotation = (PersistenceContext)method.getAnnotation(PersistenceContext.class)) != null)
/*     */                   {
/* 373 */                     annotations.add(new AnnotationCacheEntry(method.getName(), method.getParameterTypes(), persistenceContextAnnotation.name(), AnnotationCacheEntryType.SETTER));
/*     */                   }
/*     */                   else
/*     */                   {
/*     */                     PersistenceUnit persistenceUnitAnnotation;
/* 378 */                     if ((persistenceUnitAnnotation = (PersistenceUnit)method.getAnnotation(PersistenceUnit.class)) != null) {
/* 379 */                       annotations.add(new AnnotationCacheEntry(method.getName(), method.getParameterTypes(), persistenceUnitAnnotation.name(), AnnotationCacheEntryType.SETTER));
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */           
/* 387 */           postConstruct = findPostConstruct(postConstruct, postConstructFromXml, method);
/*     */           
/* 389 */           preDestroy = findPreDestroy(preDestroy, preDestroyFromXml, method);
/*     */         }
/*     */         
/* 392 */         if (postConstruct != null) {
/* 393 */           annotations.add(new AnnotationCacheEntry(postConstruct.getName(), postConstruct.getParameterTypes(), null, AnnotationCacheEntryType.POST_CONSTRUCT));
/*     */ 
/*     */ 
/*     */         }
/* 397 */         else if (postConstructFromXml != null) {
/* 398 */           throw new IllegalArgumentException("Post construct method " + postConstructFromXml + " for class " + clazz.getName() + " is declared in deployment descriptor but cannot be found.");
/*     */         }
/*     */         
/*     */ 
/* 402 */         if (preDestroy != null) {
/* 403 */           annotations.add(new AnnotationCacheEntry(preDestroy.getName(), preDestroy.getParameterTypes(), null, AnnotationCacheEntryType.PRE_DESTROY));
/*     */ 
/*     */ 
/*     */         }
/* 407 */         else if (preDestroyFromXml != null) {
/* 408 */           throw new IllegalArgumentException("Pre destroy method " + preDestroyFromXml + " for class " + clazz.getName() + " is declared in deployment descriptor but cannot be found.");
/*     */         }
/*     */         
/*     */ 
/* 412 */         if (annotations.isEmpty())
/*     */         {
/* 414 */           annotationsArray = ANNOTATIONS_EMPTY;
/*     */         } else {
/* 416 */           annotationsArray = (AnnotationCacheEntry[])annotations.toArray(new AnnotationCacheEntry[annotations.size()]);
/*     */         }
/*     */         
/* 419 */         synchronized (this.annotationCache) {
/* 420 */           this.annotationCache.put(clazz, annotationsArray);
/*     */         }
/*     */       }
/* 423 */       clazz = clazz.getSuperclass();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void processAnnotations(Object instance, Map<String, String> injections)
/*     */     throws IllegalAccessException, InvocationTargetException, NamingException
/*     */   {
/* 441 */     if (this.context == null)
/*     */     {
/* 443 */       return;
/*     */     }
/*     */     
/* 446 */     Class<?> clazz = instance.getClass();
/*     */     
/* 448 */     while (clazz != null) {
/*     */       AnnotationCacheEntry[] annotations;
/* 450 */       synchronized (this.annotationCache) {
/* 451 */         annotations = (AnnotationCacheEntry[])this.annotationCache.get(clazz); }
/*     */       AnnotationCacheEntry[] annotations;
/* 453 */       for (AnnotationCacheEntry entry : annotations) {
/* 454 */         if (entry.getType() == AnnotationCacheEntryType.SETTER) {
/* 455 */           lookupMethodResource(this.context, instance, getMethod(clazz, entry), entry.getName(), clazz);
/*     */ 
/*     */         }
/* 458 */         else if (entry.getType() == AnnotationCacheEntryType.FIELD) {
/* 459 */           lookupFieldResource(this.context, instance, getField(clazz, entry), entry.getName(), clazz);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 464 */       clazz = clazz.getSuperclass();
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected int getAnnotationCacheSize()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 4	org/apache/catalina/core/DefaultInstanceManager:annotationCache	Ljava/util/Map;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 4	org/apache/catalina/core/DefaultInstanceManager:annotationCache	Ljava/util/Map;
/*     */     //   11: invokeinterface 107 1 0
/*     */     //   16: aload_1
/*     */     //   17: monitorexit
/*     */     //   18: ireturn
/*     */     //   19: astore_2
/*     */     //   20: aload_1
/*     */     //   21: monitorexit
/*     */     //   22: aload_2
/*     */     //   23: athrow
/*     */     // Line number table:
/*     */     //   Java source line #475	-> byte code offset #0
/*     */     //   Java source line #476	-> byte code offset #7
/*     */     //   Java source line #477	-> byte code offset #19
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	24	0	this	DefaultInstanceManager
/*     */     //   5	16	1	Ljava/lang/Object;	Object
/*     */     //   19	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	18	19	finally
/*     */     //   19	22	19	finally
/*     */   }
/*     */   
/*     */   protected Class<?> loadClassMaybePrivileged(final String className, final ClassLoader classLoader)
/*     */     throws ClassNotFoundException
/*     */   {
/*     */     Class<?> clazz;
/* 484 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 486 */         clazz = (Class)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */         {
/*     */ 
/*     */           public Class<?> run() throws Exception {
/* 490 */             return DefaultInstanceManager.this.loadClass(className, classLoader); }
/*     */         });
/*     */       } catch (PrivilegedActionException e) {
/*     */         Class<?> clazz;
/* 494 */         Throwable t = e.getCause();
/* 495 */         if ((t instanceof ClassNotFoundException)) {
/* 496 */           throw ((ClassNotFoundException)t);
/*     */         }
/* 498 */         throw new RuntimeException(t);
/*     */       }
/*     */     } else {
/* 501 */       clazz = loadClass(className, classLoader);
/*     */     }
/* 503 */     checkAccess(clazz);
/* 504 */     return clazz;
/*     */   }
/*     */   
/*     */   protected Class<?> loadClass(String className, ClassLoader classLoader) throws ClassNotFoundException
/*     */   {
/* 509 */     if (className.startsWith("org.apache.catalina")) {
/* 510 */       return this.containerClassLoader.loadClass(className);
/*     */     }
/*     */     try {
/* 513 */       Class<?> clazz = this.containerClassLoader.loadClass(className);
/* 514 */       if (ContainerServlet.class.isAssignableFrom(clazz)) {
/* 515 */         return clazz;
/*     */       }
/*     */     } catch (Throwable t) {
/* 518 */       ExceptionUtils.handleThrowable(t);
/*     */     }
/* 520 */     return classLoader.loadClass(className);
/*     */   }
/*     */   
/*     */   private void checkAccess(Class<?> clazz) {
/* 524 */     if (this.privileged) {
/* 525 */       return;
/*     */     }
/* 527 */     if (ContainerServlet.class.isAssignableFrom(clazz)) {
/* 528 */       throw new SecurityException(sm.getString("defaultInstanceManager.restrictedContainerServlet", new Object[] { clazz }));
/*     */     }
/*     */     
/* 531 */     while (clazz != null) {
/* 532 */       if (this.restrictedClasses.contains(clazz.getName())) {
/* 533 */         throw new SecurityException(sm.getString("defaultInstanceManager.restrictedClass", new Object[] { clazz }));
/*     */       }
/*     */       
/* 536 */       clazz = clazz.getSuperclass();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void lookupFieldResource(javax.naming.Context context, Object instance, Field field, String name, Class<?> clazz)
/*     */     throws NamingException, IllegalAccessException
/*     */   {
/* 558 */     String normalizedName = normalize(name);
/*     */     Object lookedupResource;
/* 560 */     Object lookedupResource; if ((normalizedName != null) && (normalizedName.length() > 0)) {
/* 561 */       lookedupResource = context.lookup(normalizedName);
/*     */     } else {
/* 563 */       lookedupResource = context.lookup(clazz.getName() + "/" + field.getName());
/*     */     }
/*     */     
/*     */ 
/* 567 */     synchronized (field) {
/* 568 */       boolean accessibility = field.isAccessible();
/* 569 */       field.setAccessible(true);
/* 570 */       field.set(instance, lookedupResource);
/* 571 */       field.setAccessible(accessibility);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     boolean accessibility;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void lookupMethodResource(javax.naming.Context context, Object instance, Method method, String name, Class<?> clazz)
/*     */     throws NamingException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 592 */     if (!Introspection.isValidSetter(method)) {
/* 593 */       throw new IllegalArgumentException(sm.getString("defaultInstanceManager.invalidInjection"));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 600 */     String normalizedName = normalize(name);
/*     */     Object lookedupResource;
/* 602 */     Object lookedupResource; if ((normalizedName != null) && (normalizedName.length() > 0)) {
/* 603 */       lookedupResource = context.lookup(normalizedName);
/*     */     } else {
/* 605 */       lookedupResource = context.lookup(clazz.getName() + "/" + Introspection.getPropertyName(method));
/*     */     }
/*     */     
/*     */ 
/* 609 */     synchronized (method) {
/* 610 */       boolean accessibility = method.isAccessible();
/* 611 */       method.setAccessible(true);
/* 612 */       method.invoke(instance, new Object[] { lookedupResource });
/* 613 */       method.setAccessible(accessibility);
/*     */     }
/*     */     boolean accessibility;
/*     */   }
/*     */   
/*     */   private static void loadProperties(Set<String> classNames, String resourceName, String messageKey, Log log) {
/* 619 */     Properties properties = new Properties();
/* 620 */     ClassLoader cl = DefaultInstanceManager.class.getClassLoader();
/* 621 */     try { InputStream is = cl.getResourceAsStream(resourceName);Throwable localThrowable2 = null;
/* 622 */       try { if (is == null) {
/* 623 */           log.error(sm.getString(messageKey, new Object[] { resourceName }));
/*     */         } else {
/* 625 */           properties.load(is);
/*     */         }
/*     */       }
/*     */       catch (Throwable localThrowable1)
/*     */       {
/* 621 */         localThrowable2 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */       }
/*     */       finally
/*     */       {
/*     */ 
/* 627 */         if (is != null) if (localThrowable2 != null) try { is.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else is.close();
/* 628 */       } } catch (IOException ioe) { log.error(sm.getString(messageKey, new Object[] { resourceName }), ioe);
/*     */     }
/* 630 */     if (properties.isEmpty()) {
/* 631 */       return;
/*     */     }
/* 633 */     for (Object e : properties.entrySet()) {
/* 634 */       if ("restricted".equals(((Map.Entry)e).getValue())) {
/* 635 */         classNames.add(((Map.Entry)e).getKey().toString());
/*     */       } else {
/* 637 */         log.warn(sm.getString("defaultInstanceManager.restrictedWrongValue", new Object[] { resourceName, ((Map.Entry)e).getKey(), ((Map.Entry)e).getValue() }));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static String normalize(String jndiName)
/*     */   {
/* 645 */     if ((jndiName != null) && (jndiName.startsWith("java:comp/env/"))) {
/* 646 */       return jndiName.substring(14);
/*     */     }
/* 648 */     return jndiName;
/*     */   }
/*     */   
/*     */   private static Method getMethod(Class<?> clazz, final AnnotationCacheEntry entry)
/*     */   {
/* 653 */     Method result = null;
/* 654 */     if (Globals.IS_SECURITY_ENABLED) {
/* 655 */       result = (Method)AccessController.doPrivileged(new PrivilegedAction()
/*     */       {
/*     */         public Method run()
/*     */         {
/* 659 */           Method result = null;
/*     */           try {
/* 661 */             result = this.val$clazz.getDeclaredMethod(entry.getAccessibleObjectName(), entry.getParamTypes());
/*     */           }
/*     */           catch (NoSuchMethodException localNoSuchMethodException) {}
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 668 */           return result;
/*     */         }
/*     */       });
/*     */     } else {
/*     */       try {
/* 673 */         result = clazz.getDeclaredMethod(entry.getAccessibleObjectName(), entry.getParamTypes());
/*     */       }
/*     */       catch (NoSuchMethodException localNoSuchMethodException) {}
/*     */     }
/*     */     
/*     */ 
/* 679 */     return result;
/*     */   }
/*     */   
/*     */   private static Field getField(Class<?> clazz, final AnnotationCacheEntry entry)
/*     */   {
/* 684 */     Field result = null;
/* 685 */     if (Globals.IS_SECURITY_ENABLED) {
/* 686 */       result = (Field)AccessController.doPrivileged(new PrivilegedAction()
/*     */       {
/*     */         public Field run()
/*     */         {
/* 690 */           Field result = null;
/*     */           try {
/* 692 */             result = this.val$clazz.getDeclaredField(entry.getAccessibleObjectName());
/*     */           }
/*     */           catch (NoSuchFieldException localNoSuchFieldException) {}
/*     */           
/*     */ 
/*     */ 
/* 698 */           return result;
/*     */         }
/*     */       });
/*     */     } else {
/*     */       try {
/* 703 */         result = clazz.getDeclaredField(entry.getAccessibleObjectName());
/*     */       }
/*     */       catch (NoSuchFieldException localNoSuchFieldException) {}
/*     */     }
/*     */     
/*     */ 
/* 709 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   private static Method findPostConstruct(Method currentPostConstruct, String postConstructFromXml, Method method)
/*     */   {
/* 715 */     return findLifecycleCallback(currentPostConstruct, postConstructFromXml, method, PostConstruct.class);
/*     */   }
/*     */   
/*     */ 
/*     */   private static Method findPreDestroy(Method currentPreDestroy, String preDestroyFromXml, Method method)
/*     */   {
/* 721 */     return findLifecycleCallback(currentPreDestroy, preDestroyFromXml, method, PreDestroy.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static Method findLifecycleCallback(Method currentMethod, String methodNameFromXml, Method method, Class<? extends Annotation> annotation)
/*     */   {
/* 728 */     Method result = currentMethod;
/* 729 */     if (methodNameFromXml != null) {
/* 730 */       if (method.getName().equals(methodNameFromXml)) {
/* 731 */         if (!Introspection.isValidLifecycleCallback(method)) {
/* 732 */           throw new IllegalArgumentException("Invalid " + annotation.getName() + " annotation");
/*     */         }
/*     */         
/* 735 */         result = method;
/*     */       }
/*     */     }
/* 738 */     else if (method.isAnnotationPresent(annotation)) {
/* 739 */       if ((currentMethod != null) || (!Introspection.isValidLifecycleCallback(method))) {
/* 740 */         throw new IllegalArgumentException("Invalid " + annotation.getName() + " annotation");
/*     */       }
/*     */       
/* 743 */       result = method;
/*     */     }
/*     */     
/* 746 */     return result;
/*     */   }
/*     */   
/*     */   private static final class AnnotationCacheEntry
/*     */   {
/*     */     private final String accessibleObjectName;
/*     */     private final Class<?>[] paramTypes;
/*     */     private final String name;
/*     */     private final DefaultInstanceManager.AnnotationCacheEntryType type;
/*     */     
/*     */     public AnnotationCacheEntry(String accessibleObjectName, Class<?>[] paramTypes, String name, DefaultInstanceManager.AnnotationCacheEntryType type)
/*     */     {
/* 758 */       this.accessibleObjectName = accessibleObjectName;
/* 759 */       this.paramTypes = paramTypes;
/* 760 */       this.name = name;
/* 761 */       this.type = type;
/*     */     }
/*     */     
/*     */     public String getAccessibleObjectName() {
/* 765 */       return this.accessibleObjectName;
/*     */     }
/*     */     
/*     */     public Class<?>[] getParamTypes() {
/* 769 */       return this.paramTypes;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 773 */       return this.name;
/*     */     }
/*     */     
/* 776 */     public DefaultInstanceManager.AnnotationCacheEntryType getType() { return this.type; }
/*     */   }
/*     */   
/*     */   private static enum AnnotationCacheEntryType
/*     */   {
/* 781 */     FIELD,  SETTER,  POST_CONSTRUCT,  PRE_DESTROY;
/*     */     
/*     */     private AnnotationCacheEntryType() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\core\DefaultInstanceManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */