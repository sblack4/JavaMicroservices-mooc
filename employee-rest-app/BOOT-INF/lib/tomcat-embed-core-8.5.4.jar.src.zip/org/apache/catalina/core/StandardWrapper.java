/*      */ package org.apache.catalina.core;
/*      */ 
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.PrintStream;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Set;
/*      */ import java.util.Stack;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;
/*      */ import javax.management.ListenerNotFoundException;
/*      */ import javax.management.MBeanNotificationInfo;
/*      */ import javax.management.Notification;
/*      */ import javax.management.NotificationBroadcasterSupport;
/*      */ import javax.management.NotificationEmitter;
/*      */ import javax.management.NotificationFilter;
/*      */ import javax.management.NotificationListener;
/*      */ import javax.management.ObjectName;
/*      */ import javax.servlet.MultipartConfigElement;
/*      */ import javax.servlet.Servlet;
/*      */ import javax.servlet.ServletConfig;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletSecurityElement;
/*      */ import javax.servlet.SingleThreadModel;
/*      */ import javax.servlet.UnavailableException;
/*      */ import javax.servlet.annotation.MultipartConfig;
/*      */ import javax.servlet.annotation.ServletSecurity;
/*      */ import javax.servlet.http.HttpServlet;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.ContainerServlet;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Loader;
/*      */ import org.apache.catalina.Pipeline;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.security.SecurityUtil;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.InstanceManager;
/*      */ import org.apache.tomcat.PeriodicEventListener;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.log.SystemLogHandler;
/*      */ import org.apache.tomcat.util.modeler.Registry;
/*      */ import org.apache.tomcat.util.modeler.Util;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StandardWrapper
/*      */   extends ContainerBase
/*      */   implements ServletConfig, Wrapper, NotificationEmitter
/*      */ {
/*   80 */   private static final Log log = LogFactory.getLog(StandardWrapper.class);
/*      */   
/*   82 */   protected static final String[] DEFAULT_SERVLET_METHODS = { "GET", "HEAD", "POST" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StandardWrapper()
/*      */   {
/*   94 */     this.swValve = new StandardWrapperValve();
/*   95 */     this.pipeline.setBasic(this.swValve);
/*   96 */     this.broadcaster = new NotificationBroadcasterSupport();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  110 */   protected long available = 0L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final NotificationBroadcasterSupport broadcaster;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  121 */   protected final AtomicInteger countAllocated = new AtomicInteger(0);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  127 */   protected final StandardWrapperFacade facade = new StandardWrapperFacade(this);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  133 */   protected volatile Servlet instance = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  139 */   protected volatile boolean instanceInitialized = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  146 */   protected int loadOnStartup = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  152 */   protected final ArrayList<String> mappings = new ArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  159 */   protected HashMap<String, String> parameters = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  167 */   protected HashMap<String, String> references = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  173 */   protected String runAs = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  178 */   protected long sequenceNumber = 0L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  183 */   protected String servletClass = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  189 */   protected volatile boolean singleThreadModel = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  195 */   protected volatile boolean unloading = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  201 */   protected int maxInstances = 20;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  207 */   protected int nInstances = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  213 */   protected Stack<Servlet> instancePool = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  219 */   protected long unloadDelay = 2000L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isJspServlet;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectName jspMonitorON;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  237 */   protected boolean swallowOutput = false;
/*      */   
/*      */   protected StandardWrapperValve swValve;
/*      */   
/*  241 */   protected long loadTime = 0L;
/*  242 */   protected int classLoadTime = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  247 */   protected MultipartConfigElement multipartConfigElement = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  252 */   protected boolean asyncSupported = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  257 */   protected boolean enabled = true;
/*      */   
/*  259 */   protected volatile boolean servletSecurityAnnotationScanRequired = false;
/*      */   
/*  261 */   private boolean overridable = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  267 */   protected static Class<?>[] classType = { ServletConfig.class };
/*      */   
/*  269 */   private final ReentrantReadWriteLock parametersLock = new ReentrantReadWriteLock();
/*      */   
/*      */ 
/*  272 */   private final ReentrantReadWriteLock mappingsLock = new ReentrantReadWriteLock();
/*      */   
/*      */ 
/*  275 */   private final ReentrantReadWriteLock referencesLock = new ReentrantReadWriteLock();
/*      */   
/*      */ 
/*      */   protected MBeanNotificationInfo[] notificationInfo;
/*      */   
/*      */ 
/*      */   public boolean isOverridable()
/*      */   {
/*  283 */     return this.overridable;
/*      */   }
/*      */   
/*      */   public void setOverridable(boolean overridable)
/*      */   {
/*  288 */     this.overridable = overridable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getAvailable()
/*      */   {
/*  302 */     return this.available;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAvailable(long available)
/*      */   {
/*  319 */     long oldAvailable = this.available;
/*  320 */     if (available > System.currentTimeMillis()) {
/*  321 */       this.available = available;
/*      */     } else
/*  323 */       this.available = 0L;
/*  324 */     this.support.firePropertyChange("available", Long.valueOf(oldAvailable), Long.valueOf(this.available));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getCountAllocated()
/*      */   {
/*  336 */     return this.countAllocated.get();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLoadOnStartup()
/*      */   {
/*  347 */     if ((this.isJspServlet) && (this.loadOnStartup < 0))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  353 */       return Integer.MAX_VALUE;
/*      */     }
/*  355 */     return this.loadOnStartup;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLoadOnStartup(int value)
/*      */   {
/*  369 */     int oldLoadOnStartup = this.loadOnStartup;
/*  370 */     this.loadOnStartup = value;
/*  371 */     this.support.firePropertyChange("loadOnStartup", Integer.valueOf(oldLoadOnStartup), Integer.valueOf(this.loadOnStartup));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLoadOnStartupString(String value)
/*      */   {
/*      */     try
/*      */     {
/*  390 */       setLoadOnStartup(Integer.parseInt(value));
/*      */     } catch (NumberFormatException e) {
/*  392 */       setLoadOnStartup(0);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getLoadOnStartupString()
/*      */   {
/*  400 */     return Integer.toString(getLoadOnStartup());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxInstances()
/*      */   {
/*  410 */     return this.maxInstances;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxInstances(int maxInstances)
/*      */   {
/*  423 */     int oldMaxInstances = this.maxInstances;
/*  424 */     this.maxInstances = maxInstances;
/*  425 */     this.support.firePropertyChange("maxInstances", oldMaxInstances, this.maxInstances);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParent(Container container)
/*      */   {
/*  439 */     if ((container != null) && (!(container instanceof Context)))
/*      */     {
/*  441 */       throw new IllegalArgumentException(sm.getString("standardWrapper.notContext"));
/*      */     }
/*  443 */     if ((container instanceof StandardContext)) {
/*  444 */       this.swallowOutput = ((StandardContext)container).getSwallowOutput();
/*  445 */       this.unloadDelay = ((StandardContext)container).getUnloadDelay();
/*      */     }
/*  447 */     super.setParent(container);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRunAs()
/*      */   {
/*  458 */     return this.runAs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRunAs(String runAs)
/*      */   {
/*  471 */     String oldRunAs = this.runAs;
/*  472 */     this.runAs = runAs;
/*  473 */     this.support.firePropertyChange("runAs", oldRunAs, this.runAs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getServletClass()
/*      */   {
/*  484 */     return this.servletClass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setServletClass(String servletClass)
/*      */   {
/*  497 */     String oldServletClass = this.servletClass;
/*  498 */     this.servletClass = servletClass;
/*  499 */     this.support.firePropertyChange("servletClass", oldServletClass, this.servletClass);
/*      */     
/*  501 */     if ("org.apache.jasper.servlet.JspServlet".equals(servletClass)) {
/*  502 */       this.isJspServlet = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setServletName(String name)
/*      */   {
/*  518 */     setName(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isSingleThreadModel()
/*      */   {
/*  532 */     if ((this.singleThreadModel) || (this.instance != null)) {
/*  533 */       return this.singleThreadModel;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  539 */     ClassLoader oldCL = null;
/*      */     try {
/*  541 */       oldCL = ((Context)getParent()).bind(false, null);
/*  542 */       Servlet s = allocate();
/*  543 */       deallocate(s);
/*      */     } catch (Throwable t) {
/*  545 */       ExceptionUtils.handleThrowable(t);
/*      */     } finally {
/*  547 */       ((Context)getParent()).unbind(false, oldCL);
/*      */     }
/*  549 */     return this.singleThreadModel;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUnavailable()
/*      */   {
/*  560 */     if (!isEnabled())
/*  561 */       return true;
/*  562 */     if (this.available == 0L)
/*  563 */       return false;
/*  564 */     if (this.available <= System.currentTimeMillis()) {
/*  565 */       this.available = 0L;
/*  566 */       return false;
/*      */     }
/*  568 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String[] getServletMethods()
/*      */     throws ServletException
/*      */   {
/*  576 */     this.instance = loadServlet();
/*      */     
/*  578 */     Class<? extends Servlet> servletClazz = this.instance.getClass();
/*  579 */     if (!HttpServlet.class.isAssignableFrom(servletClazz))
/*      */     {
/*  581 */       return DEFAULT_SERVLET_METHODS;
/*      */     }
/*      */     
/*  584 */     HashSet<String> allow = new HashSet();
/*  585 */     allow.add("TRACE");
/*  586 */     allow.add("OPTIONS");
/*      */     
/*  588 */     Method[] methods = getAllDeclaredMethods(servletClazz);
/*  589 */     for (int i = 0; (methods != null) && (i < methods.length); i++) {
/*  590 */       Method m = methods[i];
/*      */       
/*  592 */       if (m.getName().equals("doGet")) {
/*  593 */         allow.add("GET");
/*  594 */         allow.add("HEAD");
/*  595 */       } else if (m.getName().equals("doPost")) {
/*  596 */         allow.add("POST");
/*  597 */       } else if (m.getName().equals("doPut")) {
/*  598 */         allow.add("PUT");
/*  599 */       } else if (m.getName().equals("doDelete")) {
/*  600 */         allow.add("DELETE");
/*      */       }
/*      */     }
/*      */     
/*  604 */     String[] methodNames = new String[allow.size()];
/*  605 */     return (String[])allow.toArray(methodNames);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Servlet getServlet()
/*      */   {
/*  615 */     return this.instance;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setServlet(Servlet servlet)
/*      */   {
/*  624 */     this.instance = servlet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setServletSecurityAnnotationScanRequired(boolean b)
/*      */   {
/*  633 */     this.servletSecurityAnnotationScanRequired = b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void backgroundProcess()
/*      */   {
/*  646 */     super.backgroundProcess();
/*      */     
/*  648 */     if (!getState().isAvailable()) {
/*  649 */       return;
/*      */     }
/*  651 */     if ((getServlet() instanceof PeriodicEventListener)) {
/*  652 */       ((PeriodicEventListener)getServlet()).periodicEvent();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Throwable getRootCause(ServletException e)
/*      */   {
/*  664 */     Throwable rootCause = e;
/*  665 */     Throwable rootCauseCheck = null;
/*      */     
/*  667 */     int loops = 0;
/*      */     do {
/*  669 */       loops++;
/*  670 */       rootCauseCheck = rootCause.getCause();
/*  671 */       if (rootCauseCheck != null)
/*  672 */         rootCause = rootCauseCheck;
/*  673 */     } while ((rootCauseCheck != null) && (loops < 20));
/*  674 */     return rootCause;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addChild(Container child)
/*      */   {
/*  687 */     throw new IllegalStateException(sm.getString("standardWrapper.notChild"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addInitParameter(String name, String value)
/*      */   {
/*  702 */     this.parametersLock.writeLock().lock();
/*      */     try {
/*  704 */       this.parameters.put(name, value);
/*      */     } finally {
/*  706 */       this.parametersLock.writeLock().unlock();
/*      */     }
/*  708 */     fireContainerEvent("addInitParameter", name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addMapping(String mapping)
/*      */   {
/*  721 */     this.mappingsLock.writeLock().lock();
/*      */     try {
/*  723 */       this.mappings.add(mapping);
/*      */     } finally {
/*  725 */       this.mappingsLock.writeLock().unlock();
/*      */     }
/*  727 */     if (this.parent.getState().equals(LifecycleState.STARTED)) {
/*  728 */       fireContainerEvent("addMapping", mapping);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addSecurityReference(String name, String link)
/*      */   {
/*  743 */     this.referencesLock.writeLock().lock();
/*      */     try {
/*  745 */       this.references.put(name, link);
/*      */     } finally {
/*  747 */       this.referencesLock.writeLock().unlock();
/*      */     }
/*  749 */     fireContainerEvent("addSecurityReference", name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Servlet allocate()
/*      */     throws ServletException
/*      */   {
/*  771 */     if (this.unloading) {
/*  772 */       throw new ServletException(sm.getString("standardWrapper.unloading", new Object[] { getName() }));
/*      */     }
/*      */     
/*  775 */     boolean newInstance = false;
/*      */     
/*      */ 
/*  778 */     if (!this.singleThreadModel)
/*      */     {
/*  780 */       if ((this.instance == null) || (!this.instanceInitialized)) {
/*  781 */         synchronized (this) {
/*  782 */           if (this.instance == null) {
/*      */             try {
/*  784 */               if (log.isDebugEnabled()) {
/*  785 */                 log.debug("Allocating non-STM instance");
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*  790 */               this.instance = loadServlet();
/*  791 */               newInstance = true;
/*  792 */               if (!this.singleThreadModel)
/*      */               {
/*      */ 
/*      */ 
/*  796 */                 this.countAllocated.incrementAndGet();
/*      */               }
/*      */             } catch (ServletException e) {
/*  799 */               throw e;
/*      */             } catch (Throwable e) {
/*  801 */               ExceptionUtils.handleThrowable(e);
/*  802 */               throw new ServletException(sm.getString("standardWrapper.allocate"), e);
/*      */             }
/*      */           }
/*  805 */           if (!this.instanceInitialized) {
/*  806 */             initServlet(this.instance);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*  811 */       if (this.singleThreadModel) {
/*  812 */         if (newInstance)
/*      */         {
/*      */ 
/*  815 */           synchronized (this.instancePool) {
/*  816 */             this.instancePool.push(this.instance);
/*  817 */             this.nInstances += 1;
/*      */           }
/*      */         }
/*      */       } else {
/*  821 */         if (log.isTraceEnabled()) {
/*  822 */           log.trace("  Returning non-STM instance");
/*      */         }
/*      */         
/*      */ 
/*  826 */         if (!newInstance) {
/*  827 */           this.countAllocated.incrementAndGet();
/*      */         }
/*  829 */         return this.instance;
/*      */       }
/*      */     }
/*      */     
/*  833 */     synchronized (this.instancePool) {
/*  834 */       while (this.countAllocated.get() >= this.nInstances)
/*      */       {
/*  836 */         if (this.nInstances < this.maxInstances) {
/*      */           try {
/*  838 */             this.instancePool.push(loadServlet());
/*  839 */             this.nInstances += 1;
/*      */           } catch (ServletException e) {
/*  841 */             throw e;
/*      */           } catch (Throwable e) {
/*  843 */             ExceptionUtils.handleThrowable(e);
/*  844 */             throw new ServletException(sm.getString("standardWrapper.allocate"), e);
/*      */           }
/*      */         } else {
/*      */           try {
/*  848 */             this.instancePool.wait();
/*      */           }
/*      */           catch (InterruptedException localInterruptedException) {}
/*      */         }
/*      */       }
/*      */       
/*  854 */       if (log.isTraceEnabled()) {
/*  855 */         log.trace("  Returning allocated STM instance");
/*      */       }
/*  857 */       this.countAllocated.incrementAndGet();
/*  858 */       return (Servlet)this.instancePool.pop();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deallocate(Servlet servlet)
/*      */     throws ServletException
/*      */   {
/*  876 */     if (!this.singleThreadModel) {
/*  877 */       this.countAllocated.decrementAndGet();
/*  878 */       return;
/*      */     }
/*      */     
/*      */ 
/*  882 */     synchronized (this.instancePool) {
/*  883 */       this.countAllocated.decrementAndGet();
/*  884 */       this.instancePool.push(servlet);
/*  885 */       this.instancePool.notify();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String findInitParameter(String name)
/*      */   {
/*  900 */     this.parametersLock.readLock().lock();
/*      */     try {
/*  902 */       return (String)this.parameters.get(name);
/*      */     } finally {
/*  904 */       this.parametersLock.readLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] findInitParameters()
/*      */   {
/*  917 */     this.parametersLock.readLock().lock();
/*      */     try {
/*  919 */       String[] results = new String[this.parameters.size()];
/*  920 */       return (String[])this.parameters.keySet().toArray(results);
/*      */     } finally {
/*  922 */       this.parametersLock.readLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] findMappings()
/*      */   {
/*  934 */     this.mappingsLock.readLock().lock();
/*      */     try {
/*  936 */       return (String[])this.mappings.toArray(new String[this.mappings.size()]);
/*      */     } finally {
/*  938 */       this.mappingsLock.readLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String findSecurityReference(String name)
/*      */   {
/*  953 */     this.referencesLock.readLock().lock();
/*      */     try {
/*  955 */       return (String)this.references.get(name);
/*      */     } finally {
/*  957 */       this.referencesLock.readLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] findSecurityReferences()
/*      */   {
/*  970 */     this.referencesLock.readLock().lock();
/*      */     try {
/*  972 */       String[] results = new String[this.references.size()];
/*  973 */       return (String[])this.references.keySet().toArray(results);
/*      */     } finally {
/*  975 */       this.referencesLock.readLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void load()
/*      */     throws ServletException
/*      */   {
/* 1000 */     this.instance = loadServlet();
/*      */     
/* 1002 */     if (!this.instanceInitialized) {
/* 1003 */       initServlet(this.instance);
/*      */     }
/*      */     
/* 1006 */     if (this.isJspServlet) {
/* 1007 */       StringBuilder oname = new StringBuilder(getDomain());
/*      */       
/* 1009 */       oname.append(":type=JspMonitor");
/*      */       
/* 1011 */       oname.append(getWebModuleKeyProperties());
/*      */       
/* 1013 */       oname.append(",name=");
/* 1014 */       oname.append(getName());
/*      */       
/* 1016 */       oname.append(getJ2EEKeyProperties());
/*      */       try
/*      */       {
/* 1019 */         this.jspMonitorON = new ObjectName(oname.toString());
/* 1020 */         Registry.getRegistry(null, null).registerComponent(this.instance, this.jspMonitorON, null);
/*      */       }
/*      */       catch (Exception ex) {
/* 1023 */         log.info("Error registering JSP monitoring with jmx " + this.instance);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized Servlet loadServlet()
/*      */     throws ServletException
/*      */   {
/* 1041 */     if ((!this.singleThreadModel) && (this.instance != null)) {
/* 1042 */       return this.instance;
/*      */     }
/* 1044 */     PrintStream out = System.out;
/* 1045 */     if (this.swallowOutput) {
/* 1046 */       SystemLogHandler.startCapture();
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1051 */       long t1 = System.currentTimeMillis();
/*      */       
/* 1053 */       if (this.servletClass == null) {
/* 1054 */         unavailable(null);
/* 1055 */         throw new ServletException(sm.getString("standardWrapper.notClass", new Object[] { getName() }));
/*      */       }
/*      */       
/*      */ 
/* 1059 */       InstanceManager instanceManager = ((StandardContext)getParent()).getInstanceManager();
/*      */       try {
/* 1061 */         servlet = (Servlet)instanceManager.newInstance(this.servletClass);
/*      */       } catch (ClassCastException e) { Servlet servlet;
/* 1063 */         unavailable(null);
/*      */         
/* 1065 */         throw new ServletException(sm.getString("standardWrapper.notServlet", new Object[] { this.servletClass }), e);
/*      */       }
/*      */       catch (Throwable e) {
/* 1068 */         e = ExceptionUtils.unwrapInvocationTargetException(e);
/* 1069 */         ExceptionUtils.handleThrowable(e);
/* 1070 */         unavailable(null);
/*      */         
/*      */ 
/*      */ 
/* 1074 */         if (log.isDebugEnabled()) {
/* 1075 */           log.debug(sm.getString("standardWrapper.instantiate", new Object[] { this.servletClass }), e);
/*      */         }
/*      */         
/*      */ 
/* 1079 */         throw new ServletException(sm.getString("standardWrapper.instantiate", new Object[] { this.servletClass }), e);
/*      */       }
/*      */       
/*      */       Servlet servlet;
/* 1083 */       if (this.multipartConfigElement == null) {
/* 1084 */         MultipartConfig annotation = (MultipartConfig)servlet.getClass().getAnnotation(MultipartConfig.class);
/*      */         
/* 1086 */         if (annotation != null) {
/* 1087 */           this.multipartConfigElement = new MultipartConfigElement(annotation);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1092 */       processServletSecurityAnnotation(servlet.getClass());
/*      */       
/*      */ 
/* 1095 */       if (((servlet instanceof ContainerServlet)) && ((isContainerProvidedServlet(this.servletClass)) || (((Context)getParent()).getPrivileged())))
/*      */       {
/*      */ 
/* 1098 */         ((ContainerServlet)servlet).setWrapper(this);
/*      */       }
/*      */       
/* 1101 */       this.classLoadTime = ((int)(System.currentTimeMillis() - t1));
/*      */       
/* 1103 */       if ((servlet instanceof SingleThreadModel)) {
/* 1104 */         if (this.instancePool == null) {
/* 1105 */           this.instancePool = new Stack();
/*      */         }
/* 1107 */         this.singleThreadModel = true;
/*      */       }
/*      */       
/* 1110 */       initServlet(servlet);
/*      */       
/* 1112 */       fireContainerEvent("load", this);
/*      */       
/* 1114 */       this.loadTime = (System.currentTimeMillis() - t1);
/*      */     } finally { String log;
/* 1116 */       if (this.swallowOutput) {
/* 1117 */         String log = SystemLogHandler.stopCapture();
/* 1118 */         if ((log != null) && (log.length() > 0)) {
/* 1119 */           if (getServletContext() != null) {
/* 1120 */             getServletContext().log(log);
/*      */           } else
/* 1122 */             out.println(log);
/*      */         }
/*      */       }
/*      */     }
/*      */     Servlet servlet;
/* 1127 */     return servlet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void servletSecurityAnnotationScan()
/*      */     throws ServletException
/*      */   {
/* 1136 */     if (getServlet() == null) {
/* 1137 */       Class<?> clazz = null;
/*      */       try {
/* 1139 */         clazz = ((Context)getParent()).getLoader().getClassLoader().loadClass(getServletClass());
/*      */         
/* 1141 */         processServletSecurityAnnotation(clazz);
/*      */ 
/*      */       }
/*      */       catch (ClassNotFoundException localClassNotFoundException) {}
/*      */     }
/* 1146 */     else if (this.servletSecurityAnnotationScanRequired) {
/* 1147 */       processServletSecurityAnnotation(getServlet().getClass());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void processServletSecurityAnnotation(Class<?> clazz)
/*      */   {
/* 1154 */     this.servletSecurityAnnotationScanRequired = false;
/*      */     
/* 1156 */     Context ctxt = (Context)getParent();
/*      */     
/* 1158 */     if (ctxt.getIgnoreAnnotations()) {
/* 1159 */       return;
/*      */     }
/*      */     
/* 1162 */     ServletSecurity secAnnotation = (ServletSecurity)clazz.getAnnotation(ServletSecurity.class);
/*      */     
/* 1164 */     if (secAnnotation != null) {
/* 1165 */       ctxt.addServletSecurity(new ApplicationServletRegistration(this, ctxt), new ServletSecurityElement(secAnnotation));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private synchronized void initServlet(Servlet servlet)
/*      */     throws ServletException
/*      */   {
/* 1174 */     if ((this.instanceInitialized) && (!this.singleThreadModel)) { return;
/*      */     }
/*      */     try
/*      */     {
/* 1178 */       if (Globals.IS_SECURITY_ENABLED) {
/* 1179 */         boolean success = false;
/*      */         try {
/* 1181 */           Object[] args = { this.facade };
/* 1182 */           SecurityUtil.doAsPrivilege("init", servlet, classType, args);
/*      */           
/*      */ 
/*      */ 
/* 1186 */           success = true;
/*      */         } finally {
/* 1188 */           if (!success)
/*      */           {
/* 1190 */             SecurityUtil.remove(servlet);
/*      */           }
/*      */         }
/*      */       } else {
/* 1194 */         servlet.init(this.facade);
/*      */       }
/*      */       
/* 1197 */       this.instanceInitialized = true;
/*      */     } catch (UnavailableException f) {
/* 1199 */       unavailable(f);
/* 1200 */       throw f;
/*      */     }
/*      */     catch (ServletException f)
/*      */     {
/* 1204 */       throw f;
/*      */     } catch (Throwable f) {
/* 1206 */       ExceptionUtils.handleThrowable(f);
/* 1207 */       getServletContext().log("StandardWrapper.Throwable", f);
/*      */       
/*      */ 
/* 1210 */       throw new ServletException(sm.getString("standardWrapper.initException", new Object[] { getName() }), f);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeInitParameter(String name)
/*      */   {
/* 1223 */     this.parametersLock.writeLock().lock();
/*      */     try {
/* 1225 */       this.parameters.remove(name);
/*      */     } finally {
/* 1227 */       this.parametersLock.writeLock().unlock();
/*      */     }
/* 1229 */     fireContainerEvent("removeInitParameter", name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeMapping(String mapping)
/*      */   {
/* 1242 */     this.mappingsLock.writeLock().lock();
/*      */     try {
/* 1244 */       this.mappings.remove(mapping);
/*      */     } finally {
/* 1246 */       this.mappingsLock.writeLock().unlock();
/*      */     }
/* 1248 */     if (this.parent.getState().equals(LifecycleState.STARTED)) {
/* 1249 */       fireContainerEvent("removeMapping", mapping);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeSecurityReference(String name)
/*      */   {
/* 1262 */     this.referencesLock.writeLock().lock();
/*      */     try {
/* 1264 */       this.references.remove(name);
/*      */     } finally {
/* 1266 */       this.referencesLock.writeLock().unlock();
/*      */     }
/* 1268 */     fireContainerEvent("removeSecurityReference", name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1279 */     StringBuilder sb = new StringBuilder();
/* 1280 */     if (getParent() != null) {
/* 1281 */       sb.append(getParent().toString());
/* 1282 */       sb.append(".");
/*      */     }
/* 1284 */     sb.append("StandardWrapper[");
/* 1285 */     sb.append(getName());
/* 1286 */     sb.append("]");
/* 1287 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void unavailable(UnavailableException unavailable)
/*      */   {
/* 1301 */     getServletContext().log(sm.getString("standardWrapper.unavailable", new Object[] { getName() }));
/* 1302 */     if (unavailable == null) {
/* 1303 */       setAvailable(Long.MAX_VALUE);
/* 1304 */     } else if (unavailable.isPermanent()) {
/* 1305 */       setAvailable(Long.MAX_VALUE);
/*      */     } else {
/* 1307 */       int unavailableSeconds = unavailable.getUnavailableSeconds();
/* 1308 */       if (unavailableSeconds <= 0)
/* 1309 */         unavailableSeconds = 60;
/* 1310 */       setAvailable(System.currentTimeMillis() + unavailableSeconds * 1000L);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void unload()
/*      */     throws ServletException
/*      */   {
/* 1331 */     if ((!this.singleThreadModel) && (this.instance == null))
/* 1332 */       return;
/* 1333 */     this.unloading = true;
/*      */     
/*      */ 
/*      */ 
/* 1337 */     if (this.countAllocated.get() > 0) {
/* 1338 */       int nRetries = 0;
/* 1339 */       long delay = this.unloadDelay / 20L;
/* 1340 */       while ((nRetries < 21) && (this.countAllocated.get() > 0)) {
/* 1341 */         if (nRetries % 10 == 0) {
/* 1342 */           log.info(sm.getString("standardWrapper.waiting", new Object[] { this.countAllocated.toString(), getName() }));
/*      */         }
/*      */         
/*      */         try
/*      */         {
/* 1347 */           Thread.sleep(delay);
/*      */         }
/*      */         catch (InterruptedException localInterruptedException) {}
/*      */         
/* 1351 */         nRetries++;
/*      */       }
/*      */     }
/*      */     
/* 1355 */     if (this.instanceInitialized) {
/* 1356 */       PrintStream out = System.out;
/* 1357 */       if (this.swallowOutput) {
/* 1358 */         SystemLogHandler.startCapture();
/*      */       }
/*      */       
/*      */       try
/*      */       {
/* 1363 */         if (Globals.IS_SECURITY_ENABLED) {
/*      */           try {
/* 1365 */             SecurityUtil.doAsPrivilege("destroy", this.instance);
/*      */           } finally {
/* 1367 */             SecurityUtil.remove(this.instance);
/*      */           }
/*      */         } else {
/* 1370 */           this.instance.destroy();
/*      */         }
/*      */       } catch (Throwable t) {
/*      */         String log;
/* 1374 */         t = ExceptionUtils.unwrapInvocationTargetException(t);
/* 1375 */         ExceptionUtils.handleThrowable(t);
/* 1376 */         this.instance = null;
/* 1377 */         this.instancePool = null;
/* 1378 */         this.nInstances = 0;
/* 1379 */         fireContainerEvent("unload", this);
/* 1380 */         this.unloading = false;
/* 1381 */         throw new ServletException(sm.getString("standardWrapper.destroyException", new Object[] { getName() }), t);
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/* 1386 */         if (!((Context)getParent()).getIgnoreAnnotations()) {
/*      */           try {
/* 1388 */             ((Context)getParent()).getInstanceManager().destroyInstance(this.instance);
/*      */           } catch (Throwable t) {
/* 1390 */             ExceptionUtils.handleThrowable(t);
/* 1391 */             log.error(sm.getString("standardWrapper.destroyInstance", new Object[] { getName() }), t);
/*      */           }
/*      */         }
/*      */         
/* 1395 */         if (this.swallowOutput) {
/* 1396 */           String log = SystemLogHandler.stopCapture();
/* 1397 */           if ((log != null) && (log.length() > 0)) {
/* 1398 */             if (getServletContext() != null) {
/* 1399 */               getServletContext().log(log);
/*      */             } else {
/* 1401 */               out.println(log);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1409 */     this.instance = null;
/* 1410 */     this.instanceInitialized = false;
/*      */     
/* 1412 */     if ((this.isJspServlet) && (this.jspMonitorON != null)) {
/* 1413 */       Registry.getRegistry(null, null).unregisterComponent(this.jspMonitorON);
/*      */     }
/*      */     
/* 1416 */     if ((this.singleThreadModel) && (this.instancePool != null)) {
/*      */       try {
/* 1418 */         while (!this.instancePool.isEmpty()) {
/* 1419 */           Servlet s = (Servlet)this.instancePool.pop();
/* 1420 */           if (Globals.IS_SECURITY_ENABLED) {
/*      */             try {
/* 1422 */               SecurityUtil.doAsPrivilege("destroy", s);
/*      */             } finally {
/* 1424 */               SecurityUtil.remove(s);
/*      */             }
/*      */           } else {
/* 1427 */             s.destroy();
/*      */           }
/*      */           
/* 1430 */           if (!((Context)getParent()).getIgnoreAnnotations()) {
/* 1431 */             ((StandardContext)getParent()).getInstanceManager().destroyInstance(s);
/*      */           }
/*      */         }
/*      */       } catch (Throwable t) {
/* 1435 */         t = ExceptionUtils.unwrapInvocationTargetException(t);
/* 1436 */         ExceptionUtils.handleThrowable(t);
/* 1437 */         this.instancePool = null;
/* 1438 */         this.nInstances = 0;
/* 1439 */         this.unloading = false;
/* 1440 */         fireContainerEvent("unload", this);
/* 1441 */         throw new ServletException(sm.getString("standardWrapper.destroyException", new Object[] { getName() }), t);
/*      */       }
/*      */       
/*      */ 
/* 1445 */       this.instancePool = null;
/* 1446 */       this.nInstances = 0;
/*      */     }
/*      */     
/* 1449 */     this.singleThreadModel = false;
/*      */     
/* 1451 */     this.unloading = false;
/* 1452 */     fireContainerEvent("unload", this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getInitParameter(String name)
/*      */   {
/* 1469 */     return findInitParameter(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Enumeration<String> getInitParameterNames()
/*      */   {
/* 1481 */     this.parametersLock.readLock().lock();
/*      */     try {
/* 1483 */       return Collections.enumeration(this.parameters.keySet());
/*      */     } finally {
/* 1485 */       this.parametersLock.readLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ServletContext getServletContext()
/*      */   {
/* 1497 */     if (this.parent == null)
/* 1498 */       return null;
/* 1499 */     if (!(this.parent instanceof Context)) {
/* 1500 */       return null;
/*      */     }
/* 1502 */     return ((Context)this.parent).getServletContext();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getServletName()
/*      */   {
/* 1513 */     return getName();
/*      */   }
/*      */   
/*      */   public long getProcessingTime()
/*      */   {
/* 1518 */     return this.swValve.getProcessingTime();
/*      */   }
/*      */   
/*      */   public long getMaxTime() {
/* 1522 */     return this.swValve.getMaxTime();
/*      */   }
/*      */   
/*      */   public long getMinTime() {
/* 1526 */     return this.swValve.getMinTime();
/*      */   }
/*      */   
/*      */   public int getRequestCount() {
/* 1530 */     return this.swValve.getRequestCount();
/*      */   }
/*      */   
/*      */   public int getErrorCount() {
/* 1534 */     return this.swValve.getErrorCount();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void incrementErrorCount()
/*      */   {
/* 1542 */     this.swValve.incrementErrorCount();
/*      */   }
/*      */   
/*      */   public long getLoadTime() {
/* 1546 */     return this.loadTime;
/*      */   }
/*      */   
/*      */   public int getClassLoadTime() {
/* 1550 */     return this.classLoadTime;
/*      */   }
/*      */   
/*      */   public MultipartConfigElement getMultipartConfigElement()
/*      */   {
/* 1555 */     return this.multipartConfigElement;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setMultipartConfigElement(MultipartConfigElement multipartConfigElement)
/*      */   {
/* 1561 */     this.multipartConfigElement = multipartConfigElement;
/*      */   }
/*      */   
/*      */   public boolean isAsyncSupported()
/*      */   {
/* 1566 */     return this.asyncSupported;
/*      */   }
/*      */   
/*      */   public void setAsyncSupported(boolean asyncSupported)
/*      */   {
/* 1571 */     this.asyncSupported = asyncSupported;
/*      */   }
/*      */   
/*      */   public boolean isEnabled()
/*      */   {
/* 1576 */     return this.enabled;
/*      */   }
/*      */   
/*      */   public void setEnabled(boolean enabled)
/*      */   {
/* 1581 */     this.enabled = enabled;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isContainerProvidedServlet(String classname)
/*      */   {
/* 1599 */     if (classname.startsWith("org.apache.catalina.")) {
/* 1600 */       return true;
/*      */     }
/*      */     try {
/* 1603 */       Class<?> clazz = getClass().getClassLoader().loadClass(classname);
/*      */       
/* 1605 */       return ContainerServlet.class.isAssignableFrom(clazz);
/*      */     } catch (Throwable t) {
/* 1607 */       ExceptionUtils.handleThrowable(t); }
/* 1608 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Method[] getAllDeclaredMethods(Class<?> c)
/*      */   {
/* 1616 */     if (c.equals(HttpServlet.class)) {
/* 1617 */       return null;
/*      */     }
/*      */     
/* 1620 */     Method[] parentMethods = getAllDeclaredMethods(c.getSuperclass());
/*      */     
/* 1622 */     Method[] thisMethods = c.getDeclaredMethods();
/* 1623 */     if (thisMethods.length == 0) {
/* 1624 */       return parentMethods;
/*      */     }
/*      */     
/* 1627 */     if ((parentMethods != null) && (parentMethods.length > 0)) {
/* 1628 */       Method[] allMethods = new Method[parentMethods.length + thisMethods.length];
/*      */       
/* 1630 */       System.arraycopy(parentMethods, 0, allMethods, 0, parentMethods.length);
/*      */       
/* 1632 */       System.arraycopy(thisMethods, 0, allMethods, parentMethods.length, thisMethods.length);
/*      */       
/*      */ 
/* 1635 */       thisMethods = allMethods;
/*      */     }
/*      */     
/* 1638 */     return thisMethods;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void startInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1656 */     if (getObjectName() != null) {
/* 1657 */       Notification notification = new Notification("j2ee.state.starting", getObjectName(), this.sequenceNumber++);
/*      */       
/*      */ 
/* 1660 */       this.broadcaster.sendNotification(notification);
/*      */     }
/*      */     
/*      */ 
/* 1664 */     super.startInternal();
/*      */     
/* 1666 */     setAvailable(0L);
/*      */     
/*      */ 
/* 1669 */     if (getObjectName() != null) {
/* 1670 */       Notification notification = new Notification("j2ee.state.running", getObjectName(), this.sequenceNumber++);
/*      */       
/*      */ 
/* 1673 */       this.broadcaster.sendNotification(notification);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void stopInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1689 */     setAvailable(Long.MAX_VALUE);
/*      */     
/*      */ 
/* 1692 */     if (getObjectName() != null) {
/* 1693 */       Notification notification = new Notification("j2ee.state.stopping", getObjectName(), this.sequenceNumber++);
/*      */       
/*      */ 
/* 1696 */       this.broadcaster.sendNotification(notification);
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1701 */       unload();
/*      */     } catch (ServletException e) {
/* 1703 */       getServletContext().log(sm.getString("standardWrapper.unloadException", new Object[] { getName() }), e);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1708 */     super.stopInternal();
/*      */     
/*      */ 
/* 1711 */     if (getObjectName() != null) {
/* 1712 */       Notification notification = new Notification("j2ee.state.stopped", getObjectName(), this.sequenceNumber++);
/*      */       
/*      */ 
/* 1715 */       this.broadcaster.sendNotification(notification);
/*      */     }
/*      */     
/*      */ 
/* 1719 */     Notification notification = new Notification("j2ee.object.deleted", getObjectName(), this.sequenceNumber++);
/*      */     
/*      */ 
/* 1722 */     this.broadcaster.sendNotification(notification);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getObjectNameKeyProperties()
/*      */   {
/* 1730 */     StringBuilder keyProperties = new StringBuilder("j2eeType=Servlet");
/*      */     
/*      */ 
/* 1733 */     keyProperties.append(getWebModuleKeyProperties());
/*      */     
/* 1735 */     keyProperties.append(",name=");
/*      */     
/* 1737 */     String name = getName();
/* 1738 */     if (Util.objectNameValueNeedsQuote(name)) {
/* 1739 */       name = ObjectName.quote(name);
/*      */     }
/* 1741 */     keyProperties.append(name);
/*      */     
/* 1743 */     keyProperties.append(getJ2EEKeyProperties());
/*      */     
/* 1745 */     return keyProperties.toString();
/*      */   }
/*      */   
/*      */ 
/*      */   private String getWebModuleKeyProperties()
/*      */   {
/* 1751 */     StringBuilder keyProperties = new StringBuilder(",WebModule=//");
/* 1752 */     String hostName = getParent().getParent().getName();
/* 1753 */     if (hostName == null) {
/* 1754 */       keyProperties.append("DEFAULT");
/*      */     } else {
/* 1756 */       keyProperties.append(hostName);
/*      */     }
/*      */     
/* 1759 */     String contextName = ((Context)getParent()).getName();
/* 1760 */     if (!contextName.startsWith("/")) {
/* 1761 */       keyProperties.append('/');
/*      */     }
/* 1763 */     keyProperties.append(contextName);
/*      */     
/* 1765 */     return keyProperties.toString();
/*      */   }
/*      */   
/*      */   private String getJ2EEKeyProperties()
/*      */   {
/* 1770 */     StringBuilder keyProperties = new StringBuilder(",J2EEApplication=");
/*      */     
/* 1772 */     StandardContext ctx = null;
/* 1773 */     if ((this.parent instanceof StandardContext)) {
/* 1774 */       ctx = (StandardContext)getParent();
/*      */     }
/*      */     
/* 1777 */     if (ctx == null) {
/* 1778 */       keyProperties.append("none");
/*      */     } else {
/* 1780 */       keyProperties.append(ctx.getJ2EEApplication());
/*      */     }
/* 1782 */     keyProperties.append(",J2EEServer=");
/* 1783 */     if (ctx == null) {
/* 1784 */       keyProperties.append("none");
/*      */     } else {
/* 1786 */       keyProperties.append(ctx.getJ2EEServer());
/*      */     }
/*      */     
/* 1789 */     return keyProperties.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeNotificationListener(NotificationListener listener, NotificationFilter filter, Object object)
/*      */     throws ListenerNotFoundException
/*      */   {
/* 1800 */     this.broadcaster.removeNotificationListener(listener, filter, object);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MBeanNotificationInfo[] getNotificationInfo()
/*      */   {
/* 1813 */     if (this.notificationInfo == null) {
/* 1814 */       this.notificationInfo = new MBeanNotificationInfo[] { new MBeanNotificationInfo(new String[] { "j2ee.object.created" }, Notification.class.getName(), "servlet is created"), new MBeanNotificationInfo(new String[] { "j2ee.state.starting" }, Notification.class.getName(), "servlet is starting"), new MBeanNotificationInfo(new String[] { "j2ee.state.running" }, Notification.class.getName(), "servlet is running"), new MBeanNotificationInfo(new String[] { "j2ee.state.stopped" }, Notification.class.getName(), "servlet start to stopped"), new MBeanNotificationInfo(new String[] { "j2ee.object.stopped" }, Notification.class.getName(), "servlet is stopped"), new MBeanNotificationInfo(new String[] { "j2ee.object.deleted" }, Notification.class.getName(), "servlet is deleted") };
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1848 */     return this.notificationInfo;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addNotificationListener(NotificationListener listener, NotificationFilter filter, Object object)
/*      */     throws IllegalArgumentException
/*      */   {
/* 1859 */     this.broadcaster.addNotificationListener(listener, filter, object);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeNotificationListener(NotificationListener listener)
/*      */     throws ListenerNotFoundException
/*      */   {
/* 1870 */     this.broadcaster.removeNotificationListener(listener);
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\core\StandardWrapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */