/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.InetAddress;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketTimeoutException;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.security.AccessControlException;
/*     */ import java.util.Random;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Server;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.deploy.NamingResourcesImpl;
/*     */ import org.apache.catalina.mbeans.MBeanFactory;
/*     */ import org.apache.catalina.startup.Catalina;
/*     */ import org.apache.catalina.util.ExtensionValidator;
/*     */ import org.apache.catalina.util.LifecycleMBeanBase;
/*     */ import org.apache.catalina.util.ServerInfo;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.buf.StringCache;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardServer
/*     */   extends LifecycleMBeanBase
/*     */   implements Server
/*     */ {
/*  64 */   private static final Log log = LogFactory.getLog(StandardServer.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StandardServer()
/*     */   {
/*  77 */     this.globalNamingResources = new NamingResourcesImpl();
/*  78 */     this.globalNamingResources.setContainer(this);
/*     */     
/*  80 */     if (isUseNaming()) {
/*  81 */       this.namingContextListener = new NamingContextListener();
/*  82 */       addLifecycleListener(this.namingContextListener);
/*     */     } else {
/*  84 */       this.namingContextListener = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */   private javax.naming.Context globalNamingContext = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */   private NamingResourcesImpl globalNamingResources = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final NamingContextListener namingContextListener;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 114 */   private int port = 8005;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 119 */   private String address = "localhost";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 126 */   private Random random = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 132 */   private Service[] services = new Service[0];
/* 133 */   private final Object servicesLock = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 139 */   private String shutdown = "SHUTDOWN";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 145 */   private static final StringManager sm = StringManager.getManager("org.apache.catalina.core");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 152 */   final PropertyChangeSupport support = new PropertyChangeSupport(this);
/*     */   
/* 154 */   private volatile boolean stopAwait = false;
/*     */   
/* 156 */   private Catalina catalina = null;
/*     */   
/* 158 */   private ClassLoader parentClassLoader = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 163 */   private volatile Thread awaitThread = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 168 */   private volatile ServerSocket awaitSocket = null;
/*     */   
/* 170 */   private File catalinaHome = null;
/*     */   
/* 172 */   private File catalinaBase = null;
/*     */   
/* 174 */   private final Object namingToken = new Object();
/*     */   
/*     */   private ObjectName onameStringCache;
/*     */   private ObjectName onameMBeanFactory;
/*     */   
/*     */   public Object getNamingToken()
/*     */   {
/* 181 */     return this.namingToken;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public javax.naming.Context getGlobalNamingContext()
/*     */   {
/* 191 */     return this.globalNamingContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setGlobalNamingContext(javax.naming.Context globalNamingContext)
/*     */   {
/* 204 */     this.globalNamingContext = globalNamingContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NamingResourcesImpl getGlobalNamingResources()
/*     */   {
/* 215 */     return this.globalNamingResources;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setGlobalNamingResources(NamingResourcesImpl globalNamingResources)
/*     */   {
/* 229 */     NamingResourcesImpl oldGlobalNamingResources = this.globalNamingResources;
/*     */     
/* 231 */     this.globalNamingResources = globalNamingResources;
/* 232 */     this.globalNamingResources.setContainer(this);
/* 233 */     this.support.firePropertyChange("globalNamingResources", oldGlobalNamingResources, this.globalNamingResources);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getServerInfo()
/*     */   {
/* 245 */     return ServerInfo.getServerInfo();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getServerBuilt()
/*     */   {
/* 254 */     return ServerInfo.getServerBuilt();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getServerNumber()
/*     */   {
/* 263 */     return ServerInfo.getServerNumber();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 273 */     return this.port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPort(int port)
/*     */   {
/* 286 */     this.port = port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAddress()
/*     */   {
/* 297 */     return this.address;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAddress(String address)
/*     */   {
/* 310 */     this.address = address;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getShutdown()
/*     */   {
/* 320 */     return this.shutdown;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setShutdown(String shutdown)
/*     */   {
/* 333 */     this.shutdown = shutdown;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Catalina getCatalina()
/*     */   {
/* 343 */     return this.catalina;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCatalina(Catalina catalina)
/*     */   {
/* 352 */     this.catalina = catalina;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addService(Service service)
/*     */   {
/* 366 */     service.setServer(this);
/*     */     
/* 368 */     synchronized (this.servicesLock) {
/* 369 */       Service[] results = new Service[this.services.length + 1];
/* 370 */       System.arraycopy(this.services, 0, results, 0, this.services.length);
/* 371 */       results[this.services.length] = service;
/* 372 */       this.services = results;
/*     */       
/* 374 */       if (getState().isAvailable()) {
/*     */         try {
/* 376 */           service.start();
/*     */         }
/*     */         catch (LifecycleException localLifecycleException) {}
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 383 */       this.support.firePropertyChange("service", null, service);
/*     */     }
/*     */   }
/*     */   
/*     */   public void stopAwait()
/*     */   {
/* 389 */     this.stopAwait = true;
/* 390 */     Thread t = this.awaitThread;
/* 391 */     if (t != null) {
/* 392 */       ServerSocket s = this.awaitSocket;
/* 393 */       if (s != null) {
/* 394 */         this.awaitSocket = null;
/*     */         try {
/* 396 */           s.close();
/*     */         }
/*     */         catch (IOException localIOException) {}
/*     */       }
/*     */       
/* 401 */       t.interrupt();
/*     */       try {
/* 403 */         t.join(1000L);
/*     */       }
/*     */       catch (InterruptedException localInterruptedException) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void await()
/*     */   {
/* 418 */     if (this.port == -2)
/*     */     {
/* 420 */       return;
/*     */     }
/* 422 */     if (this.port == -1) {
/*     */       try {
/* 424 */         this.awaitThread = Thread.currentThread();
/* 425 */         while (!this.stopAwait) {
/*     */           try {
/* 427 */             Thread.sleep(10000L);
/*     */           }
/*     */           catch (InterruptedException localInterruptedException) {}
/*     */         }
/*     */       }
/*     */       finally {
/* 433 */         this.awaitThread = null;
/*     */       }
/* 435 */       return;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 440 */       this.awaitSocket = new ServerSocket(this.port, 1, InetAddress.getByName(this.address));
/*     */     }
/*     */     catch (IOException e) {
/* 443 */       log.error("StandardServer.await: create[" + this.address + ":" + this.port + "]: ", e);
/*     */       
/*     */ 
/* 446 */       return;
/*     */     }
/*     */     try
/*     */     {
/* 450 */       this.awaitThread = Thread.currentThread();
/*     */       
/*     */ 
/* 453 */       while (!this.stopAwait) {
/* 454 */         ServerSocket serverSocket = this.awaitSocket;
/* 455 */         if (serverSocket == null) {
/*     */           break;
/*     */         }
/*     */         
/*     */ 
/* 460 */         Socket socket = null;
/* 461 */         StringBuilder command = new StringBuilder();
/*     */         try
/*     */         {
/* 464 */           long acceptStartTime = System.currentTimeMillis();
/*     */           try {
/* 466 */             socket = serverSocket.accept();
/* 467 */             socket.setSoTimeout(10000);
/* 468 */             stream = socket.getInputStream();
/*     */           }
/*     */           catch (SocketTimeoutException ste) {
/*     */             InputStream stream;
/* 472 */             log.warn(sm.getString("standardServer.accept.timeout", new Object[] { Long.valueOf(System.currentTimeMillis() - acceptStartTime) }), ste);
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             try
/*     */             {
/* 511 */               if (socket != null) {
/* 512 */                 socket.close();
/*     */               }
/*     */             }
/*     */             catch (IOException localIOException1) {}
/* 516 */             continue;
/*     */           }
/*     */           catch (AccessControlException ace)
/*     */           {
/* 476 */             log.warn("StandardServer.accept security exception: " + ace.getMessage(), ace);
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             try
/*     */             {
/* 511 */               if (socket != null) {
/* 512 */                 socket.close();
/*     */               }
/*     */             }
/*     */             catch (IOException localIOException2) {}
/* 516 */             continue;
/*     */           }
/*     */           catch (IOException e)
/*     */           {
/* 480 */             if (this.stopAwait)
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               try
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 511 */                 if (socket != null) {
/* 512 */                   socket.close();
/*     */                 }
/*     */               }
/*     */               catch (IOException localIOException3) {}
/*     */             }
/* 484 */             log.error("StandardServer.await: accept: ", e);
/*     */           }
/*     */           
/*     */           InputStream stream;
/*     */           
/* 489 */           int expected = 1024;
/* 490 */           while (expected < this.shutdown.length()) {
/* 491 */             if (this.random == null)
/* 492 */               this.random = new Random();
/* 493 */             expected += this.random.nextInt() % 1024;
/*     */           }
/* 495 */           while (expected > 0) {
/* 496 */             int ch = -1;
/*     */             try {
/* 498 */               ch = stream.read();
/*     */             } catch (IOException e) {
/* 500 */               log.warn("StandardServer.await: read: ", e);
/* 501 */               ch = -1;
/*     */             }
/* 503 */             if (ch < 32)
/*     */               break;
/* 505 */             command.append((char)ch);
/* 506 */             expected--;
/*     */           }
/*     */           
/*     */           try
/*     */           {
/* 511 */             if (socket != null) {
/* 512 */               socket.close();
/*     */             }
/*     */           }
/*     */           catch (IOException localIOException5) {}
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 520 */           match = command.toString().equals(this.shutdown);
/*     */         }
/*     */         finally
/*     */         {
/*     */           try
/*     */           {
/* 511 */             if (socket != null) {
/* 512 */               socket.close();
/*     */             }
/*     */           }
/*     */           catch (IOException localIOException6) {}
/*     */         }
/*     */         
/*     */ 
/*     */         boolean match;
/*     */         
/* 521 */         if (match) {
/* 522 */           log.info(sm.getString("standardServer.shutdownViaPort"));
/* 523 */           break;
/*     */         }
/* 525 */         log.warn("StandardServer.await: Invalid command '" + command.toString() + "' received");
/*     */       }
/*     */     } finally {
/*     */       ServerSocket serverSocket;
/* 529 */       ServerSocket serverSocket = this.awaitSocket;
/* 530 */       this.awaitThread = null;
/* 531 */       this.awaitSocket = null;
/*     */       
/*     */ 
/* 534 */       if (serverSocket != null) {
/*     */         try {
/* 536 */           serverSocket.close();
/*     */         }
/*     */         catch (IOException localIOException8) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Service findService(String name)
/*     */   {
/* 554 */     if (name == null) {
/* 555 */       return null;
/*     */     }
/* 557 */     synchronized (this.servicesLock) {
/* 558 */       for (int i = 0; i < this.services.length; i++) {
/* 559 */         if (name.equals(this.services[i].getName())) {
/* 560 */           return this.services[i];
/*     */         }
/*     */       }
/*     */     }
/* 564 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Service[] findServices()
/*     */   {
/* 575 */     return this.services;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName[] getServiceNames()
/*     */   {
/* 583 */     ObjectName[] onames = new ObjectName[this.services.length];
/* 584 */     for (int i = 0; i < this.services.length; i++) {
/* 585 */       onames[i] = ((StandardService)this.services[i]).getObjectName();
/*     */     }
/* 587 */     return onames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeService(Service service)
/*     */   {
/* 600 */     synchronized (this.servicesLock) {
/* 601 */       int j = -1;
/* 602 */       for (int i = 0; i < this.services.length; i++) {
/* 603 */         if (service == this.services[i]) {
/* 604 */           j = i;
/* 605 */           break;
/*     */         }
/*     */       }
/* 608 */       if (j < 0)
/* 609 */         return;
/*     */       try {
/* 611 */         this.services[j].stop();
/*     */       }
/*     */       catch (LifecycleException localLifecycleException) {}
/*     */       
/* 615 */       int k = 0;
/* 616 */       Service[] results = new Service[this.services.length - 1];
/* 617 */       for (int i = 0; i < this.services.length; i++) {
/* 618 */         if (i != j)
/* 619 */           results[(k++)] = this.services[i];
/*     */       }
/* 621 */       this.services = results;
/*     */       
/*     */ 
/* 624 */       this.support.firePropertyChange("service", service, null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public File getCatalinaBase()
/*     */   {
/* 632 */     if (this.catalinaBase != null) {
/* 633 */       return this.catalinaBase;
/*     */     }
/*     */     
/* 636 */     this.catalinaBase = getCatalinaHome();
/* 637 */     return this.catalinaBase;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setCatalinaBase(File catalinaBase)
/*     */   {
/* 643 */     this.catalinaBase = catalinaBase;
/*     */   }
/*     */   
/*     */ 
/*     */   public File getCatalinaHome()
/*     */   {
/* 649 */     return this.catalinaHome;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setCatalinaHome(File catalinaHome)
/*     */   {
/* 655 */     this.catalinaHome = catalinaHome;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addPropertyChangeListener(PropertyChangeListener listener)
/*     */   {
/* 668 */     this.support.addPropertyChangeListener(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removePropertyChangeListener(PropertyChangeListener listener)
/*     */   {
/* 680 */     this.support.removePropertyChangeListener(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 691 */     StringBuilder sb = new StringBuilder("StandardServer[");
/* 692 */     sb.append(getPort());
/* 693 */     sb.append("]");
/* 694 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void storeConfig()
/*     */     throws InstanceNotFoundException, MBeanException
/*     */   {
/*     */     try
/*     */     {
/* 714 */       ObjectName sname = new ObjectName("Catalina:type=StoreConfig");
/* 715 */       if (this.mserver.isRegistered(sname)) {
/* 716 */         this.mserver.invoke(sname, "storeConfig", null, null);
/*     */       } else {
/* 718 */         log.error(sm.getString("standardServer.storeConfig.notAvailable", new Object[] { sname }));
/*     */       }
/*     */     } catch (Throwable t) {
/* 721 */       ExceptionUtils.handleThrowable(t);
/* 722 */       log.error(t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void storeContext(org.apache.catalina.Context context)
/*     */     throws InstanceNotFoundException, MBeanException
/*     */   {
/*     */     try
/*     */     {
/* 743 */       ObjectName sname = new ObjectName("Catalina:type=StoreConfig");
/* 744 */       if (this.mserver.isRegistered(sname)) {
/* 745 */         this.mserver.invoke(sname, "store", new Object[] { context }, new String[] { "java.lang.String" });
/*     */       }
/*     */       else
/*     */       {
/* 749 */         log.error(sm.getString("standardServer.storeConfig.notAvailable", new Object[] { sname }));
/*     */       }
/*     */     } catch (Throwable t) {
/* 752 */       ExceptionUtils.handleThrowable(t);
/* 753 */       log.error(t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isUseNaming()
/*     */   {
/* 762 */     boolean useNaming = true;
/*     */     
/* 764 */     String useNamingProperty = System.getProperty("catalina.useNaming");
/* 765 */     if ((useNamingProperty != null) && (useNamingProperty.equals("false")))
/*     */     {
/* 767 */       useNaming = false;
/*     */     }
/* 769 */     return useNaming;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 783 */     fireLifecycleEvent("configure_start", null);
/* 784 */     setState(LifecycleState.STARTING);
/*     */     
/* 786 */     this.globalNamingResources.start();
/*     */     
/*     */ 
/* 789 */     synchronized (this.servicesLock) {
/* 790 */       for (int i = 0; i < this.services.length; i++) {
/* 791 */         this.services[i].start();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void stopInternal()
/*     */     throws LifecycleException
/*     */   {
/* 807 */     setState(LifecycleState.STOPPING);
/* 808 */     fireLifecycleEvent("configure_stop", null);
/*     */     
/*     */ 
/* 811 */     for (int i = 0; i < this.services.length; i++) {
/* 812 */       this.services[i].stop();
/*     */     }
/*     */     
/* 815 */     this.globalNamingResources.stop();
/*     */     
/* 817 */     stopAwait();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initInternal()
/*     */     throws LifecycleException
/*     */   {
/* 827 */     super.initInternal();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 833 */     this.onameStringCache = register(new StringCache(), "type=StringCache");
/*     */     
/*     */ 
/* 836 */     MBeanFactory factory = new MBeanFactory();
/* 837 */     factory.setContainer(this);
/* 838 */     this.onameMBeanFactory = register(factory, "type=MBeanFactory");
/*     */     
/*     */ 
/* 841 */     this.globalNamingResources.init();
/*     */     
/*     */ 
/*     */ 
/* 845 */     if (getCatalina() != null) {
/* 846 */       ClassLoader cl = getCatalina().getParentClassLoader();
/*     */       
/*     */ 
/* 849 */       while ((cl != null) && (cl != ClassLoader.getSystemClassLoader())) {
/* 850 */         if ((cl instanceof URLClassLoader)) {
/* 851 */           URL[] urls = ((URLClassLoader)cl).getURLs();
/* 852 */           for (URL url : urls) {
/* 853 */             if (url.getProtocol().equals("file")) {
/*     */               try {
/* 855 */                 File f = new File(url.toURI());
/* 856 */                 if ((f.isFile()) && (f.getName().endsWith(".jar")))
/*     */                 {
/* 858 */                   ExtensionValidator.addSystemResource(f);
/*     */                 }
/*     */               }
/*     */               catch (URISyntaxException localURISyntaxException) {}catch (IOException localIOException) {}
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 868 */         cl = cl.getParent();
/*     */       }
/*     */     }
/*     */     
/* 872 */     for (int i = 0; i < this.services.length; i++) {
/* 873 */       this.services[i].init();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void destroyInternal()
/*     */     throws LifecycleException
/*     */   {
/* 880 */     for (int i = 0; i < this.services.length; i++) {
/* 881 */       this.services[i].destroy();
/*     */     }
/*     */     
/* 884 */     this.globalNamingResources.destroy();
/*     */     
/* 886 */     unregister(this.onameMBeanFactory);
/*     */     
/* 888 */     unregister(this.onameStringCache);
/*     */     
/* 890 */     super.destroyInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClassLoader getParentClassLoader()
/*     */   {
/* 898 */     if (this.parentClassLoader != null)
/* 899 */       return this.parentClassLoader;
/* 900 */     if (this.catalina != null) {
/* 901 */       return this.catalina.getParentClassLoader();
/*     */     }
/* 903 */     return ClassLoader.getSystemClassLoader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParentClassLoader(ClassLoader parent)
/*     */   {
/* 913 */     ClassLoader oldParentClassLoader = this.parentClassLoader;
/* 914 */     this.parentClassLoader = parent;
/* 915 */     this.support.firePropertyChange("parentClassLoader", oldParentClassLoader, this.parentClassLoader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDomainInternal()
/*     */   {
/* 934 */     String domain = null;
/*     */     
/* 936 */     Service[] services = findServices();
/* 937 */     if (services.length > 0) {
/* 938 */       Service service = services[0];
/* 939 */       if (service != null) {
/* 940 */         domain = service.getDomain();
/*     */       }
/*     */     }
/* 943 */     return domain;
/*     */   }
/*     */   
/*     */ 
/*     */   protected final String getObjectNameKeyProperties()
/*     */   {
/* 949 */     return "type=Server";
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\core\StandardServer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */