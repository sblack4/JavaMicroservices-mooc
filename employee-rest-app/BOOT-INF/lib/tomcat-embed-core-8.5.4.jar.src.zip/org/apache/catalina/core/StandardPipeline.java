/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Contained;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.JmxEnabled;
/*     */ import org.apache.catalina.Lifecycle;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Pipeline;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.util.LifecycleBase;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardPipeline
/*     */   extends LifecycleBase
/*     */   implements Pipeline, Contained
/*     */ {
/*  56 */   private static final Log log = LogFactory.getLog(StandardPipeline.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StandardPipeline()
/*     */   {
/*  66 */     this(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StandardPipeline(Container container)
/*     */   {
/*  80 */     setContainer(container);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  91 */   protected Valve basic = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  97 */   protected Container container = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 103 */   protected Valve first = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAsyncSupported()
/*     */   {
/* 110 */     Valve valve = this.first != null ? this.first : this.basic;
/* 111 */     boolean supported = true;
/* 112 */     while ((supported) && (valve != null)) {
/* 113 */       supported &= valve.isAsyncSupported();
/* 114 */       valve = valve.getNext();
/*     */     }
/* 116 */     return supported;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Container getContainer()
/*     */   {
/* 129 */     return this.container;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContainer(Container container)
/*     */   {
/* 142 */     this.container = container;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initInternal() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 164 */     Valve current = this.first;
/* 165 */     if (current == null) {
/* 166 */       current = this.basic;
/*     */     }
/* 168 */     while (current != null) {
/* 169 */       if ((current instanceof Lifecycle))
/* 170 */         ((Lifecycle)current).start();
/* 171 */       current = current.getNext();
/*     */     }
/*     */     
/* 174 */     setState(LifecycleState.STARTING);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void stopInternal()
/*     */     throws LifecycleException
/*     */   {
/* 188 */     setState(LifecycleState.STOPPING);
/*     */     
/*     */ 
/* 191 */     Valve current = this.first;
/* 192 */     if (current == null) {
/* 193 */       current = this.basic;
/*     */     }
/* 195 */     while (current != null) {
/* 196 */       if ((current instanceof Lifecycle))
/* 197 */         ((Lifecycle)current).stop();
/* 198 */       current = current.getNext();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void destroyInternal()
/*     */   {
/* 205 */     Valve[] valves = getValves();
/* 206 */     for (Valve valve : valves) {
/* 207 */       removeValve(valve);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 217 */     StringBuilder sb = new StringBuilder("Pipeline[");
/* 218 */     sb.append(this.container);
/* 219 */     sb.append(']');
/* 220 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Valve getBasic()
/*     */   {
/* 234 */     return this.basic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBasic(Valve valve)
/*     */   {
/* 255 */     Valve oldBasic = this.basic;
/* 256 */     if (oldBasic == valve) {
/* 257 */       return;
/*     */     }
/*     */     
/* 260 */     if (oldBasic != null) {
/* 261 */       if ((getState().isAvailable()) && ((oldBasic instanceof Lifecycle))) {
/*     */         try {
/* 263 */           ((Lifecycle)oldBasic).stop();
/*     */         } catch (LifecycleException e) {
/* 265 */           log.error("StandardPipeline.setBasic: stop", e);
/*     */         }
/*     */       }
/* 268 */       if ((oldBasic instanceof Contained)) {
/*     */         try {
/* 270 */           ((Contained)oldBasic).setContainer(null);
/*     */         } catch (Throwable t) {
/* 272 */           ExceptionUtils.handleThrowable(t);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 278 */     if (valve == null)
/* 279 */       return;
/* 280 */     if ((valve instanceof Contained)) {
/* 281 */       ((Contained)valve).setContainer(this.container);
/*     */     }
/* 283 */     if ((getState().isAvailable()) && ((valve instanceof Lifecycle))) {
/*     */       try {
/* 285 */         ((Lifecycle)valve).start();
/*     */       } catch (LifecycleException e) {
/* 287 */         log.error("StandardPipeline.setBasic: start", e);
/* 288 */         return;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 293 */     Valve current = this.first;
/* 294 */     while (current != null) {
/* 295 */       if (current.getNext() == oldBasic) {
/* 296 */         current.setNext(valve);
/* 297 */         break;
/*     */       }
/* 299 */       current = current.getNext();
/*     */     }
/*     */     
/* 302 */     this.basic = valve;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addValve(Valve valve)
/*     */   {
/* 330 */     if ((valve instanceof Contained)) {
/* 331 */       ((Contained)valve).setContainer(this.container);
/*     */     }
/*     */     
/* 334 */     if ((getState().isAvailable()) && 
/* 335 */       ((valve instanceof Lifecycle))) {
/*     */       try {
/* 337 */         ((Lifecycle)valve).start();
/*     */       } catch (LifecycleException e) {
/* 339 */         log.error("StandardPipeline.addValve: start: ", e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 345 */     if (this.first == null) {
/* 346 */       this.first = valve;
/* 347 */       valve.setNext(this.basic);
/*     */     } else {
/* 349 */       Valve current = this.first;
/* 350 */       while (current != null) {
/* 351 */         if (current.getNext() == this.basic) {
/* 352 */           current.setNext(valve);
/* 353 */           valve.setNext(this.basic);
/* 354 */           break;
/*     */         }
/* 356 */         current = current.getNext();
/*     */       }
/*     */     }
/*     */     
/* 360 */     this.container.fireContainerEvent("addValve", valve);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Valve[] getValves()
/*     */   {
/* 372 */     ArrayList<Valve> valveList = new ArrayList();
/* 373 */     Valve current = this.first;
/* 374 */     if (current == null) {
/* 375 */       current = this.basic;
/*     */     }
/* 377 */     while (current != null) {
/* 378 */       valveList.add(current);
/* 379 */       current = current.getNext();
/*     */     }
/*     */     
/* 382 */     return (Valve[])valveList.toArray(new Valve[0]);
/*     */   }
/*     */   
/*     */ 
/*     */   public ObjectName[] getValveObjectNames()
/*     */   {
/* 388 */     ArrayList<ObjectName> valveList = new ArrayList();
/* 389 */     Valve current = this.first;
/* 390 */     if (current == null) {
/* 391 */       current = this.basic;
/*     */     }
/* 393 */     while (current != null) {
/* 394 */       if ((current instanceof JmxEnabled)) {
/* 395 */         valveList.add(((JmxEnabled)current).getObjectName());
/*     */       }
/* 397 */       current = current.getNext();
/*     */     }
/*     */     
/* 400 */     return (ObjectName[])valveList.toArray(new ObjectName[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeValve(Valve valve)
/*     */   {
/*     */     Valve current;
/*     */     
/*     */ 
/*     */ 
/*     */     Valve current;
/*     */     
/*     */ 
/*     */ 
/* 416 */     if (this.first == valve) {
/* 417 */       this.first = this.first.getNext();
/* 418 */       current = null;
/*     */     } else {
/* 420 */       current = this.first;
/*     */     }
/* 422 */     while (current != null) {
/* 423 */       if (current.getNext() == valve) {
/* 424 */         current.setNext(valve.getNext());
/* 425 */         break;
/*     */       }
/* 427 */       current = current.getNext();
/*     */     }
/*     */     
/* 430 */     if (this.first == this.basic) { this.first = null;
/*     */     }
/* 432 */     if ((valve instanceof Contained)) {
/* 433 */       ((Contained)valve).setContainer(null);
/*     */     }
/* 435 */     if ((valve instanceof Lifecycle))
/*     */     {
/* 437 */       if (getState().isAvailable()) {
/*     */         try {
/* 439 */           ((Lifecycle)valve).stop();
/*     */         } catch (LifecycleException e) {
/* 441 */           log.error("StandardPipeline.removeValve: stop: ", e);
/*     */         }
/*     */       }
/*     */       try {
/* 445 */         ((Lifecycle)valve).destroy();
/*     */       } catch (LifecycleException e) {
/* 447 */         log.error("StandardPipeline.removeValve: destroy: ", e);
/*     */       }
/*     */     }
/*     */     
/* 451 */     this.container.fireContainerEvent("removeValve", valve);
/*     */   }
/*     */   
/*     */ 
/*     */   public Valve getFirst()
/*     */   {
/* 457 */     if (this.first != null) {
/* 458 */       return this.first;
/*     */     }
/*     */     
/* 461 */     return this.basic;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\core\StandardPipeline.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */