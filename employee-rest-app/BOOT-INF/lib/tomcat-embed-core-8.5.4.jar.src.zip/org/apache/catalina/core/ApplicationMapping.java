/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import org.apache.catalina.Wrapper;
/*     */ import org.apache.catalina.mapper.MappingData;
/*     */ import org.apache.catalina.servlet4preview.http.Mapping;
/*     */ import org.apache.catalina.servlet4preview.http.MappingMatch;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationMapping
/*     */ {
/*     */   private final MappingData mappingData;
/*  27 */   private volatile Mapping mapping = null;
/*     */   
/*     */   public ApplicationMapping(MappingData mappingData) {
/*  30 */     this.mappingData = mappingData;
/*     */   }
/*     */   
/*     */   public Mapping getMapping() {
/*  34 */     if (this.mapping == null) {
/*  35 */       if (this.mappingData == null) {
/*  36 */         this.mapping = new MappingImpl("", "", MappingMatch.UNKNOWN, "");
/*     */       } else { String servletName;
/*     */         String servletName;
/*  39 */         if (this.mappingData.wrapper == null) {
/*  40 */           servletName = "";
/*     */         } else {
/*  42 */           servletName = this.mappingData.wrapper.getName();
/*     */         }
/*  44 */         switch (this.mappingData.matchType) {
/*     */         case CONTEXT_ROOT: 
/*  46 */           this.mapping = new MappingImpl("", "", this.mappingData.matchType, servletName);
/*  47 */           break;
/*     */         case DEFAULT: 
/*  49 */           this.mapping = new MappingImpl("/", "/", this.mappingData.matchType, servletName);
/*  50 */           break;
/*     */         case EXACT: 
/*  52 */           this.mapping = new MappingImpl(this.mappingData.wrapperPath.toString(), this.mappingData.wrapperPath.toString(), this.mappingData.matchType, servletName);
/*     */           
/*  54 */           break;
/*     */         case EXTENSION: 
/*  56 */           String path = this.mappingData.wrapperPath.toString();
/*  57 */           int extIndex = path.lastIndexOf('.');
/*  58 */           this.mapping = new MappingImpl(path.substring(0, extIndex), "*" + path.substring(extIndex), this.mappingData.matchType, servletName);
/*     */           
/*  60 */           break;
/*     */         case PATH: 
/*  62 */           this.mapping = new MappingImpl(this.mappingData.pathInfo.toString(), this.mappingData.wrapperPath.toString() + "/*", this.mappingData.matchType, servletName);
/*     */           
/*     */ 
/*  65 */           break;
/*     */         case UNKNOWN: 
/*  67 */           this.mapping = new MappingImpl("", "", this.mappingData.matchType, servletName);
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     
/*  73 */     return this.mapping;
/*     */   }
/*     */   
/*     */   public void recycle() {
/*  77 */     this.mapping = null;
/*     */   }
/*     */   
/*     */   private static class MappingImpl implements Mapping
/*     */   {
/*     */     private final String matchValue;
/*     */     private final String pattern;
/*     */     private final MappingMatch mappingType;
/*     */     private final String servletName;
/*     */     
/*     */     public MappingImpl(String matchValue, String pattern, MappingMatch mappingType, String servletName)
/*     */     {
/*  89 */       this.matchValue = matchValue;
/*  90 */       this.pattern = pattern;
/*  91 */       this.mappingType = mappingType;
/*  92 */       this.servletName = servletName;
/*     */     }
/*     */     
/*     */     public String getMatchValue()
/*     */     {
/*  97 */       return this.matchValue;
/*     */     }
/*     */     
/*     */     public String getPattern()
/*     */     {
/* 102 */       return this.pattern;
/*     */     }
/*     */     
/*     */     public MappingMatch getMappingMatch()
/*     */     {
/* 107 */       return this.mappingType;
/*     */     }
/*     */     
/*     */     public String getServletName()
/*     */     {
/* 112 */       return this.servletName;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\core\ApplicationMapping.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */