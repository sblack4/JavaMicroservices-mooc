/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Pipeline;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.Wrapper;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.catalina.valves.ValveBase;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class StandardContextValve
/*     */   extends ValveBase
/*     */ {
/*  44 */   private static final StringManager sm = StringManager.getManager(StandardContextValve.class);
/*     */   
/*     */   public StandardContextValve() {
/*  47 */     super(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContainer(Container container)
/*     */   {
/*  58 */     super.setContainer(container);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void invoke(Request request, Response response)
/*     */     throws IOException, ServletException
/*     */   {
/*  78 */     MessageBytes requestPathMB = request.getRequestPathMB();
/*  79 */     if ((requestPathMB.startsWithIgnoreCase("/META-INF/", 0)) || (requestPathMB.equalsIgnoreCase("/META-INF")) || (requestPathMB.startsWithIgnoreCase("/WEB-INF/", 0)) || (requestPathMB.equalsIgnoreCase("/WEB-INF")))
/*     */     {
/*     */ 
/*     */ 
/*  83 */       response.sendError(404);
/*  84 */       return;
/*     */     }
/*     */     
/*     */ 
/*  88 */     Wrapper wrapper = request.getWrapper();
/*  89 */     if ((wrapper == null) || (wrapper.isUnavailable())) {
/*  90 */       response.sendError(404);
/*  91 */       return;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/*  96 */       response.sendAcknowledgement();
/*     */     } catch (IOException ioe) {
/*  98 */       this.container.getLogger().error(sm.getString("standardContextValve.acknowledgeException"), ioe);
/*     */       
/* 100 */       request.setAttribute("javax.servlet.error.exception", ioe);
/* 101 */       response.sendError(500);
/* 102 */       return;
/*     */     }
/*     */     
/* 105 */     if (request.isAsyncSupported()) {
/* 106 */       request.setAsyncSupported(wrapper.getPipeline().isAsyncSupported());
/*     */     }
/* 108 */     wrapper.getPipeline().getFirst().invoke(request, response);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\core\StandardContextValve.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */