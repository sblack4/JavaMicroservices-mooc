/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.management.ObjectName;
/*     */ import javax.naming.NamingException;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.security.SecurityUtil;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.InstanceManager;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.descriptor.web.FilterDef;
/*     */ import org.apache.tomcat.util.log.SystemLogHandler;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.modeler.Util;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ApplicationFilterConfig
/*     */   implements FilterConfig, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  62 */   static final StringManager sm = StringManager.getManager("org.apache.catalina.core");
/*     */   
/*     */ 
/*  65 */   private static final Log log = LogFactory.getLog(ApplicationFilterConfig.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  70 */   private static final List<String> emptyString = Collections.emptyList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final transient Context context;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   ApplicationFilterConfig(Context context, FilterDef filterDef)
/*     */     throws ClassCastException, ClassNotFoundException, IllegalAccessException, InstantiationException, ServletException, InvocationTargetException, NamingException
/*     */   {
/* 101 */     this.context = context;
/* 102 */     this.filterDef = filterDef;
/*     */     
/* 104 */     if (filterDef.getFilter() == null) {
/* 105 */       getFilter();
/*     */     } else {
/* 107 */       this.filter = filterDef.getFilter();
/* 108 */       getInstanceManager().newInstance(this.filter);
/* 109 */       initFilter();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 126 */   private transient Filter filter = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final FilterDef filterDef;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private transient InstanceManager instanceManager;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ObjectName oname;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFilterName()
/*     */   {
/* 152 */     return this.filterDef.getFilterName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getFilterClass()
/*     */   {
/* 159 */     return this.filterDef.getFilterClass();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getInitParameter(String name)
/*     */   {
/* 172 */     Map<String, String> map = this.filterDef.getParameterMap();
/* 173 */     if (map == null) {
/* 174 */       return null;
/*     */     }
/*     */     
/* 177 */     return (String)map.get(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Enumeration<String> getInitParameterNames()
/*     */   {
/* 188 */     Map<String, String> map = this.filterDef.getParameterMap();
/*     */     
/* 190 */     if (map == null) {
/* 191 */       return Collections.enumeration(emptyString);
/*     */     }
/*     */     
/* 194 */     return Collections.enumeration(map.keySet());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletContext getServletContext()
/*     */   {
/* 204 */     return this.context.getServletContext();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 215 */     StringBuilder sb = new StringBuilder("ApplicationFilterConfig[");
/* 216 */     sb.append("name=");
/* 217 */     sb.append(this.filterDef.getFilterName());
/* 218 */     sb.append(", filterClass=");
/* 219 */     sb.append(this.filterDef.getFilterClass());
/* 220 */     sb.append("]");
/* 221 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Map<String, String> getFilterInitParameterMap()
/*     */   {
/* 228 */     return Collections.unmodifiableMap(this.filterDef.getParameterMap());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Filter getFilter()
/*     */     throws ClassCastException, ClassNotFoundException, IllegalAccessException, InstantiationException, ServletException, InvocationTargetException, NamingException
/*     */   {
/* 253 */     if (this.filter != null) {
/* 254 */       return this.filter;
/*     */     }
/*     */     
/* 257 */     String filterClass = this.filterDef.getFilterClass();
/* 258 */     this.filter = ((Filter)getInstanceManager().newInstance(filterClass));
/*     */     
/* 260 */     initFilter();
/*     */     
/* 262 */     return this.filter;
/*     */   }
/*     */   
/*     */   private void initFilter() throws ServletException
/*     */   {
/* 267 */     if (((this.context instanceof StandardContext)) && (this.context.getSwallowOutput())) {
/*     */       try
/*     */       {
/* 270 */         SystemLogHandler.startCapture();
/* 271 */         this.filter.init(this);
/*     */       } finally { String capturedlog;
/* 273 */         String capturedlog = SystemLogHandler.stopCapture();
/* 274 */         if ((capturedlog != null) && (capturedlog.length() > 0)) {
/* 275 */           getServletContext().log(capturedlog);
/*     */         }
/*     */       }
/*     */     } else {
/* 279 */       this.filter.init(this);
/*     */     }
/*     */     
/*     */ 
/* 283 */     registerJMX();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   FilterDef getFilterDef()
/*     */   {
/* 291 */     return this.filterDef;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void release()
/*     */   {
/* 301 */     unregisterJMX();
/*     */     
/* 303 */     if (this.filter != null) {
/*     */       try {
/* 305 */         if (Globals.IS_SECURITY_ENABLED) {
/*     */           try {
/* 307 */             SecurityUtil.doAsPrivilege("destroy", this.filter);
/*     */           } finally {
/* 309 */             SecurityUtil.remove(this.filter);
/*     */           }
/*     */         } else {
/* 312 */           this.filter.destroy();
/*     */         }
/*     */       } catch (Throwable t) {
/* 315 */         ExceptionUtils.handleThrowable(t);
/* 316 */         this.context.getLogger().error(sm.getString("applicationFilterConfig.release", new Object[] { this.filterDef.getFilterName(), this.filterDef.getFilterClass() }), t);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 321 */       if (!this.context.getIgnoreAnnotations()) {
/*     */         try {
/* 323 */           ((StandardContext)this.context).getInstanceManager().destroyInstance(this.filter);
/*     */         } catch (Exception e) {
/* 325 */           Throwable t = ExceptionUtils.unwrapInvocationTargetException(e);
/*     */           
/* 327 */           ExceptionUtils.handleThrowable(t);
/* 328 */           this.context.getLogger().error(sm.getString("applicationFilterConfig.preDestroy", new Object[] { this.filterDef.getFilterName(), this.filterDef.getFilterClass() }), t);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 334 */     this.filter = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private InstanceManager getInstanceManager()
/*     */   {
/* 342 */     if (this.instanceManager == null) {
/* 343 */       if ((this.context instanceof StandardContext)) {
/* 344 */         this.instanceManager = ((StandardContext)this.context).getInstanceManager();
/*     */       } else {
/* 346 */         this.instanceManager = new DefaultInstanceManager(null, new HashMap(), this.context, getClass().getClassLoader());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 352 */     return this.instanceManager;
/*     */   }
/*     */   
/*     */   private void registerJMX() {
/* 356 */     String parentName = this.context.getName();
/* 357 */     if (!parentName.startsWith("/")) {
/* 358 */       parentName = "/" + parentName;
/*     */     }
/*     */     
/* 361 */     String hostName = this.context.getParent().getName();
/* 362 */     hostName = hostName == null ? "DEFAULT" : hostName;
/*     */     
/*     */ 
/* 365 */     String domain = this.context.getParent().getParent().getName();
/*     */     
/* 367 */     String webMod = "//" + hostName + parentName;
/* 368 */     String onameStr = null;
/* 369 */     String filterName = this.filterDef.getFilterName();
/* 370 */     if (Util.objectNameValueNeedsQuote(filterName)) {
/* 371 */       filterName = ObjectName.quote(filterName);
/*     */     }
/* 373 */     if ((this.context instanceof StandardContext)) {
/* 374 */       StandardContext standardContext = (StandardContext)this.context;
/* 375 */       onameStr = domain + ":j2eeType=Filter,WebModule=" + webMod + ",name=" + filterName + ",J2EEApplication=" + standardContext.getJ2EEApplication() + ",J2EEServer=" + standardContext.getJ2EEServer();
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 380 */       onameStr = domain + ":j2eeType=Filter,name=" + filterName + ",WebModule=" + webMod;
/*     */     }
/*     */     try
/*     */     {
/* 384 */       this.oname = new ObjectName(onameStr);
/* 385 */       Registry.getRegistry(null, null).registerComponent(this, this.oname, null);
/*     */     }
/*     */     catch (Exception ex) {
/* 388 */       log.info(sm.getString("applicationFilterConfig.jmxRegisterFail", new Object[] { getFilterClass(), getFilterName() }), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void unregisterJMX()
/*     */   {
/* 395 */     if (this.oname != null) {
/*     */       try {
/* 397 */         Registry.getRegistry(null, null).unregisterComponent(this.oname);
/* 398 */         if (log.isDebugEnabled()) {
/* 399 */           log.debug(sm.getString("applicationFilterConfig.jmxUnregister", new Object[] { getFilterClass(), getFilterName() }));
/*     */         }
/*     */       }
/*     */       catch (Exception ex) {
/* 403 */         log.error(sm.getString("applicationFilterConfig.jmxUnregisterFail", new Object[] { getFilterClass(), getFilterName() }), ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\core\ApplicationFilterConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */