/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import java.io.File;
/*     */ import java.util.Locale;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.apache.catalina.AccessLog;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.ContainerEvent;
/*     */ import org.apache.catalina.ContainerListener;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Pipeline;
/*     */ import org.apache.catalina.Realm;
/*     */ import org.apache.catalina.Server;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.catalina.realm.NullRealm;
/*     */ import org.apache.catalina.util.ServerInfo;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardEngine
/*     */   extends ContainerBase
/*     */   implements Engine
/*     */ {
/*  56 */   private static final Log log = LogFactory.getLog(StandardEngine.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StandardEngine()
/*     */   {
/*  67 */     this.pipeline.setBasic(new StandardEngineValve());
/*     */     try
/*     */     {
/*  70 */       setJvmRoute(System.getProperty("jvmRoute"));
/*     */     } catch (Exception ex) {
/*  72 */       log.warn(sm.getString("standardEngine.jvmRouteFail"));
/*     */     }
/*     */     
/*  75 */     this.backgroundProcessorDelay = 10;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  87 */   private String defaultHost = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */   private Service service = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String jvmRouteId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */   private final AtomicReference<AccessLog> defaultAccessLog = new AtomicReference();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Realm getRealm()
/*     */   {
/* 118 */     Realm configured = super.getRealm();
/*     */     
/*     */ 
/* 121 */     if (configured == null) {
/* 122 */       configured = new NullRealm();
/* 123 */       setRealm(configured);
/*     */     }
/* 125 */     return configured;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDefaultHost()
/*     */   {
/* 135 */     return this.defaultHost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultHost(String host)
/*     */   {
/* 148 */     String oldDefaultHost = this.defaultHost;
/* 149 */     if (host == null) {
/* 150 */       this.defaultHost = null;
/*     */     } else {
/* 152 */       this.defaultHost = host.toLowerCase(Locale.ENGLISH);
/*     */     }
/* 154 */     this.support.firePropertyChange("defaultHost", oldDefaultHost, this.defaultHost);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setJvmRoute(String routeId)
/*     */   {
/* 168 */     this.jvmRouteId = routeId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getJvmRoute()
/*     */   {
/* 178 */     return this.jvmRouteId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Service getService()
/*     */   {
/* 188 */     return this.service;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setService(Service service)
/*     */   {
/* 200 */     this.service = service;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addChild(Container child)
/*     */   {
/* 215 */     if (!(child instanceof Host)) {
/* 216 */       throw new IllegalArgumentException(sm.getString("standardEngine.notHost"));
/*     */     }
/* 218 */     super.addChild(child);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParent(Container container)
/*     */   {
/* 232 */     throw new IllegalArgumentException(sm.getString("standardEngine.notParent"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initInternal()
/*     */     throws LifecycleException
/*     */   {
/* 242 */     getRealm();
/* 243 */     super.initInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 258 */     if (log.isInfoEnabled()) {
/* 259 */       log.info("Starting Servlet Engine: " + ServerInfo.getServerInfo());
/*     */     }
/*     */     
/* 262 */     super.startInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 272 */     StringBuilder sb = new StringBuilder("StandardEngine[");
/* 273 */     sb.append(getName());
/* 274 */     sb.append("]");
/* 275 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void logAccess(Request request, Response response, long time, boolean useDefault)
/*     */   {
/* 289 */     boolean logged = false;
/*     */     
/* 291 */     if (getAccessLog() != null) {
/* 292 */       this.accessLog.log(request, response, time);
/* 293 */       logged = true;
/*     */     }
/*     */     
/* 296 */     if ((!logged) && (useDefault)) {
/* 297 */       AccessLog newDefaultAccessLog = (AccessLog)this.defaultAccessLog.get();
/* 298 */       if (newDefaultAccessLog == null)
/*     */       {
/*     */ 
/* 301 */         Host host = (Host)findChild(getDefaultHost());
/* 302 */         Context context = null;
/* 303 */         if ((host != null) && (host.getState().isAvailable())) {
/* 304 */           newDefaultAccessLog = host.getAccessLog();
/*     */           
/* 306 */           if (newDefaultAccessLog != null) {
/* 307 */             if (this.defaultAccessLog.compareAndSet(null, newDefaultAccessLog))
/*     */             {
/* 309 */               AccessLogListener l = new AccessLogListener(this, host, null);
/*     */               
/* 311 */               l.install();
/*     */             }
/*     */           }
/*     */           else {
/* 315 */             context = (Context)host.findChild("");
/* 316 */             if ((context != null) && (context.getState().isAvailable()))
/*     */             {
/* 318 */               newDefaultAccessLog = context.getAccessLog();
/* 319 */               if ((newDefaultAccessLog != null) && 
/* 320 */                 (this.defaultAccessLog.compareAndSet(null, newDefaultAccessLog)))
/*     */               {
/* 322 */                 AccessLogListener l = new AccessLogListener(this, null, context);
/*     */                 
/* 324 */                 l.install();
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 331 */         if (newDefaultAccessLog == null) {
/* 332 */           newDefaultAccessLog = new NoopAccessLog();
/* 333 */           if (this.defaultAccessLog.compareAndSet(null, newDefaultAccessLog))
/*     */           {
/* 335 */             AccessLogListener l = new AccessLogListener(this, host, context);
/*     */             
/* 337 */             l.install();
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 342 */       newDefaultAccessLog.log(request, response, time);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClassLoader getParentClassLoader()
/*     */   {
/* 352 */     if (this.parentClassLoader != null)
/* 353 */       return this.parentClassLoader;
/* 354 */     if (this.service != null) {
/* 355 */       return this.service.getParentClassLoader();
/*     */     }
/* 357 */     return ClassLoader.getSystemClassLoader();
/*     */   }
/*     */   
/*     */ 
/*     */   public File getCatalinaBase()
/*     */   {
/* 363 */     if (this.service != null) {
/* 364 */       Server s = this.service.getServer();
/* 365 */       if (s != null) {
/* 366 */         File base = s.getCatalinaBase();
/* 367 */         if (base != null) {
/* 368 */           return base;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 373 */     return super.getCatalinaBase();
/*     */   }
/*     */   
/*     */ 
/*     */   public File getCatalinaHome()
/*     */   {
/* 379 */     if (this.service != null) {
/* 380 */       Server s = this.service.getServer();
/* 381 */       if (s != null) {
/* 382 */         File base = s.getCatalinaHome();
/* 383 */         if (base != null) {
/* 384 */           return base;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 389 */     return super.getCatalinaHome();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getObjectNameKeyProperties()
/*     */   {
/* 397 */     return "type=Engine";
/*     */   }
/*     */   
/*     */ 
/*     */   protected String getDomainInternal()
/*     */   {
/* 403 */     return getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static final class NoopAccessLog
/*     */     implements AccessLog
/*     */   {
/*     */     public void log(Request request, Response response, long time) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setRequestAttributesEnabled(boolean requestAttributesEnabled) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean getRequestAttributesEnabled()
/*     */     {
/* 425 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected static final class AccessLogListener
/*     */     implements PropertyChangeListener, LifecycleListener, ContainerListener
/*     */   {
/*     */     private final StandardEngine engine;
/*     */     private final Host host;
/*     */     private final Context context;
/* 436 */     private volatile boolean disabled = false;
/*     */     
/*     */     public AccessLogListener(StandardEngine engine, Host host, Context context)
/*     */     {
/* 440 */       this.engine = engine;
/* 441 */       this.host = host;
/* 442 */       this.context = context;
/*     */     }
/*     */     
/*     */     public void install() {
/* 446 */       this.engine.addPropertyChangeListener(this);
/* 447 */       if (this.host != null) {
/* 448 */         this.host.addContainerListener(this);
/* 449 */         this.host.addLifecycleListener(this);
/*     */       }
/* 451 */       if (this.context != null) {
/* 452 */         this.context.addLifecycleListener(this);
/*     */       }
/*     */     }
/*     */     
/*     */     private void uninstall() {
/* 457 */       this.disabled = true;
/* 458 */       if (this.context != null) {
/* 459 */         this.context.removeLifecycleListener(this);
/*     */       }
/* 461 */       if (this.host != null) {
/* 462 */         this.host.removeLifecycleListener(this);
/* 463 */         this.host.removeContainerListener(this);
/*     */       }
/* 465 */       this.engine.removePropertyChangeListener(this);
/*     */     }
/*     */     
/*     */     public void lifecycleEvent(LifecycleEvent event)
/*     */     {
/* 470 */       if (this.disabled) { return;
/*     */       }
/* 472 */       String type = event.getType();
/* 473 */       if (("after_start".equals(type)) || ("before_stop".equals(type)) || ("before_destroy".equals(type)))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 479 */         this.engine.defaultAccessLog.set(null);
/* 480 */         uninstall();
/*     */       }
/*     */     }
/*     */     
/*     */     public void propertyChange(PropertyChangeEvent evt)
/*     */     {
/* 486 */       if (this.disabled) return;
/* 487 */       if ("defaultHost".equals(evt.getPropertyName()))
/*     */       {
/*     */ 
/* 490 */         this.engine.defaultAccessLog.set(null);
/* 491 */         uninstall();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public void containerEvent(ContainerEvent event)
/*     */     {
/* 498 */       if (this.disabled) return;
/* 499 */       if ("addChild".equals(event.getType())) {
/* 500 */         Context context = (Context)event.getData();
/* 501 */         if ("".equals(context.getPath()))
/*     */         {
/*     */ 
/* 504 */           this.engine.defaultAccessLog.set(null);
/* 505 */           uninstall();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\core\StandardEngine.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */