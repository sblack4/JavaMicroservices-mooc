/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import javax.naming.NamingException;
/*     */ import javax.servlet.AsyncContext;
/*     */ import javax.servlet.AsyncEvent;
/*     */ import javax.servlet.AsyncListener;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.catalina.AsyncDispatcher;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.Pipeline;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.coyote.AsyncContextCallback;
/*     */ import org.apache.coyote.RequestInfo;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.InstanceManager;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsyncContextImpl
/*     */   implements AsyncContext, AsyncContextCallback
/*     */ {
/*  55 */   private static final Log log = LogFactory.getLog(AsyncContextImpl.class);
/*     */   
/*  57 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.core");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */   private final Object asyncContextLock = new Object();
/*     */   
/*  69 */   private volatile ServletRequest servletRequest = null;
/*  70 */   private volatile ServletResponse servletResponse = null;
/*  71 */   private final List<AsyncListenerWrapper> listeners = new ArrayList();
/*  72 */   private boolean hasOriginalRequestAndResponse = true;
/*  73 */   private volatile Runnable dispatch = null;
/*  74 */   private Context context = null;
/*     */   
/*  76 */   private long timeout = -1L;
/*  77 */   private AsyncEvent event = null;
/*     */   private volatile org.apache.catalina.connector.Request request;
/*     */   private volatile InstanceManager instanceManager;
/*     */   
/*     */   public AsyncContextImpl(org.apache.catalina.connector.Request request) {
/*  82 */     if (log.isDebugEnabled()) {
/*  83 */       logDebug("Constructor");
/*     */     }
/*  85 */     this.request = request;
/*     */   }
/*     */   
/*     */   public void complete()
/*     */   {
/*  90 */     if (log.isDebugEnabled()) {
/*  91 */       logDebug("complete   ");
/*     */     }
/*  93 */     check();
/*  94 */     this.request.getCoyoteRequest().action(ActionCode.ASYNC_COMPLETE, null);
/*     */   }
/*     */   
/*     */   public void fireOnComplete()
/*     */   {
/*  99 */     List<AsyncListenerWrapper> listenersCopy = new ArrayList();
/* 100 */     listenersCopy.addAll(this.listeners);
/*     */     
/* 102 */     ClassLoader oldCL = this.context.bind(Globals.IS_SECURITY_ENABLED, null);
/*     */     try {
/* 104 */       for (AsyncListenerWrapper listener : listenersCopy) {
/*     */         try {
/* 106 */           listener.fireOnComplete(this.event);
/*     */         } catch (Throwable t) {
/* 108 */           ExceptionUtils.handleThrowable(t);
/* 109 */           log.warn("onComplete() failed for listener of type [" + listener.getClass().getName() + "]", t);
/*     */         }
/*     */       }
/*     */     }
/*     */     finally {
/* 114 */       clearServletRequestResponse();
/* 115 */       this.context.unbind(Globals.IS_SECURITY_ENABLED, oldCL);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean timeout()
/*     */   {
/* 121 */     AtomicBoolean result = new AtomicBoolean();
/* 122 */     this.request.getCoyoteRequest().action(ActionCode.ASYNC_TIMEOUT, result);
/*     */     
/* 124 */     if (result.get()) {
/* 125 */       ClassLoader oldCL = this.context.bind(false, null);
/*     */       try {
/* 127 */         List<AsyncListenerWrapper> listenersCopy = new ArrayList();
/* 128 */         listenersCopy.addAll(this.listeners);
/* 129 */         for (AsyncListenerWrapper listener : listenersCopy) {
/*     */           try {
/* 131 */             listener.fireOnTimeout(this.event);
/*     */           } catch (Throwable t) {
/* 133 */             ExceptionUtils.handleThrowable(t);
/* 134 */             log.warn("onTimeout() failed for listener of type [" + listener.getClass().getName() + "]", t);
/*     */           }
/*     */         }
/*     */         
/* 138 */         this.request.getCoyoteRequest().action(ActionCode.ASYNC_IS_TIMINGOUT, result);
/*     */       }
/*     */       finally {
/* 141 */         this.context.unbind(false, oldCL);
/*     */       }
/*     */     }
/* 144 */     return !result.get();
/*     */   }
/*     */   
/*     */   public void dispatch()
/*     */   {
/* 149 */     check();
/*     */     
/*     */ 
/* 152 */     ServletRequest servletRequest = getRequest();
/* 153 */     String pathInfo; String path; String pathInfo; if ((servletRequest instanceof HttpServletRequest)) {
/* 154 */       HttpServletRequest sr = (HttpServletRequest)servletRequest;
/* 155 */       String path = sr.getServletPath();
/* 156 */       pathInfo = sr.getPathInfo();
/*     */     } else {
/* 158 */       path = this.request.getServletPath();
/* 159 */       pathInfo = this.request.getPathInfo();
/*     */     }
/* 161 */     if (pathInfo != null) {
/* 162 */       path = path + pathInfo;
/*     */     }
/* 164 */     dispatch(path);
/*     */   }
/*     */   
/*     */   public void dispatch(String path)
/*     */   {
/* 169 */     check();
/* 170 */     dispatch(getRequest().getServletContext(), path);
/*     */   }
/*     */   
/*     */   public void dispatch(ServletContext context, String path)
/*     */   {
/* 175 */     synchronized (this.asyncContextLock) {
/* 176 */       if (log.isDebugEnabled()) {
/* 177 */         logDebug("dispatch   ");
/*     */       }
/* 179 */       check();
/* 180 */       if (this.dispatch != null) {
/* 181 */         throw new IllegalStateException(sm.getString("asyncContextImpl.dispatchingStarted"));
/*     */       }
/*     */       
/* 184 */       if (this.request.getAttribute("javax.servlet.async.request_uri") == null) {
/* 185 */         this.request.setAttribute("javax.servlet.async.request_uri", this.request.getRequestURI());
/* 186 */         this.request.setAttribute("javax.servlet.async.context_path", this.request.getContextPath());
/* 187 */         this.request.setAttribute("javax.servlet.async.servlet_path", this.request.getServletPath());
/* 188 */         this.request.setAttribute("javax.servlet.async.path_info", this.request.getPathInfo());
/* 189 */         this.request.setAttribute("javax.servlet.async.query_string", this.request.getQueryString());
/*     */       }
/* 191 */       RequestDispatcher requestDispatcher = context.getRequestDispatcher(path);
/* 192 */       if (!(requestDispatcher instanceof AsyncDispatcher)) {
/* 193 */         throw new UnsupportedOperationException(sm.getString("asyncContextImpl.noAsyncDispatcher"));
/*     */       }
/*     */       
/* 196 */       AsyncDispatcher applicationDispatcher = (AsyncDispatcher)requestDispatcher;
/*     */       
/* 198 */       ServletRequest servletRequest = getRequest();
/* 199 */       ServletResponse servletResponse = getResponse();
/* 200 */       this.dispatch = new AsyncRunnable(this.request, applicationDispatcher, servletRequest, servletResponse);
/*     */       
/* 202 */       this.request.getCoyoteRequest().action(ActionCode.ASYNC_DISPATCH, null);
/* 203 */       clearServletRequestResponse();
/*     */     }
/*     */   }
/*     */   
/*     */   public ServletRequest getRequest()
/*     */   {
/* 209 */     check();
/* 210 */     if (this.servletRequest == null) {
/* 211 */       throw new IllegalStateException(sm.getString("asyncContextImpl.request.ise"));
/*     */     }
/*     */     
/* 214 */     return this.servletRequest;
/*     */   }
/*     */   
/*     */   public ServletResponse getResponse()
/*     */   {
/* 219 */     check();
/* 220 */     if (this.servletResponse == null) {
/* 221 */       throw new IllegalStateException(sm.getString("asyncContextImpl.response.ise"));
/*     */     }
/*     */     
/* 224 */     return this.servletResponse;
/*     */   }
/*     */   
/*     */   public void start(Runnable run)
/*     */   {
/* 229 */     if (log.isDebugEnabled()) {
/* 230 */       logDebug("start      ");
/*     */     }
/* 232 */     check();
/* 233 */     Runnable wrapper = new RunnableWrapper(run, this.context, this.request.getCoyoteRequest());
/* 234 */     this.request.getCoyoteRequest().action(ActionCode.ASYNC_RUN, wrapper);
/*     */   }
/*     */   
/*     */   public void addListener(AsyncListener listener)
/*     */   {
/* 239 */     check();
/* 240 */     AsyncListenerWrapper wrapper = new AsyncListenerWrapper();
/* 241 */     wrapper.setListener(listener);
/* 242 */     this.listeners.add(wrapper);
/*     */   }
/*     */   
/*     */ 
/*     */   public void addListener(AsyncListener listener, ServletRequest servletRequest, ServletResponse servletResponse)
/*     */   {
/* 248 */     check();
/* 249 */     AsyncListenerWrapper wrapper = new AsyncListenerWrapper();
/* 250 */     wrapper.setListener(listener);
/* 251 */     wrapper.setServletRequest(servletRequest);
/* 252 */     wrapper.setServletResponse(servletResponse);
/* 253 */     this.listeners.add(wrapper);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends AsyncListener> T createListener(Class<T> clazz)
/*     */     throws ServletException
/*     */   {
/* 260 */     check();
/* 261 */     T listener = null;
/*     */     try {
/* 263 */       listener = (AsyncListener)getInstanceManager().newInstance(clazz.getName(), clazz.getClassLoader());
/*     */     }
/*     */     catch (InstantiationException|IllegalAccessException|NamingException|ClassNotFoundException e)
/*     */     {
/* 267 */       ServletException se = new ServletException(e);
/* 268 */       throw se;
/*     */     } catch (Exception e) {
/* 270 */       ExceptionUtils.handleThrowable(e.getCause());
/* 271 */       ServletException se = new ServletException(e);
/* 272 */       throw se;
/*     */     }
/* 274 */     return listener;
/*     */   }
/*     */   
/*     */   public void recycle() {
/* 278 */     if (log.isDebugEnabled()) {
/* 279 */       logDebug("recycle    ");
/*     */     }
/* 281 */     this.context = null;
/* 282 */     this.dispatch = null;
/* 283 */     this.event = null;
/* 284 */     this.hasOriginalRequestAndResponse = true;
/* 285 */     this.instanceManager = null;
/* 286 */     this.listeners.clear();
/* 287 */     this.request = null;
/* 288 */     clearServletRequestResponse();
/* 289 */     this.timeout = -1L;
/*     */   }
/*     */   
/*     */   private void clearServletRequestResponse() {
/* 293 */     this.servletRequest = null;
/* 294 */     this.servletResponse = null;
/*     */   }
/*     */   
/*     */   public boolean isStarted() {
/* 298 */     AtomicBoolean result = new AtomicBoolean(false);
/* 299 */     this.request.getCoyoteRequest().action(ActionCode.ASYNC_IS_STARTED, result);
/*     */     
/* 301 */     return result.get();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setStarted(Context context, ServletRequest request, ServletResponse response, boolean originalRequestResponse)
/*     */   {
/* 307 */     synchronized (this.asyncContextLock) {
/* 308 */       this.request.getCoyoteRequest().action(ActionCode.ASYNC_START, this);
/*     */       
/*     */ 
/* 311 */       this.context = context;
/* 312 */       this.servletRequest = request;
/* 313 */       this.servletResponse = response;
/* 314 */       this.hasOriginalRequestAndResponse = originalRequestResponse;
/* 315 */       this.event = new AsyncEvent(this, request, response);
/*     */       
/* 317 */       List<AsyncListenerWrapper> listenersCopy = new ArrayList();
/* 318 */       listenersCopy.addAll(this.listeners);
/* 319 */       this.listeners.clear();
/* 320 */       for (AsyncListenerWrapper listener : listenersCopy) {
/*     */         try {
/* 322 */           listener.fireOnStartAsync(this.event);
/*     */         } catch (Throwable t) {
/* 324 */           ExceptionUtils.handleThrowable(t);
/* 325 */           log.warn("onStartAsync() failed for listener of type [" + listener.getClass().getName() + "]", t);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean hasOriginalRequestAndResponse()
/*     */   {
/* 334 */     check();
/* 335 */     return this.hasOriginalRequestAndResponse;
/*     */   }
/*     */   
/*     */   protected void doInternalDispatch() throws ServletException, IOException {
/* 339 */     if (log.isDebugEnabled()) {
/* 340 */       logDebug("intDispatch");
/*     */     }
/*     */     try {
/* 343 */       Runnable runnable = this.dispatch;
/* 344 */       this.dispatch = null;
/* 345 */       runnable.run();
/* 346 */       if (!this.request.isAsync()) {
/* 347 */         fireOnComplete();
/*     */       }
/*     */     }
/*     */     catch (RuntimeException x) {
/* 351 */       if ((x.getCause() instanceof ServletException)) {
/* 352 */         throw ((ServletException)x.getCause());
/*     */       }
/* 354 */       if ((x.getCause() instanceof IOException)) {
/* 355 */         throw ((IOException)x.getCause());
/*     */       }
/* 357 */       throw new ServletException(x);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public long getTimeout()
/*     */   {
/* 364 */     check();
/* 365 */     return this.timeout;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setTimeout(long timeout)
/*     */   {
/* 371 */     check();
/* 372 */     this.timeout = timeout;
/* 373 */     this.request.getCoyoteRequest().action(ActionCode.ASYNC_SETTIMEOUT, Long.valueOf(timeout));
/*     */   }
/*     */   
/*     */ 
/*     */   public void setErrorState(Throwable t, boolean fireOnError)
/*     */   {
/* 379 */     if (t != null) this.request.setAttribute("javax.servlet.error.exception", t);
/* 380 */     this.request.getCoyoteRequest().action(ActionCode.ASYNC_ERROR, null);
/*     */     AsyncEvent errorEvent;
/* 382 */     if (fireOnError) {
/* 383 */       errorEvent = new AsyncEvent(this.event.getAsyncContext(), this.event.getSuppliedRequest(), this.event.getSuppliedResponse(), t);
/*     */       
/* 385 */       List<AsyncListenerWrapper> listenersCopy = new ArrayList();
/* 386 */       listenersCopy.addAll(this.listeners);
/* 387 */       for (AsyncListenerWrapper listener : listenersCopy) {
/*     */         try {
/* 389 */           listener.fireOnError(errorEvent);
/*     */         } catch (Throwable t2) {
/* 391 */           ExceptionUtils.handleThrowable(t);
/* 392 */           log.warn("onError() failed for listener of type [" + listener.getClass().getName() + "]", t2);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 399 */     AtomicBoolean result = new AtomicBoolean();
/* 400 */     this.request.getCoyoteRequest().action(ActionCode.ASYNC_IS_ERROR, result);
/* 401 */     if (result.get())
/*     */     {
/*     */ 
/* 404 */       if ((this.servletResponse instanceof HttpServletResponse)) {
/* 405 */         ((HttpServletResponse)this.servletResponse).setStatus(500);
/*     */       }
/*     */       
/*     */ 
/* 409 */       Host host = (Host)this.context.getParent();
/* 410 */       Valve stdHostValve = host.getPipeline().getBasic();
/* 411 */       if ((stdHostValve instanceof StandardHostValve)) {
/* 412 */         ((StandardHostValve)stdHostValve).throwable(this.request, this.request.getResponse(), t);
/*     */       }
/*     */       
/*     */ 
/* 416 */       this.request.getCoyoteRequest().action(ActionCode.ASYNC_IS_ERROR, result);
/*     */       
/* 418 */       if (result.get())
/*     */       {
/*     */ 
/* 421 */         complete();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void logDebug(String method)
/*     */   {
/* 432 */     StringBuilder uri = new StringBuilder();
/* 433 */     String rHashCode; String crHashCode; String rpHashCode; String stage; if (this.request == null) {
/* 434 */       String rHashCode = "null";
/* 435 */       String crHashCode = "null";
/* 436 */       String rpHashCode = "null";
/* 437 */       String stage = "-";
/* 438 */       uri.append("N/A");
/*     */     } else {
/* 440 */       rHashCode = Integer.toHexString(this.request.hashCode());
/* 441 */       org.apache.coyote.Request coyoteRequest = this.request.getCoyoteRequest();
/* 442 */       String stage; if (coyoteRequest == null) {
/* 443 */         String crHashCode = "null";
/* 444 */         String rpHashCode = "null";
/* 445 */         stage = "-";
/*     */       } else {
/* 447 */         crHashCode = Integer.toHexString(coyoteRequest.hashCode());
/* 448 */         RequestInfo rp = coyoteRequest.getRequestProcessor();
/* 449 */         String stage; if (rp == null) {
/* 450 */           String rpHashCode = "null";
/* 451 */           stage = "-";
/*     */         } else {
/* 453 */           rpHashCode = Integer.toHexString(rp.hashCode());
/* 454 */           stage = Integer.toString(rp.getStage());
/*     */         }
/*     */       }
/* 457 */       uri.append(this.request.getRequestURI());
/* 458 */       if (this.request.getQueryString() != null) {
/* 459 */         uri.append('?');
/* 460 */         uri.append(this.request.getQueryString());
/*     */       }
/*     */     }
/* 463 */     String threadName = Thread.currentThread().getName();
/* 464 */     int len = threadName.length();
/* 465 */     if (len > 20) {
/* 466 */       threadName = threadName.substring(len - 20, len);
/*     */     }
/* 468 */     String msg = String.format("Req: %1$8s  CReq: %2$8s  RP: %3$8s  Stage: %4$s  Thread: %5$20s  State: %6$20s  Method: %7$11s  URI: %8$s", new Object[] { rHashCode, crHashCode, rpHashCode, stage, threadName, "N/A", method, uri });
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 473 */     if (log.isTraceEnabled()) {
/* 474 */       log.trace(msg, new DebugException(null));
/*     */     } else {
/* 476 */       log.debug(msg);
/*     */     }
/*     */   }
/*     */   
/*     */   private InstanceManager getInstanceManager() {
/* 481 */     if (this.instanceManager == null) {
/* 482 */       if ((this.context instanceof StandardContext)) {
/* 483 */         this.instanceManager = ((StandardContext)this.context).getInstanceManager();
/*     */       } else {
/* 485 */         this.instanceManager = new DefaultInstanceManager(null, new HashMap(), this.context, getClass().getClassLoader());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 491 */     return this.instanceManager;
/*     */   }
/*     */   
/*     */   private void check() {
/* 495 */     if (this.request == null)
/*     */     {
/* 497 */       throw new IllegalStateException(sm.getString("asyncContextImpl.requestEnded"));
/*     */     }
/*     */   }
/*     */   
/*     */   private static class DebugException extends Exception
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */   }
/*     */   
/*     */   private static class RunnableWrapper implements Runnable
/*     */   {
/*     */     private final Runnable wrapped;
/*     */     private final Context context;
/*     */     private final org.apache.coyote.Request coyoteRequest;
/*     */     
/*     */     public RunnableWrapper(Runnable wrapped, Context ctxt, org.apache.coyote.Request coyoteRequest)
/*     */     {
/* 514 */       this.wrapped = wrapped;
/* 515 */       this.context = ctxt;
/* 516 */       this.coyoteRequest = coyoteRequest;
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/* 521 */       ClassLoader oldCL = this.context.bind(Globals.IS_SECURITY_ENABLED, null);
/*     */       try {
/* 523 */         this.wrapped.run();
/*     */       } finally {
/* 525 */         this.context.unbind(Globals.IS_SECURITY_ENABLED, oldCL);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 531 */       this.coyoteRequest.action(ActionCode.DISPATCH_EXECUTE, null);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class AsyncRunnable
/*     */     implements Runnable
/*     */   {
/*     */     private final AsyncDispatcher applicationDispatcher;
/*     */     private final org.apache.catalina.connector.Request request;
/*     */     private final ServletRequest servletRequest;
/*     */     private final ServletResponse servletResponse;
/*     */     
/*     */     public AsyncRunnable(org.apache.catalina.connector.Request request, AsyncDispatcher applicationDispatcher, ServletRequest servletRequest, ServletResponse servletResponse)
/*     */     {
/* 545 */       this.request = request;
/* 546 */       this.applicationDispatcher = applicationDispatcher;
/* 547 */       this.servletRequest = servletRequest;
/* 548 */       this.servletResponse = servletResponse;
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/* 553 */       this.request.getCoyoteRequest().action(ActionCode.ASYNC_DISPATCHED, null);
/*     */       try {
/* 555 */         this.applicationDispatcher.dispatch(this.servletRequest, this.servletResponse);
/*     */       }
/*     */       catch (Exception x) {
/* 558 */         throw new RuntimeException(x);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\core\AsyncContextImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */