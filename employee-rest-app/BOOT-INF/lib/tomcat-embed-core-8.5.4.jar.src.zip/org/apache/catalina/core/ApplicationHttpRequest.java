/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import javax.servlet.DispatcherType;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Manager;
/*     */ import org.apache.catalina.Session;
/*     */ import org.apache.catalina.servlet4preview.http.HttpServletRequestWrapper;
/*     */ import org.apache.catalina.servlet4preview.http.Mapping;
/*     */ import org.apache.catalina.servlet4preview.http.PushBuilder;
/*     */ import org.apache.catalina.util.ParameterMap;
/*     */ import org.apache.tomcat.util.buf.B2CConverter;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.http.Parameters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ApplicationHttpRequest
/*     */   extends HttpServletRequestWrapper
/*     */ {
/*  73 */   protected static final String[] specials = { "javax.servlet.include.request_uri", "javax.servlet.include.context_path", "javax.servlet.include.servlet_path", "javax.servlet.include.path_info", "javax.servlet.include.query_string", "javax.servlet.include.mapping", "javax.servlet.forward.request_uri", "javax.servlet.forward.context_path", "javax.servlet.forward.servlet_path", "javax.servlet.forward.path_info", "javax.servlet.forward.query_string", "javax.servlet.forward.mapping" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final Context context;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ApplicationHttpRequest(javax.servlet.http.HttpServletRequest request, Context context, boolean crossContext)
/*     */   {
/* 102 */     super(request);
/* 103 */     this.context = context;
/* 104 */     this.crossContext = crossContext;
/* 105 */     setRequest(request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 122 */   protected String contextPath = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final boolean crossContext;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 135 */   protected DispatcherType dispatcherType = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 142 */   protected Map<String, String[]> parameters = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 148 */   private boolean parsedParams = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 154 */   protected String pathInfo = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 160 */   private String queryParamString = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 166 */   protected String queryString = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 172 */   protected Object requestDispatcherPath = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 178 */   protected String requestURI = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 184 */   protected String servletPath = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 190 */   private Mapping mapping = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 196 */   protected Session session = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 202 */   protected final Object[] specialAttributes = new Object[specials.length];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletContext getServletContext()
/*     */   {
/* 209 */     if (this.context == null) {
/* 210 */       return null;
/*     */     }
/* 212 */     return this.context.getServletContext();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getAttribute(String name)
/*     */   {
/* 224 */     if (name.equals("org.apache.catalina.core.DISPATCHER_TYPE"))
/* 225 */       return this.dispatcherType;
/* 226 */     if (name.equals("org.apache.catalina.core.DISPATCHER_REQUEST_PATH")) {
/* 227 */       if (this.requestDispatcherPath != null) {
/* 228 */         return this.requestDispatcherPath.toString();
/*     */       }
/* 230 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 234 */     int pos = getSpecial(name);
/* 235 */     if (pos == -1) {
/* 236 */       return getRequest().getAttribute(name);
/*     */     }
/* 238 */     if ((this.specialAttributes[pos] == null) && (this.specialAttributes[5] == null) && (pos >= 5))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 243 */       return getRequest().getAttribute(name);
/*     */     }
/* 245 */     return this.specialAttributes[pos];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Enumeration<String> getAttributeNames()
/*     */   {
/* 258 */     return new AttributeNamesEnumerator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeAttribute(String name)
/*     */   {
/* 271 */     if (!removeSpecial(name)) {
/* 272 */       getRequest().removeAttribute(name);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAttribute(String name, Object value)
/*     */   {
/* 287 */     if (name.equals("org.apache.catalina.core.DISPATCHER_TYPE")) {
/* 288 */       this.dispatcherType = ((DispatcherType)value);
/* 289 */       return; }
/* 290 */     if (name.equals("org.apache.catalina.core.DISPATCHER_REQUEST_PATH")) {
/* 291 */       this.requestDispatcherPath = value;
/* 292 */       return;
/*     */     }
/*     */     
/* 295 */     if (!setSpecial(name, value)) {
/* 296 */       getRequest().setAttribute(name, value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RequestDispatcher getRequestDispatcher(String path)
/*     */   {
/* 311 */     if (this.context == null) {
/* 312 */       return null;
/*     */     }
/*     */     
/* 315 */     if (path == null)
/* 316 */       return null;
/* 317 */     if (path.startsWith("/")) {
/* 318 */       return this.context.getServletContext().getRequestDispatcher(path);
/*     */     }
/*     */     
/* 321 */     String servletPath = (String)getAttribute("javax.servlet.include.servlet_path");
/*     */     
/* 323 */     if (servletPath == null) {
/* 324 */       servletPath = getServletPath();
/*     */     }
/*     */     
/* 327 */     String pathInfo = getPathInfo();
/* 328 */     String requestPath = null;
/*     */     
/* 330 */     if (pathInfo == null) {
/* 331 */       requestPath = servletPath;
/*     */     } else {
/* 333 */       requestPath = servletPath + pathInfo;
/*     */     }
/*     */     
/* 336 */     int pos = requestPath.lastIndexOf('/');
/* 337 */     String relative = null;
/* 338 */     if (pos >= 0) {
/* 339 */       relative = requestPath.substring(0, pos + 1) + path;
/*     */     } else {
/* 341 */       relative = requestPath + path;
/*     */     }
/*     */     
/* 344 */     return this.context.getServletContext().getRequestDispatcher(relative);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DispatcherType getDispatcherType()
/*     */   {
/* 355 */     return this.dispatcherType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContextPath()
/*     */   {
/* 369 */     return this.contextPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getParameter(String name)
/*     */   {
/* 382 */     parseParameters();
/*     */     
/* 384 */     String[] value = (String[])this.parameters.get(name);
/* 385 */     if (value == null) {
/* 386 */       return null;
/*     */     }
/* 388 */     return value[0];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, String[]> getParameterMap()
/*     */   {
/* 400 */     parseParameters();
/* 401 */     return this.parameters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Enumeration<String> getParameterNames()
/*     */   {
/* 413 */     parseParameters();
/* 414 */     return Collections.enumeration(this.parameters.keySet());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getParameterValues(String name)
/*     */   {
/* 427 */     parseParameters();
/* 428 */     return (String[])this.parameters.get(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPathInfo()
/*     */   {
/* 439 */     return this.pathInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPathTranslated()
/*     */   {
/* 450 */     if ((getPathInfo() == null) || (getServletContext() == null)) {
/* 451 */       return null;
/*     */     }
/*     */     
/* 454 */     return getServletContext().getRealPath(getPathInfo());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getQueryString()
/*     */   {
/* 465 */     return this.queryString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRequestURI()
/*     */   {
/* 477 */     return this.requestURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringBuffer getRequestURL()
/*     */   {
/* 489 */     StringBuffer url = new StringBuffer();
/* 490 */     String scheme = getScheme();
/* 491 */     int port = getServerPort();
/* 492 */     if (port < 0) {
/* 493 */       port = 80;
/*     */     }
/* 495 */     url.append(scheme);
/* 496 */     url.append("://");
/* 497 */     url.append(getServerName());
/* 498 */     if (((scheme.equals("http")) && (port != 80)) || ((scheme.equals("https")) && (port != 443)))
/*     */     {
/* 500 */       url.append(':');
/* 501 */       url.append(port);
/*     */     }
/* 503 */     url.append(getRequestURI());
/*     */     
/* 505 */     return url;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getServletPath()
/*     */   {
/* 517 */     return this.servletPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Mapping getMapping()
/*     */   {
/* 524 */     return this.mapping;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpSession getSession()
/*     */   {
/* 534 */     return getSession(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpSession getSession(boolean create)
/*     */   {
/* 547 */     if (this.crossContext)
/*     */     {
/*     */ 
/* 550 */       if (this.context == null) {
/* 551 */         return null;
/*     */       }
/*     */       
/* 554 */       if ((this.session != null) && (this.session.isValid())) {
/* 555 */         return this.session.getSession();
/*     */       }
/*     */       
/* 558 */       HttpSession other = super.getSession(false);
/* 559 */       if ((create) && (other == null))
/*     */       {
/*     */ 
/*     */ 
/* 563 */         other = super.getSession(true);
/*     */       }
/* 565 */       if (other != null) {
/* 566 */         Session localSession = null;
/*     */         try {
/* 568 */           localSession = this.context.getManager().findSession(other.getId());
/*     */           
/* 570 */           if ((localSession != null) && (!localSession.isValid())) {
/* 571 */             localSession = null;
/*     */           }
/*     */         }
/*     */         catch (IOException localIOException) {}
/*     */         
/* 576 */         if ((localSession == null) && (create)) {
/* 577 */           localSession = this.context.getManager().createSession(other.getId());
/*     */         }
/*     */         
/* 580 */         if (localSession != null) {
/* 581 */           localSession.access();
/* 582 */           this.session = localSession;
/* 583 */           return this.session.getSession();
/*     */         }
/*     */       }
/* 586 */       return null;
/*     */     }
/*     */     
/* 589 */     return super.getSession(create);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRequestedSessionIdValid()
/*     */   {
/* 605 */     if (this.crossContext)
/*     */     {
/* 607 */       String requestedSessionId = getRequestedSessionId();
/* 608 */       if (requestedSessionId == null)
/* 609 */         return false;
/* 610 */       if (this.context == null)
/* 611 */         return false;
/* 612 */       Manager manager = this.context.getManager();
/* 613 */       if (manager == null)
/* 614 */         return false;
/* 615 */       Session session = null;
/*     */       try {
/* 617 */         session = manager.findSession(requestedSessionId);
/*     */       }
/*     */       catch (IOException localIOException) {}
/*     */       
/* 621 */       if ((session != null) && (session.isValid())) {
/* 622 */         return true;
/*     */       }
/* 624 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 628 */     return super.isRequestedSessionIdValid();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PushBuilder getPushBuilder()
/*     */   {
/* 635 */     return new ApplicationPushBuilder(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void recycle()
/*     */   {
/* 645 */     if (this.session != null) {
/* 646 */       this.session.endAccess();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setContextPath(String contextPath)
/*     */   {
/* 658 */     this.contextPath = contextPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setPathInfo(String pathInfo)
/*     */   {
/* 670 */     this.pathInfo = pathInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setQueryString(String queryString)
/*     */   {
/* 682 */     this.queryString = queryString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setRequest(javax.servlet.http.HttpServletRequest request)
/*     */   {
/* 694 */     super.setRequest(request);
/*     */     
/*     */ 
/* 697 */     this.dispatcherType = ((DispatcherType)request.getAttribute("org.apache.catalina.core.DISPATCHER_TYPE"));
/* 698 */     this.requestDispatcherPath = request.getAttribute("org.apache.catalina.core.DISPATCHER_REQUEST_PATH");
/*     */     
/*     */ 
/* 701 */     this.contextPath = request.getContextPath();
/* 702 */     this.pathInfo = request.getPathInfo();
/* 703 */     this.queryString = request.getQueryString();
/* 704 */     this.requestURI = request.getRequestURI();
/* 705 */     this.servletPath = request.getServletPath();
/* 706 */     if ((request instanceof org.apache.catalina.servlet4preview.http.HttpServletRequest)) {
/* 707 */       this.mapping = ((org.apache.catalina.servlet4preview.http.HttpServletRequest)request).getMapping();
/*     */     } else {
/* 709 */       this.mapping = new ApplicationMapping(null).getMapping();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setRequestURI(String requestURI)
/*     */   {
/* 721 */     this.requestURI = requestURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setServletPath(String servletPath)
/*     */   {
/* 733 */     this.servletPath = servletPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void parseParameters()
/*     */   {
/* 746 */     if (this.parsedParams) {
/* 747 */       return;
/*     */     }
/*     */     
/* 750 */     this.parameters = new ParameterMap();
/* 751 */     this.parameters.putAll(getRequest().getParameterMap());
/* 752 */     mergeParameters();
/* 753 */     ((ParameterMap)this.parameters).setLocked(true);
/* 754 */     this.parsedParams = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setQueryParams(String queryString)
/*     */   {
/* 765 */     this.queryParamString = queryString;
/*     */   }
/*     */   
/*     */   void setMapping(Mapping mapping)
/*     */   {
/* 770 */     this.mapping = mapping;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isSpecial(String name)
/*     */   {
/* 784 */     for (int i = 0; i < specials.length; i++) {
/* 785 */       if (specials[i].equals(name))
/* 786 */         return true;
/*     */     }
/* 788 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getSpecial(String name)
/*     */   {
/* 800 */     for (int i = 0; i < specials.length; i++) {
/* 801 */       if (specials[i].equals(name)) {
/* 802 */         return i;
/*     */       }
/*     */     }
/* 805 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean setSpecial(String name, Object value)
/*     */   {
/* 815 */     for (int i = 0; i < specials.length; i++) {
/* 816 */       if (specials[i].equals(name)) {
/* 817 */         this.specialAttributes[i] = value;
/* 818 */         return true;
/*     */       }
/*     */     }
/* 821 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean removeSpecial(String name)
/*     */   {
/* 831 */     for (int i = 0; i < specials.length; i++) {
/* 832 */       if (specials[i].equals(name)) {
/* 833 */         this.specialAttributes[i] = null;
/* 834 */         return true;
/*     */       }
/*     */     }
/* 837 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String[] mergeValues(String[] values1, String[] values2)
/*     */   {
/* 849 */     ArrayList<Object> results = new ArrayList();
/*     */     
/* 851 */     if (values1 != null)
/*     */     {
/*     */ 
/* 854 */       for (String value : values1) {
/* 855 */         results.add(value);
/*     */       }
/*     */     }
/*     */     
/* 859 */     if (values2 != null)
/*     */     {
/*     */ 
/* 862 */       for (String value : values2) {
/* 863 */         results.add(value);
/*     */       }
/*     */     }
/*     */     
/* 867 */     String[] values = new String[results.size()];
/* 868 */     return (String[])results.toArray(values);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void mergeParameters()
/*     */   {
/* 883 */     if ((this.queryParamString == null) || (this.queryParamString.length() < 1)) {
/* 884 */       return;
/*     */     }
/*     */     
/* 887 */     Parameters paramParser = new Parameters();
/* 888 */     MessageBytes queryMB = MessageBytes.newInstance();
/* 889 */     queryMB.setString(this.queryParamString);
/*     */     
/* 891 */     String encoding = getCharacterEncoding();
/*     */     
/*     */ 
/* 894 */     if (encoding != null) {
/*     */       try {
/* 896 */         queryMB.setCharset(B2CConverter.getCharset(encoding));
/*     */       }
/*     */       catch (UnsupportedEncodingException localUnsupportedEncodingException) {}
/*     */     }
/*     */     
/*     */ 
/* 902 */     paramParser.setQuery(queryMB);
/* 903 */     paramParser.setQueryStringEncoding(encoding);
/* 904 */     paramParser.handleQueryParameters();
/*     */     
/*     */ 
/* 907 */     Enumeration<String> dispParamNames = paramParser.getParameterNames();
/* 908 */     while (dispParamNames.hasMoreElements()) {
/* 909 */       String dispParamName = (String)dispParamNames.nextElement();
/* 910 */       String[] dispParamValues = paramParser.getParameterValues(dispParamName);
/* 911 */       String[] originalValues = (String[])this.parameters.get(dispParamName);
/* 912 */       if (originalValues == null) {
/* 913 */         this.parameters.put(dispParamName, dispParamValues);
/*     */       }
/*     */       else {
/* 916 */         this.parameters.put(dispParamName, mergeValues(dispParamValues, originalValues));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected class AttributeNamesEnumerator
/*     */     implements Enumeration<String>
/*     */   {
/* 930 */     protected int pos = -1;
/*     */     protected final int last;
/*     */     protected final Enumeration<String> parentEnumeration;
/* 933 */     protected String next = null;
/*     */     
/*     */     public AttributeNamesEnumerator() {
/* 936 */       int last = -1;
/* 937 */       this.parentEnumeration = ApplicationHttpRequest.this.getRequest().getAttributeNames();
/* 938 */       for (int i = ApplicationHttpRequest.this.specialAttributes.length - 1; i >= 0; i--) {
/* 939 */         if (ApplicationHttpRequest.this.getAttribute(ApplicationHttpRequest.specials[i]) != null) {
/* 940 */           last = i;
/* 941 */           break;
/*     */         }
/*     */       }
/* 944 */       this.last = last;
/*     */     }
/*     */     
/*     */     public boolean hasMoreElements()
/*     */     {
/* 949 */       return (this.pos != this.last) || (this.next != null) || ((this.next = findNext()) != null);
/*     */     }
/*     */     
/*     */ 
/*     */     public String nextElement()
/*     */     {
/* 955 */       if (this.pos != this.last) {
/* 956 */         for (int i = this.pos + 1; i <= this.last; i++) {
/* 957 */           if (ApplicationHttpRequest.this.getAttribute(ApplicationHttpRequest.specials[i]) != null) {
/* 958 */             this.pos = i;
/* 959 */             return ApplicationHttpRequest.specials[i];
/*     */           }
/*     */         }
/*     */       }
/* 963 */       String result = this.next;
/* 964 */       if (this.next != null) {
/* 965 */         this.next = findNext();
/*     */       } else {
/* 967 */         throw new NoSuchElementException();
/*     */       }
/* 969 */       return result;
/*     */     }
/*     */     
/*     */     protected String findNext() {
/* 973 */       String result = null;
/* 974 */       while ((result == null) && (this.parentEnumeration.hasMoreElements())) {
/* 975 */         String current = (String)this.parentEnumeration.nextElement();
/* 976 */         if (!ApplicationHttpRequest.this.isSpecial(current)) {
/* 977 */           result = current;
/*     */         }
/*     */       }
/* 980 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\core\ApplicationHttpRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */