package org.apache.catalina.core;

public class Constants
{
  public static final String Package = "org.apache.catalina.core";
  public static final int MAJOR_VERSION = 3;
  public static final int MINOR_VERSION = 1;
  public static final String JSP_SERVLET_CLASS = "org.apache.jasper.servlet.JspServlet";
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\core\Constants.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */