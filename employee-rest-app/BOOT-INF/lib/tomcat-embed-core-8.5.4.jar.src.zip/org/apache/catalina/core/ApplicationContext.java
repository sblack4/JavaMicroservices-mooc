/*      */ package org.apache.catalina.core;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.EnumSet;
/*      */ import java.util.Enumeration;
/*      */ import java.util.EventListener;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import javax.naming.NamingException;
/*      */ import javax.servlet.Filter;
/*      */ import javax.servlet.FilterRegistration;
/*      */ import javax.servlet.FilterRegistration.Dynamic;
/*      */ import javax.servlet.RequestDispatcher;
/*      */ import javax.servlet.Servlet;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletContextAttributeEvent;
/*      */ import javax.servlet.ServletContextAttributeListener;
/*      */ import javax.servlet.ServletContextListener;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletRegistration;
/*      */ import javax.servlet.ServletRegistration.Dynamic;
/*      */ import javax.servlet.ServletRequestAttributeListener;
/*      */ import javax.servlet.ServletRequestListener;
/*      */ import javax.servlet.SessionCookieConfig;
/*      */ import javax.servlet.SessionTrackingMode;
/*      */ import javax.servlet.descriptor.JspConfigDescriptor;
/*      */ import javax.servlet.http.HttpSessionAttributeListener;
/*      */ import javax.servlet.http.HttpSessionIdListener;
/*      */ import javax.servlet.http.HttpSessionListener;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Loader;
/*      */ import org.apache.catalina.Service;
/*      */ import org.apache.catalina.WebResource;
/*      */ import org.apache.catalina.WebResourceRoot;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.connector.Connector;
/*      */ import org.apache.catalina.mapper.Mapper;
/*      */ import org.apache.catalina.mapper.MappingData;
/*      */ import org.apache.catalina.servlet4preview.http.Mapping;
/*      */ import org.apache.catalina.util.ServerInfo;
/*      */ import org.apache.catalina.util.URLEncoder;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.tomcat.InstanceManager;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.buf.CharChunk;
/*      */ import org.apache.tomcat.util.buf.MessageBytes;
/*      */ import org.apache.tomcat.util.descriptor.web.FilterDef;
/*      */ import org.apache.tomcat.util.http.RequestUtil;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ApplicationContext
/*      */   implements ServletContext
/*      */ {
/*   94 */   protected static final boolean STRICT_SERVLET_COMPLIANCE = Globals.STRICT_SERVLET_COMPLIANCE;
/*      */   
/*   96 */   static { String requireSlash = System.getProperty("org.apache.catalina.core.ApplicationContext.GET_RESOURCE_REQUIRE_SLASH");
/*      */     
/*   98 */     if (requireSlash == null) {
/*   99 */       GET_RESOURCE_REQUIRE_SLASH = STRICT_SERVLET_COMPLIANCE;
/*      */     } else {
/*  101 */       GET_RESOURCE_REQUIRE_SLASH = Boolean.parseBoolean(requireSlash);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final boolean GET_RESOURCE_REQUIRE_SLASH;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ApplicationContext(StandardContext context)
/*      */   {
/*  116 */     this.context = context;
/*  117 */     this.service = ((Engine)context.getParent().getParent()).getService();
/*  118 */     this.sessionCookieConfig = new ApplicationSessionCookieConfig(context);
/*      */     
/*      */ 
/*  121 */     populateSessionTrackingModes();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  131 */   protected Map<String, Object> attributes = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  137 */   private final Map<String, String> readOnlyAttributes = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final StandardContext context;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final Service service;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  155 */   private static final List<String> emptyString = Collections.emptyList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  161 */   private static final List<Servlet> emptyServlet = Collections.emptyList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  167 */   private final ServletContext facade = new ApplicationContextFacade(this);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  173 */   private final ConcurrentMap<String, String> parameters = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  179 */   private static final StringManager sm = StringManager.getManager("org.apache.catalina.core");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  186 */   private final ThreadLocal<DispatchData> dispatchData = new ThreadLocal();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private SessionCookieConfig sessionCookieConfig;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  197 */   private Set<SessionTrackingMode> sessionTrackingModes = null;
/*  198 */   private Set<SessionTrackingMode> defaultSessionTrackingModes = null;
/*  199 */   private Set<SessionTrackingMode> supportedSessionTrackingModes = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  206 */   private boolean newServletContextListenerAllowed = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getAttribute(String name)
/*      */   {
/*  213 */     return this.attributes.get(name);
/*      */   }
/*      */   
/*      */ 
/*      */   public Enumeration<String> getAttributeNames()
/*      */   {
/*  219 */     Set<String> names = new HashSet();
/*  220 */     names.addAll(this.attributes.keySet());
/*  221 */     return Collections.enumeration(names);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ServletContext getContext(String uri)
/*      */   {
/*  229 */     if ((uri == null) || (!uri.startsWith("/"))) {
/*  230 */       return null;
/*      */     }
/*      */     
/*  233 */     Context child = null;
/*      */     try
/*      */     {
/*  236 */       Container host = this.context.getParent();
/*  237 */       child = (Context)host.findChild(uri);
/*      */       
/*      */ 
/*  240 */       if ((child != null) && (!child.getState().isAvailable())) {
/*  241 */         child = null;
/*      */       }
/*      */       
/*      */ 
/*  245 */       if (child == null) {
/*  246 */         int i = uri.indexOf("##");
/*  247 */         if (i > -1) {
/*  248 */           uri = uri.substring(0, i);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  254 */         MessageBytes hostMB = MessageBytes.newInstance();
/*  255 */         hostMB.setString(host.getName());
/*      */         
/*  257 */         MessageBytes pathMB = MessageBytes.newInstance();
/*  258 */         pathMB.setString(uri);
/*      */         
/*  260 */         MappingData mappingData = new MappingData();
/*  261 */         ((Engine)host.getParent()).getService().getMapper().map(hostMB, pathMB, null, mappingData);
/*  262 */         child = mappingData.context;
/*      */       }
/*      */     } catch (Throwable t) {
/*  265 */       ExceptionUtils.handleThrowable(t);
/*  266 */       return null;
/*      */     }
/*      */     
/*  269 */     if (child == null) {
/*  270 */       return null;
/*      */     }
/*      */     
/*  273 */     if (this.context.getCrossContext())
/*      */     {
/*  275 */       return child.getServletContext(); }
/*  276 */     if (child == this.context)
/*      */     {
/*  278 */       return this.context.getServletContext();
/*      */     }
/*      */     
/*  281 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getContextPath()
/*      */   {
/*  288 */     return this.context.getPath();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getInitParameter(String name)
/*      */   {
/*  296 */     if (("org.apache.jasper.XML_VALIDATE_TLD".equals(name)) && (this.context.getTldValidation()))
/*      */     {
/*  298 */       return "true";
/*      */     }
/*  300 */     if (("org.apache.jasper.XML_BLOCK_EXTERNAL".equals(name)) && 
/*  301 */       (!this.context.getXmlBlockExternal()))
/*      */     {
/*  303 */       return "false";
/*      */     }
/*      */     
/*  306 */     return (String)this.parameters.get(name);
/*      */   }
/*      */   
/*      */ 
/*      */   public Enumeration<String> getInitParameterNames()
/*      */   {
/*  312 */     Set<String> names = new HashSet();
/*  313 */     names.addAll(this.parameters.keySet());
/*      */     
/*      */ 
/*  316 */     if (this.context.getTldValidation()) {
/*  317 */       names.add("org.apache.jasper.XML_VALIDATE_TLD");
/*      */     }
/*  319 */     if (!this.context.getXmlBlockExternal()) {
/*  320 */       names.add("org.apache.jasper.XML_BLOCK_EXTERNAL");
/*      */     }
/*  322 */     return Collections.enumeration(names);
/*      */   }
/*      */   
/*      */ 
/*      */   public int getMajorVersion()
/*      */   {
/*  328 */     return 3;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getMinorVersion()
/*      */   {
/*  334 */     return 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getMimeType(String file)
/*      */   {
/*  347 */     if (file == null)
/*  348 */       return null;
/*  349 */     int period = file.lastIndexOf('.');
/*  350 */     if (period < 0)
/*  351 */       return null;
/*  352 */     String extension = file.substring(period + 1);
/*  353 */     if (extension.length() < 1)
/*  354 */       return null;
/*  355 */     return this.context.findMimeMapping(extension);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RequestDispatcher getNamedDispatcher(String name)
/*      */   {
/*  370 */     if (name == null) {
/*  371 */       return null;
/*      */     }
/*      */     
/*  374 */     Wrapper wrapper = (Wrapper)this.context.findChild(name);
/*  375 */     if (wrapper == null) {
/*  376 */       return null;
/*      */     }
/*  378 */     return new ApplicationDispatcher(wrapper, null, null, null, null, null, name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getRealPath(String path)
/*      */   {
/*  385 */     String validatedPath = validateResourcePath(path, true);
/*  386 */     return this.context.getRealPath(validatedPath);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public RequestDispatcher getRequestDispatcher(String path)
/*      */   {
/*  394 */     if (path == null)
/*  395 */       return null;
/*  396 */     if (!path.startsWith("/")) {
/*  397 */       throw new IllegalArgumentException(sm.getString("applicationContext.requestDispatcher.iae", new Object[] { path }));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  402 */     String queryString = null;
/*  403 */     String normalizedPath = path;
/*  404 */     int pos = normalizedPath.indexOf('?');
/*  405 */     if (pos >= 0) {
/*  406 */       queryString = normalizedPath.substring(pos + 1);
/*  407 */       normalizedPath = normalizedPath.substring(0, pos);
/*      */     }
/*      */     
/*  410 */     normalizedPath = RequestUtil.normalize(normalizedPath);
/*  411 */     if (normalizedPath == null) {
/*  412 */       return null;
/*      */     }
/*  414 */     pos = normalizedPath.length();
/*      */     
/*      */ 
/*  417 */     DispatchData dd = (DispatchData)this.dispatchData.get();
/*  418 */     if (dd == null) {
/*  419 */       dd = new DispatchData();
/*  420 */       this.dispatchData.set(dd);
/*      */     }
/*      */     
/*  423 */     MessageBytes uriMB = dd.uriMB;
/*  424 */     uriMB.recycle();
/*      */     
/*      */ 
/*  427 */     MappingData mappingData = dd.mappingData;
/*      */     
/*      */ 
/*  430 */     CharChunk uriCC = uriMB.getCharChunk();
/*      */     try {
/*  432 */       uriCC.append(this.context.getPath(), 0, this.context.getPath().length());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  437 */       int semicolon = normalizedPath.indexOf(';');
/*  438 */       if ((pos >= 0) && (semicolon > pos)) {
/*  439 */         semicolon = -1;
/*      */       }
/*  441 */       uriCC.append(normalizedPath, 0, semicolon > 0 ? semicolon : pos);
/*  442 */       this.service.getMapper().map(this.context, uriMB, mappingData);
/*  443 */       if (mappingData.wrapper == null) {
/*  444 */         return null;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  451 */       if (semicolon > 0) {
/*  452 */         uriCC.append(normalizedPath, semicolon, pos - semicolon);
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/*  456 */       log(sm.getString("applicationContext.mapping.error"), e);
/*  457 */       return null;
/*      */     }
/*      */     
/*  460 */     Wrapper wrapper = mappingData.wrapper;
/*  461 */     String wrapperPath = mappingData.wrapperPath.toString();
/*  462 */     String pathInfo = mappingData.pathInfo.toString();
/*  463 */     Mapping mapping = new ApplicationMapping(mappingData).getMapping();
/*      */     
/*  465 */     mappingData.recycle();
/*      */     
/*  467 */     String encodedUri = URLEncoder.DEFAULT.encode(uriCC.toString());
/*      */     
/*      */ 
/*  470 */     return new ApplicationDispatcher(wrapper, encodedUri, wrapperPath, pathInfo, queryString, mapping, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public URL getResource(String path)
/*      */     throws MalformedURLException
/*      */   {
/*  478 */     String validatedPath = validateResourcePath(path, false);
/*      */     
/*  480 */     if (validatedPath == null) {
/*  481 */       throw new MalformedURLException(sm.getString("applicationContext.requestDispatcher.iae", new Object[] { path }));
/*      */     }
/*      */     
/*      */ 
/*  485 */     WebResourceRoot resources = this.context.getResources();
/*  486 */     if (resources != null) {
/*  487 */       return resources.getResource(validatedPath).getURL();
/*      */     }
/*      */     
/*  490 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public InputStream getResourceAsStream(String path)
/*      */   {
/*  497 */     String validatedPath = validateResourcePath(path, false);
/*      */     
/*  499 */     if (validatedPath == null) {
/*  500 */       return null;
/*      */     }
/*      */     
/*  503 */     WebResourceRoot resources = this.context.getResources();
/*  504 */     if (resources != null) {
/*  505 */       return resources.getResource(validatedPath).getInputStream();
/*      */     }
/*      */     
/*  508 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String validateResourcePath(String path, boolean allowEmptyPath)
/*      */   {
/*  517 */     if (path == null) {
/*  518 */       return null;
/*      */     }
/*      */     
/*  521 */     if ((path.length() == 0) && (allowEmptyPath)) {
/*  522 */       return path;
/*      */     }
/*      */     
/*  525 */     if (!path.startsWith("/")) {
/*  526 */       if (GET_RESOURCE_REQUIRE_SLASH) {
/*  527 */         return null;
/*      */       }
/*  529 */       return "/" + path;
/*      */     }
/*      */     
/*      */ 
/*  533 */     return path;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<String> getResourcePaths(String path)
/*      */   {
/*  541 */     if (path == null) {
/*  542 */       return null;
/*      */     }
/*  544 */     if (!path.startsWith("/")) {
/*  545 */       throw new IllegalArgumentException(sm.getString("applicationContext.resourcePaths.iae", new Object[] { path }));
/*      */     }
/*      */     
/*      */ 
/*  549 */     WebResourceRoot resources = this.context.getResources();
/*  550 */     if (resources != null) {
/*  551 */       return resources.listWebAppPaths(path);
/*      */     }
/*      */     
/*  554 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getServerInfo()
/*      */   {
/*  560 */     return ServerInfo.getServerInfo();
/*      */   }
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public Servlet getServlet(String name)
/*      */   {
/*  567 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getServletContextName()
/*      */   {
/*  573 */     return this.context.getDisplayName();
/*      */   }
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public Enumeration<String> getServletNames()
/*      */   {
/*  580 */     return Collections.enumeration(emptyString);
/*      */   }
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public Enumeration<Servlet> getServlets()
/*      */   {
/*  587 */     return Collections.enumeration(emptyServlet);
/*      */   }
/*      */   
/*      */ 
/*      */   public void log(String message)
/*      */   {
/*  593 */     this.context.getLogger().info(message);
/*      */   }
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public void log(Exception exception, String message)
/*      */   {
/*  600 */     this.context.getLogger().error(message, exception);
/*      */   }
/*      */   
/*      */ 
/*      */   public void log(String message, Throwable throwable)
/*      */   {
/*  606 */     this.context.getLogger().error(message, throwable);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void removeAttribute(String name)
/*      */   {
/*  613 */     Object value = null;
/*      */     
/*      */ 
/*      */ 
/*  617 */     if (this.readOnlyAttributes.containsKey(name)) {
/*  618 */       return;
/*      */     }
/*  620 */     value = this.attributes.remove(name);
/*  621 */     if (value == null) {
/*  622 */       return;
/*      */     }
/*      */     
/*      */ 
/*  626 */     Object[] listeners = this.context.getApplicationEventListeners();
/*  627 */     if ((listeners == null) || (listeners.length == 0))
/*  628 */       return;
/*  629 */     ServletContextAttributeEvent event = new ServletContextAttributeEvent(this.context.getServletContext(), name, value);
/*      */     
/*      */ 
/*  632 */     for (int i = 0; i < listeners.length; i++) {
/*  633 */       if ((listeners[i] instanceof ServletContextAttributeListener))
/*      */       {
/*  635 */         ServletContextAttributeListener listener = (ServletContextAttributeListener)listeners[i];
/*      */         try
/*      */         {
/*  638 */           this.context.fireContainerEvent("beforeContextAttributeRemoved", listener);
/*      */           
/*  640 */           listener.attributeRemoved(event);
/*  641 */           this.context.fireContainerEvent("afterContextAttributeRemoved", listener);
/*      */         }
/*      */         catch (Throwable t) {
/*  644 */           ExceptionUtils.handleThrowable(t);
/*  645 */           this.context.fireContainerEvent("afterContextAttributeRemoved", listener);
/*      */           
/*      */ 
/*  648 */           log(sm.getString("applicationContext.attributeEvent"), t);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setAttribute(String name, Object value)
/*      */   {
/*  657 */     if (name == null) {
/*  658 */       throw new IllegalArgumentException(sm.getString("applicationContext.setAttribute.namenull"));
/*      */     }
/*      */     
/*      */ 
/*  662 */     if (value == null) {
/*  663 */       removeAttribute(name);
/*  664 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  669 */     if (this.readOnlyAttributes.containsKey(name)) {
/*  670 */       return;
/*      */     }
/*  672 */     Object oldValue = this.attributes.put(name, value);
/*  673 */     boolean replaced = oldValue != null;
/*      */     
/*      */ 
/*  676 */     Object[] listeners = this.context.getApplicationEventListeners();
/*  677 */     if ((listeners == null) || (listeners.length == 0))
/*  678 */       return;
/*  679 */     ServletContextAttributeEvent event = null;
/*  680 */     if (replaced) {
/*  681 */       event = new ServletContextAttributeEvent(this.context.getServletContext(), name, oldValue);
/*      */     }
/*      */     else
/*      */     {
/*  685 */       event = new ServletContextAttributeEvent(this.context.getServletContext(), name, value);
/*      */     }
/*      */     
/*      */ 
/*  689 */     for (int i = 0; i < listeners.length; i++) {
/*  690 */       if ((listeners[i] instanceof ServletContextAttributeListener))
/*      */       {
/*  692 */         ServletContextAttributeListener listener = (ServletContextAttributeListener)listeners[i];
/*      */         try
/*      */         {
/*  695 */           if (replaced) {
/*  696 */             this.context.fireContainerEvent("beforeContextAttributeReplaced", listener);
/*      */             
/*  698 */             listener.attributeReplaced(event);
/*  699 */             this.context.fireContainerEvent("afterContextAttributeReplaced", listener);
/*      */           }
/*      */           else {
/*  702 */             this.context.fireContainerEvent("beforeContextAttributeAdded", listener);
/*      */             
/*  704 */             listener.attributeAdded(event);
/*  705 */             this.context.fireContainerEvent("afterContextAttributeAdded", listener);
/*      */           }
/*      */         }
/*      */         catch (Throwable t) {
/*  709 */           ExceptionUtils.handleThrowable(t);
/*  710 */           if (replaced) {
/*  711 */             this.context.fireContainerEvent("afterContextAttributeReplaced", listener);
/*      */           }
/*      */           else {
/*  714 */             this.context.fireContainerEvent("afterContextAttributeAdded", listener);
/*      */           }
/*      */           
/*  717 */           log(sm.getString("applicationContext.attributeEvent"), t);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public FilterRegistration.Dynamic addFilter(String filterName, String className)
/*      */   {
/*  725 */     return addFilter(filterName, className, null);
/*      */   }
/*      */   
/*      */ 
/*      */   public FilterRegistration.Dynamic addFilter(String filterName, Filter filter)
/*      */   {
/*  731 */     return addFilter(filterName, null, filter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public FilterRegistration.Dynamic addFilter(String filterName, Class<? extends Filter> filterClass)
/*      */   {
/*  738 */     return addFilter(filterName, filterClass.getName(), null);
/*      */   }
/*      */   
/*      */ 
/*      */   private FilterRegistration.Dynamic addFilter(String filterName, String filterClass, Filter filter)
/*      */     throws IllegalStateException
/*      */   {
/*  745 */     if ((filterName == null) || (filterName.equals(""))) {
/*  746 */       throw new IllegalArgumentException(sm.getString("applicationContext.invalidFilterName", new Object[] { filterName }));
/*      */     }
/*      */     
/*      */ 
/*  750 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP))
/*      */     {
/*  752 */       throw new IllegalStateException(sm.getString("applicationContext.addFilter.ise", new Object[] { getContextPath() }));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  757 */     FilterDef filterDef = this.context.findFilterDef(filterName);
/*      */     
/*      */ 
/*      */ 
/*  761 */     if (filterDef == null) {
/*  762 */       filterDef = new FilterDef();
/*  763 */       filterDef.setFilterName(filterName);
/*  764 */       this.context.addFilterDef(filterDef);
/*      */     }
/*  766 */     else if ((filterDef.getFilterName() != null) && (filterDef.getFilterClass() != null))
/*      */     {
/*  768 */       return null;
/*      */     }
/*      */     
/*      */ 
/*  772 */     if (filter == null) {
/*  773 */       filterDef.setFilterClass(filterClass);
/*      */     } else {
/*  775 */       filterDef.setFilterClass(filter.getClass().getName());
/*  776 */       filterDef.setFilter(filter);
/*      */     }
/*      */     
/*  779 */     return new ApplicationFilterRegistration(filterDef, this.context);
/*      */   }
/*      */   
/*      */   public <T extends Filter> T createFilter(Class<T> c)
/*      */     throws ServletException
/*      */   {
/*      */     try
/*      */     {
/*  787 */       return (Filter)this.context.getInstanceManager().newInstance(c.getName());
/*      */     }
/*      */     catch (InvocationTargetException e) {
/*  790 */       ExceptionUtils.handleThrowable(e.getCause());
/*  791 */       throw new ServletException(e);
/*      */     }
/*      */     catch (IllegalAccessException|NamingException|InstantiationException|ClassNotFoundException e) {
/*  794 */       throw new ServletException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public FilterRegistration getFilterRegistration(String filterName)
/*      */   {
/*  801 */     FilterDef filterDef = this.context.findFilterDef(filterName);
/*  802 */     if (filterDef == null) {
/*  803 */       return null;
/*      */     }
/*  805 */     return new ApplicationFilterRegistration(filterDef, this.context);
/*      */   }
/*      */   
/*      */ 
/*      */   public ServletRegistration.Dynamic addServlet(String servletName, String className)
/*      */   {
/*  811 */     return addServlet(servletName, className, null);
/*      */   }
/*      */   
/*      */ 
/*      */   public ServletRegistration.Dynamic addServlet(String servletName, Servlet servlet)
/*      */   {
/*  817 */     return addServlet(servletName, null, servlet);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ServletRegistration.Dynamic addServlet(String servletName, Class<? extends Servlet> servletClass)
/*      */   {
/*  824 */     return addServlet(servletName, servletClass.getName(), null);
/*      */   }
/*      */   
/*      */ 
/*      */   private ServletRegistration.Dynamic addServlet(String servletName, String servletClass, Servlet servlet)
/*      */     throws IllegalStateException
/*      */   {
/*  831 */     if ((servletName == null) || (servletName.equals(""))) {
/*  832 */       throw new IllegalArgumentException(sm.getString("applicationContext.invalidServletName", new Object[] { servletName }));
/*      */     }
/*      */     
/*      */ 
/*  836 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP))
/*      */     {
/*  838 */       throw new IllegalStateException(sm.getString("applicationContext.addServlet.ise", new Object[] { getContextPath() }));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  843 */     Wrapper wrapper = (Wrapper)this.context.findChild(servletName);
/*      */     
/*      */ 
/*      */ 
/*  847 */     if (wrapper == null) {
/*  848 */       wrapper = this.context.createWrapper();
/*  849 */       wrapper.setName(servletName);
/*  850 */       this.context.addChild(wrapper);
/*      */     }
/*  852 */     else if ((wrapper.getName() != null) && (wrapper.getServletClass() != null))
/*      */     {
/*  854 */       if (wrapper.isOverridable()) {
/*  855 */         wrapper.setOverridable(false);
/*      */       } else {
/*  857 */         return null;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  862 */     if (servlet == null) {
/*  863 */       wrapper.setServletClass(servletClass);
/*      */     } else {
/*  865 */       wrapper.setServletClass(servlet.getClass().getName());
/*  866 */       wrapper.setServlet(servlet);
/*      */     }
/*      */     
/*  869 */     return this.context.dynamicServletAdded(wrapper);
/*      */   }
/*      */   
/*      */ 
/*      */   public <T extends Servlet> T createServlet(Class<T> c)
/*      */     throws ServletException
/*      */   {
/*      */     try
/*      */     {
/*  878 */       T servlet = (Servlet)this.context.getInstanceManager().newInstance(c.getName());
/*  879 */       this.context.dynamicServletCreated(servlet);
/*  880 */       return servlet;
/*      */     } catch (InvocationTargetException e) {
/*  882 */       ExceptionUtils.handleThrowable(e.getCause());
/*  883 */       throw new ServletException(e);
/*      */     }
/*      */     catch (IllegalAccessException|NamingException|InstantiationException|ClassNotFoundException e) {
/*  886 */       throw new ServletException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public ServletRegistration getServletRegistration(String servletName)
/*      */   {
/*  893 */     Wrapper wrapper = (Wrapper)this.context.findChild(servletName);
/*  894 */     if (wrapper == null) {
/*  895 */       return null;
/*      */     }
/*      */     
/*  898 */     return new ApplicationServletRegistration(wrapper, this.context);
/*      */   }
/*      */   
/*      */ 
/*      */   public Set<SessionTrackingMode> getDefaultSessionTrackingModes()
/*      */   {
/*  904 */     return this.defaultSessionTrackingModes;
/*      */   }
/*      */   
/*      */ 
/*      */   private void populateSessionTrackingModes()
/*      */   {
/*  910 */     this.defaultSessionTrackingModes = EnumSet.of(SessionTrackingMode.URL);
/*  911 */     this.supportedSessionTrackingModes = EnumSet.of(SessionTrackingMode.URL);
/*      */     
/*  913 */     if (this.context.getCookies()) {
/*  914 */       this.defaultSessionTrackingModes.add(SessionTrackingMode.COOKIE);
/*  915 */       this.supportedSessionTrackingModes.add(SessionTrackingMode.COOKIE);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  920 */     Service s = ((Engine)this.context.getParent().getParent()).getService();
/*  921 */     Connector[] connectors = s.findConnectors();
/*      */     
/*  923 */     for (Connector connector : connectors) {
/*  924 */       if (Boolean.TRUE.equals(connector.getAttribute("SSLEnabled"))) {
/*  925 */         this.supportedSessionTrackingModes.add(SessionTrackingMode.SSL);
/*  926 */         break;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Set<SessionTrackingMode> getEffectiveSessionTrackingModes()
/*      */   {
/*  934 */     if (this.sessionTrackingModes != null) {
/*  935 */       return this.sessionTrackingModes;
/*      */     }
/*  937 */     return this.defaultSessionTrackingModes;
/*      */   }
/*      */   
/*      */ 
/*      */   public SessionCookieConfig getSessionCookieConfig()
/*      */   {
/*  943 */     return this.sessionCookieConfig;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setSessionTrackingModes(Set<SessionTrackingMode> sessionTrackingModes)
/*      */   {
/*  950 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP)) {
/*  951 */       throw new IllegalStateException(sm.getString("applicationContext.setSessionTracking.ise", new Object[] { getContextPath() }));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  957 */     for (SessionTrackingMode sessionTrackingMode : sessionTrackingModes) {
/*  958 */       if (!this.supportedSessionTrackingModes.contains(sessionTrackingMode)) {
/*  959 */         throw new IllegalArgumentException(sm.getString("applicationContext.setSessionTracking.iae.invalid", new Object[] { sessionTrackingMode.toString(), getContextPath() }));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  966 */     if ((sessionTrackingModes.contains(SessionTrackingMode.SSL)) && 
/*  967 */       (sessionTrackingModes.size() > 1)) {
/*  968 */       throw new IllegalArgumentException(sm.getString("applicationContext.setSessionTracking.iae.ssl", new Object[] { getContextPath() }));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  974 */     this.sessionTrackingModes = sessionTrackingModes;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean setInitParameter(String name, String value)
/*      */   {
/*  980 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP)) {
/*  981 */       throw new IllegalStateException(sm.getString("applicationContext.setInitParam.ise", new Object[] { getContextPath() }));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  986 */     return this.parameters.putIfAbsent(name, value) == null;
/*      */   }
/*      */   
/*      */ 
/*      */   public void addListener(Class<? extends EventListener> listenerClass)
/*      */   {
/*      */     try
/*      */     {
/*  994 */       listener = createListener(listenerClass);
/*      */     } catch (ServletException e) { EventListener listener;
/*  996 */       throw new IllegalArgumentException(sm.getString("applicationContext.addListener.iae.init", new Object[] { listenerClass.getName() }), e);
/*      */     }
/*      */     
/*      */     EventListener listener;
/* 1000 */     addListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */   public void addListener(String className)
/*      */   {
/*      */     try
/*      */     {
/* 1008 */       if (this.context.getInstanceManager() != null) {
/* 1009 */         Object obj = this.context.getInstanceManager().newInstance(className);
/*      */         
/* 1011 */         if (!(obj instanceof EventListener)) {
/* 1012 */           throw new IllegalArgumentException(sm.getString("applicationContext.addListener.iae.wrongType", new Object[] { className }));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1017 */         EventListener listener = (EventListener)obj;
/* 1018 */         addListener(listener);
/*      */       }
/*      */     } catch (InvocationTargetException e) {
/* 1021 */       ExceptionUtils.handleThrowable(e.getCause());
/* 1022 */       throw new IllegalArgumentException(sm.getString("applicationContext.addListener.iae.cnfe", new Object[] { className }), e);
/*      */ 
/*      */     }
/*      */     catch (IllegalAccessException|NamingException|InstantiationException|ClassNotFoundException e)
/*      */     {
/* 1027 */       throw new IllegalArgumentException(sm.getString("applicationContext.addListener.iae.cnfe", new Object[] { className }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T extends EventListener> void addListener(T t)
/*      */   {
/* 1037 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP)) {
/* 1038 */       throw new IllegalStateException(sm.getString("applicationContext.addListener.ise", new Object[] { getContextPath() }));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1043 */     boolean match = false;
/* 1044 */     if (((t instanceof ServletContextAttributeListener)) || ((t instanceof ServletRequestListener)) || ((t instanceof ServletRequestAttributeListener)) || ((t instanceof HttpSessionIdListener)) || ((t instanceof HttpSessionAttributeListener)))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1049 */       this.context.addApplicationEventListener(t);
/* 1050 */       match = true;
/*      */     }
/*      */     
/* 1053 */     if (((t instanceof HttpSessionListener)) || (((t instanceof ServletContextListener)) && (this.newServletContextListenerAllowed)))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1058 */       this.context.addApplicationLifecycleListener(t);
/* 1059 */       match = true;
/*      */     }
/*      */     
/* 1062 */     if (match) { return;
/*      */     }
/* 1064 */     if ((t instanceof ServletContextListener)) {
/* 1065 */       throw new IllegalArgumentException(sm.getString("applicationContext.addListener.iae.sclNotAllowed", new Object[] { t.getClass().getName() }));
/*      */     }
/*      */     
/*      */ 
/* 1069 */     throw new IllegalArgumentException(sm.getString("applicationContext.addListener.iae.wrongType", new Object[] { t.getClass().getName() }));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T extends EventListener> T createListener(Class<T> c)
/*      */     throws ServletException
/*      */   {
/*      */     try
/*      */     {
/* 1081 */       T listener = (EventListener)this.context.getInstanceManager().newInstance(c);
/*      */       
/* 1083 */       if (((listener instanceof ServletContextListener)) || ((listener instanceof ServletContextAttributeListener)) || ((listener instanceof ServletRequestListener)) || ((listener instanceof ServletRequestAttributeListener)) || ((listener instanceof HttpSessionListener)) || ((listener instanceof HttpSessionIdListener)) || ((listener instanceof HttpSessionAttributeListener)))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1090 */         return listener;
/*      */       }
/* 1092 */       throw new IllegalArgumentException(sm.getString("applicationContext.addListener.iae.wrongType", new Object[] { listener.getClass().getName() }));
/*      */     }
/*      */     catch (InvocationTargetException e)
/*      */     {
/* 1096 */       ExceptionUtils.handleThrowable(e.getCause());
/* 1097 */       throw new ServletException(e);
/*      */     } catch (IllegalAccessException|NamingException|InstantiationException e) {
/* 1099 */       throw new ServletException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void declareRoles(String... roleNames)
/*      */   {
/* 1107 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP))
/*      */     {
/* 1109 */       throw new IllegalStateException(sm.getString("applicationContext.addRole.ise", new Object[] { getContextPath() }));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1114 */     if (roleNames == null) {
/* 1115 */       throw new IllegalArgumentException(sm.getString("applicationContext.roles.iae", new Object[] { getContextPath() }));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1120 */     for (String role : roleNames) {
/* 1121 */       if ((role == null) || ("".equals(role))) {
/* 1122 */         throw new IllegalArgumentException(sm.getString("applicationContext.role.iae", new Object[] { getContextPath() }));
/*      */       }
/*      */       
/*      */ 
/* 1126 */       this.context.addSecurityRole(role);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public ClassLoader getClassLoader()
/*      */   {
/* 1133 */     ClassLoader result = this.context.getLoader().getClassLoader();
/* 1134 */     if (Globals.IS_SECURITY_ENABLED) {
/* 1135 */       ClassLoader tccl = Thread.currentThread().getContextClassLoader();
/* 1136 */       ClassLoader parent = result;
/* 1137 */       while ((parent != null) && 
/* 1138 */         (parent != tccl))
/*      */       {
/*      */ 
/* 1141 */         parent = parent.getParent();
/*      */       }
/* 1143 */       if (parent == null) {
/* 1144 */         System.getSecurityManager().checkPermission(new RuntimePermission("getClassLoader"));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1149 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getEffectiveMajorVersion()
/*      */   {
/* 1155 */     return this.context.getEffectiveMajorVersion();
/*      */   }
/*      */   
/*      */ 
/*      */   public int getEffectiveMinorVersion()
/*      */   {
/* 1161 */     return this.context.getEffectiveMinorVersion();
/*      */   }
/*      */   
/*      */ 
/*      */   public Map<String, ? extends FilterRegistration> getFilterRegistrations()
/*      */   {
/* 1167 */     Map<String, ApplicationFilterRegistration> result = new HashMap();
/*      */     
/* 1169 */     FilterDef[] filterDefs = this.context.findFilterDefs();
/* 1170 */     for (FilterDef filterDef : filterDefs) {
/* 1171 */       result.put(filterDef.getFilterName(), new ApplicationFilterRegistration(filterDef, this.context));
/*      */     }
/*      */     
/*      */ 
/* 1175 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */   public JspConfigDescriptor getJspConfigDescriptor()
/*      */   {
/* 1181 */     return this.context.getJspConfigDescriptor();
/*      */   }
/*      */   
/*      */ 
/*      */   public Map<String, ? extends ServletRegistration> getServletRegistrations()
/*      */   {
/* 1187 */     Map<String, ApplicationServletRegistration> result = new HashMap();
/*      */     
/* 1189 */     Container[] wrappers = this.context.findChildren();
/* 1190 */     for (Container wrapper : wrappers) {
/* 1191 */       result.put(((Wrapper)wrapper).getName(), new ApplicationServletRegistration((Wrapper)wrapper, this.context));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1196 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getVirtualServerName()
/*      */   {
/* 1203 */     Container host = this.context.getParent();
/* 1204 */     Container engine = host.getParent();
/* 1205 */     return engine.getName() + "/" + host.getName();
/*      */   }
/*      */   
/*      */ 
/*      */   protected StandardContext getContext()
/*      */   {
/* 1211 */     return this.context;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void clearAttributes()
/*      */   {
/* 1220 */     ArrayList<String> list = new ArrayList();
/* 1221 */     Iterator<String> iter = this.attributes.keySet().iterator();
/* 1222 */     while (iter.hasNext()) {
/* 1223 */       list.add(iter.next());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1228 */     Iterator<String> keys = list.iterator();
/* 1229 */     while (keys.hasNext()) {
/* 1230 */       String key = (String)keys.next();
/* 1231 */       removeAttribute(key);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ServletContext getFacade()
/*      */   {
/* 1242 */     return this.facade;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setAttributeReadOnly(String name)
/*      */   {
/* 1252 */     if (this.attributes.containsKey(name)) {
/* 1253 */       this.readOnlyAttributes.put(name, name);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void setNewServletContextListenerAllowed(boolean allowed)
/*      */   {
/* 1259 */     this.newServletContextListenerAllowed = allowed;
/*      */   }
/*      */   
/*      */ 
/*      */   private static final class DispatchData
/*      */   {
/*      */     public MessageBytes uriMB;
/*      */     
/*      */     public MappingData mappingData;
/*      */     
/*      */ 
/*      */     public DispatchData()
/*      */     {
/* 1272 */       this.uriMB = MessageBytes.newInstance();
/* 1273 */       CharChunk uriCC = this.uriMB.getCharChunk();
/* 1274 */       uriCC.setLimit(-1);
/* 1275 */       this.mappingData = new MappingData();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\core\ApplicationContext.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */