/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.MultipartConfigElement;
/*     */ import javax.servlet.ServletRegistration.Dynamic;
/*     */ import javax.servlet.ServletSecurityElement;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Wrapper;
/*     */ import org.apache.catalina.util.ParameterMap;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationServletRegistration
/*     */   implements ServletRegistration.Dynamic
/*     */ {
/*  42 */   private static final StringManager sm = StringManager.getManager("org.apache.catalina.core");
/*     */   
/*     */   private final Wrapper wrapper;
/*     */   
/*     */   private final Context context;
/*     */   
/*     */   public ApplicationServletRegistration(Wrapper wrapper, Context context)
/*     */   {
/*  50 */     this.wrapper = wrapper;
/*  51 */     this.context = context;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getClassName()
/*     */   {
/*  57 */     return this.wrapper.getServletClass();
/*     */   }
/*     */   
/*     */   public String getInitParameter(String name)
/*     */   {
/*  62 */     return this.wrapper.findInitParameter(name);
/*     */   }
/*     */   
/*     */   public Map<String, String> getInitParameters()
/*     */   {
/*  67 */     ParameterMap<String, String> result = new ParameterMap();
/*     */     
/*  69 */     String[] parameterNames = this.wrapper.findInitParameters();
/*     */     
/*  71 */     for (String parameterName : parameterNames) {
/*  72 */       result.put(parameterName, this.wrapper.findInitParameter(parameterName));
/*     */     }
/*     */     
/*  75 */     result.setLocked(true);
/*  76 */     return result;
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/*  81 */     return this.wrapper.getName();
/*     */   }
/*     */   
/*     */   public boolean setInitParameter(String name, String value)
/*     */   {
/*  86 */     if ((name == null) || (value == null)) {
/*  87 */       throw new IllegalArgumentException(sm.getString("applicationFilterRegistration.nullInitParam", new Object[] { name, value }));
/*     */     }
/*     */     
/*     */ 
/*  91 */     if (getInitParameter(name) != null) {
/*  92 */       return false;
/*     */     }
/*     */     
/*  95 */     this.wrapper.addInitParameter(name, value);
/*     */     
/*  97 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public Set<String> setInitParameters(Map<String, String> initParameters)
/*     */   {
/* 103 */     Set<String> conflicts = new HashSet();
/*     */     
/* 105 */     for (Map.Entry<String, String> entry : initParameters.entrySet()) {
/* 106 */       if ((entry.getKey() == null) || (entry.getValue() == null)) {
/* 107 */         throw new IllegalArgumentException(sm.getString("applicationFilterRegistration.nullInitParams", new Object[] { entry.getKey(), entry.getValue() }));
/*     */       }
/*     */       
/*     */ 
/* 111 */       if (getInitParameter((String)entry.getKey()) != null) {
/* 112 */         conflicts.add(entry.getKey());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 118 */     if (conflicts.isEmpty()) {
/* 119 */       for (Map.Entry<String, String> entry : initParameters.entrySet()) {
/* 120 */         setInitParameter((String)entry.getKey(), (String)entry.getValue());
/*     */       }
/*     */     }
/*     */     
/* 124 */     return conflicts;
/*     */   }
/*     */   
/*     */   public void setAsyncSupported(boolean asyncSupported)
/*     */   {
/* 129 */     this.wrapper.setAsyncSupported(asyncSupported);
/*     */   }
/*     */   
/*     */   public void setLoadOnStartup(int loadOnStartup)
/*     */   {
/* 134 */     this.wrapper.setLoadOnStartup(loadOnStartup);
/*     */   }
/*     */   
/*     */   public void setMultipartConfig(MultipartConfigElement multipartConfig)
/*     */   {
/* 139 */     this.wrapper.setMultipartConfigElement(multipartConfig);
/*     */   }
/*     */   
/*     */   public void setRunAsRole(String roleName)
/*     */   {
/* 144 */     this.wrapper.setRunAs(roleName);
/*     */   }
/*     */   
/*     */   public Set<String> setServletSecurity(ServletSecurityElement constraint)
/*     */   {
/* 149 */     if (constraint == null) {
/* 150 */       throw new IllegalArgumentException(sm.getString("applicationServletRegistration.setServletSecurity.iae", new Object[] { getName(), this.context.getName() }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 155 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP)) {
/* 156 */       throw new IllegalStateException(sm.getString("applicationServletRegistration.setServletSecurity.ise", new Object[] { getName(), this.context.getName() }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 161 */     return this.context.addServletSecurity(this, constraint);
/*     */   }
/*     */   
/*     */ 
/*     */   public Set<String> addMapping(String... urlPatterns)
/*     */   {
/* 167 */     if (urlPatterns == null) {
/* 168 */       return Collections.emptySet();
/*     */     }
/*     */     
/* 171 */     Set<String> conflicts = new HashSet();
/*     */     
/* 173 */     for (String urlPattern : urlPatterns) {
/* 174 */       String wrapperName = this.context.findServletMapping(urlPattern);
/* 175 */       if (wrapperName != null) {
/* 176 */         Wrapper wrapper = (Wrapper)this.context.findChild(wrapperName);
/* 177 */         if (wrapper.isOverridable())
/*     */         {
/*     */ 
/* 180 */           this.context.removeServletMapping(urlPattern);
/*     */         } else {
/* 182 */           conflicts.add(urlPattern);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 187 */     if (!conflicts.isEmpty()) {
/* 188 */       return conflicts;
/*     */     }
/*     */     
/* 191 */     for (String urlPattern : urlPatterns) {
/* 192 */       this.context.addServletMapping(urlPattern, this.wrapper.getName());
/*     */     }
/* 194 */     return Collections.emptySet();
/*     */   }
/*     */   
/*     */ 
/*     */   public Collection<String> getMappings()
/*     */   {
/* 200 */     Set<String> result = new HashSet();
/* 201 */     String servletName = this.wrapper.getName();
/*     */     
/* 203 */     String[] urlPatterns = this.context.findServletMappings();
/* 204 */     for (String urlPattern : urlPatterns) {
/* 205 */       String name = this.context.findServletMapping(urlPattern);
/* 206 */       if (name.equals(servletName)) {
/* 207 */         result.add(urlPattern);
/*     */       }
/*     */     }
/* 210 */     return result;
/*     */   }
/*     */   
/*     */   public String getRunAsRole()
/*     */   {
/* 215 */     return this.wrapper.getRunAs();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\core\ApplicationServletRegistration.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */