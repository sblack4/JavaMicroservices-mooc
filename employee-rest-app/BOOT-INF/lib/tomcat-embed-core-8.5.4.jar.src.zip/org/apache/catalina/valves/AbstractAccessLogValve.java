/*      */ package org.apache.catalina.valves;
/*      */ 
/*      */ import java.io.CharArrayWriter;
/*      */ import java.io.IOException;
/*      */ import java.net.InetAddress;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.TimeZone;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.http.Cookie;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpSession;
/*      */ import org.apache.catalina.AccessLog;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.catalina.Valve;
/*      */ import org.apache.coyote.RequestInfo;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.collections.SynchronizedStack;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractAccessLogValve
/*      */   extends ValveBase
/*      */   implements AccessLog
/*      */ {
/*  135 */   private static final Log log = LogFactory.getLog(AbstractAccessLogValve.class);
/*      */   
/*      */ 
/*      */ 
/*      */   private static enum FormatType
/*      */   {
/*  141 */     CLF,  SEC,  MSEC,  MSEC_FRAC,  SDF;
/*      */     
/*      */     private FormatType() {}
/*      */   }
/*      */   
/*      */   private static enum PortType
/*      */   {
/*  148 */     LOCAL,  REMOTE;
/*      */     
/*      */     private PortType() {}
/*      */   }
/*      */   
/*  153 */   public AbstractAccessLogValve() { super(true); }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  162 */   protected boolean enabled = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  167 */   protected String pattern = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int globalCacheSize = 300;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int localCacheSize = 60;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static class DateFormatCache
/*      */   {
/*      */     protected class Cache
/*      */     {
/*      */       private static final String cLFFormat = "dd/MMM/yyyy:HH:mm:ss Z";
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  213 */       private long previousSeconds = Long.MIN_VALUE;
/*      */       
/*  215 */       private String previousFormat = "";
/*      */       
/*      */ 
/*  218 */       private long first = Long.MIN_VALUE;
/*      */       
/*  220 */       private long last = Long.MIN_VALUE;
/*      */       
/*  222 */       private int offset = 0;
/*      */       
/*  224 */       private final Date currentDate = new Date();
/*      */       
/*      */       protected final String[] cache;
/*      */       private SimpleDateFormat formatter;
/*  228 */       private boolean isCLF = false;
/*      */       
/*  230 */       private Cache parent = null;
/*      */       
/*      */       private Cache(Cache parent) {
/*  233 */         this(null, parent);
/*      */       }
/*      */       
/*      */       private Cache(String format, Cache parent) {
/*  237 */         this(format, null, parent);
/*      */       }
/*      */       
/*      */       private Cache(String format, Locale loc, Cache parent) {
/*  241 */         this.cache = new String[AbstractAccessLogValve.DateFormatCache.this.cacheSize];
/*  242 */         for (int i = 0; i < AbstractAccessLogValve.DateFormatCache.this.cacheSize; i++) {
/*  243 */           this.cache[i] = null;
/*      */         }
/*  245 */         if (loc == null) {
/*  246 */           loc = AbstractAccessLogValve.DateFormatCache.this.cacheDefaultLocale;
/*      */         }
/*  248 */         if (format == null) {
/*  249 */           this.isCLF = true;
/*  250 */           format = "dd/MMM/yyyy:HH:mm:ss Z";
/*  251 */           this.formatter = new SimpleDateFormat(format, Locale.US);
/*      */         } else {
/*  253 */           this.formatter = new SimpleDateFormat(format, loc);
/*      */         }
/*  255 */         this.formatter.setTimeZone(TimeZone.getDefault());
/*  256 */         this.parent = parent;
/*      */       }
/*      */       
/*      */       private String getFormatInternal(long time)
/*      */       {
/*  261 */         long seconds = time / 1000L;
/*      */         
/*      */ 
/*      */ 
/*  265 */         if (seconds == this.previousSeconds) {
/*  266 */           return this.previousFormat;
/*      */         }
/*      */         
/*      */ 
/*  270 */         this.previousSeconds = seconds;
/*  271 */         int index = (this.offset + (int)(seconds - this.first)) % AbstractAccessLogValve.DateFormatCache.this.cacheSize;
/*  272 */         if (index < 0) {
/*  273 */           index += AbstractAccessLogValve.DateFormatCache.this.cacheSize;
/*      */         }
/*  275 */         if ((seconds >= this.first) && (seconds <= this.last)) {
/*  276 */           if (this.cache[index] != null)
/*      */           {
/*  278 */             this.previousFormat = this.cache[index];
/*  279 */             return this.previousFormat;
/*      */           }
/*      */           
/*      */         }
/*  283 */         else if ((seconds >= this.last + AbstractAccessLogValve.DateFormatCache.this.cacheSize) || (seconds <= this.first - AbstractAccessLogValve.DateFormatCache.this.cacheSize)) {
/*  284 */           this.first = seconds;
/*  285 */           this.last = (this.first + AbstractAccessLogValve.DateFormatCache.this.cacheSize - 1L);
/*  286 */           index = 0;
/*  287 */           this.offset = 0;
/*  288 */           for (int i = 1; i < AbstractAccessLogValve.DateFormatCache.this.cacheSize; i++) {
/*  289 */             this.cache[i] = null;
/*      */           }
/*  291 */         } else if (seconds > this.last) {
/*  292 */           for (int i = 1; i < seconds - this.last; i++) {
/*  293 */             this.cache[((index + AbstractAccessLogValve.DateFormatCache.this.cacheSize - i) % AbstractAccessLogValve.DateFormatCache.this.cacheSize)] = null;
/*      */           }
/*  295 */           this.first = (seconds - (AbstractAccessLogValve.DateFormatCache.this.cacheSize - 1));
/*  296 */           this.last = seconds;
/*  297 */           this.offset = ((index + 1) % AbstractAccessLogValve.DateFormatCache.this.cacheSize);
/*  298 */         } else if (seconds < this.first) {
/*  299 */           for (int i = 1; i < this.first - seconds; i++) {
/*  300 */             this.cache[((index + i) % AbstractAccessLogValve.DateFormatCache.this.cacheSize)] = null;
/*      */           }
/*  302 */           this.first = seconds;
/*  303 */           this.last = (seconds + (AbstractAccessLogValve.DateFormatCache.this.cacheSize - 1));
/*  304 */           this.offset = index;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  309 */         if (this.parent != null) {
/*  310 */           synchronized (this.parent) {
/*  311 */             this.previousFormat = this.parent.getFormatInternal(time);
/*      */           }
/*      */         } else {
/*  314 */           this.currentDate.setTime(time);
/*  315 */           this.previousFormat = this.formatter.format(this.currentDate);
/*  316 */           if (this.isCLF) {
/*  317 */             StringBuilder current = new StringBuilder(32);
/*  318 */             current.append('[');
/*  319 */             current.append(this.previousFormat);
/*  320 */             current.append(']');
/*  321 */             this.previousFormat = current.toString();
/*      */           }
/*      */         }
/*  324 */         this.cache[index] = this.previousFormat;
/*  325 */         return this.previousFormat;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  330 */     private int cacheSize = 0;
/*      */     
/*      */     private final Locale cacheDefaultLocale;
/*      */     private final DateFormatCache parent;
/*      */     protected final Cache cLFCache;
/*  335 */     private final HashMap<String, Cache> formatCache = new HashMap();
/*      */     
/*      */     protected DateFormatCache(int size, Locale loc, DateFormatCache parent) {
/*  338 */       this.cacheSize = size;
/*  339 */       this.cacheDefaultLocale = loc;
/*  340 */       this.parent = parent;
/*  341 */       Cache parentCache = null;
/*  342 */       if (parent != null) {
/*  343 */         synchronized (parent) {
/*  344 */           parentCache = parent.getCache(null, null);
/*      */         }
/*      */       }
/*  347 */       this.cLFCache = new Cache(parentCache, null);
/*      */     }
/*      */     
/*      */     private Cache getCache(String format, Locale loc) { Cache cache;
/*      */       Cache cache;
/*  352 */       if (format == null) {
/*  353 */         cache = this.cLFCache;
/*      */       } else {
/*  355 */         cache = (Cache)this.formatCache.get(format);
/*  356 */         if (cache == null) {
/*  357 */           Cache parentCache = null;
/*  358 */           if (this.parent != null) {
/*  359 */             synchronized (this.parent) {
/*  360 */               parentCache = this.parent.getCache(format, loc);
/*      */             }
/*      */           }
/*  363 */           cache = new Cache(format, loc, parentCache, null);
/*  364 */           this.formatCache.put(format, cache);
/*      */         }
/*      */       }
/*  367 */       return cache;
/*      */     }
/*      */     
/*      */     public String getFormat(long time) {
/*  371 */       return this.cLFCache.getFormatInternal(time);
/*      */     }
/*      */     
/*      */     public String getFormat(String format, Locale loc, long time) {
/*  375 */       return getCache(format, loc).getFormatInternal(time);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  382 */   private static final DateFormatCache globalDateCache = new DateFormatCache(300, Locale.getDefault(), null);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  388 */   private static final ThreadLocal<DateFormatCache> localDateCache = new ThreadLocal()
/*      */   {
/*      */     protected AbstractAccessLogValve.DateFormatCache initialValue()
/*      */     {
/*  392 */       return new AbstractAccessLogValve.DateFormatCache(60, Locale.getDefault(), AbstractAccessLogValve.globalDateCache);
/*      */     }
/*      */   };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  401 */   private static final ThreadLocal<Date> localDate = new ThreadLocal()
/*      */   {
/*      */     protected Date initialValue()
/*      */     {
/*  405 */       return new Date();
/*      */     }
/*      */   };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  413 */   protected String condition = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  419 */   protected String conditionIf = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  425 */   protected String localeName = Locale.getDefault().toString();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  432 */   protected Locale locale = Locale.getDefault();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  437 */   protected AccessLogElement[] logElements = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  442 */   protected boolean requestAttributesEnabled = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  448 */   private SynchronizedStack<CharArrayWriter> charArrayWriters = new SynchronizedStack();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  457 */   private int maxLogMessageBufferSize = 256;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRequestAttributesEnabled(boolean requestAttributesEnabled)
/*      */   {
/*  466 */     this.requestAttributesEnabled = requestAttributesEnabled;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getRequestAttributesEnabled()
/*      */   {
/*  474 */     return this.requestAttributesEnabled;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getEnabled()
/*      */   {
/*  481 */     return this.enabled;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEnabled(boolean enabled)
/*      */   {
/*  489 */     this.enabled = enabled;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getPattern()
/*      */   {
/*  496 */     return this.pattern;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPattern(String pattern)
/*      */   {
/*  506 */     if (pattern == null) {
/*  507 */       this.pattern = "";
/*  508 */     } else if (pattern.equals("common")) {
/*  509 */       this.pattern = "%h %l %u %t \"%r\" %s %b";
/*  510 */     } else if (pattern.equals("combined")) {
/*  511 */       this.pattern = "%h %l %u %t \"%r\" %s %b \"%{Referer}i\" \"%{User-Agent}i\"";
/*      */     } else {
/*  513 */       this.pattern = pattern;
/*      */     }
/*  515 */     this.logElements = createLogElements();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCondition()
/*      */   {
/*  525 */     return this.condition;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCondition(String condition)
/*      */   {
/*  536 */     this.condition = condition;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getConditionUnless()
/*      */   {
/*  547 */     return getCondition();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConditionUnless(String condition)
/*      */   {
/*  558 */     setCondition(condition);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getConditionIf()
/*      */   {
/*  568 */     return this.conditionIf;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConditionIf(String condition)
/*      */   {
/*  579 */     this.conditionIf = condition;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getLocale()
/*      */   {
/*  588 */     return this.localeName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLocale(String localeName)
/*      */   {
/*  601 */     this.localeName = localeName;
/*  602 */     this.locale = findLocale(localeName, this.locale);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void invoke(org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response)
/*      */     throws IOException, ServletException
/*      */   {
/*  620 */     getNext().invoke(request, response);
/*      */   }
/*      */   
/*      */ 
/*      */   public void log(org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */   {
/*  626 */     if ((!getState().isAvailable()) || (!getEnabled()) || (this.logElements == null) || ((this.condition != null) && (null != request.getRequest().getAttribute(this.condition))) || ((this.conditionIf != null) && (null == request.getRequest().getAttribute(this.conditionIf))))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  631 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  640 */     long start = request.getCoyoteRequest().getStartTime();
/*  641 */     Date date = getDate(start + time);
/*      */     
/*  643 */     CharArrayWriter result = (CharArrayWriter)this.charArrayWriters.pop();
/*  644 */     if (result == null) {
/*  645 */       result = new CharArrayWriter(128);
/*      */     }
/*      */     
/*  648 */     for (int i = 0; i < this.logElements.length; i++) {
/*  649 */       this.logElements[i].addElement(result, date, request, response, time);
/*      */     }
/*      */     
/*  652 */     log(result);
/*      */     
/*  654 */     if (result.size() <= this.maxLogMessageBufferSize) {
/*  655 */       result.reset();
/*  656 */       this.charArrayWriters.push(result);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected abstract void log(CharArrayWriter paramCharArrayWriter);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static Date getDate(long systime)
/*      */   {
/*  682 */     Date date = (Date)localDate.get();
/*  683 */     date.setTime(systime);
/*  684 */     return date;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static Locale findLocale(String name, Locale fallback)
/*      */   {
/*  695 */     if ((name == null) || (name.isEmpty())) {
/*  696 */       return Locale.getDefault();
/*      */     }
/*  698 */     for (Locale l : Locale.getAvailableLocales()) {
/*  699 */       if (name.equals(l.toString())) {
/*  700 */         return l;
/*      */       }
/*      */     }
/*      */     
/*  704 */     log.error(sm.getString("accessLogValve.invalidLocale", new Object[] { name }));
/*  705 */     return fallback;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void startInternal()
/*      */     throws LifecycleException
/*      */   {
/*  719 */     setState(LifecycleState.STARTING);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void stopInternal()
/*      */     throws LifecycleException
/*      */   {
/*  733 */     setState(LifecycleState.STOPPING);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static abstract interface AccessLogElement
/*      */   {
/*      */     public abstract void addElement(CharArrayWriter paramCharArrayWriter, Date paramDate, org.apache.catalina.connector.Request paramRequest, org.apache.catalina.connector.Response paramResponse, long paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static class ThreadNameElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/*  752 */       RequestInfo info = request.getCoyoteRequest().getRequestProcessor();
/*  753 */       if (info != null) {
/*  754 */         buf.append(info.getWorkerThreadName());
/*      */       } else {
/*  756 */         buf.append("-");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected static class LocalAddrElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     private static final String LOCAL_ADDR_VALUE;
/*      */     
/*      */     static
/*      */     {
/*      */       String init;
/*      */       try
/*      */       {
/*  771 */         init = InetAddress.getLocalHost().getHostAddress();
/*      */       } catch (Throwable e) { String init;
/*  773 */         ExceptionUtils.handleThrowable(e);
/*  774 */         init = "127.0.0.1";
/*      */       }
/*  776 */       LOCAL_ADDR_VALUE = init;
/*      */     }
/*      */     
/*      */ 
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/*  782 */       buf.append(LOCAL_ADDR_VALUE);
/*      */     }
/*      */   }
/*      */   
/*      */   protected class RemoteAddrElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     protected RemoteAddrElement() {}
/*      */     
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/*  793 */       if (AbstractAccessLogValve.this.requestAttributesEnabled) {
/*  794 */         Object addr = request.getAttribute("org.apache.catalina.AccessLog.RemoteAddr");
/*  795 */         if (addr == null) {
/*  796 */           buf.append(request.getRemoteAddr());
/*      */         } else {
/*  798 */           buf.append(addr.toString());
/*      */         }
/*      */       } else {
/*  801 */         buf.append(request.getRemoteAddr());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected class HostElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     protected HostElement() {}
/*      */     
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/*  813 */       String value = null;
/*  814 */       if (AbstractAccessLogValve.this.requestAttributesEnabled) {
/*  815 */         Object host = request.getAttribute("org.apache.catalina.AccessLog.RemoteHost");
/*  816 */         if (host != null) {
/*  817 */           value = host.toString();
/*      */         }
/*      */       }
/*  820 */       if ((value == null) || (value.length() == 0)) {
/*  821 */         value = request.getRemoteHost();
/*      */       }
/*  823 */       if ((value == null) || (value.length() == 0)) {
/*  824 */         value = "-";
/*      */       }
/*  826 */       buf.append(value);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static class LogicalUserNameElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/*  837 */       buf.append('-');
/*      */     }
/*      */   }
/*      */   
/*      */   protected class ProtocolElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     protected ProtocolElement() {}
/*      */     
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/*  848 */       if (AbstractAccessLogValve.this.requestAttributesEnabled) {
/*  849 */         Object proto = request.getAttribute("org.apache.catalina.AccessLog.Protocol");
/*  850 */         if (proto == null) {
/*  851 */           buf.append(request.getProtocol());
/*      */         } else {
/*  853 */           buf.append(proto.toString());
/*      */         }
/*      */       } else {
/*  856 */         buf.append(request.getProtocol());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static class UserElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/*  868 */       if (request != null) {
/*  869 */         String value = request.getRemoteUser();
/*  870 */         if (value != null) {
/*  871 */           buf.append(value);
/*      */         } else {
/*  873 */           buf.append('-');
/*      */         }
/*      */       } else {
/*  876 */         buf.append('-');
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected class DateAndTimeElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     private static final String requestStartPrefix = "begin";
/*      */     
/*      */ 
/*      */ 
/*      */     private static final String responseEndPrefix = "end";
/*      */     
/*      */ 
/*      */ 
/*      */     private static final String prefixSeparator = ":";
/*      */     
/*      */ 
/*      */ 
/*      */     private static final String secFormat = "sec";
/*      */     
/*      */ 
/*      */ 
/*      */     private static final String msecFormat = "msec";
/*      */     
/*      */ 
/*      */ 
/*      */     private static final String msecFractionFormat = "msec_frac";
/*      */     
/*      */ 
/*      */ 
/*      */     private static final String msecPattern = "{#}";
/*      */     
/*      */ 
/*      */ 
/*      */     private static final String trippleMsecPattern = "{#}{#}{#}";
/*      */     
/*      */ 
/*      */ 
/*      */     private final String format;
/*      */     
/*      */ 
/*      */ 
/*      */     private final boolean usesBegin;
/*      */     
/*      */ 
/*      */ 
/*      */     private final AbstractAccessLogValve.FormatType type;
/*      */     
/*      */ 
/*      */ 
/*  931 */     private boolean usesMsecs = false;
/*      */     
/*      */     protected DateAndTimeElement() {
/*  934 */       this(null);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private String tidyFormat(String format)
/*      */     {
/*  945 */       boolean escape = false;
/*  946 */       StringBuilder result = new StringBuilder();
/*  947 */       int len = format.length();
/*      */       
/*  949 */       for (int i = 0; i < len; i++) {
/*  950 */         char x = format.charAt(i);
/*  951 */         if ((escape) || (x != 'S')) {
/*  952 */           result.append(x);
/*      */         } else {
/*  954 */           result.append("{#}");
/*  955 */           this.usesMsecs = true;
/*      */         }
/*  957 */         if (x == '\'') {
/*  958 */           escape = !escape;
/*      */         }
/*      */       }
/*  961 */       return result.toString();
/*      */     }
/*      */     
/*      */     protected DateAndTimeElement(String header) {
/*  965 */       String format = header;
/*  966 */       boolean usesBegin = false;
/*  967 */       AbstractAccessLogValve.FormatType type = AbstractAccessLogValve.FormatType.CLF;
/*      */       
/*  969 */       if (format != null) {
/*  970 */         if (format.equals("begin")) {
/*  971 */           usesBegin = true;
/*  972 */           format = "";
/*  973 */         } else if (format.startsWith("begin:")) {
/*  974 */           usesBegin = true;
/*  975 */           format = format.substring(6);
/*  976 */         } else if (format.equals("end")) {
/*  977 */           usesBegin = false;
/*  978 */           format = "";
/*  979 */         } else if (format.startsWith("end:")) {
/*  980 */           usesBegin = false;
/*  981 */           format = format.substring(4);
/*      */         }
/*  983 */         if (format.length() == 0) {
/*  984 */           type = AbstractAccessLogValve.FormatType.CLF;
/*  985 */         } else if (format.equals("sec")) {
/*  986 */           type = AbstractAccessLogValve.FormatType.SEC;
/*  987 */         } else if (format.equals("msec")) {
/*  988 */           type = AbstractAccessLogValve.FormatType.MSEC;
/*  989 */         } else if (format.equals("msec_frac")) {
/*  990 */           type = AbstractAccessLogValve.FormatType.MSEC_FRAC;
/*      */         } else {
/*  992 */           type = AbstractAccessLogValve.FormatType.SDF;
/*  993 */           format = tidyFormat(format);
/*      */         }
/*      */       }
/*  996 */       this.format = format;
/*  997 */       this.usesBegin = usesBegin;
/*  998 */       this.type = type;
/*      */     }
/*      */     
/*      */ 
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/* 1004 */       long timestamp = date.getTime();
/*      */       
/* 1006 */       if (this.usesBegin) {
/* 1007 */         timestamp -= time;
/*      */       }
/* 1009 */       switch (AbstractAccessLogValve.3.$SwitchMap$org$apache$catalina$valves$AbstractAccessLogValve$FormatType[this.type.ordinal()]) {
/*      */       case 1: 
/* 1011 */         buf.append(((AbstractAccessLogValve.DateFormatCache)AbstractAccessLogValve.localDateCache.get()).getFormat(timestamp));
/* 1012 */         break;
/*      */       case 2: 
/* 1014 */         buf.append(Long.toString(timestamp / 1000L));
/* 1015 */         break;
/*      */       case 3: 
/* 1017 */         buf.append(Long.toString(timestamp));
/* 1018 */         break;
/*      */       case 4: 
/* 1020 */         long frac = timestamp % 1000L;
/* 1021 */         if (frac < 100L) {
/* 1022 */           if (frac < 10L) {
/* 1023 */             buf.append('0');
/* 1024 */             buf.append('0');
/*      */           } else {
/* 1026 */             buf.append('0');
/*      */           }
/*      */         }
/* 1029 */         buf.append(Long.toString(frac));
/* 1030 */         break;
/*      */       case 5: 
/* 1032 */         String temp = ((AbstractAccessLogValve.DateFormatCache)AbstractAccessLogValve.localDateCache.get()).getFormat(this.format, AbstractAccessLogValve.this.locale, timestamp);
/* 1033 */         if (this.usesMsecs) {
/* 1034 */           long frac = timestamp % 1000L;
/* 1035 */           StringBuilder trippleMsec = new StringBuilder(4);
/* 1036 */           if (frac < 100L) {
/* 1037 */             if (frac < 10L) {
/* 1038 */               trippleMsec.append('0');
/* 1039 */               trippleMsec.append('0');
/*      */             } else {
/* 1041 */               trippleMsec.append('0');
/*      */             }
/*      */           }
/* 1044 */           trippleMsec.append(frac);
/* 1045 */           temp = temp.replace("{#}{#}{#}", trippleMsec);
/* 1046 */           temp = temp.replace("{#}", Long.toString(frac));
/*      */         }
/* 1048 */         buf.append(temp);
/*      */       }
/*      */       
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static class RequestElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/* 1061 */       if (request != null) {
/* 1062 */         String method = request.getMethod();
/* 1063 */         if (method == null)
/*      */         {
/* 1065 */           buf.append('-');
/*      */         } else {
/* 1067 */           buf.append(request.getMethod());
/* 1068 */           buf.append(' ');
/* 1069 */           buf.append(request.getRequestURI());
/* 1070 */           if (request.getQueryString() != null) {
/* 1071 */             buf.append('?');
/* 1072 */             buf.append(request.getQueryString());
/*      */           }
/* 1074 */           buf.append(' ');
/* 1075 */           buf.append(request.getProtocol());
/*      */         }
/*      */       } else {
/* 1078 */         buf.append('-');
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static class HttpStatusCodeElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/* 1090 */       if (response != null)
/*      */       {
/* 1092 */         int status = response.getStatus();
/* 1093 */         if ((100 <= status) && (status < 1000)) {
/* 1094 */           buf.append((char)(48 + status / 100)).append((char)(48 + status / 10 % 10)).append((char)(48 + status % 10));
/*      */         }
/*      */         else
/*      */         {
/* 1098 */           buf.append(Integer.toString(status));
/*      */         }
/*      */       } else {
/* 1101 */         buf.append('-');
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected class PortElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     private static final String localPort = "local";
/*      */     
/*      */     private static final String remotePort = "remote";
/*      */     
/*      */     private final AbstractAccessLogValve.PortType portType;
/*      */     
/*      */ 
/*      */     public PortElement()
/*      */     {
/* 1120 */       this.portType = AbstractAccessLogValve.PortType.LOCAL;
/*      */     }
/*      */     
/*      */     public PortElement(String type) {
/* 1124 */       switch (type) {
/*      */       case "remote": 
/* 1126 */         this.portType = AbstractAccessLogValve.PortType.REMOTE;
/* 1127 */         break;
/*      */       case "local": 
/* 1129 */         this.portType = AbstractAccessLogValve.PortType.LOCAL;
/* 1130 */         break;
/*      */       default: 
/* 1132 */         AbstractAccessLogValve.log.error(ValveBase.sm.getString("accessLogValve.invalidPortType", new Object[] { type }));
/* 1133 */         this.portType = AbstractAccessLogValve.PortType.LOCAL;
/*      */       }
/*      */       
/*      */     }
/*      */     
/*      */ 
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/* 1141 */       if ((AbstractAccessLogValve.this.requestAttributesEnabled) && (this.portType == AbstractAccessLogValve.PortType.LOCAL)) {
/* 1142 */         Object port = request.getAttribute("org.apache.catalina.AccessLog.ServerPort");
/* 1143 */         if (port == null) {
/* 1144 */           buf.append(Integer.toString(request.getServerPort()));
/*      */         } else {
/* 1146 */           buf.append(port.toString());
/*      */         }
/*      */       }
/* 1149 */       else if (this.portType == AbstractAccessLogValve.PortType.LOCAL) {
/* 1150 */         buf.append(Integer.toString(request.getServerPort()));
/*      */       } else {
/* 1152 */         buf.append(Integer.toString(request.getRemotePort()));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static class ByteSentElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     private final boolean conversion;
/*      */     
/*      */ 
/*      */ 
/*      */     public ByteSentElement(boolean conversion)
/*      */     {
/* 1168 */       this.conversion = conversion;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/* 1176 */       long length = response.getBytesWritten(false);
/* 1177 */       if (length <= 0L)
/*      */       {
/*      */ 
/* 1180 */         Object start = request.getAttribute("org.apache.tomcat.sendfile.start");
/*      */         
/* 1182 */         if ((start instanceof Long)) {
/* 1183 */           Object end = request.getAttribute("org.apache.tomcat.sendfile.end");
/*      */           
/* 1185 */           if ((end instanceof Long)) {
/* 1186 */             length = ((Long)end).longValue() - ((Long)start).longValue();
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 1191 */       if ((length <= 0L) && (this.conversion)) {
/* 1192 */         buf.append('-');
/*      */       } else {
/* 1194 */         buf.append(Long.toString(length));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static class MethodElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/* 1206 */       if (request != null) {
/* 1207 */         buf.append(request.getMethod());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static class ElapsedTimeElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     private final boolean millis;
/*      */     
/*      */ 
/*      */ 
/*      */     public ElapsedTimeElement(boolean millis)
/*      */     {
/* 1223 */       this.millis = millis;
/*      */     }
/*      */     
/*      */ 
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/* 1229 */       if (this.millis) {
/* 1230 */         buf.append(Long.toString(time));
/*      */       }
/*      */       else {
/* 1233 */         buf.append(Long.toString(time / 1000L));
/* 1234 */         buf.append('.');
/* 1235 */         int remains = (int)(time % 1000L);
/* 1236 */         buf.append(Long.toString(remains / 100));
/* 1237 */         remains %= 100;
/* 1238 */         buf.append(Long.toString(remains / 10));
/* 1239 */         buf.append(Long.toString(remains % 10));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected static class FirstByteTimeElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/* 1250 */       long commitTime = response.getCoyoteResponse().getCommitTime();
/* 1251 */       if (commitTime == -1L) {
/* 1252 */         buf.append('-');
/*      */       } else {
/* 1254 */         long delta = commitTime - request.getCoyoteRequest().getStartTime();
/* 1255 */         buf.append(Long.toString(delta));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static class QueryElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/* 1267 */       String query = null;
/* 1268 */       if (request != null) {
/* 1269 */         query = request.getQueryString();
/*      */       }
/* 1271 */       if (query != null) {
/* 1272 */         buf.append('?');
/* 1273 */         buf.append(query);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static class SessionIdElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/* 1285 */       if (request == null) {
/* 1286 */         buf.append('-');
/*      */       } else {
/* 1288 */         Session session = request.getSessionInternal(false);
/* 1289 */         if (session == null) {
/* 1290 */           buf.append('-');
/*      */         } else {
/* 1292 */           buf.append(session.getIdInternal());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static class RequestURIElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/* 1305 */       if (request != null) {
/* 1306 */         buf.append(request.getRequestURI());
/*      */       } else {
/* 1308 */         buf.append('-');
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static class LocalServerNameElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/* 1320 */       buf.append(request.getServerName());
/*      */     }
/*      */   }
/*      */   
/*      */   protected static class StringElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     private final String str;
/*      */     
/*      */     public StringElement(String str)
/*      */     {
/* 1331 */       this.str = str;
/*      */     }
/*      */     
/*      */ 
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/* 1337 */       buf.append(this.str);
/*      */     }
/*      */   }
/*      */   
/*      */   protected static class HeaderElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     private final String header;
/*      */     
/*      */     public HeaderElement(String header)
/*      */     {
/* 1348 */       this.header = header;
/*      */     }
/*      */     
/*      */ 
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/* 1354 */       Enumeration<String> iter = request.getHeaders(this.header);
/* 1355 */       if (iter.hasMoreElements()) {
/* 1356 */         buf.append((CharSequence)iter.nextElement());
/* 1357 */         while (iter.hasMoreElements()) {
/* 1358 */           buf.append(',').append((CharSequence)iter.nextElement());
/*      */         }
/* 1360 */         return;
/*      */       }
/* 1362 */       buf.append('-');
/*      */     }
/*      */   }
/*      */   
/*      */   protected static class CookieElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     private final String header;
/*      */     
/*      */     public CookieElement(String header)
/*      */     {
/* 1373 */       this.header = header;
/*      */     }
/*      */     
/*      */ 
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/* 1379 */       String value = "-";
/* 1380 */       Cookie[] c = request.getCookies();
/* 1381 */       if (c != null) {
/* 1382 */         for (int i = 0; i < c.length; i++) {
/* 1383 */           if (this.header.equals(c[i].getName())) {
/* 1384 */             value = c[i].getValue();
/* 1385 */             break;
/*      */           }
/*      */         }
/*      */       }
/* 1389 */       buf.append(value);
/*      */     }
/*      */   }
/*      */   
/*      */   protected static class ResponseHeaderElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     private final String header;
/*      */     
/*      */     public ResponseHeaderElement(String header)
/*      */     {
/* 1400 */       this.header = header;
/*      */     }
/*      */     
/*      */ 
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/* 1406 */       if (null != response) {
/* 1407 */         Iterator<String> iter = response.getHeaders(this.header).iterator();
/* 1408 */         if (iter.hasNext()) {
/* 1409 */           buf.append((CharSequence)iter.next());
/* 1410 */           while (iter.hasNext()) {
/* 1411 */             buf.append(',').append((CharSequence)iter.next());
/*      */           }
/* 1413 */           return;
/*      */         }
/*      */       }
/* 1416 */       buf.append('-');
/*      */     }
/*      */   }
/*      */   
/*      */   protected static class RequestAttributeElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     private final String header;
/*      */     
/*      */     public RequestAttributeElement(String header)
/*      */     {
/* 1427 */       this.header = header;
/*      */     }
/*      */     
/*      */ 
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/* 1433 */       Object value = null;
/* 1434 */       if (request != null) {
/* 1435 */         value = request.getAttribute(this.header);
/*      */       } else {
/* 1437 */         value = "??";
/*      */       }
/* 1439 */       if (value != null) {
/* 1440 */         if ((value instanceof String)) {
/* 1441 */           buf.append((String)value);
/*      */         } else {
/* 1443 */           buf.append(value.toString());
/*      */         }
/*      */       } else {
/* 1446 */         buf.append('-');
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected static class SessionAttributeElement
/*      */     implements AbstractAccessLogValve.AccessLogElement
/*      */   {
/*      */     private final String header;
/*      */     
/*      */     public SessionAttributeElement(String header)
/*      */     {
/* 1458 */       this.header = header;
/*      */     }
/*      */     
/*      */ 
/*      */     public void addElement(CharArrayWriter buf, Date date, org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response, long time)
/*      */     {
/* 1464 */       Object value = null;
/* 1465 */       if (null != request) {
/* 1466 */         HttpSession sess = request.getSession(false);
/* 1467 */         if (null != sess) {
/* 1468 */           value = sess.getAttribute(this.header);
/*      */         }
/*      */       } else {
/* 1471 */         value = "??";
/*      */       }
/* 1473 */       if (value != null) {
/* 1474 */         if ((value instanceof String)) {
/* 1475 */           buf.append((String)value);
/*      */         } else {
/* 1477 */           buf.append(value.toString());
/*      */         }
/*      */       } else {
/* 1480 */         buf.append('-');
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected AccessLogElement[] createLogElements()
/*      */   {
/* 1491 */     List<AccessLogElement> list = new ArrayList();
/* 1492 */     boolean replace = false;
/* 1493 */     StringBuilder buf = new StringBuilder();
/* 1494 */     for (int i = 0; i < this.pattern.length(); i++) {
/* 1495 */       char ch = this.pattern.charAt(i);
/* 1496 */       if (replace)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1501 */         if ('{' == ch) {
/* 1502 */           StringBuilder name = new StringBuilder();
/* 1503 */           for (int j = i + 1; 
/* 1504 */               (j < this.pattern.length()) && ('}' != this.pattern.charAt(j)); j++) {
/* 1505 */             name.append(this.pattern.charAt(j));
/*      */           }
/* 1507 */           if (j + 1 < this.pattern.length())
/*      */           {
/* 1509 */             j++;
/* 1510 */             list.add(createAccessLogElement(name.toString(), this.pattern.charAt(j)));
/*      */             
/* 1512 */             i = j;
/*      */           }
/*      */           else
/*      */           {
/* 1516 */             list.add(createAccessLogElement(ch));
/*      */           }
/*      */         } else {
/* 1519 */           list.add(createAccessLogElement(ch));
/*      */         }
/* 1521 */         replace = false;
/* 1522 */       } else if (ch == '%') {
/* 1523 */         replace = true;
/* 1524 */         list.add(new StringElement(buf.toString()));
/* 1525 */         buf = new StringBuilder();
/*      */       } else {
/* 1527 */         buf.append(ch);
/*      */       }
/*      */     }
/* 1530 */     if (buf.length() > 0) {
/* 1531 */       list.add(new StringElement(buf.toString()));
/*      */     }
/* 1533 */     return (AccessLogElement[])list.toArray(new AccessLogElement[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected AccessLogElement createAccessLogElement(String name, char pattern)
/*      */   {
/* 1543 */     switch (pattern) {
/*      */     case 'i': 
/* 1545 */       return new HeaderElement(name);
/*      */     case 'c': 
/* 1547 */       return new CookieElement(name);
/*      */     case 'o': 
/* 1549 */       return new ResponseHeaderElement(name);
/*      */     case 'p': 
/* 1551 */       return new PortElement(name);
/*      */     case 'r': 
/* 1553 */       return new RequestAttributeElement(name);
/*      */     case 's': 
/* 1555 */       return new SessionAttributeElement(name);
/*      */     case 't': 
/* 1557 */       return new DateAndTimeElement(name);
/*      */     }
/* 1559 */     return new StringElement("???");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected AccessLogElement createAccessLogElement(char pattern)
/*      */   {
/* 1569 */     switch (pattern) {
/*      */     case 'a': 
/* 1571 */       return new RemoteAddrElement();
/*      */     case 'A': 
/* 1573 */       return new LocalAddrElement();
/*      */     case 'b': 
/* 1575 */       return new ByteSentElement(true);
/*      */     case 'B': 
/* 1577 */       return new ByteSentElement(false);
/*      */     case 'D': 
/* 1579 */       return new ElapsedTimeElement(true);
/*      */     case 'F': 
/* 1581 */       return new FirstByteTimeElement();
/*      */     case 'h': 
/* 1583 */       return new HostElement();
/*      */     case 'H': 
/* 1585 */       return new ProtocolElement();
/*      */     case 'l': 
/* 1587 */       return new LogicalUserNameElement();
/*      */     case 'm': 
/* 1589 */       return new MethodElement();
/*      */     case 'p': 
/* 1591 */       return new PortElement();
/*      */     case 'q': 
/* 1593 */       return new QueryElement();
/*      */     case 'r': 
/* 1595 */       return new RequestElement();
/*      */     case 's': 
/* 1597 */       return new HttpStatusCodeElement();
/*      */     case 'S': 
/* 1599 */       return new SessionIdElement();
/*      */     case 't': 
/* 1601 */       return new DateAndTimeElement();
/*      */     case 'T': 
/* 1603 */       return new ElapsedTimeElement(false);
/*      */     case 'u': 
/* 1605 */       return new UserElement();
/*      */     case 'U': 
/* 1607 */       return new RequestURIElement();
/*      */     case 'v': 
/* 1609 */       return new LocalServerNameElement();
/*      */     case 'I': 
/* 1611 */       return new ThreadNameElement();
/*      */     }
/* 1613 */     return new StringElement("???" + pattern + "???");
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\valves\AbstractAccessLogValve.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */