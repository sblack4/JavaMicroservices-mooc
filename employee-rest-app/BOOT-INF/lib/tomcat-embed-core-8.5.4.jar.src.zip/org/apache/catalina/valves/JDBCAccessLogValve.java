/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Driver;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Date;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.catalina.AccessLog;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JDBCAccessLogValve
/*     */   extends ValveBase
/*     */   implements AccessLog
/*     */ {
/*     */   public JDBCAccessLogValve()
/*     */   {
/* 140 */     super(true);
/* 141 */     this.driverName = null;
/* 142 */     this.connectionURL = null;
/* 143 */     this.tableName = "access";
/* 144 */     this.remoteHostField = "remoteHost";
/* 145 */     this.userField = "userName";
/* 146 */     this.timestampField = "timestamp";
/* 147 */     this.virtualHostField = "virtualHost";
/* 148 */     this.methodField = "method";
/* 149 */     this.queryField = "query";
/* 150 */     this.statusField = "status";
/* 151 */     this.bytesField = "bytes";
/* 152 */     this.refererField = "referer";
/* 153 */     this.userAgentField = "userAgent";
/* 154 */     this.pattern = "common";
/* 155 */     this.resolveHosts = false;
/* 156 */     this.conn = null;
/* 157 */     this.ps = null;
/* 158 */     this.currentTimeMillis = new Date().getTime();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 168 */   boolean useLongContentLength = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 173 */   String connectionName = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 179 */   String connectionPassword = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 184 */   Driver driver = null;
/*     */   
/*     */   private String driverName;
/*     */   
/*     */   private String connectionURL;
/*     */   
/*     */   private String tableName;
/*     */   
/*     */   private String remoteHostField;
/*     */   
/*     */   private String userField;
/*     */   
/*     */   private String timestampField;
/*     */   
/*     */   private String virtualHostField;
/*     */   
/*     */   private String methodField;
/*     */   
/*     */   private String queryField;
/*     */   
/*     */   private String statusField;
/*     */   private String bytesField;
/*     */   private String refererField;
/*     */   private String userAgentField;
/*     */   private String pattern;
/*     */   private boolean resolveHosts;
/*     */   private Connection conn;
/*     */   private PreparedStatement ps;
/*     */   private long currentTimeMillis;
/* 213 */   boolean requestAttributesEnabled = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRequestAttributesEnabled(boolean requestAttributesEnabled)
/*     */   {
/* 223 */     this.requestAttributesEnabled = requestAttributesEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getRequestAttributesEnabled()
/*     */   {
/* 231 */     return this.requestAttributesEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getConnectionName()
/*     */   {
/* 238 */     return this.connectionName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectionName(String connectionName)
/*     */   {
/* 247 */     this.connectionName = connectionName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDriverName(String driverName)
/*     */   {
/* 256 */     this.driverName = driverName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getConnectionPassword()
/*     */   {
/* 263 */     return this.connectionPassword;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectionPassword(String connectionPassword)
/*     */   {
/* 272 */     this.connectionPassword = connectionPassword;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectionURL(String connectionURL)
/*     */   {
/* 281 */     this.connectionURL = connectionURL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTableName(String tableName)
/*     */   {
/* 291 */     this.tableName = tableName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemoteHostField(String remoteHostField)
/*     */   {
/* 301 */     this.remoteHostField = remoteHostField;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserField(String userField)
/*     */   {
/* 311 */     this.userField = userField;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimestampField(String timestampField)
/*     */   {
/* 321 */     this.timestampField = timestampField;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVirtualHostField(String virtualHostField)
/*     */   {
/* 332 */     this.virtualHostField = virtualHostField;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMethodField(String methodField)
/*     */   {
/* 342 */     this.methodField = methodField;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setQueryField(String queryField)
/*     */   {
/* 353 */     this.queryField = queryField;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStatusField(String statusField)
/*     */   {
/* 363 */     this.statusField = statusField;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBytesField(String bytesField)
/*     */   {
/* 373 */     this.bytesField = bytesField;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRefererField(String refererField)
/*     */   {
/* 383 */     this.refererField = refererField;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserAgentField(String userAgentField)
/*     */   {
/* 393 */     this.userAgentField = userAgentField;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPattern(String pattern)
/*     */   {
/* 406 */     this.pattern = pattern;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResolveHosts(String resolveHosts)
/*     */   {
/* 417 */     this.resolveHosts = Boolean.parseBoolean(resolveHosts);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getUseLongContentLength()
/*     */   {
/* 425 */     return this.useLongContentLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setUseLongContentLength(boolean useLongContentLength)
/*     */   {
/* 432 */     this.useLongContentLength = useLongContentLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void invoke(Request request, Response response)
/*     */     throws IOException, ServletException
/*     */   {
/* 451 */     getNext().invoke(request, response);
/*     */   }
/*     */   
/*     */ 
/*     */   public void log(Request request, Response response, long time)
/*     */   {
/* 457 */     if (!getState().isAvailable()) {
/* 458 */       return;
/*     */     }
/*     */     
/* 461 */     String EMPTY = "";
/*     */     String remoteHost;
/*     */     String remoteHost;
/* 464 */     if (this.resolveHosts) { String remoteHost;
/* 465 */       if (this.requestAttributesEnabled) {
/* 466 */         Object host = request.getAttribute("org.apache.catalina.AccessLog.RemoteHost");
/* 467 */         String remoteHost; if (host == null) {
/* 468 */           remoteHost = request.getRemoteHost();
/*     */         } else {
/* 470 */           remoteHost = (String)host;
/*     */         }
/*     */       } else {
/* 473 */         remoteHost = request.getRemoteHost();
/*     */       }
/*     */     } else { String remoteHost;
/* 476 */       if (this.requestAttributesEnabled) {
/* 477 */         Object addr = request.getAttribute("org.apache.catalina.AccessLog.RemoteAddr");
/* 478 */         String remoteHost; if (addr == null) {
/* 479 */           remoteHost = request.getRemoteAddr();
/*     */         } else {
/* 481 */           remoteHost = (String)addr;
/*     */         }
/*     */       } else {
/* 484 */         remoteHost = request.getRemoteAddr();
/*     */       }
/*     */     }
/* 487 */     String user = request.getRemoteUser();
/* 488 */     String query = request.getRequestURI();
/*     */     
/* 490 */     long bytes = response.getBytesWritten(true);
/* 491 */     if (bytes < 0L) {
/* 492 */       bytes = 0L;
/*     */     }
/* 494 */     int status = response.getStatus();
/* 495 */     String virtualHost = "";
/* 496 */     String method = "";
/* 497 */     String referer = "";
/* 498 */     String userAgent = "";
/* 499 */     String logPattern = this.pattern;
/* 500 */     if (logPattern.equals("combined")) {
/* 501 */       virtualHost = request.getServerName();
/* 502 */       method = request.getMethod();
/* 503 */       referer = request.getHeader("referer");
/* 504 */       userAgent = request.getHeader("user-agent");
/*     */     }
/* 506 */     synchronized (this) {
/* 507 */       int numberOfTries = 2;
/* 508 */       while (numberOfTries > 0) {
/*     */         try {
/* 510 */           open();
/*     */           
/* 512 */           this.ps.setString(1, remoteHost);
/* 513 */           this.ps.setString(2, user);
/* 514 */           this.ps.setTimestamp(3, new Timestamp(getCurrentTimeMillis()));
/* 515 */           this.ps.setString(4, query);
/* 516 */           this.ps.setInt(5, status);
/*     */           
/* 518 */           if (this.useLongContentLength) {
/* 519 */             this.ps.setLong(6, bytes);
/*     */           } else {
/* 521 */             if (bytes > 2147483647L) {
/* 522 */               bytes = -1L;
/*     */             }
/* 524 */             this.ps.setInt(6, (int)bytes);
/*     */           }
/* 526 */           if (logPattern.equals("combined")) {
/* 527 */             this.ps.setString(7, virtualHost);
/* 528 */             this.ps.setString(8, method);
/* 529 */             this.ps.setString(9, referer);
/* 530 */             this.ps.setString(10, userAgent);
/*     */           }
/* 532 */           this.ps.executeUpdate();
/* 533 */           return;
/*     */         }
/*     */         catch (SQLException e) {
/* 536 */           this.container.getLogger().error(sm.getString("jdbcAccessLogValve.exception"), e);
/*     */           
/*     */ 
/* 539 */           if (this.conn != null) {
/* 540 */             close();
/*     */           }
/*     */         }
/* 543 */         numberOfTries--;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void open()
/*     */     throws SQLException
/*     */   {
/* 559 */     if (this.conn != null) {
/* 560 */       return;
/*     */     }
/*     */     
/*     */ 
/* 564 */     if (this.driver == null) {
/*     */       try {
/* 566 */         Class<?> clazz = Class.forName(this.driverName);
/* 567 */         this.driver = ((Driver)clazz.newInstance());
/*     */       } catch (Throwable e) {
/* 569 */         ExceptionUtils.handleThrowable(e);
/* 570 */         throw new SQLException(e.getMessage(), e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 575 */     Properties props = new Properties();
/* 576 */     if (this.connectionName != null) {
/* 577 */       props.put("user", this.connectionName);
/*     */     }
/* 579 */     if (this.connectionPassword != null) {
/* 580 */       props.put("password", this.connectionPassword);
/*     */     }
/* 582 */     this.conn = this.driver.connect(this.connectionURL, props);
/* 583 */     this.conn.setAutoCommit(true);
/* 584 */     String logPattern = this.pattern;
/* 585 */     if (logPattern.equals("common")) {
/* 586 */       this.ps = this.conn.prepareStatement("INSERT INTO " + this.tableName + " (" + this.remoteHostField + ", " + this.userField + ", " + this.timestampField + ", " + this.queryField + ", " + this.statusField + ", " + this.bytesField + ") VALUES(?, ?, ?, ?, ?, ?)");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/* 592 */     else if (logPattern.equals("combined")) {
/* 593 */       this.ps = this.conn.prepareStatement("INSERT INTO " + this.tableName + " (" + this.remoteHostField + ", " + this.userField + ", " + this.timestampField + ", " + this.queryField + ", " + this.statusField + ", " + this.bytesField + ", " + this.virtualHostField + ", " + this.methodField + ", " + this.refererField + ", " + this.userAgentField + ") VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void close()
/*     */   {
/* 610 */     if (this.conn == null) {
/* 611 */       return;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 616 */       this.ps.close();
/*     */     } catch (Throwable f) {
/* 618 */       ExceptionUtils.handleThrowable(f);
/*     */     }
/* 620 */     this.ps = null;
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 626 */       this.conn.close();
/*     */     } catch (SQLException e) {
/* 628 */       this.container.getLogger().error(sm.getString("jdbcAccessLogValve.close"), e);
/*     */     } finally {
/* 630 */       this.conn = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void startInternal()
/*     */     throws LifecycleException
/*     */   {
/*     */     try
/*     */     {
/* 647 */       open();
/*     */     } catch (SQLException e) {
/* 649 */       throw new LifecycleException(e);
/*     */     }
/*     */     
/* 652 */     setState(LifecycleState.STARTING);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void stopInternal()
/*     */     throws LifecycleException
/*     */   {
/* 666 */     setState(LifecycleState.STOPPING);
/*     */     
/* 668 */     close();
/*     */   }
/*     */   
/*     */   public long getCurrentTimeMillis()
/*     */   {
/* 673 */     long systime = System.currentTimeMillis();
/* 674 */     if (systime - this.currentTimeMillis > 1000L) {
/* 675 */       this.currentTimeMillis = new Date(systime).getTime();
/*     */     }
/* 677 */     return this.currentTimeMillis;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\valves\JDBCAccessLogValve.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */