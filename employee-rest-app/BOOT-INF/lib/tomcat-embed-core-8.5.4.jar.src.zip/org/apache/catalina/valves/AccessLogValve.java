/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.CharArrayWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.buf.B2CConverter;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AccessLogValve
/*     */   extends AbstractAccessLogValve
/*     */ {
/*  65 */   private static final Log log = LogFactory.getLog(AccessLogValve.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */   private volatile String dateStamp = "";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */   private String directory = "logs";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  90 */   protected String prefix = "access_log";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */   protected boolean rotatable = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */   protected boolean renameOnRotate = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 108 */   private boolean buffered = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 114 */   protected String suffix = "";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 120 */   protected PrintWriter writer = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 127 */   protected SimpleDateFormat fileDateFormatter = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 134 */   protected File currentLogFile = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 139 */   private volatile long rotationLastChecked = 0L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 145 */   private boolean checkExists = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 150 */   protected String fileDateFormat = ".yyyy-MM-dd";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 157 */   protected String encoding = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDirectory()
/*     */   {
/* 166 */     return this.directory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDirectory(String directory)
/*     */   {
/* 176 */     this.directory = directory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCheckExists()
/*     */   {
/* 185 */     return this.checkExists;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCheckExists(boolean checkExists)
/*     */   {
/* 197 */     this.checkExists = checkExists;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPrefix()
/*     */   {
/* 206 */     return this.prefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPrefix(String prefix)
/*     */   {
/* 216 */     this.prefix = prefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRotatable()
/*     */   {
/* 225 */     return this.rotatable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRotatable(boolean rotatable)
/*     */   {
/* 235 */     this.rotatable = rotatable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRenameOnRotate()
/*     */   {
/* 246 */     return this.renameOnRotate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRenameOnRotate(boolean renameOnRotate)
/*     */   {
/* 257 */     this.renameOnRotate = renameOnRotate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBuffered()
/*     */   {
/* 266 */     return this.buffered;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBuffered(boolean buffered)
/*     */   {
/* 276 */     this.buffered = buffered;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSuffix()
/*     */   {
/* 284 */     return this.suffix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSuffix(String suffix)
/*     */   {
/* 294 */     this.suffix = suffix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getFileDateFormat()
/*     */   {
/* 301 */     return this.fileDateFormat;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setFileDateFormat(String fileDateFormat)
/*     */   {
/*     */     String newFormat;
/*     */     
/*     */     String newFormat;
/*     */     
/* 311 */     if (fileDateFormat == null) {
/* 312 */       newFormat = "";
/*     */     } else {
/* 314 */       newFormat = fileDateFormat;
/*     */     }
/* 316 */     this.fileDateFormat = newFormat;
/*     */     
/* 318 */     synchronized (this) {
/* 319 */       this.fileDateFormatter = new SimpleDateFormat(newFormat, Locale.US);
/* 320 */       this.fileDateFormatter.setTimeZone(TimeZone.getDefault());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getEncoding()
/*     */   {
/* 331 */     return this.encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEncoding(String encoding)
/*     */   {
/* 340 */     if ((encoding != null) && (encoding.length() > 0)) {
/* 341 */       this.encoding = encoding;
/*     */     } else {
/* 343 */       this.encoding = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void backgroundProcess()
/*     */   {
/* 356 */     if ((getState().isAvailable()) && (getEnabled()) && (this.writer != null) && (this.buffered))
/*     */     {
/* 358 */       this.writer.flush();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void rotate()
/*     */   {
/* 366 */     if (this.rotatable)
/*     */     {
/* 368 */       long systime = System.currentTimeMillis();
/* 369 */       if (systime - this.rotationLastChecked > 1000L) {
/* 370 */         synchronized (this) {
/* 371 */           if (systime - this.rotationLastChecked > 1000L) {
/* 372 */             this.rotationLastChecked = systime;
/*     */             
/*     */ 
/*     */ 
/* 376 */             String tsDate = this.fileDateFormatter.format(new Date(systime));
/*     */             
/*     */ 
/* 379 */             if (!this.dateStamp.equals(tsDate)) {
/* 380 */               close(true);
/* 381 */               this.dateStamp = tsDate;
/* 382 */               open();
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean rotate(String newFileName)
/*     */   {
/* 400 */     if (this.currentLogFile != null) {
/* 401 */       File holder = this.currentLogFile;
/* 402 */       close(false);
/*     */       try {
/* 404 */         holder.renameTo(new File(newFileName));
/*     */       } catch (Throwable e) {
/* 406 */         ExceptionUtils.handleThrowable(e);
/* 407 */         log.error(sm.getString("accessLogValve.rotateFail"), e);
/*     */       }
/*     */       
/*     */ 
/* 411 */       this.dateStamp = this.fileDateFormatter.format(new Date(System.currentTimeMillis()));
/*     */       
/*     */ 
/* 414 */       open();
/* 415 */       return true;
/*     */     }
/* 417 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private File getLogFile(boolean useDateStamp)
/*     */   {
/* 436 */     File dir = new File(this.directory);
/* 437 */     if (!dir.isAbsolute()) {
/* 438 */       dir = new File(getContainer().getCatalinaBase(), this.directory);
/*     */     }
/* 440 */     if ((!dir.mkdirs()) && (!dir.isDirectory())) {
/* 441 */       log.error(sm.getString("accessLogValve.openDirFail", new Object[] { dir }));
/*     */     }
/*     */     
/*     */     File pathname;
/*     */     File pathname;
/* 446 */     if (useDateStamp) {
/* 447 */       pathname = new File(dir.getAbsoluteFile(), this.prefix + this.dateStamp + this.suffix);
/*     */     }
/*     */     else {
/* 450 */       pathname = new File(dir.getAbsoluteFile(), this.prefix + this.suffix);
/*     */     }
/* 452 */     File parent = pathname.getParentFile();
/* 453 */     if ((!parent.mkdirs()) && (!parent.isDirectory())) {
/* 454 */       log.error(sm.getString("accessLogValve.openDirFail", new Object[] { parent }));
/*     */     }
/* 456 */     return pathname;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void restore()
/*     */   {
/* 465 */     File newLogFile = getLogFile(false);
/* 466 */     File rotatedLogFile = getLogFile(true);
/* 467 */     if ((rotatedLogFile.exists()) && (!newLogFile.exists()) && (!rotatedLogFile.equals(newLogFile))) {
/*     */       try
/*     */       {
/* 470 */         if (!rotatedLogFile.renameTo(newLogFile)) {
/* 471 */           log.error(sm.getString("accessLogValve.renameFail", new Object[] { rotatedLogFile, newLogFile }));
/*     */         }
/*     */       } catch (Throwable e) {
/* 474 */         ExceptionUtils.handleThrowable(e);
/* 475 */         log.error(sm.getString("accessLogValve.renameFail", new Object[] { rotatedLogFile, newLogFile }), e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void close(boolean rename)
/*     */   {
/* 487 */     if (this.writer == null) {
/* 488 */       return;
/*     */     }
/* 490 */     this.writer.flush();
/* 491 */     this.writer.close();
/* 492 */     if ((rename) && (this.renameOnRotate)) {
/* 493 */       File newLogFile = getLogFile(true);
/* 494 */       if (!newLogFile.exists()) {
/*     */         try {
/* 496 */           if (!this.currentLogFile.renameTo(newLogFile)) {
/* 497 */             log.error(sm.getString("accessLogValve.renameFail", new Object[] { this.currentLogFile, newLogFile }));
/*     */           }
/*     */         } catch (Throwable e) {
/* 500 */           ExceptionUtils.handleThrowable(e);
/* 501 */           log.error(sm.getString("accessLogValve.renameFail", new Object[] { this.currentLogFile, newLogFile }), e);
/*     */         }
/*     */       } else {
/* 504 */         log.error(sm.getString("accessLogValve.alreadyExists", new Object[] { this.currentLogFile, newLogFile }));
/*     */       }
/*     */     }
/* 507 */     this.writer = null;
/* 508 */     this.dateStamp = "";
/* 509 */     this.currentLogFile = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void log(CharArrayWriter message)
/*     */   {
/* 522 */     rotate();
/*     */     
/*     */ 
/* 525 */     if (this.checkExists) {
/* 526 */       synchronized (this) {
/* 527 */         if ((this.currentLogFile != null) && (!this.currentLogFile.exists())) {
/*     */           try {
/* 529 */             close(false);
/*     */           } catch (Throwable e) {
/* 531 */             ExceptionUtils.handleThrowable(e);
/* 532 */             log.info(sm.getString("accessLogValve.closeFail"), e);
/*     */           }
/*     */           
/*     */ 
/* 536 */           this.dateStamp = this.fileDateFormatter.format(new Date(System.currentTimeMillis()));
/*     */           
/*     */ 
/* 539 */           open();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 546 */       synchronized (this) {
/* 547 */         if (this.writer != null) {
/* 548 */           message.writeTo(this.writer);
/* 549 */           this.writer.println("");
/* 550 */           if (!this.buffered) {
/* 551 */             this.writer.flush();
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (IOException ioe) {
/* 556 */       log.warn(sm.getString("accessLogValve.writeFail", new Object[] { message.toString() }), ioe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void open()
/*     */   {
/* 568 */     File pathname = getLogFile((this.rotatable) && (!this.renameOnRotate));
/*     */     
/* 570 */     Charset charset = null;
/* 571 */     if (this.encoding != null) {
/*     */       try {
/* 573 */         charset = B2CConverter.getCharset(this.encoding);
/*     */       } catch (UnsupportedEncodingException ex) {
/* 575 */         log.error(sm.getString("accessLogValve.unsupportedEncoding", new Object[] { this.encoding }), ex);
/*     */       }
/*     */     }
/*     */     
/* 579 */     if (charset == null) {
/* 580 */       charset = StandardCharsets.ISO_8859_1;
/*     */     }
/*     */     try
/*     */     {
/* 584 */       this.writer = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(pathname, true), charset), 128000), false);
/*     */       
/*     */ 
/*     */ 
/* 588 */       this.currentLogFile = pathname;
/*     */     } catch (IOException e) {
/* 590 */       this.writer = null;
/* 591 */       this.currentLogFile = null;
/* 592 */       log.error(sm.getString("accessLogValve.openFail", new Object[] { pathname }), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 607 */     String format = getFileDateFormat();
/* 608 */     this.fileDateFormatter = new SimpleDateFormat(format, Locale.US);
/* 609 */     this.fileDateFormatter.setTimeZone(TimeZone.getDefault());
/* 610 */     this.dateStamp = this.fileDateFormatter.format(new Date(System.currentTimeMillis()));
/* 611 */     if ((this.rotatable) && (this.renameOnRotate)) {
/* 612 */       restore();
/*     */     }
/* 614 */     open();
/*     */     
/* 616 */     super.startInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void stopInternal()
/*     */     throws LifecycleException
/*     */   {
/* 630 */     super.stopInternal();
/* 631 */     close(false);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\valves\AccessLogValve.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */