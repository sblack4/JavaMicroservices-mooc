/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.http.HttpSessionBindingEvent;
/*     */ import javax.servlet.http.HttpSessionBindingListener;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CrawlerSessionManagerValve
/*     */   extends ValveBase
/*     */   implements HttpSessionBindingListener
/*     */ {
/*  46 */   private static final Log log = LogFactory.getLog(CrawlerSessionManagerValve.class);
/*     */   
/*     */ 
/*  49 */   private final Map<String, String> clientIpSessionId = new ConcurrentHashMap();
/*     */   
/*  51 */   private final Map<String, String> sessionIdClientIp = new ConcurrentHashMap();
/*     */   
/*     */ 
/*  54 */   private String crawlerUserAgents = ".*[bB]ot.*|.*Yahoo! Slurp.*|.*Feedfetcher-Google.*";
/*     */   
/*  56 */   private Pattern uaPattern = null;
/*  57 */   private int sessionInactiveInterval = 60;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CrawlerSessionManagerValve()
/*     */   {
/*  64 */     super(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCrawlerUserAgents(String crawlerUserAgents)
/*     */   {
/*  76 */     this.crawlerUserAgents = crawlerUserAgents;
/*  77 */     if ((crawlerUserAgents == null) || (crawlerUserAgents.length() == 0)) {
/*  78 */       this.uaPattern = null;
/*     */     } else {
/*  80 */       this.uaPattern = Pattern.compile(crawlerUserAgents);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCrawlerUserAgents()
/*     */   {
/*  89 */     return this.crawlerUserAgents;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSessionInactiveInterval(int sessionInactiveInterval)
/*     */   {
/* 100 */     this.sessionInactiveInterval = sessionInactiveInterval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSessionInactiveInterval()
/*     */   {
/* 108 */     return this.sessionInactiveInterval;
/*     */   }
/*     */   
/*     */   public Map<String, String> getClientIpSessionId()
/*     */   {
/* 113 */     return this.clientIpSessionId;
/*     */   }
/*     */   
/*     */   protected void initInternal()
/*     */     throws LifecycleException
/*     */   {
/* 119 */     super.initInternal();
/*     */     
/* 121 */     this.uaPattern = Pattern.compile(this.crawlerUserAgents);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void invoke(Request request, Response response)
/*     */     throws IOException, ServletException
/*     */   {
/* 129 */     boolean isBot = false;
/* 130 */     String sessionId = null;
/* 131 */     String clientIp = null;
/*     */     
/* 133 */     if (log.isDebugEnabled()) {
/* 134 */       log.debug(request.hashCode() + ": ClientIp=" + request.getRemoteAddr() + ", RequestedSessionId=" + request.getRequestedSessionId());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 140 */     if (request.getSession(false) == null)
/*     */     {
/*     */ 
/* 143 */       Enumeration<String> uaHeaders = request.getHeaders("user-agent");
/* 144 */       String uaHeader = null;
/* 145 */       if (uaHeaders.hasMoreElements()) {
/* 146 */         uaHeader = (String)uaHeaders.nextElement();
/*     */       }
/*     */       
/*     */ 
/* 150 */       if ((uaHeader != null) && (!uaHeaders.hasMoreElements()))
/*     */       {
/* 152 */         if (log.isDebugEnabled()) {
/* 153 */           log.debug(request.hashCode() + ": UserAgent=" + uaHeader);
/*     */         }
/*     */         
/* 156 */         if (this.uaPattern.matcher(uaHeader).matches()) {
/* 157 */           isBot = true;
/*     */           
/* 159 */           if (log.isDebugEnabled()) {
/* 160 */             log.debug(request.hashCode() + ": Bot found. UserAgent=" + uaHeader);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 167 */       if (isBot) {
/* 168 */         clientIp = request.getRemoteAddr();
/* 169 */         sessionId = (String)this.clientIpSessionId.get(clientIp);
/* 170 */         if (sessionId != null) {
/* 171 */           request.setRequestedSessionId(sessionId);
/* 172 */           if (log.isDebugEnabled()) {
/* 173 */             log.debug(request.hashCode() + ": SessionID=" + sessionId);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 180 */     getNext().invoke(request, response);
/*     */     
/* 182 */     if (isBot) {
/* 183 */       if (sessionId == null)
/*     */       {
/* 185 */         HttpSession s = request.getSession(false);
/* 186 */         if (s != null) {
/* 187 */           this.clientIpSessionId.put(clientIp, s.getId());
/* 188 */           this.sessionIdClientIp.put(s.getId(), clientIp);
/*     */           
/* 190 */           s.setAttribute(getClass().getName(), this);
/* 191 */           s.setMaxInactiveInterval(this.sessionInactiveInterval);
/*     */           
/* 193 */           if (log.isDebugEnabled()) {
/* 194 */             log.debug(request.hashCode() + ": New bot session. SessionID=" + s.getId());
/*     */           }
/*     */           
/*     */         }
/*     */       }
/* 199 */       else if (log.isDebugEnabled()) {
/* 200 */         log.debug(request.hashCode() + ": Bot session accessed. SessionID=" + sessionId);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void valueBound(HttpSessionBindingEvent event) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void valueUnbound(HttpSessionBindingEvent event)
/*     */   {
/* 216 */     String clientIp = (String)this.sessionIdClientIp.remove(event.getSession().getId());
/* 217 */     if (clientIp != null) {
/* 218 */       this.clientIpSessionId.remove(clientIp);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\valves\CrawlerSessionManagerValve.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */