/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SSLValve
/*     */   extends ValveBase
/*     */ {
/*  65 */   private static final Log log = LogFactory.getLog(SSLValve.class);
/*     */   
/*  67 */   private String sslClientCertHeader = "ssl_client_cert";
/*  68 */   private String sslCipherHeader = "ssl_cipher";
/*  69 */   private String sslSessionIdHeader = "ssl_session_id";
/*  70 */   private String sslCipherUserKeySizeHeader = "ssl_cipher_usekeysize";
/*     */   
/*     */   public SSLValve()
/*     */   {
/*  74 */     super(true);
/*     */   }
/*     */   
/*     */   public String getSslClientCertHeader()
/*     */   {
/*  79 */     return this.sslClientCertHeader;
/*     */   }
/*     */   
/*     */   public void setSslClientCertHeader(String sslClientCertHeader) {
/*  83 */     this.sslClientCertHeader = sslClientCertHeader;
/*     */   }
/*     */   
/*     */   public String getSslCipherHeader() {
/*  87 */     return this.sslCipherHeader;
/*     */   }
/*     */   
/*     */   public void setSslCipherHeader(String sslCipherHeader) {
/*  91 */     this.sslCipherHeader = sslCipherHeader;
/*     */   }
/*     */   
/*     */   public String getSslSessionIdHeader() {
/*  95 */     return this.sslSessionIdHeader;
/*     */   }
/*     */   
/*     */   public void setSslSessionIdHeader(String sslSessionIdHeader) {
/*  99 */     this.sslSessionIdHeader = sslSessionIdHeader;
/*     */   }
/*     */   
/*     */   public String getSslCipherUserKeySizeHeader() {
/* 103 */     return this.sslCipherUserKeySizeHeader;
/*     */   }
/*     */   
/*     */   public void setSslCipherUserKeySizeHeader(String sslCipherUserKeySizeHeader) {
/* 107 */     this.sslCipherUserKeySizeHeader = sslCipherUserKeySizeHeader;
/*     */   }
/*     */   
/*     */   public String mygetHeader(Request request, String header)
/*     */   {
/* 112 */     String strcert0 = request.getHeader(header);
/* 113 */     if (strcert0 == null) {
/* 114 */       return null;
/*     */     }
/*     */     
/* 117 */     if ("(null)".equals(strcert0)) {
/* 118 */       return null;
/*     */     }
/* 120 */     return strcert0;
/*     */   }
/*     */   
/*     */ 
/*     */   public void invoke(Request request, Response response)
/*     */     throws IOException, ServletException
/*     */   {
/* 127 */     String strcert0 = mygetHeader(request, this.sslClientCertHeader);
/* 128 */     if ((strcert0 != null) && (strcert0.length() > 28)) {
/* 129 */       String strcert1 = strcert0.replace(' ', '\n');
/* 130 */       String strcert2 = strcert1.substring(28, strcert1.length() - 26);
/* 131 */       String strcert3 = "-----BEGIN CERTIFICATE-----\n";
/* 132 */       String strcert4 = strcert3.concat(strcert2);
/* 133 */       String strcerts = strcert4.concat("\n-----END CERTIFICATE-----\n");
/*     */       
/* 135 */       ByteArrayInputStream bais = new ByteArrayInputStream(strcerts.getBytes(StandardCharsets.ISO_8859_1));
/*     */       
/* 137 */       X509Certificate[] jsseCerts = null;
/* 138 */       String providerName = (String)request.getConnector().getProperty("clientCertProvider");
/*     */       try {
/*     */         CertificateFactory cf;
/*     */         CertificateFactory cf;
/* 142 */         if (providerName == null) {
/* 143 */           cf = CertificateFactory.getInstance("X.509");
/*     */         } else {
/* 145 */           cf = CertificateFactory.getInstance("X.509", providerName);
/*     */         }
/* 147 */         X509Certificate cert = (X509Certificate)cf.generateCertificate(bais);
/* 148 */         jsseCerts = new X509Certificate[1];
/* 149 */         jsseCerts[0] = cert;
/*     */       } catch (CertificateException e) {
/* 151 */         log.warn(sm.getString("sslValve.certError", new Object[] { strcerts }), e);
/*     */       } catch (NoSuchProviderException e) {
/* 153 */         log.error(sm.getString("sslValve.invalidProvider", new Object[] { providerName }), e);
/*     */       }
/*     */       
/* 156 */       request.setAttribute("javax.servlet.request.X509Certificate", jsseCerts);
/*     */     }
/* 158 */     strcert0 = mygetHeader(request, this.sslCipherHeader);
/* 159 */     if (strcert0 != null) {
/* 160 */       request.setAttribute("javax.servlet.request.cipher_suite", strcert0);
/*     */     }
/* 162 */     strcert0 = mygetHeader(request, this.sslSessionIdHeader);
/* 163 */     if (strcert0 != null) {
/* 164 */       request.setAttribute("javax.servlet.request.ssl_session_id", strcert0);
/*     */     }
/* 166 */     strcert0 = mygetHeader(request, this.sslCipherUserKeySizeHeader);
/* 167 */     if (strcert0 != null) {
/* 168 */       request.setAttribute("javax.servlet.request.key_size", Integer.valueOf(strcert0));
/*     */     }
/*     */     
/* 171 */     getNext().invoke(request, response);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\valves\SSLValve.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */