/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.http.MimeHeaders;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RequestFilterValve
/*     */   extends ValveBase
/*     */ {
/*     */   public RequestFilterValve()
/*     */   {
/*  71 */     super(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */   protected volatile Pattern allow = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  87 */   protected volatile String allowValue = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */   protected volatile boolean allowValid = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */   protected volatile Pattern deny = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 109 */   protected volatile String denyValue = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 118 */   protected volatile boolean denyValid = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */   protected int denyStatus = 403;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 133 */   private boolean invalidAuthenticationWhenDeny = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAllow()
/*     */   {
/* 144 */     return this.allowValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAllow(String allow)
/*     */   {
/* 155 */     if ((allow == null) || (allow.length() == 0)) {
/* 156 */       this.allow = null;
/* 157 */       this.allowValue = null;
/* 158 */       this.allowValid = true;
/*     */     } else {
/* 160 */       boolean success = false;
/*     */       try {
/* 162 */         this.allowValue = allow;
/* 163 */         this.allow = Pattern.compile(allow);
/* 164 */         success = true;
/*     */       } finally {
/* 166 */         this.allowValid = success;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDeny()
/*     */   {
/* 178 */     return this.denyValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDeny(String deny)
/*     */   {
/* 189 */     if ((deny == null) || (deny.length() == 0)) {
/* 190 */       this.deny = null;
/* 191 */       this.denyValue = null;
/* 192 */       this.denyValid = true;
/*     */     } else {
/* 194 */       boolean success = false;
/*     */       try {
/* 196 */         this.denyValue = deny;
/* 197 */         this.deny = Pattern.compile(deny);
/* 198 */         success = true;
/*     */       } finally {
/* 200 */         this.denyValid = success;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isAllowValid()
/*     */   {
/* 213 */     return this.allowValid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isDenyValid()
/*     */   {
/* 224 */     return this.denyValid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDenyStatus()
/*     */   {
/* 232 */     return this.denyStatus;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDenyStatus(int denyStatus)
/*     */   {
/* 241 */     this.denyStatus = denyStatus;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getInvalidAuthenticationWhenDeny()
/*     */   {
/* 249 */     return this.invalidAuthenticationWhenDeny;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInvalidAuthenticationWhenDeny(boolean value)
/*     */   {
/* 258 */     this.invalidAuthenticationWhenDeny = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void invoke(org.apache.catalina.connector.Request paramRequest, Response paramResponse)
/*     */     throws IOException, ServletException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initInternal()
/*     */     throws LifecycleException
/*     */   {
/* 286 */     super.initInternal();
/* 287 */     if ((!this.allowValid) || (!this.denyValid)) {
/* 288 */       throw new LifecycleException(sm.getString("requestFilterValve.configInvalid"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected synchronized void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 296 */     if ((!this.allowValid) || (!this.denyValid)) {
/* 297 */       throw new LifecycleException(sm.getString("requestFilterValve.configInvalid"));
/*     */     }
/*     */     
/* 300 */     super.startInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void process(String property, org.apache.catalina.connector.Request request, Response response)
/*     */     throws IOException, ServletException
/*     */   {
/* 318 */     if (isAllowed(property)) {
/* 319 */       getNext().invoke(request, response);
/* 320 */       return;
/*     */     }
/*     */     
/* 323 */     if (getLog().isDebugEnabled()) {
/* 324 */       getLog().debug(sm.getString("requestFilterValve.deny", new Object[] { request.getRequestURI(), property }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 329 */     denyRequest(request, response);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract Log getLog();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void denyRequest(org.apache.catalina.connector.Request request, Response response)
/*     */     throws IOException, ServletException
/*     */   {
/* 349 */     if (this.invalidAuthenticationWhenDeny) {
/* 350 */       Context context = request.getContext();
/* 351 */       if ((context != null) && (context.getPreemptiveAuthentication())) {
/* 352 */         if (request.getCoyoteRequest().getMimeHeaders().getValue("authorization") == null) {
/* 353 */           request.getCoyoteRequest().getMimeHeaders().addValue("authorization").setString("invalid");
/*     */         }
/* 355 */         getNext().invoke(request, response);
/* 356 */         return;
/*     */       }
/*     */     }
/* 359 */     response.sendError(this.denyStatus);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAllowed(String property)
/*     */   {
/* 374 */     Pattern deny = this.deny;
/* 375 */     Pattern allow = this.allow;
/*     */     
/*     */ 
/* 378 */     if ((deny != null) && (deny.matcher(property).matches())) {
/* 379 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 383 */     if ((allow != null) && (allow.matcher(property).matches())) {
/* 384 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 388 */     if ((deny != null) && (allow == null)) {
/* 389 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 393 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\valves\RequestFilterValve.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */