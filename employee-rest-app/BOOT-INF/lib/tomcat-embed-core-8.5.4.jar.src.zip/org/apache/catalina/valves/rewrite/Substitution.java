/*     */ package org.apache.catalina.valves.rewrite;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Substitution
/*     */ {
/*     */   public abstract class SubstitutionElement
/*     */   {
/*     */     public SubstitutionElement() {}
/*     */     
/*     */     public abstract String evaluate(Matcher paramMatcher1, Matcher paramMatcher2, Resolver paramResolver);
/*     */   }
/*     */   
/*     */   public class StaticElement
/*     */     extends Substitution.SubstitutionElement
/*     */   {
/*     */     public String value;
/*     */     
/*     */     public StaticElement()
/*     */     {
/*  29 */       super();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  34 */     public String evaluate(Matcher rule, Matcher cond, Resolver resolver) { return this.value; }
/*     */   }
/*     */   
/*     */   public class RewriteRuleBackReferenceElement extends Substitution.SubstitutionElement { public int n;
/*     */     
/*  39 */     public RewriteRuleBackReferenceElement() { super(); }
/*     */     
/*     */ 
/*     */ 
/*  43 */     public String evaluate(Matcher rule, Matcher cond, Resolver resolver) { return rule.group(this.n); } }
/*     */   
/*     */   public class RewriteCondBackReferenceElement extends Substitution.SubstitutionElement { public int n;
/*     */     
/*  47 */     public RewriteCondBackReferenceElement() { super(); }
/*     */     
/*     */ 
/*     */ 
/*  51 */     public String evaluate(Matcher rule, Matcher cond, Resolver resolver) { return cond.group(this.n); } }
/*     */   
/*     */   public class ServerVariableElement extends Substitution.SubstitutionElement { public String key;
/*     */     
/*  55 */     public ServerVariableElement() { super(); }
/*     */     
/*     */ 
/*     */ 
/*  59 */     public String evaluate(Matcher rule, Matcher cond, Resolver resolver) { return resolver.resolve(this.key); } }
/*     */   
/*     */   public class ServerVariableEnvElement extends Substitution.SubstitutionElement { public String key;
/*     */     
/*  63 */     public ServerVariableEnvElement() { super(); }
/*     */     
/*     */ 
/*     */ 
/*  67 */     public String evaluate(Matcher rule, Matcher cond, Resolver resolver) { return resolver.resolveEnv(this.key); } }
/*     */   
/*     */   public class ServerVariableSslElement extends Substitution.SubstitutionElement { public String key;
/*     */     
/*  71 */     public ServerVariableSslElement() { super(); }
/*     */     
/*     */ 
/*     */ 
/*  75 */     public String evaluate(Matcher rule, Matcher cond, Resolver resolver) { return resolver.resolveSsl(this.key); } }
/*     */   
/*     */   public class ServerVariableHttpElement extends Substitution.SubstitutionElement { public String key;
/*     */     
/*  79 */     public ServerVariableHttpElement() { super(); }
/*     */     
/*     */ 
/*     */ 
/*  83 */     public String evaluate(Matcher rule, Matcher cond, Resolver resolver) { return resolver.resolveHttp(this.key); }
/*     */   }
/*     */   
/*     */   public class MapElement extends Substitution.SubstitutionElement {
/*  87 */     public MapElement() { super(); }
/*  88 */     public RewriteMap map = null;
/*     */     public String key;
/*  90 */     public String defaultValue = null;
/*     */     public int n;
/*     */     
/*     */     public String evaluate(Matcher rule, Matcher cond, Resolver resolver) {
/*  94 */       String result = this.map.lookup(rule.group(this.n));
/*  95 */       if (result == null) {
/*  96 */         result = this.defaultValue;
/*     */       }
/*  98 */       return result;
/*     */     }
/*     */   }
/*     */   
/* 102 */   protected SubstitutionElement[] elements = null;
/*     */   
/* 104 */   protected String sub = null;
/* 105 */   public String getSub() { return this.sub; }
/* 106 */   public void setSub(String sub) { this.sub = sub; }
/*     */   
/*     */   public void parse(Map<String, RewriteMap> maps)
/*     */   {
/* 110 */     ArrayList<SubstitutionElement> elements = new ArrayList();
/* 111 */     int pos = 0;
/* 112 */     int percentPos = 0;
/* 113 */     int dollarPos = 0;
/* 114 */     int backslashPos = 0;
/*     */     
/* 116 */     while (pos < this.sub.length()) {
/* 117 */       percentPos = this.sub.indexOf('%', pos);
/* 118 */       dollarPos = this.sub.indexOf('$', pos);
/* 119 */       backslashPos = this.sub.indexOf('\\', pos);
/* 120 */       if ((percentPos == -1) && (dollarPos == -1) && (backslashPos == -1))
/*     */       {
/* 122 */         StaticElement newElement = new StaticElement();
/* 123 */         newElement.value = this.sub.substring(pos, this.sub.length());
/* 124 */         pos = this.sub.length();
/* 125 */         elements.add(newElement);
/* 126 */       } else if (isFirstPos(backslashPos, new int[] { dollarPos, percentPos })) {
/* 127 */         if (backslashPos + 1 == this.sub.length()) {
/* 128 */           throw new IllegalArgumentException(this.sub);
/*     */         }
/* 130 */         StaticElement newElement = new StaticElement();
/* 131 */         newElement.value = (this.sub.substring(pos, backslashPos) + this.sub.substring(backslashPos + 1, backslashPos + 2));
/* 132 */         pos = backslashPos + 2;
/* 133 */         elements.add(newElement);
/* 134 */       } else if (isFirstPos(dollarPos, new int[] { percentPos }))
/*     */       {
/* 136 */         if (dollarPos + 1 == this.sub.length()) {
/* 137 */           throw new IllegalArgumentException(this.sub);
/*     */         }
/* 139 */         if (pos < dollarPos)
/*     */         {
/* 141 */           StaticElement newElement = new StaticElement();
/* 142 */           newElement.value = this.sub.substring(pos, dollarPos);
/* 143 */           pos = dollarPos;
/* 144 */           elements.add(newElement);
/*     */         }
/* 146 */         if (Character.isDigit(this.sub.charAt(dollarPos + 1)))
/*     */         {
/* 148 */           RewriteRuleBackReferenceElement newElement = new RewriteRuleBackReferenceElement();
/* 149 */           newElement.n = Character.digit(this.sub.charAt(dollarPos + 1), 10);
/* 150 */           pos = dollarPos + 2;
/* 151 */           elements.add(newElement);
/* 152 */         } else if (this.sub.charAt(dollarPos + 1) == '{')
/*     */         {
/* 154 */           MapElement newElement = new MapElement();
/* 155 */           int open = this.sub.indexOf('{', dollarPos);
/* 156 */           int colon = this.sub.indexOf(':', dollarPos);
/* 157 */           int def = this.sub.indexOf('|', dollarPos);
/* 158 */           int close = this.sub.indexOf('}', dollarPos);
/* 159 */           if ((-1 >= open) || (open >= colon) || (colon >= close)) {
/* 160 */             throw new IllegalArgumentException(this.sub);
/*     */           }
/* 162 */           newElement.map = ((RewriteMap)maps.get(this.sub.substring(open + 1, colon)));
/* 163 */           if (newElement.map == null) {
/* 164 */             throw new IllegalArgumentException(this.sub + ": No map: " + this.sub.substring(open + 1, colon));
/*     */           }
/* 166 */           if (def > -1) {
/* 167 */             if ((colon >= def) || (def >= close)) {
/* 168 */               throw new IllegalArgumentException(this.sub);
/*     */             }
/* 170 */             newElement.key = this.sub.substring(colon + 1, def);
/* 171 */             newElement.defaultValue = this.sub.substring(def + 1, close);
/*     */           } else {
/* 173 */             newElement.key = this.sub.substring(colon + 1, close);
/*     */           }
/* 175 */           if (newElement.key.startsWith("$")) {
/* 176 */             newElement.n = Integer.parseInt(newElement.key.substring(1));
/*     */           }
/* 178 */           pos = close + 1;
/* 179 */           elements.add(newElement);
/*     */         } else {
/* 181 */           throw new IllegalArgumentException(this.sub + ": missing digit or curly brace.");
/*     */         }
/*     */       }
/*     */       else {
/* 185 */         if (percentPos + 1 == this.sub.length()) {
/* 186 */           throw new IllegalArgumentException(this.sub);
/*     */         }
/* 188 */         if (pos < percentPos)
/*     */         {
/* 190 */           StaticElement newElement = new StaticElement();
/* 191 */           newElement.value = this.sub.substring(pos, percentPos);
/* 192 */           pos = percentPos;
/* 193 */           elements.add(newElement);
/*     */         }
/* 195 */         if (Character.isDigit(this.sub.charAt(percentPos + 1)))
/*     */         {
/* 197 */           RewriteCondBackReferenceElement newElement = new RewriteCondBackReferenceElement();
/* 198 */           newElement.n = Character.digit(this.sub.charAt(percentPos + 1), 10);
/* 199 */           pos = percentPos + 2;
/* 200 */           elements.add(newElement);
/* 201 */         } else if (this.sub.charAt(percentPos + 1) == '{')
/*     */         {
/* 203 */           SubstitutionElement newElement = null;
/* 204 */           int open = this.sub.indexOf('{', percentPos);
/* 205 */           int colon = this.sub.indexOf(':', percentPos);
/* 206 */           int close = this.sub.indexOf('}', percentPos);
/* 207 */           if ((-1 >= open) || (open >= close)) {
/* 208 */             throw new IllegalArgumentException(this.sub);
/*     */           }
/* 210 */           if ((colon > -1) && (open < colon) && (colon < close)) {
/* 211 */             String type = this.sub.substring(open + 1, colon);
/* 212 */             if (type.equals("ENV")) {
/* 213 */               newElement = new ServerVariableEnvElement();
/* 214 */               ((ServerVariableEnvElement)newElement).key = this.sub.substring(colon + 1, close);
/* 215 */             } else if (type.equals("SSL")) {
/* 216 */               newElement = new ServerVariableSslElement();
/* 217 */               ((ServerVariableSslElement)newElement).key = this.sub.substring(colon + 1, close);
/* 218 */             } else if (type.equals("HTTP")) {
/* 219 */               newElement = new ServerVariableHttpElement();
/* 220 */               ((ServerVariableHttpElement)newElement).key = this.sub.substring(colon + 1, close);
/*     */             } else {
/* 222 */               throw new IllegalArgumentException(this.sub + ": Bad type: " + type);
/*     */             }
/*     */           } else {
/* 225 */             newElement = new ServerVariableElement();
/* 226 */             ((ServerVariableElement)newElement).key = this.sub.substring(open + 1, close);
/*     */           }
/* 228 */           pos = close + 1;
/* 229 */           elements.add(newElement);
/*     */         } else {
/* 231 */           throw new IllegalArgumentException(this.sub + ": missing digit or curly brace.");
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 236 */     this.elements = ((SubstitutionElement[])elements.toArray(new SubstitutionElement[0]));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String evaluate(Matcher rule, Matcher cond, Resolver resolver)
/*     */   {
/* 248 */     StringBuffer buf = new StringBuffer();
/* 249 */     for (int i = 0; i < this.elements.length; i++) {
/* 250 */       buf.append(this.elements[i].evaluate(rule, cond, resolver));
/*     */     }
/* 252 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isFirstPos(int testPos, int... others)
/*     */   {
/* 268 */     if (testPos < 0) {
/* 269 */       return false;
/*     */     }
/* 271 */     for (int other : others) {
/* 272 */       if ((other >= 0) && (other < testPos)) {
/* 273 */         return false;
/*     */       }
/*     */     }
/* 276 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\valves\rewrite\Substitution.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */