/*    */ package org.apache.catalina.valves.rewrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Resolver
/*    */ {
/*    */   public abstract String resolve(String paramString);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String resolveEnv(String key)
/*    */   {
/* 28 */     return System.getProperty(key);
/*    */   }
/*    */   
/*    */   public abstract String resolveSsl(String paramString);
/*    */   
/*    */   public abstract String resolveHttp(String paramString);
/*    */   
/*    */   public abstract boolean resolveResource(int paramInt, String paramString);
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\valves\rewrite\Resolver.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */