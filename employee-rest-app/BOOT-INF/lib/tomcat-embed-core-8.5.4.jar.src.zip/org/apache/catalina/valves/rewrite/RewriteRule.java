/*     */ package org.apache.catalina.valves.rewrite;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RewriteRule
/*     */ {
/*  26 */   protected RewriteCond[] conditions = new RewriteCond[0];
/*     */   
/*  28 */   protected ThreadLocal<Pattern> pattern = new ThreadLocal();
/*  29 */   protected Substitution substitution = null;
/*     */   
/*  31 */   protected String patternString = null;
/*  32 */   protected String substitutionString = null;
/*     */   
/*     */   public void parse(Map<String, RewriteMap> maps)
/*     */   {
/*  36 */     if (!"-".equals(this.substitutionString)) {
/*  37 */       this.substitution = new Substitution();
/*  38 */       this.substitution.setSub(this.substitutionString);
/*  39 */       this.substitution.parse(maps);
/*     */     }
/*     */     
/*  42 */     int flags = 0;
/*  43 */     if (isNocase()) {
/*  44 */       flags |= 0x2;
/*     */     }
/*  46 */     Pattern.compile(this.patternString, flags);
/*     */     
/*  48 */     for (int i = 0; i < this.conditions.length; i++) {
/*  49 */       this.conditions[i].parse(maps);
/*     */     }
/*     */     
/*  52 */     if (isEnv()) {
/*  53 */       for (int i = 0; i < this.envValue.size(); i++) {
/*  54 */         Substitution newEnvSubstitution = new Substitution();
/*  55 */         newEnvSubstitution.setSub((String)this.envValue.get(i));
/*  56 */         newEnvSubstitution.parse(maps);
/*  57 */         this.envSubstitution.add(newEnvSubstitution);
/*  58 */         this.envResult.add(new ThreadLocal());
/*     */       }
/*     */     }
/*  61 */     if (isCookie()) {
/*  62 */       this.cookieSubstitution = new Substitution();
/*  63 */       this.cookieSubstitution.setSub(this.cookieValue);
/*  64 */       this.cookieSubstitution.parse(maps);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addCondition(RewriteCond condition) {
/*  69 */     RewriteCond[] conditions = new RewriteCond[this.conditions.length + 1];
/*  70 */     for (int i = 0; i < this.conditions.length; i++) {
/*  71 */       conditions[i] = this.conditions[i];
/*     */     }
/*  73 */     conditions[this.conditions.length] = condition;
/*  74 */     this.conditions = conditions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CharSequence evaluate(CharSequence url, Resolver resolver)
/*     */   {
/*  84 */     Pattern pattern = (Pattern)this.pattern.get();
/*  85 */     if (pattern == null)
/*     */     {
/*  87 */       int flags = 0;
/*  88 */       if (isNocase()) {
/*  89 */         flags |= 0x2;
/*     */       }
/*  91 */       pattern = Pattern.compile(this.patternString, flags);
/*  92 */       this.pattern.set(pattern);
/*     */     }
/*  94 */     Matcher matcher = pattern.matcher(url);
/*  95 */     if (!matcher.matches())
/*     */     {
/*  97 */       return null;
/*     */     }
/*     */     
/* 100 */     boolean done = false;
/* 101 */     boolean rewrite = true;
/* 102 */     Matcher lastMatcher = null;
/* 103 */     int pos = 0;
/* 104 */     while (!done) {
/* 105 */       if (pos < this.conditions.length) {
/* 106 */         rewrite = this.conditions[pos].evaluate(matcher, lastMatcher, resolver);
/* 107 */         if (rewrite) {
/* 108 */           Matcher lastMatcher2 = this.conditions[pos].getMatcher();
/* 109 */           if (lastMatcher2 != null) {
/* 110 */             lastMatcher = lastMatcher2;
/*     */           }
/* 112 */           while ((pos < this.conditions.length) && (this.conditions[pos].isOrnext())) {
/* 113 */             pos++;
/*     */           }
/* 115 */         } else if (!this.conditions[pos].isOrnext()) {
/* 116 */           done = true;
/*     */         }
/* 118 */         pos++;
/*     */       } else {
/* 120 */         done = true;
/*     */       }
/*     */     }
/*     */     
/* 124 */     if (rewrite) {
/* 125 */       if (isEnv()) {
/* 126 */         for (int i = 0; i < this.envSubstitution.size(); i++) {
/* 127 */           ((ThreadLocal)this.envResult.get(i)).set(((Substitution)this.envSubstitution.get(i)).evaluate(matcher, lastMatcher, resolver));
/*     */         }
/*     */       }
/* 130 */       if (isCookie()) {
/* 131 */         this.cookieResult.set(this.cookieSubstitution.evaluate(matcher, lastMatcher, resolver));
/*     */       }
/* 133 */       if (this.substitution != null) {
/* 134 */         return this.substitution.evaluate(matcher, lastMatcher, resolver);
/*     */       }
/* 136 */       return url;
/*     */     }
/*     */     
/* 139 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 150 */     return "RewriteRule " + this.patternString + " " + this.substitutionString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 163 */   protected boolean chain = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 172 */   protected boolean cookie = false;
/* 173 */   protected String cookieName = null;
/* 174 */   protected String cookieValue = null;
/* 175 */   protected String cookieDomain = null;
/* 176 */   protected int cookieLifetime = -1;
/* 177 */   protected String cookiePath = null;
/* 178 */   protected boolean cookieSecure = false;
/* 179 */   protected boolean cookieHttpOnly = false;
/* 180 */   protected Substitution cookieSubstitution = null;
/* 181 */   protected ThreadLocal<String> cookieResult = new ThreadLocal();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 188 */   protected boolean env = false;
/* 189 */   protected ArrayList<String> envName = new ArrayList();
/* 190 */   protected ArrayList<String> envValue = new ArrayList();
/* 191 */   protected ArrayList<Substitution> envSubstitution = new ArrayList();
/* 192 */   protected ArrayList<ThreadLocal<String>> envResult = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 199 */   protected boolean forbidden = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 206 */   protected boolean gone = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 213 */   protected boolean host = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 222 */   protected boolean last = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 232 */   protected boolean next = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 239 */   protected boolean nocase = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 251 */   protected boolean noescape = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 265 */   protected boolean nosubreq = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 289 */   protected boolean qsappend = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 307 */   protected boolean redirect = false;
/* 308 */   protected int redirectCode = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 317 */   protected int skip = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 326 */   protected boolean type = false;
/* 327 */   protected String typeValue = null;
/*     */   
/* 329 */   public boolean isChain() { return this.chain; }
/*     */   
/*     */   public void setChain(boolean chain) {
/* 332 */     this.chain = chain;
/*     */   }
/*     */   
/* 335 */   public RewriteCond[] getConditions() { return this.conditions; }
/*     */   
/*     */   public void setConditions(RewriteCond[] conditions) {
/* 338 */     this.conditions = conditions;
/*     */   }
/*     */   
/* 341 */   public boolean isCookie() { return this.cookie; }
/*     */   
/*     */   public void setCookie(boolean cookie) {
/* 344 */     this.cookie = cookie;
/*     */   }
/*     */   
/* 347 */   public String getCookieName() { return this.cookieName; }
/*     */   
/*     */   public void setCookieName(String cookieName) {
/* 350 */     this.cookieName = cookieName;
/*     */   }
/*     */   
/* 353 */   public String getCookieValue() { return this.cookieValue; }
/*     */   
/*     */   public void setCookieValue(String cookieValue) {
/* 356 */     this.cookieValue = cookieValue;
/*     */   }
/*     */   
/* 359 */   public String getCookieResult() { return (String)this.cookieResult.get(); }
/*     */   
/*     */   public boolean isEnv() {
/* 362 */     return this.env;
/*     */   }
/*     */   
/* 365 */   public int getEnvSize() { return this.envName.size(); }
/*     */   
/*     */   public void setEnv(boolean env) {
/* 368 */     this.env = env;
/*     */   }
/*     */   
/* 371 */   public String getEnvName(int i) { return (String)this.envName.get(i); }
/*     */   
/*     */   public void addEnvName(String envName) {
/* 374 */     this.envName.add(envName);
/*     */   }
/*     */   
/* 377 */   public String getEnvValue(int i) { return (String)this.envValue.get(i); }
/*     */   
/*     */   public void addEnvValue(String envValue) {
/* 380 */     this.envValue.add(envValue);
/*     */   }
/*     */   
/* 383 */   public String getEnvResult(int i) { return (String)((ThreadLocal)this.envResult.get(i)).get(); }
/*     */   
/*     */   public boolean isForbidden() {
/* 386 */     return this.forbidden;
/*     */   }
/*     */   
/* 389 */   public void setForbidden(boolean forbidden) { this.forbidden = forbidden; }
/*     */   
/*     */   public boolean isGone() {
/* 392 */     return this.gone;
/*     */   }
/*     */   
/* 395 */   public void setGone(boolean gone) { this.gone = gone; }
/*     */   
/*     */   public boolean isLast() {
/* 398 */     return this.last;
/*     */   }
/*     */   
/* 401 */   public void setLast(boolean last) { this.last = last; }
/*     */   
/*     */   public boolean isNext() {
/* 404 */     return this.next;
/*     */   }
/*     */   
/* 407 */   public void setNext(boolean next) { this.next = next; }
/*     */   
/*     */   public boolean isNocase() {
/* 410 */     return this.nocase;
/*     */   }
/*     */   
/* 413 */   public void setNocase(boolean nocase) { this.nocase = nocase; }
/*     */   
/*     */   public boolean isNoescape() {
/* 416 */     return this.noescape;
/*     */   }
/*     */   
/* 419 */   public void setNoescape(boolean noescape) { this.noescape = noescape; }
/*     */   
/*     */   public boolean isNosubreq() {
/* 422 */     return this.nosubreq;
/*     */   }
/*     */   
/* 425 */   public void setNosubreq(boolean nosubreq) { this.nosubreq = nosubreq; }
/*     */   
/*     */   public boolean isQsappend() {
/* 428 */     return this.qsappend;
/*     */   }
/*     */   
/* 431 */   public void setQsappend(boolean qsappend) { this.qsappend = qsappend; }
/*     */   
/*     */   public boolean isRedirect() {
/* 434 */     return this.redirect;
/*     */   }
/*     */   
/* 437 */   public void setRedirect(boolean redirect) { this.redirect = redirect; }
/*     */   
/*     */   public int getRedirectCode() {
/* 440 */     return this.redirectCode;
/*     */   }
/*     */   
/* 443 */   public void setRedirectCode(int redirectCode) { this.redirectCode = redirectCode; }
/*     */   
/*     */   public int getSkip() {
/* 446 */     return this.skip;
/*     */   }
/*     */   
/* 449 */   public void setSkip(int skip) { this.skip = skip; }
/*     */   
/*     */   public Substitution getSubstitution() {
/* 452 */     return this.substitution;
/*     */   }
/*     */   
/* 455 */   public void setSubstitution(Substitution substitution) { this.substitution = substitution; }
/*     */   
/*     */   public boolean isType() {
/* 458 */     return this.type;
/*     */   }
/*     */   
/* 461 */   public void setType(boolean type) { this.type = type; }
/*     */   
/*     */   public String getTypeValue() {
/* 464 */     return this.typeValue;
/*     */   }
/*     */   
/* 467 */   public void setTypeValue(String typeValue) { this.typeValue = typeValue; }
/*     */   
/*     */   public String getPatternString()
/*     */   {
/* 471 */     return this.patternString;
/*     */   }
/*     */   
/*     */   public void setPatternString(String patternString) {
/* 475 */     this.patternString = patternString;
/*     */   }
/*     */   
/*     */   public String getSubstitutionString() {
/* 479 */     return this.substitutionString;
/*     */   }
/*     */   
/*     */   public void setSubstitutionString(String substitutionString) {
/* 483 */     this.substitutionString = substitutionString;
/*     */   }
/*     */   
/*     */   public boolean isHost() {
/* 487 */     return this.host;
/*     */   }
/*     */   
/*     */   public void setHost(boolean host) {
/* 491 */     this.host = host;
/*     */   }
/*     */   
/*     */   public String getCookieDomain() {
/* 495 */     return this.cookieDomain;
/*     */   }
/*     */   
/*     */   public void setCookieDomain(String cookieDomain) {
/* 499 */     this.cookieDomain = cookieDomain;
/*     */   }
/*     */   
/*     */   public int getCookieLifetime() {
/* 503 */     return this.cookieLifetime;
/*     */   }
/*     */   
/*     */   public void setCookieLifetime(int cookieLifetime) {
/* 507 */     this.cookieLifetime = cookieLifetime;
/*     */   }
/*     */   
/*     */   public String getCookiePath() {
/* 511 */     return this.cookiePath;
/*     */   }
/*     */   
/*     */   public void setCookiePath(String cookiePath) {
/* 515 */     this.cookiePath = cookiePath;
/*     */   }
/*     */   
/*     */   public boolean isCookieSecure() {
/* 519 */     return this.cookieSecure;
/*     */   }
/*     */   
/*     */   public void setCookieSecure(boolean cookieSecure) {
/* 523 */     this.cookieSecure = cookieSecure;
/*     */   }
/*     */   
/*     */   public boolean isCookieHttpOnly() {
/* 527 */     return this.cookieHttpOnly;
/*     */   }
/*     */   
/*     */   public void setCookieHttpOnly(boolean cookieHttpOnly) {
/* 531 */     this.cookieHttpOnly = cookieHttpOnly;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\valves\rewrite\RewriteRule.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */