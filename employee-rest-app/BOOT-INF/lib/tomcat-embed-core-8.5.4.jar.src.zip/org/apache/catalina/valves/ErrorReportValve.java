/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Scanner;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.util.RequestUtil;
/*     */ import org.apache.catalina.util.ServerInfo;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ErrorReportValve
/*     */   extends ValveBase
/*     */ {
/*  51 */   private boolean showReport = true;
/*     */   
/*  53 */   private boolean showServerInfo = true;
/*     */   
/*     */   public ErrorReportValve()
/*     */   {
/*  57 */     super(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void invoke(Request request, org.apache.catalina.connector.Response response)
/*     */     throws IOException, ServletException
/*     */   {
/*  79 */     getNext().invoke(request, response);
/*     */     
/*  81 */     if (response.isCommitted()) {
/*  82 */       if (response.setErrorReported())
/*     */       {
/*     */ 
/*     */         try
/*     */         {
/*  87 */           response.flushBuffer();
/*     */         } catch (Throwable t) {
/*  89 */           ExceptionUtils.handleThrowable(t);
/*     */         }
/*     */         
/*     */ 
/*  93 */         response.getCoyoteResponse().action(ActionCode.CLOSE_NOW, null);
/*     */       }
/*  95 */       return;
/*     */     }
/*     */     
/*  98 */     Throwable throwable = (Throwable)request.getAttribute("javax.servlet.error.exception");
/*     */     
/*     */ 
/*     */ 
/* 102 */     if ((request.isAsync()) && (!request.isAsyncCompleting())) {
/* 103 */       return;
/*     */     }
/*     */     
/* 106 */     if ((throwable != null) && (!response.isError()))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 112 */       response.reset();
/* 113 */       response.sendError(500);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 119 */     response.setSuspended(false);
/*     */     try
/*     */     {
/* 122 */       report(request, response, throwable);
/*     */     } catch (Throwable tt) {
/* 124 */       ExceptionUtils.handleThrowable(tt);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void report(Request request, org.apache.catalina.connector.Response response, Throwable throwable)
/*     */   {
/* 142 */     int statusCode = response.getStatus();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 148 */     if ((statusCode < 400) || (response.getContentWritten() > 0L) || (!response.setErrorReported())) {
/* 149 */       return;
/*     */     }
/* 151 */     String message = RequestUtil.filter(response.getMessage());
/* 152 */     if (message == null) {
/* 153 */       if (throwable != null) {
/* 154 */         String exceptionMessage = throwable.getMessage();
/* 155 */         if ((exceptionMessage != null) && (exceptionMessage.length() > 0)) {
/* 156 */           message = RequestUtil.filter(new Scanner(exceptionMessage).nextLine());
/*     */         }
/*     */       }
/* 159 */       if (message == null) {
/* 160 */         message = "";
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 166 */     String report = null;
/* 167 */     StringManager smClient = StringManager.getManager("org.apache.catalina.valves", request.getLocales());
/*     */     
/* 169 */     response.setLocale(smClient.getLocale());
/*     */     try {
/* 171 */       report = smClient.getString("http." + statusCode);
/*     */     } catch (Throwable t) {
/* 173 */       ExceptionUtils.handleThrowable(t);
/*     */     }
/* 175 */     if (report == null) {
/* 176 */       if (message.length() == 0) {
/* 177 */         return;
/*     */       }
/* 179 */       report = smClient.getString("errorReportValve.noDescription");
/*     */     }
/*     */     
/*     */ 
/* 183 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 185 */     sb.append("<!DOCTYPE html><html><head>");
/* 186 */     if ((this.showServerInfo) || (this.showReport)) {
/* 187 */       sb.append("<title>");
/* 188 */       if (this.showServerInfo) {
/* 189 */         sb.append(ServerInfo.getServerInfo()).append(" - ");
/*     */       }
/* 191 */       sb.append(smClient.getString("errorReportValve.errorReport"));
/* 192 */       sb.append("</title>");
/* 193 */       sb.append("<style type=\"text/css\">");
/* 194 */       sb.append("H1 {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;font-size:22px;} H2 {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;font-size:16px;} H3 {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;font-size:14px;} BODY {font-family:Tahoma,Arial,sans-serif;color:black;background-color:white;} B {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;} P {font-family:Tahoma,Arial,sans-serif;background:white;color:black;font-size:12px;}A {color : black;}A.name {color : black;}.line {height: 1px; background-color: #525D76; border: none;}");
/* 195 */       sb.append("</style> ");
/*     */     } else {
/* 197 */       sb.append("<title>");
/* 198 */       sb.append(smClient.getString("errorReportValve.errorReport"));
/* 199 */       sb.append("</title>");
/*     */     }
/* 201 */     sb.append("</head><body>");
/* 202 */     sb.append("<h1>");
/* 203 */     sb.append(smClient.getString("errorReportValve.statusHeader", new Object[] { String.valueOf(statusCode), message })).append("</h1>");
/*     */     
/* 205 */     if (this.showReport) {
/* 206 */       sb.append("<div class=\"line\"></div>");
/* 207 */       sb.append("<p><b>type</b> ");
/* 208 */       if (throwable != null) {
/* 209 */         sb.append(smClient.getString("errorReportValve.exceptionReport"));
/*     */       } else {
/* 211 */         sb.append(smClient.getString("errorReportValve.statusReport"));
/*     */       }
/* 213 */       sb.append("</p>");
/* 214 */       sb.append("<p><b>");
/* 215 */       sb.append(smClient.getString("errorReportValve.message"));
/* 216 */       sb.append("</b> <u>");
/* 217 */       sb.append(message).append("</u></p>");
/* 218 */       sb.append("<p><b>");
/* 219 */       sb.append(smClient.getString("errorReportValve.description"));
/* 220 */       sb.append("</b> <u>");
/* 221 */       sb.append(report);
/* 222 */       sb.append("</u></p>");
/* 223 */       if (throwable != null)
/*     */       {
/* 225 */         String stackTrace = getPartialServletStackTrace(throwable);
/* 226 */         sb.append("<p><b>");
/* 227 */         sb.append(smClient.getString("errorReportValve.exception"));
/* 228 */         sb.append("</b></p><pre>");
/* 229 */         sb.append(RequestUtil.filter(stackTrace));
/* 230 */         sb.append("</pre>");
/*     */         
/* 232 */         int loops = 0;
/* 233 */         Throwable rootCause = throwable.getCause();
/* 234 */         while ((rootCause != null) && (loops < 10)) {
/* 235 */           stackTrace = getPartialServletStackTrace(rootCause);
/* 236 */           sb.append("<p><b>");
/* 237 */           sb.append(smClient.getString("errorReportValve.rootCause"));
/* 238 */           sb.append("</b></p><pre>");
/* 239 */           sb.append(RequestUtil.filter(stackTrace));
/* 240 */           sb.append("</pre>");
/*     */           
/* 242 */           rootCause = rootCause.getCause();
/* 243 */           loops++;
/*     */         }
/*     */         
/* 246 */         sb.append("<p><b>");
/* 247 */         sb.append(smClient.getString("errorReportValve.note"));
/* 248 */         sb.append("</b> <u>");
/* 249 */         sb.append(smClient.getString("errorReportValve.rootCauseInLogs", new Object[] { this.showServerInfo ? ServerInfo.getServerInfo() : "" }));
/*     */         
/* 251 */         sb.append("</u></p>");
/*     */       }
/*     */       
/* 254 */       sb.append("<hr class=\"line\">");
/*     */     }
/* 256 */     if (this.showServerInfo) {
/* 257 */       sb.append("<h3>").append(ServerInfo.getServerInfo()).append("</h3>");
/*     */     }
/* 259 */     sb.append("</body></html>");
/*     */     try
/*     */     {
/*     */       try {
/* 263 */         response.setContentType("text/html");
/* 264 */         response.setCharacterEncoding("utf-8");
/*     */       } catch (Throwable t) {
/* 266 */         ExceptionUtils.handleThrowable(t);
/* 267 */         if (this.container.getLogger().isDebugEnabled()) {
/* 268 */           this.container.getLogger().debug("status.setContentType", t);
/*     */         }
/*     */       }
/* 271 */       Writer writer = response.getReporter();
/* 272 */       if (writer != null)
/*     */       {
/*     */ 
/* 275 */         writer.write(sb.toString());
/* 276 */         response.finishResponse();
/*     */       }
/*     */     }
/*     */     catch (IOException localIOException) {}catch (IllegalStateException localIllegalStateException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getPartialServletStackTrace(Throwable t)
/*     */   {
/* 294 */     StringBuilder trace = new StringBuilder();
/* 295 */     trace.append(t.toString()).append('\n');
/* 296 */     StackTraceElement[] elements = t.getStackTrace();
/* 297 */     int pos = elements.length;
/* 298 */     for (int i = elements.length - 1; i >= 0; i--) {
/* 299 */       if ((elements[i].getClassName().startsWith("org.apache.catalina.core.ApplicationFilterChain")) && (elements[i].getMethodName().equals("internalDoFilter")))
/*     */       {
/*     */ 
/* 302 */         pos = i;
/* 303 */         break;
/*     */       }
/*     */     }
/* 306 */     for (int i = 0; i < pos; i++) {
/* 307 */       if (!elements[i].getClassName().startsWith("org.apache.catalina.core."))
/*     */       {
/* 309 */         trace.append('\t').append(elements[i].toString()).append('\n');
/*     */       }
/*     */     }
/* 312 */     return trace.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setShowReport(boolean showReport)
/*     */   {
/* 321 */     this.showReport = showReport;
/*     */   }
/*     */   
/*     */   public boolean isShowReport() {
/* 325 */     return this.showReport;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setShowServerInfo(boolean showServerInfo)
/*     */   {
/* 334 */     this.showServerInfo = showServerInfo;
/*     */   }
/*     */   
/*     */   public boolean isShowServerInfo() {
/* 338 */     return this.showServerInfo;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\valves\ErrorReportValve.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */