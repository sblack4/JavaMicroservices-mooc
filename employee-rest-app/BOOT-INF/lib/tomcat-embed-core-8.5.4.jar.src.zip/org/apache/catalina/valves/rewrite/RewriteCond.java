/*     */ package org.apache.catalina.valves.rewrite;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RewriteCond
/*     */ {
/*     */   public static abstract class Condition
/*     */   {
/*     */     public abstract boolean evaluate(String paramString, Resolver paramResolver);
/*     */   }
/*     */   
/*     */   public static class PatternCondition
/*     */     extends RewriteCond.Condition
/*     */   {
/*     */     public Pattern pattern;
/*  32 */     public Matcher matcher = null;
/*     */     
/*     */     public boolean evaluate(String value, Resolver resolver)
/*     */     {
/*  36 */       Matcher m = this.pattern.matcher(value);
/*  37 */       if (m.matches()) {
/*  38 */         this.matcher = m;
/*  39 */         return true;
/*     */       }
/*  41 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class LexicalCondition
/*     */     extends RewriteCond.Condition
/*     */   {
/*  52 */     public int type = 0;
/*     */     public String condition;
/*     */     
/*     */     public boolean evaluate(String value, Resolver resolver)
/*     */     {
/*  57 */       int result = value.compareTo(this.condition);
/*  58 */       switch (this.type) {
/*     */       case -1: 
/*  60 */         return result < 0;
/*     */       case 0: 
/*  62 */         return result == 0;
/*     */       case 1: 
/*  64 */         return result > 0;
/*     */       }
/*  66 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class ResourceCondition
/*     */     extends RewriteCond.Condition
/*     */   {
/*  78 */     public int type = 0;
/*     */     
/*     */     public boolean evaluate(String value, Resolver resolver)
/*     */     {
/*  82 */       return resolver.resolveResource(this.type, value);
/*     */     }
/*     */   }
/*     */   
/*  86 */   protected String testString = null;
/*  87 */   protected String condPattern = null;
/*     */   
/*     */   public String getCondPattern() {
/*  90 */     return this.condPattern;
/*     */   }
/*     */   
/*     */   public void setCondPattern(String condPattern) {
/*  94 */     this.condPattern = condPattern;
/*     */   }
/*     */   
/*     */   public String getTestString() {
/*  98 */     return this.testString;
/*     */   }
/*     */   
/*     */   public void setTestString(String testString) {
/* 102 */     this.testString = testString;
/*     */   }
/*     */   
/*     */   public void parse(Map<String, RewriteMap> maps) {
/* 106 */     this.test = new Substitution();
/* 107 */     this.test.setSub(this.testString);
/* 108 */     this.test.parse(maps);
/* 109 */     if (this.condPattern.startsWith("!")) {
/* 110 */       this.positive = false;
/* 111 */       this.condPattern = this.condPattern.substring(1);
/*     */     }
/* 113 */     if (this.condPattern.startsWith("<")) {
/* 114 */       LexicalCondition condition = new LexicalCondition();
/* 115 */       condition.type = -1;
/* 116 */       condition.condition = this.condPattern.substring(1);
/* 117 */     } else if (this.condPattern.startsWith(">")) {
/* 118 */       LexicalCondition condition = new LexicalCondition();
/* 119 */       condition.type = 1;
/* 120 */       condition.condition = this.condPattern.substring(1);
/* 121 */     } else if (this.condPattern.startsWith("=")) {
/* 122 */       LexicalCondition condition = new LexicalCondition();
/* 123 */       condition.type = 0;
/* 124 */       condition.condition = this.condPattern.substring(1);
/* 125 */     } else if (this.condPattern.equals("-d")) {
/* 126 */       ResourceCondition ncondition = new ResourceCondition();
/* 127 */       ncondition.type = 0;
/* 128 */     } else if (this.condPattern.equals("-f")) {
/* 129 */       ResourceCondition ncondition = new ResourceCondition();
/* 130 */       ncondition.type = 1;
/* 131 */     } else if (this.condPattern.equals("-s")) {
/* 132 */       ResourceCondition ncondition = new ResourceCondition();
/* 133 */       ncondition.type = 2;
/*     */     } else {
/* 135 */       PatternCondition condition = new PatternCondition();
/* 136 */       int flags = 0;
/* 137 */       if (isNocase()) {
/* 138 */         flags |= 0x2;
/*     */       }
/* 140 */       condition.pattern = Pattern.compile(this.condPattern, flags);
/*     */     }
/*     */   }
/*     */   
/*     */   public Matcher getMatcher() {
/* 145 */     Object condition = this.condition.get();
/* 146 */     if ((condition instanceof PatternCondition)) {
/* 147 */       return ((PatternCondition)condition).matcher;
/*     */     }
/* 149 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 158 */     return "RewriteCond " + this.testString + " " + this.condPattern;
/*     */   }
/*     */   
/*     */ 
/* 162 */   protected boolean positive = true;
/*     */   
/* 164 */   protected Substitution test = null;
/*     */   
/* 166 */   protected ThreadLocal<Condition> condition = new ThreadLocal();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 174 */   public boolean nocase = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 179 */   public boolean ornext = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean evaluate(Matcher rule, Matcher cond, Resolver resolver)
/*     */   {
/* 190 */     String value = this.test.evaluate(rule, cond, resolver);
/* 191 */     if (this.nocase) {
/* 192 */       value = value.toLowerCase(Locale.ENGLISH);
/*     */     }
/* 194 */     Condition condition = (Condition)this.condition.get();
/* 195 */     if (condition == null) {
/* 196 */       if (this.condPattern.startsWith("<")) {
/* 197 */         LexicalCondition ncondition = new LexicalCondition();
/* 198 */         ncondition.type = -1;
/* 199 */         ncondition.condition = this.condPattern.substring(1);
/* 200 */         condition = ncondition;
/* 201 */       } else if (this.condPattern.startsWith(">")) {
/* 202 */         LexicalCondition ncondition = new LexicalCondition();
/* 203 */         ncondition.type = 1;
/* 204 */         ncondition.condition = this.condPattern.substring(1);
/* 205 */         condition = ncondition;
/* 206 */       } else if (this.condPattern.startsWith("=")) {
/* 207 */         LexicalCondition ncondition = new LexicalCondition();
/* 208 */         ncondition.type = 0;
/* 209 */         ncondition.condition = this.condPattern.substring(1);
/* 210 */         condition = ncondition;
/* 211 */       } else if (this.condPattern.equals("-d")) {
/* 212 */         ResourceCondition ncondition = new ResourceCondition();
/* 213 */         ncondition.type = 0;
/* 214 */         condition = ncondition;
/* 215 */       } else if (this.condPattern.equals("-f")) {
/* 216 */         ResourceCondition ncondition = new ResourceCondition();
/* 217 */         ncondition.type = 1;
/* 218 */         condition = ncondition;
/* 219 */       } else if (this.condPattern.equals("-s")) {
/* 220 */         ResourceCondition ncondition = new ResourceCondition();
/* 221 */         ncondition.type = 2;
/* 222 */         condition = ncondition;
/*     */       } else {
/* 224 */         PatternCondition ncondition = new PatternCondition();
/* 225 */         int flags = 0;
/* 226 */         if (isNocase()) {
/* 227 */           flags |= 0x2;
/*     */         }
/* 229 */         ncondition.pattern = Pattern.compile(this.condPattern, flags);
/* 230 */         condition = ncondition;
/*     */       }
/* 232 */       this.condition.set(condition);
/*     */     }
/* 234 */     if (this.positive) {
/* 235 */       return condition.evaluate(value, resolver);
/*     */     }
/* 237 */     return !condition.evaluate(value, resolver);
/*     */   }
/*     */   
/*     */   public boolean isNocase()
/*     */   {
/* 242 */     return this.nocase;
/*     */   }
/*     */   
/*     */   public void setNocase(boolean nocase) {
/* 246 */     this.nocase = nocase;
/*     */   }
/*     */   
/*     */   public boolean isOrnext() {
/* 250 */     return this.ornext;
/*     */   }
/*     */   
/*     */   public void setOrnext(boolean ornext) {
/* 254 */     this.ornext = ornext;
/*     */   }
/*     */   
/*     */   public boolean isPositive() {
/* 258 */     return this.positive;
/*     */   }
/*     */   
/*     */   public void setPositive(boolean positive) {
/* 262 */     this.positive = positive;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\valves\rewrite\RewriteCond.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */