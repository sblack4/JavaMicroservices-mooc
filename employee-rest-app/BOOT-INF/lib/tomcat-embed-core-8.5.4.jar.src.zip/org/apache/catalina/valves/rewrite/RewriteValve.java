/*     */ package org.apache.catalina.valves.rewrite;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.StringReader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.Cookie;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.Lifecycle;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.Pipeline;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.catalina.mapper.MappingData;
/*     */ import org.apache.catalina.util.URLEncoder;
/*     */ import org.apache.catalina.valves.ValveBase;
/*     */ import org.apache.coyote.Adapter;
/*     */ import org.apache.coyote.ProtocolHandler;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.buf.CharChunk;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.buf.UriUtil;
/*     */ import org.apache.tomcat.util.http.RequestUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RewriteValve
/*     */   extends ValveBase
/*     */ {
/*  59 */   protected RewriteRule[] rules = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  65 */   protected ThreadLocal<Boolean> invoked = new ThreadLocal();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  73 */   protected String resourcePath = "rewrite.config";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */   protected boolean context = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */   protected boolean enabled = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  90 */   protected Map<String, RewriteMap> maps = new Hashtable();
/*     */   
/*     */   public boolean getEnabled()
/*     */   {
/*  94 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/*  98 */     this.enabled = enabled;
/*     */   }
/*     */   
/*     */   protected synchronized void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 104 */     super.startInternal();
/*     */     
/* 106 */     InputStream is = null;
/*     */     
/*     */     File file;
/* 109 */     if ((getContainer() instanceof Context)) {
/* 110 */       this.context = true;
/* 111 */       is = ((Context)getContainer()).getServletContext().getResourceAsStream("/WEB-INF/" + this.resourcePath);
/*     */       
/* 113 */       if (this.container.getLogger().isDebugEnabled()) {
/* 114 */         if (is == null) {
/* 115 */           this.container.getLogger().debug("No configuration resource found: /WEB-INF/" + this.resourcePath);
/*     */         } else {
/* 117 */           this.container.getLogger().debug("Read configuration from: /WEB-INF/" + this.resourcePath);
/*     */         }
/*     */       }
/* 120 */     } else if ((getContainer() instanceof Host)) {
/* 121 */       String resourceName = getHostConfigPath(this.resourcePath);
/* 122 */       file = new File(getConfigBase(), resourceName);
/*     */       try {
/* 124 */         if (!file.exists())
/*     */         {
/* 126 */           is = getClass().getClassLoader().getResourceAsStream(resourceName);
/*     */           
/* 128 */           if ((is != null) && (this.container.getLogger().isDebugEnabled())) {
/* 129 */             this.container.getLogger().debug("Read configuration from CL at " + resourceName);
/*     */           }
/*     */         } else {
/* 132 */           if (this.container.getLogger().isDebugEnabled()) {
/* 133 */             this.container.getLogger().debug("Read configuration from " + file.getAbsolutePath());
/*     */           }
/* 135 */           is = new FileInputStream(file);
/*     */         }
/* 137 */         if ((is == null) && (this.container.getLogger().isDebugEnabled())) {
/* 138 */           this.container.getLogger().debug("No configuration resource found: " + resourceName + " in " + getConfigBase() + " or in the classloader");
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 142 */         this.container.getLogger().error("Error opening configuration", e);
/*     */       }
/*     */     }
/*     */     
/* 146 */     if (is == null)
/*     */     {
/* 148 */       return;
/*     */     }
/*     */     try {
/* 151 */       InputStreamReader isr = new InputStreamReader(is, StandardCharsets.UTF_8);file = null;
/* 152 */       try { BufferedReader reader = new BufferedReader(isr);Throwable localThrowable3 = null;
/* 153 */         try { parse(reader);
/*     */         }
/*     */         catch (Throwable localThrowable1)
/*     */         {
/* 151 */           localThrowable3 = localThrowable1;throw localThrowable1; } finally {} } catch (Throwable localThrowable2) { file = localThrowable2;throw localThrowable2;
/*     */       }
/*     */       finally {
/* 154 */         if (isr != null) if (file != null) try { isr.close(); } catch (Throwable x2) { file.addSuppressed(x2); } else isr.close(); }
/*     */       return; } catch (IOException ioe) { this.container.getLogger().error("Error closing configuration", ioe);
/*     */     } finally {
/*     */       try {
/* 158 */         is.close();
/*     */       } catch (IOException e) {
/* 160 */         this.container.getLogger().error("Error closing configuration", e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void setConfiguration(String configuration)
/*     */     throws Exception
/*     */   {
/* 168 */     this.maps.clear();
/* 169 */     parse(new BufferedReader(new StringReader(configuration)));
/*     */   }
/*     */   
/*     */   public String getConfiguration() {
/* 173 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 175 */     for (int i = 0; i < this.rules.length; i++) {
/* 176 */       for (int j = 0; j < this.rules[i].getConditions().length; j++) {
/* 177 */         buffer.append(this.rules[i].getConditions()[j].toString()).append("\r\n");
/*     */       }
/* 179 */       buffer.append(this.rules[i].toString()).append("\r\n").append("\r\n");
/*     */     }
/* 181 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   protected void parse(BufferedReader reader) throws LifecycleException {
/* 185 */     ArrayList<RewriteRule> rules = new ArrayList();
/* 186 */     ArrayList<RewriteCond> conditions = new ArrayList();
/*     */     try {
/*     */       for (;;) {
/* 189 */         String line = reader.readLine();
/* 190 */         if (line == null) {
/*     */           break;
/*     */         }
/* 193 */         Object result = parse(line);
/* 194 */         if ((result instanceof RewriteRule)) {
/* 195 */           RewriteRule rule = (RewriteRule)result;
/* 196 */           if (this.container.getLogger().isDebugEnabled()) {
/* 197 */             this.container.getLogger().debug("Add rule with pattern " + rule.getPatternString() + " and substitution " + rule.getSubstitutionString());
/*     */           }
/*     */           
/* 200 */           for (int i = conditions.size() - 1; i > 0; i--) {
/* 201 */             if (((RewriteCond)conditions.get(i - 1)).isOrnext()) {
/* 202 */               ((RewriteCond)conditions.get(i)).setOrnext(true);
/*     */             }
/*     */           }
/* 205 */           for (int i = 0; i < conditions.size(); i++) {
/* 206 */             if (this.container.getLogger().isDebugEnabled()) {
/* 207 */               RewriteCond cond = (RewriteCond)conditions.get(i);
/* 208 */               this.container.getLogger().debug("Add condition " + cond.getCondPattern() + " test " + cond.getTestString() + " to rule with pattern " + rule.getPatternString() + " and substitution " + rule.getSubstitutionString() + (cond.isOrnext() ? " [OR]" : "") + (cond.isNocase() ? " [NC]" : ""));
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/* 214 */             rule.addCondition((RewriteCond)conditions.get(i));
/*     */           }
/* 216 */           conditions.clear();
/* 217 */           rules.add(rule);
/* 218 */         } else if ((result instanceof RewriteCond)) {
/* 219 */           conditions.add((RewriteCond)result);
/* 220 */         } else if ((result instanceof Object[])) {
/* 221 */           String mapName = (String)((Object[])(Object[])result)[0];
/* 222 */           RewriteMap map = (RewriteMap)((Object[])(Object[])result)[1];
/* 223 */           this.maps.put(mapName, map);
/* 224 */           if ((map instanceof Lifecycle))
/* 225 */             ((Lifecycle)map).start();
/*     */         }
/*     */       }
/*     */     } catch (IOException e) {
/* 229 */       this.container.getLogger().error("Error reading configuration", e);
/*     */     }
/*     */     
/* 232 */     this.rules = ((RewriteRule[])rules.toArray(new RewriteRule[0]));
/*     */     
/*     */ 
/* 235 */     for (int i = 0; i < this.rules.length; i++) {
/* 236 */       this.rules[i].parse(this.maps);
/*     */     }
/*     */   }
/*     */   
/*     */   protected synchronized void stopInternal() throws LifecycleException
/*     */   {
/* 242 */     super.stopInternal();
/* 243 */     Iterator<RewriteMap> values = this.maps.values().iterator();
/* 244 */     while (values.hasNext()) {
/* 245 */       RewriteMap map = (RewriteMap)values.next();
/* 246 */       if ((map instanceof Lifecycle)) {
/* 247 */         ((Lifecycle)map).stop();
/*     */       }
/*     */     }
/* 250 */     this.maps.clear();
/* 251 */     this.rules = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void invoke(org.apache.catalina.connector.Request request, Response response)
/*     */     throws IOException, ServletException
/*     */   {
/* 259 */     if ((!getEnabled()) || (this.rules == null) || (this.rules.length == 0)) {
/* 260 */       getNext().invoke(request, response);
/* 261 */       return;
/*     */     }
/*     */     
/* 264 */     if (Boolean.TRUE.equals(this.invoked.get())) {
/*     */       try {
/* 266 */         getNext().invoke(request, response);
/*     */       } finally {
/* 268 */         this.invoked.set(null);
/*     */       }
/* 270 */       return;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 275 */       Object resolver = new ResolverImpl(request);
/*     */       
/* 277 */       this.invoked.set(Boolean.TRUE);
/*     */       
/*     */ 
/*     */ 
/* 281 */       MessageBytes urlMB = this.context ? request.getRequestPathMB() : request.getDecodedRequestURIMB();
/* 282 */       urlMB.toChars();
/* 283 */       CharSequence url = urlMB.getCharChunk();
/* 284 */       CharSequence host = request.getServerName();
/* 285 */       boolean rewritten = false;
/* 286 */       boolean done = false;
/* 287 */       for (int i = 0; i < this.rules.length; i++) {
/* 288 */         RewriteRule rule = this.rules[i];
/* 289 */         CharSequence test = rule.isHost() ? host : url;
/* 290 */         CharSequence newtest = rule.evaluate(test, (Resolver)resolver);
/* 291 */         if ((newtest != null) && (!test.equals(newtest.toString()))) {
/* 292 */           if (this.container.getLogger().isDebugEnabled()) {
/* 293 */             this.container.getLogger().debug("Rewrote " + test + " as " + newtest + " with rule pattern " + rule.getPatternString());
/*     */           }
/*     */           
/* 296 */           if (rule.isHost()) {
/* 297 */             host = newtest;
/*     */           } else {
/* 299 */             url = newtest;
/*     */           }
/* 301 */           rewritten = true;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 307 */         if ((rule.isForbidden()) && (newtest != null)) {
/* 308 */           response.sendError(403);
/* 309 */           done = true;
/* 310 */           break;
/*     */         }
/*     */         
/* 313 */         if ((rule.isGone()) && (newtest != null)) {
/* 314 */           response.sendError(410);
/* 315 */           done = true;
/* 316 */           break;
/*     */         }
/*     */         
/* 319 */         if ((rule.isRedirect()) && (newtest != null))
/*     */         {
/* 321 */           String queryString = request.getQueryString();
/* 322 */           StringBuffer urlString = new StringBuffer(url);
/* 323 */           if ((queryString != null) && (queryString.length() > 0)) {
/* 324 */             int index = urlString.indexOf("?");
/* 325 */             if (index != -1)
/*     */             {
/* 327 */               if (rule.isQsappend()) {
/* 328 */                 urlString.append('&');
/* 329 */                 urlString.append(queryString);
/*     */ 
/*     */ 
/*     */               }
/* 333 */               else if (index == urlString.length() - 1) {
/* 334 */                 urlString.deleteCharAt(index);
/*     */               }
/*     */             } else {
/* 337 */               urlString.append('?');
/* 338 */               urlString.append(queryString);
/*     */             }
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 345 */           if ((this.context) && (urlString.charAt(0) == '/') && (!UriUtil.hasScheme(urlString))) {
/* 346 */             urlString.insert(0, request.getContext().getEncodedPath());
/*     */           }
/* 348 */           response.sendRedirect(urlString.toString());
/* 349 */           response.setStatus(rule.getRedirectCode());
/* 350 */           done = true;
/* 351 */           break;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 357 */         if ((rule.isCookie()) && (newtest != null)) {
/* 358 */           Cookie cookie = new Cookie(rule.getCookieName(), rule.getCookieResult());
/*     */           
/* 360 */           cookie.setDomain(rule.getCookieDomain());
/* 361 */           cookie.setMaxAge(rule.getCookieLifetime());
/* 362 */           cookie.setPath(rule.getCookiePath());
/* 363 */           cookie.setSecure(rule.isCookieSecure());
/* 364 */           cookie.setHttpOnly(rule.isCookieHttpOnly());
/* 365 */           response.addCookie(cookie);
/*     */         }
/*     */         
/* 368 */         if ((rule.isEnv()) && (newtest != null)) {
/* 369 */           for (int j = 0; j < rule.getEnvSize(); j++) {
/* 370 */             request.setAttribute(rule.getEnvName(j), rule.getEnvResult(j));
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 375 */         if ((rule.isType()) && (newtest != null)) {
/* 376 */           request.setContentType(rule.getTypeValue());
/*     */         }
/*     */         
/* 379 */         if ((rule.isQsappend()) && (newtest != null)) {
/* 380 */           String queryString = request.getQueryString();
/* 381 */           String urlString = url.toString();
/* 382 */           if ((urlString.indexOf('?') != -1) && (queryString != null)) {
/* 383 */             url = urlString + "&" + queryString;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 390 */         if ((rule.isChain()) && (newtest == null)) {
/* 391 */           for (int j = i; j < this.rules.length; j++) {
/* 392 */             if (!this.rules[j].isChain()) {
/* 393 */               i = j;
/* 394 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 400 */           if ((rule.isLast()) && (newtest != null)) {
/*     */             break;
/*     */           }
/*     */           
/* 404 */           if ((rule.isNext()) && (newtest != null)) {
/* 405 */             i = 0;
/*     */ 
/*     */ 
/*     */           }
/* 409 */           else if (newtest != null) {
/* 410 */             i += rule.getSkip();
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 415 */       if (rewritten) {
/* 416 */         if (!done)
/*     */         {
/* 418 */           String urlString = url.toString();
/* 419 */           String queryString = null;
/* 420 */           int queryIndex = urlString.indexOf('?');
/* 421 */           if (queryIndex != -1) {
/* 422 */             queryString = urlString.substring(queryIndex + 1);
/* 423 */             urlString = urlString.substring(0, queryIndex);
/*     */           }
/*     */           
/* 426 */           String contextPath = null;
/* 427 */           if (this.context) {
/* 428 */             contextPath = request.getContextPath();
/*     */           }
/* 430 */           request.getCoyoteRequest().requestURI().setString(null);
/* 431 */           CharChunk chunk = request.getCoyoteRequest().requestURI().getCharChunk();
/* 432 */           chunk.recycle();
/* 433 */           if (this.context) {
/* 434 */             chunk.append(contextPath);
/*     */           }
/* 436 */           chunk.append(URLEncoder.DEFAULT.encode(urlString));
/* 437 */           request.getCoyoteRequest().requestURI().toChars();
/*     */           
/* 439 */           request.getCoyoteRequest().decodedURI().setString(null);
/* 440 */           chunk = request.getCoyoteRequest().decodedURI().getCharChunk();
/* 441 */           chunk.recycle();
/* 442 */           if (this.context) {
/* 443 */             chunk.append(contextPath);
/*     */           }
/* 445 */           chunk.append(RequestUtil.normalize(urlString));
/* 446 */           request.getCoyoteRequest().decodedURI().toChars();
/*     */           
/* 448 */           if (queryString != null) {
/* 449 */             request.getCoyoteRequest().queryString().setString(null);
/* 450 */             chunk = request.getCoyoteRequest().queryString().getCharChunk();
/* 451 */             chunk.recycle();
/* 452 */             chunk.append(queryString);
/* 453 */             request.getCoyoteRequest().queryString().toChars();
/*     */           }
/*     */           
/* 456 */           if (!host.equals(request.getServerName())) {
/* 457 */             request.getCoyoteRequest().serverName().setString(null);
/* 458 */             chunk = request.getCoyoteRequest().serverName().getCharChunk();
/* 459 */             chunk.recycle();
/* 460 */             chunk.append(host.toString());
/* 461 */             request.getCoyoteRequest().serverName().toChars();
/*     */           }
/* 463 */           request.getMappingData().recycle();
/*     */           try
/*     */           {
/* 466 */             Connector connector = request.getConnector();
/* 467 */             if (!connector.getProtocolHandler().getAdapter().prepare(request.getCoyoteRequest(), response.getCoyoteResponse())) {
/*     */               return;
/*     */             }
/*     */             
/* 471 */             Pipeline pipeline = connector.getService().getContainer().getPipeline();
/* 472 */             request.setAsyncSupported(pipeline.isAsyncSupported());
/* 473 */             pipeline.getFirst().invoke(request, response);
/*     */           }
/*     */           catch (Exception localException) {}
/*     */         }
/*     */       }
/*     */       else {
/* 479 */         getNext().invoke(request, response);
/*     */       }
/*     */     }
/*     */     finally {
/* 483 */       this.invoked.set(null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected File getConfigBase()
/*     */   {
/* 493 */     File configBase = new File(System.getProperty("catalina.base"), "conf");
/*     */     
/* 495 */     if (!configBase.exists()) {
/* 496 */       return null;
/*     */     }
/* 498 */     return configBase;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getHostConfigPath(String resourceName)
/*     */   {
/* 510 */     StringBuffer result = new StringBuffer();
/* 511 */     Container container = getContainer();
/* 512 */     Container host = null;
/* 513 */     Container engine = null;
/* 514 */     while (container != null) {
/* 515 */       if ((container instanceof Host))
/* 516 */         host = container;
/* 517 */       if ((container instanceof Engine))
/* 518 */         engine = container;
/* 519 */       container = container.getParent();
/*     */     }
/* 521 */     if (engine != null) {
/* 522 */       result.append(engine.getName()).append('/');
/*     */     }
/* 524 */     if (host != null) {
/* 525 */       result.append(host.getName()).append('/');
/*     */     }
/* 527 */     result.append(resourceName);
/* 528 */     return result.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object parse(String line)
/*     */   {
/* 542 */     StringTokenizer tokenizer = new StringTokenizer(line);
/* 543 */     if (tokenizer.hasMoreTokens()) {
/* 544 */       String token = tokenizer.nextToken();
/* 545 */       if (token.equals("RewriteCond"))
/*     */       {
/* 547 */         RewriteCond condition = new RewriteCond();
/* 548 */         if (tokenizer.countTokens() < 2) {
/* 549 */           throw new IllegalArgumentException("Invalid line: " + line);
/*     */         }
/* 551 */         condition.setTestString(tokenizer.nextToken());
/* 552 */         condition.setCondPattern(tokenizer.nextToken());
/* 553 */         if (tokenizer.hasMoreTokens()) {
/* 554 */           String flags = tokenizer.nextToken();
/* 555 */           if ((flags.startsWith("[")) && (flags.endsWith("]"))) {
/* 556 */             flags = flags.substring(1, flags.length() - 1);
/*     */           }
/* 558 */           StringTokenizer flagsTokenizer = new StringTokenizer(flags, ",");
/* 559 */           while (flagsTokenizer.hasMoreElements()) {
/* 560 */             parseCondFlag(line, condition, flagsTokenizer.nextToken());
/*     */           }
/*     */         }
/* 563 */         return condition; }
/* 564 */       if (token.equals("RewriteRule"))
/*     */       {
/* 566 */         RewriteRule rule = new RewriteRule();
/* 567 */         if (tokenizer.countTokens() < 2) {
/* 568 */           throw new IllegalArgumentException("Invalid line: " + line);
/*     */         }
/* 570 */         rule.setPatternString(tokenizer.nextToken());
/* 571 */         rule.setSubstitutionString(tokenizer.nextToken());
/* 572 */         if (tokenizer.hasMoreTokens()) {
/* 573 */           String flags = tokenizer.nextToken();
/* 574 */           if ((flags.startsWith("[")) && (flags.endsWith("]"))) {
/* 575 */             flags = flags.substring(1, flags.length() - 1);
/*     */           }
/* 577 */           StringTokenizer flagsTokenizer = new StringTokenizer(flags, ",");
/* 578 */           while (flagsTokenizer.hasMoreElements()) {
/* 579 */             parseRuleFlag(line, rule, flagsTokenizer.nextToken());
/*     */           }
/*     */         }
/* 582 */         return rule; }
/* 583 */       if (token.equals("RewriteMap"))
/*     */       {
/* 585 */         if (tokenizer.countTokens() < 2) {
/* 586 */           throw new IllegalArgumentException("Invalid line: " + line);
/*     */         }
/* 588 */         String name = tokenizer.nextToken();
/* 589 */         String rewriteMapClassName = tokenizer.nextToken();
/* 590 */         RewriteMap map = null;
/*     */         try {
/* 592 */           map = (RewriteMap)Class.forName(rewriteMapClassName).newInstance();
/*     */         } catch (Exception e) {
/* 594 */           throw new IllegalArgumentException("Invalid map className: " + line);
/*     */         }
/* 596 */         if (tokenizer.hasMoreTokens()) {
/* 597 */           map.setParameters(tokenizer.nextToken());
/*     */         }
/* 599 */         Object[] result = new Object[2];
/* 600 */         result[0] = name;
/* 601 */         result[1] = map;
/* 602 */         return result; }
/* 603 */       if (!token.startsWith("#"))
/*     */       {
/*     */ 
/* 606 */         throw new IllegalArgumentException("Invalid line: " + line);
/*     */       }
/*     */     }
/* 609 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void parseCondFlag(String line, RewriteCond condition, String flag)
/*     */   {
/* 620 */     if ((flag.equals("NC")) || (flag.equals("nocase"))) {
/* 621 */       condition.setNocase(true);
/* 622 */     } else if ((flag.equals("OR")) || (flag.equals("ornext"))) {
/* 623 */       condition.setOrnext(true);
/*     */     } else {
/* 625 */       throw new IllegalArgumentException("Invalid flag in: " + line + " flags: " + flag);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void parseRuleFlag(String line, RewriteRule rule, String flag)
/*     */   {
/* 637 */     if ((flag.equals("chain")) || (flag.equals("C"))) {
/* 638 */       rule.setChain(true);
/* 639 */     } else if ((flag.startsWith("cookie=")) || (flag.startsWith("CO="))) {
/* 640 */       rule.setCookie(true);
/* 641 */       if (flag.startsWith("cookie")) {
/* 642 */         flag = flag.substring("cookie=".length());
/* 643 */       } else if (flag.startsWith("CO=")) {
/* 644 */         flag = flag.substring("CO=".length());
/*     */       }
/* 646 */       StringTokenizer tokenizer = new StringTokenizer(flag, ":");
/* 647 */       if (tokenizer.countTokens() < 2) {
/* 648 */         throw new IllegalArgumentException("Invalid flag in: " + line);
/*     */       }
/* 650 */       rule.setCookieName(tokenizer.nextToken());
/* 651 */       rule.setCookieValue(tokenizer.nextToken());
/* 652 */       if (tokenizer.hasMoreTokens()) {
/* 653 */         rule.setCookieDomain(tokenizer.nextToken());
/*     */       }
/* 655 */       if (tokenizer.hasMoreTokens()) {
/*     */         try {
/* 657 */           rule.setCookieLifetime(Integer.parseInt(tokenizer.nextToken()));
/*     */         } catch (NumberFormatException e) {
/* 659 */           throw new IllegalArgumentException("Invalid flag in: " + line, e);
/*     */         }
/*     */       }
/* 662 */       if (tokenizer.hasMoreTokens()) {
/* 663 */         rule.setCookiePath(tokenizer.nextToken());
/*     */       }
/* 665 */       if (tokenizer.hasMoreTokens()) {
/* 666 */         rule.setCookieSecure(Boolean.parseBoolean(tokenizer.nextToken()));
/*     */       }
/* 668 */       if (tokenizer.hasMoreTokens()) {
/* 669 */         rule.setCookieHttpOnly(Boolean.parseBoolean(tokenizer.nextToken()));
/*     */       }
/* 671 */     } else if ((flag.startsWith("env=")) || (flag.startsWith("E="))) {
/* 672 */       rule.setEnv(true);
/* 673 */       if (flag.startsWith("env=")) {
/* 674 */         flag = flag.substring("env=".length());
/* 675 */       } else if (flag.startsWith("E=")) {
/* 676 */         flag = flag.substring("E=".length());
/*     */       }
/* 678 */       int pos = flag.indexOf(':');
/* 679 */       if ((pos == -1) || (pos + 1 == flag.length())) {
/* 680 */         throw new IllegalArgumentException("Invalid flag in: " + line);
/*     */       }
/* 682 */       rule.addEnvName(flag.substring(0, pos));
/* 683 */       rule.addEnvValue(flag.substring(pos + 1));
/* 684 */     } else if ((flag.startsWith("forbidden")) || (flag.startsWith("F"))) {
/* 685 */       rule.setForbidden(true);
/* 686 */     } else if ((flag.startsWith("gone")) || (flag.startsWith("G"))) {
/* 687 */       rule.setGone(true);
/* 688 */     } else if ((flag.startsWith("host")) || (flag.startsWith("H"))) {
/* 689 */       rule.setHost(true);
/* 690 */     } else if ((flag.startsWith("last")) || (flag.startsWith("L"))) {
/* 691 */       rule.setLast(true);
/* 692 */     } else if ((flag.startsWith("nocase")) || (flag.startsWith("NC"))) {
/* 693 */       rule.setNocase(true);
/* 694 */     } else if ((flag.startsWith("noescape")) || (flag.startsWith("NE"))) {
/* 695 */       rule.setNoescape(true);
/* 696 */     } else if ((flag.startsWith("next")) || (flag.startsWith("N"))) {
/* 697 */       rule.setNext(true);
/*     */ 
/*     */ 
/*     */     }
/* 701 */     else if ((flag.startsWith("qsappend")) || (flag.startsWith("QSA"))) {
/* 702 */       rule.setQsappend(true);
/* 703 */     } else if ((flag.startsWith("redirect")) || (flag.startsWith("R"))) {
/* 704 */       if (flag.startsWith("redirect=")) {
/* 705 */         flag = flag.substring("redirect=".length());
/* 706 */         rule.setRedirect(true);
/* 707 */         rule.setRedirectCode(Integer.parseInt(flag));
/* 708 */       } else if (flag.startsWith("R=")) {
/* 709 */         flag = flag.substring("R=".length());
/* 710 */         rule.setRedirect(true);
/* 711 */         rule.setRedirectCode(Integer.parseInt(flag));
/*     */       } else {
/* 713 */         rule.setRedirect(true);
/* 714 */         rule.setRedirectCode(302);
/*     */       }
/* 716 */     } else if ((flag.startsWith("skip")) || (flag.startsWith("S"))) {
/* 717 */       if (flag.startsWith("skip=")) {
/* 718 */         flag = flag.substring("skip=".length());
/* 719 */       } else if (flag.startsWith("S=")) {
/* 720 */         flag = flag.substring("S=".length());
/*     */       }
/* 722 */       rule.setSkip(Integer.parseInt(flag));
/* 723 */     } else if ((flag.startsWith("type")) || (flag.startsWith("T"))) {
/* 724 */       if (flag.startsWith("type=")) {
/* 725 */         flag = flag.substring("type=".length());
/* 726 */       } else if (flag.startsWith("T=")) {
/* 727 */         flag = flag.substring("T=".length());
/*     */       }
/* 729 */       rule.setType(true);
/* 730 */       rule.setTypeValue(flag);
/*     */     } else {
/* 732 */       throw new IllegalArgumentException("Invalid flag in: " + line + " flag: " + flag);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\valves\rewrite\RewriteValve.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */