/*     */ package org.apache.catalina.users;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import org.apache.catalina.Group;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.UserDatabase;
/*     */ import org.apache.catalina.util.RequestUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MemoryUser
/*     */   extends AbstractUser
/*     */ {
/*     */   protected final MemoryUserDatabase database;
/*     */   
/*     */   MemoryUser(MemoryUserDatabase database, String username, String password, String fullName)
/*     */   {
/*  56 */     this.database = database;
/*  57 */     setUsername(username);
/*  58 */     setPassword(password);
/*  59 */     setFullName(fullName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  76 */   protected final ArrayList<Group> groups = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  82 */   protected final ArrayList<Role> roles = new ArrayList();
/*     */   
/*     */   /* Error */
/*     */   public Iterator<Group> getGroups()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 4	org/apache/catalina/users/MemoryUser:groups	Ljava/util/ArrayList;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 4	org/apache/catalina/users/MemoryUser:groups	Ljava/util/ArrayList;
/*     */     //   11: invokevirtual 10	java/util/ArrayList:iterator	()Ljava/util/Iterator;
/*     */     //   14: aload_1
/*     */     //   15: monitorexit
/*     */     //   16: areturn
/*     */     //   17: astore_2
/*     */     //   18: aload_1
/*     */     //   19: monitorexit
/*     */     //   20: aload_2
/*     */     //   21: athrow
/*     */     // Line number table:
/*     */     //   Java source line #94	-> byte code offset #0
/*     */     //   Java source line #95	-> byte code offset #7
/*     */     //   Java source line #96	-> byte code offset #17
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	22	0	this	MemoryUser
/*     */     //   5	14	1	Ljava/lang/Object;	Object
/*     */     //   17	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	16	17	finally
/*     */     //   17	20	17	finally
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Iterator<Role> getRoles()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 5	org/apache/catalina/users/MemoryUser:roles	Ljava/util/ArrayList;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 5	org/apache/catalina/users/MemoryUser:roles	Ljava/util/ArrayList;
/*     */     //   11: invokevirtual 10	java/util/ArrayList:iterator	()Ljava/util/Iterator;
/*     */     //   14: aload_1
/*     */     //   15: monitorexit
/*     */     //   16: areturn
/*     */     //   17: astore_2
/*     */     //   18: aload_1
/*     */     //   19: monitorexit
/*     */     //   20: aload_2
/*     */     //   21: athrow
/*     */     // Line number table:
/*     */     //   Java source line #107	-> byte code offset #0
/*     */     //   Java source line #108	-> byte code offset #7
/*     */     //   Java source line #109	-> byte code offset #17
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	22	0	this	MemoryUser
/*     */     //   5	14	1	Ljava/lang/Object;	Object
/*     */     //   17	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	16	17	finally
/*     */     //   17	20	17	finally
/*     */   }
/*     */   
/*     */   public UserDatabase getUserDatabase()
/*     */   {
/* 120 */     return this.database;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addGroup(Group group)
/*     */   {
/* 136 */     synchronized (this.groups) {
/* 137 */       if (!this.groups.contains(group)) {
/* 138 */         this.groups.add(group);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addRole(Role role)
/*     */   {
/* 153 */     synchronized (this.roles) {
/* 154 */       if (!this.roles.contains(role)) {
/* 155 */         this.roles.add(role);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean isInGroup(Group group)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 4	org/apache/catalina/users/MemoryUser:groups	Ljava/util/ArrayList;
/*     */     //   4: dup
/*     */     //   5: astore_2
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 4	org/apache/catalina/users/MemoryUser:groups	Ljava/util/ArrayList;
/*     */     //   11: aload_1
/*     */     //   12: invokevirtual 11	java/util/ArrayList:contains	(Ljava/lang/Object;)Z
/*     */     //   15: aload_2
/*     */     //   16: monitorexit
/*     */     //   17: ireturn
/*     */     //   18: astore_3
/*     */     //   19: aload_2
/*     */     //   20: monitorexit
/*     */     //   21: aload_3
/*     */     //   22: athrow
/*     */     // Line number table:
/*     */     //   Java source line #170	-> byte code offset #0
/*     */     //   Java source line #171	-> byte code offset #7
/*     */     //   Java source line #172	-> byte code offset #18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	23	0	this	MemoryUser
/*     */     //   0	23	1	group	Group
/*     */     //   5	15	2	Ljava/lang/Object;	Object
/*     */     //   18	4	3	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	17	18	finally
/*     */     //   18	21	18	finally
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean isInRole(Role role)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 5	org/apache/catalina/users/MemoryUser:roles	Ljava/util/ArrayList;
/*     */     //   4: dup
/*     */     //   5: astore_2
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 5	org/apache/catalina/users/MemoryUser:roles	Ljava/util/ArrayList;
/*     */     //   11: aload_1
/*     */     //   12: invokevirtual 11	java/util/ArrayList:contains	(Ljava/lang/Object;)Z
/*     */     //   15: aload_2
/*     */     //   16: monitorexit
/*     */     //   17: ireturn
/*     */     //   18: astore_3
/*     */     //   19: aload_2
/*     */     //   20: monitorexit
/*     */     //   21: aload_3
/*     */     //   22: athrow
/*     */     // Line number table:
/*     */     //   Java source line #187	-> byte code offset #0
/*     */     //   Java source line #188	-> byte code offset #7
/*     */     //   Java source line #189	-> byte code offset #18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	23	0	this	MemoryUser
/*     */     //   0	23	1	role	Role
/*     */     //   5	15	2	Ljava/lang/Object;	Object
/*     */     //   18	4	3	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	17	18	finally
/*     */     //   18	21	18	finally
/*     */   }
/*     */   
/*     */   public void removeGroup(Group group)
/*     */   {
/* 202 */     synchronized (this.groups) {
/* 203 */       this.groups.remove(group);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeGroups()
/*     */   {
/* 215 */     synchronized (this.groups) {
/* 216 */       this.groups.clear();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRole(Role role)
/*     */   {
/* 230 */     synchronized (this.roles) {
/* 231 */       this.roles.remove(role);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRoles()
/*     */   {
/* 243 */     synchronized (this.roles) {
/* 244 */       this.roles.clear();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toXml()
/*     */   {
/* 261 */     StringBuilder sb = new StringBuilder("<user username=\"");
/* 262 */     sb.append(RequestUtil.filter(this.username));
/* 263 */     sb.append("\" password=\"");
/* 264 */     sb.append(RequestUtil.filter(this.password));
/* 265 */     sb.append("\"");
/* 266 */     if (this.fullName != null) {
/* 267 */       sb.append(" fullName=\"");
/* 268 */       sb.append(RequestUtil.filter(this.fullName));
/* 269 */       sb.append("\"");
/*     */     }
/* 271 */     synchronized (this.groups) {
/* 272 */       if (this.groups.size() > 0) {
/* 273 */         sb.append(" groups=\"");
/* 274 */         int n = 0;
/* 275 */         Iterator<Group> values = this.groups.iterator();
/* 276 */         while (values.hasNext()) {
/* 277 */           if (n > 0) {
/* 278 */             sb.append(',');
/*     */           }
/* 280 */           n++;
/* 281 */           sb.append(RequestUtil.filter(((Group)values.next()).getGroupname()));
/*     */         }
/* 283 */         sb.append("\"");
/*     */       }
/*     */     }
/* 286 */     synchronized (this.roles) {
/* 287 */       if (this.roles.size() > 0) {
/* 288 */         sb.append(" roles=\"");
/* 289 */         int n = 0;
/* 290 */         Iterator<Role> values = this.roles.iterator();
/* 291 */         while (values.hasNext()) {
/* 292 */           if (n > 0) {
/* 293 */             sb.append(',');
/*     */           }
/* 295 */           n++;
/* 296 */           sb.append(RequestUtil.filter(((Role)values.next()).getRolename()));
/*     */         }
/* 298 */         sb.append("\"");
/*     */       }
/*     */     }
/* 301 */     sb.append("/>");
/* 302 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 312 */     StringBuilder sb = new StringBuilder("User username=\"");
/* 313 */     sb.append(RequestUtil.filter(this.username));
/* 314 */     sb.append("\"");
/* 315 */     if (this.fullName != null) {
/* 316 */       sb.append(", fullName=\"");
/* 317 */       sb.append(RequestUtil.filter(this.fullName));
/* 318 */       sb.append("\"");
/*     */     }
/* 320 */     synchronized (this.groups) {
/* 321 */       if (this.groups.size() > 0) {
/* 322 */         sb.append(", groups=\"");
/* 323 */         int n = 0;
/* 324 */         Iterator<Group> values = this.groups.iterator();
/* 325 */         while (values.hasNext()) {
/* 326 */           if (n > 0) {
/* 327 */             sb.append(',');
/*     */           }
/* 329 */           n++;
/* 330 */           sb.append(RequestUtil.filter(((Group)values.next()).getGroupname()));
/*     */         }
/* 332 */         sb.append("\"");
/*     */       }
/*     */     }
/* 335 */     synchronized (this.roles) {
/* 336 */       if (this.roles.size() > 0) {
/* 337 */         sb.append(", roles=\"");
/* 338 */         int n = 0;
/* 339 */         Iterator<Role> values = this.roles.iterator();
/* 340 */         while (values.hasNext()) {
/* 341 */           if (n > 0) {
/* 342 */             sb.append(',');
/*     */           }
/* 344 */           n++;
/* 345 */           sb.append(RequestUtil.filter(((Role)values.next()).getRolename()));
/*     */         }
/* 347 */         sb.append("\"");
/*     */       }
/*     */     }
/* 350 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\users\MemoryUser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */