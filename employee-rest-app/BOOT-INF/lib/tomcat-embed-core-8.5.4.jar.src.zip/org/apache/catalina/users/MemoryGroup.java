/*     */ package org.apache.catalina.users;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.User;
/*     */ import org.apache.catalina.UserDatabase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MemoryGroup
/*     */   extends AbstractGroup
/*     */ {
/*     */   protected final MemoryUserDatabase database;
/*     */   
/*     */   MemoryGroup(MemoryUserDatabase database, String groupname, String description)
/*     */   {
/*  55 */     this.database = database;
/*  56 */     setGroupname(groupname);
/*  57 */     setDescription(description);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  74 */   protected final ArrayList<Role> roles = new ArrayList();
/*     */   
/*     */   /* Error */
/*     */   public Iterator<Role> getRoles()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 4	org/apache/catalina/users/MemoryGroup:roles	Ljava/util/ArrayList;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 4	org/apache/catalina/users/MemoryGroup:roles	Ljava/util/ArrayList;
/*     */     //   11: invokevirtual 8	java/util/ArrayList:iterator	()Ljava/util/Iterator;
/*     */     //   14: aload_1
/*     */     //   15: monitorexit
/*     */     //   16: areturn
/*     */     //   17: astore_2
/*     */     //   18: aload_1
/*     */     //   19: monitorexit
/*     */     //   20: aload_2
/*     */     //   21: athrow
/*     */     // Line number table:
/*     */     //   Java source line #86	-> byte code offset #0
/*     */     //   Java source line #87	-> byte code offset #7
/*     */     //   Java source line #88	-> byte code offset #17
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	22	0	this	MemoryGroup
/*     */     //   5	14	1	Ljava/lang/Object;	Object
/*     */     //   17	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	16	17	finally
/*     */     //   17	20	17	finally
/*     */   }
/*     */   
/*     */   public UserDatabase getUserDatabase()
/*     */   {
/*  99 */     return this.database;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator<User> getUsers()
/*     */   {
/* 110 */     ArrayList<User> results = new ArrayList();
/* 111 */     Iterator<User> users = this.database.getUsers();
/* 112 */     while (users.hasNext()) {
/* 113 */       User user = (User)users.next();
/* 114 */       if (user.isInGroup(this)) {
/* 115 */         results.add(user);
/*     */       }
/*     */     }
/* 118 */     return results.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addRole(Role role)
/*     */   {
/* 134 */     synchronized (this.roles) {
/* 135 */       if (!this.roles.contains(role)) {
/* 136 */         this.roles.add(role);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean isInRole(Role role)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 4	org/apache/catalina/users/MemoryGroup:roles	Ljava/util/ArrayList;
/*     */     //   4: dup
/*     */     //   5: astore_2
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 4	org/apache/catalina/users/MemoryGroup:roles	Ljava/util/ArrayList;
/*     */     //   11: aload_1
/*     */     //   12: invokevirtual 15	java/util/ArrayList:contains	(Ljava/lang/Object;)Z
/*     */     //   15: aload_2
/*     */     //   16: monitorexit
/*     */     //   17: ireturn
/*     */     //   18: astore_3
/*     */     //   19: aload_2
/*     */     //   20: monitorexit
/*     */     //   21: aload_3
/*     */     //   22: athrow
/*     */     // Line number table:
/*     */     //   Java source line #151	-> byte code offset #0
/*     */     //   Java source line #152	-> byte code offset #7
/*     */     //   Java source line #153	-> byte code offset #18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	23	0	this	MemoryGroup
/*     */     //   0	23	1	role	Role
/*     */     //   5	15	2	Ljava/lang/Object;	Object
/*     */     //   18	4	3	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	17	18	finally
/*     */     //   18	21	18	finally
/*     */   }
/*     */   
/*     */   public void removeRole(Role role)
/*     */   {
/* 166 */     synchronized (this.roles) {
/* 167 */       this.roles.remove(role);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRoles()
/*     */   {
/* 179 */     synchronized (this.roles) {
/* 180 */       this.roles.clear();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 192 */     StringBuilder sb = new StringBuilder("<group groupname=\"");
/* 193 */     sb.append(this.groupname);
/* 194 */     sb.append("\"");
/* 195 */     if (this.description != null) {
/* 196 */       sb.append(" description=\"");
/* 197 */       sb.append(this.description);
/* 198 */       sb.append("\"");
/*     */     }
/* 200 */     synchronized (this.roles) {
/* 201 */       if (this.roles.size() > 0) {
/* 202 */         sb.append(" roles=\"");
/* 203 */         int n = 0;
/* 204 */         Iterator<Role> values = this.roles.iterator();
/* 205 */         while (values.hasNext()) {
/* 206 */           if (n > 0) {
/* 207 */             sb.append(',');
/*     */           }
/* 209 */           n++;
/* 210 */           sb.append(((Role)values.next()).getRolename());
/*     */         }
/* 212 */         sb.append("\"");
/*     */       }
/*     */     }
/* 215 */     sb.append("/>");
/* 216 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\users\MemoryGroup.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */