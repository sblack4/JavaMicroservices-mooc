/*    */ package org.apache.catalina.servlet4preview.http;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpServletRequestWrapper
/*    */   extends javax.servlet.http.HttpServletRequestWrapper
/*    */   implements HttpServletRequest
/*    */ {
/*    */   public HttpServletRequestWrapper(javax.servlet.http.HttpServletRequest request)
/*    */   {
/* 35 */     super(request);
/*    */   }
/*    */   
/*    */   private HttpServletRequest _getHttpServletRequest() {
/* 39 */     return (HttpServletRequest)super.getRequest();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Mapping getMapping()
/*    */   {
/* 52 */     return _getHttpServletRequest().getMapping();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isPushSupported()
/*    */   {
/* 65 */     return _getHttpServletRequest().isPushSupported();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PushBuilder getPushBuilder()
/*    */   {
/* 79 */     return _getHttpServletRequest().getPushBuilder();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\servlet4preview\http\HttpServletRequestWrapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */