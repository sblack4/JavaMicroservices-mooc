/*    */ package org.apache.catalina.servlet4preview;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Enumeration;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class GenericFilter
/*    */   implements Filter, FilterConfig, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private volatile FilterConfig filterConfig;
/*    */   
/*    */   public String getInitParameter(String name)
/*    */   {
/* 36 */     return getFilterConfig().getInitParameter(name);
/*    */   }
/*    */   
/*    */ 
/*    */   public Enumeration<String> getInitParameterNames()
/*    */   {
/* 42 */     return getFilterConfig().getInitParameterNames();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public FilterConfig getFilterConfig()
/*    */   {
/* 53 */     return this.filterConfig;
/*    */   }
/*    */   
/*    */ 
/*    */   public ServletContext getServletContext()
/*    */   {
/* 59 */     return getFilterConfig().getServletContext();
/*    */   }
/*    */   
/*    */   public void init(FilterConfig filterConfig)
/*    */     throws ServletException
/*    */   {
/* 65 */     this.filterConfig = filterConfig;
/* 66 */     init();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void init()
/*    */     throws ServletException
/*    */   {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getFilterName()
/*    */   {
/* 84 */     return getFilterConfig().getFilterName();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\servlet4preview\GenericFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */