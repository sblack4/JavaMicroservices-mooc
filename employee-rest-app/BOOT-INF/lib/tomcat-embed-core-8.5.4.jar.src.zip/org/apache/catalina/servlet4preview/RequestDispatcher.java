package org.apache.catalina.servlet4preview;

public abstract interface RequestDispatcher
  extends javax.servlet.RequestDispatcher
{
  public static final String FORWARD_MAPPING = "javax.servlet.forward.mapping";
  public static final String INCLUDE_MAPPING = "javax.servlet.include.mapping";
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\servlet4preview\RequestDispatcher.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */