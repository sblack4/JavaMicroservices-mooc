/*    */ package org.apache.catalina.servlet4preview.http;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.catalina.servlet4preview.GenericFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class HttpFilter
/*    */   extends GenericFilter
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*    */     throws IOException, ServletException
/*    */   {
/* 48 */     if (!(request instanceof HttpServletRequest)) {
/* 49 */       throw new ServletException(request + " not HttpServletRequest");
/*    */     }
/* 51 */     if (!(response instanceof HttpServletResponse)) {
/* 52 */       throw new ServletException(request + " not HttpServletResponse");
/*    */     }
/* 54 */     doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
/*    */     throws IOException, ServletException
/*    */   {
/* 94 */     chain.doFilter(request, response);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\servlet4preview\http\HttpFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */