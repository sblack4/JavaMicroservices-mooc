/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.RuntimeOperationsException;
/*     */ import javax.management.modelmbean.InvalidTargetObjectTypeException;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.ContainerListener;
/*     */ import org.apache.catalina.JmxEnabled;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.Pipeline;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.core.ContainerBase;
/*     */ import org.apache.catalina.core.StandardContext;
/*     */ import org.apache.catalina.core.StandardHost;
/*     */ import org.apache.catalina.startup.ContextConfig;
/*     */ import org.apache.catalina.startup.HostConfig;
/*     */ import org.apache.tomcat.util.modeler.BaseModelMBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContainerMBean
/*     */   extends BaseModelMBean
/*     */ {
/*     */   public ContainerMBean()
/*     */     throws MBeanException, RuntimeOperationsException
/*     */   {}
/*     */   
/*     */   public void addChild(String type, String name)
/*     */     throws MBeanException
/*     */   {
/*  71 */     Container contained = null;
/*     */     try {
/*  73 */       contained = (Container)Class.forName(type).newInstance();
/*  74 */       contained.setName(name);
/*     */       
/*  76 */       if ((contained instanceof StandardHost)) {
/*  77 */         HostConfig config = new HostConfig();
/*  78 */         contained.addLifecycleListener(config);
/*  79 */       } else if ((contained instanceof StandardContext)) {
/*  80 */         ContextConfig config = new ContextConfig();
/*  81 */         contained.addLifecycleListener(config);
/*     */       }
/*     */     }
/*     */     catch (InstantiationException e) {
/*  85 */       throw new MBeanException(e);
/*     */     } catch (IllegalAccessException e) {
/*  87 */       throw new MBeanException(e);
/*     */     } catch (ClassNotFoundException e) {
/*  89 */       throw new MBeanException(e);
/*     */     }
/*     */     
/*  92 */     boolean oldValue = true;
/*     */     
/*  94 */     ContainerBase container = null;
/*     */     try {
/*  96 */       container = (ContainerBase)getManagedResource();
/*  97 */       oldValue = container.getStartChildren();
/*  98 */       container.setStartChildren(false);
/*  99 */       container.addChild(contained);
/* 100 */       contained.init();
/*     */     } catch (InstanceNotFoundException e) {
/* 102 */       throw new MBeanException(e);
/*     */     } catch (RuntimeOperationsException e) {
/* 104 */       throw new MBeanException(e);
/*     */     } catch (InvalidTargetObjectTypeException e) {
/* 106 */       throw new MBeanException(e);
/*     */     } catch (LifecycleException e) {
/* 108 */       throw new MBeanException(e);
/*     */     } finally {
/* 110 */       if (container != null) {
/* 111 */         container.setStartChildren(oldValue);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeChild(String name)
/*     */     throws MBeanException
/*     */   {
/* 124 */     if (name != null) {
/*     */       try {
/* 126 */         Container container = (Container)getManagedResource();
/* 127 */         Container contained = container.findChild(name);
/* 128 */         container.removeChild(contained);
/*     */       } catch (InstanceNotFoundException e) {
/* 130 */         throw new MBeanException(e);
/*     */       } catch (RuntimeOperationsException e) {
/* 132 */         throw new MBeanException(e);
/*     */       } catch (InvalidTargetObjectTypeException e) {
/* 134 */         throw new MBeanException(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String addValve(String valveType)
/*     */     throws MBeanException
/*     */   {
/* 147 */     Valve valve = null;
/*     */     try {
/* 149 */       valve = (Valve)Class.forName(valveType).newInstance();
/*     */     } catch (InstantiationException e) {
/* 151 */       throw new MBeanException(e);
/*     */     } catch (IllegalAccessException e) {
/* 153 */       throw new MBeanException(e);
/*     */     } catch (ClassNotFoundException e) {
/* 155 */       throw new MBeanException(e);
/*     */     }
/*     */     
/* 158 */     if (valve == null) {
/* 159 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 163 */       Container container = (Container)getManagedResource();
/* 164 */       container.getPipeline().addValve(valve);
/*     */     } catch (InstanceNotFoundException e) {
/* 166 */       throw new MBeanException(e);
/*     */     } catch (RuntimeOperationsException e) {
/* 168 */       throw new MBeanException(e);
/*     */     } catch (InvalidTargetObjectTypeException e) {
/* 170 */       throw new MBeanException(e);
/*     */     }
/*     */     
/* 173 */     if ((valve instanceof JmxEnabled)) {
/* 174 */       return ((JmxEnabled)valve).getObjectName().toString();
/*     */     }
/* 176 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeValve(String valveName)
/*     */     throws MBeanException
/*     */   {
/* 188 */     Container container = null;
/*     */     try {
/* 190 */       container = (Container)getManagedResource();
/*     */     } catch (InstanceNotFoundException e) {
/* 192 */       throw new MBeanException(e);
/*     */     } catch (RuntimeOperationsException e) {
/* 194 */       throw new MBeanException(e);
/*     */     } catch (InvalidTargetObjectTypeException e) {
/* 196 */       throw new MBeanException(e);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 201 */       oname = new ObjectName(valveName);
/*     */     } catch (MalformedObjectNameException e) { ObjectName oname;
/* 203 */       throw new MBeanException(e);
/*     */     } catch (NullPointerException e) {
/* 205 */       throw new MBeanException(e);
/*     */     }
/*     */     ObjectName oname;
/* 208 */     if (container != null) {
/* 209 */       Valve[] valves = container.getPipeline().getValves();
/* 210 */       for (int i = 0; i < valves.length; i++) {
/* 211 */         if ((valves[i] instanceof JmxEnabled)) {
/* 212 */           ObjectName voname = ((JmxEnabled)valves[i]).getObjectName();
/*     */           
/* 214 */           if (voname.equals(oname)) {
/* 215 */             container.getPipeline().removeValve(valves[i]);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addLifecycleListener(String type)
/*     */     throws MBeanException
/*     */   {
/* 229 */     LifecycleListener listener = null;
/*     */     try {
/* 231 */       listener = (LifecycleListener)Class.forName(type).newInstance();
/*     */     } catch (InstantiationException e) {
/* 233 */       throw new MBeanException(e);
/*     */     } catch (IllegalAccessException e) {
/* 235 */       throw new MBeanException(e);
/*     */     } catch (ClassNotFoundException e) {
/* 237 */       throw new MBeanException(e);
/*     */     }
/*     */     
/* 240 */     if (listener != null) {
/*     */       try {
/* 242 */         Container container = (Container)getManagedResource();
/* 243 */         container.addLifecycleListener(listener);
/*     */       } catch (InstanceNotFoundException e) {
/* 245 */         throw new MBeanException(e);
/*     */       } catch (RuntimeOperationsException e) {
/* 247 */         throw new MBeanException(e);
/*     */       } catch (InvalidTargetObjectTypeException e) {
/* 249 */         throw new MBeanException(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeLifecycleListeners(String type)
/*     */     throws MBeanException
/*     */   {
/* 262 */     Container container = null;
/*     */     try {
/* 264 */       container = (Container)getManagedResource();
/*     */     } catch (InstanceNotFoundException e) {
/* 266 */       throw new MBeanException(e);
/*     */     } catch (RuntimeOperationsException e) {
/* 268 */       throw new MBeanException(e);
/*     */     } catch (InvalidTargetObjectTypeException e) {
/* 270 */       throw new MBeanException(e);
/*     */     }
/*     */     
/* 273 */     LifecycleListener[] listeners = container.findLifecycleListeners();
/* 274 */     for (LifecycleListener listener : listeners) {
/* 275 */       if (listener.getClass().getName().equals(type)) {
/* 276 */         container.removeLifecycleListener(listener);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] findLifecycleListenerNames()
/*     */     throws MBeanException
/*     */   {
/* 289 */     Container container = null;
/* 290 */     List<String> result = new ArrayList();
/*     */     try
/*     */     {
/* 293 */       container = (Container)getManagedResource();
/*     */     } catch (InstanceNotFoundException e) {
/* 295 */       throw new MBeanException(e);
/*     */     } catch (RuntimeOperationsException e) {
/* 297 */       throw new MBeanException(e);
/*     */     } catch (InvalidTargetObjectTypeException e) {
/* 299 */       throw new MBeanException(e);
/*     */     }
/*     */     
/* 302 */     LifecycleListener[] listeners = container.findLifecycleListeners();
/* 303 */     for (LifecycleListener listener : listeners) {
/* 304 */       result.add(listener.getClass().getName());
/*     */     }
/*     */     
/* 307 */     return (String[])result.toArray(new String[result.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] findContainerListenerNames()
/*     */     throws MBeanException
/*     */   {
/* 318 */     Container container = null;
/* 319 */     List<String> result = new ArrayList();
/*     */     try
/*     */     {
/* 322 */       container = (Container)getManagedResource();
/*     */     } catch (InstanceNotFoundException e) {
/* 324 */       throw new MBeanException(e);
/*     */     } catch (RuntimeOperationsException e) {
/* 326 */       throw new MBeanException(e);
/*     */     } catch (InvalidTargetObjectTypeException e) {
/* 328 */       throw new MBeanException(e);
/*     */     }
/*     */     
/* 331 */     ContainerListener[] listeners = container.findContainerListeners();
/* 332 */     for (ContainerListener listener : listeners) {
/* 333 */       result.add(listener.getClass().getName());
/*     */     }
/*     */     
/* 336 */     return (String[])result.toArray(new String[result.size()]);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\mbeans\ContainerMBean.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */