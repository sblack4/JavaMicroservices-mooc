/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.RuntimeOperationsException;
/*     */ import javax.management.modelmbean.InvalidTargetObjectTypeException;
/*     */ import org.apache.catalina.Executor;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.tomcat.util.modeler.BaseModelMBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceMBean
/*     */   extends BaseModelMBean
/*     */ {
/*     */   public ServiceMBean()
/*     */     throws MBeanException, RuntimeOperationsException
/*     */   {}
/*     */   
/*     */   public void addConnector(String address, int port, boolean isAjp, boolean isSSL)
/*     */     throws MBeanException
/*     */   {
/*     */     try
/*     */     {
/*  54 */       service = (Service)getManagedResource();
/*     */     } catch (InstanceNotFoundException e) { Service service;
/*  56 */       throw new MBeanException(e);
/*     */     } catch (RuntimeOperationsException e) {
/*  58 */       throw new MBeanException(e);
/*     */     } catch (InvalidTargetObjectTypeException e) {
/*  60 */       throw new MBeanException(e); }
/*     */     Service service;
/*  62 */     String protocol = isAjp ? "AJP/1.3" : "HTTP/1.1";
/*  63 */     Connector connector = new Connector(protocol);
/*  64 */     if ((address != null) && (address.length() > 0)) {
/*  65 */       connector.setProperty("address", address);
/*     */     }
/*  67 */     connector.setPort(port);
/*  68 */     connector.setSecure(isSSL);
/*  69 */     connector.setScheme(isSSL ? "https" : "http");
/*     */     
/*  71 */     service.addConnector(connector);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addExecutor(String type)
/*     */     throws MBeanException
/*     */   {
/*     */     try
/*     */     {
/*  84 */       service = (Service)getManagedResource();
/*     */     } catch (InstanceNotFoundException e) { Service service;
/*  86 */       throw new MBeanException(e);
/*     */     } catch (RuntimeOperationsException e) {
/*  88 */       throw new MBeanException(e);
/*     */     } catch (InvalidTargetObjectTypeException e) {
/*  90 */       throw new MBeanException(e);
/*     */     }
/*     */     Service service;
/*     */     try
/*     */     {
/*  95 */       executor = (Executor)Class.forName(type).newInstance();
/*     */     } catch (InstantiationException e) { Executor executor;
/*  97 */       throw new MBeanException(e);
/*     */     } catch (IllegalAccessException e) {
/*  99 */       throw new MBeanException(e);
/*     */     } catch (ClassNotFoundException e) {
/* 101 */       throw new MBeanException(e);
/*     */     }
/*     */     Executor executor;
/* 104 */     service.addExecutor(executor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] findConnectors()
/*     */     throws MBeanException
/*     */   {
/*     */     try
/*     */     {
/* 117 */       service = (Service)getManagedResource();
/*     */     } catch (InstanceNotFoundException e) { Service service;
/* 119 */       throw new MBeanException(e);
/*     */     } catch (RuntimeOperationsException e) {
/* 121 */       throw new MBeanException(e);
/*     */     } catch (InvalidTargetObjectTypeException e) {
/* 123 */       throw new MBeanException(e);
/*     */     }
/*     */     Service service;
/* 126 */     Connector[] connectors = service.findConnectors();
/* 127 */     String[] str = new String[connectors.length];
/*     */     
/* 129 */     for (int i = 0; i < connectors.length; i++) {
/* 130 */       str[i] = connectors[i].toString();
/*     */     }
/*     */     
/* 133 */     return str;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] findExecutors()
/*     */     throws MBeanException
/*     */   {
/*     */     try
/*     */     {
/* 146 */       service = (Service)getManagedResource();
/*     */     } catch (InstanceNotFoundException e) { Service service;
/* 148 */       throw new MBeanException(e);
/*     */     } catch (RuntimeOperationsException e) {
/* 150 */       throw new MBeanException(e);
/*     */     } catch (InvalidTargetObjectTypeException e) {
/* 152 */       throw new MBeanException(e);
/*     */     }
/*     */     Service service;
/* 155 */     Executor[] executors = service.findExecutors();
/* 156 */     String[] str = new String[executors.length];
/*     */     
/* 158 */     for (int i = 0; i < executors.length; i++) {
/* 159 */       str[i] = executors[i].toString();
/*     */     }
/*     */     
/* 162 */     return str;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getExecutor(String name)
/*     */     throws MBeanException
/*     */   {
/*     */     try
/*     */     {
/* 175 */       service = (Service)getManagedResource();
/*     */     } catch (InstanceNotFoundException e) { Service service;
/* 177 */       throw new MBeanException(e);
/*     */     } catch (RuntimeOperationsException e) {
/* 179 */       throw new MBeanException(e);
/*     */     } catch (InvalidTargetObjectTypeException e) {
/* 181 */       throw new MBeanException(e);
/*     */     }
/*     */     Service service;
/* 184 */     Executor executor = service.getExecutor(name);
/* 185 */     return executor.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\mbeans\ServiceMBean.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */