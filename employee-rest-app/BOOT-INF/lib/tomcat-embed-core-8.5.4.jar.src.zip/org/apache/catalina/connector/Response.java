/*      */ package org.apache.catalina.connector;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.nio.charset.Charset;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Enumeration;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Set;
/*      */ import java.util.TimeZone;
/*      */ import java.util.Vector;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletOutputStream;
/*      */ import javax.servlet.ServletResponse;
/*      */ import javax.servlet.SessionTrackingMode;
/*      */ import javax.servlet.http.Cookie;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import javax.servlet.http.HttpServletResponseWrapper;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.security.SecurityUtil;
/*      */ import org.apache.catalina.util.RequestUtil;
/*      */ import org.apache.catalina.util.SessionConfig;
/*      */ import org.apache.coyote.ActionCode;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.buf.CharChunk;
/*      */ import org.apache.tomcat.util.buf.MessageBytes;
/*      */ import org.apache.tomcat.util.buf.UEncoder;
/*      */ import org.apache.tomcat.util.buf.UEncoder.SafeCharsSet;
/*      */ import org.apache.tomcat.util.buf.UriUtil;
/*      */ import org.apache.tomcat.util.http.CookieProcessor;
/*      */ import org.apache.tomcat.util.http.FastHttpDateFormat;
/*      */ import org.apache.tomcat.util.http.MimeHeaders;
/*      */ import org.apache.tomcat.util.http.parser.MediaTypeCache;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Response
/*      */   implements HttpServletResponse
/*      */ {
/*   73 */   private static final Log log = LogFactory.getLog(Response.class);
/*   74 */   protected static final StringManager sm = StringManager.getManager(Response.class);
/*      */   
/*   76 */   private static final MediaTypeCache MEDIA_TYPE_CACHE = new MediaTypeCache(100);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   87 */   private static final boolean ENFORCE_ENCODING_IN_GET_WRITER = Boolean.parseBoolean(System.getProperty("org.apache.catalina.connector.Response.ENFORCE_ENCODING_IN_GET_WRITER", "true"));
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   98 */   protected SimpleDateFormat format = null;
/*      */   
/*      */   protected org.apache.coyote.Response coyoteResponse;
/*      */   
/*      */   protected OutputBuffer outputBuffer;
/*      */   
/*      */   protected CoyoteOutputStream outputStream;
/*      */   protected CoyoteWriter writer;
/*      */   
/*      */   public void setConnector(Connector connector)
/*      */   {
/*  109 */     if ("AJP/1.3".equals(connector.getProtocol()))
/*      */     {
/*  111 */       this.outputBuffer = new OutputBuffer(8184);
/*      */     } else {
/*  113 */       this.outputBuffer = new OutputBuffer();
/*      */     }
/*  115 */     this.outputStream = new CoyoteOutputStream(this.outputBuffer);
/*  116 */     this.writer = new CoyoteWriter(this.outputBuffer);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCoyoteResponse(org.apache.coyote.Response coyoteResponse)
/*      */   {
/*  131 */     this.coyoteResponse = coyoteResponse;
/*  132 */     this.outputBuffer.setResponse(coyoteResponse);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public org.apache.coyote.Response getCoyoteResponse()
/*      */   {
/*  139 */     return this.coyoteResponse;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Context getContext()
/*      */   {
/*  147 */     return this.request.getContext();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  172 */   protected boolean appCommitted = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  178 */   protected boolean included = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  184 */   private boolean isCharacterEncodingSet = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  215 */   private final AtomicInteger errorState = new AtomicInteger(0);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  221 */   protected boolean usingOutputStream = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  227 */   protected boolean usingWriter = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  233 */   protected final UEncoder urlEncoder = new UEncoder(UEncoder.SafeCharsSet.WITH_SLASH);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  239 */   protected final CharChunk redirectURLCC = new CharChunk();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  246 */   private final List<Cookie> cookies = new ArrayList();
/*      */   
/*  248 */   private HttpServletResponse applicationResponse = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void recycle()
/*      */   {
/*  259 */     this.cookies.clear();
/*  260 */     this.outputBuffer.recycle();
/*  261 */     this.usingOutputStream = false;
/*  262 */     this.usingWriter = false;
/*  263 */     this.appCommitted = false;
/*  264 */     this.included = false;
/*  265 */     this.errorState.set(0);
/*  266 */     this.isCharacterEncodingSet = false;
/*      */     
/*  268 */     this.applicationResponse = null;
/*  269 */     if ((Globals.IS_SECURITY_ENABLED) || (Connector.RECYCLE_FACADES)) {
/*  270 */       if (this.facade != null) {
/*  271 */         this.facade.clear();
/*  272 */         this.facade = null;
/*      */       }
/*  274 */       if (this.outputStream != null) {
/*  275 */         this.outputStream.clear();
/*  276 */         this.outputStream = null;
/*      */       }
/*  278 */       if (this.writer != null) {
/*  279 */         this.writer.clear();
/*  280 */         this.writer = null;
/*      */       }
/*      */     } else {
/*  283 */       this.writer.recycle();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public List<Cookie> getCookies()
/*      */   {
/*  290 */     return this.cookies;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getContentWritten()
/*      */   {
/*  302 */     return this.outputBuffer.getContentWritten();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getBytesWritten(boolean flush)
/*      */   {
/*  312 */     if (flush) {
/*      */       try {
/*  314 */         this.outputBuffer.flush();
/*      */       }
/*      */       catch (IOException localIOException) {}
/*      */     }
/*      */     
/*  319 */     return getCoyoteResponse().getBytesWritten(flush);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAppCommitted(boolean appCommitted)
/*      */   {
/*  328 */     this.appCommitted = appCommitted;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isAppCommitted()
/*      */   {
/*  338 */     return (this.appCommitted) || (isCommitted()) || (isSuspended()) || ((getContentLength() > 0) && (getContentWritten() >= getContentLength()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  347 */   protected Request request = null;
/*      */   
/*      */ 
/*      */ 
/*      */   public Request getRequest()
/*      */   {
/*  353 */     return this.request;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRequest(Request request)
/*      */   {
/*  362 */     this.request = request;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  369 */   protected ResponseFacade facade = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpServletResponse getResponse()
/*      */   {
/*  377 */     if (this.facade == null) {
/*  378 */       this.facade = new ResponseFacade(this);
/*      */     }
/*  380 */     if (this.applicationResponse == null) {
/*  381 */       this.applicationResponse = this.facade;
/*      */     }
/*  383 */     return this.applicationResponse;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setResponse(HttpServletResponse applicationResponse)
/*      */   {
/*  398 */     ServletResponse r = applicationResponse;
/*  399 */     while ((r instanceof HttpServletResponseWrapper)) {
/*  400 */       r = ((HttpServletResponseWrapper)r).getResponse();
/*      */     }
/*  402 */     if (r != this.facade) {
/*  403 */       throw new IllegalArgumentException(sm.getString("response.illegalWrap"));
/*      */     }
/*  405 */     this.applicationResponse = applicationResponse;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSuspended(boolean suspended)
/*      */   {
/*  415 */     this.outputBuffer.setSuspended(suspended);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isSuspended()
/*      */   {
/*  425 */     return this.outputBuffer.isSuspended();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isClosed()
/*      */   {
/*  435 */     return this.outputBuffer.isClosed();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setError()
/*      */   {
/*  445 */     boolean result = this.errorState.compareAndSet(0, 1);
/*  446 */     if (result) {
/*  447 */       Wrapper wrapper = getRequest().getWrapper();
/*  448 */       if (wrapper != null) {
/*  449 */         wrapper.incrementErrorCount();
/*      */       }
/*      */     }
/*  452 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isError()
/*      */   {
/*  462 */     return this.errorState.get() > 0;
/*      */   }
/*      */   
/*      */   public boolean isErrorReportRequired()
/*      */   {
/*  467 */     return this.errorState.get() == 1;
/*      */   }
/*      */   
/*      */   public boolean setErrorReported()
/*      */   {
/*  472 */     return this.errorState.compareAndSet(1, 2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void finishResponse()
/*      */     throws IOException
/*      */   {
/*  484 */     this.outputBuffer.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getContentLength()
/*      */   {
/*  492 */     return getCoyoteResponse().getContentLength();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getContentType()
/*      */   {
/*  502 */     return getCoyoteResponse().getContentType();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PrintWriter getReporter()
/*      */     throws IOException
/*      */   {
/*  519 */     if (this.outputBuffer.isNew()) {
/*  520 */       this.outputBuffer.checkConverter();
/*  521 */       if (this.writer == null) {
/*  522 */         this.writer = new CoyoteWriter(this.outputBuffer);
/*      */       }
/*  524 */       return this.writer;
/*      */     }
/*  526 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void flushBuffer()
/*      */     throws IOException
/*      */   {
/*  541 */     this.outputBuffer.flush();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getBufferSize()
/*      */   {
/*  550 */     return this.outputBuffer.getBufferSize();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCharacterEncoding()
/*      */   {
/*  559 */     return getCoyoteResponse().getCharacterEncoding();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ServletOutputStream getOutputStream()
/*      */     throws IOException
/*      */   {
/*  574 */     if (this.usingWriter) {
/*  575 */       throw new IllegalStateException(sm.getString("coyoteResponse.getOutputStream.ise"));
/*      */     }
/*      */     
/*      */ 
/*  579 */     this.usingOutputStream = true;
/*  580 */     if (this.outputStream == null) {
/*  581 */       this.outputStream = new CoyoteOutputStream(this.outputBuffer);
/*      */     }
/*  583 */     return this.outputStream;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Locale getLocale()
/*      */   {
/*  593 */     return getCoyoteResponse().getLocale();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PrintWriter getWriter()
/*      */     throws IOException
/*      */   {
/*  608 */     if (this.usingOutputStream) {
/*  609 */       throw new IllegalStateException(sm.getString("coyoteResponse.getWriter.ise"));
/*      */     }
/*      */     
/*      */ 
/*  613 */     if (ENFORCE_ENCODING_IN_GET_WRITER)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  626 */       setCharacterEncoding(getCharacterEncoding());
/*      */     }
/*      */     
/*  629 */     this.usingWriter = true;
/*  630 */     this.outputBuffer.checkConverter();
/*  631 */     if (this.writer == null) {
/*  632 */       this.writer = new CoyoteWriter(this.outputBuffer);
/*      */     }
/*  634 */     return this.writer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isCommitted()
/*      */   {
/*  645 */     return getCoyoteResponse().isCommitted();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void reset()
/*      */   {
/*  658 */     if (this.included) {
/*  659 */       return;
/*      */     }
/*      */     
/*  662 */     getCoyoteResponse().reset();
/*  663 */     this.outputBuffer.reset();
/*  664 */     this.usingOutputStream = false;
/*  665 */     this.usingWriter = false;
/*  666 */     this.isCharacterEncodingSet = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resetBuffer()
/*      */   {
/*  678 */     resetBuffer(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resetBuffer(boolean resetWriterStreamFlags)
/*      */   {
/*  695 */     if (isCommitted()) {
/*  696 */       throw new IllegalStateException(sm.getString("coyoteResponse.resetBuffer.ise"));
/*      */     }
/*      */     
/*      */ 
/*  700 */     this.outputBuffer.reset(resetWriterStreamFlags);
/*      */     
/*  702 */     if (resetWriterStreamFlags) {
/*  703 */       this.usingOutputStream = false;
/*  704 */       this.usingWriter = false;
/*  705 */       this.isCharacterEncodingSet = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBufferSize(int size)
/*      */   {
/*  722 */     if ((isCommitted()) || (!this.outputBuffer.isNew())) {
/*  723 */       throw new IllegalStateException(sm.getString("coyoteResponse.setBufferSize.ise"));
/*      */     }
/*      */     
/*      */ 
/*  727 */     this.outputBuffer.setBufferSize(size);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setContentLength(int length)
/*      */   {
/*  740 */     setContentLengthLong(length);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setContentLengthLong(long length)
/*      */   {
/*  746 */     if (isCommitted()) {
/*  747 */       return;
/*      */     }
/*      */     
/*      */ 
/*  751 */     if (this.included) {
/*  752 */       return;
/*      */     }
/*      */     
/*  755 */     getCoyoteResponse().setContentLength(length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setContentType(String type)
/*      */   {
/*  767 */     if (isCommitted()) {
/*  768 */       return;
/*      */     }
/*      */     
/*      */ 
/*  772 */     if (this.included) {
/*  773 */       return;
/*      */     }
/*      */     
/*  776 */     if (type == null) {
/*  777 */       getCoyoteResponse().setContentType(null);
/*  778 */       return;
/*      */     }
/*      */     
/*  781 */     String[] m = MEDIA_TYPE_CACHE.parse(type);
/*  782 */     if (m == null)
/*      */     {
/*      */ 
/*  785 */       getCoyoteResponse().setContentTypeNoCharset(type);
/*  786 */       return;
/*      */     }
/*      */     
/*  789 */     getCoyoteResponse().setContentTypeNoCharset(m[0]);
/*      */     
/*  791 */     if (m[1] != null)
/*      */     {
/*  793 */       if (!this.usingWriter) {
/*  794 */         getCoyoteResponse().setCharacterEncoding(m[1]);
/*  795 */         this.isCharacterEncodingSet = true;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCharacterEncoding(String charset)
/*      */   {
/*  811 */     if (isCommitted()) {
/*  812 */       return;
/*      */     }
/*      */     
/*      */ 
/*  816 */     if (this.included) {
/*  817 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  822 */     if (this.usingWriter) {
/*  823 */       return;
/*      */     }
/*      */     
/*  826 */     getCoyoteResponse().setCharacterEncoding(charset);
/*  827 */     this.isCharacterEncodingSet = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLocale(Locale locale)
/*      */   {
/*  840 */     if (isCommitted()) {
/*  841 */       return;
/*      */     }
/*      */     
/*      */ 
/*  845 */     if (this.included) {
/*  846 */       return;
/*      */     }
/*      */     
/*  849 */     getCoyoteResponse().setLocale(locale);
/*      */     
/*      */ 
/*      */ 
/*  853 */     if (this.usingWriter) {
/*  854 */       return;
/*      */     }
/*      */     
/*  857 */     if (this.isCharacterEncodingSet) {
/*  858 */       return;
/*      */     }
/*      */     
/*  861 */     String charset = getContext().getCharset(locale);
/*  862 */     if (charset != null) {
/*  863 */       getCoyoteResponse().setCharacterEncoding(charset);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getHeader(String name)
/*      */   {
/*  873 */     return getCoyoteResponse().getMimeHeaders().getHeader(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Collection<String> getHeaderNames()
/*      */   {
/*  880 */     MimeHeaders headers = getCoyoteResponse().getMimeHeaders();
/*  881 */     int n = headers.size();
/*  882 */     List<String> result = new ArrayList(n);
/*  883 */     for (int i = 0; i < n; i++) {
/*  884 */       result.add(headers.getName(i).toString());
/*      */     }
/*  886 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Collection<String> getHeaders(String name)
/*      */   {
/*  894 */     Enumeration<String> enumeration = getCoyoteResponse().getMimeHeaders().values(name);
/*      */     
/*  896 */     Vector<String> result = new Vector();
/*  897 */     while (enumeration.hasMoreElements()) {
/*  898 */       result.addElement(enumeration.nextElement());
/*      */     }
/*  900 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getMessage()
/*      */   {
/*  909 */     return getCoyoteResponse().getMessage();
/*      */   }
/*      */   
/*      */ 
/*      */   public int getStatus()
/*      */   {
/*  915 */     return getCoyoteResponse().getStatus();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addCookie(Cookie cookie)
/*      */   {
/*  931 */     if ((this.included) || (isCommitted())) {
/*  932 */       return;
/*      */     }
/*      */     
/*  935 */     this.cookies.add(cookie);
/*      */     
/*  937 */     String header = generateCookieString(cookie);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  942 */     addHeader("Set-Cookie", header, getContext().getCookieProcessor().getCharset());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addSessionCookieInternal(Cookie cookie)
/*      */   {
/*  952 */     if (isCommitted()) {
/*  953 */       return;
/*      */     }
/*      */     
/*  956 */     String name = cookie.getName();
/*  957 */     String headername = "Set-Cookie";
/*  958 */     String startsWith = name + "=";
/*  959 */     String header = generateCookieString(cookie);
/*  960 */     boolean set = false;
/*  961 */     MimeHeaders headers = getCoyoteResponse().getMimeHeaders();
/*  962 */     int n = headers.size();
/*  963 */     for (int i = 0; i < n; i++) {
/*  964 */       if ((headers.getName(i).toString().equals("Set-Cookie")) && 
/*  965 */         (headers.getValue(i).toString().startsWith(startsWith))) {
/*  966 */         headers.getValue(i).setString(header);
/*  967 */         set = true;
/*      */       }
/*      */     }
/*      */     
/*  971 */     if (!set) {
/*  972 */       addHeader("Set-Cookie", header);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String generateCookieString(final Cookie cookie)
/*      */   {
/*  981 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*  982 */       (String)AccessController.doPrivileged(new PrivilegedAction()
/*      */       {
/*      */         public String run() {
/*  985 */           return Response.this.getContext().getCookieProcessor().generateHeader(cookie);
/*      */         }
/*      */       });
/*      */     }
/*  989 */     return getContext().getCookieProcessor().generateHeader(cookie);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addDateHeader(String name, long value)
/*      */   {
/* 1003 */     if ((name == null) || (name.length() == 0)) {
/* 1004 */       return;
/*      */     }
/*      */     
/* 1007 */     if (isCommitted()) {
/* 1008 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1012 */     if (this.included) {
/* 1013 */       return;
/*      */     }
/*      */     
/* 1016 */     if (this.format == null) {
/* 1017 */       this.format = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US);
/*      */       
/* 1019 */       this.format.setTimeZone(TimeZone.getTimeZone("GMT"));
/*      */     }
/*      */     
/* 1022 */     addHeader(name, FastHttpDateFormat.formatDate(value, this.format));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addHeader(String name, String value)
/*      */   {
/* 1035 */     addHeader(name, value, null);
/*      */   }
/*      */   
/*      */ 
/*      */   private void addHeader(String name, String value, Charset charset)
/*      */   {
/* 1041 */     if ((name == null) || (name.length() == 0) || (value == null)) {
/* 1042 */       return;
/*      */     }
/*      */     
/* 1045 */     if (isCommitted()) {
/* 1046 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1050 */     if (this.included) {
/* 1051 */       return;
/*      */     }
/*      */     
/* 1054 */     char cc = name.charAt(0);
/* 1055 */     if (((cc == 'C') || (cc == 'c')) && 
/* 1056 */       (checkSpecialHeader(name, value))) {
/* 1057 */       return;
/*      */     }
/*      */     
/* 1060 */     getCoyoteResponse().addHeader(name, value, charset);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean checkSpecialHeader(String name, String value)
/*      */   {
/* 1074 */     if (name.equalsIgnoreCase("Content-Type")) {
/* 1075 */       setContentType(value);
/* 1076 */       return true;
/*      */     }
/* 1078 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addIntHeader(String name, int value)
/*      */   {
/* 1091 */     if ((name == null) || (name.length() == 0)) {
/* 1092 */       return;
/*      */     }
/*      */     
/* 1095 */     if (isCommitted()) {
/* 1096 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1100 */     if (this.included) {
/* 1101 */       return;
/*      */     }
/*      */     
/* 1104 */     addHeader(name, "" + value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsHeader(String name)
/*      */   {
/* 1119 */     char cc = name.charAt(0);
/* 1120 */     if ((cc == 'C') || (cc == 'c')) {
/* 1121 */       if (name.equalsIgnoreCase("Content-Type"))
/*      */       {
/* 1123 */         return getCoyoteResponse().getContentType() != null;
/*      */       }
/* 1125 */       if (name.equalsIgnoreCase("Content-Length"))
/*      */       {
/* 1127 */         return getCoyoteResponse().getContentLengthLong() != -1L;
/*      */       }
/*      */     }
/*      */     
/* 1131 */     return getCoyoteResponse().containsHeader(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String encodeRedirectURL(String url)
/*      */   {
/* 1145 */     if (isEncodeable(toAbsolute(url))) {
/* 1146 */       return toEncoded(url, this.request.getSessionInternal().getIdInternal());
/*      */     }
/* 1148 */     return url;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public String encodeRedirectUrl(String url)
/*      */   {
/* 1167 */     return encodeRedirectURL(url);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String encodeURL(String url)
/*      */   {
/*      */     try
/*      */     {
/* 1183 */       absolute = toAbsolute(url);
/*      */     } catch (IllegalArgumentException iae) {
/*      */       String absolute;
/* 1186 */       return url;
/*      */     }
/*      */     String absolute;
/* 1189 */     if (isEncodeable(absolute))
/*      */     {
/* 1191 */       if (url.equalsIgnoreCase("")) {
/* 1192 */         url = absolute;
/* 1193 */       } else if ((url.equals(absolute)) && (!hasPath(url))) {
/* 1194 */         url = url + '/';
/*      */       }
/* 1196 */       return toEncoded(url, this.request.getSessionInternal().getIdInternal());
/*      */     }
/* 1198 */     return url;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public String encodeUrl(String url)
/*      */   {
/* 1217 */     return encodeURL(url);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void sendAcknowledgement()
/*      */     throws IOException
/*      */   {
/* 1229 */     if (isCommitted()) {
/* 1230 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1234 */     if (this.included) {
/* 1235 */       return;
/*      */     }
/*      */     
/* 1238 */     getCoyoteResponse().action(ActionCode.ACK, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void sendError(int status)
/*      */     throws IOException
/*      */   {
/* 1254 */     sendError(status, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void sendError(int status, String message)
/*      */     throws IOException
/*      */   {
/* 1271 */     if (isCommitted()) {
/* 1272 */       throw new IllegalStateException(sm.getString("coyoteResponse.sendError.ise"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1277 */     if (this.included) {
/* 1278 */       return;
/*      */     }
/*      */     
/* 1281 */     setError();
/*      */     
/* 1283 */     getCoyoteResponse().setStatus(status);
/* 1284 */     getCoyoteResponse().setMessage(message);
/*      */     
/*      */ 
/* 1287 */     resetBuffer();
/*      */     
/*      */ 
/* 1290 */     setSuspended(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void sendRedirect(String location)
/*      */     throws IOException
/*      */   {
/* 1305 */     sendRedirect(location, 302);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void sendRedirect(String location, int status)
/*      */     throws IOException
/*      */   {
/* 1319 */     if (isCommitted()) {
/* 1320 */       throw new IllegalStateException(sm.getString("coyoteResponse.sendRedirect.ise"));
/*      */     }
/*      */     
/*      */ 
/* 1324 */     if (this.included) {
/* 1325 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1329 */     resetBuffer(true);
/*      */     
/*      */     try
/*      */     {
/*      */       String locationUri;
/*      */       String locationUri;
/* 1335 */       if ((getRequest().getCoyoteRequest().getSupportsRelativeRedirects()) && (getContext().getUseRelativeRedirects()))
/*      */       {
/* 1337 */         locationUri = location;
/*      */       } else {
/* 1339 */         locationUri = toAbsolute(location);
/*      */       }
/* 1341 */       setStatus(status);
/* 1342 */       setHeader("Location", locationUri);
/* 1343 */       if (getContext().getSendRedirectBody()) {
/* 1344 */         PrintWriter writer = getWriter();
/* 1345 */         writer.print(sm.getString("coyoteResponse.sendRedirect.note", new Object[] { RequestUtil.filter(locationUri) }));
/*      */         
/* 1347 */         flushBuffer();
/*      */       }
/*      */     } catch (IllegalArgumentException e) {
/* 1350 */       log.warn(sm.getString("response.sendRedirectFail", new Object[] { location }), e);
/* 1351 */       setStatus(404);
/*      */     }
/*      */     
/*      */ 
/* 1355 */     setSuspended(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDateHeader(String name, long value)
/*      */   {
/* 1368 */     if ((name == null) || (name.length() == 0)) {
/* 1369 */       return;
/*      */     }
/*      */     
/* 1372 */     if (isCommitted()) {
/* 1373 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1377 */     if (this.included) {
/* 1378 */       return;
/*      */     }
/*      */     
/* 1381 */     if (this.format == null) {
/* 1382 */       this.format = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US);
/*      */       
/* 1384 */       this.format.setTimeZone(TimeZone.getTimeZone("GMT"));
/*      */     }
/*      */     
/* 1387 */     setHeader(name, FastHttpDateFormat.formatDate(value, this.format));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHeader(String name, String value)
/*      */   {
/* 1400 */     if ((name == null) || (name.length() == 0) || (value == null)) {
/* 1401 */       return;
/*      */     }
/*      */     
/* 1404 */     if (isCommitted()) {
/* 1405 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1409 */     if (this.included) {
/* 1410 */       return;
/*      */     }
/*      */     
/* 1413 */     char cc = name.charAt(0);
/* 1414 */     if (((cc == 'C') || (cc == 'c')) && 
/* 1415 */       (checkSpecialHeader(name, value))) {
/* 1416 */       return;
/*      */     }
/*      */     
/* 1419 */     getCoyoteResponse().setHeader(name, value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIntHeader(String name, int value)
/*      */   {
/* 1432 */     if ((name == null) || (name.length() == 0)) {
/* 1433 */       return;
/*      */     }
/*      */     
/* 1436 */     if (isCommitted()) {
/* 1437 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1441 */     if (this.included) {
/* 1442 */       return;
/*      */     }
/*      */     
/* 1445 */     setHeader(name, "" + value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStatus(int status)
/*      */   {
/* 1457 */     setStatus(status, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void setStatus(int status, String message)
/*      */   {
/* 1475 */     if (isCommitted()) {
/* 1476 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1480 */     if (this.included) {
/* 1481 */       return;
/*      */     }
/*      */     
/* 1484 */     getCoyoteResponse().setStatus(status);
/* 1485 */     getCoyoteResponse().setMessage(message);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isEncodeable(final String location)
/*      */   {
/* 1509 */     if (location == null) {
/* 1510 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 1514 */     if (location.startsWith("#")) {
/* 1515 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 1519 */     final Request hreq = this.request;
/* 1520 */     final Session session = hreq.getSessionInternal(false);
/* 1521 */     if (session == null) {
/* 1522 */       return false;
/*      */     }
/* 1524 */     if (hreq.isRequestedSessionIdFromCookie()) {
/* 1525 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 1529 */     if (!hreq.getServletContext().getEffectiveSessionTrackingModes().contains(SessionTrackingMode.URL))
/*      */     {
/* 1531 */       return false;
/*      */     }
/*      */     
/* 1534 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 1535 */       ((Boolean)AccessController.doPrivileged(new PrivilegedAction()
/*      */       {
/*      */ 
/*      */         public Boolean run()
/*      */         {
/* 1540 */           return Boolean.valueOf(Response.this.doIsEncodeable(hreq, session, location));
/*      */         }
/*      */       })).booleanValue();
/*      */     }
/* 1544 */     return doIsEncodeable(hreq, session, location);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean doIsEncodeable(Request hreq, Session session, String location)
/*      */   {
/* 1551 */     URL url = null;
/*      */     try {
/* 1553 */       url = new URL(location);
/*      */     } catch (MalformedURLException e) {
/* 1555 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 1559 */     if (!hreq.getScheme().equalsIgnoreCase(url.getProtocol())) {
/* 1560 */       return false;
/*      */     }
/* 1562 */     if (!hreq.getServerName().equalsIgnoreCase(url.getHost())) {
/* 1563 */       return false;
/*      */     }
/* 1565 */     int serverPort = hreq.getServerPort();
/* 1566 */     if (serverPort == -1) {
/* 1567 */       if ("https".equals(hreq.getScheme())) {
/* 1568 */         serverPort = 443;
/*      */       } else {
/* 1570 */         serverPort = 80;
/*      */       }
/*      */     }
/* 1573 */     int urlPort = url.getPort();
/* 1574 */     if (urlPort == -1) {
/* 1575 */       if ("https".equals(url.getProtocol())) {
/* 1576 */         urlPort = 443;
/*      */       } else {
/* 1578 */         urlPort = 80;
/*      */       }
/*      */     }
/* 1581 */     if (serverPort != urlPort) {
/* 1582 */       return false;
/*      */     }
/*      */     
/* 1585 */     String contextPath = getContext().getPath();
/* 1586 */     if (contextPath != null) {
/* 1587 */       String file = url.getFile();
/* 1588 */       if (!file.startsWith(contextPath)) {
/* 1589 */         return false;
/*      */       }
/* 1591 */       String tok = ";" + SessionConfig.getSessionUriParamName(this.request.getContext()) + "=" + session.getIdInternal();
/*      */       
/*      */ 
/* 1594 */       if (file.indexOf(tok, contextPath.length()) >= 0) {
/* 1595 */         return false;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1600 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String toAbsolute(String location)
/*      */   {
/* 1618 */     if (location == null) {
/* 1619 */       return location;
/*      */     }
/*      */     
/* 1622 */     boolean leadingSlash = location.startsWith("/");
/*      */     
/* 1624 */     if (location.startsWith("//"))
/*      */     {
/* 1626 */       this.redirectURLCC.recycle();
/*      */       
/* 1628 */       String scheme = this.request.getScheme();
/*      */       try {
/* 1630 */         this.redirectURLCC.append(scheme, 0, scheme.length());
/* 1631 */         this.redirectURLCC.append(':');
/* 1632 */         this.redirectURLCC.append(location, 0, location.length());
/* 1633 */         return this.redirectURLCC.toString();
/*      */       } catch (IOException e) {
/* 1635 */         IllegalArgumentException iae = new IllegalArgumentException(location);
/*      */         
/* 1637 */         iae.initCause(e);
/* 1638 */         throw iae;
/*      */       }
/*      */     }
/* 1641 */     if ((leadingSlash) || (!UriUtil.hasScheme(location)))
/*      */     {
/* 1643 */       this.redirectURLCC.recycle();
/*      */       
/* 1645 */       String scheme = this.request.getScheme();
/* 1646 */       String name = this.request.getServerName();
/* 1647 */       int port = this.request.getServerPort();
/*      */       try
/*      */       {
/* 1650 */         this.redirectURLCC.append(scheme, 0, scheme.length());
/* 1651 */         this.redirectURLCC.append("://", 0, 3);
/* 1652 */         this.redirectURLCC.append(name, 0, name.length());
/* 1653 */         if (((scheme.equals("http")) && (port != 80)) || ((scheme.equals("https")) && (port != 443)))
/*      */         {
/* 1655 */           this.redirectURLCC.append(':');
/* 1656 */           String portS = port + "";
/* 1657 */           this.redirectURLCC.append(portS, 0, portS.length());
/*      */         }
/* 1659 */         if (!leadingSlash) {
/* 1660 */           String relativePath = this.request.getDecodedRequestURI();
/* 1661 */           int pos = relativePath.lastIndexOf('/');
/* 1662 */           CharChunk encodedURI = null;
/* 1663 */           final String frelativePath = relativePath;
/* 1664 */           final int fend = pos;
/* 1665 */           if (SecurityUtil.isPackageProtectionEnabled()) {
/*      */             try {
/* 1667 */               encodedURI = (CharChunk)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */               {
/*      */                 public CharChunk run() throws IOException
/*      */                 {
/* 1671 */                   return Response.this.urlEncoder.encodeURL(frelativePath, 0, fend);
/*      */                 }
/*      */               });
/*      */             } catch (PrivilegedActionException pae) {
/* 1675 */               IllegalArgumentException iae = new IllegalArgumentException(location);
/*      */               
/* 1677 */               iae.initCause(pae.getException());
/* 1678 */               throw iae;
/*      */             }
/*      */           } else {
/* 1681 */             encodedURI = this.urlEncoder.encodeURL(relativePath, 0, pos);
/*      */           }
/* 1683 */           this.redirectURLCC.append(encodedURI);
/* 1684 */           encodedURI.recycle();
/* 1685 */           this.redirectURLCC.append('/');
/*      */         }
/* 1687 */         this.redirectURLCC.append(location, 0, location.length());
/*      */         
/* 1689 */         normalize(this.redirectURLCC);
/*      */       } catch (IOException e) {
/* 1691 */         IllegalArgumentException iae = new IllegalArgumentException(location);
/*      */         
/* 1693 */         iae.initCause(e);
/* 1694 */         throw iae;
/*      */       }
/*      */       
/* 1697 */       return this.redirectURLCC.toString();
/*      */     }
/*      */     
/*      */ 
/* 1701 */     return location;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void normalize(CharChunk cc)
/*      */   {
/* 1716 */     int truncate = cc.indexOf('?');
/* 1717 */     if (truncate == -1) {
/* 1718 */       truncate = cc.indexOf('#');
/*      */     }
/* 1720 */     char[] truncateCC = null;
/* 1721 */     if (truncate > -1) {
/* 1722 */       truncateCC = Arrays.copyOfRange(cc.getBuffer(), cc.getStart() + truncate, cc.getEnd());
/*      */       
/* 1724 */       cc.setEnd(cc.getStart() + truncate);
/*      */     }
/*      */     
/* 1727 */     if ((cc.endsWith("/.")) || (cc.endsWith("/.."))) {
/*      */       try {
/* 1729 */         cc.append('/');
/*      */       } catch (IOException e) {
/* 1731 */         throw new IllegalArgumentException(cc.toString(), e);
/*      */       }
/*      */     }
/*      */     
/* 1735 */     char[] c = cc.getChars();
/* 1736 */     int start = cc.getStart();
/* 1737 */     int end = cc.getEnd();
/* 1738 */     int index = 0;
/* 1739 */     int startIndex = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1744 */     for (int i = 0; i < 3; i++) {
/* 1745 */       startIndex = cc.indexOf('/', startIndex + 1);
/*      */     }
/*      */     
/*      */ 
/* 1749 */     index = startIndex;
/*      */     for (;;) {
/* 1751 */       index = cc.indexOf("/./", 0, 3, index);
/* 1752 */       if (index < 0) {
/*      */         break;
/*      */       }
/* 1755 */       copyChars(c, start + index, start + index + 2, end - start - index - 2);
/*      */       
/* 1757 */       end -= 2;
/* 1758 */       cc.setEnd(end);
/*      */     }
/*      */     
/*      */ 
/* 1762 */     index = startIndex;
/*      */     for (;;)
/*      */     {
/* 1765 */       index = cc.indexOf("/../", 0, 4, index);
/* 1766 */       if (index < 0) {
/*      */         break;
/*      */       }
/*      */       
/* 1770 */       if (index == startIndex) {
/* 1771 */         throw new IllegalArgumentException();
/*      */       }
/* 1773 */       int index2 = -1;
/* 1774 */       for (int pos = start + index - 1; (pos >= 0) && (index2 < 0); pos--) {
/* 1775 */         if (c[pos] == '/') {
/* 1776 */           index2 = pos;
/*      */         }
/*      */       }
/* 1779 */       copyChars(c, start + index2, start + index + 3, end - start - index - 3);
/*      */       
/* 1781 */       end = end + index2 - index - 3;
/* 1782 */       cc.setEnd(end);
/* 1783 */       index = index2;
/*      */     }
/*      */     
/*      */ 
/* 1787 */     if (truncateCC != null) {
/*      */       try {
/* 1789 */         cc.append(truncateCC, 0, truncateCC.length);
/*      */       } catch (IOException ioe) {
/* 1791 */         throw new IllegalArgumentException(ioe);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void copyChars(char[] c, int dest, int src, int len) {
/* 1797 */     for (int pos = 0; pos < len; pos++) {
/* 1798 */       c[(pos + dest)] = c[(pos + src)];
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean hasPath(String uri)
/*      */   {
/* 1810 */     int pos = uri.indexOf("://");
/* 1811 */     if (pos < 0) {
/* 1812 */       return false;
/*      */     }
/* 1814 */     pos = uri.indexOf('/', pos + 3);
/* 1815 */     if (pos < 0) {
/* 1816 */       return false;
/*      */     }
/* 1818 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String toEncoded(String url, String sessionId)
/*      */   {
/* 1831 */     if ((url == null) || (sessionId == null)) {
/* 1832 */       return url;
/*      */     }
/*      */     
/* 1835 */     String path = url;
/* 1836 */     String query = "";
/* 1837 */     String anchor = "";
/* 1838 */     int question = url.indexOf('?');
/* 1839 */     if (question >= 0) {
/* 1840 */       path = url.substring(0, question);
/* 1841 */       query = url.substring(question);
/*      */     }
/* 1843 */     int pound = path.indexOf('#');
/* 1844 */     if (pound >= 0) {
/* 1845 */       anchor = path.substring(pound);
/* 1846 */       path = path.substring(0, pound);
/*      */     }
/* 1848 */     StringBuilder sb = new StringBuilder(path);
/* 1849 */     if (sb.length() > 0) {
/* 1850 */       sb.append(";");
/* 1851 */       sb.append(SessionConfig.getSessionUriParamName(this.request.getContext()));
/*      */       
/* 1853 */       sb.append("=");
/* 1854 */       sb.append(sessionId);
/*      */     }
/* 1856 */     sb.append(anchor);
/* 1857 */     sb.append(query);
/* 1858 */     return sb.toString();
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\connector\Response.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */