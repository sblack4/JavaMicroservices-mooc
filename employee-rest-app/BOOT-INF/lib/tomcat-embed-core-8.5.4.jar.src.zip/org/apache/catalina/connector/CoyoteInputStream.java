/*     */ package org.apache.catalina.connector;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import javax.servlet.ReadListener;
/*     */ import javax.servlet.ServletInputStream;
/*     */ import org.apache.catalina.security.SecurityUtil;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CoyoteInputStream
/*     */   extends ServletInputStream
/*     */ {
/*  37 */   protected static final StringManager sm = StringManager.getManager(CoyoteInputStream.class);
/*     */   
/*     */   protected InputBuffer ib;
/*     */   
/*     */ 
/*     */   protected CoyoteInputStream(InputBuffer ib)
/*     */   {
/*  44 */     this.ib = ib;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void clear()
/*     */   {
/*  52 */     this.ib = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object clone()
/*     */     throws CloneNotSupportedException
/*     */   {
/*  61 */     throw new CloneNotSupportedException();
/*     */   }
/*     */   
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/*  67 */     checkNonBlockingRead();
/*     */     
/*  69 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try
/*     */       {
/*  72 */         Integer result = (Integer)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */         {
/*     */ 
/*     */           public Integer run()
/*     */             throws IOException
/*     */           {
/*  78 */             Integer integer = Integer.valueOf(CoyoteInputStream.this.ib.readByte());
/*  79 */             return integer;
/*     */           }
/*     */           
/*  82 */         });
/*  83 */         return result.intValue();
/*     */       } catch (PrivilegedActionException pae) {
/*  85 */         Exception e = pae.getException();
/*  86 */         if ((e instanceof IOException)) {
/*  87 */           throw ((IOException)e);
/*     */         }
/*  89 */         throw new RuntimeException(e.getMessage(), e);
/*     */       }
/*     */     }
/*     */     
/*  93 */     return this.ib.readByte();
/*     */   }
/*     */   
/*     */ 
/*     */   public int available()
/*     */     throws IOException
/*     */   {
/* 100 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 102 */         Integer result = (Integer)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */         {
/*     */ 
/*     */           public Integer run()
/*     */             throws IOException
/*     */           {
/* 108 */             Integer integer = Integer.valueOf(CoyoteInputStream.this.ib.available());
/* 109 */             return integer;
/*     */           }
/*     */           
/* 112 */         });
/* 113 */         return result.intValue();
/*     */       } catch (PrivilegedActionException pae) {
/* 115 */         Exception e = pae.getException();
/* 116 */         if ((e instanceof IOException)) {
/* 117 */           throw ((IOException)e);
/*     */         }
/* 119 */         throw new RuntimeException(e.getMessage(), e);
/*     */       }
/*     */     }
/*     */     
/* 123 */     return this.ib.available();
/*     */   }
/*     */   
/*     */   public int read(final byte[] b)
/*     */     throws IOException
/*     */   {
/* 129 */     checkNonBlockingRead();
/*     */     
/* 131 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 133 */         Integer result = (Integer)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */         {
/*     */ 
/*     */           public Integer run()
/*     */             throws IOException
/*     */           {
/* 139 */             Integer integer = Integer.valueOf(CoyoteInputStream.this.ib.read(b, 0, b.length));
/*     */             
/* 141 */             return integer;
/*     */           }
/*     */           
/* 144 */         });
/* 145 */         return result.intValue();
/*     */       } catch (PrivilegedActionException pae) {
/* 147 */         Exception e = pae.getException();
/* 148 */         if ((e instanceof IOException)) {
/* 149 */           throw ((IOException)e);
/*     */         }
/* 151 */         throw new RuntimeException(e.getMessage(), e);
/*     */       }
/*     */     }
/*     */     
/* 155 */     return this.ib.read(b, 0, b.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int read(final byte[] b, final int off, final int len)
/*     */     throws IOException
/*     */   {
/* 163 */     checkNonBlockingRead();
/*     */     
/* 165 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 167 */         Integer result = (Integer)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */         {
/*     */ 
/*     */           public Integer run()
/*     */             throws IOException
/*     */           {
/* 173 */             Integer integer = Integer.valueOf(CoyoteInputStream.this.ib.read(b, off, len));
/*     */             
/* 175 */             return integer;
/*     */           }
/*     */           
/* 178 */         });
/* 179 */         return result.intValue();
/*     */       } catch (PrivilegedActionException pae) {
/* 181 */         Exception e = pae.getException();
/* 182 */         if ((e instanceof IOException)) {
/* 183 */           throw ((IOException)e);
/*     */         }
/* 185 */         throw new RuntimeException(e.getMessage(), e);
/*     */       }
/*     */     }
/*     */     
/* 189 */     return this.ib.read(b, off, len);
/*     */   }
/*     */   
/*     */ 
/*     */   public int readLine(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 196 */     return super.readLine(b, off, len);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 208 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 210 */         AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */         {
/*     */           public Void run()
/*     */             throws IOException
/*     */           {
/* 215 */             CoyoteInputStream.this.ib.close();
/* 216 */             return null;
/*     */           }
/*     */         });
/*     */       }
/*     */       catch (PrivilegedActionException pae) {
/* 221 */         Exception e = pae.getException();
/* 222 */         if ((e instanceof IOException)) {
/* 223 */           throw ((IOException)e);
/*     */         }
/* 225 */         throw new RuntimeException(e.getMessage(), e);
/*     */       }
/*     */       
/*     */     } else {
/* 229 */       this.ib.close();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isFinished()
/*     */   {
/* 235 */     return this.ib.isFinished();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isReady()
/*     */   {
/* 241 */     return this.ib.isReady();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setReadListener(ReadListener listener)
/*     */   {
/* 247 */     this.ib.setReadListener(listener);
/*     */   }
/*     */   
/*     */   private void checkNonBlockingRead()
/*     */   {
/* 252 */     if ((!this.ib.isBlocking()) && (!this.ib.isReady())) {
/* 253 */       throw new IllegalStateException(sm.getString("coyoteInputStream.nbNotready"));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\connector\CoyoteInputStream.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */