/*      */ package org.apache.catalina.connector;
/*      */ 
/*      */ import java.net.InetAddress;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Locale;
/*      */ import javax.management.ObjectName;
/*      */ import org.apache.catalina.Executor;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Service;
/*      */ import org.apache.catalina.core.AprLifecycleListener;
/*      */ import org.apache.catalina.util.LifecycleMBeanBase;
/*      */ import org.apache.coyote.Adapter;
/*      */ import org.apache.coyote.ProtocolHandler;
/*      */ import org.apache.coyote.UpgradeProtocol;
/*      */ import org.apache.coyote.http11.AbstractHttp11JsseProtocol;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.IntrospectionUtils;
/*      */ import org.apache.tomcat.util.net.SSLHostConfig;
/*      */ import org.apache.tomcat.util.net.openssl.OpenSSLImplementation;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Connector
/*      */   extends LifecycleMBeanBase
/*      */ {
/*   53 */   private static final Log log = LogFactory.getLog(Connector.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   59 */   public static final boolean RECYCLE_FACADES = Boolean.parseBoolean(System.getProperty("org.apache.catalina.connector.RECYCLE_FACADES", "false"));
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Connector()
/*      */   {
/*   66 */     this(null);
/*      */   }
/*      */   
/*      */   public Connector(String protocol) {
/*   70 */     setProtocol(protocol);
/*      */     
/*   72 */     ProtocolHandler p = null;
/*      */     try {
/*   74 */       Class<?> clazz = Class.forName(this.protocolHandlerClassName);
/*   75 */       p = (ProtocolHandler)clazz.newInstance();
/*      */     } catch (Exception e) {
/*   77 */       log.error(sm.getString("coyoteConnector.protocolHandlerInstantiationFailed"), e);
/*      */     }
/*      */     finally {
/*   80 */       this.protocolHandler = p;
/*      */     }
/*      */     
/*   83 */     if (!Globals.STRICT_SERVLET_COMPLIANCE) {
/*   84 */       this.URIEncoding = "UTF-8";
/*   85 */       this.URIEncodingLower = this.URIEncoding.toLowerCase(Locale.ENGLISH);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   96 */   protected Service service = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  102 */   protected boolean allowTrace = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  108 */   protected long asyncTimeout = 30000L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  114 */   protected boolean enableLookups = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  120 */   protected boolean xpoweredBy = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  126 */   protected int port = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  135 */   protected String proxyName = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  144 */   protected int proxyPort = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  150 */   protected int redirectPort = 443;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  157 */   protected String scheme = "http";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  164 */   protected boolean secure = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  170 */   protected static final StringManager sm = StringManager.getManager(Connector.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  178 */   protected int maxParameterCount = 10000;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  184 */   protected int maxPostSize = 2097152;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  191 */   protected int maxSavePostSize = 4096;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  197 */   protected String parseBodyMethods = "POST";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected HashSet<String> parseBodyMethodsSet;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  208 */   protected boolean useIPVHosts = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  215 */   protected String protocolHandlerClassName = "org.apache.coyote.http11.Http11NioProtocol";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final ProtocolHandler protocolHandler;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  228 */   protected Adapter adapter = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  234 */   protected String URIEncoding = null;
/*  235 */   protected String URIEncodingLower = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  241 */   protected boolean useBodyEncodingForURI = false;
/*      */   
/*      */ 
/*  244 */   protected static final HashMap<String, String> replacements = new HashMap();
/*      */   
/*      */   static {
/*  247 */     replacements.put("acceptCount", "backlog");
/*  248 */     replacements.put("connectionLinger", "soLinger");
/*  249 */     replacements.put("connectionTimeout", "soTimeout");
/*  250 */     replacements.put("rootFile", "rootfile");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getProperty(String name)
/*      */   {
/*  263 */     String repl = name;
/*  264 */     if (replacements.get(name) != null) {
/*  265 */       repl = (String)replacements.get(name);
/*      */     }
/*  267 */     return IntrospectionUtils.getProperty(this.protocolHandler, repl);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setProperty(String name, String value)
/*      */   {
/*  279 */     String repl = name;
/*  280 */     if (replacements.get(name) != null) {
/*  281 */       repl = (String)replacements.get(name);
/*      */     }
/*  283 */     return IntrospectionUtils.setProperty(this.protocolHandler, repl, value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getAttribute(String name)
/*      */   {
/*  293 */     return getProperty(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAttribute(String name, Object value)
/*      */   {
/*  304 */     setProperty(name, String.valueOf(value));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Service getService()
/*      */   {
/*  313 */     return this.service;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setService(Service service)
/*      */   {
/*  325 */     this.service = service;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getAllowTrace()
/*      */   {
/*  335 */     return this.allowTrace;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAllowTrace(boolean allowTrace)
/*      */   {
/*  347 */     this.allowTrace = allowTrace;
/*  348 */     setProperty("allowTrace", String.valueOf(allowTrace));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getAsyncTimeout()
/*      */   {
/*  358 */     return this.asyncTimeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAsyncTimeout(long asyncTimeout)
/*      */   {
/*  370 */     this.asyncTimeout = asyncTimeout;
/*  371 */     setProperty("asyncTimeout", String.valueOf(asyncTimeout));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getEnableLookups()
/*      */   {
/*  381 */     return this.enableLookups;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEnableLookups(boolean enableLookups)
/*      */   {
/*  393 */     this.enableLookups = enableLookups;
/*  394 */     setProperty("enableLookups", String.valueOf(enableLookups));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxHeaderCount()
/*      */   {
/*  404 */     return ((Integer)getProperty("maxHeaderCount")).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxHeaderCount(int maxHeaderCount)
/*      */   {
/*  414 */     setProperty("maxHeaderCount", String.valueOf(maxHeaderCount));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxParameterCount()
/*      */   {
/*  423 */     return this.maxParameterCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxParameterCount(int maxParameterCount)
/*      */   {
/*  435 */     this.maxParameterCount = maxParameterCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxPostSize()
/*      */   {
/*  445 */     return this.maxPostSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxPostSize(int maxPostSize)
/*      */   {
/*  459 */     this.maxPostSize = maxPostSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxSavePostSize()
/*      */   {
/*  469 */     return this.maxSavePostSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxSavePostSize(int maxSavePostSize)
/*      */   {
/*  483 */     this.maxSavePostSize = maxSavePostSize;
/*  484 */     setProperty("maxSavePostSize", String.valueOf(maxSavePostSize));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getParseBodyMethods()
/*      */   {
/*  493 */     return this.parseBodyMethods;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParseBodyMethods(String methods)
/*      */   {
/*  505 */     HashSet<String> methodSet = new HashSet();
/*      */     
/*  507 */     if (null != methods) {
/*  508 */       methodSet.addAll(Arrays.asList(methods.split("\\s*,\\s*")));
/*      */     }
/*      */     
/*  511 */     if (methodSet.contains("TRACE")) {
/*  512 */       throw new IllegalArgumentException(sm.getString("coyoteConnector.parseBodyMethodNoTrace"));
/*      */     }
/*      */     
/*  515 */     this.parseBodyMethods = methods;
/*  516 */     this.parseBodyMethodsSet = methodSet;
/*      */   }
/*      */   
/*      */ 
/*      */   protected boolean isParseBodyMethod(String method)
/*      */   {
/*  522 */     return this.parseBodyMethodsSet.contains(method);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPort()
/*      */   {
/*  533 */     return this.port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPort(int port)
/*      */   {
/*  545 */     this.port = port;
/*  546 */     setProperty("port", String.valueOf(port));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLocalPort()
/*      */   {
/*  557 */     return ((Integer)getProperty("localPort")).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProtocol()
/*      */   {
/*  565 */     if ((("org.apache.coyote.http11.Http11NioProtocol".equals(getProtocolHandlerClassName())) && ((!AprLifecycleListener.isAprAvailable()) || (!AprLifecycleListener.getUseAprConnector()))) || (("org.apache.coyote.http11.Http11AprProtocol".equals(getProtocolHandlerClassName())) && (AprLifecycleListener.getUseAprConnector())))
/*      */     {
/*      */ 
/*      */ 
/*  569 */       return "HTTP/1.1"; }
/*  570 */     if ((("org.apache.coyote.ajp.AjpNioProtocol".equals(getProtocolHandlerClassName())) && ((!AprLifecycleListener.isAprAvailable()) || (!AprLifecycleListener.getUseAprConnector()))) || (("org.apache.coyote.ajp.AjpAprProtocol".equals(getProtocolHandlerClassName())) && (AprLifecycleListener.getUseAprConnector())))
/*      */     {
/*      */ 
/*      */ 
/*  574 */       return "AJP/1.3";
/*      */     }
/*  576 */     return getProtocolHandlerClassName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProtocol(String protocol)
/*      */   {
/*  587 */     boolean aprConnector = (AprLifecycleListener.isAprAvailable()) && (AprLifecycleListener.getUseAprConnector());
/*      */     
/*      */ 
/*  590 */     if (("HTTP/1.1".equals(protocol)) || (protocol == null)) {
/*  591 */       if (aprConnector) {
/*  592 */         setProtocolHandlerClassName("org.apache.coyote.http11.Http11AprProtocol");
/*      */       } else {
/*  594 */         setProtocolHandlerClassName("org.apache.coyote.http11.Http11NioProtocol");
/*      */       }
/*  596 */     } else if ("AJP/1.3".equals(protocol)) {
/*  597 */       if (aprConnector) {
/*  598 */         setProtocolHandlerClassName("org.apache.coyote.ajp.AjpAprProtocol");
/*      */       } else {
/*  600 */         setProtocolHandlerClassName("org.apache.coyote.ajp.AjpNioProtocol");
/*      */       }
/*      */     } else {
/*  603 */       setProtocolHandlerClassName(protocol);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProtocolHandlerClassName()
/*      */   {
/*  614 */     return this.protocolHandlerClassName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProtocolHandlerClassName(String protocolHandlerClassName)
/*      */   {
/*  627 */     this.protocolHandlerClassName = protocolHandlerClassName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ProtocolHandler getProtocolHandler()
/*      */   {
/*  637 */     return this.protocolHandler;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProxyName()
/*      */   {
/*  647 */     return this.proxyName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProxyName(String proxyName)
/*      */   {
/*  659 */     if ((proxyName != null) && (proxyName.length() > 0)) {
/*  660 */       this.proxyName = proxyName;
/*  661 */       setProperty("proxyName", proxyName);
/*      */     } else {
/*  663 */       this.proxyName = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getProxyPort()
/*      */   {
/*  674 */     return this.proxyPort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProxyPort(int proxyPort)
/*      */   {
/*  686 */     this.proxyPort = proxyPort;
/*  687 */     setProperty("proxyPort", String.valueOf(proxyPort));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRedirectPort()
/*      */   {
/*  699 */     return this.redirectPort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRedirectPort(int redirectPort)
/*      */   {
/*  711 */     this.redirectPort = redirectPort;
/*  712 */     setProperty("redirectPort", String.valueOf(redirectPort));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getScheme()
/*      */   {
/*  723 */     return this.scheme;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setScheme(String scheme)
/*      */   {
/*  736 */     this.scheme = scheme;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getSecure()
/*      */   {
/*  747 */     return this.secure;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecure(boolean secure)
/*      */   {
/*  760 */     this.secure = secure;
/*  761 */     setProperty("secure", Boolean.toString(secure));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getURIEncoding()
/*      */   {
/*  769 */     return this.URIEncoding;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getURIEncodingLower()
/*      */   {
/*  777 */     return this.URIEncodingLower;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setURIEncoding(String URIEncoding)
/*      */   {
/*  787 */     this.URIEncoding = URIEncoding;
/*  788 */     if (URIEncoding == null) {
/*  789 */       this.URIEncodingLower = null;
/*      */     } else {
/*  791 */       this.URIEncodingLower = URIEncoding.toLowerCase(Locale.ENGLISH);
/*      */     }
/*  793 */     setProperty("uRIEncoding", URIEncoding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUseBodyEncodingForURI()
/*      */   {
/*  802 */     return this.useBodyEncodingForURI;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseBodyEncodingForURI(boolean useBodyEncodingForURI)
/*      */   {
/*  814 */     this.useBodyEncodingForURI = useBodyEncodingForURI;
/*  815 */     setProperty("useBodyEncodingForURI", String.valueOf(useBodyEncodingForURI));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getXpoweredBy()
/*      */   {
/*  828 */     return this.xpoweredBy;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setXpoweredBy(boolean xpoweredBy)
/*      */   {
/*  841 */     this.xpoweredBy = xpoweredBy;
/*  842 */     setProperty("xpoweredBy", String.valueOf(xpoweredBy));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseIPVHosts(boolean useIPVHosts)
/*      */   {
/*  852 */     this.useIPVHosts = useIPVHosts;
/*  853 */     setProperty("useIPVHosts", String.valueOf(useIPVHosts));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUseIPVHosts()
/*      */   {
/*  862 */     return this.useIPVHosts;
/*      */   }
/*      */   
/*      */   public String getExecutorName()
/*      */   {
/*  867 */     Object obj = this.protocolHandler.getExecutor();
/*  868 */     if ((obj instanceof Executor)) {
/*  869 */       return ((Executor)obj).getName();
/*      */     }
/*  871 */     return "Internal";
/*      */   }
/*      */   
/*      */   public void addSslHostConfig(SSLHostConfig sslHostConfig)
/*      */   {
/*  876 */     this.protocolHandler.addSslHostConfig(sslHostConfig);
/*      */   }
/*      */   
/*      */   public SSLHostConfig[] findSslHostConfigs() {
/*  880 */     return this.protocolHandler.findSslHostConfigs();
/*      */   }
/*      */   
/*      */   public void addUpgradeProtocol(UpgradeProtocol upgradeProtocol)
/*      */   {
/*  885 */     this.protocolHandler.addUpgradeProtocol(upgradeProtocol);
/*      */   }
/*      */   
/*  888 */   public UpgradeProtocol[] findUpgradeProtocols() { return this.protocolHandler.findUpgradeProtocols(); }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Request createRequest()
/*      */   {
/*  902 */     Request request = new Request();
/*  903 */     request.setConnector(this);
/*  904 */     return request;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Response createResponse()
/*      */   {
/*  917 */     Response response = new Response();
/*  918 */     response.setConnector(this);
/*  919 */     return response;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected String createObjectNameKeyProperties(String type)
/*      */   {
/*  926 */     Object addressObj = getProperty("address");
/*      */     
/*  928 */     StringBuilder sb = new StringBuilder("type=");
/*  929 */     sb.append(type);
/*  930 */     sb.append(",port=");
/*  931 */     int port = getPort();
/*  932 */     if (port > 0) {
/*  933 */       sb.append(port);
/*      */     } else {
/*  935 */       sb.append("auto-");
/*  936 */       sb.append(getProperty("nameIndex"));
/*      */     }
/*  938 */     String address = "";
/*  939 */     if ((addressObj instanceof InetAddress)) {
/*  940 */       address = ((InetAddress)addressObj).getHostAddress();
/*  941 */     } else if (addressObj != null) {
/*  942 */       address = addressObj.toString();
/*      */     }
/*  944 */     if (address.length() > 0) {
/*  945 */       sb.append(",address=");
/*  946 */       sb.append(ObjectName.quote(address));
/*      */     }
/*  948 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void pause()
/*      */   {
/*      */     try
/*      */     {
/*  957 */       this.protocolHandler.pause();
/*      */     } catch (Exception e) {
/*  959 */       log.error(sm.getString("coyoteConnector.protocolHandlerPauseFailed"), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resume()
/*      */   {
/*      */     try
/*      */     {
/*  970 */       this.protocolHandler.resume();
/*      */     } catch (Exception e) {
/*  972 */       log.error(sm.getString("coyoteConnector.protocolHandlerResumeFailed"), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void initInternal()
/*      */     throws LifecycleException
/*      */   {
/*  981 */     super.initInternal();
/*      */     
/*      */ 
/*  984 */     this.adapter = new CoyoteAdapter(this);
/*  985 */     this.protocolHandler.setAdapter(this.adapter);
/*      */     
/*      */ 
/*  988 */     if (null == this.parseBodyMethodsSet) {
/*  989 */       setParseBodyMethods(getParseBodyMethods());
/*      */     }
/*      */     
/*  992 */     if ((this.protocolHandler.isAprRequired()) && (!AprLifecycleListener.isAprAvailable()))
/*      */     {
/*  994 */       throw new LifecycleException(sm.getString("coyoteConnector.protocolHandlerNoApr", new Object[] { getProtocolHandlerClassName() }));
/*      */     }
/*      */     
/*      */ 
/*  998 */     if ((AprLifecycleListener.isAprAvailable()) && (AprLifecycleListener.getUseOpenSSL()) && ((this.protocolHandler instanceof AbstractHttp11JsseProtocol)))
/*      */     {
/*      */ 
/* 1001 */       AbstractHttp11JsseProtocol<?> jsseProtocolHandler = (AbstractHttp11JsseProtocol)this.protocolHandler;
/*      */       
/* 1003 */       if ((jsseProtocolHandler.isSSLEnabled()) && (jsseProtocolHandler.getSslImplementationName() == null))
/*      */       {
/* 1005 */         jsseProtocolHandler.setSslImplementationName(OpenSSLImplementation.class.getName());
/*      */       }
/*      */     }
/*      */     try
/*      */     {
/* 1010 */       this.protocolHandler.init();
/*      */     } catch (Exception e) {
/* 1012 */       throw new LifecycleException(sm.getString("coyoteConnector.protocolHandlerInitializationFailed"), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void startInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1027 */     if (getPort() < 0) {
/* 1028 */       throw new LifecycleException(sm.getString("coyoteConnector.invalidPort", new Object[] { Integer.valueOf(getPort()) }));
/*      */     }
/*      */     
/*      */ 
/* 1032 */     setState(LifecycleState.STARTING);
/*      */     try
/*      */     {
/* 1035 */       this.protocolHandler.start();
/*      */     } catch (Exception e) {
/* 1037 */       String errPrefix = "";
/* 1038 */       if (this.service != null) {
/* 1039 */         errPrefix = errPrefix + "service.getName(): \"" + this.service.getName() + "\"; ";
/*      */       }
/*      */       
/* 1042 */       throw new LifecycleException(errPrefix + " " + sm.getString("coyoteConnector.protocolHandlerStartFailed"), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void stopInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1057 */     setState(LifecycleState.STOPPING);
/*      */     try
/*      */     {
/* 1060 */       this.protocolHandler.stop();
/*      */     } catch (Exception e) {
/* 1062 */       throw new LifecycleException(sm.getString("coyoteConnector.protocolHandlerStopFailed"), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected void destroyInternal()
/*      */     throws LifecycleException
/*      */   {
/*      */     try
/*      */     {
/* 1072 */       this.protocolHandler.destroy();
/*      */     } catch (Exception e) {
/* 1074 */       throw new LifecycleException(sm.getString("coyoteConnector.protocolHandlerDestroyFailed"), e);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1079 */     if (getService() != null) {
/* 1080 */       getService().removeConnector(this);
/*      */     }
/*      */     
/* 1083 */     super.destroyInternal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1094 */     StringBuilder sb = new StringBuilder("Connector[");
/* 1095 */     sb.append(getProtocol());
/* 1096 */     sb.append('-');
/* 1097 */     int port = getPort();
/* 1098 */     if (port > 0) {
/* 1099 */       sb.append(port);
/*      */     } else {
/* 1101 */       sb.append("auto-");
/* 1102 */       sb.append(getProperty("nameIndex"));
/*      */     }
/* 1104 */     sb.append(']');
/* 1105 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getDomainInternal()
/*      */   {
/* 1113 */     Service s = getService();
/* 1114 */     if (s == null) {
/* 1115 */       return null;
/*      */     }
/* 1117 */     return this.service.getDomain();
/*      */   }
/*      */   
/*      */ 
/*      */   protected String getObjectNameKeyProperties()
/*      */   {
/* 1123 */     return createObjectNameKeyProperties("Connector");
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\connector\Connector.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */