/*     */ package org.apache.catalina.connector;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import javax.servlet.ReadListener;
/*     */ import org.apache.catalina.security.SecurityUtil;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.coyote.ContainerThreadMarker;
/*     */ import org.apache.coyote.Request;
/*     */ import org.apache.tomcat.util.buf.B2CConverter;
/*     */ import org.apache.tomcat.util.buf.ByteChunk;
/*     */ import org.apache.tomcat.util.buf.ByteChunk.ByteInputChannel;
/*     */ import org.apache.tomcat.util.buf.CharChunk;
/*     */ import org.apache.tomcat.util.buf.CharChunk.CharInputChannel;
/*     */ import org.apache.tomcat.util.buf.CharChunk.CharOutputChannel;
/*     */ import org.apache.tomcat.util.collections.SynchronizedStack;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InputBuffer
/*     */   extends Reader
/*     */   implements ByteChunk.ByteInputChannel, CharChunk.CharInputChannel, CharChunk.CharOutputChannel
/*     */ {
/*  55 */   protected static final StringManager sm = StringManager.getManager(InputBuffer.class);
/*     */   
/*     */ 
/*     */   public static final int DEFAULT_BUFFER_SIZE = 8192;
/*     */   
/*     */ 
/*  61 */   public final int INITIAL_STATE = 0;
/*  62 */   public final int CHAR_STATE = 1;
/*  63 */   public final int BYTE_STATE = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */   private static final ConcurrentMap<Charset, SynchronizedStack<B2CConverter>> encoders = new ConcurrentHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ByteChunk bb;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private CharChunk cb;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */   private int state = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */   private boolean closed = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String enc;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected B2CConverter conv;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Request coyoteRequest;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 120 */   private int markPos = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int size;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputBuffer()
/*     */   {
/* 137 */     this(8192);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputBuffer(int size)
/*     */   {
/* 149 */     this.size = size;
/* 150 */     this.bb = new ByteChunk(size);
/* 151 */     this.bb.setLimit(size);
/* 152 */     this.bb.setByteInputChannel(this);
/* 153 */     this.cb = new CharChunk(size);
/* 154 */     this.cb.setLimit(size);
/* 155 */     this.cb.setOptimizedWrite(false);
/* 156 */     this.cb.setCharInputChannel(this);
/* 157 */     this.cb.setCharOutputChannel(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRequest(Request coyoteRequest)
/*     */   {
/* 171 */     this.coyoteRequest = coyoteRequest;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void recycle()
/*     */   {
/* 182 */     this.state = 0;
/*     */     
/*     */ 
/* 185 */     if (this.cb.getChars().length > this.size) {
/* 186 */       this.cb = new CharChunk(this.size);
/* 187 */       this.cb.setLimit(this.size);
/* 188 */       this.cb.setOptimizedWrite(false);
/* 189 */       this.cb.setCharInputChannel(this);
/* 190 */       this.cb.setCharOutputChannel(this);
/*     */     } else {
/* 192 */       this.cb.recycle();
/*     */     }
/* 194 */     this.markPos = -1;
/* 195 */     this.bb.recycle();
/* 196 */     this.closed = false;
/*     */     
/* 198 */     if (this.conv != null) {
/* 199 */       this.conv.recycle();
/* 200 */       ((SynchronizedStack)encoders.get(this.conv.getCharset())).push(this.conv);
/* 201 */       this.conv = null;
/*     */     }
/*     */     
/* 204 */     this.enc = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 216 */     this.closed = true;
/*     */   }
/*     */   
/*     */   public int available()
/*     */   {
/* 221 */     int available = 0;
/* 222 */     if (this.state == 2) {
/* 223 */       available = this.bb.getLength();
/* 224 */     } else if (this.state == 1) {
/* 225 */       available = this.cb.getLength();
/*     */     }
/* 227 */     if (available == 0) {
/* 228 */       this.coyoteRequest.action(ActionCode.AVAILABLE, Boolean.valueOf(this.coyoteRequest.getReadListener() != null));
/* 229 */       available = this.coyoteRequest.getAvailable() > 0 ? 1 : 0;
/*     */     }
/* 231 */     return available;
/*     */   }
/*     */   
/*     */   public void setReadListener(ReadListener listener)
/*     */   {
/* 236 */     this.coyoteRequest.setReadListener(listener);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 246 */     if ((!this.coyoteRequest.isFinished()) && (isReady())) {
/* 247 */       this.coyoteRequest.action(ActionCode.DISPATCH_READ, null);
/* 248 */       if (!ContainerThreadMarker.isContainerThread())
/*     */       {
/* 250 */         this.coyoteRequest.action(ActionCode.DISPATCH_EXECUTE, null);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isFinished()
/*     */   {
/* 257 */     int available = 0;
/* 258 */     if (this.state == 2) {
/* 259 */       available = this.bb.getLength();
/* 260 */     } else if (this.state == 1) {
/* 261 */       available = this.cb.getLength();
/*     */     }
/* 263 */     if (available > 0) {
/* 264 */       return false;
/*     */     }
/* 266 */     return this.coyoteRequest.isFinished();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isReady()
/*     */   {
/* 272 */     if (this.coyoteRequest.getReadListener() == null) {
/* 273 */       throw new IllegalStateException(sm.getString("inputBuffer.requiresNonBlocking"));
/*     */     }
/* 275 */     if (isFinished())
/*     */     {
/*     */ 
/*     */ 
/* 279 */       if (!ContainerThreadMarker.isContainerThread()) {
/* 280 */         this.coyoteRequest.action(ActionCode.DISPATCH_READ, null);
/* 281 */         this.coyoteRequest.action(ActionCode.DISPATCH_EXECUTE, null);
/*     */       }
/* 283 */       return false;
/*     */     }
/* 285 */     boolean result = available() > 0;
/* 286 */     if (!result) {
/* 287 */       this.coyoteRequest.action(ActionCode.NB_READ_INTEREST, null);
/*     */     }
/* 289 */     return result;
/*     */   }
/*     */   
/*     */   boolean isBlocking()
/*     */   {
/* 294 */     return this.coyoteRequest.getReadListener() == null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int realReadBytes()
/*     */     throws IOException
/*     */   {
/* 307 */     if (this.closed) {
/* 308 */       return -1;
/*     */     }
/* 310 */     if (this.coyoteRequest == null) {
/* 311 */       return -1;
/*     */     }
/*     */     
/* 314 */     if (this.state == 0) {
/* 315 */       this.state = 2;
/*     */     }
/*     */     
/* 318 */     int result = this.coyoteRequest.doRead(this.bb);
/*     */     
/* 320 */     return result;
/*     */   }
/*     */   
/*     */   public int readByte() throws IOException
/*     */   {
/* 325 */     if (this.closed) {
/* 326 */       throw new IOException(sm.getString("inputBuffer.streamClosed"));
/*     */     }
/*     */     
/* 329 */     return this.bb.substract();
/*     */   }
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException
/*     */   {
/* 334 */     if (this.closed) {
/* 335 */       throw new IOException(sm.getString("inputBuffer.streamClosed"));
/*     */     }
/*     */     
/* 338 */     return this.bb.substract(b, off, len);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void realWriteChars(char[] c, int off, int len)
/*     */     throws IOException
/*     */   {
/* 353 */     this.markPos = -1;
/* 354 */     this.cb.setOffset(0);
/* 355 */     this.cb.setEnd(0);
/*     */   }
/*     */   
/*     */   public void setEncoding(String s)
/*     */   {
/* 360 */     this.enc = s;
/*     */   }
/*     */   
/*     */   public int realReadChars()
/*     */     throws IOException
/*     */   {
/* 366 */     checkConverter();
/*     */     
/* 368 */     boolean eof = false;
/*     */     
/* 370 */     if (this.bb.getLength() <= 0) {
/* 371 */       int nRead = realReadBytes();
/* 372 */       if (nRead < 0) {
/* 373 */         eof = true;
/*     */       }
/*     */     }
/*     */     
/* 377 */     if (this.markPos == -1) {
/* 378 */       this.cb.setOffset(0);
/* 379 */       this.cb.setEnd(0);
/*     */     }
/*     */     else {
/* 382 */       this.cb.makeSpace(this.bb.getLength());
/* 383 */       if (this.cb.getBuffer().length - this.cb.getEnd() == 0)
/*     */       {
/* 385 */         this.cb.setOffset(0);
/* 386 */         this.cb.setEnd(0);
/* 387 */         this.markPos = -1;
/*     */       }
/*     */     }
/*     */     
/* 391 */     this.state = 1;
/* 392 */     this.conv.convert(this.bb, this.cb, eof);
/*     */     
/* 394 */     if ((this.cb.getLength() == 0) && (eof)) {
/* 395 */       return -1;
/*     */     }
/* 397 */     return this.cb.getLength();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/* 406 */     if (this.closed) {
/* 407 */       throw new IOException(sm.getString("inputBuffer.streamClosed"));
/*     */     }
/*     */     
/* 410 */     return this.cb.substract();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int read(char[] cbuf)
/*     */     throws IOException
/*     */   {
/* 418 */     if (this.closed) {
/* 419 */       throw new IOException(sm.getString("inputBuffer.streamClosed"));
/*     */     }
/*     */     
/* 422 */     return read(cbuf, 0, cbuf.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int read(char[] cbuf, int off, int len)
/*     */     throws IOException
/*     */   {
/* 430 */     if (this.closed) {
/* 431 */       throw new IOException(sm.getString("inputBuffer.streamClosed"));
/*     */     }
/*     */     
/* 434 */     return this.cb.substract(cbuf, off, len);
/*     */   }
/*     */   
/*     */   public long skip(long n)
/*     */     throws IOException
/*     */   {
/* 440 */     if (this.closed) {
/* 441 */       throw new IOException(sm.getString("inputBuffer.streamClosed"));
/*     */     }
/*     */     
/* 444 */     if (n < 0L) {
/* 445 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 448 */     long nRead = 0L;
/* 449 */     while (nRead < n) {
/* 450 */       if (this.cb.getLength() >= n) {
/* 451 */         this.cb.setOffset(this.cb.getStart() + (int)n);
/* 452 */         nRead = n;
/*     */       } else {
/* 454 */         nRead += this.cb.getLength();
/* 455 */         this.cb.setOffset(this.cb.getEnd());
/* 456 */         int nb = realReadChars();
/* 457 */         if (nb < 0) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/* 462 */     return nRead;
/*     */   }
/*     */   
/*     */   public boolean ready()
/*     */     throws IOException
/*     */   {
/* 468 */     if (this.closed) {
/* 469 */       throw new IOException(sm.getString("inputBuffer.streamClosed"));
/*     */     }
/* 471 */     if (this.state == 0) {
/* 472 */       this.state = 1;
/*     */     }
/* 474 */     return available() > 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/* 480 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void mark(int readAheadLimit)
/*     */     throws IOException
/*     */   {
/* 488 */     if (this.closed) {
/* 489 */       throw new IOException(sm.getString("inputBuffer.streamClosed"));
/*     */     }
/*     */     
/* 492 */     if (this.cb.getLength() <= 0) {
/* 493 */       this.cb.setOffset(0);
/* 494 */       this.cb.setEnd(0);
/*     */     }
/* 496 */     else if ((this.cb.getBuffer().length > 2 * this.size) && (this.cb.getLength() < this.cb.getStart()))
/*     */     {
/* 498 */       System.arraycopy(this.cb.getBuffer(), this.cb.getStart(), this.cb.getBuffer(), 0, this.cb.getLength());
/*     */       
/* 500 */       this.cb.setEnd(this.cb.getLength());
/* 501 */       this.cb.setOffset(0);
/*     */     }
/*     */     
/* 504 */     this.cb.setLimit(this.cb.getStart() + readAheadLimit + this.size);
/* 505 */     this.markPos = this.cb.getStart();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */     throws IOException
/*     */   {
/* 513 */     if (this.closed) {
/* 514 */       throw new IOException(sm.getString("inputBuffer.streamClosed"));
/*     */     }
/*     */     
/* 517 */     if (this.state == 1) {
/* 518 */       if (this.markPos < 0) {
/* 519 */         this.cb.recycle();
/* 520 */         this.markPos = -1;
/* 521 */         throw new IOException();
/*     */       }
/* 523 */       this.cb.setOffset(this.markPos);
/*     */     }
/*     */     else {
/* 526 */       this.bb.recycle();
/*     */     }
/*     */   }
/*     */   
/*     */   public void checkConverter() throws IOException
/*     */   {
/* 532 */     if (this.conv == null) {
/* 533 */       setConverter();
/*     */     }
/*     */   }
/*     */   
/*     */   private void setConverter() throws IOException
/*     */   {
/* 539 */     if (this.coyoteRequest != null) {
/* 540 */       this.enc = this.coyoteRequest.getCharacterEncoding();
/*     */     }
/*     */     
/* 543 */     if (this.enc == null) {
/* 544 */       this.enc = "ISO-8859-1";
/*     */     }
/*     */     
/* 547 */     Charset charset = B2CConverter.getCharset(this.enc);
/* 548 */     SynchronizedStack<B2CConverter> stack = (SynchronizedStack)encoders.get(charset);
/* 549 */     if (stack == null) {
/* 550 */       stack = new SynchronizedStack();
/* 551 */       encoders.putIfAbsent(charset, stack);
/* 552 */       stack = (SynchronizedStack)encoders.get(charset);
/*     */     }
/* 554 */     this.conv = ((B2CConverter)stack.pop());
/*     */     
/* 556 */     if (this.conv == null) {
/* 557 */       this.conv = createConverter(charset);
/*     */     }
/*     */   }
/*     */   
/*     */   private static B2CConverter createConverter(Charset charset) throws IOException
/*     */   {
/* 563 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 565 */         (B2CConverter)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */         {
/*     */           public B2CConverter run()
/*     */             throws IOException
/*     */           {
/* 570 */             return new B2CConverter(this.val$charset);
/*     */           }
/*     */         });
/*     */       }
/*     */       catch (PrivilegedActionException ex) {
/* 575 */         Exception e = ex.getException();
/* 576 */         if ((e instanceof IOException)) {
/* 577 */           throw ((IOException)e);
/*     */         }
/* 579 */         throw new IOException(e);
/*     */       }
/*     */     }
/*     */     
/* 583 */     return new B2CConverter(charset);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\connector\InputBuffer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */