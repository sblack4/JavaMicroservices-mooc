/*      */ package org.apache.catalina.connector;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.nio.charset.Charset;
/*      */ import java.util.EnumSet;
/*      */ import java.util.HashMap;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import javax.servlet.ReadListener;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.SessionTrackingMode;
/*      */ import javax.servlet.WriteListener;
/*      */ import org.apache.catalina.Authenticator;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.Pipeline;
/*      */ import org.apache.catalina.Realm;
/*      */ import org.apache.catalina.Service;
/*      */ import org.apache.catalina.Valve;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.authenticator.AuthenticatorBase;
/*      */ import org.apache.catalina.core.AsyncContextImpl;
/*      */ import org.apache.catalina.mapper.Mapper;
/*      */ import org.apache.catalina.mapper.MappingData;
/*      */ import org.apache.catalina.util.ServerInfo;
/*      */ import org.apache.catalina.util.SessionConfig;
/*      */ import org.apache.catalina.util.URLEncoder;
/*      */ import org.apache.coyote.ActionCode;
/*      */ import org.apache.coyote.Adapter;
/*      */ import org.apache.coyote.RequestInfo;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.buf.B2CConverter;
/*      */ import org.apache.tomcat.util.buf.ByteChunk;
/*      */ import org.apache.tomcat.util.buf.CharChunk;
/*      */ import org.apache.tomcat.util.buf.MessageBytes;
/*      */ import org.apache.tomcat.util.buf.UDecoder;
/*      */ import org.apache.tomcat.util.http.Parameters;
/*      */ import org.apache.tomcat.util.http.ServerCookie;
/*      */ import org.apache.tomcat.util.http.ServerCookies;
/*      */ import org.apache.tomcat.util.net.SocketEvent;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CoyoteAdapter
/*      */   implements Adapter
/*      */ {
/*   66 */   private static final Log log = LogFactory.getLog(CoyoteAdapter.class);
/*      */   
/*      */ 
/*      */ 
/*   70 */   private static final String POWERED_BY = "Servlet/4.0 JSP/2.3 (" + ServerInfo.getServerInfo() + " Java/" + System.getProperty("java.vm.vendor") + "/" + System.getProperty("java.runtime.version") + ")";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   75 */   private static final EnumSet<SessionTrackingMode> SSL_ONLY = EnumSet.of(SessionTrackingMode.SSL);
/*      */   
/*      */ 
/*      */   public static final int ADAPTER_NOTES = 1;
/*      */   
/*      */ 
/*   81 */   protected static final boolean ALLOW_BACKSLASH = Boolean.parseBoolean(System.getProperty("org.apache.catalina.connector.CoyoteAdapter.ALLOW_BACKSLASH", "false"));
/*      */   
/*      */ 
/*      */ 
/*   85 */   private static final ThreadLocal<String> THREAD_NAME = new ThreadLocal()
/*      */   {
/*      */ 
/*      */     protected String initialValue()
/*      */     {
/*   90 */       return Thread.currentThread().getName();
/*      */     }
/*      */   };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final Connector connector;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CoyoteAdapter(Connector connector)
/*      */   {
/*  106 */     this.connector = connector;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  123 */   protected static final StringManager sm = StringManager.getManager(CoyoteAdapter.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean asyncDispatch(org.apache.coyote.Request req, org.apache.coyote.Response res, SocketEvent status)
/*      */     throws Exception
/*      */   {
/*  131 */     Request request = (Request)req.getNote(1);
/*  132 */     Response response = (Response)res.getNote(1);
/*      */     
/*  134 */     if (request == null) {
/*  135 */       throw new IllegalStateException("Dispatch may only happen on an existing request.");
/*      */     }
/*      */     
/*  138 */     boolean success = true;
/*  139 */     AsyncContextImpl asyncConImpl = request.getAsyncContextInternal();
/*  140 */     req.getRequestProcessor().setWorkerThreadName(Thread.currentThread().getName());
/*      */     try {
/*  142 */       if (!request.isAsync())
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  147 */         Context ctxt = request.getMappingData().context;
/*  148 */         if (ctxt != null) {
/*  149 */           ctxt.fireRequestDestroyEvent(request);
/*      */         }
/*      */         
/*      */ 
/*  153 */         response.setSuspended(false);
/*      */       }
/*      */       
/*  156 */       if (status == SocketEvent.TIMEOUT) {
/*  157 */         if (!asyncConImpl.timeout()) {
/*  158 */           asyncConImpl.setErrorState(null, false);
/*      */         }
/*  160 */       } else if (status == SocketEvent.ERROR)
/*      */       {
/*      */ 
/*      */ 
/*  164 */         success = false;
/*  165 */         Throwable t = (Throwable)req.getAttribute("javax.servlet.error.exception");
/*  166 */         req.getAttributes().remove("javax.servlet.error.exception");
/*  167 */         ClassLoader oldCL = null;
/*      */         try {
/*  169 */           oldCL = request.getContext().bind(false, null);
/*  170 */           if (req.getReadListener() != null) {
/*  171 */             req.getReadListener().onError(t);
/*      */           }
/*  173 */           if (res.getWriteListener() != null) {
/*  174 */             res.getWriteListener().onError(t);
/*      */           }
/*      */         } finally {
/*  177 */           request.getContext().unbind(false, oldCL);
/*      */         }
/*  179 */         if (t != null) {
/*  180 */           asyncConImpl.setErrorState(t, true);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  185 */       if ((!request.isAsyncDispatching()) && (request.isAsync())) {
/*  186 */         WriteListener writeListener = res.getWriteListener();
/*  187 */         ReadListener readListener = req.getReadListener();
/*  188 */         if ((writeListener != null) && (status == SocketEvent.OPEN_WRITE)) {
/*  189 */           ClassLoader oldCL = null;
/*      */           try {
/*  191 */             oldCL = request.getContext().bind(false, null);
/*  192 */             res.onWritePossible();
/*  193 */             if ((request.isFinished()) && (req.sendAllDataReadEvent()) && (readListener != null))
/*      */             {
/*  195 */               readListener.onAllDataRead();
/*      */             }
/*      */           } catch (Throwable t) {
/*  198 */             ExceptionUtils.handleThrowable(t);
/*  199 */             writeListener.onError(t);
/*  200 */             success = false;
/*      */           } finally {
/*  202 */             request.getContext().unbind(false, oldCL);
/*      */           }
/*  204 */         } else if ((readListener != null) && (status == SocketEvent.OPEN_READ)) {
/*  205 */           ClassLoader oldCL = null;
/*      */           try {
/*  207 */             oldCL = request.getContext().bind(false, null);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  213 */             if (!request.isFinished()) {
/*  214 */               readListener.onDataAvailable();
/*      */             }
/*  216 */             if ((request.isFinished()) && (req.sendAllDataReadEvent())) {
/*  217 */               readListener.onAllDataRead();
/*      */             }
/*      */           } catch (Throwable t) {
/*  220 */             ExceptionUtils.handleThrowable(t);
/*  221 */             readListener.onError(t);
/*  222 */             success = false;
/*      */           } finally {
/*  224 */             request.getContext().unbind(false, oldCL);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  232 */       if ((!request.isAsyncDispatching()) && (request.isAsync()) && (response.isErrorReportRequired()))
/*      */       {
/*  234 */         this.connector.getService().getContainer().getPipeline().getFirst().invoke(request, response);
/*      */       }
/*      */       
/*  237 */       if (request.isAsyncDispatching()) {
/*  238 */         this.connector.getService().getContainer().getPipeline().getFirst().invoke(request, response);
/*  239 */         Throwable t = (Throwable)request.getAttribute("javax.servlet.error.exception");
/*      */         
/*  241 */         if (t != null) {
/*  242 */           asyncConImpl.setErrorState(t, true);
/*      */         }
/*      */       }
/*      */       
/*  246 */       if (!request.isAsync()) {
/*  247 */         request.finishRequest();
/*  248 */         response.finishResponse();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  253 */       AtomicBoolean error = new AtomicBoolean(false);
/*  254 */       res.action(ActionCode.IS_ERROR, error);
/*  255 */       if (error.get()) {
/*  256 */         if (request.isAsyncCompleting())
/*      */         {
/*      */ 
/*      */ 
/*  260 */           res.action(ActionCode.ASYNC_POST_PROCESS, null);
/*      */         }
/*  262 */         success = false;
/*      */       }
/*      */     } catch (IOException e) { long time;
/*  265 */       success = false;
/*      */     } catch (Throwable t) {
/*      */       long time;
/*  268 */       ExceptionUtils.handleThrowable(t);
/*  269 */       success = false;
/*  270 */       log.error(sm.getString("coyoteAdapter.asyncDispatch"), t);
/*      */     } finally { long time;
/*  272 */       if (!success) {
/*  273 */         res.setStatus(500);
/*      */       }
/*      */       
/*      */ 
/*  277 */       if ((!success) || (!request.isAsync())) {
/*  278 */         long time = 0L;
/*  279 */         if (req.getStartTime() != -1L) {
/*  280 */           time = System.currentTimeMillis() - req.getStartTime();
/*      */         }
/*  282 */         if (request.getMappingData().context != null) {
/*  283 */           request.getMappingData().context.logAccess(request, response, time, false);
/*      */         } else {
/*  285 */           log(req, res, time);
/*      */         }
/*      */       }
/*      */       
/*  289 */       req.getRequestProcessor().setWorkerThreadName(null);
/*      */       
/*  291 */       if ((!success) || (!request.isAsync())) {
/*  292 */         request.recycle();
/*  293 */         response.recycle();
/*      */       }
/*      */     }
/*  296 */     return success;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void service(org.apache.coyote.Request req, org.apache.coyote.Response res)
/*      */     throws Exception
/*      */   {
/*  308 */     Request request = (Request)req.getNote(1);
/*  309 */     Response response = (Response)res.getNote(1);
/*      */     
/*  311 */     if (request == null)
/*      */     {
/*      */ 
/*  314 */       request = this.connector.createRequest();
/*  315 */       request.setCoyoteRequest(req);
/*  316 */       response = this.connector.createResponse();
/*  317 */       response.setCoyoteResponse(res);
/*      */       
/*      */ 
/*  320 */       request.setResponse(response);
/*  321 */       response.setRequest(request);
/*      */       
/*      */ 
/*  324 */       req.setNote(1, request);
/*  325 */       res.setNote(1, response);
/*      */       
/*      */ 
/*  328 */       req.getParameters().setQueryStringEncoding(this.connector.getURIEncoding());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  333 */     if (this.connector.getXpoweredBy()) {
/*  334 */       response.addHeader("X-Powered-By", POWERED_BY);
/*      */     }
/*      */     
/*  337 */     boolean async = false;
/*  338 */     boolean postParseSuccess = false;
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  343 */       req.getRequestProcessor().setWorkerThreadName((String)THREAD_NAME.get());
/*  344 */       postParseSuccess = postParseRequest(req, request, res, response);
/*  345 */       if (postParseSuccess)
/*      */       {
/*  347 */         request.setAsyncSupported(this.connector.getService().getContainer().getPipeline().isAsyncSupported());
/*      */         
/*  349 */         this.connector.getService().getContainer().getPipeline().getFirst().invoke(request, response);
/*      */       }
/*  351 */       if (request.isAsync()) {
/*  352 */         async = true;
/*  353 */         ReadListener readListener = req.getReadListener();
/*  354 */         if ((readListener != null) && (request.isFinished()))
/*      */         {
/*      */ 
/*  357 */           ClassLoader oldCL = null;
/*      */           try {
/*  359 */             oldCL = request.getContext().bind(false, null);
/*  360 */             if (req.sendAllDataReadEvent()) {
/*  361 */               req.getReadListener().onAllDataRead();
/*      */             }
/*      */           } finally {
/*  364 */             request.getContext().unbind(false, oldCL);
/*      */           }
/*      */         }
/*      */         
/*  368 */         Throwable throwable = (Throwable)request.getAttribute("javax.servlet.error.exception");
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  374 */         if ((!request.isAsyncCompleting()) && (throwable != null)) {
/*  375 */           request.getAsyncContextInternal().setErrorState(throwable, true);
/*      */         }
/*      */       } else {
/*  378 */         request.finishRequest();
/*  379 */         response.finishResponse();
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException) {}finally
/*      */     {
/*      */       AtomicBoolean error;
/*      */       AtomicBoolean error;
/*  386 */       if ((!async) && (postParseSuccess))
/*      */       {
/*      */ 
/*  389 */         request.getMappingData().context.logAccess(request, response, System.currentTimeMillis() - req.getStartTime(), false);
/*      */       }
/*      */       
/*      */ 
/*  393 */       req.getRequestProcessor().setWorkerThreadName(null);
/*  394 */       AtomicBoolean error = new AtomicBoolean(false);
/*  395 */       res.action(ActionCode.IS_ERROR, error);
/*      */       
/*      */ 
/*  398 */       if ((!async) || (error.get())) {
/*  399 */         request.recycle();
/*  400 */         response.recycle();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean prepare(org.apache.coyote.Request req, org.apache.coyote.Response res)
/*      */     throws IOException, ServletException
/*      */   {
/*  409 */     Request request = (Request)req.getNote(1);
/*  410 */     Response response = (Response)res.getNote(1);
/*      */     
/*  412 */     return postParseRequest(req, request, res, response);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void log(org.apache.coyote.Request req, org.apache.coyote.Response res, long time)
/*      */   {
/*  420 */     Request request = (Request)req.getNote(1);
/*  421 */     Response response = (Response)res.getNote(1);
/*      */     
/*  423 */     if (request == null)
/*      */     {
/*  425 */       request = this.connector.createRequest();
/*  426 */       request.setCoyoteRequest(req);
/*  427 */       response = this.connector.createResponse();
/*  428 */       response.setCoyoteResponse(res);
/*      */       
/*      */ 
/*  431 */       request.setResponse(response);
/*  432 */       response.setRequest(request);
/*      */       
/*      */ 
/*  435 */       req.setNote(1, request);
/*  436 */       res.setNote(1, response);
/*      */       
/*      */ 
/*  439 */       req.getParameters().setQueryStringEncoding(this.connector.getURIEncoding());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  446 */       boolean logged = false;
/*  447 */       if (request.mappingData != null) {
/*  448 */         if (request.mappingData.context != null) {
/*  449 */           logged = true;
/*  450 */           request.mappingData.context.logAccess(request, response, time, true);
/*      */         }
/*  452 */         else if (request.mappingData.host != null) {
/*  453 */           logged = true;
/*  454 */           request.mappingData.host.logAccess(request, response, time, true);
/*      */         }
/*      */       }
/*      */       
/*  458 */       if (!logged) {
/*  459 */         this.connector.getService().getContainer().logAccess(request, response, time, true);
/*      */       }
/*      */     }
/*      */     catch (Throwable t) {
/*  463 */       ExceptionUtils.handleThrowable(t);
/*  464 */       log.warn(sm.getString("coyoteAdapter.accesslogFail"), t);
/*      */     } finally {
/*  466 */       request.recycle();
/*  467 */       response.recycle();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void checkRecycled(org.apache.coyote.Request req, org.apache.coyote.Response res)
/*      */   {
/*  479 */     Request request = (Request)req.getNote(1);
/*  480 */     Response response = (Response)res.getNote(1);
/*  481 */     String messageKey = null;
/*  482 */     if ((request != null) && (request.getHost() != null)) {
/*  483 */       messageKey = "coyoteAdapter.checkRecycled.request";
/*  484 */     } else if ((response != null) && (response.getContentWritten() != 0L)) {
/*  485 */       messageKey = "coyoteAdapter.checkRecycled.response";
/*      */     }
/*  487 */     if (messageKey != null)
/*      */     {
/*      */ 
/*  490 */       log(req, res, 0L);
/*      */       
/*  492 */       if (this.connector.getState().isAvailable()) {
/*  493 */         if (log.isInfoEnabled()) {
/*  494 */           log.info(sm.getString(messageKey), new RecycleRequiredException(null));
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */       }
/*  501 */       else if (log.isDebugEnabled()) {
/*  502 */         log.debug(sm.getString(messageKey), new RecycleRequiredException(null));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDomain()
/*      */   {
/*  512 */     return this.connector.getDomain();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean postParseRequest(org.apache.coyote.Request req, Request request, org.apache.coyote.Response res, Response response)
/*      */     throws IOException, ServletException
/*      */   {
/*  542 */     if (req.scheme().isNull())
/*      */     {
/*      */ 
/*  545 */       req.scheme().setString(this.connector.getScheme());
/*  546 */       request.setSecure(this.connector.getSecure());
/*      */     }
/*      */     else {
/*  549 */       request.setSecure(req.scheme().equals("https"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  554 */     String proxyName = this.connector.getProxyName();
/*  555 */     int proxyPort = this.connector.getProxyPort();
/*  556 */     if (proxyPort != 0) {
/*  557 */       req.setServerPort(proxyPort);
/*  558 */     } else if (req.getServerPort() == -1)
/*      */     {
/*  560 */       if (req.scheme().equals("https")) {
/*  561 */         req.setServerPort(443);
/*      */       } else {
/*  563 */         req.setServerPort(80);
/*      */       }
/*      */     }
/*  566 */     if (proxyName != null) {
/*  567 */       req.serverName().setString(proxyName);
/*      */     }
/*      */     
/*  570 */     MessageBytes undecodedURI = req.requestURI();
/*      */     
/*      */ 
/*  573 */     if (undecodedURI.equals("*")) {
/*  574 */       if (req.method().equalsIgnoreCase("OPTIONS")) {
/*  575 */         StringBuilder allow = new StringBuilder();
/*  576 */         allow.append("GET, HEAD, POST, PUT, DELETE");
/*      */         
/*  578 */         if (this.connector.getAllowTrace()) {
/*  579 */           allow.append(", TRACE");
/*      */         }
/*      */         
/*  582 */         allow.append(", OPTIONS");
/*  583 */         res.setHeader("Allow", allow.toString());
/*      */       } else {
/*  585 */         res.setStatus(404);
/*  586 */         res.setMessage("Not found");
/*      */       }
/*  588 */       this.connector.getService().getContainer().logAccess(request, response, 0L, true);
/*      */       
/*  590 */       return false;
/*      */     }
/*      */     
/*  593 */     MessageBytes decodedURI = req.decodedURI();
/*      */     
/*  595 */     if (undecodedURI.getType() == 2)
/*      */     {
/*  597 */       decodedURI.duplicate(undecodedURI);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  602 */       parsePathParameters(req, request);
/*      */       
/*      */ 
/*      */       try
/*      */       {
/*  607 */         req.getURLDecoder().convert(decodedURI, false);
/*      */       } catch (IOException ioe) {
/*  609 */         res.setStatus(400);
/*  610 */         res.setMessage("Invalid URI: " + ioe.getMessage());
/*  611 */         this.connector.getService().getContainer().logAccess(request, response, 0L, true);
/*      */         
/*  613 */         return false;
/*      */       }
/*      */       
/*  616 */       if (!normalize(req.decodedURI())) {
/*  617 */         res.setStatus(400);
/*  618 */         res.setMessage("Invalid URI");
/*  619 */         this.connector.getService().getContainer().logAccess(request, response, 0L, true);
/*      */         
/*  621 */         return false;
/*      */       }
/*      */       
/*  624 */       convertURI(decodedURI, request);
/*      */       
/*  626 */       if (!checkNormalize(req.decodedURI())) {
/*  627 */         res.setStatus(400);
/*  628 */         res.setMessage("Invalid URI character encoding");
/*  629 */         this.connector.getService().getContainer().logAccess(request, response, 0L, true);
/*      */         
/*  631 */         return false;
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*  641 */       decodedURI.toChars();
/*      */       
/*      */ 
/*  644 */       CharChunk uriCC = decodedURI.getCharChunk();
/*  645 */       int semicolon = uriCC.indexOf(';');
/*  646 */       if (semicolon > 0) {
/*  647 */         decodedURI.setChars(uriCC.getBuffer(), uriCC.getStart(), semicolon);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     MessageBytes serverName;
/*      */     
/*  654 */     if (this.connector.getUseIPVHosts()) {
/*  655 */       MessageBytes serverName = req.localName();
/*  656 */       if (serverName.isNull())
/*      */       {
/*  658 */         res.action(ActionCode.REQ_LOCAL_NAME_ATTRIBUTE, null);
/*      */       }
/*      */     } else {
/*  661 */       serverName = req.serverName();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  666 */     String version = null;
/*  667 */     Context versionContext = null;
/*  668 */     boolean mapRequired = true;
/*      */     
/*  670 */     while (mapRequired)
/*      */     {
/*  672 */       this.connector.getService().getMapper().map(serverName, decodedURI, version, request.getMappingData());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  677 */       if (request.getContext() == null) {
/*  678 */         res.setStatus(404);
/*  679 */         res.setMessage("Not found");
/*      */         
/*  681 */         Host host = request.getHost();
/*      */         
/*  683 */         if (host != null) {
/*  684 */           host.logAccess(request, response, 0L, true);
/*      */         }
/*  686 */         return false;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  693 */       if (request.getServletContext().getEffectiveSessionTrackingModes().contains(SessionTrackingMode.URL))
/*      */       {
/*      */ 
/*      */ 
/*  697 */         String sessionID = request.getPathParameter(SessionConfig.getSessionUriParamName(request.getContext()));
/*      */         
/*      */ 
/*  700 */         if (sessionID != null) {
/*  701 */           request.setRequestedSessionId(sessionID);
/*  702 */           request.setRequestedSessionURL(true);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  707 */       parseSessionCookiesId(request);
/*  708 */       parseSessionSslId(request);
/*      */       
/*  710 */       String sessionID = request.getRequestedSessionId();
/*      */       
/*  712 */       mapRequired = false;
/*  713 */       if ((version == null) || (request.getContext() != versionContext))
/*      */       {
/*      */ 
/*  716 */         version = null;
/*  717 */         versionContext = null;
/*      */         
/*  719 */         Context[] contexts = request.getMappingData().contexts;
/*      */         
/*      */ 
/*  722 */         if ((contexts != null) && (sessionID != null))
/*      */         {
/*  724 */           for (int i = contexts.length; i > 0; i--) {
/*  725 */             Context ctxt = contexts[(i - 1)];
/*  726 */             if (ctxt.getManager().findSession(sessionID) != null)
/*      */             {
/*      */ 
/*  729 */               if (ctxt.equals(request.getMappingData().context)) {
/*      */                 break;
/*      */               }
/*  732 */               version = ctxt.getWebappVersion();
/*  733 */               versionContext = ctxt;
/*      */               
/*  735 */               request.getMappingData().recycle();
/*  736 */               mapRequired = true;
/*      */               
/*      */ 
/*      */ 
/*  740 */               request.recycleSessionInfo();
/*  741 */               request.recycleCookieInfo(true); break;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  749 */       if ((!mapRequired) && (request.getContext().getPaused()))
/*      */       {
/*      */ 
/*      */         try
/*      */         {
/*  754 */           Thread.sleep(1000L);
/*      */         }
/*      */         catch (InterruptedException localInterruptedException) {}
/*      */         
/*      */ 
/*  759 */         request.getMappingData().recycle();
/*  760 */         mapRequired = true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  765 */     MessageBytes redirectPathMB = request.getMappingData().redirectPath;
/*  766 */     if (!redirectPathMB.isNull()) {
/*  767 */       String redirectPath = URLEncoder.DEFAULT.encode(redirectPathMB.toString());
/*  768 */       String query = request.getQueryString();
/*  769 */       if (request.isRequestedSessionIdFromURL())
/*      */       {
/*      */ 
/*  772 */         redirectPath = redirectPath + ";" + SessionConfig.getSessionUriParamName(request.getContext()) + "=" + request.getRequestedSessionId();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  777 */       if (query != null)
/*      */       {
/*      */ 
/*  780 */         redirectPath = redirectPath + "?" + query;
/*      */       }
/*  782 */       response.sendRedirect(redirectPath);
/*  783 */       request.getContext().logAccess(request, response, 0L, true);
/*  784 */       return false;
/*      */     }
/*      */     
/*      */ 
/*  788 */     if ((!this.connector.getAllowTrace()) && (req.method().equalsIgnoreCase("TRACE")))
/*      */     {
/*  790 */       Wrapper wrapper = request.getWrapper();
/*  791 */       String header = null;
/*  792 */       if (wrapper != null) {
/*  793 */         String[] methods = wrapper.getServletMethods();
/*  794 */         if (methods != null) {
/*  795 */           for (int i = 0; i < methods.length; i++) {
/*  796 */             if (!"TRACE".equals(methods[i]))
/*      */             {
/*      */ 
/*  799 */               if (header == null) {
/*  800 */                 header = methods[i];
/*      */               } else
/*  802 */                 header = header + ", " + methods[i];
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*  807 */       res.setStatus(405);
/*  808 */       res.addHeader("Allow", header);
/*  809 */       res.setMessage("TRACE method is not allowed");
/*  810 */       request.getContext().logAccess(request, response, 0L, true);
/*  811 */       return false;
/*      */     }
/*      */     
/*  814 */     doConnectorAuthenticationAuthorization(req, request);
/*      */     
/*  816 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */   private void doConnectorAuthenticationAuthorization(org.apache.coyote.Request req, Request request)
/*      */   {
/*  822 */     String username = req.getRemoteUser().toString();
/*  823 */     if (username != null) {
/*  824 */       if (log.isDebugEnabled()) {
/*  825 */         log.debug(sm.getString("coyoteAdapter.authenticate", new Object[] { username }));
/*      */       }
/*  827 */       if (req.getRemoteUserNeedsAuthorization()) {
/*  828 */         Authenticator authenticator = request.getContext().getAuthenticator();
/*  829 */         if (authenticator == null)
/*      */         {
/*      */ 
/*      */ 
/*  833 */           request.setUserPrincipal(new CoyotePrincipal(username));
/*  834 */         } else if (!(authenticator instanceof AuthenticatorBase)) {
/*  835 */           if (log.isDebugEnabled()) {
/*  836 */             log.debug(sm.getString("coyoteAdapter.authorize", new Object[] { username }));
/*      */           }
/*      */           
/*      */ 
/*  840 */           request.setUserPrincipal(request.getContext().getRealm().authenticate(username));
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*  850 */         request.setUserPrincipal(new CoyotePrincipal(username));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  855 */     String authtype = req.getAuthType().toString();
/*  856 */     if (authtype != null) {
/*  857 */       request.setAuthType(authtype);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parsePathParameters(org.apache.coyote.Request req, Request request)
/*      */   {
/*  875 */     req.decodedURI().toBytes();
/*      */     
/*  877 */     ByteChunk uriBC = req.decodedURI().getByteChunk();
/*  878 */     int semicolon = uriBC.indexOf(';', 0);
/*      */     
/*      */ 
/*  881 */     if (semicolon == -1) {
/*  882 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  887 */     String enc = this.connector.getURIEncodingLower();
/*  888 */     if (enc == null) {
/*  889 */       enc = "iso-8859-1";
/*      */     }
/*  891 */     Charset charset = null;
/*      */     try {
/*  893 */       charset = B2CConverter.getCharsetLower(enc);
/*      */     } catch (UnsupportedEncodingException e1) {
/*  895 */       log.warn(sm.getString("coyoteAdapter.parsePathParam", new Object[] { enc }));
/*      */     }
/*      */     
/*      */ 
/*  899 */     if (log.isDebugEnabled()) {
/*  900 */       log.debug(sm.getString("coyoteAdapter.debug", new Object[] { "uriBC", uriBC.toString() }));
/*      */       
/*  902 */       log.debug(sm.getString("coyoteAdapter.debug", new Object[] { "semicolon", String.valueOf(semicolon) }));
/*      */       
/*  904 */       log.debug(sm.getString("coyoteAdapter.debug", new Object[] { "enc", enc }));
/*      */     }
/*      */     
/*  907 */     while (semicolon > -1)
/*      */     {
/*  909 */       int start = uriBC.getStart();
/*  910 */       int end = uriBC.getEnd();
/*      */       
/*  912 */       int pathParamStart = semicolon + 1;
/*  913 */       int pathParamEnd = ByteChunk.findBytes(uriBC.getBuffer(), start + pathParamStart, end, new byte[] { 59, 47 });
/*      */       
/*      */ 
/*      */ 
/*  917 */       String pv = null;
/*      */       
/*  919 */       if (pathParamEnd >= 0) {
/*  920 */         if (charset != null) {
/*  921 */           pv = new String(uriBC.getBuffer(), start + pathParamStart, pathParamEnd - pathParamStart, charset);
/*      */         }
/*      */         
/*      */ 
/*  925 */         byte[] buf = uriBC.getBuffer();
/*  926 */         for (int i = 0; i < end - start - pathParamEnd; i++) {
/*  927 */           buf[(start + semicolon + i)] = buf[(start + i + pathParamEnd)];
/*      */         }
/*      */         
/*  930 */         uriBC.setBytes(buf, start, end - start - pathParamEnd + semicolon);
/*      */       }
/*      */       else {
/*  933 */         if (charset != null) {
/*  934 */           pv = new String(uriBC.getBuffer(), start + pathParamStart, end - start - pathParamStart, charset);
/*      */         }
/*      */         
/*  937 */         uriBC.setEnd(start + semicolon);
/*      */       }
/*      */       
/*  940 */       if (log.isDebugEnabled()) {
/*  941 */         log.debug(sm.getString("coyoteAdapter.debug", new Object[] { "pathParamStart", String.valueOf(pathParamStart) }));
/*      */         
/*  943 */         log.debug(sm.getString("coyoteAdapter.debug", new Object[] { "pathParamEnd", String.valueOf(pathParamEnd) }));
/*      */         
/*  945 */         log.debug(sm.getString("coyoteAdapter.debug", new Object[] { "pv", pv }));
/*      */       }
/*      */       
/*  948 */       if (pv != null) {
/*  949 */         int equals = pv.indexOf('=');
/*  950 */         if (equals > -1) {
/*  951 */           String name = pv.substring(0, equals);
/*  952 */           String value = pv.substring(equals + 1);
/*  953 */           request.addPathParameter(name, value);
/*  954 */           if (log.isDebugEnabled()) {
/*  955 */             log.debug(sm.getString("coyoteAdapter.debug", new Object[] { "equals", String.valueOf(equals) }));
/*      */             
/*  957 */             log.debug(sm.getString("coyoteAdapter.debug", new Object[] { "name", name }));
/*      */             
/*  959 */             log.debug(sm.getString("coyoteAdapter.debug", new Object[] { "value", value }));
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  965 */       semicolon = uriBC.indexOf(';', semicolon);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parseSessionSslId(Request request)
/*      */   {
/*  977 */     if ((request.getRequestedSessionId() == null) && (SSL_ONLY.equals(request.getServletContext().getEffectiveSessionTrackingModes())) && (request.connector.secure))
/*      */     {
/*      */ 
/*      */ 
/*  981 */       request.setRequestedSessionId(request.getAttribute("javax.servlet.request.ssl_session_id").toString());
/*      */       
/*  983 */       request.setRequestedSessionSSL(true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parseSessionCookiesId(Request request)
/*      */   {
/*  999 */     Context context = request.getMappingData().context;
/* 1000 */     if ((context != null) && (!context.getServletContext().getEffectiveSessionTrackingModes().contains(SessionTrackingMode.COOKIE)))
/*      */     {
/*      */ 
/* 1003 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1007 */     ServerCookies serverCookies = request.getServerCookies();
/* 1008 */     int count = serverCookies.getCookieCount();
/* 1009 */     if (count <= 0) {
/* 1010 */       return;
/*      */     }
/*      */     
/* 1013 */     String sessionCookieName = SessionConfig.getSessionCookieName(context);
/*      */     
/* 1015 */     for (int i = 0; i < count; i++) {
/* 1016 */       ServerCookie scookie = serverCookies.getCookie(i);
/* 1017 */       if (scookie.getName().equals(sessionCookieName))
/*      */       {
/* 1019 */         if (!request.isRequestedSessionIdFromCookie())
/*      */         {
/* 1021 */           convertMB(scookie.getValue());
/* 1022 */           request.setRequestedSessionId(scookie.getValue().toString());
/*      */           
/* 1024 */           request.setRequestedSessionCookie(true);
/* 1025 */           request.setRequestedSessionURL(false);
/* 1026 */           if (log.isDebugEnabled()) {
/* 1027 */             log.debug(" Requested cookie session id is " + request.getRequestedSessionId());
/*      */           }
/*      */           
/*      */         }
/* 1031 */         else if (!request.isRequestedSessionIdValid())
/*      */         {
/* 1033 */           convertMB(scookie.getValue());
/* 1034 */           request.setRequestedSessionId(scookie.getValue().toString());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void convertURI(MessageBytes uri, Request request)
/*      */     throws IOException
/*      */   {
/* 1053 */     ByteChunk bc = uri.getByteChunk();
/* 1054 */     int length = bc.getLength();
/* 1055 */     CharChunk cc = uri.getCharChunk();
/* 1056 */     cc.allocate(length, -1);
/*      */     
/* 1058 */     String enc = this.connector.getURIEncoding();
/* 1059 */     if (enc != null) {
/* 1060 */       B2CConverter conv = request.getURIConverter();
/*      */       try {
/* 1062 */         if (conv == null) {
/* 1063 */           conv = new B2CConverter(B2CConverter.getCharset(enc), true);
/* 1064 */           request.setURIConverter(conv);
/*      */         } else {
/* 1066 */           conv.recycle();
/*      */         }
/*      */       } catch (IOException e) {
/* 1069 */         log.error(sm.getString("coyoteAdapter.invalidEncoding"));
/* 1070 */         this.connector.setURIEncoding(null);
/*      */       }
/* 1072 */       if (conv != null) {
/*      */         try {
/* 1074 */           conv.convert(bc, cc, true);
/* 1075 */           uri.setChars(cc.getBuffer(), cc.getStart(), cc.getLength());
/* 1076 */           return;
/*      */         }
/*      */         catch (IOException ioe)
/*      */         {
/* 1080 */           request.getResponse().sendError(400);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1087 */     byte[] bbuf = bc.getBuffer();
/* 1088 */     char[] cbuf = cc.getBuffer();
/* 1089 */     int start = bc.getStart();
/* 1090 */     for (int i = 0; i < length; i++) {
/* 1091 */       cbuf[i] = ((char)(bbuf[(i + start)] & 0xFF));
/*      */     }
/* 1093 */     uri.setChars(cbuf, 0, length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void convertMB(MessageBytes mb)
/*      */   {
/* 1105 */     if (mb.getType() != 2) {
/* 1106 */       return;
/*      */     }
/*      */     
/* 1109 */     ByteChunk bc = mb.getByteChunk();
/* 1110 */     CharChunk cc = mb.getCharChunk();
/* 1111 */     int length = bc.getLength();
/* 1112 */     cc.allocate(length, -1);
/*      */     
/*      */ 
/* 1115 */     byte[] bbuf = bc.getBuffer();
/* 1116 */     char[] cbuf = cc.getBuffer();
/* 1117 */     int start = bc.getStart();
/* 1118 */     for (int i = 0; i < length; i++) {
/* 1119 */       cbuf[i] = ((char)(bbuf[(i + start)] & 0xFF));
/*      */     }
/* 1121 */     mb.setChars(cbuf, 0, length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean normalize(MessageBytes uriMB)
/*      */   {
/* 1137 */     ByteChunk uriBC = uriMB.getByteChunk();
/* 1138 */     byte[] b = uriBC.getBytes();
/* 1139 */     int start = uriBC.getStart();
/* 1140 */     int end = uriBC.getEnd();
/*      */     
/*      */ 
/* 1143 */     if (start == end) {
/* 1144 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 1148 */     if ((end - start == 1) && (b[start] == 42)) {
/* 1149 */       return true;
/*      */     }
/*      */     
/* 1152 */     int pos = 0;
/* 1153 */     int index = 0;
/*      */     
/*      */ 
/*      */ 
/* 1157 */     for (pos = start; pos < end; pos++) {
/* 1158 */       if (b[pos] == 92) {
/* 1159 */         if (ALLOW_BACKSLASH) {
/* 1160 */           b[pos] = 47;
/*      */         } else {
/* 1162 */           return false;
/*      */         }
/*      */       }
/* 1165 */       if (b[pos] == 0) {
/* 1166 */         return false;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1171 */     if (b[start] != 47) {
/* 1172 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 1176 */     for (pos = start; pos < end - 1; pos++) {
/* 1177 */       if (b[pos] == 47) {
/* 1178 */         while ((pos + 1 < end) && (b[(pos + 1)] == 47)) {
/* 1179 */           copyBytes(b, pos, pos + 1, end - pos - 1);
/* 1180 */           end--;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1188 */     if ((end - start >= 2) && (b[(end - 1)] == 46) && (
/* 1189 */       (b[(end - 2)] == 47) || ((b[(end - 2)] == 46) && (b[(end - 3)] == 47))))
/*      */     {
/*      */ 
/* 1192 */       b[end] = 47;
/* 1193 */       end++;
/*      */     }
/*      */     
/*      */ 
/* 1197 */     uriBC.setEnd(end);
/*      */     
/* 1199 */     index = 0;
/*      */     
/*      */     for (;;)
/*      */     {
/* 1203 */       index = uriBC.indexOf("/./", 0, 3, index);
/* 1204 */       if (index < 0) {
/*      */         break;
/*      */       }
/* 1207 */       copyBytes(b, start + index, start + index + 2, end - start - index - 2);
/*      */       
/* 1209 */       end -= 2;
/* 1210 */       uriBC.setEnd(end);
/*      */     }
/*      */     
/* 1213 */     index = 0;
/*      */     
/*      */     for (;;)
/*      */     {
/* 1217 */       index = uriBC.indexOf("/../", 0, 4, index);
/* 1218 */       if (index < 0) {
/*      */         break;
/*      */       }
/*      */       
/* 1222 */       if (index == 0) {
/* 1223 */         return false;
/*      */       }
/* 1225 */       int index2 = -1;
/* 1226 */       for (pos = start + index - 1; (pos >= 0) && (index2 < 0); pos--) {
/* 1227 */         if (b[pos] == 47) {
/* 1228 */           index2 = pos;
/*      */         }
/*      */       }
/* 1231 */       copyBytes(b, start + index2, start + index + 3, end - start - index - 3);
/*      */       
/* 1233 */       end = end + index2 - index - 3;
/* 1234 */       uriBC.setEnd(end);
/* 1235 */       index = index2;
/*      */     }
/*      */     
/* 1238 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean checkNormalize(MessageBytes uriMB)
/*      */   {
/* 1255 */     CharChunk uriCC = uriMB.getCharChunk();
/* 1256 */     char[] c = uriCC.getChars();
/* 1257 */     int start = uriCC.getStart();
/* 1258 */     int end = uriCC.getEnd();
/*      */     
/* 1260 */     int pos = 0;
/*      */     
/*      */ 
/* 1263 */     for (pos = start; pos < end; pos++) {
/* 1264 */       if (c[pos] == '\\') {
/* 1265 */         return false;
/*      */       }
/* 1267 */       if (c[pos] == 0) {
/* 1268 */         return false;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1273 */     for (pos = start; pos < end - 1; pos++) {
/* 1274 */       if ((c[pos] == '/') && 
/* 1275 */         (c[(pos + 1)] == '/')) {
/* 1276 */         return false;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1282 */     if ((end - start >= 2) && (c[(end - 1)] == '.') && (
/* 1283 */       (c[(end - 2)] == '/') || ((c[(end - 2)] == '.') && (c[(end - 3)] == '/'))))
/*      */     {
/*      */ 
/* 1286 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1291 */     if (uriCC.indexOf("/./", 0, 3, 0) >= 0) {
/* 1292 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 1296 */     if (uriCC.indexOf("/../", 0, 4, 0) >= 0) {
/* 1297 */       return false;
/*      */     }
/*      */     
/* 1300 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static void copyBytes(byte[] b, int dest, int src, int len)
/*      */   {
/* 1318 */     for (int pos = 0; pos < len; pos++) {
/* 1319 */       b[(pos + dest)] = b[(pos + src)];
/*      */     }
/*      */   }
/*      */   
/*      */   private static class RecycleRequiredException
/*      */     extends Exception
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\connector\CoyoteAdapter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */