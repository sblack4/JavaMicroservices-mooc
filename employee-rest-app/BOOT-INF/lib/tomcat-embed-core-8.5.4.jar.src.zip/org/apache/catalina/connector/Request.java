/*      */ package org.apache.catalina.connector;
/*      */ 
/*      */ import java.io.BufferedReader;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.nio.charset.Charset;
/*      */ import java.security.Principal;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TimeZone;
/*      */ import java.util.TreeMap;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import javax.naming.NamingException;
/*      */ import javax.security.auth.Subject;
/*      */ import javax.servlet.AsyncContext;
/*      */ import javax.servlet.DispatcherType;
/*      */ import javax.servlet.FilterChain;
/*      */ import javax.servlet.MultipartConfigElement;
/*      */ import javax.servlet.RequestDispatcher;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletInputStream;
/*      */ import javax.servlet.ServletRequest;
/*      */ import javax.servlet.ServletRequestAttributeEvent;
/*      */ import javax.servlet.ServletRequestAttributeListener;
/*      */ import javax.servlet.ServletResponse;
/*      */ import javax.servlet.SessionTrackingMode;
/*      */ import javax.servlet.http.Cookie;
/*      */ import javax.servlet.http.HttpServletRequestWrapper;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import javax.servlet.http.HttpSession;
/*      */ import javax.servlet.http.HttpUpgradeHandler;
/*      */ import javax.servlet.http.Part;
/*      */ import org.apache.catalina.Authenticator;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.Realm;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.catalina.TomcatPrincipal;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.core.ApplicationMapping;
/*      */ import org.apache.catalina.core.ApplicationPart;
/*      */ import org.apache.catalina.core.ApplicationPushBuilder;
/*      */ import org.apache.catalina.core.ApplicationSessionCookieConfig;
/*      */ import org.apache.catalina.core.AsyncContextImpl;
/*      */ import org.apache.catalina.mapper.MappingData;
/*      */ import org.apache.catalina.servlet4preview.http.Mapping;
/*      */ import org.apache.catalina.servlet4preview.http.PushBuilder;
/*      */ import org.apache.catalina.util.ParameterMap;
/*      */ import org.apache.coyote.ActionCode;
/*      */ import org.apache.coyote.ProtocolHandler;
/*      */ import org.apache.coyote.UpgradeToken;
/*      */ import org.apache.coyote.http11.upgrade.InternalHttpUpgradeHandler;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.InstanceManager;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.buf.B2CConverter;
/*      */ import org.apache.tomcat.util.buf.ByteChunk;
/*      */ import org.apache.tomcat.util.buf.MessageBytes;
/*      */ import org.apache.tomcat.util.buf.UDecoder;
/*      */ import org.apache.tomcat.util.http.CookieProcessor;
/*      */ import org.apache.tomcat.util.http.FastHttpDateFormat;
/*      */ import org.apache.tomcat.util.http.MimeHeaders;
/*      */ import org.apache.tomcat.util.http.Parameters;
/*      */ import org.apache.tomcat.util.http.Parameters.FailReason;
/*      */ import org.apache.tomcat.util.http.RequestUtil;
/*      */ import org.apache.tomcat.util.http.ServerCookie;
/*      */ import org.apache.tomcat.util.http.ServerCookies;
/*      */ import org.apache.tomcat.util.http.fileupload.FileItem;
/*      */ import org.apache.tomcat.util.http.fileupload.FileUploadBase.InvalidContentTypeException;
/*      */ import org.apache.tomcat.util.http.fileupload.FileUploadBase.SizeException;
/*      */ import org.apache.tomcat.util.http.fileupload.FileUploadException;
/*      */ import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
/*      */ import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;
/*      */ import org.apache.tomcat.util.http.fileupload.servlet.ServletRequestContext;
/*      */ import org.apache.tomcat.util.http.parser.AcceptLanguage;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.ietf.jgss.GSSCredential;
/*      */ import org.ietf.jgss.GSSException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Request
/*      */   implements org.apache.catalina.servlet4preview.http.HttpServletRequest
/*      */ {
/*  124 */   private static final Log log = LogFactory.getLog(Request.class);
/*      */   
/*      */   protected org.apache.coyote.Request coyoteRequest;
/*      */   
/*      */   public Request()
/*      */   {
/*  130 */     this.formats = new SimpleDateFormat[formatsTemplate.length];
/*  131 */     for (int i = 0; i < this.formats.length; i++) {
/*  132 */       this.formats[i] = ((SimpleDateFormat)formatsTemplate[i].clone());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCoyoteRequest(org.apache.coyote.Request coyoteRequest)
/*      */   {
/*  151 */     this.coyoteRequest = coyoteRequest;
/*  152 */     this.inputBuffer.setRequest(coyoteRequest);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public org.apache.coyote.Request getCoyoteRequest()
/*      */   {
/*  161 */     return this.coyoteRequest;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  168 */   protected static final TimeZone GMT_ZONE = TimeZone.getTimeZone("GMT");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  174 */   protected static final StringManager sm = StringManager.getManager(Request.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  180 */   protected Cookie[] cookies = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final SimpleDateFormat[] formats;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  191 */   private static final SimpleDateFormat[] formatsTemplate = { new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US), new SimpleDateFormat("EEEEEE, dd-MMM-yy HH:mm:ss zzz", Locale.US), new SimpleDateFormat("EEE MMMM d HH:mm:ss yyyy", Locale.US) };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  201 */   protected static final Locale defaultLocale = Locale.getDefault();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  207 */   private final Map<String, Object> attributes = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  215 */   protected boolean sslAttributesParsed = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  221 */   protected final ArrayList<Locale> locales = new ArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  228 */   private final transient HashMap<String, Object> notes = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  234 */   protected String authType = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  240 */   protected DispatcherType internalDispatcherType = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  246 */   protected final InputBuffer inputBuffer = new InputBuffer();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  252 */   protected CoyoteInputStream inputStream = new CoyoteInputStream(this.inputBuffer);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  259 */   protected CoyoteReader reader = new CoyoteReader(this.inputBuffer);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  265 */   protected boolean usingInputStream = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  271 */   protected boolean usingReader = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  277 */   protected Principal userPrincipal = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  283 */   protected boolean parametersParsed = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  290 */   protected boolean cookiesParsed = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  297 */   protected boolean cookiesConverted = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  303 */   protected boolean secure = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  309 */   protected transient Subject subject = null;
/*      */   
/*      */ 
/*      */ 
/*      */   protected static final int CACHED_POST_LEN = 8192;
/*      */   
/*      */ 
/*  316 */   protected byte[] postData = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  322 */   protected ParameterMap<String, String[]> parameterMap = new ParameterMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  328 */   protected Collection<Part> parts = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  334 */   protected Exception partsParseException = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  340 */   protected Session session = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  346 */   protected Object requestDispatcherPath = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  352 */   protected boolean requestedSessionCookie = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  358 */   protected String requestedSessionId = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  364 */   protected boolean requestedSessionURL = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  370 */   protected boolean requestedSessionSSL = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  376 */   protected boolean localesParsed = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  382 */   protected int localPort = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  387 */   protected String remoteAddr = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  393 */   protected String remoteHost = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  399 */   protected int remotePort = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  404 */   protected String localAddr = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  410 */   protected String localName = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  415 */   private volatile AsyncContextImpl asyncContext = null;
/*      */   
/*  417 */   protected Boolean asyncSupported = null;
/*      */   
/*  419 */   private javax.servlet.http.HttpServletRequest applicationRequest = null;
/*      */   
/*      */   protected Connector connector;
/*      */   
/*      */   protected void addPathParameter(String name, String value)
/*      */   {
/*  425 */     this.coyoteRequest.addPathParameter(name, value);
/*      */   }
/*      */   
/*      */   protected String getPathParameter(String name) {
/*  429 */     return this.coyoteRequest.getPathParameter(name);
/*      */   }
/*      */   
/*      */   public void setAsyncSupported(boolean asyncSupported) {
/*  433 */     this.asyncSupported = Boolean.valueOf(asyncSupported);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void recycle()
/*      */   {
/*  442 */     this.internalDispatcherType = null;
/*  443 */     this.requestDispatcherPath = null;
/*      */     
/*  445 */     this.authType = null;
/*  446 */     this.inputBuffer.recycle();
/*  447 */     this.usingInputStream = false;
/*  448 */     this.usingReader = false;
/*  449 */     this.userPrincipal = null;
/*  450 */     this.subject = null;
/*  451 */     this.parametersParsed = false;
/*  452 */     if (this.parts != null) {
/*  453 */       for (Part part : this.parts) {
/*      */         try {
/*  455 */           part.delete();
/*      */         }
/*      */         catch (IOException localIOException) {}
/*      */       }
/*      */       
/*  460 */       this.parts = null;
/*      */     }
/*  462 */     this.partsParseException = null;
/*  463 */     this.locales.clear();
/*  464 */     this.localesParsed = false;
/*  465 */     this.secure = false;
/*  466 */     this.remoteAddr = null;
/*  467 */     this.remoteHost = null;
/*  468 */     this.remotePort = -1;
/*  469 */     this.localPort = -1;
/*  470 */     this.localAddr = null;
/*  471 */     this.localName = null;
/*      */     
/*  473 */     this.attributes.clear();
/*  474 */     this.sslAttributesParsed = false;
/*  475 */     this.notes.clear();
/*      */     
/*  477 */     recycleSessionInfo();
/*  478 */     recycleCookieInfo(false);
/*      */     
/*  480 */     if ((Globals.IS_SECURITY_ENABLED) || (Connector.RECYCLE_FACADES)) {
/*  481 */       this.parameterMap = new ParameterMap();
/*      */     } else {
/*  483 */       this.parameterMap.setLocked(false);
/*  484 */       this.parameterMap.clear();
/*      */     }
/*      */     
/*  487 */     this.mappingData.recycle();
/*  488 */     this.applicationMapping.recycle();
/*      */     
/*  490 */     this.applicationRequest = null;
/*  491 */     if ((Globals.IS_SECURITY_ENABLED) || (Connector.RECYCLE_FACADES)) {
/*  492 */       if (this.facade != null) {
/*  493 */         this.facade.clear();
/*  494 */         this.facade = null;
/*      */       }
/*  496 */       if (this.inputStream != null) {
/*  497 */         this.inputStream.clear();
/*  498 */         this.inputStream = null;
/*      */       }
/*  500 */       if (this.reader != null) {
/*  501 */         this.reader.clear();
/*  502 */         this.reader = null;
/*      */       }
/*      */     }
/*      */     
/*  506 */     this.asyncSupported = null;
/*  507 */     if (this.asyncContext != null) {
/*  508 */       this.asyncContext.recycle();
/*      */     }
/*  510 */     this.asyncContext = null;
/*      */   }
/*      */   
/*      */   protected void recycleSessionInfo()
/*      */   {
/*  515 */     if (this.session != null) {
/*      */       try {
/*  517 */         this.session.endAccess();
/*      */       } catch (Throwable t) {
/*  519 */         ExceptionUtils.handleThrowable(t);
/*  520 */         log.warn(sm.getString("coyoteRequest.sessionEndAccessFail"), t);
/*      */       }
/*      */     }
/*  523 */     this.session = null;
/*  524 */     this.requestedSessionCookie = false;
/*  525 */     this.requestedSessionId = null;
/*  526 */     this.requestedSessionURL = false;
/*  527 */     this.requestedSessionSSL = false;
/*      */   }
/*      */   
/*      */   protected void recycleCookieInfo(boolean recycleCoyote)
/*      */   {
/*  532 */     this.cookiesParsed = false;
/*  533 */     this.cookiesConverted = false;
/*  534 */     this.cookies = null;
/*  535 */     if (recycleCoyote) {
/*  536 */       getCoyoteRequest().getCookies().recycle();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Connector getConnector()
/*      */   {
/*  552 */     return this.connector;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnector(Connector connector)
/*      */   {
/*  561 */     this.connector = connector;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Context getContext()
/*      */   {
/*  575 */     return this.mappingData.context;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void setContext(Context context)
/*      */   {
/*  587 */     this.mappingData.context = context;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  594 */   protected FilterChain filterChain = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FilterChain getFilterChain()
/*      */   {
/*  602 */     return this.filterChain;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFilterChain(FilterChain filterChain)
/*      */   {
/*  611 */     this.filterChain = filterChain;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Host getHost()
/*      */   {
/*  619 */     return this.mappingData.host;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  626 */   protected final MappingData mappingData = new MappingData();
/*  627 */   private final ApplicationMapping applicationMapping = new ApplicationMapping(this.mappingData);
/*      */   
/*      */ 
/*      */ 
/*      */   public MappingData getMappingData()
/*      */   {
/*  633 */     return this.mappingData;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  640 */   protected RequestFacade facade = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public javax.servlet.http.HttpServletRequest getRequest()
/*      */   {
/*  648 */     if (this.facade == null) {
/*  649 */       this.facade = new RequestFacade(this);
/*      */     }
/*  651 */     if (this.applicationRequest == null) {
/*  652 */       this.applicationRequest = this.facade;
/*      */     }
/*  654 */     return this.applicationRequest;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRequest(javax.servlet.http.HttpServletRequest applicationRequest)
/*      */   {
/*  668 */     ServletRequest r = applicationRequest;
/*  669 */     while ((r instanceof HttpServletRequestWrapper)) {
/*  670 */       r = ((HttpServletRequestWrapper)r).getRequest();
/*      */     }
/*  672 */     if (r != this.facade) {
/*  673 */       throw new IllegalArgumentException(sm.getString("request.illegalWrap"));
/*      */     }
/*  675 */     this.applicationRequest = applicationRequest;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  682 */   protected Response response = null;
/*      */   
/*      */ 
/*      */ 
/*      */   public Response getResponse()
/*      */   {
/*  688 */     return this.response;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setResponse(Response response)
/*      */   {
/*  697 */     this.response = response;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public InputStream getStream()
/*      */   {
/*  704 */     if (this.inputStream == null) {
/*  705 */       this.inputStream = new CoyoteInputStream(this.inputBuffer);
/*      */     }
/*  707 */     return this.inputStream;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  713 */   protected B2CConverter URIConverter = null;
/*      */   
/*      */ 
/*      */ 
/*      */   protected B2CConverter getURIConverter()
/*      */   {
/*  719 */     return this.URIConverter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setURIConverter(B2CConverter URIConverter)
/*      */   {
/*  728 */     this.URIConverter = URIConverter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Wrapper getWrapper()
/*      */   {
/*  736 */     return this.mappingData.wrapper;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void setWrapper(Wrapper wrapper)
/*      */   {
/*  748 */     this.mappingData.wrapper = wrapper;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ServletInputStream createInputStream()
/*      */     throws IOException
/*      */   {
/*  764 */     if (this.inputStream == null) {
/*  765 */       this.inputStream = new CoyoteInputStream(this.inputBuffer);
/*      */     }
/*  767 */     return this.inputStream;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void finishRequest()
/*      */     throws IOException
/*      */   {
/*  778 */     if (this.response.getStatus() == 413) {
/*  779 */       checkSwallowInput();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getNote(String name)
/*      */   {
/*  791 */     return this.notes.get(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeNote(String name)
/*      */   {
/*  802 */     this.notes.remove(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLocalPort(int port)
/*      */   {
/*  812 */     this.localPort = port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNote(String name, Object value)
/*      */   {
/*  823 */     this.notes.put(name, value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRemoteAddr(String remoteAddr)
/*      */   {
/*  833 */     this.remoteAddr = remoteAddr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRemoteHost(String remoteHost)
/*      */   {
/*  844 */     this.remoteHost = remoteHost;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecure(boolean secure)
/*      */   {
/*  855 */     this.secure = secure;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setServerPort(int port)
/*      */   {
/*  865 */     this.coyoteRequest.setServerPort(port);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getAttribute(String name)
/*      */   {
/*  883 */     SpecialAttributeAdapter adapter = (SpecialAttributeAdapter)specialAttributes.get(name);
/*  884 */     if (adapter != null) {
/*  885 */       return adapter.get(this, name);
/*      */     }
/*      */     
/*  888 */     Object attr = this.attributes.get(name);
/*      */     
/*  890 */     if (attr != null) {
/*  891 */       return attr;
/*      */     }
/*      */     
/*  894 */     attr = this.coyoteRequest.getAttribute(name);
/*  895 */     if (attr != null) {
/*  896 */       return attr;
/*      */     }
/*  898 */     if ((isSSLAttribute(name)) || (name.equals("org.apache.tomcat.util.net.secure_protocol_version"))) {
/*  899 */       this.coyoteRequest.action(ActionCode.REQ_SSL_ATTRIBUTE, this.coyoteRequest);
/*      */       
/*  901 */       attr = this.coyoteRequest.getAttribute("javax.servlet.request.X509Certificate");
/*  902 */       if (attr != null) {
/*  903 */         this.attributes.put("javax.servlet.request.X509Certificate", attr);
/*      */       }
/*  905 */       attr = this.coyoteRequest.getAttribute("javax.servlet.request.cipher_suite");
/*  906 */       if (attr != null) {
/*  907 */         this.attributes.put("javax.servlet.request.cipher_suite", attr);
/*      */       }
/*  909 */       attr = this.coyoteRequest.getAttribute("javax.servlet.request.key_size");
/*  910 */       if (attr != null) {
/*  911 */         this.attributes.put("javax.servlet.request.key_size", attr);
/*      */       }
/*  913 */       attr = this.coyoteRequest.getAttribute("javax.servlet.request.ssl_session_id");
/*  914 */       if (attr != null) {
/*  915 */         this.attributes.put("javax.servlet.request.ssl_session_id", attr);
/*      */       }
/*  917 */       attr = this.coyoteRequest.getAttribute("javax.servlet.request.ssl_session_mgr");
/*  918 */       if (attr != null) {
/*  919 */         this.attributes.put("javax.servlet.request.ssl_session_mgr", attr);
/*      */       }
/*  921 */       attr = this.coyoteRequest.getAttribute("org.apache.tomcat.util.net.secure_protocol_version");
/*  922 */       if (attr != null) {
/*  923 */         this.attributes.put("org.apache.tomcat.util.net.secure_protocol_version", attr);
/*      */       }
/*  925 */       attr = this.attributes.get(name);
/*  926 */       this.sslAttributesParsed = true;
/*      */     }
/*  928 */     return attr;
/*      */   }
/*      */   
/*      */ 
/*      */   public long getContentLengthLong()
/*      */   {
/*  934 */     return this.coyoteRequest.getContentLengthLong();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static boolean isSSLAttribute(String name)
/*      */   {
/*  943 */     return ("javax.servlet.request.X509Certificate".equals(name)) || ("javax.servlet.request.cipher_suite".equals(name)) || ("javax.servlet.request.key_size".equals(name)) || ("javax.servlet.request.ssl_session_id".equals(name)) || ("javax.servlet.request.ssl_session_mgr".equals(name));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Enumeration<String> getAttributeNames()
/*      */   {
/*  980 */     if ((isSecure()) && (!this.sslAttributesParsed)) {
/*  981 */       getAttribute("javax.servlet.request.X509Certificate");
/*      */     }
/*      */     
/*      */ 
/*  985 */     Set<String> names = new HashSet();
/*  986 */     names.addAll(this.attributes.keySet());
/*  987 */     return Collections.enumeration(names);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCharacterEncoding()
/*      */   {
/*  996 */     return this.coyoteRequest.getCharacterEncoding();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getContentLength()
/*      */   {
/* 1005 */     return this.coyoteRequest.getContentLength();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getContentType()
/*      */   {
/* 1014 */     return this.coyoteRequest.getContentType();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setContentType(String contentType)
/*      */   {
/* 1024 */     this.coyoteRequest.setContentType(contentType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ServletInputStream getInputStream()
/*      */     throws IOException
/*      */   {
/* 1040 */     if (this.usingReader) {
/* 1041 */       throw new IllegalStateException(sm.getString("coyoteRequest.getInputStream.ise"));
/*      */     }
/*      */     
/*      */ 
/* 1045 */     this.usingInputStream = true;
/* 1046 */     if (this.inputStream == null) {
/* 1047 */       this.inputStream = new CoyoteInputStream(this.inputBuffer);
/*      */     }
/* 1049 */     return this.inputStream;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Locale getLocale()
/*      */   {
/* 1063 */     if (!this.localesParsed) {
/* 1064 */       parseLocales();
/*      */     }
/*      */     
/* 1067 */     if (this.locales.size() > 0) {
/* 1068 */       return (Locale)this.locales.get(0);
/*      */     }
/*      */     
/* 1071 */     return defaultLocale;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Enumeration<Locale> getLocales()
/*      */   {
/* 1084 */     if (!this.localesParsed) {
/* 1085 */       parseLocales();
/*      */     }
/*      */     
/* 1088 */     if (this.locales.size() > 0) {
/* 1089 */       return Collections.enumeration(this.locales);
/*      */     }
/* 1091 */     ArrayList<Locale> results = new ArrayList();
/* 1092 */     results.add(defaultLocale);
/* 1093 */     return Collections.enumeration(results);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getParameter(String name)
/*      */   {
/* 1108 */     if (!this.parametersParsed) {
/* 1109 */       parseParameters();
/*      */     }
/*      */     
/* 1112 */     return this.coyoteRequest.getParameters().getParameter(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Map<String, String[]> getParameterMap()
/*      */   {
/* 1130 */     if (this.parameterMap.isLocked()) {
/* 1131 */       return this.parameterMap;
/*      */     }
/*      */     
/* 1134 */     Enumeration<String> enumeration = getParameterNames();
/* 1135 */     while (enumeration.hasMoreElements()) {
/* 1136 */       String name = (String)enumeration.nextElement();
/* 1137 */       String[] values = getParameterValues(name);
/* 1138 */       this.parameterMap.put(name, values);
/*      */     }
/*      */     
/* 1141 */     this.parameterMap.setLocked(true);
/*      */     
/* 1143 */     return this.parameterMap;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Enumeration<String> getParameterNames()
/*      */   {
/* 1154 */     if (!this.parametersParsed) {
/* 1155 */       parseParameters();
/*      */     }
/*      */     
/* 1158 */     return this.coyoteRequest.getParameters().getParameterNames();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getParameterValues(String name)
/*      */   {
/* 1172 */     if (!this.parametersParsed) {
/* 1173 */       parseParameters();
/*      */     }
/*      */     
/* 1176 */     return this.coyoteRequest.getParameters().getParameterValues(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProtocol()
/*      */   {
/* 1186 */     return this.coyoteRequest.protocol().toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BufferedReader getReader()
/*      */     throws IOException
/*      */   {
/* 1203 */     if (this.usingInputStream) {
/* 1204 */       throw new IllegalStateException(sm.getString("coyoteRequest.getReader.ise"));
/*      */     }
/*      */     
/*      */ 
/* 1208 */     this.usingReader = true;
/* 1209 */     this.inputBuffer.checkConverter();
/* 1210 */     if (this.reader == null) {
/* 1211 */       this.reader = new CoyoteReader(this.inputBuffer);
/*      */     }
/* 1213 */     return this.reader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public String getRealPath(String path)
/*      */   {
/* 1230 */     Context context = getContext();
/* 1231 */     if (context == null) {
/* 1232 */       return null;
/*      */     }
/* 1234 */     ServletContext servletContext = context.getServletContext();
/* 1235 */     if (servletContext == null) {
/* 1236 */       return null;
/*      */     }
/*      */     try
/*      */     {
/* 1240 */       return servletContext.getRealPath(path);
/*      */     } catch (IllegalArgumentException e) {}
/* 1242 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRemoteAddr()
/*      */   {
/* 1252 */     if (this.remoteAddr == null) {
/* 1253 */       this.coyoteRequest.action(ActionCode.REQ_HOST_ADDR_ATTRIBUTE, this.coyoteRequest);
/*      */       
/* 1255 */       this.remoteAddr = this.coyoteRequest.remoteAddr().toString();
/*      */     }
/* 1257 */     return this.remoteAddr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRemoteHost()
/*      */   {
/* 1266 */     if (this.remoteHost == null) {
/* 1267 */       if (!this.connector.getEnableLookups()) {
/* 1268 */         this.remoteHost = getRemoteAddr();
/*      */       } else {
/* 1270 */         this.coyoteRequest.action(ActionCode.REQ_HOST_ATTRIBUTE, this.coyoteRequest);
/*      */         
/* 1272 */         this.remoteHost = this.coyoteRequest.remoteHost().toString();
/*      */       }
/*      */     }
/* 1275 */     return this.remoteHost;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRemotePort()
/*      */   {
/* 1284 */     if (this.remotePort == -1) {
/* 1285 */       this.coyoteRequest.action(ActionCode.REQ_REMOTEPORT_ATTRIBUTE, this.coyoteRequest);
/*      */       
/* 1287 */       this.remotePort = this.coyoteRequest.getRemotePort();
/*      */     }
/* 1289 */     return this.remotePort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getLocalName()
/*      */   {
/* 1298 */     if (this.localName == null) {
/* 1299 */       this.coyoteRequest.action(ActionCode.REQ_LOCAL_NAME_ATTRIBUTE, this.coyoteRequest);
/*      */       
/* 1301 */       this.localName = this.coyoteRequest.localName().toString();
/*      */     }
/* 1303 */     return this.localName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getLocalAddr()
/*      */   {
/* 1312 */     if (this.localAddr == null) {
/* 1313 */       this.coyoteRequest.action(ActionCode.REQ_LOCAL_ADDR_ATTRIBUTE, this.coyoteRequest);
/*      */       
/* 1315 */       this.localAddr = this.coyoteRequest.localAddr().toString();
/*      */     }
/* 1317 */     return this.localAddr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLocalPort()
/*      */   {
/* 1327 */     if (this.localPort == -1) {
/* 1328 */       this.coyoteRequest.action(ActionCode.REQ_LOCALPORT_ATTRIBUTE, this.coyoteRequest);
/*      */       
/* 1330 */       this.localPort = this.coyoteRequest.getLocalPort();
/*      */     }
/* 1332 */     return this.localPort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RequestDispatcher getRequestDispatcher(String path)
/*      */   {
/* 1344 */     Context context = getContext();
/* 1345 */     if (context == null) {
/* 1346 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 1350 */     if (path == null)
/* 1351 */       return null;
/* 1352 */     if (path.startsWith("/")) {
/* 1353 */       return context.getServletContext().getRequestDispatcher(path);
/*      */     }
/*      */     
/*      */ 
/* 1357 */     String servletPath = (String)getAttribute("javax.servlet.include.servlet_path");
/*      */     
/* 1359 */     if (servletPath == null) {
/* 1360 */       servletPath = getServletPath();
/*      */     }
/*      */     
/*      */ 
/* 1364 */     String pathInfo = getPathInfo();
/* 1365 */     String requestPath = null;
/*      */     
/* 1367 */     if (pathInfo == null) {
/* 1368 */       requestPath = servletPath;
/*      */     } else {
/* 1370 */       requestPath = servletPath + pathInfo;
/*      */     }
/*      */     
/* 1373 */     int pos = requestPath.lastIndexOf('/');
/* 1374 */     String relative = null;
/* 1375 */     if (pos >= 0) {
/* 1376 */       relative = requestPath.substring(0, pos + 1) + path;
/*      */     } else {
/* 1378 */       relative = requestPath + path;
/*      */     }
/*      */     
/* 1381 */     return context.getServletContext().getRequestDispatcher(relative);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getScheme()
/*      */   {
/* 1391 */     return this.coyoteRequest.scheme().toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getServerName()
/*      */   {
/* 1400 */     return this.coyoteRequest.serverName().toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getServerPort()
/*      */   {
/* 1409 */     return this.coyoteRequest.getServerPort();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isSecure()
/*      */   {
/* 1418 */     return this.secure;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeAttribute(String name)
/*      */   {
/* 1431 */     if (name.startsWith("org.apache.tomcat.")) {
/* 1432 */       this.coyoteRequest.getAttributes().remove(name);
/*      */     }
/*      */     
/* 1435 */     boolean found = this.attributes.containsKey(name);
/* 1436 */     if (found) {
/* 1437 */       Object value = this.attributes.get(name);
/* 1438 */       this.attributes.remove(name);
/*      */       
/*      */ 
/* 1441 */       notifyAttributeRemoved(name, value);
/*      */     }
/*      */     else {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAttribute(String name, Object value)
/*      */   {
/* 1458 */     if (name == null) {
/* 1459 */       throw new IllegalArgumentException(sm.getString("coyoteRequest.setAttribute.namenull"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1464 */     if (value == null) {
/* 1465 */       removeAttribute(name);
/* 1466 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1470 */     SpecialAttributeAdapter adapter = (SpecialAttributeAdapter)specialAttributes.get(name);
/* 1471 */     if (adapter != null) {
/* 1472 */       adapter.set(this, name, value);
/* 1473 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1478 */     if ((Globals.IS_SECURITY_ENABLED) && (name.equals("org.apache.tomcat.sendfile.filename")))
/*      */     {
/*      */ 
/*      */       try
/*      */       {
/*      */ 
/* 1484 */         canonicalPath = new File(value.toString()).getCanonicalPath();
/*      */       } catch (IOException e) { String canonicalPath;
/* 1486 */         throw new SecurityException(sm.getString("coyoteRequest.sendfileNotCanonical", new Object[] { value }), e);
/*      */       }
/*      */       
/*      */ 
/*      */       String canonicalPath;
/*      */       
/* 1492 */       System.getSecurityManager().checkRead(canonicalPath);
/*      */       
/* 1494 */       value = canonicalPath;
/*      */     }
/*      */     
/* 1497 */     Object oldValue = this.attributes.put(name, value);
/*      */     
/*      */ 
/* 1500 */     if (name.startsWith("org.apache.tomcat.")) {
/* 1501 */       this.coyoteRequest.setAttribute(name, value);
/*      */     }
/*      */     
/*      */ 
/* 1505 */     notifyAttributeAssigned(name, value, oldValue);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void notifyAttributeAssigned(String name, Object value, Object oldValue)
/*      */   {
/* 1518 */     Context context = getContext();
/* 1519 */     Object[] listeners = context.getApplicationEventListeners();
/* 1520 */     if ((listeners == null) || (listeners.length == 0)) {
/* 1521 */       return;
/*      */     }
/* 1523 */     boolean replaced = oldValue != null;
/* 1524 */     ServletRequestAttributeEvent event = null;
/* 1525 */     if (replaced) {
/* 1526 */       event = new ServletRequestAttributeEvent(context.getServletContext(), getRequest(), name, oldValue);
/*      */     }
/*      */     else {
/* 1529 */       event = new ServletRequestAttributeEvent(context.getServletContext(), getRequest(), name, value);
/*      */     }
/*      */     
/*      */ 
/* 1533 */     for (int i = 0; i < listeners.length; i++) {
/* 1534 */       if ((listeners[i] instanceof ServletRequestAttributeListener))
/*      */       {
/*      */ 
/* 1537 */         ServletRequestAttributeListener listener = (ServletRequestAttributeListener)listeners[i];
/*      */         try
/*      */         {
/* 1540 */           if (replaced) {
/* 1541 */             listener.attributeReplaced(event);
/*      */           } else {
/* 1543 */             listener.attributeAdded(event);
/*      */           }
/*      */         } catch (Throwable t) {
/* 1546 */           ExceptionUtils.handleThrowable(t);
/*      */           
/* 1548 */           this.attributes.put("javax.servlet.error.exception", t);
/* 1549 */           context.getLogger().error(sm.getString("coyoteRequest.attributeEvent"), t);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void notifyAttributeRemoved(String name, Object value)
/*      */   {
/* 1562 */     Context context = getContext();
/* 1563 */     Object[] listeners = context.getApplicationEventListeners();
/* 1564 */     if ((listeners == null) || (listeners.length == 0)) {
/* 1565 */       return;
/*      */     }
/* 1567 */     ServletRequestAttributeEvent event = new ServletRequestAttributeEvent(context.getServletContext(), getRequest(), name, value);
/*      */     
/*      */ 
/* 1570 */     for (int i = 0; i < listeners.length; i++) {
/* 1571 */       if ((listeners[i] instanceof ServletRequestAttributeListener))
/*      */       {
/*      */ 
/* 1574 */         ServletRequestAttributeListener listener = (ServletRequestAttributeListener)listeners[i];
/*      */         try
/*      */         {
/* 1577 */           listener.attributeRemoved(event);
/*      */         } catch (Throwable t) {
/* 1579 */           ExceptionUtils.handleThrowable(t);
/*      */           
/* 1581 */           this.attributes.put("javax.servlet.error.exception", t);
/* 1582 */           context.getLogger().error(sm.getString("coyoteRequest.attributeEvent"), t);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCharacterEncoding(String enc)
/*      */     throws UnsupportedEncodingException
/*      */   {
/* 1604 */     if (this.usingReader) {
/* 1605 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1609 */     B2CConverter.getCharset(enc);
/*      */     
/*      */ 
/* 1612 */     this.coyoteRequest.setCharacterEncoding(enc);
/*      */   }
/*      */   
/*      */ 
/*      */   public ServletContext getServletContext()
/*      */   {
/* 1618 */     return getContext().getServletContext();
/*      */   }
/*      */   
/*      */   public AsyncContext startAsync()
/*      */   {
/* 1623 */     return startAsync(getRequest(), this.response.getResponse());
/*      */   }
/*      */   
/*      */ 
/*      */   public AsyncContext startAsync(ServletRequest request, ServletResponse response)
/*      */   {
/* 1629 */     if (!isAsyncSupported()) {
/* 1630 */       throw new IllegalStateException(sm.getString("request.asyncNotSupported"));
/*      */     }
/*      */     
/* 1633 */     if (this.asyncContext == null) {
/* 1634 */       this.asyncContext = new AsyncContextImpl(this);
/*      */     }
/*      */     
/* 1637 */     this.asyncContext.setStarted(getContext(), request, response, (request == getRequest()) && (response == getResponse().getResponse()));
/*      */     
/* 1639 */     this.asyncContext.setTimeout(getConnector().getAsyncTimeout());
/*      */     
/* 1641 */     return this.asyncContext;
/*      */   }
/*      */   
/*      */   public boolean isAsyncStarted()
/*      */   {
/* 1646 */     if (this.asyncContext == null) {
/* 1647 */       return false;
/*      */     }
/*      */     
/* 1650 */     return this.asyncContext.isStarted();
/*      */   }
/*      */   
/*      */   public boolean isAsyncDispatching() {
/* 1654 */     if (this.asyncContext == null) {
/* 1655 */       return false;
/*      */     }
/*      */     
/* 1658 */     AtomicBoolean result = new AtomicBoolean(false);
/* 1659 */     this.coyoteRequest.action(ActionCode.ASYNC_IS_DISPATCHING, result);
/* 1660 */     return result.get();
/*      */   }
/*      */   
/*      */   public boolean isAsyncCompleting() {
/* 1664 */     if (this.asyncContext == null) {
/* 1665 */       return false;
/*      */     }
/*      */     
/* 1668 */     AtomicBoolean result = new AtomicBoolean(false);
/* 1669 */     this.coyoteRequest.action(ActionCode.ASYNC_IS_COMPLETING, result);
/* 1670 */     return result.get();
/*      */   }
/*      */   
/*      */   public boolean isAsync() {
/* 1674 */     if (this.asyncContext == null) {
/* 1675 */       return false;
/*      */     }
/*      */     
/* 1678 */     AtomicBoolean result = new AtomicBoolean(false);
/* 1679 */     this.coyoteRequest.action(ActionCode.ASYNC_IS_ASYNC, result);
/* 1680 */     return result.get();
/*      */   }
/*      */   
/*      */   public boolean isAsyncSupported()
/*      */   {
/* 1685 */     if (this.asyncSupported == null) {
/* 1686 */       return true;
/*      */     }
/*      */     
/* 1689 */     return this.asyncSupported.booleanValue();
/*      */   }
/*      */   
/*      */   public AsyncContext getAsyncContext()
/*      */   {
/* 1694 */     if (!isAsyncStarted()) {
/* 1695 */       throw new IllegalStateException(sm.getString("request.notAsync"));
/*      */     }
/* 1697 */     return this.asyncContext;
/*      */   }
/*      */   
/*      */   public AsyncContextImpl getAsyncContextInternal() {
/* 1701 */     return this.asyncContext;
/*      */   }
/*      */   
/*      */   public DispatcherType getDispatcherType()
/*      */   {
/* 1706 */     if (this.internalDispatcherType == null) {
/* 1707 */       return DispatcherType.REQUEST;
/*      */     }
/*      */     
/* 1710 */     return this.internalDispatcherType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addCookie(Cookie cookie)
/*      */   {
/* 1723 */     if (!this.cookiesConverted) {
/* 1724 */       convertCookies();
/*      */     }
/*      */     
/* 1727 */     int size = 0;
/* 1728 */     if (this.cookies != null) {
/* 1729 */       size = this.cookies.length;
/*      */     }
/*      */     
/* 1732 */     Cookie[] newCookies = new Cookie[size + 1];
/* 1733 */     for (int i = 0; i < size; i++) {
/* 1734 */       newCookies[i] = this.cookies[i];
/*      */     }
/* 1736 */     newCookies[size] = cookie;
/*      */     
/* 1738 */     this.cookies = newCookies;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addLocale(Locale locale)
/*      */   {
/* 1750 */     this.locales.add(locale);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearCookies()
/*      */   {
/* 1758 */     this.cookiesParsed = true;
/* 1759 */     this.cookiesConverted = true;
/* 1760 */     this.cookies = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearLocales()
/*      */   {
/* 1768 */     this.locales.clear();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAuthType(String type)
/*      */   {
/* 1780 */     this.authType = type;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPathInfo(String path)
/*      */   {
/* 1792 */     this.mappingData.pathInfo.setString(path);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRequestedSessionCookie(boolean flag)
/*      */   {
/* 1805 */     this.requestedSessionCookie = flag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRequestedSessionId(String id)
/*      */   {
/* 1818 */     this.requestedSessionId = id;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRequestedSessionURL(boolean flag)
/*      */   {
/* 1832 */     this.requestedSessionURL = flag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRequestedSessionSSL(boolean flag)
/*      */   {
/* 1846 */     this.requestedSessionSSL = flag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDecodedRequestURI()
/*      */   {
/* 1857 */     return this.coyoteRequest.decodedURI().toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MessageBytes getDecodedRequestURIMB()
/*      */   {
/* 1867 */     return this.coyoteRequest.decodedURI();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserPrincipal(Principal principal)
/*      */   {
/* 1880 */     if (Globals.IS_SECURITY_ENABLED) {
/* 1881 */       HttpSession session = getSession(false);
/* 1882 */       if ((this.subject != null) && (!this.subject.getPrincipals().contains(principal)))
/*      */       {
/* 1884 */         this.subject.getPrincipals().add(principal);
/* 1885 */       } else if ((session != null) && (session.getAttribute("javax.security.auth.subject") == null))
/*      */       {
/* 1887 */         this.subject = new Subject();
/* 1888 */         this.subject.getPrincipals().add(principal);
/*      */       }
/* 1890 */       if (session != null) {
/* 1891 */         session.setAttribute("javax.security.auth.subject", this.subject);
/*      */       }
/*      */     }
/*      */     
/* 1895 */     this.userPrincipal = principal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isPushSupported()
/*      */   {
/* 1909 */     AtomicBoolean result = new AtomicBoolean();
/* 1910 */     this.coyoteRequest.action(ActionCode.IS_PUSH_SUPPORTED, result);
/* 1911 */     return result.get();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PushBuilder getPushBuilder()
/*      */   {
/* 1923 */     return new ApplicationPushBuilder(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T extends HttpUpgradeHandler> T upgrade(Class<T> httpUpgradeHandlerClass)
/*      */     throws IOException, ServletException
/*      */   {
/* 1936 */     InstanceManager instanceManager = null;
/*      */     try {
/*      */       T handler;
/* 1939 */       if (InternalHttpUpgradeHandler.class.isAssignableFrom(httpUpgradeHandlerClass)) {
/* 1940 */         handler = (HttpUpgradeHandler)httpUpgradeHandlerClass.newInstance();
/*      */       } else {
/* 1942 */         instanceManager = getContext().getInstanceManager();
/* 1943 */         handler = (HttpUpgradeHandler)instanceManager.newInstance(httpUpgradeHandlerClass);
/*      */       }
/*      */     } catch (InstantiationException|IllegalAccessException|InvocationTargetException|NamingException e) { T handler;
/* 1946 */       throw new ServletException(e); }
/*      */     T handler;
/* 1948 */     UpgradeToken upgradeToken = new UpgradeToken(handler, getContext(), instanceManager);
/*      */     
/*      */ 
/* 1951 */     this.coyoteRequest.action(ActionCode.UPGRADE, upgradeToken);
/*      */     
/*      */ 
/*      */ 
/* 1955 */     this.response.setStatus(101);
/*      */     
/* 1957 */     return handler;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAuthType()
/*      */   {
/* 1965 */     return this.authType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getContextPath()
/*      */   {
/* 1975 */     String canonicalContextPath = getServletContext().getContextPath();
/* 1976 */     String uri = getRequestURI();
/* 1977 */     char[] uriChars = uri.toCharArray();
/* 1978 */     int lastSlash = this.mappingData.contextSlashCount;
/*      */     
/* 1980 */     if (lastSlash == 0) {
/* 1981 */       return "";
/*      */     }
/* 1983 */     int pos = 0;
/*      */     
/* 1985 */     while (lastSlash > 0) {
/* 1986 */       pos = nextSlash(uriChars, pos + 1);
/* 1987 */       if (pos == -1) {
/*      */         break;
/*      */       }
/* 1990 */       lastSlash--;
/*      */     }
/*      */     
/*      */ 
/*      */     String candidate;
/*      */     
/*      */ 
/* 1997 */     if (pos == -1) {
/* 1998 */       candidate = uri;
/*      */     } else {
/* 2000 */       candidate = uri.substring(0, pos);
/*      */     }
/* 2002 */     String candidate = removePathParameters(candidate);
/* 2003 */     candidate = UDecoder.URLDecode(candidate, this.connector.getURIEncoding());
/* 2004 */     candidate = RequestUtil.normalize(candidate);
/* 2005 */     boolean match = canonicalContextPath.equals(candidate);
/* 2006 */     while ((!match) && (pos != -1)) {
/* 2007 */       pos = nextSlash(uriChars, pos + 1);
/* 2008 */       if (pos == -1) {
/* 2009 */         candidate = uri;
/*      */       } else {
/* 2011 */         candidate = uri.substring(0, pos);
/*      */       }
/* 2013 */       candidate = removePathParameters(candidate);
/* 2014 */       candidate = UDecoder.URLDecode(candidate, this.connector.getURIEncoding());
/* 2015 */       candidate = RequestUtil.normalize(candidate);
/* 2016 */       match = canonicalContextPath.equals(candidate);
/*      */     }
/* 2018 */     if (match) {
/* 2019 */       if (pos == -1) {
/* 2020 */         return uri;
/*      */       }
/* 2022 */       return uri.substring(0, pos);
/*      */     }
/*      */     
/*      */ 
/* 2026 */     throw new IllegalStateException(sm.getString("coyoteRequest.getContextPath.ise", new Object[] { canonicalContextPath, uri }));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private String removePathParameters(String input)
/*      */   {
/* 2033 */     int nextSemiColon = input.indexOf(';');
/*      */     
/* 2035 */     if (nextSemiColon == -1) {
/* 2036 */       return input;
/*      */     }
/* 2038 */     StringBuilder result = new StringBuilder(input.length());
/* 2039 */     result.append(input.substring(0, nextSemiColon));
/*      */     for (;;) {
/* 2041 */       int nextSlash = input.indexOf('/', nextSemiColon);
/* 2042 */       if (nextSlash == -1) {
/*      */         break;
/*      */       }
/* 2045 */       nextSemiColon = input.indexOf(';', nextSlash);
/* 2046 */       if (nextSemiColon == -1) {
/* 2047 */         result.append(input.substring(nextSlash));
/* 2048 */         break;
/*      */       }
/* 2050 */       result.append(input.substring(nextSlash, nextSemiColon));
/*      */     }
/*      */     
/*      */ 
/* 2054 */     return result.toString();
/*      */   }
/*      */   
/*      */   private int nextSlash(char[] uri, int startPos)
/*      */   {
/* 2059 */     int len = uri.length;
/* 2060 */     int pos = startPos;
/* 2061 */     while (pos < len) {
/* 2062 */       if (uri[pos] == '/')
/* 2063 */         return pos;
/* 2064 */       if ((UDecoder.ALLOW_ENCODED_SLASH) && (uri[pos] == '%') && (pos + 2 < len) && (uri[(pos + 1)] == '2') && ((uri[(pos + 2)] == 'f') || (uri[(pos + 2)] == 'F')))
/*      */       {
/* 2066 */         return pos;
/*      */       }
/* 2068 */       pos++;
/*      */     }
/* 2070 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Cookie[] getCookies()
/*      */   {
/* 2083 */     if (!this.cookiesConverted) {
/* 2084 */       convertCookies();
/*      */     }
/* 2086 */     return this.cookies;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ServerCookies getServerCookies()
/*      */   {
/* 2098 */     parseCookies();
/* 2099 */     return this.coyoteRequest.getCookies();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getDateHeader(String name)
/*      */   {
/* 2116 */     String value = getHeader(name);
/* 2117 */     if (value == null) {
/* 2118 */       return -1L;
/*      */     }
/*      */     
/*      */ 
/* 2122 */     long result = FastHttpDateFormat.parseDate(value, this.formats);
/* 2123 */     if (result != -1L) {
/* 2124 */       return result;
/*      */     }
/* 2126 */     throw new IllegalArgumentException(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getHeader(String name)
/*      */   {
/* 2140 */     return this.coyoteRequest.getHeader(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Enumeration<String> getHeaders(String name)
/*      */   {
/* 2153 */     return this.coyoteRequest.getMimeHeaders().values(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Enumeration<String> getHeaderNames()
/*      */   {
/* 2162 */     return this.coyoteRequest.getMimeHeaders().names();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getIntHeader(String name)
/*      */   {
/* 2179 */     String value = getHeader(name);
/* 2180 */     if (value == null) {
/* 2181 */       return -1;
/*      */     }
/*      */     
/* 2184 */     return Integer.parseInt(value);
/*      */   }
/*      */   
/*      */ 
/*      */   public Mapping getMapping()
/*      */   {
/* 2190 */     return this.applicationMapping.getMapping();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getMethod()
/*      */   {
/* 2199 */     return this.coyoteRequest.method().toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPathInfo()
/*      */   {
/* 2208 */     return this.mappingData.pathInfo.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPathTranslated()
/*      */   {
/* 2219 */     Context context = getContext();
/* 2220 */     if (context == null) {
/* 2221 */       return null;
/*      */     }
/*      */     
/* 2224 */     if (getPathInfo() == null) {
/* 2225 */       return null;
/*      */     }
/*      */     
/* 2228 */     return context.getServletContext().getRealPath(getPathInfo());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getQueryString()
/*      */   {
/* 2237 */     return this.coyoteRequest.queryString().toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRemoteUser()
/*      */   {
/* 2248 */     if (this.userPrincipal == null) {
/* 2249 */       return null;
/*      */     }
/*      */     
/* 2252 */     return this.userPrincipal.getName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MessageBytes getRequestPathMB()
/*      */   {
/* 2262 */     return this.mappingData.requestPath;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRequestedSessionId()
/*      */   {
/* 2271 */     return this.requestedSessionId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRequestURI()
/*      */   {
/* 2280 */     return this.coyoteRequest.requestURI().toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StringBuffer getRequestURL()
/*      */   {
/* 2303 */     StringBuffer url = new StringBuffer();
/* 2304 */     String scheme = getScheme();
/* 2305 */     int port = getServerPort();
/* 2306 */     if (port < 0)
/*      */     {
/* 2308 */       port = 80;
/*      */     }
/*      */     
/* 2311 */     url.append(scheme);
/* 2312 */     url.append("://");
/* 2313 */     url.append(getServerName());
/* 2314 */     if (((scheme.equals("http")) && (port != 80)) || ((scheme.equals("https")) && (port != 443)))
/*      */     {
/* 2316 */       url.append(':');
/* 2317 */       url.append(port);
/*      */     }
/* 2319 */     url.append(getRequestURI());
/*      */     
/* 2321 */     return url;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getServletPath()
/*      */   {
/* 2331 */     return this.mappingData.wrapperPath.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpSession getSession()
/*      */   {
/* 2341 */     Session session = doGetSession(true);
/* 2342 */     if (session == null) {
/* 2343 */       return null;
/*      */     }
/*      */     
/* 2346 */     return session.getSession();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpSession getSession(boolean create)
/*      */   {
/* 2358 */     Session session = doGetSession(create);
/* 2359 */     if (session == null) {
/* 2360 */       return null;
/*      */     }
/*      */     
/* 2363 */     return session.getSession();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isRequestedSessionIdFromCookie()
/*      */   {
/* 2374 */     if (this.requestedSessionId == null) {
/* 2375 */       return false;
/*      */     }
/*      */     
/* 2378 */     return this.requestedSessionCookie;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isRequestedSessionIdFromURL()
/*      */   {
/* 2389 */     if (this.requestedSessionId == null) {
/* 2390 */       return false;
/*      */     }
/*      */     
/* 2393 */     return this.requestedSessionURL;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public boolean isRequestedSessionIdFromUrl()
/*      */   {
/* 2407 */     return isRequestedSessionIdFromURL();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isRequestedSessionIdValid()
/*      */   {
/* 2418 */     if (this.requestedSessionId == null) {
/* 2419 */       return false;
/*      */     }
/*      */     
/* 2422 */     Context context = getContext();
/* 2423 */     if (context == null) {
/* 2424 */       return false;
/*      */     }
/*      */     
/* 2427 */     Manager manager = context.getManager();
/* 2428 */     if (manager == null) {
/* 2429 */       return false;
/*      */     }
/*      */     
/* 2432 */     Session session = null;
/*      */     try {
/* 2434 */       session = manager.findSession(this.requestedSessionId);
/*      */     }
/*      */     catch (IOException localIOException) {}
/*      */     
/*      */ 
/* 2439 */     if ((session == null) || (!session.isValid()))
/*      */     {
/* 2441 */       if (getMappingData().contexts == null) {
/* 2442 */         return false;
/*      */       }
/* 2444 */       for (int i = getMappingData().contexts.length; i > 0; i--) {
/* 2445 */         Context ctxt = getMappingData().contexts[(i - 1)];
/*      */         try {
/* 2447 */           if (ctxt.getManager().findSession(this.requestedSessionId) != null)
/*      */           {
/* 2449 */             return true;
/*      */           }
/*      */         }
/*      */         catch (IOException localIOException1) {}
/*      */       }
/*      */       
/* 2455 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 2459 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUserInRole(String role)
/*      */   {
/* 2473 */     if (this.userPrincipal == null) {
/* 2474 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 2478 */     Context context = getContext();
/* 2479 */     if (context == null) {
/* 2480 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2485 */     if ("*".equals(role)) {
/* 2486 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2491 */     if (("**".equals(role)) && (!context.findSecurityRole("**"))) {
/* 2492 */       return this.userPrincipal != null;
/*      */     }
/*      */     
/* 2495 */     Realm realm = context.getRealm();
/* 2496 */     if (realm == null) {
/* 2497 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 2501 */     return realm.hasRole(getWrapper(), this.userPrincipal, role);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal getPrincipal()
/*      */   {
/* 2509 */     return this.userPrincipal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal getUserPrincipal()
/*      */   {
/* 2518 */     if ((this.userPrincipal instanceof TomcatPrincipal)) {
/* 2519 */       GSSCredential gssCredential = ((TomcatPrincipal)this.userPrincipal).getGssCredential();
/*      */       
/* 2521 */       if (gssCredential != null) {
/* 2522 */         int left = -1;
/*      */         try {
/* 2524 */           left = gssCredential.getRemainingLifetime();
/*      */         } catch (GSSException e) {
/* 2526 */           log.warn(sm.getString("coyoteRequest.gssLifetimeFail", new Object[] { this.userPrincipal.getName() }), e);
/*      */         }
/*      */         
/* 2529 */         if (left == 0)
/*      */         {
/*      */           try {
/* 2532 */             logout();
/*      */           }
/*      */           catch (ServletException localServletException) {}
/*      */           
/*      */ 
/* 2537 */           return null;
/*      */         }
/*      */       }
/* 2540 */       return ((TomcatPrincipal)this.userPrincipal).getUserPrincipal();
/*      */     }
/*      */     
/* 2543 */     return this.userPrincipal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Session getSessionInternal()
/*      */   {
/* 2552 */     return doGetSession(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void changeSessionId(String newSessionId)
/*      */   {
/* 2567 */     if ((this.requestedSessionId != null) && (this.requestedSessionId.length() > 0)) {
/* 2568 */       this.requestedSessionId = newSessionId;
/*      */     }
/*      */     
/* 2571 */     Context context = getContext();
/* 2572 */     if ((context != null) && (!context.getServletContext().getEffectiveSessionTrackingModes().contains(SessionTrackingMode.COOKIE)))
/*      */     {
/*      */ 
/*      */ 
/* 2576 */       return;
/*      */     }
/*      */     
/* 2579 */     if (this.response != null) {
/* 2580 */       Cookie newCookie = ApplicationSessionCookieConfig.createSessionCookie(context, newSessionId, isSecure());
/*      */       
/*      */ 
/* 2583 */       this.response.addSessionCookieInternal(newCookie);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String changeSessionId()
/*      */   {
/* 2597 */     Session session = getSessionInternal(false);
/* 2598 */     if (session == null) {
/* 2599 */       throw new IllegalStateException(sm.getString("coyoteRequest.changeSessionId"));
/*      */     }
/*      */     
/*      */ 
/* 2603 */     Manager manager = getContext().getManager();
/* 2604 */     manager.changeSessionId(session);
/*      */     
/* 2606 */     String newSessionId = session.getId();
/* 2607 */     changeSessionId(newSessionId);
/*      */     
/* 2609 */     return newSessionId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Session getSessionInternal(boolean create)
/*      */   {
/* 2619 */     return doGetSession(create);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isParametersParsed()
/*      */   {
/* 2627 */     return this.parametersParsed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isFinished()
/*      */   {
/* 2636 */     return this.coyoteRequest.isFinished();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void checkSwallowInput()
/*      */   {
/* 2646 */     Context context = getContext();
/* 2647 */     if ((context != null) && (!context.getSwallowAbortedUploads())) {
/* 2648 */       this.coyoteRequest.action(ActionCode.DISABLE_SWALLOW_INPUT, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean authenticate(HttpServletResponse response)
/*      */     throws IOException, ServletException
/*      */   {
/* 2658 */     if (response.isCommitted()) {
/* 2659 */       throw new IllegalStateException(sm.getString("coyoteRequest.authenticate.ise"));
/*      */     }
/*      */     
/*      */ 
/* 2663 */     return getContext().getAuthenticator().authenticate(this, response);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void login(String username, String password)
/*      */     throws ServletException
/*      */   {
/* 2672 */     if ((getAuthType() != null) || (getRemoteUser() != null) || (getUserPrincipal() != null))
/*      */     {
/* 2674 */       throw new ServletException(sm.getString("coyoteRequest.alreadyAuthenticated"));
/*      */     }
/*      */     
/*      */ 
/* 2678 */     Context context = getContext();
/* 2679 */     if (context.getAuthenticator() == null) {
/* 2680 */       throw new ServletException("no authenticator");
/*      */     }
/*      */     
/* 2683 */     context.getAuthenticator().login(username, password, this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void logout()
/*      */     throws ServletException
/*      */   {
/* 2691 */     getContext().getAuthenticator().logout(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Collection<Part> getParts()
/*      */     throws IOException, IllegalStateException, ServletException
/*      */   {
/* 2701 */     parseParts(true);
/*      */     
/* 2703 */     if (this.partsParseException != null) {
/* 2704 */       if ((this.partsParseException instanceof IOException))
/* 2705 */         throw ((IOException)this.partsParseException);
/* 2706 */       if ((this.partsParseException instanceof IllegalStateException))
/* 2707 */         throw ((IllegalStateException)this.partsParseException);
/* 2708 */       if ((this.partsParseException instanceof ServletException)) {
/* 2709 */         throw ((ServletException)this.partsParseException);
/*      */       }
/*      */     }
/*      */     
/* 2713 */     return this.parts;
/*      */   }
/*      */   
/*      */ 
/*      */   private void parseParts(boolean explicit)
/*      */   {
/* 2719 */     if ((this.parts != null) || (this.partsParseException != null)) {
/* 2720 */       return;
/*      */     }
/*      */     
/* 2723 */     Context context = getContext();
/* 2724 */     MultipartConfigElement mce = getWrapper().getMultipartConfigElement();
/*      */     
/* 2726 */     if (mce == null) {
/* 2727 */       if (context.getAllowCasualMultipartParsing()) {
/* 2728 */         mce = new MultipartConfigElement(null, this.connector.getMaxPostSize(), this.connector.getMaxPostSize(), this.connector.getMaxPostSize());
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 2733 */         if (explicit) {
/* 2734 */           this.partsParseException = new IllegalStateException(sm.getString("coyoteRequest.noMultipartConfig"));
/*      */           
/* 2736 */           return;
/*      */         }
/* 2738 */         this.parts = Collections.emptyList();
/* 2739 */         return;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2744 */     Parameters parameters = this.coyoteRequest.getParameters();
/* 2745 */     parameters.setLimit(getConnector().getMaxParameterCount());
/*      */     
/* 2747 */     boolean success = false;
/*      */     try
/*      */     {
/* 2750 */       String locationStr = mce.getLocation();
/* 2751 */       File location; File location; if ((locationStr == null) || (locationStr.length() == 0)) {
/* 2752 */         location = (File)context.getServletContext().getAttribute("javax.servlet.context.tempdir");
/*      */       }
/*      */       else
/*      */       {
/* 2756 */         location = new File(locationStr);
/* 2757 */         if (!location.isAbsolute()) {
/* 2758 */           location = new File((File)context.getServletContext().getAttribute("javax.servlet.context.tempdir"), locationStr).getAbsoluteFile();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2765 */       if (!location.isDirectory()) {
/* 2766 */         parameters.setParseFailedReason(Parameters.FailReason.MULTIPART_CONFIG_INVALID);
/* 2767 */         this.partsParseException = new IOException(sm.getString("coyoteRequest.uploadLocationInvalid", new Object[] { location }));
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/* 2775 */         DiskFileItemFactory factory = new DiskFileItemFactory();
/*      */         try {
/* 2777 */           factory.setRepository(location.getCanonicalFile());
/*      */         } catch (IOException ioe) {
/* 2779 */           parameters.setParseFailedReason(Parameters.FailReason.IO_ERROR);
/* 2780 */           this.partsParseException = ioe;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2872 */           if ((this.partsParseException != null) || (!success)) {
/* 2873 */             parameters.setParseFailedReason(Parameters.FailReason.UNKNOWN);
/*      */           }
/*      */           return;
/*      */         }
/* 2783 */         factory.setSizeThreshold(mce.getFileSizeThreshold());
/*      */         
/* 2785 */         ServletFileUpload upload = new ServletFileUpload();
/* 2786 */         upload.setFileItemFactory(factory);
/* 2787 */         upload.setFileSizeMax(mce.getMaxFileSize());
/* 2788 */         upload.setSizeMax(mce.getMaxRequestSize());
/*      */         
/* 2790 */         this.parts = new ArrayList();
/*      */         try {
/* 2792 */           List<FileItem> items = upload.parseRequest(new ServletRequestContext(this));
/*      */           
/* 2794 */           int maxPostSize = getConnector().getMaxPostSize();
/* 2795 */           int postSize = 0;
/* 2796 */           String enc = getCharacterEncoding();
/* 2797 */           Charset charset = null;
/* 2798 */           if (enc != null) {
/*      */             try {
/* 2800 */               charset = B2CConverter.getCharset(enc);
/*      */             }
/*      */             catch (UnsupportedEncodingException localUnsupportedEncodingException1) {}
/*      */           }
/*      */           
/* 2805 */           for (FileItem item : items) {
/* 2806 */             ApplicationPart part = new ApplicationPart(item, location);
/* 2807 */             this.parts.add(part);
/* 2808 */             if (part.getSubmittedFileName() == null) {
/* 2809 */               String name = part.getName();
/* 2810 */               String value = null;
/*      */               try {
/* 2812 */                 String encoding = parameters.getEncoding();
/* 2813 */                 if (encoding == null) {
/* 2814 */                   if (enc == null) {
/* 2815 */                     encoding = "ISO-8859-1";
/*      */                   } else {
/* 2817 */                     encoding = enc;
/*      */                   }
/*      */                 }
/* 2820 */                 value = part.getString(encoding);
/*      */               } catch (UnsupportedEncodingException uee) {
/*      */                 try {
/* 2823 */                   value = part.getString("ISO-8859-1");
/*      */                 }
/*      */                 catch (UnsupportedEncodingException localUnsupportedEncodingException2) {}
/*      */               }
/*      */               
/* 2828 */               if (maxPostSize >= 0)
/*      */               {
/*      */ 
/* 2831 */                 if (charset == null)
/*      */                 {
/* 2833 */                   postSize += name.getBytes().length;
/*      */                 } else {
/* 2835 */                   postSize += name.getBytes(charset).length;
/*      */                 }
/* 2837 */                 if (value != null)
/*      */                 {
/* 2839 */                   postSize++;
/*      */                   
/* 2841 */                   postSize = (int)(postSize + part.getSize());
/*      */                 }
/*      */                 
/* 2844 */                 postSize++;
/* 2845 */                 if (postSize > maxPostSize) {
/* 2846 */                   parameters.setParseFailedReason(Parameters.FailReason.POST_TOO_LARGE);
/* 2847 */                   throw new IllegalStateException(sm.getString("coyoteRequest.maxPostSizeExceeded"));
/*      */                 }
/*      */               }
/*      */               
/* 2851 */               parameters.addParameter(name, value);
/*      */             }
/*      */           }
/*      */           
/* 2855 */           success = true;
/*      */         } catch (FileUploadBase.InvalidContentTypeException e) {
/* 2857 */           parameters.setParseFailedReason(Parameters.FailReason.INVALID_CONTENT_TYPE);
/* 2858 */           this.partsParseException = new ServletException(e);
/*      */         } catch (FileUploadBase.SizeException e) {
/* 2860 */           parameters.setParseFailedReason(Parameters.FailReason.POST_TOO_LARGE);
/* 2861 */           checkSwallowInput();
/* 2862 */           this.partsParseException = new IllegalStateException(e);
/*      */         } catch (FileUploadException e) {
/* 2864 */           parameters.setParseFailedReason(Parameters.FailReason.IO_ERROR);
/* 2865 */           this.partsParseException = new IOException(e);
/*      */         }
/*      */         catch (IllegalStateException e) {
/* 2868 */           checkSwallowInput();
/* 2869 */           this.partsParseException = e;
/*      */         }
/*      */       }
/* 2872 */     } finally { if ((this.partsParseException != null) || (!success)) {
/* 2873 */         parameters.setParseFailedReason(Parameters.FailReason.UNKNOWN);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Part getPart(String name)
/*      */     throws IOException, IllegalStateException, ServletException
/*      */   {
/* 2885 */     Collection<Part> c = getParts();
/* 2886 */     Iterator<Part> iterator = c.iterator();
/* 2887 */     while (iterator.hasNext()) {
/* 2888 */       Part part = (Part)iterator.next();
/* 2889 */       if (name.equals(part.getName())) {
/* 2890 */         return part;
/*      */       }
/*      */     }
/* 2893 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Session doGetSession(boolean create)
/*      */   {
/* 2902 */     Context context = getContext();
/* 2903 */     if (context == null) {
/* 2904 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 2908 */     if ((this.session != null) && (!this.session.isValid())) {
/* 2909 */       this.session = null;
/*      */     }
/* 2911 */     if (this.session != null) {
/* 2912 */       return this.session;
/*      */     }
/*      */     
/*      */ 
/* 2916 */     Manager manager = context.getManager();
/* 2917 */     if (manager == null) {
/* 2918 */       return null;
/*      */     }
/* 2920 */     if (this.requestedSessionId != null) {
/*      */       try {
/* 2922 */         this.session = manager.findSession(this.requestedSessionId);
/*      */       } catch (IOException e) {
/* 2924 */         this.session = null;
/*      */       }
/* 2926 */       if ((this.session != null) && (!this.session.isValid())) {
/* 2927 */         this.session = null;
/*      */       }
/* 2929 */       if (this.session != null) {
/* 2930 */         this.session.access();
/* 2931 */         return this.session;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2936 */     if (!create) {
/* 2937 */       return null;
/*      */     }
/* 2939 */     if ((this.response != null) && (context.getServletContext().getEffectiveSessionTrackingModes().contains(SessionTrackingMode.COOKIE)) && (this.response.getResponse().isCommitted()))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2944 */       throw new IllegalStateException(sm.getString("coyoteRequest.sessionCreateCommitted"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2950 */     String sessionId = getRequestedSessionId();
/* 2951 */     if (!this.requestedSessionSSL)
/*      */     {
/*      */ 
/* 2954 */       if (("/".equals(context.getSessionCookiePath())) && (isRequestedSessionIdFromCookie()))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2966 */         if (context.getValidateClientProvidedNewSessionId()) {
/* 2967 */           boolean found = false;
/* 2968 */           for (Container container : getHost().findChildren()) {
/* 2969 */             Manager m = ((Context)container).getManager();
/* 2970 */             if (m != null) {
/*      */               try {
/* 2972 */                 if (m.findSession(sessionId) != null) {
/* 2973 */                   found = true;
/* 2974 */                   break;
/*      */                 }
/*      */               }
/*      */               catch (IOException localIOException1) {}
/*      */             }
/*      */           }
/*      */           
/*      */ 
/* 2982 */           if (!found) {
/* 2983 */             sessionId = null;
/*      */           }
/*      */         }
/*      */       } else
/* 2987 */         sessionId = null;
/*      */     }
/* 2989 */     this.session = manager.createSession(sessionId);
/*      */     
/*      */ 
/* 2992 */     if ((this.session != null) && (context.getServletContext().getEffectiveSessionTrackingModes().contains(SessionTrackingMode.COOKIE)))
/*      */     {
/*      */ 
/*      */ 
/* 2996 */       Cookie cookie = ApplicationSessionCookieConfig.createSessionCookie(context, this.session.getIdInternal(), isSecure());
/*      */       
/*      */ 
/*      */ 
/* 3000 */       this.response.addSessionCookieInternal(cookie);
/*      */     }
/*      */     
/* 3003 */     if (this.session == null) {
/* 3004 */       return null;
/*      */     }
/*      */     
/* 3007 */     this.session.access();
/* 3008 */     return this.session;
/*      */   }
/*      */   
/*      */   protected String unescape(String s) {
/* 3012 */     if (s == null) {
/* 3013 */       return null;
/*      */     }
/* 3015 */     if (s.indexOf('\\') == -1) {
/* 3016 */       return s;
/*      */     }
/* 3018 */     StringBuilder buf = new StringBuilder();
/* 3019 */     for (int i = 0; i < s.length(); i++) {
/* 3020 */       char c = s.charAt(i);
/* 3021 */       if (c != '\\') {
/* 3022 */         buf.append(c);
/*      */       } else {
/* 3024 */         i++; if (i >= s.length())
/*      */         {
/* 3026 */           throw new IllegalArgumentException();
/*      */         }
/* 3028 */         c = s.charAt(i);
/* 3029 */         buf.append(c);
/*      */       }
/*      */     }
/* 3032 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parseCookies()
/*      */   {
/* 3040 */     if (this.cookiesParsed) {
/* 3041 */       return;
/*      */     }
/*      */     
/* 3044 */     this.cookiesParsed = true;
/*      */     
/* 3046 */     ServerCookies serverCookies = this.coyoteRequest.getCookies();
/* 3047 */     CookieProcessor cookieProcessor = getContext().getCookieProcessor();
/* 3048 */     cookieProcessor.parseCookieHeader(this.coyoteRequest.getMimeHeaders(), serverCookies);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void convertCookies()
/*      */   {
/* 3056 */     if (this.cookiesConverted) {
/* 3057 */       return;
/*      */     }
/*      */     
/* 3060 */     this.cookiesConverted = true;
/*      */     
/* 3062 */     if (getContext() == null) {
/* 3063 */       return;
/*      */     }
/*      */     
/* 3066 */     parseCookies();
/*      */     
/* 3068 */     ServerCookies serverCookies = this.coyoteRequest.getCookies();
/* 3069 */     CookieProcessor cookieProcessor = getContext().getCookieProcessor();
/*      */     
/* 3071 */     int count = serverCookies.getCookieCount();
/* 3072 */     if (count <= 0) {
/* 3073 */       return;
/*      */     }
/*      */     
/* 3076 */     this.cookies = new Cookie[count];
/*      */     
/* 3078 */     int idx = 0;
/* 3079 */     for (int i = 0; i < count; i++) {
/* 3080 */       ServerCookie scookie = serverCookies.getCookie(i);
/*      */       
/*      */ 
/*      */       try
/*      */       {
/* 3085 */         Cookie cookie = new Cookie(scookie.getName().toString(), null);
/* 3086 */         int version = scookie.getVersion();
/* 3087 */         cookie.setVersion(version);
/* 3088 */         scookie.getValue().getByteChunk().setCharset(cookieProcessor.getCharset());
/* 3089 */         cookie.setValue(unescape(scookie.getValue().toString()));
/* 3090 */         cookie.setPath(unescape(scookie.getPath().toString()));
/* 3091 */         String domain = scookie.getDomain().toString();
/* 3092 */         if (domain != null)
/*      */         {
/* 3094 */           cookie.setDomain(unescape(domain));
/*      */         }
/* 3096 */         String comment = scookie.getComment().toString();
/* 3097 */         cookie.setComment(version == 1 ? unescape(comment) : null);
/* 3098 */         this.cookies[(idx++)] = cookie;
/*      */       }
/*      */       catch (IllegalArgumentException localIllegalArgumentException) {}
/*      */     }
/*      */     
/* 3103 */     if (idx < count) {
/* 3104 */       Cookie[] ncookies = new Cookie[idx];
/* 3105 */       System.arraycopy(this.cookies, 0, ncookies, 0, idx);
/* 3106 */       this.cookies = ncookies;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parseParameters()
/*      */   {
/* 3116 */     this.parametersParsed = true;
/*      */     
/* 3118 */     Parameters parameters = this.coyoteRequest.getParameters();
/* 3119 */     boolean success = false;
/*      */     try
/*      */     {
/* 3122 */       parameters.setLimit(getConnector().getMaxParameterCount());
/*      */       
/*      */ 
/*      */ 
/* 3126 */       String enc = getCharacterEncoding();
/*      */       
/* 3128 */       boolean useBodyEncodingForURI = this.connector.getUseBodyEncodingForURI();
/* 3129 */       if (enc != null) {
/* 3130 */         parameters.setEncoding(enc);
/* 3131 */         if (useBodyEncodingForURI) {
/* 3132 */           parameters.setQueryStringEncoding(enc);
/*      */         }
/*      */       } else {
/* 3135 */         parameters.setEncoding("ISO-8859-1");
/*      */         
/* 3137 */         if (useBodyEncodingForURI) {
/* 3138 */           parameters.setQueryStringEncoding("ISO-8859-1");
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 3143 */       parameters.handleQueryParameters();
/*      */       
/* 3145 */       if ((this.usingInputStream) || (this.usingReader)) {
/* 3146 */         success = true;
/*      */ 
/*      */ 
/*      */       }
/* 3150 */       else if (!getConnector().isParseBodyMethod(getMethod())) {
/* 3151 */         success = true;
/*      */       }
/*      */       else
/*      */       {
/* 3155 */         String contentType = getContentType();
/* 3156 */         if (contentType == null) {
/* 3157 */           contentType = "";
/*      */         }
/* 3159 */         int semicolon = contentType.indexOf(';');
/* 3160 */         if (semicolon >= 0) {
/* 3161 */           contentType = contentType.substring(0, semicolon).trim();
/*      */         } else {
/* 3163 */           contentType = contentType.trim();
/*      */         }
/*      */         
/* 3166 */         if ("multipart/form-data".equals(contentType)) {
/* 3167 */           parseParts(false);
/* 3168 */           success = true;
/*      */ 
/*      */ 
/*      */         }
/* 3172 */         else if (!"application/x-www-form-urlencoded".equals(contentType)) {
/* 3173 */           success = true;
/*      */         }
/*      */         else
/*      */         {
/* 3177 */           int len = getContentLength();
/*      */           
/* 3179 */           if (len > 0) {
/* 3180 */             int maxPostSize = this.connector.getMaxPostSize();
/* 3181 */             if ((maxPostSize >= 0) && (len > maxPostSize)) {
/* 3182 */               Context context = getContext();
/* 3183 */               if ((context != null) && (context.getLogger().isDebugEnabled())) {
/* 3184 */                 context.getLogger().debug(sm.getString("coyoteRequest.postTooLarge"));
/*      */               }
/*      */               
/* 3187 */               checkSwallowInput();
/* 3188 */               parameters.setParseFailedReason(Parameters.FailReason.POST_TOO_LARGE); return;
/*      */             }
/*      */             
/* 3191 */             byte[] formData = null;
/* 3192 */             if (len < 8192) {
/* 3193 */               if (this.postData == null) {
/* 3194 */                 this.postData = new byte[' '];
/*      */               }
/* 3196 */               formData = this.postData;
/*      */             } else {
/* 3198 */               formData = new byte[len];
/*      */             }
/*      */             try {
/* 3201 */               if (readPostBody(formData, len) != len) {
/* 3202 */                 parameters.setParseFailedReason(Parameters.FailReason.REQUEST_BODY_INCOMPLETE); return;
/*      */               }
/*      */             }
/*      */             catch (IOException e)
/*      */             {
/* 3207 */               Context context = getContext();
/* 3208 */               if ((context != null) && (context.getLogger().isDebugEnabled())) {
/* 3209 */                 context.getLogger().debug(sm.getString("coyoteRequest.parseParameters"), e);
/*      */               }
/*      */               
/*      */ 
/* 3213 */               parameters.setParseFailedReason(Parameters.FailReason.CLIENT_DISCONNECT); return;
/*      */             }
/*      */             
/* 3216 */             parameters.processParameters(formData, 0, len);
/* 3217 */           } else if ("chunked".equalsIgnoreCase(this.coyoteRequest.getHeader("transfer-encoding")))
/*      */           {
/* 3219 */             byte[] formData = null;
/*      */             try {
/* 3221 */               formData = readChunkedPostBody();
/*      */             }
/*      */             catch (IllegalStateException ise) {
/* 3224 */               parameters.setParseFailedReason(Parameters.FailReason.POST_TOO_LARGE);
/* 3225 */               Context context = getContext();
/* 3226 */               if ((context != null) && (context.getLogger().isDebugEnabled())) {
/* 3227 */                 context.getLogger().debug(sm.getString("coyoteRequest.parseParameters"), ise);
/*      */               }
/*      */               
/*      */               return;
/*      */             }
/*      */             catch (IOException e)
/*      */             {
/* 3234 */               parameters.setParseFailedReason(Parameters.FailReason.CLIENT_DISCONNECT);
/* 3235 */               Context context = getContext();
/* 3236 */               if ((context != null) && (context.getLogger().isDebugEnabled())) {
/* 3237 */                 context.getLogger().debug(sm.getString("coyoteRequest.parseParameters"), e);
/*      */               }
/*      */               
/*      */               return;
/*      */             }
/*      */             
/* 3243 */             if (formData != null) {
/* 3244 */               parameters.processParameters(formData, 0, formData.length);
/*      */             }
/*      */           }
/* 3247 */           success = true;
/*      */         }
/* 3249 */       } } finally { if (!success) {
/* 3250 */         parameters.setParseFailedReason(Parameters.FailReason.UNKNOWN);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int readPostBody(byte[] body, int len)
/*      */     throws IOException
/*      */   {
/* 3268 */     int offset = 0;
/*      */     do {
/* 3270 */       int inputLen = getStream().read(body, offset, len - offset);
/* 3271 */       if (inputLen <= 0) {
/* 3272 */         return offset;
/*      */       }
/* 3274 */       offset += inputLen;
/* 3275 */     } while (len - offset > 0);
/* 3276 */     return len;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected byte[] readChunkedPostBody()
/*      */     throws IOException
/*      */   {
/* 3288 */     ByteChunk body = new ByteChunk();
/*      */     
/* 3290 */     byte[] buffer = new byte[' '];
/*      */     
/* 3292 */     int len = 0;
/* 3293 */     while (len > -1) {
/* 3294 */       len = getStream().read(buffer, 0, 8192);
/* 3295 */       if ((this.connector.getMaxPostSize() >= 0) && (body.getLength() + len > this.connector.getMaxPostSize()))
/*      */       {
/*      */ 
/* 3298 */         checkSwallowInput();
/* 3299 */         throw new IllegalStateException(sm.getString("coyoteRequest.chunkedPostTooLarge"));
/*      */       }
/*      */       
/* 3302 */       if (len > 0) {
/* 3303 */         body.append(buffer, 0, len);
/*      */       }
/*      */     }
/* 3306 */     if (body.getLength() == 0) {
/* 3307 */       return null;
/*      */     }
/* 3309 */     if (body.getLength() < body.getBuffer().length) {
/* 3310 */       int length = body.getLength();
/* 3311 */       byte[] result = new byte[length];
/* 3312 */       System.arraycopy(body.getBuffer(), 0, result, 0, length);
/* 3313 */       return result;
/*      */     }
/*      */     
/* 3316 */     return body.getBuffer();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parseLocales()
/*      */   {
/* 3325 */     this.localesParsed = true;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3331 */     TreeMap<Double, ArrayList<Locale>> locales = new TreeMap();
/*      */     
/* 3333 */     Enumeration<String> values = getHeaders("accept-language");
/*      */     
/* 3335 */     while (values.hasMoreElements()) {
/* 3336 */       String value = (String)values.nextElement();
/* 3337 */       parseLocalesHeader(value, locales);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3342 */     for (ArrayList<Locale> list : locales.values()) {
/* 3343 */       for (Locale locale : list) {
/* 3344 */         addLocale(locale);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parseLocalesHeader(String value, TreeMap<Double, ArrayList<Locale>> locales)
/*      */   {
/*      */     try
/*      */     {
/* 3360 */       acceptLanguages = AcceptLanguage.parse(new StringReader(value));
/*      */     }
/*      */     catch (IOException e) {
/*      */       List<AcceptLanguage> acceptLanguages;
/*      */       return;
/*      */     }
/*      */     List<AcceptLanguage> acceptLanguages;
/* 3367 */     for (AcceptLanguage acceptLanguage : acceptLanguages)
/*      */     {
/* 3369 */       Double key = Double.valueOf(-acceptLanguage.getQuality());
/* 3370 */       ArrayList<Locale> values = (ArrayList)locales.get(key);
/* 3371 */       if (values == null) {
/* 3372 */         values = new ArrayList();
/* 3373 */         locales.put(key, values);
/*      */       }
/* 3375 */       values.add(acceptLanguage.getLocale());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3391 */   private static final Map<String, SpecialAttributeAdapter> specialAttributes = new HashMap();
/*      */   
/*      */   static
/*      */   {
/* 3395 */     specialAttributes.put("org.apache.catalina.core.DISPATCHER_TYPE", new SpecialAttributeAdapter()
/*      */     {
/*      */       public Object get(Request request, String name)
/*      */       {
/* 3399 */         return request.internalDispatcherType == null ? DispatcherType.REQUEST : request.internalDispatcherType;
/*      */       }
/*      */       
/*      */ 
/*      */       public void set(Request request, String name, Object value)
/*      */       {
/* 3405 */         request.internalDispatcherType = ((DispatcherType)value);
/*      */       }
/* 3407 */     });
/* 3408 */     specialAttributes.put("org.apache.catalina.core.DISPATCHER_REQUEST_PATH", new SpecialAttributeAdapter()
/*      */     {
/*      */       public Object get(Request request, String name)
/*      */       {
/* 3412 */         return request.requestDispatcherPath == null ? request.getRequestPathMB().toString() : request.requestDispatcherPath.toString();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public void set(Request request, String name, Object value)
/*      */       {
/* 3419 */         request.requestDispatcherPath = value;
/*      */       }
/* 3421 */     });
/* 3422 */     specialAttributes.put("org.apache.catalina.ASYNC_SUPPORTED", new SpecialAttributeAdapter()
/*      */     {
/*      */       public Object get(Request request, String name)
/*      */       {
/* 3426 */         return request.asyncSupported;
/*      */       }
/*      */       
/*      */       public void set(Request request, String name, Object value)
/*      */       {
/* 3431 */         Boolean oldValue = request.asyncSupported;
/* 3432 */         request.asyncSupported = ((Boolean)value);
/* 3433 */         request.notifyAttributeAssigned(name, value, oldValue);
/*      */       }
/* 3435 */     });
/* 3436 */     specialAttributes.put("org.apache.catalina.realm.GSS_CREDENTIAL", new SpecialAttributeAdapter()
/*      */     {
/*      */       public Object get(Request request, String name)
/*      */       {
/* 3440 */         if ((request.userPrincipal instanceof TomcatPrincipal)) {
/* 3441 */           return ((TomcatPrincipal)request.userPrincipal).getGssCredential();
/*      */         }
/*      */         
/* 3444 */         return null;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public void set(Request request, String name, Object value) {}
/* 3451 */     });
/* 3452 */     specialAttributes.put("org.apache.catalina.parameter_parse_failed", new SpecialAttributeAdapter()
/*      */     {
/*      */       public Object get(Request request, String name)
/*      */       {
/* 3456 */         if (request.getCoyoteRequest().getParameters().isParseFailed())
/*      */         {
/* 3458 */           return Boolean.TRUE;
/*      */         }
/* 3460 */         return null;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public void set(Request request, String name, Object value) {}
/* 3467 */     });
/* 3468 */     specialAttributes.put("org.apache.catalina.parameter_parse_failed_reason", new SpecialAttributeAdapter()
/*      */     {
/*      */       public Object get(Request request, String name)
/*      */       {
/* 3472 */         return request.getCoyoteRequest().getParameters().getParseFailedReason();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public void set(Request request, String name, Object value) {}
/* 3479 */     });
/* 3480 */     specialAttributes.put("org.apache.tomcat.sendfile.support", new SpecialAttributeAdapter()
/*      */     {
/*      */       public Object get(Request request, String name)
/*      */       {
/* 3484 */         return Boolean.valueOf((request.getConnector().getProtocolHandler().isSendfileSupported()) && (request.getCoyoteRequest().getSendfile()));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public void set(Request request, String name, Object value) {}
/*      */     });
/*      */     
/*      */ 
/* 3494 */     for (SimpleDateFormat sdf : formatsTemplate) {
/* 3495 */       sdf.setTimeZone(GMT_ZONE);
/*      */     }
/*      */   }
/*      */   
/*      */   private static abstract interface SpecialAttributeAdapter
/*      */   {
/*      */     public abstract Object get(Request paramRequest, String paramString);
/*      */     
/*      */     public abstract void set(Request paramRequest, String paramString, Object paramObject);
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\connector\Request.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */