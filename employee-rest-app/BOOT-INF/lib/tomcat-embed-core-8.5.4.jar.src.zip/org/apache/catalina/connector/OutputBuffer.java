/*     */ package org.apache.catalina.connector;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.WriteListener;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.coyote.Response;
/*     */ import org.apache.tomcat.util.buf.B2CConverter;
/*     */ import org.apache.tomcat.util.buf.ByteChunk;
/*     */ import org.apache.tomcat.util.buf.ByteChunk.ByteOutputChannel;
/*     */ import org.apache.tomcat.util.buf.C2BConverter;
/*     */ import org.apache.tomcat.util.buf.CharChunk;
/*     */ import org.apache.tomcat.util.buf.CharChunk.CharOutputChannel;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OutputBuffer
/*     */   extends Writer
/*     */   implements ByteChunk.ByteOutputChannel, CharChunk.CharOutputChannel
/*     */ {
/*  51 */   private static final StringManager sm = StringManager.getManager(OutputBuffer.class);
/*     */   
/*     */ 
/*     */ 
/*     */   public static final int DEFAULT_BUFFER_SIZE = 8192;
/*     */   
/*     */ 
/*  58 */   private final Map<Charset, C2BConverter> encoders = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ByteChunk bb;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final CharChunk cb;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  78 */   private boolean initial = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  84 */   private long bytesWritten = 0L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */   private long charsWritten = 0L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */   private volatile boolean closed = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */   private boolean doFlush = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 108 */   private final ByteChunk outputChunk = new ByteChunk();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 114 */   private CharChunk outputCharChunk = new CharChunk();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String enc;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected C2BConverter conv;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Response coyoteResponse;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 138 */   private volatile boolean suspended = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OutputBuffer()
/*     */   {
/* 149 */     this(8192);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OutputBuffer(int size)
/*     */   {
/* 161 */     this.bb = new ByteChunk(size);
/* 162 */     this.bb.setLimit(size);
/* 163 */     this.bb.setByteOutputChannel(this);
/* 164 */     this.cb = new CharChunk(size);
/* 165 */     this.cb.setLimit(size);
/* 166 */     this.cb.setOptimizedWrite(false);
/* 167 */     this.cb.setCharOutputChannel(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResponse(Response coyoteResponse)
/*     */   {
/* 181 */     this.coyoteResponse = coyoteResponse;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSuspended()
/*     */   {
/* 191 */     return this.suspended;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSuspended(boolean suspended)
/*     */   {
/* 201 */     this.suspended = suspended;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isClosed()
/*     */   {
/* 211 */     return this.closed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void recycle()
/*     */   {
/* 222 */     this.initial = true;
/* 223 */     this.bytesWritten = 0L;
/* 224 */     this.charsWritten = 0L;
/*     */     
/* 226 */     this.bb.recycle();
/* 227 */     this.cb.recycle();
/* 228 */     this.outputCharChunk.setChars(null, 0, 0);
/* 229 */     this.closed = false;
/* 230 */     this.suspended = false;
/* 231 */     this.doFlush = false;
/*     */     
/* 233 */     if (this.conv != null) {
/* 234 */       this.conv.recycle();
/* 235 */       this.conv = null;
/*     */     }
/*     */     
/* 238 */     this.enc = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 252 */     if (this.closed) {
/* 253 */       return;
/*     */     }
/* 255 */     if (this.suspended) {
/* 256 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 261 */     if (this.cb.getLength() > 0) {
/* 262 */       this.cb.flushBuffer();
/*     */     }
/*     */     
/* 265 */     if ((!this.coyoteResponse.isCommitted()) && (this.coyoteResponse.getContentLengthLong() == -1L) && (!this.coyoteResponse.getRequest().method().equals("HEAD")))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 272 */       if (!this.coyoteResponse.isCommitted()) {
/* 273 */         this.coyoteResponse.setContentLength(this.bb.getLength());
/*     */       }
/*     */     }
/*     */     
/* 277 */     if (this.coyoteResponse.getStatus() == 101)
/*     */     {
/* 279 */       doFlush(true);
/*     */     } else {
/* 281 */       doFlush(false);
/*     */     }
/* 283 */     this.closed = true;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 288 */     Request req = (Request)this.coyoteResponse.getRequest().getNote(1);
/*     */     
/* 290 */     req.inputBuffer.close();
/*     */     
/* 292 */     this.coyoteResponse.action(ActionCode.CLOSE, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void flush()
/*     */     throws IOException
/*     */   {
/* 303 */     doFlush(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doFlush(boolean realFlush)
/*     */     throws IOException
/*     */   {
/* 315 */     if (this.suspended) {
/* 316 */       return;
/*     */     }
/*     */     try
/*     */     {
/* 320 */       this.doFlush = true;
/* 321 */       if (this.initial) {
/* 322 */         this.coyoteResponse.sendHeaders();
/* 323 */         this.initial = false;
/*     */       }
/* 325 */       if (this.cb.getLength() > 0) {
/* 326 */         this.cb.flushBuffer();
/*     */       }
/* 328 */       if (this.bb.getLength() > 0) {
/* 329 */         this.bb.flushBuffer();
/*     */       }
/*     */     } finally {
/* 332 */       this.doFlush = false;
/*     */     }
/*     */     
/* 335 */     if (realFlush) {
/* 336 */       this.coyoteResponse.action(ActionCode.CLIENT_FLUSH, null);
/*     */       
/*     */ 
/* 339 */       if (this.coyoteResponse.isExceptionPresent()) {
/* 340 */         throw new ClientAbortException(this.coyoteResponse.getErrorException());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void realWriteBytes(byte[] buf, int off, int cnt)
/*     */     throws IOException
/*     */   {
/* 363 */     if (this.closed) {
/* 364 */       return;
/*     */     }
/* 366 */     if (this.coyoteResponse == null) {
/* 367 */       return;
/*     */     }
/*     */     
/*     */ 
/* 371 */     if (cnt > 0)
/*     */     {
/* 373 */       this.outputChunk.setBytes(buf, off, cnt);
/*     */       try {
/* 375 */         this.coyoteResponse.doWrite(this.outputChunk);
/*     */ 
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 380 */         throw new ClientAbortException(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void write(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 389 */     if (this.suspended) {
/* 390 */       return;
/*     */     }
/*     */     
/* 393 */     writeBytes(b, off, len);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void writeBytes(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 401 */     if (this.closed) {
/* 402 */       return;
/*     */     }
/*     */     
/* 405 */     this.bb.append(b, off, len);
/* 406 */     this.bytesWritten += len;
/*     */     
/*     */ 
/*     */ 
/* 410 */     if (this.doFlush) {
/* 411 */       this.bb.flushBuffer();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void writeByte(int b)
/*     */     throws IOException
/*     */   {
/* 420 */     if (this.suspended) {
/* 421 */       return;
/*     */     }
/*     */     
/* 424 */     this.bb.append((byte)b);
/* 425 */     this.bytesWritten += 1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void realWriteChars(char[] buf, int off, int len)
/*     */     throws IOException
/*     */   {
/* 446 */     this.outputCharChunk.setChars(buf, off, len);
/* 447 */     while (this.outputCharChunk.getLength() > 0) {
/* 448 */       this.conv.convert(this.outputCharChunk, this.bb);
/* 449 */       if (this.bb.getLength() == 0) {
/*     */         break;
/*     */       }
/*     */       
/* 453 */       if (this.outputCharChunk.getLength() > 0) {
/* 454 */         if ((this.bb.getBuffer().length == this.bb.getEnd()) && (this.bb.getLength() < this.bb.getLimit()))
/*     */         {
/* 456 */           this.bb.makeSpace(this.outputCharChunk.getLength());
/*     */         } else {
/* 458 */           this.bb.flushBuffer();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void write(int c)
/*     */     throws IOException
/*     */   {
/* 469 */     if (this.suspended) {
/* 470 */       return;
/*     */     }
/*     */     
/* 473 */     this.cb.append((char)c);
/* 474 */     this.charsWritten += 1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(char[] c)
/*     */     throws IOException
/*     */   {
/* 483 */     if (this.suspended) {
/* 484 */       return;
/*     */     }
/*     */     
/* 487 */     write(c, 0, c.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(char[] c, int off, int len)
/*     */     throws IOException
/*     */   {
/* 496 */     if (this.suspended) {
/* 497 */       return;
/*     */     }
/*     */     
/* 500 */     this.cb.append(c, off, len);
/* 501 */     this.charsWritten += len;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(String s, int off, int len)
/*     */     throws IOException
/*     */   {
/* 513 */     if (this.suspended) {
/* 514 */       return;
/*     */     }
/*     */     
/* 517 */     if (s == null) {
/* 518 */       throw new NullPointerException(sm.getString("outputBuffer.writeNull"));
/*     */     }
/* 520 */     this.cb.append(s, off, len);
/* 521 */     this.charsWritten += len;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void write(String s)
/*     */     throws IOException
/*     */   {
/* 529 */     if (this.suspended) {
/* 530 */       return;
/*     */     }
/*     */     
/* 533 */     if (s == null) {
/* 534 */       s = "null";
/*     */     }
/* 536 */     this.cb.append(s);
/* 537 */     this.charsWritten += s.length();
/*     */   }
/*     */   
/*     */   public void setEncoding(String s)
/*     */   {
/* 542 */     this.enc = s;
/*     */   }
/*     */   
/*     */   public void checkConverter() throws IOException
/*     */   {
/* 547 */     if (this.conv == null) {
/* 548 */       setConverter();
/*     */     }
/*     */   }
/*     */   
/*     */   private void setConverter()
/*     */     throws IOException
/*     */   {
/* 555 */     if (this.coyoteResponse != null) {
/* 556 */       this.enc = this.coyoteResponse.getCharacterEncoding();
/*     */     }
/*     */     
/* 559 */     if (this.enc == null) {
/* 560 */       this.enc = "ISO-8859-1";
/*     */     }
/*     */     
/* 563 */     Charset charset = getCharset(this.enc);
/* 564 */     this.conv = ((C2BConverter)this.encoders.get(charset));
/*     */     
/* 566 */     if (this.conv == null) {
/* 567 */       this.conv = createConverter(charset);
/* 568 */       this.encoders.put(charset, this.conv);
/*     */     }
/*     */   }
/*     */   
/*     */   private static Charset getCharset(String encoding) throws IOException
/*     */   {
/* 574 */     if (Globals.IS_SECURITY_ENABLED) {
/*     */       try {
/* 576 */         (Charset)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */         {
/*     */           public Charset run() throws IOException
/*     */           {
/* 580 */             return B2CConverter.getCharset(this.val$encoding);
/*     */           }
/*     */         });
/*     */       } catch (PrivilegedActionException ex) {
/* 584 */         Exception e = ex.getException();
/* 585 */         if ((e instanceof IOException)) {
/* 586 */           throw ((IOException)e);
/*     */         }
/* 588 */         throw new IOException(ex);
/*     */       }
/*     */     }
/*     */     
/* 592 */     return B2CConverter.getCharset(encoding);
/*     */   }
/*     */   
/*     */   private static C2BConverter createConverter(Charset charset)
/*     */     throws IOException
/*     */   {
/* 598 */     if (Globals.IS_SECURITY_ENABLED) {
/*     */       try {
/* 600 */         (C2BConverter)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */         {
/*     */           public C2BConverter run() throws IOException
/*     */           {
/* 604 */             return new C2BConverter(this.val$charset);
/*     */           }
/*     */         });
/*     */       }
/*     */       catch (PrivilegedActionException ex) {
/* 609 */         Exception e = ex.getException();
/* 610 */         if ((e instanceof IOException)) {
/* 611 */           throw ((IOException)e);
/*     */         }
/* 613 */         throw new IOException(ex);
/*     */       }
/*     */     }
/*     */     
/* 617 */     return new C2BConverter(charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getContentWritten()
/*     */   {
/* 625 */     return this.bytesWritten + this.charsWritten;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNew()
/*     */   {
/* 635 */     return (this.bytesWritten == 0L) && (this.charsWritten == 0L);
/*     */   }
/*     */   
/*     */   public void setBufferSize(int size)
/*     */   {
/* 640 */     if (size > this.bb.getLimit()) {
/* 641 */       this.bb.setLimit(size);
/*     */     }
/*     */   }
/*     */   
/*     */   public void reset()
/*     */   {
/* 647 */     reset(false);
/*     */   }
/*     */   
/*     */   public void reset(boolean resetWriterStreamFlags) {
/* 651 */     this.bb.recycle();
/* 652 */     this.cb.recycle();
/* 653 */     this.bytesWritten = 0L;
/* 654 */     this.charsWritten = 0L;
/* 655 */     if (resetWriterStreamFlags) {
/* 656 */       if (this.conv != null) {
/* 657 */         this.conv.recycle();
/*     */       }
/* 659 */       this.conv = null;
/* 660 */       this.enc = null;
/*     */     }
/* 662 */     this.initial = true;
/*     */   }
/*     */   
/*     */   public int getBufferSize()
/*     */   {
/* 667 */     return this.bb.getLimit();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isReady()
/*     */   {
/* 677 */     return this.coyoteResponse.isReady();
/*     */   }
/*     */   
/*     */   public void setWriteListener(WriteListener listener)
/*     */   {
/* 682 */     this.coyoteResponse.setWriteListener(listener);
/*     */   }
/*     */   
/*     */   public boolean isBlocking()
/*     */   {
/* 687 */     return this.coyoteResponse.getWriteListener() == null;
/*     */   }
/*     */   
/*     */   public void checkRegisterForWrite() {
/* 691 */     this.coyoteResponse.checkRegisterForWrite();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\connector\OutputBuffer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */