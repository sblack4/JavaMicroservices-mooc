/*      */ package org.apache.catalina.servlets;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.RandomAccessFile;
/*      */ import java.io.Reader;
/*      */ import java.io.Serializable;
/*      */ import java.io.StringReader;
/*      */ import java.io.StringWriter;
/*      */ import java.security.AccessController;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.StringTokenizer;
/*      */ import javax.servlet.DispatcherType;
/*      */ import javax.servlet.ServletConfig;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletOutputStream;
/*      */ import javax.servlet.ServletResponse;
/*      */ import javax.servlet.ServletResponseWrapper;
/*      */ import javax.servlet.UnavailableException;
/*      */ import javax.servlet.http.HttpServlet;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import javax.xml.parsers.DocumentBuilder;
/*      */ import javax.xml.parsers.DocumentBuilderFactory;
/*      */ import javax.xml.parsers.ParserConfigurationException;
/*      */ import javax.xml.transform.Source;
/*      */ import javax.xml.transform.Transformer;
/*      */ import javax.xml.transform.TransformerException;
/*      */ import javax.xml.transform.TransformerFactory;
/*      */ import javax.xml.transform.dom.DOMSource;
/*      */ import javax.xml.transform.stream.StreamResult;
/*      */ import javax.xml.transform.stream.StreamSource;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.WebResource;
/*      */ import org.apache.catalina.WebResourceRoot;
/*      */ import org.apache.catalina.connector.RequestFacade;
/*      */ import org.apache.catalina.connector.ResponseFacade;
/*      */ import org.apache.catalina.util.RequestUtil;
/*      */ import org.apache.catalina.util.ServerInfo;
/*      */ import org.apache.catalina.util.URLEncoder;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.util.security.PrivilegedGetTccl;
/*      */ import org.apache.tomcat.util.security.PrivilegedSetTccl;
/*      */ import org.w3c.dom.Document;
/*      */ import org.xml.sax.InputSource;
/*      */ import org.xml.sax.SAXException;
/*      */ import org.xml.sax.ext.EntityResolver2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DefaultServlet
/*      */   extends HttpServlet
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*  133 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.servlets");
/*      */   
/*      */ 
/*      */   private static final DocumentBuilderFactory factory;
/*      */   
/*      */ 
/*      */   private static final SecureEntityResolver secureEntityResolver;
/*      */   
/*      */ 
/*  142 */   protected static final ArrayList<Range> FULL = new ArrayList();
/*      */   protected static final String mimeSeparation = "CATALINA_MIME_BOUNDARY";
/*      */   @Deprecated
/*      */   protected static final String RESOURCES_JNDI_NAME = "java:/comp/Resources";
/*      */   protected static final int BUFFER_SIZE = 4096;
/*      */   protected int debug;
/*      */   protected int input;
/*      */   protected boolean listings;
/*      */   protected boolean readOnly;
/*      */   protected CompressionFormat[] compressionFormats;
/*      */   protected int output;
/*      */   protected String localXsltFile;
/*      */   protected String contextXsltFile;
/*      */   protected String globalXsltFile;
/*      */   protected String readmeFile;
/*      */   protected transient WebResourceRoot resources;
/*      */   protected String fileEncoding;
/*      */   protected int sendfileSize;
/*      */   protected boolean useAcceptRanges;
/*      */   protected boolean showServerInfo;
/*      */   
/*      */   static
/*      */   {
/*  165 */     if (Globals.IS_SECURITY_ENABLED) {
/*  166 */       factory = DocumentBuilderFactory.newInstance();
/*  167 */       factory.setNamespaceAware(true);
/*  168 */       factory.setValidating(false);
/*  169 */       secureEntityResolver = new SecureEntityResolver(null);
/*      */     } else {
/*  171 */       factory = null;
/*  172 */       secureEntityResolver = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DefaultServlet()
/*      */   {
/*  182 */     this.debug = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  187 */     this.input = 2048;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  192 */     this.listings = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  197 */     this.readOnly = true;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  207 */     this.output = 2048;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  212 */     this.localXsltFile = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  217 */     this.contextXsltFile = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  222 */     this.globalXsltFile = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  227 */     this.readmeFile = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  232 */     this.resources = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  238 */     this.fileEncoding = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  243 */     this.sendfileSize = 49152;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  248 */     this.useAcceptRanges = true;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  253 */     this.showServerInfo = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void init()
/*      */     throws ServletException
/*      */   {
/*  273 */     if (getServletConfig().getInitParameter("debug") != null) {
/*  274 */       this.debug = Integer.parseInt(getServletConfig().getInitParameter("debug"));
/*      */     }
/*  276 */     if (getServletConfig().getInitParameter("input") != null) {
/*  277 */       this.input = Integer.parseInt(getServletConfig().getInitParameter("input"));
/*      */     }
/*  279 */     if (getServletConfig().getInitParameter("output") != null) {
/*  280 */       this.output = Integer.parseInt(getServletConfig().getInitParameter("output"));
/*      */     }
/*  282 */     this.listings = Boolean.parseBoolean(getServletConfig().getInitParameter("listings"));
/*      */     
/*  284 */     if (getServletConfig().getInitParameter("readonly") != null) {
/*  285 */       this.readOnly = Boolean.parseBoolean(getServletConfig().getInitParameter("readonly"));
/*      */     }
/*  287 */     this.compressionFormats = parseCompressionFormats(getServletConfig().getInitParameter("precompressed"), getServletConfig().getInitParameter("gzip"));
/*      */     
/*      */ 
/*      */ 
/*  291 */     if (getServletConfig().getInitParameter("sendfileSize") != null) {
/*  292 */       this.sendfileSize = (Integer.parseInt(getServletConfig().getInitParameter("sendfileSize")) * 1024);
/*      */     }
/*      */     
/*  295 */     this.fileEncoding = getServletConfig().getInitParameter("fileEncoding");
/*      */     
/*  297 */     this.globalXsltFile = getServletConfig().getInitParameter("globalXsltFile");
/*  298 */     this.contextXsltFile = getServletConfig().getInitParameter("contextXsltFile");
/*  299 */     this.localXsltFile = getServletConfig().getInitParameter("localXsltFile");
/*  300 */     this.readmeFile = getServletConfig().getInitParameter("readmeFile");
/*      */     
/*  302 */     if (getServletConfig().getInitParameter("useAcceptRanges") != null) {
/*  303 */       this.useAcceptRanges = Boolean.parseBoolean(getServletConfig().getInitParameter("useAcceptRanges"));
/*      */     }
/*      */     
/*  306 */     if (this.input < 256)
/*  307 */       this.input = 256;
/*  308 */     if (this.output < 256) {
/*  309 */       this.output = 256;
/*      */     }
/*  311 */     if (this.debug > 0) {
/*  312 */       log("DefaultServlet.init:  input buffer size=" + this.input + ", output buffer size=" + this.output);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  317 */     this.resources = ((WebResourceRoot)getServletContext().getAttribute("org.apache.catalina.resources"));
/*      */     
/*      */ 
/*  320 */     if (this.resources == null) {
/*  321 */       throw new UnavailableException("No resources");
/*      */     }
/*      */     
/*  324 */     if (getServletConfig().getInitParameter("showServerInfo") != null) {
/*  325 */       this.showServerInfo = Boolean.parseBoolean(getServletConfig().getInitParameter("showServerInfo"));
/*      */     }
/*      */   }
/*      */   
/*      */   private CompressionFormat[] parseCompressionFormats(String precompressed, String gzip) {
/*  330 */     List<CompressionFormat> ret = new ArrayList();
/*  331 */     if ((precompressed != null) && (precompressed.indexOf('=') > 0)) {
/*  332 */       for (String pair : precompressed.split(",")) {
/*  333 */         String[] setting = pair.split("=");
/*  334 */         String encoding = setting[0];
/*  335 */         String extension = setting[1];
/*  336 */         ret.add(new CompressionFormat(extension, encoding));
/*      */       }
/*  338 */     } else if (precompressed != null) {
/*  339 */       if (Boolean.parseBoolean(precompressed)) {
/*  340 */         ret.add(new CompressionFormat(".br", "br"));
/*  341 */         ret.add(new CompressionFormat(".gz", "gzip"));
/*      */       }
/*  343 */     } else if (Boolean.parseBoolean(gzip))
/*      */     {
/*  345 */       ret.add(new CompressionFormat(".gz", "gzip"));
/*      */     }
/*  347 */     return (CompressionFormat[])ret.toArray(new CompressionFormat[ret.size()]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getRelativePath(HttpServletRequest request)
/*      */   {
/*  361 */     return getRelativePath(request, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected String getRelativePath(HttpServletRequest request, boolean allowEmptyPath)
/*      */   {
/*      */     String servletPath;
/*      */     
/*      */     String pathInfo;
/*      */     
/*      */     String servletPath;
/*      */     
/*  374 */     if (request.getAttribute("javax.servlet.include.request_uri") != null)
/*      */     {
/*  376 */       String pathInfo = (String)request.getAttribute("javax.servlet.include.path_info");
/*  377 */       servletPath = (String)request.getAttribute("javax.servlet.include.servlet_path");
/*      */     } else {
/*  379 */       pathInfo = request.getPathInfo();
/*  380 */       servletPath = request.getServletPath();
/*      */     }
/*      */     
/*  383 */     StringBuilder result = new StringBuilder();
/*  384 */     if (servletPath.length() > 0) {
/*  385 */       result.append(servletPath);
/*      */     }
/*  387 */     if (pathInfo != null) {
/*  388 */       result.append(pathInfo);
/*      */     }
/*  390 */     if ((result.length() == 0) && (!allowEmptyPath)) {
/*  391 */       result.append('/');
/*      */     }
/*      */     
/*  394 */     return result.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getPathPrefix(HttpServletRequest request)
/*      */   {
/*  406 */     return request.getContextPath();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doGet(HttpServletRequest request, HttpServletResponse response)
/*      */     throws IOException, ServletException
/*      */   {
/*  425 */     serveResource(request, response, true, this.fileEncoding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doHead(HttpServletRequest request, HttpServletResponse response)
/*      */     throws IOException, ServletException
/*      */   {
/*  445 */     boolean serveContent = DispatcherType.INCLUDE.equals(request.getDispatcherType());
/*  446 */     serveResource(request, response, serveContent, this.fileEncoding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doOptions(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  473 */     StringBuilder allow = new StringBuilder();
/*      */     
/*  475 */     allow.append("GET, HEAD");
/*      */     
/*  477 */     allow.append(", POST");
/*      */     
/*  479 */     allow.append(", PUT");
/*      */     
/*  481 */     allow.append(", DELETE");
/*      */     
/*  483 */     if (((req instanceof RequestFacade)) && (((RequestFacade)req).getAllowTrace()))
/*      */     {
/*  485 */       allow.append(", TRACE");
/*      */     }
/*      */     
/*  488 */     allow.append(", OPTIONS");
/*      */     
/*  490 */     resp.setHeader("Allow", allow.toString());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doPost(HttpServletRequest request, HttpServletResponse response)
/*      */     throws IOException, ServletException
/*      */   {
/*  507 */     doGet(request, response);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doPut(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  524 */     if (this.readOnly) {
/*  525 */       resp.sendError(403);
/*  526 */       return;
/*      */     }
/*      */     
/*  529 */     String path = getRelativePath(req);
/*      */     
/*  531 */     WebResource resource = this.resources.getResource(path);
/*      */     
/*  533 */     Range range = parseContentRange(req, resp);
/*      */     
/*  535 */     InputStream resourceInputStream = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  542 */       if (range != null) {
/*  543 */         File contentFile = executePartialPut(req, range, path);
/*  544 */         resourceInputStream = new FileInputStream(contentFile);
/*      */       } else {
/*  546 */         resourceInputStream = req.getInputStream();
/*      */       }
/*      */       
/*  549 */       if (this.resources.write(path, resourceInputStream, true)) {
/*  550 */         if (resource.exists()) {
/*  551 */           resp.setStatus(204);
/*      */         } else {
/*  553 */           resp.setStatus(201);
/*      */         }
/*      */       } else
/*  556 */         resp.sendError(409);
/*      */       return;
/*      */     } finally {
/*  559 */       if (resourceInputStream != null) {
/*      */         try {
/*  561 */           resourceInputStream.close();
/*      */         }
/*      */         catch (IOException localIOException1) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected File executePartialPut(HttpServletRequest req, Range range, String path)
/*      */     throws IOException
/*      */   {
/*  587 */     File tempDir = (File)getServletContext().getAttribute("javax.servlet.context.tempdir");
/*      */     
/*      */ 
/*  590 */     String convertedResourcePath = path.replace('/', '.');
/*  591 */     File contentFile = new File(tempDir, convertedResourcePath);
/*  592 */     if (contentFile.createNewFile())
/*      */     {
/*  594 */       contentFile.deleteOnExit();
/*      */     }
/*      */     
/*  597 */     RandomAccessFile randAccessContentFile = new RandomAccessFile(contentFile, "rw");Throwable localThrowable4 = null;
/*      */     try
/*      */     {
/*  600 */       WebResource oldResource = this.resources.getResource(path);
/*      */       
/*      */ 
/*  603 */       if (oldResource.isFile()) {
/*  604 */         BufferedInputStream bufOldRevStream = new BufferedInputStream(oldResource.getInputStream(), 4096);Throwable localThrowable5 = null;
/*      */         
/*      */ 
/*      */         try
/*      */         {
/*  609 */           copyBuffer = new byte['က'];
/*  610 */           int numBytesRead; while ((numBytesRead = bufOldRevStream.read(copyBuffer)) != -1) {
/*  611 */             randAccessContentFile.write(copyBuffer, 0, numBytesRead);
/*      */           }
/*      */         }
/*      */         catch (Throwable localThrowable1)
/*      */         {
/*  604 */           localThrowable5 = localThrowable1;throw localThrowable1;
/*      */         }
/*      */         finally {}
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  617 */       randAccessContentFile.setLength(range.length);
/*      */       
/*      */ 
/*  620 */       randAccessContentFile.seek(range.start);
/*      */       
/*  622 */       byte[] transferBuffer = new byte['က'];
/*  623 */       BufferedInputStream requestBufInStream = new BufferedInputStream(req.getInputStream(), 4096);byte[] copyBuffer = null;
/*      */       try { int numBytesRead;
/*  625 */         while ((numBytesRead = requestBufInStream.read(transferBuffer)) != -1) {
/*  626 */           randAccessContentFile.write(transferBuffer, 0, numBytesRead);
/*      */         }
/*      */       }
/*      */       catch (Throwable localThrowable6)
/*      */       {
/*  623 */         copyBuffer = localThrowable6;throw localThrowable6;
/*      */       }
/*      */       finally {}
/*      */     }
/*      */     catch (Throwable localThrowable3)
/*      */     {
/*  597 */       localThrowable4 = localThrowable3;throw localThrowable3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  629 */       if (randAccessContentFile != null) if (localThrowable4 != null) try { randAccessContentFile.close(); } catch (Throwable x2) { localThrowable4.addSuppressed(x2); } else randAccessContentFile.close();
/*      */     }
/*  631 */     return contentFile;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doDelete(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  648 */     if (this.readOnly) {
/*  649 */       resp.sendError(403);
/*  650 */       return;
/*      */     }
/*      */     
/*  653 */     String path = getRelativePath(req);
/*      */     
/*  655 */     WebResource resource = this.resources.getResource(path);
/*      */     
/*  657 */     if (resource.exists()) {
/*  658 */       if (resource.delete()) {
/*  659 */         resp.setStatus(204);
/*      */       } else {
/*  661 */         resp.sendError(405);
/*      */       }
/*      */     } else {
/*  664 */       resp.sendError(404);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean checkIfHeaders(HttpServletRequest request, HttpServletResponse response, WebResource resource)
/*      */     throws IOException
/*      */   {
/*  687 */     return (checkIfMatch(request, response, resource)) && (checkIfModifiedSince(request, response, resource)) && (checkIfNoneMatch(request, response, resource)) && (checkIfUnmodifiedSince(request, response, resource));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String rewriteUrl(String path)
/*      */   {
/*  702 */     return URLEncoder.DEFAULT.encode(path);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void serveResource(HttpServletRequest request, HttpServletResponse response, boolean content, String encoding)
/*      */     throws IOException, ServletException
/*      */   {
/*  724 */     boolean serveContent = content;
/*      */     
/*      */ 
/*  727 */     String path = getRelativePath(request, true);
/*      */     
/*  729 */     if (this.debug > 0) {
/*  730 */       if (serveContent) {
/*  731 */         log("DefaultServlet.serveResource:  Serving resource '" + path + "' headers and data");
/*      */       }
/*      */       else {
/*  734 */         log("DefaultServlet.serveResource:  Serving resource '" + path + "' headers only");
/*      */       }
/*      */     }
/*      */     
/*  738 */     if (path.length() == 0)
/*      */     {
/*  740 */       doDirectoryRedirect(request, response);
/*  741 */       return;
/*      */     }
/*      */     
/*  744 */     WebResource resource = this.resources.getResource(path);
/*      */     
/*  746 */     if (!resource.exists())
/*      */     {
/*      */ 
/*  749 */       String requestUri = (String)request.getAttribute("javax.servlet.include.request_uri");
/*      */       
/*  751 */       if (requestUri == null) {
/*  752 */         requestUri = request.getRequestURI();
/*      */       }
/*      */       else
/*      */       {
/*  756 */         throw new FileNotFoundException(sm.getString("defaultServlet.missingResource", new Object[] { requestUri }));
/*      */       }
/*      */       
/*      */ 
/*  760 */       response.sendError(404, requestUri);
/*  761 */       return;
/*      */     }
/*      */     
/*  764 */     if (!resource.canRead())
/*      */     {
/*      */ 
/*  767 */       String requestUri = (String)request.getAttribute("javax.servlet.include.request_uri");
/*      */       
/*  769 */       if (requestUri == null) {
/*  770 */         requestUri = request.getRequestURI();
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  775 */         throw new FileNotFoundException(sm.getString("defaultServlet.missingResource", new Object[] { requestUri }));
/*      */       }
/*      */       
/*      */ 
/*  779 */       response.sendError(403, requestUri);
/*  780 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  785 */     if ((resource.isFile()) && ((path.endsWith("/")) || (path.endsWith("\\"))))
/*      */     {
/*      */ 
/*  788 */       String requestUri = (String)request.getAttribute("javax.servlet.include.request_uri");
/*      */       
/*  790 */       if (requestUri == null) {
/*  791 */         requestUri = request.getRequestURI();
/*      */       }
/*  793 */       response.sendError(404, requestUri);
/*  794 */       return;
/*      */     }
/*      */     
/*  797 */     boolean isError = response.getStatus() >= 400;
/*      */     
/*  799 */     boolean included = false;
/*      */     
/*      */ 
/*  802 */     if (resource.isFile())
/*      */     {
/*  804 */       included = request.getAttribute("javax.servlet.include.context_path") != null;
/*      */       
/*  806 */       if ((!included) && (!isError) && (!checkIfHeaders(request, response, resource))) {
/*  807 */         return;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  812 */     String contentType = resource.getMimeType();
/*  813 */     if (contentType == null) {
/*  814 */       contentType = getServletContext().getMimeType(resource.getName());
/*  815 */       resource.setMimeType(contentType);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  821 */     String eTag = null;
/*  822 */     String lastModifiedHttp = null;
/*  823 */     if ((resource.isFile()) && (!isError)) {
/*  824 */       eTag = resource.getETag();
/*  825 */       lastModifiedHttp = resource.getLastModifiedHttp();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  830 */     boolean usingPrecompressedVersion = false;
/*  831 */     if ((this.compressionFormats.length > 0) && (!included) && (resource.isFile()) && (!pathEndsWithCompressedExtension(path)))
/*      */     {
/*  833 */       List<PrecompressedResource> precompressedResources = getAvailablePrecompressedResources(path);
/*      */       
/*  835 */       if (!precompressedResources.isEmpty()) {
/*  836 */         Collection<String> varyHeaders = response.getHeaders("Vary");
/*  837 */         boolean addRequired = true;
/*  838 */         for (String varyHeader : varyHeaders) {
/*  839 */           if (("*".equals(varyHeader)) || ("accept-encoding".equalsIgnoreCase(varyHeader)))
/*      */           {
/*  841 */             addRequired = false;
/*  842 */             break;
/*      */           }
/*      */         }
/*  845 */         if (addRequired) {
/*  846 */           response.addHeader("Vary", "accept-encoding");
/*      */         }
/*  848 */         PrecompressedResource bestResource = getBestPrecompressedResource(request, precompressedResources);
/*      */         
/*  850 */         if (bestResource != null) {
/*  851 */           response.addHeader("Content-Encoding", bestResource.format.encoding);
/*  852 */           resource = bestResource.resource;
/*  853 */           usingPrecompressedVersion = true;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  858 */     ArrayList<Range> ranges = null;
/*  859 */     long contentLength = -1L;
/*      */     
/*  861 */     if (resource.isDirectory()) {
/*  862 */       if (!path.endsWith("/")) {
/*  863 */         doDirectoryRedirect(request, response);
/*  864 */         return;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  869 */       if (!this.listings) {
/*  870 */         response.sendError(404, request.getRequestURI());
/*      */         
/*  872 */         return;
/*      */       }
/*  874 */       contentType = "text/html;charset=UTF-8";
/*      */     } else {
/*  876 */       if (!isError) {
/*  877 */         if (this.useAcceptRanges)
/*      */         {
/*  879 */           response.setHeader("Accept-Ranges", "bytes");
/*      */         }
/*      */         
/*      */ 
/*  883 */         ranges = parseRange(request, response, resource);
/*      */         
/*      */ 
/*  886 */         response.setHeader("ETag", eTag);
/*      */         
/*      */ 
/*  889 */         response.setHeader("Last-Modified", lastModifiedHttp);
/*      */       }
/*      */       
/*      */ 
/*  893 */       contentLength = resource.getContentLength();
/*      */       
/*      */ 
/*  896 */       if (contentLength == 0L) {
/*  897 */         serveContent = false;
/*      */       }
/*      */     }
/*      */     
/*  901 */     ServletOutputStream ostream = null;
/*  902 */     PrintWriter writer = null;
/*      */     
/*  904 */     if (serveContent) {
/*      */       try
/*      */       {
/*  907 */         ostream = response.getOutputStream();
/*      */       }
/*      */       catch (IllegalStateException e)
/*      */       {
/*  911 */         if ((!usingPrecompressedVersion) && ((contentType == null) || (contentType.startsWith("text")) || (contentType.endsWith("xml")) || (contentType.contains("/javascript"))))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  917 */           writer = response.getWriter();
/*      */           
/*  919 */           ranges = FULL;
/*      */         } else {
/*  921 */           throw e;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  929 */     ServletResponse r = response;
/*  930 */     long contentWritten = 0L;
/*  931 */     while ((r instanceof ServletResponseWrapper)) {
/*  932 */       r = ((ServletResponseWrapper)r).getResponse();
/*      */     }
/*  934 */     if ((r instanceof ResponseFacade)) {
/*  935 */       contentWritten = ((ResponseFacade)r).getContentWritten();
/*      */     }
/*  937 */     if (contentWritten > 0L) {
/*  938 */       ranges = FULL;
/*      */     }
/*      */     
/*  941 */     if ((resource.isDirectory()) || (isError) || (((ranges != null) && (!ranges.isEmpty())) || ((request.getHeader("Range") == null) || (ranges == FULL))))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  948 */       if (contentType != null) {
/*  949 */         if (this.debug > 0) {
/*  950 */           log("DefaultServlet.serveFile:  contentType='" + contentType + "'");
/*      */         }
/*  952 */         response.setContentType(contentType);
/*      */       }
/*  954 */       if ((resource.isFile()) && (contentLength >= 0L) && ((!serveContent) || (ostream != null)))
/*      */       {
/*  956 */         if (this.debug > 0) {
/*  957 */           log("DefaultServlet.serveFile:  contentLength=" + contentLength);
/*      */         }
/*      */         
/*      */ 
/*  961 */         if (contentWritten == 0L) {
/*  962 */           response.setContentLengthLong(contentLength);
/*      */         }
/*      */       }
/*      */       
/*  966 */       if (serveContent) {
/*      */         try {
/*  968 */           response.setBufferSize(this.output);
/*      */         }
/*      */         catch (IllegalStateException localIllegalStateException1) {}
/*      */         
/*  972 */         InputStream renderResult = null;
/*  973 */         if (ostream == null)
/*      */         {
/*      */ 
/*  976 */           if (resource.isDirectory()) {
/*  977 */             renderResult = render(getPathPrefix(request), resource, encoding);
/*      */           } else {
/*  979 */             renderResult = resource.getInputStream();
/*      */           }
/*  981 */           copy(resource, renderResult, writer, encoding);
/*      */         }
/*      */         else {
/*  984 */           if (resource.isDirectory()) {
/*  985 */             renderResult = render(getPathPrefix(request), resource, encoding);
/*      */ 
/*      */           }
/*  988 */           else if (!checkSendfile(request, response, resource, contentLength, null))
/*      */           {
/*      */ 
/*      */ 
/*  992 */             byte[] resourceBody = resource.getContent();
/*  993 */             if (resourceBody == null)
/*      */             {
/*      */ 
/*  996 */               renderResult = resource.getInputStream();
/*      */             }
/*      */             else {
/*  999 */               ostream.write(resourceBody);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1005 */           if (renderResult != null) {
/* 1006 */             copy(resource, renderResult, ostream);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1013 */       if ((ranges == null) || (ranges.isEmpty())) {
/* 1014 */         return;
/*      */       }
/*      */       
/*      */ 
/* 1018 */       response.setStatus(206);
/*      */       
/* 1020 */       if (ranges.size() == 1)
/*      */       {
/* 1022 */         Range range = (Range)ranges.get(0);
/* 1023 */         response.addHeader("Content-Range", "bytes " + range.start + "-" + range.end + "/" + range.length);
/*      */         
/*      */ 
/*      */ 
/* 1027 */         long length = range.end - range.start + 1L;
/* 1028 */         response.setContentLengthLong(length);
/*      */         
/* 1030 */         if (contentType != null) {
/* 1031 */           if (this.debug > 0) {
/* 1032 */             log("DefaultServlet.serveFile:  contentType='" + contentType + "'");
/*      */           }
/* 1034 */           response.setContentType(contentType);
/*      */         }
/*      */         
/* 1037 */         if (serveContent) {
/*      */           try {
/* 1039 */             response.setBufferSize(this.output);
/*      */           }
/*      */           catch (IllegalStateException localIllegalStateException2) {}
/*      */           
/* 1043 */           if (ostream != null) {
/* 1044 */             if (!checkSendfile(request, response, resource, range.end - range.start + 1L, range))
/*      */             {
/* 1046 */               copy(resource, ostream, range);
/*      */             }
/*      */           } else {
/* 1049 */             throw new IllegalStateException();
/*      */           }
/*      */         }
/*      */       } else {
/* 1053 */         response.setContentType("multipart/byteranges; boundary=CATALINA_MIME_BOUNDARY");
/*      */         
/* 1055 */         if (serveContent) {
/*      */           try {
/* 1057 */             response.setBufferSize(this.output);
/*      */           }
/*      */           catch (IllegalStateException localIllegalStateException3) {}
/*      */           
/* 1061 */           if (ostream != null) {
/* 1062 */             copy(resource, ostream, ranges.iterator(), contentType);
/*      */           }
/*      */           else {
/* 1065 */             throw new IllegalStateException();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean pathEndsWithCompressedExtension(String path) {
/* 1073 */     for (CompressionFormat format : this.compressionFormats) {
/* 1074 */       if (path.endsWith(format.extension)) {
/* 1075 */         return true;
/*      */       }
/*      */     }
/* 1078 */     return false;
/*      */   }
/*      */   
/*      */   private List<PrecompressedResource> getAvailablePrecompressedResources(String path) {
/* 1082 */     List<PrecompressedResource> ret = new ArrayList(this.compressionFormats.length);
/* 1083 */     for (CompressionFormat format : this.compressionFormats) {
/* 1084 */       WebResource precompressedResource = this.resources.getResource(path + format.extension);
/* 1085 */       if ((precompressedResource.exists()) && (precompressedResource.isFile())) {
/* 1086 */         ret.add(new PrecompressedResource(precompressedResource, format, null));
/*      */       }
/*      */     }
/* 1089 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private PrecompressedResource getBestPrecompressedResource(HttpServletRequest request, List<PrecompressedResource> precompressedResources)
/*      */   {
/* 1101 */     Enumeration<String> headers = request.getHeaders("Accept-Encoding");
/* 1102 */     PrecompressedResource bestResource = null;
/* 1103 */     double bestResourceQuality = 0.0D;
/* 1104 */     int bestResourcePreference = Integer.MAX_VALUE;
/* 1105 */     while (headers.hasMoreElements()) {
/* 1106 */       String header = (String)headers.nextElement();
/* 1107 */       for (String preference : header.split(",")) {
/* 1108 */         double quality = 1.0D;
/* 1109 */         int qualityIdx = preference.indexOf(';');
/* 1110 */         if (qualityIdx > 0) {
/* 1111 */           int equalsIdx = preference.indexOf('=', qualityIdx + 1);
/* 1112 */           if (equalsIdx != -1)
/*      */           {
/*      */ 
/* 1115 */             quality = Double.parseDouble(preference.substring(equalsIdx + 1).trim());
/*      */           }
/* 1117 */         } else if (quality >= bestResourceQuality) {
/* 1118 */           String encoding = preference;
/* 1119 */           if (qualityIdx > 0) {
/* 1120 */             encoding = encoding.substring(0, qualityIdx);
/*      */           }
/* 1122 */           encoding = encoding.trim();
/* 1123 */           if ("identity".equals(encoding)) {
/* 1124 */             bestResource = null;
/* 1125 */             bestResourceQuality = quality;
/* 1126 */             bestResourcePreference = Integer.MAX_VALUE;
/*      */ 
/*      */           }
/* 1129 */           else if ("*".equals(encoding)) {
/* 1130 */             bestResource = (PrecompressedResource)precompressedResources.get(0);
/* 1131 */             bestResourceQuality = quality;
/* 1132 */             bestResourcePreference = 0;
/*      */           }
/*      */           else {
/* 1135 */             for (int i = 0; i < precompressedResources.size(); i++) {
/* 1136 */               PrecompressedResource resource = (PrecompressedResource)precompressedResources.get(i);
/* 1137 */               if (encoding.equals(resource.format.encoding)) {
/* 1138 */                 if ((quality <= bestResourceQuality) && (i >= bestResourcePreference)) break;
/* 1139 */                 bestResource = resource;
/* 1140 */                 bestResourceQuality = quality;
/* 1141 */                 bestResourcePreference = i; break;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1149 */     return bestResource;
/*      */   }
/*      */   
/*      */   private void doDirectoryRedirect(HttpServletRequest request, HttpServletResponse response) throws IOException
/*      */   {
/* 1154 */     StringBuilder location = new StringBuilder(request.getRequestURI());
/* 1155 */     location.append('/');
/* 1156 */     if (request.getQueryString() != null) {
/* 1157 */       location.append('?');
/* 1158 */       location.append(request.getQueryString());
/*      */     }
/* 1160 */     response.sendRedirect(response.encodeRedirectURL(location.toString()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Range parseContentRange(HttpServletRequest request, HttpServletResponse response)
/*      */     throws IOException
/*      */   {
/* 1176 */     String rangeHeader = request.getHeader("Content-Range");
/*      */     
/* 1178 */     if (rangeHeader == null) {
/* 1179 */       return null;
/*      */     }
/*      */     
/* 1182 */     if (!rangeHeader.startsWith("bytes")) {
/* 1183 */       response.sendError(400);
/* 1184 */       return null;
/*      */     }
/*      */     
/* 1187 */     rangeHeader = rangeHeader.substring(6).trim();
/*      */     
/* 1189 */     int dashPos = rangeHeader.indexOf('-');
/* 1190 */     int slashPos = rangeHeader.indexOf('/');
/*      */     
/* 1192 */     if (dashPos == -1) {
/* 1193 */       response.sendError(400);
/* 1194 */       return null;
/*      */     }
/*      */     
/* 1197 */     if (slashPos == -1) {
/* 1198 */       response.sendError(400);
/* 1199 */       return null;
/*      */     }
/*      */     
/* 1202 */     Range range = new Range();
/*      */     try
/*      */     {
/* 1205 */       range.start = Long.parseLong(rangeHeader.substring(0, dashPos));
/* 1206 */       range.end = Long.parseLong(rangeHeader.substring(dashPos + 1, slashPos));
/*      */       
/* 1208 */       range.length = Long.parseLong(rangeHeader.substring(slashPos + 1, rangeHeader.length()));
/*      */     }
/*      */     catch (NumberFormatException e) {
/* 1211 */       response.sendError(400);
/* 1212 */       return null;
/*      */     }
/*      */     
/* 1215 */     if (!range.validate()) {
/* 1216 */       response.sendError(400);
/* 1217 */       return null;
/*      */     }
/*      */     
/* 1220 */     return range;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ArrayList<Range> parseRange(HttpServletRequest request, HttpServletResponse response, WebResource resource)
/*      */     throws IOException
/*      */   {
/* 1239 */     String headerValue = request.getHeader("If-Range");
/*      */     
/* 1241 */     if (headerValue != null)
/*      */     {
/* 1243 */       long headerValueTime = -1L;
/*      */       try {
/* 1245 */         headerValueTime = request.getDateHeader("If-Range");
/*      */       }
/*      */       catch (IllegalArgumentException localIllegalArgumentException) {}
/*      */       
/*      */ 
/* 1250 */       String eTag = resource.getETag();
/* 1251 */       long lastModified = resource.getLastModified();
/*      */       
/* 1253 */       if (headerValueTime == -1L)
/*      */       {
/*      */ 
/*      */ 
/* 1257 */         if (!eTag.equals(headerValue.trim())) {
/* 1258 */           return FULL;
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */       }
/* 1265 */       else if (lastModified > headerValueTime + 1000L) {
/* 1266 */         return FULL;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1272 */     long fileLength = resource.getContentLength();
/*      */     
/* 1274 */     if (fileLength == 0L) {
/* 1275 */       return null;
/*      */     }
/*      */     
/* 1278 */     String rangeHeader = request.getHeader("Range");
/*      */     
/* 1280 */     if (rangeHeader == null) {
/* 1281 */       return null;
/*      */     }
/*      */     
/* 1284 */     if (!rangeHeader.startsWith("bytes")) {
/* 1285 */       response.addHeader("Content-Range", "bytes */" + fileLength);
/* 1286 */       response.sendError(416);
/*      */       
/* 1288 */       return null;
/*      */     }
/*      */     
/* 1291 */     rangeHeader = rangeHeader.substring(6);
/*      */     
/*      */ 
/*      */ 
/* 1295 */     ArrayList<Range> result = new ArrayList();
/* 1296 */     StringTokenizer commaTokenizer = new StringTokenizer(rangeHeader, ",");
/*      */     
/*      */ 
/* 1299 */     while (commaTokenizer.hasMoreTokens()) {
/* 1300 */       String rangeDefinition = commaTokenizer.nextToken().trim();
/*      */       
/* 1302 */       Range currentRange = new Range();
/* 1303 */       currentRange.length = fileLength;
/*      */       
/* 1305 */       int dashPos = rangeDefinition.indexOf('-');
/*      */       
/* 1307 */       if (dashPos == -1) {
/* 1308 */         response.addHeader("Content-Range", "bytes */" + fileLength);
/* 1309 */         response.sendError(416);
/*      */         
/* 1311 */         return null;
/*      */       }
/*      */       
/* 1314 */       if (dashPos == 0) {
/*      */         try
/*      */         {
/* 1317 */           long offset = Long.parseLong(rangeDefinition);
/* 1318 */           currentRange.start = (fileLength + offset);
/* 1319 */           currentRange.end = (fileLength - 1L);
/*      */         } catch (NumberFormatException e) {
/* 1321 */           response.addHeader("Content-Range", "bytes */" + fileLength);
/*      */           
/* 1323 */           response.sendError(416);
/*      */           
/*      */ 
/* 1326 */           return null;
/*      */         }
/*      */         
/*      */       } else {
/*      */         try
/*      */         {
/* 1332 */           currentRange.start = Long.parseLong(rangeDefinition.substring(0, dashPos));
/*      */           
/* 1334 */           if (dashPos < rangeDefinition.length() - 1) {
/* 1335 */             currentRange.end = Long.parseLong(rangeDefinition.substring(dashPos + 1, rangeDefinition.length()));
/*      */           }
/*      */           else
/*      */           {
/* 1339 */             currentRange.end = (fileLength - 1L); }
/*      */         } catch (NumberFormatException e) {
/* 1341 */           response.addHeader("Content-Range", "bytes */" + fileLength);
/*      */           
/* 1343 */           response.sendError(416);
/*      */           
/*      */ 
/* 1346 */           return null;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1351 */       if (!currentRange.validate()) {
/* 1352 */         response.addHeader("Content-Range", "bytes */" + fileLength);
/* 1353 */         response.sendError(416);
/*      */         
/* 1355 */         return null;
/*      */       }
/*      */       
/* 1358 */       result.add(currentRange);
/*      */     }
/*      */     
/* 1361 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected InputStream render(String contextPath, WebResource resource)
/*      */     throws IOException, ServletException
/*      */   {
/* 1381 */     return render(contextPath, resource, null);
/*      */   }
/*      */   
/*      */   protected InputStream render(String contextPath, WebResource resource, String encoding)
/*      */     throws IOException, ServletException
/*      */   {
/* 1387 */     Source xsltSource = findXsltSource(resource);
/*      */     
/* 1389 */     if (xsltSource == null) {
/* 1390 */       return renderHtml(contextPath, resource, encoding);
/*      */     }
/* 1392 */     return renderXml(contextPath, resource, xsltSource, encoding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected InputStream renderXml(String contextPath, WebResource resource, Source xsltSource)
/*      */     throws IOException, ServletException
/*      */   {
/* 1414 */     return renderXml(contextPath, resource, xsltSource, null);
/*      */   }
/*      */   
/*      */ 
/*      */   protected InputStream renderXml(String contextPath, WebResource resource, Source xsltSource, String encoding)
/*      */     throws IOException, ServletException
/*      */   {
/* 1421 */     StringBuilder sb = new StringBuilder();
/*      */     
/* 1423 */     sb.append("<?xml version=\"1.0\"?>");
/* 1424 */     sb.append("<listing ");
/* 1425 */     sb.append(" contextPath='");
/* 1426 */     sb.append(contextPath);
/* 1427 */     sb.append("'");
/* 1428 */     sb.append(" directory='");
/* 1429 */     sb.append(resource.getName());
/* 1430 */     sb.append("' ");
/* 1431 */     sb.append(" hasParent='").append(!resource.getName().equals("/"));
/* 1432 */     sb.append("'>");
/*      */     
/* 1434 */     sb.append("<entries>");
/*      */     
/* 1436 */     String[] entries = this.resources.list(resource.getWebappPath());
/*      */     
/*      */ 
/* 1439 */     String rewrittenContextPath = rewriteUrl(contextPath);
/* 1440 */     String directoryWebappPath = resource.getWebappPath();
/*      */     
/* 1442 */     for (String entry : entries)
/*      */     {
/* 1444 */       if ((!entry.equalsIgnoreCase("WEB-INF")) && (!entry.equalsIgnoreCase("META-INF")) && (!entry.equalsIgnoreCase(this.localXsltFile)))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1449 */         if (!(directoryWebappPath + entry).equals(this.contextXsltFile))
/*      */         {
/*      */ 
/* 1452 */           WebResource childResource = this.resources.getResource(directoryWebappPath + entry);
/*      */           
/* 1454 */           if (childResource.exists())
/*      */           {
/*      */ 
/*      */ 
/* 1458 */             sb.append("<entry");
/* 1459 */             sb.append(" type='").append(childResource.isDirectory() ? "dir" : "file").append("'");
/*      */             
/*      */ 
/* 1462 */             sb.append(" urlPath='").append(rewrittenContextPath).append(rewriteUrl(directoryWebappPath + entry)).append(childResource.isDirectory() ? "/" : "").append("'");
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 1467 */             if (childResource.isFile()) {
/* 1468 */               sb.append(" size='").append(renderSize(childResource.getContentLength())).append("'");
/*      */             }
/*      */             
/*      */ 
/* 1472 */             sb.append(" date='").append(childResource.getLastModifiedHttp()).append("'");
/*      */             
/*      */ 
/*      */ 
/* 1476 */             sb.append(">");
/* 1477 */             sb.append(RequestUtil.filter(entry));
/* 1478 */             if (childResource.isDirectory())
/* 1479 */               sb.append("/");
/* 1480 */             sb.append("</entry>");
/*      */           } } } }
/* 1482 */     sb.append("</entries>");
/*      */     
/* 1484 */     String readme = getReadme(resource, encoding);
/*      */     
/* 1486 */     if (readme != null) {
/* 1487 */       sb.append("<readme><![CDATA[");
/* 1488 */       sb.append(readme);
/* 1489 */       sb.append("]]></readme>");
/*      */     }
/*      */     
/* 1492 */     sb.append("</listing>");
/*      */     
/*      */     ClassLoader original;
/*      */     
/*      */     ClassLoader original;
/* 1497 */     if (Globals.IS_SECURITY_ENABLED) {
/* 1498 */       PrivilegedGetTccl pa = new PrivilegedGetTccl();
/* 1499 */       original = (ClassLoader)AccessController.doPrivileged(pa);
/*      */     } else {
/* 1501 */       original = Thread.currentThread().getContextClassLoader();
/*      */     }
/*      */     try {
/* 1504 */       if (Globals.IS_SECURITY_ENABLED) {
/* 1505 */         PrivilegedSetTccl pa = new PrivilegedSetTccl(DefaultServlet.class.getClassLoader());
/*      */         
/* 1507 */         AccessController.doPrivileged(pa);
/*      */       } else {
/* 1509 */         Thread.currentThread().setContextClassLoader(DefaultServlet.class.getClassLoader());
/*      */       }
/*      */       
/*      */ 
/* 1513 */       TransformerFactory tFactory = TransformerFactory.newInstance();
/* 1514 */       Source xmlSource = new StreamSource(new StringReader(sb.toString()));
/* 1515 */       Transformer transformer = tFactory.newTransformer(xsltSource);
/*      */       
/* 1517 */       ByteArrayOutputStream stream = new ByteArrayOutputStream();
/* 1518 */       OutputStreamWriter osWriter = new OutputStreamWriter(stream, "UTF8");
/* 1519 */       StreamResult out = new StreamResult(osWriter);
/* 1520 */       transformer.transform(xmlSource, out);
/* 1521 */       osWriter.flush();
/* 1522 */       PrivilegedSetTccl pa; return new ByteArrayInputStream(stream.toByteArray());
/*      */     } catch (TransformerException e) {
/* 1524 */       throw new ServletException("XSL transformer error", e);
/*      */     } finally {
/* 1526 */       if (Globals.IS_SECURITY_ENABLED) {
/* 1527 */         PrivilegedSetTccl pa = new PrivilegedSetTccl(original);
/* 1528 */         AccessController.doPrivileged(pa);
/*      */       } else {
/* 1530 */         Thread.currentThread().setContextClassLoader(original);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected InputStream renderHtml(String contextPath, WebResource resource)
/*      */     throws IOException
/*      */   {
/* 1551 */     return renderHtml(contextPath, resource, null);
/*      */   }
/*      */   
/*      */ 
/*      */   protected InputStream renderHtml(String contextPath, WebResource resource, String encoding)
/*      */     throws IOException
/*      */   {
/* 1558 */     ByteArrayOutputStream stream = new ByteArrayOutputStream();
/* 1559 */     OutputStreamWriter osWriter = new OutputStreamWriter(stream, "UTF8");
/* 1560 */     PrintWriter writer = new PrintWriter(osWriter);
/*      */     
/* 1562 */     StringBuilder sb = new StringBuilder();
/*      */     
/* 1564 */     String[] entries = this.resources.list(resource.getWebappPath());
/*      */     
/*      */ 
/* 1567 */     String rewrittenContextPath = rewriteUrl(contextPath);
/* 1568 */     String directoryWebappPath = resource.getWebappPath();
/*      */     
/*      */ 
/* 1571 */     sb.append("<html>\r\n");
/* 1572 */     sb.append("<head>\r\n");
/* 1573 */     sb.append("<title>");
/* 1574 */     sb.append(sm.getString("directory.title", new Object[] { directoryWebappPath }));
/* 1575 */     sb.append("</title>\r\n");
/* 1576 */     sb.append("<STYLE><!--");
/* 1577 */     sb.append("H1 {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;font-size:22px;} H2 {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;font-size:16px;} H3 {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;font-size:14px;} BODY {font-family:Tahoma,Arial,sans-serif;color:black;background-color:white;} B {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;} P {font-family:Tahoma,Arial,sans-serif;background:white;color:black;font-size:12px;}A {color : black;}A.name {color : black;}.line {height: 1px; background-color: #525D76; border: none;}");
/* 1578 */     sb.append("--></STYLE> ");
/* 1579 */     sb.append("</head>\r\n");
/* 1580 */     sb.append("<body>");
/* 1581 */     sb.append("<h1>");
/* 1582 */     sb.append(sm.getString("directory.title", new Object[] { directoryWebappPath }));
/*      */     
/*      */ 
/* 1585 */     String parentDirectory = directoryWebappPath;
/* 1586 */     if (parentDirectory.endsWith("/")) {
/* 1587 */       parentDirectory = parentDirectory.substring(0, parentDirectory.length() - 1);
/*      */     }
/*      */     
/* 1590 */     int slash = parentDirectory.lastIndexOf('/');
/* 1591 */     if (slash >= 0) {
/* 1592 */       String parent = directoryWebappPath.substring(0, slash);
/* 1593 */       sb.append(" - <a href=\"");
/* 1594 */       sb.append(rewrittenContextPath);
/* 1595 */       if (parent.equals(""))
/* 1596 */         parent = "/";
/* 1597 */       sb.append(rewriteUrl(parent));
/* 1598 */       if (!parent.endsWith("/"))
/* 1599 */         sb.append("/");
/* 1600 */       sb.append("\">");
/* 1601 */       sb.append("<b>");
/* 1602 */       sb.append(sm.getString("directory.parent", new Object[] { parent }));
/* 1603 */       sb.append("</b>");
/* 1604 */       sb.append("</a>");
/*      */     }
/*      */     
/* 1607 */     sb.append("</h1>");
/* 1608 */     sb.append("<HR size=\"1\" noshade=\"noshade\">");
/*      */     
/* 1610 */     sb.append("<table width=\"100%\" cellspacing=\"0\" cellpadding=\"5\" align=\"center\">\r\n");
/*      */     
/*      */ 
/*      */ 
/* 1614 */     sb.append("<tr>\r\n");
/* 1615 */     sb.append("<td align=\"left\"><font size=\"+1\"><strong>");
/* 1616 */     sb.append(sm.getString("directory.filename"));
/* 1617 */     sb.append("</strong></font></td>\r\n");
/* 1618 */     sb.append("<td align=\"center\"><font size=\"+1\"><strong>");
/* 1619 */     sb.append(sm.getString("directory.size"));
/* 1620 */     sb.append("</strong></font></td>\r\n");
/* 1621 */     sb.append("<td align=\"right\"><font size=\"+1\"><strong>");
/* 1622 */     sb.append(sm.getString("directory.lastModified"));
/* 1623 */     sb.append("</strong></font></td>\r\n");
/* 1624 */     sb.append("</tr>");
/*      */     
/* 1626 */     boolean shade = false;
/* 1627 */     for (String entry : entries) {
/* 1628 */       if ((!entry.equalsIgnoreCase("WEB-INF")) && (!entry.equalsIgnoreCase("META-INF")))
/*      */       {
/*      */ 
/*      */ 
/* 1632 */         WebResource childResource = this.resources.getResource(directoryWebappPath + entry);
/*      */         
/* 1634 */         if (childResource.exists())
/*      */         {
/*      */ 
/*      */ 
/* 1638 */           sb.append("<tr");
/* 1639 */           if (shade)
/* 1640 */             sb.append(" bgcolor=\"#eeeeee\"");
/* 1641 */           sb.append(">\r\n");
/* 1642 */           shade = !shade;
/*      */           
/* 1644 */           sb.append("<td align=\"left\">&nbsp;&nbsp;\r\n");
/* 1645 */           sb.append("<a href=\"");
/* 1646 */           sb.append(rewrittenContextPath);
/* 1647 */           sb.append(rewriteUrl(directoryWebappPath + entry));
/* 1648 */           if (childResource.isDirectory())
/* 1649 */             sb.append("/");
/* 1650 */           sb.append("\"><tt>");
/* 1651 */           sb.append(RequestUtil.filter(entry));
/* 1652 */           if (childResource.isDirectory())
/* 1653 */             sb.append("/");
/* 1654 */           sb.append("</tt></a></td>\r\n");
/*      */           
/* 1656 */           sb.append("<td align=\"right\"><tt>");
/* 1657 */           if (childResource.isDirectory()) {
/* 1658 */             sb.append("&nbsp;");
/*      */           } else
/* 1660 */             sb.append(renderSize(childResource.getContentLength()));
/* 1661 */           sb.append("</tt></td>\r\n");
/*      */           
/* 1663 */           sb.append("<td align=\"right\"><tt>");
/* 1664 */           sb.append(childResource.getLastModifiedHttp());
/* 1665 */           sb.append("</tt></td>\r\n");
/*      */           
/* 1667 */           sb.append("</tr>\r\n");
/*      */         }
/*      */       }
/*      */     }
/* 1671 */     sb.append("</table>\r\n");
/*      */     
/* 1673 */     sb.append("<HR size=\"1\" noshade=\"noshade\">");
/*      */     
/* 1675 */     String readme = getReadme(resource, encoding);
/* 1676 */     if (readme != null) {
/* 1677 */       sb.append(readme);
/* 1678 */       sb.append("<HR size=\"1\" noshade=\"noshade\">");
/*      */     }
/*      */     
/* 1681 */     if (this.showServerInfo) {
/* 1682 */       sb.append("<h3>").append(ServerInfo.getServerInfo()).append("</h3>");
/*      */     }
/* 1684 */     sb.append("</body>\r\n");
/* 1685 */     sb.append("</html>\r\n");
/*      */     
/*      */ 
/* 1688 */     writer.write(sb.toString());
/* 1689 */     writer.flush();
/* 1690 */     return new ByteArrayInputStream(stream.toByteArray());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String renderSize(long size)
/*      */   {
/* 1703 */     long leftSide = size / 1024L;
/* 1704 */     long rightSide = size % 1024L / 103L;
/* 1705 */     if ((leftSide == 0L) && (rightSide == 0L) && (size > 0L)) {
/* 1706 */       rightSide = 1L;
/*      */     }
/* 1708 */     return "" + leftSide + "." + rightSide + " kb";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected String getReadme(WebResource directory)
/*      */   {
/* 1722 */     return getReadme(directory, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getReadme(WebResource directory, String encoding)
/*      */   {
/* 1733 */     if (this.readmeFile != null) {
/* 1734 */       WebResource resource = this.resources.getResource(directory.getWebappPath() + this.readmeFile);
/*      */       StringWriter buffer;
/* 1736 */       if (resource.isFile()) {
/* 1737 */         buffer = new StringWriter();
/* 1738 */         InputStreamReader reader = null;
/* 1739 */         try { InputStream is = resource.getInputStream();Throwable localThrowable2 = null;
/* 1740 */           try { if (encoding != null) {
/* 1741 */               reader = new InputStreamReader(is, encoding);
/*      */             } else {
/* 1743 */               reader = new InputStreamReader(is);
/*      */             }
/* 1745 */             copyRange(reader, new PrintWriter(buffer));
/*      */           }
/*      */           catch (Throwable localThrowable1)
/*      */           {
/* 1739 */             localThrowable2 = localThrowable1;throw localThrowable1;
/*      */ 
/*      */ 
/*      */           }
/*      */           finally
/*      */           {
/*      */ 
/* 1746 */             if (is != null) { if (localThrowable2 != null) try { is.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else { is.close();
/*      */               }
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1756 */           return buffer.toString();
/*      */         }
/*      */         catch (IOException e)
/*      */         {
/* 1747 */           log("Failure to close reader", e);
/*      */         } finally {
/* 1749 */           if (reader != null) {
/*      */             try {
/* 1751 */               reader.close();
/*      */             }
/*      */             catch (IOException localIOException3) {}
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 1758 */       if (this.debug > 10) {
/* 1759 */         log("readme '" + this.readmeFile + "' not found");
/*      */       }
/* 1761 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 1765 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Source findXsltSource(WebResource directory)
/*      */     throws IOException
/*      */   {
/* 1778 */     if (this.localXsltFile != null) {
/* 1779 */       WebResource resource = this.resources.getResource(directory.getWebappPath() + this.localXsltFile);
/*      */       
/* 1781 */       if (resource.isFile()) {
/* 1782 */         InputStream is = resource.getInputStream();
/* 1783 */         if (is != null) {
/* 1784 */           if (Globals.IS_SECURITY_ENABLED) {
/* 1785 */             return secureXslt(is);
/*      */           }
/* 1787 */           return new StreamSource(is);
/*      */         }
/*      */       }
/*      */       
/* 1791 */       if (this.debug > 10) {
/* 1792 */         log("localXsltFile '" + this.localXsltFile + "' not found");
/*      */       }
/*      */     }
/*      */     
/* 1796 */     if (this.contextXsltFile != null) {
/* 1797 */       InputStream is = getServletContext().getResourceAsStream(this.contextXsltFile);
/*      */       
/* 1799 */       if (is != null) {
/* 1800 */         if (Globals.IS_SECURITY_ENABLED) {
/* 1801 */           return secureXslt(is);
/*      */         }
/* 1803 */         return new StreamSource(is);
/*      */       }
/*      */       
/*      */ 
/* 1807 */       if (this.debug > 10) {
/* 1808 */         log("contextXsltFile '" + this.contextXsltFile + "' not found");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1814 */     if (this.globalXsltFile != null) {
/* 1815 */       File f = validateGlobalXsltFile();
/* 1816 */       if (f != null) {
/* 1817 */         FileInputStream fis = new FileInputStream(f);Throwable localThrowable2 = null;
/* 1818 */         try { byte[] b = new byte[(int)f.length()];
/* 1819 */           fis.read(b);
/* 1820 */           return new StreamSource(new ByteArrayInputStream(b));
/*      */         }
/*      */         catch (Throwable localThrowable1)
/*      */         {
/* 1817 */           localThrowable2 = localThrowable1;throw localThrowable1;
/*      */         }
/*      */         finally
/*      */         {
/* 1821 */           if (fis != null) if (localThrowable2 != null) try { fis.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else fis.close();
/*      */         }
/*      */       }
/*      */     }
/* 1825 */     return null;
/*      */   }
/*      */   
/*      */   private File validateGlobalXsltFile()
/*      */   {
/* 1830 */     Context context = this.resources.getContext();
/*      */     
/* 1832 */     File baseConf = new File(context.getCatalinaBase(), "conf");
/* 1833 */     File result = validateGlobalXsltFile(baseConf);
/* 1834 */     if (result == null) {
/* 1835 */       File homeConf = new File(context.getCatalinaHome(), "conf");
/* 1836 */       if (!baseConf.equals(homeConf)) {
/* 1837 */         result = validateGlobalXsltFile(homeConf);
/*      */       }
/*      */     }
/*      */     
/* 1841 */     return result;
/*      */   }
/*      */   
/*      */   private File validateGlobalXsltFile(File base)
/*      */   {
/* 1846 */     File candidate = new File(this.globalXsltFile);
/* 1847 */     if (!candidate.isAbsolute()) {
/* 1848 */       candidate = new File(base, this.globalXsltFile);
/*      */     }
/*      */     
/* 1851 */     if (!candidate.isFile()) {
/* 1852 */       return null;
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1857 */       if (!candidate.getCanonicalPath().startsWith(base.getCanonicalPath())) {
/* 1858 */         return null;
/*      */       }
/*      */     } catch (IOException ioe) {
/* 1861 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 1865 */     String nameLower = candidate.getName().toLowerCase(Locale.ENGLISH);
/* 1866 */     if ((!nameLower.endsWith(".xslt")) && (!nameLower.endsWith(".xsl"))) {
/* 1867 */       return null;
/*      */     }
/*      */     
/* 1870 */     return candidate;
/*      */   }
/*      */   
/*      */ 
/*      */   private Source secureXslt(InputStream is)
/*      */   {
/* 1876 */     result = null;
/*      */     try {
/* 1878 */       DocumentBuilder builder = factory.newDocumentBuilder();
/* 1879 */       builder.setEntityResolver(secureEntityResolver);
/* 1880 */       Document document = builder.parse(is);
/* 1881 */       return new DOMSource(document);
/*      */     } catch (ParserConfigurationException|SAXException|IOException e) {
/* 1883 */       if (this.debug > 0) {
/* 1884 */         log(e.getMessage(), e);
/*      */       }
/*      */     } finally {
/* 1887 */       if (is != null) {
/*      */         try {
/* 1889 */           is.close();
/*      */         }
/*      */         catch (IOException localIOException2) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean checkSendfile(HttpServletRequest request, HttpServletResponse response, WebResource resource, long length, Range range)
/*      */   {
/* 1916 */     if ((this.sendfileSize > 0) && (resource.isFile()) && (length > this.sendfileSize) && (resource.getCanonicalPath() != null) && (Boolean.TRUE.equals(request.getAttribute("org.apache.tomcat.sendfile.support"))) && (request.getClass().getName().equals("org.apache.catalina.connector.RequestFacade")) && (response.getClass().getName().equals("org.apache.catalina.connector.ResponseFacade")))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1923 */       request.setAttribute("org.apache.tomcat.sendfile.filename", resource.getCanonicalPath());
/* 1924 */       if (range == null) {
/* 1925 */         request.setAttribute("org.apache.tomcat.sendfile.start", Long.valueOf(0L));
/* 1926 */         request.setAttribute("org.apache.tomcat.sendfile.end", Long.valueOf(length));
/*      */       } else {
/* 1928 */         request.setAttribute("org.apache.tomcat.sendfile.start", Long.valueOf(range.start));
/* 1929 */         request.setAttribute("org.apache.tomcat.sendfile.end", Long.valueOf(range.end + 1L));
/*      */       }
/* 1931 */       return true;
/*      */     }
/* 1933 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean checkIfMatch(HttpServletRequest request, HttpServletResponse response, WebResource resource)
/*      */     throws IOException
/*      */   {
/* 1952 */     String eTag = resource.getETag();
/* 1953 */     String headerValue = request.getHeader("If-Match");
/* 1954 */     if ((headerValue != null) && 
/* 1955 */       (headerValue.indexOf('*') == -1))
/*      */     {
/* 1957 */       StringTokenizer commaTokenizer = new StringTokenizer(headerValue, ",");
/*      */       
/* 1959 */       boolean conditionSatisfied = false;
/*      */       
/* 1961 */       while ((!conditionSatisfied) && (commaTokenizer.hasMoreTokens())) {
/* 1962 */         String currentToken = commaTokenizer.nextToken();
/* 1963 */         if (currentToken.trim().equals(eTag)) {
/* 1964 */           conditionSatisfied = true;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1969 */       if (!conditionSatisfied) {
/* 1970 */         response.sendError(412);
/*      */         
/* 1972 */         return false;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1977 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean checkIfModifiedSince(HttpServletRequest request, HttpServletResponse response, WebResource resource)
/*      */   {
/*      */     try
/*      */     {
/* 1994 */       long headerValue = request.getDateHeader("If-Modified-Since");
/* 1995 */       long lastModified = resource.getLastModified();
/* 1996 */       if (headerValue != -1L)
/*      */       {
/*      */ 
/*      */ 
/* 2000 */         if ((request.getHeader("If-None-Match") == null) && (lastModified < headerValue + 1000L))
/*      */         {
/*      */ 
/*      */ 
/* 2004 */           response.setStatus(304);
/* 2005 */           response.setHeader("ETag", resource.getETag());
/*      */           
/* 2007 */           return false;
/*      */         }
/*      */       }
/*      */     } catch (IllegalArgumentException illegalArgument) {
/* 2011 */       return true;
/*      */     }
/* 2013 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean checkIfNoneMatch(HttpServletRequest request, HttpServletResponse response, WebResource resource)
/*      */     throws IOException
/*      */   {
/* 2032 */     String eTag = resource.getETag();
/* 2033 */     String headerValue = request.getHeader("If-None-Match");
/* 2034 */     if (headerValue != null)
/*      */     {
/* 2036 */       boolean conditionSatisfied = false;
/*      */       
/* 2038 */       if (!headerValue.equals("*"))
/*      */       {
/* 2040 */         StringTokenizer commaTokenizer = new StringTokenizer(headerValue, ",");
/*      */         
/*      */ 
/* 2043 */         while ((!conditionSatisfied) && (commaTokenizer.hasMoreTokens())) {
/* 2044 */           String currentToken = commaTokenizer.nextToken();
/* 2045 */           if (currentToken.trim().equals(eTag)) {
/* 2046 */             conditionSatisfied = true;
/*      */           }
/*      */         }
/*      */       } else {
/* 2050 */         conditionSatisfied = true;
/*      */       }
/*      */       
/* 2053 */       if (conditionSatisfied)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2059 */         if (("GET".equals(request.getMethod())) || ("HEAD".equals(request.getMethod())))
/*      */         {
/* 2061 */           response.setStatus(304);
/* 2062 */           response.setHeader("ETag", eTag);
/*      */           
/* 2064 */           return false;
/*      */         }
/* 2066 */         response.sendError(412);
/* 2067 */         return false;
/*      */       }
/*      */     }
/* 2070 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean checkIfUnmodifiedSince(HttpServletRequest request, HttpServletResponse response, WebResource resource)
/*      */     throws IOException
/*      */   {
/*      */     try
/*      */     {
/* 2088 */       long lastModified = resource.getLastModified();
/* 2089 */       long headerValue = request.getDateHeader("If-Unmodified-Since");
/* 2090 */       if ((headerValue != -1L) && 
/* 2091 */         (lastModified >= headerValue + 1000L))
/*      */       {
/*      */ 
/* 2094 */         response.sendError(412);
/* 2095 */         return false;
/*      */       }
/*      */     }
/*      */     catch (IllegalArgumentException illegalArgument) {
/* 2099 */       return true;
/*      */     }
/* 2101 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void copy(WebResource resource, InputStream is, ServletOutputStream ostream)
/*      */     throws IOException
/*      */   {
/* 2120 */     IOException exception = null;
/* 2121 */     InputStream istream = new BufferedInputStream(is, this.input);
/*      */     
/*      */ 
/* 2124 */     exception = copyRange(istream, ostream);
/*      */     
/*      */ 
/* 2127 */     istream.close();
/*      */     
/*      */ 
/* 2130 */     if (exception != null) {
/* 2131 */       throw exception;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void copy(WebResource resource, InputStream is, PrintWriter writer, String encoding)
/*      */     throws IOException
/*      */   {
/* 2150 */     IOException exception = null;
/*      */     
/* 2152 */     InputStream resourceInputStream = null;
/* 2153 */     if (resource.isFile()) {
/* 2154 */       resourceInputStream = resource.getInputStream();
/*      */     } else {
/* 2156 */       resourceInputStream = is;
/*      */     }
/*      */     Reader reader;
/*      */     Reader reader;
/* 2160 */     if (encoding == null) {
/* 2161 */       reader = new InputStreamReader(resourceInputStream);
/*      */     } else {
/* 2163 */       reader = new InputStreamReader(resourceInputStream, encoding);
/*      */     }
/*      */     
/*      */ 
/* 2167 */     exception = copyRange(reader, writer);
/*      */     
/*      */ 
/* 2170 */     reader.close();
/*      */     
/*      */ 
/* 2173 */     if (exception != null) {
/* 2174 */       throw exception;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void copy(WebResource resource, ServletOutputStream ostream, Range range)
/*      */     throws IOException
/*      */   {
/* 2192 */     IOException exception = null;
/*      */     
/* 2194 */     InputStream resourceInputStream = resource.getInputStream();
/* 2195 */     InputStream istream = new BufferedInputStream(resourceInputStream, this.input);
/*      */     
/* 2197 */     exception = copyRange(istream, ostream, range.start, range.end);
/*      */     
/*      */ 
/* 2200 */     istream.close();
/*      */     
/*      */ 
/* 2203 */     if (exception != null) {
/* 2204 */       throw exception;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void copy(WebResource resource, ServletOutputStream ostream, Iterator<Range> ranges, String contentType)
/*      */     throws IOException
/*      */   {
/* 2225 */     IOException exception = null;
/*      */     
/* 2227 */     while ((exception == null) && (ranges.hasNext()))
/*      */     {
/* 2229 */       InputStream resourceInputStream = resource.getInputStream();
/* 2230 */       InputStream istream = new BufferedInputStream(resourceInputStream, this.input);Throwable localThrowable2 = null;
/*      */       try {
/* 2232 */         Range currentRange = (Range)ranges.next();
/*      */         
/*      */ 
/* 2235 */         ostream.println();
/* 2236 */         ostream.println("--CATALINA_MIME_BOUNDARY");
/* 2237 */         if (contentType != null)
/* 2238 */           ostream.println("Content-Type: " + contentType);
/* 2239 */         ostream.println("Content-Range: bytes " + currentRange.start + "-" + currentRange.end + "/" + currentRange.length);
/*      */         
/*      */ 
/* 2242 */         ostream.println();
/*      */         
/*      */ 
/* 2245 */         exception = copyRange(istream, ostream, currentRange.start, currentRange.end);
/*      */       }
/*      */       catch (Throwable localThrowable1)
/*      */       {
/* 2230 */         localThrowable2 = localThrowable1;throw localThrowable1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2247 */         if (istream != null) if (localThrowable2 != null) try { istream.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else istream.close();
/*      */       }
/*      */     }
/* 2250 */     ostream.println();
/* 2251 */     ostream.print("--CATALINA_MIME_BOUNDARY--");
/*      */     
/*      */ 
/* 2254 */     if (exception != null) {
/* 2255 */       throw exception;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected IOException copyRange(InputStream istream, ServletOutputStream ostream)
/*      */   {
/* 2273 */     exception = null;
/* 2274 */     byte[] buffer = new byte[this.input];
/* 2275 */     int len = buffer.length;
/*      */     try {
/*      */       for (;;) {
/* 2278 */         len = istream.read(buffer);
/* 2279 */         if (len == -1)
/*      */           break;
/* 2281 */         ostream.write(buffer, 0, len);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2288 */       return exception;
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/* 2283 */       exception = e;
/* 2284 */       len = -1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected IOException copyRange(Reader reader, PrintWriter writer)
/*      */   {
/* 2305 */     exception = null;
/* 2306 */     char[] buffer = new char[this.input];
/* 2307 */     int len = buffer.length;
/*      */     try {
/*      */       for (;;) {
/* 2310 */         len = reader.read(buffer);
/* 2311 */         if (len == -1)
/*      */           break;
/* 2313 */         writer.write(buffer, 0, len);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2320 */       return exception;
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/* 2315 */       exception = e;
/* 2316 */       len = -1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected IOException copyRange(InputStream istream, ServletOutputStream ostream, long start, long end)
/*      */   {
/* 2340 */     if (this.debug > 10) {
/* 2341 */       log("Serving bytes:" + start + "-" + end);
/*      */     }
/* 2343 */     long skipped = 0L;
/*      */     try {
/* 2345 */       skipped = istream.skip(start);
/*      */     } catch (IOException e) {
/* 2347 */       return e;
/*      */     }
/* 2349 */     if (skipped < start) {
/* 2350 */       return new IOException(sm.getString("defaultservlet.skipfail", new Object[] { Long.valueOf(skipped), Long.valueOf(start) }));
/*      */     }
/*      */     
/*      */ 
/* 2354 */     IOException exception = null;
/* 2355 */     long bytesToRead = end - start + 1L;
/*      */     
/* 2357 */     byte[] buffer = new byte[this.input];
/* 2358 */     int len = buffer.length;
/* 2359 */     while ((bytesToRead > 0L) && (len >= buffer.length)) {
/*      */       try {
/* 2361 */         len = istream.read(buffer);
/* 2362 */         if (bytesToRead >= len) {
/* 2363 */           ostream.write(buffer, 0, len);
/* 2364 */           bytesToRead -= len;
/*      */         } else {
/* 2366 */           ostream.write(buffer, 0, (int)bytesToRead);
/* 2367 */           bytesToRead = 0L;
/*      */         }
/*      */       } catch (IOException e) {
/* 2370 */         exception = e;
/* 2371 */         len = -1;
/*      */       }
/* 2373 */       if (len < buffer.length) {
/*      */         break;
/*      */       }
/*      */     }
/* 2377 */     return exception;
/*      */   }
/*      */   
/*      */ 
/*      */   public void destroy() {}
/*      */   
/*      */ 
/*      */   protected static class Range
/*      */   {
/*      */     public long start;
/*      */     
/*      */     public long end;
/*      */     
/*      */     public long length;
/*      */     
/*      */     public boolean validate()
/*      */     {
/* 2394 */       if (this.end >= this.length)
/* 2395 */         this.end = (this.length - 1L);
/* 2396 */       return (this.start >= 0L) && (this.end >= 0L) && (this.start <= this.end) && (this.length > 0L);
/*      */     }
/*      */   }
/*      */   
/*      */   protected static class CompressionFormat implements Serializable {
/*      */     private static final long serialVersionUID = 1L;
/*      */     public final String extension;
/*      */     public final String encoding;
/*      */     
/*      */     public CompressionFormat(String extension, String encoding) {
/* 2406 */       this.extension = extension;
/* 2407 */       this.encoding = encoding;
/*      */     }
/*      */   }
/*      */   
/*      */   private static class PrecompressedResource {
/*      */     public final WebResource resource;
/*      */     public final DefaultServlet.CompressionFormat format;
/*      */     
/*      */     private PrecompressedResource(WebResource resource, DefaultServlet.CompressionFormat format) {
/* 2416 */       this.resource = resource;
/* 2417 */       this.format = format;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class SecureEntityResolver
/*      */     implements EntityResolver2
/*      */   {
/*      */     public InputSource resolveEntity(String publicId, String systemId)
/*      */       throws SAXException, IOException
/*      */     {
/* 2430 */       throw new SAXException(DefaultServlet.sm.getString("defaultServlet.blockExternalEntity", new Object[] { publicId, systemId }));
/*      */     }
/*      */     
/*      */ 
/*      */     public InputSource getExternalSubset(String name, String baseURI)
/*      */       throws SAXException, IOException
/*      */     {
/* 2437 */       throw new SAXException(DefaultServlet.sm.getString("defaultServlet.blockExternalSubset", new Object[] { name, baseURI }));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public InputSource resolveEntity(String name, String publicId, String baseURI, String systemId)
/*      */       throws SAXException, IOException
/*      */     {
/* 2445 */       throw new SAXException(DefaultServlet.sm.getString("defaultServlet.blockExternalEntity2", new Object[] { name, publicId, baseURI, systemId }));
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\servlets\DefaultServlet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */