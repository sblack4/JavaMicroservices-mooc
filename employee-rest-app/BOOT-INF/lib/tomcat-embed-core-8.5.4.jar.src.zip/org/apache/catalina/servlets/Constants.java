package org.apache.catalina.servlets;

public class Constants
{
  public static final String Package = "org.apache.catalina.servlets";
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\servlets\Constants.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */