/*      */ package org.apache.catalina.servlets;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.StringReader;
/*      */ import java.io.StringWriter;
/*      */ import java.io.Writer;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Locale;
/*      */ import java.util.Stack;
/*      */ import java.util.TimeZone;
/*      */ import java.util.Vector;
/*      */ import javax.servlet.ServletConfig;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import javax.xml.parsers.DocumentBuilder;
/*      */ import javax.xml.parsers.DocumentBuilderFactory;
/*      */ import javax.xml.parsers.ParserConfigurationException;
/*      */ import org.apache.catalina.WebResource;
/*      */ import org.apache.catalina.WebResourceRoot;
/*      */ import org.apache.catalina.util.ConcurrentDateFormat;
/*      */ import org.apache.catalina.util.DOMWriter;
/*      */ import org.apache.catalina.util.XMLWriter;
/*      */ import org.apache.tomcat.util.buf.UDecoder;
/*      */ import org.apache.tomcat.util.http.FastHttpDateFormat;
/*      */ import org.apache.tomcat.util.http.RequestUtil;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.util.security.ConcurrentMessageDigest;
/*      */ import org.apache.tomcat.util.security.MD5Encoder;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ import org.xml.sax.EntityResolver;
/*      */ import org.xml.sax.InputSource;
/*      */ import org.xml.sax.SAXException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class WebdavServlet
/*      */   extends DefaultServlet
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   private static final String METHOD_PROPFIND = "PROPFIND";
/*      */   private static final String METHOD_PROPPATCH = "PROPPATCH";
/*      */   private static final String METHOD_MKCOL = "MKCOL";
/*      */   private static final String METHOD_COPY = "COPY";
/*      */   private static final String METHOD_MOVE = "MOVE";
/*      */   private static final String METHOD_LOCK = "LOCK";
/*      */   private static final String METHOD_UNLOCK = "UNLOCK";
/*      */   private static final int FIND_BY_PROPERTY = 0;
/*      */   private static final int FIND_ALL_PROP = 1;
/*      */   private static final int FIND_PROPERTY_NAMES = 2;
/*      */   private static final int LOCK_CREATION = 0;
/*      */   private static final int LOCK_REFRESH = 1;
/*      */   private static final int DEFAULT_TIMEOUT = 3600;
/*      */   private static final int MAX_TIMEOUT = 604800;
/*      */   protected static final String DEFAULT_NAMESPACE = "DAV:";
/*  187 */   protected static final ConcurrentDateFormat creationDateFormat = new ConcurrentDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US, TimeZone.getTimeZone("GMT"));
/*      */   
/*      */   private final Hashtable<String, LockInfo> resourceLocks;
/*      */   
/*      */   private final Hashtable<String, Vector<String>> lockNullResources;
/*      */   
/*      */   private final Vector<LockInfo> collectionLocks;
/*      */   private String secret;
/*      */   private int maxDepth;
/*      */   private boolean allowSpecialPaths;
/*      */   
/*      */   public WebdavServlet()
/*      */   {
/*  200 */     this.resourceLocks = new Hashtable();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  211 */     this.lockNullResources = new Hashtable();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  221 */     this.collectionLocks = new Vector();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  227 */     this.secret = "catalina";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  234 */     this.maxDepth = 3;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  241 */     this.allowSpecialPaths = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void init()
/*      */     throws ServletException
/*      */   {
/*  254 */     super.init();
/*      */     
/*  256 */     if (getServletConfig().getInitParameter("secret") != null) {
/*  257 */       this.secret = getServletConfig().getInitParameter("secret");
/*      */     }
/*  259 */     if (getServletConfig().getInitParameter("maxDepth") != null) {
/*  260 */       this.maxDepth = Integer.parseInt(getServletConfig().getInitParameter("maxDepth"));
/*      */     }
/*      */     
/*  263 */     if (getServletConfig().getInitParameter("allowSpecialPaths") != null) {
/*  264 */       this.allowSpecialPaths = Boolean.parseBoolean(getServletConfig().getInitParameter("allowSpecialPaths"));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected DocumentBuilder getDocumentBuilder()
/*      */     throws ServletException
/*      */   {
/*  280 */     DocumentBuilder documentBuilder = null;
/*  281 */     DocumentBuilderFactory documentBuilderFactory = null;
/*      */     try {
/*  283 */       documentBuilderFactory = DocumentBuilderFactory.newInstance();
/*  284 */       documentBuilderFactory.setNamespaceAware(true);
/*  285 */       documentBuilderFactory.setExpandEntityReferences(false);
/*  286 */       documentBuilder = documentBuilderFactory.newDocumentBuilder();
/*  287 */       documentBuilder.setEntityResolver(new WebdavResolver(getServletContext()));
/*      */     }
/*      */     catch (ParserConfigurationException e) {
/*  290 */       throw new ServletException(sm.getString("webdavservlet.jaxpfailed"));
/*      */     }
/*      */     
/*  293 */     return documentBuilder;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void service(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  304 */     String path = getRelativePath(req);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  311 */     if (isSpecialPath(path)) {
/*  312 */       resp.sendError(404);
/*  313 */       return;
/*      */     }
/*      */     
/*  316 */     String method = req.getMethod();
/*      */     
/*  318 */     if (this.debug > 0) {
/*  319 */       log("[" + method + "] " + path);
/*      */     }
/*      */     
/*  322 */     if (method.equals("PROPFIND")) {
/*  323 */       doPropfind(req, resp);
/*  324 */     } else if (method.equals("PROPPATCH")) {
/*  325 */       doProppatch(req, resp);
/*  326 */     } else if (method.equals("MKCOL")) {
/*  327 */       doMkcol(req, resp);
/*  328 */     } else if (method.equals("COPY")) {
/*  329 */       doCopy(req, resp);
/*  330 */     } else if (method.equals("MOVE")) {
/*  331 */       doMove(req, resp);
/*  332 */     } else if (method.equals("LOCK")) {
/*  333 */       doLock(req, resp);
/*  334 */     } else if (method.equals("UNLOCK")) {
/*  335 */       doUnlock(req, resp);
/*      */     }
/*      */     else {
/*  338 */       super.service(req, resp);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final boolean isSpecialPath(String path)
/*      */   {
/*  351 */     return (!this.allowSpecialPaths) && ((path.toUpperCase(Locale.ENGLISH).startsWith("/WEB-INF")) || (path.toUpperCase(Locale.ENGLISH).startsWith("/META-INF")));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean checkIfHeaders(HttpServletRequest request, HttpServletResponse response, WebResource resource)
/*      */     throws IOException
/*      */   {
/*  363 */     if (!super.checkIfHeaders(request, response, resource)) {
/*  364 */       return false;
/*      */     }
/*      */     
/*  367 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getRelativePath(HttpServletRequest request)
/*      */   {
/*  381 */     return getRelativePath(request, false);
/*      */   }
/*      */   
/*      */   protected String getRelativePath(HttpServletRequest request, boolean allowEmptyPath)
/*      */   {
/*      */     String pathInfo;
/*      */     String pathInfo;
/*  388 */     if (request.getAttribute("javax.servlet.include.request_uri") != null)
/*      */     {
/*  390 */       pathInfo = (String)request.getAttribute("javax.servlet.include.path_info");
/*      */     } else {
/*  392 */       pathInfo = request.getPathInfo();
/*      */     }
/*      */     
/*  395 */     StringBuilder result = new StringBuilder();
/*  396 */     if (pathInfo != null) {
/*  397 */       result.append(pathInfo);
/*      */     }
/*  399 */     if (result.length() == 0) {
/*  400 */       result.append('/');
/*      */     }
/*      */     
/*  403 */     return result.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getPathPrefix(HttpServletRequest request)
/*      */   {
/*  413 */     String contextPath = request.getContextPath();
/*  414 */     if (request.getServletPath() != null) {
/*  415 */       contextPath = contextPath + request.getServletPath();
/*      */     }
/*  417 */     return contextPath;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doOptions(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  433 */     resp.addHeader("DAV", "1,2");
/*      */     
/*  435 */     StringBuilder methodsAllowed = determineMethodsAllowed(req);
/*      */     
/*  437 */     resp.addHeader("Allow", methodsAllowed.toString());
/*  438 */     resp.addHeader("MS-Author-Via", "DAV");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doPropfind(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  452 */     if (!this.listings)
/*      */     {
/*  454 */       StringBuilder methodsAllowed = determineMethodsAllowed(req);
/*      */       
/*  456 */       resp.addHeader("Allow", methodsAllowed.toString());
/*  457 */       resp.sendError(405);
/*  458 */       return;
/*      */     }
/*      */     
/*  461 */     String path = getRelativePath(req);
/*  462 */     if ((path.length() > 1) && (path.endsWith("/"))) {
/*  463 */       path = path.substring(0, path.length() - 1);
/*      */     }
/*      */     
/*  466 */     Vector<String> properties = null;
/*      */     
/*  468 */     int depth = this.maxDepth;
/*      */     
/*  470 */     int type = 1;
/*      */     
/*  472 */     String depthStr = req.getHeader("Depth");
/*      */     
/*  474 */     if (depthStr == null) {
/*  475 */       depth = this.maxDepth;
/*      */     }
/*  477 */     else if (depthStr.equals("0")) {
/*  478 */       depth = 0;
/*  479 */     } else if (depthStr.equals("1")) {
/*  480 */       depth = 1;
/*  481 */     } else if (depthStr.equals("infinity")) {
/*  482 */       depth = this.maxDepth;
/*      */     }
/*      */     
/*      */ 
/*  486 */     Node propNode = null;
/*      */     
/*  488 */     if (req.getContentLengthLong() > 0L) {
/*  489 */       DocumentBuilder documentBuilder = getDocumentBuilder();
/*      */       try
/*      */       {
/*  492 */         Document document = documentBuilder.parse(new InputSource(req.getInputStream()));
/*      */         
/*      */ 
/*      */ 
/*  496 */         Element rootElement = document.getDocumentElement();
/*  497 */         NodeList childList = rootElement.getChildNodes();
/*      */         
/*  499 */         for (int i = 0; i < childList.getLength(); i++) {
/*  500 */           Node currentNode = childList.item(i);
/*  501 */           switch (currentNode.getNodeType()) {
/*      */           case 3: 
/*      */             break;
/*      */           case 1: 
/*  505 */             if (currentNode.getNodeName().endsWith("prop")) {
/*  506 */               type = 0;
/*  507 */               propNode = currentNode;
/*      */             }
/*  509 */             if (currentNode.getNodeName().endsWith("propname")) {
/*  510 */               type = 2;
/*      */             }
/*  512 */             if (currentNode.getNodeName().endsWith("allprop")) {
/*  513 */               type = 1;
/*      */             }
/*      */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (SAXException e) {
/*  520 */         resp.sendError(400);
/*  521 */         return;
/*      */       }
/*      */       catch (IOException e) {
/*  524 */         resp.sendError(400);
/*  525 */         return;
/*      */       }
/*      */     }
/*      */     
/*  529 */     if (type == 0) {
/*  530 */       properties = new Vector();
/*      */       
/*      */ 
/*  533 */       NodeList childList = propNode.getChildNodes();
/*      */       
/*  535 */       for (int i = 0; i < childList.getLength(); i++) {
/*  536 */         Node currentNode = childList.item(i);
/*  537 */         switch (currentNode.getNodeType()) {
/*      */         case 3: 
/*      */           break;
/*      */         case 1: 
/*  541 */           String nodeName = currentNode.getNodeName();
/*  542 */           String propertyName = null;
/*  543 */           if (nodeName.indexOf(':') != -1) {
/*  544 */             propertyName = nodeName.substring(nodeName.indexOf(':') + 1);
/*      */           }
/*      */           else {
/*  547 */             propertyName = nodeName;
/*      */           }
/*      */           
/*  550 */           properties.addElement(propertyName);
/*      */         }
/*      */         
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  557 */     WebResource resource = this.resources.getResource(path);
/*      */     
/*  559 */     if (!resource.exists()) {
/*  560 */       int slash = path.lastIndexOf('/');
/*  561 */       if (slash != -1) {
/*  562 */         String parentPath = path.substring(0, slash);
/*  563 */         Vector<String> currentLockNullResources = (Vector)this.lockNullResources.get(parentPath);
/*      */         
/*  565 */         if (currentLockNullResources != null) {
/*  566 */           Enumeration<String> lockNullResourcesList = currentLockNullResources.elements();
/*      */           
/*  568 */           while (lockNullResourcesList.hasMoreElements()) {
/*  569 */             String lockNullPath = (String)lockNullResourcesList.nextElement();
/*      */             
/*  571 */             if (lockNullPath.equals(path)) {
/*  572 */               resp.setStatus(207);
/*  573 */               resp.setContentType("text/xml; charset=UTF-8");
/*      */               
/*  575 */               XMLWriter generatedXML = new XMLWriter(resp.getWriter());
/*      */               
/*  577 */               generatedXML.writeXMLHeader();
/*  578 */               generatedXML.writeElement("D", "DAV:", "multistatus", 0);
/*      */               
/*  580 */               parseLockNullProperties(req, generatedXML, lockNullPath, type, properties);
/*      */               
/*      */ 
/*  583 */               generatedXML.writeElement("D", "multistatus", 1);
/*      */               
/*  585 */               generatedXML.sendData();
/*  586 */               return;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  593 */     if (!resource.exists()) {
/*  594 */       resp.sendError(404, path);
/*  595 */       return;
/*      */     }
/*      */     
/*  598 */     resp.setStatus(207);
/*      */     
/*  600 */     resp.setContentType("text/xml; charset=UTF-8");
/*      */     
/*      */ 
/*  603 */     XMLWriter generatedXML = new XMLWriter(resp.getWriter());
/*  604 */     generatedXML.writeXMLHeader();
/*      */     
/*  606 */     generatedXML.writeElement("D", "DAV:", "multistatus", 0);
/*      */     
/*      */ 
/*  609 */     if (depth == 0) {
/*  610 */       parseProperties(req, generatedXML, path, type, properties);
/*      */     }
/*      */     else
/*      */     {
/*  614 */       Stack<String> stack = new Stack();
/*  615 */       stack.push(path);
/*      */       
/*      */ 
/*  618 */       Stack<String> stackBelow = new Stack();
/*      */       
/*  620 */       while ((!stack.isEmpty()) && (depth >= 0))
/*      */       {
/*  622 */         String currentPath = (String)stack.pop();
/*  623 */         parseProperties(req, generatedXML, currentPath, type, properties);
/*      */         
/*      */ 
/*  626 */         resource = this.resources.getResource(currentPath);
/*      */         
/*  628 */         if ((resource.isDirectory()) && (depth > 0))
/*      */         {
/*  630 */           String[] entries = this.resources.list(currentPath);
/*  631 */           for (String entry : entries) {
/*  632 */             String newPath = currentPath;
/*  633 */             if (!newPath.endsWith("/"))
/*  634 */               newPath = newPath + "/";
/*  635 */             newPath = newPath + entry;
/*  636 */             stackBelow.push(newPath);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  641 */           String lockPath = currentPath;
/*  642 */           if (lockPath.endsWith("/")) {
/*  643 */             lockPath = lockPath.substring(0, lockPath.length() - 1);
/*      */           }
/*  645 */           Vector<String> currentLockNullResources = (Vector)this.lockNullResources.get(lockPath);
/*      */           
/*  647 */           if (currentLockNullResources != null) {
/*  648 */             Enumeration<String> lockNullResourcesList = currentLockNullResources.elements();
/*      */             
/*  650 */             while (lockNullResourcesList.hasMoreElements()) {
/*  651 */               String lockNullPath = (String)lockNullResourcesList.nextElement();
/*      */               
/*  653 */               parseLockNullProperties(req, generatedXML, lockNullPath, type, properties);
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  661 */         if (stack.isEmpty()) {
/*  662 */           depth--;
/*  663 */           stack = stackBelow;
/*  664 */           stackBelow = new Stack();
/*      */         }
/*      */         
/*  667 */         generatedXML.sendData();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  672 */     generatedXML.writeElement("D", "multistatus", 1);
/*      */     
/*  674 */     generatedXML.sendData();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doProppatch(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws IOException
/*      */   {
/*  688 */     if (this.readOnly) {
/*  689 */       resp.sendError(403);
/*  690 */       return;
/*      */     }
/*      */     
/*  693 */     if (isLocked(req)) {
/*  694 */       resp.sendError(423);
/*  695 */       return;
/*      */     }
/*      */     
/*  698 */     resp.sendError(501);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doMkcol(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  713 */     if (this.readOnly) {
/*  714 */       resp.sendError(403);
/*  715 */       return;
/*      */     }
/*      */     
/*  718 */     if (isLocked(req)) {
/*  719 */       resp.sendError(423);
/*  720 */       return;
/*      */     }
/*      */     
/*  723 */     String path = getRelativePath(req);
/*      */     
/*  725 */     WebResource resource = this.resources.getResource(path);
/*      */     
/*      */ 
/*      */ 
/*  729 */     if (resource.exists())
/*      */     {
/*  731 */       StringBuilder methodsAllowed = determineMethodsAllowed(req);
/*      */       
/*  733 */       resp.addHeader("Allow", methodsAllowed.toString());
/*      */       
/*  735 */       resp.sendError(405);
/*  736 */       return;
/*      */     }
/*      */     
/*  739 */     if (req.getContentLengthLong() > 0L) {
/*  740 */       DocumentBuilder documentBuilder = getDocumentBuilder();
/*      */       try
/*      */       {
/*  743 */         documentBuilder.parse(new InputSource(req.getInputStream()));
/*      */         
/*  745 */         resp.sendError(501);
/*  746 */         return;
/*      */       }
/*      */       catch (SAXException saxe)
/*      */       {
/*  750 */         resp.sendError(415);
/*  751 */         return;
/*      */       }
/*      */     }
/*      */     
/*  755 */     if (this.resources.mkdir(path)) {
/*  756 */       resp.setStatus(201);
/*      */       
/*  758 */       this.lockNullResources.remove(path);
/*      */     } else {
/*  760 */       resp.sendError(409, WebdavStatus.getStatusText(409));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doDelete(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  778 */     if (this.readOnly) {
/*  779 */       resp.sendError(403);
/*  780 */       return;
/*      */     }
/*      */     
/*  783 */     if (isLocked(req)) {
/*  784 */       resp.sendError(423);
/*  785 */       return;
/*      */     }
/*      */     
/*  788 */     deleteResource(req, resp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doPut(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  806 */     if (isLocked(req)) {
/*  807 */       resp.sendError(423);
/*  808 */       return;
/*      */     }
/*      */     
/*  811 */     super.doPut(req, resp);
/*      */     
/*  813 */     String path = getRelativePath(req);
/*      */     
/*      */ 
/*  816 */     this.lockNullResources.remove(path);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doCopy(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws IOException
/*      */   {
/*  829 */     if (this.readOnly) {
/*  830 */       resp.sendError(403);
/*  831 */       return;
/*      */     }
/*      */     
/*  834 */     copyResource(req, resp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doMove(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws IOException
/*      */   {
/*  848 */     if (this.readOnly) {
/*  849 */       resp.sendError(403);
/*  850 */       return;
/*      */     }
/*      */     
/*  853 */     if (isLocked(req)) {
/*  854 */       resp.sendError(423);
/*  855 */       return;
/*      */     }
/*      */     
/*  858 */     String path = getRelativePath(req);
/*      */     
/*  860 */     if (copyResource(req, resp)) {
/*  861 */       deleteResource(path, req, resp, false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doLock(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  877 */     if (this.readOnly) {
/*  878 */       resp.sendError(403);
/*  879 */       return;
/*      */     }
/*      */     
/*  882 */     if (isLocked(req)) {
/*  883 */       resp.sendError(423);
/*  884 */       return;
/*      */     }
/*      */     
/*  887 */     LockInfo lock = new LockInfo(null);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  893 */     String depthStr = req.getHeader("Depth");
/*      */     
/*  895 */     if (depthStr == null) {
/*  896 */       lock.depth = this.maxDepth;
/*      */     }
/*  898 */     else if (depthStr.equals("0")) {
/*  899 */       lock.depth = 0;
/*      */     } else {
/*  901 */       lock.depth = this.maxDepth;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  907 */     int lockDuration = 3600;
/*  908 */     String lockDurationStr = req.getHeader("Timeout");
/*  909 */     if (lockDurationStr == null) {
/*  910 */       lockDuration = 3600;
/*      */     } else {
/*  912 */       int commaPos = lockDurationStr.indexOf(',');
/*      */       
/*  914 */       if (commaPos != -1) {
/*  915 */         lockDurationStr = lockDurationStr.substring(0, commaPos);
/*      */       }
/*  917 */       if (lockDurationStr.startsWith("Second-")) {
/*  918 */         lockDuration = Integer.parseInt(lockDurationStr.substring(7));
/*      */       }
/*  920 */       else if (lockDurationStr.equalsIgnoreCase("infinity")) {
/*  921 */         lockDuration = 604800;
/*      */       } else {
/*      */         try {
/*  924 */           lockDuration = Integer.parseInt(lockDurationStr);
/*      */         } catch (NumberFormatException e) {
/*  926 */           lockDuration = 604800;
/*      */         }
/*      */       }
/*      */       
/*  930 */       if (lockDuration == 0) {
/*  931 */         lockDuration = 3600;
/*      */       }
/*  933 */       if (lockDuration > 604800) {
/*  934 */         lockDuration = 604800;
/*      */       }
/*      */     }
/*  937 */     lock.expiresAt = (System.currentTimeMillis() + lockDuration * 1000);
/*      */     
/*  939 */     int lockRequestType = 0;
/*      */     
/*  941 */     Node lockInfoNode = null;
/*      */     
/*  943 */     DocumentBuilder documentBuilder = getDocumentBuilder();
/*      */     try
/*      */     {
/*  946 */       Document document = documentBuilder.parse(new InputSource(req.getInputStream()));
/*      */       
/*      */ 
/*      */ 
/*  950 */       Element rootElement = document.getDocumentElement();
/*  951 */       lockInfoNode = rootElement;
/*      */     } catch (IOException e) {
/*  953 */       lockRequestType = 1;
/*      */     } catch (SAXException e) {
/*  955 */       lockRequestType = 1;
/*      */     }
/*      */     
/*  958 */     if (lockInfoNode != null)
/*      */     {
/*      */ 
/*      */ 
/*  962 */       NodeList childList = lockInfoNode.getChildNodes();
/*  963 */       StringWriter strWriter = null;
/*  964 */       DOMWriter domWriter = null;
/*      */       
/*  966 */       Node lockScopeNode = null;
/*  967 */       Node lockTypeNode = null;
/*  968 */       Node lockOwnerNode = null;
/*      */       
/*  970 */       for (int i = 0; i < childList.getLength(); i++) {
/*  971 */         Node currentNode = childList.item(i);
/*  972 */         switch (currentNode.getNodeType()) {
/*      */         case 3: 
/*      */           break;
/*      */         case 1: 
/*  976 */           String nodeName = currentNode.getNodeName();
/*  977 */           if (nodeName.endsWith("lockscope")) {
/*  978 */             lockScopeNode = currentNode;
/*      */           }
/*  980 */           if (nodeName.endsWith("locktype")) {
/*  981 */             lockTypeNode = currentNode;
/*      */           }
/*  983 */           if (nodeName.endsWith("owner")) {
/*  984 */             lockOwnerNode = currentNode;
/*      */           }
/*      */           break;
/*      */         }
/*      */         
/*      */       }
/*  990 */       if (lockScopeNode != null)
/*      */       {
/*  992 */         childList = lockScopeNode.getChildNodes();
/*  993 */         for (int i = 0; i < childList.getLength(); i++) {
/*  994 */           Node currentNode = childList.item(i);
/*  995 */           switch (currentNode.getNodeType()) {
/*      */           case 3: 
/*      */             break;
/*      */           case 1: 
/*  999 */             String tempScope = currentNode.getNodeName();
/* 1000 */             if (tempScope.indexOf(':') != -1) {
/* 1001 */               lock.scope = tempScope.substring(tempScope.indexOf(':') + 1);
/*      */             }
/*      */             else {
/* 1004 */               lock.scope = tempScope;
/*      */             }
/*      */             break;
/*      */           }
/*      */           
/*      */         }
/* 1010 */         if (lock.scope == null)
/*      */         {
/* 1012 */           resp.setStatus(400);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1017 */         resp.setStatus(400);
/*      */       }
/*      */       
/* 1020 */       if (lockTypeNode != null)
/*      */       {
/* 1022 */         childList = lockTypeNode.getChildNodes();
/* 1023 */         for (int i = 0; i < childList.getLength(); i++) {
/* 1024 */           Node currentNode = childList.item(i);
/* 1025 */           switch (currentNode.getNodeType()) {
/*      */           case 3: 
/*      */             break;
/*      */           case 1: 
/* 1029 */             String tempType = currentNode.getNodeName();
/* 1030 */             if (tempType.indexOf(':') != -1) {
/* 1031 */               lock.type = tempType.substring(tempType.indexOf(':') + 1);
/*      */             }
/*      */             else {
/* 1034 */               lock.type = tempType;
/*      */             }
/*      */             break;
/*      */           }
/*      */           
/*      */         }
/* 1040 */         if (lock.type == null)
/*      */         {
/* 1042 */           resp.setStatus(400);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1047 */         resp.setStatus(400);
/*      */       }
/*      */       
/* 1050 */       if (lockOwnerNode != null)
/*      */       {
/* 1052 */         childList = lockOwnerNode.getChildNodes();
/* 1053 */         for (int i = 0; i < childList.getLength(); i++) {
/* 1054 */           Node currentNode = childList.item(i);
/* 1055 */           switch (currentNode.getNodeType()) {
/*      */           case 3: 
/* 1057 */             lock.owner += currentNode.getNodeValue();
/* 1058 */             break;
/*      */           case 1: 
/* 1060 */             strWriter = new StringWriter();
/* 1061 */             domWriter = new DOMWriter(strWriter, true);
/* 1062 */             domWriter.print(currentNode);
/* 1063 */             lock.owner += strWriter.toString();
/*      */           }
/*      */           
/*      */         }
/*      */         
/* 1068 */         if (lock.owner == null)
/*      */         {
/* 1070 */           resp.setStatus(400);
/*      */         }
/*      */       }
/*      */       else {
/* 1074 */         lock.owner = "";
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1079 */     String path = getRelativePath(req);
/*      */     
/* 1081 */     lock.path = path;
/*      */     
/* 1083 */     WebResource resource = this.resources.getResource(path);
/*      */     
/* 1085 */     Enumeration<LockInfo> locksList = null;
/*      */     
/* 1087 */     if (lockRequestType == 0)
/*      */     {
/*      */ 
/* 1090 */       String lockTokenStr = req.getServletPath() + "-" + lock.type + "-" + lock.scope + "-" + req.getUserPrincipal() + "-" + lock.depth + "-" + lock.owner + "-" + lock.tokens + "-" + lock.expiresAt + "-" + System.currentTimeMillis() + "-" + this.secret;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1095 */       String lockToken = MD5Encoder.encode(ConcurrentMessageDigest.digestMD5(new byte[][] { lockTokenStr.getBytes(StandardCharsets.ISO_8859_1) }));
/*      */       
/*      */ 
/* 1098 */       if ((resource.isDirectory()) && (lock.depth == this.maxDepth))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1104 */         Vector<String> lockPaths = new Vector();
/* 1105 */         locksList = this.collectionLocks.elements();
/* 1106 */         while (locksList.hasMoreElements()) {
/* 1107 */           LockInfo currentLock = (LockInfo)locksList.nextElement();
/* 1108 */           if (currentLock.hasExpired()) {
/* 1109 */             this.resourceLocks.remove(currentLock.path);
/*      */ 
/*      */           }
/* 1112 */           else if ((currentLock.path.startsWith(lock.path)) && ((currentLock.isExclusive()) || (lock.isExclusive())))
/*      */           {
/*      */ 
/*      */ 
/* 1116 */             lockPaths.addElement(currentLock.path);
/*      */           }
/*      */         }
/* 1119 */         locksList = this.resourceLocks.elements();
/* 1120 */         while (locksList.hasMoreElements()) {
/* 1121 */           LockInfo currentLock = (LockInfo)locksList.nextElement();
/* 1122 */           if (currentLock.hasExpired()) {
/* 1123 */             this.resourceLocks.remove(currentLock.path);
/*      */ 
/*      */           }
/* 1126 */           else if ((currentLock.path.startsWith(lock.path)) && ((currentLock.isExclusive()) || (lock.isExclusive())))
/*      */           {
/*      */ 
/*      */ 
/* 1130 */             lockPaths.addElement(currentLock.path);
/*      */           }
/*      */         }
/*      */         
/* 1134 */         if (!lockPaths.isEmpty())
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 1139 */           Enumeration<String> lockPathsList = lockPaths.elements();
/*      */           
/* 1141 */           resp.setStatus(409);
/*      */           
/* 1143 */           XMLWriter generatedXML = new XMLWriter();
/* 1144 */           generatedXML.writeXMLHeader();
/*      */           
/* 1146 */           generatedXML.writeElement("D", "DAV:", "multistatus", 0);
/*      */           
/*      */ 
/* 1149 */           while (lockPathsList.hasMoreElements()) {
/* 1150 */             generatedXML.writeElement("D", "response", 0);
/*      */             
/* 1152 */             generatedXML.writeElement("D", "href", 0);
/*      */             
/* 1154 */             generatedXML.writeText((String)lockPathsList.nextElement());
/* 1155 */             generatedXML.writeElement("D", "href", 1);
/*      */             
/* 1157 */             generatedXML.writeElement("D", "status", 0);
/*      */             
/* 1159 */             generatedXML.writeText("HTTP/1.1 423 " + WebdavStatus.getStatusText(423));
/*      */             
/*      */ 
/*      */ 
/* 1163 */             generatedXML.writeElement("D", "status", 1);
/*      */             
/*      */ 
/* 1166 */             generatedXML.writeElement("D", "response", 1);
/*      */           }
/*      */           
/*      */ 
/* 1170 */           generatedXML.writeElement("D", "multistatus", 1);
/*      */           
/*      */ 
/* 1173 */           Writer writer = resp.getWriter();
/* 1174 */           writer.write(generatedXML.toString());
/* 1175 */           writer.close();
/*      */           
/* 1177 */           return;
/*      */         }
/*      */         
/*      */ 
/* 1181 */         boolean addLock = true;
/*      */         
/*      */ 
/* 1184 */         locksList = this.collectionLocks.elements();
/* 1185 */         while (locksList.hasMoreElements())
/*      */         {
/* 1187 */           LockInfo currentLock = (LockInfo)locksList.nextElement();
/* 1188 */           if (currentLock.path.equals(lock.path))
/*      */           {
/* 1190 */             if (currentLock.isExclusive()) {
/* 1191 */               resp.sendError(423);
/* 1192 */               return;
/*      */             }
/* 1194 */             if (lock.isExclusive()) {
/* 1195 */               resp.sendError(423);
/* 1196 */               return;
/*      */             }
/*      */             
/*      */ 
/* 1200 */             currentLock.tokens.addElement(lockToken);
/* 1201 */             lock = currentLock;
/* 1202 */             addLock = false;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1208 */         if (addLock) {
/* 1209 */           lock.tokens.addElement(lockToken);
/* 1210 */           this.collectionLocks.addElement(lock);
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 1218 */         LockInfo presentLock = (LockInfo)this.resourceLocks.get(lock.path);
/* 1219 */         if (presentLock != null)
/*      */         {
/* 1221 */           if ((presentLock.isExclusive()) || (lock.isExclusive()))
/*      */           {
/*      */ 
/* 1224 */             resp.sendError(412);
/* 1225 */             return;
/*      */           }
/* 1227 */           presentLock.tokens.addElement(lockToken);
/* 1228 */           lock = presentLock;
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 1233 */           lock.tokens.addElement(lockToken);
/* 1234 */           this.resourceLocks.put(lock.path, lock);
/*      */           
/*      */ 
/* 1237 */           if (!resource.exists())
/*      */           {
/*      */ 
/* 1240 */             int slash = lock.path.lastIndexOf('/');
/* 1241 */             String parentPath = lock.path.substring(0, slash);
/*      */             
/* 1243 */             Vector<String> lockNulls = (Vector)this.lockNullResources.get(parentPath);
/*      */             
/* 1245 */             if (lockNulls == null) {
/* 1246 */               lockNulls = new Vector();
/* 1247 */               this.lockNullResources.put(parentPath, lockNulls);
/*      */             }
/*      */             
/* 1250 */             lockNulls.addElement(lock.path);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1255 */           resp.addHeader("Lock-Token", "<opaquelocktoken:" + lockToken + ">");
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1263 */     if (lockRequestType == 1)
/*      */     {
/* 1265 */       String ifHeader = req.getHeader("If");
/* 1266 */       if (ifHeader == null) {
/* 1267 */         ifHeader = "";
/*      */       }
/*      */       
/*      */ 
/* 1271 */       LockInfo toRenew = (LockInfo)this.resourceLocks.get(path);
/* 1272 */       Enumeration<String> tokenList = null;
/*      */       
/* 1274 */       if (toRenew != null)
/*      */       {
/* 1276 */         tokenList = toRenew.tokens.elements();
/* 1277 */         while (tokenList.hasMoreElements()) {
/* 1278 */           String token = (String)tokenList.nextElement();
/* 1279 */           if (ifHeader.indexOf(token) != -1) {
/* 1280 */             toRenew.expiresAt = lock.expiresAt;
/* 1281 */             lock = toRenew;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1288 */       Enumeration<LockInfo> collectionLocksList = this.collectionLocks.elements();
/*      */       
/* 1290 */       while (collectionLocksList.hasMoreElements()) {
/* 1291 */         toRenew = (LockInfo)collectionLocksList.nextElement();
/* 1292 */         if (path.equals(toRenew.path))
/*      */         {
/* 1294 */           tokenList = toRenew.tokens.elements();
/* 1295 */           while (tokenList.hasMoreElements()) {
/* 1296 */             String token = (String)tokenList.nextElement();
/* 1297 */             if (ifHeader.indexOf(token) != -1) {
/* 1298 */               toRenew.expiresAt = lock.expiresAt;
/* 1299 */               lock = toRenew;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1310 */     XMLWriter generatedXML = new XMLWriter();
/* 1311 */     generatedXML.writeXMLHeader();
/* 1312 */     generatedXML.writeElement("D", "DAV:", "prop", 0);
/*      */     
/*      */ 
/* 1315 */     generatedXML.writeElement("D", "lockdiscovery", 0);
/*      */     
/* 1317 */     lock.toXML(generatedXML);
/*      */     
/* 1319 */     generatedXML.writeElement("D", "lockdiscovery", 1);
/*      */     
/* 1321 */     generatedXML.writeElement("D", "prop", 1);
/*      */     
/* 1323 */     resp.setStatus(200);
/* 1324 */     resp.setContentType("text/xml; charset=UTF-8");
/* 1325 */     Writer writer = resp.getWriter();
/* 1326 */     writer.write(generatedXML.toString());
/* 1327 */     writer.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doUnlock(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws IOException
/*      */   {
/* 1341 */     if (this.readOnly) {
/* 1342 */       resp.sendError(403);
/* 1343 */       return;
/*      */     }
/*      */     
/* 1346 */     if (isLocked(req)) {
/* 1347 */       resp.sendError(423);
/* 1348 */       return;
/*      */     }
/*      */     
/* 1351 */     String path = getRelativePath(req);
/*      */     
/* 1353 */     String lockTokenHeader = req.getHeader("Lock-Token");
/* 1354 */     if (lockTokenHeader == null) {
/* 1355 */       lockTokenHeader = "";
/*      */     }
/*      */     
/*      */ 
/* 1359 */     LockInfo lock = (LockInfo)this.resourceLocks.get(path);
/* 1360 */     Enumeration<String> tokenList = null;
/* 1361 */     if (lock != null)
/*      */     {
/*      */ 
/*      */ 
/* 1365 */       tokenList = lock.tokens.elements();
/* 1366 */       while (tokenList.hasMoreElements()) {
/* 1367 */         String token = (String)tokenList.nextElement();
/* 1368 */         if (lockTokenHeader.indexOf(token) != -1) {
/* 1369 */           lock.tokens.removeElement(token);
/*      */         }
/*      */       }
/*      */       
/* 1373 */       if (lock.tokens.isEmpty()) {
/* 1374 */         this.resourceLocks.remove(path);
/*      */         
/* 1376 */         this.lockNullResources.remove(path);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1383 */     Enumeration<LockInfo> collectionLocksList = this.collectionLocks.elements();
/* 1384 */     while (collectionLocksList.hasMoreElements()) {
/* 1385 */       lock = (LockInfo)collectionLocksList.nextElement();
/* 1386 */       if (path.equals(lock.path))
/*      */       {
/* 1388 */         tokenList = lock.tokens.elements();
/* 1389 */         while (tokenList.hasMoreElements()) {
/* 1390 */           String token = (String)tokenList.nextElement();
/* 1391 */           if (lockTokenHeader.indexOf(token) != -1) {
/* 1392 */             lock.tokens.removeElement(token);
/* 1393 */             break;
/*      */           }
/*      */         }
/*      */         
/* 1397 */         if (lock.tokens.isEmpty()) {
/* 1398 */           this.collectionLocks.removeElement(lock);
/*      */           
/* 1400 */           this.lockNullResources.remove(path);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1406 */     resp.setStatus(204);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isLocked(HttpServletRequest req)
/*      */   {
/* 1424 */     String path = getRelativePath(req);
/*      */     
/* 1426 */     String ifHeader = req.getHeader("If");
/* 1427 */     if (ifHeader == null) {
/* 1428 */       ifHeader = "";
/*      */     }
/* 1430 */     String lockTokenHeader = req.getHeader("Lock-Token");
/* 1431 */     if (lockTokenHeader == null) {
/* 1432 */       lockTokenHeader = "";
/*      */     }
/* 1434 */     return isLocked(path, ifHeader + lockTokenHeader);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isLocked(String path, String ifHeader)
/*      */   {
/* 1452 */     LockInfo lock = (LockInfo)this.resourceLocks.get(path);
/* 1453 */     Enumeration<String> tokenList = null;
/* 1454 */     if ((lock != null) && (lock.hasExpired())) {
/* 1455 */       this.resourceLocks.remove(path);
/* 1456 */     } else if (lock != null)
/*      */     {
/*      */ 
/*      */ 
/* 1460 */       tokenList = lock.tokens.elements();
/* 1461 */       boolean tokenMatch = false;
/* 1462 */       while (tokenList.hasMoreElements()) {
/* 1463 */         String token = (String)tokenList.nextElement();
/* 1464 */         if (ifHeader.indexOf(token) != -1) {
/* 1465 */           tokenMatch = true;
/* 1466 */           break;
/*      */         }
/*      */       }
/* 1469 */       if (!tokenMatch) {
/* 1470 */         return true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1476 */     Enumeration<LockInfo> collectionLocksList = this.collectionLocks.elements();
/* 1477 */     while (collectionLocksList.hasMoreElements()) {
/* 1478 */       lock = (LockInfo)collectionLocksList.nextElement();
/* 1479 */       if (lock.hasExpired()) {
/* 1480 */         this.collectionLocks.removeElement(lock);
/* 1481 */       } else if (path.startsWith(lock.path))
/*      */       {
/* 1483 */         tokenList = lock.tokens.elements();
/* 1484 */         boolean tokenMatch = false;
/* 1485 */         while (tokenList.hasMoreElements()) {
/* 1486 */           String token = (String)tokenList.nextElement();
/* 1487 */           if (ifHeader.indexOf(token) != -1) {
/* 1488 */             tokenMatch = true;
/* 1489 */             break;
/*      */           }
/*      */         }
/* 1492 */         if (!tokenMatch) {
/* 1493 */           return true;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1498 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean copyResource(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws IOException
/*      */   {
/* 1517 */     String destinationPath = req.getHeader("Destination");
/*      */     
/* 1519 */     if (destinationPath == null) {
/* 1520 */       resp.sendError(400);
/* 1521 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 1525 */     destinationPath = UDecoder.URLDecode(destinationPath, "UTF8");
/*      */     
/* 1527 */     int protocolIndex = destinationPath.indexOf("://");
/* 1528 */     if (protocolIndex >= 0)
/*      */     {
/*      */ 
/* 1531 */       int firstSeparator = destinationPath.indexOf('/', protocolIndex + 4);
/*      */       
/* 1533 */       if (firstSeparator < 0) {
/* 1534 */         destinationPath = "/";
/*      */       } else {
/* 1536 */         destinationPath = destinationPath.substring(firstSeparator);
/*      */       }
/*      */     } else {
/* 1539 */       String hostName = req.getServerName();
/* 1540 */       if ((hostName != null) && (destinationPath.startsWith(hostName))) {
/* 1541 */         destinationPath = destinationPath.substring(hostName.length());
/*      */       }
/*      */       
/* 1544 */       int portIndex = destinationPath.indexOf(':');
/* 1545 */       if (portIndex >= 0) {
/* 1546 */         destinationPath = destinationPath.substring(portIndex);
/*      */       }
/*      */       
/* 1549 */       if (destinationPath.startsWith(":")) {
/* 1550 */         int firstSeparator = destinationPath.indexOf('/');
/* 1551 */         if (firstSeparator < 0) {
/* 1552 */           destinationPath = "/";
/*      */         } else {
/* 1554 */           destinationPath = destinationPath.substring(firstSeparator);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1561 */     destinationPath = RequestUtil.normalize(destinationPath);
/*      */     
/* 1563 */     String contextPath = req.getContextPath();
/* 1564 */     if ((contextPath != null) && (destinationPath.startsWith(contextPath)))
/*      */     {
/* 1566 */       destinationPath = destinationPath.substring(contextPath.length());
/*      */     }
/*      */     
/* 1569 */     String pathInfo = req.getPathInfo();
/* 1570 */     if (pathInfo != null) {
/* 1571 */       String servletPath = req.getServletPath();
/* 1572 */       if ((servletPath != null) && (destinationPath.startsWith(servletPath)))
/*      */       {
/* 1574 */         destinationPath = destinationPath.substring(servletPath.length());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1579 */     if (this.debug > 0) {
/* 1580 */       log("Dest path :" + destinationPath);
/*      */     }
/*      */     
/* 1583 */     if (isSpecialPath(destinationPath)) {
/* 1584 */       resp.sendError(403);
/* 1585 */       return false;
/*      */     }
/*      */     
/* 1588 */     String path = getRelativePath(req);
/*      */     
/* 1590 */     if (destinationPath.equals(path)) {
/* 1591 */       resp.sendError(403);
/* 1592 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1597 */     boolean overwrite = true;
/* 1598 */     String overwriteHeader = req.getHeader("Overwrite");
/*      */     
/* 1600 */     if (overwriteHeader != null) {
/* 1601 */       if (overwriteHeader.equalsIgnoreCase("T")) {
/* 1602 */         overwrite = true;
/*      */       } else {
/* 1604 */         overwrite = false;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1610 */     WebResource destination = this.resources.getResource(destinationPath);
/*      */     
/* 1612 */     if (overwrite)
/*      */     {
/* 1614 */       if (destination.exists()) {
/* 1615 */         if (!deleteResource(destinationPath, req, resp, true)) {
/* 1616 */           return false;
/*      */         }
/*      */       } else {
/* 1619 */         resp.setStatus(201);
/*      */       }
/*      */       
/*      */     }
/* 1623 */     else if (destination.exists()) {
/* 1624 */       resp.sendError(412);
/* 1625 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1631 */     Hashtable<String, Integer> errorList = new Hashtable();
/*      */     
/* 1633 */     boolean result = copyResource(errorList, path, destinationPath);
/*      */     
/* 1635 */     if ((!result) || (!errorList.isEmpty())) {
/* 1636 */       if (errorList.size() == 1) {
/* 1637 */         resp.sendError(((Integer)errorList.elements().nextElement()).intValue());
/*      */       } else {
/* 1639 */         sendReport(req, resp, errorList);
/*      */       }
/* 1641 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 1645 */     if (destination.exists()) {
/* 1646 */       resp.setStatus(204);
/*      */     } else {
/* 1648 */       resp.setStatus(201);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1653 */     this.lockNullResources.remove(destinationPath);
/*      */     
/* 1655 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean copyResource(Hashtable<String, Integer> errorList, String source, String dest)
/*      */   {
/* 1671 */     if (this.debug > 1) {
/* 1672 */       log("Copy: " + source + " To: " + dest);
/*      */     }
/* 1674 */     WebResource sourceResource = this.resources.getResource(source);
/*      */     
/* 1676 */     if (sourceResource.isDirectory()) {
/* 1677 */       if (!this.resources.mkdir(dest)) {
/* 1678 */         WebResource destResource = this.resources.getResource(dest);
/* 1679 */         if (!destResource.isDirectory()) {
/* 1680 */           errorList.put(dest, Integer.valueOf(409));
/* 1681 */           return false;
/*      */         }
/*      */       }
/*      */       
/* 1685 */       String[] entries = this.resources.list(source);
/* 1686 */       for (String entry : entries) {
/* 1687 */         String childDest = dest;
/* 1688 */         if (!childDest.equals("/")) {
/* 1689 */           childDest = childDest + "/";
/*      */         }
/* 1691 */         childDest = childDest + entry;
/* 1692 */         String childSrc = source;
/* 1693 */         if (!childSrc.equals("/")) {
/* 1694 */           childSrc = childSrc + "/";
/*      */         }
/* 1696 */         childSrc = childSrc + entry;
/* 1697 */         copyResource(errorList, childSrc, childDest);
/*      */       }
/* 1699 */     } else if (sourceResource.isFile()) {
/* 1700 */       WebResource destResource = this.resources.getResource(dest);
/* 1701 */       if ((!destResource.exists()) && (!destResource.getWebappPath().endsWith("/"))) {
/* 1702 */         int lastSlash = destResource.getWebappPath().lastIndexOf('/');
/* 1703 */         if (lastSlash > 0) {
/* 1704 */           String parent = destResource.getWebappPath().substring(0, lastSlash);
/* 1705 */           WebResource parentResource = this.resources.getResource(parent);
/* 1706 */           if (!parentResource.isDirectory()) {
/* 1707 */             errorList.put(source, Integer.valueOf(409));
/* 1708 */             return false;
/*      */           }
/*      */         }
/*      */       }
/* 1712 */       if (!this.resources.write(dest, sourceResource.getInputStream(), false))
/*      */       {
/* 1714 */         errorList.put(source, Integer.valueOf(500));
/*      */         
/* 1716 */         return false;
/*      */       }
/*      */     } else {
/* 1719 */       errorList.put(source, Integer.valueOf(500));
/*      */       
/* 1721 */       return false;
/*      */     }
/* 1723 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean deleteResource(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws IOException
/*      */   {
/* 1739 */     String path = getRelativePath(req);
/*      */     
/* 1741 */     return deleteResource(path, req, resp, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean deleteResource(String path, HttpServletRequest req, HttpServletResponse resp, boolean setStatus)
/*      */     throws IOException
/*      */   {
/* 1761 */     String ifHeader = req.getHeader("If");
/* 1762 */     if (ifHeader == null) {
/* 1763 */       ifHeader = "";
/*      */     }
/* 1765 */     String lockTokenHeader = req.getHeader("Lock-Token");
/* 1766 */     if (lockTokenHeader == null) {
/* 1767 */       lockTokenHeader = "";
/*      */     }
/* 1769 */     if (isLocked(path, ifHeader + lockTokenHeader)) {
/* 1770 */       resp.sendError(423);
/* 1771 */       return false;
/*      */     }
/*      */     
/* 1774 */     WebResource resource = this.resources.getResource(path);
/*      */     
/* 1776 */     if (!resource.exists()) {
/* 1777 */       resp.sendError(404);
/* 1778 */       return false;
/*      */     }
/*      */     
/* 1781 */     if (!resource.isDirectory()) {
/* 1782 */       if (!resource.delete()) {
/* 1783 */         resp.sendError(500);
/* 1784 */         return false;
/*      */       }
/*      */     }
/*      */     else {
/* 1788 */       Hashtable<String, Integer> errorList = new Hashtable();
/*      */       
/* 1790 */       deleteCollection(req, path, errorList);
/* 1791 */       if (!resource.delete()) {
/* 1792 */         errorList.put(path, Integer.valueOf(500));
/*      */       }
/*      */       
/*      */ 
/* 1796 */       if (!errorList.isEmpty()) {
/* 1797 */         sendReport(req, resp, errorList);
/* 1798 */         return false;
/*      */       }
/*      */     }
/* 1801 */     if (setStatus) {
/* 1802 */       resp.setStatus(204);
/*      */     }
/* 1804 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void deleteCollection(HttpServletRequest req, String path, Hashtable<String, Integer> errorList)
/*      */   {
/* 1818 */     if (this.debug > 1) {
/* 1819 */       log("Delete:" + path);
/*      */     }
/*      */     
/* 1822 */     if (isSpecialPath(path)) {
/* 1823 */       errorList.put(path, Integer.valueOf(403));
/* 1824 */       return;
/*      */     }
/*      */     
/* 1827 */     String ifHeader = req.getHeader("If");
/* 1828 */     if (ifHeader == null) {
/* 1829 */       ifHeader = "";
/*      */     }
/* 1831 */     String lockTokenHeader = req.getHeader("Lock-Token");
/* 1832 */     if (lockTokenHeader == null) {
/* 1833 */       lockTokenHeader = "";
/*      */     }
/* 1835 */     String[] entries = this.resources.list(path);
/*      */     
/* 1837 */     for (String entry : entries) {
/* 1838 */       String childName = path;
/* 1839 */       if (!childName.equals("/"))
/* 1840 */         childName = childName + "/";
/* 1841 */       childName = childName + entry;
/*      */       
/* 1843 */       if (isLocked(childName, ifHeader + lockTokenHeader))
/*      */       {
/* 1845 */         errorList.put(childName, Integer.valueOf(423));
/*      */       }
/*      */       else {
/* 1848 */         WebResource childResource = this.resources.getResource(childName);
/* 1849 */         if (childResource.isDirectory()) {
/* 1850 */           deleteCollection(req, childName, errorList);
/*      */         }
/*      */         
/* 1853 */         if ((!childResource.delete()) && 
/* 1854 */           (!childResource.isDirectory()))
/*      */         {
/*      */ 
/* 1857 */           errorList.put(childName, Integer.valueOf(500));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void sendReport(HttpServletRequest req, HttpServletResponse resp, Hashtable<String, Integer> errorList)
/*      */     throws IOException
/*      */   {
/* 1879 */     resp.setStatus(207);
/*      */     
/* 1881 */     String absoluteUri = req.getRequestURI();
/* 1882 */     String relativePath = getRelativePath(req);
/*      */     
/* 1884 */     XMLWriter generatedXML = new XMLWriter();
/* 1885 */     generatedXML.writeXMLHeader();
/*      */     
/* 1887 */     generatedXML.writeElement("D", "DAV:", "multistatus", 0);
/*      */     
/*      */ 
/* 1890 */     Enumeration<String> pathList = errorList.keys();
/* 1891 */     while (pathList.hasMoreElements())
/*      */     {
/* 1893 */       String errorPath = (String)pathList.nextElement();
/* 1894 */       int errorCode = ((Integer)errorList.get(errorPath)).intValue();
/*      */       
/* 1896 */       generatedXML.writeElement("D", "response", 0);
/*      */       
/* 1898 */       generatedXML.writeElement("D", "href", 0);
/* 1899 */       String toAppend = errorPath.substring(relativePath.length());
/* 1900 */       if (!toAppend.startsWith("/"))
/* 1901 */         toAppend = "/" + toAppend;
/* 1902 */       generatedXML.writeText(absoluteUri + toAppend);
/* 1903 */       generatedXML.writeElement("D", "href", 1);
/* 1904 */       generatedXML.writeElement("D", "status", 0);
/* 1905 */       generatedXML.writeText("HTTP/1.1 " + errorCode + " " + WebdavStatus.getStatusText(errorCode));
/*      */       
/* 1907 */       generatedXML.writeElement("D", "status", 1);
/*      */       
/* 1909 */       generatedXML.writeElement("D", "response", 1);
/*      */     }
/*      */     
/*      */ 
/* 1913 */     generatedXML.writeElement("D", "multistatus", 1);
/*      */     
/* 1915 */     Writer writer = resp.getWriter();
/* 1916 */     writer.write(generatedXML.toString());
/* 1917 */     writer.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void parseProperties(HttpServletRequest req, XMLWriter generatedXML, String path, int type, Vector<String> propertiesVector)
/*      */   {
/* 1939 */     if (isSpecialPath(path)) {
/* 1940 */       return;
/*      */     }
/* 1942 */     WebResource resource = this.resources.getResource(path);
/* 1943 */     if (!resource.exists())
/*      */     {
/*      */ 
/* 1946 */       return;
/*      */     }
/*      */     
/* 1949 */     String href = req.getContextPath() + req.getServletPath();
/* 1950 */     if ((href.endsWith("/")) && (path.startsWith("/"))) {
/* 1951 */       href = href + path.substring(1);
/*      */     } else
/* 1953 */       href = href + path;
/* 1954 */     if ((resource.isDirectory()) && (!href.endsWith("/"))) {
/* 1955 */       href = href + "/";
/*      */     }
/* 1957 */     String rewrittenUrl = rewriteUrl(href);
/*      */     
/* 1959 */     generatePropFindResponse(generatedXML, rewrittenUrl, path, type, propertiesVector, resource.isFile(), false, resource.getCreation(), resource.getLastModified(), resource.getContentLength(), getServletContext().getMimeType(resource.getName()), resource.getETag());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void parseLockNullProperties(HttpServletRequest req, XMLWriter generatedXML, String path, int type, Vector<String> propertiesVector)
/*      */   {
/* 1982 */     if (isSpecialPath(path)) {
/* 1983 */       return;
/*      */     }
/*      */     
/* 1986 */     LockInfo lock = (LockInfo)this.resourceLocks.get(path);
/*      */     
/* 1988 */     if (lock == null) {
/* 1989 */       return;
/*      */     }
/* 1991 */     String absoluteUri = req.getRequestURI();
/* 1992 */     String relativePath = getRelativePath(req);
/* 1993 */     String toAppend = path.substring(relativePath.length());
/* 1994 */     if (!toAppend.startsWith("/")) {
/* 1995 */       toAppend = "/" + toAppend;
/*      */     }
/* 1997 */     String rewrittenUrl = rewriteUrl(RequestUtil.normalize(absoluteUri + toAppend));
/*      */     
/*      */ 
/* 2000 */     generatePropFindResponse(generatedXML, rewrittenUrl, path, type, propertiesVector, true, true, lock.creationDate.getTime(), lock.creationDate.getTime(), 0L, "", "");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void generatePropFindResponse(XMLWriter generatedXML, String rewrittenUrl, String path, int propFindType, Vector<String> propertiesVector, boolean isFile, boolean isLockNull, long created, long lastModified, long contentLength, String contentType, String eTag)
/*      */   {
/* 2011 */     generatedXML.writeElement("D", "response", 0);
/* 2012 */     String status = "HTTP/1.1 200 " + WebdavStatus.getStatusText(200);
/*      */     
/*      */ 
/*      */ 
/* 2016 */     generatedXML.writeElement("D", "href", 0);
/* 2017 */     generatedXML.writeText(rewrittenUrl);
/* 2018 */     generatedXML.writeElement("D", "href", 1);
/*      */     
/* 2020 */     String resourceName = path;
/* 2021 */     int lastSlash = path.lastIndexOf('/');
/* 2022 */     if (lastSlash != -1) {
/* 2023 */       resourceName = resourceName.substring(lastSlash + 1);
/*      */     }
/* 2025 */     switch (propFindType)
/*      */     {
/*      */ 
/*      */     case 1: 
/* 2029 */       generatedXML.writeElement("D", "propstat", 0);
/* 2030 */       generatedXML.writeElement("D", "prop", 0);
/*      */       
/* 2032 */       generatedXML.writeProperty("D", "creationdate", getISOCreationDate(created));
/* 2033 */       generatedXML.writeElement("D", "displayname", 0);
/* 2034 */       generatedXML.writeData(resourceName);
/* 2035 */       generatedXML.writeElement("D", "displayname", 1);
/* 2036 */       if (isFile) {
/* 2037 */         generatedXML.writeProperty("D", "getlastmodified", FastHttpDateFormat.formatDate(lastModified, null));
/*      */         
/* 2039 */         generatedXML.writeProperty("D", "getcontentlength", Long.toString(contentLength));
/* 2040 */         if (contentType != null) {
/* 2041 */           generatedXML.writeProperty("D", "getcontenttype", contentType);
/*      */         }
/* 2043 */         generatedXML.writeProperty("D", "getetag", eTag);
/* 2044 */         if (isLockNull) {
/* 2045 */           generatedXML.writeElement("D", "resourcetype", 0);
/* 2046 */           generatedXML.writeElement("D", "lock-null", 2);
/* 2047 */           generatedXML.writeElement("D", "resourcetype", 1);
/*      */         } else {
/* 2049 */           generatedXML.writeElement("D", "resourcetype", 2);
/*      */         }
/*      */       } else {
/* 2052 */         generatedXML.writeElement("D", "resourcetype", 0);
/* 2053 */         generatedXML.writeElement("D", "collection", 2);
/* 2054 */         generatedXML.writeElement("D", "resourcetype", 1);
/*      */       }
/*      */       
/* 2057 */       generatedXML.writeProperty("D", "source", "");
/*      */       
/* 2059 */       String supportedLocks = "<D:lockentry><D:lockscope><D:exclusive/></D:lockscope><D:locktype><D:write/></D:locktype></D:lockentry><D:lockentry><D:lockscope><D:shared/></D:lockscope><D:locktype><D:write/></D:locktype></D:lockentry>";
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2066 */       generatedXML.writeElement("D", "supportedlock", 0);
/* 2067 */       generatedXML.writeText(supportedLocks);
/* 2068 */       generatedXML.writeElement("D", "supportedlock", 1);
/*      */       
/* 2070 */       generateLockDiscovery(path, generatedXML);
/*      */       
/* 2072 */       generatedXML.writeElement("D", "prop", 1);
/* 2073 */       generatedXML.writeElement("D", "status", 0);
/* 2074 */       generatedXML.writeText(status);
/* 2075 */       generatedXML.writeElement("D", "status", 1);
/* 2076 */       generatedXML.writeElement("D", "propstat", 1);
/*      */       
/* 2078 */       break;
/*      */     
/*      */ 
/*      */     case 2: 
/* 2082 */       generatedXML.writeElement("D", "propstat", 0);
/* 2083 */       generatedXML.writeElement("D", "prop", 0);
/*      */       
/* 2085 */       generatedXML.writeElement("D", "creationdate", 2);
/* 2086 */       generatedXML.writeElement("D", "displayname", 2);
/* 2087 */       if (isFile) {
/* 2088 */         generatedXML.writeElement("D", "getcontentlanguage", 2);
/* 2089 */         generatedXML.writeElement("D", "getcontentlength", 2);
/* 2090 */         generatedXML.writeElement("D", "getcontenttype", 2);
/* 2091 */         generatedXML.writeElement("D", "getetag", 2);
/* 2092 */         generatedXML.writeElement("D", "getlastmodified", 2);
/*      */       }
/* 2094 */       generatedXML.writeElement("D", "resourcetype", 2);
/* 2095 */       generatedXML.writeElement("D", "source", 2);
/* 2096 */       generatedXML.writeElement("D", "lockdiscovery", 2);
/*      */       
/* 2098 */       generatedXML.writeElement("D", "prop", 1);
/* 2099 */       generatedXML.writeElement("D", "status", 0);
/* 2100 */       generatedXML.writeText(status);
/* 2101 */       generatedXML.writeElement("D", "status", 1);
/* 2102 */       generatedXML.writeElement("D", "propstat", 1);
/*      */       
/* 2104 */       break;
/*      */     
/*      */ 
/*      */     case 0: 
/* 2108 */       Vector<String> propertiesNotFound = new Vector();
/*      */       
/*      */ 
/*      */ 
/* 2112 */       generatedXML.writeElement("D", "propstat", 0);
/* 2113 */       generatedXML.writeElement("D", "prop", 0);
/*      */       
/* 2115 */       Enumeration<String> properties = propertiesVector.elements();
/*      */       
/* 2117 */       while (properties.hasMoreElements())
/*      */       {
/* 2119 */         String property = (String)properties.nextElement();
/*      */         
/* 2121 */         if (property.equals("creationdate")) {
/* 2122 */           generatedXML.writeProperty("D", "creationdate", getISOCreationDate(created));
/* 2123 */         } else if (property.equals("displayname")) {
/* 2124 */           generatedXML.writeElement("D", "displayname", 0);
/* 2125 */           generatedXML.writeData(resourceName);
/* 2126 */           generatedXML.writeElement("D", "displayname", 1);
/* 2127 */         } else if (property.equals("getcontentlanguage")) {
/* 2128 */           if (isFile) {
/* 2129 */             generatedXML.writeElement("D", "getcontentlanguage", 2);
/*      */           }
/*      */           else {
/* 2132 */             propertiesNotFound.addElement(property);
/*      */           }
/* 2134 */         } else if (property.equals("getcontentlength")) {
/* 2135 */           if (isFile) {
/* 2136 */             generatedXML.writeProperty("D", "getcontentlength", Long.toString(contentLength));
/*      */           }
/*      */           else {
/* 2139 */             propertiesNotFound.addElement(property);
/*      */           }
/* 2141 */         } else if (property.equals("getcontenttype")) {
/* 2142 */           if (isFile) {
/* 2143 */             generatedXML.writeProperty("D", "getcontenttype", contentType);
/*      */           } else {
/* 2145 */             propertiesNotFound.addElement(property);
/*      */           }
/* 2147 */         } else if (property.equals("getetag")) {
/* 2148 */           if (isFile) {
/* 2149 */             generatedXML.writeProperty("D", "getetag", eTag);
/*      */           } else {
/* 2151 */             propertiesNotFound.addElement(property);
/*      */           }
/* 2153 */         } else if (property.equals("getlastmodified")) {
/* 2154 */           if (isFile) {
/* 2155 */             generatedXML.writeProperty("D", "getlastmodified", FastHttpDateFormat.formatDate(lastModified, null));
/*      */           }
/*      */           else {
/* 2158 */             propertiesNotFound.addElement(property);
/*      */           }
/* 2160 */         } else if (property.equals("resourcetype")) {
/* 2161 */           if (isFile) {
/* 2162 */             if (isLockNull) {
/* 2163 */               generatedXML.writeElement("D", "resourcetype", 0);
/* 2164 */               generatedXML.writeElement("D", "lock-null", 2);
/* 2165 */               generatedXML.writeElement("D", "resourcetype", 1);
/*      */             } else {
/* 2167 */               generatedXML.writeElement("D", "resourcetype", 2);
/*      */             }
/*      */           } else {
/* 2170 */             generatedXML.writeElement("D", "resourcetype", 0);
/* 2171 */             generatedXML.writeElement("D", "collection", 2);
/* 2172 */             generatedXML.writeElement("D", "resourcetype", 1);
/*      */           }
/* 2174 */         } else if (property.equals("source")) {
/* 2175 */           generatedXML.writeProperty("D", "source", "");
/* 2176 */         } else if (property.equals("supportedlock")) {
/* 2177 */           String supportedLocks = "<D:lockentry><D:lockscope><D:exclusive/></D:lockscope><D:locktype><D:write/></D:locktype></D:lockentry><D:lockentry><D:lockscope><D:shared/></D:lockscope><D:locktype><D:write/></D:locktype></D:lockentry>";
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2184 */           generatedXML.writeElement("D", "supportedlock", 0);
/* 2185 */           generatedXML.writeText(supportedLocks);
/* 2186 */           generatedXML.writeElement("D", "supportedlock", 1);
/* 2187 */         } else if (property.equals("lockdiscovery")) {
/* 2188 */           if (!generateLockDiscovery(path, generatedXML))
/* 2189 */             propertiesNotFound.addElement(property);
/*      */         } else {
/* 2191 */           propertiesNotFound.addElement(property);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 2196 */       generatedXML.writeElement("D", "prop", 1);
/* 2197 */       generatedXML.writeElement("D", "status", 0);
/* 2198 */       generatedXML.writeText(status);
/* 2199 */       generatedXML.writeElement("D", "status", 1);
/* 2200 */       generatedXML.writeElement("D", "propstat", 1);
/*      */       
/* 2202 */       Enumeration<String> propertiesNotFoundList = propertiesNotFound.elements();
/*      */       
/* 2204 */       if (propertiesNotFoundList.hasMoreElements())
/*      */       {
/* 2206 */         status = "HTTP/1.1 404 " + WebdavStatus.getStatusText(404);
/*      */         
/*      */ 
/* 2209 */         generatedXML.writeElement("D", "propstat", 0);
/* 2210 */         generatedXML.writeElement("D", "prop", 0);
/*      */         
/* 2212 */         while (propertiesNotFoundList.hasMoreElements()) {
/* 2213 */           generatedXML.writeElement("D", (String)propertiesNotFoundList.nextElement(), 2);
/*      */         }
/*      */         
/*      */ 
/* 2217 */         generatedXML.writeElement("D", "prop", 1);
/* 2218 */         generatedXML.writeElement("D", "status", 0);
/* 2219 */         generatedXML.writeText(status);
/* 2220 */         generatedXML.writeElement("D", "status", 1);
/* 2221 */         generatedXML.writeElement("D", "propstat", 1);
/*      */       }
/*      */       
/*      */ 
/*      */       break;
/*      */     }
/*      */     
/*      */     
/* 2229 */     generatedXML.writeElement("D", "response", 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean generateLockDiscovery(String path, XMLWriter generatedXML)
/*      */   {
/* 2243 */     LockInfo resourceLock = (LockInfo)this.resourceLocks.get(path);
/* 2244 */     Enumeration<LockInfo> collectionLocksList = this.collectionLocks.elements();
/*      */     
/* 2246 */     boolean wroteStart = false;
/*      */     
/* 2248 */     if (resourceLock != null) {
/* 2249 */       wroteStart = true;
/* 2250 */       generatedXML.writeElement("D", "lockdiscovery", 0);
/* 2251 */       resourceLock.toXML(generatedXML);
/*      */     }
/*      */     
/* 2254 */     while (collectionLocksList.hasMoreElements()) {
/* 2255 */       LockInfo currentLock = (LockInfo)collectionLocksList.nextElement();
/* 2256 */       if (path.startsWith(currentLock.path)) {
/* 2257 */         if (!wroteStart) {
/* 2258 */           wroteStart = true;
/* 2259 */           generatedXML.writeElement("D", "lockdiscovery", 0);
/*      */         }
/*      */         
/* 2262 */         currentLock.toXML(generatedXML);
/*      */       }
/*      */     }
/*      */     
/* 2266 */     if (wroteStart) {
/* 2267 */       generatedXML.writeElement("D", "lockdiscovery", 1);
/*      */     } else {
/* 2269 */       return false;
/*      */     }
/*      */     
/* 2272 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getISOCreationDate(long creationDate)
/*      */   {
/* 2282 */     return creationDateFormat.format(new Date(creationDate));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private StringBuilder determineMethodsAllowed(HttpServletRequest req)
/*      */   {
/* 2292 */     StringBuilder methodsAllowed = new StringBuilder();
/*      */     
/* 2294 */     WebResource resource = this.resources.getResource(getRelativePath(req));
/*      */     
/* 2296 */     if (!resource.exists()) {
/* 2297 */       methodsAllowed.append("OPTIONS, MKCOL, PUT, LOCK");
/* 2298 */       return methodsAllowed;
/*      */     }
/*      */     
/* 2301 */     methodsAllowed.append("OPTIONS, GET, HEAD, POST, DELETE, TRACE");
/* 2302 */     methodsAllowed.append(", PROPPATCH, COPY, MOVE, LOCK, UNLOCK");
/*      */     
/* 2304 */     if (this.listings) {
/* 2305 */       methodsAllowed.append(", PROPFIND");
/*      */     }
/*      */     
/* 2308 */     if (resource.isFile()) {
/* 2309 */       methodsAllowed.append(", PUT");
/*      */     }
/*      */     
/* 2312 */     return methodsAllowed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private class LockInfo
/*      */   {
/* 2327 */     String path = "/";
/* 2328 */     String type = "write";
/* 2329 */     String scope = "exclusive";
/* 2330 */     int depth = 0;
/* 2331 */     String owner = "";
/* 2332 */     Vector<String> tokens = new Vector();
/* 2333 */     long expiresAt = 0L;
/* 2334 */     Date creationDate = new Date();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private LockInfo() {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public String toString()
/*      */     {
/* 2346 */       StringBuilder result = new StringBuilder("Type:");
/* 2347 */       result.append(this.type);
/* 2348 */       result.append("\nScope:");
/* 2349 */       result.append(this.scope);
/* 2350 */       result.append("\nDepth:");
/* 2351 */       result.append(this.depth);
/* 2352 */       result.append("\nOwner:");
/* 2353 */       result.append(this.owner);
/* 2354 */       result.append("\nExpiration:");
/* 2355 */       result.append(FastHttpDateFormat.formatDate(this.expiresAt, null));
/* 2356 */       Enumeration<String> tokensList = this.tokens.elements();
/* 2357 */       while (tokensList.hasMoreElements()) {
/* 2358 */         result.append("\nToken:");
/* 2359 */         result.append((String)tokensList.nextElement());
/*      */       }
/* 2361 */       result.append("\n");
/* 2362 */       return result.toString();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean hasExpired()
/*      */     {
/* 2370 */       return System.currentTimeMillis() > this.expiresAt;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean isExclusive()
/*      */     {
/* 2378 */       return this.scope.equals("exclusive");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void toXML(XMLWriter generatedXML)
/*      */     {
/* 2390 */       generatedXML.writeElement("D", "activelock", 0);
/*      */       
/* 2392 */       generatedXML.writeElement("D", "locktype", 0);
/* 2393 */       generatedXML.writeElement("D", this.type, 2);
/* 2394 */       generatedXML.writeElement("D", "locktype", 1);
/*      */       
/* 2396 */       generatedXML.writeElement("D", "lockscope", 0);
/* 2397 */       generatedXML.writeElement("D", this.scope, 2);
/* 2398 */       generatedXML.writeElement("D", "lockscope", 1);
/*      */       
/* 2400 */       generatedXML.writeElement("D", "depth", 0);
/* 2401 */       if (this.depth == WebdavServlet.this.maxDepth) {
/* 2402 */         generatedXML.writeText("Infinity");
/*      */       } else {
/* 2404 */         generatedXML.writeText("0");
/*      */       }
/* 2406 */       generatedXML.writeElement("D", "depth", 1);
/*      */       
/* 2408 */       generatedXML.writeElement("D", "owner", 0);
/* 2409 */       generatedXML.writeText(this.owner);
/* 2410 */       generatedXML.writeElement("D", "owner", 1);
/*      */       
/* 2412 */       generatedXML.writeElement("D", "timeout", 0);
/* 2413 */       long timeout = (this.expiresAt - System.currentTimeMillis()) / 1000L;
/* 2414 */       generatedXML.writeText("Second-" + timeout);
/* 2415 */       generatedXML.writeElement("D", "timeout", 1);
/*      */       
/* 2417 */       generatedXML.writeElement("D", "locktoken", 0);
/* 2418 */       Enumeration<String> tokensList = this.tokens.elements();
/* 2419 */       while (tokensList.hasMoreElements()) {
/* 2420 */         generatedXML.writeElement("D", "href", 0);
/* 2421 */         generatedXML.writeText("opaquelocktoken:" + (String)tokensList.nextElement());
/*      */         
/* 2423 */         generatedXML.writeElement("D", "href", 1);
/*      */       }
/* 2425 */       generatedXML.writeElement("D", "locktoken", 1);
/*      */       
/* 2427 */       generatedXML.writeElement("D", "activelock", 1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class WebdavResolver
/*      */     implements EntityResolver
/*      */   {
/*      */     private ServletContext context;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public WebdavResolver(ServletContext theContext)
/*      */     {
/* 2446 */       this.context = theContext;
/*      */     }
/*      */     
/*      */     public InputSource resolveEntity(String publicId, String systemId)
/*      */     {
/* 2451 */       this.context.log(DefaultServlet.sm.getString("webdavservlet.enternalEntityIgnored", new Object[] { publicId, systemId }));
/*      */       
/* 2453 */       return new InputSource(new StringReader("Ignored external entity"));
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\servlets\WebdavServlet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */