/*      */ package org.apache.catalina.servlets;
/*      */ 
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.OutputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.URLDecoder;
/*      */ import java.nio.file.CopyOption;
/*      */ import java.nio.file.Files;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.Vector;
/*      */ import javax.servlet.ServletConfig;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletOutputStream;
/*      */ import javax.servlet.http.Cookie;
/*      */ import javax.servlet.http.HttpServlet;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import javax.servlet.http.HttpSession;
/*      */ import org.apache.catalina.util.IOTools;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class CGIServlet
/*      */   extends HttpServlet
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   private int debug;
/*      */   private String cgiPathPrefix;
/*      */   private String cgiExecutable;
/*      */   private List<String> cgiExecutableArgs;
/*      */   private String parameterEncoding;
/*      */   private long stderrTimeout;
/*  276 */   private static final Object expandFileLock = new Object();
/*      */   private final Hashtable<String, String> shellEnv;
/*      */   
/*      */   public CGIServlet()
/*      */   {
/*  249 */     this.debug = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  257 */     this.cgiPathPrefix = null;
/*      */     
/*      */ 
/*  260 */     this.cgiExecutable = "perl";
/*      */     
/*      */ 
/*  263 */     this.cgiExecutableArgs = null;
/*      */     
/*      */ 
/*  266 */     this.parameterEncoding = System.getProperty("file.encoding", "UTF-8");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  273 */     this.stderrTimeout = 2000L;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  279 */     this.shellEnv = new Hashtable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void init(ServletConfig config)
/*      */     throws ServletException
/*      */   {
/*  299 */     super.init(config);
/*      */     
/*      */ 
/*  302 */     if (getServletConfig().getInitParameter("debug") != null)
/*  303 */       this.debug = Integer.parseInt(getServletConfig().getInitParameter("debug"));
/*  304 */     this.cgiPathPrefix = getServletConfig().getInitParameter("cgiPathPrefix");
/*  305 */     boolean passShellEnvironment = Boolean.parseBoolean(getServletConfig().getInitParameter("passShellEnvironment"));
/*      */     
/*      */ 
/*  308 */     if (passShellEnvironment) {
/*  309 */       this.shellEnv.putAll(System.getenv());
/*      */     }
/*      */     
/*  312 */     if (getServletConfig().getInitParameter("executable") != null) {
/*  313 */       this.cgiExecutable = getServletConfig().getInitParameter("executable");
/*      */     }
/*      */     
/*  316 */     if (getServletConfig().getInitParameter("executable-arg-1") != null) {
/*  317 */       List<String> args = new ArrayList();
/*  318 */       for (int i = 1;; i++) {
/*  319 */         String arg = getServletConfig().getInitParameter("executable-arg-" + i);
/*      */         
/*  321 */         if (arg == null) {
/*      */           break;
/*      */         }
/*  324 */         args.add(arg);
/*      */       }
/*  326 */       this.cgiExecutableArgs = args;
/*      */     }
/*      */     
/*  329 */     if (getServletConfig().getInitParameter("parameterEncoding") != null) {
/*  330 */       this.parameterEncoding = getServletConfig().getInitParameter("parameterEncoding");
/*      */     }
/*      */     
/*  333 */     if (getServletConfig().getInitParameter("stderrTimeout") != null) {
/*  334 */       this.stderrTimeout = Long.parseLong(getServletConfig().getInitParameter("stderrTimeout"));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void printServletEnvironment(ServletOutputStream out, HttpServletRequest req, HttpServletResponse res)
/*      */     throws IOException
/*      */   {
/*  361 */     out.println("<h1>ServletRequest Properties</h1>");
/*  362 */     out.println("<ul>");
/*  363 */     Enumeration<String> attrs = req.getAttributeNames();
/*  364 */     while (attrs.hasMoreElements()) {
/*  365 */       String attr = (String)attrs.nextElement();
/*  366 */       out.println("<li><b>attribute</b> " + attr + " = " + req.getAttribute(attr));
/*      */     }
/*      */     
/*  369 */     out.println("<li><b>characterEncoding</b> = " + req.getCharacterEncoding());
/*      */     
/*  371 */     out.println("<li><b>contentLength</b> = " + req.getContentLengthLong());
/*      */     
/*  373 */     out.println("<li><b>contentType</b> = " + req.getContentType());
/*      */     
/*  375 */     Enumeration<Locale> locales = req.getLocales();
/*  376 */     while (locales.hasMoreElements()) {
/*  377 */       Locale locale = (Locale)locales.nextElement();
/*  378 */       out.println("<li><b>locale</b> = " + locale);
/*      */     }
/*  380 */     Enumeration<String> params = req.getParameterNames();
/*  381 */     while (params.hasMoreElements()) {
/*  382 */       String param = (String)params.nextElement();
/*  383 */       for (String value : req.getParameterValues(param)) {
/*  384 */         out.println("<li><b>parameter</b> " + param + " = " + value);
/*      */       }
/*      */     }
/*  387 */     out.println("<li><b>protocol</b> = " + req.getProtocol());
/*  388 */     out.println("<li><b>remoteAddr</b> = " + req.getRemoteAddr());
/*  389 */     out.println("<li><b>remoteHost</b> = " + req.getRemoteHost());
/*  390 */     out.println("<li><b>scheme</b> = " + req.getScheme());
/*  391 */     out.println("<li><b>secure</b> = " + req.isSecure());
/*  392 */     out.println("<li><b>serverName</b> = " + req.getServerName());
/*  393 */     out.println("<li><b>serverPort</b> = " + req.getServerPort());
/*  394 */     out.println("</ul>");
/*  395 */     out.println("<hr>");
/*      */     
/*      */ 
/*  398 */     out.println("<h1>HttpServletRequest Properties</h1>");
/*  399 */     out.println("<ul>");
/*  400 */     out.println("<li><b>authType</b> = " + req.getAuthType());
/*  401 */     out.println("<li><b>contextPath</b> = " + req.getContextPath());
/*      */     
/*  403 */     Cookie[] cookies = req.getCookies();
/*  404 */     if (cookies != null) {
/*  405 */       for (int i = 0; i < cookies.length; i++)
/*  406 */         out.println("<li><b>cookie</b> " + cookies[i].getName() + " = " + cookies[i].getValue());
/*      */     }
/*  408 */     Enumeration<String> headers = req.getHeaderNames();
/*  409 */     while (headers.hasMoreElements()) {
/*  410 */       String header = (String)headers.nextElement();
/*  411 */       out.println("<li><b>header</b> " + header + " = " + req.getHeader(header));
/*      */     }
/*      */     
/*  414 */     out.println("<li><b>method</b> = " + req.getMethod());
/*  415 */     out.println("<li><a name=\"pathInfo\"><b>pathInfo</b></a> = " + req.getPathInfo());
/*      */     
/*  417 */     out.println("<li><b>pathTranslated</b> = " + req.getPathTranslated());
/*      */     
/*  419 */     out.println("<li><b>queryString</b> = " + req.getQueryString());
/*      */     
/*  421 */     out.println("<li><b>remoteUser</b> = " + req.getRemoteUser());
/*      */     
/*  423 */     out.println("<li><b>requestedSessionId</b> = " + req.getRequestedSessionId());
/*      */     
/*  425 */     out.println("<li><b>requestedSessionIdFromCookie</b> = " + req.isRequestedSessionIdFromCookie());
/*      */     
/*  427 */     out.println("<li><b>requestedSessionIdFromURL</b> = " + req.isRequestedSessionIdFromURL());
/*      */     
/*  429 */     out.println("<li><b>requestedSessionIdValid</b> = " + req.isRequestedSessionIdValid());
/*      */     
/*  431 */     out.println("<li><b>requestURI</b> = " + req.getRequestURI());
/*      */     
/*  433 */     out.println("<li><b>servletPath</b> = " + req.getServletPath());
/*      */     
/*  435 */     out.println("<li><b>userPrincipal</b> = " + req.getUserPrincipal());
/*      */     
/*  437 */     out.println("</ul>");
/*  438 */     out.println("<hr>");
/*      */     
/*      */ 
/*  441 */     out.println("<h1>ServletRequest Attributes</h1>");
/*  442 */     out.println("<ul>");
/*  443 */     attrs = req.getAttributeNames();
/*  444 */     while (attrs.hasMoreElements()) {
/*  445 */       String attr = (String)attrs.nextElement();
/*  446 */       out.println("<li><b>" + attr + "</b> = " + req.getAttribute(attr));
/*      */     }
/*      */     
/*  449 */     out.println("</ul>");
/*  450 */     out.println("<hr>");
/*      */     
/*      */ 
/*  453 */     HttpSession session = req.getSession(false);
/*  454 */     if (session != null)
/*      */     {
/*      */ 
/*  457 */       out.println("<h1>HttpSession Properties</h1>");
/*  458 */       out.println("<ul>");
/*  459 */       out.println("<li><b>id</b> = " + session.getId());
/*      */       
/*  461 */       out.println("<li><b>creationTime</b> = " + new Date(session.getCreationTime()));
/*      */       
/*  463 */       out.println("<li><b>lastAccessedTime</b> = " + new Date(session.getLastAccessedTime()));
/*      */       
/*  465 */       out.println("<li><b>maxInactiveInterval</b> = " + session.getMaxInactiveInterval());
/*      */       
/*  467 */       out.println("</ul>");
/*  468 */       out.println("<hr>");
/*      */       
/*      */ 
/*  471 */       out.println("<h1>HttpSession Attributes</h1>");
/*  472 */       out.println("<ul>");
/*  473 */       attrs = session.getAttributeNames();
/*  474 */       while (attrs.hasMoreElements()) {
/*  475 */         String attr = (String)attrs.nextElement();
/*  476 */         out.println("<li><b>" + attr + "</b> = " + session.getAttribute(attr));
/*      */       }
/*      */       
/*  479 */       out.println("</ul>");
/*  480 */       out.println("<hr>");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  485 */     out.println("<h1>ServletConfig Properties</h1>");
/*  486 */     out.println("<ul>");
/*  487 */     out.println("<li><b>servletName</b> = " + getServletConfig().getServletName());
/*      */     
/*  489 */     out.println("</ul>");
/*  490 */     out.println("<hr>");
/*      */     
/*      */ 
/*  493 */     out.println("<h1>ServletConfig Initialization Parameters</h1>");
/*  494 */     out.println("<ul>");
/*  495 */     params = getServletConfig().getInitParameterNames();
/*  496 */     while (params.hasMoreElements()) {
/*  497 */       String param = (String)params.nextElement();
/*  498 */       String value = getServletConfig().getInitParameter(param);
/*  499 */       out.println("<li><b>" + param + "</b> = " + value);
/*      */     }
/*  501 */     out.println("</ul>");
/*  502 */     out.println("<hr>");
/*      */     
/*      */ 
/*  505 */     out.println("<h1>ServletContext Properties</h1>");
/*  506 */     out.println("<ul>");
/*  507 */     out.println("<li><b>majorVersion</b> = " + getServletContext().getMajorVersion());
/*      */     
/*  509 */     out.println("<li><b>minorVersion</b> = " + getServletContext().getMinorVersion());
/*      */     
/*  511 */     out.println("<li><b>realPath('/')</b> = " + getServletContext().getRealPath("/"));
/*      */     
/*  513 */     out.println("<li><b>serverInfo</b> = " + getServletContext().getServerInfo());
/*      */     
/*  515 */     out.println("</ul>");
/*  516 */     out.println("<hr>");
/*      */     
/*      */ 
/*  519 */     out.println("<h1>ServletContext Initialization Parameters</h1>");
/*  520 */     out.println("<ul>");
/*  521 */     params = getServletContext().getInitParameterNames();
/*  522 */     while (params.hasMoreElements()) {
/*  523 */       String param = (String)params.nextElement();
/*  524 */       String value = getServletContext().getInitParameter(param);
/*  525 */       out.println("<li><b>" + param + "</b> = " + value);
/*      */     }
/*  527 */     out.println("</ul>");
/*  528 */     out.println("<hr>");
/*      */     
/*      */ 
/*  531 */     out.println("<h1>ServletContext Attributes</h1>");
/*  532 */     out.println("<ul>");
/*  533 */     attrs = getServletContext().getAttributeNames();
/*  534 */     while (attrs.hasMoreElements()) {
/*  535 */       String attr = (String)attrs.nextElement();
/*  536 */       out.println("<li><b>" + attr + "</b> = " + getServletContext().getAttribute(attr));
/*      */     }
/*      */     
/*  539 */     out.println("</ul>");
/*  540 */     out.println("<hr>");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doPost(HttpServletRequest req, HttpServletResponse res)
/*      */     throws IOException, ServletException
/*      */   {
/*  559 */     doGet(req, res);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doGet(HttpServletRequest req, HttpServletResponse res)
/*      */     throws ServletException, IOException
/*      */   {
/*  576 */     CGIEnvironment cgiEnv = new CGIEnvironment(req, getServletContext());
/*      */     
/*  578 */     if (cgiEnv.isValid()) {
/*  579 */       CGIRunner cgi = new CGIRunner(cgiEnv.getCommand(), cgiEnv.getEnvironment(), cgiEnv.getWorkingDirectory(), cgiEnv.getParameters());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  584 */       if ("POST".equals(req.getMethod())) {
/*  585 */         cgi.setInput(req.getInputStream());
/*      */       }
/*  587 */       cgi.setResponse(res);
/*  588 */       cgi.run();
/*      */     }
/*  590 */     else if (setStatus(res, 404)) {
/*  591 */       return;
/*      */     }
/*      */     
/*      */ 
/*  595 */     if (this.debug >= 10)
/*      */     {
/*  597 */       ServletOutputStream out = res.getOutputStream();
/*  598 */       out.println("<HTML><HEAD><TITLE>$Name$</TITLE></HEAD>");
/*  599 */       out.println("<BODY>$Header$<p>");
/*      */       
/*  601 */       if (cgiEnv.isValid()) {
/*  602 */         out.println(cgiEnv.toString());
/*      */       } else {
/*  604 */         out.println("<H3>");
/*  605 */         out.println("CGI script not found or not specified.");
/*  606 */         out.println("</H3>");
/*  607 */         out.println("<H4>");
/*  608 */         out.println("Check the <b>HttpServletRequest ");
/*  609 */         out.println("<a href=\"#pathInfo\">pathInfo</a></b> ");
/*  610 */         out.println("property to see if it is what you meant ");
/*  611 */         out.println("it to be.  You must specify an existant ");
/*  612 */         out.println("and executable file as part of the ");
/*  613 */         out.println("path-info.");
/*  614 */         out.println("</H4>");
/*  615 */         out.println("<H4>");
/*  616 */         out.println("For a good discussion of how CGI scripts ");
/*  617 */         out.println("work and what their environment variables ");
/*  618 */         out.println("mean, please visit the <a ");
/*  619 */         out.println("href=\"http://cgi-spec.golux.com\">CGI ");
/*  620 */         out.println("Specification page</a>.");
/*  621 */         out.println("</H4>");
/*      */       }
/*      */       
/*      */ 
/*  625 */       printServletEnvironment(out, req, res);
/*      */       
/*  627 */       out.println("</BODY></HTML>");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean setStatus(HttpServletResponse response, int status)
/*      */     throws IOException
/*      */   {
/*  645 */     if ((status >= 400) && (this.debug < 10)) {
/*  646 */       response.sendError(status);
/*  647 */       return true;
/*      */     }
/*  649 */     response.setStatus(status);
/*  650 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected class CGIEnvironment
/*      */   {
/*  663 */     private ServletContext context = null;
/*      */     
/*      */ 
/*  666 */     private String contextPath = null;
/*      */     
/*      */ 
/*  669 */     private String servletPath = null;
/*      */     
/*      */ 
/*  672 */     private String pathInfo = null;
/*      */     
/*      */ 
/*  675 */     private String webAppRootDir = null;
/*      */     
/*      */ 
/*  678 */     private File tmpDir = null;
/*      */     
/*      */ 
/*  681 */     private Hashtable<String, String> env = null;
/*      */     
/*      */ 
/*  684 */     private String command = null;
/*      */     
/*      */ 
/*      */     private final File workingDirectory;
/*      */     
/*      */ 
/*  690 */     private final ArrayList<String> cmdLineParameters = new ArrayList();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private final boolean valid;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected CGIEnvironment(HttpServletRequest req, ServletContext context)
/*      */       throws IOException
/*      */     {
/*  708 */       setupFromContext(context);
/*  709 */       setupFromRequest(req);
/*      */       
/*  711 */       this.valid = setCGIEnvironment(req);
/*      */       
/*  713 */       if (this.valid) {
/*  714 */         this.workingDirectory = new File(this.command.substring(0, this.command.lastIndexOf(File.separator)));
/*      */       }
/*      */       else {
/*  717 */         this.workingDirectory = null;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected void setupFromContext(ServletContext context)
/*      */     {
/*  729 */       this.context = context;
/*  730 */       this.webAppRootDir = context.getRealPath("/");
/*  731 */       this.tmpDir = ((File)context.getAttribute("javax.servlet.context.tempdir"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected void setupFromRequest(HttpServletRequest req)
/*      */       throws UnsupportedEncodingException
/*      */     {
/*  745 */       boolean isIncluded = false;
/*      */       
/*      */ 
/*  748 */       if (req.getAttribute("javax.servlet.include.request_uri") != null)
/*      */       {
/*  750 */         isIncluded = true;
/*      */       }
/*  752 */       if (isIncluded) {
/*  753 */         this.contextPath = ((String)req.getAttribute("javax.servlet.include.context_path"));
/*      */         
/*  755 */         this.servletPath = ((String)req.getAttribute("javax.servlet.include.servlet_path"));
/*      */         
/*  757 */         this.pathInfo = ((String)req.getAttribute("javax.servlet.include.path_info"));
/*      */       }
/*      */       else {
/*  760 */         this.contextPath = req.getContextPath();
/*  761 */         this.servletPath = req.getServletPath();
/*  762 */         this.pathInfo = req.getPathInfo();
/*      */       }
/*      */       
/*      */ 
/*  766 */       if (this.pathInfo == null) {
/*  767 */         this.pathInfo = this.servletPath;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  774 */       if ((req.getMethod().equals("GET")) || (req.getMethod().equals("POST")) || (req.getMethod().equals("HEAD")))
/*      */       {
/*      */         String qs;
/*      */         String qs;
/*  778 */         if (isIncluded) {
/*  779 */           qs = (String)req.getAttribute("javax.servlet.include.query_string");
/*      */         }
/*      */         else {
/*  782 */           qs = req.getQueryString();
/*      */         }
/*  784 */         if ((qs != null) && (qs.indexOf('=') == -1)) {
/*  785 */           StringTokenizer qsTokens = new StringTokenizer(qs, "+");
/*  786 */           while (qsTokens.hasMoreTokens()) {
/*  787 */             this.cmdLineParameters.add(URLDecoder.decode(qsTokens.nextToken(), CGIServlet.this.parameterEncoding));
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected String[] findCGI(String pathInfo, String webAppRootDir, String contextPath, String servletPath, String cgiPathPrefix)
/*      */     {
/*  861 */       String path = null;
/*  862 */       String name = null;
/*  863 */       String scriptname = null;
/*      */       
/*  865 */       if ((webAppRootDir != null) && (webAppRootDir.lastIndexOf(File.separator) == webAppRootDir.length() - 1))
/*      */       {
/*      */ 
/*      */ 
/*  869 */         webAppRootDir = webAppRootDir.substring(0, webAppRootDir.length() - 1);
/*      */       }
/*      */       
/*      */ 
/*  873 */       if (cgiPathPrefix != null) {
/*  874 */         webAppRootDir = webAppRootDir + File.separator + cgiPathPrefix;
/*      */       }
/*      */       
/*      */ 
/*  878 */       if (CGIServlet.this.debug >= 2) {
/*  879 */         CGIServlet.this.log("findCGI: path=" + pathInfo + ", " + webAppRootDir);
/*      */       }
/*      */       
/*  882 */       File currentLocation = new File(webAppRootDir);
/*  883 */       StringTokenizer dirWalker = new StringTokenizer(pathInfo, "/");
/*      */       
/*  885 */       if (CGIServlet.this.debug >= 3) {
/*  886 */         CGIServlet.this.log("findCGI: currentLoc=" + currentLocation);
/*      */       }
/*  888 */       StringBuilder cginameBuilder = new StringBuilder();
/*  889 */       while ((!currentLocation.isFile()) && (dirWalker.hasMoreElements())) {
/*  890 */         if (CGIServlet.this.debug >= 3) {
/*  891 */           CGIServlet.this.log("findCGI: currentLoc=" + currentLocation);
/*      */         }
/*  893 */         String nextElement = (String)dirWalker.nextElement();
/*  894 */         currentLocation = new File(currentLocation, nextElement);
/*  895 */         cginameBuilder.append('/').append(nextElement);
/*      */       }
/*  897 */       String cginame = cginameBuilder.toString();
/*  898 */       if (!currentLocation.isFile()) {
/*  899 */         return new String[] { null, null, null, null };
/*      */       }
/*      */       
/*  902 */       if (CGIServlet.this.debug >= 2) {
/*  903 */         CGIServlet.this.log("findCGI: FOUND cgi at " + currentLocation);
/*      */       }
/*  905 */       path = currentLocation.getAbsolutePath();
/*  906 */       name = currentLocation.getName();
/*      */       
/*  908 */       if (".".equals(contextPath)) {
/*  909 */         scriptname = servletPath;
/*      */       } else {
/*  911 */         scriptname = contextPath + servletPath;
/*      */       }
/*  913 */       if (!servletPath.equals(cginame)) {
/*  914 */         scriptname = scriptname + cginame;
/*      */       }
/*      */       
/*  917 */       if (CGIServlet.this.debug >= 1) {
/*  918 */         CGIServlet.this.log("findCGI calc: name=" + name + ", path=" + path + ", scriptname=" + scriptname + ", cginame=" + cginame);
/*      */       }
/*      */       
/*  921 */       return new String[] { path, scriptname, cginame, name };
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected boolean setCGIEnvironment(HttpServletRequest req)
/*      */       throws IOException
/*      */     {
/*  943 */       Hashtable<String, String> envp = new Hashtable();
/*      */       
/*      */ 
/*  946 */       envp.putAll(CGIServlet.this.shellEnv);
/*      */       
/*      */ 
/*  949 */       String sPathInfoOrig = null;
/*  950 */       String sPathInfoCGI = null;
/*  951 */       String sPathTranslatedCGI = null;
/*  952 */       String sCGIFullPath = null;
/*  953 */       String sCGIScriptName = null;
/*  954 */       String sCGIFullName = null;
/*  955 */       String sCGIName = null;
/*      */       
/*      */ 
/*      */ 
/*  959 */       sPathInfoOrig = this.pathInfo;
/*  960 */       sPathInfoOrig = sPathInfoOrig == null ? "" : sPathInfoOrig;
/*      */       
/*  962 */       if (this.webAppRootDir == null)
/*      */       {
/*  964 */         this.webAppRootDir = this.tmpDir.toString();
/*  965 */         expandCGIScript();
/*      */       }
/*      */       
/*  968 */       String[] sCGINames = findCGI(sPathInfoOrig, this.webAppRootDir, this.contextPath, this.servletPath, CGIServlet.this.cgiPathPrefix);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  974 */       sCGIFullPath = sCGINames[0];
/*  975 */       sCGIScriptName = sCGINames[1];
/*  976 */       sCGIFullName = sCGINames[2];
/*  977 */       sCGIName = sCGINames[3];
/*      */       
/*  979 */       if ((sCGIFullPath == null) || (sCGIScriptName == null) || (sCGIFullName == null) || (sCGIName == null))
/*      */       {
/*      */ 
/*      */ 
/*  983 */         return false;
/*      */       }
/*      */       
/*  986 */       envp.put("SERVER_SOFTWARE", "TOMCAT");
/*      */       
/*  988 */       envp.put("SERVER_NAME", nullsToBlanks(req.getServerName()));
/*      */       
/*  990 */       envp.put("GATEWAY_INTERFACE", "CGI/1.1");
/*      */       
/*  992 */       envp.put("SERVER_PROTOCOL", nullsToBlanks(req.getProtocol()));
/*      */       
/*  994 */       int port = req.getServerPort();
/*  995 */       Integer iPort = port == 0 ? Integer.valueOf(-1) : Integer.valueOf(port);
/*      */       
/*  997 */       envp.put("SERVER_PORT", iPort.toString());
/*      */       
/*  999 */       envp.put("REQUEST_METHOD", nullsToBlanks(req.getMethod()));
/*      */       
/* 1001 */       envp.put("REQUEST_URI", nullsToBlanks(req.getRequestURI()));
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1015 */       if ((this.pathInfo == null) || (this.pathInfo.substring(sCGIFullName.length()).length() <= 0))
/*      */       {
/* 1017 */         sPathInfoCGI = "";
/*      */       } else {
/* 1019 */         sPathInfoCGI = this.pathInfo.substring(sCGIFullName.length());
/*      */       }
/* 1021 */       envp.put("PATH_INFO", sPathInfoCGI);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1043 */       if (!"".equals(sPathInfoCGI)) {
/* 1044 */         sPathTranslatedCGI = this.context.getRealPath(sPathInfoCGI);
/*      */       }
/* 1046 */       if ((sPathTranslatedCGI != null) && (!"".equals(sPathTranslatedCGI)))
/*      */       {
/*      */ 
/* 1049 */         envp.put("PATH_TRANSLATED", nullsToBlanks(sPathTranslatedCGI));
/*      */       }
/*      */       
/*      */ 
/* 1053 */       envp.put("SCRIPT_NAME", nullsToBlanks(sCGIScriptName));
/*      */       
/* 1055 */       envp.put("QUERY_STRING", nullsToBlanks(req.getQueryString()));
/*      */       
/* 1057 */       envp.put("REMOTE_HOST", nullsToBlanks(req.getRemoteHost()));
/*      */       
/* 1059 */       envp.put("REMOTE_ADDR", nullsToBlanks(req.getRemoteAddr()));
/*      */       
/* 1061 */       envp.put("AUTH_TYPE", nullsToBlanks(req.getAuthType()));
/*      */       
/* 1063 */       envp.put("REMOTE_USER", nullsToBlanks(req.getRemoteUser()));
/*      */       
/* 1065 */       envp.put("REMOTE_IDENT", "");
/*      */       
/* 1067 */       envp.put("CONTENT_TYPE", nullsToBlanks(req.getContentType()));
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1074 */       long contentLength = req.getContentLengthLong();
/* 1075 */       String sContentLength = contentLength <= 0L ? "" : Long.toString(contentLength);
/*      */       
/* 1077 */       envp.put("CONTENT_LENGTH", sContentLength);
/*      */       
/*      */ 
/* 1080 */       Enumeration<String> headers = req.getHeaderNames();
/* 1081 */       String header = null;
/* 1082 */       while (headers.hasMoreElements()) {
/* 1083 */         header = null;
/* 1084 */         header = ((String)headers.nextElement()).toUpperCase(Locale.ENGLISH);
/*      */         
/*      */ 
/*      */ 
/* 1088 */         if ((!"AUTHORIZATION".equalsIgnoreCase(header)) && (!"PROXY_AUTHORIZATION".equalsIgnoreCase(header)))
/*      */         {
/*      */ 
/*      */ 
/* 1092 */           envp.put("HTTP_" + header.replace('-', '_'), req.getHeader(header));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1097 */       File fCGIFullPath = new File(sCGIFullPath);
/* 1098 */       this.command = fCGIFullPath.getCanonicalPath();
/*      */       
/* 1100 */       envp.put("X_TOMCAT_SCRIPT_PATH", this.command);
/*      */       
/* 1102 */       envp.put("SCRIPT_FILENAME", this.command);
/*      */       
/* 1104 */       this.env = envp;
/*      */       
/* 1106 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected void expandCGIScript()
/*      */     {
/* 1115 */       StringBuilder srcPath = new StringBuilder();
/* 1116 */       StringBuilder destPath = new StringBuilder();
/* 1117 */       InputStream is = null;
/*      */       
/*      */ 
/* 1120 */       if (CGIServlet.this.cgiPathPrefix == null) {
/* 1121 */         srcPath.append(this.pathInfo);
/* 1122 */         is = this.context.getResourceAsStream(srcPath.toString());
/* 1123 */         destPath.append(this.tmpDir);
/* 1124 */         destPath.append(this.pathInfo);
/*      */       }
/*      */       else {
/* 1127 */         srcPath.append(CGIServlet.this.cgiPathPrefix);
/* 1128 */         StringTokenizer pathWalker = new StringTokenizer(this.pathInfo, "/");
/*      */         
/*      */ 
/* 1131 */         while ((pathWalker.hasMoreElements()) && (is == null)) {
/* 1132 */           srcPath.append("/");
/* 1133 */           srcPath.append(pathWalker.nextElement());
/* 1134 */           is = this.context.getResourceAsStream(srcPath.toString());
/*      */         }
/* 1136 */         destPath.append(this.tmpDir);
/* 1137 */         destPath.append("/");
/* 1138 */         destPath.append(srcPath);
/*      */       }
/*      */       
/* 1141 */       if (is == null)
/*      */       {
/* 1143 */         if (CGIServlet.this.debug >= 2) {
/* 1144 */           CGIServlet.this.log("expandCGIScript: source '" + srcPath + "' not found");
/*      */         }
/* 1146 */         return;
/*      */       }
/*      */       
/* 1149 */       File f = new File(destPath.toString());
/* 1150 */       if (f.exists()) {
/*      */         try {
/* 1152 */           is.close();
/*      */         } catch (IOException e) {
/* 1154 */           CGIServlet.this.log("Could not close is", e);
/*      */         }
/*      */         
/* 1157 */         return;
/*      */       }
/*      */       
/*      */ 
/* 1161 */       File dir = f.getParentFile();
/* 1162 */       if ((!dir.mkdirs()) && (!dir.isDirectory())) {
/* 1163 */         if (CGIServlet.this.debug >= 2) {
/* 1164 */           CGIServlet.this.log("expandCGIScript: failed to create directories for '" + dir.getAbsolutePath() + "'");
/*      */         }
/*      */         
/* 1167 */         return;
/*      */       }
/*      */       try
/*      */       {
/* 1171 */         synchronized (CGIServlet.expandFileLock)
/*      */         {
/* 1173 */           if (f.exists()) {
/* 1174 */             return;
/*      */           }
/*      */           
/*      */ 
/* 1178 */           if (!f.createNewFile()) {
/* 1179 */             return;
/*      */           }
/*      */           try
/*      */           {
/* 1183 */             Files.copy(is, f.toPath(), new CopyOption[0]);
/*      */           } finally {
/* 1185 */             is.close();
/*      */           }
/*      */           
/* 1188 */           if (CGIServlet.this.debug >= 2) {
/* 1189 */             CGIServlet.this.log("expandCGIScript: expanded '" + srcPath + "' to '" + destPath + "'");
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (IOException ioe) {
/* 1194 */         if ((f.exists()) && 
/* 1195 */           (!f.delete()) && (CGIServlet.this.debug >= 2)) {
/* 1196 */           CGIServlet.this.log("expandCGIScript: failed to delete '" + f.getAbsolutePath() + "'");
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1214 */       StringBuilder sb = new StringBuilder();
/*      */       
/* 1216 */       sb.append("<TABLE border=2>");
/*      */       
/* 1218 */       sb.append("<tr><th colspan=2 bgcolor=grey>");
/* 1219 */       sb.append("CGIEnvironment Info</th></tr>");
/*      */       
/* 1221 */       sb.append("<tr><td>Debug Level</td><td>");
/* 1222 */       sb.append(CGIServlet.this.debug);
/* 1223 */       sb.append("</td></tr>");
/*      */       
/* 1225 */       sb.append("<tr><td>Validity:</td><td>");
/* 1226 */       sb.append(isValid());
/* 1227 */       sb.append("</td></tr>");
/*      */       
/* 1229 */       if (isValid()) {
/* 1230 */         Enumeration<String> envk = this.env.keys();
/* 1231 */         while (envk.hasMoreElements()) {
/* 1232 */           String s = (String)envk.nextElement();
/* 1233 */           sb.append("<tr><td>");
/* 1234 */           sb.append(s);
/* 1235 */           sb.append("</td><td>");
/* 1236 */           sb.append(blanksToString((String)this.env.get(s), "[will be set to blank]"));
/*      */           
/* 1238 */           sb.append("</td></tr>");
/*      */         }
/*      */       }
/*      */       
/* 1242 */       sb.append("<tr><td colspan=2><HR></td></tr>");
/*      */       
/* 1244 */       sb.append("<tr><td>Derived Command</td><td>");
/* 1245 */       sb.append(nullsToBlanks(this.command));
/* 1246 */       sb.append("</td></tr>");
/*      */       
/* 1248 */       sb.append("<tr><td>Working Directory</td><td>");
/* 1249 */       if (this.workingDirectory != null) {
/* 1250 */         sb.append(this.workingDirectory.toString());
/*      */       }
/* 1252 */       sb.append("</td></tr>");
/*      */       
/* 1254 */       sb.append("<tr><td>Command Line Params</td><td>");
/* 1255 */       for (String param : this.cmdLineParameters) {
/* 1256 */         sb.append("<p>");
/* 1257 */         sb.append(param);
/* 1258 */         sb.append("</p>");
/*      */       }
/* 1260 */       sb.append("</td></tr>");
/*      */       
/* 1262 */       sb.append("</TABLE><p>end.");
/*      */       
/* 1264 */       return sb.toString();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected String getCommand()
/*      */     {
/* 1275 */       return this.command;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected File getWorkingDirectory()
/*      */     {
/* 1286 */       return this.workingDirectory;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected Hashtable<String, String> getEnvironment()
/*      */     {
/* 1297 */       return this.env;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected ArrayList<String> getParameters()
/*      */     {
/* 1308 */       return this.cmdLineParameters;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected boolean isValid()
/*      */     {
/* 1320 */       return this.valid;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected String nullsToBlanks(String s)
/*      */     {
/* 1332 */       return nullsToString(s, "");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected String nullsToString(String couldBeNull, String subForNulls)
/*      */     {
/* 1346 */       return couldBeNull == null ? subForNulls : couldBeNull;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected String blanksToString(String couldBeBlank, String subForBlanks)
/*      */     {
/* 1360 */       return ("".equals(couldBeBlank)) || (couldBeBlank == null) ? subForBlanks : couldBeBlank;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected class CGIRunner
/*      */   {
/*      */     private final String command;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private final Hashtable<String, String> env;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private final File wd;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private final ArrayList<String> params;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1406 */     private InputStream stdin = null;
/*      */     
/*      */ 
/* 1409 */     private HttpServletResponse response = null;
/*      */     
/*      */ 
/* 1412 */     private boolean readyToRun = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected CGIRunner(Hashtable<String, String> command, File env, ArrayList<String> wd)
/*      */     {
/* 1431 */       this.command = command;
/* 1432 */       this.env = env;
/* 1433 */       this.wd = wd;
/* 1434 */       this.params = params;
/* 1435 */       updateReadyStatus();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     protected void updateReadyStatus()
/*      */     {
/* 1443 */       if ((this.command != null) && (this.env != null) && (this.wd != null) && (this.params != null) && (this.response != null))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1448 */         this.readyToRun = true;
/*      */       } else {
/* 1450 */         this.readyToRun = false;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected boolean isReady()
/*      */     {
/* 1462 */       return this.readyToRun;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected void setResponse(HttpServletResponse response)
/*      */     {
/* 1474 */       this.response = response;
/* 1475 */       updateReadyStatus();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected void setInput(InputStream stdin)
/*      */     {
/* 1486 */       this.stdin = stdin;
/* 1487 */       updateReadyStatus();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected String[] hashToStringArray(Hashtable<String, ?> h)
/*      */       throws NullPointerException
/*      */     {
/* 1505 */       Vector<String> v = new Vector();
/* 1506 */       Enumeration<String> e = h.keys();
/* 1507 */       while (e.hasMoreElements()) {
/* 1508 */         String k = (String)e.nextElement();
/* 1509 */         v.add(k + "=" + h.get(k).toString());
/*      */       }
/* 1511 */       String[] strArr = new String[v.size()];
/* 1512 */       v.copyInto(strArr);
/* 1513 */       return strArr;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected void run()
/*      */       throws IOException
/*      */     {
/* 1575 */       if (!isReady()) {
/* 1576 */         throw new IOException(getClass().getName() + ": not ready to run.");
/*      */       }
/*      */       
/*      */ 
/* 1580 */       if (CGIServlet.this.debug >= 1) {
/* 1581 */         CGIServlet.this.log("runCGI(envp=[" + this.env + "], command=" + this.command + ")");
/*      */       }
/*      */       
/* 1584 */       if ((this.command.indexOf(File.separator + "." + File.separator) >= 0) || (this.command.indexOf(File.separator + "..") >= 0) || (this.command.indexOf(".." + File.separator) >= 0))
/*      */       {
/*      */ 
/* 1587 */         throw new IOException(getClass().getName() + "Illegal Character in CGI command " + "path ('.' or '..') detected.  Not " + "running CGI [" + this.command + "].");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1597 */       Runtime rt = null;
/* 1598 */       BufferedReader cgiHeaderReader = null;
/* 1599 */       InputStream cgiOutput = null;
/* 1600 */       BufferedReader commandsStdErr = null;
/* 1601 */       Thread errReaderThread = null;
/* 1602 */       BufferedOutputStream commandsStdIn = null;
/* 1603 */       Process proc = null;
/* 1604 */       int bufRead = -1;
/*      */       
/* 1606 */       List<String> cmdAndArgs = new ArrayList();
/* 1607 */       if (CGIServlet.this.cgiExecutable.length() != 0) {
/* 1608 */         cmdAndArgs.add(CGIServlet.this.cgiExecutable);
/*      */       }
/* 1610 */       if (CGIServlet.this.cgiExecutableArgs != null) {
/* 1611 */         cmdAndArgs.addAll(CGIServlet.this.cgiExecutableArgs);
/*      */       }
/* 1613 */       cmdAndArgs.add(this.command);
/* 1614 */       cmdAndArgs.addAll(this.params);
/*      */       try
/*      */       {
/* 1617 */         rt = Runtime.getRuntime();
/* 1618 */         proc = rt.exec((String[])cmdAndArgs.toArray(new String[cmdAndArgs.size()]), hashToStringArray(this.env), this.wd);
/*      */         
/*      */ 
/*      */ 
/* 1622 */         String sContentLength = (String)this.env.get("CONTENT_LENGTH");
/*      */         
/* 1624 */         if (!"".equals(sContentLength)) {
/* 1625 */           commandsStdIn = new BufferedOutputStream(proc.getOutputStream());
/* 1626 */           IOTools.flow(this.stdin, commandsStdIn);
/* 1627 */           commandsStdIn.flush();
/* 1628 */           commandsStdIn.close();
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1636 */         boolean isRunning = true;
/* 1637 */         commandsStdErr = new BufferedReader(new InputStreamReader(proc.getErrorStream()));
/*      */         
/* 1639 */         final BufferedReader stdErrRdr = commandsStdErr;
/*      */         
/* 1641 */         errReaderThread = new Thread()
/*      */         {
/*      */           public void run() {
/* 1644 */             CGIServlet.CGIRunner.this.sendToLog(stdErrRdr);
/*      */           }
/* 1646 */         };
/* 1647 */         errReaderThread.start();
/*      */         
/* 1649 */         InputStream cgiHeaderStream = new CGIServlet.HTTPHeaderInputStream(proc.getInputStream());
/*      */         
/* 1651 */         cgiHeaderReader = new BufferedReader(new InputStreamReader(cgiHeaderStream));
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1658 */         boolean skipBody = false;
/*      */         
/* 1660 */         while (isRunning) {
/*      */           try
/*      */           {
/* 1663 */             String line = null;
/*      */             
/* 1665 */             while (((line = cgiHeaderReader.readLine()) != null) && (!"".equals(line))) {
/* 1666 */               if (CGIServlet.this.debug >= 2) {
/* 1667 */                 CGIServlet.this.log("runCGI: addHeader(\"" + line + "\")");
/*      */               }
/* 1669 */               if (line.startsWith("HTTP")) {
/* 1670 */                 skipBody = CGIServlet.this.setStatus(this.response, getSCFromHttpStatusLine(line));
/* 1671 */               } else if (line.indexOf(':') >= 0) {
/* 1672 */                 String header = line.substring(0, line.indexOf(':')).trim();
/*      */                 
/* 1674 */                 String value = line.substring(line.indexOf(':') + 1).trim();
/*      */                 
/* 1676 */                 if (header.equalsIgnoreCase("status")) {
/* 1677 */                   skipBody = CGIServlet.this.setStatus(this.response, getSCFromCGIStatusHeader(value));
/*      */                 } else {
/* 1679 */                   this.response.addHeader(header, value);
/*      */                 }
/*      */               } else {
/* 1682 */                 CGIServlet.this.log("runCGI: bad header line \"" + line + "\"");
/*      */               }
/*      */             }
/*      */             
/*      */ 
/* 1687 */             byte[] bBuf = new byte['ࠀ'];
/*      */             
/* 1689 */             OutputStream out = this.response.getOutputStream();
/* 1690 */             cgiOutput = proc.getInputStream();
/*      */             try
/*      */             {
/* 1693 */               while ((!skipBody) && ((bufRead = cgiOutput.read(bBuf)) != -1)) {
/* 1694 */                 if (CGIServlet.this.debug >= 4) {
/* 1695 */                   CGIServlet.this.log("runCGI: output " + bufRead + " bytes of data");
/*      */                 }
/*      */                 
/* 1698 */                 out.write(bBuf, 0, bufRead);
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/* 1704 */               while ((bufRead != -1) && 
/* 1705 */                 ((bufRead = cgiOutput.read(bBuf)) != -1)) {}
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1711 */               proc.exitValue();
/*      */             }
/*      */             finally
/*      */             {
/* 1704 */               if (bufRead != -1) {
/* 1705 */                 while ((bufRead = cgiOutput.read(bBuf)) != -1) {}
/*      */               }
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1713 */             isRunning = false;
/*      */           }
/*      */           catch (IllegalThreadStateException e) {
/*      */             try {
/* 1717 */               Thread.sleep(500L);
/*      */ 
/*      */             }
/*      */             catch (InterruptedException localInterruptedException1) {}
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/* 1726 */         CGIServlet.this.log("Caught exception " + e);
/* 1727 */         throw e;
/*      */       }
/*      */       finally
/*      */       {
/* 1731 */         if (cgiHeaderReader != null) {
/*      */           try {
/* 1733 */             cgiHeaderReader.close();
/*      */           } catch (IOException ioe) {
/* 1735 */             CGIServlet.this.log("Exception closing header reader " + ioe);
/*      */           }
/*      */         }
/*      */         
/* 1739 */         if (cgiOutput != null) {
/*      */           try {
/* 1741 */             cgiOutput.close();
/*      */           } catch (IOException ioe) {
/* 1743 */             CGIServlet.this.log("Exception closing output stream " + ioe);
/*      */           }
/*      */         }
/*      */         
/* 1747 */         if (errReaderThread != null) {
/*      */           try {
/* 1749 */             errReaderThread.join(CGIServlet.this.stderrTimeout);
/*      */           } catch (InterruptedException e) {
/* 1751 */             CGIServlet.this.log("Interupted waiting for stderr reader thread");
/*      */           }
/*      */         }
/* 1754 */         if (CGIServlet.this.debug > 4) {
/* 1755 */           CGIServlet.this.log("Running finally block");
/*      */         }
/* 1757 */         if (proc != null) {
/* 1758 */           proc.destroy();
/* 1759 */           proc = null;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private int getSCFromHttpStatusLine(String line)
/*      */     {
/* 1772 */       int statusStart = line.indexOf(' ') + 1;
/*      */       
/* 1774 */       if ((statusStart < 1) || (line.length() < statusStart + 3))
/*      */       {
/* 1776 */         CGIServlet.this.log("runCGI: invalid HTTP Status-Line:" + line);
/* 1777 */         return 500;
/*      */       }
/*      */       
/* 1780 */       String status = line.substring(statusStart, statusStart + 3);
/*      */       
/*      */       try
/*      */       {
/* 1784 */         statusCode = Integer.parseInt(status);
/*      */       } catch (NumberFormatException nfe) {
/*      */         int statusCode;
/* 1787 */         CGIServlet.this.log("runCGI: invalid status code:" + status);
/* 1788 */         return 500;
/*      */       }
/*      */       int statusCode;
/* 1791 */       return statusCode;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private int getSCFromCGIStatusHeader(String value)
/*      */     {
/* 1803 */       if (value.length() < 3)
/*      */       {
/* 1805 */         CGIServlet.this.log("runCGI: invalid status value:" + value);
/* 1806 */         return 500;
/*      */       }
/*      */       
/* 1809 */       String status = value.substring(0, 3);
/*      */       
/*      */       try
/*      */       {
/* 1813 */         statusCode = Integer.parseInt(status);
/*      */       } catch (NumberFormatException nfe) {
/*      */         int statusCode;
/* 1816 */         CGIServlet.this.log("runCGI: invalid status code:" + status);
/* 1817 */         return 500;
/*      */       }
/*      */       int statusCode;
/* 1820 */       return statusCode;
/*      */     }
/*      */     
/*      */     private void sendToLog(BufferedReader rdr) {
/* 1824 */       String line = null;
/* 1825 */       int lineCount = 0;
/*      */       try {
/* 1827 */         while ((line = rdr.readLine()) != null) {
/* 1828 */           CGIServlet.this.log("runCGI (stderr):" + line);
/* 1829 */           lineCount++;
/*      */         }
/*      */         
/*      */ 
/*      */         try
/*      */         {
/* 1835 */           rdr.close();
/*      */         } catch (IOException ce) {
/* 1837 */           CGIServlet.this.log("sendToLog error", ce);
/*      */         }
/*      */         
/* 1840 */         if (lineCount <= 0) {
/*      */           return;
/*      */         }
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/* 1832 */         CGIServlet.this.log("sendToLog error", e);
/*      */       } finally {
/*      */         try {
/* 1835 */           rdr.close();
/*      */         } catch (IOException ce) {
/* 1837 */           CGIServlet.this.log("sendToLog error", ce);
/*      */         }
/*      */       }
/* 1840 */       if (CGIServlet.this.debug > 2) {
/* 1841 */         CGIServlet.this.log("runCGI: " + lineCount + " lines received on stderr");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected static class HTTPHeaderInputStream
/*      */     extends InputStream
/*      */   {
/*      */     private static final int STATE_CHARACTER = 0;
/*      */     
/*      */     private static final int STATE_FIRST_CR = 1;
/*      */     
/*      */     private static final int STATE_FIRST_LF = 2;
/*      */     private static final int STATE_SECOND_CR = 3;
/*      */     private static final int STATE_HEADER_END = 4;
/*      */     private final InputStream input;
/*      */     private int state;
/*      */     
/*      */     HTTPHeaderInputStream(InputStream theInput)
/*      */     {
/* 1862 */       this.input = theInput;
/* 1863 */       this.state = 0;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public int read()
/*      */       throws IOException
/*      */     {
/* 1871 */       if (this.state == 4) {
/* 1872 */         return -1;
/*      */       }
/*      */       
/* 1875 */       int i = this.input.read();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1893 */       if (i == 10)
/*      */       {
/* 1895 */         switch (this.state) {
/*      */         case 0: 
/* 1897 */           this.state = 2;
/* 1898 */           break;
/*      */         case 1: 
/* 1900 */           this.state = 2;
/* 1901 */           break;
/*      */         case 2: 
/*      */         case 3: 
/* 1904 */           this.state = 4;
/*      */         
/*      */         }
/*      */         
/* 1908 */       } else if (i == 13)
/*      */       {
/* 1910 */         switch (this.state) {
/*      */         case 0: 
/* 1912 */           this.state = 1;
/* 1913 */           break;
/*      */         case 1: 
/* 1915 */           this.state = 4;
/* 1916 */           break;
/*      */         case 2: 
/* 1918 */           this.state = 3;
/*      */         
/*      */         }
/*      */         
/*      */       } else {
/* 1923 */         this.state = 0;
/*      */       }
/*      */       
/* 1926 */       return i;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\tomcat-embed-core-8.5.4.jar!\org\apache\catalina\servlets\CGIServlet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */