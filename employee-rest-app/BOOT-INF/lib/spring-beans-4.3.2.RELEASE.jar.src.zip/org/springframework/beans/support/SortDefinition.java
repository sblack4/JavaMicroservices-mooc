package org.springframework.beans.support;

public abstract interface SortDefinition
{
  public abstract String getProperty();
  
  public abstract boolean isIgnoreCase();
  
  public abstract boolean isAscending();
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-beans-4.3.2.RELEASE.jar!\org\springframework\beans\support\SortDefinition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */