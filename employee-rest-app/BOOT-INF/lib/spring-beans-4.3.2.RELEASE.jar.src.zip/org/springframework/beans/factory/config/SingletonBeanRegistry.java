package org.springframework.beans.factory.config;

public abstract interface SingletonBeanRegistry
{
  public abstract void registerSingleton(String paramString, Object paramObject);
  
  public abstract Object getSingleton(String paramString);
  
  public abstract boolean containsSingleton(String paramString);
  
  public abstract String[] getSingletonNames();
  
  public abstract int getSingletonCount();
  
  public abstract Object getSingletonMutex();
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-beans-4.3.2.RELEASE.jar!\org\springframework\beans\factory\config\SingletonBeanRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */