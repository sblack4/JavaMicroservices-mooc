/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import org.springframework.beans.BeanInstantiationException;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleInstantiationStrategy
/*     */   implements InstantiationStrategy
/*     */ {
/*  45 */   private static final ThreadLocal<Method> currentlyInvokedFactoryMethod = new ThreadLocal();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Method getCurrentlyInvokedFactoryMethod()
/*     */   {
/*  54 */     return (Method)currentlyInvokedFactoryMethod.get();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object instantiate(RootBeanDefinition bd, String beanName, BeanFactory owner)
/*     */   {
/*  61 */     if (bd.getMethodOverrides().isEmpty())
/*     */     {
/*  63 */       synchronized (bd.constructorArgumentLock) {
/*  64 */         Constructor<?> constructorToUse = (Constructor)bd.resolvedConstructorOrFactoryMethod;
/*  65 */         if (constructorToUse == null) {
/*  66 */           final Class<?> clazz = bd.getBeanClass();
/*  67 */           if (clazz.isInterface()) {
/*  68 */             throw new BeanInstantiationException(clazz, "Specified class is an interface");
/*     */           }
/*     */           try {
/*  71 */             if (System.getSecurityManager() != null) {
/*  72 */               constructorToUse = (Constructor)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */               {
/*     */                 public Constructor<?> run() throws Exception {
/*  75 */                   return clazz.getDeclaredConstructor((Class[])null);
/*     */                 }
/*     */                 
/*     */               });
/*     */             } else {
/*  80 */               constructorToUse = clazz.getDeclaredConstructor((Class[])null);
/*     */             }
/*  82 */             bd.resolvedConstructorOrFactoryMethod = constructorToUse;
/*     */           }
/*     */           catch (Throwable ex) {
/*  85 */             throw new BeanInstantiationException(clazz, "No default constructor found", ex);
/*     */           }
/*     */         } }
/*     */       Constructor<?> constructorToUse;
/*  89 */       return BeanUtils.instantiateClass(constructorToUse, new Object[0]);
/*     */     }
/*     */     
/*     */ 
/*  93 */     return instantiateWithMethodInjection(bd, beanName, owner);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object instantiateWithMethodInjection(RootBeanDefinition bd, String beanName, BeanFactory owner)
/*     */   {
/* 104 */     throw new UnsupportedOperationException("Method Injection not supported in SimpleInstantiationStrategy");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object instantiate(RootBeanDefinition bd, String beanName, BeanFactory owner, final Constructor<?> ctor, Object... args)
/*     */   {
/* 111 */     if (bd.getMethodOverrides().isEmpty()) {
/* 112 */       if (System.getSecurityManager() != null)
/*     */       {
/* 114 */         AccessController.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public Object run() {
/* 117 */             ReflectionUtils.makeAccessible(ctor);
/* 118 */             return null;
/*     */           }
/*     */         });
/*     */       }
/* 122 */       return BeanUtils.instantiateClass(ctor, args);
/*     */     }
/*     */     
/* 125 */     return instantiateWithMethodInjection(bd, beanName, owner, ctor, args);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object instantiateWithMethodInjection(RootBeanDefinition bd, String beanName, BeanFactory owner, Constructor<?> ctor, Object... args)
/*     */   {
/* 138 */     throw new UnsupportedOperationException("Method Injection not supported in SimpleInstantiationStrategy");
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object instantiate(RootBeanDefinition bd, String beanName, BeanFactory owner, Object factoryBean, final Method factoryMethod, Object... args)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: invokestatic 15	java/lang/System:getSecurityManager	()Ljava/lang/SecurityManager;
/*     */     //   3: ifnull +20 -> 23
/*     */     //   6: new 34	org/springframework/beans/factory/support/SimpleInstantiationStrategy$3
/*     */     //   9: dup
/*     */     //   10: aload_0
/*     */     //   11: aload 5
/*     */     //   13: invokespecial 35	org/springframework/beans/factory/support/SimpleInstantiationStrategy$3:<init>	(Lorg/springframework/beans/factory/support/SimpleInstantiationStrategy;Ljava/lang/reflect/Method;)V
/*     */     //   16: invokestatic 32	java/security/AccessController:doPrivileged	(Ljava/security/PrivilegedAction;)Ljava/lang/Object;
/*     */     //   19: pop
/*     */     //   20: goto +8 -> 28
/*     */     //   23: aload 5
/*     */     //   25: invokestatic 36	org/springframework/util/ReflectionUtils:makeAccessible	(Ljava/lang/reflect/Method;)V
/*     */     //   28: getstatic 2	org/springframework/beans/factory/support/SimpleInstantiationStrategy:currentlyInvokedFactoryMethod	Ljava/lang/ThreadLocal;
/*     */     //   31: invokevirtual 3	java/lang/ThreadLocal:get	()Ljava/lang/Object;
/*     */     //   34: checkcast 4	java/lang/reflect/Method
/*     */     //   37: astore 7
/*     */     //   39: getstatic 2	org/springframework/beans/factory/support/SimpleInstantiationStrategy:currentlyInvokedFactoryMethod	Ljava/lang/ThreadLocal;
/*     */     //   42: aload 5
/*     */     //   44: invokevirtual 37	java/lang/ThreadLocal:set	(Ljava/lang/Object;)V
/*     */     //   47: aload 5
/*     */     //   49: aload 4
/*     */     //   51: aload 6
/*     */     //   53: invokevirtual 38	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   56: astore 8
/*     */     //   58: aload 7
/*     */     //   60: ifnull +14 -> 74
/*     */     //   63: getstatic 2	org/springframework/beans/factory/support/SimpleInstantiationStrategy:currentlyInvokedFactoryMethod	Ljava/lang/ThreadLocal;
/*     */     //   66: aload 7
/*     */     //   68: invokevirtual 37	java/lang/ThreadLocal:set	(Ljava/lang/Object;)V
/*     */     //   71: goto +9 -> 80
/*     */     //   74: getstatic 2	org/springframework/beans/factory/support/SimpleInstantiationStrategy:currentlyInvokedFactoryMethod	Ljava/lang/ThreadLocal;
/*     */     //   77: invokevirtual 39	java/lang/ThreadLocal:remove	()V
/*     */     //   80: aload 8
/*     */     //   82: areturn
/*     */     //   83: astore 9
/*     */     //   85: aload 7
/*     */     //   87: ifnull +14 -> 101
/*     */     //   90: getstatic 2	org/springframework/beans/factory/support/SimpleInstantiationStrategy:currentlyInvokedFactoryMethod	Ljava/lang/ThreadLocal;
/*     */     //   93: aload 7
/*     */     //   95: invokevirtual 37	java/lang/ThreadLocal:set	(Ljava/lang/Object;)V
/*     */     //   98: goto +9 -> 107
/*     */     //   101: getstatic 2	org/springframework/beans/factory/support/SimpleInstantiationStrategy:currentlyInvokedFactoryMethod	Ljava/lang/ThreadLocal;
/*     */     //   104: invokevirtual 39	java/lang/ThreadLocal:remove	()V
/*     */     //   107: aload 9
/*     */     //   109: athrow
/*     */     //   110: astore 7
/*     */     //   112: new 12	org/springframework/beans/BeanInstantiationException
/*     */     //   115: dup
/*     */     //   116: aload 5
/*     */     //   118: new 41	java/lang/StringBuilder
/*     */     //   121: dup
/*     */     //   122: invokespecial 42	java/lang/StringBuilder:<init>	()V
/*     */     //   125: ldc 43
/*     */     //   127: invokevirtual 44	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   130: aload 5
/*     */     //   132: invokevirtual 45	java/lang/reflect/Method:getName	()Ljava/lang/String;
/*     */     //   135: invokevirtual 44	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   138: ldc 46
/*     */     //   140: invokevirtual 44	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   143: ldc 47
/*     */     //   145: invokevirtual 44	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   148: aload 6
/*     */     //   150: invokestatic 48	org/springframework/util/StringUtils:arrayToCommaDelimitedString	([Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   153: invokevirtual 44	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   156: invokevirtual 49	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   159: aload 7
/*     */     //   161: invokespecial 50	org/springframework/beans/BeanInstantiationException:<init>	(Ljava/lang/reflect/Method;Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   164: athrow
/*     */     //   165: astore 7
/*     */     //   167: new 12	org/springframework/beans/BeanInstantiationException
/*     */     //   170: dup
/*     */     //   171: aload 5
/*     */     //   173: new 41	java/lang/StringBuilder
/*     */     //   176: dup
/*     */     //   177: invokespecial 42	java/lang/StringBuilder:<init>	()V
/*     */     //   180: ldc 52
/*     */     //   182: invokevirtual 44	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   185: aload 5
/*     */     //   187: invokevirtual 45	java/lang/reflect/Method:getName	()Ljava/lang/String;
/*     */     //   190: invokevirtual 44	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   193: ldc 53
/*     */     //   195: invokevirtual 44	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   198: invokevirtual 49	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   201: aload 7
/*     */     //   203: invokespecial 50	org/springframework/beans/BeanInstantiationException:<init>	(Ljava/lang/reflect/Method;Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   206: athrow
/*     */     //   207: astore 7
/*     */     //   209: new 41	java/lang/StringBuilder
/*     */     //   212: dup
/*     */     //   213: invokespecial 42	java/lang/StringBuilder:<init>	()V
/*     */     //   216: ldc 55
/*     */     //   218: invokevirtual 44	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   221: aload 5
/*     */     //   223: invokevirtual 45	java/lang/reflect/Method:getName	()Ljava/lang/String;
/*     */     //   226: invokevirtual 44	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   229: ldc 56
/*     */     //   231: invokevirtual 44	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   234: invokevirtual 49	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   237: astore 8
/*     */     //   239: aload_1
/*     */     //   240: invokevirtual 57	org/springframework/beans/factory/support/RootBeanDefinition:getFactoryBeanName	()Ljava/lang/String;
/*     */     //   243: ifnull +65 -> 308
/*     */     //   246: aload_3
/*     */     //   247: instanceof 58
/*     */     //   250: ifeq +58 -> 308
/*     */     //   253: aload_3
/*     */     //   254: checkcast 58	org/springframework/beans/factory/config/ConfigurableBeanFactory
/*     */     //   257: aload_1
/*     */     //   258: invokevirtual 57	org/springframework/beans/factory/support/RootBeanDefinition:getFactoryBeanName	()Ljava/lang/String;
/*     */     //   261: invokeinterface 59 2 0
/*     */     //   266: ifeq +42 -> 308
/*     */     //   269: new 41	java/lang/StringBuilder
/*     */     //   272: dup
/*     */     //   273: invokespecial 42	java/lang/StringBuilder:<init>	()V
/*     */     //   276: ldc 60
/*     */     //   278: invokevirtual 44	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   281: aload_1
/*     */     //   282: invokevirtual 57	org/springframework/beans/factory/support/RootBeanDefinition:getFactoryBeanName	()Ljava/lang/String;
/*     */     //   285: invokevirtual 44	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   288: ldc 61
/*     */     //   290: invokevirtual 44	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   293: ldc 62
/*     */     //   295: invokevirtual 44	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   298: aload 8
/*     */     //   300: invokevirtual 44	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   303: invokevirtual 49	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   306: astore 8
/*     */     //   308: new 12	org/springframework/beans/BeanInstantiationException
/*     */     //   311: dup
/*     */     //   312: aload 5
/*     */     //   314: aload 8
/*     */     //   316: aload 7
/*     */     //   318: invokevirtual 63	java/lang/reflect/InvocationTargetException:getTargetException	()Ljava/lang/Throwable;
/*     */     //   321: invokespecial 50	org/springframework/beans/BeanInstantiationException:<init>	(Ljava/lang/reflect/Method;Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   324: athrow
/*     */     // Line number table:
/*     */     //   Java source line #146	-> byte code offset #0
/*     */     //   Java source line #147	-> byte code offset #6
/*     */     //   Java source line #156	-> byte code offset #23
/*     */     //   Java source line #159	-> byte code offset #28
/*     */     //   Java source line #161	-> byte code offset #39
/*     */     //   Java source line #162	-> byte code offset #47
/*     */     //   Java source line #165	-> byte code offset #58
/*     */     //   Java source line #166	-> byte code offset #63
/*     */     //   Java source line #169	-> byte code offset #74
/*     */     //   Java source line #165	-> byte code offset #83
/*     */     //   Java source line #166	-> byte code offset #90
/*     */     //   Java source line #169	-> byte code offset #101
/*     */     //   Java source line #173	-> byte code offset #110
/*     */     //   Java source line #174	-> byte code offset #112
/*     */     //   Java source line #175	-> byte code offset #132
/*     */     //   Java source line #176	-> byte code offset #150
/*     */     //   Java source line #178	-> byte code offset #165
/*     */     //   Java source line #179	-> byte code offset #167
/*     */     //   Java source line #180	-> byte code offset #187
/*     */     //   Java source line #182	-> byte code offset #207
/*     */     //   Java source line #183	-> byte code offset #209
/*     */     //   Java source line #184	-> byte code offset #239
/*     */     //   Java source line #185	-> byte code offset #258
/*     */     //   Java source line #186	-> byte code offset #269
/*     */     //   Java source line #189	-> byte code offset #308
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	325	0	this	SimpleInstantiationStrategy
/*     */     //   0	325	1	bd	RootBeanDefinition
/*     */     //   0	325	2	beanName	String
/*     */     //   0	325	3	owner	BeanFactory
/*     */     //   0	325	4	factoryBean	Object
/*     */     //   0	325	5	factoryMethod	Method
/*     */     //   0	325	6	args	Object[]
/*     */     //   37	57	7	priorInvokedFactoryMethod	Method
/*     */     //   110	50	7	ex	IllegalArgumentException
/*     */     //   165	37	7	ex	IllegalAccessException
/*     */     //   207	110	7	ex	java.lang.reflect.InvocationTargetException
/*     */     //   237	78	8	msg	String
/*     */     //   83	25	9	localObject2	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   39	58	83	finally
/*     */     //   83	85	83	finally
/*     */     //   0	80	110	java/lang/IllegalArgumentException
/*     */     //   83	110	110	java/lang/IllegalArgumentException
/*     */     //   0	80	165	java/lang/IllegalAccessException
/*     */     //   83	110	165	java/lang/IllegalAccessException
/*     */     //   0	80	207	java/lang/reflect/InvocationTargetException
/*     */     //   83	110	207	java/lang/reflect/InvocationTargetException
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-beans-4.3.2.RELEASE.jar!\org\springframework\beans\factory\support\SimpleInstantiationStrategy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */