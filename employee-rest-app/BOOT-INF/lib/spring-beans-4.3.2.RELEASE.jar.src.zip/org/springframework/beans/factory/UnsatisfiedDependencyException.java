/*     */ package org.springframework.beans.factory;
/*     */ 
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnsatisfiedDependencyException
/*     */   extends BeanCreationException
/*     */ {
/*     */   private InjectionPoint injectionPoint;
/*     */   
/*     */   public UnsatisfiedDependencyException(String resourceDescription, String beanName, String propertyName, String msg)
/*     */   {
/*  47 */     super(resourceDescription, beanName, "Unsatisfied dependency expressed through bean property '" + propertyName + "'" + (msg != null ? ": " + msg : ""));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UnsatisfiedDependencyException(String resourceDescription, String beanName, String propertyName, BeansException ex)
/*     */   {
/*  62 */     this(resourceDescription, beanName, propertyName, ex != null ? ex.getMessage() : "");
/*  63 */     initCause(ex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UnsatisfiedDependencyException(String resourceDescription, String beanName, InjectionPoint injectionPoint, String msg)
/*     */   {
/*  77 */     super(resourceDescription, beanName, "Unsatisfied dependency expressed through " + injectionPoint + ": " + msg);
/*  78 */     this.injectionPoint = injectionPoint;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UnsatisfiedDependencyException(String resourceDescription, String beanName, InjectionPoint injectionPoint, BeansException ex)
/*     */   {
/*  92 */     this(resourceDescription, beanName, injectionPoint, ex != null ? ex.getMessage() : "");
/*  93 */     initCause(ex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public UnsatisfiedDependencyException(String resourceDescription, String beanName, int ctorArgIndex, Class<?> ctorArgType, String msg)
/*     */   {
/* 109 */     super(resourceDescription, beanName, "Unsatisfied dependency expressed through constructor argument with index " + ctorArgIndex + " of type [" + 
/*     */     
/* 111 */       ClassUtils.getQualifiedName(ctorArgType) + "]" + (msg != null ? ": " + msg : ""));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public UnsatisfiedDependencyException(String resourceDescription, String beanName, int ctorArgIndex, Class<?> ctorArgType, BeansException ex)
/*     */   {
/* 128 */     this(resourceDescription, beanName, ctorArgIndex, ctorArgType, ex != null ? ex.getMessage() : "");
/* 129 */     initCause(ex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InjectionPoint getInjectionPoint()
/*     */   {
/* 138 */     return this.injectionPoint;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-beans-4.3.2.RELEASE.jar!\org\springframework\beans\factory\UnsatisfiedDependencyException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */