package org.springframework.beans.factory.support;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;

public abstract interface BeanDefinitionRegistryPostProcessor
  extends BeanFactoryPostProcessor
{
  public abstract void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry paramBeanDefinitionRegistry)
    throws BeansException;
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-beans-4.3.2.RELEASE.jar!\org\springframework\beans\factory\support\BeanDefinitionRegistryPostProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */