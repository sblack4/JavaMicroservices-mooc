/*     */ package org.springframework.beans.factory;
/*     */ 
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NoSuchBeanDefinitionException
/*     */   extends BeansException
/*     */ {
/*     */   private String beanName;
/*     */   private Class<?> beanType;
/*     */   
/*     */   public NoSuchBeanDefinitionException(String name)
/*     */   {
/*  48 */     super("No bean named '" + name + "' is defined");
/*  49 */     this.beanName = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NoSuchBeanDefinitionException(String name, String message)
/*     */   {
/*  58 */     super("No bean named '" + name + "' is defined: " + message);
/*  59 */     this.beanName = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NoSuchBeanDefinitionException(Class<?> type)
/*     */   {
/*  67 */     super("No qualifying bean of type [" + type.getName() + "] is defined");
/*  68 */     this.beanType = type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NoSuchBeanDefinitionException(Class<?> type, String message)
/*     */   {
/*  77 */     super("No qualifying bean of type [" + type.getName() + "] is defined: " + message);
/*  78 */     this.beanType = type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NoSuchBeanDefinitionException(Class<?> type, String dependencyDescription, String message)
/*     */   {
/*  88 */     super("No qualifying bean of type [" + type.getName() + "] found for dependency" + (
/*  89 */       StringUtils.hasLength(dependencyDescription) ? " [" + dependencyDescription + "]" : "") + ": " + message);
/*     */     
/*  91 */     this.beanType = type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBeanName()
/*     */   {
/*  99 */     return this.beanName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Class<?> getBeanType()
/*     */   {
/* 106 */     return this.beanType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumberOfBeansFound()
/*     */   {
/* 115 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-beans-4.3.2.RELEASE.jar!\org\springframework\beans\factory\NoSuchBeanDefinitionException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */