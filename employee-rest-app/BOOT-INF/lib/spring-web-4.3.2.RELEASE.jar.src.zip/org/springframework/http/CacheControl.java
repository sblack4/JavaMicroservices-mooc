/*     */ package org.springframework.http;
/*     */ 
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CacheControl
/*     */ {
/*  52 */   private long maxAge = -1L;
/*     */   
/*  54 */   private boolean noCache = false;
/*     */   
/*  56 */   private boolean noStore = false;
/*     */   
/*  58 */   private boolean mustRevalidate = false;
/*     */   
/*  60 */   private boolean noTransform = false;
/*     */   
/*  62 */   private boolean cachePublic = false;
/*     */   
/*  64 */   private boolean cachePrivate = false;
/*     */   
/*  66 */   private boolean proxyRevalidate = false;
/*     */   
/*  68 */   private long staleWhileRevalidate = -1L;
/*     */   
/*  70 */   private long staleIfError = -1L;
/*     */   
/*  72 */   private long sMaxAge = -1L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CacheControl empty()
/*     */   {
/*  89 */     return new CacheControl();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CacheControl maxAge(long maxAge, TimeUnit unit)
/*     */   {
/* 105 */     CacheControl cc = new CacheControl();
/* 106 */     cc.maxAge = unit.toSeconds(maxAge);
/* 107 */     return cc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CacheControl noCache()
/*     */   {
/* 122 */     CacheControl cc = new CacheControl();
/* 123 */     cc.noCache = true;
/* 124 */     return cc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CacheControl noStore()
/*     */   {
/* 134 */     CacheControl cc = new CacheControl();
/* 135 */     cc.noStore = true;
/* 136 */     return cc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CacheControl mustRevalidate()
/*     */   {
/* 148 */     this.mustRevalidate = true;
/* 149 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CacheControl noTransform()
/*     */   {
/* 160 */     this.noTransform = true;
/* 161 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CacheControl cachePublic()
/*     */   {
/* 172 */     this.cachePublic = true;
/* 173 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CacheControl cachePrivate()
/*     */   {
/* 184 */     this.cachePrivate = true;
/* 185 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CacheControl proxyRevalidate()
/*     */   {
/* 196 */     this.proxyRevalidate = true;
/* 197 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CacheControl sMaxAge(long sMaxAge, TimeUnit unit)
/*     */   {
/* 210 */     this.sMaxAge = unit.toSeconds(sMaxAge);
/* 211 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CacheControl staleWhileRevalidate(long staleWhileRevalidate, TimeUnit unit)
/*     */   {
/* 226 */     this.staleWhileRevalidate = unit.toSeconds(staleWhileRevalidate);
/* 227 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CacheControl staleIfError(long staleIfError, TimeUnit unit)
/*     */   {
/* 240 */     this.staleIfError = unit.toSeconds(staleIfError);
/* 241 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHeaderValue()
/*     */   {
/* 250 */     StringBuilder ccValue = new StringBuilder();
/* 251 */     if (this.maxAge != -1L) {
/* 252 */       appendDirective(ccValue, "max-age=" + Long.toString(this.maxAge));
/*     */     }
/* 254 */     if (this.noCache) {
/* 255 */       appendDirective(ccValue, "no-cache");
/*     */     }
/* 257 */     if (this.noStore) {
/* 258 */       appendDirective(ccValue, "no-store");
/*     */     }
/* 260 */     if (this.mustRevalidate) {
/* 261 */       appendDirective(ccValue, "must-revalidate");
/*     */     }
/* 263 */     if (this.noTransform) {
/* 264 */       appendDirective(ccValue, "no-transform");
/*     */     }
/* 266 */     if (this.cachePublic) {
/* 267 */       appendDirective(ccValue, "public");
/*     */     }
/* 269 */     if (this.cachePrivate) {
/* 270 */       appendDirective(ccValue, "private");
/*     */     }
/* 272 */     if (this.proxyRevalidate) {
/* 273 */       appendDirective(ccValue, "proxy-revalidate");
/*     */     }
/* 275 */     if (this.sMaxAge != -1L) {
/* 276 */       appendDirective(ccValue, "s-maxage=" + Long.toString(this.sMaxAge));
/*     */     }
/* 278 */     if (this.staleIfError != -1L) {
/* 279 */       appendDirective(ccValue, "stale-if-error=" + Long.toString(this.staleIfError));
/*     */     }
/* 281 */     if (this.staleWhileRevalidate != -1L) {
/* 282 */       appendDirective(ccValue, "stale-while-revalidate=" + Long.toString(this.staleWhileRevalidate));
/*     */     }
/*     */     
/* 285 */     String ccHeaderValue = ccValue.toString();
/* 286 */     return StringUtils.hasText(ccHeaderValue) ? ccHeaderValue : null;
/*     */   }
/*     */   
/*     */   private void appendDirective(StringBuilder builder, String value) {
/* 290 */     if (builder.length() > 0) {
/* 291 */       builder.append(", ");
/*     */     }
/* 293 */     builder.append(value);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\CacheControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */