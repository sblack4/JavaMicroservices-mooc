/*     */ package org.springframework.http;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.InvalidMimeTypeException;
/*     */ import org.springframework.util.MimeType;
/*     */ import org.springframework.util.MimeType.SpecificityComparator;
/*     */ import org.springframework.util.MimeTypeUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.comparator.CompoundComparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MediaType
/*     */   extends MimeType
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2069937152339670231L;
/* 229 */   public static final MediaType ALL = valueOf("*/*");
/* 230 */   public static final String ALL_VALUE = "*/*"; public static final MediaType APPLICATION_ATOM_XML = valueOf("application/atom+xml");
/* 231 */   public static final String APPLICATION_ATOM_XML_VALUE = "application/atom+xml"; public static final MediaType APPLICATION_FORM_URLENCODED = valueOf("application/x-www-form-urlencoded");
/* 232 */   public static final String APPLICATION_FORM_URLENCODED_VALUE = "application/x-www-form-urlencoded"; public static final MediaType APPLICATION_JSON = valueOf("application/json");
/* 233 */   public static final String APPLICATION_JSON_VALUE = "application/json"; public static final MediaType APPLICATION_JSON_UTF8 = valueOf("application/json;charset=UTF-8");
/* 234 */   public static final String APPLICATION_JSON_UTF8_VALUE = "application/json;charset=UTF-8"; public static final MediaType APPLICATION_OCTET_STREAM = valueOf("application/octet-stream");
/* 235 */   public static final String APPLICATION_OCTET_STREAM_VALUE = "application/octet-stream"; public static final MediaType APPLICATION_PDF = valueOf("application/pdf");
/* 236 */   public static final String APPLICATION_PDF_VALUE = "application/pdf"; public static final MediaType APPLICATION_XHTML_XML = valueOf("application/xhtml+xml");
/* 237 */   public static final String APPLICATION_XHTML_XML_VALUE = "application/xhtml+xml"; public static final MediaType APPLICATION_XML = valueOf("application/xml");
/* 238 */   public static final String APPLICATION_XML_VALUE = "application/xml"; public static final MediaType IMAGE_GIF = valueOf("image/gif");
/* 239 */   public static final String IMAGE_GIF_VALUE = "image/gif"; public static final MediaType IMAGE_JPEG = valueOf("image/jpeg");
/* 240 */   public static final String IMAGE_JPEG_VALUE = "image/jpeg"; public static final MediaType IMAGE_PNG = valueOf("image/png");
/* 241 */   public static final String IMAGE_PNG_VALUE = "image/png"; public static final MediaType MULTIPART_FORM_DATA = valueOf("multipart/form-data");
/* 242 */   public static final String MULTIPART_FORM_DATA_VALUE = "multipart/form-data"; public static final MediaType TEXT_HTML = valueOf("text/html");
/* 243 */   public static final String TEXT_HTML_VALUE = "text/html"; public static final MediaType TEXT_MARKDOWN = valueOf("text/markdown");
/* 244 */   public static final String TEXT_MARKDOWN_VALUE = "text/markdown"; public static final MediaType TEXT_PLAIN = valueOf("text/plain");
/* 245 */   public static final String TEXT_PLAIN_VALUE = "text/plain"; public static final MediaType TEXT_XML = valueOf("text/xml");
/*     */   
/*     */ 
/*     */   public static final String TEXT_XML_VALUE = "text/xml";
/*     */   
/*     */ 
/*     */   private static final String PARAM_QUALITY_FACTOR = "q";
/*     */   
/*     */ 
/*     */   public MediaType(String type)
/*     */   {
/* 256 */     super(type);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MediaType(String type, String subtype)
/*     */   {
/* 267 */     super(type, subtype, Collections.emptyMap());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MediaType(String type, String subtype, Charset charset)
/*     */   {
/* 278 */     super(type, subtype, charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MediaType(String type, String subtype, double qualityValue)
/*     */   {
/* 289 */     this(type, subtype, Collections.singletonMap("q", Double.toString(qualityValue)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MediaType(MediaType other, Charset charset)
/*     */   {
/* 300 */     super(other, charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MediaType(MediaType other, Map<String, String> parameters)
/*     */   {
/* 311 */     super(other.getType(), other.getSubtype(), parameters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MediaType(String type, String subtype, Map<String, String> parameters)
/*     */   {
/* 322 */     super(type, subtype, parameters);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void checkParameters(String attribute, String value)
/*     */   {
/* 328 */     super.checkParameters(attribute, value);
/* 329 */     if ("q".equals(attribute)) {
/* 330 */       value = unquote(value);
/* 331 */       double d = Double.parseDouble(value);
/* 332 */       Assert.isTrue((d >= 0.0D) && (d <= 1.0D), "Invalid quality value \"" + value + "\": should be between 0.0 and 1.0");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getQualityValue()
/*     */   {
/* 343 */     String qualityFactory = getParameter("q");
/* 344 */     return qualityFactory != null ? Double.parseDouble(unquote(qualityFactory)) : 1.0D;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean includes(MediaType other)
/*     */   {
/* 355 */     return super.includes(other);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCompatibleWith(MediaType other)
/*     */   {
/* 366 */     return super.isCompatibleWith(other);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MediaType copyQualityValue(MediaType mediaType)
/*     */   {
/* 374 */     if (!mediaType.getParameters().containsKey("q")) {
/* 375 */       return this;
/*     */     }
/* 377 */     Map<String, String> params = new LinkedHashMap(getParameters());
/* 378 */     params.put("q", mediaType.getParameters().get("q"));
/* 379 */     return new MediaType(this, params);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MediaType removeQualityValue()
/*     */   {
/* 387 */     if (!getParameters().containsKey("q")) {
/* 388 */       return this;
/*     */     }
/* 390 */     Map<String, String> params = new LinkedHashMap(getParameters());
/* 391 */     params.remove("q");
/* 392 */     return new MediaType(this, params);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MediaType valueOf(String value)
/*     */   {
/* 405 */     return parseMediaType(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MediaType parseMediaType(String mediaType)
/*     */   {
/*     */     try
/*     */     {
/* 417 */       type = MimeTypeUtils.parseMimeType(mediaType);
/*     */     } catch (InvalidMimeTypeException ex) {
/*     */       MimeType type;
/* 420 */       throw new InvalidMediaTypeException(ex);
/*     */     }
/*     */     try { MimeType type;
/* 423 */       return new MediaType(type.getType(), type.getSubtype(), type.getParameters());
/*     */     }
/*     */     catch (IllegalArgumentException ex) {
/* 426 */       throw new InvalidMediaTypeException(mediaType, ex.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<MediaType> parseMediaTypes(String mediaTypes)
/*     */   {
/* 438 */     if (!StringUtils.hasLength(mediaTypes)) {
/* 439 */       return Collections.emptyList();
/*     */     }
/* 441 */     String[] tokens = mediaTypes.split(",\\s*");
/* 442 */     List<MediaType> result = new ArrayList(tokens.length);
/* 443 */     for (String token : tokens) {
/* 444 */       result.add(parseMediaType(token));
/*     */     }
/* 446 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<MediaType> parseMediaTypes(List<String> mediaTypes)
/*     */   {
/* 459 */     if (CollectionUtils.isEmpty(mediaTypes)) {
/* 460 */       return Collections.emptyList();
/*     */     }
/* 462 */     if (mediaTypes.size() == 1) {
/* 463 */       return parseMediaTypes((String)mediaTypes.get(0));
/*     */     }
/*     */     
/* 466 */     List<MediaType> result = new ArrayList(8);
/* 467 */     for (String mediaType : mediaTypes) {
/* 468 */       result.addAll(parseMediaTypes(mediaType));
/*     */     }
/* 470 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toString(Collection<MediaType> mediaTypes)
/*     */   {
/* 481 */     return MimeTypeUtils.toString(mediaTypes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void sortBySpecificity(List<MediaType> mediaTypes)
/*     */   {
/* 512 */     Assert.notNull(mediaTypes, "'mediaTypes' must not be null");
/* 513 */     if (mediaTypes.size() > 1) {
/* 514 */       Collections.sort(mediaTypes, SPECIFICITY_COMPARATOR);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void sortByQualityValue(List<MediaType> mediaTypes)
/*     */   {
/* 539 */     Assert.notNull(mediaTypes, "'mediaTypes' must not be null");
/* 540 */     if (mediaTypes.size() > 1) {
/* 541 */       Collections.sort(mediaTypes, QUALITY_VALUE_COMPARATOR);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void sortBySpecificityAndQuality(List<MediaType> mediaTypes)
/*     */   {
/* 552 */     Assert.notNull(mediaTypes, "'mediaTypes' must not be null");
/* 553 */     if (mediaTypes.size() > 1) {
/* 554 */       Collections.sort(mediaTypes, new CompoundComparator(new Comparator[] { SPECIFICITY_COMPARATOR, QUALITY_VALUE_COMPARATOR }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 563 */   public static final Comparator<MediaType> QUALITY_VALUE_COMPARATOR = new Comparator()
/*     */   {
/*     */     public int compare(MediaType mediaType1, MediaType mediaType2)
/*     */     {
/* 567 */       double quality1 = mediaType1.getQualityValue();
/* 568 */       double quality2 = mediaType2.getQualityValue();
/* 569 */       int qualityComparison = Double.compare(quality2, quality1);
/* 570 */       if (qualityComparison != 0) {
/* 571 */         return qualityComparison;
/*     */       }
/* 573 */       if ((mediaType1.isWildcardType()) && (!mediaType2.isWildcardType())) {
/* 574 */         return 1;
/*     */       }
/* 576 */       if ((mediaType2.isWildcardType()) && (!mediaType1.isWildcardType())) {
/* 577 */         return -1;
/*     */       }
/* 579 */       if (!mediaType1.getType().equals(mediaType2.getType())) {
/* 580 */         return 0;
/*     */       }
/*     */       
/* 583 */       if ((mediaType1.isWildcardSubtype()) && (!mediaType2.isWildcardSubtype())) {
/* 584 */         return 1;
/*     */       }
/* 586 */       if ((mediaType2.isWildcardSubtype()) && (!mediaType1.isWildcardSubtype())) {
/* 587 */         return -1;
/*     */       }
/* 589 */       if (!mediaType1.getSubtype().equals(mediaType2.getSubtype())) {
/* 590 */         return 0;
/*     */       }
/*     */       
/* 593 */       int paramsSize1 = mediaType1.getParameters().size();
/* 594 */       int paramsSize2 = mediaType2.getParameters().size();
/* 595 */       return paramsSize2 == paramsSize1 ? 0 : paramsSize2 < paramsSize1 ? -1 : 1;
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 605 */   public static final Comparator<MediaType> SPECIFICITY_COMPARATOR = new MimeType.SpecificityComparator()
/*     */   {
/*     */     protected int compareParameters(MediaType mediaType1, MediaType mediaType2)
/*     */     {
/* 609 */       double quality1 = mediaType1.getQualityValue();
/* 610 */       double quality2 = mediaType2.getQualityValue();
/* 611 */       int qualityComparison = Double.compare(quality2, quality1);
/* 612 */       if (qualityComparison != 0) {
/* 613 */         return qualityComparison;
/*     */       }
/* 615 */       return super.compareParameters(mediaType1, mediaType2);
/*     */     }
/*     */   };
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\MediaType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */