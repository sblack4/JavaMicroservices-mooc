/*      */ package org.springframework.http;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.net.URI;
/*      */ import java.nio.charset.Charset;
/*      */ import java.text.ParseException;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.EnumSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.TimeZone;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*      */ import org.springframework.util.MultiValueMap;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HttpHeaders
/*      */   implements MultiValueMap<String, String>, Serializable
/*      */ {
/*      */   private static final long serialVersionUID = -8578554704772377436L;
/*      */   public static final String ACCEPT = "Accept";
/*      */   public static final String ACCEPT_CHARSET = "Accept-Charset";
/*      */   public static final String ACCEPT_ENCODING = "Accept-Encoding";
/*      */   public static final String ACCEPT_LANGUAGE = "Accept-Language";
/*      */   public static final String ACCEPT_RANGES = "Accept-Ranges";
/*      */   public static final String ACCESS_CONTROL_ALLOW_CREDENTIALS = "Access-Control-Allow-Credentials";
/*      */   public static final String ACCESS_CONTROL_ALLOW_HEADERS = "Access-Control-Allow-Headers";
/*      */   public static final String ACCESS_CONTROL_ALLOW_METHODS = "Access-Control-Allow-Methods";
/*      */   public static final String ACCESS_CONTROL_ALLOW_ORIGIN = "Access-Control-Allow-Origin";
/*      */   public static final String ACCESS_CONTROL_EXPOSE_HEADERS = "Access-Control-Expose-Headers";
/*      */   public static final String ACCESS_CONTROL_MAX_AGE = "Access-Control-Max-Age";
/*      */   public static final String ACCESS_CONTROL_REQUEST_HEADERS = "Access-Control-Request-Headers";
/*      */   public static final String ACCESS_CONTROL_REQUEST_METHOD = "Access-Control-Request-Method";
/*      */   public static final String AGE = "Age";
/*      */   public static final String ALLOW = "Allow";
/*      */   public static final String AUTHORIZATION = "Authorization";
/*      */   public static final String CACHE_CONTROL = "Cache-Control";
/*      */   public static final String CONNECTION = "Connection";
/*      */   public static final String CONTENT_ENCODING = "Content-Encoding";
/*      */   public static final String CONTENT_DISPOSITION = "Content-Disposition";
/*      */   public static final String CONTENT_LANGUAGE = "Content-Language";
/*      */   public static final String CONTENT_LENGTH = "Content-Length";
/*      */   public static final String CONTENT_LOCATION = "Content-Location";
/*      */   public static final String CONTENT_RANGE = "Content-Range";
/*      */   public static final String CONTENT_TYPE = "Content-Type";
/*      */   public static final String COOKIE = "Cookie";
/*      */   public static final String DATE = "Date";
/*      */   public static final String ETAG = "ETag";
/*      */   public static final String EXPECT = "Expect";
/*      */   public static final String EXPIRES = "Expires";
/*      */   public static final String FROM = "From";
/*      */   public static final String HOST = "Host";
/*      */   public static final String IF_MATCH = "If-Match";
/*      */   public static final String IF_MODIFIED_SINCE = "If-Modified-Since";
/*      */   public static final String IF_NONE_MATCH = "If-None-Match";
/*      */   public static final String IF_RANGE = "If-Range";
/*      */   public static final String IF_UNMODIFIED_SINCE = "If-Unmodified-Since";
/*      */   public static final String LAST_MODIFIED = "Last-Modified";
/*      */   public static final String LINK = "Link";
/*      */   public static final String LOCATION = "Location";
/*      */   public static final String MAX_FORWARDS = "Max-Forwards";
/*      */   public static final String ORIGIN = "Origin";
/*      */   public static final String PRAGMA = "Pragma";
/*      */   public static final String PROXY_AUTHENTICATE = "Proxy-Authenticate";
/*      */   public static final String PROXY_AUTHORIZATION = "Proxy-Authorization";
/*      */   public static final String RANGE = "Range";
/*      */   public static final String REFERER = "Referer";
/*      */   public static final String RETRY_AFTER = "Retry-After";
/*      */   public static final String SERVER = "Server";
/*      */   public static final String SET_COOKIE = "Set-Cookie";
/*      */   public static final String SET_COOKIE2 = "Set-Cookie2";
/*      */   public static final String TE = "TE";
/*      */   public static final String TRAILER = "Trailer";
/*      */   public static final String TRANSFER_ENCODING = "Transfer-Encoding";
/*      */   public static final String UPGRADE = "Upgrade";
/*      */   public static final String USER_AGENT = "User-Agent";
/*      */   public static final String VARY = "Vary";
/*      */   public static final String VIA = "Via";
/*      */   public static final String WARNING = "Warning";
/*      */   public static final String WWW_AUTHENTICATE = "WWW-Authenticate";
/*  373 */   private static final String[] DATE_FORMATS = { "EEE, dd MMM yyyy HH:mm:ss zzz", "EEE, dd-MMM-yy HH:mm:ss zzz", "EEE MMM dd HH:mm:ss yyyy" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  383 */   private static final Pattern ETAG_HEADER_VALUE_PATTERN = Pattern.compile("\\*|\\s*((W\\/)?(\"[^\"]*\"))\\s*,?");
/*      */   
/*  385 */   private static TimeZone GMT = TimeZone.getTimeZone("GMT");
/*      */   
/*      */ 
/*      */ 
/*      */   private final Map<String, List<String>> headers;
/*      */   
/*      */ 
/*      */ 
/*      */   public HttpHeaders()
/*      */   {
/*  395 */     this(new LinkedCaseInsensitiveMap(8, Locale.ENGLISH), false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private HttpHeaders(Map<String, List<String>> headers, boolean readOnly)
/*      */   {
/*  402 */     Assert.notNull(headers, "'headers' must not be null");
/*  403 */     if (readOnly)
/*      */     {
/*  405 */       Map<String, List<String>> map = new LinkedCaseInsensitiveMap(headers.size(), Locale.ENGLISH);
/*  406 */       for (Map.Entry<String, List<String>> entry : headers.entrySet()) {
/*  407 */         List<String> values = Collections.unmodifiableList((List)entry.getValue());
/*  408 */         map.put(entry.getKey(), values);
/*      */       }
/*  410 */       this.headers = Collections.unmodifiableMap(map);
/*      */     }
/*      */     else {
/*  413 */       this.headers = headers;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAccept(List<MediaType> acceptableMediaTypes)
/*      */   {
/*  423 */     set("Accept", MediaType.toString(acceptableMediaTypes));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<MediaType> getAccept()
/*      */   {
/*  432 */     return MediaType.parseMediaTypes(get("Accept"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setAccessControlAllowCredentials(boolean allowCredentials)
/*      */   {
/*  439 */     set("Access-Control-Allow-Credentials", Boolean.toString(allowCredentials));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getAccessControlAllowCredentials()
/*      */   {
/*  446 */     return Boolean.parseBoolean(getFirst("Access-Control-Allow-Credentials"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setAccessControlAllowHeaders(List<String> allowedHeaders)
/*      */   {
/*  453 */     set("Access-Control-Allow-Headers", toCommaDelimitedString(allowedHeaders));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public List<String> getAccessControlAllowHeaders()
/*      */   {
/*  460 */     return getValuesAsList("Access-Control-Allow-Headers");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setAccessControlAllowMethods(List<HttpMethod> allowedMethods)
/*      */   {
/*  467 */     set("Access-Control-Allow-Methods", StringUtils.collectionToCommaDelimitedString(allowedMethods));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public List<HttpMethod> getAccessControlAllowMethods()
/*      */   {
/*  474 */     List<HttpMethod> result = new ArrayList();
/*  475 */     String value = getFirst("Access-Control-Allow-Methods");
/*  476 */     if (value != null) {
/*  477 */       String[] tokens = StringUtils.tokenizeToStringArray(value, ",", true, true);
/*  478 */       for (String token : tokens) {
/*  479 */         HttpMethod resolved = HttpMethod.resolve(token);
/*  480 */         if (resolved != null) {
/*  481 */           result.add(resolved);
/*      */         }
/*      */       }
/*      */     }
/*  485 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setAccessControlAllowOrigin(String allowedOrigin)
/*      */   {
/*  492 */     set("Access-Control-Allow-Origin", allowedOrigin);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getAccessControlAllowOrigin()
/*      */   {
/*  499 */     return getFieldValues("Access-Control-Allow-Origin");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setAccessControlExposeHeaders(List<String> exposedHeaders)
/*      */   {
/*  506 */     set("Access-Control-Expose-Headers", toCommaDelimitedString(exposedHeaders));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public List<String> getAccessControlExposeHeaders()
/*      */   {
/*  513 */     return getValuesAsList("Access-Control-Expose-Headers");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setAccessControlMaxAge(long maxAge)
/*      */   {
/*  520 */     set("Access-Control-Max-Age", Long.toString(maxAge));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getAccessControlMaxAge()
/*      */   {
/*  528 */     String value = getFirst("Access-Control-Max-Age");
/*  529 */     return value != null ? Long.parseLong(value) : -1L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setAccessControlRequestHeaders(List<String> requestHeaders)
/*      */   {
/*  536 */     set("Access-Control-Request-Headers", toCommaDelimitedString(requestHeaders));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public List<String> getAccessControlRequestHeaders()
/*      */   {
/*  543 */     return getValuesAsList("Access-Control-Request-Headers");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setAccessControlRequestMethod(HttpMethod requestedMethod)
/*      */   {
/*  550 */     set("Access-Control-Request-Method", requestedMethod.name());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public HttpMethod getAccessControlRequestMethod()
/*      */   {
/*  557 */     return HttpMethod.resolve(getFirst("Access-Control-Request-Method"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAcceptCharset(List<Charset> acceptableCharsets)
/*      */   {
/*  565 */     StringBuilder builder = new StringBuilder();
/*  566 */     for (Iterator<Charset> iterator = acceptableCharsets.iterator(); iterator.hasNext();) {
/*  567 */       Charset charset = (Charset)iterator.next();
/*  568 */       builder.append(charset.name().toLowerCase(Locale.ENGLISH));
/*  569 */       if (iterator.hasNext()) {
/*  570 */         builder.append(", ");
/*      */       }
/*      */     }
/*  573 */     set("Accept-Charset", builder.toString());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<Charset> getAcceptCharset()
/*      */   {
/*  581 */     List<Charset> result = new ArrayList();
/*  582 */     String value = getFirst("Accept-Charset");
/*  583 */     if (value != null) {
/*  584 */       String[] tokens = value.split(",\\s*");
/*  585 */       for (String token : tokens) {
/*  586 */         int paramIdx = token.indexOf(';');
/*      */         String charsetName;
/*  588 */         String charsetName; if (paramIdx == -1) {
/*  589 */           charsetName = token;
/*      */         }
/*      */         else {
/*  592 */           charsetName = token.substring(0, paramIdx);
/*      */         }
/*  594 */         if (!charsetName.equals("*")) {
/*  595 */           result.add(Charset.forName(charsetName));
/*      */         }
/*      */       }
/*      */     }
/*  599 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAllow(Set<HttpMethod> allowedMethods)
/*      */   {
/*  607 */     set("Allow", StringUtils.collectionToCommaDelimitedString(allowedMethods));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<HttpMethod> getAllow()
/*      */   {
/*  616 */     String value = getFirst("Allow");
/*  617 */     if (!StringUtils.isEmpty(value)) {
/*  618 */       List<HttpMethod> result = new LinkedList();
/*  619 */       String[] tokens = value.split(",\\s*");
/*  620 */       for (String token : tokens) {
/*  621 */         HttpMethod resolved = HttpMethod.resolve(token);
/*  622 */         if (resolved != null) {
/*  623 */           result.add(resolved);
/*      */         }
/*      */       }
/*  626 */       return EnumSet.copyOf(result);
/*      */     }
/*      */     
/*  629 */     return EnumSet.noneOf(HttpMethod.class);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCacheControl(String cacheControl)
/*      */   {
/*  637 */     set("Cache-Control", cacheControl);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getCacheControl()
/*      */   {
/*  644 */     return getFieldValues("Cache-Control");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setConnection(String connection)
/*      */   {
/*  651 */     set("Connection", connection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setConnection(List<String> connection)
/*      */   {
/*  658 */     set("Connection", toCommaDelimitedString(connection));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public List<String> getConnection()
/*      */   {
/*  665 */     return getValuesAsList("Connection");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setContentDispositionFormData(String name, String filename)
/*      */   {
/*  675 */     Assert.notNull(name, "'name' must not be null");
/*  676 */     StringBuilder builder = new StringBuilder("form-data; name=\"");
/*  677 */     builder.append(name).append('"');
/*  678 */     if (filename != null) {
/*  679 */       builder.append("; filename=\"");
/*  680 */       builder.append(filename).append('"');
/*      */     }
/*  682 */     set("Content-Disposition", builder.toString());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setContentLength(long contentLength)
/*      */   {
/*  690 */     set("Content-Length", Long.toString(contentLength));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getContentLength()
/*      */   {
/*  699 */     String value = getFirst("Content-Length");
/*  700 */     return value != null ? Long.parseLong(value) : -1L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setContentType(MediaType mediaType)
/*      */   {
/*  708 */     Assert.isTrue(!mediaType.isWildcardType(), "'Content-Type' cannot contain wildcard type '*'");
/*  709 */     Assert.isTrue(!mediaType.isWildcardSubtype(), "'Content-Type' cannot contain wildcard subtype '*'");
/*  710 */     set("Content-Type", mediaType.toString());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MediaType getContentType()
/*      */   {
/*  719 */     String value = getFirst("Content-Type");
/*  720 */     return StringUtils.hasLength(value) ? MediaType.parseMediaType(value) : null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDate(long date)
/*      */   {
/*  730 */     setDate("Date", date);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getDate()
/*      */   {
/*  741 */     return getFirstDate("Date");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setETag(String eTag)
/*      */   {
/*  748 */     if (eTag != null) {
/*  749 */       Assert.isTrue((eTag.startsWith("\"")) || (eTag.startsWith("W/")), "Invalid eTag, does not start with W/ or \"");
/*      */       
/*  751 */       Assert.isTrue(eTag.endsWith("\""), "Invalid eTag, does not end with \"");
/*      */     }
/*  753 */     set("ETag", eTag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getETag()
/*      */   {
/*  760 */     return getFirst("ETag");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setExpires(long expires)
/*      */   {
/*  770 */     setDate("Expires", expires);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getExpires()
/*      */   {
/*  780 */     return getFirstDate("Expires", false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIfMatch(String ifMatch)
/*      */   {
/*  788 */     set("If-Match", ifMatch);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIfMatch(List<String> ifMatchList)
/*      */   {
/*  796 */     set("If-Match", toCommaDelimitedString(ifMatchList));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<String> getIfMatch()
/*      */   {
/*  804 */     return getETagValuesAsList("If-Match");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIfModifiedSince(long ifModifiedSince)
/*      */   {
/*  813 */     setDate("If-Modified-Since", ifModifiedSince);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getIfModifiedSince()
/*      */   {
/*  822 */     return getFirstDate("If-Modified-Since", false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setIfNoneMatch(String ifNoneMatch)
/*      */   {
/*  829 */     set("If-None-Match", ifNoneMatch);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setIfNoneMatch(List<String> ifNoneMatchList)
/*      */   {
/*  836 */     set("If-None-Match", toCommaDelimitedString(ifNoneMatchList));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public List<String> getIfNoneMatch()
/*      */   {
/*  843 */     return getETagValuesAsList("If-None-Match");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIfUnmodifiedSince(long ifUnmodifiedSince)
/*      */   {
/*  853 */     setDate("If-Unmodified-Since", ifUnmodifiedSince);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getIfUnmodifiedSince()
/*      */   {
/*  863 */     return getFirstDate("If-Unmodified-Since", false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLastModified(long lastModified)
/*      */   {
/*  873 */     setDate("Last-Modified", lastModified);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getLastModified()
/*      */   {
/*  883 */     return getFirstDate("Last-Modified", false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLocation(URI location)
/*      */   {
/*  891 */     set("Location", location.toASCIIString());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URI getLocation()
/*      */   {
/*  900 */     String value = getFirst("Location");
/*  901 */     return value != null ? URI.create(value) : null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setOrigin(String origin)
/*      */   {
/*  908 */     set("Origin", origin);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getOrigin()
/*      */   {
/*  915 */     return getFirst("Origin");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPragma(String pragma)
/*      */   {
/*  922 */     set("Pragma", pragma);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getPragma()
/*      */   {
/*  929 */     return getFirst("Pragma");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setRange(List<HttpRange> ranges)
/*      */   {
/*  936 */     String value = HttpRange.toString(ranges);
/*  937 */     set("Range", value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<HttpRange> getRange()
/*      */   {
/*  945 */     String value = getFirst("Range");
/*  946 */     return HttpRange.parseRanges(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUpgrade(String upgrade)
/*      */   {
/*  953 */     set("Upgrade", upgrade);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getUpgrade()
/*      */   {
/*  960 */     return getFirst("Upgrade");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setVary(List<String> requestHeaders)
/*      */   {
/*  971 */     set("Vary", toCommaDelimitedString(requestHeaders));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<String> getVary()
/*      */   {
/*  979 */     return getValuesAsList("Vary");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDate(String headerName, long date)
/*      */   {
/*  989 */     SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMATS[0], Locale.US);
/*  990 */     dateFormat.setTimeZone(GMT);
/*  991 */     set(headerName, dateFormat.format(new Date(date)));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getFirstDate(String headerName)
/*      */   {
/* 1003 */     return getFirstDate(headerName, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private long getFirstDate(String headerName, boolean rejectInvalid)
/*      */   {
/* 1018 */     String headerValue = getFirst(headerName);
/* 1019 */     if (headerValue == null)
/*      */     {
/* 1021 */       return -1L;
/*      */     }
/* 1023 */     if (headerValue.length() >= 3)
/*      */     {
/*      */ 
/* 1026 */       for (String dateFormat : DATE_FORMATS) {
/* 1027 */         SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormat, Locale.US);
/* 1028 */         simpleDateFormat.setTimeZone(GMT);
/*      */         try {
/* 1030 */           return simpleDateFormat.parse(headerValue).getTime();
/*      */         }
/*      */         catch (ParseException localParseException) {}
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1037 */     if (rejectInvalid) {
/* 1038 */       throw new IllegalArgumentException("Cannot parse date value \"" + headerValue + "\" for \"" + headerName + "\" header");
/*      */     }
/*      */     
/* 1041 */     return -1L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<String> getValuesAsList(String headerName)
/*      */   {
/* 1052 */     List<String> values = get(headerName);
/* 1053 */     if (values != null) {
/* 1054 */       List<String> result = new ArrayList();
/* 1055 */       for (String value : values) {
/* 1056 */         if (value != null) {
/* 1057 */           String[] tokens = StringUtils.tokenizeToStringArray(value, ",");
/* 1058 */           for (String token : tokens) {
/* 1059 */             result.add(token);
/*      */           }
/*      */         }
/*      */       }
/* 1063 */       return result;
/*      */     }
/* 1065 */     return Collections.emptyList();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected List<String> getETagValuesAsList(String headerName)
/*      */   {
/* 1075 */     List<String> values = get(headerName);
/* 1076 */     if (values != null) {
/* 1077 */       List<String> result = new ArrayList();
/* 1078 */       for (String value : values) {
/* 1079 */         if (value != null) {
/* 1080 */           Matcher matcher = ETAG_HEADER_VALUE_PATTERN.matcher(value);
/* 1081 */           while (matcher.find()) {
/* 1082 */             if ("*".equals(matcher.group())) {
/* 1083 */               result.add(matcher.group());
/*      */             }
/*      */             else {
/* 1086 */               result.add(matcher.group(1));
/*      */             }
/*      */           }
/* 1089 */           if (result.isEmpty()) {
/* 1090 */             throw new IllegalArgumentException("Could not parse header '" + headerName + "' with value '" + value + "'");
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 1095 */       return result;
/*      */     }
/* 1097 */     return Collections.emptyList();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getFieldValues(String headerName)
/*      */   {
/* 1107 */     List<String> headerValues = get(headerName);
/* 1108 */     return headerValues != null ? toCommaDelimitedString(headerValues) : null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String toCommaDelimitedString(List<String> headerValues)
/*      */   {
/* 1117 */     StringBuilder builder = new StringBuilder();
/* 1118 */     for (Iterator<String> it = headerValues.iterator(); it.hasNext();) {
/* 1119 */       String val = (String)it.next();
/* 1120 */       builder.append(val);
/* 1121 */       if (it.hasNext()) {
/* 1122 */         builder.append(", ");
/*      */       }
/*      */     }
/* 1125 */     return builder.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getFirst(String headerName)
/*      */   {
/* 1138 */     List<String> headerValues = (List)this.headers.get(headerName);
/* 1139 */     return headerValues != null ? (String)headerValues.get(0) : null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(String headerName, String headerValue)
/*      */   {
/* 1152 */     List<String> headerValues = (List)this.headers.get(headerName);
/* 1153 */     if (headerValues == null) {
/* 1154 */       headerValues = new LinkedList();
/* 1155 */       this.headers.put(headerName, headerValues);
/*      */     }
/* 1157 */     headerValues.add(headerValue);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void set(String headerName, String headerValue)
/*      */   {
/* 1170 */     List<String> headerValues = new LinkedList();
/* 1171 */     headerValues.add(headerValue);
/* 1172 */     this.headers.put(headerName, headerValues);
/*      */   }
/*      */   
/*      */   public void setAll(Map<String, String> values)
/*      */   {
/* 1177 */     for (Map.Entry<String, String> entry : values.entrySet()) {
/* 1178 */       set((String)entry.getKey(), (String)entry.getValue());
/*      */     }
/*      */   }
/*      */   
/*      */   public Map<String, String> toSingleValueMap()
/*      */   {
/* 1184 */     LinkedHashMap<String, String> singleValueMap = new LinkedHashMap(this.headers.size());
/* 1185 */     for (Map.Entry<String, List<String>> entry : this.headers.entrySet()) {
/* 1186 */       singleValueMap.put(entry.getKey(), ((List)entry.getValue()).get(0));
/*      */     }
/* 1188 */     return singleValueMap;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int size()
/*      */   {
/* 1196 */     return this.headers.size();
/*      */   }
/*      */   
/*      */   public boolean isEmpty()
/*      */   {
/* 1201 */     return this.headers.isEmpty();
/*      */   }
/*      */   
/*      */   public boolean containsKey(Object key)
/*      */   {
/* 1206 */     return this.headers.containsKey(key);
/*      */   }
/*      */   
/*      */   public boolean containsValue(Object value)
/*      */   {
/* 1211 */     return this.headers.containsValue(value);
/*      */   }
/*      */   
/*      */   public List<String> get(Object key)
/*      */   {
/* 1216 */     return (List)this.headers.get(key);
/*      */   }
/*      */   
/*      */   public List<String> put(String key, List<String> value)
/*      */   {
/* 1221 */     return (List)this.headers.put(key, value);
/*      */   }
/*      */   
/*      */   public List<String> remove(Object key)
/*      */   {
/* 1226 */     return (List)this.headers.remove(key);
/*      */   }
/*      */   
/*      */   public void putAll(Map<? extends String, ? extends List<String>> map)
/*      */   {
/* 1231 */     this.headers.putAll(map);
/*      */   }
/*      */   
/*      */   public void clear()
/*      */   {
/* 1236 */     this.headers.clear();
/*      */   }
/*      */   
/*      */   public Set<String> keySet()
/*      */   {
/* 1241 */     return this.headers.keySet();
/*      */   }
/*      */   
/*      */   public Collection<List<String>> values()
/*      */   {
/* 1246 */     return this.headers.values();
/*      */   }
/*      */   
/*      */   public Set<Map.Entry<String, List<String>>> entrySet()
/*      */   {
/* 1251 */     return this.headers.entrySet();
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean equals(Object other)
/*      */   {
/* 1257 */     if (this == other) {
/* 1258 */       return true;
/*      */     }
/* 1260 */     if (!(other instanceof HttpHeaders)) {
/* 1261 */       return false;
/*      */     }
/* 1263 */     HttpHeaders otherHeaders = (HttpHeaders)other;
/* 1264 */     return this.headers.equals(otherHeaders.headers);
/*      */   }
/*      */   
/*      */   public int hashCode()
/*      */   {
/* 1269 */     return this.headers.hashCode();
/*      */   }
/*      */   
/*      */   public String toString()
/*      */   {
/* 1274 */     return this.headers.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static HttpHeaders readOnlyHttpHeaders(HttpHeaders headers)
/*      */   {
/* 1282 */     return new HttpHeaders(headers, true);
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\HttpHeaders.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */