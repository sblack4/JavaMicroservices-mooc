/*     */ package org.springframework.http;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashSet;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResponseEntity<T>
/*     */   extends HttpEntity<T>
/*     */ {
/*     */   private final Object statusCode;
/*     */   
/*     */   public ResponseEntity(HttpStatus status)
/*     */   {
/*  77 */     this(null, null, status);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResponseEntity(T body, HttpStatus status)
/*     */   {
/*  86 */     this(body, null, status);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResponseEntity(MultiValueMap<String, String> headers, HttpStatus status)
/*     */   {
/*  95 */     this(null, headers, status);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResponseEntity(T body, MultiValueMap<String, String> headers, HttpStatus status)
/*     */   {
/* 105 */     super(body, headers);
/* 106 */     Assert.notNull(status, "HttpStatus must not be null");
/* 107 */     this.statusCode = status;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ResponseEntity(T body, MultiValueMap<String, String> headers, Object statusCode)
/*     */   {
/* 118 */     super(body, headers);
/* 119 */     this.statusCode = statusCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpStatus getStatusCode()
/*     */   {
/* 128 */     if ((this.statusCode instanceof HttpStatus)) {
/* 129 */       return (HttpStatus)this.statusCode;
/*     */     }
/*     */     
/* 132 */     return HttpStatus.valueOf(((Integer)this.statusCode).intValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getStatusCodeValue()
/*     */   {
/* 142 */     if ((this.statusCode instanceof HttpStatus)) {
/* 143 */       return ((HttpStatus)this.statusCode).value();
/*     */     }
/*     */     
/* 146 */     return ((Integer)this.statusCode).intValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 153 */     if (this == other) {
/* 154 */       return true;
/*     */     }
/* 156 */     if (!super.equals(other)) {
/* 157 */       return false;
/*     */     }
/* 159 */     ResponseEntity<?> otherEntity = (ResponseEntity)other;
/* 160 */     return ObjectUtils.nullSafeEquals(this.statusCode, otherEntity.statusCode);
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 165 */     return super.hashCode() * 29 + ObjectUtils.nullSafeHashCode(this.statusCode);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 170 */     StringBuilder builder = new StringBuilder("<");
/* 171 */     builder.append(this.statusCode.toString());
/* 172 */     if ((this.statusCode instanceof HttpStatus)) {
/* 173 */       builder.append(' ');
/* 174 */       builder.append(((HttpStatus)this.statusCode).getReasonPhrase());
/*     */     }
/* 176 */     builder.append(',');
/* 177 */     T body = getBody();
/* 178 */     HttpHeaders headers = getHeaders();
/* 179 */     if (body != null) {
/* 180 */       builder.append(body);
/* 181 */       if (headers != null) {
/* 182 */         builder.append(',');
/*     */       }
/*     */     }
/* 185 */     if (headers != null) {
/* 186 */       builder.append(headers);
/*     */     }
/* 188 */     builder.append('>');
/* 189 */     return builder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BodyBuilder status(HttpStatus status)
/*     */   {
/* 202 */     Assert.notNull(status, "HttpStatus must not be null");
/* 203 */     return new DefaultBuilder(status);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BodyBuilder status(int status)
/*     */   {
/* 213 */     return new DefaultBuilder(Integer.valueOf(status));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BodyBuilder ok()
/*     */   {
/* 222 */     return status(HttpStatus.OK);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T> ResponseEntity<T> ok(T body)
/*     */   {
/* 232 */     BodyBuilder builder = ok();
/* 233 */     return builder.body(body);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BodyBuilder created(URI location)
/*     */   {
/* 244 */     BodyBuilder builder = status(HttpStatus.CREATED);
/* 245 */     return (BodyBuilder)builder.location(location);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BodyBuilder accepted()
/*     */   {
/* 254 */     return status(HttpStatus.ACCEPTED);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HeadersBuilder<?> noContent()
/*     */   {
/* 263 */     return status(HttpStatus.NO_CONTENT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BodyBuilder badRequest()
/*     */   {
/* 272 */     return status(HttpStatus.BAD_REQUEST);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HeadersBuilder<?> notFound()
/*     */   {
/* 281 */     return status(HttpStatus.NOT_FOUND);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BodyBuilder unprocessableEntity()
/*     */   {
/* 291 */     return status(HttpStatus.UNPROCESSABLE_ENTITY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class DefaultBuilder
/*     */     implements ResponseEntity.BodyBuilder
/*     */   {
/*     */     private final Object statusCode;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 426 */     private final HttpHeaders headers = new HttpHeaders();
/*     */     
/*     */     public DefaultBuilder(Object statusCode) {
/* 429 */       this.statusCode = statusCode;
/*     */     }
/*     */     
/*     */     public ResponseEntity.BodyBuilder header(String headerName, String... headerValues)
/*     */     {
/* 434 */       for (String headerValue : headerValues) {
/* 435 */         this.headers.add(headerName, headerValue);
/*     */       }
/* 437 */       return this;
/*     */     }
/*     */     
/*     */     public ResponseEntity.BodyBuilder headers(HttpHeaders headers)
/*     */     {
/* 442 */       if (headers != null) {
/* 443 */         this.headers.putAll(headers);
/*     */       }
/* 445 */       return this;
/*     */     }
/*     */     
/*     */     public ResponseEntity.BodyBuilder allow(HttpMethod... allowedMethods)
/*     */     {
/* 450 */       this.headers.setAllow(new LinkedHashSet(Arrays.asList(allowedMethods)));
/* 451 */       return this;
/*     */     }
/*     */     
/*     */     public ResponseEntity.BodyBuilder contentLength(long contentLength)
/*     */     {
/* 456 */       this.headers.setContentLength(contentLength);
/* 457 */       return this;
/*     */     }
/*     */     
/*     */     public ResponseEntity.BodyBuilder contentType(MediaType contentType)
/*     */     {
/* 462 */       this.headers.setContentType(contentType);
/* 463 */       return this;
/*     */     }
/*     */     
/*     */     public ResponseEntity.BodyBuilder eTag(String eTag)
/*     */     {
/* 468 */       if (eTag != null) {
/* 469 */         if ((!eTag.startsWith("\"")) && (!eTag.startsWith("W/\""))) {
/* 470 */           eTag = "\"" + eTag;
/*     */         }
/* 472 */         if (!eTag.endsWith("\"")) {
/* 473 */           eTag = eTag + "\"";
/*     */         }
/*     */       }
/* 476 */       this.headers.setETag(eTag);
/* 477 */       return this;
/*     */     }
/*     */     
/*     */     public ResponseEntity.BodyBuilder lastModified(long date)
/*     */     {
/* 482 */       this.headers.setLastModified(date);
/* 483 */       return this;
/*     */     }
/*     */     
/*     */     public ResponseEntity.BodyBuilder location(URI location)
/*     */     {
/* 488 */       this.headers.setLocation(location);
/* 489 */       return this;
/*     */     }
/*     */     
/*     */     public ResponseEntity.BodyBuilder cacheControl(CacheControl cacheControl)
/*     */     {
/* 494 */       String ccValue = cacheControl.getHeaderValue();
/* 495 */       if (ccValue != null) {
/* 496 */         this.headers.setCacheControl(cacheControl.getHeaderValue());
/*     */       }
/* 498 */       return this;
/*     */     }
/*     */     
/*     */     public ResponseEntity.BodyBuilder varyBy(String... requestHeaders)
/*     */     {
/* 503 */       this.headers.setVary(Arrays.asList(requestHeaders));
/* 504 */       return this;
/*     */     }
/*     */     
/*     */     public ResponseEntity<Void> build()
/*     */     {
/* 509 */       return body(null);
/*     */     }
/*     */     
/*     */     public <T> ResponseEntity<T> body(T body)
/*     */     {
/* 514 */       return new ResponseEntity(body, this.headers, this.statusCode, null);
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract interface BodyBuilder
/*     */     extends ResponseEntity.HeadersBuilder<BodyBuilder>
/*     */   {
/*     */     public abstract BodyBuilder contentLength(long paramLong);
/*     */     
/*     */     public abstract BodyBuilder contentType(MediaType paramMediaType);
/*     */     
/*     */     public abstract <T> ResponseEntity<T> body(T paramT);
/*     */   }
/*     */   
/*     */   public static abstract interface HeadersBuilder<B extends HeadersBuilder<B>>
/*     */   {
/*     */     public abstract B header(String paramString, String... paramVarArgs);
/*     */     
/*     */     public abstract B headers(HttpHeaders paramHttpHeaders);
/*     */     
/*     */     public abstract B allow(HttpMethod... paramVarArgs);
/*     */     
/*     */     public abstract B eTag(String paramString);
/*     */     
/*     */     public abstract B lastModified(long paramLong);
/*     */     
/*     */     public abstract B location(URI paramURI);
/*     */     
/*     */     public abstract B cacheControl(CacheControl paramCacheControl);
/*     */     
/*     */     public abstract B varyBy(String... paramVarArgs);
/*     */     
/*     */     public abstract ResponseEntity<Void> build();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\ResponseEntity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */