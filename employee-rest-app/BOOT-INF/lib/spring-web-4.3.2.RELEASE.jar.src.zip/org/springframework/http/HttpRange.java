/*     */ package org.springframework.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.springframework.core.io.InputStreamResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.ResourceRegion;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HttpRange
/*     */ {
/*     */   private static final String BYTE_RANGE_PREFIX = "bytes=";
/*     */   
/*     */   public ResourceRegion toResourceRegion(Resource resource)
/*     */   {
/*  58 */     Assert.isTrue(InputStreamResource.class != resource.getClass(), "Can't convert an InputStreamResource to a ResourceRegion");
/*     */     try
/*     */     {
/*  61 */       long contentLength = resource.contentLength();
/*  62 */       Assert.isTrue(contentLength > 0L, "Resource content length should be > 0");
/*  63 */       long start = getRangeStart(contentLength);
/*  64 */       long end = getRangeEnd(contentLength);
/*  65 */       return new ResourceRegion(resource, start, end - start + 1L);
/*     */     }
/*     */     catch (IOException ex) {
/*  68 */       throw new IllegalArgumentException("Failed to convert Resource to ResourceRegion", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract long getRangeStart(long paramLong);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract long getRangeEnd(long paramLong);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HttpRange createByteRange(long firstBytePos)
/*     */   {
/*  94 */     return new ByteRange(firstBytePos, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HttpRange createByteRange(long firstBytePos, long lastBytePos)
/*     */   {
/* 105 */     return new ByteRange(firstBytePos, Long.valueOf(lastBytePos));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HttpRange createSuffixRange(long suffixLength)
/*     */   {
/* 115 */     return new SuffixByteRange(suffixLength);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<HttpRange> parseRanges(String ranges)
/*     */   {
/* 126 */     if (!StringUtils.hasLength(ranges)) {
/* 127 */       return Collections.emptyList();
/*     */     }
/* 129 */     if (!ranges.startsWith("bytes=")) {
/* 130 */       throw new IllegalArgumentException("Range '" + ranges + "' does not start with 'bytes='");
/*     */     }
/* 132 */     ranges = ranges.substring("bytes=".length());
/*     */     
/* 134 */     String[] tokens = ranges.split(",\\s*");
/* 135 */     List<HttpRange> result = new ArrayList(tokens.length);
/* 136 */     for (String token : tokens) {
/* 137 */       result.add(parseRange(token));
/*     */     }
/* 139 */     return result;
/*     */   }
/*     */   
/*     */   private static HttpRange parseRange(String range) {
/* 143 */     Assert.hasLength(range, "Range String must not be empty");
/* 144 */     int dashIdx = range.indexOf('-');
/* 145 */     if (dashIdx > 0) {
/* 146 */       long firstPos = Long.parseLong(range.substring(0, dashIdx));
/* 147 */       if (dashIdx < range.length() - 1) {
/* 148 */         Long lastPos = Long.valueOf(Long.parseLong(range.substring(dashIdx + 1, range.length())));
/* 149 */         return new ByteRange(firstPos, lastPos);
/*     */       }
/*     */       
/* 152 */       return new ByteRange(firstPos, null);
/*     */     }
/*     */     
/* 155 */     if (dashIdx == 0) {
/* 156 */       long suffixLength = Long.parseLong(range.substring(1));
/* 157 */       return new SuffixByteRange(suffixLength);
/*     */     }
/*     */     
/* 160 */     throw new IllegalArgumentException("Range '" + range + "' does not contain \"-\"");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<ResourceRegion> toResourceRegions(List<HttpRange> ranges, Resource resource)
/*     */   {
/* 173 */     if ((ranges == null) || (ranges.size() == 0)) {
/* 174 */       return Collections.emptyList();
/*     */     }
/* 176 */     List<ResourceRegion> regions = new ArrayList(ranges.size());
/* 177 */     for (HttpRange range : ranges) {
/* 178 */       regions.add(range.toResourceRegion(resource));
/*     */     }
/* 180 */     return regions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toString(Collection<HttpRange> ranges)
/*     */   {
/* 190 */     Assert.notEmpty(ranges, "Ranges Collection must not be empty");
/* 191 */     StringBuilder builder = new StringBuilder("bytes=");
/* 192 */     for (Iterator<HttpRange> iterator = ranges.iterator(); iterator.hasNext();) {
/* 193 */       HttpRange range = (HttpRange)iterator.next();
/* 194 */       builder.append(range);
/* 195 */       if (iterator.hasNext()) {
/* 196 */         builder.append(", ");
/*     */       }
/*     */     }
/* 199 */     return builder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class ByteRange
/*     */     extends HttpRange
/*     */   {
/*     */     private final long firstPos;
/*     */     
/*     */ 
/*     */     private final Long lastPos;
/*     */     
/*     */ 
/*     */ 
/*     */     public ByteRange(long firstPos, Long lastPos)
/*     */     {
/* 216 */       assertPositions(firstPos, lastPos);
/* 217 */       this.firstPos = firstPos;
/* 218 */       this.lastPos = lastPos;
/*     */     }
/*     */     
/*     */     private void assertPositions(long firstBytePos, Long lastBytePos) {
/* 222 */       if (firstBytePos < 0L) {
/* 223 */         throw new IllegalArgumentException("Invalid first byte position: " + firstBytePos);
/*     */       }
/* 225 */       if ((lastBytePos != null) && (lastBytePos.longValue() < firstBytePos)) {
/* 226 */         throw new IllegalArgumentException("firstBytePosition=" + firstBytePos + " should be less then or equal to lastBytePosition=" + lastBytePos);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public long getRangeStart(long length)
/*     */     {
/* 233 */       return this.firstPos;
/*     */     }
/*     */     
/*     */     public long getRangeEnd(long length)
/*     */     {
/* 238 */       if ((this.lastPos != null) && (this.lastPos.longValue() < length)) {
/* 239 */         return this.lastPos.longValue();
/*     */       }
/*     */       
/* 242 */       return length - 1L;
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 248 */       if (this == other) {
/* 249 */         return true;
/*     */       }
/* 251 */       if (!(other instanceof ByteRange)) {
/* 252 */         return false;
/*     */       }
/* 254 */       ByteRange otherRange = (ByteRange)other;
/*     */       
/* 256 */       return (this.firstPos == otherRange.firstPos) && (ObjectUtils.nullSafeEquals(this.lastPos, otherRange.lastPos));
/*     */     }
/*     */     
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 262 */       return ObjectUtils.nullSafeHashCode(Long.valueOf(this.firstPos)) * 31 + ObjectUtils.nullSafeHashCode(this.lastPos);
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 267 */       StringBuilder builder = new StringBuilder();
/* 268 */       builder.append(this.firstPos);
/* 269 */       builder.append('-');
/* 270 */       if (this.lastPos != null) {
/* 271 */         builder.append(this.lastPos);
/*     */       }
/* 273 */       return builder.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class SuffixByteRange
/*     */     extends HttpRange
/*     */   {
/*     */     private final long suffixLength;
/*     */     
/*     */ 
/*     */ 
/*     */     public SuffixByteRange(long suffixLength)
/*     */     {
/* 288 */       if (suffixLength < 0L) {
/* 289 */         throw new IllegalArgumentException("Invalid suffix length: " + suffixLength);
/*     */       }
/* 291 */       this.suffixLength = suffixLength;
/*     */     }
/*     */     
/*     */     public long getRangeStart(long length)
/*     */     {
/* 296 */       if (this.suffixLength < length) {
/* 297 */         return length - this.suffixLength;
/*     */       }
/*     */       
/* 300 */       return 0L;
/*     */     }
/*     */     
/*     */ 
/*     */     public long getRangeEnd(long length)
/*     */     {
/* 306 */       return length - 1L;
/*     */     }
/*     */     
/*     */     public boolean equals(Object other)
/*     */     {
/* 311 */       if (this == other) {
/* 312 */         return true;
/*     */       }
/* 314 */       if (!(other instanceof SuffixByteRange)) {
/* 315 */         return false;
/*     */       }
/* 317 */       SuffixByteRange otherRange = (SuffixByteRange)other;
/* 318 */       return this.suffixLength == otherRange.suffixLength;
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 323 */       return ObjectUtils.hashCode(this.suffixLength);
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 328 */       return "-" + this.suffixLength;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\HttpRange.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */