/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ import okhttp3.Headers;
/*    */ import okhttp3.Response;
/*    */ import okhttp3.ResponseBody;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OkHttp3ClientHttpResponse
/*    */   extends AbstractClientHttpResponse
/*    */ {
/*    */   private final Response response;
/*    */   private HttpHeaders headers;
/*    */   
/*    */   public OkHttp3ClientHttpResponse(Response response)
/*    */   {
/* 43 */     Assert.notNull(response, "Response must not be null");
/* 44 */     this.response = response;
/*    */   }
/*    */   
/*    */ 
/*    */   public int getRawStatusCode()
/*    */   {
/* 50 */     return this.response.code();
/*    */   }
/*    */   
/*    */   public String getStatusText()
/*    */   {
/* 55 */     return this.response.message();
/*    */   }
/*    */   
/*    */   public InputStream getBody() throws IOException
/*    */   {
/* 60 */     return this.response.body().byteStream();
/*    */   }
/*    */   
/*    */   public HttpHeaders getHeaders()
/*    */   {
/* 65 */     if (this.headers == null) {
/* 66 */       HttpHeaders headers = new HttpHeaders();
/* 67 */       for (Iterator localIterator1 = this.response.headers().names().iterator(); localIterator1.hasNext();) { headerName = (String)localIterator1.next();
/* 68 */         for (String headerValue : this.response.headers(headerName))
/* 69 */           headers.add(headerName, headerValue);
/*    */       }
/*    */       String headerName;
/* 72 */       this.headers = headers;
/*    */     }
/* 74 */     return this.headers;
/*    */   }
/*    */   
/*    */   public void close()
/*    */   {
/* 79 */     this.response.body().close();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\client\OkHttp3ClientHttpResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */