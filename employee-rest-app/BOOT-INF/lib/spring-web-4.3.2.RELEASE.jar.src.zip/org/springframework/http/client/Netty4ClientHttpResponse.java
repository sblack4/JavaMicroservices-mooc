/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import io.netty.buffer.ByteBufInputStream;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.handler.codec.http.FullHttpResponse;
/*    */ import io.netty.handler.codec.http.HttpResponseStatus;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.Map.Entry;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Netty4ClientHttpResponse
/*    */   extends AbstractClientHttpResponse
/*    */ {
/*    */   private final ChannelHandlerContext context;
/*    */   private final FullHttpResponse nettyResponse;
/*    */   private final ByteBufInputStream body;
/*    */   private volatile HttpHeaders headers;
/*    */   
/*    */   public Netty4ClientHttpResponse(ChannelHandlerContext context, FullHttpResponse nettyResponse)
/*    */   {
/* 49 */     Assert.notNull(context, "ChannelHandlerContext must not be null");
/* 50 */     Assert.notNull(nettyResponse, "FullHttpResponse must not be null");
/* 51 */     this.context = context;
/* 52 */     this.nettyResponse = nettyResponse;
/* 53 */     this.body = new ByteBufInputStream(this.nettyResponse.content());
/* 54 */     this.nettyResponse.retain();
/*    */   }
/*    */   
/*    */ 
/*    */   public int getRawStatusCode()
/*    */     throws IOException
/*    */   {
/* 61 */     return this.nettyResponse.getStatus().code();
/*    */   }
/*    */   
/*    */   public String getStatusText()
/*    */     throws IOException
/*    */   {
/* 67 */     return this.nettyResponse.getStatus().reasonPhrase();
/*    */   }
/*    */   
/*    */   public HttpHeaders getHeaders()
/*    */   {
/* 72 */     if (this.headers == null) {
/* 73 */       HttpHeaders headers = new HttpHeaders();
/* 74 */       for (Map.Entry<String, String> entry : this.nettyResponse.headers()) {
/* 75 */         headers.add((String)entry.getKey(), (String)entry.getValue());
/*    */       }
/* 77 */       this.headers = headers;
/*    */     }
/* 79 */     return this.headers;
/*    */   }
/*    */   
/*    */   public InputStream getBody() throws IOException
/*    */   {
/* 84 */     return this.body;
/*    */   }
/*    */   
/*    */   public void close()
/*    */   {
/* 89 */     this.nettyResponse.release();
/* 90 */     this.context.close();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\client\Netty4ClientHttpResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */