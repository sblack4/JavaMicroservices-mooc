/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import org.apache.http.client.config.RequestConfig;
/*     */ import org.apache.http.client.methods.Configurable;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ import org.apache.http.client.protocol.HttpClientContext;
/*     */ import org.apache.http.impl.client.CloseableHttpClient;
/*     */ import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
/*     */ import org.apache.http.impl.nio.client.HttpAsyncClients;
/*     */ import org.apache.http.nio.client.HttpAsyncClient;
/*     */ import org.apache.http.protocol.HttpContext;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpComponentsAsyncClientHttpRequestFactory
/*     */   extends HttpComponentsClientHttpRequestFactory
/*     */   implements AsyncClientHttpRequestFactory, InitializingBean
/*     */ {
/*     */   private CloseableHttpAsyncClient httpAsyncClient;
/*     */   
/*     */   public HttpComponentsAsyncClientHttpRequestFactory()
/*     */   {
/*  58 */     this(HttpAsyncClients.createSystem());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpComponentsAsyncClientHttpRequestFactory(CloseableHttpAsyncClient httpAsyncClient)
/*     */   {
/*  68 */     Assert.notNull(httpAsyncClient, "HttpAsyncClient must not be null");
/*  69 */     this.httpAsyncClient = httpAsyncClient;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpComponentsAsyncClientHttpRequestFactory(CloseableHttpClient httpClient, CloseableHttpAsyncClient httpAsyncClient)
/*     */   {
/*  81 */     super(httpClient);
/*  82 */     Assert.notNull(httpAsyncClient, "HttpAsyncClient must not be null");
/*  83 */     this.httpAsyncClient = httpAsyncClient;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHttpAsyncClient(CloseableHttpAsyncClient httpAsyncClient)
/*     */   {
/*  92 */     this.httpAsyncClient = httpAsyncClient;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CloseableHttpAsyncClient getHttpAsyncClient()
/*     */   {
/* 100 */     return this.httpAsyncClient;
/*     */   }
/*     */   
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 106 */     startAsyncClient();
/*     */   }
/*     */   
/*     */   private void startAsyncClient() {
/* 110 */     CloseableHttpAsyncClient asyncClient = getHttpAsyncClient();
/* 111 */     if (!asyncClient.isRunning()) {
/* 112 */       asyncClient.start();
/*     */     }
/*     */   }
/*     */   
/*     */   public AsyncClientHttpRequest createAsyncRequest(URI uri, HttpMethod httpMethod) throws IOException
/*     */   {
/* 118 */     HttpAsyncClient asyncClient = getHttpAsyncClient();
/* 119 */     startAsyncClient();
/* 120 */     HttpUriRequest httpRequest = createHttpUriRequest(httpMethod, uri);
/* 121 */     postProcessHttpRequest(httpRequest);
/* 122 */     HttpContext context = createHttpContext(httpMethod, uri);
/* 123 */     if (context == null) {
/* 124 */       context = HttpClientContext.create();
/*     */     }
/*     */     
/* 127 */     if (context.getAttribute("http.request-config") == null)
/*     */     {
/* 129 */       RequestConfig config = null;
/* 130 */       if ((httpRequest instanceof Configurable)) {
/* 131 */         config = ((Configurable)httpRequest).getConfig();
/*     */       }
/* 133 */       if (config == null) {
/* 134 */         config = createRequestConfig(asyncClient);
/*     */       }
/* 136 */       if (config != null) {
/* 137 */         context.setAttribute("http.request-config", config);
/*     */       }
/*     */     }
/* 140 */     return new HttpComponentsAsyncClientHttpRequest(asyncClient, httpRequest, context);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void destroy()
/*     */     throws java.lang.Exception
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokespecial 25	org/springframework/http/client/HttpComponentsClientHttpRequestFactory:destroy	()V
/*     */     //   4: aload_0
/*     */     //   5: invokevirtual 9	org/springframework/http/client/HttpComponentsAsyncClientHttpRequestFactory:getHttpAsyncClient	()Lorg/apache/http/impl/nio/client/CloseableHttpAsyncClient;
/*     */     //   8: invokevirtual 26	org/apache/http/impl/nio/client/CloseableHttpAsyncClient:close	()V
/*     */     //   11: goto +13 -> 24
/*     */     //   14: astore_1
/*     */     //   15: aload_0
/*     */     //   16: invokevirtual 9	org/springframework/http/client/HttpComponentsAsyncClientHttpRequestFactory:getHttpAsyncClient	()Lorg/apache/http/impl/nio/client/CloseableHttpAsyncClient;
/*     */     //   19: invokevirtual 26	org/apache/http/impl/nio/client/CloseableHttpAsyncClient:close	()V
/*     */     //   22: aload_1
/*     */     //   23: athrow
/*     */     //   24: return
/*     */     // Line number table:
/*     */     //   Java source line #146	-> byte code offset #0
/*     */     //   Java source line #149	-> byte code offset #4
/*     */     //   Java source line #150	-> byte code offset #11
/*     */     //   Java source line #149	-> byte code offset #14
/*     */     //   Java source line #151	-> byte code offset #24
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	25	0	this	HttpComponentsAsyncClientHttpRequestFactory
/*     */     //   14	9	1	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   0	4	14	finally
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\client\HttpComponentsAsyncClientHttpRequestFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */