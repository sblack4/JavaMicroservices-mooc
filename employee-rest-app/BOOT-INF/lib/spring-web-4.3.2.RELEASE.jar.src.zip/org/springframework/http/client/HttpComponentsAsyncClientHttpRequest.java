/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.util.concurrent.Future;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.HttpEntityEnclosingRequest;
/*     */ import org.apache.http.HttpResponse;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ import org.apache.http.concurrent.FutureCallback;
/*     */ import org.apache.http.nio.client.HttpAsyncClient;
/*     */ import org.apache.http.nio.entity.NByteArrayEntity;
/*     */ import org.apache.http.protocol.HttpContext;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.concurrent.FailureCallback;
/*     */ import org.springframework.util.concurrent.FutureAdapter;
/*     */ import org.springframework.util.concurrent.ListenableFuture;
/*     */ import org.springframework.util.concurrent.ListenableFutureCallback;
/*     */ import org.springframework.util.concurrent.ListenableFutureCallbackRegistry;
/*     */ import org.springframework.util.concurrent.SuccessCallback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class HttpComponentsAsyncClientHttpRequest
/*     */   extends AbstractBufferingAsyncClientHttpRequest
/*     */ {
/*     */   private final HttpAsyncClient httpClient;
/*     */   private final HttpUriRequest httpRequest;
/*     */   private final HttpContext httpContext;
/*     */   
/*     */   HttpComponentsAsyncClientHttpRequest(HttpAsyncClient httpClient, HttpUriRequest httpRequest, HttpContext httpContext)
/*     */   {
/*  63 */     this.httpClient = httpClient;
/*  64 */     this.httpRequest = httpRequest;
/*  65 */     this.httpContext = httpContext;
/*     */   }
/*     */   
/*     */ 
/*     */   public HttpMethod getMethod()
/*     */   {
/*  71 */     return HttpMethod.resolve(this.httpRequest.getMethod());
/*     */   }
/*     */   
/*     */   public URI getURI()
/*     */   {
/*  76 */     return this.httpRequest.getURI();
/*     */   }
/*     */   
/*     */   HttpContext getHttpContext() {
/*  80 */     return this.httpContext;
/*     */   }
/*     */   
/*     */ 
/*     */   protected ListenableFuture<ClientHttpResponse> executeInternal(HttpHeaders headers, byte[] bufferedOutput)
/*     */     throws IOException
/*     */   {
/*  87 */     HttpComponentsClientHttpRequest.addHeaders(this.httpRequest, headers);
/*     */     
/*  89 */     if ((this.httpRequest instanceof HttpEntityEnclosingRequest)) {
/*  90 */       HttpEntityEnclosingRequest entityEnclosingRequest = (HttpEntityEnclosingRequest)this.httpRequest;
/*  91 */       HttpEntity requestEntity = new NByteArrayEntity(bufferedOutput);
/*  92 */       entityEnclosingRequest.setEntity(requestEntity);
/*     */     }
/*     */     
/*  95 */     HttpResponseFutureCallback callback = new HttpResponseFutureCallback(null);
/*     */     
/*  97 */     Future<HttpResponse> futureResponse = this.httpClient.execute(this.httpRequest, this.httpContext, callback);
/*  98 */     return new ClientHttpResponseFuture(futureResponse, callback);
/*     */   }
/*     */   
/*     */   private static class HttpResponseFutureCallback
/*     */     implements FutureCallback<HttpResponse>
/*     */   {
/* 104 */     private final ListenableFutureCallbackRegistry<ClientHttpResponse> callbacks = new ListenableFutureCallbackRegistry();
/*     */     
/*     */     public void addCallback(ListenableFutureCallback<? super ClientHttpResponse> callback)
/*     */     {
/* 108 */       this.callbacks.addCallback(callback);
/*     */     }
/*     */     
/*     */     public void addSuccessCallback(SuccessCallback<? super ClientHttpResponse> callback) {
/* 112 */       this.callbacks.addSuccessCallback(callback);
/*     */     }
/*     */     
/*     */     public void addFailureCallback(FailureCallback callback) {
/* 116 */       this.callbacks.addFailureCallback(callback);
/*     */     }
/*     */     
/*     */     public void completed(HttpResponse result)
/*     */     {
/* 121 */       this.callbacks.success(new HttpComponentsAsyncClientHttpResponse(result));
/*     */     }
/*     */     
/*     */     public void failed(Exception ex)
/*     */     {
/* 126 */       this.callbacks.failure(ex);
/*     */     }
/*     */     
/*     */ 
/*     */     public void cancelled() {}
/*     */   }
/*     */   
/*     */   private static class ClientHttpResponseFuture
/*     */     extends FutureAdapter<ClientHttpResponse, HttpResponse>
/*     */     implements ListenableFuture<ClientHttpResponse>
/*     */   {
/*     */     private final HttpComponentsAsyncClientHttpRequest.HttpResponseFutureCallback callback;
/*     */     
/*     */     public ClientHttpResponseFuture(Future<HttpResponse> futureResponse, HttpComponentsAsyncClientHttpRequest.HttpResponseFutureCallback callback)
/*     */     {
/* 141 */       super();
/* 142 */       this.callback = callback;
/*     */     }
/*     */     
/*     */     protected ClientHttpResponse adapt(HttpResponse response)
/*     */     {
/* 147 */       return new HttpComponentsAsyncClientHttpResponse(response);
/*     */     }
/*     */     
/*     */     public void addCallback(ListenableFutureCallback<? super ClientHttpResponse> callback)
/*     */     {
/* 152 */       this.callback.addCallback(callback);
/*     */     }
/*     */     
/*     */     public void addCallback(SuccessCallback<? super ClientHttpResponse> successCallback, FailureCallback failureCallback)
/*     */     {
/* 157 */       this.callback.addSuccessCallback(successCallback);
/* 158 */       this.callback.addFailureCallback(failureCallback);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\client\HttpComponentsAsyncClientHttpRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */