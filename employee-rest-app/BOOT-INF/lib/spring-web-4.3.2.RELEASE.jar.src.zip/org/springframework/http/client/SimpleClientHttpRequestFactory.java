/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.Proxy;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import org.springframework.core.task.AsyncListenableTaskExecutor;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleClientHttpRequestFactory
/*     */   implements ClientHttpRequestFactory, AsyncClientHttpRequestFactory
/*     */ {
/*     */   private static final int DEFAULT_CHUNK_SIZE = 4096;
/*     */   private Proxy proxy;
/*  46 */   private boolean bufferRequestBody = true;
/*     */   
/*  48 */   private int chunkSize = 4096;
/*     */   
/*  50 */   private int connectTimeout = -1;
/*     */   
/*  52 */   private int readTimeout = -1;
/*     */   
/*  54 */   private boolean outputStreaming = true;
/*     */   
/*     */ 
/*     */   private AsyncListenableTaskExecutor taskExecutor;
/*     */   
/*     */ 
/*     */ 
/*     */   public void setProxy(Proxy proxy)
/*     */   {
/*  63 */     this.proxy = proxy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBufferRequestBody(boolean bufferRequestBody)
/*     */   {
/*  78 */     this.bufferRequestBody = bufferRequestBody;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setChunkSize(int chunkSize)
/*     */   {
/*  89 */     this.chunkSize = chunkSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectTimeout(int connectTimeout)
/*     */   {
/*  99 */     this.connectTimeout = connectTimeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReadTimeout(int readTimeout)
/*     */   {
/* 109 */     this.readTimeout = readTimeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOutputStreaming(boolean outputStreaming)
/*     */   {
/* 122 */     this.outputStreaming = outputStreaming;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTaskExecutor(AsyncListenableTaskExecutor taskExecutor)
/*     */   {
/* 131 */     this.taskExecutor = taskExecutor;
/*     */   }
/*     */   
/*     */   public ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod)
/*     */     throws IOException
/*     */   {
/* 137 */     HttpURLConnection connection = openConnection(uri.toURL(), this.proxy);
/* 138 */     prepareConnection(connection, httpMethod.name());
/*     */     
/* 140 */     if (this.bufferRequestBody) {
/* 141 */       return new SimpleBufferingClientHttpRequest(connection, this.outputStreaming);
/*     */     }
/*     */     
/* 144 */     return new SimpleStreamingClientHttpRequest(connection, this.chunkSize, this.outputStreaming);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AsyncClientHttpRequest createAsyncRequest(URI uri, HttpMethod httpMethod)
/*     */     throws IOException
/*     */   {
/* 154 */     Assert.state(this.taskExecutor != null, "Asynchronous execution requires an AsyncTaskExecutor to be set");
/*     */     
/*     */ 
/* 157 */     HttpURLConnection connection = openConnection(uri.toURL(), this.proxy);
/* 158 */     prepareConnection(connection, httpMethod.name());
/*     */     
/* 160 */     if (this.bufferRequestBody) {
/* 161 */       return new SimpleBufferingAsyncClientHttpRequest(connection, this.outputStreaming, this.taskExecutor);
/*     */     }
/*     */     
/*     */ 
/* 165 */     return new SimpleStreamingAsyncClientHttpRequest(connection, this.chunkSize, this.outputStreaming, this.taskExecutor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected HttpURLConnection openConnection(URL url, Proxy proxy)
/*     */     throws IOException
/*     */   {
/* 180 */     URLConnection urlConnection = proxy != null ? url.openConnection(proxy) : url.openConnection();
/* 181 */     Assert.isInstanceOf(HttpURLConnection.class, urlConnection);
/* 182 */     return (HttpURLConnection)urlConnection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void prepareConnection(HttpURLConnection connection, String httpMethod)
/*     */     throws IOException
/*     */   {
/* 193 */     if (this.connectTimeout >= 0) {
/* 194 */       connection.setConnectTimeout(this.connectTimeout);
/*     */     }
/* 196 */     if (this.readTimeout >= 0) {
/* 197 */       connection.setReadTimeout(this.readTimeout);
/*     */     }
/*     */     
/* 200 */     connection.setDoInput(true);
/*     */     
/* 202 */     if ("GET".equals(httpMethod)) {
/* 203 */       connection.setInstanceFollowRedirects(true);
/*     */     }
/*     */     else {
/* 206 */       connection.setInstanceFollowRedirects(false);
/*     */     }
/*     */     
/* 209 */     if (("POST".equals(httpMethod)) || ("PUT".equals(httpMethod)) || 
/* 210 */       ("PATCH".equals(httpMethod)) || ("DELETE".equals(httpMethod))) {
/* 211 */       connection.setDoOutput(true);
/*     */     }
/*     */     else {
/* 214 */       connection.setDoOutput(false);
/*     */     }
/*     */     
/* 217 */     connection.setRequestMethod(httpMethod);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\client\SimpleClientHttpRequestFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */