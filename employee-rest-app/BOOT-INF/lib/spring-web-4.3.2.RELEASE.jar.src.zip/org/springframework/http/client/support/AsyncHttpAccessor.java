/*    */ package org.springframework.http.client.support;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URI;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.http.client.AsyncClientHttpRequest;
/*    */ import org.springframework.http.client.AsyncClientHttpRequestFactory;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AsyncHttpAccessor
/*    */ {
/* 45 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */   
/*    */ 
/*    */   private AsyncClientHttpRequestFactory asyncRequestFactory;
/*    */   
/*    */ 
/*    */ 
/*    */   public void setAsyncRequestFactory(AsyncClientHttpRequestFactory asyncRequestFactory)
/*    */   {
/* 54 */     Assert.notNull(asyncRequestFactory, "'asyncRequestFactory' must not be null");
/* 55 */     this.asyncRequestFactory = asyncRequestFactory;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public AsyncClientHttpRequestFactory getAsyncRequestFactory()
/*    */   {
/* 63 */     return this.asyncRequestFactory;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected AsyncClientHttpRequest createAsyncRequest(URI url, HttpMethod method)
/*    */     throws IOException
/*    */   {
/* 76 */     AsyncClientHttpRequest request = getAsyncRequestFactory().createAsyncRequest(url, method);
/* 77 */     if (this.logger.isDebugEnabled()) {
/* 78 */       this.logger.debug("Created asynchronous " + method.name() + " request for \"" + url + "\"");
/*    */     }
/* 80 */     return request;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\client\support\AsyncHttpAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */