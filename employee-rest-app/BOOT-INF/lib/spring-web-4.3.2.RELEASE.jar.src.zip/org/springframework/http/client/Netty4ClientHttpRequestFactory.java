/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import io.netty.bootstrap.Bootstrap;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelInitializer;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.nio.NioEventLoopGroup;
/*     */ import io.netty.channel.socket.SocketChannel;
/*     */ import io.netty.channel.socket.SocketChannelConfig;
/*     */ import io.netty.channel.socket.nio.NioSocketChannel;
/*     */ import io.netty.handler.codec.http.HttpClientCodec;
/*     */ import io.netty.handler.codec.http.HttpObjectAggregator;
/*     */ import io.netty.handler.ssl.SslContext;
/*     */ import io.netty.handler.timeout.ReadTimeoutHandler;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Netty4ClientHttpRequestFactory
/*     */   implements ClientHttpRequestFactory, AsyncClientHttpRequestFactory, InitializingBean, DisposableBean
/*     */ {
/*     */   public static final int DEFAULT_MAX_RESPONSE_SIZE = 10485760;
/*     */   private final EventLoopGroup eventLoopGroup;
/*     */   private final boolean defaultEventLoopGroup;
/*  67 */   private int maxResponseSize = 10485760;
/*     */   
/*     */   private SslContext sslContext;
/*     */   
/*  71 */   private int connectTimeout = -1;
/*     */   
/*  73 */   private int readTimeout = -1;
/*     */   
/*     */ 
/*     */ 
/*     */   private volatile Bootstrap bootstrap;
/*     */   
/*     */ 
/*     */ 
/*     */   public Netty4ClientHttpRequestFactory()
/*     */   {
/*  83 */     int ioWorkerCount = Runtime.getRuntime().availableProcessors() * 2;
/*  84 */     this.eventLoopGroup = new NioEventLoopGroup(ioWorkerCount);
/*  85 */     this.defaultEventLoopGroup = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Netty4ClientHttpRequestFactory(EventLoopGroup eventLoopGroup)
/*     */   {
/*  96 */     Assert.notNull(eventLoopGroup, "EventLoopGroup must not be null");
/*  97 */     this.eventLoopGroup = eventLoopGroup;
/*  98 */     this.defaultEventLoopGroup = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaxResponseSize(int maxResponseSize)
/*     */   {
/* 109 */     this.maxResponseSize = maxResponseSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSslContext(SslContext sslContext)
/*     */   {
/* 118 */     this.sslContext = sslContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectTimeout(int connectTimeout)
/*     */   {
/* 127 */     this.connectTimeout = connectTimeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReadTimeout(int readTimeout)
/*     */   {
/* 136 */     this.readTimeout = readTimeout;
/*     */   }
/*     */   
/*     */   private Bootstrap getBootstrap() {
/* 140 */     if (this.bootstrap == null) {
/* 141 */       Bootstrap bootstrap = new Bootstrap();
/* 142 */       ((Bootstrap)((Bootstrap)bootstrap.group(this.eventLoopGroup)).channel(NioSocketChannel.class))
/* 143 */         .handler(new ChannelInitializer()
/*     */         {
/*     */           protected void initChannel(SocketChannel channel) throws Exception
/*     */           {
/* 146 */             Netty4ClientHttpRequestFactory.this.configureChannel(channel.config());
/* 147 */             ChannelPipeline pipeline = channel.pipeline();
/* 148 */             if (Netty4ClientHttpRequestFactory.this.sslContext != null) {
/* 149 */               pipeline.addLast(new ChannelHandler[] { Netty4ClientHttpRequestFactory.this.sslContext.newHandler(channel.alloc()) });
/*     */             }
/* 151 */             pipeline.addLast(new ChannelHandler[] { new HttpClientCodec() });
/* 152 */             pipeline.addLast(new ChannelHandler[] { new HttpObjectAggregator(Netty4ClientHttpRequestFactory.this.maxResponseSize) });
/* 153 */             if (Netty4ClientHttpRequestFactory.this.readTimeout > 0) {
/* 154 */               pipeline.addLast(new ChannelHandler[] { new ReadTimeoutHandler(Netty4ClientHttpRequestFactory.this.readTimeout, TimeUnit.MILLISECONDS) });
/*     */             }
/*     */             
/*     */           }
/* 158 */         });
/* 159 */       this.bootstrap = bootstrap;
/*     */     }
/* 161 */     return this.bootstrap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void configureChannel(SocketChannelConfig config)
/*     */   {
/* 170 */     if (this.connectTimeout >= 0) {
/* 171 */       config.setConnectTimeoutMillis(this.connectTimeout);
/*     */     }
/*     */   }
/*     */   
/*     */   public void afterPropertiesSet()
/*     */   {
/* 177 */     getBootstrap();
/*     */   }
/*     */   
/*     */   public ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod)
/*     */     throws IOException
/*     */   {
/* 183 */     return createRequestInternal(uri, httpMethod);
/*     */   }
/*     */   
/*     */   public AsyncClientHttpRequest createAsyncRequest(URI uri, HttpMethod httpMethod) throws IOException
/*     */   {
/* 188 */     return createRequestInternal(uri, httpMethod);
/*     */   }
/*     */   
/*     */   private Netty4ClientHttpRequest createRequestInternal(URI uri, HttpMethod httpMethod) {
/* 192 */     return new Netty4ClientHttpRequest(getBootstrap(), uri, httpMethod);
/*     */   }
/*     */   
/*     */   public void destroy()
/*     */     throws InterruptedException
/*     */   {
/* 198 */     if (this.defaultEventLoopGroup)
/*     */     {
/* 200 */       this.eventLoopGroup.shutdownGracefully().sync();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\client\Netty4ClientHttpRequestFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */