/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.HttpEntityEnclosingRequest;
/*     */ import org.apache.http.HttpResponse;
/*     */ import org.apache.http.client.HttpClient;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ import org.apache.http.entity.ByteArrayEntity;
/*     */ import org.apache.http.protocol.HttpContext;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class HttpComponentsClientHttpRequest
/*     */   extends AbstractBufferingClientHttpRequest
/*     */ {
/*     */   private final HttpClient httpClient;
/*     */   private final HttpUriRequest httpRequest;
/*     */   private final HttpContext httpContext;
/*     */   
/*     */   HttpComponentsClientHttpRequest(HttpClient httpClient, HttpUriRequest httpRequest, HttpContext httpContext)
/*     */   {
/*  61 */     this.httpClient = httpClient;
/*  62 */     this.httpRequest = httpRequest;
/*  63 */     this.httpContext = httpContext;
/*     */   }
/*     */   
/*     */ 
/*     */   public HttpMethod getMethod()
/*     */   {
/*  69 */     return HttpMethod.resolve(this.httpRequest.getMethod());
/*     */   }
/*     */   
/*     */   public URI getURI()
/*     */   {
/*  74 */     return this.httpRequest.getURI();
/*     */   }
/*     */   
/*     */   HttpContext getHttpContext() {
/*  78 */     return this.httpContext;
/*     */   }
/*     */   
/*     */   protected ClientHttpResponse executeInternal(HttpHeaders headers, byte[] bufferedOutput)
/*     */     throws IOException
/*     */   {
/*  84 */     addHeaders(this.httpRequest, headers);
/*     */     
/*  86 */     if ((this.httpRequest instanceof HttpEntityEnclosingRequest)) {
/*  87 */       HttpEntityEnclosingRequest entityEnclosingRequest = (HttpEntityEnclosingRequest)this.httpRequest;
/*  88 */       HttpEntity requestEntity = new ByteArrayEntity(bufferedOutput);
/*  89 */       entityEnclosingRequest.setEntity(requestEntity);
/*     */     }
/*  91 */     HttpResponse httpResponse = this.httpClient.execute(this.httpRequest, this.httpContext);
/*  92 */     return new HttpComponentsClientHttpResponse(httpResponse);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void addHeaders(HttpUriRequest httpRequest, HttpHeaders headers)
/*     */   {
/* 102 */     for (Map.Entry<String, List<String>> entry : headers.entrySet()) {
/* 103 */       headerName = (String)entry.getKey();
/* 104 */       if ("Cookie".equalsIgnoreCase(headerName)) {
/* 105 */         headerValue = StringUtils.collectionToDelimitedString((Collection)entry.getValue(), "; ");
/* 106 */         httpRequest.addHeader(headerName, headerValue);
/*     */       }
/* 108 */       else if ((!"Content-Length".equalsIgnoreCase(headerName)) && 
/* 109 */         (!"Transfer-Encoding".equalsIgnoreCase(headerName))) {
/* 110 */         for (String headerValue : (List)entry.getValue()) {
/* 111 */           httpRequest.addHeader(headerName, headerValue);
/*     */         }
/*     */       }
/*     */     }
/*     */     String headerName;
/*     */     String headerValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\client\HttpComponentsClientHttpRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */