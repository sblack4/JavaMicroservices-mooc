/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import com.squareup.okhttp.Cache;
/*     */ import com.squareup.okhttp.Dispatcher;
/*     */ import com.squareup.okhttp.MediaType;
/*     */ import com.squareup.okhttp.OkHttpClient;
/*     */ import com.squareup.okhttp.Request;
/*     */ import com.squareup.okhttp.Request.Builder;
/*     */ import com.squareup.okhttp.RequestBody;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OkHttpClientHttpRequestFactory
/*     */   implements ClientHttpRequestFactory, AsyncClientHttpRequestFactory, DisposableBean
/*     */ {
/*     */   private final OkHttpClient client;
/*     */   private final boolean defaultClient;
/*     */   
/*     */   public OkHttpClientHttpRequestFactory()
/*     */   {
/*  58 */     this.client = new OkHttpClient();
/*  59 */     this.defaultClient = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public OkHttpClientHttpRequestFactory(OkHttpClient client)
/*     */   {
/*  67 */     Assert.notNull(client, "OkHttpClient must not be null");
/*  68 */     this.client = client;
/*  69 */     this.defaultClient = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReadTimeout(int readTimeout)
/*     */   {
/*  79 */     this.client.setReadTimeout(readTimeout, TimeUnit.MILLISECONDS);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWriteTimeout(int writeTimeout)
/*     */   {
/*  88 */     this.client.setWriteTimeout(writeTimeout, TimeUnit.MILLISECONDS);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectTimeout(int connectTimeout)
/*     */   {
/*  97 */     this.client.setConnectTimeout(connectTimeout, TimeUnit.MILLISECONDS);
/*     */   }
/*     */   
/*     */ 
/*     */   public ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod)
/*     */   {
/* 103 */     return new OkHttpClientHttpRequest(this.client, uri, httpMethod);
/*     */   }
/*     */   
/*     */   public AsyncClientHttpRequest createAsyncRequest(URI uri, HttpMethod httpMethod)
/*     */   {
/* 108 */     return new OkHttpAsyncClientHttpRequest(this.client, uri, httpMethod);
/*     */   }
/*     */   
/*     */   public void destroy()
/*     */     throws IOException
/*     */   {
/* 114 */     if (this.defaultClient)
/*     */     {
/* 116 */       if (this.client.getCache() != null) {
/* 117 */         this.client.getCache().close();
/*     */       }
/* 119 */       this.client.getDispatcher().getExecutorService().shutdown();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static Request buildRequest(HttpHeaders headers, byte[] content, URI uri, HttpMethod method)
/*     */     throws MalformedURLException
/*     */   {
/* 127 */     MediaType contentType = getContentType(headers);
/* 128 */     RequestBody body = content.length > 0 ? RequestBody.create(contentType, content) : null;
/*     */     
/* 130 */     URL url = uri.toURL();
/* 131 */     String methodName = method.name();
/* 132 */     Request.Builder builder = new Request.Builder().url(url).method(methodName, body);
/*     */     
/* 134 */     for (Map.Entry<String, List<String>> entry : headers.entrySet()) {
/* 135 */       headerName = (String)entry.getKey();
/* 136 */       for (String headerValue : (List)entry.getValue()) {
/* 137 */         builder.addHeader(headerName, headerValue);
/*     */       }
/*     */     }
/*     */     String headerName;
/* 141 */     return builder.build();
/*     */   }
/*     */   
/*     */   private static MediaType getContentType(HttpHeaders headers) {
/* 145 */     String rawContentType = headers.getFirst("Content-Type");
/*     */     
/* 147 */     return StringUtils.hasText(rawContentType) ? MediaType.parse(rawContentType) : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\client\OkHttpClientHttpRequestFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */