/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import okhttp3.Cache;
/*     */ import okhttp3.Dispatcher;
/*     */ import okhttp3.MediaType;
/*     */ import okhttp3.OkHttpClient;
/*     */ import okhttp3.OkHttpClient.Builder;
/*     */ import okhttp3.Request;
/*     */ import okhttp3.Request.Builder;
/*     */ import okhttp3.RequestBody;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OkHttp3ClientHttpRequestFactory
/*     */   implements ClientHttpRequestFactory, AsyncClientHttpRequestFactory, DisposableBean
/*     */ {
/*     */   private OkHttpClient client;
/*     */   private final boolean defaultClient;
/*     */   
/*     */   public OkHttp3ClientHttpRequestFactory()
/*     */   {
/*  58 */     this.client = new OkHttpClient();
/*  59 */     this.defaultClient = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public OkHttp3ClientHttpRequestFactory(OkHttpClient client)
/*     */   {
/*  67 */     Assert.notNull(client, "OkHttpClient must not be null");
/*  68 */     this.client = client;
/*  69 */     this.defaultClient = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReadTimeout(int readTimeout)
/*     */   {
/*  81 */     this.client = this.client.newBuilder().readTimeout(readTimeout, TimeUnit.MILLISECONDS).build();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWriteTimeout(int writeTimeout)
/*     */   {
/*  92 */     this.client = this.client.newBuilder().writeTimeout(writeTimeout, TimeUnit.MILLISECONDS).build();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectTimeout(int connectTimeout)
/*     */   {
/* 103 */     this.client = this.client.newBuilder().connectTimeout(connectTimeout, TimeUnit.MILLISECONDS).build();
/*     */   }
/*     */   
/*     */ 
/*     */   public ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod)
/*     */   {
/* 109 */     return new OkHttp3ClientHttpRequest(this.client, uri, httpMethod);
/*     */   }
/*     */   
/*     */   public AsyncClientHttpRequest createAsyncRequest(URI uri, HttpMethod httpMethod)
/*     */   {
/* 114 */     return new OkHttp3AsyncClientHttpRequest(this.client, uri, httpMethod);
/*     */   }
/*     */   
/*     */   public void destroy()
/*     */     throws IOException
/*     */   {
/* 120 */     if (this.defaultClient)
/*     */     {
/* 122 */       if (this.client.cache() != null) {
/* 123 */         this.client.cache().close();
/*     */       }
/* 125 */       this.client.dispatcher().executorService().shutdown();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static Request buildRequest(HttpHeaders headers, byte[] content, URI uri, HttpMethod method)
/*     */     throws MalformedURLException
/*     */   {
/* 133 */     MediaType contentType = getContentType(headers);
/* 134 */     RequestBody body = content.length > 0 ? RequestBody.create(contentType, content) : null;
/*     */     
/* 136 */     URL url = uri.toURL();
/* 137 */     String methodName = method.name();
/* 138 */     Request.Builder builder = new Request.Builder().url(url).method(methodName, body);
/*     */     
/* 140 */     for (Map.Entry<String, List<String>> entry : headers.entrySet()) {
/* 141 */       headerName = (String)entry.getKey();
/* 142 */       for (String headerValue : (List)entry.getValue()) {
/* 143 */         builder.addHeader(headerName, headerValue);
/*     */       }
/*     */     }
/*     */     String headerName;
/* 147 */     return builder.build();
/*     */   }
/*     */   
/*     */   private static MediaType getContentType(HttpHeaders headers) {
/* 151 */     String rawContentType = headers.getFirst("Content-Type");
/* 152 */     return StringUtils.hasText(rawContentType) ? MediaType.parse(rawContentType) : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\client\OkHttp3ClientHttpRequestFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */