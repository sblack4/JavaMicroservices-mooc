/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import io.netty.bootstrap.Bootstrap;
/*     */ import io.netty.buffer.ByteBufOutputStream;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.channel.SimpleChannelInboundHandler;
/*     */ import io.netty.handler.codec.http.DefaultFullHttpRequest;
/*     */ import io.netty.handler.codec.http.FullHttpRequest;
/*     */ import io.netty.handler.codec.http.FullHttpResponse;
/*     */ import io.netty.handler.codec.http.HttpVersion;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import org.springframework.util.concurrent.ListenableFuture;
/*     */ import org.springframework.util.concurrent.SettableListenableFuture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Netty4ClientHttpRequest
/*     */   extends AbstractAsyncClientHttpRequest
/*     */   implements ClientHttpRequest
/*     */ {
/*     */   private final Bootstrap bootstrap;
/*     */   private final URI uri;
/*     */   private final org.springframework.http.HttpMethod method;
/*     */   private final ByteBufOutputStream body;
/*     */   
/*     */   public Netty4ClientHttpRequest(Bootstrap bootstrap, URI uri, org.springframework.http.HttpMethod method)
/*     */   {
/*  66 */     this.bootstrap = bootstrap;
/*  67 */     this.uri = uri;
/*  68 */     this.method = method;
/*  69 */     this.body = new ByteBufOutputStream(Unpooled.buffer(1024));
/*     */   }
/*     */   
/*     */ 
/*     */   public org.springframework.http.HttpMethod getMethod()
/*     */   {
/*  75 */     return this.method;
/*     */   }
/*     */   
/*     */   public URI getURI()
/*     */   {
/*  80 */     return this.uri;
/*     */   }
/*     */   
/*     */   protected OutputStream getBodyInternal(org.springframework.http.HttpHeaders headers) throws IOException
/*     */   {
/*  85 */     return this.body;
/*     */   }
/*     */   
/*     */   protected ListenableFuture<ClientHttpResponse> executeInternal(final org.springframework.http.HttpHeaders headers) throws IOException
/*     */   {
/*  90 */     final SettableListenableFuture<ClientHttpResponse> responseFuture = new SettableListenableFuture();
/*     */     
/*     */ 
/*  93 */     ChannelFutureListener connectionListener = new ChannelFutureListener()
/*     */     {
/*     */       public void operationComplete(ChannelFuture future) throws Exception {
/*  96 */         if (future.isSuccess()) {
/*  97 */           Channel channel = future.channel();
/*  98 */           channel.pipeline().addLast(new ChannelHandler[] { new Netty4ClientHttpRequest.RequestExecuteHandler(responseFuture) });
/*  99 */           FullHttpRequest nettyRequest = Netty4ClientHttpRequest.this.createFullHttpRequest(headers);
/* 100 */           channel.writeAndFlush(nettyRequest);
/*     */         }
/*     */         else {
/* 103 */           responseFuture.setException(future.cause());
/*     */         }
/*     */         
/*     */       }
/* 107 */     };
/* 108 */     this.bootstrap.connect(this.uri.getHost(), getPort(this.uri)).addListener(connectionListener);
/*     */     
/* 110 */     return responseFuture;
/*     */   }
/*     */   
/*     */   public ClientHttpResponse execute() throws IOException
/*     */   {
/*     */     try {
/* 116 */       return (ClientHttpResponse)executeAsync().get();
/*     */     }
/*     */     catch (InterruptedException ex) {
/* 119 */       throw new IOException(ex.getMessage(), ex);
/*     */     }
/*     */     catch (ExecutionException ex) {
/* 122 */       if ((ex.getCause() instanceof IOException)) {
/* 123 */         throw ((IOException)ex.getCause());
/*     */       }
/*     */       
/* 126 */       throw new IOException(ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private static int getPort(URI uri)
/*     */   {
/* 132 */     int port = uri.getPort();
/* 133 */     if (port == -1) {
/* 134 */       if ("http".equalsIgnoreCase(uri.getScheme())) {
/* 135 */         port = 80;
/*     */       }
/* 137 */       else if ("https".equalsIgnoreCase(uri.getScheme())) {
/* 138 */         port = 443;
/*     */       }
/*     */     }
/* 141 */     return port;
/*     */   }
/*     */   
/*     */   private FullHttpRequest createFullHttpRequest(org.springframework.http.HttpHeaders headers)
/*     */   {
/* 146 */     io.netty.handler.codec.http.HttpMethod nettyMethod = io.netty.handler.codec.http.HttpMethod.valueOf(this.method.name());
/*     */     
/*     */ 
/* 149 */     FullHttpRequest nettyRequest = new DefaultFullHttpRequest(HttpVersion.HTTP_1_1, nettyMethod, this.uri.toString(), this.body.buffer());
/*     */     
/* 151 */     nettyRequest.headers().set("Host", this.uri.getHost());
/* 152 */     nettyRequest.headers().set("Connection", "close");
/*     */     
/* 154 */     for (Map.Entry<String, List<String>> entry : headers.entrySet()) {
/* 155 */       nettyRequest.headers().add((String)entry.getKey(), (Iterable)entry.getValue());
/*     */     }
/*     */     
/* 158 */     return nettyRequest;
/*     */   }
/*     */   
/*     */ 
/*     */   private static class RequestExecuteHandler
/*     */     extends SimpleChannelInboundHandler<FullHttpResponse>
/*     */   {
/*     */     private final SettableListenableFuture<ClientHttpResponse> responseFuture;
/*     */     
/*     */ 
/*     */     public RequestExecuteHandler(SettableListenableFuture<ClientHttpResponse> responseFuture)
/*     */     {
/* 170 */       this.responseFuture = responseFuture;
/*     */     }
/*     */     
/*     */     protected void channelRead0(ChannelHandlerContext context, FullHttpResponse response) throws Exception
/*     */     {
/* 175 */       this.responseFuture.set(new Netty4ClientHttpResponse(context, response));
/*     */     }
/*     */     
/*     */     public void exceptionCaught(ChannelHandlerContext context, Throwable cause) throws Exception
/*     */     {
/* 180 */       this.responseFuture.setException(cause);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\client\Netty4ClientHttpRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */