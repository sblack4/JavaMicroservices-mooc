/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URI;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.http.HttpRequest;
/*    */ import org.springframework.util.StreamUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class InterceptingClientHttpRequest
/*    */   extends AbstractBufferingClientHttpRequest
/*    */ {
/*    */   private final ClientHttpRequestFactory requestFactory;
/*    */   private final List<ClientHttpRequestInterceptor> interceptors;
/*    */   private HttpMethod method;
/*    */   private URI uri;
/*    */   
/*    */   protected InterceptingClientHttpRequest(ClientHttpRequestFactory requestFactory, List<ClientHttpRequestInterceptor> interceptors, URI uri, HttpMethod method)
/*    */   {
/* 49 */     this.requestFactory = requestFactory;
/* 50 */     this.interceptors = interceptors;
/* 51 */     this.method = method;
/* 52 */     this.uri = uri;
/*    */   }
/*    */   
/*    */ 
/*    */   public HttpMethod getMethod()
/*    */   {
/* 58 */     return this.method;
/*    */   }
/*    */   
/*    */   public URI getURI()
/*    */   {
/* 63 */     return this.uri;
/*    */   }
/*    */   
/*    */   protected final ClientHttpResponse executeInternal(HttpHeaders headers, byte[] bufferedOutput) throws IOException
/*    */   {
/* 68 */     InterceptingRequestExecution requestExecution = new InterceptingRequestExecution();
/* 69 */     return requestExecution.execute(this, bufferedOutput);
/*    */   }
/*    */   
/*    */   private class InterceptingRequestExecution implements ClientHttpRequestExecution
/*    */   {
/*    */     private final Iterator<ClientHttpRequestInterceptor> iterator;
/*    */     
/*    */     public InterceptingRequestExecution()
/*    */     {
/* 78 */       this.iterator = InterceptingClientHttpRequest.this.interceptors.iterator();
/*    */     }
/*    */     
/*    */     public ClientHttpResponse execute(HttpRequest request, byte[] body) throws IOException
/*    */     {
/* 83 */       if (this.iterator.hasNext()) {
/* 84 */         ClientHttpRequestInterceptor nextInterceptor = (ClientHttpRequestInterceptor)this.iterator.next();
/* 85 */         return nextInterceptor.intercept(request, body, this);
/*    */       }
/*    */       
/* 88 */       ClientHttpRequest delegate = InterceptingClientHttpRequest.this.requestFactory.createRequest(request.getURI(), request.getMethod());
/* 89 */       delegate.getHeaders().putAll(request.getHeaders());
/* 90 */       if (body.length > 0) {
/* 91 */         StreamUtils.copy(body, delegate.getBody());
/*    */       }
/* 93 */       return delegate.execute();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\client\InterceptingClientHttpRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */