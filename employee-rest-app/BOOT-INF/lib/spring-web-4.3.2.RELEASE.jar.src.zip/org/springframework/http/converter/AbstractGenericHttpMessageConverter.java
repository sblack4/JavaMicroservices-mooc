/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.Type;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.StreamingHttpOutputMessage;
/*     */ import org.springframework.http.StreamingHttpOutputMessage.Body;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractGenericHttpMessageConverter<T>
/*     */   extends AbstractHttpMessageConverter<T>
/*     */   implements GenericHttpMessageConverter<T>
/*     */ {
/*     */   protected AbstractGenericHttpMessageConverter() {}
/*     */   
/*     */   protected AbstractGenericHttpMessageConverter(MediaType supportedMediaType)
/*     */   {
/*  49 */     super(supportedMediaType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractGenericHttpMessageConverter(MediaType... supportedMediaTypes)
/*     */   {
/*  57 */     super(supportedMediaTypes);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean canRead(Type type, Class<?> contextClass, MediaType mediaType)
/*     */   {
/*  63 */     return canRead(contextClass, mediaType);
/*     */   }
/*     */   
/*     */   public boolean canWrite(Type type, Class<?> clazz, MediaType mediaType)
/*     */   {
/*  68 */     return canWrite(clazz, mediaType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void write(final T t, final Type type, MediaType contentType, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/*  78 */     final HttpHeaders headers = outputMessage.getHeaders();
/*  79 */     addDefaultHeaders(headers, t, contentType);
/*     */     
/*  81 */     if ((outputMessage instanceof StreamingHttpOutputMessage)) {
/*  82 */       StreamingHttpOutputMessage streamingOutputMessage = (StreamingHttpOutputMessage)outputMessage;
/*  83 */       streamingOutputMessage.setBody(new StreamingHttpOutputMessage.Body()
/*     */       {
/*     */         public void writeTo(final OutputStream outputStream) throws IOException {
/*  86 */           AbstractGenericHttpMessageConverter.this.writeInternal(t, type, new HttpOutputMessage()
/*     */           {
/*     */             public OutputStream getBody() throws IOException {
/*  89 */               return outputStream;
/*     */             }
/*     */             
/*     */             public HttpHeaders getHeaders() {
/*  93 */               return AbstractGenericHttpMessageConverter.1.this.val$headers;
/*     */             }
/*     */           });
/*     */         }
/*     */       });
/*     */     }
/*     */     else {
/* 100 */       writeInternal(t, type, outputMessage);
/* 101 */       outputMessage.getBody().flush();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void writeInternal(T t, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/* 110 */     writeInternal(t, null, outputMessage);
/*     */   }
/*     */   
/*     */   protected abstract void writeInternal(T paramT, Type paramType, HttpOutputMessage paramHttpOutputMessage)
/*     */     throws IOException, HttpMessageNotWritableException;
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\converter\AbstractGenericHttpMessageConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */