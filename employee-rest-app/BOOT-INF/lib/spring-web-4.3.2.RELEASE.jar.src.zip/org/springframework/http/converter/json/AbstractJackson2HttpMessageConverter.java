/*     */ package org.springframework.http.converter.json;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonEncoding;
/*     */ import com.fasterxml.jackson.core.JsonFactory;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonProcessingException;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.ObjectReader;
/*     */ import com.fasterxml.jackson.databind.ObjectWriter;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.ser.FilterProvider;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.AbstractGenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.TypeUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractJackson2HttpMessageConverter
/*     */   extends AbstractGenericHttpMessageConverter<Object>
/*     */ {
/*  64 */   public static final Charset DEFAULT_CHARSET = Charset.forName("UTF-8");
/*     */   
/*     */   protected ObjectMapper objectMapper;
/*     */   
/*     */   private Boolean prettyPrint;
/*     */   
/*     */ 
/*     */   protected AbstractJackson2HttpMessageConverter(ObjectMapper objectMapper)
/*     */   {
/*  73 */     this.objectMapper = objectMapper;
/*  74 */     setDefaultCharset(DEFAULT_CHARSET);
/*     */   }
/*     */   
/*     */   protected AbstractJackson2HttpMessageConverter(ObjectMapper objectMapper, MediaType supportedMediaType) {
/*  78 */     super(supportedMediaType);
/*  79 */     this.objectMapper = objectMapper;
/*  80 */     setDefaultCharset(DEFAULT_CHARSET);
/*     */   }
/*     */   
/*     */   protected AbstractJackson2HttpMessageConverter(ObjectMapper objectMapper, MediaType... supportedMediaTypes) {
/*  84 */     super(supportedMediaTypes);
/*  85 */     this.objectMapper = objectMapper;
/*  86 */     setDefaultCharset(DEFAULT_CHARSET);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setObjectMapper(ObjectMapper objectMapper)
/*     */   {
/* 102 */     Assert.notNull(objectMapper, "ObjectMapper must not be null");
/* 103 */     this.objectMapper = objectMapper;
/* 104 */     configurePrettyPrint();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ObjectMapper getObjectMapper()
/*     */   {
/* 111 */     return this.objectMapper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPrettyPrint(boolean prettyPrint)
/*     */   {
/* 124 */     this.prettyPrint = Boolean.valueOf(prettyPrint);
/* 125 */     configurePrettyPrint();
/*     */   }
/*     */   
/*     */   private void configurePrettyPrint() {
/* 129 */     if (this.prettyPrint != null) {
/* 130 */       this.objectMapper.configure(SerializationFeature.INDENT_OUTPUT, this.prettyPrint.booleanValue());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 137 */     return canRead(clazz, null, mediaType);
/*     */   }
/*     */   
/*     */   public boolean canRead(Type type, Class<?> contextClass, MediaType mediaType)
/*     */   {
/* 142 */     if (!canRead(mediaType)) {
/* 143 */       return false;
/*     */     }
/* 145 */     JavaType javaType = getJavaType(type, contextClass);
/* 146 */     if (!this.logger.isWarnEnabled()) {
/* 147 */       return this.objectMapper.canDeserialize(javaType);
/*     */     }
/* 149 */     AtomicReference<Throwable> causeRef = new AtomicReference();
/* 150 */     if (this.objectMapper.canDeserialize(javaType, causeRef)) {
/* 151 */       return true;
/*     */     }
/* 153 */     logWarningIfNecessary(javaType, (Throwable)causeRef.get());
/* 154 */     return false;
/*     */   }
/*     */   
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 159 */     if (!canWrite(mediaType)) {
/* 160 */       return false;
/*     */     }
/* 162 */     if (!this.logger.isWarnEnabled()) {
/* 163 */       return this.objectMapper.canSerialize(clazz);
/*     */     }
/* 165 */     AtomicReference<Throwable> causeRef = new AtomicReference();
/* 166 */     if (this.objectMapper.canSerialize(clazz, causeRef)) {
/* 167 */       return true;
/*     */     }
/* 169 */     logWarningIfNecessary(clazz, (Throwable)causeRef.get());
/* 170 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void logWarningIfNecessary(Type type, Throwable cause)
/*     */   {
/* 182 */     if ((cause != null) && ((!(cause instanceof JsonMappingException)) || (!cause.getMessage().startsWith("Can not find")))) {
/* 183 */       String msg = "Failed to evaluate Jackson " + ((type instanceof JavaType) ? "de" : "") + "serialization for type [" + type + "]";
/*     */       
/* 185 */       if (this.logger.isDebugEnabled()) {
/* 186 */         this.logger.warn(msg, cause);
/*     */       }
/*     */       else {
/* 189 */         this.logger.warn(msg + ": " + cause);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected boolean supports(Class<?> clazz)
/*     */   {
/* 197 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */   protected Object readInternal(Class<?> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 204 */     JavaType javaType = getJavaType(clazz, null);
/* 205 */     return readJavaType(javaType, inputMessage);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object read(Type type, Class<?> contextClass, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 212 */     JavaType javaType = getJavaType(type, contextClass);
/* 213 */     return readJavaType(javaType, inputMessage);
/*     */   }
/*     */   
/*     */   private Object readJavaType(JavaType javaType, HttpInputMessage inputMessage) {
/*     */     try {
/* 218 */       if ((inputMessage instanceof MappingJacksonInputMessage)) {
/* 219 */         Class<?> deserializationView = ((MappingJacksonInputMessage)inputMessage).getDeserializationView();
/* 220 */         if (deserializationView != null)
/*     */         {
/* 222 */           return this.objectMapper.readerWithView(deserializationView).forType(javaType).readValue(inputMessage.getBody());
/*     */         }
/*     */       }
/* 225 */       return this.objectMapper.readValue(inputMessage.getBody(), javaType);
/*     */     }
/*     */     catch (IOException ex) {
/* 228 */       throw new HttpMessageNotReadableException("Could not read document: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void writeInternal(Object object, Type type, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/* 236 */     JsonEncoding encoding = getJsonEncoding(outputMessage.getHeaders().getContentType());
/* 237 */     JsonGenerator generator = this.objectMapper.getFactory().createGenerator(outputMessage.getBody(), encoding);
/*     */     try {
/* 239 */       writePrefix(generator, object);
/*     */       
/* 241 */       Class<?> serializationView = null;
/* 242 */       FilterProvider filters = null;
/* 243 */       Object value = object;
/* 244 */       JavaType javaType = null;
/* 245 */       if ((object instanceof MappingJacksonValue)) {
/* 246 */         MappingJacksonValue container = (MappingJacksonValue)object;
/* 247 */         value = container.getValue();
/* 248 */         serializationView = container.getSerializationView();
/* 249 */         filters = container.getFilters();
/*     */       }
/* 251 */       if ((type != null) && (value != null) && (TypeUtils.isAssignable(type, value.getClass())))
/* 252 */         javaType = getJavaType(type, null);
/*     */       ObjectWriter objectWriter;
/*     */       ObjectWriter objectWriter;
/* 255 */       if (serializationView != null) {
/* 256 */         objectWriter = this.objectMapper.writerWithView(serializationView);
/*     */       } else { ObjectWriter objectWriter;
/* 258 */         if (filters != null) {
/* 259 */           objectWriter = this.objectMapper.writer(filters);
/*     */         }
/*     */         else
/* 262 */           objectWriter = this.objectMapper.writer();
/*     */       }
/* 264 */       if ((javaType != null) && (javaType.isContainerType())) {
/* 265 */         objectWriter = objectWriter.forType(javaType);
/*     */       }
/* 267 */       objectWriter.writeValue(generator, value);
/*     */       
/* 269 */       writeSuffix(generator, object);
/* 270 */       generator.flush();
/*     */     }
/*     */     catch (JsonProcessingException ex)
/*     */     {
/* 274 */       throw new HttpMessageNotWritableException("Could not write content: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writePrefix(JsonGenerator generator, Object object)
/*     */     throws IOException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeSuffix(JsonGenerator generator, Object object)
/*     */     throws IOException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JavaType getJavaType(Type type, Class<?> contextClass)
/*     */   {
/* 314 */     TypeFactory typeFactory = this.objectMapper.getTypeFactory();
/* 315 */     if (contextClass != null) {
/* 316 */       ResolvableType resolvedType = ResolvableType.forType(type);
/* 317 */       if ((type instanceof TypeVariable)) {
/* 318 */         ResolvableType resolvedTypeVariable = resolveVariable((TypeVariable)type, 
/* 319 */           ResolvableType.forClass(contextClass));
/* 320 */         if (resolvedTypeVariable != ResolvableType.NONE) {
/* 321 */           return typeFactory.constructType(resolvedTypeVariable.resolve());
/*     */         }
/*     */       }
/* 324 */       else if (((type instanceof ParameterizedType)) && (resolvedType.hasUnresolvableGenerics())) {
/* 325 */         ParameterizedType parameterizedType = (ParameterizedType)type;
/* 326 */         Class<?>[] generics = new Class[parameterizedType.getActualTypeArguments().length];
/* 327 */         Type[] typeArguments = parameterizedType.getActualTypeArguments();
/* 328 */         for (int i = 0; i < typeArguments.length; i++) {
/* 329 */           Type typeArgument = typeArguments[i];
/* 330 */           if ((typeArgument instanceof TypeVariable)) {
/* 331 */             ResolvableType resolvedTypeArgument = resolveVariable((TypeVariable)typeArgument, 
/* 332 */               ResolvableType.forClass(contextClass));
/* 333 */             if (resolvedTypeArgument != ResolvableType.NONE) {
/* 334 */               generics[i] = resolvedTypeArgument.resolve();
/*     */             }
/*     */             else {
/* 337 */               generics[i] = ResolvableType.forType(typeArgument).resolve();
/*     */             }
/*     */           }
/*     */           else {
/* 341 */             generics[i] = ResolvableType.forType(typeArgument).resolve();
/*     */           }
/*     */         }
/* 344 */         return typeFactory.constructType(
/* 345 */           ResolvableType.forClassWithGenerics(resolvedType.getRawClass(), generics).getType());
/*     */       }
/*     */     }
/* 348 */     return typeFactory.constructType(type);
/*     */   }
/*     */   
/*     */   private ResolvableType resolveVariable(TypeVariable<?> typeVariable, ResolvableType contextType)
/*     */   {
/* 353 */     if (contextType.hasGenerics()) {
/* 354 */       ResolvableType resolvedType = ResolvableType.forType(typeVariable, contextType);
/* 355 */       if (resolvedType.resolve() != null) {
/* 356 */         return resolvedType;
/*     */       }
/*     */     }
/* 359 */     ResolvableType resolvedType = resolveVariable(typeVariable, contextType.getSuperType());
/* 360 */     if (resolvedType.resolve() != null) {
/* 361 */       return resolvedType;
/*     */     }
/* 363 */     for (ResolvableType ifc : contextType.getInterfaces()) {
/* 364 */       resolvedType = resolveVariable(typeVariable, ifc);
/* 365 */       if (resolvedType.resolve() != null) {
/* 366 */         return resolvedType;
/*     */       }
/*     */     }
/* 369 */     return ResolvableType.NONE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JsonEncoding getJsonEncoding(MediaType contentType)
/*     */   {
/* 378 */     if ((contentType != null) && (contentType.getCharset() != null)) {
/* 379 */       Charset charset = contentType.getCharset();
/* 380 */       for (JsonEncoding encoding : JsonEncoding.values()) {
/* 381 */         if (charset.name().equals(encoding.getJavaName())) {
/* 382 */           return encoding;
/*     */         }
/*     */       }
/*     */     }
/* 386 */     return JsonEncoding.UTF8;
/*     */   }
/*     */   
/*     */   protected MediaType getDefaultContentType(Object object) throws IOException
/*     */   {
/* 391 */     if ((object instanceof MappingJacksonValue)) {
/* 392 */       object = ((MappingJacksonValue)object).getValue();
/*     */     }
/* 394 */     return super.getDefaultContentType(object);
/*     */   }
/*     */   
/*     */   protected Long getContentLength(Object object, MediaType contentType) throws IOException
/*     */   {
/* 399 */     if ((object instanceof MappingJacksonValue)) {
/* 400 */       object = ((MappingJacksonValue)object).getValue();
/*     */     }
/* 402 */     return super.getContentLength(object, contentType);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\converter\json\AbstractJackson2HttpMessageConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */