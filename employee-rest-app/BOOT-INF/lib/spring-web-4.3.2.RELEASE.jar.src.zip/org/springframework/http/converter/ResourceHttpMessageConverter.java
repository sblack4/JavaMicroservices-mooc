/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.activation.FileTypeMap;
/*     */ import javax.activation.MimetypesFileTypeMap;
/*     */ import org.springframework.core.io.ByteArrayResource;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.InputStreamResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceHttpMessageConverter
/*     */   extends AbstractHttpMessageConverter<Resource>
/*     */ {
/*  52 */   private static final boolean jafPresent = ClassUtils.isPresent("javax.activation.FileTypeMap", ResourceHttpMessageConverter.class
/*  53 */     .getClassLoader());
/*     */   
/*     */   public ResourceHttpMessageConverter()
/*     */   {
/*  57 */     super(MediaType.ALL);
/*     */   }
/*     */   
/*     */ 
/*     */   protected boolean supports(Class<?> clazz)
/*     */   {
/*  63 */     return Resource.class.isAssignableFrom(clazz);
/*     */   }
/*     */   
/*     */ 
/*     */   protected Resource readInternal(Class<? extends Resource> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/*  70 */     if (InputStreamResource.class == clazz) {
/*  71 */       return new InputStreamResource(inputMessage.getBody());
/*     */     }
/*  73 */     if (clazz.isAssignableFrom(ByteArrayResource.class)) {
/*  74 */       byte[] body = StreamUtils.copyToByteArray(inputMessage.getBody());
/*  75 */       return new ByteArrayResource(body);
/*     */     }
/*     */     
/*  78 */     throw new IllegalStateException("Unsupported resource class: " + clazz);
/*     */   }
/*     */   
/*     */ 
/*     */   protected MediaType getDefaultContentType(Resource resource)
/*     */   {
/*  84 */     if (jafPresent) {
/*  85 */       return ActivationMediaTypeFactory.getMediaType(resource);
/*     */     }
/*     */     
/*  88 */     return MediaType.APPLICATION_OCTET_STREAM;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Long getContentLength(Resource resource, MediaType contentType)
/*     */     throws IOException
/*     */   {
/*  96 */     if (InputStreamResource.class == resource.getClass()) {
/*  97 */       return null;
/*     */     }
/*  99 */     long contentLength = resource.contentLength();
/* 100 */     return contentLength < 0L ? null : Long.valueOf(contentLength);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void writeInternal(Resource resource, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/* 107 */     writeContent(resource, outputMessage);
/*     */   }
/*     */   
/*     */   protected void writeContent(Resource resource, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException
/*     */   {
/*     */     try {
/* 113 */       InputStream in = resource.getInputStream();
/*     */       try {
/* 115 */         StreamUtils.copy(in, outputMessage.getBody());
/*     */ 
/*     */       }
/*     */       catch (NullPointerException localNullPointerException) {}finally
/*     */       {
/*     */         try
/*     */         {
/* 122 */           in.close();
/*     */         }
/*     */         catch (Throwable localThrowable2) {}
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 132 */       return;
/*     */     }
/*     */     catch (FileNotFoundException localFileNotFoundException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class ActivationMediaTypeFactory
/*     */   {
/* 143 */     private static final FileTypeMap fileTypeMap = ;
/*     */     
/*     */ 
/*     */     private static FileTypeMap loadFileTypeMapFromContextSupportModule()
/*     */     {
/* 148 */       Resource mappingLocation = new ClassPathResource("org/springframework/mail/javamail/mime.types");
/* 149 */       if (mappingLocation.exists()) {
/* 150 */         InputStream inputStream = null;
/*     */         try {
/* 152 */           inputStream = mappingLocation.getInputStream();
/* 153 */           return new MimetypesFileTypeMap(inputStream);
/*     */ 
/*     */         }
/*     */         catch (IOException localIOException4) {}finally
/*     */         {
/*     */ 
/* 159 */           if (inputStream != null) {
/*     */             try {
/* 161 */               inputStream.close();
/*     */             }
/*     */             catch (IOException localIOException3) {}
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 169 */       return FileTypeMap.getDefaultFileTypeMap();
/*     */     }
/*     */     
/*     */     public static MediaType getMediaType(Resource resource) {
/* 173 */       String filename = resource.getFilename();
/* 174 */       if (filename != null) {
/* 175 */         String mediaType = fileTypeMap.getContentType(filename);
/* 176 */         if (StringUtils.hasText(mediaType)) {
/* 177 */           return MediaType.parseMediaType(mediaType);
/*     */         }
/*     */       }
/* 180 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\converter\ResourceHttpMessageConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */