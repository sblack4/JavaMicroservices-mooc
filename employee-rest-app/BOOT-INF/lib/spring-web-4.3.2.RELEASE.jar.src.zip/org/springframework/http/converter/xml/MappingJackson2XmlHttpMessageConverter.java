/*    */ package org.springframework.http.converter.xml;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import com.fasterxml.jackson.dataformat.xml.XmlMapper;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.http.converter.json.AbstractJackson2HttpMessageConverter;
/*    */ import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MappingJackson2XmlHttpMessageConverter
/*    */   extends AbstractJackson2HttpMessageConverter
/*    */ {
/*    */   public MappingJackson2XmlHttpMessageConverter()
/*    */   {
/* 50 */     this(Jackson2ObjectMapperBuilder.xml().build());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public MappingJackson2XmlHttpMessageConverter(ObjectMapper objectMapper)
/*    */   {
/* 60 */     super(objectMapper, new MediaType[] { new MediaType("application", "xml"), new MediaType("text", "xml"), new MediaType("application", "*+xml") });
/*    */     
/*    */ 
/* 63 */     Assert.isAssignable(XmlMapper.class, objectMapper.getClass());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setObjectMapper(ObjectMapper objectMapper)
/*    */   {
/* 72 */     Assert.isAssignable(XmlMapper.class, objectMapper.getClass());
/* 73 */     super.setObjectMapper(objectMapper);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\converter\xml\MappingJackson2XmlHttpMessageConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */