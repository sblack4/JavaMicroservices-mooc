/*     */ package org.springframework.http.converter.json;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.GsonBuilder;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GsonFactoryBean
/*     */   implements FactoryBean<Gson>, InitializingBean
/*     */ {
/*  37 */   private boolean base64EncodeByteArrays = false;
/*     */   
/*  39 */   private boolean serializeNulls = false;
/*     */   
/*  41 */   private boolean prettyPrinting = false;
/*     */   
/*  43 */   private boolean disableHtmlEscaping = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String dateFormatPattern;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Gson gson;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBase64EncodeByteArrays(boolean base64EncodeByteArrays)
/*     */   {
/*  63 */     this.base64EncodeByteArrays = base64EncodeByteArrays;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSerializeNulls(boolean serializeNulls)
/*     */   {
/*  74 */     this.serializeNulls = serializeNulls;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPrettyPrinting(boolean prettyPrinting)
/*     */   {
/*  85 */     this.prettyPrinting = prettyPrinting;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDisableHtmlEscaping(boolean disableHtmlEscaping)
/*     */   {
/*  97 */     this.disableHtmlEscaping = disableHtmlEscaping;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDateFormatPattern(String dateFormatPattern)
/*     */   {
/* 108 */     this.dateFormatPattern = dateFormatPattern;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 115 */     GsonBuilder builder = this.base64EncodeByteArrays ? GsonBuilderUtils.gsonBuilderWithBase64EncodedByteArrays() : new GsonBuilder();
/* 116 */     if (this.serializeNulls) {
/* 117 */       builder.serializeNulls();
/*     */     }
/* 119 */     if (this.prettyPrinting) {
/* 120 */       builder.setPrettyPrinting();
/*     */     }
/* 122 */     if (this.disableHtmlEscaping) {
/* 123 */       builder.disableHtmlEscaping();
/*     */     }
/* 125 */     if (this.dateFormatPattern != null) {
/* 126 */       builder.setDateFormat(this.dateFormatPattern);
/*     */     }
/* 128 */     this.gson = builder.create();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Gson getObject()
/*     */   {
/* 137 */     return this.gson;
/*     */   }
/*     */   
/*     */   public Class<?> getObjectType()
/*     */   {
/* 142 */     return Gson.class;
/*     */   }
/*     */   
/*     */   public boolean isSingleton()
/*     */   {
/* 147 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\converter\json\GsonFactoryBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */