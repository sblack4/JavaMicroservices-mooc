/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.ResourceRegion;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MimeTypeUtils;
/*     */ import org.springframework.util.StreamUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceRegionHttpMessageConverter
/*     */   extends AbstractGenericHttpMessageConverter<Object>
/*     */ {
/*     */   public ResourceRegionHttpMessageConverter()
/*     */   {
/*  45 */     super(MediaType.ALL);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean supports(Class<?> clazz)
/*     */   {
/*  52 */     return false;
/*     */   }
/*     */   
/*     */   public boolean canRead(Type type, Class<?> contextClass, MediaType mediaType)
/*     */   {
/*  57 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public Object read(Type type, Class<?> contextClass, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/*  64 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   protected ResourceRegion readInternal(Class<?> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/*  71 */     return null;
/*     */   }
/*     */   
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/*  76 */     return canWrite(clazz, null, mediaType);
/*     */   }
/*     */   
/*     */   public boolean canWrite(Type type, Class<?> clazz, MediaType mediaType)
/*     */   {
/*  81 */     if (!(type instanceof ParameterizedType)) {
/*  82 */       return ResourceRegion.class.isAssignableFrom((Class)type);
/*     */     }
/*  84 */     ParameterizedType parameterizedType = (ParameterizedType)type;
/*  85 */     if (!(parameterizedType.getRawType() instanceof Class)) {
/*  86 */       return false;
/*     */     }
/*  88 */     Class<?> rawType = (Class)parameterizedType.getRawType();
/*  89 */     if (!Collection.class.isAssignableFrom(rawType)) {
/*  90 */       return false;
/*     */     }
/*  92 */     if (parameterizedType.getActualTypeArguments().length != 1) {
/*  93 */       return false;
/*     */     }
/*  95 */     Type typeArgument = parameterizedType.getActualTypeArguments()[0];
/*  96 */     if (!(typeArgument instanceof Class)) {
/*  97 */       return false;
/*     */     }
/*  99 */     Class<?> typeArgumentClass = (Class)typeArgument;
/* 100 */     return typeArgumentClass.isAssignableFrom(ResourceRegion.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void writeInternal(Object object, Type type, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/* 108 */     if ((object instanceof ResourceRegion)) {
/* 109 */       writeResourceRegion((ResourceRegion)object, outputMessage);
/*     */     }
/*     */     else {
/* 112 */       Collection<ResourceRegion> regions = (Collection)object;
/* 113 */       if (regions.size() == 1) {
/* 114 */         writeResourceRegion((ResourceRegion)regions.iterator().next(), outputMessage);
/*     */       }
/*     */       else {
/* 117 */         writeResourceRegionCollection((Collection)object, outputMessage);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void writeResourceRegion(ResourceRegion region, HttpOutputMessage outputMessage) throws IOException {
/* 123 */     Assert.notNull(region, "ResourceRegion must not be null");
/* 124 */     HttpHeaders responseHeaders = outputMessage.getHeaders();
/* 125 */     long start = region.getPosition();
/* 126 */     long end = start + region.getCount() - 1L;
/* 127 */     Long resourceLength = Long.valueOf(region.getResource().contentLength());
/* 128 */     end = Math.min(end, resourceLength.longValue() - 1L);
/* 129 */     long rangeLength = end - start + 1L;
/* 130 */     responseHeaders.add("Content-Range", "bytes " + start + "-" + end + "/" + resourceLength);
/* 131 */     responseHeaders.setContentLength(rangeLength);
/* 132 */     InputStream in = region.getResource().getInputStream();
/*     */     try {
/* 134 */       StreamUtils.copyRange(in, outputMessage.getBody(), start, end); return;
/*     */     }
/*     */     finally {
/*     */       try {
/* 138 */         in.close();
/*     */       }
/*     */       catch (IOException localIOException1) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void writeResourceRegionCollection(Collection<ResourceRegion> resourceRegions, HttpOutputMessage outputMessage)
/*     */     throws IOException
/*     */   {
/* 149 */     Assert.notNull(resourceRegions, "Collection of ResourceRegion should not be null");
/* 150 */     HttpHeaders responseHeaders = outputMessage.getHeaders();
/* 151 */     MediaType contentType = responseHeaders.getContentType();
/* 152 */     String boundaryString = MimeTypeUtils.generateMultipartBoundaryString();
/* 153 */     responseHeaders.set("Content-Type", "multipart/byteranges; boundary=" + boundaryString);
/* 154 */     OutputStream out = outputMessage.getBody();
/* 155 */     for (ResourceRegion region : resourceRegions) {
/* 156 */       long start = region.getPosition();
/* 157 */       long end = start + region.getCount() - 1L;
/* 158 */       InputStream in = region.getResource().getInputStream();
/*     */       
/* 160 */       println(out);
/* 161 */       print(out, "--" + boundaryString);
/* 162 */       println(out);
/* 163 */       if (contentType != null) {
/* 164 */         print(out, "Content-Type: " + contentType.toString());
/* 165 */         println(out);
/*     */       }
/* 167 */       Long resourceLength = Long.valueOf(region.getResource().contentLength());
/* 168 */       end = Math.min(end, resourceLength.longValue() - 1L);
/* 169 */       print(out, "Content-Range: bytes " + start + "-" + end + "/" + resourceLength);
/* 170 */       println(out);
/* 171 */       println(out);
/*     */       
/* 173 */       StreamUtils.copyRange(in, out, start, end);
/*     */     }
/* 175 */     println(out);
/* 176 */     print(out, "--" + boundaryString + "--");
/*     */   }
/*     */   
/*     */   private static void println(OutputStream os)
/*     */     throws IOException
/*     */   {
/* 182 */     os.write(13);
/* 183 */     os.write(10);
/*     */   }
/*     */   
/*     */   private static void print(OutputStream os, String buf) throws IOException {
/* 187 */     os.write(buf.getBytes("US-ASCII"));
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\converter\ResourceRegionHttpMessageConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */