/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.SortedMap;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.StreamUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringHttpMessageConverter
/*     */   extends AbstractHttpMessageConverter<String>
/*     */ {
/*  43 */   public static final Charset DEFAULT_CHARSET = Charset.forName("ISO-8859-1");
/*     */   
/*     */ 
/*     */   private final List<Charset> availableCharsets;
/*     */   
/*  48 */   private boolean writeAcceptCharset = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringHttpMessageConverter()
/*     */   {
/*  56 */     this(DEFAULT_CHARSET);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringHttpMessageConverter(Charset defaultCharset)
/*     */   {
/*  64 */     super(defaultCharset, new MediaType[] { MediaType.TEXT_PLAIN, MediaType.ALL });
/*  65 */     this.availableCharsets = new ArrayList(Charset.availableCharsets().values());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWriteAcceptCharset(boolean writeAcceptCharset)
/*     */   {
/*  74 */     this.writeAcceptCharset = writeAcceptCharset;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean supports(Class<?> clazz)
/*     */   {
/*  80 */     return String.class == clazz;
/*     */   }
/*     */   
/*     */   protected String readInternal(Class<? extends String> clazz, HttpInputMessage inputMessage) throws IOException
/*     */   {
/*  85 */     Charset charset = getContentTypeCharset(inputMessage.getHeaders().getContentType());
/*  86 */     return StreamUtils.copyToString(inputMessage.getBody(), charset);
/*     */   }
/*     */   
/*     */   protected Long getContentLength(String str, MediaType contentType)
/*     */   {
/*  91 */     Charset charset = getContentTypeCharset(contentType);
/*     */     try {
/*  93 */       return Long.valueOf(str.getBytes(charset.name()).length);
/*     */     }
/*     */     catch (UnsupportedEncodingException ex)
/*     */     {
/*  97 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void writeInternal(String str, HttpOutputMessage outputMessage) throws IOException
/*     */   {
/* 103 */     if (this.writeAcceptCharset) {
/* 104 */       outputMessage.getHeaders().setAcceptCharset(getAcceptedCharsets());
/*     */     }
/* 106 */     Charset charset = getContentTypeCharset(outputMessage.getHeaders().getContentType());
/* 107 */     StreamUtils.copy(str, charset, outputMessage.getBody());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<Charset> getAcceptedCharsets()
/*     */   {
/* 118 */     return this.availableCharsets;
/*     */   }
/*     */   
/*     */   private Charset getContentTypeCharset(MediaType contentType) {
/* 122 */     if ((contentType != null) && (contentType.getCharset() != null)) {
/* 123 */       return contentType.getCharset();
/*     */     }
/*     */     
/* 126 */     return getDefaultCharset();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\converter\StringHttpMessageConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */