/*    */ package org.springframework.http.converter.support;
/*    */ 
/*    */ import org.springframework.http.converter.FormHttpMessageConverter;
/*    */ import org.springframework.http.converter.json.GsonHttpMessageConverter;
/*    */ import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
/*    */ import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
/*    */ import org.springframework.http.converter.xml.MappingJackson2XmlHttpMessageConverter;
/*    */ import org.springframework.http.converter.xml.SourceHttpMessageConverter;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AllEncompassingFormHttpMessageConverter
/*    */   extends FormHttpMessageConverter
/*    */ {
/* 40 */   private static final boolean jaxb2Present = ClassUtils.isPresent("javax.xml.bind.Binder", AllEncompassingFormHttpMessageConverter.class.getClassLoader());
/*    */   
/*    */ 
/* 43 */   private static final boolean jackson2Present = (ClassUtils.isPresent("com.fasterxml.jackson.databind.ObjectMapper", AllEncompassingFormHttpMessageConverter.class.getClassLoader())) && 
/* 44 */     (ClassUtils.isPresent("com.fasterxml.jackson.core.JsonGenerator", AllEncompassingFormHttpMessageConverter.class.getClassLoader()));
/*    */   
/*    */ 
/* 47 */   private static final boolean jackson2XmlPresent = ClassUtils.isPresent("com.fasterxml.jackson.dataformat.xml.XmlMapper", AllEncompassingFormHttpMessageConverter.class.getClassLoader());
/*    */   
/*    */ 
/* 50 */   private static final boolean gsonPresent = ClassUtils.isPresent("com.google.gson.Gson", AllEncompassingFormHttpMessageConverter.class.getClassLoader());
/*    */   
/*    */   public AllEncompassingFormHttpMessageConverter()
/*    */   {
/* 54 */     addPartConverter(new SourceHttpMessageConverter());
/*    */     
/* 56 */     if ((jaxb2Present) && (!jackson2XmlPresent)) {
/* 57 */       addPartConverter(new Jaxb2RootElementHttpMessageConverter());
/*    */     }
/*    */     
/* 60 */     if (jackson2Present) {
/* 61 */       addPartConverter(new MappingJackson2HttpMessageConverter());
/*    */     }
/* 63 */     else if (gsonPresent) {
/* 64 */       addPartConverter(new GsonHttpMessageConverter());
/*    */     }
/*    */     
/* 67 */     if (jackson2XmlPresent) {
/* 68 */       addPartConverter(new MappingJackson2XmlHttpMessageConverter());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\converter\support\AllEncompassingFormHttpMessageConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */