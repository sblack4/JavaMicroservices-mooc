/*     */ package org.springframework.http.converter.json;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.JsonIOException;
/*     */ import com.google.gson.JsonParseException;
/*     */ import com.google.gson.reflect.TypeToken;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Reader;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.charset.Charset;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.AbstractGenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GsonHttpMessageConverter
/*     */   extends AbstractGenericHttpMessageConverter<Object>
/*     */ {
/*  59 */   public static final Charset DEFAULT_CHARSET = Charset.forName("UTF-8");
/*     */   
/*     */ 
/*  62 */   private Gson gson = new Gson();
/*     */   
/*     */ 
/*     */   private String jsonPrefix;
/*     */   
/*     */ 
/*     */ 
/*     */   public GsonHttpMessageConverter()
/*     */   {
/*  71 */     super(new MediaType[] { MediaType.APPLICATION_JSON, new MediaType("application", "*+json") });
/*  72 */     setDefaultCharset(DEFAULT_CHARSET);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setGson(Gson gson)
/*     */   {
/*  83 */     Assert.notNull(gson, "'gson' is required");
/*  84 */     this.gson = gson;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Gson getGson()
/*     */   {
/*  91 */     return this.gson;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setJsonPrefix(String jsonPrefix)
/*     */   {
/*  99 */     this.jsonPrefix = jsonPrefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPrefixJson(boolean prefixJson)
/*     */   {
/* 112 */     this.jsonPrefix = (prefixJson ? ")]}', " : null);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 118 */     return canRead(mediaType);
/*     */   }
/*     */   
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 123 */     return canWrite(mediaType);
/*     */   }
/*     */   
/*     */ 
/*     */   protected boolean supports(Class<?> clazz)
/*     */   {
/* 129 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */   protected Object readInternal(Class<?> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 136 */     TypeToken<?> token = getTypeToken(clazz);
/* 137 */     return readTypeToken(token, inputMessage);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object read(Type type, Class<?> contextClass, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 144 */     TypeToken<?> token = getTypeToken(type);
/* 145 */     return readTypeToken(token, inputMessage);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TypeToken<?> getTypeToken(Type type)
/*     */   {
/* 167 */     return TypeToken.get(type);
/*     */   }
/*     */   
/*     */   private Object readTypeToken(TypeToken<?> token, HttpInputMessage inputMessage) throws IOException {
/* 171 */     Reader json = new InputStreamReader(inputMessage.getBody(), getCharset(inputMessage.getHeaders()));
/*     */     try {
/* 173 */       return this.gson.fromJson(json, token.getType());
/*     */     }
/*     */     catch (JsonParseException ex) {
/* 176 */       throw new HttpMessageNotReadableException("Could not read JSON: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private Charset getCharset(HttpHeaders headers) {
/* 181 */     if ((headers == null) || (headers.getContentType() == null) || (headers.getContentType().getCharset() == null)) {
/* 182 */       return DEFAULT_CHARSET;
/*     */     }
/* 184 */     return headers.getContentType().getCharset();
/*     */   }
/*     */   
/*     */ 
/*     */   protected void writeInternal(Object o, Type type, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/* 191 */     Charset charset = getCharset(outputMessage.getHeaders());
/* 192 */     OutputStreamWriter writer = new OutputStreamWriter(outputMessage.getBody(), charset);
/*     */     try {
/* 194 */       if (this.jsonPrefix != null) {
/* 195 */         writer.append(this.jsonPrefix);
/*     */       }
/* 197 */       if (type != null) {
/* 198 */         this.gson.toJson(o, type, writer);
/*     */       }
/*     */       else {
/* 201 */         this.gson.toJson(o, writer);
/*     */       }
/* 203 */       writer.close();
/*     */     }
/*     */     catch (JsonIOException ex) {
/* 206 */       throw new HttpMessageNotWritableException("Could not write JSON: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\http\converter\json\GsonHttpMessageConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */