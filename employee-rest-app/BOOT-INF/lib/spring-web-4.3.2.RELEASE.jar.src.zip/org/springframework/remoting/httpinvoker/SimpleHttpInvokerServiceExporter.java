/*     */ package org.springframework.remoting.httpinvoker;
/*     */ 
/*     */ import com.sun.net.httpserver.Headers;
/*     */ import com.sun.net.httpserver.HttpExchange;
/*     */ import com.sun.net.httpserver.HttpHandler;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.lang.UsesSunHttpServer;
/*     */ import org.springframework.remoting.rmi.RemoteInvocationSerializingExporter;
/*     */ import org.springframework.remoting.support.RemoteInvocation;
/*     */ import org.springframework.remoting.support.RemoteInvocationResult;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @UsesSunHttpServer
/*     */ public class SimpleHttpInvokerServiceExporter
/*     */   extends RemoteInvocationSerializingExporter
/*     */   implements HttpHandler
/*     */ {
/*     */   public void handle(HttpExchange exchange)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/*  69 */       RemoteInvocation invocation = readRemoteInvocation(exchange);
/*  70 */       RemoteInvocationResult result = invokeAndCreateResult(invocation, getProxy());
/*  71 */       writeRemoteInvocationResult(exchange, result);
/*  72 */       exchange.close();
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/*  75 */       exchange.sendResponseHeaders(500, -1L);
/*  76 */       this.logger.error("Class not found during deserialization", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected RemoteInvocation readRemoteInvocation(HttpExchange exchange)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/*  94 */     return readRemoteInvocation(exchange, exchange.getRequestBody());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected RemoteInvocation readRemoteInvocation(HttpExchange exchange, InputStream is)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 113 */     ObjectInputStream ois = createObjectInputStream(decorateInputStream(exchange, is));
/* 114 */     return doReadRemoteInvocation(ois);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected InputStream decorateInputStream(HttpExchange exchange, InputStream is)
/*     */     throws IOException
/*     */   {
/* 128 */     return is;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeRemoteInvocationResult(HttpExchange exchange, RemoteInvocationResult result)
/*     */     throws IOException
/*     */   {
/* 140 */     exchange.getResponseHeaders().set("Content-Type", getContentType());
/* 141 */     exchange.sendResponseHeaders(200, 0L);
/* 142 */     writeRemoteInvocationResult(exchange, result, exchange.getResponseBody());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeRemoteInvocationResult(HttpExchange exchange, RemoteInvocationResult result, OutputStream os)
/*     */     throws IOException
/*     */   {
/* 162 */     ObjectOutputStream oos = createObjectOutputStream(decorateOutputStream(exchange, os));
/* 163 */     doWriteRemoteInvocationResult(result, oos);
/* 164 */     oos.flush();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected OutputStream decorateOutputStream(HttpExchange exchange, OutputStream os)
/*     */     throws IOException
/*     */   {
/* 178 */     return os;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\remoting\httpinvoker\SimpleHttpInvokerServiceExporter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */