package org.springframework.remoting.httpinvoker;

public abstract interface HttpInvokerClientConfiguration
{
  public abstract String getServiceUrl();
  
  public abstract String getCodebaseUrl();
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\remoting\httpinvoker\HttpInvokerClientConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */