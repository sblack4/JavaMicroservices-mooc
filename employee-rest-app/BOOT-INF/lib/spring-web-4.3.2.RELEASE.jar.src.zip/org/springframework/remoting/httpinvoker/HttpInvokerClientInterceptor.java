/*     */ package org.springframework.remoting.httpinvoker;
/*     */ 
/*     */ import java.io.InvalidClassException;
/*     */ import java.net.ConnectException;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.remoting.RemoteAccessException;
/*     */ import org.springframework.remoting.RemoteConnectFailureException;
/*     */ import org.springframework.remoting.RemoteInvocationFailureException;
/*     */ import org.springframework.remoting.support.RemoteInvocation;
/*     */ import org.springframework.remoting.support.RemoteInvocationBasedAccessor;
/*     */ import org.springframework.remoting.support.RemoteInvocationResult;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpInvokerClientInterceptor
/*     */   extends RemoteInvocationBasedAccessor
/*     */   implements MethodInterceptor, HttpInvokerClientConfiguration
/*     */ {
/*     */   private String codebaseUrl;
/*     */   private HttpInvokerRequestExecutor httpInvokerRequestExecutor;
/*     */   
/*     */   public void setCodebaseUrl(String codebaseUrl)
/*     */   {
/*  88 */     this.codebaseUrl = codebaseUrl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCodebaseUrl()
/*     */   {
/*  96 */     return this.codebaseUrl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHttpInvokerRequestExecutor(HttpInvokerRequestExecutor httpInvokerRequestExecutor)
/*     */   {
/* 109 */     this.httpInvokerRequestExecutor = httpInvokerRequestExecutor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpInvokerRequestExecutor getHttpInvokerRequestExecutor()
/*     */   {
/* 118 */     if (this.httpInvokerRequestExecutor == null) {
/* 119 */       SimpleHttpInvokerRequestExecutor executor = new SimpleHttpInvokerRequestExecutor();
/* 120 */       executor.setBeanClassLoader(getBeanClassLoader());
/* 121 */       this.httpInvokerRequestExecutor = executor;
/*     */     }
/* 123 */     return this.httpInvokerRequestExecutor;
/*     */   }
/*     */   
/*     */   public void afterPropertiesSet()
/*     */   {
/* 128 */     super.afterPropertiesSet();
/*     */     
/*     */ 
/* 131 */     getHttpInvokerRequestExecutor();
/*     */   }
/*     */   
/*     */   public Object invoke(MethodInvocation methodInvocation)
/*     */     throws Throwable
/*     */   {
/* 137 */     if (AopUtils.isToStringMethod(methodInvocation.getMethod())) {
/* 138 */       return "HTTP invoker proxy for service URL [" + getServiceUrl() + "]";
/*     */     }
/*     */     
/* 141 */     RemoteInvocation invocation = createRemoteInvocation(methodInvocation);
/*     */     try
/*     */     {
/* 144 */       result = executeRequest(invocation, methodInvocation);
/*     */     } catch (Throwable ex) {
/*     */       RemoteInvocationResult result;
/* 147 */       throw convertHttpInvokerAccessException(ex);
/*     */     }
/*     */     try {
/* 150 */       return recreateRemoteInvocationResult(result);
/*     */     } catch (Throwable ex) {
/*     */       RemoteInvocationResult result;
/* 153 */       if (result.hasInvocationTargetException()) {
/* 154 */         throw ex;
/*     */       }
/*     */       
/*     */ 
/* 158 */       throw new RemoteInvocationFailureException("Invocation of method [" + methodInvocation.getMethod() + "] failed in HTTP invoker remote service at [" + getServiceUrl() + "]", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected RemoteInvocationResult executeRequest(RemoteInvocation invocation, MethodInvocation originalInvocation)
/*     */     throws Exception
/*     */   {
/* 176 */     return executeRequest(invocation);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected RemoteInvocationResult executeRequest(RemoteInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 194 */     return getHttpInvokerRequestExecutor().executeRequest(this, invocation);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected RemoteAccessException convertHttpInvokerAccessException(Throwable ex)
/*     */   {
/* 204 */     if ((ex instanceof ConnectException))
/*     */     {
/* 206 */       return new RemoteConnectFailureException("Could not connect to HTTP invoker remote service at [" + getServiceUrl() + "]", ex);
/*     */     }
/*     */     
/* 209 */     if (((ex instanceof ClassNotFoundException)) || ((ex instanceof NoClassDefFoundError)) || ((ex instanceof InvalidClassException)))
/*     */     {
/*     */ 
/* 212 */       return new RemoteAccessException("Could not deserialize result from HTTP invoker remote service [" + getServiceUrl() + "]", ex);
/*     */     }
/*     */     
/*     */ 
/* 216 */     return new RemoteAccessException("Could not access HTTP invoker remote service at [" + getServiceUrl() + "]", ex);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\remoting\httpinvoker\HttpInvokerClientInterceptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */