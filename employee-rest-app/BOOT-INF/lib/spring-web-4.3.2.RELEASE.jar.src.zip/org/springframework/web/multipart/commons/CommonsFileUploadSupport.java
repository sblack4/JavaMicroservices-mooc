/*     */ package org.springframework.web.multipart.commons;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.fileupload.FileItem;
/*     */ import org.apache.commons.fileupload.FileItemFactory;
/*     */ import org.apache.commons.fileupload.FileUpload;
/*     */ import org.apache.commons.fileupload.disk.DiskFileItemFactory;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.multipart.MultipartFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CommonsFileUploadSupport
/*     */ {
/*  63 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private final DiskFileItemFactory fileItemFactory;
/*     */   
/*     */   private final FileUpload fileUpload;
/*     */   
/*  69 */   private boolean uploadTempDirSpecified = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CommonsFileUploadSupport()
/*     */   {
/*  79 */     this.fileItemFactory = newFileItemFactory();
/*  80 */     this.fileUpload = newFileUpload(getFileItemFactory());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DiskFileItemFactory getFileItemFactory()
/*     */   {
/*  90 */     return this.fileItemFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FileUpload getFileUpload()
/*     */   {
/*  99 */     return this.fileUpload;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaxUploadSize(long maxUploadSize)
/*     */   {
/* 109 */     this.fileUpload.setSizeMax(maxUploadSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaxUploadSizePerFile(long maxUploadSizePerFile)
/*     */   {
/* 120 */     this.fileUpload.setFileSizeMax(maxUploadSizePerFile);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaxInMemorySize(int maxInMemorySize)
/*     */   {
/* 131 */     this.fileItemFactory.setSizeThreshold(maxInMemorySize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultEncoding(String defaultEncoding)
/*     */   {
/* 149 */     this.fileUpload.setHeaderEncoding(defaultEncoding);
/*     */   }
/*     */   
/*     */   protected String getDefaultEncoding() {
/* 153 */     String encoding = getFileUpload().getHeaderEncoding();
/* 154 */     if (encoding == null) {
/* 155 */       encoding = "ISO-8859-1";
/*     */     }
/* 157 */     return encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUploadTempDir(Resource uploadTempDir)
/*     */     throws IOException
/*     */   {
/* 166 */     if ((!uploadTempDir.exists()) && (!uploadTempDir.getFile().mkdirs())) {
/* 167 */       throw new IllegalArgumentException("Given uploadTempDir [" + uploadTempDir + "] could not be created");
/*     */     }
/* 169 */     this.fileItemFactory.setRepository(uploadTempDir.getFile());
/* 170 */     this.uploadTempDirSpecified = true;
/*     */   }
/*     */   
/*     */   protected boolean isUploadTempDirSpecified() {
/* 174 */     return this.uploadTempDirSpecified;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected DiskFileItemFactory newFileItemFactory()
/*     */   {
/* 185 */     return new DiskFileItemFactory();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract FileUpload newFileUpload(FileItemFactory paramFileItemFactory);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected FileUpload prepareFileUpload(String encoding)
/*     */   {
/* 206 */     FileUpload fileUpload = getFileUpload();
/* 207 */     FileUpload actualFileUpload = fileUpload;
/*     */     
/*     */ 
/*     */ 
/* 211 */     if ((encoding != null) && (!encoding.equals(fileUpload.getHeaderEncoding()))) {
/* 212 */       actualFileUpload = newFileUpload(getFileItemFactory());
/* 213 */       actualFileUpload.setSizeMax(fileUpload.getSizeMax());
/* 214 */       actualFileUpload.setFileSizeMax(fileUpload.getFileSizeMax());
/* 215 */       actualFileUpload.setHeaderEncoding(encoding);
/*     */     }
/*     */     
/* 218 */     return actualFileUpload;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MultipartParsingResult parseFileItems(List<FileItem> fileItems, String encoding)
/*     */   {
/* 230 */     MultiValueMap<String, MultipartFile> multipartFiles = new LinkedMultiValueMap();
/* 231 */     Map<String, String[]> multipartParameters = new HashMap();
/* 232 */     Map<String, String> multipartParameterContentTypes = new HashMap();
/*     */     
/*     */ 
/* 235 */     for (FileItem fileItem : fileItems) {
/* 236 */       if (fileItem.isFormField())
/*     */       {
/* 238 */         String partEncoding = determineEncoding(fileItem.getContentType(), encoding);
/* 239 */         String value; if (partEncoding != null) {
/*     */           String value;
/* 241 */           try { value = fileItem.getString(partEncoding);
/*     */           } catch (UnsupportedEncodingException ex) {
/*     */             String value;
/* 244 */             if (this.logger.isWarnEnabled()) {
/* 245 */               this.logger.warn("Could not decode multipart item '" + fileItem.getFieldName() + "' with encoding '" + partEncoding + "': using platform default");
/*     */             }
/*     */             
/* 248 */             value = fileItem.getString();
/*     */           }
/*     */         }
/*     */         else {
/* 252 */           value = fileItem.getString();
/*     */         }
/* 254 */         String[] curParam = (String[])multipartParameters.get(fileItem.getFieldName());
/* 255 */         if (curParam == null)
/*     */         {
/* 257 */           multipartParameters.put(fileItem.getFieldName(), new String[] { value });
/*     */         }
/*     */         else
/*     */         {
/* 261 */           String[] newParam = StringUtils.addStringToArray(curParam, value);
/* 262 */           multipartParameters.put(fileItem.getFieldName(), newParam);
/*     */         }
/* 264 */         multipartParameterContentTypes.put(fileItem.getFieldName(), fileItem.getContentType());
/*     */       }
/*     */       else
/*     */       {
/* 268 */         CommonsMultipartFile file = new CommonsMultipartFile(fileItem);
/* 269 */         multipartFiles.add(file.getName(), file);
/* 270 */         if (this.logger.isDebugEnabled()) {
/* 271 */           this.logger.debug("Found multipart file [" + file.getName() + "] of size " + file.getSize() + " bytes with original filename [" + file
/* 272 */             .getOriginalFilename() + "], stored " + file
/* 273 */             .getStorageDescription());
/*     */         }
/*     */       }
/*     */     }
/* 277 */     return new MultipartParsingResult(multipartFiles, multipartParameters, multipartParameterContentTypes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void cleanupFileItems(MultiValueMap<String, MultipartFile> multipartFiles)
/*     */   {
/* 288 */     for (List<MultipartFile> files : multipartFiles.values()) {
/* 289 */       for (MultipartFile file : files) {
/* 290 */         if ((file instanceof CommonsMultipartFile)) {
/* 291 */           CommonsMultipartFile cmf = (CommonsMultipartFile)file;
/* 292 */           cmf.getFileItem().delete();
/* 293 */           if (this.logger.isDebugEnabled()) {
/* 294 */             this.logger.debug("Cleaning up multipart file [" + cmf.getName() + "] with original filename [" + cmf
/* 295 */               .getOriginalFilename() + "], stored " + cmf.getStorageDescription());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private String determineEncoding(String contentTypeHeader, String defaultEncoding) {
/* 303 */     if (!StringUtils.hasText(contentTypeHeader)) {
/* 304 */       return defaultEncoding;
/*     */     }
/* 306 */     MediaType contentType = MediaType.parseMediaType(contentTypeHeader);
/* 307 */     Charset charset = contentType.getCharset();
/* 308 */     return charset != null ? charset.name() : defaultEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected static class MultipartParsingResult
/*     */   {
/*     */     private final MultiValueMap<String, MultipartFile> multipartFiles;
/*     */     
/*     */ 
/*     */     private final Map<String, String[]> multipartParameters;
/*     */     
/*     */ 
/*     */     private final Map<String, String> multipartParameterContentTypes;
/*     */     
/*     */ 
/*     */     public MultipartParsingResult(MultiValueMap<String, MultipartFile> mpFiles, Map<String, String[]> mpParams, Map<String, String> mpParamContentTypes)
/*     */     {
/* 326 */       this.multipartFiles = mpFiles;
/* 327 */       this.multipartParameters = mpParams;
/* 328 */       this.multipartParameterContentTypes = mpParamContentTypes;
/*     */     }
/*     */     
/*     */     public MultiValueMap<String, MultipartFile> getMultipartFiles() {
/* 332 */       return this.multipartFiles;
/*     */     }
/*     */     
/*     */     public Map<String, String[]> getMultipartParameters() {
/* 336 */       return this.multipartParameters;
/*     */     }
/*     */     
/*     */     public Map<String, String> getMultipartParameterContentTypes() {
/* 340 */       return this.multipartParameterContentTypes;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\multipart\commons\CommonsFileUploadSupport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */