/*     */ package org.springframework.web.multipart.commons;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Serializable;
/*     */ import org.apache.commons.fileupload.FileItem;
/*     */ import org.apache.commons.fileupload.FileUploadException;
/*     */ import org.apache.commons.fileupload.disk.DiskFileItem;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.springframework.web.multipart.MultipartFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommonsMultipartFile
/*     */   implements MultipartFile, Serializable
/*     */ {
/*  44 */   protected static final Log logger = LogFactory.getLog(CommonsMultipartFile.class);
/*     */   
/*     */ 
/*     */   private final FileItem fileItem;
/*     */   
/*     */ 
/*     */   private final long size;
/*     */   
/*     */ 
/*     */ 
/*     */   public CommonsMultipartFile(FileItem fileItem)
/*     */   {
/*  56 */     this.fileItem = fileItem;
/*  57 */     this.size = this.fileItem.getSize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final FileItem getFileItem()
/*     */   {
/*  66 */     return this.fileItem;
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/*  71 */     return this.fileItem.getFieldName();
/*     */   }
/*     */   
/*     */   public String getOriginalFilename()
/*     */   {
/*  76 */     String filename = this.fileItem.getName();
/*  77 */     if (filename == null)
/*     */     {
/*  79 */       return "";
/*     */     }
/*     */     
/*     */ 
/*  83 */     int unixSep = filename.lastIndexOf("/");
/*     */     
/*  85 */     int winSep = filename.lastIndexOf("\\");
/*     */     
/*  87 */     int pos = winSep > unixSep ? winSep : unixSep;
/*  88 */     if (pos != -1)
/*     */     {
/*  90 */       return filename.substring(pos + 1);
/*     */     }
/*     */     
/*     */ 
/*  94 */     return filename;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getContentType()
/*     */   {
/* 100 */     return this.fileItem.getContentType();
/*     */   }
/*     */   
/*     */   public boolean isEmpty()
/*     */   {
/* 105 */     return this.size == 0L;
/*     */   }
/*     */   
/*     */   public long getSize()
/*     */   {
/* 110 */     return this.size;
/*     */   }
/*     */   
/*     */   public byte[] getBytes()
/*     */   {
/* 115 */     if (!isAvailable()) {
/* 116 */       throw new IllegalStateException("File has been moved - cannot be read again");
/*     */     }
/* 118 */     byte[] bytes = this.fileItem.get();
/* 119 */     return bytes != null ? bytes : new byte[0];
/*     */   }
/*     */   
/*     */   public InputStream getInputStream() throws IOException
/*     */   {
/* 124 */     if (!isAvailable()) {
/* 125 */       throw new IllegalStateException("File has been moved - cannot be read again");
/*     */     }
/* 127 */     InputStream inputStream = this.fileItem.getInputStream();
/* 128 */     return inputStream != null ? inputStream : StreamUtils.emptyInput();
/*     */   }
/*     */   
/*     */   public void transferTo(File dest) throws IOException, IllegalStateException
/*     */   {
/* 133 */     if (!isAvailable()) {
/* 134 */       throw new IllegalStateException("File has already been moved - cannot be transferred again");
/*     */     }
/*     */     
/* 137 */     if ((dest.exists()) && (!dest.delete()))
/*     */     {
/* 139 */       throw new IOException("Destination file [" + dest.getAbsolutePath() + "] already exists and could not be deleted");
/*     */     }
/*     */     try
/*     */     {
/* 143 */       this.fileItem.write(dest);
/* 144 */       if (logger.isDebugEnabled()) {
/* 145 */         String action = "transferred";
/* 146 */         if (!this.fileItem.isInMemory()) {
/* 147 */           action = isAvailable() ? "copied" : "moved";
/*     */         }
/* 149 */         logger.debug("Multipart file '" + getName() + "' with original filename [" + 
/* 150 */           getOriginalFilename() + "], stored " + getStorageDescription() + ": " + action + " to [" + dest
/* 151 */           .getAbsolutePath() + "]");
/*     */       }
/*     */     }
/*     */     catch (FileUploadException ex) {
/* 155 */       throw new IllegalStateException(ex.getMessage());
/*     */     }
/*     */     catch (IOException ex) {
/* 158 */       throw ex;
/*     */     }
/*     */     catch (Exception ex) {
/* 161 */       logger.error("Could not transfer to file", ex);
/* 162 */       throw new IOException("Could not transfer to file: " + ex.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isAvailable()
/*     */   {
/* 172 */     if (this.fileItem.isInMemory()) {
/* 173 */       return true;
/*     */     }
/*     */     
/* 176 */     if ((this.fileItem instanceof DiskFileItem)) {
/* 177 */       return ((DiskFileItem)this.fileItem).getStoreLocation().exists();
/*     */     }
/*     */     
/* 180 */     return this.fileItem.getSize() == this.size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getStorageDescription()
/*     */   {
/* 189 */     if (this.fileItem.isInMemory()) {
/* 190 */       return "in memory";
/*     */     }
/* 192 */     if ((this.fileItem instanceof DiskFileItem)) {
/* 193 */       return "at [" + ((DiskFileItem)this.fileItem).getStoreLocation().getAbsolutePath() + "]";
/*     */     }
/*     */     
/* 196 */     return "on disk";
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\multipart\commons\CommonsMultipartFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */