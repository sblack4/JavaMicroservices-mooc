/*     */ package org.springframework.web.multipart.commons;
/*     */ 
/*     */ import java.util.List;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.fileupload.FileItem;
/*     */ import org.apache.commons.fileupload.FileItemFactory;
/*     */ import org.apache.commons.fileupload.FileUpload;
/*     */ import org.apache.commons.fileupload.FileUploadBase.SizeLimitExceededException;
/*     */ import org.apache.commons.fileupload.FileUploadException;
/*     */ import org.apache.commons.fileupload.disk.DiskFileItemFactory;
/*     */ import org.apache.commons.fileupload.servlet.ServletFileUpload;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ import org.springframework.web.multipart.MaxUploadSizeExceededException;
/*     */ import org.springframework.web.multipart.MultipartException;
/*     */ import org.springframework.web.multipart.MultipartHttpServletRequest;
/*     */ import org.springframework.web.multipart.MultipartResolver;
/*     */ import org.springframework.web.multipart.support.DefaultMultipartHttpServletRequest;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommonsMultipartResolver
/*     */   extends CommonsFileUploadSupport
/*     */   implements MultipartResolver, ServletContextAware
/*     */ {
/*  65 */   private boolean resolveLazily = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CommonsMultipartResolver() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CommonsMultipartResolver(ServletContext servletContext)
/*     */   {
/*  86 */     this();
/*  87 */     setServletContext(servletContext);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResolveLazily(boolean resolveLazily)
/*     */   {
/* 100 */     this.resolveLazily = resolveLazily;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected FileUpload newFileUpload(FileItemFactory fileItemFactory)
/*     */   {
/* 111 */     return new ServletFileUpload(fileItemFactory);
/*     */   }
/*     */   
/*     */   public void setServletContext(ServletContext servletContext)
/*     */   {
/* 116 */     if (!isUploadTempDirSpecified()) {
/* 117 */       getFileItemFactory().setRepository(WebUtils.getTempDir(servletContext));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isMultipart(HttpServletRequest request)
/*     */   {
/* 124 */     return (request != null) && (ServletFileUpload.isMultipartContent(request));
/*     */   }
/*     */   
/*     */   public MultipartHttpServletRequest resolveMultipart(final HttpServletRequest request) throws MultipartException
/*     */   {
/* 129 */     Assert.notNull(request, "Request must not be null");
/* 130 */     if (this.resolveLazily) {
/* 131 */       new DefaultMultipartHttpServletRequest(request)
/*     */       {
/*     */         protected void initializeMultipart() {
/* 134 */           CommonsFileUploadSupport.MultipartParsingResult parsingResult = CommonsMultipartResolver.this.parseRequest(request);
/* 135 */           setMultipartFiles(parsingResult.getMultipartFiles());
/* 136 */           setMultipartParameters(parsingResult.getMultipartParameters());
/* 137 */           setMultipartParameterContentTypes(parsingResult.getMultipartParameterContentTypes());
/*     */         }
/*     */       };
/*     */     }
/*     */     
/* 142 */     CommonsFileUploadSupport.MultipartParsingResult parsingResult = parseRequest(request);
/*     */     
/* 144 */     return new DefaultMultipartHttpServletRequest(request, parsingResult.getMultipartFiles(), parsingResult.getMultipartParameters(), parsingResult.getMultipartParameterContentTypes());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected CommonsFileUploadSupport.MultipartParsingResult parseRequest(HttpServletRequest request)
/*     */     throws MultipartException
/*     */   {
/* 155 */     String encoding = determineEncoding(request);
/* 156 */     FileUpload fileUpload = prepareFileUpload(encoding);
/*     */     try {
/* 158 */       List<FileItem> fileItems = ((ServletFileUpload)fileUpload).parseRequest(request);
/* 159 */       return parseFileItems(fileItems, encoding);
/*     */     }
/*     */     catch (FileUploadBase.SizeLimitExceededException ex) {
/* 162 */       throw new MaxUploadSizeExceededException(fileUpload.getSizeMax(), ex);
/*     */     }
/*     */     catch (FileUploadException ex) {
/* 165 */       throw new MultipartException("Could not parse multipart servlet request", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String determineEncoding(HttpServletRequest request)
/*     */   {
/* 180 */     String encoding = request.getCharacterEncoding();
/* 181 */     if (encoding == null) {
/* 182 */       encoding = getDefaultEncoding();
/*     */     }
/* 184 */     return encoding;
/*     */   }
/*     */   
/*     */   public void cleanupMultipart(MultipartHttpServletRequest request)
/*     */   {
/* 189 */     if (request != null) {
/*     */       try {
/* 191 */         cleanupFileItems(request.getMultiFileMap());
/*     */       }
/*     */       catch (Throwable ex) {
/* 194 */         this.logger.warn("Failed to perform multipart cleanup for servlet request", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\multipart\commons\CommonsMultipartResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */