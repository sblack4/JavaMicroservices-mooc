/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URLDecoder;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UrlPathHelper
/*     */ {
/*     */   private static final String WEBSPHERE_URI_ATTRIBUTE = "com.ibm.websphere.servlet.uri_non_decoded";
/*  57 */   private static final Log logger = LogFactory.getLog(UrlPathHelper.class);
/*     */   
/*     */ 
/*     */   static volatile Boolean websphereComplianceFlag;
/*     */   
/*  62 */   private boolean alwaysUseFullPath = false;
/*     */   
/*  64 */   private boolean urlDecode = true;
/*     */   
/*  66 */   private boolean removeSemicolonContent = true;
/*     */   
/*  68 */   private String defaultEncoding = "ISO-8859-1";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAlwaysUseFullPath(boolean alwaysUseFullPath)
/*     */   {
/*  78 */     this.alwaysUseFullPath = alwaysUseFullPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUrlDecode(boolean urlDecode)
/*     */   {
/*  96 */     this.urlDecode = urlDecode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemoveSemicolonContent(boolean removeSemicolonContent)
/*     */   {
/* 104 */     this.removeSemicolonContent = removeSemicolonContent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean shouldRemoveSemicolonContent()
/*     */   {
/* 111 */     return this.removeSemicolonContent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultEncoding(String defaultEncoding)
/*     */   {
/* 128 */     this.defaultEncoding = defaultEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String getDefaultEncoding()
/*     */   {
/* 135 */     return this.defaultEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLookupPathForRequest(HttpServletRequest request)
/*     */   {
/* 150 */     if (this.alwaysUseFullPath) {
/* 151 */       return getPathWithinApplication(request);
/*     */     }
/*     */     
/* 154 */     String rest = getPathWithinServletMapping(request);
/* 155 */     if (!"".equals(rest)) {
/* 156 */       return rest;
/*     */     }
/*     */     
/* 159 */     return getPathWithinApplication(request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPathWithinServletMapping(HttpServletRequest request)
/*     */   {
/* 177 */     String pathWithinApp = getPathWithinApplication(request);
/* 178 */     String servletPath = getServletPath(request);
/* 179 */     String sanitizedPathWithinApp = getSanitizedPath(pathWithinApp);
/*     */     
/*     */     String path;
/*     */     String path;
/* 183 */     if (servletPath.contains(sanitizedPathWithinApp)) {
/* 184 */       path = getRemainingPath(sanitizedPathWithinApp, servletPath, false);
/*     */     }
/*     */     else {
/* 187 */       path = getRemainingPath(pathWithinApp, servletPath, false);
/*     */     }
/*     */     
/* 190 */     if (path != null)
/*     */     {
/* 192 */       return path;
/*     */     }
/*     */     
/*     */ 
/* 196 */     String pathInfo = request.getPathInfo();
/* 197 */     if (pathInfo != null)
/*     */     {
/*     */ 
/* 200 */       return pathInfo;
/*     */     }
/* 202 */     if (!this.urlDecode)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 207 */       path = getRemainingPath(decodeInternal(request, pathWithinApp), servletPath, false);
/* 208 */       if (path != null) {
/* 209 */         return pathWithinApp;
/*     */       }
/*     */     }
/*     */     
/* 213 */     return servletPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPathWithinApplication(HttpServletRequest request)
/*     */   {
/* 224 */     String contextPath = getContextPath(request);
/* 225 */     String requestUri = getRequestUri(request);
/* 226 */     String path = getRemainingPath(requestUri, contextPath, true);
/* 227 */     if (path != null)
/*     */     {
/* 229 */       return StringUtils.hasText(path) ? path : "/";
/*     */     }
/*     */     
/* 232 */     return requestUri;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getRemainingPath(String requestUri, String mapping, boolean ignoreCase)
/*     */   {
/* 243 */     int index1 = 0;
/* 244 */     for (int index2 = 0; 
/* 245 */         (index1 < requestUri.length()) && (index2 < mapping.length()); index2++) {
/* 246 */       char c1 = requestUri.charAt(index1);
/* 247 */       char c2 = mapping.charAt(index2);
/* 248 */       if (c1 == ';') {
/* 249 */         index1 = requestUri.indexOf('/', index1);
/* 250 */         if (index1 == -1) {
/* 251 */           return null;
/*     */         }
/* 253 */         c1 = requestUri.charAt(index1);
/*     */       }
/* 255 */       if (c1 != c2)
/*     */       {
/*     */ 
/* 258 */         if ((!ignoreCase) || (Character.toLowerCase(c1) != Character.toLowerCase(c2)))
/*     */         {
/*     */ 
/* 261 */           return null;
/*     */         }
/*     */       }
/* 245 */       index1++;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 263 */     if (index2 != mapping.length()) {
/* 264 */       return null;
/*     */     }
/* 266 */     if (index1 == requestUri.length()) {
/* 267 */       return "";
/*     */     }
/* 269 */     if (requestUri.charAt(index1) == ';') {
/* 270 */       index1 = requestUri.indexOf('/', index1);
/*     */     }
/* 272 */     return index1 != -1 ? requestUri.substring(index1) : "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getSanitizedPath(String path)
/*     */   {
/* 282 */     String sanitized = path;
/*     */     for (;;) {
/* 284 */       int index = sanitized.indexOf("//");
/* 285 */       if (index < 0) {
/*     */         break;
/*     */       }
/*     */       
/* 289 */       sanitized = sanitized.substring(0, index) + sanitized.substring(index + 1);
/*     */     }
/*     */     
/* 292 */     return sanitized;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRequestUri(HttpServletRequest request)
/*     */   {
/* 307 */     String uri = (String)request.getAttribute("javax.servlet.include.request_uri");
/* 308 */     if (uri == null) {
/* 309 */       uri = request.getRequestURI();
/*     */     }
/* 311 */     return decodeAndCleanUriString(request, uri);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContextPath(HttpServletRequest request)
/*     */   {
/* 323 */     String contextPath = (String)request.getAttribute("javax.servlet.include.context_path");
/* 324 */     if (contextPath == null) {
/* 325 */       contextPath = request.getContextPath();
/*     */     }
/* 327 */     if ("/".equals(contextPath))
/*     */     {
/* 329 */       contextPath = "";
/*     */     }
/* 331 */     return decodeRequestString(request, contextPath);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getServletPath(HttpServletRequest request)
/*     */   {
/* 343 */     String servletPath = (String)request.getAttribute("javax.servlet.include.servlet_path");
/* 344 */     if (servletPath == null) {
/* 345 */       servletPath = request.getServletPath();
/*     */     }
/* 347 */     if ((servletPath.length() > 1) && (servletPath.endsWith("/")) && (shouldRemoveTrailingServletPathSlash(request)))
/*     */     {
/*     */ 
/*     */ 
/* 351 */       servletPath = servletPath.substring(0, servletPath.length() - 1);
/*     */     }
/* 353 */     return servletPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getOriginatingRequestUri(HttpServletRequest request)
/*     */   {
/* 362 */     String uri = (String)request.getAttribute("com.ibm.websphere.servlet.uri_non_decoded");
/* 363 */     if (uri == null) {
/* 364 */       uri = (String)request.getAttribute("javax.servlet.forward.request_uri");
/* 365 */       if (uri == null) {
/* 366 */         uri = request.getRequestURI();
/*     */       }
/*     */     }
/* 369 */     return decodeAndCleanUriString(request, uri);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getOriginatingContextPath(HttpServletRequest request)
/*     */   {
/* 381 */     String contextPath = (String)request.getAttribute("javax.servlet.forward.context_path");
/* 382 */     if (contextPath == null) {
/* 383 */       contextPath = request.getContextPath();
/*     */     }
/* 385 */     return decodeRequestString(request, contextPath);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getOriginatingServletPath(HttpServletRequest request)
/*     */   {
/* 395 */     String servletPath = (String)request.getAttribute("javax.servlet.forward.servlet_path");
/* 396 */     if (servletPath == null) {
/* 397 */       servletPath = request.getServletPath();
/*     */     }
/* 399 */     return servletPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getOriginatingQueryString(HttpServletRequest request)
/*     */   {
/* 409 */     if ((request.getAttribute("javax.servlet.forward.request_uri") != null) || 
/* 410 */       (request.getAttribute("javax.servlet.error.request_uri") != null)) {
/* 411 */       return (String)request.getAttribute("javax.servlet.forward.query_string");
/*     */     }
/*     */     
/* 414 */     return request.getQueryString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String decodeAndCleanUriString(HttpServletRequest request, String uri)
/*     */   {
/* 422 */     uri = removeSemicolonContent(uri);
/* 423 */     uri = decodeRequestString(request, uri);
/* 424 */     uri = getSanitizedPath(uri);
/* 425 */     return uri;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String decodeRequestString(HttpServletRequest request, String source)
/*     */   {
/* 441 */     if ((this.urlDecode) && (source != null)) {
/* 442 */       return decodeInternal(request, source);
/*     */     }
/* 444 */     return source;
/*     */   }
/*     */   
/*     */   private String decodeInternal(HttpServletRequest request, String source)
/*     */   {
/* 449 */     String enc = determineEncoding(request);
/*     */     try {
/* 451 */       return UriUtils.decode(source, enc);
/*     */     }
/*     */     catch (UnsupportedEncodingException ex) {
/* 454 */       if (logger.isWarnEnabled())
/* 455 */         logger.warn("Could not decode request string [" + source + "] with encoding '" + enc + "': falling back to platform default encoding; exception message: " + ex
/* 456 */           .getMessage());
/*     */     }
/* 458 */     return URLDecoder.decode(source);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String determineEncoding(HttpServletRequest request)
/*     */   {
/* 473 */     String enc = request.getCharacterEncoding();
/* 474 */     if (enc == null) {
/* 475 */       enc = getDefaultEncoding();
/*     */     }
/* 477 */     return enc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String removeSemicolonContent(String requestUri)
/*     */   {
/* 489 */     return this.removeSemicolonContent ? removeSemicolonContentInternal(requestUri) : removeJsessionid(requestUri);
/*     */   }
/*     */   
/*     */   private String removeSemicolonContentInternal(String requestUri) {
/* 493 */     int semicolonIndex = requestUri.indexOf(';');
/* 494 */     while (semicolonIndex != -1) {
/* 495 */       int slashIndex = requestUri.indexOf('/', semicolonIndex);
/* 496 */       String start = requestUri.substring(0, semicolonIndex);
/* 497 */       requestUri = slashIndex != -1 ? start + requestUri.substring(slashIndex) : start;
/* 498 */       semicolonIndex = requestUri.indexOf(';', semicolonIndex);
/*     */     }
/* 500 */     return requestUri;
/*     */   }
/*     */   
/*     */   private String removeJsessionid(String requestUri) {
/* 504 */     int startIndex = requestUri.toLowerCase().indexOf(";jsessionid=");
/* 505 */     if (startIndex != -1) {
/* 506 */       int endIndex = requestUri.indexOf(';', startIndex + 12);
/* 507 */       String start = requestUri.substring(0, startIndex);
/* 508 */       requestUri = endIndex != -1 ? start + requestUri.substring(endIndex) : start;
/*     */     }
/* 510 */     return requestUri;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, String> decodePathVariables(HttpServletRequest request, Map<String, String> vars)
/*     */   {
/* 525 */     if (this.urlDecode) {
/* 526 */       return vars;
/*     */     }
/*     */     
/* 529 */     Map<String, String> decodedVars = new LinkedHashMap(vars.size());
/* 530 */     for (Map.Entry<String, String> entry : vars.entrySet()) {
/* 531 */       decodedVars.put(entry.getKey(), decodeInternal(request, (String)entry.getValue()));
/*     */     }
/* 533 */     return decodedVars;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MultiValueMap<String, String> decodeMatrixVariables(HttpServletRequest request, MultiValueMap<String, String> vars)
/*     */   {
/* 549 */     if (this.urlDecode) {
/* 550 */       return vars;
/*     */     }
/*     */     
/* 553 */     MultiValueMap<String, String> decodedVars = new LinkedMultiValueMap(vars.size());
/* 554 */     for (Iterator localIterator1 = vars.keySet().iterator(); localIterator1.hasNext();) { key = (String)localIterator1.next();
/* 555 */       for (String value : (List)vars.get(key))
/* 556 */         decodedVars.add(key, decodeInternal(request, value));
/*     */     }
/*     */     String key;
/* 559 */     return decodedVars;
/*     */   }
/*     */   
/*     */   private boolean shouldRemoveTrailingServletPathSlash(HttpServletRequest request)
/*     */   {
/* 564 */     if (request.getAttribute("com.ibm.websphere.servlet.uri_non_decoded") == null)
/*     */     {
/*     */ 
/*     */ 
/* 568 */       return false;
/*     */     }
/* 570 */     if (websphereComplianceFlag == null) {
/* 571 */       ClassLoader classLoader = UrlPathHelper.class.getClassLoader();
/* 572 */       String className = "com.ibm.ws.webcontainer.WebContainer";
/* 573 */       String methodName = "getWebContainerProperties";
/* 574 */       String propName = "com.ibm.ws.webcontainer.removetrailingservletpathslash";
/* 575 */       boolean flag = false;
/*     */       try {
/* 577 */         Class<?> cl = classLoader.loadClass(className);
/* 578 */         Properties prop = (Properties)cl.getMethod(methodName, new Class[0]).invoke(null, new Object[0]);
/* 579 */         flag = Boolean.parseBoolean(prop.getProperty(propName));
/*     */       }
/*     */       catch (Throwable ex) {
/* 582 */         if (logger.isDebugEnabled()) {
/* 583 */           logger.debug("Could not introspect WebSphere web container properties: " + ex);
/*     */         }
/*     */       }
/* 586 */       websphereComplianceFlag = Boolean.valueOf(flag);
/*     */     }
/*     */     
/*     */ 
/* 590 */     return !websphereComplianceFlag.booleanValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\util\UrlPathHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */