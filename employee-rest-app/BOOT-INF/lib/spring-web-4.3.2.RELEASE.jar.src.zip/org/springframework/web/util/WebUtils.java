/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.TreeMap;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletRequestWrapper;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.ServletResponseWrapper;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpRequest;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class WebUtils
/*     */ {
/*     */   public static final String INCLUDE_REQUEST_URI_ATTRIBUTE = "javax.servlet.include.request_uri";
/*     */   public static final String INCLUDE_CONTEXT_PATH_ATTRIBUTE = "javax.servlet.include.context_path";
/*     */   public static final String INCLUDE_SERVLET_PATH_ATTRIBUTE = "javax.servlet.include.servlet_path";
/*     */   public static final String INCLUDE_PATH_INFO_ATTRIBUTE = "javax.servlet.include.path_info";
/*     */   public static final String INCLUDE_QUERY_STRING_ATTRIBUTE = "javax.servlet.include.query_string";
/*     */   public static final String FORWARD_REQUEST_URI_ATTRIBUTE = "javax.servlet.forward.request_uri";
/*     */   public static final String FORWARD_CONTEXT_PATH_ATTRIBUTE = "javax.servlet.forward.context_path";
/*     */   public static final String FORWARD_SERVLET_PATH_ATTRIBUTE = "javax.servlet.forward.servlet_path";
/*     */   public static final String FORWARD_PATH_INFO_ATTRIBUTE = "javax.servlet.forward.path_info";
/*     */   public static final String FORWARD_QUERY_STRING_ATTRIBUTE = "javax.servlet.forward.query_string";
/*     */   public static final String ERROR_STATUS_CODE_ATTRIBUTE = "javax.servlet.error.status_code";
/*     */   public static final String ERROR_EXCEPTION_TYPE_ATTRIBUTE = "javax.servlet.error.exception_type";
/*     */   public static final String ERROR_MESSAGE_ATTRIBUTE = "javax.servlet.error.message";
/*     */   public static final String ERROR_EXCEPTION_ATTRIBUTE = "javax.servlet.error.exception";
/*     */   public static final String ERROR_REQUEST_URI_ATTRIBUTE = "javax.servlet.error.request_uri";
/*     */   public static final String ERROR_SERVLET_NAME_ATTRIBUTE = "javax.servlet.error.servlet_name";
/*     */   public static final String CONTENT_TYPE_CHARSET_PREFIX = ";charset=";
/*     */   public static final String DEFAULT_CHARACTER_ENCODING = "ISO-8859-1";
/*     */   public static final String TEMP_DIR_CONTEXT_ATTRIBUTE = "javax.servlet.context.tempdir";
/*     */   public static final String HTML_ESCAPE_CONTEXT_PARAM = "defaultHtmlEscape";
/*     */   public static final String RESPONSE_ENCODED_HTML_ESCAPE_CONTEXT_PARAM = "responseEncodedHtmlEscape";
/*     */   public static final String WEB_APP_ROOT_KEY_PARAM = "webAppRootKey";
/*     */   public static final String DEFAULT_WEB_APP_ROOT_KEY = "webapp.root";
/* 131 */   public static final String[] SUBMIT_IMAGE_SUFFIXES = { ".x", ".y" };
/*     */   
/*     */ 
/* 134 */   public static final String SESSION_MUTEX_ATTRIBUTE = WebUtils.class.getName() + ".MUTEX";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setWebAppRootSystemProperty(ServletContext servletContext)
/*     */     throws IllegalStateException
/*     */   {
/* 152 */     Assert.notNull(servletContext, "ServletContext must not be null");
/* 153 */     String root = servletContext.getRealPath("/");
/* 154 */     if (root == null) {
/* 155 */       throw new IllegalStateException("Cannot set web app root system property when WAR file is not expanded");
/*     */     }
/*     */     
/* 158 */     String param = servletContext.getInitParameter("webAppRootKey");
/* 159 */     String key = param != null ? param : "webapp.root";
/* 160 */     String oldValue = System.getProperty(key);
/* 161 */     if ((oldValue != null) && (!StringUtils.pathEquals(oldValue, root))) {
/* 162 */       throw new IllegalStateException("Web app root system property already set to different value: '" + key + "' = [" + oldValue + "] instead of [" + root + "] - " + "Choose unique values for the 'webAppRootKey' context-param in your web.xml files!");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 167 */     System.setProperty(key, root);
/* 168 */     servletContext.log("Set web app root system property: '" + key + "' = [" + root + "]");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void removeWebAppRootSystemProperty(ServletContext servletContext)
/*     */   {
/* 178 */     Assert.notNull(servletContext, "ServletContext must not be null");
/* 179 */     String param = servletContext.getInitParameter("webAppRootKey");
/* 180 */     String key = param != null ? param : "webapp.root";
/* 181 */     System.getProperties().remove(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static boolean isDefaultHtmlEscape(ServletContext servletContext)
/*     */   {
/* 194 */     if (servletContext == null) {
/* 195 */       return false;
/*     */     }
/* 197 */     String param = servletContext.getInitParameter("defaultHtmlEscape");
/* 198 */     return Boolean.valueOf(param).booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Boolean getDefaultHtmlEscape(ServletContext servletContext)
/*     */   {
/* 213 */     if (servletContext == null) {
/* 214 */       return null;
/*     */     }
/* 216 */     String param = servletContext.getInitParameter("defaultHtmlEscape");
/* 217 */     return StringUtils.hasText(param) ? Boolean.valueOf(param) : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Boolean getResponseEncodedHtmlEscape(ServletContext servletContext)
/*     */   {
/* 235 */     if (servletContext == null) {
/* 236 */       return null;
/*     */     }
/* 238 */     String param = servletContext.getInitParameter("responseEncodedHtmlEscape");
/* 239 */     return StringUtils.hasText(param) ? Boolean.valueOf(param) : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static File getTempDir(ServletContext servletContext)
/*     */   {
/* 249 */     Assert.notNull(servletContext, "ServletContext must not be null");
/* 250 */     return (File)servletContext.getAttribute("javax.servlet.context.tempdir");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getRealPath(ServletContext servletContext, String path)
/*     */     throws FileNotFoundException
/*     */   {
/* 267 */     Assert.notNull(servletContext, "ServletContext must not be null");
/*     */     
/* 269 */     if (!path.startsWith("/")) {
/* 270 */       path = "/" + path;
/*     */     }
/* 272 */     String realPath = servletContext.getRealPath(path);
/* 273 */     if (realPath == null) {
/* 274 */       throw new FileNotFoundException("ServletContext resource [" + path + "] cannot be resolved to absolute file path - " + "web application archive not expanded?");
/*     */     }
/*     */     
/*     */ 
/* 278 */     return realPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getSessionId(HttpServletRequest request)
/*     */   {
/* 287 */     Assert.notNull(request, "Request must not be null");
/* 288 */     HttpSession session = request.getSession(false);
/* 289 */     return session != null ? session.getId() : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getSessionAttribute(HttpServletRequest request, String name)
/*     */   {
/* 301 */     Assert.notNull(request, "Request must not be null");
/* 302 */     HttpSession session = request.getSession(false);
/* 303 */     return session != null ? session.getAttribute(name) : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getRequiredSessionAttribute(HttpServletRequest request, String name)
/*     */     throws IllegalStateException
/*     */   {
/* 318 */     Object attr = getSessionAttribute(request, name);
/* 319 */     if (attr == null) {
/* 320 */       throw new IllegalStateException("No session attribute '" + name + "' found");
/*     */     }
/* 322 */     return attr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setSessionAttribute(HttpServletRequest request, String name, Object value)
/*     */   {
/* 334 */     Assert.notNull(request, "Request must not be null");
/* 335 */     if (value != null) {
/* 336 */       request.getSession().setAttribute(name, value);
/*     */     }
/*     */     else {
/* 339 */       HttpSession session = request.getSession(false);
/* 340 */       if (session != null) {
/* 341 */         session.removeAttribute(name);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static Object getOrCreateSessionAttribute(HttpSession session, String name, Class<?> clazz)
/*     */     throws IllegalArgumentException
/*     */   {
/* 361 */     Assert.notNull(session, "Session must not be null");
/* 362 */     Object sessionObject = session.getAttribute(name);
/* 363 */     if (sessionObject == null) {
/*     */       try {
/* 365 */         sessionObject = clazz.newInstance();
/*     */ 
/*     */       }
/*     */       catch (InstantiationException ex)
/*     */       {
/* 370 */         throw new IllegalArgumentException("Could not instantiate class [" + clazz.getName() + "] for session attribute '" + name + "': " + ex.getMessage());
/*     */ 
/*     */       }
/*     */       catch (IllegalAccessException ex)
/*     */       {
/* 375 */         throw new IllegalArgumentException("Could not access default constructor of class [" + clazz.getName() + "] for session attribute '" + name + "': " + ex.getMessage());
/*     */       }
/* 377 */       session.setAttribute(name, sessionObject);
/*     */     }
/* 379 */     return sessionObject;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getSessionMutex(HttpSession session)
/*     */   {
/* 403 */     Assert.notNull(session, "Session must not be null");
/* 404 */     Object mutex = session.getAttribute(SESSION_MUTEX_ATTRIBUTE);
/* 405 */     if (mutex == null) {
/* 406 */       mutex = session;
/*     */     }
/* 408 */     return mutex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T> T getNativeRequest(ServletRequest request, Class<T> requiredType)
/*     */   {
/* 422 */     if (requiredType != null) {
/* 423 */       if (requiredType.isInstance(request)) {
/* 424 */         return request;
/*     */       }
/* 426 */       if ((request instanceof ServletRequestWrapper)) {
/* 427 */         return (T)getNativeRequest(((ServletRequestWrapper)request).getRequest(), requiredType);
/*     */       }
/*     */     }
/* 430 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T> T getNativeResponse(ServletResponse response, Class<T> requiredType)
/*     */   {
/* 443 */     if (requiredType != null) {
/* 444 */       if (requiredType.isInstance(response)) {
/* 445 */         return response;
/*     */       }
/* 447 */       if ((response instanceof ServletResponseWrapper)) {
/* 448 */         return (T)getNativeResponse(((ServletResponseWrapper)response).getResponse(), requiredType);
/*     */       }
/*     */     }
/* 451 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isIncludeRequest(ServletRequest request)
/*     */   {
/* 464 */     return request.getAttribute("javax.servlet.include.request_uri") != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void exposeErrorRequestAttributes(HttpServletRequest request, Throwable ex, String servletName)
/*     */   {
/* 486 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.status_code", Integer.valueOf(200));
/* 487 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.exception_type", ex.getClass());
/* 488 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.message", ex.getMessage());
/* 489 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.exception", ex);
/* 490 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.request_uri", request.getRequestURI());
/* 491 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.servlet_name", servletName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void exposeRequestAttributeIfNotPresent(ServletRequest request, String name, Object value)
/*     */   {
/* 501 */     if (request.getAttribute(name) == null) {
/* 502 */       request.setAttribute(name, value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void clearErrorRequestAttributes(HttpServletRequest request)
/*     */   {
/* 518 */     request.removeAttribute("javax.servlet.error.status_code");
/* 519 */     request.removeAttribute("javax.servlet.error.exception_type");
/* 520 */     request.removeAttribute("javax.servlet.error.message");
/* 521 */     request.removeAttribute("javax.servlet.error.exception");
/* 522 */     request.removeAttribute("javax.servlet.error.request_uri");
/* 523 */     request.removeAttribute("javax.servlet.error.servlet_name");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static void exposeRequestAttributes(ServletRequest request, Map<String, ?> attributes)
/*     */   {
/* 535 */     Assert.notNull(request, "Request must not be null");
/* 536 */     Assert.notNull(attributes, "Attributes Map must not be null");
/* 537 */     for (Map.Entry<String, ?> entry : attributes.entrySet()) {
/* 538 */       request.setAttribute((String)entry.getKey(), entry.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Cookie getCookie(HttpServletRequest request, String name)
/*     */   {
/* 550 */     Assert.notNull(request, "Request must not be null");
/* 551 */     Cookie[] cookies = request.getCookies();
/* 552 */     if (cookies != null) {
/* 553 */       for (Cookie cookie : cookies) {
/* 554 */         if (name.equals(cookie.getName())) {
/* 555 */           return cookie;
/*     */         }
/*     */       }
/*     */     }
/* 559 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean hasSubmitParameter(ServletRequest request, String name)
/*     */   {
/* 572 */     Assert.notNull(request, "Request must not be null");
/* 573 */     if (request.getParameter(name) != null) {
/* 574 */       return true;
/*     */     }
/* 576 */     for (String suffix : SUBMIT_IMAGE_SUFFIXES) {
/* 577 */       if (request.getParameter(name + suffix) != null) {
/* 578 */         return true;
/*     */       }
/*     */     }
/* 581 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String findParameterValue(ServletRequest request, String name)
/*     */   {
/* 594 */     return findParameterValue(request.getParameterMap(), name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String findParameterValue(Map<String, ?> parameters, String name)
/*     */   {
/* 622 */     Object value = parameters.get(name);
/* 623 */     if ((value instanceof String[])) {
/* 624 */       String[] values = (String[])value;
/* 625 */       return values.length > 0 ? values[0] : null;
/*     */     }
/* 627 */     if (value != null) {
/* 628 */       return value.toString();
/*     */     }
/*     */     
/* 631 */     String prefix = name + "_";
/* 632 */     for (String paramName : parameters.keySet()) {
/* 633 */       if (paramName.startsWith(prefix))
/*     */       {
/* 635 */         for (String suffix : SUBMIT_IMAGE_SUFFIXES) {
/* 636 */           if (paramName.endsWith(suffix)) {
/* 637 */             return paramName.substring(prefix.length(), paramName.length() - suffix.length());
/*     */           }
/*     */         }
/* 640 */         return paramName.substring(prefix.length());
/*     */       }
/*     */     }
/*     */     
/* 644 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map<String, Object> getParametersStartingWith(ServletRequest request, String prefix)
/*     */   {
/* 662 */     Assert.notNull(request, "Request must not be null");
/* 663 */     Enumeration<String> paramNames = request.getParameterNames();
/* 664 */     Map<String, Object> params = new TreeMap();
/* 665 */     if (prefix == null) {
/* 666 */       prefix = "";
/*     */     }
/* 668 */     while ((paramNames != null) && (paramNames.hasMoreElements())) {
/* 669 */       String paramName = (String)paramNames.nextElement();
/* 670 */       if (("".equals(prefix)) || (paramName.startsWith(prefix))) {
/* 671 */         String unprefixed = paramName.substring(prefix.length());
/* 672 */         String[] values = request.getParameterValues(paramName);
/* 673 */         if ((values != null) && (values.length != 0))
/*     */         {
/*     */ 
/* 676 */           if (values.length > 1) {
/* 677 */             params.put(unprefixed, values);
/*     */           }
/*     */           else
/* 680 */             params.put(unprefixed, values[0]);
/*     */         }
/*     */       }
/*     */     }
/* 684 */     return params;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static int getTargetPage(ServletRequest request, String paramPrefix, int currentPage)
/*     */   {
/* 699 */     Enumeration<String> paramNames = request.getParameterNames();
/* 700 */     while (paramNames.hasMoreElements()) {
/* 701 */       String paramName = (String)paramNames.nextElement();
/* 702 */       if (paramName.startsWith(paramPrefix)) {
/* 703 */         for (int i = 0; i < SUBMIT_IMAGE_SUFFIXES.length; i++) {
/* 704 */           String suffix = SUBMIT_IMAGE_SUFFIXES[i];
/* 705 */           if (paramName.endsWith(suffix)) {
/* 706 */             paramName = paramName.substring(0, paramName.length() - suffix.length());
/*     */           }
/*     */         }
/* 709 */         return Integer.parseInt(paramName.substring(paramPrefix.length()));
/*     */       }
/*     */     }
/* 712 */     return currentPage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static String extractFilenameFromUrlPath(String urlPath)
/*     */   {
/* 725 */     String filename = extractFullFilenameFromUrlPath(urlPath);
/* 726 */     int dotIndex = filename.lastIndexOf('.');
/* 727 */     if (dotIndex != -1) {
/* 728 */       filename = filename.substring(0, dotIndex);
/*     */     }
/* 730 */     return filename;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static String extractFullFilenameFromUrlPath(String urlPath)
/*     */   {
/* 744 */     int end = urlPath.indexOf('?');
/* 745 */     if (end == -1) {
/* 746 */       end = urlPath.indexOf('#');
/* 747 */       if (end == -1) {
/* 748 */         end = urlPath.length();
/*     */       }
/*     */     }
/* 751 */     int begin = urlPath.lastIndexOf('/', end) + 1;
/* 752 */     int paramIndex = urlPath.indexOf(';', begin);
/* 753 */     end = (paramIndex != -1) && (paramIndex < end) ? paramIndex : end;
/* 754 */     return urlPath.substring(begin, end);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MultiValueMap<String, String> parseMatrixVariables(String matrixVariables)
/*     */   {
/* 767 */     MultiValueMap<String, String> result = new LinkedMultiValueMap();
/* 768 */     if (!StringUtils.hasText(matrixVariables)) {
/* 769 */       return result;
/*     */     }
/* 771 */     StringTokenizer pairs = new StringTokenizer(matrixVariables, ";");
/* 772 */     while (pairs.hasMoreTokens()) {
/* 773 */       String pair = pairs.nextToken();
/* 774 */       int index = pair.indexOf('=');
/* 775 */       if (index != -1) {
/* 776 */         String name = pair.substring(0, index);
/* 777 */         String rawValue = pair.substring(index + 1);
/* 778 */         for (String value : StringUtils.commaDelimitedListToStringArray(rawValue)) {
/* 779 */           result.add(name, value);
/*     */         }
/*     */       }
/*     */       else {
/* 783 */         result.add(pair, "");
/*     */       }
/*     */     }
/* 786 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isValidOrigin(HttpRequest request, Collection<String> allowedOrigins)
/*     */   {
/* 798 */     Assert.notNull(request, "Request must not be null");
/* 799 */     Assert.notNull(allowedOrigins, "Allowed origins must not be null");
/*     */     
/* 801 */     String origin = request.getHeaders().getOrigin();
/* 802 */     if ((origin == null) || (allowedOrigins.contains("*"))) {
/* 803 */       return true;
/*     */     }
/* 805 */     if (CollectionUtils.isEmpty(allowedOrigins)) {
/* 806 */       return isSameOrigin(request);
/*     */     }
/*     */     
/* 809 */     return allowedOrigins.contains(origin);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isSameOrigin(HttpRequest request)
/*     */   {
/* 821 */     String origin = request.getHeaders().getOrigin();
/* 822 */     if (origin == null)
/* 823 */       return true;
/*     */     UriComponentsBuilder urlBuilder;
/*     */     UriComponentsBuilder urlBuilder;
/* 826 */     if ((request instanceof ServletServerHttpRequest))
/*     */     {
/* 828 */       HttpServletRequest servletRequest = ((ServletServerHttpRequest)request).getServletRequest();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 833 */       urlBuilder = new UriComponentsBuilder().scheme(servletRequest.getScheme()).host(servletRequest.getServerName()).port(servletRequest.getServerPort()).adaptFromForwardedHeaders(request.getHeaders());
/*     */     }
/*     */     else {
/* 836 */       urlBuilder = UriComponentsBuilder.fromHttpRequest(request);
/*     */     }
/* 838 */     UriComponents actualUrl = urlBuilder.build();
/* 839 */     UriComponents originUrl = UriComponentsBuilder.fromOriginHeader(origin).build();
/* 840 */     return (actualUrl.getHost().equals(originUrl.getHost())) && (getPort(actualUrl) == getPort(originUrl));
/*     */   }
/*     */   
/*     */   private static int getPort(UriComponents uri) {
/* 844 */     int port = uri.getPort();
/* 845 */     if (port == -1) {
/* 846 */       if (("http".equals(uri.getScheme())) || ("ws".equals(uri.getScheme()))) {
/* 847 */         port = 80;
/*     */       }
/* 849 */       else if (("https".equals(uri.getScheme())) || ("wss".equals(uri.getScheme()))) {
/* 850 */         port = 443;
/*     */       }
/*     */     }
/* 853 */     return port;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\util\WebUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */