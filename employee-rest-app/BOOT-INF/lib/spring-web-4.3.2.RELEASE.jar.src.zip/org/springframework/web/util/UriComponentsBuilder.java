/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpRequest;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UriComponentsBuilder
/*     */   implements Cloneable
/*     */ {
/*  61 */   private static final Pattern QUERY_PARAM_PATTERN = Pattern.compile("([^&=]+)(=?)([^&]+)?");
/*     */   
/*     */ 
/*     */   private static final String SCHEME_PATTERN = "([^:/?#]+):";
/*     */   
/*     */   private static final String HTTP_PATTERN = "(?i)(http|https):";
/*     */   
/*     */   private static final String USERINFO_PATTERN = "([^@\\[/?#]*)";
/*     */   
/*     */   private static final String HOST_IPV4_PATTERN = "[^\\[/?#:]*";
/*     */   
/*     */   private static final String HOST_IPV6_PATTERN = "\\[[\\p{XDigit}\\:\\.]*[%\\p{Alnum}]*\\]";
/*     */   
/*     */   private static final String HOST_PATTERN = "(\\[[\\p{XDigit}\\:\\.]*[%\\p{Alnum}]*\\]|[^\\[/?#:]*)";
/*     */   
/*     */   private static final String PORT_PATTERN = "(\\d*(?:\\{[^/]+?\\})?)";
/*     */   
/*     */   private static final String PATH_PATTERN = "([^?#]*)";
/*     */   
/*     */   private static final String QUERY_PATTERN = "([^#]*)";
/*     */   
/*     */   private static final String LAST_PATTERN = "(.*)";
/*     */   
/*  84 */   private static final Pattern URI_PATTERN = Pattern.compile("^(([^:/?#]+):)?(//(([^@\\[/?#]*)@)?(\\[[\\p{XDigit}\\:\\.]*[%\\p{Alnum}]*\\]|[^\\[/?#:]*)(:(\\d*(?:\\{[^/]+?\\})?))?)?([^?#]*)(\\?([^#]*))?(#(.*))?");
/*     */   
/*     */ 
/*     */ 
/*  88 */   private static final Pattern HTTP_URL_PATTERN = Pattern.compile("^(?i)(http|https):(//(([^@\\[/?#]*)@)?(\\[[\\p{XDigit}\\:\\.]*[%\\p{Alnum}]*\\]|[^\\[/?#:]*)(:(\\d*(?:\\{[^/]+?\\})?))?)?([^?#]*)(\\?(.*))?");
/*     */   
/*     */ 
/*     */ 
/*  92 */   private static final Pattern FORWARDED_HOST_PATTERN = Pattern.compile("host=\"?([^;,\"]+)\"?");
/*     */   
/*  94 */   private static final Pattern FORWARDED_PROTO_PATTERN = Pattern.compile("proto=\"?([^;,\"]+)\"?");
/*     */   
/*     */ 
/*     */   private String scheme;
/*     */   
/*     */   private String ssp;
/*     */   
/*     */   private String userInfo;
/*     */   
/*     */   private String host;
/*     */   
/*     */   private String port;
/*     */   
/*     */   private CompositePathComponentBuilder pathBuilder;
/*     */   
/* 109 */   private final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String fragment;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected UriComponentsBuilder()
/*     */   {
/* 121 */     this.pathBuilder = new CompositePathComponentBuilder();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected UriComponentsBuilder(UriComponentsBuilder other)
/*     */   {
/* 129 */     this.scheme = other.scheme;
/* 130 */     this.ssp = other.ssp;
/* 131 */     this.userInfo = other.userInfo;
/* 132 */     this.host = other.host;
/* 133 */     this.port = other.port;
/* 134 */     this.pathBuilder = other.pathBuilder.cloneBuilder();
/* 135 */     this.queryParams.putAll(other.queryParams);
/* 136 */     this.fragment = other.fragment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UriComponentsBuilder newInstance()
/*     */   {
/* 147 */     return new UriComponentsBuilder();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UriComponentsBuilder fromPath(String path)
/*     */   {
/* 156 */     UriComponentsBuilder builder = new UriComponentsBuilder();
/* 157 */     builder.path(path);
/* 158 */     return builder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UriComponentsBuilder fromUri(URI uri)
/*     */   {
/* 167 */     UriComponentsBuilder builder = new UriComponentsBuilder();
/* 168 */     builder.uri(uri);
/* 169 */     return builder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UriComponentsBuilder fromUriString(String uri)
/*     */   {
/* 187 */     Assert.notNull(uri, "URI must not be null");
/* 188 */     Matcher matcher = URI_PATTERN.matcher(uri);
/* 189 */     if (matcher.matches()) {
/* 190 */       UriComponentsBuilder builder = new UriComponentsBuilder();
/* 191 */       String scheme = matcher.group(2);
/* 192 */       String userInfo = matcher.group(5);
/* 193 */       String host = matcher.group(6);
/* 194 */       String port = matcher.group(8);
/* 195 */       String path = matcher.group(9);
/* 196 */       String query = matcher.group(11);
/* 197 */       String fragment = matcher.group(13);
/* 198 */       boolean opaque = false;
/* 199 */       if (StringUtils.hasLength(scheme)) {
/* 200 */         String rest = uri.substring(scheme.length());
/* 201 */         if (!rest.startsWith(":/")) {
/* 202 */           opaque = true;
/*     */         }
/*     */       }
/* 205 */       builder.scheme(scheme);
/* 206 */       if (opaque) {
/* 207 */         String ssp = uri.substring(scheme.length()).substring(1);
/* 208 */         if (StringUtils.hasLength(fragment)) {
/* 209 */           ssp = ssp.substring(0, ssp.length() - (fragment.length() + 1));
/*     */         }
/* 211 */         builder.schemeSpecificPart(ssp);
/*     */       }
/*     */       else {
/* 214 */         builder.userInfo(userInfo);
/* 215 */         builder.host(host);
/* 216 */         if (StringUtils.hasLength(port)) {
/* 217 */           builder.port(port);
/*     */         }
/* 219 */         builder.path(path);
/* 220 */         builder.query(query);
/*     */       }
/* 222 */       if (StringUtils.hasText(fragment)) {
/* 223 */         builder.fragment(fragment);
/*     */       }
/* 225 */       return builder;
/*     */     }
/*     */     
/* 228 */     throw new IllegalArgumentException("[" + uri + "] is not a valid URI");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UriComponentsBuilder fromHttpUrl(String httpUrl)
/*     */   {
/* 247 */     Assert.notNull(httpUrl, "HTTP URL must not be null");
/* 248 */     Matcher matcher = HTTP_URL_PATTERN.matcher(httpUrl);
/* 249 */     if (matcher.matches()) {
/* 250 */       UriComponentsBuilder builder = new UriComponentsBuilder();
/* 251 */       String scheme = matcher.group(1);
/* 252 */       builder.scheme(scheme != null ? scheme.toLowerCase() : null);
/* 253 */       builder.userInfo(matcher.group(4));
/* 254 */       String host = matcher.group(5);
/* 255 */       if ((StringUtils.hasLength(scheme)) && (!StringUtils.hasLength(host))) {
/* 256 */         throw new IllegalArgumentException("[" + httpUrl + "] is not a valid HTTP URL");
/*     */       }
/* 258 */       builder.host(host);
/* 259 */       String port = matcher.group(7);
/* 260 */       if (StringUtils.hasLength(port)) {
/* 261 */         builder.port(port);
/*     */       }
/* 263 */       builder.path(matcher.group(8));
/* 264 */       builder.query(matcher.group(10));
/* 265 */       return builder;
/*     */     }
/*     */     
/* 268 */     throw new IllegalArgumentException("[" + httpUrl + "] is not a valid HTTP URL");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UriComponentsBuilder fromHttpRequest(HttpRequest request)
/*     */   {
/* 283 */     return fromUri(request.getURI()).adaptFromForwardedHeaders(request.getHeaders());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UriComponentsBuilder fromOriginHeader(String origin)
/*     */   {
/* 291 */     Matcher matcher = URI_PATTERN.matcher(origin);
/* 292 */     if (matcher.matches()) {
/* 293 */       UriComponentsBuilder builder = new UriComponentsBuilder();
/* 294 */       String scheme = matcher.group(2);
/* 295 */       String host = matcher.group(6);
/* 296 */       String port = matcher.group(8);
/* 297 */       if (StringUtils.hasLength(scheme)) {
/* 298 */         builder.scheme(scheme);
/*     */       }
/* 300 */       builder.host(host);
/* 301 */       if (StringUtils.hasLength(port)) {
/* 302 */         builder.port(port);
/*     */       }
/* 304 */       return builder;
/*     */     }
/*     */     
/* 307 */     throw new IllegalArgumentException("[" + origin + "] is not a valid \"Origin\" header value");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponents build()
/*     */   {
/* 319 */     return build(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponents build(boolean encoded)
/*     */   {
/* 330 */     if (this.ssp != null) {
/* 331 */       return new OpaqueUriComponents(this.scheme, this.ssp, this.fragment);
/*     */     }
/*     */     
/*     */ 
/* 335 */     return new HierarchicalUriComponents(this.scheme, this.userInfo, this.host, this.port, this.pathBuilder.build(), this.queryParams, this.fragment, encoded, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponents buildAndExpand(Map<String, ?> uriVariables)
/*     */   {
/* 347 */     return build(false).expand(uriVariables);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponents buildAndExpand(Object... uriVariableValues)
/*     */   {
/* 358 */     return build(false).expand(uriVariableValues);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toUriString()
/*     */   {
/* 369 */     return build(false).encode().toUriString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder uri(URI uri)
/*     */   {
/* 381 */     Assert.notNull(uri, "URI must not be null");
/* 382 */     this.scheme = uri.getScheme();
/* 383 */     if (uri.isOpaque()) {
/* 384 */       this.ssp = uri.getRawSchemeSpecificPart();
/* 385 */       resetHierarchicalComponents();
/*     */     }
/*     */     else {
/* 388 */       if (uri.getRawUserInfo() != null) {
/* 389 */         this.userInfo = uri.getRawUserInfo();
/*     */       }
/* 391 */       if (uri.getHost() != null) {
/* 392 */         this.host = uri.getHost();
/*     */       }
/* 394 */       if (uri.getPort() != -1) {
/* 395 */         this.port = String.valueOf(uri.getPort());
/*     */       }
/* 397 */       if (StringUtils.hasLength(uri.getRawPath())) {
/* 398 */         this.pathBuilder = new CompositePathComponentBuilder(uri.getRawPath());
/*     */       }
/* 400 */       if (StringUtils.hasLength(uri.getRawQuery())) {
/* 401 */         this.queryParams.clear();
/* 402 */         query(uri.getRawQuery());
/*     */       }
/* 404 */       resetSchemeSpecificPart();
/*     */     }
/* 406 */     if (uri.getRawFragment() != null) {
/* 407 */       this.fragment = uri.getRawFragment();
/*     */     }
/* 409 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder scheme(String scheme)
/*     */   {
/* 419 */     this.scheme = scheme;
/* 420 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder uriComponents(UriComponents uriComponents)
/*     */   {
/* 429 */     Assert.notNull(uriComponents, "UriComponents must not be null");
/* 430 */     uriComponents.copyToUriComponentsBuilder(this);
/* 431 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder schemeSpecificPart(String ssp)
/*     */   {
/* 443 */     this.ssp = ssp;
/* 444 */     resetHierarchicalComponents();
/* 445 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder userInfo(String userInfo)
/*     */   {
/* 455 */     this.userInfo = userInfo;
/* 456 */     resetSchemeSpecificPart();
/* 457 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder host(String host)
/*     */   {
/* 467 */     this.host = host;
/* 468 */     resetSchemeSpecificPart();
/* 469 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder port(int port)
/*     */   {
/* 478 */     Assert.isTrue(port >= -1, "Port must be >= -1");
/* 479 */     this.port = String.valueOf(port);
/* 480 */     resetSchemeSpecificPart();
/* 481 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder port(String port)
/*     */   {
/* 492 */     this.port = port;
/* 493 */     resetSchemeSpecificPart();
/* 494 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder path(String path)
/*     */   {
/* 504 */     this.pathBuilder.addPath(path);
/* 505 */     resetSchemeSpecificPart();
/* 506 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder replacePath(String path)
/*     */   {
/* 515 */     this.pathBuilder = new CompositePathComponentBuilder(path);
/* 516 */     resetSchemeSpecificPart();
/* 517 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder pathSegment(String... pathSegments)
/*     */     throws IllegalArgumentException
/*     */   {
/* 528 */     this.pathBuilder.addPathSegments(pathSegments);
/* 529 */     resetSchemeSpecificPart();
/* 530 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder query(String query)
/*     */   {
/* 550 */     if (query != null) {
/* 551 */       Matcher matcher = QUERY_PARAM_PATTERN.matcher(query);
/* 552 */       while (matcher.find()) {
/* 553 */         String name = matcher.group(1);
/* 554 */         String eq = matcher.group(2);
/* 555 */         String value = matcher.group(3);
/* 556 */         queryParam(name, new Object[] { StringUtils.hasLength(eq) ? "" : value != null ? value : null });
/*     */       }
/*     */     }
/*     */     else {
/* 560 */       this.queryParams.clear();
/*     */     }
/* 562 */     resetSchemeSpecificPart();
/* 563 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder replaceQuery(String query)
/*     */   {
/* 572 */     this.queryParams.clear();
/* 573 */     query(query);
/* 574 */     resetSchemeSpecificPart();
/* 575 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder queryParam(String name, Object... values)
/*     */   {
/* 588 */     Assert.notNull(name, "Name must not be null");
/* 589 */     if (!ObjectUtils.isEmpty(values)) {
/* 590 */       for (Object value : values) {
/* 591 */         String valueAsString = value != null ? value.toString() : null;
/* 592 */         this.queryParams.add(name, valueAsString);
/*     */       }
/*     */       
/*     */     } else {
/* 596 */       this.queryParams.add(name, null);
/*     */     }
/* 598 */     resetSchemeSpecificPart();
/* 599 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder queryParams(MultiValueMap<String, String> params)
/*     */   {
/* 608 */     if (params != null) {
/* 609 */       this.queryParams.putAll(params);
/*     */     }
/* 611 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder replaceQueryParam(String name, Object... values)
/*     */   {
/* 622 */     Assert.notNull(name, "Name must not be null");
/* 623 */     this.queryParams.remove(name);
/* 624 */     if (!ObjectUtils.isEmpty(values)) {
/* 625 */       queryParam(name, values);
/*     */     }
/* 627 */     resetSchemeSpecificPart();
/* 628 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder replaceQueryParams(MultiValueMap<String, String> params)
/*     */   {
/* 637 */     this.queryParams.clear();
/* 638 */     if (params != null) {
/* 639 */       this.queryParams.putAll(params);
/*     */     }
/* 641 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder fragment(String fragment)
/*     */   {
/* 651 */     if (fragment != null) {
/* 652 */       Assert.hasLength(fragment, "Fragment must not be empty");
/* 653 */       this.fragment = fragment;
/*     */     }
/*     */     else {
/* 656 */       this.fragment = null;
/*     */     }
/* 658 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   UriComponentsBuilder adaptFromForwardedHeaders(HttpHeaders headers)
/*     */   {
/* 671 */     String forwardedHeader = headers.getFirst("Forwarded");
/* 672 */     if (StringUtils.hasText(forwardedHeader)) {
/* 673 */       String forwardedToUse = StringUtils.commaDelimitedListToStringArray(forwardedHeader)[0];
/* 674 */       Matcher matcher = FORWARDED_HOST_PATTERN.matcher(forwardedToUse);
/* 675 */       if (matcher.find()) {
/* 676 */         host(matcher.group(1).trim());
/*     */       }
/* 678 */       matcher = FORWARDED_PROTO_PATTERN.matcher(forwardedToUse);
/* 679 */       if (matcher.find()) {
/* 680 */         scheme(matcher.group(1).trim());
/*     */       }
/*     */     }
/*     */     else {
/* 684 */       String hostHeader = headers.getFirst("X-Forwarded-Host");
/* 685 */       if (StringUtils.hasText(hostHeader)) {
/* 686 */         String[] hosts = StringUtils.commaDelimitedListToStringArray(hostHeader);
/* 687 */         String hostToUse = hosts[0];
/* 688 */         if (hostToUse.contains(":")) {
/* 689 */           String[] hostAndPort = StringUtils.split(hostToUse, ":");
/* 690 */           host(hostAndPort[0]);
/* 691 */           port(Integer.parseInt(hostAndPort[1]));
/*     */         }
/*     */         else {
/* 694 */           host(hostToUse);
/* 695 */           port(null);
/*     */         }
/*     */       }
/*     */       
/* 699 */       String portHeader = headers.getFirst("X-Forwarded-Port");
/* 700 */       if (StringUtils.hasText(portHeader)) {
/* 701 */         String[] ports = StringUtils.commaDelimitedListToStringArray(portHeader);
/* 702 */         port(Integer.parseInt(ports[0]));
/*     */       }
/*     */       
/* 705 */       String protocolHeader = headers.getFirst("X-Forwarded-Proto");
/* 706 */       if (StringUtils.hasText(protocolHeader)) {
/* 707 */         String[] protocols = StringUtils.commaDelimitedListToStringArray(protocolHeader);
/* 708 */         scheme(protocols[0]);
/*     */       }
/*     */     }
/*     */     
/* 712 */     if (((this.scheme.equals("http")) && ("80".equals(this.port))) || (
/* 713 */       (this.scheme.equals("https")) && ("443".equals(this.port)))) {
/* 714 */       this.port = null;
/*     */     }
/*     */     
/* 717 */     return this;
/*     */   }
/*     */   
/*     */   private void resetHierarchicalComponents() {
/* 721 */     this.userInfo = null;
/* 722 */     this.host = null;
/* 723 */     this.port = null;
/* 724 */     this.pathBuilder = new CompositePathComponentBuilder();
/* 725 */     this.queryParams.clear();
/*     */   }
/*     */   
/*     */   private void resetSchemeSpecificPart() {
/* 729 */     this.ssp = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 740 */     return cloneBuilder();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponentsBuilder cloneBuilder()
/*     */   {
/* 749 */     return new UriComponentsBuilder(this);
/*     */   }
/*     */   
/*     */ 
/*     */   private static abstract interface PathComponentBuilder
/*     */   {
/*     */     public abstract HierarchicalUriComponents.PathComponent build();
/*     */     
/*     */     public abstract PathComponentBuilder cloneBuilder();
/*     */   }
/*     */   
/*     */   private static class CompositePathComponentBuilder
/*     */     implements UriComponentsBuilder.PathComponentBuilder
/*     */   {
/* 763 */     private final LinkedList<UriComponentsBuilder.PathComponentBuilder> builders = new LinkedList();
/*     */     
/*     */     public CompositePathComponentBuilder() {}
/*     */     
/*     */     public CompositePathComponentBuilder(String path)
/*     */     {
/* 769 */       addPath(path);
/*     */     }
/*     */     
/*     */     public void addPathSegments(String... pathSegments) {
/* 773 */       if (!ObjectUtils.isEmpty(pathSegments)) {
/* 774 */         UriComponentsBuilder.PathSegmentComponentBuilder psBuilder = (UriComponentsBuilder.PathSegmentComponentBuilder)getLastBuilder(UriComponentsBuilder.PathSegmentComponentBuilder.class);
/* 775 */         UriComponentsBuilder.FullPathComponentBuilder fpBuilder = (UriComponentsBuilder.FullPathComponentBuilder)getLastBuilder(UriComponentsBuilder.FullPathComponentBuilder.class);
/* 776 */         if (psBuilder == null) {
/* 777 */           psBuilder = new UriComponentsBuilder.PathSegmentComponentBuilder(null);
/* 778 */           this.builders.add(psBuilder);
/* 779 */           if (fpBuilder != null) {
/* 780 */             fpBuilder.removeTrailingSlash();
/*     */           }
/*     */         }
/* 783 */         psBuilder.append(pathSegments);
/*     */       }
/*     */     }
/*     */     
/*     */     public void addPath(String path) {
/* 788 */       if (StringUtils.hasText(path)) {
/* 789 */         UriComponentsBuilder.PathSegmentComponentBuilder psBuilder = (UriComponentsBuilder.PathSegmentComponentBuilder)getLastBuilder(UriComponentsBuilder.PathSegmentComponentBuilder.class);
/* 790 */         UriComponentsBuilder.FullPathComponentBuilder fpBuilder = (UriComponentsBuilder.FullPathComponentBuilder)getLastBuilder(UriComponentsBuilder.FullPathComponentBuilder.class);
/* 791 */         if (psBuilder != null) {
/* 792 */           path = "/" + path;
/*     */         }
/* 794 */         if (fpBuilder == null) {
/* 795 */           fpBuilder = new UriComponentsBuilder.FullPathComponentBuilder(null);
/* 796 */           this.builders.add(fpBuilder);
/*     */         }
/* 798 */         fpBuilder.append(path);
/*     */       }
/*     */     }
/*     */     
/*     */     private <T> T getLastBuilder(Class<T> builderClass)
/*     */     {
/* 804 */       if (!this.builders.isEmpty()) {
/* 805 */         UriComponentsBuilder.PathComponentBuilder last = (UriComponentsBuilder.PathComponentBuilder)this.builders.getLast();
/* 806 */         if (builderClass.isInstance(last)) {
/* 807 */           return last;
/*     */         }
/*     */       }
/* 810 */       return null;
/*     */     }
/*     */     
/*     */     public HierarchicalUriComponents.PathComponent build()
/*     */     {
/* 815 */       int size = this.builders.size();
/* 816 */       List<HierarchicalUriComponents.PathComponent> components = new ArrayList(size);
/* 817 */       for (UriComponentsBuilder.PathComponentBuilder componentBuilder : this.builders) {
/* 818 */         HierarchicalUriComponents.PathComponent pathComponent = componentBuilder.build();
/* 819 */         if (pathComponent != null) {
/* 820 */           components.add(pathComponent);
/*     */         }
/*     */       }
/* 823 */       if (components.isEmpty()) {
/* 824 */         return HierarchicalUriComponents.NULL_PATH_COMPONENT;
/*     */       }
/* 826 */       if (components.size() == 1) {
/* 827 */         return (HierarchicalUriComponents.PathComponent)components.get(0);
/*     */       }
/* 829 */       return new HierarchicalUriComponents.PathComponentComposite(components);
/*     */     }
/*     */     
/*     */     public CompositePathComponentBuilder cloneBuilder()
/*     */     {
/* 834 */       CompositePathComponentBuilder compositeBuilder = new CompositePathComponentBuilder();
/* 835 */       for (UriComponentsBuilder.PathComponentBuilder builder : this.builders) {
/* 836 */         compositeBuilder.builders.add(builder.cloneBuilder());
/*     */       }
/* 838 */       return compositeBuilder;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class FullPathComponentBuilder
/*     */     implements UriComponentsBuilder.PathComponentBuilder
/*     */   {
/* 845 */     private final StringBuilder path = new StringBuilder();
/*     */     
/*     */     public void append(String path) {
/* 848 */       this.path.append(path);
/*     */     }
/*     */     
/*     */     public HierarchicalUriComponents.PathComponent build()
/*     */     {
/* 853 */       if (this.path.length() == 0) {
/* 854 */         return null;
/*     */       }
/* 856 */       String path = this.path.toString();
/*     */       for (;;) {
/* 858 */         int index = path.indexOf("//");
/* 859 */         if (index == -1) {
/*     */           break;
/*     */         }
/* 862 */         path = path.substring(0, index) + path.substring(index + 1);
/*     */       }
/* 864 */       return new HierarchicalUriComponents.FullPathComponent(path);
/*     */     }
/*     */     
/*     */     public void removeTrailingSlash() {
/* 868 */       int index = this.path.length() - 1;
/* 869 */       if (this.path.charAt(index) == '/') {
/* 870 */         this.path.deleteCharAt(index);
/*     */       }
/*     */     }
/*     */     
/*     */     public FullPathComponentBuilder cloneBuilder()
/*     */     {
/* 876 */       FullPathComponentBuilder builder = new FullPathComponentBuilder();
/* 877 */       builder.append(this.path.toString());
/* 878 */       return builder;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class PathSegmentComponentBuilder
/*     */     implements UriComponentsBuilder.PathComponentBuilder
/*     */   {
/* 885 */     private final List<String> pathSegments = new LinkedList();
/*     */     
/*     */     public void append(String... pathSegments) {
/* 888 */       for (String pathSegment : pathSegments) {
/* 889 */         if (StringUtils.hasText(pathSegment)) {
/* 890 */           this.pathSegments.add(pathSegment);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     public HierarchicalUriComponents.PathComponent build()
/*     */     {
/* 897 */       return this.pathSegments.isEmpty() ? null : new HierarchicalUriComponents.PathSegmentComponent(this.pathSegments);
/*     */     }
/*     */     
/*     */ 
/*     */     public PathSegmentComponentBuilder cloneBuilder()
/*     */     {
/* 903 */       PathSegmentComponentBuilder builder = new PathSegmentComponentBuilder();
/* 904 */       builder.pathSegments.addAll(this.pathSegments);
/* 905 */       return builder;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\util\UriComponentsBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */