/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CookieGenerator
/*     */ {
/*     */   public static final String DEFAULT_COOKIE_PATH = "/";
/*  50 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private String cookieName;
/*     */   
/*     */   private String cookieDomain;
/*     */   
/*  56 */   private String cookiePath = "/";
/*     */   
/*  58 */   private Integer cookieMaxAge = null;
/*     */   
/*  60 */   private boolean cookieSecure = false;
/*     */   
/*  62 */   private boolean cookieHttpOnly = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCookieName(String cookieName)
/*     */   {
/*  70 */     this.cookieName = cookieName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getCookieName()
/*     */   {
/*  77 */     return this.cookieName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCookieDomain(String cookieDomain)
/*     */   {
/*  86 */     this.cookieDomain = cookieDomain;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getCookieDomain()
/*     */   {
/*  93 */     return this.cookieDomain;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCookiePath(String cookiePath)
/*     */   {
/* 102 */     this.cookiePath = cookiePath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getCookiePath()
/*     */   {
/* 109 */     return this.cookiePath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCookieMaxAge(Integer cookieMaxAge)
/*     */   {
/* 118 */     this.cookieMaxAge = cookieMaxAge;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Integer getCookieMaxAge()
/*     */   {
/* 125 */     return this.cookieMaxAge;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCookieSecure(boolean cookieSecure)
/*     */   {
/* 135 */     this.cookieSecure = cookieSecure;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCookieSecure()
/*     */   {
/* 143 */     return this.cookieSecure;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCookieHttpOnly(boolean cookieHttpOnly)
/*     */   {
/* 152 */     this.cookieHttpOnly = cookieHttpOnly;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isCookieHttpOnly()
/*     */   {
/* 159 */     return this.cookieHttpOnly;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addCookie(HttpServletResponse response, String cookieValue)
/*     */   {
/* 175 */     Assert.notNull(response, "HttpServletResponse must not be null");
/* 176 */     Cookie cookie = createCookie(cookieValue);
/* 177 */     Integer maxAge = getCookieMaxAge();
/* 178 */     if (maxAge != null) {
/* 179 */       cookie.setMaxAge(maxAge.intValue());
/*     */     }
/* 181 */     if (isCookieSecure()) {
/* 182 */       cookie.setSecure(true);
/*     */     }
/* 184 */     if (isCookieHttpOnly()) {
/* 185 */       cookie.setHttpOnly(true);
/*     */     }
/* 187 */     response.addCookie(cookie);
/* 188 */     if (this.logger.isDebugEnabled()) {
/* 189 */       this.logger.debug("Added cookie with name [" + getCookieName() + "] and value [" + cookieValue + "]");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeCookie(HttpServletResponse response)
/*     */   {
/* 203 */     Assert.notNull(response, "HttpServletResponse must not be null");
/* 204 */     Cookie cookie = createCookie("");
/* 205 */     cookie.setMaxAge(0);
/* 206 */     if (isCookieSecure()) {
/* 207 */       cookie.setSecure(true);
/*     */     }
/* 209 */     if (isCookieHttpOnly()) {
/* 210 */       cookie.setHttpOnly(true);
/*     */     }
/* 212 */     response.addCookie(cookie);
/* 213 */     if (this.logger.isDebugEnabled()) {
/* 214 */       this.logger.debug("Removed cookie with name [" + getCookieName() + "]");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Cookie createCookie(String cookieValue)
/*     */   {
/* 228 */     Cookie cookie = new Cookie(getCookieName(), cookieValue);
/* 229 */     if (getCookieDomain() != null) {
/* 230 */       cookie.setDomain(getCookieDomain());
/*     */     }
/* 232 */     cookie.setPath(getCookiePath());
/* 233 */     return cookie;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\util\CookieGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */