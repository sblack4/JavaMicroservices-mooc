/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.Arrays;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletInputStream;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletRequestWrapper;
/*     */ import org.springframework.http.HttpMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContentCachingRequestWrapper
/*     */   extends HttpServletRequestWrapper
/*     */ {
/*     */   private static final String FORM_CONTENT_TYPE = "application/x-www-form-urlencoded";
/*     */   private final ByteArrayOutputStream cachedContent;
/*     */   private ServletInputStream inputStream;
/*     */   private BufferedReader reader;
/*     */   
/*     */   public ContentCachingRequestWrapper(HttpServletRequest request)
/*     */   {
/*  64 */     super(request);
/*  65 */     int contentLength = request.getContentLength();
/*  66 */     this.cachedContent = new ByteArrayOutputStream(contentLength >= 0 ? contentLength : 1024);
/*     */   }
/*     */   
/*     */   public ServletInputStream getInputStream()
/*     */     throws IOException
/*     */   {
/*  72 */     if (this.inputStream == null) {
/*  73 */       this.inputStream = new ContentCachingInputStream(getRequest().getInputStream());
/*     */     }
/*  75 */     return this.inputStream;
/*     */   }
/*     */   
/*     */   public String getCharacterEncoding()
/*     */   {
/*  80 */     String enc = super.getCharacterEncoding();
/*  81 */     return enc != null ? enc : "ISO-8859-1";
/*     */   }
/*     */   
/*     */   public BufferedReader getReader() throws IOException
/*     */   {
/*  86 */     if (this.reader == null) {
/*  87 */       this.reader = new BufferedReader(new InputStreamReader(getInputStream(), getCharacterEncoding()));
/*     */     }
/*  89 */     return this.reader;
/*     */   }
/*     */   
/*     */   public String getParameter(String name)
/*     */   {
/*  94 */     if ((this.cachedContent.size() == 0) && (isFormPost())) {
/*  95 */       writeRequestParametersToCachedContent();
/*     */     }
/*  97 */     return super.getParameter(name);
/*     */   }
/*     */   
/*     */   public Map<String, String[]> getParameterMap()
/*     */   {
/* 102 */     if ((this.cachedContent.size() == 0) && (isFormPost())) {
/* 103 */       writeRequestParametersToCachedContent();
/*     */     }
/* 105 */     return super.getParameterMap();
/*     */   }
/*     */   
/*     */   public Enumeration<String> getParameterNames()
/*     */   {
/* 110 */     if ((this.cachedContent.size() == 0) && (isFormPost())) {
/* 111 */       writeRequestParametersToCachedContent();
/*     */     }
/* 113 */     return super.getParameterNames();
/*     */   }
/*     */   
/*     */   public String[] getParameterValues(String name)
/*     */   {
/* 118 */     if ((this.cachedContent.size() == 0) && (isFormPost())) {
/* 119 */       writeRequestParametersToCachedContent();
/*     */     }
/* 121 */     return super.getParameterValues(name);
/*     */   }
/*     */   
/*     */   private boolean isFormPost()
/*     */   {
/* 126 */     String contentType = getContentType();
/*     */     
/* 128 */     return (contentType != null) && (contentType.contains("application/x-www-form-urlencoded")) && (HttpMethod.POST.matches(getMethod()));
/*     */   }
/*     */   
/*     */   private void writeRequestParametersToCachedContent() {
/*     */     try {
/* 133 */       if (this.cachedContent.size() == 0) {
/* 134 */         requestEncoding = getCharacterEncoding();
/* 135 */         form = super.getParameterMap();
/* 136 */         for (nameIterator = form.keySet().iterator(); nameIterator.hasNext();) {
/* 137 */           String name = (String)nameIterator.next();
/* 138 */           List<String> values = Arrays.asList((Object[])form.get(name));
/* 139 */           for (Iterator<String> valueIterator = values.iterator(); valueIterator.hasNext();) {
/* 140 */             String value = (String)valueIterator.next();
/* 141 */             this.cachedContent.write(URLEncoder.encode(name, requestEncoding).getBytes());
/* 142 */             if (value != null) {
/* 143 */               this.cachedContent.write(61);
/* 144 */               this.cachedContent.write(URLEncoder.encode(value, requestEncoding).getBytes());
/* 145 */               if (valueIterator.hasNext()) {
/* 146 */                 this.cachedContent.write(38);
/*     */               }
/*     */             }
/*     */           }
/* 150 */           if (nameIterator.hasNext())
/* 151 */             this.cachedContent.write(38);
/*     */         }
/*     */       }
/*     */     } catch (IOException ex) { String requestEncoding;
/*     */       Map<String, String[]> form;
/*     */       Iterator<String> nameIterator;
/* 157 */       throw new IllegalStateException("Failed to write request parameters to cached content", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte[] getContentAsByteArray()
/*     */   {
/* 165 */     return this.cachedContent.toByteArray();
/*     */   }
/*     */   
/*     */   private class ContentCachingInputStream extends ServletInputStream
/*     */   {
/*     */     private final ServletInputStream is;
/*     */     
/*     */     public ContentCachingInputStream(ServletInputStream is)
/*     */     {
/* 174 */       this.is = is;
/*     */     }
/*     */     
/*     */     public int read() throws IOException
/*     */     {
/* 179 */       int ch = this.is.read();
/* 180 */       if (ch != -1) {
/* 181 */         ContentCachingRequestWrapper.this.cachedContent.write(ch);
/*     */       }
/* 183 */       return ch;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\util\ContentCachingRequestWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */