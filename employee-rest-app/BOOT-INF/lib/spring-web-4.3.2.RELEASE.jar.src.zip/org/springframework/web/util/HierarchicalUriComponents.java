/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class HierarchicalUriComponents
/*     */   extends UriComponents
/*     */ {
/*     */   private static final char PATH_DELIMITER = '/';
/*     */   private final String userInfo;
/*     */   private final String host;
/*     */   private final String port;
/*     */   private final PathComponent path;
/*     */   private final MultiValueMap<String, String> queryParams;
/*     */   private final boolean encoded;
/*     */   
/*     */   HierarchicalUriComponents(String scheme, String userInfo, String host, String port, PathComponent path, MultiValueMap<String, String> queryParams, String fragment, boolean encoded, boolean verify)
/*     */   {
/*  81 */     super(scheme, fragment);
/*  82 */     this.userInfo = userInfo;
/*  83 */     this.host = host;
/*  84 */     this.port = port;
/*  85 */     this.path = (path != null ? path : NULL_PATH_COMPONENT);
/*  86 */     this.queryParams = CollectionUtils.unmodifiableMultiValueMap(queryParams != null ? queryParams : new LinkedMultiValueMap(0));
/*     */     
/*  88 */     this.encoded = encoded;
/*  89 */     if (verify) {
/*  90 */       verify();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSchemeSpecificPart()
/*     */   {
/*  99 */     return null;
/*     */   }
/*     */   
/*     */   public String getUserInfo()
/*     */   {
/* 104 */     return this.userInfo;
/*     */   }
/*     */   
/*     */   public String getHost()
/*     */   {
/* 109 */     return this.host;
/*     */   }
/*     */   
/*     */   public int getPort()
/*     */   {
/* 114 */     if (this.port == null) {
/* 115 */       return -1;
/*     */     }
/* 117 */     if (this.port.contains("{")) {
/* 118 */       throw new IllegalStateException("The port contains a URI variable but has not been expanded yet: " + this.port);
/*     */     }
/*     */     
/* 121 */     return Integer.parseInt(this.port);
/*     */   }
/*     */   
/*     */   public String getPath()
/*     */   {
/* 126 */     return this.path.getPath();
/*     */   }
/*     */   
/*     */   public List<String> getPathSegments()
/*     */   {
/* 131 */     return this.path.getPathSegments();
/*     */   }
/*     */   
/*     */   public String getQuery()
/*     */   {
/* 136 */     if (!this.queryParams.isEmpty()) {
/* 137 */       StringBuilder queryBuilder = new StringBuilder();
/* 138 */       for (Map.Entry<String, List<String>> entry : this.queryParams.entrySet()) {
/* 139 */         name = (String)entry.getKey();
/* 140 */         List<String> values = (List)entry.getValue();
/* 141 */         if (CollectionUtils.isEmpty(values)) {
/* 142 */           if (queryBuilder.length() != 0) {
/* 143 */             queryBuilder.append('&');
/*     */           }
/* 145 */           queryBuilder.append(name);
/*     */         }
/*     */         else {
/* 148 */           for (Object value : values) {
/* 149 */             if (queryBuilder.length() != 0) {
/* 150 */               queryBuilder.append('&');
/*     */             }
/* 152 */             queryBuilder.append(name);
/*     */             
/* 154 */             if (value != null) {
/* 155 */               queryBuilder.append('=');
/* 156 */               queryBuilder.append(value.toString());
/*     */             }
/*     */           }
/*     */         } }
/*     */       String name;
/* 161 */       return queryBuilder.toString();
/*     */     }
/*     */     
/* 164 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MultiValueMap<String, String> getQueryParams()
/*     */   {
/* 173 */     return this.queryParams;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HierarchicalUriComponents encode(String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 188 */     if (this.encoded) {
/* 189 */       return this;
/*     */     }
/* 191 */     Assert.hasLength(encoding, "Encoding must not be empty");
/* 192 */     String schemeTo = encodeUriComponent(getScheme(), encoding, Type.SCHEME);
/* 193 */     String userInfoTo = encodeUriComponent(this.userInfo, encoding, Type.USER_INFO);
/* 194 */     String hostTo = encodeUriComponent(this.host, encoding, getHostType());
/* 195 */     PathComponent pathTo = this.path.encode(encoding);
/* 196 */     MultiValueMap<String, String> paramsTo = encodeQueryParams(encoding);
/* 197 */     String fragmentTo = encodeUriComponent(getFragment(), encoding, Type.FRAGMENT);
/* 198 */     return new HierarchicalUriComponents(schemeTo, userInfoTo, hostTo, this.port, pathTo, paramsTo, fragmentTo, true, false);
/*     */   }
/*     */   
/*     */   private MultiValueMap<String, String> encodeQueryParams(String encoding) throws UnsupportedEncodingException
/*     */   {
/* 203 */     int size = this.queryParams.size();
/* 204 */     MultiValueMap<String, String> result = new LinkedMultiValueMap(size);
/* 205 */     for (Map.Entry<String, List<String>> entry : this.queryParams.entrySet()) {
/* 206 */       String name = encodeUriComponent((String)entry.getKey(), encoding, Type.QUERY_PARAM);
/* 207 */       List<String> values = new ArrayList(((List)entry.getValue()).size());
/* 208 */       for (String value : (List)entry.getValue()) {
/* 209 */         values.add(encodeUriComponent(value, encoding, Type.QUERY_PARAM));
/*     */       }
/* 211 */       result.put(name, values);
/*     */     }
/* 213 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String encodeUriComponent(String source, String encoding, Type type)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 228 */     if (source == null) {
/* 229 */       return null;
/*     */     }
/* 231 */     Assert.hasLength(encoding, "Encoding must not be empty");
/* 232 */     byte[] bytes = encodeBytes(source.getBytes(encoding), type);
/* 233 */     return new String(bytes, "US-ASCII");
/*     */   }
/*     */   
/*     */   private static byte[] encodeBytes(byte[] source, Type type) {
/* 237 */     Assert.notNull(source, "Source must not be null");
/* 238 */     Assert.notNull(type, "Type must not be null");
/* 239 */     ByteArrayOutputStream bos = new ByteArrayOutputStream(source.length);
/* 240 */     for (byte b : source) {
/* 241 */       if (b < 0) {
/* 242 */         b = (byte)(b + 256);
/*     */       }
/* 244 */       if (type.isAllowed(b)) {
/* 245 */         bos.write(b);
/*     */       }
/*     */       else {
/* 248 */         bos.write(37);
/* 249 */         char hex1 = Character.toUpperCase(Character.forDigit(b >> 4 & 0xF, 16));
/* 250 */         char hex2 = Character.toUpperCase(Character.forDigit(b & 0xF, 16));
/* 251 */         bos.write(hex1);
/* 252 */         bos.write(hex2);
/*     */       }
/*     */     }
/* 255 */     return bos.toByteArray();
/*     */   }
/*     */   
/*     */   private Type getHostType() {
/* 259 */     return (this.host != null) && (this.host.startsWith("[")) ? Type.HOST_IPV6 : Type.HOST_IPV4;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void verify()
/*     */   {
/* 271 */     if (!this.encoded) {
/* 272 */       return;
/*     */     }
/* 274 */     verifyUriComponent(getScheme(), Type.SCHEME);
/* 275 */     verifyUriComponent(this.userInfo, Type.USER_INFO);
/* 276 */     verifyUriComponent(this.host, getHostType());
/* 277 */     this.path.verify();
/* 278 */     for (Map.Entry<String, List<String>> entry : this.queryParams.entrySet()) {
/* 279 */       verifyUriComponent((String)entry.getKey(), Type.QUERY_PARAM);
/* 280 */       for (String value : (List)entry.getValue()) {
/* 281 */         verifyUriComponent(value, Type.QUERY_PARAM);
/*     */       }
/*     */     }
/* 284 */     verifyUriComponent(getFragment(), Type.FRAGMENT);
/*     */   }
/*     */   
/*     */   private static void verifyUriComponent(String source, Type type) {
/* 288 */     if (source == null) {
/* 289 */       return;
/*     */     }
/* 291 */     int length = source.length();
/* 292 */     for (int i = 0; i < length; i++) {
/* 293 */       char ch = source.charAt(i);
/* 294 */       if (ch == '%') {
/* 295 */         if (i + 2 < length) {
/* 296 */           char hex1 = source.charAt(i + 1);
/* 297 */           char hex2 = source.charAt(i + 2);
/* 298 */           int u = Character.digit(hex1, 16);
/* 299 */           int l = Character.digit(hex2, 16);
/* 300 */           if ((u == -1) || (l == -1))
/*     */           {
/* 302 */             throw new IllegalArgumentException("Invalid encoded sequence \"" + source.substring(i) + "\"");
/*     */           }
/* 304 */           i += 2;
/*     */         }
/*     */         else
/*     */         {
/* 308 */           throw new IllegalArgumentException("Invalid encoded sequence \"" + source.substring(i) + "\"");
/*     */         }
/*     */       }
/* 311 */       else if (!type.isAllowed(ch))
/*     */       {
/* 313 */         throw new IllegalArgumentException("Invalid character '" + ch + "' for " + type.name() + " in \"" + source + "\"");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected HierarchicalUriComponents expandInternal(UriComponents.UriTemplateVariables uriVariables)
/*     */   {
/* 323 */     Assert.state(!this.encoded, "Cannot expand an already encoded UriComponents object");
/*     */     
/* 325 */     String schemeTo = expandUriComponent(getScheme(), uriVariables);
/* 326 */     String userInfoTo = expandUriComponent(this.userInfo, uriVariables);
/* 327 */     String hostTo = expandUriComponent(this.host, uriVariables);
/* 328 */     String portTo = expandUriComponent(this.port, uriVariables);
/* 329 */     PathComponent pathTo = this.path.expand(uriVariables);
/* 330 */     MultiValueMap<String, String> paramsTo = expandQueryParams(uriVariables);
/* 331 */     String fragmentTo = expandUriComponent(getFragment(), uriVariables);
/*     */     
/* 333 */     return new HierarchicalUriComponents(schemeTo, userInfoTo, hostTo, portTo, pathTo, paramsTo, fragmentTo, false, false);
/*     */   }
/*     */   
/*     */   private MultiValueMap<String, String> expandQueryParams(UriComponents.UriTemplateVariables variables)
/*     */   {
/* 338 */     int size = this.queryParams.size();
/* 339 */     MultiValueMap<String, String> result = new LinkedMultiValueMap(size);
/* 340 */     variables = new QueryUriTemplateVariables(variables);
/* 341 */     for (Map.Entry<String, List<String>> entry : this.queryParams.entrySet()) {
/* 342 */       String name = expandUriComponent((String)entry.getKey(), variables);
/* 343 */       List<String> values = new ArrayList(((List)entry.getValue()).size());
/* 344 */       for (String value : (List)entry.getValue()) {
/* 345 */         values.add(expandUriComponent(value, variables));
/*     */       }
/* 347 */       result.put(name, values);
/*     */     }
/* 349 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriComponents normalize()
/*     */   {
/* 358 */     String normalizedPath = StringUtils.cleanPath(getPath());
/*     */     
/*     */ 
/* 361 */     return new HierarchicalUriComponents(getScheme(), this.userInfo, this.host, this.port, new FullPathComponent(normalizedPath), this.queryParams, getFragment(), this.encoded, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toUriString()
/*     */   {
/* 372 */     StringBuilder uriBuilder = new StringBuilder();
/* 373 */     if (getScheme() != null) {
/* 374 */       uriBuilder.append(getScheme());
/* 375 */       uriBuilder.append(':');
/*     */     }
/* 377 */     if ((this.userInfo != null) || (this.host != null)) {
/* 378 */       uriBuilder.append("//");
/* 379 */       if (this.userInfo != null) {
/* 380 */         uriBuilder.append(this.userInfo);
/* 381 */         uriBuilder.append('@');
/*     */       }
/* 383 */       if (this.host != null) {
/* 384 */         uriBuilder.append(this.host);
/*     */       }
/* 386 */       if (getPort() != -1) {
/* 387 */         uriBuilder.append(':');
/* 388 */         uriBuilder.append(this.port);
/*     */       }
/*     */     }
/* 391 */     String path = getPath();
/* 392 */     if (StringUtils.hasLength(path)) {
/* 393 */       if ((uriBuilder.length() != 0) && (path.charAt(0) != '/')) {
/* 394 */         uriBuilder.append('/');
/*     */       }
/* 396 */       uriBuilder.append(path);
/*     */     }
/* 398 */     String query = getQuery();
/* 399 */     if (query != null) {
/* 400 */       uriBuilder.append('?');
/* 401 */       uriBuilder.append(query);
/*     */     }
/* 403 */     if (getFragment() != null) {
/* 404 */       uriBuilder.append('#');
/* 405 */       uriBuilder.append(getFragment());
/*     */     }
/* 407 */     return uriBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public URI toUri()
/*     */   {
/*     */     try
/*     */     {
/* 416 */       if (this.encoded) {
/* 417 */         return new URI(toString());
/*     */       }
/*     */       
/* 420 */       String path = getPath();
/* 421 */       if ((StringUtils.hasLength(path)) && (path.charAt(0) != '/'))
/*     */       {
/* 423 */         if ((getScheme() != null) || (getUserInfo() != null) || (getHost() != null) || (getPort() != -1)) {
/* 424 */           path = '/' + path;
/*     */         }
/*     */       }
/*     */       
/* 428 */       return new URI(getScheme(), getUserInfo(), getHost(), getPort(), path, getQuery(), getFragment());
/*     */     }
/*     */     catch (URISyntaxException ex)
/*     */     {
/* 432 */       throw new IllegalStateException("Could not create URI object: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void copyToUriComponentsBuilder(UriComponentsBuilder builder)
/*     */   {
/* 438 */     builder.scheme(getScheme());
/* 439 */     builder.userInfo(getUserInfo());
/* 440 */     builder.host(getHost());
/* 441 */     builder.port(getPort());
/* 442 */     builder.replacePath("");
/* 443 */     this.path.copyToUriComponentsBuilder(builder);
/* 444 */     builder.replaceQueryParams(getQueryParams());
/* 445 */     builder.fragment(getFragment());
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 451 */     if (this == obj) {
/* 452 */       return true;
/*     */     }
/* 454 */     if (!(obj instanceof HierarchicalUriComponents)) {
/* 455 */       return false;
/*     */     }
/* 457 */     HierarchicalUriComponents other = (HierarchicalUriComponents)obj;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 464 */     return (ObjectUtils.nullSafeEquals(getScheme(), other.getScheme())) && (ObjectUtils.nullSafeEquals(getUserInfo(), other.getUserInfo())) && (ObjectUtils.nullSafeEquals(getHost(), other.getHost())) && (getPort() == other.getPort()) && (this.path.equals(other.path)) && (this.queryParams.equals(other.queryParams)) && (ObjectUtils.nullSafeEquals(getFragment(), other.getFragment()));
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 469 */     int result = ObjectUtils.nullSafeHashCode(getScheme());
/* 470 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.userInfo);
/* 471 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.host);
/* 472 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.port);
/* 473 */     result = 31 * result + this.path.hashCode();
/* 474 */     result = 31 * result + this.queryParams.hashCode();
/* 475 */     result = 31 * result + ObjectUtils.nullSafeHashCode(getFragment());
/* 476 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static abstract enum Type
/*     */   {
/* 489 */     SCHEME, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 495 */     AUTHORITY, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 501 */     USER_INFO, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 507 */     HOST_IPV4, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 513 */     HOST_IPV6, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 519 */     PORT, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 525 */     PATH, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 531 */     PATH_SEGMENT, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 537 */     QUERY, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 543 */     QUERY_PARAM, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 554 */     FRAGMENT, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 560 */     URI;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private Type() {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract boolean isAllowed(int paramInt);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected boolean isAlpha(int c)
/*     */     {
/* 578 */       return ((c >= 97) && (c <= 122)) || ((c >= 65) && (c <= 90));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected boolean isDigit(int c)
/*     */     {
/* 586 */       return (c >= 48) && (c <= 57);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected boolean isGenericDelimiter(int c)
/*     */     {
/* 594 */       return (58 == c) || (47 == c) || (63 == c) || (35 == c) || (91 == c) || (93 == c) || (64 == c);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected boolean isSubDelimiter(int c)
/*     */     {
/* 602 */       return (33 == c) || (36 == c) || (38 == c) || (39 == c) || (40 == c) || (41 == c) || (42 == c) || (43 == c) || (44 == c) || (59 == c) || (61 == c);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected boolean isReserved(int c)
/*     */     {
/* 611 */       return (isGenericDelimiter(c)) || (isSubDelimiter(c));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected boolean isUnreserved(int c)
/*     */     {
/* 619 */       return (isAlpha(c)) || (isDigit(c)) || (45 == c) || (46 == c) || (95 == c) || (126 == c);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected boolean isPchar(int c)
/*     */     {
/* 627 */       return (isUnreserved(c)) || (isSubDelimiter(c)) || (58 == c) || (64 == c);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static abstract interface PathComponent
/*     */     extends Serializable
/*     */   {
/*     */     public abstract String getPath();
/*     */     
/*     */ 
/*     */     public abstract List<String> getPathSegments();
/*     */     
/*     */ 
/*     */     public abstract PathComponent encode(String paramString)
/*     */       throws UnsupportedEncodingException;
/*     */     
/*     */ 
/*     */     public abstract void verify();
/*     */     
/*     */ 
/*     */     public abstract PathComponent expand(UriComponents.UriTemplateVariables paramUriTemplateVariables);
/*     */     
/*     */     public abstract void copyToUriComponentsBuilder(UriComponentsBuilder paramUriComponentsBuilder);
/*     */   }
/*     */   
/*     */   static final class FullPathComponent
/*     */     implements HierarchicalUriComponents.PathComponent
/*     */   {
/*     */     private final String path;
/*     */     
/*     */     public FullPathComponent(String path)
/*     */     {
/* 660 */       this.path = path;
/*     */     }
/*     */     
/*     */     public String getPath()
/*     */     {
/* 665 */       return this.path;
/*     */     }
/*     */     
/*     */     public List<String> getPathSegments()
/*     */     {
/* 670 */       String delimiter = new String(new char[] { '/' });
/* 671 */       String[] pathSegments = StringUtils.tokenizeToStringArray(this.path, delimiter);
/* 672 */       return Collections.unmodifiableList(Arrays.asList(pathSegments));
/*     */     }
/*     */     
/*     */     public HierarchicalUriComponents.PathComponent encode(String encoding) throws UnsupportedEncodingException
/*     */     {
/* 677 */       String encodedPath = HierarchicalUriComponents.encodeUriComponent(getPath(), encoding, HierarchicalUriComponents.Type.PATH);
/* 678 */       return new FullPathComponent(encodedPath);
/*     */     }
/*     */     
/*     */     public void verify() {
/* 682 */       HierarchicalUriComponents.verifyUriComponent(this.path, HierarchicalUriComponents.Type.PATH);
/*     */     }
/*     */     
/*     */     public HierarchicalUriComponents.PathComponent expand(UriComponents.UriTemplateVariables uriVariables)
/*     */     {
/* 687 */       String expandedPath = UriComponents.expandUriComponent(getPath(), uriVariables);
/* 688 */       return new FullPathComponent(expandedPath);
/*     */     }
/*     */     
/*     */     public void copyToUriComponentsBuilder(UriComponentsBuilder builder)
/*     */     {
/* 693 */       builder.path(getPath());
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean equals(Object obj)
/*     */     {
/* 699 */       return (this == obj) || (((obj instanceof FullPathComponent)) && (getPath().equals(((FullPathComponent)obj).getPath())));
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 704 */       return getPath().hashCode();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static final class PathSegmentComponent
/*     */     implements HierarchicalUriComponents.PathComponent
/*     */   {
/*     */     private final List<String> pathSegments;
/*     */     
/*     */ 
/*     */     public PathSegmentComponent(List<String> pathSegments)
/*     */     {
/* 717 */       Assert.notNull(pathSegments);
/* 718 */       this.pathSegments = Collections.unmodifiableList(new ArrayList(pathSegments));
/*     */     }
/*     */     
/*     */     public String getPath()
/*     */     {
/* 723 */       StringBuilder pathBuilder = new StringBuilder();
/* 724 */       pathBuilder.append('/');
/* 725 */       for (Iterator<String> iterator = this.pathSegments.iterator(); iterator.hasNext();) {
/* 726 */         String pathSegment = (String)iterator.next();
/* 727 */         pathBuilder.append(pathSegment);
/* 728 */         if (iterator.hasNext()) {
/* 729 */           pathBuilder.append('/');
/*     */         }
/*     */       }
/* 732 */       return pathBuilder.toString();
/*     */     }
/*     */     
/*     */     public List<String> getPathSegments()
/*     */     {
/* 737 */       return this.pathSegments;
/*     */     }
/*     */     
/*     */     public HierarchicalUriComponents.PathComponent encode(String encoding) throws UnsupportedEncodingException
/*     */     {
/* 742 */       List<String> pathSegments = getPathSegments();
/* 743 */       List<String> encodedPathSegments = new ArrayList(pathSegments.size());
/* 744 */       for (String pathSegment : pathSegments) {
/* 745 */         String encodedPathSegment = HierarchicalUriComponents.encodeUriComponent(pathSegment, encoding, HierarchicalUriComponents.Type.PATH_SEGMENT);
/* 746 */         encodedPathSegments.add(encodedPathSegment);
/*     */       }
/* 748 */       return new PathSegmentComponent(encodedPathSegments);
/*     */     }
/*     */     
/*     */     public void verify()
/*     */     {
/* 753 */       for (String pathSegment : getPathSegments()) {
/* 754 */         HierarchicalUriComponents.verifyUriComponent(pathSegment, HierarchicalUriComponents.Type.PATH_SEGMENT);
/*     */       }
/*     */     }
/*     */     
/*     */     public HierarchicalUriComponents.PathComponent expand(UriComponents.UriTemplateVariables uriVariables)
/*     */     {
/* 760 */       List<String> pathSegments = getPathSegments();
/* 761 */       List<String> expandedPathSegments = new ArrayList(pathSegments.size());
/* 762 */       for (String pathSegment : pathSegments) {
/* 763 */         String expandedPathSegment = UriComponents.expandUriComponent(pathSegment, uriVariables);
/* 764 */         expandedPathSegments.add(expandedPathSegment);
/*     */       }
/* 766 */       return new PathSegmentComponent(expandedPathSegments);
/*     */     }
/*     */     
/*     */     public void copyToUriComponentsBuilder(UriComponentsBuilder builder)
/*     */     {
/* 771 */       builder.pathSegment((String[])getPathSegments().toArray(new String[getPathSegments().size()]));
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean equals(Object obj)
/*     */     {
/* 777 */       return (this == obj) || (((obj instanceof PathSegmentComponent)) && (getPathSegments().equals(((PathSegmentComponent)obj).getPathSegments())));
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 782 */       return getPathSegments().hashCode();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static final class PathComponentComposite
/*     */     implements HierarchicalUriComponents.PathComponent
/*     */   {
/*     */     private final List<HierarchicalUriComponents.PathComponent> pathComponents;
/*     */     
/*     */ 
/*     */     public PathComponentComposite(List<HierarchicalUriComponents.PathComponent> pathComponents)
/*     */     {
/* 795 */       Assert.notNull(pathComponents);
/* 796 */       this.pathComponents = pathComponents;
/*     */     }
/*     */     
/*     */     public String getPath()
/*     */     {
/* 801 */       StringBuilder pathBuilder = new StringBuilder();
/* 802 */       for (HierarchicalUriComponents.PathComponent pathComponent : this.pathComponents) {
/* 803 */         pathBuilder.append(pathComponent.getPath());
/*     */       }
/* 805 */       return pathBuilder.toString();
/*     */     }
/*     */     
/*     */     public List<String> getPathSegments()
/*     */     {
/* 810 */       List<String> result = new ArrayList();
/* 811 */       for (HierarchicalUriComponents.PathComponent pathComponent : this.pathComponents) {
/* 812 */         result.addAll(pathComponent.getPathSegments());
/*     */       }
/* 814 */       return result;
/*     */     }
/*     */     
/*     */     public HierarchicalUriComponents.PathComponent encode(String encoding) throws UnsupportedEncodingException
/*     */     {
/* 819 */       List<HierarchicalUriComponents.PathComponent> encodedComponents = new ArrayList(this.pathComponents.size());
/* 820 */       for (HierarchicalUriComponents.PathComponent pathComponent : this.pathComponents) {
/* 821 */         encodedComponents.add(pathComponent.encode(encoding));
/*     */       }
/* 823 */       return new PathComponentComposite(encodedComponents);
/*     */     }
/*     */     
/*     */     public void verify()
/*     */     {
/* 828 */       for (HierarchicalUriComponents.PathComponent pathComponent : this.pathComponents) {
/* 829 */         pathComponent.verify();
/*     */       }
/*     */     }
/*     */     
/*     */     public HierarchicalUriComponents.PathComponent expand(UriComponents.UriTemplateVariables uriVariables)
/*     */     {
/* 835 */       List<HierarchicalUriComponents.PathComponent> expandedComponents = new ArrayList(this.pathComponents.size());
/* 836 */       for (HierarchicalUriComponents.PathComponent pathComponent : this.pathComponents) {
/* 837 */         expandedComponents.add(pathComponent.expand(uriVariables));
/*     */       }
/* 839 */       return new PathComponentComposite(expandedComponents);
/*     */     }
/*     */     
/*     */     public void copyToUriComponentsBuilder(UriComponentsBuilder builder)
/*     */     {
/* 844 */       for (HierarchicalUriComponents.PathComponent pathComponent : this.pathComponents) {
/* 845 */         pathComponent.copyToUriComponentsBuilder(builder);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 854 */   static final PathComponent NULL_PATH_COMPONENT = new PathComponent()
/*     */   {
/*     */     public String getPath() {
/* 857 */       return null;
/*     */     }
/*     */     
/*     */     public List<String> getPathSegments() {
/* 861 */       return Collections.emptyList();
/*     */     }
/*     */     
/*     */     public HierarchicalUriComponents.PathComponent encode(String encoding) throws UnsupportedEncodingException {
/* 865 */       return this;
/*     */     }
/*     */     
/*     */     public void verify() {}
/*     */     
/*     */     public HierarchicalUriComponents.PathComponent expand(UriComponents.UriTemplateVariables uriVariables)
/*     */     {
/* 872 */       return this;
/*     */     }
/*     */     
/*     */     public void copyToUriComponentsBuilder(UriComponentsBuilder builder) {}
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/* 879 */       return this == obj;
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 883 */       return 42;
/*     */     }
/*     */   };
/*     */   
/*     */   private static class QueryUriTemplateVariables implements UriComponents.UriTemplateVariables
/*     */   {
/*     */     private final UriComponents.UriTemplateVariables delegate;
/*     */     
/*     */     public QueryUriTemplateVariables(UriComponents.UriTemplateVariables delegate)
/*     */     {
/* 893 */       this.delegate = delegate;
/*     */     }
/*     */     
/*     */     public Object getValue(String name)
/*     */     {
/* 898 */       Object value = this.delegate.getValue(name);
/* 899 */       if (ObjectUtils.isArray(value)) {
/* 900 */         value = StringUtils.arrayToCommaDelimitedString(ObjectUtils.toObjectArray(value));
/*     */       }
/* 902 */       return value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\util\HierarchicalUriComponents.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */