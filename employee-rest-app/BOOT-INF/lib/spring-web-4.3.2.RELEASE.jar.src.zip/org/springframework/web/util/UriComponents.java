/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URI;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class UriComponents
/*     */   implements Serializable
/*     */ {
/*     */   private static final String DEFAULT_ENCODING = "UTF-8";
/*  48 */   private static final Pattern NAMES_PATTERN = Pattern.compile("\\{([^/]+?)\\}");
/*     */   
/*     */   private final String scheme;
/*     */   
/*     */   private final String fragment;
/*     */   
/*     */ 
/*     */   protected UriComponents(String scheme, String fragment)
/*     */   {
/*  57 */     this.scheme = scheme;
/*  58 */     this.fragment = fragment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getScheme()
/*     */   {
/*  68 */     return this.scheme;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String getSchemeSpecificPart();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String getUserInfo();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String getHost();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int getPort();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String getPath();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract List<String> getPathSegments();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String getQuery();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract MultiValueMap<String, String> getQueryParams();
/*     */   
/*     */ 
/*     */ 
/*     */   public final String getFragment()
/*     */   {
/* 115 */     return this.fragment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final UriComponents encode()
/*     */   {
/*     */     try
/*     */     {
/* 126 */       return encode("UTF-8");
/*     */     }
/*     */     catch (UnsupportedEncodingException ex)
/*     */     {
/* 130 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract UriComponents encode(String paramString)
/*     */     throws UnsupportedEncodingException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final UriComponents expand(Map<String, ?> uriVariables)
/*     */   {
/* 151 */     Assert.notNull(uriVariables, "'uriVariables' must not be null");
/* 152 */     return expandInternal(new MapTemplateVariables(uriVariables));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final UriComponents expand(Object... uriVariableValues)
/*     */   {
/* 162 */     Assert.notNull(uriVariableValues, "'uriVariableValues' must not be null");
/* 163 */     return expandInternal(new VarArgsTemplateVariables(uriVariableValues));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final UriComponents expand(UriTemplateVariables uriVariables)
/*     */   {
/* 173 */     Assert.notNull(uriVariables, "'uriVariables' must not be null");
/* 174 */     return expandInternal(uriVariables);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   abstract UriComponents expandInternal(UriTemplateVariables paramUriTemplateVariables);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract UriComponents normalize();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String toUriString();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract URI toUri();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String toString()
/*     */   {
/* 203 */     return toUriString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void copyToUriComponentsBuilder(UriComponentsBuilder paramUriComponentsBuilder);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static String expandUriComponent(String source, UriTemplateVariables uriVariables)
/*     */   {
/* 216 */     if (source == null) {
/* 217 */       return null;
/*     */     }
/* 219 */     if (source.indexOf('{') == -1) {
/* 220 */       return source;
/*     */     }
/* 222 */     if (source.indexOf(':') != -1) {
/* 223 */       source = sanitizeSource(source);
/*     */     }
/* 225 */     Matcher matcher = NAMES_PATTERN.matcher(source);
/* 226 */     StringBuffer sb = new StringBuffer();
/* 227 */     while (matcher.find()) {
/* 228 */       String match = matcher.group(1);
/* 229 */       String variableName = getVariableName(match);
/* 230 */       Object variableValue = uriVariables.getValue(variableName);
/* 231 */       if (!UriTemplateVariables.SKIP_VALUE.equals(variableValue))
/*     */       {
/*     */ 
/* 234 */         String variableValueString = getVariableValueAsString(variableValue);
/* 235 */         String replacement = Matcher.quoteReplacement(variableValueString);
/* 236 */         matcher.appendReplacement(sb, replacement);
/*     */       } }
/* 238 */     matcher.appendTail(sb);
/* 239 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static String sanitizeSource(String source)
/*     */   {
/* 246 */     int level = 0;
/* 247 */     StringBuilder sb = new StringBuilder();
/* 248 */     for (char c : source.toCharArray()) {
/* 249 */       if (c == '{') {
/* 250 */         level++;
/*     */       }
/* 252 */       if (c == '}') {
/* 253 */         level--;
/*     */       }
/* 255 */       if ((level <= 1) && ((level != 1) || (c != '}')))
/*     */       {
/*     */ 
/* 258 */         sb.append(c); }
/*     */     }
/* 260 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private static String getVariableName(String match) {
/* 264 */     int colonIdx = match.indexOf(':');
/* 265 */     return colonIdx != -1 ? match.substring(0, colonIdx) : match;
/*     */   }
/*     */   
/*     */   private static String getVariableValueAsString(Object variableValue) {
/* 269 */     return variableValue != null ? variableValue.toString() : "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static abstract interface UriTemplateVariables
/*     */   {
/* 279 */     public static final Object SKIP_VALUE = UriTemplateVariables.class;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract Object getValue(String paramString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class MapTemplateVariables
/*     */     implements UriComponents.UriTemplateVariables
/*     */   {
/*     */     private final Map<String, ?> uriVariables;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public MapTemplateVariables(Map<String, ?> uriVariables)
/*     */     {
/* 300 */       this.uriVariables = uriVariables;
/*     */     }
/*     */     
/*     */     public Object getValue(String name)
/*     */     {
/* 305 */       if (!this.uriVariables.containsKey(name)) {
/* 306 */         throw new IllegalArgumentException("Map has no value for '" + name + "'");
/*     */       }
/* 308 */       return this.uriVariables.get(name);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class VarArgsTemplateVariables
/*     */     implements UriComponents.UriTemplateVariables
/*     */   {
/*     */     private final Iterator<Object> valueIterator;
/*     */     
/*     */ 
/*     */     public VarArgsTemplateVariables(Object... uriVariableValues)
/*     */     {
/* 321 */       this.valueIterator = Arrays.asList(uriVariableValues).iterator();
/*     */     }
/*     */     
/*     */     public Object getValue(String name)
/*     */     {
/* 326 */       if (!this.valueIterator.hasNext()) {
/* 327 */         throw new IllegalArgumentException("Not enough variable values available to expand '" + name + "'");
/*     */       }
/* 329 */       return this.valueIterator.next();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\util\UriComponents.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */