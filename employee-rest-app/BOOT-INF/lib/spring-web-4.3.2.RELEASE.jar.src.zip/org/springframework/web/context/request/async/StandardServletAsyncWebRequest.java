/*     */ package org.springframework.web.context.request.async;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import javax.servlet.AsyncContext;
/*     */ import javax.servlet.AsyncEvent;
/*     */ import javax.servlet.AsyncListener;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardServletAsyncWebRequest
/*     */   extends ServletWebRequest
/*     */   implements AsyncWebRequest, AsyncListener
/*     */ {
/*     */   private Long timeout;
/*     */   private AsyncContext asyncContext;
/*  49 */   private AtomicBoolean asyncCompleted = new AtomicBoolean(false);
/*     */   
/*  51 */   private final List<Runnable> timeoutHandlers = new ArrayList();
/*     */   
/*  53 */   private final List<Runnable> completionHandlers = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StandardServletAsyncWebRequest(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  62 */     super(request, response);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeout(Long timeout)
/*     */   {
/*  72 */     Assert.state(!isAsyncStarted(), "Cannot change the timeout with concurrent handling in progress");
/*  73 */     this.timeout = timeout;
/*     */   }
/*     */   
/*     */   public void addTimeoutHandler(Runnable timeoutHandler)
/*     */   {
/*  78 */     this.timeoutHandlers.add(timeoutHandler);
/*     */   }
/*     */   
/*     */   public void addCompletionHandler(Runnable runnable)
/*     */   {
/*  83 */     this.completionHandlers.add(runnable);
/*     */   }
/*     */   
/*     */   public boolean isAsyncStarted()
/*     */   {
/*  88 */     return (this.asyncContext != null) && (getRequest().isAsyncStarted());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAsyncComplete()
/*     */   {
/*  98 */     return this.asyncCompleted.get();
/*     */   }
/*     */   
/*     */   public void startAsync()
/*     */   {
/* 103 */     Assert.state(getRequest().isAsyncSupported(), "Async support must be enabled on a servlet and for all filters involved in async request processing. This is done in Java code using the Servlet API or by adding \"<async-supported>true</async-supported>\" to servlet and filter declarations in web.xml.");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 108 */     Assert.state(!isAsyncComplete(), "Async processing has already completed");
/*     */     
/* 110 */     if (isAsyncStarted()) {
/* 111 */       return;
/*     */     }
/* 113 */     this.asyncContext = getRequest().startAsync(getRequest(), getResponse());
/* 114 */     this.asyncContext.addListener(this);
/* 115 */     if (this.timeout != null) {
/* 116 */       this.asyncContext.setTimeout(this.timeout.longValue());
/*     */     }
/*     */   }
/*     */   
/*     */   public void dispatch()
/*     */   {
/* 122 */     Assert.notNull(this.asyncContext, "Cannot dispatch without an AsyncContext");
/* 123 */     this.asyncContext.dispatch();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void onStartAsync(AsyncEvent event)
/*     */     throws IOException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void onError(AsyncEvent event)
/*     */     throws IOException
/*     */   {
/* 137 */     onComplete(event);
/*     */   }
/*     */   
/*     */   public void onTimeout(AsyncEvent event) throws IOException
/*     */   {
/* 142 */     for (Runnable handler : this.timeoutHandlers) {
/* 143 */       handler.run();
/*     */     }
/*     */   }
/*     */   
/*     */   public void onComplete(AsyncEvent event) throws IOException
/*     */   {
/* 149 */     for (Runnable handler : this.completionHandlers) {
/* 150 */       handler.run();
/*     */     }
/* 152 */     this.asyncContext = null;
/* 153 */     this.asyncCompleted.set(true);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\context\request\async\StandardServletAsyncWebRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */