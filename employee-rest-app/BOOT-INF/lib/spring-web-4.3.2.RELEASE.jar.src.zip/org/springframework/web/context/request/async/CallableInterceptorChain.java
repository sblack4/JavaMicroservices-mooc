/*     */ package org.springframework.web.context.request.async;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CallableInterceptorChain
/*     */ {
/*  36 */   private static final Log logger = LogFactory.getLog(CallableInterceptorChain.class);
/*     */   
/*     */   private final List<CallableProcessingInterceptor> interceptors;
/*     */   
/*  40 */   private int preProcessIndex = -1;
/*     */   
/*     */   public CallableInterceptorChain(List<CallableProcessingInterceptor> interceptors)
/*     */   {
/*  44 */     this.interceptors = interceptors;
/*     */   }
/*     */   
/*     */   public void applyBeforeConcurrentHandling(NativeWebRequest request, Callable<?> task) throws Exception {
/*  48 */     for (CallableProcessingInterceptor interceptor : this.interceptors) {
/*  49 */       interceptor.beforeConcurrentHandling(request, task);
/*     */     }
/*     */   }
/*     */   
/*     */   public void applyPreProcess(NativeWebRequest request, Callable<?> task) throws Exception {
/*  54 */     for (CallableProcessingInterceptor interceptor : this.interceptors) {
/*  55 */       interceptor.preProcess(request, task);
/*  56 */       this.preProcessIndex += 1;
/*     */     }
/*     */   }
/*     */   
/*     */   public Object applyPostProcess(NativeWebRequest request, Callable<?> task, Object concurrentResult) {
/*  61 */     Throwable exceptionResult = null;
/*  62 */     for (int i = this.preProcessIndex; i >= 0; i--) {
/*     */       try {
/*  64 */         ((CallableProcessingInterceptor)this.interceptors.get(i)).postProcess(request, task, concurrentResult);
/*     */       }
/*     */       catch (Throwable t)
/*     */       {
/*  68 */         if (exceptionResult != null) {
/*  69 */           logger.error("postProcess error", t);
/*     */         }
/*     */         else {
/*  72 */           exceptionResult = t;
/*     */         }
/*     */       }
/*     */     }
/*  76 */     return exceptionResult != null ? exceptionResult : concurrentResult;
/*     */   }
/*     */   
/*     */   public Object triggerAfterTimeout(NativeWebRequest request, Callable<?> task) {
/*  80 */     for (CallableProcessingInterceptor interceptor : this.interceptors) {
/*     */       try {
/*  82 */         Object result = interceptor.handleTimeout(request, task);
/*  83 */         if (result == CallableProcessingInterceptor.RESPONSE_HANDLED) {
/*     */           break;
/*     */         }
/*  86 */         if (result != CallableProcessingInterceptor.RESULT_NONE) {
/*  87 */           return result;
/*     */         }
/*     */       }
/*     */       catch (Throwable t) {
/*  91 */         return t;
/*     */       }
/*     */     }
/*  94 */     return CallableProcessingInterceptor.RESULT_NONE;
/*     */   }
/*     */   
/*     */   public void triggerAfterCompletion(NativeWebRequest request, Callable<?> task) {
/*  98 */     for (int i = this.interceptors.size() - 1; i >= 0; i--) {
/*     */       try {
/* 100 */         ((CallableProcessingInterceptor)this.interceptors.get(i)).afterCompletion(request, task);
/*     */       }
/*     */       catch (Throwable t) {
/* 103 */         logger.error("afterCompletion error", t);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\context\request\async\CallableInterceptorChain.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */