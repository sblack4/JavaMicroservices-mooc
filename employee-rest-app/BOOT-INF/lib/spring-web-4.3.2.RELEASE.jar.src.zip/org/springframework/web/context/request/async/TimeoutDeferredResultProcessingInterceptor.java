/*    */ package org.springframework.web.context.request.async;
/*    */ 
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimeoutDeferredResultProcessingInterceptor
/*    */   extends DeferredResultProcessingInterceptorAdapter
/*    */ {
/*    */   public <T> boolean handleTimeout(NativeWebRequest request, DeferredResult<T> deferredResult)
/*    */     throws Exception
/*    */   {
/* 41 */     HttpServletResponse servletResponse = (HttpServletResponse)request.getNativeResponse(HttpServletResponse.class);
/* 42 */     if (!servletResponse.isCommitted()) {
/* 43 */       servletResponse.sendError(HttpStatus.SERVICE_UNAVAILABLE.value());
/*    */     }
/* 45 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\context\request\async\TimeoutDeferredResultProcessingInterceptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */