/*     */ package org.springframework.web.context.request;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletWebRequest
/*     */   extends ServletRequestAttributes
/*     */   implements NativeWebRequest
/*     */ {
/*     */   private static final String HEADER_ETAG = "ETag";
/*     */   private static final String HEADER_IF_MODIFIED_SINCE = "If-Modified-Since";
/*     */   private static final String HEADER_IF_UNMODIFIED_SINCE = "If-Unmodified-Since";
/*     */   private static final String HEADER_IF_NONE_MATCH = "If-None-Match";
/*     */   private static final String HEADER_LAST_MODIFIED = "Last-Modified";
/*     */   private static final String METHOD_GET = "GET";
/*     */   private static final String METHOD_HEAD = "HEAD";
/*     */   private static final String METHOD_POST = "POST";
/*     */   private static final String METHOD_PUT = "PUT";
/*     */   private static final String METHOD_DELETE = "DELETE";
/*  72 */   private static final Pattern ETAG_HEADER_VALUE_PATTERN = Pattern.compile("\\*|\\s*((W\\/)?(\"[^\"]*\"))\\s*,?");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  77 */   private static final boolean servlet3Present = ClassUtils.hasMethod(HttpServletResponse.class, "getHeader", new Class[] { String.class });
/*     */   
/*  79 */   private boolean notModified = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletWebRequest(HttpServletRequest request)
/*     */   {
/*  87 */     super(request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletWebRequest(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  96 */     super(request, response);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object getNativeRequest()
/*     */   {
/* 102 */     return getRequest();
/*     */   }
/*     */   
/*     */   public Object getNativeResponse()
/*     */   {
/* 107 */     return getResponse();
/*     */   }
/*     */   
/*     */   public <T> T getNativeRequest(Class<T> requiredType)
/*     */   {
/* 112 */     return (T)WebUtils.getNativeRequest(getRequest(), requiredType);
/*     */   }
/*     */   
/*     */   public <T> T getNativeResponse(Class<T> requiredType)
/*     */   {
/* 117 */     return (T)WebUtils.getNativeResponse(getResponse(), requiredType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpMethod getHttpMethod()
/*     */   {
/* 125 */     return HttpMethod.resolve(getRequest().getMethod());
/*     */   }
/*     */   
/*     */   public String getHeader(String headerName)
/*     */   {
/* 130 */     return getRequest().getHeader(headerName);
/*     */   }
/*     */   
/*     */   public String[] getHeaderValues(String headerName)
/*     */   {
/* 135 */     String[] headerValues = StringUtils.toStringArray(getRequest().getHeaders(headerName));
/* 136 */     return !ObjectUtils.isEmpty(headerValues) ? headerValues : null;
/*     */   }
/*     */   
/*     */   public Iterator<String> getHeaderNames()
/*     */   {
/* 141 */     return CollectionUtils.toIterator(getRequest().getHeaderNames());
/*     */   }
/*     */   
/*     */   public String getParameter(String paramName)
/*     */   {
/* 146 */     return getRequest().getParameter(paramName);
/*     */   }
/*     */   
/*     */   public String[] getParameterValues(String paramName)
/*     */   {
/* 151 */     return getRequest().getParameterValues(paramName);
/*     */   }
/*     */   
/*     */   public Iterator<String> getParameterNames()
/*     */   {
/* 156 */     return CollectionUtils.toIterator(getRequest().getParameterNames());
/*     */   }
/*     */   
/*     */   public Map<String, String[]> getParameterMap()
/*     */   {
/* 161 */     return getRequest().getParameterMap();
/*     */   }
/*     */   
/*     */   public Locale getLocale()
/*     */   {
/* 166 */     return getRequest().getLocale();
/*     */   }
/*     */   
/*     */   public String getContextPath()
/*     */   {
/* 171 */     return getRequest().getContextPath();
/*     */   }
/*     */   
/*     */   public String getRemoteUser()
/*     */   {
/* 176 */     return getRequest().getRemoteUser();
/*     */   }
/*     */   
/*     */   public Principal getUserPrincipal()
/*     */   {
/* 181 */     return getRequest().getUserPrincipal();
/*     */   }
/*     */   
/*     */   public boolean isUserInRole(String role)
/*     */   {
/* 186 */     return getRequest().isUserInRole(role);
/*     */   }
/*     */   
/*     */   public boolean isSecure()
/*     */   {
/* 191 */     return getRequest().isSecure();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean checkNotModified(long lastModifiedTimestamp)
/*     */   {
/* 197 */     HttpServletResponse response = getResponse();
/* 198 */     if ((lastModifiedTimestamp >= 0L) && (!this.notModified) && 
/* 199 */       (isCompatibleWithConditionalRequests(response))) {
/* 200 */       this.notModified = isTimestampNotModified(lastModifiedTimestamp);
/* 201 */       if (response != null) {
/* 202 */         if (supportsNotModifiedStatus()) {
/* 203 */           if (this.notModified) {
/* 204 */             response.setStatus(304);
/*     */           }
/* 206 */           if (isHeaderAbsent(response, "Last-Modified")) {
/* 207 */             response.setDateHeader("Last-Modified", lastModifiedTimestamp);
/*     */           }
/*     */         }
/* 210 */         else if ((supportsConditionalUpdate()) && 
/* 211 */           (this.notModified)) {
/* 212 */           response.setStatus(412);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 218 */     return this.notModified;
/*     */   }
/*     */   
/*     */   public boolean checkNotModified(String etag)
/*     */   {
/* 223 */     HttpServletResponse response = getResponse();
/* 224 */     if ((StringUtils.hasLength(etag)) && (!this.notModified) && 
/* 225 */       (isCompatibleWithConditionalRequests(response))) {
/* 226 */       etag = addEtagPadding(etag);
/* 227 */       if (hasRequestHeader("If-None-Match")) {
/* 228 */         this.notModified = isEtagNotModified(etag);
/*     */       }
/* 230 */       if (response != null) {
/* 231 */         if ((this.notModified) && (supportsNotModifiedStatus())) {
/* 232 */           response.setStatus(304);
/*     */         }
/* 234 */         if (isHeaderAbsent(response, "ETag")) {
/* 235 */           response.setHeader("ETag", etag);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 240 */     return this.notModified;
/*     */   }
/*     */   
/*     */   public boolean checkNotModified(String etag, long lastModifiedTimestamp)
/*     */   {
/* 245 */     HttpServletResponse response = getResponse();
/* 246 */     if ((StringUtils.hasLength(etag)) && (!this.notModified) && 
/* 247 */       (isCompatibleWithConditionalRequests(response))) {
/* 248 */       etag = addEtagPadding(etag);
/* 249 */       if (hasRequestHeader("If-None-Match")) {
/* 250 */         this.notModified = isEtagNotModified(etag);
/*     */       }
/* 252 */       else if (hasRequestHeader("If-Modified-Since")) {
/* 253 */         this.notModified = isTimestampNotModified(lastModifiedTimestamp);
/*     */       }
/* 255 */       if (response != null) {
/* 256 */         if (supportsNotModifiedStatus()) {
/* 257 */           if (this.notModified) {
/* 258 */             response.setStatus(304);
/*     */           }
/* 260 */           if (isHeaderAbsent(response, "ETag")) {
/* 261 */             response.setHeader("ETag", etag);
/*     */           }
/* 263 */           if (isHeaderAbsent(response, "Last-Modified")) {
/* 264 */             response.setDateHeader("Last-Modified", lastModifiedTimestamp);
/*     */           }
/*     */         }
/* 267 */         else if ((supportsConditionalUpdate()) && 
/* 268 */           (this.notModified)) {
/* 269 */           response.setStatus(412);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 275 */     return this.notModified;
/*     */   }
/*     */   
/*     */   public boolean isNotModified() {
/* 279 */     return this.notModified;
/*     */   }
/*     */   
/*     */   private boolean isCompatibleWithConditionalRequests(HttpServletResponse response)
/*     */   {
/*     */     try {
/* 285 */       if ((response == null) || (!servlet3Present))
/*     */       {
/* 287 */         return true;
/*     */       }
/* 289 */       return HttpStatus.valueOf(response.getStatus()).is2xxSuccessful();
/*     */     }
/*     */     catch (IllegalArgumentException e) {}
/* 292 */     return true;
/*     */   }
/*     */   
/*     */   private boolean isHeaderAbsent(HttpServletResponse response, String header)
/*     */   {
/* 297 */     if ((response == null) || (!servlet3Present))
/*     */     {
/* 299 */       return true;
/*     */     }
/* 301 */     return response.getHeader(header) == null;
/*     */   }
/*     */   
/*     */   private boolean hasRequestHeader(String headerName) {
/* 305 */     return StringUtils.hasLength(getHeader(headerName));
/*     */   }
/*     */   
/*     */   private boolean supportsNotModifiedStatus() {
/* 309 */     String method = getRequest().getMethod();
/* 310 */     return ("GET".equals(method)) || ("HEAD".equals(method));
/*     */   }
/*     */   
/*     */   private boolean supportsConditionalUpdate() {
/* 314 */     String method = getRequest().getMethod();
/*     */     
/* 316 */     return (("POST".equals(method)) || ("PUT".equals(method)) || ("DELETE".equals(method))) && (hasRequestHeader("If-Unmodified-Since"));
/*     */   }
/*     */   
/*     */   private boolean isTimestampNotModified(long lastModifiedTimestamp) {
/* 320 */     long ifModifiedSince = parseDateHeader("If-Modified-Since");
/* 321 */     if (ifModifiedSince != -1L) {
/* 322 */       return ifModifiedSince >= lastModifiedTimestamp / 1000L * 1000L;
/*     */     }
/* 324 */     long ifUnmodifiedSince = parseDateHeader("If-Unmodified-Since");
/* 325 */     if (ifUnmodifiedSince != -1L) {
/* 326 */       return ifUnmodifiedSince < lastModifiedTimestamp / 1000L * 1000L;
/*     */     }
/* 328 */     return false;
/*     */   }
/*     */   
/*     */   private long parseDateHeader(String headerName)
/*     */   {
/* 333 */     long dateValue = -1L;
/*     */     try {
/* 335 */       dateValue = getRequest().getDateHeader(headerName);
/*     */     }
/*     */     catch (IllegalArgumentException ex) {
/* 338 */       String headerValue = getHeader(headerName);
/*     */       
/* 340 */       int separatorIndex = headerValue.indexOf(';');
/* 341 */       if (separatorIndex != -1) {
/* 342 */         String datePart = headerValue.substring(0, separatorIndex);
/*     */         try {
/* 344 */           dateValue = Date.parse(datePart);
/*     */         }
/*     */         catch (IllegalArgumentException localIllegalArgumentException1) {}
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 351 */     return dateValue;
/*     */   }
/*     */   
/*     */   private boolean isEtagNotModified(String etag) {
/* 355 */     String ifNoneMatch = getHeader("If-None-Match");
/*     */     
/* 357 */     String serverETag = etag.replaceFirst("^W/", "");
/* 358 */     Matcher eTagMatcher = ETAG_HEADER_VALUE_PATTERN.matcher(ifNoneMatch);
/* 359 */     while (eTagMatcher.find()) {
/* 360 */       if (("*".equals(eTagMatcher.group())) || 
/* 361 */         (serverETag.equals(eTagMatcher.group(3)))) {
/* 362 */         return true;
/*     */       }
/*     */     }
/* 365 */     return false;
/*     */   }
/*     */   
/*     */   private String addEtagPadding(String etag) {
/* 369 */     if (((!etag.startsWith("\"")) && (!etag.startsWith("W/\""))) || (!etag.endsWith("\""))) {
/* 370 */       etag = "\"" + etag + "\"";
/*     */     }
/* 372 */     return etag;
/*     */   }
/*     */   
/*     */   public String getDescription(boolean includeClientInfo)
/*     */   {
/* 377 */     HttpServletRequest request = getRequest();
/* 378 */     StringBuilder sb = new StringBuilder();
/* 379 */     sb.append("uri=").append(request.getRequestURI());
/* 380 */     if (includeClientInfo) {
/* 381 */       String client = request.getRemoteAddr();
/* 382 */       if (StringUtils.hasLength(client)) {
/* 383 */         sb.append(";client=").append(client);
/*     */       }
/* 385 */       HttpSession session = request.getSession(false);
/* 386 */       if (session != null) {
/* 387 */         sb.append(";session=").append(session.getId());
/*     */       }
/* 389 */       String user = request.getRemoteUser();
/* 390 */       if (StringUtils.hasLength(user)) {
/* 391 */         sb.append(";user=").append(user);
/*     */       }
/*     */     }
/* 394 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 400 */     return "ServletWebRequest: " + getDescription(true);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\context\request\ServletWebRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */