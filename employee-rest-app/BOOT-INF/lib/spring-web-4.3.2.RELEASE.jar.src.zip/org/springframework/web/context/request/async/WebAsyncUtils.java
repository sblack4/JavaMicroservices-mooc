/*    */ package org.springframework.web.context.request.async;
/*    */ 
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.web.context.request.WebRequest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WebAsyncUtils
/*    */ {
/* 36 */   public static final String WEB_ASYNC_MANAGER_ATTRIBUTE = WebAsyncManager.class.getName() + ".WEB_ASYNC_MANAGER";
/*    */   
/*    */ 
/* 39 */   private static final boolean startAsyncAvailable = ClassUtils.hasMethod(ServletRequest.class, "startAsync", new Class[0]);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static WebAsyncManager getAsyncManager(ServletRequest servletRequest)
/*    */   {
/* 47 */     WebAsyncManager asyncManager = (WebAsyncManager)servletRequest.getAttribute(WEB_ASYNC_MANAGER_ATTRIBUTE);
/* 48 */     if (asyncManager == null) {
/* 49 */       asyncManager = new WebAsyncManager();
/* 50 */       servletRequest.setAttribute(WEB_ASYNC_MANAGER_ATTRIBUTE, asyncManager);
/*    */     }
/* 52 */     return asyncManager;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static WebAsyncManager getAsyncManager(WebRequest webRequest)
/*    */   {
/* 60 */     int scope = 0;
/* 61 */     WebAsyncManager asyncManager = (WebAsyncManager)webRequest.getAttribute(WEB_ASYNC_MANAGER_ATTRIBUTE, scope);
/* 62 */     if (asyncManager == null) {
/* 63 */       asyncManager = new WebAsyncManager();
/* 64 */       webRequest.setAttribute(WEB_ASYNC_MANAGER_ATTRIBUTE, asyncManager, scope);
/*    */     }
/* 66 */     return asyncManager;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static AsyncWebRequest createAsyncWebRequest(HttpServletRequest request, HttpServletResponse response)
/*    */   {
/* 79 */     return startAsyncAvailable ? AsyncWebRequestFactory.createStandardAsyncWebRequest(request, response) : new NoSupportAsyncWebRequest(request, response);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static class AsyncWebRequestFactory
/*    */   {
/*    */     public static AsyncWebRequest createStandardAsyncWebRequest(HttpServletRequest request, HttpServletResponse response)
/*    */     {
/* 90 */       return new StandardServletAsyncWebRequest(request, response);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\context\request\async\WebAsyncUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */