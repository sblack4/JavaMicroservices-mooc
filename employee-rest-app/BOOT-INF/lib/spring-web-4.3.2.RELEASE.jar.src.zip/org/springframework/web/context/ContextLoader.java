/*     */ package org.springframework.web.context;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.access.BeanFactoryLocator;
/*     */ import org.springframework.beans.factory.access.BeanFactoryReference;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.context.ApplicationContextInitializer;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.access.ContextSingletonBeanFactoryLocator;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.support.PropertiesLoaderUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextLoader
/*     */ {
/*     */   public static final String CONTEXT_ID_PARAM = "contextId";
/*     */   public static final String CONFIG_LOCATION_PARAM = "contextConfigLocation";
/*     */   public static final String CONTEXT_CLASS_PARAM = "contextClass";
/*     */   public static final String CONTEXT_INITIALIZER_CLASSES_PARAM = "contextInitializerClasses";
/*     */   public static final String GLOBAL_INITIALIZER_CLASSES_PARAM = "globalInitializerClasses";
/*     */   public static final String LOCATOR_FACTORY_SELECTOR_PARAM = "locatorFactorySelector";
/*     */   public static final String LOCATOR_FACTORY_KEY_PARAM = "parentContextKey";
/*     */   private static final String INIT_PARAM_DELIMITERS = ",; \t\n";
/*     */   private static final String DEFAULT_STRATEGIES_PATH = "ContextLoader.properties";
/*     */   private static final Properties defaultStrategies;
/*     */   
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/* 173 */       ClassPathResource resource = new ClassPathResource("ContextLoader.properties", ContextLoader.class);
/* 174 */       defaultStrategies = PropertiesLoaderUtils.loadProperties(resource);
/*     */     }
/*     */     catch (IOException ex) {
/* 177 */       throw new IllegalStateException("Could not load 'ContextLoader.properties': " + ex.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 185 */   private static final Map<ClassLoader, WebApplicationContext> currentContextPerThread = new ConcurrentHashMap(1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static volatile WebApplicationContext currentContext;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private WebApplicationContext context;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private BeanFactoryReference parentContextRef;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 207 */   private final List<ApplicationContextInitializer<ConfigurableApplicationContext>> contextInitializers = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContextLoader(WebApplicationContext context)
/*     */   {
/* 263 */     this.context = context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContextInitializers(ApplicationContextInitializer<?>... initializers)
/*     */   {
/* 276 */     if (initializers != null) {
/* 277 */       for (ApplicationContextInitializer<?> initializer : initializers) {
/* 278 */         this.contextInitializers.add(initializer);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WebApplicationContext initWebApplicationContext(ServletContext servletContext)
/*     */   {
/* 296 */     if (servletContext.getAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE) != null) {
/* 297 */       throw new IllegalStateException("Cannot initialize context because there is already a root application context present - check whether you have multiple ContextLoader* definitions in your web.xml!");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 302 */     Log logger = LogFactory.getLog(ContextLoader.class);
/* 303 */     servletContext.log("Initializing Spring root WebApplicationContext");
/* 304 */     if (logger.isInfoEnabled()) {
/* 305 */       logger.info("Root WebApplicationContext: initialization started");
/*     */     }
/* 307 */     long startTime = System.currentTimeMillis();
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 312 */       if (this.context == null) {
/* 313 */         this.context = createWebApplicationContext(servletContext);
/*     */       }
/* 315 */       if ((this.context instanceof ConfigurableWebApplicationContext)) {
/* 316 */         ConfigurableWebApplicationContext cwac = (ConfigurableWebApplicationContext)this.context;
/* 317 */         if (!cwac.isActive())
/*     */         {
/*     */ 
/* 320 */           if (cwac.getParent() == null)
/*     */           {
/*     */ 
/* 323 */             ApplicationContext parent = loadParentContext(servletContext);
/* 324 */             cwac.setParent(parent);
/*     */           }
/* 326 */           configureAndRefreshWebApplicationContext(cwac, servletContext);
/*     */         }
/*     */       }
/* 329 */       servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE, this.context);
/*     */       
/* 331 */       ClassLoader ccl = Thread.currentThread().getContextClassLoader();
/* 332 */       if (ccl == ContextLoader.class.getClassLoader()) {
/* 333 */         currentContext = this.context;
/*     */       }
/* 335 */       else if (ccl != null) {
/* 336 */         currentContextPerThread.put(ccl, this.context);
/*     */       }
/*     */       
/* 339 */       if (logger.isDebugEnabled()) {
/* 340 */         logger.debug("Published root WebApplicationContext as ServletContext attribute with name [" + WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE + "]");
/*     */       }
/*     */       
/* 343 */       if (logger.isInfoEnabled()) {
/* 344 */         long elapsedTime = System.currentTimeMillis() - startTime;
/* 345 */         logger.info("Root WebApplicationContext: initialization completed in " + elapsedTime + " ms");
/*     */       }
/*     */       
/* 348 */       return this.context;
/*     */     }
/*     */     catch (RuntimeException ex) {
/* 351 */       logger.error("Context initialization failed", ex);
/* 352 */       servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE, ex);
/* 353 */       throw ex;
/*     */     }
/*     */     catch (Error err) {
/* 356 */       logger.error("Context initialization failed", err);
/* 357 */       servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE, err);
/* 358 */       throw err;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected WebApplicationContext createWebApplicationContext(ServletContext sc)
/*     */   {
/* 375 */     Class<?> contextClass = determineContextClass(sc);
/* 376 */     if (!ConfigurableWebApplicationContext.class.isAssignableFrom(contextClass))
/*     */     {
/* 378 */       throw new ApplicationContextException("Custom context class [" + contextClass.getName() + "] is not of type [" + ConfigurableWebApplicationContext.class.getName() + "]");
/*     */     }
/* 380 */     return (ConfigurableWebApplicationContext)BeanUtils.instantiateClass(contextClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Class<?> determineContextClass(ServletContext servletContext)
/*     */   {
/* 392 */     String contextClassName = servletContext.getInitParameter("contextClass");
/* 393 */     if (contextClassName != null) {
/*     */       try {
/* 395 */         return ClassUtils.forName(contextClassName, ClassUtils.getDefaultClassLoader());
/*     */       }
/*     */       catch (ClassNotFoundException ex) {
/* 398 */         throw new ApplicationContextException("Failed to load custom context class [" + contextClassName + "]", ex);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 403 */     contextClassName = defaultStrategies.getProperty(WebApplicationContext.class.getName());
/*     */     try {
/* 405 */       return ClassUtils.forName(contextClassName, ContextLoader.class.getClassLoader());
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 408 */       throw new ApplicationContextException("Failed to load default context class [" + contextClassName + "]", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void configureAndRefreshWebApplicationContext(ConfigurableWebApplicationContext wac, ServletContext sc)
/*     */   {
/* 415 */     if (ObjectUtils.identityToString(wac).equals(wac.getId()))
/*     */     {
/*     */ 
/* 418 */       String idParam = sc.getInitParameter("contextId");
/* 419 */       if (idParam != null) {
/* 420 */         wac.setId(idParam);
/*     */       }
/*     */       else
/*     */       {
/* 424 */         wac.setId(ConfigurableWebApplicationContext.APPLICATION_CONTEXT_ID_PREFIX + 
/* 425 */           ObjectUtils.getDisplayString(sc.getContextPath()));
/*     */       }
/*     */     }
/*     */     
/* 429 */     wac.setServletContext(sc);
/* 430 */     String configLocationParam = sc.getInitParameter("contextConfigLocation");
/* 431 */     if (configLocationParam != null) {
/* 432 */       wac.setConfigLocation(configLocationParam);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 438 */     ConfigurableEnvironment env = wac.getEnvironment();
/* 439 */     if ((env instanceof ConfigurableWebEnvironment)) {
/* 440 */       ((ConfigurableWebEnvironment)env).initPropertySources(sc, null);
/*     */     }
/*     */     
/* 443 */     customizeContext(sc, wac);
/* 444 */     wac.refresh();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void customizeContext(ServletContext sc, ConfigurableWebApplicationContext wac)
/*     */   {
/* 466 */     List<Class<ApplicationContextInitializer<ConfigurableApplicationContext>>> initializerClasses = determineContextInitializerClasses(sc);
/*     */     
/* 468 */     for (Class<ApplicationContextInitializer<ConfigurableApplicationContext>> initializerClass : initializerClasses)
/*     */     {
/* 470 */       Class<?> initializerContextClass = GenericTypeResolver.resolveTypeArgument(initializerClass, ApplicationContextInitializer.class);
/* 471 */       if ((initializerContextClass != null) && (!initializerContextClass.isInstance(wac))) {
/* 472 */         throw new ApplicationContextException(String.format("Could not apply context initializer [%s] since its generic parameter [%s] is not assignable from the type of application context used by this context loader: [%s]", new Object[] {initializerClass
/*     */         
/*     */ 
/* 475 */           .getName(), initializerContextClass.getName(), wac
/* 476 */           .getClass().getName() }));
/*     */       }
/* 478 */       this.contextInitializers.add(BeanUtils.instantiateClass(initializerClass));
/*     */     }
/*     */     
/* 481 */     AnnotationAwareOrderComparator.sort(this.contextInitializers);
/* 482 */     for (ApplicationContextInitializer<ConfigurableApplicationContext> initializer : this.contextInitializers) {
/* 483 */       initializer.initialize(wac);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<Class<ApplicationContextInitializer<ConfigurableApplicationContext>>> determineContextInitializerClasses(ServletContext servletContext)
/*     */   {
/* 496 */     List<Class<ApplicationContextInitializer<ConfigurableApplicationContext>>> classes = new ArrayList();
/*     */     
/*     */ 
/* 499 */     String globalClassNames = servletContext.getInitParameter("globalInitializerClasses");
/* 500 */     String str1; String className; if (globalClassNames != null) {
/* 501 */       String[] arrayOfString1 = StringUtils.tokenizeToStringArray(globalClassNames, ",; \t\n");int i = arrayOfString1.length; for (str1 = 0; str1 < i; str1++) { className = arrayOfString1[str1];
/* 502 */         classes.add(loadInitializerClass(className));
/*     */       }
/*     */     }
/*     */     
/* 506 */     String localClassNames = servletContext.getInitParameter("contextInitializerClasses");
/* 507 */     if (localClassNames != null) {
/* 508 */       String[] arrayOfString2 = StringUtils.tokenizeToStringArray(localClassNames, ",; \t\n");str1 = arrayOfString2.length; for (className = 0; className < str1; className++) { String className = arrayOfString2[className];
/* 509 */         classes.add(loadInitializerClass(className));
/*     */       }
/*     */     }
/*     */     
/* 513 */     return classes;
/*     */   }
/*     */   
/*     */   private Class<ApplicationContextInitializer<ConfigurableApplicationContext>> loadInitializerClass(String className)
/*     */   {
/*     */     try {
/* 519 */       Class<?> clazz = ClassUtils.forName(className, ClassUtils.getDefaultClassLoader());
/* 520 */       Assert.isAssignable(ApplicationContextInitializer.class, clazz);
/* 521 */       return clazz;
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 524 */       throw new ApplicationContextException("Failed to load context initializer class [" + className + "]", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ApplicationContext loadParentContext(ServletContext servletContext)
/*     */   {
/* 549 */     ApplicationContext parentContext = null;
/* 550 */     String locatorFactorySelector = servletContext.getInitParameter("locatorFactorySelector");
/* 551 */     String parentContextKey = servletContext.getInitParameter("parentContextKey");
/*     */     
/* 553 */     if (parentContextKey != null)
/*     */     {
/* 555 */       BeanFactoryLocator locator = ContextSingletonBeanFactoryLocator.getInstance(locatorFactorySelector);
/* 556 */       Log logger = LogFactory.getLog(ContextLoader.class);
/* 557 */       if (logger.isDebugEnabled()) {
/* 558 */         logger.debug("Getting parent context definition: using parent context key of '" + parentContextKey + "' with BeanFactoryLocator");
/*     */       }
/*     */       
/* 561 */       this.parentContextRef = locator.useBeanFactory(parentContextKey);
/* 562 */       parentContext = (ApplicationContext)this.parentContextRef.getFactory();
/*     */     }
/*     */     
/* 565 */     return parentContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static WebApplicationContext getCurrentWebApplicationContext()
/*     */   {
/* 609 */     ClassLoader ccl = Thread.currentThread().getContextClassLoader();
/* 610 */     if (ccl != null) {
/* 611 */       WebApplicationContext ccpt = (WebApplicationContext)currentContextPerThread.get(ccl);
/* 612 */       if (ccpt != null) {
/* 613 */         return ccpt;
/*     */       }
/*     */     }
/* 616 */     return currentContext;
/*     */   }
/*     */   
/*     */   public ContextLoader() {}
/*     */   
/*     */   /* Error */
/*     */   public void closeWebApplicationContext(ServletContext servletContext)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ldc 114
/*     */     //   3: invokeinterface 15 2 0
/*     */     //   8: aload_0
/*     */     //   9: getfield 5	org/springframework/web/context/ContextLoader:context	Lorg/springframework/web/context/WebApplicationContext;
/*     */     //   12: instanceof 21
/*     */     //   15: ifeq +15 -> 30
/*     */     //   18: aload_0
/*     */     //   19: getfield 5	org/springframework/web/context/ContextLoader:context	Lorg/springframework/web/context/WebApplicationContext;
/*     */     //   22: checkcast 21	org/springframework/web/context/ConfigurableWebApplicationContext
/*     */     //   25: invokeinterface 115 1 0
/*     */     //   30: invokestatic 28	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   33: invokevirtual 29	java/lang/Thread:getContextClassLoader	()Ljava/lang/ClassLoader;
/*     */     //   36: astore_2
/*     */     //   37: aload_2
/*     */     //   38: ldc 12
/*     */     //   40: invokevirtual 30	java/lang/Class:getClassLoader	()Ljava/lang/ClassLoader;
/*     */     //   43: if_acmpne +10 -> 53
/*     */     //   46: aconst_null
/*     */     //   47: putstatic 31	org/springframework/web/context/ContextLoader:currentContext	Lorg/springframework/web/context/WebApplicationContext;
/*     */     //   50: goto +17 -> 67
/*     */     //   53: aload_2
/*     */     //   54: ifnull +13 -> 67
/*     */     //   57: getstatic 32	org/springframework/web/context/ContextLoader:currentContextPerThread	Ljava/util/Map;
/*     */     //   60: aload_2
/*     */     //   61: invokeinterface 116 2 0
/*     */     //   66: pop
/*     */     //   67: aload_1
/*     */     //   68: getstatic 7	org/springframework/web/context/WebApplicationContext:ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE	Ljava/lang/String;
/*     */     //   71: invokeinterface 117 2 0
/*     */     //   76: aload_0
/*     */     //   77: getfield 111	org/springframework/web/context/ContextLoader:parentContextRef	Lorg/springframework/beans/factory/access/BeanFactoryReference;
/*     */     //   80: ifnull +12 -> 92
/*     */     //   83: aload_0
/*     */     //   84: getfield 111	org/springframework/web/context/ContextLoader:parentContextRef	Lorg/springframework/beans/factory/access/BeanFactoryReference;
/*     */     //   87: invokeinterface 118 1 0
/*     */     //   92: goto +72 -> 164
/*     */     //   95: astore_3
/*     */     //   96: invokestatic 28	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   99: invokevirtual 29	java/lang/Thread:getContextClassLoader	()Ljava/lang/ClassLoader;
/*     */     //   102: astore 4
/*     */     //   104: aload 4
/*     */     //   106: ldc 12
/*     */     //   108: invokevirtual 30	java/lang/Class:getClassLoader	()Ljava/lang/ClassLoader;
/*     */     //   111: if_acmpne +10 -> 121
/*     */     //   114: aconst_null
/*     */     //   115: putstatic 31	org/springframework/web/context/ContextLoader:currentContext	Lorg/springframework/web/context/WebApplicationContext;
/*     */     //   118: goto +19 -> 137
/*     */     //   121: aload 4
/*     */     //   123: ifnull +14 -> 137
/*     */     //   126: getstatic 32	org/springframework/web/context/ContextLoader:currentContextPerThread	Ljava/util/Map;
/*     */     //   129: aload 4
/*     */     //   131: invokeinterface 116 2 0
/*     */     //   136: pop
/*     */     //   137: aload_1
/*     */     //   138: getstatic 7	org/springframework/web/context/WebApplicationContext:ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE	Ljava/lang/String;
/*     */     //   141: invokeinterface 117 2 0
/*     */     //   146: aload_0
/*     */     //   147: getfield 111	org/springframework/web/context/ContextLoader:parentContextRef	Lorg/springframework/beans/factory/access/BeanFactoryReference;
/*     */     //   150: ifnull +12 -> 162
/*     */     //   153: aload_0
/*     */     //   154: getfield 111	org/springframework/web/context/ContextLoader:parentContextRef	Lorg/springframework/beans/factory/access/BeanFactoryReference;
/*     */     //   157: invokeinterface 118 1 0
/*     */     //   162: aload_3
/*     */     //   163: athrow
/*     */     //   164: return
/*     */     // Line number table:
/*     */     //   Java source line #578	-> byte code offset #0
/*     */     //   Java source line #580	-> byte code offset #8
/*     */     //   Java source line #581	-> byte code offset #18
/*     */     //   Java source line #585	-> byte code offset #30
/*     */     //   Java source line #586	-> byte code offset #37
/*     */     //   Java source line #587	-> byte code offset #46
/*     */     //   Java source line #589	-> byte code offset #53
/*     */     //   Java source line #590	-> byte code offset #57
/*     */     //   Java source line #592	-> byte code offset #67
/*     */     //   Java source line #593	-> byte code offset #76
/*     */     //   Java source line #594	-> byte code offset #83
/*     */     //   Java source line #596	-> byte code offset #92
/*     */     //   Java source line #585	-> byte code offset #95
/*     */     //   Java source line #586	-> byte code offset #104
/*     */     //   Java source line #587	-> byte code offset #114
/*     */     //   Java source line #589	-> byte code offset #121
/*     */     //   Java source line #590	-> byte code offset #126
/*     */     //   Java source line #592	-> byte code offset #137
/*     */     //   Java source line #593	-> byte code offset #146
/*     */     //   Java source line #594	-> byte code offset #153
/*     */     //   Java source line #596	-> byte code offset #162
/*     */     //   Java source line #597	-> byte code offset #164
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	165	0	this	ContextLoader
/*     */     //   0	165	1	servletContext	ServletContext
/*     */     //   36	25	2	ccl	ClassLoader
/*     */     //   95	68	3	localObject	Object
/*     */     //   102	28	4	ccl	ClassLoader
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   8	30	95	finally
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\context\ContextLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */