/*     */ package org.springframework.web.context.request.async;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeferredResult<T>
/*     */ {
/*  51 */   private static final Object RESULT_NONE = new Object();
/*     */   
/*  53 */   private static final Log logger = LogFactory.getLog(DeferredResult.class);
/*     */   
/*     */ 
/*     */   private final Long timeout;
/*     */   
/*     */   private final Object timeoutResult;
/*     */   
/*     */   private Runnable timeoutCallback;
/*     */   
/*     */   private Runnable completionCallback;
/*     */   
/*     */   private DeferredResultHandler resultHandler;
/*     */   
/*  66 */   private volatile Object result = RESULT_NONE;
/*     */   
/*     */ 
/*     */   private volatile boolean expired;
/*     */   
/*     */ 
/*     */ 
/*     */   public DeferredResult()
/*     */   {
/*  75 */     this(null, RESULT_NONE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DeferredResult(Long timeout)
/*     */   {
/*  86 */     this(timeout, RESULT_NONE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DeferredResult(Long timeout, Object timeoutResult)
/*     */   {
/*  96 */     this.timeoutResult = timeoutResult;
/*  97 */     this.timeout = timeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isSetOrExpired()
/*     */   {
/* 110 */     return (this.result != RESULT_NONE) || (this.expired);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasResult()
/*     */   {
/* 118 */     return this.result != RESULT_NONE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getResult()
/*     */   {
/* 128 */     Object resultToCheck = this.result;
/* 129 */     return resultToCheck != RESULT_NONE ? resultToCheck : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   final Long getTimeoutValue()
/*     */   {
/* 136 */     return this.timeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onTimeout(Runnable callback)
/*     */   {
/* 147 */     this.timeoutCallback = callback;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onCompletion(Runnable callback)
/*     */   {
/* 157 */     this.completionCallback = callback;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setResultHandler(DeferredResultHandler resultHandler)
/*     */   {
/* 166 */     Assert.notNull(resultHandler, "DeferredResultHandler is required");
/* 167 */     synchronized (this) {
/* 168 */       this.resultHandler = resultHandler;
/* 169 */       if ((this.result != RESULT_NONE) && (!this.expired)) {
/*     */         try {
/* 171 */           this.resultHandler.handleResult(this.result);
/*     */         }
/*     */         catch (Throwable ex) {
/* 174 */           logger.trace("DeferredResult not handled", ex);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean setResult(T result)
/*     */   {
/* 188 */     return setResultInternal(result);
/*     */   }
/*     */   
/*     */   private boolean setResultInternal(Object result) {
/* 192 */     synchronized (this) {
/* 193 */       if (isSetOrExpired()) {
/* 194 */         return false;
/*     */       }
/* 196 */       this.result = result;
/*     */     }
/* 198 */     if (this.resultHandler != null) {
/* 199 */       this.resultHandler.handleResult(this.result);
/*     */     }
/* 201 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean setErrorResult(Object result)
/*     */   {
/* 214 */     return setResultInternal(result);
/*     */   }
/*     */   
/*     */   final DeferredResultProcessingInterceptor getInterceptor()
/*     */   {
/* 219 */     new DeferredResultProcessingInterceptorAdapter()
/*     */     {
/*     */       public <S> boolean handleTimeout(NativeWebRequest request, DeferredResult<S> deferredResult) {
/* 222 */         if (DeferredResult.this.timeoutCallback != null) {
/* 223 */           DeferredResult.this.timeoutCallback.run();
/*     */         }
/* 225 */         if (DeferredResult.this.timeoutResult != DeferredResult.RESULT_NONE) {
/* 226 */           DeferredResult.this.setResultInternal(DeferredResult.this.timeoutResult);
/*     */         }
/* 228 */         return true;
/*     */       }
/*     */       
/*     */       public <S> void afterCompletion(NativeWebRequest request, DeferredResult<S> deferredResult) {
/* 232 */         synchronized (DeferredResult.this) {
/* 233 */           DeferredResult.this.expired = true;
/*     */         }
/* 235 */         if (DeferredResult.this.completionCallback != null) {
/* 236 */           DeferredResult.this.completionCallback.run();
/*     */         }
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public static abstract interface DeferredResultHandler
/*     */   {
/*     */     public abstract void handleResult(Object paramObject);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\context\request\async\DeferredResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */