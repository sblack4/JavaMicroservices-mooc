/*     */ package org.springframework.web.context.request.async;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.core.task.SimpleAsyncTaskExecutor;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WebAsyncManager
/*     */ {
/*  60 */   private static final Object RESULT_NONE = new Object();
/*     */   
/*  62 */   private static final Log logger = LogFactory.getLog(WebAsyncManager.class);
/*     */   
/*  64 */   private static final UrlPathHelper urlPathHelper = new UrlPathHelper();
/*     */   
/*  66 */   private static final CallableProcessingInterceptor timeoutCallableInterceptor = new TimeoutCallableProcessingInterceptor();
/*     */   
/*     */ 
/*  69 */   private static final DeferredResultProcessingInterceptor timeoutDeferredResultInterceptor = new TimeoutDeferredResultProcessingInterceptor();
/*     */   
/*     */ 
/*     */   private AsyncWebRequest asyncWebRequest;
/*     */   
/*     */ 
/*  75 */   private AsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor(getClass().getSimpleName());
/*     */   
/*  77 */   private Object concurrentResult = RESULT_NONE;
/*     */   
/*     */   private Object[] concurrentResultContext;
/*     */   
/*  81 */   private final Map<Object, CallableProcessingInterceptor> callableInterceptors = new LinkedHashMap();
/*     */   
/*     */ 
/*  84 */   private final Map<Object, DeferredResultProcessingInterceptor> deferredResultInterceptors = new LinkedHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAsyncWebRequest(final AsyncWebRequest asyncWebRequest)
/*     */   {
/* 107 */     Assert.notNull(asyncWebRequest, "AsyncWebRequest must not be null");
/* 108 */     this.asyncWebRequest = asyncWebRequest;
/* 109 */     this.asyncWebRequest.addCompletionHandler(new Runnable()
/*     */     {
/*     */       public void run() {
/* 112 */         asyncWebRequest.removeAttribute(WebAsyncUtils.WEB_ASYNC_MANAGER_ATTRIBUTE, 0);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTaskExecutor(AsyncTaskExecutor taskExecutor)
/*     */   {
/* 123 */     this.taskExecutor = taskExecutor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isConcurrentHandlingStarted()
/*     */   {
/* 135 */     return (this.asyncWebRequest != null) && (this.asyncWebRequest.isAsyncStarted());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean hasConcurrentResult()
/*     */   {
/* 142 */     return this.concurrentResult != RESULT_NONE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getConcurrentResult()
/*     */   {
/* 152 */     return this.concurrentResult;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object[] getConcurrentResultContext()
/*     */   {
/* 161 */     return this.concurrentResultContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CallableProcessingInterceptor getCallableInterceptor(Object key)
/*     */   {
/* 170 */     return (CallableProcessingInterceptor)this.callableInterceptors.get(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DeferredResultProcessingInterceptor getDeferredResultInterceptor(Object key)
/*     */   {
/* 179 */     return (DeferredResultProcessingInterceptor)this.deferredResultInterceptors.get(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerCallableInterceptor(Object key, CallableProcessingInterceptor interceptor)
/*     */   {
/* 188 */     Assert.notNull(key, "Key is required");
/* 189 */     Assert.notNull(interceptor, "CallableProcessingInterceptor  is required");
/* 190 */     this.callableInterceptors.put(key, interceptor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerCallableInterceptors(CallableProcessingInterceptor... interceptors)
/*     */   {
/* 199 */     Assert.notNull(interceptors, "A CallableProcessingInterceptor is required");
/* 200 */     for (CallableProcessingInterceptor interceptor : interceptors) {
/* 201 */       String key = interceptor.getClass().getName() + ":" + interceptor.hashCode();
/* 202 */       this.callableInterceptors.put(key, interceptor);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerDeferredResultInterceptor(Object key, DeferredResultProcessingInterceptor interceptor)
/*     */   {
/* 212 */     Assert.notNull(key, "Key is required");
/* 213 */     Assert.notNull(interceptor, "DeferredResultProcessingInterceptor is required");
/* 214 */     this.deferredResultInterceptors.put(key, interceptor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerDeferredResultInterceptors(DeferredResultProcessingInterceptor... interceptors)
/*     */   {
/* 223 */     Assert.notNull(interceptors, "A DeferredResultProcessingInterceptor is required");
/* 224 */     for (DeferredResultProcessingInterceptor interceptor : interceptors) {
/* 225 */       String key = interceptor.getClass().getName() + ":" + interceptor.hashCode();
/* 226 */       this.deferredResultInterceptors.put(key, interceptor);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearConcurrentResult()
/*     */   {
/* 235 */     this.concurrentResult = RESULT_NONE;
/* 236 */     this.concurrentResultContext = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void startCallableProcessing(Callable<?> callable, Object... processingContext)
/*     */     throws Exception
/*     */   {
/* 254 */     Assert.notNull(callable, "Callable must not be null");
/* 255 */     startCallableProcessing(new WebAsyncTask(callable), processingContext);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void startCallableProcessing(WebAsyncTask<?> webAsyncTask, Object... processingContext)
/*     */     throws Exception
/*     */   {
/* 268 */     Assert.notNull(webAsyncTask, "WebAsyncTask must not be null");
/* 269 */     Assert.state(this.asyncWebRequest != null, "AsyncWebRequest must not be null");
/*     */     
/* 271 */     Long timeout = webAsyncTask.getTimeout();
/* 272 */     if (timeout != null) {
/* 273 */       this.asyncWebRequest.setTimeout(timeout);
/*     */     }
/*     */     
/* 276 */     AsyncTaskExecutor executor = webAsyncTask.getExecutor();
/* 277 */     if (executor != null) {
/* 278 */       this.taskExecutor = executor;
/*     */     }
/*     */     
/* 281 */     List<CallableProcessingInterceptor> interceptors = new ArrayList();
/* 282 */     interceptors.add(webAsyncTask.getInterceptor());
/* 283 */     interceptors.addAll(this.callableInterceptors.values());
/* 284 */     interceptors.add(timeoutCallableInterceptor);
/*     */     
/* 286 */     final Callable<?> callable = webAsyncTask.getCallable();
/* 287 */     final CallableInterceptorChain interceptorChain = new CallableInterceptorChain(interceptors);
/*     */     
/* 289 */     this.asyncWebRequest.addTimeoutHandler(new Runnable()
/*     */     {
/*     */       public void run() {
/* 292 */         WebAsyncManager.logger.debug("Processing timeout");
/* 293 */         Object result = interceptorChain.triggerAfterTimeout(WebAsyncManager.this.asyncWebRequest, callable);
/* 294 */         if (result != CallableProcessingInterceptor.RESULT_NONE) {
/* 295 */           WebAsyncManager.this.setConcurrentResultAndDispatch(result);
/*     */         }
/*     */         
/*     */       }
/* 299 */     });
/* 300 */     this.asyncWebRequest.addCompletionHandler(new Runnable()
/*     */     {
/*     */       public void run() {
/* 303 */         interceptorChain.triggerAfterCompletion(WebAsyncManager.this.asyncWebRequest, callable);
/*     */       }
/*     */       
/* 306 */     });
/* 307 */     interceptorChain.applyBeforeConcurrentHandling(this.asyncWebRequest, callable);
/* 308 */     startAsyncProcessing(processingContext);
/*     */     try {
/* 310 */       this.taskExecutor.submit(new Runnable()
/*     */       {
/*     */         public void run() {
/* 313 */           Object result = null;
/*     */           try {
/* 315 */             interceptorChain.applyPreProcess(WebAsyncManager.this.asyncWebRequest, callable);
/* 316 */             result = callable.call();
/*     */           }
/*     */           catch (Throwable ex) {
/* 319 */             result = ex;
/*     */           }
/*     */           finally {
/* 322 */             result = interceptorChain.applyPostProcess(WebAsyncManager.this.asyncWebRequest, callable, result);
/*     */           }
/* 324 */           WebAsyncManager.this.setConcurrentResultAndDispatch(result);
/*     */         }
/*     */       });
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 329 */       Object result = interceptorChain.applyPostProcess(this.asyncWebRequest, callable, ex);
/* 330 */       setConcurrentResultAndDispatch(result);
/* 331 */       throw ex;
/*     */     }
/*     */   }
/*     */   
/*     */   private void setConcurrentResultAndDispatch(Object result) {
/* 336 */     synchronized (this) {
/* 337 */       if (hasConcurrentResult()) {
/* 338 */         return;
/*     */       }
/* 340 */       this.concurrentResult = result;
/*     */     }
/*     */     
/* 343 */     if (this.asyncWebRequest.isAsyncComplete()) {
/* 344 */       logger.error("Could not complete async processing due to timeout or network error");
/* 345 */       return;
/*     */     }
/*     */     
/* 348 */     if (logger.isDebugEnabled()) {
/* 349 */       logger.debug("Concurrent result value [" + this.concurrentResult + "] - dispatching request to resume processing");
/*     */     }
/*     */     
/*     */ 
/* 353 */     this.asyncWebRequest.dispatch();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void startDeferredResultProcessing(final DeferredResult<?> deferredResult, Object... processingContext)
/*     */     throws Exception
/*     */   {
/* 373 */     Assert.notNull(deferredResult, "DeferredResult must not be null");
/* 374 */     Assert.state(this.asyncWebRequest != null, "AsyncWebRequest must not be null");
/*     */     
/* 376 */     Long timeout = deferredResult.getTimeoutValue();
/* 377 */     if (timeout != null) {
/* 378 */       this.asyncWebRequest.setTimeout(timeout);
/*     */     }
/*     */     
/* 381 */     List<DeferredResultProcessingInterceptor> interceptors = new ArrayList();
/* 382 */     interceptors.add(deferredResult.getInterceptor());
/* 383 */     interceptors.addAll(this.deferredResultInterceptors.values());
/* 384 */     interceptors.add(timeoutDeferredResultInterceptor);
/*     */     
/* 386 */     final DeferredResultInterceptorChain interceptorChain = new DeferredResultInterceptorChain(interceptors);
/*     */     
/* 388 */     this.asyncWebRequest.addTimeoutHandler(new Runnable()
/*     */     {
/*     */       public void run() {
/*     */         try {
/* 392 */           interceptorChain.triggerAfterTimeout(WebAsyncManager.this.asyncWebRequest, deferredResult);
/*     */         }
/*     */         catch (Throwable ex) {
/* 395 */           WebAsyncManager.this.setConcurrentResultAndDispatch(ex);
/*     */         }
/*     */         
/*     */       }
/* 399 */     });
/* 400 */     this.asyncWebRequest.addCompletionHandler(new Runnable()
/*     */     {
/*     */       public void run() {
/* 403 */         interceptorChain.triggerAfterCompletion(WebAsyncManager.this.asyncWebRequest, deferredResult);
/*     */       }
/*     */       
/* 406 */     });
/* 407 */     interceptorChain.applyBeforeConcurrentHandling(this.asyncWebRequest, deferredResult);
/* 408 */     startAsyncProcessing(processingContext);
/*     */     try
/*     */     {
/* 411 */       interceptorChain.applyPreProcess(this.asyncWebRequest, deferredResult);
/* 412 */       deferredResult.setResultHandler(new DeferredResult.DeferredResultHandler()
/*     */       {
/*     */         public void handleResult(Object result) {
/* 415 */           result = interceptorChain.applyPostProcess(WebAsyncManager.this.asyncWebRequest, deferredResult, result);
/* 416 */           WebAsyncManager.this.setConcurrentResultAndDispatch(result);
/*     */         }
/*     */       });
/*     */     }
/*     */     catch (Throwable ex) {
/* 421 */       setConcurrentResultAndDispatch(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private void startAsyncProcessing(Object[] processingContext) {
/* 426 */     clearConcurrentResult();
/* 427 */     this.concurrentResultContext = processingContext;
/* 428 */     this.asyncWebRequest.startAsync();
/*     */     
/* 430 */     if (logger.isDebugEnabled()) {
/* 431 */       HttpServletRequest request = (HttpServletRequest)this.asyncWebRequest.getNativeRequest(HttpServletRequest.class);
/* 432 */       String requestUri = urlPathHelper.getRequestUri(request);
/* 433 */       logger.debug("Concurrent handling starting for " + request.getMethod() + " [" + requestUri + "]");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\context\request\async\WebAsyncManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */