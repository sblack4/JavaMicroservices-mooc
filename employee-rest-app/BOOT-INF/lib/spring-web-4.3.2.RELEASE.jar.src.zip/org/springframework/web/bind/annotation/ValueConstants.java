package org.springframework.web.bind.annotation;

public abstract interface ValueConstants
{
  public static final String DEFAULT_NONE = "\n\t\t\n\t\t\n\n\t\t\t\t\n";
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\bind\annotation\ValueConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */