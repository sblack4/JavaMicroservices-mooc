/*     */ package org.springframework.web.method.annotation;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.ServletException;
/*     */ import org.springframework.beans.ConversionNotSupportedException;
/*     */ import org.springframework.beans.TypeMismatchException;
/*     */ import org.springframework.beans.factory.config.BeanExpressionContext;
/*     */ import org.springframework.beans.factory.config.BeanExpressionResolver;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.web.bind.ServletRequestBindingException;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.RequestScope;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractNamedValueMethodArgumentResolver
/*     */   implements HandlerMethodArgumentResolver
/*     */ {
/*     */   private final ConfigurableBeanFactory configurableBeanFactory;
/*     */   private final BeanExpressionContext expressionContext;
/*  66 */   private final Map<MethodParameter, NamedValueInfo> namedValueInfoCache = new ConcurrentHashMap(256);
/*     */   
/*     */   public AbstractNamedValueMethodArgumentResolver()
/*     */   {
/*  70 */     this.configurableBeanFactory = null;
/*  71 */     this.expressionContext = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractNamedValueMethodArgumentResolver(ConfigurableBeanFactory beanFactory)
/*     */   {
/*  80 */     this.configurableBeanFactory = beanFactory;
/*  81 */     this.expressionContext = (beanFactory != null ? new BeanExpressionContext(beanFactory, new RequestScope()) : null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*     */     throws Exception
/*     */   {
/*  89 */     NamedValueInfo namedValueInfo = getNamedValueInfo(parameter);
/*  90 */     MethodParameter nestedParameter = parameter.nestedIfOptional();
/*     */     
/*  92 */     Object resolvedName = resolveStringValue(namedValueInfo.name);
/*  93 */     if (resolvedName == null)
/*     */     {
/*  95 */       throw new IllegalArgumentException("Specified name must not resolve to null: [" + namedValueInfo.name + "]");
/*     */     }
/*     */     
/*  98 */     Object arg = resolveName(resolvedName.toString(), nestedParameter, webRequest);
/*  99 */     if (arg == null) {
/* 100 */       if (namedValueInfo.defaultValue != null) {
/* 101 */         arg = resolveStringValue(namedValueInfo.defaultValue);
/*     */       }
/* 103 */       else if ((namedValueInfo.required) && (!nestedParameter.isOptional())) {
/* 104 */         handleMissingValue(namedValueInfo.name, nestedParameter, webRequest);
/*     */       }
/* 106 */       arg = handleNullValue(namedValueInfo.name, arg, nestedParameter.getNestedParameterType());
/*     */     }
/* 108 */     else if (("".equals(arg)) && (namedValueInfo.defaultValue != null)) {
/* 109 */       arg = resolveStringValue(namedValueInfo.defaultValue);
/*     */     }
/*     */     
/* 112 */     if (binderFactory != null) {
/* 113 */       WebDataBinder binder = binderFactory.createBinder(webRequest, null, namedValueInfo.name);
/*     */       try {
/* 115 */         arg = binder.convertIfNecessary(arg, parameter.getParameterType(), parameter);
/*     */       }
/*     */       catch (ConversionNotSupportedException ex)
/*     */       {
/* 119 */         throw new MethodArgumentConversionNotSupportedException(arg, ex.getRequiredType(), namedValueInfo.name, parameter, ex.getCause());
/*     */       }
/*     */       catch (TypeMismatchException ex)
/*     */       {
/* 123 */         throw new MethodArgumentTypeMismatchException(arg, ex.getRequiredType(), namedValueInfo.name, parameter, ex.getCause());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 128 */     handleResolvedValue(arg, namedValueInfo.name, parameter, mavContainer, webRequest);
/*     */     
/* 130 */     return arg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private NamedValueInfo getNamedValueInfo(MethodParameter parameter)
/*     */   {
/* 137 */     NamedValueInfo namedValueInfo = (NamedValueInfo)this.namedValueInfoCache.get(parameter);
/* 138 */     if (namedValueInfo == null) {
/* 139 */       namedValueInfo = createNamedValueInfo(parameter);
/* 140 */       namedValueInfo = updateNamedValueInfo(parameter, namedValueInfo);
/* 141 */       this.namedValueInfoCache.put(parameter, namedValueInfo);
/*     */     }
/* 143 */     return namedValueInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract NamedValueInfo createNamedValueInfo(MethodParameter paramMethodParameter);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private NamedValueInfo updateNamedValueInfo(MethodParameter parameter, NamedValueInfo info)
/*     */   {
/* 158 */     String name = info.name;
/* 159 */     if (info.name.length() == 0) {
/* 160 */       name = parameter.getParameterName();
/* 161 */       if (name == null)
/*     */       {
/* 163 */         throw new IllegalArgumentException("Name for argument type [" + parameter.getNestedParameterType().getName() + "] not available, and parameter name information not found in class file either.");
/*     */       }
/*     */     }
/*     */     
/* 167 */     String defaultValue = "\n\t\t\n\t\t\n\n\t\t\t\t\n".equals(info.defaultValue) ? null : info.defaultValue;
/* 168 */     return new NamedValueInfo(name, info.required, defaultValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object resolveStringValue(String value)
/*     */   {
/* 176 */     if (this.configurableBeanFactory == null) {
/* 177 */       return value;
/*     */     }
/* 179 */     String placeholdersResolved = this.configurableBeanFactory.resolveEmbeddedValue(value);
/* 180 */     BeanExpressionResolver exprResolver = this.configurableBeanFactory.getBeanExpressionResolver();
/* 181 */     if (exprResolver == null) {
/* 182 */       return value;
/*     */     }
/* 184 */     return exprResolver.evaluate(placeholdersResolved, this.expressionContext);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract Object resolveName(String paramString, MethodParameter paramMethodParameter, NativeWebRequest paramNativeWebRequest)
/*     */     throws Exception;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void handleMissingValue(String name, MethodParameter parameter, NativeWebRequest request)
/*     */     throws Exception
/*     */   {
/* 208 */     handleMissingValue(name, parameter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void handleMissingValue(String name, MethodParameter parameter)
/*     */     throws ServletException
/*     */   {
/* 219 */     throw new ServletRequestBindingException("Missing argument '" + name + "' for method parameter of type " + parameter.getNestedParameterType().getSimpleName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private Object handleNullValue(String name, Object value, Class<?> paramType)
/*     */   {
/* 226 */     if (value == null) {
/* 227 */       if (Boolean.TYPE.equals(paramType)) {
/* 228 */         return Boolean.FALSE;
/*     */       }
/* 230 */       if (paramType.isPrimitive()) {
/* 231 */         throw new IllegalStateException("Optional " + paramType.getSimpleName() + " parameter '" + name + "' is present but cannot be translated into a null value due to being declared as a " + "primitive type. Consider declaring it as object wrapper for the corresponding primitive type.");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 236 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void handleResolvedValue(Object arg, String name, MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static class NamedValueInfo
/*     */   {
/*     */     private final String name;
/*     */     
/*     */ 
/*     */ 
/*     */     private final boolean required;
/*     */     
/*     */ 
/*     */ 
/*     */     private final String defaultValue;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public NamedValueInfo(String name, boolean required, String defaultValue)
/*     */     {
/* 264 */       this.name = name;
/* 265 */       this.required = required;
/* 266 */       this.defaultValue = defaultValue;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\method\annotation\AbstractNamedValueMethodArgumentResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */