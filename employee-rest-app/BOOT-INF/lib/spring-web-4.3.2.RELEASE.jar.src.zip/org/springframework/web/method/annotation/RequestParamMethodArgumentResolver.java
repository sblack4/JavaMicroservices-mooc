/*     */ package org.springframework.web.method.annotation;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.bind.MissingServletRequestParameterException;
/*     */ import org.springframework.web.bind.annotation.RequestParam;
/*     */ import org.springframework.web.bind.annotation.RequestPart;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.UriComponentsContributor;
/*     */ import org.springframework.web.multipart.MultipartException;
/*     */ import org.springframework.web.multipart.MultipartFile;
/*     */ import org.springframework.web.multipart.MultipartHttpServletRequest;
/*     */ import org.springframework.web.multipart.support.MissingServletRequestPartException;
/*     */ import org.springframework.web.multipart.support.MultipartResolutionDelegate;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RequestParamMethodArgumentResolver
/*     */   extends AbstractNamedValueMethodArgumentResolver
/*     */   implements UriComponentsContributor
/*     */ {
/*  77 */   private static final TypeDescriptor STRING_TYPE_DESCRIPTOR = TypeDescriptor.valueOf(String.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final boolean useDefaultResolution;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public RequestParamMethodArgumentResolver(boolean useDefaultResolution)
/*     */   {
/*  89 */     this.useDefaultResolution = useDefaultResolution;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RequestParamMethodArgumentResolver(ConfigurableBeanFactory beanFactory, boolean useDefaultResolution)
/*     */   {
/* 102 */     super(beanFactory);
/* 103 */     this.useDefaultResolution = useDefaultResolution;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/* 124 */     if (parameter.hasParameterAnnotation(RequestParam.class)) {
/* 125 */       if (Map.class.isAssignableFrom(parameter.nestedIfOptional().getNestedParameterType())) {
/* 126 */         String paramName = ((RequestParam)parameter.getParameterAnnotation(RequestParam.class)).name();
/* 127 */         return StringUtils.hasText(paramName);
/*     */       }
/*     */       
/* 130 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 134 */     if (parameter.hasParameterAnnotation(RequestPart.class)) {
/* 135 */       return false;
/*     */     }
/* 137 */     parameter = parameter.nestedIfOptional();
/* 138 */     if (MultipartResolutionDelegate.isMultipartArgument(parameter)) {
/* 139 */       return true;
/*     */     }
/* 141 */     if (this.useDefaultResolution) {
/* 142 */       return BeanUtils.isSimpleProperty(parameter.getNestedParameterType());
/*     */     }
/*     */     
/* 145 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected AbstractNamedValueMethodArgumentResolver.NamedValueInfo createNamedValueInfo(MethodParameter parameter)
/*     */   {
/* 152 */     RequestParam ann = (RequestParam)parameter.getParameterAnnotation(RequestParam.class);
/* 153 */     return ann != null ? new RequestParamNamedValueInfo(ann) : new RequestParamNamedValueInfo();
/*     */   }
/*     */   
/*     */   protected Object resolveName(String name, MethodParameter parameter, NativeWebRequest request) throws Exception
/*     */   {
/* 158 */     HttpServletRequest servletRequest = (HttpServletRequest)request.getNativeRequest(HttpServletRequest.class);
/*     */     
/* 160 */     MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest)WebUtils.getNativeRequest(servletRequest, MultipartHttpServletRequest.class);
/*     */     
/* 162 */     Object mpArg = MultipartResolutionDelegate.resolveMultipartArgument(name, parameter, servletRequest);
/* 163 */     if (mpArg != MultipartResolutionDelegate.UNRESOLVABLE) {
/* 164 */       return mpArg;
/*     */     }
/*     */     
/* 167 */     Object arg = null;
/* 168 */     if (multipartRequest != null) {
/* 169 */       List<MultipartFile> files = multipartRequest.getFiles(name);
/* 170 */       if (!files.isEmpty()) {
/* 171 */         arg = files.size() == 1 ? files.get(0) : files;
/*     */       }
/*     */     }
/* 174 */     if (arg == null) {
/* 175 */       String[] paramValues = request.getParameterValues(name);
/* 176 */       if (paramValues != null) {
/* 177 */         arg = paramValues.length == 1 ? paramValues[0] : paramValues;
/*     */       }
/*     */     }
/* 180 */     return arg;
/*     */   }
/*     */   
/*     */   protected void handleMissingValue(String name, MethodParameter parameter, NativeWebRequest request) throws Exception
/*     */   {
/* 185 */     HttpServletRequest servletRequest = (HttpServletRequest)request.getNativeRequest(HttpServletRequest.class);
/* 186 */     if (MultipartResolutionDelegate.isMultipartArgument(parameter)) {
/* 187 */       if (!MultipartResolutionDelegate.isMultipartRequest(servletRequest)) {
/* 188 */         throw new MultipartException("Current request is not a multipart request");
/*     */       }
/*     */       
/* 191 */       throw new MissingServletRequestPartException(name);
/*     */     }
/*     */     
/*     */ 
/* 195 */     throw new MissingServletRequestParameterException(name, parameter.getNestedParameterType().getSimpleName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void contributeMethodArgument(MethodParameter parameter, Object value, UriComponentsBuilder builder, Map<String, Object> uriVariables, ConversionService conversionService)
/*     */   {
/* 203 */     Class<?> paramType = parameter.getNestedParameterType();
/* 204 */     if ((Map.class.isAssignableFrom(paramType)) || (MultipartFile.class == paramType) || 
/* 205 */       ("javax.servlet.http.Part".equals(paramType.getName()))) {
/* 206 */       return;
/*     */     }
/*     */     
/* 209 */     RequestParam requestParam = (RequestParam)parameter.getParameterAnnotation(RequestParam.class);
/*     */     
/* 211 */     String name = (requestParam == null) || (StringUtils.isEmpty(requestParam.name())) ? parameter.getParameterName() : requestParam.name();
/*     */     
/* 213 */     if (value == null) {
/* 214 */       if ((requestParam != null) && (
/* 215 */         (!requestParam.required()) || (!requestParam.defaultValue().equals("\n\t\t\n\t\t\n\n\t\t\t\t\n")))) {
/* 216 */         return;
/*     */       }
/*     */       
/* 219 */       builder.queryParam(name, new Object[0]);
/*     */     }
/* 221 */     else if ((value instanceof Collection)) {
/* 222 */       for (Object element : (Collection)value) {
/* 223 */         element = formatUriValue(conversionService, TypeDescriptor.nested(parameter, 1), element);
/* 224 */         builder.queryParam(name, new Object[] { element });
/*     */       }
/*     */     }
/*     */     else {
/* 228 */       builder.queryParam(name, new Object[] { formatUriValue(conversionService, new TypeDescriptor(parameter), value) });
/*     */     }
/*     */   }
/*     */   
/*     */   protected String formatUriValue(ConversionService cs, TypeDescriptor sourceType, Object value) {
/* 233 */     if (value == null) {
/* 234 */       return null;
/*     */     }
/* 236 */     if ((value instanceof String)) {
/* 237 */       return (String)value;
/*     */     }
/* 239 */     if (cs != null) {
/* 240 */       return (String)cs.convert(value, sourceType, STRING_TYPE_DESCRIPTOR);
/*     */     }
/*     */     
/* 243 */     return value.toString();
/*     */   }
/*     */   
/*     */   private static class RequestParamNamedValueInfo
/*     */     extends AbstractNamedValueMethodArgumentResolver.NamedValueInfo
/*     */   {
/*     */     public RequestParamNamedValueInfo()
/*     */     {
/* 251 */       super(false, "\n\t\t\n\t\t\n\n\t\t\t\t\n");
/*     */     }
/*     */     
/*     */     public RequestParamNamedValueInfo(RequestParam annotation) {
/* 255 */       super(annotation.required(), annotation.defaultValue());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\method\annotation\RequestParamMethodArgumentResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */