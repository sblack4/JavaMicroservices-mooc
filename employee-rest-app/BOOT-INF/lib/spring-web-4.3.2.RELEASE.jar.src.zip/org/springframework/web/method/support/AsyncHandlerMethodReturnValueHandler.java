package org.springframework.web.method.support;

import org.springframework.core.MethodParameter;

public abstract interface AsyncHandlerMethodReturnValueHandler
  extends HandlerMethodReturnValueHandler
{
  public abstract boolean isAsyncReturnValue(Object paramObject, MethodParameter paramMethodParameter);
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\method\support\AsyncHandlerMethodReturnValueHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */