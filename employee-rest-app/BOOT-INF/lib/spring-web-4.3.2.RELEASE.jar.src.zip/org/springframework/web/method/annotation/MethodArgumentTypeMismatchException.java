/*    */ package org.springframework.web.method.annotation;
/*    */ 
/*    */ import org.springframework.beans.TypeMismatchException;
/*    */ import org.springframework.core.MethodParameter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodArgumentTypeMismatchException
/*    */   extends TypeMismatchException
/*    */ {
/*    */   private final String name;
/*    */   private final MethodParameter parameter;
/*    */   
/*    */   public MethodArgumentTypeMismatchException(Object value, Class<?> requiredType, String name, MethodParameter param, Throwable cause)
/*    */   {
/* 41 */     super(value, requiredType, cause);
/* 42 */     this.name = name;
/* 43 */     this.parameter = param;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getName()
/*    */   {
/* 51 */     return this.name;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public MethodParameter getParameter()
/*    */   {
/* 58 */     return this.parameter;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\method\annotation\MethodArgumentTypeMismatchException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */