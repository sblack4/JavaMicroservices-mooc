/*     */ package org.springframework.web.method.annotation;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.bind.annotation.SessionAttributes;
/*     */ import org.springframework.web.bind.support.SessionAttributeStore;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionAttributesHandler
/*     */ {
/*  50 */   private final Set<String> attributeNames = new HashSet();
/*     */   
/*  52 */   private final Set<Class<?>> attributeTypes = new HashSet();
/*     */   
/*     */ 
/*  55 */   private final Set<String> knownAttributeNames = Collections.newSetFromMap(new ConcurrentHashMap(4));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final SessionAttributeStore sessionAttributeStore;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SessionAttributesHandler(Class<?> handlerType, SessionAttributeStore sessionAttributeStore)
/*     */   {
/*  68 */     Assert.notNull(sessionAttributeStore, "SessionAttributeStore may not be null");
/*  69 */     this.sessionAttributeStore = sessionAttributeStore;
/*     */     
/*     */ 
/*  72 */     SessionAttributes annotation = (SessionAttributes)AnnotatedElementUtils.findMergedAnnotation(handlerType, SessionAttributes.class);
/*  73 */     if (annotation != null) {
/*  74 */       this.attributeNames.addAll(Arrays.asList(annotation.names()));
/*  75 */       this.attributeTypes.addAll(Arrays.asList(annotation.types()));
/*     */     }
/*     */     
/*  78 */     for (String attributeName : this.attributeNames) {
/*  79 */       this.knownAttributeNames.add(attributeName);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasSessionAttributes()
/*     */   {
/*  88 */     return (this.attributeNames.size() > 0) || (this.attributeTypes.size() > 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isHandlerSessionAttribute(String attributeName, Class<?> attributeType)
/*     */   {
/* 103 */     Assert.notNull(attributeName, "Attribute name must not be null");
/* 104 */     if ((this.attributeNames.contains(attributeName)) || (this.attributeTypes.contains(attributeType))) {
/* 105 */       this.knownAttributeNames.add(attributeName);
/* 106 */       return true;
/*     */     }
/*     */     
/* 109 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void storeAttributes(WebRequest request, Map<String, ?> attributes)
/*     */   {
/* 120 */     for (String name : attributes.keySet()) {
/* 121 */       Object value = attributes.get(name);
/* 122 */       Class<?> attrType = value != null ? value.getClass() : null;
/*     */       
/* 124 */       if (isHandlerSessionAttribute(name, attrType)) {
/* 125 */         this.sessionAttributeStore.storeAttribute(request, name, value);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, Object> retrieveAttributes(WebRequest request)
/*     */   {
/* 138 */     Map<String, Object> attributes = new HashMap();
/* 139 */     for (String name : this.knownAttributeNames) {
/* 140 */       Object value = this.sessionAttributeStore.retrieveAttribute(request, name);
/* 141 */       if (value != null) {
/* 142 */         attributes.put(name, value);
/*     */       }
/*     */     }
/* 145 */     return attributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void cleanupAttributes(WebRequest request)
/*     */   {
/* 155 */     for (String attributeName : this.knownAttributeNames) {
/* 156 */       this.sessionAttributeStore.cleanupAttribute(request, attributeName);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Object retrieveAttribute(WebRequest request, String attributeName)
/*     */   {
/* 167 */     return this.sessionAttributeStore.retrieveAttribute(request, attributeName);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\method\annotation\SessionAttributesHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */