/*     */ package org.springframework.web.method.support;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InvocableHandlerMethod
/*     */   extends HandlerMethod
/*     */ {
/*     */   private WebDataBinderFactory dataBinderFactory;
/*  52 */   private HandlerMethodArgumentResolverComposite argumentResolvers = new HandlerMethodArgumentResolverComposite();
/*     */   
/*  54 */   private ParameterNameDiscoverer parameterNameDiscoverer = new DefaultParameterNameDiscoverer();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public InvocableHandlerMethod(HandlerMethod handlerMethod)
/*     */   {
/*  61 */     super(handlerMethod);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public InvocableHandlerMethod(Object bean, Method method)
/*     */   {
/*  68 */     super(bean, method);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InvocableHandlerMethod(Object bean, String methodName, Class<?>... parameterTypes)
/*     */     throws NoSuchMethodException
/*     */   {
/*  81 */     super(bean, methodName, parameterTypes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDataBinderFactory(WebDataBinderFactory dataBinderFactory)
/*     */   {
/*  91 */     this.dataBinderFactory = dataBinderFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setHandlerMethodArgumentResolvers(HandlerMethodArgumentResolverComposite argumentResolvers)
/*     */   {
/*  98 */     this.argumentResolvers = argumentResolvers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParameterNameDiscoverer(ParameterNameDiscoverer parameterNameDiscoverer)
/*     */   {
/* 107 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invokeForRequest(NativeWebRequest request, ModelAndViewContainer mavContainer, Object... providedArgs)
/*     */     throws Exception
/*     */   {
/* 128 */     Object[] args = getMethodArgumentValues(request, mavContainer, providedArgs);
/* 129 */     if (this.logger.isTraceEnabled()) {
/* 130 */       StringBuilder sb = new StringBuilder("Invoking [");
/* 131 */       sb.append(getBeanType().getSimpleName()).append(".");
/* 132 */       sb.append(getMethod().getName()).append("] method with arguments ");
/* 133 */       sb.append(Arrays.asList(args));
/* 134 */       this.logger.trace(sb.toString());
/*     */     }
/* 136 */     Object returnValue = doInvoke(args);
/* 137 */     if (this.logger.isTraceEnabled()) {
/* 138 */       this.logger.trace("Method [" + getMethod().getName() + "] returned [" + returnValue + "]");
/*     */     }
/* 140 */     return returnValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object[] getMethodArgumentValues(NativeWebRequest request, ModelAndViewContainer mavContainer, Object... providedArgs)
/*     */     throws Exception
/*     */   {
/* 149 */     MethodParameter[] parameters = getMethodParameters();
/* 150 */     Object[] args = new Object[parameters.length];
/* 151 */     for (int i = 0; i < parameters.length; i++) {
/* 152 */       MethodParameter parameter = parameters[i];
/* 153 */       parameter.initParameterNameDiscovery(this.parameterNameDiscoverer);
/* 154 */       GenericTypeResolver.resolveParameterType(parameter, getBean().getClass());
/* 155 */       args[i] = resolveProvidedArgument(parameter, providedArgs);
/* 156 */       if (args[i] == null)
/*     */       {
/*     */ 
/* 159 */         if (this.argumentResolvers.supportsParameter(parameter)) {
/*     */           try {
/* 161 */             args[i] = this.argumentResolvers.resolveArgument(parameter, mavContainer, request, this.dataBinderFactory);
/*     */ 
/*     */           }
/*     */           catch (Exception ex)
/*     */           {
/* 166 */             if (this.logger.isDebugEnabled()) {
/* 167 */               this.logger.debug(getArgumentResolutionErrorMessage("Error resolving argument", i), ex);
/*     */             }
/* 169 */             throw ex;
/*     */           }
/*     */         }
/* 172 */         else if (args[i] == null) {
/* 173 */           String msg = getArgumentResolutionErrorMessage("No suitable resolver for argument", i);
/* 174 */           throw new IllegalStateException(msg);
/*     */         } }
/*     */     }
/* 177 */     return args;
/*     */   }
/*     */   
/*     */   private String getArgumentResolutionErrorMessage(String message, int index) {
/* 181 */     MethodParameter param = getMethodParameters()[index];
/* 182 */     message = message + " [" + index + "] [type=" + param.getParameterType().getName() + "]";
/* 183 */     return getDetailedErrorMessage(message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDetailedErrorMessage(String message)
/*     */   {
/* 192 */     StringBuilder sb = new StringBuilder(message).append("\n");
/* 193 */     sb.append("HandlerMethod details: \n");
/* 194 */     sb.append("Controller [").append(getBeanType().getName()).append("]\n");
/* 195 */     sb.append("Method [").append(getBridgedMethod().toGenericString()).append("]\n");
/* 196 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private Object resolveProvidedArgument(MethodParameter parameter, Object... providedArgs)
/*     */   {
/* 203 */     if (providedArgs == null) {
/* 204 */       return null;
/*     */     }
/* 206 */     for (Object providedArg : providedArgs) {
/* 207 */       if (parameter.getParameterType().isInstance(providedArg)) {
/* 208 */         return providedArg;
/*     */       }
/*     */     }
/* 211 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Object doInvoke(Object... args)
/*     */     throws Exception
/*     */   {
/* 219 */     ReflectionUtils.makeAccessible(getBridgedMethod());
/*     */     try {
/* 221 */       return getBridgedMethod().invoke(getBean(), args);
/*     */     }
/*     */     catch (IllegalArgumentException ex) {
/* 224 */       assertTargetBean(getBridgedMethod(), getBean(), args);
/* 225 */       String message = ex.getMessage() != null ? ex.getMessage() : "Illegal argument";
/* 226 */       throw new IllegalStateException(getInvocationErrorMessage(message, args), ex);
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 230 */       Throwable targetException = ex.getTargetException();
/* 231 */       if ((targetException instanceof RuntimeException)) {
/* 232 */         throw ((RuntimeException)targetException);
/*     */       }
/* 234 */       if ((targetException instanceof Error)) {
/* 235 */         throw ((Error)targetException);
/*     */       }
/* 237 */       if ((targetException instanceof Exception)) {
/* 238 */         throw ((Exception)targetException);
/*     */       }
/*     */       
/* 241 */       String msg = getInvocationErrorMessage("Failed to invoke controller method", args);
/* 242 */       throw new IllegalStateException(msg, targetException);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void assertTargetBean(Method method, Object targetBean, Object[] args)
/*     */   {
/* 255 */     Class<?> methodDeclaringClass = method.getDeclaringClass();
/* 256 */     Class<?> targetBeanClass = targetBean.getClass();
/* 257 */     if (!methodDeclaringClass.isAssignableFrom(targetBeanClass))
/*     */     {
/*     */ 
/* 260 */       String msg = "The mapped controller method class '" + methodDeclaringClass.getName() + "' is not an instance of the actual controller bean class '" + targetBeanClass.getName() + "'. If the controller requires proxying " + "(e.g. due to @Transactional), please use class-based proxying.";
/*     */       
/* 262 */       throw new IllegalStateException(getInvocationErrorMessage(msg, args));
/*     */     }
/*     */   }
/*     */   
/*     */   private String getInvocationErrorMessage(String message, Object[] resolvedArgs) {
/* 267 */     StringBuilder sb = new StringBuilder(getDetailedErrorMessage(message));
/* 268 */     sb.append("Resolved arguments: \n");
/* 269 */     for (int i = 0; i < resolvedArgs.length; i++) {
/* 270 */       sb.append("[").append(i).append("] ");
/* 271 */       if (resolvedArgs[i] == null) {
/* 272 */         sb.append("[null] \n");
/*     */       }
/*     */       else {
/* 275 */         sb.append("[type=").append(resolvedArgs[i].getClass().getName()).append("] ");
/* 276 */         sb.append("[value=").append(resolvedArgs[i]).append("]\n");
/*     */       }
/*     */     }
/* 279 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\method\support\InvocableHandlerMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */