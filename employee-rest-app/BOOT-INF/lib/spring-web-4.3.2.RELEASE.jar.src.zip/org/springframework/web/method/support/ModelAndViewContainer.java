/*     */ package org.springframework.web.method.support;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.validation.support.BindingAwareModelMap;
/*     */ import org.springframework.web.bind.support.SessionStatus;
/*     */ import org.springframework.web.bind.support.SimpleSessionStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelAndViewContainer
/*     */ {
/*  50 */   private boolean ignoreDefaultModelOnRedirect = false;
/*     */   
/*     */   private Object view;
/*     */   
/*  54 */   private final ModelMap defaultModel = new BindingAwareModelMap();
/*     */   
/*     */   private ModelMap redirectModel;
/*     */   
/*  58 */   private boolean redirectModelScenario = false;
/*     */   
/*     */ 
/*  61 */   private final Set<String> bindingDisabledAttributes = new HashSet(4);
/*     */   
/*     */   private HttpStatus status;
/*     */   
/*  65 */   private final SessionStatus sessionStatus = new SimpleSessionStatus();
/*     */   
/*  67 */   private boolean requestHandled = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIgnoreDefaultModelOnRedirect(boolean ignoreDefaultModelOnRedirect)
/*     */   {
/*  83 */     this.ignoreDefaultModelOnRedirect = ignoreDefaultModelOnRedirect;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setViewName(String viewName)
/*     */   {
/*  91 */     this.view = viewName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getViewName()
/*     */   {
/*  99 */     return (this.view instanceof String) ? (String)this.view : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setView(Object view)
/*     */   {
/* 107 */     this.view = view;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getView()
/*     */   {
/* 115 */     return this.view;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isViewReference()
/*     */   {
/* 123 */     return this.view instanceof String;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModelMap getModel()
/*     */   {
/* 133 */     if (useDefaultModel()) {
/* 134 */       return this.defaultModel;
/*     */     }
/*     */     
/* 137 */     if (this.redirectModel == null) {
/* 138 */       this.redirectModel = new ModelMap();
/*     */     }
/* 140 */     return this.redirectModel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBindingDisabled(String attributeName)
/*     */   {
/* 151 */     this.bindingDisabledAttributes.add(attributeName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBindingDisabled(String name)
/*     */   {
/* 159 */     return this.bindingDisabledAttributes.contains(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean useDefaultModel()
/*     */   {
/* 166 */     return (!this.redirectModelScenario) || ((this.redirectModel == null) && (!this.ignoreDefaultModelOnRedirect));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModelMap getDefaultModel()
/*     */   {
/* 180 */     return this.defaultModel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRedirectModel(ModelMap redirectModel)
/*     */   {
/* 190 */     this.redirectModel = redirectModel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRedirectModelScenario(boolean redirectModelScenario)
/*     */   {
/* 198 */     this.redirectModelScenario = redirectModelScenario;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SessionStatus getSessionStatus()
/*     */   {
/* 206 */     return this.sessionStatus;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStatus(HttpStatus status)
/*     */   {
/* 215 */     this.status = status;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpStatus getStatus()
/*     */   {
/* 223 */     return this.status;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRequestHandled(boolean requestHandled)
/*     */   {
/* 234 */     this.requestHandled = requestHandled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isRequestHandled()
/*     */   {
/* 241 */     return this.requestHandled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModelAndViewContainer addAttribute(String name, Object value)
/*     */   {
/* 249 */     getModel().addAttribute(name, value);
/* 250 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModelAndViewContainer addAttribute(Object value)
/*     */   {
/* 258 */     getModel().addAttribute(value);
/* 259 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModelAndViewContainer addAllAttributes(Map<String, ?> attributes)
/*     */   {
/* 267 */     getModel().addAllAttributes(attributes);
/* 268 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModelAndViewContainer mergeAttributes(Map<String, ?> attributes)
/*     */   {
/* 277 */     getModel().mergeAttributes(attributes);
/* 278 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ModelAndViewContainer removeAttributes(Map<String, ?> attributes)
/*     */   {
/* 285 */     if (attributes != null) {
/* 286 */       for (String key : attributes.keySet()) {
/* 287 */         getModel().remove(key);
/*     */       }
/*     */     }
/* 290 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsAttribute(String name)
/*     */   {
/* 298 */     return getModel().containsAttribute(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 307 */     StringBuilder sb = new StringBuilder("ModelAndViewContainer: ");
/* 308 */     if (!isRequestHandled()) {
/* 309 */       if (isViewReference()) {
/* 310 */         sb.append("reference to view with name '").append(this.view).append("'");
/*     */       }
/*     */       else {
/* 313 */         sb.append("View is [").append(this.view).append(']');
/*     */       }
/* 315 */       if (useDefaultModel()) {
/* 316 */         sb.append("; default model ");
/*     */       }
/*     */       else {
/* 319 */         sb.append("; redirect model ");
/*     */       }
/* 321 */       sb.append(getModel());
/*     */     }
/*     */     else {
/* 324 */       sb.append("Request handled directly");
/*     */     }
/* 326 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\method\support\ModelAndViewContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */