/*     */ package org.springframework.web.method.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.core.ExceptionDepthComparator;
/*     */ import org.springframework.core.MethodIntrospector;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils.MethodFilter;
/*     */ import org.springframework.web.bind.annotation.ExceptionHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExceptionHandlerMethodResolver
/*     */ {
/*  49 */   public static final ReflectionUtils.MethodFilter EXCEPTION_HANDLER_METHODS = new ReflectionUtils.MethodFilter()
/*     */   {
/*     */     public boolean matches(Method method) {
/*  52 */       return AnnotationUtils.findAnnotation(method, ExceptionHandler.class) != null;
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  59 */   private static final Method NO_METHOD_FOUND = ClassUtils.getMethodIfAvailable(System.class, "currentTimeMillis", new Class[0]);
/*     */   
/*     */ 
/*  62 */   private final Map<Class<? extends Throwable>, Method> mappedMethods = new ConcurrentHashMap(16);
/*     */   
/*     */ 
/*  65 */   private final Map<Class<? extends Throwable>, Method> exceptionLookupCache = new ConcurrentHashMap(16);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExceptionHandlerMethodResolver(Class<?> handlerType)
/*     */   {
/*  74 */     for (Iterator localIterator1 = MethodIntrospector.selectMethods(handlerType, EXCEPTION_HANDLER_METHODS).iterator(); localIterator1.hasNext();) { method = (Method)localIterator1.next();
/*  75 */       for (Class<? extends Throwable> exceptionType : detectExceptionMappings(method)) {
/*  76 */         addExceptionMapping(exceptionType, method);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     Method method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private List<Class<? extends Throwable>> detectExceptionMappings(Method method)
/*     */   {
/*  88 */     List<Class<? extends Throwable>> result = new ArrayList();
/*  89 */     detectAnnotationExceptionMappings(method, result);
/*  90 */     if (result.isEmpty()) {
/*  91 */       for (Class<?> paramType : method.getParameterTypes()) {
/*  92 */         if (Throwable.class.isAssignableFrom(paramType)) {
/*  93 */           result.add(paramType);
/*     */         }
/*     */       }
/*     */     }
/*  97 */     Assert.notEmpty(result, "No exception types mapped to {" + method + "}");
/*  98 */     return result;
/*     */   }
/*     */   
/*     */   protected void detectAnnotationExceptionMappings(Method method, List<Class<? extends Throwable>> result) {
/* 102 */     ExceptionHandler ann = (ExceptionHandler)AnnotationUtils.findAnnotation(method, ExceptionHandler.class);
/* 103 */     result.addAll(Arrays.asList(ann.value()));
/*     */   }
/*     */   
/*     */   private void addExceptionMapping(Class<? extends Throwable> exceptionType, Method method) {
/* 107 */     Method oldMethod = (Method)this.mappedMethods.put(exceptionType, method);
/* 108 */     if ((oldMethod != null) && (!oldMethod.equals(method))) {
/* 109 */       throw new IllegalStateException("Ambiguous @ExceptionHandler method mapped for [" + exceptionType + "]: {" + oldMethod + ", " + method + "}");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasExceptionMappings()
/*     */   {
/* 118 */     return !this.mappedMethods.isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Method resolveMethod(Exception exception)
/*     */   {
/* 128 */     Method method = resolveMethodByExceptionType(exception.getClass());
/* 129 */     if (method == null) {
/* 130 */       Throwable cause = exception.getCause();
/* 131 */       if (cause != null) {
/* 132 */         method = resolveMethodByExceptionType(cause.getClass());
/*     */       }
/*     */     }
/* 135 */     return method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Method resolveMethodByExceptionType(Class<? extends Throwable> exceptionType)
/*     */   {
/* 145 */     Method method = (Method)this.exceptionLookupCache.get(exceptionType);
/* 146 */     if (method == null) {
/* 147 */       method = getMappedMethod(exceptionType);
/* 148 */       this.exceptionLookupCache.put(exceptionType, method != null ? method : NO_METHOD_FOUND);
/*     */     }
/* 150 */     return method != NO_METHOD_FOUND ? method : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private Method getMappedMethod(Class<? extends Throwable> exceptionType)
/*     */   {
/* 157 */     List<Class<? extends Throwable>> matches = new ArrayList();
/* 158 */     for (Class<? extends Throwable> mappedException : this.mappedMethods.keySet()) {
/* 159 */       if (mappedException.isAssignableFrom(exceptionType)) {
/* 160 */         matches.add(mappedException);
/*     */       }
/*     */     }
/* 163 */     if (!matches.isEmpty()) {
/* 164 */       Collections.sort(matches, new ExceptionDepthComparator(exceptionType));
/* 165 */       return (Method)this.mappedMethods.get(matches.get(0));
/*     */     }
/*     */     
/* 168 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\method\annotation\ExceptionHandlerMethodResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */