/*     */ package org.springframework.web.method.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.validation.annotation.Validated;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.bind.annotation.ModelAttribute;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.bind.support.WebRequestDataBinder;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelAttributeMethodProcessor
/*     */   implements HandlerMethodArgumentResolver, HandlerMethodReturnValueHandler
/*     */ {
/*  60 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final boolean annotationNotRequired;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModelAttributeMethodProcessor(boolean annotationNotRequired)
/*     */   {
/*  72 */     this.annotationNotRequired = annotationNotRequired;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/*  84 */     return (parameter.hasParameterAnnotation(ModelAttribute.class)) || ((this.annotationNotRequired) && (!BeanUtils.isSimpleProperty(parameter.getParameterType())));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*     */     throws Exception
/*     */   {
/* 100 */     String name = ModelFactory.getNameForParameter(parameter);
/*     */     
/* 102 */     Object attribute = mavContainer.containsAttribute(name) ? mavContainer.getModel().get(name) : createAttribute(name, parameter, binderFactory, webRequest);
/*     */     
/* 104 */     if (!mavContainer.isBindingDisabled(name)) {
/* 105 */       ModelAttribute ann = (ModelAttribute)parameter.getParameterAnnotation(ModelAttribute.class);
/* 106 */       if ((ann != null) && (!ann.binding())) {
/* 107 */         mavContainer.setBindingDisabled(name);
/*     */       }
/*     */     }
/*     */     
/* 111 */     WebDataBinder binder = binderFactory.createBinder(webRequest, attribute, name);
/* 112 */     if (binder.getTarget() != null) {
/* 113 */       if (!mavContainer.isBindingDisabled(name)) {
/* 114 */         bindRequestParameters(binder, webRequest);
/*     */       }
/* 116 */       validateIfApplicable(binder, parameter);
/* 117 */       if ((binder.getBindingResult().hasErrors()) && (isBindExceptionRequired(binder, parameter))) {
/* 118 */         throw new BindException(binder.getBindingResult());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 123 */     Map<String, Object> bindingResultModel = binder.getBindingResult().getModel();
/* 124 */     mavContainer.removeAttributes(bindingResultModel);
/* 125 */     mavContainer.addAllAttributes(bindingResultModel);
/*     */     
/* 127 */     return binder.convertIfNecessary(binder.getTarget(), parameter.getParameterType(), parameter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object createAttribute(String attributeName, MethodParameter methodParam, WebDataBinderFactory binderFactory, NativeWebRequest request)
/*     */     throws Exception
/*     */   {
/* 142 */     return BeanUtils.instantiateClass(methodParam.getParameterType());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void bindRequestParameters(WebDataBinder binder, NativeWebRequest request)
/*     */   {
/* 151 */     ((WebRequestDataBinder)binder).bind(request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void validateIfApplicable(WebDataBinder binder, MethodParameter methodParam)
/*     */   {
/* 163 */     Annotation[] annotations = methodParam.getParameterAnnotations();
/* 164 */     for (Annotation ann : annotations) {
/* 165 */       Validated validatedAnn = (Validated)AnnotationUtils.getAnnotation(ann, Validated.class);
/* 166 */       if ((validatedAnn != null) || (ann.annotationType().getSimpleName().startsWith("Valid"))) {
/* 167 */         Object hints = validatedAnn != null ? validatedAnn.value() : AnnotationUtils.getValue(ann);
/* 168 */         Object[] validationHints = { (hints instanceof Object[]) ? (Object[])hints : hints };
/* 169 */         binder.validate(validationHints);
/* 170 */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isBindExceptionRequired(WebDataBinder binder, MethodParameter methodParam)
/*     */   {
/* 182 */     int i = methodParam.getParameterIndex();
/* 183 */     Class<?>[] paramTypes = methodParam.getMethod().getParameterTypes();
/* 184 */     boolean hasBindingResult = (paramTypes.length > i + 1) && (Errors.class.isAssignableFrom(paramTypes[(i + 1)]));
/* 185 */     return !hasBindingResult;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsReturnType(MethodParameter returnType)
/*     */   {
/* 196 */     return (returnType.hasMethodAnnotation(ModelAttribute.class)) || ((this.annotationNotRequired) && (!BeanUtils.isSimpleProperty(returnType.getParameterType())));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 206 */     if (returnValue != null) {
/* 207 */       String name = ModelFactory.getNameForReturnValue(returnValue, returnType);
/* 208 */       mavContainer.addAttribute(name, returnValue);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\method\annotation\ModelAttributeMethodProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */