/*     */ package org.springframework.web.method;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.core.annotation.SynthesizingMethodParameter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HandlerMethod
/*     */ {
/*  52 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */ 
/*     */   private final Object bean;
/*     */   
/*     */ 
/*     */   private final BeanFactory beanFactory;
/*     */   
/*     */   private final Class<?> beanType;
/*     */   
/*     */   private final Method method;
/*     */   
/*     */   private final Method bridgedMethod;
/*     */   
/*     */   private final MethodParameter[] parameters;
/*     */   
/*     */   private final HandlerMethod resolvedFromHandlerMethod;
/*     */   
/*     */ 
/*     */   public HandlerMethod(Object bean, Method method)
/*     */   {
/*  73 */     Assert.notNull(bean, "Bean is required");
/*  74 */     Assert.notNull(method, "Method is required");
/*  75 */     this.bean = bean;
/*  76 */     this.beanFactory = null;
/*  77 */     this.beanType = ClassUtils.getUserClass(bean);
/*  78 */     this.method = method;
/*  79 */     this.bridgedMethod = BridgeMethodResolver.findBridgedMethod(method);
/*  80 */     this.parameters = initMethodParameters();
/*  81 */     this.resolvedFromHandlerMethod = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public HandlerMethod(Object bean, String methodName, Class<?>... parameterTypes)
/*     */     throws NoSuchMethodException
/*     */   {
/*  89 */     Assert.notNull(bean, "Bean is required");
/*  90 */     Assert.notNull(methodName, "Method name is required");
/*  91 */     this.bean = bean;
/*  92 */     this.beanFactory = null;
/*  93 */     this.beanType = ClassUtils.getUserClass(bean);
/*  94 */     this.method = bean.getClass().getMethod(methodName, parameterTypes);
/*  95 */     this.bridgedMethod = BridgeMethodResolver.findBridgedMethod(this.method);
/*  96 */     this.parameters = initMethodParameters();
/*  97 */     this.resolvedFromHandlerMethod = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HandlerMethod(String beanName, BeanFactory beanFactory, Method method)
/*     */   {
/* 106 */     Assert.hasText(beanName, "Bean name is required");
/* 107 */     Assert.notNull(beanFactory, "BeanFactory is required");
/* 108 */     Assert.notNull(method, "Method is required");
/* 109 */     this.bean = beanName;
/* 110 */     this.beanFactory = beanFactory;
/* 111 */     this.beanType = ClassUtils.getUserClass(beanFactory.getType(beanName));
/* 112 */     this.method = method;
/* 113 */     this.bridgedMethod = BridgeMethodResolver.findBridgedMethod(method);
/* 114 */     this.parameters = initMethodParameters();
/* 115 */     this.resolvedFromHandlerMethod = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected HandlerMethod(HandlerMethod handlerMethod)
/*     */   {
/* 122 */     Assert.notNull(handlerMethod, "HandlerMethod is required");
/* 123 */     this.bean = handlerMethod.bean;
/* 124 */     this.beanFactory = handlerMethod.beanFactory;
/* 125 */     this.beanType = handlerMethod.beanType;
/* 126 */     this.method = handlerMethod.method;
/* 127 */     this.bridgedMethod = handlerMethod.bridgedMethod;
/* 128 */     this.parameters = handlerMethod.parameters;
/* 129 */     this.resolvedFromHandlerMethod = handlerMethod.resolvedFromHandlerMethod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private HandlerMethod(HandlerMethod handlerMethod, Object handler)
/*     */   {
/* 136 */     Assert.notNull(handlerMethod, "HandlerMethod is required");
/* 137 */     Assert.notNull(handler, "Handler object is required");
/* 138 */     this.bean = handler;
/* 139 */     this.beanFactory = handlerMethod.beanFactory;
/* 140 */     this.beanType = handlerMethod.beanType;
/* 141 */     this.method = handlerMethod.method;
/* 142 */     this.bridgedMethod = handlerMethod.bridgedMethod;
/* 143 */     this.parameters = handlerMethod.parameters;
/* 144 */     this.resolvedFromHandlerMethod = handlerMethod;
/*     */   }
/*     */   
/*     */   private MethodParameter[] initMethodParameters()
/*     */   {
/* 149 */     int count = this.bridgedMethod.getParameterTypes().length;
/* 150 */     MethodParameter[] result = new MethodParameter[count];
/* 151 */     for (int i = 0; i < count; i++) {
/* 152 */       result[i] = new HandlerMethodParameter(i);
/*     */     }
/* 154 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getBean()
/*     */   {
/* 161 */     return this.bean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Method getMethod()
/*     */   {
/* 168 */     return this.method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getBeanType()
/*     */   {
/* 177 */     return this.beanType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Method getBridgedMethod()
/*     */   {
/* 185 */     return this.bridgedMethod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public MethodParameter[] getMethodParameters()
/*     */   {
/* 192 */     return this.parameters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public HandlerMethod getResolvedFromHandlerMethod()
/*     */   {
/* 200 */     return this.resolvedFromHandlerMethod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public MethodParameter getReturnType()
/*     */   {
/* 207 */     return new HandlerMethodParameter(-1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public MethodParameter getReturnValueType(Object returnValue)
/*     */   {
/* 214 */     return new ReturnValueMethodParameter(returnValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isVoid()
/*     */   {
/* 221 */     return Void.TYPE.equals(getReturnType().getParameterType());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <A extends Annotation> A getMethodAnnotation(Class<A> annotationType)
/*     */   {
/* 234 */     return AnnotatedElementUtils.findMergedAnnotation(this.method, annotationType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <A extends Annotation> boolean hasMethodAnnotation(Class<A> annotationType)
/*     */   {
/* 244 */     return AnnotatedElementUtils.hasAnnotation(this.method, annotationType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public HandlerMethod createWithResolvedBean()
/*     */   {
/* 252 */     Object handler = this.bean;
/* 253 */     if ((this.bean instanceof String)) {
/* 254 */       String beanName = (String)this.bean;
/* 255 */       handler = this.beanFactory.getBean(beanName);
/*     */     }
/* 257 */     return new HandlerMethod(this, handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getShortLogMessage()
/*     */   {
/* 265 */     int args = this.method.getParameterTypes().length;
/* 266 */     return getBeanType().getName() + "#" + this.method.getName() + "[" + args + " args]";
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 272 */     if (this == other) {
/* 273 */       return true;
/*     */     }
/* 275 */     if (!(other instanceof HandlerMethod)) {
/* 276 */       return false;
/*     */     }
/* 278 */     HandlerMethod otherMethod = (HandlerMethod)other;
/* 279 */     return (this.bean.equals(otherMethod.bean)) && (this.method.equals(otherMethod.method));
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 284 */     return this.bean.hashCode() * 31 + this.method.hashCode();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 289 */     return this.method.toGenericString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected class HandlerMethodParameter
/*     */     extends SynthesizingMethodParameter
/*     */   {
/*     */     public HandlerMethodParameter(int index)
/*     */     {
/* 299 */       super(index);
/*     */     }
/*     */     
/*     */     protected HandlerMethodParameter(HandlerMethodParameter original) {
/* 303 */       super();
/*     */     }
/*     */     
/*     */     public Class<?> getContainingClass()
/*     */     {
/* 308 */       return HandlerMethod.this.getBeanType();
/*     */     }
/*     */     
/*     */     public <T extends Annotation> T getMethodAnnotation(Class<T> annotationType)
/*     */     {
/* 313 */       return HandlerMethod.this.getMethodAnnotation(annotationType);
/*     */     }
/*     */     
/*     */     public <T extends Annotation> boolean hasMethodAnnotation(Class<T> annotationType)
/*     */     {
/* 318 */       return HandlerMethod.this.hasMethodAnnotation(annotationType);
/*     */     }
/*     */     
/*     */     public HandlerMethodParameter clone()
/*     */     {
/* 323 */       return new HandlerMethodParameter(HandlerMethod.this, this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private class ReturnValueMethodParameter
/*     */     extends HandlerMethod.HandlerMethodParameter
/*     */   {
/*     */     private final Object returnValue;
/*     */     
/*     */ 
/*     */     public ReturnValueMethodParameter(Object returnValue)
/*     */     {
/* 336 */       super(-1);
/* 337 */       this.returnValue = returnValue;
/*     */     }
/*     */     
/*     */     protected ReturnValueMethodParameter(ReturnValueMethodParameter original) {
/* 341 */       super(original);
/* 342 */       this.returnValue = original.returnValue;
/*     */     }
/*     */     
/*     */     public Class<?> getParameterType()
/*     */     {
/* 347 */       return this.returnValue != null ? this.returnValue.getClass() : super.getParameterType();
/*     */     }
/*     */     
/*     */     public ReturnValueMethodParameter clone()
/*     */     {
/* 352 */       return new ReturnValueMethodParameter(HandlerMethod.this, this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\method\HandlerMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */