/*     */ package org.springframework.web.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.URI;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.ParameterizedTypeReference;
/*     */ import org.springframework.core.task.AsyncListenableTaskExecutor;
/*     */ import org.springframework.core.task.SimpleAsyncTaskExecutor;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.ResponseEntity;
/*     */ import org.springframework.http.client.AsyncClientHttpRequest;
/*     */ import org.springframework.http.client.AsyncClientHttpRequestFactory;
/*     */ import org.springframework.http.client.ClientHttpRequest;
/*     */ import org.springframework.http.client.ClientHttpRequestFactory;
/*     */ import org.springframework.http.client.ClientHttpResponse;
/*     */ import org.springframework.http.client.SimpleClientHttpRequestFactory;
/*     */ import org.springframework.http.client.support.InterceptingAsyncHttpAccessor;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.concurrent.ListenableFuture;
/*     */ import org.springframework.util.concurrent.ListenableFutureAdapter;
/*     */ import org.springframework.web.util.AbstractUriTemplateHandler;
/*     */ import org.springframework.web.util.UriTemplateHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsyncRestTemplate
/*     */   extends InterceptingAsyncHttpAccessor
/*     */   implements AsyncRestOperations
/*     */ {
/*     */   private final RestTemplate syncTemplate;
/*     */   
/*     */   public AsyncRestTemplate()
/*     */   {
/*  83 */     this(new SimpleAsyncTaskExecutor());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AsyncRestTemplate(AsyncListenableTaskExecutor taskExecutor)
/*     */   {
/*  93 */     Assert.notNull(taskExecutor, "AsyncTaskExecutor must not be null");
/*  94 */     SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
/*  95 */     requestFactory.setTaskExecutor(taskExecutor);
/*  96 */     this.syncTemplate = new RestTemplate(requestFactory);
/*  97 */     setAsyncRequestFactory(requestFactory);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AsyncRestTemplate(AsyncClientHttpRequestFactory asyncRequestFactory)
/*     */   {
/* 110 */     this(asyncRequestFactory, (ClientHttpRequestFactory)asyncRequestFactory);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AsyncRestTemplate(AsyncClientHttpRequestFactory asyncRequestFactory, ClientHttpRequestFactory syncRequestFactory)
/*     */   {
/* 122 */     this(asyncRequestFactory, new RestTemplate(syncRequestFactory));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AsyncRestTemplate(AsyncClientHttpRequestFactory requestFactory, RestTemplate restTemplate)
/*     */   {
/* 132 */     Assert.notNull(restTemplate, "RestTemplate must not be null");
/* 133 */     this.syncTemplate = restTemplate;
/* 134 */     setAsyncRequestFactory(requestFactory);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setErrorHandler(ResponseErrorHandler errorHandler)
/*     */   {
/* 144 */     this.syncTemplate.setErrorHandler(errorHandler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ResponseErrorHandler getErrorHandler()
/*     */   {
/* 151 */     return this.syncTemplate.getErrorHandler();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultUriVariables(Map<String, ?> defaultUriVariables)
/*     */   {
/* 167 */     UriTemplateHandler handler = this.syncTemplate.getUriTemplateHandler();
/* 168 */     Assert.isInstanceOf(AbstractUriTemplateHandler.class, handler, "Can only use this property in conjunction with a DefaultUriTemplateHandler");
/*     */     
/* 170 */     ((AbstractUriTemplateHandler)handler).setDefaultUriVariables(defaultUriVariables);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUriTemplateHandler(UriTemplateHandler handler)
/*     */   {
/* 180 */     this.syncTemplate.setUriTemplateHandler(handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public UriTemplateHandler getUriTemplateHandler()
/*     */   {
/* 187 */     return this.syncTemplate.getUriTemplateHandler();
/*     */   }
/*     */   
/*     */   public RestOperations getRestOperations()
/*     */   {
/* 192 */     return this.syncTemplate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessageConverters(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/* 200 */     this.syncTemplate.setMessageConverters(messageConverters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<HttpMessageConverter<?>> getMessageConverters()
/*     */   {
/* 207 */     return this.syncTemplate.getMessageConverters();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> getForEntity(String url, Class<T> responseType, Object... uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 217 */     AsyncRequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/* 218 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(responseType);
/* 219 */     return execute(url, HttpMethod.GET, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> getForEntity(String url, Class<T> responseType, Map<String, ?> urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 226 */     AsyncRequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/* 227 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(responseType);
/* 228 */     return execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */   
/*     */   public <T> ListenableFuture<ResponseEntity<T>> getForEntity(URI url, Class<T> responseType) throws RestClientException
/*     */   {
/* 233 */     AsyncRequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/* 234 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(responseType);
/* 235 */     return execute(url, HttpMethod.GET, requestCallback, responseExtractor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ListenableFuture<HttpHeaders> headForHeaders(String url, Object... uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 243 */     ResponseExtractor<HttpHeaders> headersExtractor = headersExtractor();
/* 244 */     return execute(url, HttpMethod.HEAD, null, headersExtractor, uriVariables);
/*     */   }
/*     */   
/*     */   public ListenableFuture<HttpHeaders> headForHeaders(String url, Map<String, ?> uriVariables) throws RestClientException
/*     */   {
/* 249 */     ResponseExtractor<HttpHeaders> headersExtractor = headersExtractor();
/* 250 */     return execute(url, HttpMethod.HEAD, null, headersExtractor, uriVariables);
/*     */   }
/*     */   
/*     */   public ListenableFuture<HttpHeaders> headForHeaders(URI url) throws RestClientException
/*     */   {
/* 255 */     ResponseExtractor<HttpHeaders> headersExtractor = headersExtractor();
/* 256 */     return execute(url, HttpMethod.HEAD, null, headersExtractor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ListenableFuture<URI> postForLocation(String url, HttpEntity<?> request, Object... uriVars)
/*     */     throws RestClientException
/*     */   {
/* 266 */     AsyncRequestCallback callback = httpEntityCallback(request);
/* 267 */     ResponseExtractor<HttpHeaders> extractor = headersExtractor();
/* 268 */     ListenableFuture<HttpHeaders> future = execute(url, HttpMethod.POST, callback, extractor, uriVars);
/* 269 */     return adaptToLocationHeader(future);
/*     */   }
/*     */   
/*     */ 
/*     */   public ListenableFuture<URI> postForLocation(String url, HttpEntity<?> request, Map<String, ?> uriVars)
/*     */     throws RestClientException
/*     */   {
/* 276 */     AsyncRequestCallback callback = httpEntityCallback(request);
/* 277 */     ResponseExtractor<HttpHeaders> extractor = headersExtractor();
/* 278 */     ListenableFuture<HttpHeaders> future = execute(url, HttpMethod.POST, callback, extractor, uriVars);
/* 279 */     return adaptToLocationHeader(future);
/*     */   }
/*     */   
/*     */   public ListenableFuture<URI> postForLocation(URI url, HttpEntity<?> request) throws RestClientException
/*     */   {
/* 284 */     AsyncRequestCallback callback = httpEntityCallback(request);
/* 285 */     ResponseExtractor<HttpHeaders> extractor = headersExtractor();
/* 286 */     ListenableFuture<HttpHeaders> future = execute(url, HttpMethod.POST, callback, extractor);
/* 287 */     return adaptToLocationHeader(future);
/*     */   }
/*     */   
/*     */   private static ListenableFuture<URI> adaptToLocationHeader(ListenableFuture<HttpHeaders> future) {
/* 291 */     new ListenableFutureAdapter(future)
/*     */     {
/*     */       protected URI adapt(HttpHeaders headers) throws ExecutionException {
/* 294 */         return headers.getLocation();
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> postForEntity(String url, HttpEntity<?> request, Class<T> responseType, Object... uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 303 */     AsyncRequestCallback requestCallback = httpEntityCallback(request, responseType);
/* 304 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(responseType);
/* 305 */     return execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> postForEntity(String url, HttpEntity<?> request, Class<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 312 */     AsyncRequestCallback requestCallback = httpEntityCallback(request, responseType);
/* 313 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(responseType);
/* 314 */     return execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> postForEntity(URI url, HttpEntity<?> request, Class<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 321 */     AsyncRequestCallback requestCallback = httpEntityCallback(request, responseType);
/* 322 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(responseType);
/* 323 */     return execute(url, HttpMethod.POST, requestCallback, responseExtractor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ListenableFuture<?> put(String url, HttpEntity<?> request, Object... uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 331 */     AsyncRequestCallback requestCallback = httpEntityCallback(request);
/* 332 */     return execute(url, HttpMethod.PUT, requestCallback, null, uriVariables);
/*     */   }
/*     */   
/*     */   public ListenableFuture<?> put(String url, HttpEntity<?> request, Map<String, ?> uriVariables) throws RestClientException
/*     */   {
/* 337 */     AsyncRequestCallback requestCallback = httpEntityCallback(request);
/* 338 */     return execute(url, HttpMethod.PUT, requestCallback, null, uriVariables);
/*     */   }
/*     */   
/*     */   public ListenableFuture<?> put(URI url, HttpEntity<?> request) throws RestClientException
/*     */   {
/* 343 */     AsyncRequestCallback requestCallback = httpEntityCallback(request);
/* 344 */     return execute(url, HttpMethod.PUT, requestCallback, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ListenableFuture<?> delete(String url, Object... urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 352 */     return execute(url, HttpMethod.DELETE, null, null, urlVariables);
/*     */   }
/*     */   
/*     */   public ListenableFuture<?> delete(String url, Map<String, ?> urlVariables) throws RestClientException
/*     */   {
/* 357 */     return execute(url, HttpMethod.DELETE, null, null, urlVariables);
/*     */   }
/*     */   
/*     */   public ListenableFuture<?> delete(URI url) throws RestClientException
/*     */   {
/* 362 */     return execute(url, HttpMethod.DELETE, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ListenableFuture<Set<HttpMethod>> optionsForAllow(String url, Object... uriVars)
/*     */     throws RestClientException
/*     */   {
/* 370 */     ResponseExtractor<HttpHeaders> extractor = headersExtractor();
/* 371 */     ListenableFuture<HttpHeaders> future = execute(url, HttpMethod.OPTIONS, null, extractor, uriVars);
/* 372 */     return adaptToAllowHeader(future);
/*     */   }
/*     */   
/*     */   public ListenableFuture<Set<HttpMethod>> optionsForAllow(String url, Map<String, ?> uriVars) throws RestClientException
/*     */   {
/* 377 */     ResponseExtractor<HttpHeaders> extractor = headersExtractor();
/* 378 */     ListenableFuture<HttpHeaders> future = execute(url, HttpMethod.OPTIONS, null, extractor, uriVars);
/* 379 */     return adaptToAllowHeader(future);
/*     */   }
/*     */   
/*     */   public ListenableFuture<Set<HttpMethod>> optionsForAllow(URI url) throws RestClientException
/*     */   {
/* 384 */     ResponseExtractor<HttpHeaders> extractor = headersExtractor();
/* 385 */     ListenableFuture<HttpHeaders> future = execute(url, HttpMethod.OPTIONS, null, extractor);
/* 386 */     return adaptToAllowHeader(future);
/*     */   }
/*     */   
/*     */   private static ListenableFuture<Set<HttpMethod>> adaptToAllowHeader(ListenableFuture<HttpHeaders> future) {
/* 390 */     new ListenableFutureAdapter(future)
/*     */     {
/*     */       protected Set<HttpMethod> adapt(HttpHeaders headers) throws ExecutionException {
/* 393 */         return headers.getAllow();
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType, Object... uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 404 */     AsyncRequestCallback requestCallback = httpEntityCallback(requestEntity, responseType);
/* 405 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(responseType);
/* 406 */     return execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 413 */     AsyncRequestCallback requestCallback = httpEntityCallback(requestEntity, responseType);
/* 414 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(responseType);
/* 415 */     return execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> exchange(URI url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 422 */     AsyncRequestCallback requestCallback = httpEntityCallback(requestEntity, responseType);
/* 423 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(responseType);
/* 424 */     return execute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType, Object... uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 431 */     Type type = responseType.getType();
/* 432 */     AsyncRequestCallback requestCallback = httpEntityCallback(requestEntity, type);
/* 433 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(type);
/* 434 */     return execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 441 */     Type type = responseType.getType();
/* 442 */     AsyncRequestCallback requestCallback = httpEntityCallback(requestEntity, type);
/* 443 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(type);
/* 444 */     return execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> exchange(URI url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 451 */     Type type = responseType.getType();
/* 452 */     AsyncRequestCallback requestCallback = httpEntityCallback(requestEntity, type);
/* 453 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(type);
/* 454 */     return execute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> ListenableFuture<T> execute(String url, HttpMethod method, AsyncRequestCallback requestCallback, ResponseExtractor<T> responseExtractor, Object... urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 464 */     URI expanded = getUriTemplateHandler().expand(url, urlVariables);
/* 465 */     return doExecute(expanded, method, requestCallback, responseExtractor);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ListenableFuture<T> execute(String url, HttpMethod method, AsyncRequestCallback requestCallback, ResponseExtractor<T> responseExtractor, Map<String, ?> urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 472 */     URI expanded = getUriTemplateHandler().expand(url, urlVariables);
/* 473 */     return doExecute(expanded, method, requestCallback, responseExtractor);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ListenableFuture<T> execute(URI url, HttpMethod method, AsyncRequestCallback requestCallback, ResponseExtractor<T> responseExtractor)
/*     */     throws RestClientException
/*     */   {
/* 480 */     return doExecute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected <T> ListenableFuture<T> doExecute(URI url, HttpMethod method, AsyncRequestCallback requestCallback, ResponseExtractor<T> responseExtractor)
/*     */     throws RestClientException
/*     */   {
/* 498 */     Assert.notNull(url, "'url' must not be null");
/* 499 */     Assert.notNull(method, "'method' must not be null");
/*     */     try {
/* 501 */       AsyncClientHttpRequest request = createAsyncRequest(url, method);
/* 502 */       if (requestCallback != null) {
/* 503 */         requestCallback.doWithRequest(request);
/*     */       }
/* 505 */       ListenableFuture<ClientHttpResponse> responseFuture = request.executeAsync();
/* 506 */       return new ResponseExtractorFuture(method, url, responseFuture, responseExtractor);
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 510 */       throw new ResourceAccessException("I/O error on " + method.name() + " request for \"" + url + "\":" + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private void logResponseStatus(HttpMethod method, URI url, ClientHttpResponse response) {
/* 515 */     if (this.logger.isDebugEnabled()) {
/*     */       try {
/* 517 */         this.logger.debug("Async " + method.name() + " request for \"" + url + "\" resulted in " + response
/* 518 */           .getStatusCode() + " (" + response.getStatusText() + ")");
/*     */       }
/*     */       catch (IOException localIOException) {}
/*     */     }
/*     */   }
/*     */   
/*     */   private void handleResponseError(HttpMethod method, URI url, ClientHttpResponse response)
/*     */     throws IOException
/*     */   {
/* 527 */     if (this.logger.isWarnEnabled()) {
/*     */       try {
/* 529 */         this.logger.warn("Async " + method.name() + " request for \"" + url + "\" resulted in " + response
/* 530 */           .getStatusCode() + " (" + response.getStatusText() + "); invoking error handler");
/*     */       }
/*     */       catch (IOException localIOException) {}
/*     */     }
/*     */     
/*     */ 
/* 536 */     getErrorHandler().handleError(response);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected <T> AsyncRequestCallback acceptHeaderRequestCallback(Class<T> responseType)
/*     */   {
/* 545 */     return new AsyncRequestCallbackAdapter(this.syncTemplate.acceptHeaderRequestCallback(responseType));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected <T> AsyncRequestCallback httpEntityCallback(HttpEntity<T> requestBody)
/*     */   {
/* 553 */     return new AsyncRequestCallbackAdapter(this.syncTemplate.httpEntityCallback(requestBody));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected <T> AsyncRequestCallback httpEntityCallback(HttpEntity<T> request, Type responseType)
/*     */   {
/* 561 */     return new AsyncRequestCallbackAdapter(this.syncTemplate.httpEntityCallback(request, responseType));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected <T> ResponseExtractor<ResponseEntity<T>> responseEntityExtractor(Type responseType)
/*     */   {
/* 568 */     return this.syncTemplate.responseEntityExtractor(responseType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected ResponseExtractor<HttpHeaders> headersExtractor()
/*     */   {
/* 575 */     return this.syncTemplate.headersExtractor();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class ResponseExtractorFuture<T>
/*     */     extends ListenableFutureAdapter<T, ClientHttpResponse>
/*     */   {
/*     */     private final HttpMethod method;
/*     */     
/*     */ 
/*     */     private final URI url;
/*     */     
/*     */     private final ResponseExtractor<T> responseExtractor;
/*     */     
/*     */ 
/*     */     public ResponseExtractorFuture(URI method, ListenableFuture<ClientHttpResponse> url, ResponseExtractor<T> clientHttpResponseFuture)
/*     */     {
/* 593 */       super();
/* 594 */       this.method = method;
/* 595 */       this.url = url;
/* 596 */       this.responseExtractor = responseExtractor;
/*     */     }
/*     */     
/*     */     protected final T adapt(ClientHttpResponse response) throws ExecutionException
/*     */     {
/*     */       try {
/* 602 */         if (!AsyncRestTemplate.this.getErrorHandler().hasError(response)) {
/* 603 */           AsyncRestTemplate.this.logResponseStatus(this.method, this.url, response);
/*     */         }
/*     */         else {
/* 606 */           AsyncRestTemplate.this.handleResponseError(this.method, this.url, response);
/*     */         }
/* 608 */         return (T)convertResponse(response);
/*     */       }
/*     */       catch (Throwable ex) {
/* 611 */         throw new ExecutionException(ex);
/*     */       }
/*     */       finally {
/* 614 */         if (response != null) {
/* 615 */           response.close();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     protected T convertResponse(ClientHttpResponse response) throws IOException {
/* 621 */       return (T)(this.responseExtractor != null ? this.responseExtractor.extractData(response) : null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class AsyncRequestCallbackAdapter
/*     */     implements AsyncRequestCallback
/*     */   {
/*     */     private final RequestCallback adaptee;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public AsyncRequestCallbackAdapter(RequestCallback requestCallback)
/*     */     {
/* 639 */       this.adaptee = requestCallback;
/*     */     }
/*     */     
/*     */     public void doWithRequest(final AsyncClientHttpRequest request) throws IOException
/*     */     {
/* 644 */       if (this.adaptee != null) {
/* 645 */         this.adaptee.doWithRequest(new ClientHttpRequest()
/*     */         {
/*     */           public ClientHttpResponse execute() throws IOException {
/* 648 */             throw new UnsupportedOperationException("execute not supported");
/*     */           }
/*     */           
/*     */           public OutputStream getBody() throws IOException {
/* 652 */             return request.getBody();
/*     */           }
/*     */           
/*     */           public HttpMethod getMethod() {
/* 656 */             return request.getMethod();
/*     */           }
/*     */           
/*     */           public URI getURI() {
/* 660 */             return request.getURI();
/*     */           }
/*     */           
/*     */           public HttpHeaders getHeaders() {
/* 664 */             return request.getHeaders();
/*     */           }
/*     */         });
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\client\AsyncRestTemplate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */