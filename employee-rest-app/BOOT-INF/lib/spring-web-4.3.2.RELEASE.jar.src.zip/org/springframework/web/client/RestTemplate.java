/*     */ package org.springframework.web.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.ParameterizedTypeReference;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.RequestEntity;
/*     */ import org.springframework.http.ResponseEntity;
/*     */ import org.springframework.http.client.ClientHttpRequest;
/*     */ import org.springframework.http.client.ClientHttpRequestFactory;
/*     */ import org.springframework.http.client.ClientHttpResponse;
/*     */ import org.springframework.http.client.support.InterceptingHttpAccessor;
/*     */ import org.springframework.http.converter.ByteArrayHttpMessageConverter;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.ResourceHttpMessageConverter;
/*     */ import org.springframework.http.converter.StringHttpMessageConverter;
/*     */ import org.springframework.http.converter.feed.AtomFeedHttpMessageConverter;
/*     */ import org.springframework.http.converter.feed.RssChannelHttpMessageConverter;
/*     */ import org.springframework.http.converter.json.GsonHttpMessageConverter;
/*     */ import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
/*     */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.MappingJackson2XmlHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.SourceHttpMessageConverter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.util.AbstractUriTemplateHandler;
/*     */ import org.springframework.web.util.DefaultUriTemplateHandler;
/*     */ import org.springframework.web.util.UriTemplateHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RestTemplate
/*     */   extends InterceptingHttpAccessor
/*     */   implements RestOperations
/*     */ {
/* 125 */   private static boolean romePresent = ClassUtils.isPresent("com.rometools.rome.feed.WireFeed", RestTemplate.class.getClassLoader());
/*     */   
/*     */ 
/* 128 */   private static final boolean jaxb2Present = ClassUtils.isPresent("javax.xml.bind.Binder", RestTemplate.class.getClassLoader());
/*     */   
/*     */ 
/* 131 */   private static final boolean jackson2Present = (ClassUtils.isPresent("com.fasterxml.jackson.databind.ObjectMapper", RestTemplate.class.getClassLoader())) && 
/* 132 */     (ClassUtils.isPresent("com.fasterxml.jackson.core.JsonGenerator", RestTemplate.class.getClassLoader()));
/*     */   
/*     */ 
/* 135 */   private static final boolean jackson2XmlPresent = ClassUtils.isPresent("com.fasterxml.jackson.dataformat.xml.XmlMapper", RestTemplate.class.getClassLoader());
/*     */   
/*     */ 
/* 138 */   private static final boolean gsonPresent = ClassUtils.isPresent("com.google.gson.Gson", RestTemplate.class.getClassLoader());
/*     */   
/*     */ 
/* 141 */   private final List<HttpMessageConverter<?>> messageConverters = new ArrayList();
/*     */   
/* 143 */   private ResponseErrorHandler errorHandler = new DefaultResponseErrorHandler();
/*     */   
/* 145 */   private UriTemplateHandler uriTemplateHandler = new DefaultUriTemplateHandler();
/*     */   
/* 147 */   private final ResponseExtractor<HttpHeaders> headersExtractor = new HeadersExtractor(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplate()
/*     */   {
/* 155 */     this.messageConverters.add(new ByteArrayHttpMessageConverter());
/* 156 */     this.messageConverters.add(new StringHttpMessageConverter());
/* 157 */     this.messageConverters.add(new ResourceHttpMessageConverter());
/* 158 */     this.messageConverters.add(new SourceHttpMessageConverter());
/* 159 */     this.messageConverters.add(new AllEncompassingFormHttpMessageConverter());
/*     */     
/* 161 */     if (romePresent) {
/* 162 */       this.messageConverters.add(new AtomFeedHttpMessageConverter());
/* 163 */       this.messageConverters.add(new RssChannelHttpMessageConverter());
/*     */     }
/*     */     
/* 166 */     if (jackson2XmlPresent) {
/* 167 */       this.messageConverters.add(new MappingJackson2XmlHttpMessageConverter());
/*     */     }
/* 169 */     else if (jaxb2Present) {
/* 170 */       this.messageConverters.add(new Jaxb2RootElementHttpMessageConverter());
/*     */     }
/*     */     
/* 173 */     if (jackson2Present) {
/* 174 */       this.messageConverters.add(new MappingJackson2HttpMessageConverter());
/*     */     }
/* 176 */     else if (gsonPresent) {
/* 177 */       this.messageConverters.add(new GsonHttpMessageConverter());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplate(ClientHttpRequestFactory requestFactory)
/*     */   {
/* 188 */     this();
/* 189 */     setRequestFactory(requestFactory);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplate(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/* 199 */     Assert.notEmpty(messageConverters, "At least one HttpMessageConverter required");
/* 200 */     this.messageConverters.addAll(messageConverters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessageConverters(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/* 209 */     Assert.notEmpty(messageConverters, "At least one HttpMessageConverter required");
/*     */     
/* 211 */     if (this.messageConverters != messageConverters) {
/* 212 */       this.messageConverters.clear();
/* 213 */       this.messageConverters.addAll(messageConverters);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<HttpMessageConverter<?>> getMessageConverters()
/*     */   {
/* 221 */     return this.messageConverters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setErrorHandler(ResponseErrorHandler errorHandler)
/*     */   {
/* 229 */     Assert.notNull(errorHandler, "ResponseErrorHandler must not be null");
/* 230 */     this.errorHandler = errorHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ResponseErrorHandler getErrorHandler()
/*     */   {
/* 237 */     return this.errorHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultUriVariables(Map<String, ?> defaultUriVariables)
/*     */   {
/* 253 */     Assert.isInstanceOf(AbstractUriTemplateHandler.class, this.uriTemplateHandler, "Can only use this property in conjunction with an AbstractUriTemplateHandler");
/*     */     
/* 255 */     ((AbstractUriTemplateHandler)this.uriTemplateHandler).setDefaultUriVariables(defaultUriVariables);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUriTemplateHandler(UriTemplateHandler handler)
/*     */   {
/* 268 */     Assert.notNull(handler, "UriTemplateHandler must not be null");
/* 269 */     this.uriTemplateHandler = handler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public UriTemplateHandler getUriTemplateHandler()
/*     */   {
/* 276 */     return this.uriTemplateHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public <T> T getForObject(String url, Class<T> responseType, Object... urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 284 */     RequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/*     */     
/* 286 */     HttpMessageConverterExtractor<T> responseExtractor = new HttpMessageConverterExtractor(responseType, getMessageConverters(), this.logger);
/* 287 */     return (T)execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */   
/*     */   public <T> T getForObject(String url, Class<T> responseType, Map<String, ?> urlVariables) throws RestClientException
/*     */   {
/* 292 */     RequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/*     */     
/* 294 */     HttpMessageConverterExtractor<T> responseExtractor = new HttpMessageConverterExtractor(responseType, getMessageConverters(), this.logger);
/* 295 */     return (T)execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */   
/*     */   public <T> T getForObject(URI url, Class<T> responseType) throws RestClientException
/*     */   {
/* 300 */     RequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/*     */     
/* 302 */     HttpMessageConverterExtractor<T> responseExtractor = new HttpMessageConverterExtractor(responseType, getMessageConverters(), this.logger);
/* 303 */     return (T)execute(url, HttpMethod.GET, requestCallback, responseExtractor);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ResponseEntity<T> getForEntity(String url, Class<T> responseType, Object... urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 310 */     RequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/* 311 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(responseType);
/* 312 */     return (ResponseEntity)execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ResponseEntity<T> getForEntity(String url, Class<T> responseType, Map<String, ?> urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 319 */     RequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/* 320 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(responseType);
/* 321 */     return (ResponseEntity)execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */   
/*     */   public <T> ResponseEntity<T> getForEntity(URI url, Class<T> responseType) throws RestClientException
/*     */   {
/* 326 */     RequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/* 327 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(responseType);
/* 328 */     return (ResponseEntity)execute(url, HttpMethod.GET, requestCallback, responseExtractor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public HttpHeaders headForHeaders(String url, Object... urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 336 */     return (HttpHeaders)execute(url, HttpMethod.HEAD, null, headersExtractor(), urlVariables);
/*     */   }
/*     */   
/*     */   public HttpHeaders headForHeaders(String url, Map<String, ?> urlVariables) throws RestClientException
/*     */   {
/* 341 */     return (HttpHeaders)execute(url, HttpMethod.HEAD, null, headersExtractor(), urlVariables);
/*     */   }
/*     */   
/*     */   public HttpHeaders headForHeaders(URI url) throws RestClientException
/*     */   {
/* 346 */     return (HttpHeaders)execute(url, HttpMethod.HEAD, null, headersExtractor());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public URI postForLocation(String url, Object request, Object... urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 354 */     RequestCallback requestCallback = httpEntityCallback(request);
/* 355 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.POST, requestCallback, headersExtractor(), urlVariables);
/* 356 */     return headers.getLocation();
/*     */   }
/*     */   
/*     */   public URI postForLocation(String url, Object request, Map<String, ?> urlVariables) throws RestClientException
/*     */   {
/* 361 */     RequestCallback requestCallback = httpEntityCallback(request);
/* 362 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.POST, requestCallback, headersExtractor(), urlVariables);
/* 363 */     return headers.getLocation();
/*     */   }
/*     */   
/*     */   public URI postForLocation(URI url, Object request) throws RestClientException
/*     */   {
/* 368 */     RequestCallback requestCallback = httpEntityCallback(request);
/* 369 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.POST, requestCallback, headersExtractor());
/* 370 */     return headers.getLocation();
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> T postForObject(String url, Object request, Class<T> responseType, Object... uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 377 */     RequestCallback requestCallback = httpEntityCallback(request, responseType);
/*     */     
/* 379 */     HttpMessageConverterExtractor<T> responseExtractor = new HttpMessageConverterExtractor(responseType, getMessageConverters(), this.logger);
/* 380 */     return (T)execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> T postForObject(String url, Object request, Class<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 387 */     RequestCallback requestCallback = httpEntityCallback(request, responseType);
/*     */     
/* 389 */     HttpMessageConverterExtractor<T> responseExtractor = new HttpMessageConverterExtractor(responseType, getMessageConverters(), this.logger);
/* 390 */     return (T)execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */   
/*     */   public <T> T postForObject(URI url, Object request, Class<T> responseType) throws RestClientException
/*     */   {
/* 395 */     RequestCallback requestCallback = httpEntityCallback(request, responseType);
/*     */     
/* 397 */     HttpMessageConverterExtractor<T> responseExtractor = new HttpMessageConverterExtractor(responseType, getMessageConverters());
/* 398 */     return (T)execute(url, HttpMethod.POST, requestCallback, responseExtractor);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ResponseEntity<T> postForEntity(String url, Object request, Class<T> responseType, Object... uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 405 */     RequestCallback requestCallback = httpEntityCallback(request, responseType);
/* 406 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(responseType);
/* 407 */     return (ResponseEntity)execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ResponseEntity<T> postForEntity(String url, Object request, Class<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 414 */     RequestCallback requestCallback = httpEntityCallback(request, responseType);
/* 415 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(responseType);
/* 416 */     return (ResponseEntity)execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */   
/*     */   public <T> ResponseEntity<T> postForEntity(URI url, Object request, Class<T> responseType) throws RestClientException
/*     */   {
/* 421 */     RequestCallback requestCallback = httpEntityCallback(request, responseType);
/* 422 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(responseType);
/* 423 */     return (ResponseEntity)execute(url, HttpMethod.POST, requestCallback, responseExtractor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void put(String url, Object request, Object... urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 431 */     RequestCallback requestCallback = httpEntityCallback(request);
/* 432 */     execute(url, HttpMethod.PUT, requestCallback, null, urlVariables);
/*     */   }
/*     */   
/*     */   public void put(String url, Object request, Map<String, ?> urlVariables) throws RestClientException
/*     */   {
/* 437 */     RequestCallback requestCallback = httpEntityCallback(request);
/* 438 */     execute(url, HttpMethod.PUT, requestCallback, null, urlVariables);
/*     */   }
/*     */   
/*     */   public void put(URI url, Object request) throws RestClientException
/*     */   {
/* 443 */     RequestCallback requestCallback = httpEntityCallback(request);
/* 444 */     execute(url, HttpMethod.PUT, requestCallback, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void delete(String url, Object... urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 452 */     execute(url, HttpMethod.DELETE, null, null, urlVariables);
/*     */   }
/*     */   
/*     */   public void delete(String url, Map<String, ?> urlVariables) throws RestClientException
/*     */   {
/* 457 */     execute(url, HttpMethod.DELETE, null, null, urlVariables);
/*     */   }
/*     */   
/*     */   public void delete(URI url) throws RestClientException
/*     */   {
/* 462 */     execute(url, HttpMethod.DELETE, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Set<HttpMethod> optionsForAllow(String url, Object... urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 470 */     ResponseExtractor<HttpHeaders> headersExtractor = headersExtractor();
/* 471 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.OPTIONS, null, headersExtractor, urlVariables);
/* 472 */     return headers.getAllow();
/*     */   }
/*     */   
/*     */   public Set<HttpMethod> optionsForAllow(String url, Map<String, ?> urlVariables) throws RestClientException
/*     */   {
/* 477 */     ResponseExtractor<HttpHeaders> headersExtractor = headersExtractor();
/* 478 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.OPTIONS, null, headersExtractor, urlVariables);
/* 479 */     return headers.getAllow();
/*     */   }
/*     */   
/*     */   public Set<HttpMethod> optionsForAllow(URI url) throws RestClientException
/*     */   {
/* 484 */     ResponseExtractor<HttpHeaders> headersExtractor = headersExtractor();
/* 485 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.OPTIONS, null, headersExtractor);
/* 486 */     return headers.getAllow();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType, Object... uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 496 */     RequestCallback requestCallback = httpEntityCallback(requestEntity, responseType);
/* 497 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(responseType);
/* 498 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 505 */     RequestCallback requestCallback = httpEntityCallback(requestEntity, responseType);
/* 506 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(responseType);
/* 507 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(URI url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 514 */     RequestCallback requestCallback = httpEntityCallback(requestEntity, responseType);
/* 515 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(responseType);
/* 516 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType, Object... uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 523 */     Type type = responseType.getType();
/* 524 */     RequestCallback requestCallback = httpEntityCallback(requestEntity, type);
/* 525 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(type);
/* 526 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 533 */     Type type = responseType.getType();
/* 534 */     RequestCallback requestCallback = httpEntityCallback(requestEntity, type);
/* 535 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(type);
/* 536 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(URI url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 543 */     Type type = responseType.getType();
/* 544 */     RequestCallback requestCallback = httpEntityCallback(requestEntity, type);
/* 545 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(type);
/* 546 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(RequestEntity<?> requestEntity, Class<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 553 */     Assert.notNull(requestEntity, "'requestEntity' must not be null");
/*     */     
/* 555 */     RequestCallback requestCallback = httpEntityCallback(requestEntity, responseType);
/* 556 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(responseType);
/* 557 */     return (ResponseEntity)execute(requestEntity.getUrl(), requestEntity.getMethod(), requestCallback, responseExtractor);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(RequestEntity<?> requestEntity, ParameterizedTypeReference<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 564 */     Assert.notNull(requestEntity, "'requestEntity' must not be null");
/*     */     
/* 566 */     Type type = responseType.getType();
/* 567 */     RequestCallback requestCallback = httpEntityCallback(requestEntity, type);
/* 568 */     ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(type);
/* 569 */     return (ResponseEntity)execute(requestEntity.getUrl(), requestEntity.getMethod(), requestCallback, responseExtractor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> T execute(String url, HttpMethod method, RequestCallback requestCallback, ResponseExtractor<T> responseExtractor, Object... urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 579 */     URI expanded = getUriTemplateHandler().expand(url, urlVariables);
/* 580 */     return (T)doExecute(expanded, method, requestCallback, responseExtractor);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> T execute(String url, HttpMethod method, RequestCallback requestCallback, ResponseExtractor<T> responseExtractor, Map<String, ?> urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 587 */     URI expanded = getUriTemplateHandler().expand(url, urlVariables);
/* 588 */     return (T)doExecute(expanded, method, requestCallback, responseExtractor);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> T execute(URI url, HttpMethod method, RequestCallback requestCallback, ResponseExtractor<T> responseExtractor)
/*     */     throws RestClientException
/*     */   {
/* 595 */     return (T)doExecute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected <T> T doExecute(URI url, HttpMethod method, RequestCallback requestCallback, ResponseExtractor<T> responseExtractor)
/*     */     throws RestClientException
/*     */   {
/* 611 */     Assert.notNull(url, "'url' must not be null");
/* 612 */     Assert.notNull(method, "'method' must not be null");
/* 613 */     ClientHttpResponse response = null;
/*     */     try {
/* 615 */       ClientHttpRequest request = createRequest(url, method);
/* 616 */       if (requestCallback != null) {
/* 617 */         requestCallback.doWithRequest(request);
/*     */       }
/* 619 */       response = request.execute();
/* 620 */       handleResponse(url, method, response);
/* 621 */       Object localObject1; if (responseExtractor != null) {
/* 622 */         return (T)responseExtractor.extractData(response);
/*     */       }
/*     */       
/* 625 */       return null;
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 629 */       String resource = url.toString();
/* 630 */       String query = url.getRawQuery();
/* 631 */       resource = query != null ? resource.substring(0, resource.indexOf(query) - 1) : resource;
/*     */       
/* 633 */       throw new ResourceAccessException("I/O error on " + method.name() + " request for \"" + resource + "\": " + ex.getMessage(), ex);
/*     */     }
/*     */     finally {
/* 636 */       if (response != null) {
/* 637 */         response.close();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void handleResponse(URI url, HttpMethod method, ClientHttpResponse response)
/*     */     throws IOException
/*     */   {
/* 654 */     ResponseErrorHandler errorHandler = getErrorHandler();
/* 655 */     boolean hasError = errorHandler.hasError(response);
/* 656 */     if (this.logger.isDebugEnabled()) {
/*     */       try {
/* 658 */         this.logger.debug(method.name() + " request for \"" + url + "\" resulted in " + response
/* 659 */           .getRawStatusCode() + " (" + response.getStatusText() + ")" + (hasError ? "; invoking error handler" : ""));
/*     */       }
/*     */       catch (IOException localIOException) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 666 */     if (hasError) {
/* 667 */       errorHandler.handleError(response);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected <T> RequestCallback acceptHeaderRequestCallback(Class<T> responseType)
/*     */   {
/* 677 */     return new AcceptHeaderRequestCallback(responseType, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected <T> RequestCallback httpEntityCallback(Object requestBody)
/*     */   {
/* 685 */     return new HttpEntityRequestCallback(requestBody, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected <T> RequestCallback httpEntityCallback(Object requestBody, Type responseType)
/*     */   {
/* 693 */     return new HttpEntityRequestCallback(requestBody, responseType, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected <T> ResponseExtractor<ResponseEntity<T>> responseEntityExtractor(Type responseType)
/*     */   {
/* 700 */     return new ResponseEntityResponseExtractor(responseType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected ResponseExtractor<HttpHeaders> headersExtractor()
/*     */   {
/* 707 */     return this.headersExtractor;
/*     */   }
/*     */   
/*     */ 
/*     */   private class AcceptHeaderRequestCallback
/*     */     implements RequestCallback
/*     */   {
/*     */     private final Type responseType;
/*     */     
/*     */ 
/*     */     private AcceptHeaderRequestCallback(Type responseType)
/*     */     {
/* 719 */       this.responseType = responseType;
/*     */     }
/*     */     
/*     */     public void doWithRequest(ClientHttpRequest request) throws IOException
/*     */     {
/* 724 */       if (this.responseType != null) {
/* 725 */         Class<?> responseClass = null;
/* 726 */         if ((this.responseType instanceof Class)) {
/* 727 */           responseClass = (Class)this.responseType;
/*     */         }
/* 729 */         List<MediaType> allSupportedMediaTypes = new ArrayList();
/* 730 */         for (HttpMessageConverter<?> converter : RestTemplate.this.getMessageConverters()) {
/* 731 */           if (responseClass != null) {
/* 732 */             if (converter.canRead(responseClass, null)) {
/* 733 */               allSupportedMediaTypes.addAll(getSupportedMediaTypes(converter));
/*     */             }
/*     */           }
/* 736 */           else if ((converter instanceof GenericHttpMessageConverter)) {
/* 737 */             GenericHttpMessageConverter<?> genericConverter = (GenericHttpMessageConverter)converter;
/* 738 */             if (genericConverter.canRead(this.responseType, null, null)) {
/* 739 */               allSupportedMediaTypes.addAll(getSupportedMediaTypes(converter));
/*     */             }
/*     */           }
/*     */         }
/* 743 */         if (!allSupportedMediaTypes.isEmpty()) {
/* 744 */           MediaType.sortBySpecificity(allSupportedMediaTypes);
/* 745 */           if (RestTemplate.this.logger.isDebugEnabled()) {
/* 746 */             RestTemplate.this.logger.debug("Setting request Accept header to " + allSupportedMediaTypes);
/*     */           }
/* 748 */           request.getHeaders().setAccept(allSupportedMediaTypes);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private List<MediaType> getSupportedMediaTypes(HttpMessageConverter<?> messageConverter) {
/* 754 */       List<MediaType> supportedMediaTypes = messageConverter.getSupportedMediaTypes();
/* 755 */       List<MediaType> result = new ArrayList(supportedMediaTypes.size());
/* 756 */       for (MediaType supportedMediaType : supportedMediaTypes) {
/* 757 */         if (supportedMediaType.getCharset() != null)
/*     */         {
/* 759 */           supportedMediaType = new MediaType(supportedMediaType.getType(), supportedMediaType.getSubtype());
/*     */         }
/* 761 */         result.add(supportedMediaType);
/*     */       }
/* 763 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private class HttpEntityRequestCallback
/*     */     extends RestTemplate.AcceptHeaderRequestCallback
/*     */   {
/*     */     private final HttpEntity<?> requestEntity;
/*     */     
/*     */ 
/*     */     private HttpEntityRequestCallback(Object requestBody)
/*     */     {
/* 776 */       this(requestBody, null);
/*     */     }
/*     */     
/*     */     private HttpEntityRequestCallback(Object requestBody, Type responseType) {
/* 780 */       super(responseType, null);
/* 781 */       if ((requestBody instanceof HttpEntity)) {
/* 782 */         this.requestEntity = ((HttpEntity)requestBody);
/*     */       }
/* 784 */       else if (requestBody != null) {
/* 785 */         this.requestEntity = new HttpEntity(requestBody);
/*     */       }
/*     */       else {
/* 788 */         this.requestEntity = HttpEntity.EMPTY;
/*     */       }
/*     */     }
/*     */     
/*     */     public void doWithRequest(ClientHttpRequest httpRequest)
/*     */       throws IOException
/*     */     {
/* 795 */       super.doWithRequest(httpRequest);
/* 796 */       if (!this.requestEntity.hasBody()) {
/* 797 */         HttpHeaders httpHeaders = httpRequest.getHeaders();
/* 798 */         HttpHeaders requestHeaders = this.requestEntity.getHeaders();
/* 799 */         if (!requestHeaders.isEmpty()) {
/* 800 */           httpHeaders.putAll(requestHeaders);
/*     */         }
/* 802 */         if (httpHeaders.getContentLength() < 0L) {
/* 803 */           httpHeaders.setContentLength(0L);
/*     */         }
/*     */       }
/*     */       else {
/* 807 */         Object requestBody = this.requestEntity.getBody();
/* 808 */         Class<?> requestBodyClass = requestBody.getClass();
/*     */         
/* 810 */         Type requestBodyType = (this.requestEntity instanceof RequestEntity) ? ((RequestEntity)this.requestEntity).getType() : requestBodyClass;
/* 811 */         HttpHeaders requestHeaders = this.requestEntity.getHeaders();
/* 812 */         MediaType requestContentType = requestHeaders.getContentType();
/* 813 */         for (HttpMessageConverter<?> messageConverter : RestTemplate.this.getMessageConverters()) {
/* 814 */           if ((messageConverter instanceof GenericHttpMessageConverter)) {
/* 815 */             GenericHttpMessageConverter<Object> genericMessageConverter = (GenericHttpMessageConverter)messageConverter;
/* 816 */             if (genericMessageConverter.canWrite(requestBodyType, requestBodyClass, requestContentType)) {
/* 817 */               if (!requestHeaders.isEmpty()) {
/* 818 */                 httpRequest.getHeaders().putAll(requestHeaders);
/*     */               }
/* 820 */               if (RestTemplate.this.logger.isDebugEnabled()) {
/* 821 */                 if (requestContentType != null) {
/* 822 */                   RestTemplate.this.logger.debug("Writing [" + requestBody + "] as \"" + requestContentType + "\" using [" + messageConverter + "]");
/*     */                 }
/*     */                 else
/*     */                 {
/* 826 */                   RestTemplate.this.logger.debug("Writing [" + requestBody + "] using [" + messageConverter + "]");
/*     */                 }
/*     */               }
/*     */               
/* 830 */               genericMessageConverter.write(requestBody, requestBodyType, requestContentType, httpRequest);
/*     */               
/* 832 */               return;
/*     */             }
/*     */           }
/* 835 */           else if (messageConverter.canWrite(requestBodyClass, requestContentType)) {
/* 836 */             if (!requestHeaders.isEmpty()) {
/* 837 */               httpRequest.getHeaders().putAll(requestHeaders);
/*     */             }
/* 839 */             if (RestTemplate.this.logger.isDebugEnabled()) {
/* 840 */               if (requestContentType != null) {
/* 841 */                 RestTemplate.this.logger.debug("Writing [" + requestBody + "] as \"" + requestContentType + "\" using [" + messageConverter + "]");
/*     */               }
/*     */               else
/*     */               {
/* 845 */                 RestTemplate.this.logger.debug("Writing [" + requestBody + "] using [" + messageConverter + "]");
/*     */               }
/*     */             }
/*     */             
/* 849 */             messageConverter.write(requestBody, requestContentType, httpRequest);
/*     */             
/* 851 */             return;
/*     */           }
/*     */         }
/*     */         
/* 855 */         String message = "Could not write request: no suitable HttpMessageConverter found for request type [" + requestBodyClass.getName() + "]";
/* 856 */         if (requestContentType != null) {
/* 857 */           message = message + " and content type [" + requestContentType + "]";
/*     */         }
/* 859 */         throw new RestClientException(message);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private class ResponseEntityResponseExtractor<T>
/*     */     implements ResponseExtractor<ResponseEntity<T>>
/*     */   {
/*     */     private final HttpMessageConverterExtractor<T> delegate;
/*     */     
/*     */ 
/*     */     public ResponseEntityResponseExtractor(Type responseType)
/*     */     {
/* 873 */       if ((responseType != null) && (Void.class != responseType)) {
/* 874 */         this.delegate = new HttpMessageConverterExtractor(responseType, RestTemplate.this.getMessageConverters(), RestTemplate.this.logger);
/*     */       }
/*     */       else {
/* 877 */         this.delegate = null;
/*     */       }
/*     */     }
/*     */     
/*     */     public ResponseEntity<T> extractData(ClientHttpResponse response) throws IOException
/*     */     {
/* 883 */       if (this.delegate != null) {
/* 884 */         T body = this.delegate.extractData(response);
/* 885 */         return new ResponseEntity(body, response.getHeaders(), response.getStatusCode());
/*     */       }
/*     */       
/* 888 */       return new ResponseEntity(response.getHeaders(), response.getStatusCode());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class HeadersExtractor
/*     */     implements ResponseExtractor<HttpHeaders>
/*     */   {
/*     */     public HttpHeaders extractData(ClientHttpResponse response)
/*     */       throws IOException
/*     */     {
/* 901 */       return response.getHeaders();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\client\RestTemplate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */