/*     */ package org.springframework.web.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PushbackInputStream;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.client.ClientHttpResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MessageBodyClientHttpResponseWrapper
/*     */   implements ClientHttpResponse
/*     */ {
/*     */   private final ClientHttpResponse response;
/*     */   private PushbackInputStream pushbackInputStream;
/*     */   
/*     */   public MessageBodyClientHttpResponseWrapper(ClientHttpResponse response)
/*     */     throws IOException
/*     */   {
/*  44 */     this.response = response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasMessageBody()
/*     */     throws IOException
/*     */   {
/*  59 */     HttpStatus responseStatus = getStatusCode();
/*  60 */     if ((responseStatus.is1xxInformational()) || (responseStatus == HttpStatus.NO_CONTENT) || (responseStatus == HttpStatus.NOT_MODIFIED))
/*     */     {
/*  62 */       return false;
/*     */     }
/*  64 */     if (getHeaders().getContentLength() == 0L) {
/*  65 */       return false;
/*     */     }
/*  67 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasEmptyMessageBody()
/*     */     throws IOException
/*     */   {
/*  81 */     InputStream body = this.response.getBody();
/*  82 */     if (body == null) {
/*  83 */       return true;
/*     */     }
/*  85 */     if (body.markSupported()) {
/*  86 */       body.mark(1);
/*  87 */       if (body.read() == -1) {
/*  88 */         return true;
/*     */       }
/*     */       
/*  91 */       body.reset();
/*  92 */       return false;
/*     */     }
/*     */     
/*     */ 
/*  96 */     this.pushbackInputStream = new PushbackInputStream(body);
/*  97 */     int b = this.pushbackInputStream.read();
/*  98 */     if (b == -1) {
/*  99 */       return true;
/*     */     }
/*     */     
/* 102 */     this.pushbackInputStream.unread(b);
/* 103 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpHeaders getHeaders()
/*     */   {
/* 111 */     return this.response.getHeaders();
/*     */   }
/*     */   
/*     */   public InputStream getBody() throws IOException
/*     */   {
/* 116 */     return this.pushbackInputStream != null ? this.pushbackInputStream : this.response.getBody();
/*     */   }
/*     */   
/*     */   public HttpStatus getStatusCode() throws IOException
/*     */   {
/* 121 */     return this.response.getStatusCode();
/*     */   }
/*     */   
/*     */   public int getRawStatusCode() throws IOException
/*     */   {
/* 126 */     return this.response.getRawStatusCode();
/*     */   }
/*     */   
/*     */   public String getStatusText() throws IOException
/*     */   {
/* 131 */     return this.response.getStatusText();
/*     */   }
/*     */   
/*     */   public void close()
/*     */   {
/* 136 */     this.response.close();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\client\MessageBodyClientHttpResponseWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */