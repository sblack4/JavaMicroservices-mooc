/*     */ package org.springframework.web.filter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletRequestWrapper;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.http.HttpRequest;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*     */ import org.springframework.web.util.UriComponents;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ForwardedHeaderFilter
/*     */   extends OncePerRequestFilter
/*     */ {
/*  56 */   private static final Set<String> FORWARDED_HEADER_NAMES = Collections.newSetFromMap(new LinkedCaseInsensitiveMap(5, Locale.ENGLISH));
/*     */   
/*     */   static {
/*  59 */     FORWARDED_HEADER_NAMES.add("Forwarded");
/*  60 */     FORWARDED_HEADER_NAMES.add("X-Forwarded-Host");
/*  61 */     FORWARDED_HEADER_NAMES.add("X-Forwarded-Port");
/*  62 */     FORWARDED_HEADER_NAMES.add("X-Forwarded-Proto");
/*  63 */     FORWARDED_HEADER_NAMES.add("X-Forwarded-Prefix");
/*     */   }
/*     */   
/*     */ 
/*  67 */   private final UrlPathHelper pathHelper = new UrlPathHelper();
/*     */   
/*     */   protected boolean shouldNotFilter(HttpServletRequest request)
/*     */     throws ServletException
/*     */   {
/*  72 */     Enumeration<String> names = request.getHeaderNames();
/*  73 */     while (names.hasMoreElements()) {
/*  74 */       String name = (String)names.nextElement();
/*  75 */       if (FORWARDED_HEADER_NAMES.contains(name)) {
/*  76 */         return false;
/*     */       }
/*     */     }
/*  79 */     return true;
/*     */   }
/*     */   
/*     */   protected boolean shouldNotFilterAsyncDispatch()
/*     */   {
/*  84 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean shouldNotFilterErrorDispatch()
/*     */   {
/*  89 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/*  96 */     filterChain.doFilter(new ForwardedHeaderRequestWrapper(request, this.pathHelper), response);
/*     */   }
/*     */   
/*     */ 
/*     */   private static class ForwardedHeaderRequestWrapper
/*     */     extends HttpServletRequestWrapper
/*     */   {
/*     */     private final String scheme;
/*     */     
/*     */     private final boolean secure;
/*     */     
/*     */     private final String host;
/*     */     
/*     */     private final int port;
/*     */     
/*     */     private final String contextPath;
/*     */     
/*     */     private final String requestUri;
/*     */     private final StringBuffer requestUrl;
/*     */     private final Map<String, List<String>> headers;
/*     */     
/*     */     public ForwardedHeaderRequestWrapper(HttpServletRequest request, UrlPathHelper pathHelper)
/*     */     {
/* 119 */       super();
/*     */       
/* 121 */       HttpRequest httpRequest = new ServletServerHttpRequest(request);
/* 122 */       UriComponents uriComponents = UriComponentsBuilder.fromHttpRequest(httpRequest).build();
/* 123 */       int port = uriComponents.getPort();
/*     */       
/* 125 */       this.scheme = uriComponents.getScheme();
/* 126 */       this.secure = "https".equals(this.scheme);
/* 127 */       this.host = uriComponents.getHost();
/* 128 */       this.port = (port == -1 ? 80 : this.secure ? 443 : port);
/*     */       
/* 130 */       String prefix = getForwardedPrefix(request);
/* 131 */       this.contextPath = (prefix != null ? prefix : request.getContextPath());
/* 132 */       this.requestUri = (this.contextPath + pathHelper.getPathWithinApplication(request));
/* 133 */       this.requestUrl = new StringBuffer(this.scheme + "://" + this.host + (port == -1 ? "" : new StringBuilder().append(":").append(port).toString()) + this.requestUri);
/*     */       
/* 135 */       this.headers = initHeaders(request);
/*     */     }
/*     */     
/*     */     private static String getForwardedPrefix(HttpServletRequest request) {
/* 139 */       String prefix = null;
/* 140 */       Enumeration<String> names = request.getHeaderNames();
/* 141 */       while (names.hasMoreElements()) {
/* 142 */         String name = (String)names.nextElement();
/* 143 */         if ("X-Forwarded-Prefix".equalsIgnoreCase(name)) {
/* 144 */           prefix = request.getHeader(name);
/*     */         }
/*     */       }
/* 147 */       if (prefix != null) {
/* 148 */         while (prefix.endsWith("/")) {
/* 149 */           prefix = prefix.substring(0, prefix.length() - 1);
/*     */         }
/*     */       }
/* 152 */       return prefix;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private static Map<String, List<String>> initHeaders(HttpServletRequest request)
/*     */     {
/* 159 */       Map<String, List<String>> headers = new LinkedCaseInsensitiveMap(Locale.ENGLISH);
/* 160 */       Enumeration<String> names = request.getHeaderNames();
/* 161 */       while (names.hasMoreElements()) {
/* 162 */         String name = (String)names.nextElement();
/* 163 */         if (!ForwardedHeaderFilter.FORWARDED_HEADER_NAMES.contains(name)) {
/* 164 */           headers.put(name, Collections.list(request.getHeaders(name)));
/*     */         }
/*     */       }
/* 167 */       return headers;
/*     */     }
/*     */     
/*     */     public String getScheme()
/*     */     {
/* 172 */       return this.scheme;
/*     */     }
/*     */     
/*     */     public String getServerName()
/*     */     {
/* 177 */       return this.host;
/*     */     }
/*     */     
/*     */     public int getServerPort()
/*     */     {
/* 182 */       return this.port;
/*     */     }
/*     */     
/*     */     public boolean isSecure()
/*     */     {
/* 187 */       return this.secure;
/*     */     }
/*     */     
/*     */     public String getContextPath()
/*     */     {
/* 192 */       return this.contextPath;
/*     */     }
/*     */     
/*     */     public String getRequestURI()
/*     */     {
/* 197 */       return this.requestUri;
/*     */     }
/*     */     
/*     */     public StringBuffer getRequestURL()
/*     */     {
/* 202 */       return this.requestUrl;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public String getHeader(String name)
/*     */     {
/* 209 */       List<String> value = (List)this.headers.get(name);
/* 210 */       return CollectionUtils.isEmpty(value) ? null : (String)value.get(0);
/*     */     }
/*     */     
/*     */     public Enumeration<String> getHeaders(String name)
/*     */     {
/* 215 */       List<String> value = (List)this.headers.get(name);
/* 216 */       return Collections.enumeration(value != null ? value : Collections.emptySet());
/*     */     }
/*     */     
/*     */     public Enumeration<String> getHeaderNames()
/*     */     {
/* 221 */       return Collections.enumeration(this.headers.keySet());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\filter\ForwardedHeaderFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */