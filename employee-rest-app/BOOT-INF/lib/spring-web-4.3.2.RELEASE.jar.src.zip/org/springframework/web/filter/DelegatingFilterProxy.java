/*     */ package org.springframework.web.filter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelegatingFilterProxy
/*     */   extends GenericFilterBean
/*     */ {
/*     */   private String contextAttribute;
/*     */   private WebApplicationContext webApplicationContext;
/*     */   private String targetBeanName;
/*  89 */   private boolean targetFilterLifecycle = false;
/*     */   
/*     */   private volatile Filter delegate;
/*     */   
/*  93 */   private final Object delegateMonitor = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DelegatingFilterProxy() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DelegatingFilterProxy(Filter delegate)
/*     */   {
/* 118 */     Assert.notNull(delegate, "delegate Filter object must not be null");
/* 119 */     this.delegate = delegate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DelegatingFilterProxy(String targetBeanName)
/*     */   {
/* 136 */     this(targetBeanName, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DelegatingFilterProxy(String targetBeanName, WebApplicationContext wac)
/*     */   {
/* 160 */     Assert.hasText(targetBeanName, "target Filter bean name must not be null or empty");
/* 161 */     setTargetBeanName(targetBeanName);
/* 162 */     this.webApplicationContext = wac;
/* 163 */     if (wac != null) {
/* 164 */       setEnvironment(wac.getEnvironment());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContextAttribute(String contextAttribute)
/*     */   {
/* 173 */     this.contextAttribute = contextAttribute;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContextAttribute()
/*     */   {
/* 181 */     return this.contextAttribute;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTargetBeanName(String targetBeanName)
/*     */   {
/* 191 */     this.targetBeanName = targetBeanName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String getTargetBeanName()
/*     */   {
/* 198 */     return this.targetBeanName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTargetFilterLifecycle(boolean targetFilterLifecycle)
/*     */   {
/* 210 */     this.targetFilterLifecycle = targetFilterLifecycle;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isTargetFilterLifecycle()
/*     */   {
/* 218 */     return this.targetFilterLifecycle;
/*     */   }
/*     */   
/*     */   protected void initFilterBean()
/*     */     throws ServletException
/*     */   {
/* 224 */     synchronized (this.delegateMonitor) {
/* 225 */       if (this.delegate == null)
/*     */       {
/* 227 */         if (this.targetBeanName == null) {
/* 228 */           this.targetBeanName = getFilterName();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 233 */         WebApplicationContext wac = findWebApplicationContext();
/* 234 */         if (wac != null) {
/* 235 */           this.delegate = initDelegate(wac);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/* 246 */     Filter delegateToUse = this.delegate;
/* 247 */     if (delegateToUse == null) {
/* 248 */       synchronized (this.delegateMonitor) {
/* 249 */         if (this.delegate == null) {
/* 250 */           WebApplicationContext wac = findWebApplicationContext();
/* 251 */           if (wac == null) {
/* 252 */             throw new IllegalStateException("No WebApplicationContext found: no ContextLoaderListener or DispatcherServlet registered?");
/*     */           }
/*     */           
/* 255 */           this.delegate = initDelegate(wac);
/*     */         }
/* 257 */         delegateToUse = this.delegate;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 262 */     invokeDelegate(delegateToUse, request, response, filterChain);
/*     */   }
/*     */   
/*     */   public void destroy()
/*     */   {
/* 267 */     Filter delegateToUse = this.delegate;
/* 268 */     if (delegateToUse != null) {
/* 269 */       destroyDelegate(delegateToUse);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected WebApplicationContext findWebApplicationContext()
/*     */   {
/* 291 */     if (this.webApplicationContext != null)
/*     */     {
/* 293 */       if ((this.webApplicationContext instanceof ConfigurableApplicationContext)) {
/* 294 */         ConfigurableApplicationContext cac = (ConfigurableApplicationContext)this.webApplicationContext;
/* 295 */         if (!cac.isActive())
/*     */         {
/* 297 */           cac.refresh();
/*     */         }
/*     */       }
/* 300 */       return this.webApplicationContext;
/*     */     }
/* 302 */     String attrName = getContextAttribute();
/* 303 */     if (attrName != null) {
/* 304 */       return WebApplicationContextUtils.getWebApplicationContext(getServletContext(), attrName);
/*     */     }
/*     */     
/* 307 */     return WebApplicationContextUtils.findWebApplicationContext(getServletContext());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Filter initDelegate(WebApplicationContext wac)
/*     */     throws ServletException
/*     */   {
/* 326 */     Filter delegate = (Filter)wac.getBean(getTargetBeanName(), Filter.class);
/* 327 */     if (isTargetFilterLifecycle()) {
/* 328 */       delegate.init(getFilterConfig());
/*     */     }
/* 330 */     return delegate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void invokeDelegate(Filter delegate, ServletRequest request, ServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/* 346 */     delegate.doFilter(request, response, filterChain);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void destroyDelegate(Filter delegate)
/*     */   {
/* 357 */     if (isTargetFilterLifecycle()) {
/* 358 */       delegate.destroy();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\filter\DelegatingFilterProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */