/*     */ package org.springframework.web.filter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintWriter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.DigestUtils;
/*     */ import org.springframework.web.util.ContentCachingResponseWrapper;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ShallowEtagHeaderFilter
/*     */   extends OncePerRequestFilter
/*     */ {
/*     */   private static final String HEADER_ETAG = "ETag";
/*     */   private static final String HEADER_IF_NONE_MATCH = "If-None-Match";
/*     */   private static final String HEADER_CACHE_CONTROL = "Cache-Control";
/*     */   private static final String DIRECTIVE_NO_STORE = "no-store";
/*  62 */   private static final String STREAMING_ATTRIBUTE = ShallowEtagHeaderFilter.class.getName() + ".STREAMING";
/*     */   
/*     */ 
/*     */ 
/*  66 */   private static final boolean servlet3Present = ClassUtils.hasMethod(HttpServletResponse.class, "getHeader", new Class[] { String.class });
/*     */   
/*  68 */   private boolean writeWeakETag = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isWriteWeakETag()
/*     */   {
/*  77 */     return this.writeWeakETag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setWriteWeakETag(boolean writeWeakETag)
/*     */   {
/*  84 */     this.writeWeakETag = writeWeakETag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean shouldNotFilterAsyncDispatch()
/*     */   {
/*  93 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/* 100 */     HttpServletResponse responseToUse = response;
/* 101 */     if ((!isAsyncDispatch(request)) && (!(response instanceof ContentCachingResponseWrapper))) {
/* 102 */       responseToUse = new HttpStreamingAwareContentCachingResponseWrapper(response, request);
/*     */     }
/*     */     
/* 105 */     filterChain.doFilter(request, responseToUse);
/*     */     
/* 107 */     if ((!isAsyncStarted(request)) && (!isContentCachingDisabled(request))) {
/* 108 */       updateResponse(request, responseToUse);
/*     */     }
/*     */   }
/*     */   
/*     */   private void updateResponse(HttpServletRequest request, HttpServletResponse response) throws IOException
/*     */   {
/* 114 */     ContentCachingResponseWrapper responseWrapper = (ContentCachingResponseWrapper)WebUtils.getNativeResponse(response, ContentCachingResponseWrapper.class);
/* 115 */     Assert.notNull(responseWrapper, "ContentCachingResponseWrapper not found");
/* 116 */     HttpServletResponse rawResponse = (HttpServletResponse)responseWrapper.getResponse();
/* 117 */     int statusCode = responseWrapper.getStatusCode();
/*     */     
/* 119 */     if (rawResponse.isCommitted()) {
/* 120 */       responseWrapper.copyBodyToResponse();
/*     */     }
/* 122 */     else if (isEligibleForEtag(request, responseWrapper, statusCode, responseWrapper.getContentInputStream())) {
/* 123 */       String responseETag = generateETagHeaderValue(responseWrapper.getContentInputStream(), this.writeWeakETag);
/* 124 */       rawResponse.setHeader("ETag", responseETag);
/* 125 */       String requestETag = request.getHeader("If-None-Match");
/* 126 */       if ((requestETag != null) && (
/* 127 */         (responseETag.equals(requestETag)) || 
/* 128 */         (responseETag.replaceFirst("^W/", "").equals(requestETag.replaceFirst("^W/", ""))) || 
/* 129 */         ("*".equals(requestETag)))) {
/* 130 */         if (this.logger.isTraceEnabled()) {
/* 131 */           this.logger.trace("ETag [" + responseETag + "] equal to If-None-Match, sending 304");
/*     */         }
/* 133 */         rawResponse.setStatus(304);
/*     */       }
/*     */       else {
/* 136 */         if (this.logger.isTraceEnabled()) {
/* 137 */           this.logger.trace("ETag [" + responseETag + "] not equal to If-None-Match [" + requestETag + "], sending normal response");
/*     */         }
/*     */         
/* 140 */         responseWrapper.copyBodyToResponse();
/*     */       }
/*     */     }
/*     */     else {
/* 144 */       if (this.logger.isTraceEnabled()) {
/* 145 */         this.logger.trace("Response with status code [" + statusCode + "] not eligible for ETag");
/*     */       }
/* 147 */       responseWrapper.copyBodyToResponse();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isEligibleForEtag(HttpServletRequest request, HttpServletResponse response, int responseStatusCode, InputStream inputStream)
/*     */   {
/* 168 */     String method = request.getMethod();
/* 169 */     if ((responseStatusCode >= 200) && (responseStatusCode < 300) && (
/* 170 */       (HttpMethod.GET.matches(method)) || (HttpMethod.HEAD.matches(method))))
/*     */     {
/* 172 */       String cacheControl = null;
/* 173 */       if (servlet3Present) {
/* 174 */         cacheControl = response.getHeader("Cache-Control");
/*     */       }
/* 176 */       if ((cacheControl == null) || (!cacheControl.contains("no-store"))) {
/* 177 */         return true;
/*     */       }
/*     */     }
/* 180 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String generateETagHeaderValue(InputStream inputStream, boolean isWeak)
/*     */     throws IOException
/*     */   {
/* 193 */     StringBuilder builder = new StringBuilder(37);
/* 194 */     if (isWeak) {
/* 195 */       builder.append("W/");
/*     */     }
/* 197 */     builder.append("\"0");
/* 198 */     DigestUtils.appendMd5DigestAsHex(inputStream, builder);
/* 199 */     builder.append('"');
/* 200 */     return builder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void disableContentCaching(ServletRequest request)
/*     */   {
/* 212 */     Assert.notNull(request, "ServletRequest must not be null");
/* 213 */     request.setAttribute(STREAMING_ATTRIBUTE, Boolean.valueOf(true));
/*     */   }
/*     */   
/*     */   private static boolean isContentCachingDisabled(HttpServletRequest request) {
/* 217 */     return request.getAttribute(STREAMING_ATTRIBUTE) != null;
/*     */   }
/*     */   
/*     */   private static class HttpStreamingAwareContentCachingResponseWrapper extends ContentCachingResponseWrapper
/*     */   {
/*     */     private final HttpServletRequest request;
/*     */     
/*     */     public HttpStreamingAwareContentCachingResponseWrapper(HttpServletResponse response, HttpServletRequest request)
/*     */     {
/* 226 */       super();
/* 227 */       this.request = request;
/*     */     }
/*     */     
/*     */     public ServletOutputStream getOutputStream() throws IOException
/*     */     {
/* 232 */       return useRawResponse() ? getResponse().getOutputStream() : super.getOutputStream();
/*     */     }
/*     */     
/*     */     public PrintWriter getWriter() throws IOException
/*     */     {
/* 237 */       return useRawResponse() ? getResponse().getWriter() : super.getWriter();
/*     */     }
/*     */     
/*     */     private boolean useRawResponse() {
/* 241 */       return ShallowEtagHeaderFilter.isContentCachingDisabled(this.request);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\filter\ShallowEtagHeaderFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */