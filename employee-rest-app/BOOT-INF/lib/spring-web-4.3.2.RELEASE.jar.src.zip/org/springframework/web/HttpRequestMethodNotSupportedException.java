/*     */ package org.springframework.web;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.EnumSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletException;
/*     */ import org.springframework.http.HttpMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpRequestMethodNotSupportedException
/*     */   extends ServletException
/*     */ {
/*     */   private String method;
/*     */   private String[] supportedMethods;
/*     */   
/*     */   public HttpRequestMethodNotSupportedException(String method)
/*     */   {
/*  48 */     this(method, (String[])null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpRequestMethodNotSupportedException(String method, String[] supportedMethods)
/*     */   {
/*  57 */     this(method, supportedMethods, "Request method '" + method + "' not supported");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpRequestMethodNotSupportedException(String method, Collection<String> supportedMethods)
/*     */   {
/*  66 */     this(method, (String[])supportedMethods.toArray(new String[supportedMethods.size()]));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpRequestMethodNotSupportedException(String method, String msg)
/*     */   {
/*  75 */     this(method, null, msg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpRequestMethodNotSupportedException(String method, String[] supportedMethods, String msg)
/*     */   {
/*  85 */     super(msg);
/*  86 */     this.method = method;
/*  87 */     this.supportedMethods = supportedMethods;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMethod()
/*     */   {
/*  95 */     return this.method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String[] getSupportedMethods()
/*     */   {
/* 102 */     return this.supportedMethods;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Set<HttpMethod> getSupportedHttpMethods()
/*     */   {
/* 109 */     List<HttpMethod> supportedMethods = new LinkedList();
/* 110 */     for (String value : this.supportedMethods) {
/* 111 */       HttpMethod resolved = HttpMethod.resolve(value);
/* 112 */       if (resolved != null) {
/* 113 */         supportedMethods.add(resolved);
/*     */       }
/*     */     }
/* 116 */     return EnumSet.copyOf(supportedMethods);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\HttpRequestMethodNotSupportedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */