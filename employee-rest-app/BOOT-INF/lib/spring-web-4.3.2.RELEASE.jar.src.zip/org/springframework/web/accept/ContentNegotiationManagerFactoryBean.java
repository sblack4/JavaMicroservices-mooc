/*     */ package org.springframework.web.accept;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContentNegotiationManagerFactoryBean
/*     */   implements FactoryBean<ContentNegotiationManager>, ServletContextAware, InitializingBean
/*     */ {
/*  93 */   private boolean favorPathExtension = true;
/*     */   
/*  95 */   private boolean favorParameter = false;
/*     */   
/*  97 */   private boolean ignoreAcceptHeader = false;
/*     */   
/*  99 */   private Map<String, MediaType> mediaTypes = new HashMap();
/*     */   
/* 101 */   private boolean ignoreUnknownPathExtensions = true;
/*     */   
/*     */   private Boolean useJaf;
/*     */   
/* 105 */   private String parameterName = "format";
/*     */   
/*     */ 
/*     */ 
/*     */   private ContentNegotiationStrategy defaultNegotiationStrategy;
/*     */   
/*     */ 
/*     */ 
/*     */   private ContentNegotiationManager contentNegotiationManager;
/*     */   
/*     */ 
/*     */   private ServletContext servletContext;
/*     */   
/*     */ 
/*     */ 
/*     */   public void setFavorPathExtension(boolean favorPathExtension)
/*     */   {
/* 122 */     this.favorPathExtension = favorPathExtension;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMediaTypes(Properties mediaTypes)
/*     */   {
/* 140 */     if (!CollectionUtils.isEmpty(mediaTypes)) {
/* 141 */       for (Map.Entry<Object, Object> entry : mediaTypes.entrySet()) {
/* 142 */         String extension = ((String)entry.getKey()).toLowerCase(Locale.ENGLISH);
/* 143 */         MediaType mediaType = MediaType.valueOf((String)entry.getValue());
/* 144 */         this.mediaTypes.put(extension, mediaType);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addMediaType(String fileExtension, MediaType mediaType)
/*     */   {
/* 155 */     this.mediaTypes.put(fileExtension, mediaType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addMediaTypes(Map<String, MediaType> mediaTypes)
/*     */   {
/* 164 */     if (mediaTypes != null) {
/* 165 */       this.mediaTypes.putAll(mediaTypes);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIgnoreUnknownPathExtensions(boolean ignore)
/*     */   {
/* 176 */     this.ignoreUnknownPathExtensions = ignore;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUseJaf(boolean useJaf)
/*     */   {
/* 187 */     this.useJaf = Boolean.valueOf(useJaf);
/*     */   }
/*     */   
/*     */   private boolean isUseJafTurnedOff() {
/* 191 */     return (this.useJaf != null) && (!this.useJaf.booleanValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFavorParameter(boolean favorParameter)
/*     */   {
/* 202 */     this.favorParameter = favorParameter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParameterName(String parameterName)
/*     */   {
/* 210 */     Assert.notNull(parameterName, "parameterName is required");
/* 211 */     this.parameterName = parameterName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIgnoreAcceptHeader(boolean ignoreAcceptHeader)
/*     */   {
/* 219 */     this.ignoreAcceptHeader = ignoreAcceptHeader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultContentType(MediaType contentType)
/*     */   {
/* 228 */     this.defaultNegotiationStrategy = new FixedContentNegotiationStrategy(contentType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultContentTypeStrategy(ContentNegotiationStrategy strategy)
/*     */   {
/* 239 */     this.defaultNegotiationStrategy = strategy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setServletContext(ServletContext servletContext)
/*     */   {
/* 247 */     this.servletContext = servletContext;
/*     */   }
/*     */   
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 253 */     List<ContentNegotiationStrategy> strategies = new ArrayList();
/*     */     
/* 255 */     if (this.favorPathExtension) { PathExtensionContentNegotiationStrategy strategy;
/*     */       PathExtensionContentNegotiationStrategy strategy;
/* 257 */       if ((this.servletContext != null) && (!isUseJafTurnedOff())) {
/* 258 */         strategy = new ServletPathExtensionContentNegotiationStrategy(this.servletContext, this.mediaTypes);
/*     */       }
/*     */       else
/*     */       {
/* 262 */         strategy = new PathExtensionContentNegotiationStrategy(this.mediaTypes);
/*     */       }
/* 264 */       strategy.setIgnoreUnknownExtensions(this.ignoreUnknownPathExtensions);
/* 265 */       if (this.useJaf != null) {
/* 266 */         strategy.setUseJaf(this.useJaf.booleanValue());
/*     */       }
/* 268 */       strategies.add(strategy);
/*     */     }
/*     */     
/* 271 */     if (this.favorParameter) {
/* 272 */       ParameterContentNegotiationStrategy strategy = new ParameterContentNegotiationStrategy(this.mediaTypes);
/*     */       
/* 274 */       strategy.setParameterName(this.parameterName);
/* 275 */       strategies.add(strategy);
/*     */     }
/*     */     
/* 278 */     if (!this.ignoreAcceptHeader) {
/* 279 */       strategies.add(new HeaderContentNegotiationStrategy());
/*     */     }
/*     */     
/* 282 */     if (this.defaultNegotiationStrategy != null) {
/* 283 */       strategies.add(this.defaultNegotiationStrategy);
/*     */     }
/*     */     
/* 286 */     this.contentNegotiationManager = new ContentNegotiationManager(strategies);
/*     */   }
/*     */   
/*     */   public ContentNegotiationManager getObject()
/*     */   {
/* 291 */     return this.contentNegotiationManager;
/*     */   }
/*     */   
/*     */   public Class<?> getObjectType()
/*     */   {
/* 296 */     return ContentNegotiationManager.class;
/*     */   }
/*     */   
/*     */   public boolean isSingleton()
/*     */   {
/* 301 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\accept\ContentNegotiationManagerFactoryBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */