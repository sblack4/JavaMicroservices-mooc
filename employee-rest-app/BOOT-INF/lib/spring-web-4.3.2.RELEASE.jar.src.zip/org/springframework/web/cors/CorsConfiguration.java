/*     */ package org.springframework.web.cors;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CorsConfiguration
/*     */ {
/*     */   public static final String ALL = "*";
/*     */   private List<String> allowedOrigins;
/*     */   private List<String> allowedMethods;
/*     */   private List<String> allowedHeaders;
/*     */   private List<String> exposedHeaders;
/*     */   private Boolean allowCredentials;
/*     */   private Long maxAge;
/*     */   
/*     */   public CorsConfiguration() {}
/*     */   
/*     */   public CorsConfiguration(CorsConfiguration other)
/*     */   {
/*  68 */     this.allowedOrigins = other.allowedOrigins;
/*  69 */     this.allowedMethods = other.allowedMethods;
/*  70 */     this.allowedHeaders = other.allowedHeaders;
/*  71 */     this.exposedHeaders = other.exposedHeaders;
/*  72 */     this.allowCredentials = other.allowCredentials;
/*  73 */     this.maxAge = other.maxAge;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CorsConfiguration combine(CorsConfiguration other)
/*     */   {
/*  85 */     if (other == null) {
/*  86 */       return this;
/*     */     }
/*  88 */     CorsConfiguration config = new CorsConfiguration(this);
/*  89 */     config.setAllowedOrigins(combine(getAllowedOrigins(), other.getAllowedOrigins()));
/*  90 */     config.setAllowedMethods(combine(getAllowedMethods(), other.getAllowedMethods()));
/*  91 */     config.setAllowedHeaders(combine(getAllowedHeaders(), other.getAllowedHeaders()));
/*  92 */     config.setExposedHeaders(combine(getExposedHeaders(), other.getExposedHeaders()));
/*  93 */     Boolean allowCredentials = other.getAllowCredentials();
/*  94 */     if (allowCredentials != null) {
/*  95 */       config.setAllowCredentials(allowCredentials);
/*     */     }
/*  97 */     Long maxAge = other.getMaxAge();
/*  98 */     if (maxAge != null) {
/*  99 */       config.setMaxAge(maxAge);
/*     */     }
/* 101 */     return config;
/*     */   }
/*     */   
/*     */   private List<String> combine(List<String> source, List<String> other) {
/* 105 */     if ((other == null) || (other.contains("*"))) {
/* 106 */       return source;
/*     */     }
/* 108 */     if ((source == null) || (source.contains("*"))) {
/* 109 */       return other;
/*     */     }
/* 111 */     List<String> combined = new ArrayList(source);
/* 112 */     combined.addAll(other);
/* 113 */     return combined;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAllowedOrigins(List<String> allowedOrigins)
/*     */   {
/* 123 */     this.allowedOrigins = (allowedOrigins != null ? new ArrayList(allowedOrigins) : null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getAllowedOrigins()
/*     */   {
/* 132 */     return this.allowedOrigins;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addAllowedOrigin(String origin)
/*     */   {
/* 139 */     if (this.allowedOrigins == null) {
/* 140 */       this.allowedOrigins = new ArrayList();
/*     */     }
/* 142 */     this.allowedOrigins.add(origin);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAllowedMethods(List<String> allowedMethods)
/*     */   {
/* 153 */     this.allowedMethods = (allowedMethods != null ? new ArrayList(allowedMethods) : null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getAllowedMethods()
/*     */   {
/* 164 */     return this.allowedMethods;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addAllowedMethod(HttpMethod method)
/*     */   {
/* 171 */     if (method != null) {
/* 172 */       addAllowedMethod(method.name());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addAllowedMethod(String method)
/*     */   {
/* 180 */     if (StringUtils.hasText(method)) {
/* 181 */       if (this.allowedMethods == null) {
/* 182 */         this.allowedMethods = new ArrayList();
/*     */       }
/* 184 */       this.allowedMethods.add(method);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAllowedHeaders(List<String> allowedHeaders)
/*     */   {
/* 199 */     this.allowedHeaders = (allowedHeaders != null ? new ArrayList(allowedHeaders) : null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getAllowedHeaders()
/*     */   {
/* 208 */     return this.allowedHeaders;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addAllowedHeader(String allowedHeader)
/*     */   {
/* 215 */     if (this.allowedHeaders == null) {
/* 216 */       this.allowedHeaders = new ArrayList();
/*     */     }
/* 218 */     this.allowedHeaders.add(allowedHeader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExposedHeaders(List<String> exposedHeaders)
/*     */   {
/* 230 */     if ((exposedHeaders != null) && (exposedHeaders.contains("*"))) {
/* 231 */       throw new IllegalArgumentException("'*' is not a valid exposed header value");
/*     */     }
/* 233 */     this.exposedHeaders = (exposedHeaders == null ? null : new ArrayList(exposedHeaders));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getExposedHeaders()
/*     */   {
/* 242 */     return this.exposedHeaders;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addExposedHeader(String exposedHeader)
/*     */   {
/* 250 */     if ("*".equals(exposedHeader)) {
/* 251 */       throw new IllegalArgumentException("'*' is not a valid exposed header value");
/*     */     }
/* 253 */     if (this.exposedHeaders == null) {
/* 254 */       this.exposedHeaders = new ArrayList();
/*     */     }
/* 256 */     this.exposedHeaders.add(exposedHeader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAllowCredentials(Boolean allowCredentials)
/*     */   {
/* 264 */     this.allowCredentials = allowCredentials;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean getAllowCredentials()
/*     */   {
/* 272 */     return this.allowCredentials;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaxAge(Long maxAge)
/*     */   {
/* 281 */     this.maxAge = maxAge;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Long getMaxAge()
/*     */   {
/* 289 */     return this.maxAge;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String checkOrigin(String requestOrigin)
/*     */   {
/* 300 */     if (!StringUtils.hasText(requestOrigin)) {
/* 301 */       return null;
/*     */     }
/* 303 */     if (ObjectUtils.isEmpty(this.allowedOrigins)) {
/* 304 */       return null;
/*     */     }
/*     */     
/* 307 */     if (this.allowedOrigins.contains("*")) {
/* 308 */       if (this.allowCredentials != Boolean.TRUE) {
/* 309 */         return "*";
/*     */       }
/*     */       
/* 312 */       return requestOrigin;
/*     */     }
/*     */     
/* 315 */     for (String allowedOrigin : this.allowedOrigins) {
/* 316 */       if (requestOrigin.equalsIgnoreCase(allowedOrigin)) {
/* 317 */         return requestOrigin;
/*     */       }
/*     */     }
/*     */     
/* 321 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<HttpMethod> checkHttpMethod(HttpMethod requestMethod)
/*     */   {
/* 333 */     if (requestMethod == null) {
/* 334 */       return null;
/*     */     }
/* 336 */     List<String> allowedMethods = this.allowedMethods != null ? this.allowedMethods : new ArrayList();
/*     */     
/* 338 */     if (allowedMethods.contains("*")) {
/* 339 */       return Collections.singletonList(requestMethod);
/*     */     }
/* 341 */     if (allowedMethods.isEmpty()) {
/* 342 */       allowedMethods.add(HttpMethod.GET.name());
/* 343 */       allowedMethods.add(HttpMethod.HEAD.name());
/*     */     }
/* 345 */     List<HttpMethod> result = new ArrayList(allowedMethods.size());
/* 346 */     boolean allowed = false;
/* 347 */     for (String method : allowedMethods) {
/* 348 */       if (requestMethod.matches(method)) {
/* 349 */         allowed = true;
/*     */       }
/* 351 */       HttpMethod resolved = HttpMethod.resolve(method);
/* 352 */       if (resolved != null) {
/* 353 */         result.add(resolved);
/*     */       }
/*     */     }
/* 356 */     return allowed ? result : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> checkHeaders(List<String> requestHeaders)
/*     */   {
/* 368 */     if (requestHeaders == null) {
/* 369 */       return null;
/*     */     }
/* 371 */     if (requestHeaders.isEmpty()) {
/* 372 */       return Collections.emptyList();
/*     */     }
/* 374 */     if (ObjectUtils.isEmpty(this.allowedHeaders)) {
/* 375 */       return null;
/*     */     }
/*     */     
/* 378 */     boolean allowAnyHeader = this.allowedHeaders.contains("*");
/* 379 */     List<String> result = new ArrayList();
/* 380 */     for (Iterator localIterator1 = requestHeaders.iterator(); localIterator1.hasNext();) { requestHeader = (String)localIterator1.next();
/* 381 */       if (StringUtils.hasText(requestHeader)) {
/* 382 */         requestHeader = requestHeader.trim();
/* 383 */         for (String allowedHeader : this.allowedHeaders)
/* 384 */           if ((allowAnyHeader) || (requestHeader.equalsIgnoreCase(allowedHeader))) {
/* 385 */             result.add(requestHeader);
/* 386 */             break;
/*     */           }
/*     */       }
/*     */     }
/*     */     String requestHeader;
/* 391 */     return result.isEmpty() ? null : result;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-web-4.3.2.RELEASE.jar!\org\springframework\web\cors\CorsConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */