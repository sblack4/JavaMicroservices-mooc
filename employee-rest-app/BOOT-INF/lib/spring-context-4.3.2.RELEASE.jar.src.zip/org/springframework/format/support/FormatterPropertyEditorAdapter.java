/*    */ package org.springframework.format.support;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ import java.text.ParseException;
/*    */ import org.springframework.context.i18n.LocaleContextHolder;
/*    */ import org.springframework.format.Formatter;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FormatterPropertyEditorAdapter
/*    */   extends PropertyEditorSupport
/*    */ {
/*    */   private final Formatter<Object> formatter;
/*    */   
/*    */   public FormatterPropertyEditorAdapter(Formatter<?> formatter)
/*    */   {
/* 45 */     Assert.notNull(formatter, "Formatter must not be null");
/* 46 */     this.formatter = formatter;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Class<?> getFieldType()
/*    */   {
/* 58 */     return FormattingConversionService.getFieldType(this.formatter);
/*    */   }
/*    */   
/*    */   public void setAsText(String text)
/*    */     throws IllegalArgumentException
/*    */   {
/* 64 */     if (StringUtils.hasText(text)) {
/*    */       try {
/* 66 */         setValue(this.formatter.parse(text, LocaleContextHolder.getLocale()));
/*    */       }
/*    */       catch (ParseException ex) {
/* 69 */         throw new IllegalArgumentException("Parse attempt failed for value [" + text + "]", ex);
/*    */       }
/*    */       
/*    */     } else {
/* 73 */       setValue(null);
/*    */     }
/*    */   }
/*    */   
/*    */   public String getAsText()
/*    */   {
/* 79 */     Object value = getValue();
/* 80 */     return value != null ? this.formatter.print(value, LocaleContextHolder.getLocale()) : "";
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\format\support\FormatterPropertyEditorAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */