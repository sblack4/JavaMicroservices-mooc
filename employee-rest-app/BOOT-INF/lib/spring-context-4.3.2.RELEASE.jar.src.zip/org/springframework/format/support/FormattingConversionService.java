/*     */ package org.springframework.format.support;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.text.ParseException;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.context.EmbeddedValueResolverAware;
/*     */ import org.springframework.context.i18n.LocaleContextHolder;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*     */ import org.springframework.core.convert.support.GenericConversionService;
/*     */ import org.springframework.format.AnnotationFormatterFactory;
/*     */ import org.springframework.format.Formatter;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.format.Parser;
/*     */ import org.springframework.format.Printer;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormattingConversionService
/*     */   extends GenericConversionService
/*     */   implements FormatterRegistry, EmbeddedValueResolverAware
/*     */ {
/*     */   private StringValueResolver embeddedValueResolver;
/*  55 */   private final Map<AnnotationConverterKey, GenericConverter> cachedPrinters = new ConcurrentHashMap(64);
/*     */   
/*     */ 
/*  58 */   private final Map<AnnotationConverterKey, GenericConverter> cachedParsers = new ConcurrentHashMap(64);
/*     */   
/*     */ 
/*     */ 
/*     */   public void setEmbeddedValueResolver(StringValueResolver resolver)
/*     */   {
/*  64 */     this.embeddedValueResolver = resolver;
/*     */   }
/*     */   
/*     */ 
/*     */   public void addFormatter(Formatter<?> formatter)
/*     */   {
/*  70 */     addFormatterForFieldType(getFieldType(formatter), formatter);
/*     */   }
/*     */   
/*     */   public void addFormatterForFieldType(Class<?> fieldType, Formatter<?> formatter)
/*     */   {
/*  75 */     addConverter(new PrinterConverter(fieldType, formatter, this));
/*  76 */     addConverter(new ParserConverter(fieldType, formatter, this));
/*     */   }
/*     */   
/*     */   public void addFormatterForFieldType(Class<?> fieldType, Printer<?> printer, Parser<?> parser)
/*     */   {
/*  81 */     addConverter(new PrinterConverter(fieldType, printer, this));
/*  82 */     addConverter(new ParserConverter(fieldType, parser, this));
/*     */   }
/*     */   
/*     */   public void addFormatterForFieldAnnotation(AnnotationFormatterFactory<? extends Annotation> annotationFormatterFactory)
/*     */   {
/*  87 */     Class<? extends Annotation> annotationType = getAnnotationType(annotationFormatterFactory);
/*  88 */     if ((this.embeddedValueResolver != null) && ((annotationFormatterFactory instanceof EmbeddedValueResolverAware))) {
/*  89 */       ((EmbeddedValueResolverAware)annotationFormatterFactory).setEmbeddedValueResolver(this.embeddedValueResolver);
/*     */     }
/*  91 */     Set<Class<?>> fieldTypes = annotationFormatterFactory.getFieldTypes();
/*  92 */     for (Class<?> fieldType : fieldTypes) {
/*  93 */       addConverter(new AnnotationPrinterConverter(annotationType, annotationFormatterFactory, fieldType));
/*  94 */       addConverter(new AnnotationParserConverter(annotationType, annotationFormatterFactory, fieldType));
/*     */     }
/*     */   }
/*     */   
/*     */   static Class<?> getFieldType(Formatter<?> formatter)
/*     */   {
/* 100 */     Class<?> fieldType = GenericTypeResolver.resolveTypeArgument(formatter.getClass(), Formatter.class);
/* 101 */     if (fieldType == null)
/*     */     {
/* 103 */       throw new IllegalArgumentException("Unable to extract parameterized field type argument from Formatter [" + formatter.getClass().getName() + "]; does the formatter parameterize the <T> generic type?");
/*     */     }
/* 105 */     return fieldType;
/*     */   }
/*     */   
/*     */ 
/*     */   static Class<? extends Annotation> getAnnotationType(AnnotationFormatterFactory<? extends Annotation> factory)
/*     */   {
/* 111 */     Class<? extends Annotation> annotationType = GenericTypeResolver.resolveTypeArgument(factory.getClass(), AnnotationFormatterFactory.class);
/* 112 */     if (annotationType == null)
/*     */     {
/* 114 */       throw new IllegalArgumentException("Unable to extract parameterized Annotation type argument from AnnotationFormatterFactory [" + factory.getClass().getName() + "]; does the factory parameterize the <A extends Annotation> generic type?");
/*     */     }
/*     */     
/* 117 */     return annotationType;
/*     */   }
/*     */   
/*     */ 
/*     */   private static class PrinterConverter
/*     */     implements GenericConverter
/*     */   {
/*     */     private final Class<?> fieldType;
/*     */     
/*     */     private final TypeDescriptor printerObjectType;
/*     */     
/*     */     private final Printer printer;
/*     */     private final ConversionService conversionService;
/*     */     
/*     */     public PrinterConverter(Class<?> fieldType, Printer<?> printer, ConversionService conversionService)
/*     */     {
/* 133 */       this.fieldType = fieldType;
/* 134 */       this.printerObjectType = TypeDescriptor.valueOf(resolvePrinterObjectType(printer));
/* 135 */       this.printer = printer;
/* 136 */       this.conversionService = conversionService;
/*     */     }
/*     */     
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*     */     {
/* 141 */       return Collections.singleton(new GenericConverter.ConvertiblePair(this.fieldType, String.class));
/*     */     }
/*     */     
/*     */ 
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 147 */       if (source == null) {
/* 148 */         return "";
/*     */       }
/* 150 */       if (!sourceType.isAssignableTo(this.printerObjectType)) {
/* 151 */         source = this.conversionService.convert(source, sourceType, this.printerObjectType);
/*     */       }
/* 153 */       return this.printer.print(source, LocaleContextHolder.getLocale());
/*     */     }
/*     */     
/*     */     private Class<?> resolvePrinterObjectType(Printer<?> printer) {
/* 157 */       return GenericTypeResolver.resolveTypeArgument(printer.getClass(), Printer.class);
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 162 */       return this.fieldType.getName() + " -> " + String.class.getName() + " : " + this.printer;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class ParserConverter
/*     */     implements GenericConverter
/*     */   {
/*     */     private final Class<?> fieldType;
/*     */     private final Parser<?> parser;
/*     */     private final ConversionService conversionService;
/*     */     
/*     */     public ParserConverter(Class<?> fieldType, Parser<?> parser, ConversionService conversionService)
/*     */     {
/* 176 */       this.fieldType = fieldType;
/* 177 */       this.parser = parser;
/* 178 */       this.conversionService = conversionService;
/*     */     }
/*     */     
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*     */     {
/* 183 */       return Collections.singleton(new GenericConverter.ConvertiblePair(String.class, this.fieldType));
/*     */     }
/*     */     
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 188 */       String text = (String)source;
/* 189 */       if (!StringUtils.hasText(text)) {
/* 190 */         return null;
/*     */       }
/*     */       try
/*     */       {
/* 194 */         result = this.parser.parse(text, LocaleContextHolder.getLocale());
/*     */       } catch (ParseException ex) {
/*     */         Object result;
/* 197 */         throw new IllegalArgumentException("Parse attempt failed for value [" + text + "]", ex); }
/*     */       Object result;
/* 199 */       if (result == null) {
/* 200 */         throw new IllegalStateException("Parsers are not allowed to return null");
/*     */       }
/* 202 */       TypeDescriptor resultType = TypeDescriptor.valueOf(result.getClass());
/* 203 */       if (!resultType.isAssignableTo(targetType)) {
/* 204 */         result = this.conversionService.convert(result, resultType, targetType);
/*     */       }
/* 206 */       return result;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 211 */       return String.class.getName() + " -> " + this.fieldType.getName() + ": " + this.parser;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private class AnnotationPrinterConverter
/*     */     implements ConditionalGenericConverter
/*     */   {
/*     */     private final Class<? extends Annotation> annotationType;
/*     */     
/*     */     private final AnnotationFormatterFactory annotationFormatterFactory;
/*     */     
/*     */     private final Class<?> fieldType;
/*     */     
/*     */     public AnnotationPrinterConverter(AnnotationFormatterFactory<?> annotationType, Class<?> annotationFormatterFactory)
/*     */     {
/* 227 */       this.annotationType = annotationType;
/* 228 */       this.annotationFormatterFactory = annotationFormatterFactory;
/* 229 */       this.fieldType = fieldType;
/*     */     }
/*     */     
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*     */     {
/* 234 */       return Collections.singleton(new GenericConverter.ConvertiblePair(this.fieldType, String.class));
/*     */     }
/*     */     
/*     */     public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 239 */       return sourceType.hasAnnotation(this.annotationType);
/*     */     }
/*     */     
/*     */ 
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 245 */       Annotation ann = sourceType.getAnnotation(this.annotationType);
/* 246 */       if (ann == null)
/*     */       {
/* 248 */         throw new IllegalStateException("Expected [" + this.annotationType.getName() + "] to be present on " + sourceType);
/*     */       }
/* 250 */       FormattingConversionService.AnnotationConverterKey converterKey = new FormattingConversionService.AnnotationConverterKey(ann, sourceType.getObjectType());
/* 251 */       GenericConverter converter = (GenericConverter)FormattingConversionService.this.cachedPrinters.get(converterKey);
/* 252 */       if (converter == null) {
/* 253 */         Printer<?> printer = this.annotationFormatterFactory.getPrinter(converterKey
/* 254 */           .getAnnotation(), converterKey.getFieldType());
/* 255 */         converter = new FormattingConversionService.PrinterConverter(this.fieldType, printer, FormattingConversionService.this);
/* 256 */         FormattingConversionService.this.cachedPrinters.put(converterKey, converter);
/*     */       }
/* 258 */       return converter.convert(source, sourceType, targetType);
/*     */     }
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/* 264 */       return "@" + this.annotationType.getName() + " " + this.fieldType.getName() + " -> " + String.class.getName() + ": " + this.annotationFormatterFactory;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private class AnnotationParserConverter
/*     */     implements ConditionalGenericConverter
/*     */   {
/*     */     private final Class<? extends Annotation> annotationType;
/*     */     
/*     */     private final AnnotationFormatterFactory annotationFormatterFactory;
/*     */     
/*     */     private final Class<?> fieldType;
/*     */     
/*     */     public AnnotationParserConverter(AnnotationFormatterFactory<?> annotationType, Class<?> annotationFormatterFactory)
/*     */     {
/* 280 */       this.annotationType = annotationType;
/* 281 */       this.annotationFormatterFactory = annotationFormatterFactory;
/* 282 */       this.fieldType = fieldType;
/*     */     }
/*     */     
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*     */     {
/* 287 */       return Collections.singleton(new GenericConverter.ConvertiblePair(String.class, this.fieldType));
/*     */     }
/*     */     
/*     */     public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 292 */       return targetType.hasAnnotation(this.annotationType);
/*     */     }
/*     */     
/*     */ 
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 298 */       Annotation ann = targetType.getAnnotation(this.annotationType);
/* 299 */       if (ann == null)
/*     */       {
/* 301 */         throw new IllegalStateException("Expected [" + this.annotationType.getName() + "] to be present on " + targetType);
/*     */       }
/* 303 */       FormattingConversionService.AnnotationConverterKey converterKey = new FormattingConversionService.AnnotationConverterKey(ann, targetType.getObjectType());
/* 304 */       GenericConverter converter = (GenericConverter)FormattingConversionService.this.cachedParsers.get(converterKey);
/* 305 */       if (converter == null) {
/* 306 */         Parser<?> parser = this.annotationFormatterFactory.getParser(converterKey
/* 307 */           .getAnnotation(), converterKey.getFieldType());
/* 308 */         converter = new FormattingConversionService.ParserConverter(this.fieldType, parser, FormattingConversionService.this);
/* 309 */         FormattingConversionService.this.cachedParsers.put(converterKey, converter);
/*     */       }
/* 311 */       return converter.convert(source, sourceType, targetType);
/*     */     }
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/* 317 */       return String.class.getName() + " -> @" + this.annotationType.getName() + " " + this.fieldType.getName() + ": " + this.annotationFormatterFactory;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class AnnotationConverterKey
/*     */   {
/*     */     private final Annotation annotation;
/*     */     private final Class<?> fieldType;
/*     */     
/*     */     public AnnotationConverterKey(Annotation annotation, Class<?> fieldType)
/*     */     {
/* 329 */       this.annotation = annotation;
/* 330 */       this.fieldType = fieldType;
/*     */     }
/*     */     
/*     */     public Annotation getAnnotation() {
/* 334 */       return this.annotation;
/*     */     }
/*     */     
/*     */     public Class<?> getFieldType() {
/* 338 */       return this.fieldType;
/*     */     }
/*     */     
/*     */     public boolean equals(Object other)
/*     */     {
/* 343 */       if (this == other) {
/* 344 */         return true;
/*     */       }
/* 346 */       if (!(other instanceof AnnotationConverterKey)) {
/* 347 */         return false;
/*     */       }
/* 349 */       AnnotationConverterKey otherKey = (AnnotationConverterKey)other;
/* 350 */       return (this.annotation.equals(otherKey.annotation)) && (this.fieldType.equals(otherKey.fieldType));
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 355 */       return this.annotation.hashCode() + 29 * this.fieldType.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\format\support\FormattingConversionService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */