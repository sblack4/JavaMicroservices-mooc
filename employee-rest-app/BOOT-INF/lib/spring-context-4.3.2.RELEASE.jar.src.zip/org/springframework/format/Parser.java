package org.springframework.format;

import java.text.ParseException;
import java.util.Locale;

public abstract interface Parser<T>
{
  public abstract T parse(String paramString, Locale paramLocale)
    throws ParseException;
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\format\Parser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */