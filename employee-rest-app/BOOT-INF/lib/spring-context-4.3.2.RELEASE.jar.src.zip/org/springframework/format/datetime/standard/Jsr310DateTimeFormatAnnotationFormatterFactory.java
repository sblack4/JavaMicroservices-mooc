/*    */ package org.springframework.format.datetime.standard;
/*    */ 
/*    */ import java.time.LocalDate;
/*    */ import java.time.LocalDateTime;
/*    */ import java.time.LocalTime;
/*    */ import java.time.OffsetDateTime;
/*    */ import java.time.OffsetTime;
/*    */ import java.time.ZonedDateTime;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.springframework.context.support.EmbeddedValueResolutionSupport;
/*    */ import org.springframework.format.AnnotationFormatterFactory;
/*    */ import org.springframework.format.Parser;
/*    */ import org.springframework.format.Printer;
/*    */ import org.springframework.format.annotation.DateTimeFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Jsr310DateTimeFormatAnnotationFormatterFactory
/*    */   extends EmbeddedValueResolutionSupport
/*    */   implements AnnotationFormatterFactory<DateTimeFormat>
/*    */ {
/*    */   private static final Set<Class<?>> FIELD_TYPES;
/*    */   
/*    */   static
/*    */   {
/* 52 */     Set<Class<?>> fieldTypes = new HashSet(8);
/* 53 */     fieldTypes.add(LocalDate.class);
/* 54 */     fieldTypes.add(LocalTime.class);
/* 55 */     fieldTypes.add(LocalDateTime.class);
/* 56 */     fieldTypes.add(ZonedDateTime.class);
/* 57 */     fieldTypes.add(OffsetDateTime.class);
/* 58 */     fieldTypes.add(OffsetTime.class);
/* 59 */     FIELD_TYPES = Collections.unmodifiableSet(fieldTypes);
/*    */   }
/*    */   
/*    */ 
/*    */   public final Set<Class<?>> getFieldTypes()
/*    */   {
/* 65 */     return FIELD_TYPES;
/*    */   }
/*    */   
/*    */   public Printer<?> getPrinter(DateTimeFormat annotation, Class<?> fieldType)
/*    */   {
/* 70 */     DateTimeFormatter formatter = getFormatter(annotation, fieldType);
/* 71 */     return new TemporalAccessorPrinter(formatter);
/*    */   }
/*    */   
/*    */ 
/*    */   public Parser<?> getParser(DateTimeFormat annotation, Class<?> fieldType)
/*    */   {
/* 77 */     DateTimeFormatter formatter = getFormatter(annotation, fieldType);
/* 78 */     return new TemporalAccessorParser(fieldType, formatter);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected DateTimeFormatter getFormatter(DateTimeFormat annotation, Class<?> fieldType)
/*    */   {
/* 88 */     DateTimeFormatterFactory factory = new DateTimeFormatterFactory();
/* 89 */     factory.setStylePattern(resolveEmbeddedValue(annotation.style()));
/* 90 */     factory.setIso(annotation.iso());
/* 91 */     factory.setPattern(resolveEmbeddedValue(annotation.pattern()));
/* 92 */     return factory.createDateTimeFormatter();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\format\datetime\standard\Jsr310DateTimeFormatAnnotationFormatterFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */