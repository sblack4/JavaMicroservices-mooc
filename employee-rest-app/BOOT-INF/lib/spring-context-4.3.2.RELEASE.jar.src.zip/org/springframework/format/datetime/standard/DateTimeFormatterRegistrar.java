/*     */ package org.springframework.format.datetime.standard;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ import java.time.MonthDay;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.OffsetTime;
/*     */ import java.time.Period;
/*     */ import java.time.YearMonth;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.format.FormatStyle;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.format.FormatterRegistrar;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.format.annotation.DateTimeFormat.ISO;
/*     */ import org.springframework.lang.UsesJava8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @UsesJava8
/*     */ public class DateTimeFormatterRegistrar
/*     */   implements FormatterRegistrar
/*     */ {
/*     */   private static enum Type
/*     */   {
/*  57 */     DATE,  TIME,  DATE_TIME;
/*     */     
/*     */ 
/*     */     private Type() {}
/*     */   }
/*     */   
/*  63 */   private final Map<Type, DateTimeFormatter> formatters = new HashMap();
/*     */   
/*     */ 
/*     */   private final Map<Type, DateTimeFormatterFactory> factories;
/*     */   
/*     */ 
/*     */ 
/*     */   public DateTimeFormatterRegistrar()
/*     */   {
/*  72 */     this.factories = new HashMap();
/*  73 */     for (Type type : Type.values()) {
/*  74 */       this.factories.put(type, new DateTimeFormatterFactory());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUseIsoFormat(boolean useIsoFormat)
/*     */   {
/*  86 */     ((DateTimeFormatterFactory)this.factories.get(Type.DATE)).setIso(useIsoFormat ? DateTimeFormat.ISO.DATE : null);
/*  87 */     ((DateTimeFormatterFactory)this.factories.get(Type.TIME)).setIso(useIsoFormat ? DateTimeFormat.ISO.TIME : null);
/*  88 */     ((DateTimeFormatterFactory)this.factories.get(Type.DATE_TIME)).setIso(useIsoFormat ? DateTimeFormat.ISO.DATE_TIME : null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDateStyle(FormatStyle dateStyle)
/*     */   {
/*  96 */     ((DateTimeFormatterFactory)this.factories.get(Type.DATE)).setDateStyle(dateStyle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeStyle(FormatStyle timeStyle)
/*     */   {
/* 104 */     ((DateTimeFormatterFactory)this.factories.get(Type.TIME)).setTimeStyle(timeStyle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDateTimeStyle(FormatStyle dateTimeStyle)
/*     */   {
/* 112 */     ((DateTimeFormatterFactory)this.factories.get(Type.DATE_TIME)).setDateTimeStyle(dateTimeStyle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDateFormatter(DateTimeFormatter formatter)
/*     */   {
/* 125 */     this.formatters.put(Type.DATE, formatter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeFormatter(DateTimeFormatter formatter)
/*     */   {
/* 138 */     this.formatters.put(Type.TIME, formatter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDateTimeFormatter(DateTimeFormatter formatter)
/*     */   {
/* 152 */     this.formatters.put(Type.DATE_TIME, formatter);
/*     */   }
/*     */   
/*     */ 
/*     */   public void registerFormatters(FormatterRegistry registry)
/*     */   {
/* 158 */     DateTimeConverters.registerConverters(registry);
/*     */     
/* 160 */     DateTimeFormatter dateFormatter = getFormatter(Type.DATE);
/* 161 */     DateTimeFormatter timeFormatter = getFormatter(Type.TIME);
/* 162 */     DateTimeFormatter dateTimeFormatter = getFormatter(Type.DATE_TIME);
/*     */     
/* 164 */     registry.addFormatterForFieldType(LocalDate.class, new TemporalAccessorPrinter(dateFormatter), new TemporalAccessorParser(LocalDate.class, dateFormatter));
/*     */     
/*     */ 
/*     */ 
/* 168 */     registry.addFormatterForFieldType(LocalTime.class, new TemporalAccessorPrinter(timeFormatter), new TemporalAccessorParser(LocalTime.class, timeFormatter));
/*     */     
/*     */ 
/*     */ 
/* 172 */     registry.addFormatterForFieldType(LocalDateTime.class, new TemporalAccessorPrinter(dateTimeFormatter), new TemporalAccessorParser(LocalDateTime.class, dateTimeFormatter));
/*     */     
/*     */ 
/*     */ 
/* 176 */     registry.addFormatterForFieldType(ZonedDateTime.class, new TemporalAccessorPrinter(dateTimeFormatter), new TemporalAccessorParser(ZonedDateTime.class, dateTimeFormatter));
/*     */     
/*     */ 
/*     */ 
/* 180 */     registry.addFormatterForFieldType(OffsetDateTime.class, new TemporalAccessorPrinter(dateTimeFormatter), new TemporalAccessorParser(OffsetDateTime.class, dateTimeFormatter));
/*     */     
/*     */ 
/*     */ 
/* 184 */     registry.addFormatterForFieldType(OffsetTime.class, new TemporalAccessorPrinter(timeFormatter), new TemporalAccessorParser(OffsetTime.class, timeFormatter));
/*     */     
/*     */ 
/*     */ 
/* 188 */     registry.addFormatterForFieldType(Instant.class, new InstantFormatter());
/* 189 */     registry.addFormatterForFieldType(Period.class, new PeriodFormatter());
/* 190 */     registry.addFormatterForFieldType(Duration.class, new DurationFormatter());
/* 191 */     registry.addFormatterForFieldType(YearMonth.class, new YearMonthFormatter());
/* 192 */     registry.addFormatterForFieldType(MonthDay.class, new MonthDayFormatter());
/*     */     
/* 194 */     registry.addFormatterForFieldAnnotation(new Jsr310DateTimeFormatAnnotationFormatterFactory());
/*     */   }
/*     */   
/*     */   private DateTimeFormatter getFormatter(Type type) {
/* 198 */     DateTimeFormatter formatter = (DateTimeFormatter)this.formatters.get(type);
/* 199 */     if (formatter != null) {
/* 200 */       return formatter;
/*     */     }
/* 202 */     DateTimeFormatter fallbackFormatter = getFallbackFormatter(type);
/* 203 */     return ((DateTimeFormatterFactory)this.factories.get(type)).createDateTimeFormatter(fallbackFormatter);
/*     */   }
/*     */   
/*     */   private DateTimeFormatter getFallbackFormatter(Type type) {
/* 207 */     switch (type) {
/* 208 */     case DATE:  return DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT);
/* 209 */     case TIME:  return DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT); }
/* 210 */     return DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\format\datetime\standard\DateTimeFormatterRegistrar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */