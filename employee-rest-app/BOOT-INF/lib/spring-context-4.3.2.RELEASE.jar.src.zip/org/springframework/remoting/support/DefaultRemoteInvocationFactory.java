/*    */ package org.springframework.remoting.support;
/*    */ 
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultRemoteInvocationFactory
/*    */   implements RemoteInvocationFactory
/*    */ {
/*    */   public RemoteInvocation createRemoteInvocation(MethodInvocation methodInvocation)
/*    */   {
/* 32 */     return new RemoteInvocation(methodInvocation);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\remoting\support\DefaultRemoteInvocationFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */