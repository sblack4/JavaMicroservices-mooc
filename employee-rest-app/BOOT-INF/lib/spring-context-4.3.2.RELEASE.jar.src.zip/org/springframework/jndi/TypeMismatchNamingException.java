/*    */ package org.springframework.jndi;
/*    */ 
/*    */ import javax.naming.NamingException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeMismatchNamingException
/*    */   extends NamingException
/*    */ {
/*    */   private Class<?> requiredType;
/*    */   private Class<?> actualType;
/*    */   
/*    */   public TypeMismatchNamingException(String jndiName, Class<?> requiredType, Class<?> actualType)
/*    */   {
/* 45 */     super("Object of type [" + actualType + "] available at JNDI location [" + jndiName + "] is not assignable to [" + requiredType
/* 46 */       .getName() + "]");
/* 47 */     this.requiredType = requiredType;
/* 48 */     this.actualType = actualType;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public TypeMismatchNamingException(String explanation)
/*    */   {
/* 56 */     super(explanation);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public final Class<?> getRequiredType()
/*    */   {
/* 64 */     return this.requiredType;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public final Class<?> getActualType()
/*    */   {
/* 71 */     return this.actualType;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\jndi\TypeMismatchNamingException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */