/*     */ package org.springframework.jmx.export.assembler;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InterfaceBasedMBeanInfoAssembler
/*     */   extends AbstractConfigurableMBeanInfoAssembler
/*     */   implements BeanClassLoaderAware, InitializingBean
/*     */ {
/*     */   private Class<?>[] managedInterfaces;
/*     */   private Properties interfaceMappings;
/*  73 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Map<String, Class<?>[]> resolvedInterfaceMappings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setManagedInterfaces(Class<?>[] managedInterfaces)
/*     */   {
/*  90 */     if (managedInterfaces != null) {
/*  91 */       for (Class<?> ifc : managedInterfaces) {
/*  92 */         if (!ifc.isInterface())
/*     */         {
/*  94 */           throw new IllegalArgumentException("Management interface [" + ifc.getName() + "] is not an interface");
/*     */         }
/*     */       }
/*     */     }
/*  98 */     this.managedInterfaces = managedInterfaces;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInterfaceMappings(Properties mappings)
/*     */   {
/* 109 */     this.interfaceMappings = mappings;
/*     */   }
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader beanClassLoader)
/*     */   {
/* 114 */     this.beanClassLoader = beanClassLoader;
/*     */   }
/*     */   
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 120 */     if (this.interfaceMappings != null) {
/* 121 */       this.resolvedInterfaceMappings = resolveInterfaceMappings(this.interfaceMappings);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Map<String, Class<?>[]> resolveInterfaceMappings(Properties mappings)
/*     */   {
/* 131 */     Map<String, Class<?>[]> resolvedMappings = new HashMap(mappings.size());
/* 132 */     for (Enumeration<?> en = mappings.propertyNames(); en.hasMoreElements();) {
/* 133 */       String beanKey = (String)en.nextElement();
/* 134 */       String[] classNames = StringUtils.commaDelimitedListToStringArray(mappings.getProperty(beanKey));
/* 135 */       Class<?>[] classes = resolveClassNames(classNames, beanKey);
/* 136 */       resolvedMappings.put(beanKey, classes);
/*     */     }
/* 138 */     return resolvedMappings;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Class<?>[] resolveClassNames(String[] classNames, String beanKey)
/*     */   {
/* 148 */     Class<?>[] classes = new Class[classNames.length];
/* 149 */     for (int x = 0; x < classes.length; x++) {
/* 150 */       Class<?> cls = ClassUtils.resolveClassName(classNames[x].trim(), this.beanClassLoader);
/* 151 */       if (!cls.isInterface()) {
/* 152 */         throw new IllegalArgumentException("Class [" + classNames[x] + "] mapped to bean key [" + beanKey + "] is no interface");
/*     */       }
/*     */       
/* 155 */       classes[x] = cls;
/*     */     }
/* 157 */     return classes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean includeReadAttribute(Method method, String beanKey)
/*     */   {
/* 172 */     return isPublicInInterface(method, beanKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean includeWriteAttribute(Method method, String beanKey)
/*     */   {
/* 186 */     return isPublicInInterface(method, beanKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean includeOperation(Method method, String beanKey)
/*     */   {
/* 200 */     return isPublicInInterface(method, beanKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isPublicInInterface(Method method, String beanKey)
/*     */   {
/* 212 */     return ((method.getModifiers() & 0x1) > 0) && (isDeclaredInInterface(method, beanKey));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isDeclaredInInterface(Method method, String beanKey)
/*     */   {
/* 220 */     Class<?>[] ifaces = null;
/*     */     
/* 222 */     if (this.resolvedInterfaceMappings != null) {
/* 223 */       ifaces = (Class[])this.resolvedInterfaceMappings.get(beanKey);
/*     */     }
/*     */     
/* 226 */     if (ifaces == null) {
/* 227 */       ifaces = this.managedInterfaces;
/* 228 */       if (ifaces == null) {
/* 229 */         ifaces = ClassUtils.getAllInterfacesForClass(method.getDeclaringClass());
/*     */       }
/*     */     }
/*     */     
/* 233 */     if (ifaces != null) {
/* 234 */       for (Class<?> ifc : ifaces) {
/* 235 */         for (Method ifcMethod : ifc.getMethods()) {
/* 236 */           if ((ifcMethod.getName().equals(method.getName())) && 
/* 237 */             (Arrays.equals(ifcMethod.getParameterTypes(), method.getParameterTypes()))) {
/* 238 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 244 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\jmx\export\assembler\InterfaceBasedMBeanInfoAssembler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */