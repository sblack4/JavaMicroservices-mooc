/*     */ package org.springframework.jmx.export.naming;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Properties;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.PropertiesLoaderUtils;
/*     */ import org.springframework.jmx.support.ObjectNameManager;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyNamingStrategy
/*     */   implements ObjectNamingStrategy, InitializingBean
/*     */ {
/*  57 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Properties mappings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Resource[] mappingLocations;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Properties mergedMappings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMappings(Properties mappings)
/*     */   {
/*  84 */     this.mappings = mappings;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMappingLocation(Resource location)
/*     */   {
/*  92 */     this.mappingLocations = new Resource[] { location };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMappingLocations(Resource[] mappingLocations)
/*     */   {
/* 100 */     this.mappingLocations = mappingLocations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws IOException
/*     */   {
/* 112 */     this.mergedMappings = new Properties();
/*     */     
/* 114 */     CollectionUtils.mergePropertiesIntoMap(this.mappings, this.mergedMappings);
/*     */     
/* 116 */     if (this.mappingLocations != null) {
/* 117 */       for (int i = 0; i < this.mappingLocations.length; i++) {
/* 118 */         Resource location = this.mappingLocations[i];
/* 119 */         if (this.logger.isInfoEnabled()) {
/* 120 */           this.logger.info("Loading JMX object name mappings file from " + location);
/*     */         }
/* 122 */         PropertiesLoaderUtils.fillProperties(this.mergedMappings, location);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName getObjectName(Object managedBean, String beanKey)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 134 */     String objectName = null;
/* 135 */     if (this.mergedMappings != null) {
/* 136 */       objectName = this.mergedMappings.getProperty(beanKey);
/*     */     }
/* 138 */     if (objectName == null) {
/* 139 */       objectName = beanKey;
/*     */     }
/* 141 */     return ObjectNameManager.getInstance(objectName);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\jmx\export\naming\KeyNamingStrategy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */