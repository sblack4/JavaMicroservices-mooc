/*    */ package org.springframework.instrument.classloading.websphere;
/*    */ 
/*    */ import java.lang.instrument.ClassFileTransformer;
/*    */ import java.lang.reflect.InvocationHandler;
/*    */ import java.lang.reflect.Method;
/*    */ import java.security.CodeSource;
/*    */ import org.springframework.util.FileCopyUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WebSphereClassPreDefinePlugin
/*    */   implements InvocationHandler
/*    */ {
/*    */   private final ClassFileTransformer transformer;
/*    */   
/*    */   public WebSphereClassPreDefinePlugin(ClassFileTransformer transformer)
/*    */   {
/* 46 */     this.transformer = transformer;
/* 47 */     ClassLoader classLoader = transformer.getClass().getClassLoader();
/*    */     
/*    */     try
/*    */     {
/* 51 */       String dummyClass = Dummy.class.getName().replace('.', '/');
/* 52 */       byte[] bytes = FileCopyUtils.copyToByteArray(classLoader.getResourceAsStream(dummyClass + ".class"));
/* 53 */       transformer.transform(classLoader, dummyClass, null, null, bytes);
/*    */     }
/*    */     catch (Throwable ex) {
/* 56 */       throw new IllegalArgumentException("Cannot load transformer", ex);
/*    */     }
/*    */   }
/*    */   
/*    */   public Object invoke(Object proxy, Method method, Object[] args)
/*    */     throws Throwable
/*    */   {
/* 63 */     String name = method.getName();
/* 64 */     if ("equals".equals(name)) {
/* 65 */       return Boolean.valueOf(proxy == args[0]);
/*    */     }
/* 67 */     if ("hashCode".equals(name)) {
/* 68 */       return Integer.valueOf(hashCode());
/*    */     }
/* 70 */     if ("toString".equals(name)) {
/* 71 */       return toString();
/*    */     }
/* 73 */     if ("transformClass".equals(name)) {
/* 74 */       return transform((String)args[0], (byte[])args[1], (CodeSource)args[2], (ClassLoader)args[3]);
/*    */     }
/*    */     
/* 77 */     throw new IllegalArgumentException("Unknown method: " + method);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected byte[] transform(String className, byte[] classfileBuffer, CodeSource codeSource, ClassLoader classLoader)
/*    */     throws Exception
/*    */   {
/* 85 */     byte[] result = this.transformer.transform(classLoader, className.replace('.', '/'), null, null, classfileBuffer);
/* 86 */     return result != null ? result : classfileBuffer;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 91 */     StringBuilder builder = new StringBuilder(getClass().getName());
/* 92 */     builder.append(" for transformer: ");
/* 93 */     builder.append(this.transformer);
/* 94 */     return builder.toString();
/*    */   }
/*    */   
/*    */   private static class Dummy {}
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\instrument\classloading\websphere\WebSphereClassPreDefinePlugin.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */