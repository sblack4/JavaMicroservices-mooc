/*    */ package org.springframework.instrument.classloading.weblogic;
/*    */ 
/*    */ import java.lang.instrument.ClassFileTransformer;
/*    */ import java.lang.instrument.IllegalClassFormatException;
/*    */ import java.lang.reflect.InvocationHandler;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WebLogicClassPreProcessorAdapter
/*    */   implements InvocationHandler
/*    */ {
/*    */   private final ClassFileTransformer transformer;
/*    */   private final ClassLoader loader;
/*    */   
/*    */   public WebLogicClassPreProcessorAdapter(ClassFileTransformer transformer, ClassLoader loader)
/*    */   {
/* 49 */     this.transformer = transformer;
/* 50 */     this.loader = loader;
/*    */   }
/*    */   
/*    */   public Object invoke(Object proxy, Method method, Object[] args)
/*    */     throws Throwable
/*    */   {
/* 56 */     String name = method.getName();
/* 57 */     if ("equals".equals(name)) {
/* 58 */       return Boolean.valueOf(proxy == args[0]);
/*    */     }
/* 60 */     if ("hashCode".equals(name)) {
/* 61 */       return Integer.valueOf(hashCode());
/*    */     }
/* 63 */     if ("toString".equals(name)) {
/* 64 */       return toString();
/*    */     }
/* 66 */     if ("initialize".equals(name)) {
/* 67 */       initialize((Hashtable)args[0]);
/* 68 */       return null;
/*    */     }
/* 70 */     if ("preProcess".equals(name)) {
/* 71 */       return preProcess((String)args[0], (byte[])args[1]);
/*    */     }
/*    */     
/* 74 */     throw new IllegalArgumentException("Unknown method: " + method);
/*    */   }
/*    */   
/*    */   public void initialize(Hashtable<?, ?> params) {}
/*    */   
/*    */   public byte[] preProcess(String className, byte[] classBytes)
/*    */   {
/*    */     try
/*    */     {
/* 83 */       byte[] result = this.transformer.transform(this.loader, className, null, null, classBytes);
/* 84 */       return result != null ? result : classBytes;
/*    */     }
/*    */     catch (IllegalClassFormatException ex) {
/* 87 */       throw new IllegalStateException("Cannot transform due to illegal class format", ex);
/*    */     }
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 93 */     return getClass().getName() + " for transformer: " + this.transformer;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\instrument\classloading\weblogic\WebLogicClassPreProcessorAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */