/*    */ package org.springframework.instrument.classloading.jboss;
/*    */ 
/*    */ import java.lang.instrument.ClassFileTransformer;
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.util.ReflectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JBossModulesAdapter
/*    */   implements JBossClassLoaderAdapter
/*    */ {
/*    */   private static final String DELEGATING_TRANSFORMER_CLASS_NAME = "org.jboss.as.server.deployment.module.DelegatingClassFileTransformer";
/*    */   private final ClassLoader classLoader;
/*    */   private final Method addTransformer;
/*    */   private final Object delegatingTransformer;
/*    */   
/*    */   public JBossModulesAdapter(ClassLoader loader)
/*    */   {
/* 47 */     this.classLoader = loader;
/*    */     try {
/* 49 */       Field transformer = ReflectionUtils.findField(loader.getClass(), "transformer");
/* 50 */       transformer.setAccessible(true);
/* 51 */       this.delegatingTransformer = transformer.get(loader);
/* 52 */       if (!this.delegatingTransformer.getClass().getName().equals("org.jboss.as.server.deployment.module.DelegatingClassFileTransformer"))
/*    */       {
/* 54 */         throw new IllegalStateException("Transformer not of the expected type DelegatingClassFileTransformer: " + this.delegatingTransformer.getClass().getName());
/*    */       }
/* 56 */       this.addTransformer = ReflectionUtils.findMethod(this.delegatingTransformer.getClass(), "addTransformer", new Class[] { ClassFileTransformer.class });
/*    */       
/* 58 */       this.addTransformer.setAccessible(true);
/*    */     }
/*    */     catch (Exception ex) {
/* 61 */       throw new IllegalStateException("Could not initialize JBoss 7 LoadTimeWeaver", ex);
/*    */     }
/*    */   }
/*    */   
/*    */   public void addTransformer(ClassFileTransformer transformer)
/*    */   {
/*    */     try {
/* 68 */       this.addTransformer.invoke(this.delegatingTransformer, new Object[] { transformer });
/*    */     }
/*    */     catch (Exception ex) {
/* 71 */       throw new IllegalStateException("Could not add transformer on JBoss 7 ClassLoader " + this.classLoader, ex);
/*    */     }
/*    */   }
/*    */   
/*    */   public ClassLoader getInstrumentableClassLoader()
/*    */   {
/* 77 */     return this.classLoader;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\instrument\classloading\jboss\JBossModulesAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */