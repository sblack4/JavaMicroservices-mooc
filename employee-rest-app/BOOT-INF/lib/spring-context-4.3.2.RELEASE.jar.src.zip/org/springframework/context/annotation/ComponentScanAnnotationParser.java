/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.Aware;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionDefaults;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.filter.AbstractTypeHierarchyTraversingFilter;
/*     */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*     */ import org.springframework.core.type.filter.AspectJTypeFilter;
/*     */ import org.springframework.core.type.filter.AssignableTypeFilter;
/*     */ import org.springframework.core.type.filter.RegexPatternTypeFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ComponentScanAnnotationParser
/*     */ {
/*     */   private final ResourceLoader resourceLoader;
/*     */   private final Environment environment;
/*     */   private final BeanDefinitionRegistry registry;
/*     */   private final BeanNameGenerator beanNameGenerator;
/*     */   
/*     */   public ComponentScanAnnotationParser(ResourceLoader resourceLoader, Environment environment, BeanNameGenerator beanNameGenerator, BeanDefinitionRegistry registry)
/*     */   {
/*  76 */     this.resourceLoader = resourceLoader;
/*  77 */     this.environment = environment;
/*  78 */     this.beanNameGenerator = beanNameGenerator;
/*  79 */     this.registry = registry;
/*     */   }
/*     */   
/*     */   public Set<BeanDefinitionHolder> parse(AnnotationAttributes componentScan, final String declaringClass)
/*     */   {
/*  84 */     Assert.state(this.environment != null, "Environment must not be null");
/*  85 */     Assert.state(this.resourceLoader != null, "ResourceLoader must not be null");
/*     */     
/*     */ 
/*  88 */     ClassPathBeanDefinitionScanner scanner = new ClassPathBeanDefinitionScanner(this.registry, componentScan.getBoolean("useDefaultFilters"));
/*  89 */     scanner.setEnvironment(this.environment);
/*  90 */     scanner.setResourceLoader(this.resourceLoader);
/*     */     
/*  92 */     Class<? extends BeanNameGenerator> generatorClass = componentScan.getClass("nameGenerator");
/*  93 */     boolean useInheritedGenerator = BeanNameGenerator.class == generatorClass;
/*  94 */     scanner.setBeanNameGenerator(useInheritedGenerator ? this.beanNameGenerator : 
/*  95 */       (BeanNameGenerator)BeanUtils.instantiateClass(generatorClass));
/*     */     
/*  97 */     ScopedProxyMode scopedProxyMode = (ScopedProxyMode)componentScan.getEnum("scopedProxy");
/*  98 */     Class<? extends ScopeMetadataResolver> resolverClass; if (scopedProxyMode != ScopedProxyMode.DEFAULT) {
/*  99 */       scanner.setScopedProxyMode(scopedProxyMode);
/*     */     }
/*     */     else {
/* 102 */       resolverClass = componentScan.getClass("scopeResolver");
/* 103 */       scanner.setScopeMetadataResolver((ScopeMetadataResolver)BeanUtils.instantiateClass(resolverClass));
/*     */     }
/*     */     
/* 106 */     scanner.setResourcePattern(componentScan.getString("resourcePattern"));
/*     */     
/* 108 */     for (AnnotationAttributes filter : componentScan.getAnnotationArray("includeFilters")) {
/* 109 */       for (TypeFilter typeFilter : typeFiltersFor(filter)) {
/* 110 */         scanner.addIncludeFilter(typeFilter);
/*     */       }
/*     */     }
/* 113 */     for (filter : componentScan.getAnnotationArray("excludeFilters")) {
/* 114 */       for (??? = typeFiltersFor(filter).iterator(); ???.hasNext();) { typeFilter = (TypeFilter)???.next();
/* 115 */         scanner.addExcludeFilter(typeFilter);
/*     */       }
/*     */     }
/*     */     
/* 119 */     boolean lazyInit = componentScan.getBoolean("lazyInit");
/* 120 */     if (lazyInit) {
/* 121 */       scanner.getBeanDefinitionDefaults().setLazyInit(true);
/*     */     }
/*     */     
/* 124 */     Object basePackages = new LinkedHashSet();
/* 125 */     String[] basePackagesArray = componentScan.getStringArray("basePackages");
/* 126 */     AnnotationAttributes filter = basePackagesArray;TypeFilter localTypeFilter1 = filter.length; for (TypeFilter typeFilter = 0; typeFilter < localTypeFilter1; typeFilter++) { String pkg = filter[typeFilter];
/* 127 */       String[] tokenized = StringUtils.tokenizeToStringArray(this.environment.resolvePlaceholders(pkg), ",; \t\n");
/*     */       
/* 129 */       ((Set)basePackages).addAll(Arrays.asList(tokenized));
/*     */     }
/* 131 */     filter = componentScan.getClassArray("basePackageClasses");TypeFilter localTypeFilter2 = filter.length; for (typeFilter = 0; typeFilter < localTypeFilter2; typeFilter++) { Class<?> clazz = filter[typeFilter];
/* 132 */       ((Set)basePackages).add(ClassUtils.getPackageName(clazz));
/*     */     }
/* 134 */     if (((Set)basePackages).isEmpty()) {
/* 135 */       ((Set)basePackages).add(ClassUtils.getPackageName(declaringClass));
/*     */     }
/*     */     
/* 138 */     scanner.addExcludeFilter(new AbstractTypeHierarchyTraversingFilter(false, false)
/*     */     {
/*     */       protected boolean matchClassName(String className) {
/* 141 */         return declaringClass.equals(className);
/*     */       }
/* 143 */     });
/* 144 */     return scanner.doScan(StringUtils.toStringArray((Collection)basePackages));
/*     */   }
/*     */   
/*     */   private List<TypeFilter> typeFiltersFor(AnnotationAttributes filterAttributes) {
/* 148 */     List<TypeFilter> typeFilters = new ArrayList();
/* 149 */     FilterType filterType = (FilterType)filterAttributes.getEnum("type");
/*     */     
/* 151 */     for (Class<?> filterClass : filterAttributes.getClassArray("classes")) {
/* 152 */       switch (filterType) {
/*     */       case ANNOTATION: 
/* 154 */         Assert.isAssignable(Annotation.class, filterClass, "An error occurred while processing a @ComponentScan ANNOTATION type filter: ");
/*     */         
/*     */ 
/* 157 */         Class<Annotation> annotationType = filterClass;
/* 158 */         typeFilters.add(new AnnotationTypeFilter(annotationType));
/* 159 */         break;
/*     */       case ASSIGNABLE_TYPE: 
/* 161 */         typeFilters.add(new AssignableTypeFilter(filterClass));
/* 162 */         break;
/*     */       case CUSTOM: 
/* 164 */         Assert.isAssignable(TypeFilter.class, filterClass, "An error occurred while processing a @ComponentScan CUSTOM type filter: ");
/*     */         
/* 166 */         TypeFilter filter = (TypeFilter)BeanUtils.instantiateClass(filterClass, TypeFilter.class);
/* 167 */         invokeAwareMethods(filter);
/* 168 */         typeFilters.add(filter);
/* 169 */         break;
/*     */       default: 
/* 171 */         throw new IllegalArgumentException("Filter type not supported with Class value: " + filterType);
/*     */       }
/*     */       
/*     */     }
/* 175 */     for (String expression : filterAttributes.getStringArray("pattern")) {
/* 176 */       switch (filterType) {
/*     */       case ASPECTJ: 
/* 178 */         typeFilters.add(new AspectJTypeFilter(expression, this.resourceLoader.getClassLoader()));
/* 179 */         break;
/*     */       case REGEX: 
/* 181 */         typeFilters.add(new RegexPatternTypeFilter(Pattern.compile(expression)));
/* 182 */         break;
/*     */       default: 
/* 184 */         throw new IllegalArgumentException("Filter type not supported with String pattern: " + filterType);
/*     */       }
/*     */       
/*     */     }
/* 188 */     return typeFilters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void invokeAwareMethods(TypeFilter filter)
/*     */   {
/* 196 */     if ((filter instanceof Aware)) {
/* 197 */       if ((filter instanceof EnvironmentAware)) {
/* 198 */         ((EnvironmentAware)filter).setEnvironment(this.environment);
/*     */       }
/* 200 */       if ((filter instanceof ResourceLoaderAware)) {
/* 201 */         ((ResourceLoaderAware)filter).setResourceLoader(this.resourceLoader);
/*     */       }
/* 203 */       if ((filter instanceof BeanClassLoaderAware))
/*     */       {
/*     */ 
/* 206 */         ClassLoader classLoader = (this.registry instanceof ConfigurableBeanFactory) ? ((ConfigurableBeanFactory)this.registry).getBeanClassLoader() : this.resourceLoader.getClassLoader();
/* 207 */         ((BeanClassLoaderAware)filter).setBeanClassLoader(classLoader);
/*     */       }
/* 209 */       if (((filter instanceof BeanFactoryAware)) && ((this.registry instanceof BeanFactory))) {
/* 210 */         ((BeanFactoryAware)filter).setBeanFactory((BeanFactory)this.registry);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\context\annotation\ComponentScanAnnotationParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */