/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedGenericBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.support.AutowireCandidateQualifier;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionReaderUtils;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.EnvironmentCapable;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotatedBeanDefinitionReader
/*     */ {
/*     */   private final BeanDefinitionRegistry registry;
/*  48 */   private BeanNameGenerator beanNameGenerator = new AnnotationBeanNameGenerator();
/*     */   
/*  50 */   private ScopeMetadataResolver scopeMetadataResolver = new AnnotationScopeMetadataResolver();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ConditionEvaluator conditionEvaluator;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotatedBeanDefinitionReader(BeanDefinitionRegistry registry)
/*     */   {
/*  66 */     this(registry, getOrCreateEnvironment(registry));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotatedBeanDefinitionReader(BeanDefinitionRegistry registry, Environment environment)
/*     */   {
/*  79 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/*  80 */     Assert.notNull(environment, "Environment must not be null");
/*  81 */     this.registry = registry;
/*  82 */     this.conditionEvaluator = new ConditionEvaluator(registry, environment, null);
/*  83 */     AnnotationConfigUtils.registerAnnotationConfigProcessors(this.registry);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final BeanDefinitionRegistry getRegistry()
/*     */   {
/*  90 */     return this.registry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnvironment(Environment environment)
/*     */   {
/* 100 */     this.conditionEvaluator = new ConditionEvaluator(this.registry, environment, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBeanNameGenerator(BeanNameGenerator beanNameGenerator)
/*     */   {
/* 108 */     this.beanNameGenerator = (beanNameGenerator != null ? beanNameGenerator : new AnnotationBeanNameGenerator());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScopeMetadataResolver(ScopeMetadataResolver scopeMetadataResolver)
/*     */   {
/* 116 */     this.scopeMetadataResolver = (scopeMetadataResolver != null ? scopeMetadataResolver : new AnnotationScopeMetadataResolver());
/*     */   }
/*     */   
/*     */   public void register(Class<?>... annotatedClasses)
/*     */   {
/* 121 */     for (Class<?> annotatedClass : annotatedClasses) {
/* 122 */       registerBean(annotatedClass);
/*     */     }
/*     */   }
/*     */   
/*     */   public void registerBean(Class<?> annotatedClass) {
/* 127 */     registerBean(annotatedClass, null, (Class[])null);
/*     */   }
/*     */   
/*     */   public void registerBean(Class<?> annotatedClass, Class<? extends Annotation>... qualifiers)
/*     */   {
/* 132 */     registerBean(annotatedClass, null, qualifiers);
/*     */   }
/*     */   
/*     */   public void registerBean(Class<?> annotatedClass, String name, Class<? extends Annotation>... qualifiers)
/*     */   {
/* 137 */     AnnotatedGenericBeanDefinition abd = new AnnotatedGenericBeanDefinition(annotatedClass);
/* 138 */     if (this.conditionEvaluator.shouldSkip(abd.getMetadata())) {
/* 139 */       return;
/*     */     }
/*     */     
/* 142 */     ScopeMetadata scopeMetadata = this.scopeMetadataResolver.resolveScopeMetadata(abd);
/* 143 */     abd.setScope(scopeMetadata.getScopeName());
/* 144 */     String beanName = name != null ? name : this.beanNameGenerator.generateBeanName(abd, this.registry);
/* 145 */     AnnotationConfigUtils.processCommonDefinitionAnnotations(abd);
/* 146 */     if (qualifiers != null) {
/* 147 */       for (Class<? extends Annotation> qualifier : qualifiers) {
/* 148 */         if (Primary.class == qualifier) {
/* 149 */           abd.setPrimary(true);
/*     */         }
/* 151 */         else if (Lazy.class == qualifier) {
/* 152 */           abd.setLazyInit(true);
/*     */         }
/*     */         else {
/* 155 */           abd.addQualifier(new AutowireCandidateQualifier(qualifier));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 160 */     BeanDefinitionHolder definitionHolder = new BeanDefinitionHolder(abd, beanName);
/* 161 */     definitionHolder = AnnotationConfigUtils.applyScopedProxyMode(scopeMetadata, definitionHolder, this.registry);
/* 162 */     BeanDefinitionReaderUtils.registerBeanDefinition(definitionHolder, this.registry);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Environment getOrCreateEnvironment(BeanDefinitionRegistry registry)
/*     */   {
/* 171 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/* 172 */     if ((registry instanceof EnvironmentCapable)) {
/* 173 */       return ((EnvironmentCapable)registry).getEnvironment();
/*     */     }
/* 175 */     return new StandardEnvironment();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\context\annotation\AnnotatedBeanDefinitionReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */