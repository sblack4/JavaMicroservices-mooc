/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Deque;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.Aware;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.parsing.Location;
/*     */ import org.springframework.beans.factory.parsing.Problem;
/*     */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionReader;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.NestedIOException;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.env.CompositePropertySource;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.DefaultPropertySourceFactory;
/*     */ import org.springframework.core.io.support.EncodedResource;
/*     */ import org.springframework.core.io.support.PropertySourceFactory;
/*     */ import org.springframework.core.io.support.ResourcePropertySource;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.ClassMetadata;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.core.type.StandardAnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.core.type.filter.AssignableTypeFilter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigurationClassParser
/*     */ {
/* 108 */   private static final PropertySourceFactory DEFAULT_PROPERTY_SOURCE_FACTORY = new DefaultPropertySourceFactory();
/*     */   
/* 110 */   private static final Comparator<DeferredImportSelectorHolder> DEFERRED_IMPORT_COMPARATOR = new Comparator()
/*     */   {
/*     */     public int compare(ConfigurationClassParser.DeferredImportSelectorHolder o1, ConfigurationClassParser.DeferredImportSelectorHolder o2)
/*     */     {
/* 114 */       return AnnotationAwareOrderComparator.INSTANCE.compare(o1.getImportSelector(), o2.getImportSelector());
/*     */     }
/*     */   };
/*     */   
/*     */ 
/* 119 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private final MetadataReaderFactory metadataReaderFactory;
/*     */   
/*     */   private final ProblemReporter problemReporter;
/*     */   
/*     */   private final Environment environment;
/*     */   
/*     */   private final ResourceLoader resourceLoader;
/*     */   
/*     */   private final BeanDefinitionRegistry registry;
/*     */   
/*     */   private final ComponentScanAnnotationParser componentScanParser;
/*     */   
/*     */   private final ConditionEvaluator conditionEvaluator;
/*     */   
/* 135 */   private final Map<ConfigurationClass, ConfigurationClass> configurationClasses = new LinkedHashMap();
/*     */   
/*     */ 
/* 138 */   private final Map<String, ConfigurationClass> knownSuperclasses = new HashMap();
/*     */   
/* 140 */   private final List<String> propertySourceNames = new ArrayList();
/*     */   
/* 142 */   private final ImportStack importStack = new ImportStack(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<DeferredImportSelectorHolder> deferredImportSelectors;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConfigurationClassParser(MetadataReaderFactory metadataReaderFactory, ProblemReporter problemReporter, Environment environment, ResourceLoader resourceLoader, BeanNameGenerator componentScanBeanNameGenerator, BeanDefinitionRegistry registry)
/*     */   {
/* 155 */     this.metadataReaderFactory = metadataReaderFactory;
/* 156 */     this.problemReporter = problemReporter;
/* 157 */     this.environment = environment;
/* 158 */     this.resourceLoader = resourceLoader;
/* 159 */     this.registry = registry;
/* 160 */     this.componentScanParser = new ComponentScanAnnotationParser(resourceLoader, environment, componentScanBeanNameGenerator, registry);
/*     */     
/* 162 */     this.conditionEvaluator = new ConditionEvaluator(registry, environment, resourceLoader);
/*     */   }
/*     */   
/*     */   public void parse(Set<BeanDefinitionHolder> configCandidates)
/*     */   {
/* 167 */     this.deferredImportSelectors = new LinkedList();
/*     */     
/* 169 */     for (BeanDefinitionHolder holder : configCandidates) {
/* 170 */       BeanDefinition bd = holder.getBeanDefinition();
/*     */       try {
/* 172 */         if ((bd instanceof AnnotatedBeanDefinition)) {
/* 173 */           parse(((AnnotatedBeanDefinition)bd).getMetadata(), holder.getBeanName());
/*     */         }
/* 175 */         else if (((bd instanceof AbstractBeanDefinition)) && (((AbstractBeanDefinition)bd).hasBeanClass())) {
/* 176 */           parse(((AbstractBeanDefinition)bd).getBeanClass(), holder.getBeanName());
/*     */         }
/*     */         else {
/* 179 */           parse(bd.getBeanClassName(), holder.getBeanName());
/*     */         }
/*     */       }
/*     */       catch (BeanDefinitionStoreException ex) {
/* 183 */         throw ex;
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 187 */         throw new BeanDefinitionStoreException("Failed to parse configuration class [" + bd.getBeanClassName() + "]", ex);
/*     */       }
/*     */     }
/*     */     
/* 191 */     processDeferredImportSelectors();
/*     */   }
/*     */   
/*     */   protected final void parse(String className, String beanName) throws IOException {
/* 195 */     MetadataReader reader = this.metadataReaderFactory.getMetadataReader(className);
/* 196 */     processConfigurationClass(new ConfigurationClass(reader, beanName));
/*     */   }
/*     */   
/*     */   protected final void parse(Class<?> clazz, String beanName) throws IOException {
/* 200 */     processConfigurationClass(new ConfigurationClass(clazz, beanName));
/*     */   }
/*     */   
/*     */   protected final void parse(AnnotationMetadata metadata, String beanName) throws IOException {
/* 204 */     processConfigurationClass(new ConfigurationClass(metadata, beanName));
/*     */   }
/*     */   
/*     */   protected void processConfigurationClass(ConfigurationClass configClass) throws IOException
/*     */   {
/* 209 */     if (this.conditionEvaluator.shouldSkip(configClass.getMetadata(), ConfigurationCondition.ConfigurationPhase.PARSE_CONFIGURATION)) {
/* 210 */       return;
/*     */     }
/*     */     
/* 213 */     ConfigurationClass existingClass = (ConfigurationClass)this.configurationClasses.get(configClass);
/* 214 */     Iterator<ConfigurationClass> it; if (existingClass != null) {
/* 215 */       if (configClass.isImported()) {
/* 216 */         if (existingClass.isImported()) {
/* 217 */           existingClass.mergeImportedBy(configClass);
/*     */         }
/*     */         
/* 220 */         return;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 225 */       this.configurationClasses.remove(configClass);
/* 226 */       for (it = this.knownSuperclasses.values().iterator(); it.hasNext();) {
/* 227 */         if (configClass.equals(it.next())) {
/* 228 */           it.remove();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 235 */     SourceClass sourceClass = asSourceClass(configClass);
/*     */     do {
/* 237 */       sourceClass = doProcessConfigurationClass(configClass, sourceClass);
/*     */     }
/* 239 */     while (sourceClass != null);
/*     */     
/* 241 */     this.configurationClasses.put(configClass, configClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final SourceClass doProcessConfigurationClass(ConfigurationClass configClass, SourceClass sourceClass)
/*     */     throws IOException
/*     */   {
/* 254 */     processMemberClasses(configClass, sourceClass);
/*     */     
/*     */ 
/* 257 */     for (Iterator localIterator = AnnotationConfigUtils.attributesForRepeatable(sourceClass
/* 258 */           .getMetadata(), PropertySources.class, PropertySource.class).iterator(); localIterator.hasNext();) { propertySource = (AnnotationAttributes)localIterator.next();
/*     */       
/* 259 */       if ((this.environment instanceof ConfigurableEnvironment)) {
/* 260 */         processPropertySource(propertySource);
/*     */       }
/*     */       else {
/* 263 */         this.logger.warn("Ignoring @PropertySource annotation on [" + sourceClass.getMetadata().getClassName() + "]. Reason: Environment must implement ConfigurableEnvironment");
/*     */       }
/*     */     }
/*     */     
/*     */     AnnotationAttributes propertySource;
/*     */     
/* 269 */     Object componentScans = AnnotationConfigUtils.attributesForRepeatable(sourceClass
/* 270 */       .getMetadata(), ComponentScans.class, ComponentScan.class);
/* 271 */     if ((!((Set)componentScans).isEmpty()) && (!this.conditionEvaluator.shouldSkip(sourceClass.getMetadata(), ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN))) {
/* 272 */       for (AnnotationAttributes componentScan : (Set)componentScans)
/*     */       {
/*     */ 
/* 275 */         Set<BeanDefinitionHolder> scannedBeanDefinitions = this.componentScanParser.parse(componentScan, sourceClass.getMetadata().getClassName());
/*     */         
/* 277 */         for (localObject1 = scannedBeanDefinitions.iterator(); ((Iterator)localObject1).hasNext();) { holder = (BeanDefinitionHolder)((Iterator)localObject1).next();
/* 278 */           if (ConfigurationClassUtils.checkConfigurationClassCandidate(holder.getBeanDefinition(), this.metadataReaderFactory)) {
/* 279 */             parse(holder.getBeanDefinition().getBeanClassName(), holder.getBeanName());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     Object localObject1;
/*     */     BeanDefinitionHolder holder;
/* 286 */     processImports(configClass, sourceClass, getImports(sourceClass), true);
/*     */     
/*     */     String[] resources;
/* 289 */     if (sourceClass.getMetadata().isAnnotated(ImportResource.class.getName()))
/*     */     {
/* 291 */       AnnotationAttributes importResource = AnnotationConfigUtils.attributesFor(sourceClass.getMetadata(), ImportResource.class);
/* 292 */       resources = importResource.getStringArray("locations");
/* 293 */       Class<? extends BeanDefinitionReader> readerClass = importResource.getClass("reader");
/* 294 */       localObject1 = resources;holder = localObject1.length; for (BeanDefinitionHolder localBeanDefinitionHolder1 = 0; localBeanDefinitionHolder1 < holder; localBeanDefinitionHolder1++) { String resource = localObject1[localBeanDefinitionHolder1];
/* 295 */         String resolvedResource = this.environment.resolveRequiredPlaceholders(resource);
/* 296 */         configClass.addImportedResource(resolvedResource, readerClass);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 301 */     Set<MethodMetadata> beanMethods = sourceClass.getMetadata().getAnnotatedMethods(Bean.class.getName());
/* 302 */     for (MethodMetadata methodMetadata : beanMethods) {
/* 303 */       configClass.addBeanMethod(new BeanMethod(methodMetadata, configClass));
/*     */     }
/*     */     
/*     */ 
/* 307 */     processInterfaces(configClass, sourceClass);
/*     */     
/*     */ 
/* 310 */     if (sourceClass.getMetadata().hasSuperClass()) {
/* 311 */       String superclass = sourceClass.getMetadata().getSuperClassName();
/* 312 */       if ((!superclass.startsWith("java")) && (!this.knownSuperclasses.containsKey(superclass))) {
/* 313 */         this.knownSuperclasses.put(superclass, configClass);
/*     */         
/* 315 */         return sourceClass.getSuperClass();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 320 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   private void processMemberClasses(ConfigurationClass configClass, SourceClass sourceClass)
/*     */     throws IOException
/*     */   {
/* 327 */     for (SourceClass memberClass : sourceClass.getMemberClasses()) {
/* 328 */       if ((ConfigurationClassUtils.isConfigurationCandidate(memberClass.getMetadata())) && 
/* 329 */         (!memberClass.getMetadata().getClassName().equals(configClass.getMetadata().getClassName()))) {
/* 330 */         if (this.importStack.contains(configClass)) {
/* 331 */           this.problemReporter.error(new CircularImportProblem(configClass, this.importStack));
/*     */         }
/*     */         else {
/* 334 */           this.importStack.push(configClass);
/*     */           try {
/* 336 */             processConfigurationClass(memberClass.asConfigClass(configClass));
/*     */           }
/*     */           finally {
/* 339 */             this.importStack.pop();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void processInterfaces(ConfigurationClass configClass, SourceClass sourceClass)
/*     */     throws IOException
/*     */   {
/* 350 */     for (SourceClass ifc : sourceClass.getInterfaces()) {
/* 351 */       Set<MethodMetadata> beanMethods = ifc.getMetadata().getAnnotatedMethods(Bean.class.getName());
/* 352 */       for (MethodMetadata methodMetadata : beanMethods) {
/* 353 */         if (!methodMetadata.isAbstract())
/*     */         {
/* 355 */           configClass.addBeanMethod(new BeanMethod(methodMetadata, configClass));
/*     */         }
/*     */       }
/* 358 */       processInterfaces(configClass, ifc);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void processPropertySource(AnnotationAttributes propertySource)
/*     */     throws IOException
/*     */   {
/* 368 */     String name = propertySource.getString("name");
/* 369 */     if (!StringUtils.hasLength(name)) {
/* 370 */       name = null;
/*     */     }
/* 372 */     String encoding = propertySource.getString("encoding");
/* 373 */     if (!StringUtils.hasLength(encoding)) {
/* 374 */       encoding = null;
/*     */     }
/* 376 */     String[] locations = propertySource.getStringArray("value");
/* 377 */     Assert.isTrue(locations.length > 0, "At least one @PropertySource(value) location is required");
/* 378 */     boolean ignoreResourceNotFound = propertySource.getBoolean("ignoreResourceNotFound");
/*     */     
/* 380 */     Class<? extends PropertySourceFactory> factoryClass = propertySource.getClass("factory");
/*     */     
/* 382 */     PropertySourceFactory factory = factoryClass == PropertySourceFactory.class ? DEFAULT_PROPERTY_SOURCE_FACTORY : (PropertySourceFactory)BeanUtils.instantiateClass(factoryClass);
/*     */     
/* 384 */     for (String location : locations) {
/*     */       try {
/* 386 */         String resolvedLocation = this.environment.resolveRequiredPlaceholders(location);
/* 387 */         Resource resource = this.resourceLoader.getResource(resolvedLocation);
/* 388 */         addPropertySource(factory.createPropertySource(name, new EncodedResource(resource, encoding)));
/*     */       }
/*     */       catch (IllegalArgumentException ex)
/*     */       {
/* 392 */         if (!ignoreResourceNotFound) {
/* 393 */           throw ex;
/*     */         }
/*     */       }
/*     */       catch (FileNotFoundException ex)
/*     */       {
/* 398 */         if (!ignoreResourceNotFound) {
/* 399 */           throw ex;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void addPropertySource(org.springframework.core.env.PropertySource<?> propertySource) {
/* 406 */     String name = propertySource.getName();
/* 407 */     MutablePropertySources propertySources = ((ConfigurableEnvironment)this.environment).getPropertySources();
/* 408 */     if ((propertySources.contains(name)) && (this.propertySourceNames.contains(name)))
/*     */     {
/* 410 */       org.springframework.core.env.PropertySource<?> existing = propertySources.get(name);
/*     */       
/* 412 */       org.springframework.core.env.PropertySource<?> newSource = (propertySource instanceof ResourcePropertySource) ? ((ResourcePropertySource)propertySource).withResourceName() : propertySource;
/* 413 */       if ((existing instanceof CompositePropertySource)) {
/* 414 */         ((CompositePropertySource)existing).addFirstPropertySource(newSource);
/*     */       }
/*     */       else {
/* 417 */         if ((existing instanceof ResourcePropertySource)) {
/* 418 */           existing = ((ResourcePropertySource)existing).withResourceName();
/*     */         }
/* 420 */         CompositePropertySource composite = new CompositePropertySource(name);
/* 421 */         composite.addPropertySource(newSource);
/* 422 */         composite.addPropertySource(existing);
/* 423 */         propertySources.replace(name, composite);
/*     */       }
/*     */       
/*     */     }
/* 427 */     else if (this.propertySourceNames.isEmpty()) {
/* 428 */       propertySources.addLast(propertySource);
/*     */     }
/*     */     else {
/* 431 */       String firstProcessed = (String)this.propertySourceNames.get(this.propertySourceNames.size() - 1);
/* 432 */       propertySources.addBefore(firstProcessed, propertySource);
/*     */     }
/*     */     
/* 435 */     this.propertySourceNames.add(name);
/*     */   }
/*     */   
/*     */ 
/*     */   private Set<SourceClass> getImports(SourceClass sourceClass)
/*     */     throws IOException
/*     */   {
/* 442 */     Set<SourceClass> imports = new LinkedHashSet();
/* 443 */     Set<SourceClass> visited = new LinkedHashSet();
/* 444 */     collectImports(sourceClass, imports, visited);
/* 445 */     return imports;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void collectImports(SourceClass sourceClass, Set<SourceClass> imports, Set<SourceClass> visited)
/*     */     throws IOException
/*     */   {
/* 462 */     if (visited.add(sourceClass)) {
/* 463 */       for (SourceClass annotation : sourceClass.getAnnotations()) {
/* 464 */         String annName = annotation.getMetadata().getClassName();
/* 465 */         if ((!annName.startsWith("java")) && (!annName.equals(Import.class.getName()))) {
/* 466 */           collectImports(annotation, imports, visited);
/*     */         }
/*     */       }
/* 469 */       imports.addAll(sourceClass.getAnnotationAttributes(Import.class.getName(), "value"));
/*     */     }
/*     */   }
/*     */   
/*     */   private void processDeferredImportSelectors() {
/* 474 */     List<DeferredImportSelectorHolder> deferredImports = this.deferredImportSelectors;
/* 475 */     this.deferredImportSelectors = null;
/* 476 */     Collections.sort(deferredImports, DEFERRED_IMPORT_COMPARATOR);
/*     */     
/* 478 */     for (DeferredImportSelectorHolder deferredImport : deferredImports) {
/* 479 */       ConfigurationClass configClass = deferredImport.getConfigurationClass();
/*     */       try {
/* 481 */         String[] imports = deferredImport.getImportSelector().selectImports(configClass.getMetadata());
/* 482 */         processImports(configClass, asSourceClass(configClass), asSourceClasses(imports), false);
/*     */       }
/*     */       catch (BeanDefinitionStoreException ex) {
/* 485 */         throw ex;
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 489 */         throw new BeanDefinitionStoreException("Failed to process import candidates for configuration class [" + configClass.getMetadata().getClassName() + "]", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void processImports(ConfigurationClass configClass, SourceClass currentSourceClass, Collection<SourceClass> importCandidates, boolean checkForCircularImports)
/*     */     throws IOException
/*     */   {
/* 497 */     if (importCandidates.isEmpty()) {
/* 498 */       return;
/*     */     }
/*     */     
/* 501 */     if ((checkForCircularImports) && (isChainedImportOnStack(configClass))) {
/* 502 */       this.problemReporter.error(new CircularImportProblem(configClass, this.importStack));
/*     */     }
/*     */     else {
/* 505 */       this.importStack.push(configClass);
/*     */       try {
/* 507 */         for (SourceClass candidate : importCandidates) {
/* 508 */           if (candidate.isAssignable(ImportSelector.class))
/*     */           {
/* 510 */             Class<?> candidateClass = candidate.loadClass();
/* 511 */             ImportSelector selector = (ImportSelector)BeanUtils.instantiateClass(candidateClass, ImportSelector.class);
/* 512 */             invokeAwareMethods(selector);
/* 513 */             if ((this.deferredImportSelectors != null) && ((selector instanceof DeferredImportSelector))) {
/* 514 */               this.deferredImportSelectors.add(new DeferredImportSelectorHolder(configClass, (DeferredImportSelector)selector));
/*     */             }
/*     */             else
/*     */             {
/* 518 */               String[] importClassNames = selector.selectImports(currentSourceClass.getMetadata());
/* 519 */               Collection<SourceClass> importSourceClasses = asSourceClasses(importClassNames);
/* 520 */               processImports(configClass, currentSourceClass, importSourceClasses, false);
/*     */             }
/*     */           }
/* 523 */           else if (candidate.isAssignable(ImportBeanDefinitionRegistrar.class))
/*     */           {
/*     */ 
/* 526 */             Class<?> candidateClass = candidate.loadClass();
/*     */             
/* 528 */             ImportBeanDefinitionRegistrar registrar = (ImportBeanDefinitionRegistrar)BeanUtils.instantiateClass(candidateClass, ImportBeanDefinitionRegistrar.class);
/* 529 */             invokeAwareMethods(registrar);
/* 530 */             configClass.addImportBeanDefinitionRegistrar(registrar, currentSourceClass.getMetadata());
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 535 */             this.importStack.registerImport(currentSourceClass
/* 536 */               .getMetadata(), candidate.getMetadata().getClassName());
/* 537 */             processConfigurationClass(candidate.asConfigClass(configClass));
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (BeanDefinitionStoreException ex) {
/* 542 */         throw ex;
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 546 */         throw new BeanDefinitionStoreException("Failed to process import candidates for configuration class [" + configClass.getMetadata().getClassName() + "]", ex);
/*     */       }
/*     */       finally {
/* 549 */         this.importStack.pop();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isChainedImportOnStack(ConfigurationClass configClass) {
/* 555 */     if (this.importStack.contains(configClass)) {
/* 556 */       String configClassName = configClass.getMetadata().getClassName();
/* 557 */       AnnotationMetadata importingClass = this.importStack.getImportingClassFor(configClassName);
/* 558 */       while (importingClass != null) {
/* 559 */         if (configClassName.equals(importingClass.getClassName())) {
/* 560 */           return true;
/*     */         }
/* 562 */         importingClass = this.importStack.getImportingClassFor(importingClass.getClassName());
/*     */       }
/*     */     }
/* 565 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void invokeAwareMethods(Object importStrategyBean)
/*     */   {
/* 573 */     if ((importStrategyBean instanceof Aware)) {
/* 574 */       if ((importStrategyBean instanceof EnvironmentAware)) {
/* 575 */         ((EnvironmentAware)importStrategyBean).setEnvironment(this.environment);
/*     */       }
/* 577 */       if ((importStrategyBean instanceof ResourceLoaderAware)) {
/* 578 */         ((ResourceLoaderAware)importStrategyBean).setResourceLoader(this.resourceLoader);
/*     */       }
/* 580 */       if ((importStrategyBean instanceof BeanClassLoaderAware))
/*     */       {
/*     */ 
/* 583 */         ClassLoader classLoader = (this.registry instanceof ConfigurableBeanFactory) ? ((ConfigurableBeanFactory)this.registry).getBeanClassLoader() : this.resourceLoader.getClassLoader();
/* 584 */         ((BeanClassLoaderAware)importStrategyBean).setBeanClassLoader(classLoader);
/*     */       }
/* 586 */       if (((importStrategyBean instanceof BeanFactoryAware)) && ((this.registry instanceof BeanFactory))) {
/* 587 */         ((BeanFactoryAware)importStrategyBean).setBeanFactory((BeanFactory)this.registry);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validate()
/*     */   {
/* 598 */     for (ConfigurationClass configClass : this.configurationClasses.keySet()) {
/* 599 */       configClass.validate(this.problemReporter);
/*     */     }
/*     */   }
/*     */   
/*     */   public Set<ConfigurationClass> getConfigurationClasses() {
/* 604 */     return this.configurationClasses.keySet();
/*     */   }
/*     */   
/*     */   ImportRegistry getImportRegistry()
/*     */   {
/* 609 */     return this.importStack;
/*     */   }
/*     */   
/*     */ 
/*     */   public SourceClass asSourceClass(ConfigurationClass configurationClass)
/*     */     throws IOException
/*     */   {
/* 616 */     AnnotationMetadata metadata = configurationClass.getMetadata();
/* 617 */     if ((metadata instanceof StandardAnnotationMetadata)) {
/* 618 */       return asSourceClass(((StandardAnnotationMetadata)metadata).getIntrospectedClass());
/*     */     }
/* 620 */     return asSourceClass(configurationClass.getMetadata().getClassName());
/*     */   }
/*     */   
/*     */ 
/*     */   public SourceClass asSourceClass(Class<?> classType)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 629 */       classType.getAnnotations();
/* 630 */       return new SourceClass(classType);
/*     */     }
/*     */     catch (Throwable ex) {}
/*     */     
/* 634 */     return asSourceClass(classType.getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Collection<SourceClass> asSourceClasses(String[] classNames)
/*     */     throws IOException
/*     */   {
/* 642 */     List<SourceClass> annotatedClasses = new ArrayList();
/* 643 */     for (String className : classNames) {
/* 644 */       annotatedClasses.add(asSourceClass(className));
/*     */     }
/* 646 */     return annotatedClasses;
/*     */   }
/*     */   
/*     */ 
/*     */   public SourceClass asSourceClass(String className)
/*     */     throws IOException
/*     */   {
/* 653 */     if (className.startsWith("java")) {
/*     */       try
/*     */       {
/* 656 */         return new SourceClass(this.resourceLoader.getClassLoader().loadClass(className));
/*     */       }
/*     */       catch (ClassNotFoundException ex) {
/* 659 */         throw new NestedIOException("Failed to load class [" + className + "]", ex);
/*     */       }
/*     */     }
/* 662 */     return new SourceClass(this.metadataReaderFactory.getMetadataReader(className));
/*     */   }
/*     */   
/*     */   private static class ImportStack
/*     */     extends ArrayDeque<ConfigurationClass>
/*     */     implements ImportRegistry
/*     */   {
/* 669 */     private final MultiValueMap<String, AnnotationMetadata> imports = new LinkedMultiValueMap();
/*     */     
/*     */     public void registerImport(AnnotationMetadata importingClass, String importedClass) {
/* 672 */       this.imports.add(importedClass, importingClass);
/*     */     }
/*     */     
/*     */     public void removeImportingClassFor(String importedClass)
/*     */     {
/* 677 */       for (List<AnnotationMetadata> list : this.imports.values()) {
/* 678 */         for (iterator = list.iterator(); iterator.hasNext();) {
/* 679 */           if (((AnnotationMetadata)iterator.next()).getClassName().equals(importedClass)) {
/* 680 */             iterator.remove();
/*     */           }
/*     */         }
/*     */       }
/*     */       Iterator<AnnotationMetadata> iterator;
/*     */     }
/*     */     
/*     */     public AnnotationMetadata getImportingClassFor(String importedClass) {
/* 688 */       List<AnnotationMetadata> list = (List)this.imports.get(importedClass);
/* 689 */       return !CollectionUtils.isEmpty(list) ? (AnnotationMetadata)list.get(list.size() - 1) : null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/* 703 */       StringBuilder builder = new StringBuilder("[");
/* 704 */       Iterator<ConfigurationClass> iterator = iterator();
/* 705 */       while (iterator.hasNext()) {
/* 706 */         builder.append(((ConfigurationClass)iterator.next()).getSimpleName());
/* 707 */         if (iterator.hasNext()) {
/* 708 */           builder.append("->");
/*     */         }
/*     */       }
/* 711 */       return ']';
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class DeferredImportSelectorHolder
/*     */   {
/*     */     private final ConfigurationClass configurationClass;
/*     */     private final DeferredImportSelector importSelector;
/*     */     
/*     */     public DeferredImportSelectorHolder(ConfigurationClass configurationClass, DeferredImportSelector importSelector)
/*     */     {
/* 723 */       this.configurationClass = configurationClass;
/* 724 */       this.importSelector = importSelector;
/*     */     }
/*     */     
/*     */     public ConfigurationClass getConfigurationClass() {
/* 728 */       return this.configurationClass;
/*     */     }
/*     */     
/*     */     public DeferredImportSelector getImportSelector() {
/* 732 */       return this.importSelector;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class SourceClass
/*     */   {
/*     */     private final Object source;
/*     */     
/*     */ 
/*     */     private final AnnotationMetadata metadata;
/*     */     
/*     */ 
/*     */     public SourceClass(Object source)
/*     */     {
/* 748 */       this.source = source;
/* 749 */       if ((source instanceof Class)) {
/* 750 */         this.metadata = new StandardAnnotationMetadata((Class)source, true);
/*     */       }
/*     */       else {
/* 753 */         this.metadata = ((MetadataReader)source).getAnnotationMetadata();
/*     */       }
/*     */     }
/*     */     
/*     */     public final AnnotationMetadata getMetadata() {
/* 758 */       return this.metadata;
/*     */     }
/*     */     
/*     */     public Class<?> loadClass() throws ClassNotFoundException {
/* 762 */       if ((this.source instanceof Class)) {
/* 763 */         return (Class)this.source;
/*     */       }
/* 765 */       String className = ((MetadataReader)this.source).getClassMetadata().getClassName();
/* 766 */       return ConfigurationClassParser.this.resourceLoader.getClassLoader().loadClass(className);
/*     */     }
/*     */     
/*     */     public boolean isAssignable(Class<?> clazz) throws IOException {
/* 770 */       if ((this.source instanceof Class)) {
/* 771 */         return clazz.isAssignableFrom((Class)this.source);
/*     */       }
/* 773 */       return new AssignableTypeFilter(clazz).match((MetadataReader)this.source, ConfigurationClassParser.this.metadataReaderFactory);
/*     */     }
/*     */     
/*     */     public ConfigurationClass asConfigClass(ConfigurationClass importedBy) throws IOException {
/* 777 */       if ((this.source instanceof Class)) {
/* 778 */         return new ConfigurationClass((Class)this.source, importedBy);
/*     */       }
/* 780 */       return new ConfigurationClass((MetadataReader)this.source, importedBy);
/*     */     }
/*     */     
/*     */     public Collection<SourceClass> getMemberClasses() throws IOException {
/* 784 */       Object sourceToProcess = this.source;
/* 785 */       if ((sourceToProcess instanceof Class)) {
/* 786 */         Class<?> sourceClass = (Class)sourceToProcess;
/*     */         try {
/* 788 */           Class<?>[] declaredClasses = sourceClass.getDeclaredClasses();
/* 789 */           List<SourceClass> members = new ArrayList(declaredClasses.length);
/* 790 */           for (Class<?> declaredClass : declaredClasses) {
/* 791 */             members.add(ConfigurationClassParser.this.asSourceClass(declaredClass));
/*     */           }
/* 793 */           return members;
/*     */ 
/*     */         }
/*     */         catch (NoClassDefFoundError err)
/*     */         {
/* 798 */           sourceToProcess = ConfigurationClassParser.this.metadataReaderFactory.getMetadataReader(sourceClass.getName());
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 803 */       MetadataReader sourceReader = (MetadataReader)sourceToProcess;
/* 804 */       String[] memberClassNames = sourceReader.getClassMetadata().getMemberClassNames();
/* 805 */       List<SourceClass> members = new ArrayList(memberClassNames.length);
/* 806 */       for (String memberClassName : memberClassNames) {
/*     */         try {
/* 808 */           members.add(ConfigurationClassParser.this.asSourceClass(memberClassName));
/*     */         }
/*     */         catch (IOException ex)
/*     */         {
/* 812 */           if (ConfigurationClassParser.this.logger.isDebugEnabled()) {
/* 813 */             ConfigurationClassParser.this.logger.debug("Failed to resolve member class [" + memberClassName + "] - not considering it as a configuration class candidate");
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 818 */       return members;
/*     */     }
/*     */     
/*     */     public SourceClass getSuperClass() throws IOException {
/* 822 */       if ((this.source instanceof Class)) {
/* 823 */         return ConfigurationClassParser.this.asSourceClass(((Class)this.source).getSuperclass());
/*     */       }
/* 825 */       return ConfigurationClassParser.this.asSourceClass(((MetadataReader)this.source).getClassMetadata().getSuperClassName());
/*     */     }
/*     */     
/*     */     public Set<SourceClass> getInterfaces() throws IOException {
/* 829 */       Set<SourceClass> result = new LinkedHashSet();
/* 830 */       Class<?> sourceClass; if ((this.source instanceof Class)) {
/* 831 */         sourceClass = (Class)this.source;
/* 832 */         for (Class<?> ifcClass : sourceClass.getInterfaces()) {
/* 833 */           result.add(ConfigurationClassParser.this.asSourceClass(ifcClass));
/*     */         }
/*     */       }
/*     */       else {
/* 837 */         for (String className : this.metadata.getInterfaceNames()) {
/* 838 */           result.add(ConfigurationClassParser.this.asSourceClass(className));
/*     */         }
/*     */       }
/* 841 */       return result;
/*     */     }
/*     */     
/*     */     public Set<SourceClass> getAnnotations() throws IOException {
/* 845 */       Set<SourceClass> result = new LinkedHashSet();
/* 846 */       for (String className : this.metadata.getAnnotationTypes()) {
/*     */         try {
/* 848 */           result.add(getRelated(className));
/*     */         }
/*     */         catch (Throwable localThrowable) {}
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 855 */       return result;
/*     */     }
/*     */     
/*     */     public Collection<SourceClass> getAnnotationAttributes(String annotationType, String attribute) throws IOException {
/* 859 */       Map<String, Object> annotationAttributes = this.metadata.getAnnotationAttributes(annotationType, true);
/* 860 */       if ((annotationAttributes == null) || (!annotationAttributes.containsKey(attribute))) {
/* 861 */         return Collections.emptySet();
/*     */       }
/* 863 */       String[] classNames = (String[])annotationAttributes.get(attribute);
/* 864 */       Set<SourceClass> result = new LinkedHashSet();
/* 865 */       for (String className : classNames) {
/* 866 */         result.add(getRelated(className));
/*     */       }
/* 868 */       return result;
/*     */     }
/*     */     
/*     */     private SourceClass getRelated(String className) throws IOException {
/* 872 */       if ((this.source instanceof Class)) {
/*     */         try {
/* 874 */           Class<?> clazz = ((Class)this.source).getClassLoader().loadClass(className);
/* 875 */           return ConfigurationClassParser.this.asSourceClass(clazz);
/*     */         }
/*     */         catch (ClassNotFoundException ex)
/*     */         {
/* 879 */           if (className.startsWith("java")) {
/* 880 */             throw new NestedIOException("Failed to load class [" + className + "]", ex);
/*     */           }
/* 882 */           return new SourceClass(ConfigurationClassParser.this, ConfigurationClassParser.this.metadataReaderFactory.getMetadataReader(className));
/*     */         }
/*     */       }
/* 885 */       return ConfigurationClassParser.this.asSourceClass(className);
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 891 */       return (this == other) || (((other instanceof SourceClass)) && (this.metadata.getClassName().equals(((SourceClass)other).metadata.getClassName())));
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 896 */       return this.metadata.getClassName().hashCode();
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 901 */       return this.metadata.getClassName();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class CircularImportProblem
/*     */     extends Problem
/*     */   {
/*     */     public CircularImportProblem(ConfigurationClass attemptedImport, Deque<ConfigurationClass> importStack)
/*     */     {
/* 912 */       super(new Location(
/*     */       
/*     */ 
/*     */ 
/* 916 */         ((ConfigurationClass)importStack.peek()).getResource(), attemptedImport.getMetadata()));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\context\annotation\ConfigurationClassParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */