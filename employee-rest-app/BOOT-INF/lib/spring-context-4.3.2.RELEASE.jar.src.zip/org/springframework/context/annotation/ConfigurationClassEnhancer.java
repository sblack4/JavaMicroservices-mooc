/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.scope.ScopedProxyFactoryBean;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.support.SimpleInstantiationStrategy;
/*     */ import org.springframework.cglib.core.ClassGenerator;
/*     */ import org.springframework.cglib.core.DefaultGeneratorStrategy;
/*     */ import org.springframework.cglib.core.SpringNamingPolicy;
/*     */ import org.springframework.cglib.proxy.Callback;
/*     */ import org.springframework.cglib.proxy.CallbackFilter;
/*     */ import org.springframework.cglib.proxy.Enhancer;
/*     */ import org.springframework.cglib.proxy.Factory;
/*     */ import org.springframework.cglib.proxy.MethodInterceptor;
/*     */ import org.springframework.cglib.proxy.MethodProxy;
/*     */ import org.springframework.cglib.proxy.NoOp;
/*     */ import org.springframework.cglib.transform.ClassEmitterTransformer;
/*     */ import org.springframework.cglib.transform.TransformingClassGenerator;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.objenesis.ObjenesisException;
/*     */ import org.springframework.objenesis.SpringObjenesis;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigurationClassEnhancer
/*     */ {
/*  74 */   private static final Callback[] CALLBACKS = { new BeanMethodInterceptor(null), new BeanFactoryAwareMethodInterceptor(null), NoOp.INSTANCE };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */   private static final ConditionalCallbackFilter CALLBACK_FILTER = new ConditionalCallbackFilter(CALLBACKS);
/*     */   
/*     */ 
/*     */   private static final String BEAN_FACTORY_FIELD = "$$beanFactory";
/*     */   
/*  85 */   private static final Log logger = LogFactory.getLog(ConfigurationClassEnhancer.class);
/*     */   
/*  87 */   private static final SpringObjenesis objenesis = new SpringObjenesis();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> enhance(Class<?> configClass, ClassLoader classLoader)
/*     */   {
/*  96 */     if (EnhancedConfiguration.class.isAssignableFrom(configClass)) {
/*  97 */       if (logger.isDebugEnabled()) {
/*  98 */         logger.debug(String.format("Ignoring request to enhance %s as it has already been enhanced. This usually indicates that more than one ConfigurationClassPostProcessor has been registered (e.g. via <context:annotation-config>). This is harmless, but you may want check your configuration and remove one CCPP if possible", new Object[] {configClass
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 103 */           .getName() }));
/*     */       }
/* 105 */       return configClass;
/*     */     }
/* 107 */     Class<?> enhancedClass = createClass(newEnhancer(configClass, classLoader));
/* 108 */     if (logger.isDebugEnabled()) {
/* 109 */       logger.debug(String.format("Successfully enhanced %s; enhanced class name is: %s", new Object[] {configClass
/* 110 */         .getName(), enhancedClass.getName() }));
/*     */     }
/* 112 */     return enhancedClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private Enhancer newEnhancer(Class<?> superclass, ClassLoader classLoader)
/*     */   {
/* 119 */     Enhancer enhancer = new Enhancer();
/* 120 */     enhancer.setSuperclass(superclass);
/* 121 */     enhancer.setInterfaces(new Class[] { EnhancedConfiguration.class });
/* 122 */     enhancer.setUseFactory(false);
/* 123 */     enhancer.setNamingPolicy(SpringNamingPolicy.INSTANCE);
/* 124 */     enhancer.setStrategy(new BeanFactoryAwareGeneratorStrategy(classLoader));
/* 125 */     enhancer.setCallbackFilter(CALLBACK_FILTER);
/* 126 */     enhancer.setCallbackTypes(CALLBACK_FILTER.getCallbackTypes());
/* 127 */     return enhancer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Class<?> createClass(Enhancer enhancer)
/*     */   {
/* 135 */     Class<?> subclass = enhancer.createClass();
/*     */     
/*     */ 
/* 138 */     Enhancer.registerStaticCallbacks(subclass, CALLBACKS);
/* 139 */     return subclass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static abstract interface EnhancedConfiguration
/*     */     extends BeanFactoryAware
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static abstract interface ConditionalCallback
/*     */     extends Callback
/*     */   {
/*     */     public abstract boolean isMatch(Method paramMethod);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class ConditionalCallbackFilter
/*     */     implements CallbackFilter
/*     */   {
/*     */     private final Callback[] callbacks;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private final Class<?>[] callbackTypes;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public ConditionalCallbackFilter(Callback[] callbacks)
/*     */     {
/* 179 */       this.callbacks = callbacks;
/* 180 */       this.callbackTypes = new Class[callbacks.length];
/* 181 */       for (int i = 0; i < callbacks.length; i++) {
/* 182 */         this.callbackTypes[i] = callbacks[i].getClass();
/*     */       }
/*     */     }
/*     */     
/*     */     public int accept(Method method)
/*     */     {
/* 188 */       for (int i = 0; i < this.callbacks.length; i++) {
/* 189 */         if ((!(this.callbacks[i] instanceof ConfigurationClassEnhancer.ConditionalCallback)) || 
/* 190 */           (((ConfigurationClassEnhancer.ConditionalCallback)this.callbacks[i]).isMatch(method))) {
/* 191 */           return i;
/*     */         }
/*     */       }
/* 194 */       throw new IllegalStateException("No callback available for method " + method.getName());
/*     */     }
/*     */     
/*     */     public Class<?>[] getCallbackTypes() {
/* 198 */       return this.callbackTypes;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class BeanFactoryAwareGeneratorStrategy
/*     */     extends DefaultGeneratorStrategy
/*     */   {
/*     */     private final ClassLoader classLoader;
/*     */     
/*     */ 
/*     */ 
/*     */     public BeanFactoryAwareGeneratorStrategy(ClassLoader classLoader)
/*     */     {
/* 213 */       this.classLoader = classLoader;
/*     */     }
/*     */     
/*     */     protected ClassGenerator transform(ClassGenerator cg) throws Exception
/*     */     {
/* 218 */       ClassEmitterTransformer transformer = new ClassEmitterTransformer()
/*     */       {
/*     */         public void end_class() {
/* 221 */           declare_field(1, "$$beanFactory", Type.getType(BeanFactory.class), null);
/* 222 */           super.end_class();
/*     */         }
/* 224 */       };
/* 225 */       return new TransformingClassGenerator(cg, transformer);
/*     */     }
/*     */     
/*     */     public byte[] generate(ClassGenerator cg) throws Exception
/*     */     {
/* 230 */       if (this.classLoader == null) {
/* 231 */         return super.generate(cg);
/*     */       }
/*     */       
/* 234 */       Thread currentThread = Thread.currentThread();
/*     */       try
/*     */       {
/* 237 */         threadContextClassLoader = currentThread.getContextClassLoader();
/*     */       }
/*     */       catch (Throwable ex) {
/*     */         ClassLoader threadContextClassLoader;
/* 241 */         return super.generate(cg);
/*     */       }
/*     */       ClassLoader threadContextClassLoader;
/* 244 */       boolean overrideClassLoader = !this.classLoader.equals(threadContextClassLoader);
/* 245 */       if (overrideClassLoader) {
/* 246 */         currentThread.setContextClassLoader(this.classLoader);
/*     */       }
/*     */       try {
/* 249 */         return super.generate(cg);
/*     */       }
/*     */       finally {
/* 252 */         if (overrideClassLoader)
/*     */         {
/* 254 */           currentThread.setContextClassLoader(threadContextClassLoader);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class BeanFactoryAwareMethodInterceptor
/*     */     implements MethodInterceptor, ConfigurationClassEnhancer.ConditionalCallback
/*     */   {
/*     */     public Object intercept(Object obj, Method method, Object[] args, MethodProxy proxy)
/*     */       throws Throwable
/*     */     {
/* 270 */       Field field = obj.getClass().getDeclaredField("$$beanFactory");
/* 271 */       Assert.state(field != null, "Unable to find generated BeanFactory field");
/* 272 */       field.set(obj, args[0]);
/*     */       
/*     */ 
/*     */ 
/* 276 */       if (BeanFactoryAware.class.isAssignableFrom(obj.getClass().getSuperclass())) {
/* 277 */         return proxy.invokeSuper(obj, args);
/*     */       }
/* 279 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isMatch(Method candidateMethod)
/*     */     {
/* 287 */       return (candidateMethod.getName().equals("setBeanFactory")) && (candidateMethod.getParameterTypes().length == 1) && (BeanFactory.class == candidateMethod.getParameterTypes()[0]) && (BeanFactoryAware.class.isAssignableFrom(candidateMethod.getDeclaringClass()));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class BeanMethodInterceptor
/*     */     implements MethodInterceptor, ConfigurationClassEnhancer.ConditionalCallback
/*     */   {
/*     */     public Object intercept(Object enhancedConfigInstance, Method beanMethod, Object[] beanMethodArgs, MethodProxy cglibMethodProxy)
/*     */       throws Throwable
/*     */     {
/* 310 */       ConfigurableBeanFactory beanFactory = getBeanFactory(enhancedConfigInstance);
/* 311 */       String beanName = BeanAnnotationHelper.determineBeanNameFor(beanMethod);
/*     */       
/*     */ 
/* 314 */       Scope scope = (Scope)AnnotatedElementUtils.findMergedAnnotation(beanMethod, Scope.class);
/* 315 */       if ((scope != null) && (scope.proxyMode() != ScopedProxyMode.NO)) {
/* 316 */         String scopedBeanName = ScopedProxyCreator.getTargetBeanName(beanName);
/* 317 */         if (beanFactory.isCurrentlyInCreation(scopedBeanName)) {
/* 318 */           beanName = scopedBeanName;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 329 */       if ((factoryContainsBean(beanFactory, "&" + beanName)) && 
/* 330 */         (factoryContainsBean(beanFactory, beanName))) {
/* 331 */         Object factoryBean = beanFactory.getBean("&" + beanName);
/* 332 */         if (!(factoryBean instanceof ScopedProxyFactoryBean))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 338 */           return enhanceFactoryBean(factoryBean, beanFactory, beanName);
/*     */         }
/*     */       }
/*     */       
/* 342 */       if (isCurrentlyInvokedFactoryMethod(beanMethod))
/*     */       {
/*     */ 
/*     */ 
/* 346 */         if ((ConfigurationClassEnhancer.logger.isWarnEnabled()) && 
/* 347 */           (BeanFactoryPostProcessor.class.isAssignableFrom(beanMethod.getReturnType()))) {
/* 348 */           ConfigurationClassEnhancer.logger.warn(String.format("@Bean method %s.%s is non-static and returns an object assignable to Spring's BeanFactoryPostProcessor interface. This will result in a failure to process annotations such as @Autowired, @Resource and @PostConstruct within the method's declaring @Configuration class. Add the 'static' modifier to this method to avoid these container lifecycle issues; see @Bean javadoc for complete details.", new Object[] {beanMethod
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 354 */             .getDeclaringClass().getSimpleName(), beanMethod.getName() }));
/*     */         }
/* 356 */         return cglibMethodProxy.invokeSuper(enhancedConfigInstance, beanMethodArgs);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 363 */       boolean alreadyInCreation = beanFactory.isCurrentlyInCreation(beanName);
/*     */       try {
/* 365 */         if (alreadyInCreation) {
/* 366 */           beanFactory.setCurrentlyInCreation(beanName, false);
/*     */         }
/* 368 */         boolean useArgs = !ObjectUtils.isEmpty(beanMethodArgs);
/* 369 */         if ((useArgs) && (beanFactory.isSingleton(beanName)))
/*     */         {
/*     */ 
/*     */ 
/* 373 */           for (Object arg : beanMethodArgs) {
/* 374 */             if (arg == null) {
/* 375 */               useArgs = false;
/* 376 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 381 */         Object beanInstance = useArgs ? beanFactory.getBean(beanName, beanMethodArgs) : beanFactory.getBean(beanName);
/* 382 */         Object msg; if ((beanInstance != null) && (!ClassUtils.isAssignableValue(beanMethod.getReturnType(), beanInstance))) {
/* 383 */           msg = String.format("@Bean method %s.%s called as a bean reference for type [%s] but overridden by non-compatible bean instance of type [%s].", new Object[] {beanMethod
/*     */           
/* 385 */             .getDeclaringClass().getSimpleName(), beanMethod.getName(), beanMethod
/* 386 */             .getReturnType().getName(), beanInstance.getClass().getName() });
/*     */           try {
/* 388 */             BeanDefinition beanDefinition = beanFactory.getMergedBeanDefinition(beanName);
/* 389 */             msg = (String)msg + " Overriding bean of same name declared in: " + beanDefinition.getResourceDescription();
/*     */           }
/*     */           catch (NoSuchBeanDefinitionException localNoSuchBeanDefinitionException1) {}
/*     */           
/*     */ 
/* 394 */           throw new IllegalStateException((String)msg);
/*     */         }
/* 396 */         return beanInstance;
/*     */       }
/*     */       finally {
/* 399 */         if (alreadyInCreation) {
/* 400 */           beanFactory.setCurrentlyInCreation(beanName, true);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private boolean factoryContainsBean(ConfigurableBeanFactory beanFactory, String beanName)
/*     */     {
/* 420 */       return (beanFactory.containsBean(beanName)) && (!beanFactory.isCurrentlyInCreation(beanName));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private boolean isCurrentlyInvokedFactoryMethod(Method method)
/*     */     {
/* 430 */       Method currentlyInvoked = SimpleInstantiationStrategy.getCurrentlyInvokedFactoryMethod();
/*     */       
/* 432 */       return (currentlyInvoked != null) && (method.getName().equals(currentlyInvoked.getName())) && (Arrays.equals(method.getParameterTypes(), currentlyInvoked.getParameterTypes()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private Object enhanceFactoryBean(final Object factoryBean, final ConfigurableBeanFactory beanFactory, final String beanName)
/*     */     {
/* 445 */       Enhancer enhancer = new Enhancer();
/* 446 */       enhancer.setSuperclass(factoryBean.getClass());
/* 447 */       enhancer.setNamingPolicy(SpringNamingPolicy.INSTANCE);
/* 448 */       enhancer.setCallbackType(MethodInterceptor.class);
/*     */       
/*     */ 
/*     */ 
/* 452 */       Class<?> fbClass = enhancer.createClass();
/* 453 */       Object fbProxy = null;
/*     */       
/* 455 */       if (ConfigurationClassEnhancer.objenesis.isWorthTrying()) {
/*     */         try {
/* 457 */           fbProxy = ConfigurationClassEnhancer.objenesis.newInstance(fbClass, enhancer.getUseCache());
/*     */         }
/*     */         catch (ObjenesisException ex) {
/* 460 */           ConfigurationClassEnhancer.logger.debug("Unable to instantiate enhanced FactoryBean using Objenesis, falling back to regular construction", ex);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 465 */       if (fbProxy == null) {
/*     */         try {
/* 467 */           fbProxy = fbClass.newInstance();
/*     */         }
/*     */         catch (Throwable ex) {
/* 470 */           throw new IllegalStateException("Unable to instantiate enhanced FactoryBean using Objenesis, and regular FactoryBean instantiation via default constructor fails as well", ex);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 475 */       ((Factory)fbProxy).setCallback(0, new MethodInterceptor()
/*     */       {
/*     */         public Object intercept(Object obj, Method method, Object[] args, MethodProxy proxy) throws Throwable {
/* 478 */           if ((method.getName().equals("getObject")) && (args.length == 0)) {
/* 479 */             return beanFactory.getBean(beanName);
/*     */           }
/* 481 */           return proxy.invoke(factoryBean, args);
/*     */         }
/*     */         
/* 484 */       });
/* 485 */       return fbProxy;
/*     */     }
/*     */     
/*     */     private ConfigurableBeanFactory getBeanFactory(Object enhancedConfigInstance) {
/* 489 */       Field field = ReflectionUtils.findField(enhancedConfigInstance.getClass(), "$$beanFactory");
/* 490 */       Assert.state(field != null, "Unable to find generated bean factory field");
/* 491 */       Object beanFactory = ReflectionUtils.getField(field, enhancedConfigInstance);
/* 492 */       Assert.state(beanFactory != null, "BeanFactory has not been injected into @Configuration class");
/* 493 */       Assert.state(beanFactory instanceof ConfigurableBeanFactory, "Injected BeanFactory is not a ConfigurableBeanFactory");
/*     */       
/* 495 */       return (ConfigurableBeanFactory)beanFactory;
/*     */     }
/*     */     
/*     */     public boolean isMatch(Method candidateMethod)
/*     */     {
/* 500 */       return BeanAnnotationHelper.isBeanAnnotated(candidateMethod);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\context\annotation\ConfigurationClassEnhancer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */