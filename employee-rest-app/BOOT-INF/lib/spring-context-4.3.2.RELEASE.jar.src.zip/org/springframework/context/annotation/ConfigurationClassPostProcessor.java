/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.framework.autoproxy.AutoProxyUtils;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessorAdapter;
/*     */ import org.springframework.beans.factory.config.SingletonBeanRegistry;
/*     */ import org.springframework.beans.factory.parsing.FailFastProblemReporter;
/*     */ import org.springframework.beans.factory.parsing.PassThroughSourceExtractor;
/*     */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*     */ import org.springframework.beans.factory.parsing.SourceExtractor;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.PriorityOrdered;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.CachingMetadataReaderFactory;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigurationClassPostProcessor
/*     */   implements BeanDefinitionRegistryPostProcessor, PriorityOrdered, ResourceLoaderAware, BeanClassLoaderAware, EnvironmentAware
/*     */ {
/*  94 */   private static final String IMPORT_AWARE_PROCESSOR_BEAN_NAME = ConfigurationClassPostProcessor.class
/*  95 */     .getName() + ".importAwareProcessor";
/*     */   
/*  97 */   private static final String IMPORT_REGISTRY_BEAN_NAME = ConfigurationClassPostProcessor.class
/*  98 */     .getName() + ".importRegistry";
/*     */   
/* 100 */   private static final String ENHANCED_CONFIGURATION_PROCESSOR_BEAN_NAME = ConfigurationClassPostProcessor.class
/* 101 */     .getName() + ".enhancedConfigurationProcessor";
/*     */   
/*     */ 
/* 104 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/* 106 */   private SourceExtractor sourceExtractor = new PassThroughSourceExtractor();
/*     */   
/* 108 */   private ProblemReporter problemReporter = new FailFastProblemReporter();
/*     */   
/*     */   private Environment environment;
/*     */   
/* 112 */   private ResourceLoader resourceLoader = new DefaultResourceLoader();
/*     */   
/* 114 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   
/* 116 */   private MetadataReaderFactory metadataReaderFactory = new CachingMetadataReaderFactory();
/*     */   
/* 118 */   private boolean setMetadataReaderFactoryCalled = false;
/*     */   
/* 120 */   private final Set<Integer> registriesPostProcessed = new HashSet();
/*     */   
/* 122 */   private final Set<Integer> factoriesPostProcessed = new HashSet();
/*     */   
/*     */   private ConfigurationClassBeanDefinitionReader reader;
/*     */   
/* 126 */   private boolean localBeanNameGeneratorSet = false;
/*     */   
/*     */ 
/* 129 */   private BeanNameGenerator componentScanBeanNameGenerator = new AnnotationBeanNameGenerator();
/*     */   
/*     */ 
/* 132 */   private BeanNameGenerator importBeanNameGenerator = new AnnotationBeanNameGenerator()
/*     */   {
/*     */     protected String buildDefaultBeanName(BeanDefinition definition) {
/* 135 */       return definition.getBeanClassName();
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */   public int getOrder()
/*     */   {
/* 142 */     return Integer.MAX_VALUE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSourceExtractor(SourceExtractor sourceExtractor)
/*     */   {
/* 150 */     this.sourceExtractor = (sourceExtractor != null ? sourceExtractor : new PassThroughSourceExtractor());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProblemReporter(ProblemReporter problemReporter)
/*     */   {
/* 160 */     this.problemReporter = (problemReporter != null ? problemReporter : new FailFastProblemReporter());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMetadataReaderFactory(MetadataReaderFactory metadataReaderFactory)
/*     */   {
/* 169 */     Assert.notNull(metadataReaderFactory, "MetadataReaderFactory must not be null");
/* 170 */     this.metadataReaderFactory = metadataReaderFactory;
/* 171 */     this.setMetadataReaderFactoryCalled = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBeanNameGenerator(BeanNameGenerator beanNameGenerator)
/*     */   {
/* 192 */     Assert.notNull(beanNameGenerator, "BeanNameGenerator must not be null");
/* 193 */     this.localBeanNameGeneratorSet = true;
/* 194 */     this.componentScanBeanNameGenerator = beanNameGenerator;
/* 195 */     this.importBeanNameGenerator = beanNameGenerator;
/*     */   }
/*     */   
/*     */   public void setEnvironment(Environment environment)
/*     */   {
/* 200 */     Assert.notNull(environment, "Environment must not be null");
/* 201 */     this.environment = environment;
/*     */   }
/*     */   
/*     */   public void setResourceLoader(ResourceLoader resourceLoader)
/*     */   {
/* 206 */     Assert.notNull(resourceLoader, "ResourceLoader must not be null");
/* 207 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader beanClassLoader)
/*     */   {
/* 212 */     this.beanClassLoader = beanClassLoader;
/* 213 */     if (!this.setMetadataReaderFactoryCalled) {
/* 214 */       this.metadataReaderFactory = new CachingMetadataReaderFactory(beanClassLoader);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry)
/*     */   {
/* 224 */     RootBeanDefinition iabpp = new RootBeanDefinition(ImportAwareBeanPostProcessor.class);
/* 225 */     iabpp.setRole(2);
/* 226 */     registry.registerBeanDefinition(IMPORT_AWARE_PROCESSOR_BEAN_NAME, iabpp);
/*     */     
/* 228 */     RootBeanDefinition ecbpp = new RootBeanDefinition(EnhancedConfigurationBeanPostProcessor.class);
/* 229 */     ecbpp.setRole(2);
/* 230 */     registry.registerBeanDefinition(ENHANCED_CONFIGURATION_PROCESSOR_BEAN_NAME, ecbpp);
/*     */     
/* 232 */     int registryId = System.identityHashCode(registry);
/* 233 */     if (this.registriesPostProcessed.contains(Integer.valueOf(registryId))) {
/* 234 */       throw new IllegalStateException("postProcessBeanDefinitionRegistry already called on this post-processor against " + registry);
/*     */     }
/*     */     
/* 237 */     if (this.factoriesPostProcessed.contains(Integer.valueOf(registryId))) {
/* 238 */       throw new IllegalStateException("postProcessBeanFactory already called on this post-processor against " + registry);
/*     */     }
/*     */     
/* 241 */     this.registriesPostProcessed.add(Integer.valueOf(registryId));
/*     */     
/* 243 */     processConfigBeanDefinitions(registry);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*     */   {
/* 252 */     int factoryId = System.identityHashCode(beanFactory);
/* 253 */     if (this.factoriesPostProcessed.contains(Integer.valueOf(factoryId))) {
/* 254 */       throw new IllegalStateException("postProcessBeanFactory already called on this post-processor against " + beanFactory);
/*     */     }
/*     */     
/* 257 */     this.factoriesPostProcessed.add(Integer.valueOf(factoryId));
/* 258 */     if (!this.registriesPostProcessed.contains(Integer.valueOf(factoryId)))
/*     */     {
/*     */ 
/* 261 */       processConfigBeanDefinitions((BeanDefinitionRegistry)beanFactory);
/*     */     }
/* 263 */     enhanceConfigurationClasses(beanFactory);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void processConfigBeanDefinitions(BeanDefinitionRegistry registry)
/*     */   {
/* 271 */     List<BeanDefinitionHolder> configCandidates = new ArrayList();
/* 272 */     String[] candidateNames = registry.getBeanDefinitionNames();
/*     */     
/* 274 */     for (String beanName : candidateNames) {
/* 275 */       BeanDefinition beanDef = registry.getBeanDefinition(beanName);
/* 276 */       if ((ConfigurationClassUtils.isFullConfigurationClass(beanDef)) || 
/* 277 */         (ConfigurationClassUtils.isLiteConfigurationClass(beanDef))) {
/* 278 */         if (this.logger.isDebugEnabled()) {
/* 279 */           this.logger.debug("Bean definition has already been processed as a configuration class: " + beanDef);
/*     */         }
/*     */       }
/* 282 */       else if (ConfigurationClassUtils.checkConfigurationClassCandidate(beanDef, this.metadataReaderFactory)) {
/* 283 */         configCandidates.add(new BeanDefinitionHolder(beanDef, beanName));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 288 */     if (configCandidates.isEmpty()) {
/* 289 */       return;
/*     */     }
/*     */     
/*     */ 
/* 293 */     Collections.sort(configCandidates, new Comparator()
/*     */     {
/*     */       public int compare(BeanDefinitionHolder bd1, BeanDefinitionHolder bd2) {
/* 296 */         int i1 = ConfigurationClassUtils.getOrder(bd1.getBeanDefinition());
/* 297 */         int i2 = ConfigurationClassUtils.getOrder(bd2.getBeanDefinition());
/* 298 */         return i1 > i2 ? 1 : i1 < i2 ? -1 : 0;
/*     */       }
/*     */       
/*     */ 
/* 302 */     });
/* 303 */     SingletonBeanRegistry singletonRegistry = null;
/* 304 */     if ((registry instanceof SingletonBeanRegistry)) {
/* 305 */       singletonRegistry = (SingletonBeanRegistry)registry;
/* 306 */       if ((!this.localBeanNameGeneratorSet) && (singletonRegistry.containsSingleton("org.springframework.context.annotation.internalConfigurationBeanNameGenerator"))) {
/* 307 */         BeanNameGenerator generator = (BeanNameGenerator)singletonRegistry.getSingleton("org.springframework.context.annotation.internalConfigurationBeanNameGenerator");
/* 308 */         this.componentScanBeanNameGenerator = generator;
/* 309 */         this.importBeanNameGenerator = generator;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 314 */     ConfigurationClassParser parser = new ConfigurationClassParser(this.metadataReaderFactory, this.problemReporter, this.environment, this.resourceLoader, this.componentScanBeanNameGenerator, registry);
/*     */     
/*     */ 
/*     */ 
/* 318 */     Object candidates = new LinkedHashSet(configCandidates);
/* 319 */     Set<ConfigurationClass> alreadyParsed = new HashSet(configCandidates.size());
/*     */     do {
/* 321 */       parser.parse((Set)candidates);
/* 322 */       parser.validate();
/*     */       
/* 324 */       Set<ConfigurationClass> configClasses = new LinkedHashSet(parser.getConfigurationClasses());
/* 325 */       configClasses.removeAll(alreadyParsed);
/*     */       
/*     */ 
/* 328 */       if (this.reader == null)
/*     */       {
/*     */ 
/* 331 */         this.reader = new ConfigurationClassBeanDefinitionReader(registry, this.sourceExtractor, this.resourceLoader, this.environment, this.importBeanNameGenerator, parser.getImportRegistry());
/*     */       }
/* 333 */       this.reader.loadBeanDefinitions(configClasses);
/* 334 */       alreadyParsed.addAll(configClasses);
/*     */       
/* 336 */       ((Set)candidates).clear();
/* 337 */       if (registry.getBeanDefinitionCount() > candidateNames.length) {
/* 338 */         String[] newCandidateNames = registry.getBeanDefinitionNames();
/* 339 */         Set<String> oldCandidateNames = new HashSet(Arrays.asList(candidateNames));
/* 340 */         Set<String> alreadyParsedClasses = new HashSet();
/* 341 */         for (Object localObject1 = alreadyParsed.iterator(); ((Iterator)localObject1).hasNext();) { configurationClass = (ConfigurationClass)((Iterator)localObject1).next();
/* 342 */           alreadyParsedClasses.add(configurationClass.getMetadata().getClassName());
/*     */         }
/* 344 */         localObject1 = newCandidateNames;ConfigurationClass configurationClass = localObject1.length; for (ConfigurationClass localConfigurationClass1 = 0; localConfigurationClass1 < configurationClass; localConfigurationClass1++) { String candidateName = localObject1[localConfigurationClass1];
/* 345 */           if (!oldCandidateNames.contains(candidateName)) {
/* 346 */             BeanDefinition beanDef = registry.getBeanDefinition(candidateName);
/* 347 */             if ((ConfigurationClassUtils.checkConfigurationClassCandidate(beanDef, this.metadataReaderFactory)) && 
/* 348 */               (!alreadyParsedClasses.contains(beanDef.getBeanClassName()))) {
/* 349 */               ((Set)candidates).add(new BeanDefinitionHolder(beanDef, candidateName));
/*     */             }
/*     */           }
/*     */         }
/* 353 */         candidateNames = newCandidateNames;
/*     */       }
/*     */       
/* 356 */     } while (!((Set)candidates).isEmpty());
/*     */     
/*     */ 
/* 359 */     if ((singletonRegistry != null) && 
/* 360 */       (!singletonRegistry.containsSingleton(IMPORT_REGISTRY_BEAN_NAME))) {
/* 361 */       singletonRegistry.registerSingleton(IMPORT_REGISTRY_BEAN_NAME, parser.getImportRegistry());
/*     */     }
/*     */     
/*     */ 
/* 365 */     if ((this.metadataReaderFactory instanceof CachingMetadataReaderFactory)) {
/* 366 */       ((CachingMetadataReaderFactory)this.metadataReaderFactory).clearCache();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void enhanceConfigurationClasses(ConfigurableListableBeanFactory beanFactory)
/*     */   {
/* 377 */     Map<String, AbstractBeanDefinition> configBeanDefs = new LinkedHashMap();
/* 378 */     for (String beanName : beanFactory.getBeanDefinitionNames()) {
/* 379 */       BeanDefinition beanDef = beanFactory.getBeanDefinition(beanName);
/* 380 */       if (ConfigurationClassUtils.isFullConfigurationClass(beanDef)) {
/* 381 */         if (!(beanDef instanceof AbstractBeanDefinition)) {
/* 382 */           throw new BeanDefinitionStoreException("Cannot enhance @Configuration bean definition '" + beanName + "' since it is not stored in an AbstractBeanDefinition subclass");
/*     */         }
/*     */         
/* 385 */         if ((this.logger.isWarnEnabled()) && (beanFactory.containsSingleton(beanName))) {
/* 386 */           this.logger.warn("Cannot enhance @Configuration bean definition '" + beanName + "' since its singleton instance has been created too early. The typical cause " + "is a non-static @Bean method with a BeanDefinitionRegistryPostProcessor " + "return type: Consider declaring such methods as 'static'.");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 391 */         configBeanDefs.put(beanName, (AbstractBeanDefinition)beanDef);
/*     */       }
/*     */     }
/* 394 */     if (configBeanDefs.isEmpty())
/*     */     {
/* 396 */       return;
/*     */     }
/* 398 */     ConfigurationClassEnhancer enhancer = new ConfigurationClassEnhancer();
/* 399 */     for (Object entry : configBeanDefs.entrySet()) {
/* 400 */       AbstractBeanDefinition beanDef = (AbstractBeanDefinition)((Map.Entry)entry).getValue();
/*     */       
/* 402 */       beanDef.setAttribute(AutoProxyUtils.PRESERVE_TARGET_CLASS_ATTRIBUTE, Boolean.TRUE);
/*     */       try
/*     */       {
/* 405 */         Class<?> configClass = beanDef.resolveBeanClass(this.beanClassLoader);
/* 406 */         Class<?> enhancedClass = enhancer.enhance(configClass, this.beanClassLoader);
/* 407 */         if (configClass != enhancedClass) {
/* 408 */           if (this.logger.isDebugEnabled()) {
/* 409 */             this.logger.debug(String.format("Replacing bean definition '%s' existing class '%s' with enhanced class '%s'", new Object[] {((Map.Entry)entry)
/* 410 */               .getKey(), configClass.getName(), enhancedClass.getName() }));
/*     */           }
/* 412 */           beanDef.setBeanClass(enhancedClass);
/*     */         }
/*     */       }
/*     */       catch (Throwable ex) {
/* 416 */         throw new IllegalStateException("Cannot load configuration class: " + beanDef.getBeanClassName(), ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ImportAwareBeanPostProcessor
/*     */     implements BeanPostProcessor, BeanFactoryAware, PriorityOrdered
/*     */   {
/*     */     private BeanFactory beanFactory;
/*     */     
/*     */     public void setBeanFactory(BeanFactory beanFactory)
/*     */     {
/* 428 */       this.beanFactory = beanFactory;
/*     */     }
/*     */     
/*     */     public int getOrder()
/*     */     {
/* 433 */       return Integer.MIN_VALUE;
/*     */     }
/*     */     
/*     */     public Object postProcessBeforeInitialization(Object bean, String beanName)
/*     */     {
/* 438 */       if ((bean instanceof ImportAware)) {
/* 439 */         ImportRegistry importRegistry = (ImportRegistry)this.beanFactory.getBean(ConfigurationClassPostProcessor.IMPORT_REGISTRY_BEAN_NAME, ImportRegistry.class);
/* 440 */         AnnotationMetadata importingClass = importRegistry.getImportingClassFor(bean.getClass().getSuperclass().getName());
/* 441 */         if (importingClass != null) {
/* 442 */           ((ImportAware)bean).setImportMetadata(importingClass);
/*     */         }
/*     */       }
/* 445 */       return bean;
/*     */     }
/*     */     
/*     */     public Object postProcessAfterInitialization(Object bean, String beanName)
/*     */     {
/* 450 */       return bean;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class EnhancedConfigurationBeanPostProcessor
/*     */     extends InstantiationAwareBeanPostProcessorAdapter
/*     */     implements PriorityOrdered, BeanFactoryAware
/*     */   {
/*     */     private BeanFactory beanFactory;
/*     */     
/*     */ 
/*     */ 
/*     */     public int getOrder()
/*     */     {
/* 467 */       return Integer.MIN_VALUE;
/*     */     }
/*     */     
/*     */     public void setBeanFactory(BeanFactory beanFactory)
/*     */     {
/* 472 */       this.beanFactory = beanFactory;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public PropertyValues postProcessPropertyValues(PropertyValues pvs, PropertyDescriptor[] pds, Object bean, String beanName)
/*     */     {
/* 479 */       if ((bean instanceof ConfigurationClassEnhancer.EnhancedConfiguration)) {
/* 480 */         ((ConfigurationClassEnhancer.EnhancedConfiguration)bean).setBeanFactory(this.beanFactory);
/*     */       }
/* 482 */       return pvs;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\context\annotation\ConfigurationClassPostProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */