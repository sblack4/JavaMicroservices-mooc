/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.EnvironmentCapable;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.core.io.support.ResourcePatternUtils;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.CachingMetadataReaderFactory;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.stereotype.Component;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassPathScanningCandidateComponentProvider
/*     */   implements EnvironmentCapable, ResourceLoaderAware
/*     */ {
/*     */   static final String DEFAULT_RESOURCE_PATTERN = "**/*.class";
/*  75 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private Environment environment;
/*     */   
/*  79 */   private ResourcePatternResolver resourcePatternResolver = new PathMatchingResourcePatternResolver();
/*     */   
/*  81 */   private MetadataReaderFactory metadataReaderFactory = new CachingMetadataReaderFactory(this.resourcePatternResolver);
/*     */   
/*     */ 
/*  84 */   private String resourcePattern = "**/*.class";
/*     */   
/*  86 */   private final List<TypeFilter> includeFilters = new LinkedList();
/*     */   
/*  88 */   private final List<TypeFilter> excludeFilters = new LinkedList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ConditionEvaluator conditionEvaluator;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClassPathScanningCandidateComponentProvider(boolean useDefaultFilters)
/*     */   {
/* 102 */     this(useDefaultFilters, new StandardEnvironment());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClassPathScanningCandidateComponentProvider(boolean useDefaultFilters, Environment environment)
/*     */   {
/* 115 */     if (useDefaultFilters) {
/* 116 */       registerDefaultFilters();
/*     */     }
/* 118 */     Assert.notNull(environment, "Environment must not be null");
/* 119 */     this.environment = environment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResourceLoader(ResourceLoader resourceLoader)
/*     */   {
/* 133 */     this.resourcePatternResolver = ResourcePatternUtils.getResourcePatternResolver(resourceLoader);
/* 134 */     this.metadataReaderFactory = new CachingMetadataReaderFactory(resourceLoader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final ResourceLoader getResourceLoader()
/*     */   {
/* 141 */     return this.resourcePatternResolver;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMetadataReaderFactory(MetadataReaderFactory metadataReaderFactory)
/*     */   {
/* 152 */     this.metadataReaderFactory = metadataReaderFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final MetadataReaderFactory getMetadataReaderFactory()
/*     */   {
/* 159 */     return this.metadataReaderFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnvironment(Environment environment)
/*     */   {
/* 169 */     Assert.notNull(environment, "Environment must not be null");
/* 170 */     this.environment = environment;
/* 171 */     this.conditionEvaluator = null;
/*     */   }
/*     */   
/*     */   public final Environment getEnvironment()
/*     */   {
/* 176 */     return this.environment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected BeanDefinitionRegistry getRegistry()
/*     */   {
/* 183 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResourcePattern(String resourcePattern)
/*     */   {
/* 193 */     Assert.notNull(resourcePattern, "'resourcePattern' must not be null");
/* 194 */     this.resourcePattern = resourcePattern;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addIncludeFilter(TypeFilter includeFilter)
/*     */   {
/* 201 */     this.includeFilters.add(includeFilter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addExcludeFilter(TypeFilter excludeFilter)
/*     */   {
/* 208 */     this.excludeFilters.add(0, excludeFilter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void resetFilters(boolean useDefaultFilters)
/*     */   {
/* 220 */     this.includeFilters.clear();
/* 221 */     this.excludeFilters.clear();
/* 222 */     if (useDefaultFilters) {
/* 223 */       registerDefaultFilters();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void registerDefaultFilters()
/*     */   {
/* 239 */     this.includeFilters.add(new AnnotationTypeFilter(Component.class));
/* 240 */     ClassLoader cl = ClassPathScanningCandidateComponentProvider.class.getClassLoader();
/*     */     try {
/* 242 */       this.includeFilters.add(new AnnotationTypeFilter(
/* 243 */         ClassUtils.forName("javax.annotation.ManagedBean", cl), false));
/* 244 */       this.logger.debug("JSR-250 'javax.annotation.ManagedBean' found and supported for component scanning");
/*     */     }
/*     */     catch (ClassNotFoundException localClassNotFoundException) {}
/*     */     
/*     */     try
/*     */     {
/* 250 */       this.includeFilters.add(new AnnotationTypeFilter(
/* 251 */         ClassUtils.forName("javax.inject.Named", cl), false));
/* 252 */       this.logger.debug("JSR-330 'javax.inject.Named' annotation found and supported for component scanning");
/*     */     }
/*     */     catch (ClassNotFoundException localClassNotFoundException1) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<BeanDefinition> findCandidateComponents(String basePackage)
/*     */   {
/* 266 */     Set<BeanDefinition> candidates = new LinkedHashSet();
/*     */     try
/*     */     {
/* 269 */       String packageSearchPath = "classpath*:" + resolveBasePackage(basePackage) + "/" + this.resourcePattern;
/* 270 */       Resource[] resources = this.resourcePatternResolver.getResources(packageSearchPath);
/* 271 */       boolean traceEnabled = this.logger.isTraceEnabled();
/* 272 */       boolean debugEnabled = this.logger.isDebugEnabled();
/* 273 */       for (Resource resource : resources) {
/* 274 */         if (traceEnabled) {
/* 275 */           this.logger.trace("Scanning " + resource);
/*     */         }
/* 277 */         if (resource.isReadable()) {
/*     */           try {
/* 279 */             MetadataReader metadataReader = this.metadataReaderFactory.getMetadataReader(resource);
/* 280 */             if (isCandidateComponent(metadataReader)) {
/* 281 */               ScannedGenericBeanDefinition sbd = new ScannedGenericBeanDefinition(metadataReader);
/* 282 */               sbd.setResource(resource);
/* 283 */               sbd.setSource(resource);
/* 284 */               if (isCandidateComponent(sbd)) {
/* 285 */                 if (debugEnabled) {
/* 286 */                   this.logger.debug("Identified candidate component class: " + resource);
/*     */                 }
/* 288 */                 candidates.add(sbd);
/*     */ 
/*     */               }
/* 291 */               else if (debugEnabled) {
/* 292 */                 this.logger.debug("Ignored because not a concrete top-level class: " + resource);
/*     */               }
/*     */               
/*     */ 
/*     */             }
/* 297 */             else if (traceEnabled) {
/* 298 */               this.logger.trace("Ignored because not matching any filter: " + resource);
/*     */             }
/*     */           }
/*     */           catch (Throwable ex)
/*     */           {
/* 303 */             throw new BeanDefinitionStoreException("Failed to read candidate component class: " + resource, ex);
/*     */ 
/*     */           }
/*     */           
/*     */         }
/* 308 */         else if (traceEnabled) {
/* 309 */           this.logger.trace("Ignored because not readable: " + resource);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 315 */       throw new BeanDefinitionStoreException("I/O failure during classpath scanning", ex);
/*     */     }
/* 317 */     return candidates;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String resolveBasePackage(String basePackage)
/*     */   {
/* 330 */     return ClassUtils.convertClassNameToResourcePath(this.environment.resolveRequiredPlaceholders(basePackage));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isCandidateComponent(MetadataReader metadataReader)
/*     */     throws IOException
/*     */   {
/* 340 */     for (TypeFilter tf : this.excludeFilters) {
/* 341 */       if (tf.match(metadataReader, this.metadataReaderFactory)) {
/* 342 */         return false;
/*     */       }
/*     */     }
/* 345 */     for (TypeFilter tf : this.includeFilters) {
/* 346 */       if (tf.match(metadataReader, this.metadataReaderFactory)) {
/* 347 */         return isConditionMatch(metadataReader);
/*     */       }
/*     */     }
/* 350 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isConditionMatch(MetadataReader metadataReader)
/*     */   {
/* 360 */     if (this.conditionEvaluator == null) {
/* 361 */       this.conditionEvaluator = new ConditionEvaluator(getRegistry(), getEnvironment(), getResourceLoader());
/*     */     }
/* 363 */     return !this.conditionEvaluator.shouldSkip(metadataReader.getAnnotationMetadata());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isCandidateComponent(AnnotatedBeanDefinition beanDefinition)
/*     */   {
/* 374 */     return (beanDefinition.getMetadata().isConcrete()) && (beanDefinition.getMetadata().isIndependent());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearCache()
/*     */   {
/* 382 */     if ((this.metadataReaderFactory instanceof CachingMetadataReaderFactory)) {
/* 383 */       ((CachingMetadataReaderFactory)this.metadataReaderFactory).clearCache();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\context\annotation\ClassPathScanningCandidateComponentProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */