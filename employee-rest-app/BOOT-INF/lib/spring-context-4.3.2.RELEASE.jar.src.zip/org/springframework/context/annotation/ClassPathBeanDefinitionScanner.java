/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionDefaults;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionReaderUtils;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.EnvironmentCapable;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassPathBeanDefinitionScanner
/*     */   extends ClassPathScanningCandidateComponentProvider
/*     */ {
/*     */   private final BeanDefinitionRegistry registry;
/*  66 */   private BeanDefinitionDefaults beanDefinitionDefaults = new BeanDefinitionDefaults();
/*     */   
/*     */   private String[] autowireCandidatePatterns;
/*     */   
/*  70 */   private BeanNameGenerator beanNameGenerator = new AnnotationBeanNameGenerator();
/*     */   
/*  72 */   private ScopeMetadataResolver scopeMetadataResolver = new AnnotationScopeMetadataResolver();
/*     */   
/*  74 */   private boolean includeAnnotationConfig = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClassPathBeanDefinitionScanner(BeanDefinitionRegistry registry)
/*     */   {
/*  83 */     this(registry, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClassPathBeanDefinitionScanner(BeanDefinitionRegistry registry, boolean useDefaultFilters)
/*     */   {
/* 111 */     this(registry, useDefaultFilters, getOrCreateEnvironment(registry));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClassPathBeanDefinitionScanner(BeanDefinitionRegistry registry, boolean useDefaultFilters, Environment environment)
/*     */   {
/* 136 */     super(useDefaultFilters, environment);
/*     */     
/* 138 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/* 139 */     this.registry = registry;
/*     */     
/*     */ 
/* 142 */     if ((this.registry instanceof ResourceLoader)) {
/* 143 */       setResourceLoader((ResourceLoader)this.registry);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final BeanDefinitionRegistry getRegistry()
/*     */   {
/* 152 */     return this.registry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBeanDefinitionDefaults(BeanDefinitionDefaults beanDefinitionDefaults)
/*     */   {
/* 160 */     this.beanDefinitionDefaults = (beanDefinitionDefaults != null ? beanDefinitionDefaults : new BeanDefinitionDefaults());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BeanDefinitionDefaults getBeanDefinitionDefaults()
/*     */   {
/* 169 */     return this.beanDefinitionDefaults;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutowireCandidatePatterns(String... autowireCandidatePatterns)
/*     */   {
/* 177 */     this.autowireCandidatePatterns = autowireCandidatePatterns;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBeanNameGenerator(BeanNameGenerator beanNameGenerator)
/*     */   {
/* 185 */     this.beanNameGenerator = (beanNameGenerator != null ? beanNameGenerator : new AnnotationBeanNameGenerator());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScopeMetadataResolver(ScopeMetadataResolver scopeMetadataResolver)
/*     */   {
/* 195 */     this.scopeMetadataResolver = (scopeMetadataResolver != null ? scopeMetadataResolver : new AnnotationScopeMetadataResolver());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScopedProxyMode(ScopedProxyMode scopedProxyMode)
/*     */   {
/* 205 */     this.scopeMetadataResolver = new AnnotationScopeMetadataResolver(scopedProxyMode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIncludeAnnotationConfig(boolean includeAnnotationConfig)
/*     */   {
/* 214 */     this.includeAnnotationConfig = includeAnnotationConfig;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int scan(String... basePackages)
/*     */   {
/* 224 */     int beanCountAtScanStart = this.registry.getBeanDefinitionCount();
/*     */     
/* 226 */     doScan(basePackages);
/*     */     
/*     */ 
/* 229 */     if (this.includeAnnotationConfig) {
/* 230 */       AnnotationConfigUtils.registerAnnotationConfigProcessors(this.registry);
/*     */     }
/*     */     
/* 233 */     return this.registry.getBeanDefinitionCount() - beanCountAtScanStart;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Set<BeanDefinitionHolder> doScan(String... basePackages)
/*     */   {
/* 245 */     Assert.notEmpty(basePackages, "At least one base package must be specified");
/* 246 */     Set<BeanDefinitionHolder> beanDefinitions = new LinkedHashSet();
/* 247 */     for (String basePackage : basePackages) {
/* 248 */       Set<BeanDefinition> candidates = findCandidateComponents(basePackage);
/* 249 */       for (BeanDefinition candidate : candidates) {
/* 250 */         ScopeMetadata scopeMetadata = this.scopeMetadataResolver.resolveScopeMetadata(candidate);
/* 251 */         candidate.setScope(scopeMetadata.getScopeName());
/* 252 */         String beanName = this.beanNameGenerator.generateBeanName(candidate, this.registry);
/* 253 */         if ((candidate instanceof AbstractBeanDefinition)) {
/* 254 */           postProcessBeanDefinition((AbstractBeanDefinition)candidate, beanName);
/*     */         }
/* 256 */         if ((candidate instanceof AnnotatedBeanDefinition)) {
/* 257 */           AnnotationConfigUtils.processCommonDefinitionAnnotations((AnnotatedBeanDefinition)candidate);
/*     */         }
/* 259 */         if (checkCandidate(beanName, candidate)) {
/* 260 */           BeanDefinitionHolder definitionHolder = new BeanDefinitionHolder(candidate, beanName);
/* 261 */           definitionHolder = AnnotationConfigUtils.applyScopedProxyMode(scopeMetadata, definitionHolder, this.registry);
/* 262 */           beanDefinitions.add(definitionHolder);
/* 263 */           registerBeanDefinition(definitionHolder, this.registry);
/*     */         }
/*     */       }
/*     */     }
/* 267 */     return beanDefinitions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void postProcessBeanDefinition(AbstractBeanDefinition beanDefinition, String beanName)
/*     */   {
/* 277 */     beanDefinition.applyDefaults(this.beanDefinitionDefaults);
/* 278 */     if (this.autowireCandidatePatterns != null) {
/* 279 */       beanDefinition.setAutowireCandidate(PatternMatchUtils.simpleMatch(this.autowireCandidatePatterns, beanName));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void registerBeanDefinition(BeanDefinitionHolder definitionHolder, BeanDefinitionRegistry registry)
/*     */   {
/* 291 */     BeanDefinitionReaderUtils.registerBeanDefinition(definitionHolder, registry);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean checkCandidate(String beanName, BeanDefinition beanDefinition)
/*     */     throws IllegalStateException
/*     */   {
/* 307 */     if (!this.registry.containsBeanDefinition(beanName)) {
/* 308 */       return true;
/*     */     }
/* 310 */     BeanDefinition existingDef = this.registry.getBeanDefinition(beanName);
/* 311 */     BeanDefinition originatingDef = existingDef.getOriginatingBeanDefinition();
/* 312 */     if (originatingDef != null) {
/* 313 */       existingDef = originatingDef;
/*     */     }
/* 315 */     if (isCompatible(beanDefinition, existingDef)) {
/* 316 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 320 */     throw new ConflictingBeanDefinitionException("Annotation-specified bean name '" + beanName + "' for bean class [" + beanDefinition.getBeanClassName() + "] conflicts with existing, " + "non-compatible bean definition of same name and class [" + existingDef.getBeanClassName() + "]");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isCompatible(BeanDefinition newDefinition, BeanDefinition existingDefinition)
/*     */   {
/* 337 */     return (!(existingDefinition instanceof ScannedGenericBeanDefinition)) || (newDefinition.getSource().equals(existingDefinition.getSource())) || (newDefinition.equals(existingDefinition));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Environment getOrCreateEnvironment(BeanDefinitionRegistry registry)
/*     */   {
/* 346 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/* 347 */     if ((registry instanceof EnvironmentCapable)) {
/* 348 */       return ((EnvironmentCapable)registry).getEnvironment();
/*     */     }
/* 350 */     return new StandardEnvironment();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\context\annotation\ClassPathBeanDefinitionScanner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */