package org.springframework.context.annotation;

public enum ScopedProxyMode
{
  DEFAULT,  NO,  INTERFACES,  TARGET_CLASS;
  
  private ScopedProxyMode() {}
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\context\annotation\ScopedProxyMode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */