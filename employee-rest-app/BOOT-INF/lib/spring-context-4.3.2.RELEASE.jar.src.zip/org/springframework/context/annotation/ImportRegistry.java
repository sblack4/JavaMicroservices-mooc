package org.springframework.context.annotation;

import org.springframework.core.type.AnnotationMetadata;

abstract interface ImportRegistry
{
  public abstract AnnotationMetadata getImportingClassFor(String paramString);
  
  public abstract void removeImportingClassFor(String paramString);
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\context\annotation\ImportRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */