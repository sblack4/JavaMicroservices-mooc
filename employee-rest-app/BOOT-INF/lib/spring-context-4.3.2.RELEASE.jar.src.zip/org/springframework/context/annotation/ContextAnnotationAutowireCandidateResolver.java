/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.annotation.QualifierAnnotationAutowireCandidateResolver;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextAnnotationAutowireCandidateResolver
/*     */   extends QualifierAnnotationAutowireCandidateResolver
/*     */ {
/*     */   public Object getLazyResolutionProxyIfNecessary(DependencyDescriptor descriptor, String beanName)
/*     */   {
/*  45 */     return isLazy(descriptor) ? buildLazyResolutionProxy(descriptor, beanName) : null;
/*     */   }
/*     */   
/*     */   protected boolean isLazy(DependencyDescriptor descriptor) {
/*  49 */     for (Annotation ann : descriptor.getAnnotations()) {
/*  50 */       Lazy lazy = (Lazy)AnnotationUtils.getAnnotation(ann, Lazy.class);
/*  51 */       if ((lazy != null) && (lazy.value())) {
/*  52 */         return true;
/*     */       }
/*     */     }
/*  55 */     MethodParameter methodParam = descriptor.getMethodParameter();
/*  56 */     if (methodParam != null) {
/*  57 */       Method method = methodParam.getMethod();
/*  58 */       if ((method == null) || (Void.TYPE == method.getReturnType())) {
/*  59 */         Lazy lazy = (Lazy)AnnotationUtils.getAnnotation(methodParam.getAnnotatedElement(), Lazy.class);
/*  60 */         if ((lazy != null) && (lazy.value())) {
/*  61 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*  65 */     return false;
/*     */   }
/*     */   
/*     */   protected Object buildLazyResolutionProxy(final DependencyDescriptor descriptor, final String beanName) {
/*  69 */     Assert.state(getBeanFactory() instanceof DefaultListableBeanFactory, "BeanFactory needs to be a DefaultListableBeanFactory");
/*     */     
/*  71 */     final DefaultListableBeanFactory beanFactory = (DefaultListableBeanFactory)getBeanFactory();
/*  72 */     TargetSource ts = new TargetSource()
/*     */     {
/*     */       public Class<?> getTargetClass() {
/*  75 */         return descriptor.getDependencyType();
/*     */       }
/*     */       
/*     */       public boolean isStatic() {
/*  79 */         return false;
/*     */       }
/*     */       
/*     */       public Object getTarget() {
/*  83 */         Object target = beanFactory.doResolveDependency(descriptor, beanName, null, null);
/*  84 */         if (target == null) {
/*  85 */           throw new NoSuchBeanDefinitionException(descriptor.getDependencyType(), "Optional dependency not present for lazy injection point");
/*     */         }
/*     */         
/*  88 */         return target;
/*     */       }
/*     */       
/*     */ 
/*     */       public void releaseTarget(Object target) {}
/*  93 */     };
/*  94 */     ProxyFactory pf = new ProxyFactory();
/*  95 */     pf.setTargetSource(ts);
/*  96 */     Class<?> dependencyType = descriptor.getDependencyType();
/*  97 */     if (dependencyType.isInterface()) {
/*  98 */       pf.addInterface(dependencyType);
/*     */     }
/* 100 */     return pf.getProxy(beanFactory.getBeanClassLoader());
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\context\annotation\ContextAnnotationAutowireCandidateResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */