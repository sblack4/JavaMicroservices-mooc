/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LiveBeansView
/*     */   implements LiveBeansViewMBean, ApplicationContextAware
/*     */ {
/*     */   public static final String MBEAN_DOMAIN_PROPERTY_NAME = "spring.liveBeansView.mbeanDomain";
/*     */   public static final String MBEAN_APPLICATION_KEY = "application";
/*  57 */   private static final Set<ConfigurableApplicationContext> applicationContexts = new LinkedHashSet();
/*     */   private ConfigurableApplicationContext applicationContext;
/*     */   
/*     */   static void registerApplicationContext(ConfigurableApplicationContext applicationContext)
/*     */   {
/*  62 */     String mbeanDomain = applicationContext.getEnvironment().getProperty("spring.liveBeansView.mbeanDomain");
/*  63 */     if (mbeanDomain != null) {
/*  64 */       synchronized (applicationContexts) {
/*  65 */         if (applicationContexts.isEmpty()) {
/*     */           try {
/*  67 */             MBeanServer server = ManagementFactory.getPlatformMBeanServer();
/*  68 */             server.registerMBean(new LiveBeansView(), new ObjectName(mbeanDomain, "application", applicationContext
/*  69 */               .getApplicationName()));
/*     */           }
/*     */           catch (Exception ex) {
/*  72 */             throw new ApplicationContextException("Failed to register LiveBeansView MBean", ex);
/*     */           }
/*     */         }
/*  75 */         applicationContexts.add(applicationContext);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   static void unregisterApplicationContext(ConfigurableApplicationContext applicationContext) {
/*  81 */     synchronized (applicationContexts) {
/*  82 */       if ((applicationContexts.remove(applicationContext)) && (applicationContexts.isEmpty())) {
/*     */         try {
/*  84 */           MBeanServer server = ManagementFactory.getPlatformMBeanServer();
/*  85 */           String mbeanDomain = applicationContext.getEnvironment().getProperty("spring.liveBeansView.mbeanDomain");
/*  86 */           server.unregisterMBean(new ObjectName(mbeanDomain, "application", applicationContext.getApplicationName()));
/*     */         }
/*     */         catch (Exception ex) {
/*  89 */           throw new ApplicationContextException("Failed to unregister LiveBeansView MBean", ex);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setApplicationContext(ApplicationContext applicationContext)
/*     */   {
/* 101 */     Assert.isTrue(applicationContext instanceof ConfigurableApplicationContext, "ApplicationContext does not implement ConfigurableApplicationContext");
/*     */     
/* 103 */     this.applicationContext = ((ConfigurableApplicationContext)applicationContext);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getSnapshotAsJson()
/*     */   {
/*     */     Set<ConfigurableApplicationContext> contexts;
/*     */     
/*     */ 
/*     */     Set<ConfigurableApplicationContext> contexts;
/*     */     
/* 115 */     if (this.applicationContext != null) {
/* 116 */       contexts = Collections.singleton(this.applicationContext);
/*     */     }
/*     */     else {
/* 119 */       contexts = findApplicationContexts();
/*     */     }
/* 121 */     return generateJson(contexts);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected Set<ConfigurableApplicationContext> findApplicationContexts()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 6	org/springframework/context/support/LiveBeansView:applicationContexts	Ljava/util/Set;
/*     */     //   3: dup
/*     */     //   4: astore_1
/*     */     //   5: monitorenter
/*     */     //   6: new 30	java/util/LinkedHashSet
/*     */     //   9: dup
/*     */     //   10: getstatic 6	org/springframework/context/support/LiveBeansView:applicationContexts	Ljava/util/Set;
/*     */     //   13: invokespecial 31	java/util/LinkedHashSet:<init>	(Ljava/util/Collection;)V
/*     */     //   16: aload_1
/*     */     //   17: monitorexit
/*     */     //   18: areturn
/*     */     //   19: astore_2
/*     */     //   20: aload_1
/*     */     //   21: monitorexit
/*     */     //   22: aload_2
/*     */     //   23: athrow
/*     */     // Line number table:
/*     */     //   Java source line #130	-> byte code offset #0
/*     */     //   Java source line #131	-> byte code offset #6
/*     */     //   Java source line #132	-> byte code offset #19
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	24	0	this	LiveBeansView
/*     */     //   4	17	1	Ljava/lang/Object;	Object
/*     */     //   19	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   6	18	19	finally
/*     */     //   19	22	19	finally
/*     */   }
/*     */   
/*     */   protected String generateJson(Set<ConfigurableApplicationContext> contexts)
/*     */   {
/* 147 */     StringBuilder result = new StringBuilder("[\n");
/* 148 */     for (Iterator<ConfigurableApplicationContext> it = contexts.iterator(); it.hasNext();) {
/* 149 */       ConfigurableApplicationContext context = (ConfigurableApplicationContext)it.next();
/* 150 */       result.append("{\n\"context\": \"").append(context.getId()).append("\",\n");
/* 151 */       if (context.getParent() != null) {
/* 152 */         result.append("\"parent\": \"").append(context.getParent().getId()).append("\",\n");
/*     */       }
/*     */       else {
/* 155 */         result.append("\"parent\": null,\n");
/*     */       }
/* 157 */       result.append("\"beans\": [\n");
/* 158 */       ConfigurableListableBeanFactory bf = context.getBeanFactory();
/* 159 */       String[] beanNames = bf.getBeanDefinitionNames();
/* 160 */       boolean elementAppended = false;
/* 161 */       for (String beanName : beanNames) {
/* 162 */         BeanDefinition bd = bf.getBeanDefinition(beanName);
/* 163 */         if (isBeanEligible(beanName, bd, bf)) {
/* 164 */           if (elementAppended) {
/* 165 */             result.append(",\n");
/*     */           }
/* 167 */           result.append("{\n\"bean\": \"").append(beanName).append("\",\n");
/* 168 */           String scope = bd.getScope();
/* 169 */           if (!StringUtils.hasText(scope)) {
/* 170 */             scope = "singleton";
/*     */           }
/* 172 */           result.append("\"scope\": \"").append(scope).append("\",\n");
/* 173 */           Class<?> beanType = bf.getType(beanName);
/* 174 */           if (beanType != null) {
/* 175 */             result.append("\"type\": \"").append(beanType.getName()).append("\",\n");
/*     */           }
/*     */           else {
/* 178 */             result.append("\"type\": null,\n");
/*     */           }
/* 180 */           result.append("\"resource\": \"").append(getEscapedResourceDescription(bd)).append("\",\n");
/* 181 */           result.append("\"dependencies\": [");
/* 182 */           String[] dependencies = bf.getDependenciesForBean(beanName);
/* 183 */           if (dependencies.length > 0) {
/* 184 */             result.append("\"");
/*     */           }
/* 186 */           result.append(StringUtils.arrayToDelimitedString(dependencies, "\", \""));
/* 187 */           if (dependencies.length > 0) {
/* 188 */             result.append("\"");
/*     */           }
/* 190 */           result.append("]\n}");
/* 191 */           elementAppended = true;
/*     */         }
/*     */       }
/* 194 */       result.append("]\n");
/* 195 */       result.append("}");
/* 196 */       if (it.hasNext()) {
/* 197 */         result.append(",\n");
/*     */       }
/*     */     }
/* 200 */     result.append("]");
/* 201 */     return result.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isBeanEligible(String beanName, BeanDefinition bd, ConfigurableBeanFactory bf)
/*     */   {
/* 214 */     return (bd.getRole() != 2) && ((!bd.isLazyInit()) || (bf.containsSingleton(beanName)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getEscapedResourceDescription(BeanDefinition bd)
/*     */   {
/* 224 */     String resourceDescription = bd.getResourceDescription();
/* 225 */     if (resourceDescription == null) {
/* 226 */       return null;
/*     */     }
/* 228 */     StringBuilder result = new StringBuilder(resourceDescription.length() + 16);
/* 229 */     for (int i = 0; i < resourceDescription.length(); i++) {
/* 230 */       char character = resourceDescription.charAt(i);
/* 231 */       if (character == '\\') {
/* 232 */         result.append('/');
/*     */       }
/* 234 */       else if (character == '"') {
/* 235 */         result.append("\\").append('"');
/*     */       }
/*     */       else {
/* 238 */         result.append(character);
/*     */       }
/*     */     }
/* 241 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\context\support\LiveBeansView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */