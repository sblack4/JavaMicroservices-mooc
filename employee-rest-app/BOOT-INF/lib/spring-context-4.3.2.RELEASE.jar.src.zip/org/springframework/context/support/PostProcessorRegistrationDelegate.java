/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.DestructionAwareBeanPostProcessor;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.MergedBeanDefinitionPostProcessor;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.event.ApplicationEventMulticaster;
/*     */ import org.springframework.core.OrderComparator;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.PriorityOrdered;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PostProcessorRegistrationDelegate
/*     */ {
/*     */   public static void invokeBeanFactoryPostProcessors(ConfigurableListableBeanFactory beanFactory, List<BeanFactoryPostProcessor> beanFactoryPostProcessors)
/*     */   {
/*  61 */     Set<String> processedBeans = new HashSet();
/*     */     
/*  63 */     if ((beanFactory instanceof BeanDefinitionRegistry)) {
/*  64 */       BeanDefinitionRegistry registry = (BeanDefinitionRegistry)beanFactory;
/*  65 */       List<BeanFactoryPostProcessor> regularPostProcessors = new LinkedList();
/*  66 */       List<BeanDefinitionRegistryPostProcessor> registryPostProcessors = new LinkedList();
/*     */       
/*     */ 
/*  69 */       for (BeanFactoryPostProcessor postProcessor : beanFactoryPostProcessors) {
/*  70 */         if ((postProcessor instanceof BeanDefinitionRegistryPostProcessor)) {
/*  71 */           registryPostProcessor = (BeanDefinitionRegistryPostProcessor)postProcessor;
/*     */           
/*  73 */           registryPostProcessor.postProcessBeanDefinitionRegistry(registry);
/*  74 */           registryPostProcessors.add(registryPostProcessor);
/*     */         }
/*     */         else {
/*  77 */           regularPostProcessors.add(postProcessor);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  86 */       String[] postProcessorNames = beanFactory.getBeanNamesForType(BeanDefinitionRegistryPostProcessor.class, true, false);
/*     */       
/*     */ 
/*  89 */       priorityOrderedPostProcessors = new ArrayList();
/*  90 */       BeanDefinitionRegistryPostProcessor registryPostProcessor = postProcessorNames;int i = registryPostProcessor.length; for (Object localObject1 = 0; localObject1 < i; localObject1++) { ppName = registryPostProcessor[localObject1];
/*  91 */         if (beanFactory.isTypeMatch(ppName, PriorityOrdered.class)) {
/*  92 */           priorityOrderedPostProcessors.add(beanFactory.getBean(ppName, BeanDefinitionRegistryPostProcessor.class));
/*  93 */           processedBeans.add(ppName);
/*     */         }
/*     */       }
/*  96 */       sortPostProcessors(beanFactory, priorityOrderedPostProcessors);
/*  97 */       registryPostProcessors.addAll(priorityOrderedPostProcessors);
/*  98 */       invokeBeanDefinitionRegistryPostProcessors(priorityOrderedPostProcessors, registry);
/*     */       
/*     */ 
/* 101 */       postProcessorNames = beanFactory.getBeanNamesForType(BeanDefinitionRegistryPostProcessor.class, true, false);
/* 102 */       orderedPostProcessors = new ArrayList();
/* 103 */       String[] arrayOfString1 = postProcessorNames;localObject1 = arrayOfString1.length; String ppName; for (String ppName = 0; ppName < localObject1; ppName++) { ppName = arrayOfString1[ppName];
/* 104 */         if ((!processedBeans.contains(ppName)) && (beanFactory.isTypeMatch(ppName, Ordered.class))) {
/* 105 */           orderedPostProcessors.add(beanFactory.getBean(ppName, BeanDefinitionRegistryPostProcessor.class));
/* 106 */           processedBeans.add(ppName);
/*     */         }
/*     */       }
/* 109 */       sortPostProcessors(beanFactory, orderedPostProcessors);
/* 110 */       registryPostProcessors.addAll(orderedPostProcessors);
/* 111 */       invokeBeanDefinitionRegistryPostProcessors(orderedPostProcessors, registry);
/*     */       
/*     */ 
/* 114 */       reiterate = true;
/* 115 */       while (reiterate) {
/* 116 */         reiterate = false;
/* 117 */         postProcessorNames = beanFactory.getBeanNamesForType(BeanDefinitionRegistryPostProcessor.class, true, false);
/* 118 */         localObject1 = postProcessorNames;ppName = localObject1.length; for (ppName = 0; ppName < ppName; ppName++) { String ppName = localObject1[ppName];
/* 119 */           if (!processedBeans.contains(ppName)) {
/* 120 */             BeanDefinitionRegistryPostProcessor pp = (BeanDefinitionRegistryPostProcessor)beanFactory.getBean(ppName, BeanDefinitionRegistryPostProcessor.class);
/* 121 */             registryPostProcessors.add(pp);
/* 122 */             processedBeans.add(ppName);
/* 123 */             pp.postProcessBeanDefinitionRegistry(registry);
/* 124 */             reiterate = true;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 130 */       invokeBeanFactoryPostProcessors(registryPostProcessors, beanFactory);
/* 131 */       invokeBeanFactoryPostProcessors(regularPostProcessors, beanFactory);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 136 */       invokeBeanFactoryPostProcessors(beanFactoryPostProcessors, beanFactory);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 142 */     String[] postProcessorNames = beanFactory.getBeanNamesForType(BeanFactoryPostProcessor.class, true, false);
/*     */     
/*     */ 
/*     */ 
/* 146 */     List<BeanFactoryPostProcessor> priorityOrderedPostProcessors = new ArrayList();
/* 147 */     List<String> orderedPostProcessorNames = new ArrayList();
/* 148 */     Object nonOrderedPostProcessorNames = new ArrayList();
/* 149 */     List<BeanDefinitionRegistryPostProcessor> priorityOrderedPostProcessors = postProcessorNames;List<BeanDefinitionRegistryPostProcessor> orderedPostProcessors = priorityOrderedPostProcessors.length; for (boolean reiterate = false; reiterate < orderedPostProcessors; reiterate++) { String ppName = priorityOrderedPostProcessors[reiterate];
/* 150 */       if (!processedBeans.contains(ppName))
/*     */       {
/*     */ 
/* 153 */         if (beanFactory.isTypeMatch(ppName, PriorityOrdered.class)) {
/* 154 */           priorityOrderedPostProcessors.add(beanFactory.getBean(ppName, BeanFactoryPostProcessor.class));
/*     */         }
/* 156 */         else if (beanFactory.isTypeMatch(ppName, Ordered.class)) {
/* 157 */           orderedPostProcessorNames.add(ppName);
/*     */         }
/*     */         else {
/* 160 */           ((List)nonOrderedPostProcessorNames).add(ppName);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 165 */     sortPostProcessors(beanFactory, priorityOrderedPostProcessors);
/* 166 */     invokeBeanFactoryPostProcessors(priorityOrderedPostProcessors, beanFactory);
/*     */     
/*     */ 
/* 169 */     List<BeanFactoryPostProcessor> orderedPostProcessors = new ArrayList();
/* 170 */     for (orderedPostProcessors = orderedPostProcessorNames.iterator(); orderedPostProcessors.hasNext();) { postProcessorName = (String)orderedPostProcessors.next();
/* 171 */       orderedPostProcessors.add(beanFactory.getBean((String)postProcessorName, BeanFactoryPostProcessor.class));
/*     */     }
/* 173 */     sortPostProcessors(beanFactory, orderedPostProcessors);
/* 174 */     invokeBeanFactoryPostProcessors(orderedPostProcessors, beanFactory);
/*     */     
/*     */ 
/* 177 */     List<BeanFactoryPostProcessor> nonOrderedPostProcessors = new ArrayList();
/* 178 */     for (Object postProcessorName = ((List)nonOrderedPostProcessorNames).iterator(); ((Iterator)postProcessorName).hasNext();) { String postProcessorName = (String)((Iterator)postProcessorName).next();
/* 179 */       nonOrderedPostProcessors.add(beanFactory.getBean(postProcessorName, BeanFactoryPostProcessor.class));
/*     */     }
/* 181 */     invokeBeanFactoryPostProcessors(nonOrderedPostProcessors, beanFactory);
/*     */     
/*     */ 
/*     */ 
/* 185 */     beanFactory.clearMetadataCache();
/*     */   }
/*     */   
/*     */ 
/*     */   public static void registerBeanPostProcessors(ConfigurableListableBeanFactory beanFactory, AbstractApplicationContext applicationContext)
/*     */   {
/* 191 */     String[] postProcessorNames = beanFactory.getBeanNamesForType(BeanPostProcessor.class, true, false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 196 */     int beanProcessorTargetCount = beanFactory.getBeanPostProcessorCount() + 1 + postProcessorNames.length;
/* 197 */     beanFactory.addBeanPostProcessor(new BeanPostProcessorChecker(beanFactory, beanProcessorTargetCount));
/*     */     
/*     */ 
/*     */ 
/* 201 */     List<BeanPostProcessor> priorityOrderedPostProcessors = new ArrayList();
/* 202 */     List<BeanPostProcessor> internalPostProcessors = new ArrayList();
/* 203 */     List<String> orderedPostProcessorNames = new ArrayList();
/* 204 */     List<String> nonOrderedPostProcessorNames = new ArrayList();
/* 205 */     for (String ppName : postProcessorNames) {
/* 206 */       if (beanFactory.isTypeMatch(ppName, PriorityOrdered.class)) {
/* 207 */         BeanPostProcessor pp = (BeanPostProcessor)beanFactory.getBean(ppName, BeanPostProcessor.class);
/* 208 */         priorityOrderedPostProcessors.add(pp);
/* 209 */         if ((pp instanceof MergedBeanDefinitionPostProcessor)) {
/* 210 */           internalPostProcessors.add(pp);
/*     */         }
/*     */       }
/* 213 */       else if (beanFactory.isTypeMatch(ppName, Ordered.class)) {
/* 214 */         orderedPostProcessorNames.add(ppName);
/*     */       }
/*     */       else {
/* 217 */         nonOrderedPostProcessorNames.add(ppName);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 222 */     sortPostProcessors(beanFactory, priorityOrderedPostProcessors);
/* 223 */     registerBeanPostProcessors(beanFactory, priorityOrderedPostProcessors);
/*     */     
/*     */ 
/* 226 */     Object orderedPostProcessors = new ArrayList();
/* 227 */     for (Iterator localIterator = orderedPostProcessorNames.iterator(); localIterator.hasNext();) { ppName = (String)localIterator.next();
/* 228 */       BeanPostProcessor pp = (BeanPostProcessor)beanFactory.getBean((String)ppName, BeanPostProcessor.class);
/* 229 */       ((List)orderedPostProcessors).add(pp);
/* 230 */       if ((pp instanceof MergedBeanDefinitionPostProcessor)) {
/* 231 */         internalPostProcessors.add(pp);
/*     */       }
/*     */     }
/* 234 */     sortPostProcessors(beanFactory, (List)orderedPostProcessors);
/* 235 */     registerBeanPostProcessors(beanFactory, (List)orderedPostProcessors);
/*     */     
/*     */ 
/* 238 */     Object nonOrderedPostProcessors = new ArrayList();
/* 239 */     for (Object ppName = nonOrderedPostProcessorNames.iterator(); ((Iterator)ppName).hasNext();) { String ppName = (String)((Iterator)ppName).next();
/* 240 */       BeanPostProcessor pp = (BeanPostProcessor)beanFactory.getBean(ppName, BeanPostProcessor.class);
/* 241 */       ((List)nonOrderedPostProcessors).add(pp);
/* 242 */       if ((pp instanceof MergedBeanDefinitionPostProcessor)) {
/* 243 */         internalPostProcessors.add(pp);
/*     */       }
/*     */     }
/* 246 */     registerBeanPostProcessors(beanFactory, (List)nonOrderedPostProcessors);
/*     */     
/*     */ 
/* 249 */     sortPostProcessors(beanFactory, internalPostProcessors);
/* 250 */     registerBeanPostProcessors(beanFactory, internalPostProcessors);
/*     */     
/* 252 */     beanFactory.addBeanPostProcessor(new ApplicationListenerDetector(applicationContext));
/*     */   }
/*     */   
/*     */   private static void sortPostProcessors(ConfigurableListableBeanFactory beanFactory, List<?> postProcessors) {
/* 256 */     Comparator<Object> comparatorToUse = null;
/* 257 */     if ((beanFactory instanceof DefaultListableBeanFactory)) {
/* 258 */       comparatorToUse = ((DefaultListableBeanFactory)beanFactory).getDependencyComparator();
/*     */     }
/* 260 */     if (comparatorToUse == null) {
/* 261 */       comparatorToUse = OrderComparator.INSTANCE;
/*     */     }
/* 263 */     Collections.sort(postProcessors, comparatorToUse);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void invokeBeanDefinitionRegistryPostProcessors(Collection<? extends BeanDefinitionRegistryPostProcessor> postProcessors, BeanDefinitionRegistry registry)
/*     */   {
/* 272 */     for (BeanDefinitionRegistryPostProcessor postProcessor : postProcessors) {
/* 273 */       postProcessor.postProcessBeanDefinitionRegistry(registry);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void invokeBeanFactoryPostProcessors(Collection<? extends BeanFactoryPostProcessor> postProcessors, ConfigurableListableBeanFactory beanFactory)
/*     */   {
/* 283 */     for (BeanFactoryPostProcessor postProcessor : postProcessors) {
/* 284 */       postProcessor.postProcessBeanFactory(beanFactory);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void registerBeanPostProcessors(ConfigurableListableBeanFactory beanFactory, List<BeanPostProcessor> postProcessors)
/*     */   {
/* 294 */     for (BeanPostProcessor postProcessor : postProcessors) {
/* 295 */       beanFactory.addBeanPostProcessor(postProcessor);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class BeanPostProcessorChecker
/*     */     implements BeanPostProcessor
/*     */   {
/* 307 */     private static final Log logger = LogFactory.getLog(BeanPostProcessorChecker.class);
/*     */     
/*     */     private final ConfigurableListableBeanFactory beanFactory;
/*     */     private final int beanPostProcessorTargetCount;
/*     */     
/*     */     public BeanPostProcessorChecker(ConfigurableListableBeanFactory beanFactory, int beanPostProcessorTargetCount)
/*     */     {
/* 314 */       this.beanFactory = beanFactory;
/* 315 */       this.beanPostProcessorTargetCount = beanPostProcessorTargetCount;
/*     */     }
/*     */     
/*     */     public Object postProcessBeforeInitialization(Object bean, String beanName)
/*     */     {
/* 320 */       return bean;
/*     */     }
/*     */     
/*     */     public Object postProcessAfterInitialization(Object bean, String beanName)
/*     */     {
/* 325 */       if ((bean != null) && (!(bean instanceof BeanPostProcessor)) && (!isInfrastructureBean(beanName)) && 
/* 326 */         (this.beanFactory.getBeanPostProcessorCount() < this.beanPostProcessorTargetCount) && 
/* 327 */         (logger.isInfoEnabled())) {
/* 328 */         logger.info("Bean '" + beanName + "' of type [" + bean.getClass() + "] is not eligible for getting processed by all BeanPostProcessors " + "(for example: not eligible for auto-proxying)");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 333 */       return bean;
/*     */     }
/*     */     
/*     */     private boolean isInfrastructureBean(String beanName) {
/* 337 */       if ((beanName != null) && (this.beanFactory.containsBeanDefinition(beanName))) {
/* 338 */         BeanDefinition bd = this.beanFactory.getBeanDefinition(beanName);
/* 339 */         return 2 == bd.getRole();
/*     */       }
/* 341 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class ApplicationListenerDetector
/*     */     implements DestructionAwareBeanPostProcessor, MergedBeanDefinitionPostProcessor
/*     */   {
/* 359 */     private static final Log logger = LogFactory.getLog(ApplicationListenerDetector.class);
/*     */     
/*     */     private final transient AbstractApplicationContext applicationContext;
/*     */     
/* 363 */     private final transient Map<String, Boolean> singletonNames = new ConcurrentHashMap(256);
/*     */     
/*     */     public ApplicationListenerDetector(AbstractApplicationContext applicationContext) {
/* 366 */       this.applicationContext = applicationContext;
/*     */     }
/*     */     
/*     */     public void postProcessMergedBeanDefinition(RootBeanDefinition beanDefinition, Class<?> beanType, String beanName)
/*     */     {
/* 371 */       if ((this.applicationContext != null) && (beanDefinition.isSingleton())) {
/* 372 */         this.singletonNames.put(beanName, Boolean.TRUE);
/*     */       }
/*     */     }
/*     */     
/*     */     public Object postProcessBeforeInitialization(Object bean, String beanName)
/*     */     {
/* 378 */       return bean;
/*     */     }
/*     */     
/*     */     public Object postProcessAfterInitialization(Object bean, String beanName)
/*     */     {
/* 383 */       if ((this.applicationContext != null) && ((bean instanceof ApplicationListener)))
/*     */       {
/* 385 */         Boolean flag = (Boolean)this.singletonNames.get(beanName);
/* 386 */         if (Boolean.TRUE.equals(flag))
/*     */         {
/* 388 */           this.applicationContext.addApplicationListener((ApplicationListener)bean);
/*     */         }
/* 390 */         else if (flag == null) {
/* 391 */           if ((logger.isWarnEnabled()) && (!this.applicationContext.containsBean(beanName)))
/*     */           {
/* 393 */             logger.warn("Inner bean '" + beanName + "' implements ApplicationListener interface " + "but is not reachable for event multicasting by its containing ApplicationContext " + "because it does not have singleton scope. Only top-level listener beans are allowed " + "to be of non-singleton scope.");
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 398 */           this.singletonNames.put(beanName, Boolean.FALSE);
/*     */         }
/*     */       }
/* 401 */       return bean;
/*     */     }
/*     */     
/*     */     public void postProcessBeforeDestruction(Object bean, String beanName)
/*     */     {
/* 406 */       if ((bean instanceof ApplicationListener)) {
/* 407 */         ApplicationEventMulticaster multicaster = this.applicationContext.getApplicationEventMulticaster();
/* 408 */         multicaster.removeApplicationListener((ApplicationListener)bean);
/* 409 */         multicaster.removeApplicationListenerBean(beanName);
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean requiresDestruction(Object bean)
/*     */     {
/* 415 */       return bean instanceof ApplicationListener;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\context\support\PostProcessorRegistrationDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */