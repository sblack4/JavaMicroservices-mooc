/*      */ package org.springframework.context.support;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.beans.BeansException;
/*      */ import org.springframework.beans.CachedIntrospectionResults;
/*      */ import org.springframework.beans.factory.BeanFactory;
/*      */ import org.springframework.beans.factory.DisposableBean;
/*      */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*      */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*      */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*      */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*      */ import org.springframework.beans.support.ResourceEditorRegistrar;
/*      */ import org.springframework.context.ApplicationContext;
/*      */ import org.springframework.context.ApplicationContextAware;
/*      */ import org.springframework.context.ApplicationEvent;
/*      */ import org.springframework.context.ApplicationEventPublisher;
/*      */ import org.springframework.context.ApplicationEventPublisherAware;
/*      */ import org.springframework.context.ApplicationListener;
/*      */ import org.springframework.context.ConfigurableApplicationContext;
/*      */ import org.springframework.context.EnvironmentAware;
/*      */ import org.springframework.context.HierarchicalMessageSource;
/*      */ import org.springframework.context.LifecycleProcessor;
/*      */ import org.springframework.context.MessageSource;
/*      */ import org.springframework.context.MessageSourceAware;
/*      */ import org.springframework.context.MessageSourceResolvable;
/*      */ import org.springframework.context.NoSuchMessageException;
/*      */ import org.springframework.context.PayloadApplicationEvent;
/*      */ import org.springframework.context.ResourceLoaderAware;
/*      */ import org.springframework.context.event.ApplicationEventMulticaster;
/*      */ import org.springframework.context.event.ContextClosedEvent;
/*      */ import org.springframework.context.event.ContextRefreshedEvent;
/*      */ import org.springframework.context.event.ContextStartedEvent;
/*      */ import org.springframework.context.event.ContextStoppedEvent;
/*      */ import org.springframework.context.event.SimpleApplicationEventMulticaster;
/*      */ import org.springframework.context.expression.StandardBeanExpressionResolver;
/*      */ import org.springframework.context.weaving.LoadTimeWeaverAware;
/*      */ import org.springframework.context.weaving.LoadTimeWeaverAwareProcessor;
/*      */ import org.springframework.core.ResolvableType;
/*      */ import org.springframework.core.convert.ConversionService;
/*      */ import org.springframework.core.env.ConfigurableEnvironment;
/*      */ import org.springframework.core.env.Environment;
/*      */ import org.springframework.core.env.StandardEnvironment;
/*      */ import org.springframework.core.io.DefaultResourceLoader;
/*      */ import org.springframework.core.io.Resource;
/*      */ import org.springframework.core.io.ResourceLoader;
/*      */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*      */ import org.springframework.core.io.support.ResourcePatternResolver;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.ReflectionUtils;
/*      */ import org.springframework.util.StringValueResolver;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractApplicationContext
/*      */   extends DefaultResourceLoader
/*      */   implements ConfigurableApplicationContext, DisposableBean
/*      */ {
/*      */   public static final String MESSAGE_SOURCE_BEAN_NAME = "messageSource";
/*      */   public static final String LIFECYCLE_PROCESSOR_BEAN_NAME = "lifecycleProcessor";
/*      */   public static final String APPLICATION_EVENT_MULTICASTER_BEAN_NAME = "applicationEventMulticaster";
/*      */   
/*      */   static
/*      */   {
/*  155 */     ContextClosedEvent.class.getName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*  160 */   protected final Log logger = LogFactory.getLog(getClass());
/*      */   
/*      */ 
/*  163 */   private String id = ObjectUtils.identityToString(this);
/*      */   
/*      */ 
/*  166 */   private String displayName = ObjectUtils.identityToString(this);
/*      */   
/*      */ 
/*      */   private ApplicationContext parent;
/*      */   
/*      */ 
/*      */   private ConfigurableEnvironment environment;
/*      */   
/*      */ 
/*  175 */   private final List<BeanFactoryPostProcessor> beanFactoryPostProcessors = new ArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */   private long startupDate;
/*      */   
/*      */ 
/*  182 */   private final AtomicBoolean active = new AtomicBoolean();
/*      */   
/*      */ 
/*  185 */   private final AtomicBoolean closed = new AtomicBoolean();
/*      */   
/*      */ 
/*  188 */   private final Object startupShutdownMonitor = new Object();
/*      */   
/*      */ 
/*      */   private Thread shutdownHook;
/*      */   
/*      */ 
/*      */   private ResourcePatternResolver resourcePatternResolver;
/*      */   
/*      */ 
/*      */   private LifecycleProcessor lifecycleProcessor;
/*      */   
/*      */ 
/*      */   private MessageSource messageSource;
/*      */   
/*      */ 
/*      */   private ApplicationEventMulticaster applicationEventMulticaster;
/*      */   
/*      */ 
/*  206 */   private final Set<ApplicationListener<?>> applicationListeners = new LinkedHashSet();
/*      */   
/*      */ 
/*      */ 
/*      */   private Set<ApplicationEvent> earlyApplicationEvents;
/*      */   
/*      */ 
/*      */ 
/*      */   public AbstractApplicationContext()
/*      */   {
/*  216 */     this.resourcePatternResolver = getResourcePatternResolver();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public AbstractApplicationContext(ApplicationContext parent)
/*      */   {
/*  224 */     this();
/*  225 */     setParent(parent);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setId(String id)
/*      */   {
/*  241 */     this.id = id;
/*      */   }
/*      */   
/*      */   public String getId()
/*      */   {
/*  246 */     return this.id;
/*      */   }
/*      */   
/*      */   public String getApplicationName()
/*      */   {
/*  251 */     return "";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDisplayName(String displayName)
/*      */   {
/*  260 */     Assert.hasLength(displayName, "Display name must not be empty");
/*  261 */     this.displayName = displayName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDisplayName()
/*      */   {
/*  270 */     return this.displayName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ApplicationContext getParent()
/*      */   {
/*  279 */     return this.parent;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ConfigurableEnvironment getEnvironment()
/*      */   {
/*  289 */     if (this.environment == null) {
/*  290 */       this.environment = createEnvironment();
/*      */     }
/*  292 */     return this.environment;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEnvironment(ConfigurableEnvironment environment)
/*      */   {
/*  305 */     this.environment = environment;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AutowireCapableBeanFactory getAutowireCapableBeanFactory()
/*      */     throws IllegalStateException
/*      */   {
/*  315 */     return getBeanFactory();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getStartupDate()
/*      */   {
/*  323 */     return this.startupDate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void publishEvent(ApplicationEvent event)
/*      */   {
/*  336 */     publishEvent(event, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void publishEvent(Object event)
/*      */   {
/*  349 */     publishEvent(event, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void publishEvent(Object event, ResolvableType eventType)
/*      */   {
/*  360 */     Assert.notNull(event, "Event must not be null");
/*  361 */     if (this.logger.isTraceEnabled()) {
/*  362 */       this.logger.trace("Publishing event in " + getDisplayName() + ": " + event);
/*      */     }
/*      */     
/*      */     ApplicationEvent applicationEvent;
/*      */     ApplicationEvent applicationEvent;
/*  367 */     if ((event instanceof ApplicationEvent)) {
/*  368 */       applicationEvent = (ApplicationEvent)event;
/*      */     }
/*      */     else {
/*  371 */       applicationEvent = new PayloadApplicationEvent(this, event);
/*  372 */       if (eventType == null) {
/*  373 */         eventType = ((PayloadApplicationEvent)applicationEvent).getResolvableType();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  378 */     if (this.earlyApplicationEvents != null) {
/*  379 */       this.earlyApplicationEvents.add(applicationEvent);
/*      */     }
/*      */     else {
/*  382 */       getApplicationEventMulticaster().multicastEvent(applicationEvent, eventType);
/*      */     }
/*      */     
/*      */ 
/*  386 */     if (this.parent != null) {
/*  387 */       if ((this.parent instanceof AbstractApplicationContext)) {
/*  388 */         ((AbstractApplicationContext)this.parent).publishEvent(event, eventType);
/*      */       }
/*      */       else {
/*  391 */         this.parent.publishEvent(event);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   ApplicationEventMulticaster getApplicationEventMulticaster()
/*      */     throws IllegalStateException
/*      */   {
/*  402 */     if (this.applicationEventMulticaster == null) {
/*  403 */       throw new IllegalStateException("ApplicationEventMulticaster not initialized - call 'refresh' before multicasting events via the context: " + this);
/*      */     }
/*      */     
/*  406 */     return this.applicationEventMulticaster;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   LifecycleProcessor getLifecycleProcessor()
/*      */     throws IllegalStateException
/*      */   {
/*  415 */     if (this.lifecycleProcessor == null) {
/*  416 */       throw new IllegalStateException("LifecycleProcessor not initialized - call 'refresh' before invoking lifecycle methods via the context: " + this);
/*      */     }
/*      */     
/*  419 */     return this.lifecycleProcessor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ResourcePatternResolver getResourcePatternResolver()
/*      */   {
/*  437 */     return new PathMatchingResourcePatternResolver(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParent(ApplicationContext parent)
/*      */   {
/*  455 */     this.parent = parent;
/*  456 */     if (parent != null) {
/*  457 */       Environment parentEnvironment = parent.getEnvironment();
/*  458 */       if ((parentEnvironment instanceof ConfigurableEnvironment)) {
/*  459 */         getEnvironment().merge((ConfigurableEnvironment)parentEnvironment);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void addBeanFactoryPostProcessor(BeanFactoryPostProcessor postProcessor)
/*      */   {
/*  466 */     Assert.notNull(postProcessor, "BeanFactoryPostProcessor must not be null");
/*  467 */     this.beanFactoryPostProcessors.add(postProcessor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<BeanFactoryPostProcessor> getBeanFactoryPostProcessors()
/*      */   {
/*  476 */     return this.beanFactoryPostProcessors;
/*      */   }
/*      */   
/*      */   public void addApplicationListener(ApplicationListener<?> listener)
/*      */   {
/*  481 */     Assert.notNull(listener, "ApplicationListener must not be null");
/*  482 */     if (this.applicationEventMulticaster != null) {
/*  483 */       this.applicationEventMulticaster.addApplicationListener(listener);
/*      */     }
/*      */     else {
/*  486 */       this.applicationListeners.add(listener);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Collection<ApplicationListener<?>> getApplicationListeners()
/*      */   {
/*  494 */     return this.applicationListeners;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ConfigurableEnvironment createEnvironment()
/*      */   {
/*  503 */     return new StandardEnvironment();
/*      */   }
/*      */   
/*      */   public void refresh() throws BeansException, IllegalStateException
/*      */   {
/*  508 */     synchronized (this.startupShutdownMonitor)
/*      */     {
/*  510 */       prepareRefresh();
/*      */       
/*      */ 
/*  513 */       ConfigurableListableBeanFactory beanFactory = obtainFreshBeanFactory();
/*      */       
/*      */ 
/*  516 */       prepareBeanFactory(beanFactory);
/*      */       
/*      */       try
/*      */       {
/*  520 */         postProcessBeanFactory(beanFactory);
/*      */         
/*      */ 
/*  523 */         invokeBeanFactoryPostProcessors(beanFactory);
/*      */         
/*      */ 
/*  526 */         registerBeanPostProcessors(beanFactory);
/*      */         
/*      */ 
/*  529 */         initMessageSource();
/*      */         
/*      */ 
/*  532 */         initApplicationEventMulticaster();
/*      */         
/*      */ 
/*  535 */         onRefresh();
/*      */         
/*      */ 
/*  538 */         registerListeners();
/*      */         
/*      */ 
/*  541 */         finishBeanFactoryInitialization(beanFactory);
/*      */         
/*      */ 
/*  544 */         finishRefresh();
/*      */       }
/*      */       catch (BeansException ex)
/*      */       {
/*  548 */         if (this.logger.isWarnEnabled()) {
/*  549 */           this.logger.warn("Exception encountered during context initialization - cancelling refresh attempt: " + ex);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  554 */         destroyBeans();
/*      */         
/*      */ 
/*  557 */         cancelRefresh(ex);
/*      */         
/*      */ 
/*  560 */         throw ex;
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*      */ 
/*  566 */         resetCommonCaches();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void prepareRefresh()
/*      */   {
/*  576 */     this.startupDate = System.currentTimeMillis();
/*  577 */     this.closed.set(false);
/*  578 */     this.active.set(true);
/*      */     
/*  580 */     if (this.logger.isInfoEnabled()) {
/*  581 */       this.logger.info("Refreshing " + this);
/*      */     }
/*      */     
/*      */ 
/*  585 */     initPropertySources();
/*      */     
/*      */ 
/*      */ 
/*  589 */     getEnvironment().validateRequiredProperties();
/*      */     
/*      */ 
/*      */ 
/*  593 */     this.earlyApplicationEvents = new LinkedHashSet();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ConfigurableListableBeanFactory obtainFreshBeanFactory()
/*      */   {
/*  612 */     refreshBeanFactory();
/*  613 */     ConfigurableListableBeanFactory beanFactory = getBeanFactory();
/*  614 */     if (this.logger.isDebugEnabled()) {
/*  615 */       this.logger.debug("Bean factory for " + getDisplayName() + ": " + beanFactory);
/*      */     }
/*  617 */     return beanFactory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void prepareBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*      */   {
/*  627 */     beanFactory.setBeanClassLoader(getClassLoader());
/*  628 */     beanFactory.setBeanExpressionResolver(new StandardBeanExpressionResolver(beanFactory.getBeanClassLoader()));
/*  629 */     beanFactory.addPropertyEditorRegistrar(new ResourceEditorRegistrar(this, getEnvironment()));
/*      */     
/*      */ 
/*  632 */     beanFactory.addBeanPostProcessor(new ApplicationContextAwareProcessor(this));
/*  633 */     beanFactory.ignoreDependencyInterface(ResourceLoaderAware.class);
/*  634 */     beanFactory.ignoreDependencyInterface(ApplicationEventPublisherAware.class);
/*  635 */     beanFactory.ignoreDependencyInterface(MessageSourceAware.class);
/*  636 */     beanFactory.ignoreDependencyInterface(ApplicationContextAware.class);
/*  637 */     beanFactory.ignoreDependencyInterface(EnvironmentAware.class);
/*      */     
/*      */ 
/*      */ 
/*  641 */     beanFactory.registerResolvableDependency(BeanFactory.class, beanFactory);
/*  642 */     beanFactory.registerResolvableDependency(ResourceLoader.class, this);
/*  643 */     beanFactory.registerResolvableDependency(ApplicationEventPublisher.class, this);
/*  644 */     beanFactory.registerResolvableDependency(ApplicationContext.class, this);
/*      */     
/*      */ 
/*  647 */     if (beanFactory.containsBean("loadTimeWeaver")) {
/*  648 */       beanFactory.addBeanPostProcessor(new LoadTimeWeaverAwareProcessor(beanFactory));
/*      */       
/*  650 */       beanFactory.setTempClassLoader(new ContextTypeMatchClassLoader(beanFactory.getBeanClassLoader()));
/*      */     }
/*      */     
/*      */ 
/*  654 */     if (!beanFactory.containsLocalBean("environment")) {
/*  655 */       beanFactory.registerSingleton("environment", getEnvironment());
/*      */     }
/*  657 */     if (!beanFactory.containsLocalBean("systemProperties")) {
/*  658 */       beanFactory.registerSingleton("systemProperties", getEnvironment().getSystemProperties());
/*      */     }
/*  660 */     if (!beanFactory.containsLocalBean("systemEnvironment")) {
/*  661 */       beanFactory.registerSingleton("systemEnvironment", getEnvironment().getSystemEnvironment());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void invokeBeanFactoryPostProcessors(ConfigurableListableBeanFactory beanFactory)
/*      */   {
/*  681 */     PostProcessorRegistrationDelegate.invokeBeanFactoryPostProcessors(beanFactory, getBeanFactoryPostProcessors());
/*      */     
/*      */ 
/*      */ 
/*  685 */     if ((beanFactory.getTempClassLoader() == null) && (beanFactory.containsBean("loadTimeWeaver"))) {
/*  686 */       beanFactory.addBeanPostProcessor(new LoadTimeWeaverAwareProcessor(beanFactory));
/*  687 */       beanFactory.setTempClassLoader(new ContextTypeMatchClassLoader(beanFactory.getBeanClassLoader()));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void registerBeanPostProcessors(ConfigurableListableBeanFactory beanFactory)
/*      */   {
/*  697 */     PostProcessorRegistrationDelegate.registerBeanPostProcessors(beanFactory, this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void initMessageSource()
/*      */   {
/*  705 */     ConfigurableListableBeanFactory beanFactory = getBeanFactory();
/*  706 */     if (beanFactory.containsLocalBean("messageSource")) {
/*  707 */       this.messageSource = ((MessageSource)beanFactory.getBean("messageSource", MessageSource.class));
/*      */       
/*  709 */       if ((this.parent != null) && ((this.messageSource instanceof HierarchicalMessageSource))) {
/*  710 */         HierarchicalMessageSource hms = (HierarchicalMessageSource)this.messageSource;
/*  711 */         if (hms.getParentMessageSource() == null)
/*      */         {
/*      */ 
/*  714 */           hms.setParentMessageSource(getInternalParentMessageSource());
/*      */         }
/*      */       }
/*  717 */       if (this.logger.isDebugEnabled()) {
/*  718 */         this.logger.debug("Using MessageSource [" + this.messageSource + "]");
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  723 */       DelegatingMessageSource dms = new DelegatingMessageSource();
/*  724 */       dms.setParentMessageSource(getInternalParentMessageSource());
/*  725 */       this.messageSource = dms;
/*  726 */       beanFactory.registerSingleton("messageSource", this.messageSource);
/*  727 */       if (this.logger.isDebugEnabled()) {
/*  728 */         this.logger.debug("Unable to locate MessageSource with name 'messageSource': using default [" + this.messageSource + "]");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void initApplicationEventMulticaster()
/*      */   {
/*  740 */     ConfigurableListableBeanFactory beanFactory = getBeanFactory();
/*  741 */     if (beanFactory.containsLocalBean("applicationEventMulticaster"))
/*      */     {
/*  743 */       this.applicationEventMulticaster = ((ApplicationEventMulticaster)beanFactory.getBean("applicationEventMulticaster", ApplicationEventMulticaster.class));
/*  744 */       if (this.logger.isDebugEnabled()) {
/*  745 */         this.logger.debug("Using ApplicationEventMulticaster [" + this.applicationEventMulticaster + "]");
/*      */       }
/*      */     }
/*      */     else {
/*  749 */       this.applicationEventMulticaster = new SimpleApplicationEventMulticaster(beanFactory);
/*  750 */       beanFactory.registerSingleton("applicationEventMulticaster", this.applicationEventMulticaster);
/*  751 */       if (this.logger.isDebugEnabled()) {
/*  752 */         this.logger.debug("Unable to locate ApplicationEventMulticaster with name 'applicationEventMulticaster': using default [" + this.applicationEventMulticaster + "]");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void initLifecycleProcessor()
/*      */   {
/*  765 */     ConfigurableListableBeanFactory beanFactory = getBeanFactory();
/*  766 */     if (beanFactory.containsLocalBean("lifecycleProcessor"))
/*      */     {
/*  768 */       this.lifecycleProcessor = ((LifecycleProcessor)beanFactory.getBean("lifecycleProcessor", LifecycleProcessor.class));
/*  769 */       if (this.logger.isDebugEnabled()) {
/*  770 */         this.logger.debug("Using LifecycleProcessor [" + this.lifecycleProcessor + "]");
/*      */       }
/*      */     }
/*      */     else {
/*  774 */       DefaultLifecycleProcessor defaultProcessor = new DefaultLifecycleProcessor();
/*  775 */       defaultProcessor.setBeanFactory(beanFactory);
/*  776 */       this.lifecycleProcessor = defaultProcessor;
/*  777 */       beanFactory.registerSingleton("lifecycleProcessor", this.lifecycleProcessor);
/*  778 */       if (this.logger.isDebugEnabled()) {
/*  779 */         this.logger.debug("Unable to locate LifecycleProcessor with name 'lifecycleProcessor': using default [" + this.lifecycleProcessor + "]");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void registerListeners()
/*      */   {
/*  803 */     for (Iterator localIterator1 = getApplicationListeners().iterator(); localIterator1.hasNext();) { listener = (ApplicationListener)localIterator1.next();
/*  804 */       getApplicationEventMulticaster().addApplicationListener(listener);
/*      */     }
/*      */     
/*      */     ApplicationListener<?> listener;
/*      */     
/*  809 */     String[] listenerBeanNames = getBeanNamesForType(ApplicationListener.class, true, false);
/*  810 */     for (String listenerBeanName : listenerBeanNames) {
/*  811 */       getApplicationEventMulticaster().addApplicationListenerBean(listenerBeanName);
/*      */     }
/*      */     
/*      */ 
/*  815 */     Set<ApplicationEvent> earlyEventsToProcess = this.earlyApplicationEvents;
/*  816 */     this.earlyApplicationEvents = null;
/*  817 */     if (earlyEventsToProcess != null) {
/*  818 */       for (ApplicationEvent earlyEvent : earlyEventsToProcess) {
/*  819 */         getApplicationEventMulticaster().multicastEvent(earlyEvent);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void finishBeanFactoryInitialization(ConfigurableListableBeanFactory beanFactory)
/*      */   {
/*  830 */     if ((beanFactory.containsBean("conversionService")) && 
/*  831 */       (beanFactory.isTypeMatch("conversionService", ConversionService.class))) {
/*  832 */       beanFactory.setConversionService(
/*  833 */         (ConversionService)beanFactory.getBean("conversionService", ConversionService.class));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  839 */     if (!beanFactory.hasEmbeddedValueResolver()) {
/*  840 */       beanFactory.addEmbeddedValueResolver(new StringValueResolver()
/*      */       {
/*      */         public String resolveStringValue(String strVal) {
/*  843 */           return AbstractApplicationContext.this.getEnvironment().resolvePlaceholders(strVal);
/*      */         }
/*      */       });
/*      */     }
/*      */     
/*      */ 
/*  849 */     String[] weaverAwareNames = beanFactory.getBeanNamesForType(LoadTimeWeaverAware.class, false, false);
/*  850 */     for (String weaverAwareName : weaverAwareNames) {
/*  851 */       getBean(weaverAwareName);
/*      */     }
/*      */     
/*      */ 
/*  855 */     beanFactory.setTempClassLoader(null);
/*      */     
/*      */ 
/*  858 */     beanFactory.freezeConfiguration();
/*      */     
/*      */ 
/*  861 */     beanFactory.preInstantiateSingletons();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void finishRefresh()
/*      */   {
/*  871 */     initLifecycleProcessor();
/*      */     
/*      */ 
/*  874 */     getLifecycleProcessor().onRefresh();
/*      */     
/*      */ 
/*  877 */     publishEvent(new ContextRefreshedEvent(this));
/*      */     
/*      */ 
/*  880 */     LiveBeansView.registerApplicationContext(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void cancelRefresh(BeansException ex)
/*      */   {
/*  889 */     this.active.set(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void resetCommonCaches()
/*      */   {
/*  901 */     ReflectionUtils.clearCache();
/*  902 */     ResolvableType.clearCache();
/*  903 */     CachedIntrospectionResults.clearClassLoader(getClassLoader());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerShutdownHook()
/*      */   {
/*  917 */     if (this.shutdownHook == null)
/*      */     {
/*  919 */       this.shutdownHook = new Thread()
/*      */       {
/*      */         public void run() {
/*  922 */           synchronized (AbstractApplicationContext.this.startupShutdownMonitor) {
/*  923 */             AbstractApplicationContext.this.doClose();
/*      */           }
/*      */         }
/*  926 */       };
/*  927 */       Runtime.getRuntime().addShutdownHook(this.shutdownHook);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void destroy()
/*      */   {
/*  943 */     close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */   {
/*  955 */     synchronized (this.startupShutdownMonitor) {
/*  956 */       doClose();
/*      */       
/*      */ 
/*  959 */       if (this.shutdownHook != null) {
/*      */         try {
/*  961 */           Runtime.getRuntime().removeShutdownHook(this.shutdownHook);
/*      */         }
/*      */         catch (IllegalStateException localIllegalStateException) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doClose()
/*      */   {
/*  980 */     if ((this.active.get()) && (this.closed.compareAndSet(false, true))) {
/*  981 */       if (this.logger.isInfoEnabled()) {
/*  982 */         this.logger.info("Closing " + this);
/*      */       }
/*      */       
/*  985 */       LiveBeansView.unregisterApplicationContext(this);
/*      */       
/*      */       try
/*      */       {
/*  989 */         publishEvent(new ContextClosedEvent(this));
/*      */       }
/*      */       catch (Throwable ex) {
/*  992 */         this.logger.warn("Exception thrown from ApplicationListener handling ContextClosedEvent", ex);
/*      */       }
/*      */       
/*      */       try
/*      */       {
/*  997 */         getLifecycleProcessor().onClose();
/*      */       }
/*      */       catch (Throwable ex) {
/* 1000 */         this.logger.warn("Exception thrown from LifecycleProcessor on context close", ex);
/*      */       }
/*      */       
/*      */ 
/* 1004 */       destroyBeans();
/*      */       
/*      */ 
/* 1007 */       closeBeanFactory();
/*      */       
/*      */ 
/* 1010 */       onClose();
/*      */       
/* 1012 */       this.active.set(false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void destroyBeans()
/*      */   {
/* 1028 */     getBeanFactory().destroySingletons();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isActive()
/*      */   {
/* 1045 */     return this.active.get();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void assertBeanFactoryActive()
/*      */   {
/* 1058 */     if (!this.active.get()) {
/* 1059 */       if (this.closed.get()) {
/* 1060 */         throw new IllegalStateException(getDisplayName() + " has been closed already");
/*      */       }
/*      */       
/* 1063 */       throw new IllegalStateException(getDisplayName() + " has not been refreshed yet");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getBean(String name)
/*      */     throws BeansException
/*      */   {
/* 1075 */     assertBeanFactoryActive();
/* 1076 */     return getBeanFactory().getBean(name);
/*      */   }
/*      */   
/*      */   public <T> T getBean(String name, Class<T> requiredType) throws BeansException
/*      */   {
/* 1081 */     assertBeanFactoryActive();
/* 1082 */     return (T)getBeanFactory().getBean(name, requiredType);
/*      */   }
/*      */   
/*      */   public <T> T getBean(Class<T> requiredType) throws BeansException
/*      */   {
/* 1087 */     assertBeanFactoryActive();
/* 1088 */     return (T)getBeanFactory().getBean(requiredType);
/*      */   }
/*      */   
/*      */   public Object getBean(String name, Object... args) throws BeansException
/*      */   {
/* 1093 */     assertBeanFactoryActive();
/* 1094 */     return getBeanFactory().getBean(name, args);
/*      */   }
/*      */   
/*      */   public <T> T getBean(Class<T> requiredType, Object... args) throws BeansException
/*      */   {
/* 1099 */     assertBeanFactoryActive();
/* 1100 */     return (T)getBeanFactory().getBean(requiredType, args);
/*      */   }
/*      */   
/*      */   public boolean containsBean(String name)
/*      */   {
/* 1105 */     return getBeanFactory().containsBean(name);
/*      */   }
/*      */   
/*      */   public boolean isSingleton(String name) throws NoSuchBeanDefinitionException
/*      */   {
/* 1110 */     assertBeanFactoryActive();
/* 1111 */     return getBeanFactory().isSingleton(name);
/*      */   }
/*      */   
/*      */   public boolean isPrototype(String name) throws NoSuchBeanDefinitionException
/*      */   {
/* 1116 */     assertBeanFactoryActive();
/* 1117 */     return getBeanFactory().isPrototype(name);
/*      */   }
/*      */   
/*      */   public boolean isTypeMatch(String name, ResolvableType typeToMatch) throws NoSuchBeanDefinitionException
/*      */   {
/* 1122 */     assertBeanFactoryActive();
/* 1123 */     return getBeanFactory().isTypeMatch(name, typeToMatch);
/*      */   }
/*      */   
/*      */   public boolean isTypeMatch(String name, Class<?> typeToMatch) throws NoSuchBeanDefinitionException
/*      */   {
/* 1128 */     assertBeanFactoryActive();
/* 1129 */     return getBeanFactory().isTypeMatch(name, typeToMatch);
/*      */   }
/*      */   
/*      */   public Class<?> getType(String name) throws NoSuchBeanDefinitionException
/*      */   {
/* 1134 */     assertBeanFactoryActive();
/* 1135 */     return getBeanFactory().getType(name);
/*      */   }
/*      */   
/*      */   public String[] getAliases(String name)
/*      */   {
/* 1140 */     return getBeanFactory().getAliases(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsBeanDefinition(String beanName)
/*      */   {
/* 1150 */     return getBeanFactory().containsBeanDefinition(beanName);
/*      */   }
/*      */   
/*      */   public int getBeanDefinitionCount()
/*      */   {
/* 1155 */     return getBeanFactory().getBeanDefinitionCount();
/*      */   }
/*      */   
/*      */   public String[] getBeanDefinitionNames()
/*      */   {
/* 1160 */     return getBeanFactory().getBeanDefinitionNames();
/*      */   }
/*      */   
/*      */   public String[] getBeanNamesForType(ResolvableType type)
/*      */   {
/* 1165 */     assertBeanFactoryActive();
/* 1166 */     return getBeanFactory().getBeanNamesForType(type);
/*      */   }
/*      */   
/*      */   public String[] getBeanNamesForType(Class<?> type)
/*      */   {
/* 1171 */     assertBeanFactoryActive();
/* 1172 */     return getBeanFactory().getBeanNamesForType(type);
/*      */   }
/*      */   
/*      */   public String[] getBeanNamesForType(Class<?> type, boolean includeNonSingletons, boolean allowEagerInit)
/*      */   {
/* 1177 */     assertBeanFactoryActive();
/* 1178 */     return getBeanFactory().getBeanNamesForType(type, includeNonSingletons, allowEagerInit);
/*      */   }
/*      */   
/*      */   public <T> Map<String, T> getBeansOfType(Class<T> type) throws BeansException
/*      */   {
/* 1183 */     assertBeanFactoryActive();
/* 1184 */     return getBeanFactory().getBeansOfType(type);
/*      */   }
/*      */   
/*      */ 
/*      */   public <T> Map<String, T> getBeansOfType(Class<T> type, boolean includeNonSingletons, boolean allowEagerInit)
/*      */     throws BeansException
/*      */   {
/* 1191 */     assertBeanFactoryActive();
/* 1192 */     return getBeanFactory().getBeansOfType(type, includeNonSingletons, allowEagerInit);
/*      */   }
/*      */   
/*      */   public String[] getBeanNamesForAnnotation(Class<? extends Annotation> annotationType)
/*      */   {
/* 1197 */     assertBeanFactoryActive();
/* 1198 */     return getBeanFactory().getBeanNamesForAnnotation(annotationType);
/*      */   }
/*      */   
/*      */ 
/*      */   public Map<String, Object> getBeansWithAnnotation(Class<? extends Annotation> annotationType)
/*      */     throws BeansException
/*      */   {
/* 1205 */     assertBeanFactoryActive();
/* 1206 */     return getBeanFactory().getBeansWithAnnotation(annotationType);
/*      */   }
/*      */   
/*      */ 
/*      */   public <A extends Annotation> A findAnnotationOnBean(String beanName, Class<A> annotationType)
/*      */     throws NoSuchBeanDefinitionException
/*      */   {
/* 1213 */     assertBeanFactoryActive();
/* 1214 */     return getBeanFactory().findAnnotationOnBean(beanName, annotationType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BeanFactory getParentBeanFactory()
/*      */   {
/* 1224 */     return getParent();
/*      */   }
/*      */   
/*      */   public boolean containsLocalBean(String name)
/*      */   {
/* 1229 */     return getBeanFactory().containsLocalBean(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected BeanFactory getInternalParentBeanFactory()
/*      */   {
/* 1239 */     return (getParent() instanceof ConfigurableApplicationContext) ? ((ConfigurableApplicationContext)getParent()).getBeanFactory() : getParent();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getMessage(String code, Object[] args, String defaultMessage, Locale locale)
/*      */   {
/* 1249 */     return getMessageSource().getMessage(code, args, defaultMessage, locale);
/*      */   }
/*      */   
/*      */   public String getMessage(String code, Object[] args, Locale locale) throws NoSuchMessageException
/*      */   {
/* 1254 */     return getMessageSource().getMessage(code, args, locale);
/*      */   }
/*      */   
/*      */   public String getMessage(MessageSourceResolvable resolvable, Locale locale) throws NoSuchMessageException
/*      */   {
/* 1259 */     return getMessageSource().getMessage(resolvable, locale);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private MessageSource getMessageSource()
/*      */     throws IllegalStateException
/*      */   {
/* 1268 */     if (this.messageSource == null) {
/* 1269 */       throw new IllegalStateException("MessageSource not initialized - call 'refresh' before accessing messages via the context: " + this);
/*      */     }
/*      */     
/* 1272 */     return this.messageSource;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected MessageSource getInternalParentMessageSource()
/*      */   {
/* 1281 */     return (getParent() instanceof AbstractApplicationContext) ? ((AbstractApplicationContext)getParent()).messageSource : getParent();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Resource[] getResources(String locationPattern)
/*      */     throws IOException
/*      */   {
/* 1291 */     return this.resourcePatternResolver.getResources(locationPattern);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void start()
/*      */   {
/* 1301 */     getLifecycleProcessor().start();
/* 1302 */     publishEvent(new ContextStartedEvent(this));
/*      */   }
/*      */   
/*      */   public void stop()
/*      */   {
/* 1307 */     getLifecycleProcessor().stop();
/* 1308 */     publishEvent(new ContextStoppedEvent(this));
/*      */   }
/*      */   
/*      */   public boolean isRunning()
/*      */   {
/* 1313 */     return (this.lifecycleProcessor != null) && (this.lifecycleProcessor.isRunning());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1362 */     StringBuilder sb = new StringBuilder(getDisplayName());
/* 1363 */     sb.append(": startup date [").append(new Date(getStartupDate()));
/* 1364 */     sb.append("]; ");
/* 1365 */     ApplicationContext parent = getParent();
/* 1366 */     if (parent == null) {
/* 1367 */       sb.append("root of context hierarchy");
/*      */     }
/*      */     else {
/* 1370 */       sb.append("parent: ").append(parent.getDisplayName());
/*      */     }
/* 1372 */     return sb.toString();
/*      */   }
/*      */   
/*      */   protected void initPropertySources() {}
/*      */   
/*      */   protected void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) {}
/*      */   
/*      */   protected void onRefresh()
/*      */     throws BeansException
/*      */   {}
/*      */   
/*      */   protected void onClose() {}
/*      */   
/*      */   protected abstract void refreshBeanFactory()
/*      */     throws BeansException, IllegalStateException;
/*      */   
/*      */   protected abstract void closeBeanFactory();
/*      */   
/*      */   public abstract ConfigurableListableBeanFactory getBeanFactory()
/*      */     throws IllegalStateException;
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\context\support\AbstractApplicationContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */