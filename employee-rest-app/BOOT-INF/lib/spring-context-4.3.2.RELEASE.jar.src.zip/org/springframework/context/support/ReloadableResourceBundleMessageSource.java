/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.DefaultPropertiesPersister;
/*     */ import org.springframework.util.PropertiesPersister;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReloadableResourceBundleMessageSource
/*     */   extends AbstractResourceBasedMessageSource
/*     */   implements ResourceLoaderAware
/*     */ {
/*     */   private static final String PROPERTIES_SUFFIX = ".properties";
/*     */   private static final String XML_SUFFIX = ".xml";
/*     */   private Properties fileEncodings;
/*  96 */   private boolean concurrentRefresh = true;
/*     */   
/*  98 */   private PropertiesPersister propertiesPersister = new DefaultPropertiesPersister();
/*     */   
/* 100 */   private ResourceLoader resourceLoader = new DefaultResourceLoader();
/*     */   
/*     */ 
/* 103 */   private final ConcurrentMap<String, Map<Locale, List<String>>> cachedFilenames = new ConcurrentHashMap();
/*     */   
/*     */ 
/*     */ 
/* 107 */   private final ConcurrentMap<String, PropertiesHolder> cachedProperties = new ConcurrentHashMap();
/*     */   
/*     */ 
/*     */ 
/* 111 */   private final ConcurrentMap<Locale, PropertiesHolder> cachedMergedProperties = new ConcurrentHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFileEncodings(Properties fileEncodings)
/*     */   {
/* 126 */     this.fileEncodings = fileEncodings;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConcurrentRefresh(boolean concurrentRefresh)
/*     */   {
/* 141 */     this.concurrentRefresh = concurrentRefresh;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPropertiesPersister(PropertiesPersister propertiesPersister)
/*     */   {
/* 150 */     this.propertiesPersister = (propertiesPersister != null ? propertiesPersister : new DefaultPropertiesPersister());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResourceLoader(ResourceLoader resourceLoader)
/*     */   {
/* 165 */     this.resourceLoader = (resourceLoader != null ? resourceLoader : new DefaultResourceLoader());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String resolveCodeWithoutArguments(String code, Locale locale)
/*     */   {
/*     */     PropertiesHolder propHolder;
/*     */     
/*     */ 
/* 175 */     if (getCacheMillis() < 0L) {
/* 176 */       propHolder = getMergedProperties(locale);
/* 177 */       String result = propHolder.getProperty(code);
/* 178 */       if (result != null) {
/* 179 */         return result;
/*     */       }
/*     */     }
/*     */     else {
/* 183 */       for (String basename : getBasenameSet()) {
/* 184 */         List<String> filenames = calculateAllFilenames(basename, locale);
/* 185 */         for (String filename : filenames) {
/* 186 */           PropertiesHolder propHolder = getProperties(filename);
/* 187 */           String result = propHolder.getProperty(code);
/* 188 */           if (result != null) {
/* 189 */             return result;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 194 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected MessageFormat resolveCode(String code, Locale locale)
/*     */   {
/*     */     PropertiesHolder propHolder;
/*     */     
/* 203 */     if (getCacheMillis() < 0L) {
/* 204 */       propHolder = getMergedProperties(locale);
/* 205 */       MessageFormat result = propHolder.getMessageFormat(code, locale);
/* 206 */       if (result != null) {
/* 207 */         return result;
/*     */       }
/*     */     }
/*     */     else {
/* 211 */       for (String basename : getBasenameSet()) {
/* 212 */         List<String> filenames = calculateAllFilenames(basename, locale);
/* 213 */         for (String filename : filenames) {
/* 214 */           PropertiesHolder propHolder = getProperties(filename);
/* 215 */           MessageFormat result = propHolder.getMessageFormat(code, locale);
/* 216 */           if (result != null) {
/* 217 */             return result;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 222 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PropertiesHolder getMergedProperties(Locale locale)
/*     */   {
/* 235 */     PropertiesHolder mergedHolder = (PropertiesHolder)this.cachedMergedProperties.get(locale);
/* 236 */     if (mergedHolder != null) {
/* 237 */       return mergedHolder;
/*     */     }
/* 239 */     Properties mergedProps = newProperties();
/* 240 */     mergedHolder = new PropertiesHolder(mergedProps, -1L);
/* 241 */     String[] basenames = StringUtils.toStringArray(getBasenameSet());
/* 242 */     for (int i = basenames.length - 1; i >= 0; i--) {
/* 243 */       List<String> filenames = calculateAllFilenames(basenames[i], locale);
/* 244 */       for (int j = filenames.size() - 1; j >= 0; j--) {
/* 245 */         String filename = (String)filenames.get(j);
/* 246 */         PropertiesHolder propHolder = getProperties(filename);
/* 247 */         if (propHolder.getProperties() != null) {
/* 248 */           mergedProps.putAll(propHolder.getProperties());
/*     */         }
/*     */       }
/*     */     }
/* 252 */     PropertiesHolder existing = (PropertiesHolder)this.cachedMergedProperties.putIfAbsent(locale, mergedHolder);
/* 253 */     if (existing != null) {
/* 254 */       mergedHolder = existing;
/*     */     }
/* 256 */     return mergedHolder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<String> calculateAllFilenames(String basename, Locale locale)
/*     */   {
/* 270 */     Map<Locale, List<String>> localeMap = (Map)this.cachedFilenames.get(basename);
/* 271 */     if (localeMap != null) {
/* 272 */       List<String> filenames = (List)localeMap.get(locale);
/* 273 */       if (filenames != null) {
/* 274 */         return filenames;
/*     */       }
/*     */     }
/* 277 */     List<String> filenames = new ArrayList(7);
/* 278 */     filenames.addAll(calculateFilenamesForLocale(basename, locale));
/* 279 */     if ((isFallbackToSystemLocale()) && (!locale.equals(Locale.getDefault()))) {
/* 280 */       List<String> fallbackFilenames = calculateFilenamesForLocale(basename, Locale.getDefault());
/* 281 */       for (String fallbackFilename : fallbackFilenames) {
/* 282 */         if (!filenames.contains(fallbackFilename))
/*     */         {
/* 284 */           filenames.add(fallbackFilename);
/*     */         }
/*     */       }
/*     */     }
/* 288 */     filenames.add(basename);
/* 289 */     if (localeMap == null) {
/* 290 */       localeMap = new ConcurrentHashMap();
/* 291 */       Map<Locale, List<String>> existing = (Map)this.cachedFilenames.putIfAbsent(basename, localeMap);
/* 292 */       if (existing != null) {
/* 293 */         localeMap = existing;
/*     */       }
/*     */     }
/* 296 */     localeMap.put(locale, filenames);
/* 297 */     return filenames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<String> calculateFilenamesForLocale(String basename, Locale locale)
/*     */   {
/* 311 */     List<String> result = new ArrayList(3);
/* 312 */     String language = locale.getLanguage();
/* 313 */     String country = locale.getCountry();
/* 314 */     String variant = locale.getVariant();
/* 315 */     StringBuilder temp = new StringBuilder(basename);
/*     */     
/* 317 */     temp.append('_');
/* 318 */     if (language.length() > 0) {
/* 319 */       temp.append(language);
/* 320 */       result.add(0, temp.toString());
/*     */     }
/*     */     
/* 323 */     temp.append('_');
/* 324 */     if (country.length() > 0) {
/* 325 */       temp.append(country);
/* 326 */       result.add(0, temp.toString());
/*     */     }
/*     */     
/* 329 */     if ((variant.length() > 0) && ((language.length() > 0) || (country.length() > 0))) {
/* 330 */       temp.append('_').append(variant);
/* 331 */       result.add(0, temp.toString());
/*     */     }
/*     */     
/* 334 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PropertiesHolder getProperties(String filename)
/*     */   {
/* 345 */     PropertiesHolder propHolder = (PropertiesHolder)this.cachedProperties.get(filename);
/* 346 */     long originalTimestamp = -2L;
/*     */     
/* 348 */     if (propHolder != null) {
/* 349 */       originalTimestamp = propHolder.getRefreshTimestamp();
/* 350 */       if ((originalTimestamp == -1L) || (originalTimestamp > System.currentTimeMillis() - getCacheMillis()))
/*     */       {
/* 352 */         return propHolder;
/*     */       }
/*     */     }
/*     */     else {
/* 356 */       propHolder = new PropertiesHolder();
/* 357 */       PropertiesHolder existingHolder = (PropertiesHolder)this.cachedProperties.putIfAbsent(filename, propHolder);
/* 358 */       if (existingHolder != null) {
/* 359 */         propHolder = existingHolder;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 364 */     if ((this.concurrentRefresh) && (propHolder.getRefreshTimestamp() >= 0L))
/*     */     {
/* 366 */       if (!propHolder.refreshLock.tryLock())
/*     */       {
/*     */ 
/* 369 */         return propHolder;
/*     */       }
/*     */     }
/*     */     else {
/* 373 */       propHolder.refreshLock.lock();
/*     */     }
/*     */     try {
/* 376 */       PropertiesHolder existingHolder = (PropertiesHolder)this.cachedProperties.get(filename);
/* 377 */       PropertiesHolder localPropertiesHolder1; if ((existingHolder != null) && (existingHolder.getRefreshTimestamp() > originalTimestamp)) {
/* 378 */         return existingHolder;
/*     */       }
/* 380 */       return refreshProperties(filename, propHolder);
/*     */     }
/*     */     finally {
/* 383 */       propHolder.refreshLock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PropertiesHolder refreshProperties(String filename, PropertiesHolder propHolder)
/*     */   {
/* 395 */     long refreshTimestamp = getCacheMillis() < 0L ? -1L : System.currentTimeMillis();
/*     */     
/* 397 */     Resource resource = this.resourceLoader.getResource(filename + ".properties");
/* 398 */     if (!resource.exists()) {
/* 399 */       resource = this.resourceLoader.getResource(filename + ".xml");
/*     */     }
/*     */     
/* 402 */     if (resource.exists()) {
/* 403 */       long fileTimestamp = -1L;
/* 404 */       if (getCacheMillis() >= 0L) {
/*     */         try
/*     */         {
/* 407 */           fileTimestamp = resource.lastModified();
/* 408 */           if ((propHolder != null) && (propHolder.getFileTimestamp() == fileTimestamp)) {
/* 409 */             if (this.logger.isDebugEnabled()) {
/* 410 */               this.logger.debug("Re-caching properties for filename [" + filename + "] - file hasn't been modified");
/*     */             }
/* 412 */             propHolder.setRefreshTimestamp(refreshTimestamp);
/* 413 */             return propHolder;
/*     */           }
/*     */         }
/*     */         catch (IOException ex)
/*     */         {
/* 418 */           if (this.logger.isDebugEnabled()) {
/* 419 */             this.logger.debug(resource + " could not be resolved in the file system - assuming that it hasn't changed", ex);
/*     */           }
/* 421 */           fileTimestamp = -1L;
/*     */         }
/*     */       }
/*     */       try {
/* 425 */         Properties props = loadProperties(resource, filename);
/* 426 */         propHolder = new PropertiesHolder(props, fileTimestamp);
/*     */       }
/*     */       catch (IOException ex) {
/* 429 */         if (this.logger.isWarnEnabled()) {
/* 430 */           this.logger.warn("Could not parse properties file [" + resource.getFilename() + "]", ex);
/*     */         }
/*     */         
/* 433 */         propHolder = new PropertiesHolder();
/*     */       }
/*     */       
/*     */     }
/*     */     else
/*     */     {
/* 439 */       if (this.logger.isDebugEnabled()) {
/* 440 */         this.logger.debug("No properties file found for [" + filename + "] - neither plain properties nor XML");
/*     */       }
/*     */       
/* 443 */       propHolder = new PropertiesHolder();
/*     */     }
/*     */     
/* 446 */     propHolder.setRefreshTimestamp(refreshTimestamp);
/* 447 */     this.cachedProperties.put(filename, propHolder);
/* 448 */     return propHolder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Properties loadProperties(Resource resource, String filename)
/*     */     throws IOException
/*     */   {
/* 459 */     InputStream is = resource.getInputStream();
/* 460 */     Properties props = newProperties();
/*     */     try { String encoding;
/* 462 */       if (resource.getFilename().endsWith(".xml")) {
/* 463 */         if (this.logger.isDebugEnabled()) {
/* 464 */           this.logger.debug("Loading properties [" + resource.getFilename() + "]");
/*     */         }
/* 466 */         this.propertiesPersister.loadFromXml(props, is);
/*     */       }
/*     */       else {
/* 469 */         encoding = null;
/* 470 */         if (this.fileEncodings != null) {
/* 471 */           encoding = this.fileEncodings.getProperty(filename);
/*     */         }
/* 473 */         if (encoding == null) {
/* 474 */           encoding = getDefaultEncoding();
/*     */         }
/* 476 */         if (encoding != null) {
/* 477 */           if (this.logger.isDebugEnabled()) {
/* 478 */             this.logger.debug("Loading properties [" + resource.getFilename() + "] with encoding '" + encoding + "'");
/*     */           }
/* 480 */           this.propertiesPersister.load(props, new InputStreamReader(is, encoding));
/*     */         }
/*     */         else {
/* 483 */           if (this.logger.isDebugEnabled()) {
/* 484 */             this.logger.debug("Loading properties [" + resource.getFilename() + "]");
/*     */           }
/* 486 */           this.propertiesPersister.load(props, is);
/*     */         }
/*     */       }
/* 489 */       return props;
/*     */     }
/*     */     finally {
/* 492 */       is.close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Properties newProperties()
/*     */   {
/* 506 */     return new Properties();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearCache()
/*     */   {
/* 515 */     this.logger.debug("Clearing entire resource bundle cache");
/* 516 */     this.cachedProperties.clear();
/* 517 */     this.cachedMergedProperties.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearCacheIncludingAncestors()
/*     */   {
/* 525 */     clearCache();
/* 526 */     if ((getParentMessageSource() instanceof ReloadableResourceBundleMessageSource)) {
/* 527 */       ((ReloadableResourceBundleMessageSource)getParentMessageSource()).clearCacheIncludingAncestors();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 534 */     return getClass().getName() + ": basenames=" + getBasenameSet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected class PropertiesHolder
/*     */   {
/*     */     private final Properties properties;
/*     */     
/*     */ 
/*     */ 
/*     */     private final long fileTimestamp;
/*     */     
/*     */ 
/*     */ 
/* 550 */     private volatile long refreshTimestamp = -2L;
/*     */     
/* 552 */     private final ReentrantLock refreshLock = new ReentrantLock();
/*     */     
/*     */ 
/* 555 */     private final ConcurrentMap<String, Map<Locale, MessageFormat>> cachedMessageFormats = new ConcurrentHashMap();
/*     */     
/*     */     public PropertiesHolder()
/*     */     {
/* 559 */       this.properties = null;
/* 560 */       this.fileTimestamp = -1L;
/*     */     }
/*     */     
/*     */     public PropertiesHolder(Properties properties, long fileTimestamp) {
/* 564 */       this.properties = properties;
/* 565 */       this.fileTimestamp = fileTimestamp;
/*     */     }
/*     */     
/*     */     public Properties getProperties() {
/* 569 */       return this.properties;
/*     */     }
/*     */     
/*     */     public long getFileTimestamp() {
/* 573 */       return this.fileTimestamp;
/*     */     }
/*     */     
/*     */     public void setRefreshTimestamp(long refreshTimestamp) {
/* 577 */       this.refreshTimestamp = refreshTimestamp;
/*     */     }
/*     */     
/*     */     public long getRefreshTimestamp() {
/* 581 */       return this.refreshTimestamp;
/*     */     }
/*     */     
/*     */     public String getProperty(String code) {
/* 585 */       if (this.properties == null) {
/* 586 */         return null;
/*     */       }
/* 588 */       return this.properties.getProperty(code);
/*     */     }
/*     */     
/*     */     public MessageFormat getMessageFormat(String code, Locale locale) {
/* 592 */       if (this.properties == null) {
/* 593 */         return null;
/*     */       }
/* 595 */       Map<Locale, MessageFormat> localeMap = (Map)this.cachedMessageFormats.get(code);
/* 596 */       if (localeMap != null) {
/* 597 */         MessageFormat result = (MessageFormat)localeMap.get(locale);
/* 598 */         if (result != null) {
/* 599 */           return result;
/*     */         }
/*     */       }
/* 602 */       String msg = this.properties.getProperty(code);
/* 603 */       if (msg != null) {
/* 604 */         if (localeMap == null) {
/* 605 */           localeMap = new ConcurrentHashMap();
/* 606 */           Map<Locale, MessageFormat> existing = (Map)this.cachedMessageFormats.putIfAbsent(code, localeMap);
/* 607 */           if (existing != null) {
/* 608 */             localeMap = existing;
/*     */           }
/*     */         }
/* 611 */         MessageFormat result = ReloadableResourceBundleMessageSource.this.createMessageFormat(msg, locale);
/* 612 */         localeMap.put(locale, result);
/* 613 */         return result;
/*     */       }
/* 615 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\context\support\ReloadableResourceBundleMessageSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */