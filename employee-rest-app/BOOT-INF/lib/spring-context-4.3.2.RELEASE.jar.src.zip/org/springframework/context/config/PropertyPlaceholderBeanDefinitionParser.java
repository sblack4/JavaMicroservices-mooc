/*    */ package org.springframework.context.config;
/*    */ 
/*    */ import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PropertyPlaceholderBeanDefinitionParser
/*    */   extends AbstractPropertyLoadingBeanDefinitionParser
/*    */ {
/*    */   private static final String SYSTEM_PROPERTIES_MODE_ATTRIBUTE = "system-properties-mode";
/*    */   private static final String SYSTEM_PROPERTIES_MODE_DEFAULT = "ENVIRONMENT";
/*    */   
/*    */   protected Class<?> getBeanClass(Element element)
/*    */   {
/* 47 */     if ("ENVIRONMENT".equals(element.getAttribute("system-properties-mode"))) {
/* 48 */       return PropertySourcesPlaceholderConfigurer.class;
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 53 */     return PropertyPlaceholderConfigurer.class;
/*    */   }
/*    */   
/*    */   protected void doParse(Element element, BeanDefinitionBuilder builder)
/*    */   {
/* 58 */     super.doParse(element, builder);
/*    */     
/* 60 */     builder.addPropertyValue("ignoreUnresolvablePlaceholders", 
/* 61 */       Boolean.valueOf(element.getAttribute("ignore-unresolvable")));
/*    */     
/* 63 */     String systemPropertiesModeName = element.getAttribute("system-properties-mode");
/* 64 */     if ((StringUtils.hasLength(systemPropertiesModeName)) && 
/* 65 */       (!systemPropertiesModeName.equals("ENVIRONMENT"))) {
/* 66 */       builder.addPropertyValue("systemPropertiesModeName", "SYSTEM_PROPERTIES_MODE_" + systemPropertiesModeName);
/*    */     }
/*    */     
/* 69 */     if (element.hasAttribute("value-separator")) {
/* 70 */       builder.addPropertyValue("valueSeparator", element.getAttribute("value-separator"));
/*    */     }
/* 72 */     if (element.hasAttribute("trim-values")) {
/* 73 */       builder.addPropertyValue("trimValues", element.getAttribute("trim-values"));
/*    */     }
/* 75 */     if (element.hasAttribute("null-value")) {
/* 76 */       builder.addPropertyValue("nullValue", element.getAttribute("null-value"));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\context\config\PropertyPlaceholderBeanDefinitionParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */