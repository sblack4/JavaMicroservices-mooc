/*    */ package org.springframework.context.expression;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.core.ParameterNameDiscoverer;
/*    */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodBasedEvaluationContext
/*    */   extends StandardEvaluationContext
/*    */ {
/*    */   private final Method method;
/*    */   private final Object[] args;
/*    */   private final ParameterNameDiscoverer paramDiscoverer;
/* 48 */   private boolean paramLoaded = false;
/*    */   
/*    */ 
/*    */ 
/*    */   public MethodBasedEvaluationContext(Object rootObject, Method method, Object[] args, ParameterNameDiscoverer paramDiscoverer)
/*    */   {
/* 54 */     super(rootObject);
/* 55 */     this.method = method;
/* 56 */     this.args = args;
/* 57 */     this.paramDiscoverer = paramDiscoverer;
/*    */   }
/*    */   
/*    */ 
/*    */   public Object lookupVariable(String name)
/*    */   {
/* 63 */     Object variable = super.lookupVariable(name);
/* 64 */     if (variable != null) {
/* 65 */       return variable;
/*    */     }
/* 67 */     if (!this.paramLoaded) {
/* 68 */       lazyLoadArguments();
/* 69 */       this.paramLoaded = true;
/* 70 */       variable = super.lookupVariable(name);
/*    */     }
/* 72 */     return variable;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void lazyLoadArguments()
/*    */   {
/* 80 */     if (ObjectUtils.isEmpty(this.args)) {
/* 81 */       return;
/*    */     }
/*    */     
/*    */ 
/* 85 */     for (int i = 0; i < this.args.length; i++) {
/* 86 */       setVariable("a" + i, this.args[i]);
/* 87 */       setVariable("p" + i, this.args[i]);
/*    */     }
/*    */     
/* 90 */     String[] parameterNames = this.paramDiscoverer.getParameterNames(this.method);
/*    */     
/* 92 */     if (parameterNames != null) {
/* 93 */       for (int i = 0; i < this.args.length; i++) {
/* 94 */         setVariable(parameterNames[i], this.args[i]);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\context\expression\MethodBasedEvaluationContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */