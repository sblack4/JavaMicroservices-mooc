/*     */ package org.springframework.context.event;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.framework.autoproxy.AutoProxyUtils;
/*     */ import org.springframework.aop.scope.ScopedObject;
/*     */ import org.springframework.aop.scope.ScopedProxyUtils;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanInitializationException;
/*     */ import org.springframework.beans.factory.SmartInitializingSingleton;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.MethodIntrospector;
/*     */ import org.springframework.core.MethodIntrospector.MetadataLookup;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EventListenerMethodProcessor
/*     */   implements SmartInitializingSingleton, ApplicationContextAware
/*     */ {
/*     */   protected final Log logger;
/*     */   private ConfigurableApplicationContext applicationContext;
/*     */   private final EventExpressionEvaluator evaluator;
/*     */   
/*     */   public EventListenerMethodProcessor()
/*     */   {
/*  57 */     this.logger = LogFactory.getLog(getClass());
/*     */     
/*     */ 
/*     */ 
/*  61 */     this.evaluator = new EventExpressionEvaluator();
/*     */   }
/*     */   
/*  64 */   private final Set<Class<?>> nonAnnotatedClasses = Collections.newSetFromMap(new ConcurrentHashMap(64));
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext)
/*     */     throws BeansException
/*     */   {
/*  69 */     Assert.isTrue(applicationContext instanceof ConfigurableApplicationContext, "ApplicationContext does not implement ConfigurableApplicationContext");
/*     */     
/*  71 */     this.applicationContext = ((ConfigurableApplicationContext)applicationContext);
/*     */   }
/*     */   
/*     */   public void afterSingletonsInstantiated()
/*     */   {
/*  76 */     List<EventListenerFactory> factories = getEventListenerFactories();
/*  77 */     String[] beanNames = this.applicationContext.getBeanNamesForType(Object.class);
/*  78 */     for (String beanName : beanNames) {
/*  79 */       if (!ScopedProxyUtils.isScopedTarget(beanName)) {
/*  80 */         Class<?> type = null;
/*     */         try {
/*  82 */           type = AutoProxyUtils.determineTargetClass(this.applicationContext.getBeanFactory(), beanName);
/*     */         }
/*     */         catch (Throwable ex)
/*     */         {
/*  86 */           if (this.logger.isDebugEnabled()) {
/*  87 */             this.logger.debug("Could not resolve target class for bean with name '" + beanName + "'", ex);
/*     */           }
/*     */         }
/*  90 */         if (type != null) {
/*  91 */           if (ScopedObject.class.isAssignableFrom(type)) {
/*     */             try {
/*  93 */               type = AutoProxyUtils.determineTargetClass(this.applicationContext.getBeanFactory(), 
/*  94 */                 ScopedProxyUtils.getTargetBeanName(beanName));
/*     */             }
/*     */             catch (Throwable ex)
/*     */             {
/*  98 */               if (this.logger.isDebugEnabled()) {
/*  99 */                 this.logger.debug("Could not resolve target bean for scoped proxy '" + beanName + "'", ex);
/*     */               }
/*     */             }
/*     */           }
/*     */           try {
/* 104 */             processBean(factories, beanName, type);
/*     */           }
/*     */           catch (Throwable ex) {
/* 107 */             throw new BeanInitializationException("Failed to process @EventListener annotation on bean with name '" + beanName + "'", ex);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<EventListenerFactory> getEventListenerFactories()
/*     */   {
/* 121 */     Map<String, EventListenerFactory> beans = this.applicationContext.getBeansOfType(EventListenerFactory.class);
/* 122 */     List<EventListenerFactory> allFactories = new ArrayList(beans.values());
/* 123 */     AnnotationAwareOrderComparator.sort(allFactories);
/* 124 */     return allFactories;
/*     */   }
/*     */   
/*     */   protected void processBean(List<EventListenerFactory> factories, String beanName, Class<?> targetType) {
/* 128 */     if (!this.nonAnnotatedClasses.contains(targetType)) {
/* 129 */       Map<Method, EventListener> annotatedMethods = null;
/*     */       try {
/* 131 */         annotatedMethods = MethodIntrospector.selectMethods(targetType, new MethodIntrospector.MetadataLookup()
/*     */         {
/*     */           public EventListener inspect(Method method)
/*     */           {
/* 135 */             return (EventListener)AnnotatedElementUtils.findMergedAnnotation(method, EventListener.class);
/*     */           }
/*     */         });
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 141 */         if (this.logger.isDebugEnabled()) {
/* 142 */           this.logger.debug("Could not resolve methods for bean with name '" + beanName + "'", ex);
/*     */         }
/*     */       }
/* 145 */       if (CollectionUtils.isEmpty(annotatedMethods)) {
/* 146 */         this.nonAnnotatedClasses.add(targetType);
/* 147 */         if (this.logger.isTraceEnabled()) {
/* 148 */           this.logger.trace("No @EventListener annotations found on bean class: " + targetType);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 153 */         for (ex = annotatedMethods.keySet().iterator(); ex.hasNext();) { method = (Method)ex.next();
/* 154 */           for (EventListenerFactory factory : factories)
/* 155 */             if (factory.supportsMethod(method)) {
/* 156 */               Method methodToUse = AopUtils.selectInvocableMethod(method, this.applicationContext
/* 157 */                 .getType(beanName));
/*     */               
/* 159 */               ApplicationListener<?> applicationListener = factory.createApplicationListener(beanName, targetType, methodToUse);
/* 160 */               if ((applicationListener instanceof ApplicationListenerMethodAdapter))
/*     */               {
/* 162 */                 ((ApplicationListenerMethodAdapter)applicationListener).init(this.applicationContext, this.evaluator);
/*     */               }
/* 164 */               this.applicationContext.addApplicationListener(applicationListener);
/* 165 */               break;
/*     */             }
/*     */         }
/*     */         Method method;
/* 169 */         if (this.logger.isDebugEnabled()) {
/* 170 */           this.logger.debug(annotatedMethods.size() + " @EventListener methods processed on bean '" + beanName + "': " + annotatedMethods);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\context\event\EventListenerMethodProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */