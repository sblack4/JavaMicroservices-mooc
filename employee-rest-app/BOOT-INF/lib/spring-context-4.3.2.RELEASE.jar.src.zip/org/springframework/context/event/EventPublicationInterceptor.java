/*     */ package org.springframework.context.event;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationEventPublisher;
/*     */ import org.springframework.context.ApplicationEventPublisherAware;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EventPublicationInterceptor
/*     */   implements MethodInterceptor, ApplicationEventPublisherAware, InitializingBean
/*     */ {
/*     */   private Constructor<?> applicationEventClassConstructor;
/*     */   private ApplicationEventPublisher applicationEventPublisher;
/*     */   
/*     */   public void setApplicationEventClass(Class<?> applicationEventClass)
/*     */   {
/*  66 */     if ((ApplicationEvent.class == applicationEventClass) || 
/*  67 */       (!ApplicationEvent.class.isAssignableFrom(applicationEventClass))) {
/*  68 */       throw new IllegalArgumentException("applicationEventClass needs to extend ApplicationEvent");
/*     */     }
/*     */     try
/*     */     {
/*  72 */       this.applicationEventClassConstructor = applicationEventClass.getConstructor(new Class[] { Object.class });
/*     */     }
/*     */     catch (NoSuchMethodException ex)
/*     */     {
/*  76 */       throw new IllegalArgumentException("applicationEventClass [" + applicationEventClass.getName() + "] does not have the required Object constructor: " + ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher)
/*     */   {
/*  82 */     this.applicationEventPublisher = applicationEventPublisher;
/*     */   }
/*     */   
/*     */   public void afterPropertiesSet() throws Exception
/*     */   {
/*  87 */     if (this.applicationEventClassConstructor == null) {
/*  88 */       throw new IllegalArgumentException("applicationEventClass is required");
/*     */     }
/*     */   }
/*     */   
/*     */   public Object invoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/*  95 */     Object retVal = invocation.proceed();
/*     */     
/*     */ 
/*  98 */     ApplicationEvent event = (ApplicationEvent)this.applicationEventClassConstructor.newInstance(new Object[] {invocation.getThis() });
/*  99 */     this.applicationEventPublisher.publishEvent(event);
/*     */     
/* 101 */     return retVal;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\context\event\EventPublicationInterceptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */