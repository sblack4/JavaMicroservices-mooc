/*     */ package org.springframework.context.event;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.UndeclaredThrowableException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.PayloadApplicationEvent;
/*     */ import org.springframework.context.expression.AnnotatedElementKey;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationListenerMethodAdapter
/*     */   implements GenericApplicationListener
/*     */ {
/*  61 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private final String beanName;
/*     */   
/*     */   private final Method method;
/*     */   
/*     */   private final Class<?> targetClass;
/*     */   
/*     */   private final Method bridgedMethod;
/*     */   
/*     */   private final List<ResolvableType> declaredEventTypes;
/*     */   
/*     */   private final AnnotatedElementKey methodKey;
/*     */   
/*     */   private ApplicationContext applicationContext;
/*     */   
/*     */   private EventExpressionEvaluator evaluator;
/*     */   
/*     */   private String condition;
/*     */   
/*     */   private EventListener eventListener;
/*     */   
/*     */   public ApplicationListenerMethodAdapter(String beanName, Class<?> targetClass, Method method)
/*     */   {
/*  85 */     this.beanName = beanName;
/*  86 */     this.method = method;
/*  87 */     this.targetClass = targetClass;
/*  88 */     this.bridgedMethod = BridgeMethodResolver.findBridgedMethod(method);
/*  89 */     this.declaredEventTypes = resolveDeclaredEventTypes();
/*  90 */     this.methodKey = new AnnotatedElementKey(this.method, this.targetClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void init(ApplicationContext applicationContext, EventExpressionEvaluator evaluator)
/*     */   {
/*  98 */     this.applicationContext = applicationContext;
/*  99 */     this.evaluator = evaluator;
/*     */   }
/*     */   
/*     */ 
/*     */   public void onApplicationEvent(ApplicationEvent event)
/*     */   {
/* 105 */     processEvent(event);
/*     */   }
/*     */   
/*     */   public boolean supportsEventType(ResolvableType eventType)
/*     */   {
/* 110 */     for (ResolvableType declaredEventType : this.declaredEventTypes) {
/* 111 */       if (declaredEventType.isAssignableFrom(eventType)) {
/* 112 */         return true;
/*     */       }
/* 114 */       if (PayloadApplicationEvent.class.isAssignableFrom(eventType.getRawClass())) {
/* 115 */         ResolvableType payloadType = eventType.as(PayloadApplicationEvent.class).getGeneric(new int[0]);
/* 116 */         if (declaredEventType.isAssignableFrom(payloadType)) {
/* 117 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 121 */     return eventType.hasUnresolvableGenerics();
/*     */   }
/*     */   
/*     */   public boolean supportsSourceType(Class<?> sourceType)
/*     */   {
/* 126 */     return true;
/*     */   }
/*     */   
/*     */   public int getOrder()
/*     */   {
/* 131 */     Order order = (Order)getMethodAnnotation(Order.class);
/* 132 */     return order != null ? order.value() : 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void processEvent(ApplicationEvent event)
/*     */   {
/* 141 */     Object[] args = resolveArguments(event);
/* 142 */     if (shouldHandle(event, args)) {
/* 143 */       Object result = doInvoke(args);
/* 144 */       if (result != null) {
/* 145 */         handleResult(result);
/*     */       }
/*     */       else {
/* 148 */         this.logger.trace("No result object given - no result to handle");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object[] resolveArguments(ApplicationEvent event)
/*     */   {
/* 160 */     ResolvableType declaredEventType = getResolvableType(event);
/* 161 */     if (declaredEventType == null) {
/* 162 */       return null;
/*     */     }
/* 164 */     if (this.method.getParameterTypes().length == 0) {
/* 165 */       return new Object[0];
/*     */     }
/* 167 */     if ((!ApplicationEvent.class.isAssignableFrom(declaredEventType.getRawClass())) && ((event instanceof PayloadApplicationEvent)))
/*     */     {
/* 169 */       return new Object[] { ((PayloadApplicationEvent)event).getPayload() };
/*     */     }
/*     */     
/* 172 */     return new Object[] { event };
/*     */   }
/*     */   
/*     */   protected void handleResult(Object result)
/*     */   {
/* 177 */     if (result.getClass().isArray()) {
/* 178 */       Object[] events = ObjectUtils.toObjectArray(result);
/* 179 */       for (Object event : events) {
/* 180 */         publishEvent(event);
/*     */       }
/*     */     }
/* 183 */     else if ((result instanceof Collection)) {
/* 184 */       Collection<?> events = (Collection)result;
/* 185 */       for (??? = events.iterator(); ((Iterator)???).hasNext();) { Object event = ((Iterator)???).next();
/* 186 */         publishEvent(event);
/*     */       }
/*     */     }
/*     */     else {
/* 190 */       publishEvent(result);
/*     */     }
/*     */   }
/*     */   
/*     */   private void publishEvent(Object event) {
/* 195 */     if (event != null) {
/* 196 */       Assert.notNull(this.applicationContext, "ApplicationContext must no be null");
/* 197 */       this.applicationContext.publishEvent(event);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean shouldHandle(ApplicationEvent event, Object[] args) {
/* 202 */     if (args == null) {
/* 203 */       return false;
/*     */     }
/* 205 */     String condition = getCondition();
/* 206 */     if (StringUtils.hasText(condition)) {
/* 207 */       Assert.notNull(this.evaluator, "EventExpressionEvaluator must no be null");
/* 208 */       EvaluationContext evaluationContext = this.evaluator.createEvaluationContext(event, this.targetClass, this.method, args, this.applicationContext);
/*     */       
/* 210 */       return this.evaluator.condition(condition, this.methodKey, evaluationContext);
/*     */     }
/* 212 */     return true;
/*     */   }
/*     */   
/*     */   protected <A extends Annotation> A getMethodAnnotation(Class<A> annotationType) {
/* 216 */     return AnnotatedElementUtils.findMergedAnnotation(this.method, annotationType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Object doInvoke(Object... args)
/*     */   {
/* 223 */     Object bean = getTargetBean();
/* 224 */     ReflectionUtils.makeAccessible(this.bridgedMethod);
/*     */     try {
/* 226 */       return this.bridgedMethod.invoke(bean, args);
/*     */     }
/*     */     catch (IllegalArgumentException ex) {
/* 229 */       assertTargetBean(this.bridgedMethod, bean, args);
/* 230 */       throw new IllegalStateException(getInvocationErrorMessage(bean, ex.getMessage(), args), ex);
/*     */     }
/*     */     catch (IllegalAccessException ex) {
/* 233 */       throw new IllegalStateException(getInvocationErrorMessage(bean, ex.getMessage(), args), ex);
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 237 */       Throwable targetException = ex.getTargetException();
/* 238 */       if ((targetException instanceof RuntimeException)) {
/* 239 */         throw ((RuntimeException)targetException);
/*     */       }
/*     */       
/* 242 */       String msg = getInvocationErrorMessage(bean, "Failed to invoke event listener method", args);
/* 243 */       throw new UndeclaredThrowableException(targetException, msg);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object getTargetBean()
/*     */   {
/* 252 */     Assert.notNull(this.applicationContext, "ApplicationContext must no be null");
/* 253 */     return this.applicationContext.getBean(this.beanName);
/*     */   }
/*     */   
/*     */   protected EventListener getEventListener() {
/* 257 */     if (this.eventListener == null) {
/* 258 */       this.eventListener = ((EventListener)AnnotatedElementUtils.findMergedAnnotation(this.method, EventListener.class));
/*     */     }
/* 260 */     return this.eventListener;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getCondition()
/*     */   {
/* 270 */     if (this.condition == null) {
/* 271 */       EventListener eventListener = (EventListener)AnnotatedElementUtils.findMergedAnnotation(this.method, EventListener.class);
/* 272 */       if (eventListener != null) {
/* 273 */         this.condition = eventListener.condition();
/*     */       }
/*     */     }
/* 276 */     return this.condition;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDetailedErrorMessage(Object bean, String message)
/*     */   {
/* 285 */     StringBuilder sb = new StringBuilder(message).append("\n");
/* 286 */     sb.append("HandlerMethod details: \n");
/* 287 */     sb.append("Bean [").append(bean.getClass().getName()).append("]\n");
/* 288 */     sb.append("Method [").append(this.bridgedMethod.toGenericString()).append("]\n");
/* 289 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void assertTargetBean(Method method, Object targetBean, Object[] args)
/*     */   {
/* 300 */     Class<?> methodDeclaringClass = method.getDeclaringClass();
/* 301 */     Class<?> targetBeanClass = targetBean.getClass();
/* 302 */     if (!methodDeclaringClass.isAssignableFrom(targetBeanClass))
/*     */     {
/*     */ 
/* 305 */       String msg = "The event listener method class '" + methodDeclaringClass.getName() + "' is not an instance of the actual bean class '" + targetBeanClass.getName() + "'. If the bean requires proxying " + "(e.g. due to @Transactional), please use class-based proxying.";
/*     */       
/* 307 */       throw new IllegalStateException(getInvocationErrorMessage(targetBean, msg, args));
/*     */     }
/*     */   }
/*     */   
/*     */   private String getInvocationErrorMessage(Object bean, String message, Object[] resolvedArgs) {
/* 312 */     StringBuilder sb = new StringBuilder(getDetailedErrorMessage(bean, message));
/* 313 */     sb.append("Resolved arguments: \n");
/* 314 */     for (int i = 0; i < resolvedArgs.length; i++) {
/* 315 */       sb.append("[").append(i).append("] ");
/* 316 */       if (resolvedArgs[i] == null) {
/* 317 */         sb.append("[null] \n");
/*     */       }
/*     */       else {
/* 320 */         sb.append("[type=").append(resolvedArgs[i].getClass().getName()).append("] ");
/* 321 */         sb.append("[value=").append(resolvedArgs[i]).append("]\n");
/*     */       }
/*     */     }
/* 324 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private ResolvableType getResolvableType(ApplicationEvent event)
/*     */   {
/* 329 */     ResolvableType payloadType = null;
/* 330 */     PayloadApplicationEvent<?> payloadEvent; if ((event instanceof PayloadApplicationEvent)) {
/* 331 */       payloadEvent = (PayloadApplicationEvent)event;
/*     */       
/* 333 */       payloadType = payloadEvent.getResolvableType().as(PayloadApplicationEvent.class).getGeneric(new int[] { 0 });
/*     */     }
/* 335 */     for (ResolvableType declaredEventType : this.declaredEventTypes) {
/* 336 */       if ((!ApplicationEvent.class.isAssignableFrom(declaredEventType.getRawClass())) && (payloadType != null))
/*     */       {
/* 338 */         if (declaredEventType.isAssignableFrom(payloadType)) {
/* 339 */           return declaredEventType;
/*     */         }
/*     */       }
/* 342 */       if (declaredEventType.getRawClass().isAssignableFrom(event.getClass())) {
/* 343 */         return declaredEventType;
/*     */       }
/*     */     }
/* 346 */     return null;
/*     */   }
/*     */   
/*     */   private List<ResolvableType> resolveDeclaredEventTypes() {
/* 350 */     int count = this.method.getParameterTypes().length;
/* 351 */     if (count > 1) {
/* 352 */       throw new IllegalStateException("Maximum one parameter is allowed for event listener method: " + this.method);
/*     */     }
/*     */     
/* 355 */     EventListener ann = getEventListener();
/* 356 */     if ((ann != null) && (ann.classes().length > 0)) {
/* 357 */       List<ResolvableType> types = new ArrayList();
/* 358 */       for (Class<?> eventType : ann.classes()) {
/* 359 */         types.add(ResolvableType.forClass(eventType));
/*     */       }
/* 361 */       return types;
/*     */     }
/*     */     
/* 364 */     if (count == 0) {
/* 365 */       throw new IllegalStateException("Event parameter is mandatory for event listener method: " + this.method);
/*     */     }
/*     */     
/* 368 */     return Collections.singletonList(ResolvableType.forMethodParameter(this.method, 0));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 375 */     return this.method.toGenericString();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\context\event\ApplicationListenerMethodAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */