/*     */ package org.springframework.context.event;
/*     */ 
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericApplicationListenerAdapter
/*     */   implements GenericApplicationListener, SmartApplicationListener
/*     */ {
/*     */   private final ApplicationListener<ApplicationEvent> delegate;
/*     */   private final ResolvableType declaredEventType;
/*     */   
/*     */   public GenericApplicationListenerAdapter(ApplicationListener<?> delegate)
/*     */   {
/*  48 */     Assert.notNull(delegate, "Delegate listener must not be null");
/*  49 */     this.delegate = delegate;
/*  50 */     this.declaredEventType = resolveDeclaredEventType(this.delegate);
/*     */   }
/*     */   
/*     */ 
/*     */   public void onApplicationEvent(ApplicationEvent event)
/*     */   {
/*  56 */     this.delegate.onApplicationEvent(event);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean supportsEventType(ResolvableType eventType)
/*     */   {
/*  62 */     if ((this.delegate instanceof SmartApplicationListener)) {
/*  63 */       Class<? extends ApplicationEvent> eventClass = eventType.getRawClass();
/*  64 */       return ((SmartApplicationListener)this.delegate).supportsEventType(eventClass);
/*     */     }
/*     */     
/*  67 */     return (this.declaredEventType == null) || (this.declaredEventType.isAssignableFrom(eventType));
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean supportsEventType(Class<? extends ApplicationEvent> eventType)
/*     */   {
/*  73 */     return supportsEventType(ResolvableType.forType(eventType));
/*     */   }
/*     */   
/*     */   public boolean supportsSourceType(Class<?> sourceType)
/*     */   {
/*  78 */     if ((this.delegate instanceof SmartApplicationListener)) {
/*  79 */       return ((SmartApplicationListener)this.delegate).supportsSourceType(sourceType);
/*     */     }
/*     */     
/*  82 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getOrder()
/*     */   {
/*  88 */     return (this.delegate instanceof Ordered) ? ((Ordered)this.delegate).getOrder() : Integer.MAX_VALUE;
/*     */   }
/*     */   
/*     */   static ResolvableType resolveDeclaredEventType(Class<?> listenerType)
/*     */   {
/*  93 */     ResolvableType resolvableType = ResolvableType.forClass(listenerType).as(ApplicationListener.class);
/*  94 */     if ((resolvableType == null) || (!resolvableType.hasGenerics())) {
/*  95 */       return null;
/*     */     }
/*  97 */     return resolvableType.getGeneric(new int[0]);
/*     */   }
/*     */   
/*     */   private static ResolvableType resolveDeclaredEventType(ApplicationListener<ApplicationEvent> listener) {
/* 101 */     ResolvableType declaredEventType = resolveDeclaredEventType(listener.getClass());
/* 102 */     if ((declaredEventType == null) || (declaredEventType.isAssignableFrom(
/* 103 */       ResolvableType.forClass(ApplicationEvent.class))))
/*     */     {
/* 105 */       Class<?> targetClass = AopUtils.getTargetClass(listener);
/* 106 */       if (targetClass != listener.getClass()) {
/* 107 */         declaredEventType = resolveDeclaredEventType(targetClass);
/*     */       }
/*     */     }
/* 110 */     return declaredEventType;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\context\event\GenericApplicationListenerAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */