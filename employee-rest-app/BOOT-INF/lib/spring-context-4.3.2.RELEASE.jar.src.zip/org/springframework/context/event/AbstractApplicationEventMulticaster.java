/*     */ package org.springframework.context.event;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractApplicationEventMulticaster
/*     */   implements ApplicationEventMulticaster, BeanClassLoaderAware, BeanFactoryAware
/*     */ {
/*  61 */   private final ListenerRetriever defaultRetriever = new ListenerRetriever(false);
/*     */   
/*  63 */   final Map<ListenerCacheKey, ListenerRetriever> retrieverCache = new ConcurrentHashMap(64);
/*     */   
/*     */ 
/*     */   private ClassLoader beanClassLoader;
/*     */   
/*     */   private BeanFactory beanFactory;
/*     */   
/*  70 */   private Object retrievalMutex = this.defaultRetriever;
/*     */   
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/*  75 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/*  80 */     this.beanFactory = beanFactory;
/*  81 */     if ((beanFactory instanceof ConfigurableBeanFactory)) {
/*  82 */       ConfigurableBeanFactory cbf = (ConfigurableBeanFactory)beanFactory;
/*  83 */       if (this.beanClassLoader == null) {
/*  84 */         this.beanClassLoader = cbf.getBeanClassLoader();
/*     */       }
/*  86 */       this.retrievalMutex = cbf.getSingletonMutex();
/*     */     }
/*     */   }
/*     */   
/*     */   private BeanFactory getBeanFactory() {
/*  91 */     if (this.beanFactory == null) {
/*  92 */       throw new IllegalStateException("ApplicationEventMulticaster cannot retrieve listener beans because it is not associated with a BeanFactory");
/*     */     }
/*     */     
/*  95 */     return this.beanFactory;
/*     */   }
/*     */   
/*     */ 
/*     */   public void addApplicationListener(ApplicationListener<?> listener)
/*     */   {
/* 101 */     synchronized (this.retrievalMutex) {
/* 102 */       this.defaultRetriever.applicationListeners.add(listener);
/* 103 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public void addApplicationListenerBean(String listenerBeanName)
/*     */   {
/* 109 */     synchronized (this.retrievalMutex) {
/* 110 */       this.defaultRetriever.applicationListenerBeans.add(listenerBeanName);
/* 111 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeApplicationListener(ApplicationListener<?> listener)
/*     */   {
/* 117 */     synchronized (this.retrievalMutex) {
/* 118 */       this.defaultRetriever.applicationListeners.remove(listener);
/* 119 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeApplicationListenerBean(String listenerBeanName)
/*     */   {
/* 125 */     synchronized (this.retrievalMutex) {
/* 126 */       this.defaultRetriever.applicationListenerBeans.remove(listenerBeanName);
/* 127 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeAllListeners()
/*     */   {
/* 133 */     synchronized (this.retrievalMutex) {
/* 134 */       this.defaultRetriever.applicationListeners.clear();
/* 135 */       this.defaultRetriever.applicationListenerBeans.clear();
/* 136 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected Collection<ApplicationListener<?>> getApplicationListeners()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 9	org/springframework/context/event/AbstractApplicationEventMulticaster:retrievalMutex	Ljava/lang/Object;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 5	org/springframework/context/event/AbstractApplicationEventMulticaster:defaultRetriever	Lorg/springframework/context/event/AbstractApplicationEventMulticaster$ListenerRetriever;
/*     */     //   11: invokevirtual 24	org/springframework/context/event/AbstractApplicationEventMulticaster$ListenerRetriever:getApplicationListeners	()Ljava/util/Collection;
/*     */     //   14: aload_1
/*     */     //   15: monitorexit
/*     */     //   16: areturn
/*     */     //   17: astore_2
/*     */     //   18: aload_1
/*     */     //   19: monitorexit
/*     */     //   20: aload_2
/*     */     //   21: athrow
/*     */     // Line number table:
/*     */     //   Java source line #147	-> byte code offset #0
/*     */     //   Java source line #148	-> byte code offset #7
/*     */     //   Java source line #149	-> byte code offset #17
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	22	0	this	AbstractApplicationEventMulticaster
/*     */     //   5	14	1	Ljava/lang/Object;	Object
/*     */     //   17	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	16	17	finally
/*     */     //   17	20	17	finally
/*     */   }
/*     */   
/*     */   protected Collection<ApplicationListener<?>> getApplicationListeners(ApplicationEvent event, ResolvableType eventType)
/*     */   {
/* 164 */     Object source = event.getSource();
/* 165 */     Class<?> sourceType = source != null ? source.getClass() : null;
/* 166 */     ListenerCacheKey cacheKey = new ListenerCacheKey(eventType, sourceType);
/*     */     
/*     */ 
/* 169 */     ListenerRetriever retriever = (ListenerRetriever)this.retrieverCache.get(cacheKey);
/* 170 */     if (retriever != null) {
/* 171 */       return retriever.getApplicationListeners();
/*     */     }
/*     */     
/* 174 */     if ((this.beanClassLoader == null) || (
/* 175 */       (ClassUtils.isCacheSafe(event.getClass(), this.beanClassLoader)) && ((sourceType == null) || 
/* 176 */       (ClassUtils.isCacheSafe(sourceType, this.beanClassLoader)))))
/*     */     {
/* 178 */       synchronized (this.retrievalMutex) {
/* 179 */         retriever = (ListenerRetriever)this.retrieverCache.get(cacheKey);
/* 180 */         if (retriever != null) {
/* 181 */           return retriever.getApplicationListeners();
/*     */         }
/* 183 */         retriever = new ListenerRetriever(true);
/*     */         
/* 185 */         Collection<ApplicationListener<?>> listeners = retrieveApplicationListeners(eventType, sourceType, retriever);
/* 186 */         this.retrieverCache.put(cacheKey, retriever);
/* 187 */         return listeners;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 192 */     return retrieveApplicationListeners(eventType, sourceType, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Collection<ApplicationListener<?>> retrieveApplicationListeners(ResolvableType eventType, Class<?> sourceType, ListenerRetriever retriever)
/*     */   {
/* 206 */     LinkedList<ApplicationListener<?>> allListeners = new LinkedList();
/*     */     
/*     */     Set<String> listenerBeans;
/* 209 */     synchronized (this.retrievalMutex) {
/* 210 */       Set<ApplicationListener<?>> listeners = new LinkedHashSet(this.defaultRetriever.applicationListeners);
/* 211 */       listenerBeans = new LinkedHashSet(this.defaultRetriever.applicationListenerBeans); }
/*     */     Set<String> listenerBeans;
/* 213 */     Set<ApplicationListener<?>> listeners; for (??? = listeners.iterator(); ((Iterator)???).hasNext();) { listener = (ApplicationListener)((Iterator)???).next();
/* 214 */       if (supportsEvent((ApplicationListener)listener, eventType, sourceType)) {
/* 215 */         if (retriever != null) {
/* 216 */           retriever.applicationListeners.add(listener);
/*     */         }
/* 218 */         allListeners.add(listener); } }
/*     */     Object listener;
/*     */     BeanFactory beanFactory;
/* 221 */     if (!listenerBeans.isEmpty()) {
/* 222 */       beanFactory = getBeanFactory();
/* 223 */       for (listener = listenerBeans.iterator(); ((Iterator)listener).hasNext();) { String listenerBeanName = (String)((Iterator)listener).next();
/*     */         try {
/* 225 */           Class<?> listenerType = beanFactory.getType(listenerBeanName);
/* 226 */           if ((listenerType == null) || (supportsEvent(listenerType, eventType)))
/*     */           {
/* 228 */             ApplicationListener<?> listener = (ApplicationListener)beanFactory.getBean(listenerBeanName, ApplicationListener.class);
/* 229 */             if ((!allListeners.contains(listener)) && (supportsEvent(listener, eventType, sourceType))) {
/* 230 */               if (retriever != null) {
/* 231 */                 retriever.applicationListenerBeans.add(listenerBeanName);
/*     */               }
/* 233 */               allListeners.add(listener);
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (NoSuchBeanDefinitionException localNoSuchBeanDefinitionException) {}
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 243 */     AnnotationAwareOrderComparator.sort(allListeners);
/* 244 */     return allListeners;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean supportsEvent(Class<?> listenerType, ResolvableType eventType)
/*     */   {
/* 259 */     if ((GenericApplicationListener.class.isAssignableFrom(listenerType)) || 
/* 260 */       (SmartApplicationListener.class.isAssignableFrom(listenerType))) {
/* 261 */       return true;
/*     */     }
/* 263 */     ResolvableType declaredEventType = GenericApplicationListenerAdapter.resolveDeclaredEventType(listenerType);
/* 264 */     return (declaredEventType == null) || (declaredEventType.isAssignableFrom(eventType));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean supportsEvent(ApplicationListener<?> listener, ResolvableType eventType, Class<?> sourceType)
/*     */   {
/* 280 */     GenericApplicationListener smartListener = (listener instanceof GenericApplicationListener) ? (GenericApplicationListener)listener : new GenericApplicationListenerAdapter(listener);
/*     */     
/* 282 */     return (smartListener.supportsEventType(eventType)) && (smartListener.supportsSourceType(sourceType));
/*     */   }
/*     */   
/*     */ 
/*     */   private static final class ListenerCacheKey
/*     */     implements Comparable<ListenerCacheKey>
/*     */   {
/*     */     private final ResolvableType eventType;
/*     */     
/*     */     private final Class<?> sourceType;
/*     */     
/*     */ 
/*     */     public ListenerCacheKey(ResolvableType eventType, Class<?> sourceType)
/*     */     {
/* 296 */       this.eventType = eventType;
/* 297 */       this.sourceType = sourceType;
/*     */     }
/*     */     
/*     */     public boolean equals(Object other)
/*     */     {
/* 302 */       if (this == other) {
/* 303 */         return true;
/*     */       }
/* 305 */       ListenerCacheKey otherKey = (ListenerCacheKey)other;
/*     */       
/* 307 */       return (ObjectUtils.nullSafeEquals(this.eventType, otherKey.eventType)) && (ObjectUtils.nullSafeEquals(this.sourceType, otherKey.sourceType));
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 312 */       return ObjectUtils.nullSafeHashCode(this.eventType) * 29 + ObjectUtils.nullSafeHashCode(this.sourceType);
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 317 */       return "ListenerCacheKey [eventType = " + this.eventType + ", sourceType = " + this.sourceType.getName() + "]";
/*     */     }
/*     */     
/*     */     public int compareTo(ListenerCacheKey other)
/*     */     {
/* 322 */       int result = 0;
/* 323 */       if (this.eventType != null) {
/* 324 */         result = this.eventType.toString().compareTo(other.eventType.toString());
/*     */       }
/* 326 */       if ((result == 0) && (this.sourceType != null)) {
/* 327 */         result = this.sourceType.getName().compareTo(other.sourceType.getName());
/*     */       }
/* 329 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class ListenerRetriever
/*     */   {
/*     */     public final Set<ApplicationListener<?>> applicationListeners;
/*     */     
/*     */ 
/*     */     public final Set<String> applicationListenerBeans;
/*     */     
/*     */ 
/*     */     private final boolean preFiltered;
/*     */     
/*     */ 
/*     */     public ListenerRetriever(boolean preFiltered)
/*     */     {
/* 348 */       this.applicationListeners = new LinkedHashSet();
/* 349 */       this.applicationListenerBeans = new LinkedHashSet();
/* 350 */       this.preFiltered = preFiltered;
/*     */     }
/*     */     
/*     */     public Collection<ApplicationListener<?>> getApplicationListeners() {
/* 354 */       LinkedList<ApplicationListener<?>> allListeners = new LinkedList();
/* 355 */       for (Iterator localIterator = this.applicationListeners.iterator(); localIterator.hasNext();) { listener = (ApplicationListener)localIterator.next();
/* 356 */         allListeners.add(listener); }
/*     */       ApplicationListener<?> listener;
/* 358 */       BeanFactory beanFactory; if (!this.applicationListenerBeans.isEmpty()) {
/* 359 */         beanFactory = AbstractApplicationEventMulticaster.this.getBeanFactory();
/* 360 */         for (String listenerBeanName : this.applicationListenerBeans) {
/*     */           try {
/* 362 */             ApplicationListener<?> listener = (ApplicationListener)beanFactory.getBean(listenerBeanName, ApplicationListener.class);
/* 363 */             if ((this.preFiltered) || (!allListeners.contains(listener))) {
/* 364 */               allListeners.add(listener);
/*     */             }
/*     */           }
/*     */           catch (NoSuchBeanDefinitionException localNoSuchBeanDefinitionException) {}
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 373 */       AnnotationAwareOrderComparator.sort(allListeners);
/* 374 */       return allListeners;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\context\event\AbstractApplicationEventMulticaster.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */