/*     */ package org.springframework.context.event;
/*     */ 
/*     */ import java.util.concurrent.Executor;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.util.ErrorHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleApplicationEventMulticaster
/*     */   extends AbstractApplicationEventMulticaster
/*     */ {
/*     */   private Executor taskExecutor;
/*     */   private ErrorHandler errorHandler;
/*     */   
/*     */   public SimpleApplicationEventMulticaster() {}
/*     */   
/*     */   public SimpleApplicationEventMulticaster(BeanFactory beanFactory)
/*     */   {
/*  64 */     setBeanFactory(beanFactory);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTaskExecutor(Executor taskExecutor)
/*     */   {
/*  81 */     this.taskExecutor = taskExecutor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Executor getTaskExecutor()
/*     */   {
/*  88 */     return this.taskExecutor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setErrorHandler(ErrorHandler errorHandler)
/*     */   {
/* 107 */     this.errorHandler = errorHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ErrorHandler getErrorHandler()
/*     */   {
/* 115 */     return this.errorHandler;
/*     */   }
/*     */   
/*     */ 
/*     */   public void multicastEvent(ApplicationEvent event)
/*     */   {
/* 121 */     multicastEvent(event, resolveDefaultEventType(event));
/*     */   }
/*     */   
/*     */   public void multicastEvent(final ApplicationEvent event, ResolvableType eventType)
/*     */   {
/* 126 */     ResolvableType type = eventType != null ? eventType : resolveDefaultEventType(event);
/* 127 */     for (final ApplicationListener<?> listener : getApplicationListeners(event, type)) {
/* 128 */       Executor executor = getTaskExecutor();
/* 129 */       if (executor != null) {
/* 130 */         executor.execute(new Runnable()
/*     */         {
/*     */           public void run() {
/* 133 */             SimpleApplicationEventMulticaster.this.invokeListener(listener, event);
/*     */           }
/*     */           
/*     */         });
/*     */       } else {
/* 138 */         invokeListener(listener, event);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private ResolvableType resolveDefaultEventType(ApplicationEvent event) {
/* 144 */     return ResolvableType.forInstance(event);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void invokeListener(ApplicationListener listener, ApplicationEvent event)
/*     */   {
/* 155 */     ErrorHandler errorHandler = getErrorHandler();
/* 156 */     if (errorHandler != null) {
/*     */       try {
/* 158 */         listener.onApplicationEvent(event);
/*     */       }
/*     */       catch (Throwable err) {
/* 161 */         errorHandler.handleError(err);
/*     */       }
/*     */     } else {
/*     */       try
/*     */       {
/* 166 */         listener.onApplicationEvent(event);
/*     */       }
/*     */       catch (ClassCastException ex)
/*     */       {
/* 170 */         LogFactory.getLog(getClass()).debug("Non-matching event type for listener: " + listener, ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\context\event\SimpleApplicationEventMulticaster.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */