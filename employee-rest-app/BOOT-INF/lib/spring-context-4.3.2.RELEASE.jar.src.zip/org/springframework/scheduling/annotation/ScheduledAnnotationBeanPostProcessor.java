/*     */ package org.springframework.scheduling.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.TimeZone;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
/*     */ import org.springframework.beans.factory.SmartInitializingSingleton;
/*     */ import org.springframework.beans.factory.config.DestructionAwareBeanPostProcessor;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.EmbeddedValueResolverAware;
/*     */ import org.springframework.context.event.ContextRefreshedEvent;
/*     */ import org.springframework.core.MethodIntrospector;
/*     */ import org.springframework.core.MethodIntrospector.MetadataLookup;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.scheduling.TaskScheduler;
/*     */ import org.springframework.scheduling.config.CronTask;
/*     */ import org.springframework.scheduling.config.IntervalTask;
/*     */ import org.springframework.scheduling.config.ScheduledTask;
/*     */ import org.springframework.scheduling.config.ScheduledTaskRegistrar;
/*     */ import org.springframework.scheduling.support.CronTrigger;
/*     */ import org.springframework.scheduling.support.ScheduledMethodRunnable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScheduledAnnotationBeanPostProcessor
/*     */   implements DestructionAwareBeanPostProcessor, Ordered, EmbeddedValueResolverAware, BeanFactoryAware, ApplicationContextAware, SmartInitializingSingleton, ApplicationListener<ContextRefreshedEvent>, DisposableBean
/*     */ {
/*     */   public static final String DEFAULT_TASK_SCHEDULER_BEAN_NAME = "taskScheduler";
/* 100 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private Object scheduler;
/*     */   
/*     */   private StringValueResolver embeddedValueResolver;
/*     */   
/*     */   private BeanFactory beanFactory;
/*     */   
/*     */   private ApplicationContext applicationContext;
/*     */   
/* 110 */   private final ScheduledTaskRegistrar registrar = new ScheduledTaskRegistrar();
/*     */   
/*     */ 
/* 113 */   private final Set<Class<?>> nonAnnotatedClasses = Collections.newSetFromMap(new ConcurrentHashMap(64));
/*     */   
/* 115 */   private final Map<Object, Set<ScheduledTask>> scheduledTasks = new ConcurrentHashMap(16);
/*     */   
/*     */ 
/*     */ 
/*     */   public int getOrder()
/*     */   {
/* 121 */     return Integer.MAX_VALUE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScheduler(Object scheduler)
/*     */   {
/* 136 */     this.scheduler = scheduler;
/*     */   }
/*     */   
/*     */   public void setEmbeddedValueResolver(StringValueResolver resolver)
/*     */   {
/* 141 */     this.embeddedValueResolver = resolver;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/* 151 */     this.beanFactory = beanFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setApplicationContext(ApplicationContext applicationContext)
/*     */   {
/* 161 */     this.applicationContext = applicationContext;
/* 162 */     if (this.beanFactory == null) {
/* 163 */       this.beanFactory = applicationContext;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void afterSingletonsInstantiated()
/*     */   {
/* 170 */     if (this.applicationContext == null)
/*     */     {
/* 172 */       finishRegistration();
/*     */     }
/*     */   }
/*     */   
/*     */   public void onApplicationEvent(ContextRefreshedEvent event)
/*     */   {
/* 178 */     if (event.getApplicationContext() == this.applicationContext)
/*     */     {
/*     */ 
/*     */ 
/* 182 */       finishRegistration();
/*     */     }
/*     */   }
/*     */   
/*     */   private void finishRegistration() {
/* 187 */     if (this.scheduler != null) {
/* 188 */       this.registrar.setScheduler(this.scheduler);
/*     */     }
/*     */     
/* 191 */     if ((this.beanFactory instanceof ListableBeanFactory))
/*     */     {
/* 193 */       Map<String, SchedulingConfigurer> configurers = ((ListableBeanFactory)this.beanFactory).getBeansOfType(SchedulingConfigurer.class);
/* 194 */       for (SchedulingConfigurer configurer : configurers.values()) {
/* 195 */         configurer.configureTasks(this.registrar);
/*     */       }
/*     */     }
/*     */     
/* 199 */     if ((this.registrar.hasTasks()) && (this.registrar.getScheduler() == null)) {
/* 200 */       Assert.state(this.beanFactory != null, "BeanFactory must be set to find scheduler by type");
/*     */       try
/*     */       {
/* 203 */         this.registrar.setTaskScheduler((TaskScheduler)this.beanFactory.getBean(TaskScheduler.class));
/*     */       }
/*     */       catch (NoUniqueBeanDefinitionException ex) {
/*     */         try {
/* 207 */           this.registrar.setTaskScheduler(
/* 208 */             (TaskScheduler)this.beanFactory.getBean("taskScheduler", TaskScheduler.class));
/*     */         }
/*     */         catch (NoSuchBeanDefinitionException ex2) {
/* 211 */           if (this.logger.isInfoEnabled()) {
/* 212 */             this.logger.info("More than one TaskScheduler bean exists within the context, and none is named 'taskScheduler'. Mark one of them as primary or name it 'taskScheduler' (possibly as an alias); or implement the SchedulingConfigurer interface and call ScheduledTaskRegistrar#setScheduler explicitly within the configureTasks() callback: " + ex
/*     */             
/*     */ 
/*     */ 
/* 216 */               .getBeanNamesFound());
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (NoSuchBeanDefinitionException ex) {
/* 221 */         this.logger.debug("Could not find default TaskScheduler bean", ex);
/*     */         try
/*     */         {
/* 224 */           this.registrar.setScheduler(this.beanFactory.getBean(ScheduledExecutorService.class));
/*     */         }
/*     */         catch (NoUniqueBeanDefinitionException ex2) {
/*     */           try {
/* 228 */             this.registrar.setScheduler(this.beanFactory
/* 229 */               .getBean("taskScheduler", ScheduledExecutorService.class));
/*     */           }
/*     */           catch (NoSuchBeanDefinitionException ex3) {
/* 232 */             if (this.logger.isInfoEnabled()) {
/* 233 */               this.logger.info("More than one ScheduledExecutorService bean exists within the context, and none is named 'taskScheduler'. Mark one of them as primary or name it 'taskScheduler' (possibly as an alias); or implement the SchedulingConfigurer interface and call ScheduledTaskRegistrar#setScheduler explicitly within the configureTasks() callback: " + ex2
/*     */               
/*     */ 
/*     */ 
/* 237 */                 .getBeanNamesFound());
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (NoSuchBeanDefinitionException ex2) {
/* 242 */           this.logger.debug("Could not find default ScheduledExecutorService bean", ex2);
/*     */           
/* 244 */           this.logger.info("No TaskScheduler/ScheduledExecutorService bean found for scheduled processing");
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 249 */     this.registrar.afterPropertiesSet();
/*     */   }
/*     */   
/*     */ 
/*     */   public Object postProcessBeforeInitialization(Object bean, String beanName)
/*     */   {
/* 255 */     return bean;
/*     */   }
/*     */   
/*     */   public Object postProcessAfterInitialization(Object bean, String beanName)
/*     */   {
/* 260 */     Class<?> targetClass = AopUtils.getTargetClass(bean);
/* 261 */     if (!this.nonAnnotatedClasses.contains(targetClass)) {
/* 262 */       Map<Method, Set<Scheduled>> annotatedMethods = MethodIntrospector.selectMethods(targetClass, new MethodIntrospector.MetadataLookup()
/*     */       {
/*     */ 
/*     */         public Set<Scheduled> inspect(Method method)
/*     */         {
/* 267 */           Set<Scheduled> scheduledMethods = AnnotatedElementUtils.getMergedRepeatableAnnotations(method, Scheduled.class, Schedules.class);
/* 268 */           return !scheduledMethods.isEmpty() ? scheduledMethods : null;
/*     */         }
/*     */       });
/* 271 */       if (annotatedMethods.isEmpty()) {
/* 272 */         this.nonAnnotatedClasses.add(targetClass);
/* 273 */         if (this.logger.isTraceEnabled()) {
/* 274 */           this.logger.trace("No @Scheduled annotations found on bean class: " + bean.getClass());
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 279 */         for (Map.Entry<Method, Set<Scheduled>> entry : annotatedMethods.entrySet()) {
/* 280 */           method = (Method)entry.getKey();
/* 281 */           for (Scheduled scheduled : (Set)entry.getValue())
/* 282 */             processScheduled(scheduled, method, bean);
/*     */         }
/*     */         Method method;
/* 285 */         if (this.logger.isDebugEnabled()) {
/* 286 */           this.logger.debug(annotatedMethods.size() + " @Scheduled methods processed on bean '" + beanName + "': " + annotatedMethods);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 291 */     return bean;
/*     */   }
/*     */   
/*     */   protected void processScheduled(Scheduled scheduled, Method method, Object bean) {
/*     */     try {
/* 296 */       Assert.isTrue(method.getParameterTypes().length == 0, "Only no-arg methods may be annotated with @Scheduled");
/*     */       
/*     */ 
/* 299 */       Method invocableMethod = AopUtils.selectInvocableMethod(method, bean.getClass());
/* 300 */       Runnable runnable = new ScheduledMethodRunnable(bean, invocableMethod);
/* 301 */       boolean processedSchedule = false;
/* 302 */       String errorMessage = "Exactly one of the 'cron', 'fixedDelay(String)', or 'fixedRate(String)' attributes is required";
/*     */       
/*     */ 
/* 305 */       Set<ScheduledTask> tasks = (Set)this.scheduledTasks.get(bean);
/* 306 */       if (tasks == null) {
/* 307 */         tasks = new LinkedHashSet(4);
/* 308 */         this.scheduledTasks.put(bean, tasks);
/*     */       }
/*     */       
/*     */ 
/* 312 */       long initialDelay = scheduled.initialDelay();
/* 313 */       String initialDelayString = scheduled.initialDelayString();
/* 314 */       if (StringUtils.hasText(initialDelayString)) {
/* 315 */         Assert.isTrue(initialDelay < 0L, "Specify 'initialDelay' or 'initialDelayString', not both");
/* 316 */         if (this.embeddedValueResolver != null) {
/* 317 */           initialDelayString = this.embeddedValueResolver.resolveStringValue(initialDelayString);
/*     */         }
/*     */         try {
/* 320 */           initialDelay = Long.parseLong(initialDelayString);
/*     */         }
/*     */         catch (NumberFormatException ex) {
/* 323 */           throw new IllegalArgumentException("Invalid initialDelayString value \"" + initialDelayString + "\" - cannot parse into integer");
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 329 */       String cron = scheduled.cron();
/* 330 */       if (StringUtils.hasText(cron)) {
/* 331 */         Assert.isTrue(initialDelay == -1L, "'initialDelay' not supported for cron triggers");
/* 332 */         processedSchedule = true;
/* 333 */         String zone = scheduled.zone();
/* 334 */         if (this.embeddedValueResolver != null) {
/* 335 */           cron = this.embeddedValueResolver.resolveStringValue(cron);
/* 336 */           zone = this.embeddedValueResolver.resolveStringValue(zone); }
/*     */         TimeZone timeZone;
/*     */         TimeZone timeZone;
/* 339 */         if (StringUtils.hasText(zone)) {
/* 340 */           timeZone = StringUtils.parseTimeZoneString(zone);
/*     */         }
/*     */         else {
/* 343 */           timeZone = TimeZone.getDefault();
/*     */         }
/* 345 */         tasks.add(this.registrar.scheduleCronTask(new CronTask(runnable, new CronTrigger(cron, timeZone))));
/*     */       }
/*     */       
/*     */ 
/* 349 */       if (initialDelay < 0L) {
/* 350 */         initialDelay = 0L;
/*     */       }
/*     */       
/*     */ 
/* 354 */       long fixedDelay = scheduled.fixedDelay();
/* 355 */       if (fixedDelay >= 0L) {
/* 356 */         Assert.isTrue(!processedSchedule, errorMessage);
/* 357 */         processedSchedule = true;
/* 358 */         tasks.add(this.registrar.scheduleFixedDelayTask(new IntervalTask(runnable, fixedDelay, initialDelay)));
/*     */       }
/* 360 */       String fixedDelayString = scheduled.fixedDelayString();
/* 361 */       if (StringUtils.hasText(fixedDelayString)) {
/* 362 */         Assert.isTrue(!processedSchedule, errorMessage);
/* 363 */         processedSchedule = true;
/* 364 */         if (this.embeddedValueResolver != null) {
/* 365 */           fixedDelayString = this.embeddedValueResolver.resolveStringValue(fixedDelayString);
/*     */         }
/*     */         try {
/* 368 */           fixedDelay = Long.parseLong(fixedDelayString);
/*     */         }
/*     */         catch (NumberFormatException ex) {
/* 371 */           throw new IllegalArgumentException("Invalid fixedDelayString value \"" + fixedDelayString + "\" - cannot parse into integer");
/*     */         }
/*     */         
/* 374 */         tasks.add(this.registrar.scheduleFixedDelayTask(new IntervalTask(runnable, fixedDelay, initialDelay)));
/*     */       }
/*     */       
/*     */ 
/* 378 */       long fixedRate = scheduled.fixedRate();
/* 379 */       if (fixedRate >= 0L) {
/* 380 */         Assert.isTrue(!processedSchedule, errorMessage);
/* 381 */         processedSchedule = true;
/* 382 */         tasks.add(this.registrar.scheduleFixedRateTask(new IntervalTask(runnable, fixedRate, initialDelay)));
/*     */       }
/* 384 */       String fixedRateString = scheduled.fixedRateString();
/* 385 */       if (StringUtils.hasText(fixedRateString)) {
/* 386 */         Assert.isTrue(!processedSchedule, errorMessage);
/* 387 */         processedSchedule = true;
/* 388 */         if (this.embeddedValueResolver != null) {
/* 389 */           fixedRateString = this.embeddedValueResolver.resolveStringValue(fixedRateString);
/*     */         }
/*     */         try {
/* 392 */           fixedRate = Long.parseLong(fixedRateString);
/*     */         }
/*     */         catch (NumberFormatException ex) {
/* 395 */           throw new IllegalArgumentException("Invalid fixedRateString value \"" + fixedRateString + "\" - cannot parse into integer");
/*     */         }
/*     */         
/* 398 */         tasks.add(this.registrar.scheduleFixedRateTask(new IntervalTask(runnable, fixedRate, initialDelay)));
/*     */       }
/*     */       
/*     */ 
/* 402 */       Assert.isTrue(processedSchedule, errorMessage);
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/* 406 */       throw new IllegalStateException("Encountered invalid @Scheduled method '" + method.getName() + "': " + ex.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void postProcessBeforeDestruction(Object bean, String beanName)
/*     */   {
/* 413 */     Set<ScheduledTask> tasks = (Set)this.scheduledTasks.remove(bean);
/* 414 */     if (tasks != null) {
/* 415 */       for (ScheduledTask task : tasks) {
/* 416 */         task.cancel();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean requiresDestruction(Object bean)
/*     */   {
/* 423 */     return this.scheduledTasks.containsKey(bean);
/*     */   }
/*     */   
/*     */   public void destroy()
/*     */   {
/* 428 */     Collection<Set<ScheduledTask>> allTasks = this.scheduledTasks.values();
/* 429 */     for (Set<ScheduledTask> tasks : allTasks) {
/* 430 */       for (ScheduledTask task : tasks) {
/* 431 */         task.cancel();
/*     */       }
/*     */     }
/* 434 */     this.scheduledTasks.clear();
/* 435 */     this.registrar.destroy();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\scheduling\annotation\ScheduledAnnotationBeanPostProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */