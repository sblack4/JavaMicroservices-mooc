/*     */ package org.springframework.scheduling.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.BitSet;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CronSequenceGenerator
/*     */ {
/*     */   private final String expression;
/*     */   private final TimeZone timeZone;
/*  61 */   private final BitSet months = new BitSet(12);
/*     */   
/*  63 */   private final BitSet daysOfMonth = new BitSet(31);
/*     */   
/*  65 */   private final BitSet daysOfWeek = new BitSet(7);
/*     */   
/*  67 */   private final BitSet hours = new BitSet(24);
/*     */   
/*  69 */   private final BitSet minutes = new BitSet(60);
/*     */   
/*  71 */   private final BitSet seconds = new BitSet(60);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CronSequenceGenerator(String expression)
/*     */   {
/*  82 */     this(expression, TimeZone.getDefault());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CronSequenceGenerator(String expression, TimeZone timeZone)
/*     */   {
/*  93 */     this.expression = expression;
/*  94 */     this.timeZone = timeZone;
/*  95 */     parse(expression);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   String getExpression()
/*     */   {
/* 103 */     return this.expression;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date next(Date date)
/*     */   {
/* 134 */     Calendar calendar = new GregorianCalendar();
/* 135 */     calendar.setTimeZone(this.timeZone);
/* 136 */     calendar.setTime(date);
/*     */     
/*     */ 
/* 139 */     calendar.set(14, 0);
/* 140 */     long originalTimestamp = calendar.getTimeInMillis();
/* 141 */     doNext(calendar, calendar.get(1));
/*     */     
/* 143 */     if (calendar.getTimeInMillis() == originalTimestamp)
/*     */     {
/* 145 */       calendar.add(13, 1);
/* 146 */       doNext(calendar, calendar.get(1));
/*     */     }
/*     */     
/* 149 */     return calendar.getTime();
/*     */   }
/*     */   
/*     */   private void doNext(Calendar calendar, int dot) {
/* 153 */     List<Integer> resets = new ArrayList();
/*     */     
/* 155 */     int second = calendar.get(13);
/* 156 */     List<Integer> emptyList = Collections.emptyList();
/* 157 */     int updateSecond = findNext(this.seconds, second, calendar, 13, 12, emptyList);
/* 158 */     if (second == updateSecond) {
/* 159 */       resets.add(Integer.valueOf(13));
/*     */     }
/*     */     
/* 162 */     int minute = calendar.get(12);
/* 163 */     int updateMinute = findNext(this.minutes, minute, calendar, 12, 11, resets);
/* 164 */     if (minute == updateMinute) {
/* 165 */       resets.add(Integer.valueOf(12));
/*     */     }
/*     */     else {
/* 168 */       doNext(calendar, dot);
/*     */     }
/*     */     
/* 171 */     int hour = calendar.get(11);
/* 172 */     int updateHour = findNext(this.hours, hour, calendar, 11, 7, resets);
/* 173 */     if (hour == updateHour) {
/* 174 */       resets.add(Integer.valueOf(11));
/*     */     }
/*     */     else {
/* 177 */       doNext(calendar, dot);
/*     */     }
/*     */     
/* 180 */     int dayOfWeek = calendar.get(7);
/* 181 */     int dayOfMonth = calendar.get(5);
/* 182 */     int updateDayOfMonth = findNextDay(calendar, this.daysOfMonth, dayOfMonth, this.daysOfWeek, dayOfWeek, resets);
/* 183 */     if (dayOfMonth == updateDayOfMonth) {
/* 184 */       resets.add(Integer.valueOf(5));
/*     */     }
/*     */     else {
/* 187 */       doNext(calendar, dot);
/*     */     }
/*     */     
/* 190 */     int month = calendar.get(2);
/* 191 */     int updateMonth = findNext(this.months, month, calendar, 2, 1, resets);
/* 192 */     if (month != updateMonth) {
/* 193 */       if (calendar.get(1) - dot > 4) {
/* 194 */         throw new IllegalArgumentException("Invalid cron expression \"" + this.expression + "\" led to runaway search for next trigger");
/*     */       }
/*     */       
/* 197 */       doNext(calendar, dot);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private int findNextDay(Calendar calendar, BitSet daysOfMonth, int dayOfMonth, BitSet daysOfWeek, int dayOfWeek, List<Integer> resets)
/*     */   {
/* 205 */     int count = 0;
/* 206 */     int max = 366;
/*     */     
/*     */ 
/* 209 */     while (((!daysOfMonth.get(dayOfMonth)) || (!daysOfWeek.get(dayOfWeek - 1))) && (count++ < max)) {
/* 210 */       calendar.add(5, 1);
/* 211 */       dayOfMonth = calendar.get(5);
/* 212 */       dayOfWeek = calendar.get(7);
/* 213 */       reset(calendar, resets);
/*     */     }
/* 215 */     if (count >= max) {
/* 216 */       throw new IllegalArgumentException("Overflow in day for expression \"" + this.expression + "\"");
/*     */     }
/* 218 */     return dayOfMonth;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int findNext(BitSet bits, int value, Calendar calendar, int field, int nextField, List<Integer> lowerOrders)
/*     */   {
/* 234 */     int nextValue = bits.nextSetBit(value);
/*     */     
/* 236 */     if (nextValue == -1) {
/* 237 */       calendar.add(nextField, 1);
/* 238 */       reset(calendar, Arrays.asList(new Integer[] { Integer.valueOf(field) }));
/* 239 */       nextValue = bits.nextSetBit(0);
/*     */     }
/* 241 */     if (nextValue != value) {
/* 242 */       calendar.set(field, nextValue);
/* 243 */       reset(calendar, lowerOrders);
/*     */     }
/* 245 */     return nextValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void reset(Calendar calendar, List<Integer> fields)
/*     */   {
/* 252 */     for (Iterator localIterator = fields.iterator(); localIterator.hasNext();) { int field = ((Integer)localIterator.next()).intValue();
/* 253 */       calendar.set(field, field == 5 ? 1 : 0);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void parse(String expression)
/*     */     throws IllegalArgumentException
/*     */   {
/* 264 */     String[] fields = StringUtils.tokenizeToStringArray(expression, " ");
/* 265 */     if (!areValidCronFields(fields)) {
/* 266 */       throw new IllegalArgumentException(String.format("Cron expression must consist of 6 fields (found %d in \"%s\")", new Object[] {
/* 267 */         Integer.valueOf(fields.length), expression }));
/*     */     }
/* 269 */     setNumberHits(this.seconds, fields[0], 0, 60);
/* 270 */     setNumberHits(this.minutes, fields[1], 0, 60);
/* 271 */     setNumberHits(this.hours, fields[2], 0, 24);
/* 272 */     setDaysOfMonth(this.daysOfMonth, fields[3]);
/* 273 */     setMonths(this.months, fields[4]);
/* 274 */     setDays(this.daysOfWeek, replaceOrdinals(fields[5], "SUN,MON,TUE,WED,THU,FRI,SAT"), 8);
/* 275 */     if (this.daysOfWeek.get(7))
/*     */     {
/* 277 */       this.daysOfWeek.set(0);
/* 278 */       this.daysOfWeek.clear(7);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String replaceOrdinals(String value, String commaSeparatedList)
/*     */   {
/* 288 */     String[] list = StringUtils.commaDelimitedListToStringArray(commaSeparatedList);
/* 289 */     for (int i = 0; i < list.length; i++) {
/* 290 */       String item = list[i].toUpperCase();
/* 291 */       value = StringUtils.replace(value.toUpperCase(), item, "" + i);
/*     */     }
/* 293 */     return value;
/*     */   }
/*     */   
/*     */   private void setDaysOfMonth(BitSet bits, String field) {
/* 297 */     int max = 31;
/*     */     
/* 299 */     setDays(bits, field, max + 1);
/*     */     
/* 301 */     bits.clear(0);
/*     */   }
/*     */   
/*     */   private void setDays(BitSet bits, String field, int max) {
/* 305 */     if (field.contains("?")) {
/* 306 */       field = "*";
/*     */     }
/* 308 */     setNumberHits(bits, field, 0, max);
/*     */   }
/*     */   
/*     */   private void setMonths(BitSet bits, String value) {
/* 312 */     int max = 12;
/* 313 */     value = replaceOrdinals(value, "FOO,JAN,FEB,MAR,APR,MAY,JUN,JUL,AUG,SEP,OCT,NOV,DEC");
/* 314 */     BitSet months = new BitSet(13);
/*     */     
/* 316 */     setNumberHits(months, value, 1, max + 1);
/*     */     
/* 318 */     for (int i = 1; i <= max; i++) {
/* 319 */       if (months.get(i)) {
/* 320 */         bits.set(i - 1);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void setNumberHits(BitSet bits, String value, int min, int max) {
/* 326 */     String[] fields = StringUtils.delimitedListToStringArray(value, ",");
/* 327 */     for (String field : fields) {
/* 328 */       if (!field.contains("/"))
/*     */       {
/* 330 */         int[] range = getRange(field, min, max);
/* 331 */         bits.set(range[0], range[1] + 1);
/*     */       }
/*     */       else {
/* 334 */         String[] split = StringUtils.delimitedListToStringArray(field, "/");
/* 335 */         if (split.length > 2) {
/* 336 */           throw new IllegalArgumentException("Incrementer has more than two fields: '" + field + "' in expression \"" + this.expression + "\"");
/*     */         }
/*     */         
/* 339 */         int[] range = getRange(split[0], min, max);
/* 340 */         if (!split[0].contains("-")) {
/* 341 */           range[1] = (max - 1);
/*     */         }
/* 343 */         int delta = Integer.valueOf(split[1]).intValue();
/* 344 */         if (delta <= 0) {
/* 345 */           throw new IllegalArgumentException("Incrementer delta must be 1 or higher: '" + field + "' in expression \"" + this.expression + "\"");
/*     */         }
/*     */         
/* 348 */         for (int i = range[0]; i <= range[1]; i += delta) {
/* 349 */           bits.set(i);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private int[] getRange(String field, int min, int max) {
/* 356 */     int[] result = new int[2];
/* 357 */     if (field.contains("*")) {
/* 358 */       result[0] = min;
/* 359 */       result[1] = (max - 1);
/* 360 */       return result;
/*     */     }
/* 362 */     if (!field.contains("-")) {
/* 363 */       result[0] = (result[1] = Integer.valueOf(field).intValue());
/*     */     }
/*     */     else {
/* 366 */       String[] split = StringUtils.delimitedListToStringArray(field, "-");
/* 367 */       if (split.length > 2) {
/* 368 */         throw new IllegalArgumentException("Range has more than two fields: '" + field + "' in expression \"" + this.expression + "\"");
/*     */       }
/*     */       
/* 371 */       result[0] = Integer.valueOf(split[0]).intValue();
/* 372 */       result[1] = Integer.valueOf(split[1]).intValue();
/*     */     }
/* 374 */     if ((result[0] >= max) || (result[1] >= max)) {
/* 375 */       throw new IllegalArgumentException("Range exceeds maximum (" + max + "): '" + field + "' in expression \"" + this.expression + "\"");
/*     */     }
/*     */     
/* 378 */     if ((result[0] < min) || (result[1] < min)) {
/* 379 */       throw new IllegalArgumentException("Range less than minimum (" + min + "): '" + field + "' in expression \"" + this.expression + "\"");
/*     */     }
/*     */     
/* 382 */     if (result[0] > result[1]) {
/* 383 */       throw new IllegalArgumentException("Invalid inverted range: '" + field + "' in expression \"" + this.expression + "\"");
/*     */     }
/*     */     
/* 386 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isValidExpression(String expression)
/*     */   {
/* 399 */     String[] fields = StringUtils.tokenizeToStringArray(expression, " ");
/* 400 */     return areValidCronFields(fields);
/*     */   }
/*     */   
/*     */   private static boolean areValidCronFields(String[] fields) {
/* 404 */     return (fields != null) && (fields.length == 6);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 410 */     if (this == other) {
/* 411 */       return true;
/*     */     }
/* 413 */     if (!(other instanceof CronSequenceGenerator)) {
/* 414 */       return false;
/*     */     }
/* 416 */     CronSequenceGenerator otherCron = (CronSequenceGenerator)other;
/*     */     
/*     */ 
/* 419 */     return (this.months.equals(otherCron.months)) && (this.daysOfMonth.equals(otherCron.daysOfMonth)) && (this.daysOfWeek.equals(otherCron.daysOfWeek)) && (this.hours.equals(otherCron.hours)) && (this.minutes.equals(otherCron.minutes)) && (this.seconds.equals(otherCron.seconds));
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 425 */     return 17 * this.months.hashCode() + 29 * this.daysOfMonth.hashCode() + 37 * this.daysOfWeek.hashCode() + 41 * this.hours.hashCode() + 53 * this.minutes.hashCode() + 61 * this.seconds.hashCode();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 430 */     return getClass().getSimpleName() + ": " + this.expression;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\scheduling\support\CronSequenceGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */