/*     */ package org.springframework.cache.annotation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.springframework.cache.interceptor.CacheEvictOperation;
/*     */ import org.springframework.cache.interceptor.CacheEvictOperation.Builder;
/*     */ import org.springframework.cache.interceptor.CacheOperation;
/*     */ import org.springframework.cache.interceptor.CacheOperation.Builder;
/*     */ import org.springframework.cache.interceptor.CachePutOperation;
/*     */ import org.springframework.cache.interceptor.CachePutOperation.Builder;
/*     */ import org.springframework.cache.interceptor.CacheableOperation;
/*     */ import org.springframework.cache.interceptor.CacheableOperation.Builder;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringCacheAnnotationParser
/*     */   implements CacheAnnotationParser, Serializable
/*     */ {
/*     */   public Collection<CacheOperation> parseCacheAnnotations(Class<?> type)
/*     */   {
/*  52 */     DefaultCacheConfig defaultConfig = getDefaultCacheConfig(type);
/*  53 */     return parseCacheAnnotations(defaultConfig, type);
/*     */   }
/*     */   
/*     */   public Collection<CacheOperation> parseCacheAnnotations(Method method)
/*     */   {
/*  58 */     DefaultCacheConfig defaultConfig = getDefaultCacheConfig(method.getDeclaringClass());
/*  59 */     return parseCacheAnnotations(defaultConfig, method);
/*     */   }
/*     */   
/*     */   protected Collection<CacheOperation> parseCacheAnnotations(DefaultCacheConfig cachingConfig, AnnotatedElement ae) {
/*  63 */     Collection<CacheOperation> ops = null;
/*     */     
/*  65 */     Collection<Cacheable> cacheables = AnnotatedElementUtils.findAllMergedAnnotations(ae, Cacheable.class);
/*  66 */     Iterator localIterator; if (!cacheables.isEmpty()) {
/*  67 */       ops = lazyInit(ops);
/*  68 */       for (localIterator = cacheables.iterator(); localIterator.hasNext();) { cacheable = (Cacheable)localIterator.next();
/*  69 */         ops.add(parseCacheableAnnotation(ae, cachingConfig, cacheable));
/*     */       } }
/*     */     Cacheable cacheable;
/*  72 */     Object evicts = AnnotatedElementUtils.findAllMergedAnnotations(ae, CacheEvict.class);
/*  73 */     if (!((Collection)evicts).isEmpty()) {
/*  74 */       ops = lazyInit(ops);
/*  75 */       for (cacheable = ((Collection)evicts).iterator(); cacheable.hasNext();) { evict = (CacheEvict)cacheable.next();
/*  76 */         ops.add(parseEvictAnnotation(ae, cachingConfig, evict));
/*     */       } }
/*     */     CacheEvict evict;
/*  79 */     Collection<CachePut> puts = AnnotatedElementUtils.findAllMergedAnnotations(ae, CachePut.class);
/*  80 */     if (!puts.isEmpty()) {
/*  81 */       ops = lazyInit(ops);
/*  82 */       for (evict = puts.iterator(); evict.hasNext();) { put = (CachePut)evict.next();
/*  83 */         ops.add(parsePutAnnotation(ae, cachingConfig, put));
/*     */       } }
/*     */     CachePut put;
/*  86 */     Collection<Caching> cachings = AnnotatedElementUtils.findAllMergedAnnotations(ae, Caching.class);
/*  87 */     if (!cachings.isEmpty()) {
/*  88 */       ops = lazyInit(ops);
/*  89 */       for (Caching caching : cachings) {
/*  90 */         Collection<CacheOperation> cachingOps = parseCachingAnnotation(ae, cachingConfig, caching);
/*  91 */         if (cachingOps != null) {
/*  92 */           ops.addAll(cachingOps);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  97 */     return ops;
/*     */   }
/*     */   
/*     */   private <T extends Annotation> Collection<CacheOperation> lazyInit(Collection<CacheOperation> ops) {
/* 101 */     return ops != null ? ops : new ArrayList(1);
/*     */   }
/*     */   
/*     */   CacheableOperation parseCacheableAnnotation(AnnotatedElement ae, DefaultCacheConfig defaultConfig, Cacheable cacheable) {
/* 105 */     CacheableOperation.Builder builder = new CacheableOperation.Builder();
/*     */     
/* 107 */     builder.setName(ae.toString());
/* 108 */     builder.setCacheNames(cacheable.cacheNames());
/* 109 */     builder.setCondition(cacheable.condition());
/* 110 */     builder.setUnless(cacheable.unless());
/* 111 */     builder.setKey(cacheable.key());
/* 112 */     builder.setKeyGenerator(cacheable.keyGenerator());
/* 113 */     builder.setCacheManager(cacheable.cacheManager());
/* 114 */     builder.setCacheResolver(cacheable.cacheResolver());
/* 115 */     builder.setSync(cacheable.sync());
/*     */     
/* 117 */     defaultConfig.applyDefault(builder);
/* 118 */     CacheableOperation op = builder.build();
/* 119 */     validateCacheOperation(ae, op);
/*     */     
/* 121 */     return op;
/*     */   }
/*     */   
/*     */   CacheEvictOperation parseEvictAnnotation(AnnotatedElement ae, DefaultCacheConfig defaultConfig, CacheEvict cacheEvict) {
/* 125 */     CacheEvictOperation.Builder builder = new CacheEvictOperation.Builder();
/*     */     
/* 127 */     builder.setName(ae.toString());
/* 128 */     builder.setCacheNames(cacheEvict.cacheNames());
/* 129 */     builder.setCondition(cacheEvict.condition());
/* 130 */     builder.setKey(cacheEvict.key());
/* 131 */     builder.setKeyGenerator(cacheEvict.keyGenerator());
/* 132 */     builder.setCacheManager(cacheEvict.cacheManager());
/* 133 */     builder.setCacheResolver(cacheEvict.cacheResolver());
/* 134 */     builder.setCacheWide(cacheEvict.allEntries());
/* 135 */     builder.setBeforeInvocation(cacheEvict.beforeInvocation());
/*     */     
/* 137 */     defaultConfig.applyDefault(builder);
/* 138 */     CacheEvictOperation op = builder.build();
/* 139 */     validateCacheOperation(ae, op);
/*     */     
/* 141 */     return op;
/*     */   }
/*     */   
/*     */   CacheOperation parsePutAnnotation(AnnotatedElement ae, DefaultCacheConfig defaultConfig, CachePut cachePut) {
/* 145 */     CachePutOperation.Builder builder = new CachePutOperation.Builder();
/*     */     
/* 147 */     builder.setName(ae.toString());
/* 148 */     builder.setCacheNames(cachePut.cacheNames());
/* 149 */     builder.setCondition(cachePut.condition());
/* 150 */     builder.setUnless(cachePut.unless());
/* 151 */     builder.setKey(cachePut.key());
/* 152 */     builder.setKeyGenerator(cachePut.keyGenerator());
/* 153 */     builder.setCacheManager(cachePut.cacheManager());
/* 154 */     builder.setCacheResolver(cachePut.cacheResolver());
/*     */     
/* 156 */     defaultConfig.applyDefault(builder);
/* 157 */     CachePutOperation op = builder.build();
/* 158 */     validateCacheOperation(ae, op);
/*     */     
/* 160 */     return op;
/*     */   }
/*     */   
/*     */   Collection<CacheOperation> parseCachingAnnotation(AnnotatedElement ae, DefaultCacheConfig defaultConfig, Caching caching) {
/* 164 */     Collection<CacheOperation> ops = null;
/*     */     
/* 166 */     Cacheable[] cacheables = caching.cacheable();
/* 167 */     Object localObject; Cacheable cacheable; if (!ObjectUtils.isEmpty(cacheables)) {
/* 168 */       ops = lazyInit(ops);
/* 169 */       Cacheable[] arrayOfCacheable1 = cacheables;int i = arrayOfCacheable1.length; for (localObject = 0; localObject < i; localObject++) { cacheable = arrayOfCacheable1[localObject];
/* 170 */         ops.add(parseCacheableAnnotation(ae, defaultConfig, cacheable));
/*     */       }
/*     */     }
/* 173 */     CacheEvict[] cacheEvicts = caching.evict();
/* 174 */     CacheEvict cacheEvict; if (!ObjectUtils.isEmpty(cacheEvicts)) {
/* 175 */       ops = lazyInit(ops);
/* 176 */       CacheEvict[] arrayOfCacheEvict1 = cacheEvicts;localObject = arrayOfCacheEvict1.length; for (cacheable = 0; cacheable < localObject; cacheable++) { cacheEvict = arrayOfCacheEvict1[cacheable];
/* 177 */         ops.add(parseEvictAnnotation(ae, defaultConfig, cacheEvict));
/*     */       }
/*     */     }
/* 180 */     CachePut[] cachePuts = caching.put();
/* 181 */     if (!ObjectUtils.isEmpty(cachePuts)) {
/* 182 */       ops = lazyInit(ops);
/* 183 */       localObject = cachePuts;cacheable = localObject.length; for (cacheEvict = 0; cacheEvict < cacheable; cacheEvict++) { CachePut cachePut = localObject[cacheEvict];
/* 184 */         ops.add(parsePutAnnotation(ae, defaultConfig, cachePut));
/*     */       }
/*     */     }
/*     */     
/* 188 */     return ops;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   DefaultCacheConfig getDefaultCacheConfig(Class<?> target)
/*     */   {
/* 197 */     CacheConfig annotation = (CacheConfig)AnnotationUtils.getAnnotation(target, CacheConfig.class);
/* 198 */     if (annotation != null)
/*     */     {
/* 200 */       return new DefaultCacheConfig(annotation.cacheNames(), annotation.keyGenerator(), annotation.cacheManager(), annotation.cacheResolver(), null);
/*     */     }
/* 202 */     return new DefaultCacheConfig();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void validateCacheOperation(AnnotatedElement ae, CacheOperation operation)
/*     */   {
/* 214 */     if ((StringUtils.hasText(operation.getKey())) && (StringUtils.hasText(operation.getKeyGenerator())))
/*     */     {
/* 216 */       throw new IllegalStateException("Invalid cache annotation configuration on '" + ae.toString() + "'. Both 'key' and 'keyGenerator' attributes have been set. " + "These attributes are mutually exclusive: either set the SpEL expression used to" + "compute the key at runtime or set the name of the KeyGenerator bean to use.");
/*     */     }
/*     */     
/*     */ 
/* 220 */     if ((StringUtils.hasText(operation.getCacheManager())) && (StringUtils.hasText(operation.getCacheResolver())))
/*     */     {
/* 222 */       throw new IllegalStateException("Invalid cache annotation configuration on '" + ae.toString() + "'. Both 'cacheManager' and 'cacheResolver' attributes have been set. " + "These attributes are mutually exclusive: the cache manager is used to configure a" + "default cache resolver if none is set. If a cache resolver is set, the cache manager" + "won't be used.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 231 */     return (this == other) || ((other instanceof SpringCacheAnnotationParser));
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 236 */     return SpringCacheAnnotationParser.class.hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static class DefaultCacheConfig
/*     */   {
/*     */     private final String[] cacheNames;
/*     */     
/*     */     private final String keyGenerator;
/*     */     
/*     */     private final String cacheManager;
/*     */     
/*     */     private final String cacheResolver;
/*     */     
/*     */ 
/*     */     public DefaultCacheConfig()
/*     */     {
/* 254 */       this(null, null, null, null);
/*     */     }
/*     */     
/*     */     private DefaultCacheConfig(String[] cacheNames, String keyGenerator, String cacheManager, String cacheResolver) {
/* 258 */       this.cacheNames = cacheNames;
/* 259 */       this.keyGenerator = keyGenerator;
/* 260 */       this.cacheManager = cacheManager;
/* 261 */       this.cacheResolver = cacheResolver;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void applyDefault(CacheOperation.Builder builder)
/*     */     {
/* 269 */       if ((builder.getCacheNames().isEmpty()) && (this.cacheNames != null)) {
/* 270 */         builder.setCacheNames(this.cacheNames);
/*     */       }
/* 272 */       if ((!StringUtils.hasText(builder.getKey())) && (!StringUtils.hasText(builder.getKeyGenerator())) && 
/* 273 */         (StringUtils.hasText(this.keyGenerator))) {
/* 274 */         builder.setKeyGenerator(this.keyGenerator);
/*     */       }
/*     */       
/* 277 */       if ((!StringUtils.hasText(builder.getCacheManager())) && (!StringUtils.hasText(builder.getCacheResolver())))
/*     */       {
/*     */ 
/* 280 */         if (StringUtils.hasText(this.cacheResolver)) {
/* 281 */           builder.setCacheResolver(this.cacheResolver);
/*     */         }
/* 283 */         else if (StringUtils.hasText(this.cacheManager)) {
/* 284 */           builder.setCacheManager(this.cacheManager);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\cache\annotation\SpringCacheAnnotationParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */