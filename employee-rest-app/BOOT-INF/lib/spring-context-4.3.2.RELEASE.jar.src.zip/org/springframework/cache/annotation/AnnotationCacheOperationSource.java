/*     */ package org.springframework.cache.annotation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.cache.interceptor.AbstractFallbackCacheOperationSource;
/*     */ import org.springframework.cache.interceptor.CacheOperation;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationCacheOperationSource
/*     */   extends AbstractFallbackCacheOperationSource
/*     */   implements Serializable
/*     */ {
/*     */   private final boolean publicMethodsOnly;
/*     */   private final Set<CacheAnnotationParser> annotationParsers;
/*     */   
/*     */   public AnnotationCacheOperationSource()
/*     */   {
/*  59 */     this(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationCacheOperationSource(boolean publicMethodsOnly)
/*     */   {
/*  70 */     this.publicMethodsOnly = publicMethodsOnly;
/*  71 */     this.annotationParsers = new LinkedHashSet(1);
/*  72 */     this.annotationParsers.add(new SpringCacheAnnotationParser());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationCacheOperationSource(CacheAnnotationParser annotationParser)
/*     */   {
/*  80 */     this.publicMethodsOnly = true;
/*  81 */     Assert.notNull(annotationParser, "CacheAnnotationParser must not be null");
/*  82 */     this.annotationParsers = Collections.singleton(annotationParser);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationCacheOperationSource(CacheAnnotationParser... annotationParsers)
/*     */   {
/*  90 */     this.publicMethodsOnly = true;
/*  91 */     Assert.notEmpty(annotationParsers, "At least one CacheAnnotationParser needs to be specified");
/*  92 */     Set<CacheAnnotationParser> parsers = new LinkedHashSet(annotationParsers.length);
/*  93 */     Collections.addAll(parsers, annotationParsers);
/*  94 */     this.annotationParsers = parsers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationCacheOperationSource(Set<CacheAnnotationParser> annotationParsers)
/*     */   {
/* 102 */     this.publicMethodsOnly = true;
/* 103 */     Assert.notEmpty(annotationParsers, "At least one CacheAnnotationParser needs to be specified");
/* 104 */     this.annotationParsers = annotationParsers;
/*     */   }
/*     */   
/*     */ 
/*     */   protected Collection<CacheOperation> findCacheOperations(final Class<?> clazz)
/*     */   {
/* 110 */     determineCacheOperations(new CacheOperationProvider()
/*     */     {
/*     */       public Collection<CacheOperation> getCacheOperations(CacheAnnotationParser parser) {
/* 113 */         return parser.parseCacheAnnotations(clazz);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */   protected Collection<CacheOperation> findCacheOperations(final Method method)
/*     */   {
/* 121 */     determineCacheOperations(new CacheOperationProvider()
/*     */     {
/*     */       public Collection<CacheOperation> getCacheOperations(CacheAnnotationParser parser) {
/* 124 */         return parser.parseCacheAnnotations(method);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Collection<CacheOperation> determineCacheOperations(CacheOperationProvider provider)
/*     */   {
/* 140 */     Collection<CacheOperation> ops = null;
/* 141 */     for (CacheAnnotationParser annotationParser : this.annotationParsers) {
/* 142 */       Collection<CacheOperation> annOps = provider.getCacheOperations(annotationParser);
/* 143 */       if (annOps != null) {
/* 144 */         if (ops == null) {
/* 145 */           ops = new ArrayList();
/*     */         }
/* 147 */         ops.addAll(annOps);
/*     */       }
/*     */     }
/* 150 */     return ops;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean allowPublicMethodsOnly()
/*     */   {
/* 158 */     return this.publicMethodsOnly;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 164 */     if (this == other) {
/* 165 */       return true;
/*     */     }
/* 167 */     if (!(other instanceof AnnotationCacheOperationSource)) {
/* 168 */       return false;
/*     */     }
/* 170 */     AnnotationCacheOperationSource otherCos = (AnnotationCacheOperationSource)other;
/* 171 */     return (this.annotationParsers.equals(otherCos.annotationParsers)) && (this.publicMethodsOnly == otherCos.publicMethodsOnly);
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 177 */     return this.annotationParsers.hashCode();
/*     */   }
/*     */   
/*     */   protected static abstract interface CacheOperationProvider
/*     */   {
/*     */     public abstract Collection<CacheOperation> getCacheOperations(CacheAnnotationParser paramCacheAnnotationParser);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\cache\annotation\AnnotationCacheOperationSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */