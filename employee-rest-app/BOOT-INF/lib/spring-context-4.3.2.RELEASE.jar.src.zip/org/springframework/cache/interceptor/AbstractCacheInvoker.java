/*     */ package org.springframework.cache.interceptor;
/*     */ 
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.cache.Cache.ValueWrapper;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractCacheInvoker
/*     */ {
/*     */   private CacheErrorHandler errorHandler;
/*     */   
/*     */   protected AbstractCacheInvoker(CacheErrorHandler errorHandler)
/*     */   {
/*  35 */     Assert.notNull("ErrorHandler must not be null");
/*  36 */     this.errorHandler = errorHandler;
/*     */   }
/*     */   
/*     */   protected AbstractCacheInvoker() {
/*  40 */     this(new SimpleCacheErrorHandler());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setErrorHandler(CacheErrorHandler errorHandler)
/*     */   {
/*  49 */     this.errorHandler = errorHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CacheErrorHandler getErrorHandler()
/*     */   {
/*  56 */     return this.errorHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Cache.ValueWrapper doGet(Cache cache, Object key)
/*     */   {
/*     */     try
/*     */     {
/*  68 */       return cache.get(key);
/*     */     }
/*     */     catch (RuntimeException e) {
/*  71 */       getErrorHandler().handleCacheGetError(e, cache, key); }
/*  72 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doPut(Cache cache, Object key, Object result)
/*     */   {
/*     */     try
/*     */     {
/*  82 */       cache.put(key, result);
/*     */     }
/*     */     catch (RuntimeException e) {
/*  85 */       getErrorHandler().handleCachePutError(e, cache, key, result);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void doEvict(Cache cache, Object key)
/*     */   {
/*     */     try
/*     */     {
/*  95 */       cache.evict(key);
/*     */     }
/*     */     catch (RuntimeException e) {
/*  98 */       getErrorHandler().handleCacheEvictError(e, cache, key);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void doClear(Cache cache)
/*     */   {
/*     */     try
/*     */     {
/* 108 */       cache.clear();
/*     */     }
/*     */     catch (RuntimeException e) {
/* 111 */       getErrorHandler().handleCacheClearError(e, cache);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\cache\interceptor\AbstractCacheInvoker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */