/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import org.springframework.cache.CacheManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NamedCacheResolver
/*    */   extends AbstractCacheResolver
/*    */ {
/*    */   private Collection<String> cacheNames;
/*    */   
/*    */   public NamedCacheResolver(CacheManager cacheManager, String... cacheNames)
/*    */   {
/* 38 */     super(cacheManager);
/* 39 */     this.cacheNames = new ArrayList(Arrays.asList(cacheNames));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public NamedCacheResolver() {}
/*    */   
/*    */ 
/*    */   public void setCacheNames(Collection<String> cacheNames)
/*    */   {
/* 49 */     this.cacheNames = cacheNames;
/*    */   }
/*    */   
/*    */   protected Collection<String> getCacheNames(CacheOperationInvocationContext<?> context)
/*    */   {
/* 54 */     return this.cacheNames;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\cache\interceptor\NamedCacheResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */