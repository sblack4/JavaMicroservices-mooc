/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import org.springframework.aop.Pointcut;
/*    */ import org.springframework.aop.framework.AbstractSingletonProxyFactoryBean;
/*    */ import org.springframework.aop.support.DefaultPointcutAdvisor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheProxyFactoryBean
/*    */   extends AbstractSingletonProxyFactoryBean
/*    */ {
/* 45 */   private final CacheInterceptor cachingInterceptor = new CacheInterceptor();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private Pointcut pointcut;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setPointcut(Pointcut pointcut)
/*    */   {
/* 58 */     this.pointcut = pointcut;
/*    */   }
/*    */   
/*    */   protected Object createMainInterceptor()
/*    */   {
/* 63 */     this.cachingInterceptor.afterPropertiesSet();
/* 64 */     if (this.pointcut == null)
/*    */     {
/* 66 */       throw new UnsupportedOperationException();
/*    */     }
/* 68 */     return new DefaultPointcutAdvisor(this.pointcut, this.cachingInterceptor);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setCacheOperationSources(CacheOperationSource... cacheOperationSources)
/*    */   {
/* 75 */     this.cachingInterceptor.setCacheOperationSources(cacheOperationSources);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\cache\interceptor\CacheProxyFactoryBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */