/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CachePutOperation
/*    */   extends CacheOperation
/*    */ {
/*    */   private final String unless;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CachePutOperation(Builder b)
/*    */   {
/* 36 */     super(b);
/* 37 */     this.unless = b.unless;
/*    */   }
/*    */   
/*    */   public String getUnless()
/*    */   {
/* 42 */     return this.unless;
/*    */   }
/*    */   
/*    */ 
/*    */   public static class Builder
/*    */     extends CacheOperation.Builder
/*    */   {
/*    */     private String unless;
/*    */     
/*    */ 
/*    */     public void setUnless(String unless)
/*    */     {
/* 54 */       this.unless = unless;
/*    */     }
/*    */     
/*    */     protected StringBuilder getOperationDescription()
/*    */     {
/* 59 */       StringBuilder sb = super.getOperationDescription();
/* 60 */       sb.append(" | unless='");
/* 61 */       sb.append(this.unless);
/* 62 */       sb.append("'");
/* 63 */       return sb;
/*    */     }
/*    */     
/*    */     public CachePutOperation build() {
/* 67 */       return new CachePutOperation(this);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\cache\interceptor\CachePutOperation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */