/*     */ package org.springframework.cache.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.MethodClassKey;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractFallbackCacheOperationSource
/*     */   implements CacheOperationSource
/*     */ {
/*  58 */   private static final Collection<CacheOperation> NULL_CACHING_ATTRIBUTE = ;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  66 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  73 */   private final Map<Object, Collection<CacheOperation>> attributeCache = new ConcurrentHashMap(1024);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<CacheOperation> getCacheOperations(Method method, Class<?> targetClass)
/*     */   {
/*  87 */     Object cacheKey = getCacheKey(method, targetClass);
/*  88 */     Collection<CacheOperation> cached = (Collection)this.attributeCache.get(cacheKey);
/*     */     
/*  90 */     if (cached != null) {
/*  91 */       return cached != NULL_CACHING_ATTRIBUTE ? cached : null;
/*     */     }
/*     */     
/*  94 */     Collection<CacheOperation> cacheOps = computeCacheOperations(method, targetClass);
/*  95 */     if (cacheOps != null) {
/*  96 */       if (this.logger.isDebugEnabled()) {
/*  97 */         this.logger.debug("Adding cacheable method '" + method.getName() + "' with attribute: " + cacheOps);
/*     */       }
/*  99 */       this.attributeCache.put(cacheKey, cacheOps);
/*     */     }
/*     */     else {
/* 102 */       this.attributeCache.put(cacheKey, NULL_CACHING_ATTRIBUTE);
/*     */     }
/* 104 */     return cacheOps;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object getCacheKey(Method method, Class<?> targetClass)
/*     */   {
/* 117 */     return new MethodClassKey(method, targetClass);
/*     */   }
/*     */   
/*     */   private Collection<CacheOperation> computeCacheOperations(Method method, Class<?> targetClass)
/*     */   {
/* 122 */     if ((allowPublicMethodsOnly()) && (!Modifier.isPublic(method.getModifiers()))) {
/* 123 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 128 */     Method specificMethod = ClassUtils.getMostSpecificMethod(method, targetClass);
/*     */     
/* 130 */     specificMethod = BridgeMethodResolver.findBridgedMethod(specificMethod);
/*     */     
/*     */ 
/* 133 */     Collection<CacheOperation> opDef = findCacheOperations(specificMethod);
/* 134 */     if (opDef != null) {
/* 135 */       return opDef;
/*     */     }
/*     */     
/*     */ 
/* 139 */     opDef = findCacheOperations(specificMethod.getDeclaringClass());
/* 140 */     if ((opDef != null) && (ClassUtils.isUserLevelMethod(method))) {
/* 141 */       return opDef;
/*     */     }
/*     */     
/* 144 */     if (specificMethod != method)
/*     */     {
/* 146 */       opDef = findCacheOperations(method);
/* 147 */       if (opDef != null) {
/* 148 */         return opDef;
/*     */       }
/*     */       
/* 151 */       opDef = findCacheOperations(method.getDeclaringClass());
/* 152 */       if ((opDef != null) && (ClassUtils.isUserLevelMethod(method))) {
/* 153 */         return opDef;
/*     */       }
/*     */     }
/*     */     
/* 157 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract Collection<CacheOperation> findCacheOperations(Method paramMethod);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract Collection<CacheOperation> findCacheOperations(Class<?> paramClass);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean allowPublicMethodsOnly()
/*     */   {
/* 184 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\cache\interceptor\AbstractFallbackCacheOperationSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */