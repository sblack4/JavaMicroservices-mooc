/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.context.expression.MethodBasedEvaluationContext;
/*    */ import org.springframework.core.ParameterNameDiscoverer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CacheEvaluationContext
/*    */   extends MethodBasedEvaluationContext
/*    */ {
/*    */   private final List<String> unavailableVariables;
/*    */   
/*    */   CacheEvaluationContext(Object rootObject, Method method, Object[] args, ParameterNameDiscoverer paramDiscoverer)
/*    */   {
/* 50 */     super(rootObject, method, args, paramDiscoverer);
/* 51 */     this.unavailableVariables = new ArrayList();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void addUnavailableVariable(String name)
/*    */   {
/* 62 */     this.unavailableVariables.add(name);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object lookupVariable(String name)
/*    */   {
/* 71 */     if (this.unavailableVariables.contains(name)) {
/* 72 */       throw new VariableNotAvailableException(name);
/*    */     }
/* 74 */     return super.lookupVariable(name);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\cache\interceptor\CacheEvaluationContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */