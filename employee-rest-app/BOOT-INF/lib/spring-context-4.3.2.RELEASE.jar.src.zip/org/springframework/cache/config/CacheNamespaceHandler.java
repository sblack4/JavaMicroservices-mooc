/*    */ package org.springframework.cache.config;
/*    */ 
/*    */ import org.springframework.beans.MutablePropertyValues;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*    */ import org.springframework.beans.factory.xml.NamespaceHandlerSupport;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheNamespaceHandler
/*    */   extends NamespaceHandlerSupport
/*    */ {
/*    */   static final String CACHE_MANAGER_ATTRIBUTE = "cache-manager";
/*    */   static final String DEFAULT_CACHE_MANAGER_BEAN_NAME = "cacheManager";
/*    */   
/*    */   static String extractCacheManager(Element element)
/*    */   {
/* 44 */     return element.hasAttribute("cache-manager") ? element.getAttribute("cache-manager") : "cacheManager";
/*    */   }
/*    */   
/*    */   static BeanDefinition parseKeyGenerator(Element element, BeanDefinition def)
/*    */   {
/* 49 */     String name = element.getAttribute("key-generator");
/* 50 */     if (StringUtils.hasText(name)) {
/* 51 */       def.getPropertyValues().add("keyGenerator", new RuntimeBeanReference(name.trim()));
/*    */     }
/* 53 */     return def;
/*    */   }
/*    */   
/*    */   public void init()
/*    */   {
/* 58 */     registerBeanDefinitionParser("annotation-driven", new AnnotationDrivenCacheBeanDefinitionParser());
/* 59 */     registerBeanDefinitionParser("advice", new CacheAdviceParser());
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\cache\config\CacheNamespaceHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */