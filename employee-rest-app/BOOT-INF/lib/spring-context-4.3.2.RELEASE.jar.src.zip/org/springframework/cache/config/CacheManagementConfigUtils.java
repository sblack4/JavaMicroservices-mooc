package org.springframework.cache.config;

public class CacheManagementConfigUtils
{
  public static final String CACHE_ADVISOR_BEAN_NAME = "org.springframework.cache.config.internalCacheAdvisor";
  public static final String CACHE_ASPECT_BEAN_NAME = "org.springframework.cache.config.internalCacheAspect";
  public static final String JCACHE_ADVISOR_BEAN_NAME = "org.springframework.cache.config.internalJCacheAdvisor";
  public static final String JCACHE_ASPECT_BEAN_NAME = "org.springframework.cache.config.internalJCacheAspect";
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\cache\config\CacheManagementConfigUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */