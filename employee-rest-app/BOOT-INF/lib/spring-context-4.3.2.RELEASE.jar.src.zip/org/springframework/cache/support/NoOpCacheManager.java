/*     */ package org.springframework.cache.support;
/*     */ 
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.cache.Cache.ValueRetrievalException;
/*     */ import org.springframework.cache.Cache.ValueWrapper;
/*     */ import org.springframework.cache.CacheManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NoOpCacheManager
/*     */   implements CacheManager
/*     */ {
/*  44 */   private final ConcurrentMap<String, Cache> caches = new ConcurrentHashMap(16);
/*     */   
/*  46 */   private final Set<String> cacheNames = new LinkedHashSet(16);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cache getCache(String name)
/*     */   {
/*  55 */     Cache cache = (Cache)this.caches.get(name);
/*  56 */     if (cache == null) {
/*  57 */       this.caches.putIfAbsent(name, new NoOpCache(name));
/*  58 */       synchronized (this.cacheNames) {
/*  59 */         this.cacheNames.add(name);
/*     */       }
/*     */     }
/*     */     
/*  63 */     return (Cache)this.caches.get(name);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public java.util.Collection<String> getCacheNames()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 7	org/springframework/cache/support/NoOpCacheManager:cacheNames	Ljava/util/Set;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 7	org/springframework/cache/support/NoOpCacheManager:cacheNames	Ljava/util/Set;
/*     */     //   11: invokestatic 14	java/util/Collections:unmodifiableSet	(Ljava/util/Set;)Ljava/util/Set;
/*     */     //   14: aload_1
/*     */     //   15: monitorexit
/*     */     //   16: areturn
/*     */     //   17: astore_2
/*     */     //   18: aload_1
/*     */     //   19: monitorexit
/*     */     //   20: aload_2
/*     */     //   21: athrow
/*     */     // Line number table:
/*     */     //   Java source line #71	-> byte code offset #0
/*     */     //   Java source line #72	-> byte code offset #7
/*     */     //   Java source line #73	-> byte code offset #17
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	22	0	this	NoOpCacheManager
/*     */     //   5	14	1	Ljava/lang/Object;	Object
/*     */     //   17	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	16	17	finally
/*     */     //   17	20	17	finally
/*     */   }
/*     */   
/*     */   private static class NoOpCache
/*     */     implements Cache
/*     */   {
/*     */     private final String name;
/*     */     
/*     */     public NoOpCache(String name)
/*     */     {
/*  82 */       this.name = name;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void clear() {}
/*     */     
/*     */ 
/*     */     public void evict(Object key) {}
/*     */     
/*     */ 
/*     */     public Cache.ValueWrapper get(Object key)
/*     */     {
/*  95 */       return null;
/*     */     }
/*     */     
/*     */     public <T> T get(Object key, Class<T> type)
/*     */     {
/* 100 */       return null;
/*     */     }
/*     */     
/*     */     public <T> T get(Object key, Callable<T> valueLoader)
/*     */     {
/*     */       try {
/* 106 */         return (T)valueLoader.call();
/*     */       }
/*     */       catch (Exception ex) {
/* 109 */         throw new Cache.ValueRetrievalException(key, valueLoader, ex);
/*     */       }
/*     */     }
/*     */     
/*     */     public String getName()
/*     */     {
/* 115 */       return this.name;
/*     */     }
/*     */     
/*     */     public Object getNativeCache()
/*     */     {
/* 120 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */     public void put(Object key, Object value) {}
/*     */     
/*     */ 
/*     */     public Cache.ValueWrapper putIfAbsent(Object key, Object value)
/*     */     {
/* 129 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-context-4.3.2.RELEASE.jar!\org\springframework\cache\support\NoOpCacheManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */