/*     */ package org.springframework.boot.autoconfigure.jms.activemq;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.DeprecatedConfigurationProperty;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.activemq")
/*     */ public class ActiveMQProperties
/*     */ {
/*     */   private String brokerUrl;
/*  45 */   private boolean inMemory = true;
/*     */   
/*     */ 
/*     */ 
/*     */   private String user;
/*     */   
/*     */ 
/*     */ 
/*     */   private String password;
/*     */   
/*     */ 
/*     */ 
/*  57 */   private Pool pool = new Pool();
/*     */   
/*  59 */   private Packages packages = new Packages();
/*     */   
/*     */   public String getBrokerUrl() {
/*  62 */     return this.brokerUrl;
/*     */   }
/*     */   
/*     */   public void setBrokerUrl(String brokerUrl) {
/*  66 */     this.brokerUrl = brokerUrl;
/*     */   }
/*     */   
/*     */   public boolean isInMemory() {
/*  70 */     return this.inMemory;
/*     */   }
/*     */   
/*     */   public void setInMemory(boolean inMemory) {
/*  74 */     this.inMemory = inMemory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   @DeprecatedConfigurationProperty(replacement="spring.activemq.pool.enabled")
/*     */   public boolean isPooled()
/*     */   {
/*  85 */     return getPool().isEnabled();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void setPooled(boolean pooled)
/*     */   {
/*  95 */     getPool().setEnabled(pooled);
/*     */   }
/*     */   
/*     */   public String getUser() {
/*  99 */     return this.user;
/*     */   }
/*     */   
/*     */   public void setUser(String user) {
/* 103 */     this.user = user;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 107 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 111 */     this.password = password;
/*     */   }
/*     */   
/*     */   public Pool getPool() {
/* 115 */     return this.pool;
/*     */   }
/*     */   
/*     */   public void setPool(Pool pool) {
/* 119 */     this.pool = pool;
/*     */   }
/*     */   
/*     */   public Packages getPackages() {
/* 123 */     return this.packages;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Pool
/*     */   {
/*     */     private boolean enabled;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 137 */     private int maxConnections = 1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 142 */     private int idleTimeout = 30000;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 147 */     private long expiryTimeout = 0L;
/*     */     
/*     */     public boolean isEnabled() {
/* 150 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 154 */       this.enabled = enabled;
/*     */     }
/*     */     
/*     */     public int getMaxConnections() {
/* 158 */       return this.maxConnections;
/*     */     }
/*     */     
/*     */     public void setMaxConnections(int maxConnections) {
/* 162 */       this.maxConnections = maxConnections;
/*     */     }
/*     */     
/*     */     public int getIdleTimeout() {
/* 166 */       return this.idleTimeout;
/*     */     }
/*     */     
/*     */     public void setIdleTimeout(int idleTimeout) {
/* 170 */       this.idleTimeout = idleTimeout;
/*     */     }
/*     */     
/*     */     public long getExpiryTimeout() {
/* 174 */       return this.expiryTimeout;
/*     */     }
/*     */     
/*     */     public void setExpiryTimeout(long expiryTimeout) {
/* 178 */       this.expiryTimeout = expiryTimeout;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Packages
/*     */   {
/*     */     private Boolean trustAll;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 194 */     private List<String> trusted = new ArrayList();
/*     */     
/*     */     public Boolean getTrustAll() {
/* 197 */       return this.trustAll;
/*     */     }
/*     */     
/*     */     public void setTrustAll(Boolean trustAll) {
/* 201 */       this.trustAll = trustAll;
/*     */     }
/*     */     
/*     */     public List<String> getTrusted() {
/* 205 */       return this.trusted;
/*     */     }
/*     */     
/*     */     public void setTrusted(List<String> trusted) {
/* 209 */       this.trusted = trusted;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jms\activemq\ActiveMQProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */