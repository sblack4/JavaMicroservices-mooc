/*     */ package org.springframework.boot.autoconfigure.jms.hornetq;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.hornetq.api.core.TransportConfiguration;
/*     */ import org.hornetq.api.core.client.HornetQClient;
/*     */ import org.hornetq.api.core.client.ServerLocator;
/*     */ import org.hornetq.core.remoting.impl.invm.InVMConnectorFactory;
/*     */ import org.hornetq.core.remoting.impl.netty.NettyConnectorFactory;
/*     */ import org.hornetq.jms.client.HornetQConnectionFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ class HornetQConnectionFactoryFactory
/*     */ {
/*     */   static final String EMBEDDED_JMS_CLASS = "org.hornetq.jms.server.embedded.EmbeddedJMS";
/*     */   private final HornetQProperties properties;
/*     */   private final ListableBeanFactory beanFactory;
/*     */   
/*     */   HornetQConnectionFactoryFactory(ListableBeanFactory beanFactory, HornetQProperties properties)
/*     */   {
/*  56 */     Assert.notNull(beanFactory, "BeanFactory must not be null");
/*  57 */     Assert.notNull(properties, "Properties must not be null");
/*  58 */     this.beanFactory = beanFactory;
/*  59 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   public <T extends HornetQConnectionFactory> T createConnectionFactory(Class<T> factoryClass)
/*     */   {
/*     */     try {
/*  65 */       startEmbeddedJms();
/*  66 */       return doCreateConnectionFactory(factoryClass);
/*     */     }
/*     */     catch (Exception ex) {
/*  69 */       throw new IllegalStateException("Unable to create HornetQConnectionFactory", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private void startEmbeddedJms()
/*     */   {
/*  75 */     if (ClassUtils.isPresent("org.hornetq.jms.server.embedded.EmbeddedJMS", null)) {
/*     */       try {
/*  77 */         this.beanFactory.getBeansOfType(Class.forName("org.hornetq.jms.server.embedded.EmbeddedJMS"));
/*     */       }
/*     */       catch (Exception localException) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private <T extends HornetQConnectionFactory> T doCreateConnectionFactory(Class<T> factoryClass)
/*     */     throws Exception
/*     */   {
/*  87 */     HornetQMode mode = this.properties.getMode();
/*  88 */     if (mode == null) {
/*  89 */       mode = deduceMode();
/*     */     }
/*  91 */     if (mode == HornetQMode.EMBEDDED) {
/*  92 */       return createEmbeddedConnectionFactory(factoryClass);
/*     */     }
/*  94 */     return createNativeConnectionFactory(factoryClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private HornetQMode deduceMode()
/*     */   {
/* 102 */     if ((this.properties.getEmbedded().isEnabled()) && 
/* 103 */       (ClassUtils.isPresent("org.hornetq.jms.server.embedded.EmbeddedJMS", null))) {
/* 104 */       return HornetQMode.EMBEDDED;
/*     */     }
/* 106 */     return HornetQMode.NATIVE;
/*     */   }
/*     */   
/*     */   private <T extends HornetQConnectionFactory> T createEmbeddedConnectionFactory(Class<T> factoryClass)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 114 */       TransportConfiguration transportConfiguration = new TransportConfiguration(InVMConnectorFactory.class.getName(), this.properties.getEmbedded().generateTransportParameters());
/*     */       
/* 116 */       ServerLocator serviceLocator = HornetQClient.createServerLocatorWithoutHA(new TransportConfiguration[] { transportConfiguration });
/*     */       
/* 118 */       Constructor<T> constructor = factoryClass.getDeclaredConstructor(new Class[] { HornetQProperties.class, ServerLocator.class });
/* 119 */       return (HornetQConnectionFactory)BeanUtils.instantiateClass(constructor, new Object[] { this.properties, serviceLocator });
/*     */     }
/*     */     catch (NoClassDefFoundError ex)
/*     */     {
/* 123 */       throw new IllegalStateException("Unable to create InVM HornetQ connection, ensure that hornet-jms-server.jar is in the classpath", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private <T extends HornetQConnectionFactory> T createNativeConnectionFactory(Class<T> factoryClass)
/*     */     throws Exception
/*     */   {
/* 131 */     Map<String, Object> params = new HashMap();
/* 132 */     params.put("host", this.properties.getHost());
/* 133 */     params.put("port", Integer.valueOf(this.properties.getPort()));
/*     */     
/* 135 */     TransportConfiguration transportConfiguration = new TransportConfiguration(NettyConnectorFactory.class.getName(), params);
/* 136 */     Constructor<T> constructor = factoryClass.getDeclaredConstructor(new Class[] { HornetQProperties.class, Boolean.TYPE, TransportConfiguration[].class });
/*     */     
/* 138 */     return (HornetQConnectionFactory)BeanUtils.instantiateClass(constructor, new Object[] { this.properties, Boolean.valueOf(false), { transportConfiguration } });
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jms\hornetq\HornetQConnectionFactoryFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */