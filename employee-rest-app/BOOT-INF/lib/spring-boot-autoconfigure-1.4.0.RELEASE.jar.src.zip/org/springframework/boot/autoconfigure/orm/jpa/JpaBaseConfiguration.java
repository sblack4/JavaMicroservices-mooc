/*     */ package org.springframework.boot.autoconfigure.orm.jpa;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.persistence.EntityManagerFactory;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigurationPackages;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.autoconfigure.domain.EntityScanPackages;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
/*     */ import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder.Builder;
/*     */ import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder.EntityManagerFactoryBeanCallback;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.context.annotation.Primary;
/*     */ import org.springframework.orm.jpa.JpaTransactionManager;
/*     */ import org.springframework.orm.jpa.JpaVendorAdapter;
/*     */ import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
/*     */ import org.springframework.orm.jpa.persistenceunit.PersistenceUnitManager;
/*     */ import org.springframework.orm.jpa.support.OpenEntityManagerInViewFilter;
/*     */ import org.springframework.orm.jpa.support.OpenEntityManagerInViewInterceptor;
/*     */ import org.springframework.orm.jpa.vendor.AbstractJpaVendorAdapter;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ import org.springframework.transaction.jta.JtaTransactionManager;
/*     */ import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
/*     */ import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @EnableConfigurationProperties({JpaProperties.class})
/*     */ @Import({DataSourceInitializedPublisher.Registrar.class})
/*     */ public abstract class JpaBaseConfiguration
/*     */   implements BeanFactoryAware
/*     */ {
/*     */   private final DataSource dataSource;
/*     */   private final JpaProperties properties;
/*     */   private final JtaTransactionManager jtaTransactionManager;
/*     */   private ConfigurableListableBeanFactory beanFactory;
/*     */   
/*     */   protected JpaBaseConfiguration(DataSource dataSource, JpaProperties properties, ObjectProvider<JtaTransactionManager> jtaTransactionManagerProvider)
/*     */   {
/*  77 */     this.dataSource = dataSource;
/*  78 */     this.properties = properties;
/*  79 */     this.jtaTransactionManager = ((JtaTransactionManager)jtaTransactionManagerProvider.getIfAvailable());
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({PlatformTransactionManager.class})
/*     */   public PlatformTransactionManager transactionManager() {
/*  85 */     return new JpaTransactionManager();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public JpaVendorAdapter jpaVendorAdapter() {
/*  91 */     AbstractJpaVendorAdapter adapter = createJpaVendorAdapter();
/*  92 */     adapter.setShowSql(this.properties.isShowSql());
/*  93 */     adapter.setDatabase(this.properties.getDatabase());
/*  94 */     adapter.setDatabasePlatform(this.properties.getDatabasePlatform());
/*  95 */     adapter.setGenerateDdl(this.properties.isGenerateDdl());
/*  96 */     return adapter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public EntityManagerFactoryBuilder entityManagerFactoryBuilder(JpaVendorAdapter jpaVendorAdapter, ObjectProvider<PersistenceUnitManager> persistenceUnitManagerProvider)
/*     */   {
/* 106 */     EntityManagerFactoryBuilder builder = new EntityManagerFactoryBuilder(jpaVendorAdapter, this.properties.getProperties(), (PersistenceUnitManager)persistenceUnitManagerProvider.getIfAvailable());
/* 107 */     builder.setCallback(getVendorCallback());
/* 108 */     return builder;
/*     */   }
/*     */   
/*     */ 
/*     */   @Bean
/*     */   @Primary
/*     */   @ConditionalOnMissingBean({LocalContainerEntityManagerFactoryBean.class, EntityManagerFactory.class})
/*     */   public LocalContainerEntityManagerFactoryBean entityManagerFactory(EntityManagerFactoryBuilder factoryBuilder)
/*     */   {
/* 117 */     Map<String, Object> vendorProperties = getVendorProperties();
/* 118 */     customizeVendorProperties(vendorProperties);
/*     */     
/* 120 */     return factoryBuilder.dataSource(this.dataSource).packages(getPackagesToScan()).properties(vendorProperties).jta(isJta()).build();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract AbstractJpaVendorAdapter createJpaVendorAdapter();
/*     */   
/*     */ 
/*     */   protected abstract Map<String, Object> getVendorProperties();
/*     */   
/*     */ 
/*     */   protected void customizeVendorProperties(Map<String, Object> vendorProperties) {}
/*     */   
/*     */ 
/*     */   protected EntityManagerFactoryBuilder.EntityManagerFactoryBeanCallback getVendorCallback()
/*     */   {
/* 136 */     return null;
/*     */   }
/*     */   
/*     */   protected String[] getPackagesToScan()
/*     */   {
/* 141 */     List<String> packages = EntityScanPackages.get(this.beanFactory).getPackageNames();
/* 142 */     if ((packages.isEmpty()) && (AutoConfigurationPackages.has(this.beanFactory))) {
/* 143 */       packages = AutoConfigurationPackages.get(this.beanFactory);
/*     */     }
/* 145 */     return (String[])packages.toArray(new String[packages.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JtaTransactionManager getJtaTransactionManager()
/*     */   {
/* 153 */     return this.jtaTransactionManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final boolean isJta()
/*     */   {
/* 161 */     return this.jtaTransactionManager != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final JpaProperties getProperties()
/*     */   {
/* 169 */     return this.properties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final DataSource getDataSource()
/*     */   {
/* 177 */     return this.dataSource;
/*     */   }
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException
/*     */   {
/* 182 */     this.beanFactory = ((ConfigurableListableBeanFactory)beanFactory);
/*     */   }
/*     */   
/*     */ 
/*     */   @Configuration
/*     */   @ConditionalOnWebApplication
/*     */   @ConditionalOnClass({WebMvcConfigurerAdapter.class})
/*     */   @ConditionalOnMissingBean({OpenEntityManagerInViewInterceptor.class, OpenEntityManagerInViewFilter.class})
/*     */   @ConditionalOnProperty(prefix="spring.jpa", name={"open-in-view"}, havingValue="true", matchIfMissing=true)
/*     */   protected static class JpaWebConfiguration
/*     */   {
/*     */     @Configuration
/*     */     protected static class JpaWebMvcConfiguration
/*     */       extends WebMvcConfigurerAdapter
/*     */     {
/*     */       @Bean
/*     */       public OpenEntityManagerInViewInterceptor openEntityManagerInViewInterceptor()
/*     */       {
/* 200 */         return new OpenEntityManagerInViewInterceptor();
/*     */       }
/*     */       
/*     */       public void addInterceptors(InterceptorRegistry registry)
/*     */       {
/* 205 */         registry.addWebRequestInterceptor(openEntityManagerInViewInterceptor());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\orm\jpa\JpaBaseConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */