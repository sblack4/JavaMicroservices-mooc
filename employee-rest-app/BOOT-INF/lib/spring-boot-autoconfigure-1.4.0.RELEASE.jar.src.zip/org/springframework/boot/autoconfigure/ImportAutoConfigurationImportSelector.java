/*     */ package org.springframework.boot.autoconfigure;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ImportAutoConfigurationImportSelector
/*     */   extends EnableAutoConfigurationImportSelector
/*     */ {
/*     */   private static final Set<String> ANNOTATION_NAMES;
/*     */   
/*     */   static
/*     */   {
/*  48 */     Set<String> names = new LinkedHashSet();
/*  49 */     names.add(ImportAutoConfiguration.class.getName());
/*  50 */     names.add("org.springframework.boot.autoconfigure.test.ImportAutoConfiguration");
/*  51 */     ANNOTATION_NAMES = Collections.unmodifiableSet(names);
/*     */   }
/*     */   
/*     */   protected AnnotationAttributes getAttributes(AnnotationMetadata metadata)
/*     */   {
/*  56 */     return null;
/*     */   }
/*     */   
/*     */   protected List<String> getCandidateConfigurations(AnnotationMetadata metadata, AnnotationAttributes attributes)
/*     */   {
/*     */     try
/*     */     {
/*  63 */       return getCandidateConfigurations(
/*  64 */         ClassUtils.forName(metadata.getClassName(), null));
/*     */     }
/*     */     catch (Exception ex) {
/*  67 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private List<String> getCandidateConfigurations(Class<?> source) {
/*  72 */     Set<String> candidates = new LinkedHashSet();
/*  73 */     collectCandidateConfigurations(source, candidates, new HashSet());
/*  74 */     return new ArrayList(candidates);
/*     */   }
/*     */   
/*     */   private void collectCandidateConfigurations(Class<?> source, Set<String> candidates, Set<Class<?>> seen)
/*     */   {
/*  79 */     if ((source != null) && (seen.add(source))) {
/*  80 */       for (Annotation annotation : source.getDeclaredAnnotations()) {
/*  81 */         if (!AnnotationUtils.isInJavaLangAnnotationPackage(annotation)) {
/*  82 */           collectCandidateConfigurations(source, annotation, candidates, seen);
/*     */         }
/*     */       }
/*  85 */       collectCandidateConfigurations(source.getSuperclass(), candidates, seen);
/*     */     }
/*     */   }
/*     */   
/*     */   private void collectCandidateConfigurations(Class<?> source, Annotation annotation, Set<String> candidates, Set<Class<?>> seen)
/*     */   {
/*  91 */     if (ANNOTATION_NAMES.contains(annotation.annotationType().getName())) {
/*  92 */       candidates.addAll(getConfigurationsForAnnotation(source, annotation));
/*     */     }
/*  94 */     collectCandidateConfigurations(annotation.annotationType(), candidates, seen);
/*     */   }
/*     */   
/*     */ 
/*     */   private Collection<String> getConfigurationsForAnnotation(Class<?> source, Annotation annotation)
/*     */   {
/* 100 */     String[] value = (String[])AnnotationUtils.getAnnotationAttributes(annotation, true).get("value");
/* 101 */     if (value.length > 0) {
/* 102 */       return Arrays.asList(value);
/*     */     }
/* 104 */     return SpringFactoriesLoader.loadFactoryNames(source, 
/* 105 */       getClass().getClassLoader());
/*     */   }
/*     */   
/*     */ 
/*     */   protected Set<String> getExclusions(AnnotationMetadata metadata, AnnotationAttributes attributes)
/*     */   {
/* 111 */     return Collections.emptySet();
/*     */   }
/*     */   
/*     */   public int getOrder()
/*     */   {
/* 116 */     return super.getOrder() - 1;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\ImportAutoConfigurationImportSelector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */