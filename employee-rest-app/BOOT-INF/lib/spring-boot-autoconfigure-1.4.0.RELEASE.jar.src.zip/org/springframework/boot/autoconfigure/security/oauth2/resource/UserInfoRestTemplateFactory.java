/*    */ package org.springframework.boot.autoconfigure.security.oauth2.resource;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*    */ import org.springframework.security.oauth2.client.OAuth2ClientContext;
/*    */ import org.springframework.security.oauth2.client.OAuth2RestTemplate;
/*    */ import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
/*    */ import org.springframework.security.oauth2.client.token.grant.code.AuthorizationCodeAccessTokenProvider;
/*    */ import org.springframework.security.oauth2.client.token.grant.code.AuthorizationCodeResourceDetails;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration
/*    */ public class UserInfoRestTemplateFactory
/*    */ {
/*    */   private static final AuthorizationCodeResourceDetails DEFAULT_RESOURCE_DETAILS;
/*    */   private final List<UserInfoRestTemplateCustomizer> customizers;
/*    */   private final OAuth2ProtectedResourceDetails details;
/*    */   private final OAuth2ClientContext oauth2ClientContext;
/*    */   private OAuth2RestTemplate template;
/*    */   
/*    */   static
/*    */   {
/* 46 */     AuthorizationCodeResourceDetails details = new AuthorizationCodeResourceDetails();
/* 47 */     details.setClientId("<N/A>");
/* 48 */     details.setUserAuthorizationUri("Not a URI because there is no client");
/* 49 */     details.setAccessTokenUri("Not a URI because there is no client");
/* 50 */     DEFAULT_RESOURCE_DETAILS = details;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public UserInfoRestTemplateFactory(ObjectProvider<List<UserInfoRestTemplateCustomizer>> customizersProvider, ObjectProvider<OAuth2ProtectedResourceDetails> detailsProvider, ObjectProvider<OAuth2ClientContext> oauth2ClientContextProvider)
/*    */   {
/* 65 */     this.customizers = ((List)customizersProvider.getIfAvailable());
/* 66 */     this.details = ((OAuth2ProtectedResourceDetails)detailsProvider.getIfAvailable());
/* 67 */     this.oauth2ClientContext = ((OAuth2ClientContext)oauth2ClientContextProvider.getIfAvailable());
/*    */   }
/*    */   
/*    */   public OAuth2RestTemplate getUserInfoRestTemplate() {
/* 71 */     if (this.template == null) {
/* 72 */       this.template = getTemplate(this.details == null ? DEFAULT_RESOURCE_DETAILS : this.details);
/*    */       
/* 74 */       this.template.getInterceptors().add(new ResourceServerTokenServicesConfiguration.AcceptJsonRequestInterceptor());
/* 75 */       AuthorizationCodeAccessTokenProvider accessTokenProvider = new AuthorizationCodeAccessTokenProvider();
/* 76 */       accessTokenProvider.setTokenRequestEnhancer(new ResourceServerTokenServicesConfiguration.AcceptJsonRequestEnhancer());
/* 77 */       this.template.setAccessTokenProvider(accessTokenProvider);
/* 78 */       if (!CollectionUtils.isEmpty(this.customizers)) {
/* 79 */         AnnotationAwareOrderComparator.sort(this.customizers);
/* 80 */         for (UserInfoRestTemplateCustomizer customizer : this.customizers) {
/* 81 */           customizer.customize(this.template);
/*    */         }
/*    */       }
/*    */     }
/* 85 */     return this.template;
/*    */   }
/*    */   
/*    */   private OAuth2RestTemplate getTemplate(OAuth2ProtectedResourceDetails details) {
/* 89 */     if (this.oauth2ClientContext == null) {
/* 90 */       return new OAuth2RestTemplate(details);
/*    */     }
/* 92 */     return new OAuth2RestTemplate(details, this.oauth2ClientContext);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\security\oauth2\resource\UserInfoRestTemplateFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */