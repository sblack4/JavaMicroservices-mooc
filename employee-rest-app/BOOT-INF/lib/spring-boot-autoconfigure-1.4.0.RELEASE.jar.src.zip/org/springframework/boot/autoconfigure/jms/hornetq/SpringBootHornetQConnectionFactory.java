/*    */ package org.springframework.boot.autoconfigure.jms.hornetq;
/*    */ 
/*    */ import javax.jms.Connection;
/*    */ import javax.jms.JMSException;
/*    */ import org.hornetq.api.core.TransportConfiguration;
/*    */ import org.hornetq.api.core.client.ServerLocator;
/*    */ import org.hornetq.jms.client.HornetQConnectionFactory;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ class SpringBootHornetQConnectionFactory
/*    */   extends HornetQConnectionFactory
/*    */ {
/*    */   private final HornetQProperties properties;
/*    */   
/*    */   SpringBootHornetQConnectionFactory(HornetQProperties properties, ServerLocator serverLocator)
/*    */   {
/* 42 */     super(serverLocator);
/* 43 */     this.properties = properties;
/*    */   }
/*    */   
/*    */   SpringBootHornetQConnectionFactory(HornetQProperties properties, boolean ha, TransportConfiguration... initialConnectors)
/*    */   {
/* 48 */     super(ha, initialConnectors);
/* 49 */     this.properties = properties;
/*    */   }
/*    */   
/*    */   public Connection createConnection() throws JMSException
/*    */   {
/* 54 */     String user = this.properties.getUser();
/* 55 */     if (StringUtils.hasText(user)) {
/* 56 */       return createConnection(user, this.properties.getPassword());
/*    */     }
/* 58 */     return super.createConnection();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jms\hornetq\SpringBootHornetQConnectionFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */