/*    */ package org.springframework.boot.autoconfigure.jdbc;
/*    */ 
/*    */ import javax.annotation.PreDestroy;
/*    */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.jdbc.datasource.embedded.EmbeddedDatabase;
/*    */ import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration
/*    */ @EnableConfigurationProperties({DataSourceProperties.class})
/*    */ public class EmbeddedDataSourceConfiguration
/*    */   implements BeanClassLoaderAware
/*    */ {
/*    */   private EmbeddedDatabase database;
/*    */   private ClassLoader classLoader;
/*    */   private final DataSourceProperties properties;
/*    */   
/*    */   public EmbeddedDataSourceConfiguration(DataSourceProperties properties)
/*    */   {
/* 46 */     this.properties = properties;
/*    */   }
/*    */   
/*    */   public void setBeanClassLoader(ClassLoader classLoader)
/*    */   {
/* 51 */     this.classLoader = classLoader;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   public EmbeddedDatabase dataSource()
/*    */   {
/* 57 */     EmbeddedDatabaseBuilder builder = new EmbeddedDatabaseBuilder().setType(EmbeddedDatabaseConnection.get(this.classLoader).getType());
/* 58 */     this.database = builder.setName(this.properties.getName()).build();
/* 59 */     return this.database;
/*    */   }
/*    */   
/*    */   @PreDestroy
/*    */   public void close() {
/* 64 */     if (this.database != null) {
/* 65 */       this.database.shutdown();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jdbc\EmbeddedDataSourceConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */