/*    */ package org.springframework.boot.autoconfigure.amqp;
/*    */ 
/*    */ import org.springframework.amqp.rabbit.annotation.EnableRabbit;
/*    */ import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
/*    */ import org.springframework.amqp.rabbit.connection.ConnectionFactory;
/*    */ import org.springframework.amqp.support.converter.MessageConverter;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration
/*    */ @ConditionalOnClass({EnableRabbit.class})
/*    */ class RabbitAnnotationDrivenConfiguration
/*    */ {
/*    */   private final ObjectProvider<MessageConverter> messageConverter;
/*    */   private final RabbitProperties properties;
/*    */   
/*    */   RabbitAnnotationDrivenConfiguration(ObjectProvider<MessageConverter> messageConverter, RabbitProperties properties)
/*    */   {
/* 47 */     this.messageConverter = messageConverter;
/* 48 */     this.properties = properties;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public SimpleRabbitListenerContainerFactoryConfigurer rabbitListenerContainerFactoryConfigurer() {
/* 54 */     SimpleRabbitListenerContainerFactoryConfigurer configurer = new SimpleRabbitListenerContainerFactoryConfigurer();
/* 55 */     configurer.setMessageConverter((MessageConverter)this.messageConverter.getIfUnique());
/* 56 */     configurer.setRabbitProperties(this.properties);
/* 57 */     return configurer;
/*    */   }
/*    */   
/*    */ 
/*    */   @Bean
/*    */   @ConditionalOnMissingBean(name={"rabbitListenerContainerFactory"})
/*    */   public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory(SimpleRabbitListenerContainerFactoryConfigurer configurer, ConnectionFactory connectionFactory)
/*    */   {
/* 65 */     SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
/* 66 */     configurer.configure(factory, connectionFactory);
/* 67 */     return factory;
/*    */   }
/*    */   
/*    */   @EnableRabbit
/*    */   @ConditionalOnMissingBean(name={"org.springframework.amqp.rabbit.config.internalRabbitListenerAnnotationProcessor"})
/*    */   protected static class EnableRabbitConfiguration {}
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\amqp\RabbitAnnotationDrivenConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */