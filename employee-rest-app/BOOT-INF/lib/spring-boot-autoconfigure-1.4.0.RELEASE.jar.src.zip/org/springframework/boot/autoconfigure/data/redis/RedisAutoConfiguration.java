/*     */ package org.springframework.boot.autoconfigure.data.redis;
/*     */ 
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.pool2.impl.GenericObjectPool;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.data.redis.connection.RedisClusterConfiguration;
/*     */ import org.springframework.data.redis.connection.RedisConnectionFactory;
/*     */ import org.springframework.data.redis.connection.RedisNode;
/*     */ import org.springframework.data.redis.connection.RedisSentinelConfiguration;
/*     */ import org.springframework.data.redis.connection.jedis.JedisConnection;
/*     */ import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
/*     */ import org.springframework.data.redis.core.RedisOperations;
/*     */ import org.springframework.data.redis.core.RedisTemplate;
/*     */ import org.springframework.data.redis.core.StringRedisTemplate;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import redis.clients.jedis.Jedis;
/*     */ import redis.clients.jedis.JedisPoolConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @ConditionalOnClass({JedisConnection.class, RedisOperations.class, Jedis.class})
/*     */ @EnableConfigurationProperties({RedisProperties.class})
/*     */ public class RedisAutoConfiguration
/*     */ {
/*     */   @Configuration
/*     */   @ConditionalOnClass({GenericObjectPool.class})
/*     */   protected static class RedisConnectionConfiguration
/*     */   {
/*     */     private final RedisProperties properties;
/*     */     private final RedisSentinelConfiguration sentinelConfiguration;
/*     */     private final RedisClusterConfiguration clusterConfiguration;
/*     */     
/*     */     public RedisConnectionConfiguration(RedisProperties properties, ObjectProvider<RedisSentinelConfiguration> sentinelConfigurationProvider, ObjectProvider<RedisClusterConfiguration> clusterConfigurationProvider)
/*     */     {
/*  80 */       this.properties = properties;
/*  81 */       this.sentinelConfiguration = ((RedisSentinelConfiguration)sentinelConfigurationProvider.getIfAvailable());
/*  82 */       this.clusterConfiguration = ((RedisClusterConfiguration)clusterConfigurationProvider.getIfAvailable());
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({RedisConnectionFactory.class})
/*     */     public JedisConnectionFactory redisConnectionFactory() throws UnknownHostException
/*     */     {
/*  89 */       return applyProperties(createJedisConnectionFactory());
/*     */     }
/*     */     
/*     */     protected final JedisConnectionFactory applyProperties(JedisConnectionFactory factory)
/*     */     {
/*  94 */       factory.setHostName(this.properties.getHost());
/*  95 */       factory.setPort(this.properties.getPort());
/*  96 */       if (this.properties.getPassword() != null) {
/*  97 */         factory.setPassword(this.properties.getPassword());
/*     */       }
/*  99 */       factory.setDatabase(this.properties.getDatabase());
/* 100 */       if (this.properties.getTimeout() > 0) {
/* 101 */         factory.setTimeout(this.properties.getTimeout());
/*     */       }
/* 103 */       return factory;
/*     */     }
/*     */     
/*     */     protected final RedisSentinelConfiguration getSentinelConfig() {
/* 107 */       if (this.sentinelConfiguration != null) {
/* 108 */         return this.sentinelConfiguration;
/*     */       }
/* 110 */       RedisProperties.Sentinel sentinelProperties = this.properties.getSentinel();
/* 111 */       if (sentinelProperties != null) {
/* 112 */         RedisSentinelConfiguration config = new RedisSentinelConfiguration();
/* 113 */         config.master(sentinelProperties.getMaster());
/* 114 */         config.setSentinels(createSentinels(sentinelProperties));
/* 115 */         return config;
/*     */       }
/* 117 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected final RedisClusterConfiguration getClusterConfiguration()
/*     */     {
/* 125 */       if (this.clusterConfiguration != null) {
/* 126 */         return this.clusterConfiguration;
/*     */       }
/* 128 */       if (this.properties.getCluster() == null) {
/* 129 */         return null;
/*     */       }
/* 131 */       RedisProperties.Cluster clusterProperties = this.properties.getCluster();
/*     */       
/* 133 */       RedisClusterConfiguration config = new RedisClusterConfiguration(clusterProperties.getNodes());
/*     */       
/* 135 */       if (clusterProperties.getMaxRedirects() != null) {
/* 136 */         config.setMaxRedirects(clusterProperties.getMaxRedirects().intValue());
/*     */       }
/* 138 */       return config;
/*     */     }
/*     */     
/*     */     private List<RedisNode> createSentinels(RedisProperties.Sentinel sentinel) {
/* 142 */       List<RedisNode> nodes = new ArrayList();
/* 143 */       for (String node : StringUtils.commaDelimitedListToStringArray(sentinel.getNodes())) {
/*     */         try {
/* 146 */           String[] parts = StringUtils.split(node, ":");
/* 147 */           Assert.state(parts.length == 2, "Must be defined as 'host:port'");
/* 148 */           nodes.add(new RedisNode(parts[0], Integer.valueOf(parts[1]).intValue()));
/*     */         }
/*     */         catch (RuntimeException ex) {
/* 151 */           throw new IllegalStateException("Invalid redis sentinel property '" + node + "'", ex);
/*     */         }
/*     */       }
/*     */       
/* 155 */       return nodes;
/*     */     }
/*     */     
/*     */     private JedisConnectionFactory createJedisConnectionFactory()
/*     */     {
/* 160 */       JedisPoolConfig poolConfig = this.properties.getPool() != null ? jedisPoolConfig() : new JedisPoolConfig();
/*     */       
/* 162 */       if (getSentinelConfig() != null) {
/* 163 */         return new JedisConnectionFactory(getSentinelConfig(), poolConfig);
/*     */       }
/* 165 */       if (getClusterConfiguration() != null) {
/* 166 */         return new JedisConnectionFactory(getClusterConfiguration(), poolConfig);
/*     */       }
/* 168 */       return new JedisConnectionFactory(poolConfig);
/*     */     }
/*     */     
/*     */     private JedisPoolConfig jedisPoolConfig() {
/* 172 */       JedisPoolConfig config = new JedisPoolConfig();
/* 173 */       RedisProperties.Pool props = this.properties.getPool();
/* 174 */       config.setMaxTotal(props.getMaxActive());
/* 175 */       config.setMaxIdle(props.getMaxIdle());
/* 176 */       config.setMinIdle(props.getMinIdle());
/* 177 */       config.setMaxWaitMillis(props.getMaxWait());
/* 178 */       return config;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Configuration
/*     */   protected static class RedisConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean(name={"redisTemplate"})
/*     */     public RedisTemplate<Object, Object> redisTemplate(RedisConnectionFactory redisConnectionFactory)
/*     */       throws UnknownHostException
/*     */     {
/* 194 */       RedisTemplate<Object, Object> template = new RedisTemplate();
/* 195 */       template.setConnectionFactory(redisConnectionFactory);
/* 196 */       return template;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({StringRedisTemplate.class})
/*     */     public StringRedisTemplate stringRedisTemplate(RedisConnectionFactory redisConnectionFactory)
/*     */       throws UnknownHostException
/*     */     {
/* 204 */       StringRedisTemplate template = new StringRedisTemplate();
/* 205 */       template.setConnectionFactory(redisConnectionFactory);
/* 206 */       return template;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\data\redis\RedisAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */