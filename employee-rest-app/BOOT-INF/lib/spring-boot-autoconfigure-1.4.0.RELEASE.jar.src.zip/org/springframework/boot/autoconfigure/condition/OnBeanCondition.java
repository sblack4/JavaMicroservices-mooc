/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.HierarchicalBeanFactory;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.ConfigurationCondition;
/*     */ import org.springframework.context.annotation.ConfigurationCondition.ConfigurationPhase;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.ReflectionUtils.MethodCallback;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Order(Integer.MAX_VALUE)
/*     */ class OnBeanCondition
/*     */   extends SpringBootCondition
/*     */   implements ConfigurationCondition
/*     */ {
/*  61 */   private static final String[] NO_BEANS = new String[0];
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String FACTORY_BEAN_OBJECT_TYPE = "factoryBeanObjectType";
/*     */   
/*     */ 
/*     */ 
/*     */   public ConfigurationCondition.ConfigurationPhase getConfigurationPhase()
/*     */   {
/*  71 */     return ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN;
/*     */   }
/*     */   
/*     */ 
/*     */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*     */   {
/*  77 */     StringBuilder matchMessage = new StringBuilder();
/*  78 */     if (metadata.isAnnotated(ConditionalOnBean.class.getName())) {
/*  79 */       BeanSearchSpec spec = new BeanSearchSpec(context, metadata, ConditionalOnBean.class);
/*     */       
/*  81 */       List<String> matching = getMatchingBeans(context, spec);
/*  82 */       if (matching.isEmpty())
/*     */       {
/*  84 */         return ConditionOutcome.noMatch("@ConditionalOnBean " + spec + " found no beans");
/*     */       }
/*     */       
/*  87 */       matchMessage.append("@ConditionalOnBean ").append(spec).append(" found the following ").append(matching);
/*     */     }
/*  89 */     if (metadata.isAnnotated(ConditionalOnSingleCandidate.class.getName())) {
/*  90 */       BeanSearchSpec spec = new SingleCandidateBeanSearchSpec(context, metadata, ConditionalOnSingleCandidate.class);
/*     */       
/*  92 */       List<String> matching = getMatchingBeans(context, spec);
/*  93 */       if (matching.isEmpty()) {
/*  94 */         return ConditionOutcome.noMatch("@ConditionalOnSingleCandidate " + spec + " found no beans");
/*     */       }
/*     */       
/*  97 */       if (!hasSingleAutowireCandidate(context.getBeanFactory(), matching)) {
/*  98 */         return ConditionOutcome.noMatch("@ConditionalOnSingleCandidate " + spec + " found no primary candidate amongst the" + " following " + matching);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 104 */       matchMessage.append("@ConditionalOnSingleCandidate ").append(spec).append(" found a primary candidate amongst the following ").append(matching);
/*     */     }
/* 106 */     if (metadata.isAnnotated(ConditionalOnMissingBean.class.getName())) {
/* 107 */       BeanSearchSpec spec = new BeanSearchSpec(context, metadata, ConditionalOnMissingBean.class);
/*     */       
/* 109 */       List<String> matching = getMatchingBeans(context, spec);
/* 110 */       if (!matching.isEmpty()) {
/* 111 */         return ConditionOutcome.noMatch("@ConditionalOnMissingBean " + spec + " found the following " + matching);
/*     */       }
/*     */       
/* 114 */       matchMessage.append(matchMessage.length() == 0 ? "" : " ");
/* 115 */       matchMessage.append("@ConditionalOnMissingBean ").append(spec)
/* 116 */         .append(" found no beans");
/*     */     }
/* 118 */     return ConditionOutcome.match(matchMessage.toString());
/*     */   }
/*     */   
/*     */   private List<String> getMatchingBeans(ConditionContext context, BeanSearchSpec beans)
/*     */   {
/* 123 */     ConfigurableListableBeanFactory beanFactory = context.getBeanFactory();
/* 124 */     if (beans.getStrategy() == SearchStrategy.PARENTS) {
/* 125 */       BeanFactory parent = beanFactory.getParentBeanFactory();
/* 126 */       Assert.isInstanceOf(ConfigurableListableBeanFactory.class, parent, "Unable to use SearchStrategy.PARENTS");
/*     */       
/* 128 */       beanFactory = (ConfigurableListableBeanFactory)parent;
/*     */     }
/* 130 */     if (beanFactory == null) {
/* 131 */       return Collections.emptyList();
/*     */     }
/* 133 */     List<String> beanNames = new ArrayList();
/* 134 */     boolean considerHierarchy = beans.getStrategy() == SearchStrategy.ALL;
/* 135 */     for (String type : beans.getTypes()) {
/* 136 */       beanNames.addAll(getBeanNamesForType(beanFactory, type, context
/* 137 */         .getClassLoader(), considerHierarchy));
/*     */     }
/* 139 */     for (String ignoredType : beans.getIgnoredTypes()) {
/* 140 */       beanNames.removeAll(getBeanNamesForType(beanFactory, ignoredType, context
/* 141 */         .getClassLoader(), considerHierarchy));
/*     */     }
/* 143 */     for (String annotation : beans.getAnnotations()) {
/* 144 */       beanNames.addAll(Arrays.asList(getBeanNamesForAnnotation(beanFactory, annotation, context
/* 145 */         .getClassLoader(), considerHierarchy)));
/*     */     }
/* 147 */     for (String beanName : beans.getNames()) {
/* 148 */       if (containsBean(beanFactory, beanName, considerHierarchy)) {
/* 149 */         beanNames.add(beanName);
/*     */       }
/*     */     }
/* 152 */     return beanNames;
/*     */   }
/*     */   
/*     */   private boolean containsBean(ConfigurableListableBeanFactory beanFactory, String beanName, boolean considerHierarchy)
/*     */   {
/* 157 */     if (considerHierarchy) {
/* 158 */       return beanFactory.containsBean(beanName);
/*     */     }
/* 160 */     return beanFactory.containsLocalBean(beanName);
/*     */   }
/*     */   
/*     */   private Collection<String> getBeanNamesForType(ListableBeanFactory beanFactory, String type, ClassLoader classLoader, boolean considerHierarchy) throws LinkageError
/*     */   {
/*     */     try
/*     */     {
/* 167 */       Set<String> result = new LinkedHashSet();
/* 168 */       collectBeanNamesForType(result, beanFactory, 
/* 169 */         ClassUtils.forName(type, classLoader), considerHierarchy);
/* 170 */       return result;
/*     */     }
/*     */     catch (ClassNotFoundException ex) {}
/* 173 */     return Collections.emptySet();
/*     */   }
/*     */   
/*     */ 
/*     */   private void collectBeanNamesForType(Set<String> result, ListableBeanFactory beanFactory, Class<?> type, boolean considerHierarchy)
/*     */   {
/* 179 */     result.addAll(BeanTypeRegistry.get(beanFactory).getNamesForType(type));
/* 180 */     if ((considerHierarchy) && ((beanFactory instanceof HierarchicalBeanFactory)))
/*     */     {
/* 182 */       BeanFactory parent = ((HierarchicalBeanFactory)beanFactory).getParentBeanFactory();
/* 183 */       if ((parent instanceof ListableBeanFactory)) {
/* 184 */         collectBeanNamesForType(result, (ListableBeanFactory)parent, type, considerHierarchy);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private String[] getBeanNamesForAnnotation(ConfigurableListableBeanFactory beanFactory, String type, ClassLoader classLoader, boolean considerHierarchy)
/*     */     throws LinkageError
/*     */   {
/* 193 */     String[] result = NO_BEANS;
/*     */     
/*     */     try
/*     */     {
/* 197 */       Class<? extends Annotation> typeClass = ClassUtils.forName(type, classLoader);
/* 198 */       result = beanFactory.getBeanNamesForAnnotation(typeClass);
/* 199 */       List<String> resultList; if (considerHierarchy)
/*     */       {
/* 201 */         if ((beanFactory.getParentBeanFactory() instanceof ConfigurableListableBeanFactory)) {
/* 202 */           String[] parentResult = getBeanNamesForAnnotation(
/*     */           
/* 204 */             (ConfigurableListableBeanFactory)beanFactory.getParentBeanFactory(), type, classLoader, true);
/*     */           
/* 206 */           resultList = new ArrayList();
/* 207 */           resultList.addAll(Arrays.asList(result));
/* 208 */           for (String beanName : parentResult)
/* 209 */             if ((!resultList.contains(beanName)) && 
/* 210 */               (!beanFactory.containsLocalBean(beanName)))
/* 211 */               resultList.add(beanName);
/*     */         }
/*     */       }
/* 214 */       return StringUtils.toStringArray(resultList);
/*     */     }
/*     */     catch (ClassNotFoundException ex) {}
/*     */     
/*     */ 
/*     */ 
/* 220 */     return NO_BEANS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean hasSingleAutowireCandidate(ConfigurableListableBeanFactory beanFactory, List<String> beanNames)
/*     */   {
/* 227 */     return (beanNames.size() == 1) || (getPrimaryBeans(beanFactory, beanNames).size() == 1);
/*     */   }
/*     */   
/*     */   private List<String> getPrimaryBeans(ConfigurableListableBeanFactory beanFactory, List<String> beanNames)
/*     */   {
/* 232 */     List<String> primaryBeans = new ArrayList();
/* 233 */     for (String beanName : beanNames) {
/* 234 */       BeanDefinition beanDefinition = beanFactory.getBeanDefinition(beanName);
/* 235 */       if ((beanDefinition != null) && (beanDefinition.isPrimary())) {
/* 236 */         primaryBeans.add(beanName);
/*     */       }
/*     */     }
/* 239 */     return primaryBeans;
/*     */   }
/*     */   
/*     */ 
/*     */   private static class BeanSearchSpec
/*     */   {
/*     */     private final Class<?> annotationType;
/* 246 */     private final List<String> names = new ArrayList();
/*     */     
/* 248 */     private final List<String> types = new ArrayList();
/*     */     
/* 250 */     private final List<String> annotations = new ArrayList();
/*     */     
/* 252 */     private final List<String> ignoredTypes = new ArrayList();
/*     */     
/*     */     private final SearchStrategy strategy;
/*     */     
/*     */     BeanSearchSpec(ConditionContext context, AnnotatedTypeMetadata metadata, Class<?> annotationType)
/*     */     {
/* 258 */       this.annotationType = annotationType;
/*     */       
/* 260 */       MultiValueMap<String, Object> attributes = metadata.getAllAnnotationAttributes(annotationType.getName(), true);
/* 261 */       collect(attributes, "name", this.names);
/* 262 */       collect(attributes, "value", this.types);
/* 263 */       collect(attributes, "type", this.types);
/* 264 */       collect(attributes, "annotation", this.annotations);
/* 265 */       collect(attributes, "ignored", this.ignoredTypes);
/* 266 */       collect(attributes, "ignoredType", this.ignoredTypes);
/*     */       
/* 268 */       this.strategy = ((SearchStrategy)metadata.getAnnotationAttributes(annotationType.getName()).get("search"));
/* 269 */       OnBeanCondition.BeanTypeDeductionException deductionException = null;
/*     */       try {
/* 271 */         if ((this.types.isEmpty()) && (this.names.isEmpty())) {
/* 272 */           addDeducedBeanType(context, metadata, this.types);
/*     */         }
/*     */       }
/*     */       catch (OnBeanCondition.BeanTypeDeductionException ex) {
/* 276 */         deductionException = ex;
/*     */       }
/* 278 */       validate(deductionException);
/*     */     }
/*     */     
/*     */     protected void validate(OnBeanCondition.BeanTypeDeductionException ex) {
/* 282 */       if (!hasAtLeastOne(new List[] { this.types, this.names, this.annotations })) {
/* 283 */         String message = annotationName() + " did not specify a bean using type, name or annotation";
/*     */         
/* 285 */         if (ex == null) {
/* 286 */           throw new IllegalStateException(message);
/*     */         }
/* 288 */         throw new IllegalStateException(message + " and the attempt to deduce" + " the bean's type failed", ex);
/*     */       }
/*     */     }
/*     */     
/*     */     private boolean hasAtLeastOne(List<?>... lists)
/*     */     {
/* 294 */       for (List<?> list : lists) {
/* 295 */         if (!list.isEmpty()) {
/* 296 */           return true;
/*     */         }
/*     */       }
/* 299 */       return false;
/*     */     }
/*     */     
/*     */     protected String annotationName() {
/* 303 */       return "@" + ClassUtils.getShortName(this.annotationType);
/*     */     }
/*     */     
/*     */     protected void collect(MultiValueMap<String, Object> attributes, String key, List<String> destination)
/*     */     {
/* 308 */       List<?> values = (List)attributes.get(key);
/* 309 */       if (values != null) {
/* 310 */         for (Object value : values) {
/* 311 */           if ((value instanceof String[])) {
/* 312 */             Collections.addAll(destination, (String[])value);
/*     */           }
/*     */           else {
/* 315 */             destination.add((String)value);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private void addDeducedBeanType(ConditionContext context, AnnotatedTypeMetadata metadata, List<String> beanTypes)
/*     */     {
/* 323 */       if (((metadata instanceof MethodMetadata)) && 
/* 324 */         (metadata.isAnnotated(Bean.class.getName()))) {
/* 325 */         addDeducedBeanTypeForBeanMethod(context, metadata, beanTypes, (MethodMetadata)metadata);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private void addDeducedBeanTypeForBeanMethod(ConditionContext context, AnnotatedTypeMetadata metadata, final List<String> beanTypes, final MethodMetadata methodMetadata)
/*     */     {
/*     */       try
/*     */       {
/* 336 */         Class<?> configClass = ClassUtils.forName(methodMetadata
/* 337 */           .getDeclaringClassName(), context.getClassLoader());
/* 338 */         ReflectionUtils.doWithMethods(configClass, new ReflectionUtils.MethodCallback()
/*     */         {
/*     */           public void doWith(Method method) throws IllegalArgumentException, IllegalAccessException
/*     */           {
/* 342 */             if (methodMetadata.getMethodName().equals(method.getName())) {
/* 343 */               beanTypes.add(method.getReturnType().getName());
/*     */             }
/*     */             
/*     */           }
/*     */         });
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 351 */         throw new OnBeanCondition.BeanTypeDeductionException(methodMetadata.getDeclaringClassName(), methodMetadata.getMethodName(), ex, null);
/*     */       }
/*     */     }
/*     */     
/*     */     public SearchStrategy getStrategy() {
/* 356 */       return this.strategy != null ? this.strategy : SearchStrategy.ALL;
/*     */     }
/*     */     
/*     */     public List<String> getNames() {
/* 360 */       return this.names;
/*     */     }
/*     */     
/*     */     public List<String> getTypes() {
/* 364 */       return this.types;
/*     */     }
/*     */     
/*     */     public List<String> getAnnotations() {
/* 368 */       return this.annotations;
/*     */     }
/*     */     
/*     */     public List<String> getIgnoredTypes() {
/* 372 */       return this.ignoredTypes;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 377 */       StringBuilder string = new StringBuilder();
/* 378 */       string.append("(");
/* 379 */       if (!this.names.isEmpty()) {
/* 380 */         string.append("names: ");
/* 381 */         string.append(StringUtils.collectionToCommaDelimitedString(this.names));
/* 382 */         if (!this.types.isEmpty()) {
/* 383 */           string.append("; ");
/*     */         }
/*     */       }
/* 386 */       if (!this.types.isEmpty()) {
/* 387 */         string.append("types: ");
/* 388 */         string.append(StringUtils.collectionToCommaDelimitedString(this.types));
/*     */       }
/* 390 */       string.append("; SearchStrategy: ");
/* 391 */       string.append(this.strategy.toString().toLowerCase());
/* 392 */       string.append(")");
/* 393 */       return string.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   private static class SingleCandidateBeanSearchSpec
/*     */     extends OnBeanCondition.BeanSearchSpec
/*     */   {
/*     */     SingleCandidateBeanSearchSpec(ConditionContext context, AnnotatedTypeMetadata metadata, Class<?> annotationType)
/*     */     {
/* 402 */       super(metadata, annotationType);
/*     */     }
/*     */     
/*     */ 
/*     */     protected void collect(MultiValueMap<String, Object> attributes, String key, List<String> destination)
/*     */     {
/* 408 */       super.collect(attributes, key, destination);
/* 409 */       destination.removeAll(Arrays.asList(new String[] { "", Object.class.getName() }));
/*     */     }
/*     */     
/*     */     protected void validate(OnBeanCondition.BeanTypeDeductionException ex)
/*     */     {
/* 414 */       Assert.isTrue(getTypes().size() == 1, annotationName() + " annotations must " + "specify only one type (got " + 
/* 415 */         getTypes() + ")");
/*     */     }
/*     */   }
/*     */   
/*     */   static final class BeanTypeDeductionException extends RuntimeException
/*     */   {
/*     */     private BeanTypeDeductionException(String className, String beanMethodName, Throwable cause)
/*     */     {
/* 423 */       super(cause);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\condition\OnBeanCondition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */