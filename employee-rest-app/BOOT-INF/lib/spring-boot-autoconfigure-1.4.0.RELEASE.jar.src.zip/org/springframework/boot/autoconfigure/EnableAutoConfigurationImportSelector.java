/*     */ package org.springframework.boot.autoconfigure;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionEvaluationReport;
/*     */ import org.springframework.boot.bind.PropertySourcesPropertyValues;
/*     */ import org.springframework.boot.bind.RelaxedDataBinder;
/*     */ import org.springframework.boot.bind.RelaxedPropertyResolver;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.context.annotation.DeferredImportSelector;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.CachingMetadataReaderFactory;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EnableAutoConfigurationImportSelector
/*     */   implements DeferredImportSelector, BeanClassLoaderAware, ResourceLoaderAware, BeanFactoryAware, EnvironmentAware, Ordered
/*     */ {
/*  67 */   private static final String[] NO_IMPORTS = new String[0];
/*     */   
/*     */   private ConfigurableListableBeanFactory beanFactory;
/*     */   
/*     */   private Environment environment;
/*     */   
/*     */   private ClassLoader beanClassLoader;
/*     */   
/*     */   private ResourceLoader resourceLoader;
/*     */   
/*     */   public String[] selectImports(AnnotationMetadata metadata)
/*     */   {
/*  79 */     if (!isEnabled(metadata)) {
/*  80 */       return NO_IMPORTS;
/*     */     }
/*     */     try {
/*  83 */       AnnotationAttributes attributes = getAttributes(metadata);
/*  84 */       List<String> configurations = getCandidateConfigurations(metadata, attributes);
/*     */       
/*  86 */       configurations = removeDuplicates(configurations);
/*  87 */       Set<String> exclusions = getExclusions(metadata, attributes);
/*  88 */       configurations.removeAll(exclusions);
/*  89 */       configurations = sort(configurations);
/*  90 */       recordWithConditionEvaluationReport(configurations, exclusions);
/*  91 */       return (String[])configurations.toArray(new String[configurations.size()]);
/*     */     }
/*     */     catch (IOException ex) {
/*  94 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean isEnabled(AnnotationMetadata metadata) {
/*  99 */     if (getClass().equals(EnableAutoConfigurationImportSelector.class)) {
/* 100 */       return ((Boolean)this.environment.getProperty("spring.boot.enableautoconfiguration", Boolean.class, 
/*     */       
/* 102 */         Boolean.valueOf(true))).booleanValue();
/*     */     }
/*     */     
/*     */ 
/* 104 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AnnotationAttributes getAttributes(AnnotationMetadata metadata)
/*     */   {
/* 115 */     String name = getAnnotationClass().getName();
/*     */     
/* 117 */     AnnotationAttributes attributes = AnnotationAttributes.fromMap(metadata.getAnnotationAttributes(name, true));
/* 118 */     Assert.notNull(attributes, "No auto-configuration attributes found. Is " + metadata
/* 119 */       .getClassName() + " annotated with " + 
/* 120 */       ClassUtils.getShortName(name) + "?");
/* 121 */     return attributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Class<?> getAnnotationClass()
/*     */   {
/* 129 */     return EnableAutoConfiguration.class;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<String> getCandidateConfigurations(AnnotationMetadata metadata, AnnotationAttributes attributes)
/*     */   {
/* 143 */     List<String> configurations = SpringFactoriesLoader.loadFactoryNames(
/* 144 */       getSpringFactoriesLoaderFactoryClass(), getBeanClassLoader());
/* 145 */     Assert.notEmpty(configurations, "No auto configuration classes found in META-INF/spring.factories. If you are using a custom packaging, make sure that file is correct.");
/*     */     
/*     */ 
/* 148 */     return configurations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Class<?> getSpringFactoriesLoaderFactoryClass()
/*     */   {
/* 157 */     return EnableAutoConfiguration.class;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Set<String> getExclusions(AnnotationMetadata metadata, AnnotationAttributes attributes)
/*     */   {
/* 169 */     Set<String> excluded = new LinkedHashSet();
/* 170 */     excluded.addAll(asList(attributes, "exclude"));
/* 171 */     excluded.addAll(Arrays.asList(attributes.getStringArray("excludeName")));
/* 172 */     excluded.addAll(getExcludeAutoConfigurationsProperty());
/* 173 */     return excluded;
/*     */   }
/*     */   
/*     */   private List<String> getExcludeAutoConfigurationsProperty() {
/* 177 */     if ((getEnvironment() instanceof ConfigurableEnvironment)) {
/* 178 */       Excludes excludes = new Excludes();
/* 179 */       RelaxedDataBinder binder = new RelaxedDataBinder(excludes, "spring.autoconfigure.");
/*     */       
/* 181 */       binder.bind(new PropertySourcesPropertyValues(
/* 182 */         ((ConfigurableEnvironment)getEnvironment()).getPropertySources()));
/* 183 */       return excludes.getExclude();
/*     */     }
/* 185 */     RelaxedPropertyResolver resolver = new RelaxedPropertyResolver(getEnvironment(), "spring.autoconfigure.");
/*     */     
/* 187 */     String[] exclude = (String[])resolver.getProperty("exclude", String[].class);
/* 188 */     return Arrays.asList(exclude == null ? new String[0] : exclude);
/*     */   }
/*     */   
/*     */   private List<String> sort(List<String> configurations) throws IOException
/*     */   {
/* 193 */     configurations = new AutoConfigurationSorter(getMetadataReaderFactory()).getInPriorityOrder(configurations);
/* 194 */     return configurations;
/*     */   }
/*     */   
/*     */   private MetadataReaderFactory getMetadataReaderFactory() {
/*     */     try {
/* 199 */       return (MetadataReaderFactory)getBeanFactory().getBean("org.springframework.boot.autoconfigure.internalCachingMetadataReaderFactory", MetadataReaderFactory.class);
/*     */     }
/*     */     catch (NoSuchBeanDefinitionException ex) {}
/*     */     
/*     */ 
/* 204 */     return new CachingMetadataReaderFactory(this.resourceLoader);
/*     */   }
/*     */   
/*     */ 
/*     */   private void recordWithConditionEvaluationReport(List<String> configurations, Collection<String> exclusions)
/*     */     throws IOException
/*     */   {
/* 211 */     ConditionEvaluationReport report = ConditionEvaluationReport.get(getBeanFactory());
/* 212 */     report.recordEvaluationCandidates(configurations);
/* 213 */     report.recordExclusions(exclusions);
/*     */   }
/*     */   
/*     */   protected final <T> List<T> removeDuplicates(List<T> list) {
/* 217 */     return new ArrayList(new LinkedHashSet(list));
/*     */   }
/*     */   
/*     */   protected final List<String> asList(AnnotationAttributes attributes, String name) {
/* 221 */     String[] value = attributes.getStringArray(name);
/* 222 */     return Arrays.asList(value == null ? new String[0] : value);
/*     */   }
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException
/*     */   {
/* 227 */     Assert.isInstanceOf(ConfigurableListableBeanFactory.class, beanFactory);
/* 228 */     this.beanFactory = ((ConfigurableListableBeanFactory)beanFactory);
/*     */   }
/*     */   
/*     */   protected final ConfigurableListableBeanFactory getBeanFactory() {
/* 232 */     return this.beanFactory;
/*     */   }
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/* 237 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */   
/*     */   protected ClassLoader getBeanClassLoader() {
/* 241 */     return this.beanClassLoader;
/*     */   }
/*     */   
/*     */   public void setEnvironment(Environment environment)
/*     */   {
/* 246 */     this.environment = environment;
/*     */   }
/*     */   
/*     */   protected final Environment getEnvironment() {
/* 250 */     return this.environment;
/*     */   }
/*     */   
/*     */   public void setResourceLoader(ResourceLoader resourceLoader)
/*     */   {
/* 255 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */   
/*     */   protected final ResourceLoader getResourceLoader() {
/* 259 */     return this.resourceLoader;
/*     */   }
/*     */   
/*     */   public int getOrder()
/*     */   {
/* 264 */     return 2147483646;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static class Excludes
/*     */   {
/* 272 */     private List<String> exclude = new ArrayList();
/*     */     
/*     */     public List<String> getExclude() {
/* 275 */       return this.exclude;
/*     */     }
/*     */     
/*     */     public void setExclude(List<String> excludes) {
/* 279 */       this.exclude = excludes;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\EnableAutoConfigurationImportSelector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */