/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import javax.naming.NamingException;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.annotation.Order;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.jndi.JndiLocatorDelegate;
/*    */ import org.springframework.jndi.JndiLocatorSupport;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Order(2147483627)
/*    */ class OnJndiCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 44 */     AnnotationAttributes annotationAttributes = AnnotationAttributes.fromMap(metadata
/* 45 */       .getAnnotationAttributes(ConditionalOnJndi.class.getName()));
/* 46 */     String[] locations = annotationAttributes.getStringArray("value");
/*    */     try {
/* 48 */       return getMatchOutcome(locations);
/*    */     }
/*    */     catch (NoClassDefFoundError ex) {}
/* 51 */     return ConditionOutcome.noMatch("JNDI class not found");
/*    */   }
/*    */   
/*    */   private ConditionOutcome getMatchOutcome(String[] locations)
/*    */   {
/* 56 */     if (!isJndiAvailable()) {
/* 57 */       return ConditionOutcome.noMatch("JNDI environment is not available");
/*    */     }
/* 59 */     if (locations.length == 0) {
/* 60 */       return ConditionOutcome.match("JNDI environment is available");
/*    */     }
/* 62 */     JndiLocator locator = getJndiLocator(locations);
/* 63 */     String location = locator.lookupFirstLocation();
/* 64 */     if (location != null)
/*    */     {
/* 66 */       return ConditionOutcome.match("JNDI location '" + location + "' found from candidates " + 
/* 67 */         StringUtils.arrayToCommaDelimitedString(locations));
/*    */     }
/* 69 */     return ConditionOutcome.noMatch("No JNDI location found from candidates " + 
/* 70 */       StringUtils.arrayToCommaDelimitedString(locations));
/*    */   }
/*    */   
/*    */   protected boolean isJndiAvailable() {
/* 74 */     return JndiLocatorDelegate.isDefaultJndiEnvironmentAvailable();
/*    */   }
/*    */   
/*    */   protected JndiLocator getJndiLocator(String[] locations) {
/* 78 */     return new JndiLocator(locations);
/*    */   }
/*    */   
/*    */   protected static class JndiLocator extends JndiLocatorSupport
/*    */   {
/*    */     private String[] locations;
/*    */     
/*    */     public JndiLocator(String[] locations) {
/* 86 */       this.locations = locations;
/*    */     }
/*    */     
/*    */     public String lookupFirstLocation() {
/* 90 */       for (String location : this.locations) {
/*    */         try {
/* 92 */           lookup(location);
/* 93 */           return location;
/*    */         }
/*    */         catch (NamingException localNamingException) {}
/*    */       }
/*    */       
/*    */ 
/* 99 */       return null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\condition\OnJndiCondition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */