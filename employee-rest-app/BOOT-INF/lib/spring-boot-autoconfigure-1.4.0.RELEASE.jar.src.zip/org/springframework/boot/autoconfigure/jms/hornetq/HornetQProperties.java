/*     */ package org.springframework.boot.autoconfigure.jms.hornetq;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.hornetq")
/*     */ @Deprecated
/*     */ public class HornetQProperties
/*     */ {
/*     */   private HornetQMode mode;
/*  48 */   private String host = "localhost";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  53 */   private int port = 5445;
/*     */   
/*     */ 
/*     */ 
/*     */   private String user;
/*     */   
/*     */ 
/*     */ 
/*     */   private String password;
/*     */   
/*     */ 
/*     */ 
/*  65 */   private final Embedded embedded = new Embedded();
/*     */   
/*     */   public HornetQMode getMode() {
/*  68 */     return this.mode;
/*     */   }
/*     */   
/*     */   public void setMode(HornetQMode mode) {
/*  72 */     this.mode = mode;
/*     */   }
/*     */   
/*     */   public String getHost() {
/*  76 */     return this.host;
/*     */   }
/*     */   
/*     */   public void setHost(String host) {
/*  80 */     this.host = host;
/*     */   }
/*     */   
/*     */   public int getPort() {
/*  84 */     return this.port;
/*     */   }
/*     */   
/*     */   public void setPort(int port) {
/*  88 */     this.port = port;
/*     */   }
/*     */   
/*     */   public String getUser() {
/*  92 */     return this.user;
/*     */   }
/*     */   
/*     */   public void setUser(String user) {
/*  96 */     this.user = user;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 100 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 104 */     this.password = password;
/*     */   }
/*     */   
/*     */   public Embedded getEmbedded() {
/* 108 */     return this.embedded;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Embedded
/*     */   {
/* 116 */     private static final AtomicInteger serverIdCounter = new AtomicInteger();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 121 */     private int serverId = serverIdCounter.getAndIncrement();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 126 */     private boolean enabled = true;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private boolean persistent;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private String dataDirectory;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 141 */     private String[] queues = new String[0];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 146 */     private String[] topics = new String[0];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 151 */     private String clusterPassword = UUID.randomUUID().toString();
/*     */     
/* 153 */     private boolean defaultClusterPassword = true;
/*     */     
/*     */     public int getServerId() {
/* 156 */       return this.serverId;
/*     */     }
/*     */     
/*     */     public void setServerId(int serverId) {
/* 160 */       this.serverId = serverId;
/*     */     }
/*     */     
/*     */     public boolean isEnabled() {
/* 164 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 168 */       this.enabled = enabled;
/*     */     }
/*     */     
/*     */     public boolean isPersistent() {
/* 172 */       return this.persistent;
/*     */     }
/*     */     
/*     */     public void setPersistent(boolean persistent) {
/* 176 */       this.persistent = persistent;
/*     */     }
/*     */     
/*     */     public String getDataDirectory() {
/* 180 */       return this.dataDirectory;
/*     */     }
/*     */     
/*     */     public void setDataDirectory(String dataDirectory) {
/* 184 */       this.dataDirectory = dataDirectory;
/*     */     }
/*     */     
/*     */     public String[] getQueues() {
/* 188 */       return this.queues;
/*     */     }
/*     */     
/*     */     public void setQueues(String[] queues) {
/* 192 */       this.queues = queues;
/*     */     }
/*     */     
/*     */     public String[] getTopics() {
/* 196 */       return this.topics;
/*     */     }
/*     */     
/*     */     public void setTopics(String[] topics) {
/* 200 */       this.topics = topics;
/*     */     }
/*     */     
/*     */     public String getClusterPassword() {
/* 204 */       return this.clusterPassword;
/*     */     }
/*     */     
/*     */     public void setClusterPassword(String clusterPassword) {
/* 208 */       this.clusterPassword = clusterPassword;
/* 209 */       this.defaultClusterPassword = false;
/*     */     }
/*     */     
/*     */     public boolean isDefaultClusterPassword() {
/* 213 */       return this.defaultClusterPassword;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Map<String, Object> generateTransportParameters()
/*     */     {
/* 224 */       Map<String, Object> parameters = new HashMap();
/* 225 */       parameters.put("server-id", Integer.valueOf(getServerId()));
/* 226 */       return parameters;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jms\hornetq\HornetQProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */