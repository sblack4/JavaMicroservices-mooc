/*    */ package org.springframework.boot.autoconfigure.security.oauth2.client;
/*    */ 
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*    */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
/*    */ import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer.AuthorizedUrl;
/*    */ import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer.ExpressionInterceptUrlRegistry;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration
/*    */ @Conditional({NeedsWebSecurityCondition.class})
/*    */ public class OAuth2SsoDefaultConfiguration
/*    */   extends WebSecurityConfigurerAdapter
/*    */   implements Ordered
/*    */ {
/*    */   private final ApplicationContext applicationContext;
/*    */   private final OAuth2SsoProperties sso;
/*    */   
/*    */   public OAuth2SsoDefaultConfiguration(ApplicationContext applicationContext, OAuth2SsoProperties sso)
/*    */   {
/* 53 */     this.applicationContext = applicationContext;
/* 54 */     this.sso = sso;
/*    */   }
/*    */   
/*    */   protected void configure(HttpSecurity http) throws Exception
/*    */   {
/* 59 */     ((ExpressionUrlAuthorizationConfigurer.AuthorizedUrl)http.antMatcher("/**").authorizeRequests().anyRequest()).authenticated();
/* 60 */     new SsoSecurityConfigurer(this.applicationContext).configure(http);
/*    */   }
/*    */   
/*    */   public int getOrder()
/*    */   {
/* 65 */     if (this.sso.getFilterOrder() != null) {
/* 66 */       return this.sso.getFilterOrder().intValue();
/*    */     }
/* 68 */     if (ClassUtils.isPresent("org.springframework.boot.actuate.autoconfigure.ManagementServerProperties", null))
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/* 73 */       return 2147483635;
/*    */     }
/* 75 */     return 2147483640;
/*    */   }
/*    */   
/*    */ 
/*    */   protected static class NeedsWebSecurityCondition
/*    */     extends SpringBootCondition
/*    */   {
/*    */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */     {
/* 84 */       String[] enablers = context.getBeanFactory().getBeanNamesForAnnotation(EnableOAuth2Sso.class);
/* 85 */       for (String name : enablers) {
/* 86 */         if (context.getBeanFactory().isTypeMatch(name, WebSecurityConfigurerAdapter.class))
/*    */         {
/* 88 */           return ConditionOutcome.noMatch("found @EnableOAuth2Sso on a WebSecurityConfigurerAdapter");
/*    */         }
/*    */       }
/*    */       
/*    */ 
/* 93 */       return ConditionOutcome.match("found no @EnableOAuth2Sso on a WebSecurityConfigurerAdapter");
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\security\oauth2\client\OAuth2SsoDefaultConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */