/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.io.DefaultResourceLoader;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OnResourceCondition
/*    */   extends SpringBootCondition
/*    */ {
/* 38 */   private final ResourceLoader defaultResourceLoader = new DefaultResourceLoader();
/*    */   
/*    */ 
/*    */ 
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 44 */     MultiValueMap<String, Object> attributes = metadata.getAllAnnotationAttributes(ConditionalOnResource.class.getName(), true);
/* 45 */     ResourceLoader loader; if (attributes != null)
/*    */     {
/* 47 */       loader = context.getResourceLoader() == null ? this.defaultResourceLoader : context.getResourceLoader();
/* 48 */       List<String> locations = new ArrayList();
/* 49 */       collectValues(locations, (List)attributes.get("resources"));
/* 50 */       Assert.isTrue(!locations.isEmpty(), "@ConditionalOnResource annotations must specify at least one resource location");
/*    */       
/* 52 */       for (String location : locations)
/*    */       {
/*    */ 
/*    */ 
/* 56 */         if (!loader.getResource(context.getEnvironment().resolvePlaceholders(location)).exists()) {
/* 57 */           return ConditionOutcome.noMatch("resource not found: " + location);
/*    */         }
/*    */       }
/*    */     }
/* 61 */     return ConditionOutcome.match();
/*    */   }
/*    */   
/*    */   private void collectValues(List<String> names, List<Object> values) {
/* 65 */     for (Object value : values) {
/* 66 */       for (Object item : (Object[])value) {
/* 67 */         names.add((String)item);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\condition\OnResourceCondition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */