/*    */ package org.springframework.boot.autoconfigure.elasticsearch.jest;
/*    */ 
/*    */ import com.google.gson.Gson;
/*    */ import io.searchbox.client.JestClient;
/*    */ import io.searchbox.client.JestClientFactory;
/*    */ import io.searchbox.client.config.HttpClientConfig;
/*    */ import io.searchbox.client.config.HttpClientConfig.Builder;
/*    */ import org.apache.http.HttpHost;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.gson.GsonAutoConfiguration;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration
/*    */ @ConditionalOnClass({JestClient.class})
/*    */ @EnableConfigurationProperties({JestProperties.class})
/*    */ @AutoConfigureAfter({GsonAutoConfiguration.class})
/*    */ public class JestAutoConfiguration
/*    */ {
/*    */   private final JestProperties properties;
/*    */   private final ObjectProvider<Gson> gsonProvider;
/*    */   
/*    */   public JestAutoConfiguration(JestProperties properties, ObjectProvider<Gson> gsonProvider)
/*    */   {
/* 55 */     this.properties = properties;
/* 56 */     this.gsonProvider = gsonProvider;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public JestClient jestClient() {
/* 62 */     JestClientFactory factory = new JestClientFactory();
/* 63 */     factory.setHttpClientConfig(createHttpClientConfig());
/* 64 */     return factory.getObject();
/*    */   }
/*    */   
/*    */   protected HttpClientConfig createHttpClientConfig()
/*    */   {
/* 69 */     HttpClientConfig.Builder builder = new HttpClientConfig.Builder(this.properties.getUris());
/* 70 */     if (StringUtils.hasText(this.properties.getUsername())) {
/* 71 */       builder.defaultCredentials(this.properties.getUsername(), this.properties
/* 72 */         .getPassword());
/*    */     }
/* 74 */     String proxyHost = this.properties.getProxy().getHost();
/* 75 */     if (StringUtils.hasText(proxyHost)) {
/* 76 */       Integer proxyPort = this.properties.getProxy().getPort();
/* 77 */       Assert.notNull(proxyPort, "Proxy port must not be null");
/* 78 */       builder.proxy(new HttpHost(proxyHost, proxyPort.intValue()));
/*    */     }
/* 80 */     Gson gson = (Gson)this.gsonProvider.getIfUnique();
/* 81 */     if (gson != null) {
/* 82 */       builder.gson(gson);
/*    */     }
/*    */     
/* 85 */     return ((HttpClientConfig.Builder)((HttpClientConfig.Builder)builder.connTimeout(this.properties.getConnectionTimeout())).readTimeout(this.properties.getReadTimeout())).build();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\elasticsearch\jest\JestAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */