/*     */ package org.springframework.boot.autoconfigure.liquibase;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Map;
/*     */ import javax.validation.constraints.NotNull;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="liquibase", ignoreUnknownFields=false)
/*     */ public class LiquibaseProperties
/*     */ {
/*     */   @NotNull
/*  40 */   private String changeLog = "classpath:/db/changelog/db.changelog-master.yaml";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  46 */   private boolean checkChangeLogLocation = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String contexts;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String defaultSchema;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean dropFirst;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  66 */   private boolean enabled = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String user;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String password;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String url;
/*     */   
/*     */ 
/*     */ 
/*     */   private String labels;
/*     */   
/*     */ 
/*     */ 
/*     */   private Map<String, String> parameters;
/*     */   
/*     */ 
/*     */ 
/*     */   private File rollbackFile;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getChangeLog()
/*     */   {
/* 100 */     return this.changeLog;
/*     */   }
/*     */   
/*     */   public void setChangeLog(String changeLog) {
/* 104 */     this.changeLog = changeLog;
/*     */   }
/*     */   
/*     */   public boolean isCheckChangeLogLocation() {
/* 108 */     return this.checkChangeLogLocation;
/*     */   }
/*     */   
/*     */   public void setCheckChangeLogLocation(boolean checkChangeLogLocation) {
/* 112 */     this.checkChangeLogLocation = checkChangeLogLocation;
/*     */   }
/*     */   
/*     */   public String getContexts() {
/* 116 */     return this.contexts;
/*     */   }
/*     */   
/*     */   public void setContexts(String contexts) {
/* 120 */     this.contexts = contexts;
/*     */   }
/*     */   
/*     */   public String getDefaultSchema() {
/* 124 */     return this.defaultSchema;
/*     */   }
/*     */   
/*     */   public void setDefaultSchema(String defaultSchema) {
/* 128 */     this.defaultSchema = defaultSchema;
/*     */   }
/*     */   
/*     */   public boolean isDropFirst() {
/* 132 */     return this.dropFirst;
/*     */   }
/*     */   
/*     */   public void setDropFirst(boolean dropFirst) {
/* 136 */     this.dropFirst = dropFirst;
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/* 140 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/* 144 */     this.enabled = enabled;
/*     */   }
/*     */   
/*     */   public String getUser() {
/* 148 */     return this.user;
/*     */   }
/*     */   
/*     */   public void setUser(String user) {
/* 152 */     this.user = user;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 156 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 160 */     this.password = password;
/*     */   }
/*     */   
/*     */   public String getUrl() {
/* 164 */     return this.url;
/*     */   }
/*     */   
/*     */   public void setUrl(String url) {
/* 168 */     this.url = url;
/*     */   }
/*     */   
/*     */   public String getLabels() {
/* 172 */     return this.labels;
/*     */   }
/*     */   
/*     */   public void setLabels(String labels) {
/* 176 */     this.labels = labels;
/*     */   }
/*     */   
/*     */   public Map<String, String> getParameters() {
/* 180 */     return this.parameters;
/*     */   }
/*     */   
/*     */   public void setParameters(Map<String, String> parameters) {
/* 184 */     this.parameters = parameters;
/*     */   }
/*     */   
/*     */   public File getRollbackFile() {
/* 188 */     return this.rollbackFile;
/*     */   }
/*     */   
/*     */   public void setRollbackFile(File rollbackFile) {
/* 192 */     this.rollbackFile = rollbackFile;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\liquibase\LiquibaseProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */