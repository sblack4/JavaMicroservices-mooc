/*    */ package org.springframework.boot.autoconfigure.cache;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*    */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*    */ import org.springframework.boot.bind.RelaxedPropertyResolver;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CacheCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 39 */     RelaxedPropertyResolver resolver = new RelaxedPropertyResolver(context.getEnvironment(), "spring.cache.");
/* 40 */     if (!resolver.containsProperty("type")) {
/* 41 */       return ConditionOutcome.match("Automatic cache type");
/*    */     }
/*    */     
/* 44 */     CacheType cacheType = CacheConfigurations.getType(((AnnotationMetadata)metadata).getClassName());
/* 45 */     String value = resolver.getProperty("type").replace("-", "_").toUpperCase();
/* 46 */     if (value.equals(cacheType.name())) {
/* 47 */       return ConditionOutcome.match("Cache type " + cacheType);
/*    */     }
/* 49 */     return ConditionOutcome.noMatch("Cache type " + value);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\cache\CacheCondition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */