/*     */ package org.springframework.boot.autoconfigure.web;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.servlet.MultipartConfigElement;
/*     */ import javax.servlet.ServletRegistration;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureOrder;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.web.servlet.ServletRegistrationBean;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.web.multipart.MultipartResolver;
/*     */ import org.springframework.web.servlet.DispatcherServlet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoConfigureOrder(Integer.MIN_VALUE)
/*     */ @Configuration
/*     */ @ConditionalOnWebApplication
/*     */ @ConditionalOnClass({DispatcherServlet.class})
/*     */ @AutoConfigureAfter({EmbeddedServletContainerAutoConfiguration.class})
/*     */ public class DispatcherServletAutoConfiguration
/*     */ {
/*     */   public static final String DEFAULT_DISPATCHER_SERVLET_BEAN_NAME = "dispatcherServlet";
/*     */   public static final String DEFAULT_DISPATCHER_SERVLET_REGISTRATION_BEAN_NAME = "dispatcherServletRegistration";
/*     */   
/*     */   @Configuration
/*     */   @Conditional({DispatcherServletAutoConfiguration.DefaultDispatcherServletCondition.class})
/*     */   @ConditionalOnClass({ServletRegistration.class})
/*     */   @EnableConfigurationProperties({WebMvcProperties.class})
/*     */   protected static class DispatcherServletConfiguration
/*     */   {
/*     */     private final WebMvcProperties webMvcProperties;
/*     */     
/*     */     public DispatcherServletConfiguration(WebMvcProperties webMvcProperties)
/*     */     {
/*  87 */       this.webMvcProperties = webMvcProperties;
/*     */     }
/*     */     
/*     */     @Bean(name={"dispatcherServlet"})
/*     */     public DispatcherServlet dispatcherServlet() {
/*  92 */       DispatcherServlet dispatcherServlet = new DispatcherServlet();
/*  93 */       dispatcherServlet.setDispatchOptionsRequest(this.webMvcProperties
/*  94 */         .isDispatchOptionsRequest());
/*  95 */       dispatcherServlet.setDispatchTraceRequest(this.webMvcProperties
/*  96 */         .isDispatchTraceRequest());
/*  97 */       dispatcherServlet.setThrowExceptionIfNoHandlerFound(this.webMvcProperties
/*  98 */         .isThrowExceptionIfNoHandlerFound());
/*  99 */       return dispatcherServlet;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnBean({MultipartResolver.class})
/*     */     @ConditionalOnMissingBean(name={"multipartResolver"})
/*     */     public MultipartResolver multipartResolver(MultipartResolver resolver)
/*     */     {
/* 107 */       return resolver;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   @Configuration
/*     */   @Conditional({DispatcherServletAutoConfiguration.DispatcherServletRegistrationCondition.class})
/*     */   @ConditionalOnClass({ServletRegistration.class})
/*     */   @EnableConfigurationProperties({WebMvcProperties.class})
/*     */   @Import({DispatcherServletAutoConfiguration.DispatcherServletConfiguration.class})
/*     */   protected static class DispatcherServletRegistrationConfiguration
/*     */   {
/*     */     private final ServerProperties serverProperties;
/*     */     
/*     */     private final WebMvcProperties webMvcProperties;
/*     */     
/*     */     private final MultipartConfigElement multipartConfig;
/*     */     
/*     */ 
/*     */     public DispatcherServletRegistrationConfiguration(ServerProperties serverProperties, WebMvcProperties webMvcProperties, ObjectProvider<MultipartConfigElement> multipartConfigProvider)
/*     */     {
/* 128 */       this.serverProperties = serverProperties;
/* 129 */       this.webMvcProperties = webMvcProperties;
/* 130 */       this.multipartConfig = ((MultipartConfigElement)multipartConfigProvider.getIfAvailable());
/*     */     }
/*     */     
/*     */ 
/*     */     @Bean(name={"dispatcherServletRegistration"})
/*     */     @ConditionalOnBean(value={DispatcherServlet.class}, name={"dispatcherServlet"})
/*     */     public ServletRegistrationBean dispatcherServletRegistration(DispatcherServlet dispatcherServlet)
/*     */     {
/* 138 */       ServletRegistrationBean registration = new ServletRegistrationBean(dispatcherServlet, new String[] { this.serverProperties.getServletMapping() });
/* 139 */       registration.setName("dispatcherServlet");
/* 140 */       registration.setLoadOnStartup(this.webMvcProperties
/* 141 */         .getServlet().getLoadOnStartup());
/* 142 */       if (this.multipartConfig != null) {
/* 143 */         registration.setMultipartConfig(this.multipartConfig);
/*     */       }
/* 145 */       return registration;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   @Order(2147483637)
/*     */   private static class DefaultDispatcherServletCondition
/*     */     extends SpringBootCondition
/*     */   {
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*     */     {
/* 156 */       ConfigurableListableBeanFactory beanFactory = context.getBeanFactory();
/* 157 */       List<String> dispatchServletBeans = Arrays.asList(beanFactory
/* 158 */         .getBeanNamesForType(DispatcherServlet.class, false, false));
/* 159 */       if (dispatchServletBeans.contains("dispatcherServlet")) {
/* 160 */         return ConditionOutcome.noMatch("found DispatcherServlet named dispatcherServlet");
/*     */       }
/*     */       
/* 163 */       if (beanFactory.containsBean("dispatcherServlet")) {
/* 164 */         return ConditionOutcome.noMatch("found non-DispatcherServlet named dispatcherServlet");
/*     */       }
/*     */       
/* 167 */       if (dispatchServletBeans.isEmpty()) {
/* 168 */         return ConditionOutcome.match("no DispatcherServlet found");
/*     */       }
/*     */       
/* 171 */       return ConditionOutcome.match("one or more DispatcherServlets found and none is named dispatcherServlet");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Order(2147483637)
/*     */   private static class DispatcherServletRegistrationCondition
/*     */     extends SpringBootCondition
/*     */   {
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*     */     {
/* 184 */       ConfigurableListableBeanFactory beanFactory = context.getBeanFactory();
/* 185 */       ConditionOutcome outcome = checkDefaultDispatcherName(beanFactory);
/* 186 */       if (!outcome.isMatch()) {
/* 187 */         return outcome;
/*     */       }
/* 189 */       return checkServletRegistration(beanFactory);
/*     */     }
/*     */     
/*     */     private ConditionOutcome checkDefaultDispatcherName(ConfigurableListableBeanFactory beanFactory)
/*     */     {
/* 194 */       List<String> servlets = Arrays.asList(beanFactory
/* 195 */         .getBeanNamesForType(DispatcherServlet.class, false, false));
/*     */       
/* 197 */       boolean containsDispatcherBean = beanFactory.containsBean("dispatcherServlet");
/* 198 */       if ((containsDispatcherBean) && 
/* 199 */         (!servlets.contains("dispatcherServlet"))) {
/* 200 */         return ConditionOutcome.noMatch("found non-DispatcherServlet named dispatcherServlet");
/*     */       }
/*     */       
/* 203 */       return ConditionOutcome.match();
/*     */     }
/*     */     
/*     */     private ConditionOutcome checkServletRegistration(ConfigurableListableBeanFactory beanFactory)
/*     */     {
/* 208 */       List<String> registrations = Arrays.asList(beanFactory
/* 209 */         .getBeanNamesForType(ServletRegistrationBean.class, false, false));
/*     */       
/* 211 */       boolean containsDispatcherRegistrationBean = beanFactory.containsBean("dispatcherServletRegistration");
/* 212 */       if (registrations.isEmpty()) {
/* 213 */         if (containsDispatcherRegistrationBean) {
/* 214 */           return ConditionOutcome.noMatch("found no ServletRegistrationBean but a non-ServletRegistrationBean named dispatcherServletRegistration");
/*     */         }
/*     */         
/*     */ 
/* 218 */         return ConditionOutcome.match("no ServletRegistrationBean found");
/*     */       }
/*     */       
/* 221 */       if (registrations.contains("dispatcherServletRegistration")) {
/* 222 */         return ConditionOutcome.noMatch("found ServletRegistrationBean named dispatcherServletRegistration");
/*     */       }
/*     */       
/* 225 */       if (containsDispatcherRegistrationBean) {
/* 226 */         return ConditionOutcome.noMatch("found non-ServletRegistrationBean named dispatcherServletRegistration");
/*     */       }
/*     */       
/*     */ 
/* 230 */       return ConditionOutcome.match("one or more ServletRegistrationBeans is found and none is named dispatcherServletRegistration");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\web\DispatcherServletAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */