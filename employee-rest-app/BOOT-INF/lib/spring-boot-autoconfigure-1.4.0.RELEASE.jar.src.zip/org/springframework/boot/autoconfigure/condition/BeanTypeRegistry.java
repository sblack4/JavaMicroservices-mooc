/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.CannotLoadBeanClassException;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.SmartInitializingSingleton;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.core.type.StandardMethodMetadata;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BeanTypeRegistry
/*     */ {
/*  66 */   private static final Log logger = LogFactory.getLog(BeanTypeRegistry.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String FACTORY_BEAN_OBJECT_TYPE = "factoryBeanObjectType";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Set<String> getNamesForType(Class<?> paramClass);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final Class<?> getFactoryBeanGeneric(ConfigurableListableBeanFactory beanFactory, BeanDefinition definition, String name)
/*     */   {
/*     */     try
/*     */     {
/*  92 */       return doGetFactoryBeanGeneric(beanFactory, definition, name);
/*     */     }
/*     */     catch (Exception ex) {}
/*  95 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   private Class<?> doGetFactoryBeanGeneric(ConfigurableListableBeanFactory beanFactory, BeanDefinition definition, String name)
/*     */     throws Exception, ClassNotFoundException, LinkageError
/*     */   {
/* 102 */     if ((StringUtils.hasLength(definition.getFactoryBeanName())) && 
/* 103 */       (StringUtils.hasLength(definition.getFactoryMethodName()))) {
/* 104 */       return getConfigurationClassFactoryBeanGeneric(beanFactory, definition, name);
/*     */     }
/* 106 */     if (StringUtils.hasLength(definition.getBeanClassName())) {
/* 107 */       return getDirectFactoryBeanGeneric(beanFactory, definition, name);
/*     */     }
/* 109 */     return null;
/*     */   }
/*     */   
/*     */   private Class<?> getConfigurationClassFactoryBeanGeneric(ConfigurableListableBeanFactory beanFactory, BeanDefinition definition, String name)
/*     */     throws Exception
/*     */   {
/* 115 */     Method method = getFactoryMethod(beanFactory, definition);
/*     */     
/* 117 */     Class<?> generic = ResolvableType.forMethodReturnType(method).as(FactoryBean.class).resolveGeneric(new int[0]);
/* 118 */     if (((generic == null) || (generic.equals(Object.class))) && 
/* 119 */       (definition.hasAttribute("factoryBeanObjectType"))) {
/* 120 */       generic = getTypeFromAttribute(definition
/* 121 */         .getAttribute("factoryBeanObjectType"));
/*     */     }
/* 123 */     return generic;
/*     */   }
/*     */   
/*     */   private Method getFactoryMethod(ConfigurableListableBeanFactory beanFactory, BeanDefinition definition) throws Exception
/*     */   {
/* 128 */     if ((definition instanceof AnnotatedBeanDefinition))
/*     */     {
/* 130 */       MethodMetadata factoryMethodMetadata = ((AnnotatedBeanDefinition)definition).getFactoryMethodMetadata();
/* 131 */       if ((factoryMethodMetadata instanceof StandardMethodMetadata))
/*     */       {
/* 133 */         return ((StandardMethodMetadata)factoryMethodMetadata).getIntrospectedMethod();
/*     */       }
/*     */     }
/*     */     
/* 137 */     BeanDefinition factoryDefinition = beanFactory.getBeanDefinition(definition.getFactoryBeanName());
/* 138 */     Class<?> factoryClass = ClassUtils.forName(factoryDefinition.getBeanClassName(), beanFactory
/* 139 */       .getBeanClassLoader());
/* 140 */     return ReflectionUtils.findMethod(factoryClass, definition
/* 141 */       .getFactoryMethodName());
/*     */   }
/*     */   
/*     */   private Class<?> getDirectFactoryBeanGeneric(ConfigurableListableBeanFactory beanFactory, BeanDefinition definition, String name)
/*     */     throws ClassNotFoundException, LinkageError
/*     */   {
/* 147 */     Class<?> factoryBeanClass = ClassUtils.forName(definition.getBeanClassName(), beanFactory
/* 148 */       .getBeanClassLoader());
/*     */     
/* 150 */     Class<?> generic = ResolvableType.forClass(factoryBeanClass).as(FactoryBean.class).resolveGeneric(new int[0]);
/* 151 */     if (((generic == null) || (generic.equals(Object.class))) && 
/* 152 */       (definition.hasAttribute("factoryBeanObjectType"))) {
/* 153 */       generic = getTypeFromAttribute(definition
/* 154 */         .getAttribute("factoryBeanObjectType"));
/*     */     }
/* 156 */     return generic;
/*     */   }
/*     */   
/*     */   private Class<?> getTypeFromAttribute(Object attribute) throws ClassNotFoundException, LinkageError
/*     */   {
/* 161 */     if ((attribute instanceof Class)) {
/* 162 */       return (Class)attribute;
/*     */     }
/* 164 */     if ((attribute instanceof String)) {
/* 165 */       return ClassUtils.forName((String)attribute, null);
/*     */     }
/* 167 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BeanTypeRegistry get(ListableBeanFactory beanFactory)
/*     */   {
/* 176 */     if ((beanFactory instanceof DefaultListableBeanFactory)) {
/* 177 */       DefaultListableBeanFactory listableBeanFactory = (DefaultListableBeanFactory)beanFactory;
/* 178 */       if (listableBeanFactory.isAllowEagerClassLoading()) {
/* 179 */         return OptimizedBeanTypeRegistry.getFromFactory(listableBeanFactory);
/*     */       }
/*     */     }
/* 182 */     return new DefaultBeanTypeRegistry(beanFactory);
/*     */   }
/*     */   
/*     */ 
/*     */   static class DefaultBeanTypeRegistry
/*     */     extends BeanTypeRegistry
/*     */   {
/*     */     private final ListableBeanFactory beanFactory;
/*     */     
/*     */     DefaultBeanTypeRegistry(ListableBeanFactory beanFactory)
/*     */     {
/* 193 */       this.beanFactory = beanFactory;
/*     */     }
/*     */     
/*     */     public Set<String> getNamesForType(Class<?> type)
/*     */     {
/* 198 */       Set<String> result = new LinkedHashSet();
/* 199 */       result.addAll(
/* 200 */         Arrays.asList(this.beanFactory.getBeanNamesForType(type, true, false)));
/* 201 */       if ((this.beanFactory instanceof ConfigurableListableBeanFactory)) {
/* 202 */         collectBeanNamesForTypeFromFactoryBeans(result, (ConfigurableListableBeanFactory)this.beanFactory, type);
/*     */       }
/*     */       
/* 205 */       return result;
/*     */     }
/*     */     
/*     */     private void collectBeanNamesForTypeFromFactoryBeans(Set<String> result, ConfigurableListableBeanFactory beanFactory, Class<?> type)
/*     */     {
/* 210 */       String[] names = beanFactory.getBeanNamesForType(FactoryBean.class, true, false);
/*     */       
/* 212 */       for (String name : names) {
/* 213 */         name = BeanFactoryUtils.transformedBeanName(name);
/* 214 */         BeanDefinition beanDefinition = beanFactory.getBeanDefinition(name);
/* 215 */         Class<?> generic = getFactoryBeanGeneric(beanFactory, beanDefinition, name);
/*     */         
/* 217 */         if ((generic != null) && (ClassUtils.isAssignable(type, generic))) {
/* 218 */           result.add(name);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static class OptimizedBeanTypeRegistry
/*     */     extends BeanTypeRegistry
/*     */     implements SmartInitializingSingleton
/*     */   {
/* 232 */     private static final String BEAN_NAME = BeanTypeRegistry.class.getName();
/*     */     
/*     */     private final DefaultListableBeanFactory beanFactory;
/*     */     
/* 236 */     private final Map<String, Class<?>> beanTypes = new HashMap();
/*     */     
/* 238 */     private int lastBeanDefinitionCount = 0;
/*     */     
/*     */     OptimizedBeanTypeRegistry(DefaultListableBeanFactory beanFactory) {
/* 241 */       this.beanFactory = beanFactory;
/*     */     }
/*     */     
/*     */ 
/*     */     public void afterSingletonsInstantiated()
/*     */     {
/* 247 */       this.beanTypes.clear();
/* 248 */       this.lastBeanDefinitionCount = 0;
/*     */     }
/*     */     
/*     */     public Set<String> getNamesForType(Class<?> type)
/*     */     {
/*     */       String name;
/* 254 */       if (this.lastBeanDefinitionCount != this.beanFactory.getBeanDefinitionCount()) {
/* 255 */         Iterator<String> names = this.beanFactory.getBeanNamesIterator();
/* 256 */         while (names.hasNext()) {
/* 257 */           name = (String)names.next();
/* 258 */           if (!this.beanTypes.containsKey(name)) {
/* 259 */             addBeanType(name);
/*     */           }
/*     */         }
/* 262 */         this.lastBeanDefinitionCount = this.beanFactory.getBeanDefinitionCount();
/*     */       }
/* 264 */       Set<String> matches = new LinkedHashSet();
/* 265 */       for (Map.Entry<String, Class<?>> entry : this.beanTypes.entrySet()) {
/* 266 */         if ((entry.getValue() != null) && (type.isAssignableFrom((Class)entry.getValue()))) {
/* 267 */           matches.add(entry.getKey());
/*     */         }
/*     */       }
/* 270 */       return matches;
/*     */     }
/*     */     
/*     */     private void addBeanType(String name) {
/* 274 */       if (this.beanFactory.containsSingleton(name)) {
/* 275 */         this.beanTypes.put(name, this.beanFactory.getType(name));
/*     */       }
/* 277 */       else if (!this.beanFactory.isAlias(name)) {
/* 278 */         addBeanTypeForNonAliasDefinition(name);
/*     */       }
/*     */     }
/*     */     
/*     */     private void addBeanTypeForNonAliasDefinition(String name) {
/*     */       try {
/* 284 */         String factoryName = "&" + name;
/*     */         
/* 286 */         RootBeanDefinition beanDefinition = (RootBeanDefinition)this.beanFactory.getMergedBeanDefinition(name);
/* 287 */         if ((!beanDefinition.isAbstract()) && 
/* 288 */           (!requiresEagerInit(beanDefinition.getFactoryBeanName()))) {
/* 289 */           if (this.beanFactory.isFactoryBean(factoryName)) {
/* 290 */             Class<?> factoryBeanGeneric = getFactoryBeanGeneric(this.beanFactory, beanDefinition, name);
/*     */             
/* 292 */             this.beanTypes.put(name, factoryBeanGeneric);
/* 293 */             this.beanTypes.put(factoryName, this.beanFactory
/* 294 */               .getType(factoryName));
/*     */           }
/*     */           else {
/* 297 */             this.beanTypes.put(name, this.beanFactory.getType(name));
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (CannotLoadBeanClassException ex)
/*     */       {
/* 303 */         logIgnoredError("bean class loading failure for bean", name, ex);
/*     */       }
/*     */       catch (BeanDefinitionStoreException ex)
/*     */       {
/* 307 */         logIgnoredError("unresolvable metadata in bean definition", name, ex);
/*     */       }
/*     */     }
/*     */     
/*     */     private void logIgnoredError(String message, String name, Exception ex) {
/* 312 */       if (BeanTypeRegistry.logger.isDebugEnabled()) {
/* 313 */         BeanTypeRegistry.logger.debug("Ignoring " + message + " '" + name + "'", ex);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private boolean requiresEagerInit(String factoryBeanName)
/*     */     {
/* 321 */       return (factoryBeanName != null) && (this.beanFactory.isFactoryBean(factoryBeanName)) && (!this.beanFactory.containsSingleton(factoryBeanName));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static OptimizedBeanTypeRegistry getFromFactory(DefaultListableBeanFactory factory)
/*     */     {
/* 331 */       if (!factory.containsLocalBean(BEAN_NAME)) {
/* 332 */         BeanDefinition bd = new RootBeanDefinition(OptimizedBeanTypeRegistry.class);
/*     */         
/* 334 */         bd.getConstructorArgumentValues().addIndexedArgumentValue(0, factory);
/* 335 */         factory.registerBeanDefinition(BEAN_NAME, bd);
/*     */       }
/*     */       
/* 338 */       return (OptimizedBeanTypeRegistry)factory.getBean(BEAN_NAME, OptimizedBeanTypeRegistry.class);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\condition\BeanTypeRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */