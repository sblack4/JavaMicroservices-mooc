/*     */ package org.springframework.boot.autoconfigure.transaction.jta;
/*     */ 
/*     */ import com.arjuna.ats.jbossatx.jta.RecoveryManagerService;
/*     */ import java.io.File;
/*     */ import javax.jms.Message;
/*     */ import org.springframework.boot.ApplicationHome;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.jta.XAConnectionFactoryWrapper;
/*     */ import org.springframework.boot.jta.XADataSourceWrapper;
/*     */ import org.springframework.boot.jta.narayana.NarayanaBeanFactoryPostProcessor;
/*     */ import org.springframework.boot.jta.narayana.NarayanaConfigurationBean;
/*     */ import org.springframework.boot.jta.narayana.NarayanaProperties;
/*     */ import org.springframework.boot.jta.narayana.NarayanaRecoveryManagerBean;
/*     */ import org.springframework.boot.jta.narayana.NarayanaXAConnectionFactoryWrapper;
/*     */ import org.springframework.boot.jta.narayana.NarayanaXADataSourceWrapper;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.DependsOn;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ import org.springframework.transaction.jta.JtaTransactionManager;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @ConditionalOnClass({JtaTransactionManager.class, com.arjuna.ats.jta.UserTransaction.class})
/*     */ @ConditionalOnMissingBean({PlatformTransactionManager.class})
/*     */ public class NarayanaJtaConfiguration
/*     */ {
/*     */   private final JtaProperties jtaProperties;
/*     */   
/*     */   public NarayanaJtaConfiguration(JtaProperties jtaProperties)
/*     */   {
/*  60 */     this.jtaProperties = jtaProperties;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public NarayanaProperties narayanaProperties() {
/*  66 */     return new NarayanaProperties();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public NarayanaConfigurationBean narayanaConfiguration(NarayanaProperties properties)
/*     */   {
/*  73 */     properties.setLogDir(getLogDir().getAbsolutePath());
/*  74 */     if (this.jtaProperties.getTransactionManagerId() != null) {
/*  75 */       properties.setTransactionManagerId(this.jtaProperties
/*  76 */         .getTransactionManagerId());
/*     */     }
/*  78 */     return new NarayanaConfigurationBean(properties);
/*     */   }
/*     */   
/*     */   private File getLogDir() {
/*  82 */     if (StringUtils.hasLength(this.jtaProperties.getLogDir())) {
/*  83 */       return new File(this.jtaProperties.getLogDir());
/*     */     }
/*  85 */     File home = new ApplicationHome().getDir();
/*  86 */     return new File(home, "transaction-logs");
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @DependsOn({"narayanaConfiguration"})
/*     */   @ConditionalOnMissingBean
/*     */   public javax.transaction.UserTransaction narayanaUserTransaction() {
/*  93 */     return com.arjuna.ats.jta.UserTransaction.userTransaction();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @DependsOn({"narayanaConfiguration"})
/*     */   @ConditionalOnMissingBean
/*     */   public javax.transaction.TransactionManager narayanaTransactionManager() {
/* 100 */     return com.arjuna.ats.jta.TransactionManager.transactionManager();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @DependsOn({"narayanaConfiguration"})
/*     */   public RecoveryManagerService narayanaRecoveryManagerService() {
/* 106 */     return new RecoveryManagerService();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   public NarayanaRecoveryManagerBean narayanaRecoveryManager(RecoveryManagerService recoveryManagerService)
/*     */   {
/* 112 */     return new NarayanaRecoveryManagerBean(recoveryManagerService);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   public JtaTransactionManager transactionManager(javax.transaction.UserTransaction userTransaction, javax.transaction.TransactionManager transactionManager)
/*     */   {
/* 118 */     return new JtaTransactionManager(userTransaction, transactionManager);
/*     */   }
/*     */   
/*     */ 
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({XADataSourceWrapper.class})
/*     */   public XADataSourceWrapper xaDataSourceWrapper(NarayanaRecoveryManagerBean narayanaRecoveryManagerBean, NarayanaProperties narayanaProperties)
/*     */   {
/* 126 */     return new NarayanaXADataSourceWrapper(narayanaRecoveryManagerBean, narayanaProperties);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public static NarayanaBeanFactoryPostProcessor narayanaBeanFactoryPostProcessor()
/*     */   {
/* 133 */     return new NarayanaBeanFactoryPostProcessor();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Configuration
/*     */   @ConditionalOnClass({Message.class})
/*     */   static class NarayanaJtaJmsConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({XAConnectionFactoryWrapper.class})
/*     */     public NarayanaXAConnectionFactoryWrapper xaConnectionFactoryWrapper(javax.transaction.TransactionManager transactionManager, NarayanaRecoveryManagerBean narayanaRecoveryManagerBean, NarayanaProperties narayanaProperties)
/*     */     {
/* 146 */       return new NarayanaXAConnectionFactoryWrapper(transactionManager, narayanaRecoveryManagerBean, narayanaProperties);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\transaction\jta\NarayanaJtaConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */