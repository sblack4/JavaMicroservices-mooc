/*    */ package org.springframework.boot.autoconfigure.webservices;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.validation.constraints.NotNull;
/*    */ import javax.validation.constraints.Pattern;
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties("spring.webservices")
/*    */ public class WebServicesProperties
/*    */ {
/*    */   @NotNull
/*    */   @Pattern(regexp="/[^?#]*", message="Path must start with /")
/* 40 */   private String path = "/services";
/*    */   
/*    */ 
/*    */ 
/* 44 */   private final Servlet servlet = new Servlet();
/*    */   
/*    */   public String getPath() {
/* 47 */     return this.path;
/*    */   }
/*    */   
/*    */   public void setPath(String path) {
/* 51 */     this.path = path;
/*    */   }
/*    */   
/*    */   public Servlet getServlet() {
/* 55 */     return this.servlet;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static class Servlet
/*    */   {
/* 63 */     private Map<String, String> init = new HashMap();
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 68 */     private int loadOnStartup = -1;
/*    */     
/*    */     public Map<String, String> getInit() {
/* 71 */       return this.init;
/*    */     }
/*    */     
/*    */     public void setInit(Map<String, String> init) {
/* 75 */       this.init = init;
/*    */     }
/*    */     
/*    */     public int getLoadOnStartup() {
/* 79 */       return this.loadOnStartup;
/*    */     }
/*    */     
/*    */     public void setLoadOnStartup(int loadOnStartup) {
/* 83 */       this.loadOnStartup = loadOnStartup;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\webservices\WebServicesProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */