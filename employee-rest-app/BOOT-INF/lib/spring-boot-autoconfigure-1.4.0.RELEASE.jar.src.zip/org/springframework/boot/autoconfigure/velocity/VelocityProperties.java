/*     */ package org.springframework.boot.autoconfigure.velocity;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.autoconfigure.template.AbstractTemplateViewResolverProperties;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.web.servlet.view.velocity.VelocityViewResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ @ConfigurationProperties(prefix="spring.velocity")
/*     */ public class VelocityProperties
/*     */   extends AbstractTemplateViewResolverProperties
/*     */ {
/*     */   public static final String DEFAULT_RESOURCE_LOADER_PATH = "classpath:/templates/";
/*     */   public static final String DEFAULT_PREFIX = "";
/*     */   public static final String DEFAULT_SUFFIX = ".vm";
/*     */   private String dateToolAttribute;
/*     */   private String numberToolAttribute;
/*  57 */   private Map<String, String> properties = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  62 */   private String resourceLoaderPath = "classpath:/templates/";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String toolboxConfigLocation;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  75 */   private boolean preferFileSystemAccess = true;
/*     */   
/*     */   public VelocityProperties() {
/*  78 */     super("", ".vm");
/*     */   }
/*     */   
/*     */   public String getDateToolAttribute() {
/*  82 */     return this.dateToolAttribute;
/*     */   }
/*     */   
/*     */   public void setDateToolAttribute(String dateToolAttribute) {
/*  86 */     this.dateToolAttribute = dateToolAttribute;
/*     */   }
/*     */   
/*     */   public String getNumberToolAttribute() {
/*  90 */     return this.numberToolAttribute;
/*     */   }
/*     */   
/*     */   public void setNumberToolAttribute(String numberToolAttribute) {
/*  94 */     this.numberToolAttribute = numberToolAttribute;
/*     */   }
/*     */   
/*     */   public Map<String, String> getProperties() {
/*  98 */     return this.properties;
/*     */   }
/*     */   
/*     */   public void setProperties(Map<String, String> properties) {
/* 102 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   public String getResourceLoaderPath() {
/* 106 */     return this.resourceLoaderPath;
/*     */   }
/*     */   
/*     */   public void setResourceLoaderPath(String resourceLoaderPath) {
/* 110 */     this.resourceLoaderPath = resourceLoaderPath;
/*     */   }
/*     */   
/*     */   public String getToolboxConfigLocation() {
/* 114 */     return this.toolboxConfigLocation;
/*     */   }
/*     */   
/*     */   public void setToolboxConfigLocation(String toolboxConfigLocation) {
/* 118 */     this.toolboxConfigLocation = toolboxConfigLocation;
/*     */   }
/*     */   
/*     */   public boolean isPreferFileSystemAccess() {
/* 122 */     return this.preferFileSystemAccess;
/*     */   }
/*     */   
/*     */   public void setPreferFileSystemAccess(boolean preferFileSystemAccess) {
/* 126 */     this.preferFileSystemAccess = preferFileSystemAccess;
/*     */   }
/*     */   
/*     */   public void applyToViewResolver(Object viewResolver)
/*     */   {
/* 131 */     super.applyToViewResolver(viewResolver);
/* 132 */     VelocityViewResolver resolver = (VelocityViewResolver)viewResolver;
/* 133 */     resolver.setToolboxConfigLocation(getToolboxConfigLocation());
/* 134 */     resolver.setDateToolAttribute(getDateToolAttribute());
/* 135 */     resolver.setNumberToolAttribute(getNumberToolAttribute());
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\velocity\VelocityProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */