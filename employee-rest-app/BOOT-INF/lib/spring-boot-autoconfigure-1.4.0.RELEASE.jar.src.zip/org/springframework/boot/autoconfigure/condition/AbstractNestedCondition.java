/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.context.annotation.Condition;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.ConfigurationCondition;
/*     */ import org.springframework.context.annotation.ConfigurationCondition.ConfigurationPhase;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.core.type.classreading.SimpleMetadataReaderFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractNestedCondition
/*     */   extends SpringBootCondition
/*     */   implements ConfigurationCondition
/*     */ {
/*     */   private final ConfigurationCondition.ConfigurationPhase configurationPhase;
/*     */   
/*     */   AbstractNestedCondition(ConfigurationCondition.ConfigurationPhase configurationPhase)
/*     */   {
/*  51 */     Assert.notNull(configurationPhase, "ConfigurationPhase must not be null");
/*  52 */     this.configurationPhase = configurationPhase;
/*     */   }
/*     */   
/*     */   public ConfigurationCondition.ConfigurationPhase getConfigurationPhase()
/*     */   {
/*  57 */     return this.configurationPhase;
/*     */   }
/*     */   
/*     */ 
/*     */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*     */   {
/*  63 */     String className = getClass().getName();
/*  64 */     MemberConditions memberConditions = new MemberConditions(context, className);
/*  65 */     MemberMatchOutcomes memberOutcomes = new MemberMatchOutcomes(memberConditions);
/*  66 */     return getFinalMatchOutcome(memberOutcomes);
/*     */   }
/*     */   
/*     */ 
/*     */   protected abstract ConditionOutcome getFinalMatchOutcome(MemberMatchOutcomes paramMemberMatchOutcomes);
/*     */   
/*     */ 
/*     */   protected static class MemberMatchOutcomes
/*     */   {
/*     */     private final List<ConditionOutcome> all;
/*     */     private final List<ConditionOutcome> matches;
/*     */     private final List<ConditionOutcome> nonMatches;
/*     */     
/*     */     public MemberMatchOutcomes(AbstractNestedCondition.MemberConditions memberConditions)
/*     */     {
/*  81 */       this.all = Collections.unmodifiableList(memberConditions.getMatchOutcomes());
/*  82 */       List<ConditionOutcome> matches = new ArrayList();
/*  83 */       List<ConditionOutcome> nonMatches = new ArrayList();
/*  84 */       for (ConditionOutcome outcome : this.all) {
/*  85 */         (outcome.isMatch() ? matches : nonMatches).add(outcome);
/*     */       }
/*  87 */       this.matches = Collections.unmodifiableList(matches);
/*  88 */       this.nonMatches = Collections.unmodifiableList(nonMatches);
/*     */     }
/*     */     
/*     */     public List<ConditionOutcome> getAll() {
/*  92 */       return this.all;
/*     */     }
/*     */     
/*     */     public List<ConditionOutcome> getMatches() {
/*  96 */       return this.matches;
/*     */     }
/*     */     
/*     */     public List<ConditionOutcome> getNonMatches() {
/* 100 */       return this.nonMatches;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class MemberConditions
/*     */   {
/*     */     private final ConditionContext context;
/*     */     
/*     */     private final MetadataReaderFactory readerFactory;
/*     */     private final Map<AnnotationMetadata, List<Condition>> memberConditions;
/*     */     
/*     */     MemberConditions(ConditionContext context, String className)
/*     */     {
/* 114 */       this.context = context;
/*     */       
/* 116 */       this.readerFactory = new SimpleMetadataReaderFactory(context.getResourceLoader());
/* 117 */       String[] members = getMetadata(className).getMemberClassNames();
/* 118 */       this.memberConditions = getMemberConditions(members);
/*     */     }
/*     */     
/*     */     private Map<AnnotationMetadata, List<Condition>> getMemberConditions(String[] members)
/*     */     {
/* 123 */       MultiValueMap<AnnotationMetadata, Condition> memberConditions = new LinkedMultiValueMap();
/* 124 */       AnnotationMetadata metadata; for (String member : members) {
/* 125 */         metadata = getMetadata(member);
/* 126 */         for (String[] conditionClasses : getConditionClasses(metadata)) {
/* 127 */           for (String conditionClass : conditionClasses) {
/* 128 */             Condition condition = getCondition(conditionClass);
/* 129 */             memberConditions.add(metadata, condition);
/*     */           }
/*     */         }
/*     */       }
/* 133 */       return Collections.unmodifiableMap(memberConditions);
/*     */     }
/*     */     
/*     */     private AnnotationMetadata getMetadata(String className)
/*     */     {
/*     */       try {
/* 139 */         return this.readerFactory.getMetadataReader(className).getAnnotationMetadata();
/*     */       }
/*     */       catch (IOException ex) {
/* 142 */         throw new IllegalStateException(ex);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     private List<String[]> getConditionClasses(AnnotatedTypeMetadata metadata)
/*     */     {
/* 149 */       MultiValueMap<String, Object> attributes = metadata.getAllAnnotationAttributes(Conditional.class.getName(), true);
/* 150 */       Object values = attributes != null ? (List)attributes.get("value") : null;
/* 151 */       return (List)(values != null ? values : Collections.emptyList());
/*     */     }
/*     */     
/*     */     private Condition getCondition(String conditionClassName) {
/* 155 */       Class<?> conditionClass = ClassUtils.resolveClassName(conditionClassName, this.context
/* 156 */         .getClassLoader());
/* 157 */       return (Condition)BeanUtils.instantiateClass(conditionClass);
/*     */     }
/*     */     
/*     */     public List<ConditionOutcome> getMatchOutcomes() {
/* 161 */       List<ConditionOutcome> outcomes = new ArrayList();
/* 162 */       for (Map.Entry<AnnotationMetadata, List<Condition>> entry : this.memberConditions
/* 163 */         .entrySet()) {
/* 164 */         metadata = (AnnotationMetadata)entry.getKey();
/* 165 */         for (Condition condition : (List)entry.getValue())
/* 166 */           outcomes.add(getConditionOutcome(metadata, condition));
/*     */       }
/*     */       AnnotationMetadata metadata;
/* 169 */       return Collections.unmodifiableList(outcomes);
/*     */     }
/*     */     
/*     */     private ConditionOutcome getConditionOutcome(AnnotationMetadata metadata, Condition condition)
/*     */     {
/* 174 */       String messagePrefix = "member condition on " + metadata.getClassName();
/* 175 */       if ((condition instanceof SpringBootCondition))
/*     */       {
/* 177 */         ConditionOutcome outcome = ((SpringBootCondition)condition).getMatchOutcome(this.context, metadata);
/* 178 */         String message = outcome.getMessage();
/*     */         
/* 180 */         return new ConditionOutcome(outcome.isMatch(), messagePrefix + (StringUtils.hasLength(message) ? " : " + message : ""));
/*     */       }
/* 182 */       boolean matches = condition.matches(this.context, metadata);
/* 183 */       return new ConditionOutcome(matches, messagePrefix);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\condition\AbstractNestedCondition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */