/*     */ package org.springframework.boot.autoconfigure.web;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.NestedConfigurationProperty;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.resources", ignoreUnknownFields=false)
/*     */ public class ResourceProperties
/*     */   implements ResourceLoaderAware
/*     */ {
/*  42 */   private static final String[] SERVLET_RESOURCE_LOCATIONS = { "/" };
/*     */   
/*  44 */   private static final String[] CLASSPATH_RESOURCE_LOCATIONS = { "classpath:/META-INF/resources/", "classpath:/resources/", "classpath:/static/", "classpath:/public/" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  51 */   private static final String[] RESOURCE_LOCATIONS = new String[CLASSPATH_RESOURCE_LOCATIONS.length + SERVLET_RESOURCE_LOCATIONS.length];
/*     */   
/*  53 */   static { System.arraycopy(SERVLET_RESOURCE_LOCATIONS, 0, RESOURCE_LOCATIONS, 0, SERVLET_RESOURCE_LOCATIONS.length);
/*     */     
/*  55 */     System.arraycopy(CLASSPATH_RESOURCE_LOCATIONS, 0, RESOURCE_LOCATIONS, SERVLET_RESOURCE_LOCATIONS.length, CLASSPATH_RESOURCE_LOCATIONS.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  63 */   private String[] staticLocations = RESOURCE_LOCATIONS;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Integer cachePeriod;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  73 */   private boolean addMappings = true;
/*     */   
/*  75 */   private final Chain chain = new Chain();
/*     */   
/*     */   private ResourceLoader resourceLoader;
/*     */   
/*     */   public void setResourceLoader(ResourceLoader resourceLoader)
/*     */   {
/*  81 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */   
/*     */   public String[] getStaticLocations() {
/*  85 */     return this.staticLocations;
/*     */   }
/*     */   
/*     */   public void setStaticLocations(String[] staticLocations) {
/*  89 */     this.staticLocations = staticLocations;
/*     */   }
/*     */   
/*     */   public Resource getWelcomePage() {
/*  93 */     for (String location : getStaticWelcomePageLocations()) {
/*  94 */       Resource resource = this.resourceLoader.getResource(location);
/*     */       try {
/*  96 */         if (resource.exists()) {
/*  97 */           resource.getURL();
/*  98 */           return resource;
/*     */         }
/*     */       }
/*     */       catch (Exception localException) {}
/*     */     }
/*     */     
/*     */ 
/* 105 */     return null;
/*     */   }
/*     */   
/*     */   private String[] getStaticWelcomePageLocations() {
/* 109 */     String[] result = new String[this.staticLocations.length];
/* 110 */     for (int i = 0; i < result.length; i++) {
/* 111 */       String location = this.staticLocations[i];
/* 112 */       if (!location.endsWith("/")) {
/* 113 */         location = location + "/";
/*     */       }
/* 115 */       result[i] = (location + "index.html");
/*     */     }
/* 117 */     return result;
/*     */   }
/*     */   
/*     */   List<Resource> getFaviconLocations() {
/* 121 */     List<Resource> locations = new ArrayList(this.staticLocations.length + 1);
/*     */     
/* 123 */     if (this.resourceLoader != null) {
/* 124 */       for (String location : this.staticLocations) {
/* 125 */         locations.add(this.resourceLoader.getResource(location));
/*     */       }
/*     */     }
/* 128 */     locations.add(new ClassPathResource("/"));
/* 129 */     return Collections.unmodifiableList(locations);
/*     */   }
/*     */   
/*     */   public Integer getCachePeriod() {
/* 133 */     return this.cachePeriod;
/*     */   }
/*     */   
/*     */   public void setCachePeriod(Integer cachePeriod) {
/* 137 */     this.cachePeriod = cachePeriod;
/*     */   }
/*     */   
/*     */   public boolean isAddMappings() {
/* 141 */     return this.addMappings;
/*     */   }
/*     */   
/*     */   public void setAddMappings(boolean addMappings) {
/* 145 */     this.addMappings = addMappings;
/*     */   }
/*     */   
/*     */   public Chain getChain() {
/* 149 */     return this.chain;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Chain
/*     */   {
/*     */     private Boolean enabled;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 166 */     private boolean cache = true;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 171 */     private boolean htmlApplicationCache = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 177 */     private boolean gzipped = false;
/*     */     @NestedConfigurationProperty
/* 179 */     private final ResourceProperties.Strategy strategy = new ResourceProperties.Strategy();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Boolean getEnabled()
/*     */     {
/* 189 */       Boolean strategyEnabled = Boolean.valueOf((getStrategy().getFixed().isEnabled()) || 
/* 190 */         (getStrategy().getContent().isEnabled()));
/* 191 */       return strategyEnabled.booleanValue() ? Boolean.TRUE : this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 195 */       this.enabled = Boolean.valueOf(enabled);
/*     */     }
/*     */     
/*     */     public boolean isCache() {
/* 199 */       return this.cache;
/*     */     }
/*     */     
/*     */     public void setCache(boolean cache) {
/* 203 */       this.cache = cache;
/*     */     }
/*     */     
/*     */     public ResourceProperties.Strategy getStrategy() {
/* 207 */       return this.strategy;
/*     */     }
/*     */     
/*     */     public boolean isHtmlApplicationCache() {
/* 211 */       return this.htmlApplicationCache;
/*     */     }
/*     */     
/*     */     public void setHtmlApplicationCache(boolean htmlApplicationCache) {
/* 215 */       this.htmlApplicationCache = htmlApplicationCache;
/*     */     }
/*     */     
/*     */     public boolean isGzipped() {
/* 219 */       return this.gzipped;
/*     */     }
/*     */     
/*     */     public void setGzipped(boolean gzipped) {
/* 223 */       this.gzipped = gzipped;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Strategy
/*     */   {
/*     */     @NestedConfigurationProperty
/* 233 */     private final ResourceProperties.Fixed fixed = new ResourceProperties.Fixed();
/*     */     
/*     */     @NestedConfigurationProperty
/* 236 */     private final ResourceProperties.Content content = new ResourceProperties.Content();
/*     */     
/*     */     public ResourceProperties.Fixed getFixed()
/*     */     {
/* 240 */       return this.fixed;
/*     */     }
/*     */     
/*     */     public ResourceProperties.Content getContent() {
/* 244 */       return this.content;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Content
/*     */   {
/*     */     private boolean enabled;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 262 */     private String[] paths = { "/**" };
/*     */     
/*     */     public boolean isEnabled() {
/* 265 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 269 */       this.enabled = enabled;
/*     */     }
/*     */     
/*     */     public String[] getPaths() {
/* 273 */       return this.paths;
/*     */     }
/*     */     
/*     */     public void setPaths(String[] paths) {
/* 277 */       this.paths = paths;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Fixed
/*     */   {
/*     */     private boolean enabled;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 295 */     private String[] paths = { "/**" };
/*     */     
/*     */ 
/*     */     private String version;
/*     */     
/*     */ 
/*     */     public boolean isEnabled()
/*     */     {
/* 303 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 307 */       this.enabled = enabled;
/*     */     }
/*     */     
/*     */     public String[] getPaths() {
/* 311 */       return this.paths;
/*     */     }
/*     */     
/*     */     public void setPaths(String[] paths) {
/* 315 */       this.paths = paths;
/*     */     }
/*     */     
/*     */     public String getVersion() {
/* 319 */       return this.version;
/*     */     }
/*     */     
/*     */     public void setVersion(String version) {
/* 323 */       this.version = version;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\web\ResourceProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */