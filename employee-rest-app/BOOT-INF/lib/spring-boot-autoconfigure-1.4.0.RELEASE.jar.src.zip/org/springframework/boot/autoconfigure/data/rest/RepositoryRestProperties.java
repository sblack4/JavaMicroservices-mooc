/*     */ package org.springframework.boot.autoconfigure.data.rest;
/*     */ 
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.data.rest.core.config.RepositoryRestConfiguration;
/*     */ import org.springframework.http.MediaType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.data.rest")
/*     */ public class RepositoryRestProperties
/*     */ {
/*     */   private String basePath;
/*     */   private Integer defaultPageSize;
/*     */   private Integer maxPageSize;
/*     */   private String pageParamName;
/*     */   private String limitParamName;
/*     */   private String sortParamName;
/*     */   private MediaType defaultMediaType;
/*     */   private Boolean returnBodyOnCreate;
/*     */   private Boolean returnBodyOnUpdate;
/*     */   private Boolean enableEnumTranslation;
/*     */   
/*     */   public String getBasePath()
/*     */   {
/*  86 */     return this.basePath;
/*     */   }
/*     */   
/*     */   public void setBasePath(String basePath) {
/*  90 */     this.basePath = basePath;
/*     */   }
/*     */   
/*     */   public Integer getDefaultPageSize() {
/*  94 */     return this.defaultPageSize;
/*     */   }
/*     */   
/*     */   public void setDefaultPageSize(Integer defaultPageSize) {
/*  98 */     this.defaultPageSize = defaultPageSize;
/*     */   }
/*     */   
/*     */   public Integer getMaxPageSize() {
/* 102 */     return this.maxPageSize;
/*     */   }
/*     */   
/*     */   public void setMaxPageSize(Integer maxPageSize) {
/* 106 */     this.maxPageSize = maxPageSize;
/*     */   }
/*     */   
/*     */   public String getPageParamName() {
/* 110 */     return this.pageParamName;
/*     */   }
/*     */   
/*     */   public void setPageParamName(String pageParamName) {
/* 114 */     this.pageParamName = pageParamName;
/*     */   }
/*     */   
/*     */   public String getLimitParamName() {
/* 118 */     return this.limitParamName;
/*     */   }
/*     */   
/*     */   public void setLimitParamName(String limitParamName) {
/* 122 */     this.limitParamName = limitParamName;
/*     */   }
/*     */   
/*     */   public String getSortParamName() {
/* 126 */     return this.sortParamName;
/*     */   }
/*     */   
/*     */   public void setSortParamName(String sortParamName) {
/* 130 */     this.sortParamName = sortParamName;
/*     */   }
/*     */   
/*     */   public MediaType getDefaultMediaType() {
/* 134 */     return this.defaultMediaType;
/*     */   }
/*     */   
/*     */   public void setDefaultMediaType(MediaType defaultMediaType) {
/* 138 */     this.defaultMediaType = defaultMediaType;
/*     */   }
/*     */   
/*     */   public Boolean getReturnBodyOnCreate() {
/* 142 */     return this.returnBodyOnCreate;
/*     */   }
/*     */   
/*     */   public void setReturnBodyOnCreate(Boolean returnBodyOnCreate) {
/* 146 */     this.returnBodyOnCreate = returnBodyOnCreate;
/*     */   }
/*     */   
/*     */   public Boolean getReturnBodyOnUpdate() {
/* 150 */     return this.returnBodyOnUpdate;
/*     */   }
/*     */   
/*     */   public void setReturnBodyOnUpdate(Boolean returnBodyOnUpdate) {
/* 154 */     this.returnBodyOnUpdate = returnBodyOnUpdate;
/*     */   }
/*     */   
/*     */   public Boolean getEnableEnumTranslation() {
/* 158 */     return this.enableEnumTranslation;
/*     */   }
/*     */   
/*     */   public void setEnableEnumTranslation(Boolean enableEnumTranslation) {
/* 162 */     this.enableEnumTranslation = enableEnumTranslation;
/*     */   }
/*     */   
/*     */   public void applyTo(RepositoryRestConfiguration configuration) {
/* 166 */     if (this.basePath != null) {
/* 167 */       configuration.setBasePath(this.basePath);
/*     */     }
/* 169 */     if (this.defaultPageSize != null) {
/* 170 */       configuration.setDefaultPageSize(this.defaultPageSize.intValue());
/*     */     }
/* 172 */     if (this.maxPageSize != null) {
/* 173 */       configuration.setMaxPageSize(this.maxPageSize.intValue());
/*     */     }
/* 175 */     if (this.pageParamName != null) {
/* 176 */       configuration.setPageParamName(this.pageParamName);
/*     */     }
/* 178 */     if (this.limitParamName != null) {
/* 179 */       configuration.setLimitParamName(this.limitParamName);
/*     */     }
/* 181 */     if (this.sortParamName != null) {
/* 182 */       configuration.setSortParamName(this.sortParamName);
/*     */     }
/* 184 */     if (this.defaultMediaType != null) {
/* 185 */       configuration.setDefaultMediaType(this.defaultMediaType);
/*     */     }
/* 187 */     if (this.returnBodyOnCreate != null) {
/* 188 */       configuration.setReturnBodyOnCreate(this.returnBodyOnCreate);
/*     */     }
/* 190 */     if (this.returnBodyOnUpdate != null) {
/* 191 */       configuration.setReturnBodyOnUpdate(this.returnBodyOnUpdate);
/*     */     }
/* 193 */     if (this.enableEnumTranslation != null) {
/* 194 */       configuration.setEnableEnumTranslation(this.enableEnumTranslation.booleanValue());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\data\rest\RepositoryRestProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */