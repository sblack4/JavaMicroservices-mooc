/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.factory.config.BeanExpressionContext;
/*    */ import org.springframework.beans.factory.config.BeanExpressionResolver;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.context.expression.StandardBeanExpressionResolver;
/*    */ import org.springframework.core.annotation.Order;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.core.type.ClassMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Order(2147483627)
/*    */ class OnExpressionCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 44 */     String expression = (String)metadata.getAnnotationAttributes(ConditionalOnExpression.class.getName()).get("value");
/* 45 */     String rawExpression = expression;
/* 46 */     if (!expression.startsWith("#{"))
/*    */     {
/* 48 */       expression = "#{" + expression + "}";
/*    */     }
/*    */     
/*    */ 
/* 52 */     expression = context.getEnvironment().resolvePlaceholders(expression);
/* 53 */     ConfigurableListableBeanFactory beanFactory = context.getBeanFactory();
/*    */     
/* 55 */     BeanExpressionResolver resolver = beanFactory != null ? beanFactory.getBeanExpressionResolver() : null;
/* 56 */     BeanExpressionContext expressionContext = beanFactory != null ? new BeanExpressionContext(beanFactory, null) : null;
/*    */     
/* 58 */     if (resolver == null) {
/* 59 */       resolver = new StandardBeanExpressionResolver();
/*    */     }
/* 61 */     boolean result = ((Boolean)resolver.evaluate(expression, expressionContext)).booleanValue();
/*    */     
/* 63 */     StringBuilder message = new StringBuilder("SpEL expression");
/* 64 */     if ((metadata instanceof ClassMetadata)) {
/* 65 */       message.append(" on " + ((ClassMetadata)metadata).getClassName());
/*    */     }
/* 67 */     message.append(": " + rawExpression);
/* 68 */     return new ConditionOutcome(result, message.toString());
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\condition\OnExpressionCondition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */