/*     */ package org.springframework.boot.autoconfigure.flyway;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="flyway", ignoreUnknownFields=true)
/*     */ public class FlywayProperties
/*     */ {
/*  43 */   private List<String> locations = new ArrayList(Arrays.asList(new String[] { "db/migration" }));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  48 */   private boolean checkLocation = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  53 */   private boolean enabled = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String user;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String password;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String url;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  75 */   private List<String> initSqls = Collections.emptyList();
/*     */   
/*     */   public void setLocations(List<String> locations) {
/*  78 */     this.locations = locations;
/*     */   }
/*     */   
/*     */   public List<String> getLocations() {
/*  82 */     return this.locations;
/*     */   }
/*     */   
/*     */   public void setCheckLocation(boolean checkLocation) {
/*  86 */     this.checkLocation = checkLocation;
/*     */   }
/*     */   
/*     */   public boolean isCheckLocation() {
/*  90 */     return this.checkLocation;
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/*  94 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/*  98 */     this.enabled = enabled;
/*     */   }
/*     */   
/*     */   public String getUser() {
/* 102 */     return this.user;
/*     */   }
/*     */   
/*     */   public void setUser(String user) {
/* 106 */     this.user = user;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 110 */     return this.password == null ? "" : this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 114 */     this.password = password;
/*     */   }
/*     */   
/*     */   public String getUrl() {
/* 118 */     return this.url;
/*     */   }
/*     */   
/*     */   public void setUrl(String url) {
/* 122 */     this.url = url;
/*     */   }
/*     */   
/*     */   public List<String> getInitSqls() {
/* 126 */     return this.initSqls;
/*     */   }
/*     */   
/*     */   public void setInitSqls(List<String> initSqls) {
/* 130 */     this.initSqls = initSqls;
/*     */   }
/*     */   
/*     */   public boolean isCreateDataSource() {
/* 134 */     return (this.url != null) && (this.user != null);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\flyway\FlywayProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */