/*    */ package org.springframework.boot.autoconfigure.session;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*    */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*    */ import org.springframework.boot.bind.RelaxedPropertyResolver;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SessionCondition
/*    */   extends SpringBootCondition
/*    */ {
/* 34 */   private static final boolean redisPresent = ClassUtils.isPresent("org.springframework.data.redis.core.RedisTemplate", SessionCondition.class
/*    */   
/* 36 */     .getClassLoader());
/*    */   
/*    */ 
/*    */ 
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 42 */     RelaxedPropertyResolver resolver = new RelaxedPropertyResolver(context.getEnvironment(), "spring.session.");
/*    */     
/* 44 */     StoreType sessionStoreType = SessionStoreMappings.getType(((AnnotationMetadata)metadata).getClassName());
/* 45 */     if (!resolver.containsProperty("store-type")) {
/* 46 */       if ((sessionStoreType == StoreType.REDIS) && (redisPresent))
/*    */       {
/* 48 */         return ConditionOutcome.match("Session store type default to redis (deprecated)");
/*    */       }
/* 50 */       return ConditionOutcome.noMatch("Session store type not set");
/*    */     }
/* 52 */     String value = resolver.getProperty("store-type").replace("-", "_").toUpperCase();
/* 53 */     if (value.equals(sessionStoreType.name())) {
/* 54 */       return ConditionOutcome.match("Session store type " + sessionStoreType);
/*    */     }
/* 56 */     return ConditionOutcome.noMatch("Session store type " + value);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\session\SessionCondition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */