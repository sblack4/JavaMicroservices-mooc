/*    */ package org.springframework.boot.autoconfigure.jdbc.metadata;
/*    */ 
/*    */ import com.zaxxer.hikari.HikariDataSource;
/*    */ import com.zaxxer.hikari.pool.HikariPool;
/*    */ import org.springframework.beans.DirectFieldAccessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HikariDataSourcePoolMetadata
/*    */   extends AbstractDataSourcePoolMetadata<HikariDataSource>
/*    */ {
/*    */   public HikariDataSourcePoolMetadata(HikariDataSource dataSource)
/*    */   {
/* 36 */     super(dataSource);
/*    */   }
/*    */   
/*    */   public Integer getActive()
/*    */   {
/*    */     try {
/* 42 */       return Integer.valueOf(getHikariPool().getActiveConnections());
/*    */     }
/*    */     catch (Exception ex) {}
/* 45 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   private HikariPool getHikariPool()
/*    */   {
/* 51 */     return (HikariPool)new DirectFieldAccessor(getDataSource()).getPropertyValue("pool");
/*    */   }
/*    */   
/*    */   public Integer getMax()
/*    */   {
/* 56 */     return Integer.valueOf(((HikariDataSource)getDataSource()).getMaximumPoolSize());
/*    */   }
/*    */   
/*    */   public Integer getMin()
/*    */   {
/* 61 */     return Integer.valueOf(((HikariDataSource)getDataSource()).getMinimumIdle());
/*    */   }
/*    */   
/*    */   public String getValidationQuery()
/*    */   {
/* 66 */     return ((HikariDataSource)getDataSource()).getConnectionTestQuery();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jdbc\metadata\HikariDataSourcePoolMetadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */