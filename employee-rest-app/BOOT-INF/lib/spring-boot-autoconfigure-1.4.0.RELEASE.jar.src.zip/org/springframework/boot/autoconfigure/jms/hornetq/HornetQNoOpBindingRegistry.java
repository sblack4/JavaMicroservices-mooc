/*    */ package org.springframework.boot.autoconfigure.jms.hornetq;
/*    */ 
/*    */ import org.hornetq.spi.core.naming.BindingRegistry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class HornetQNoOpBindingRegistry
/*    */   implements BindingRegistry
/*    */ {
/*    */   public Object lookup(String name)
/*    */   {
/* 36 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean bind(String name, Object obj)
/*    */   {
/* 46 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void unbind(String name) {}
/*    */   
/*    */ 
/*    */   public void close() {}
/*    */   
/*    */ 
/*    */   public Object getContext()
/*    */   {
/* 59 */     return this;
/*    */   }
/*    */   
/*    */   public void setContext(Object ctx) {}
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jms\hornetq\HornetQNoOpBindingRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */