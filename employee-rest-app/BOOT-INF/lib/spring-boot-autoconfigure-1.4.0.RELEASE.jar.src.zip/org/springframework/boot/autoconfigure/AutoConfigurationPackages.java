/*     */ package org.springframework.boot.autoconfigure;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues.ValueHolder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*     */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AutoConfigurationPackages
/*     */ {
/*  51 */   private static final Log logger = LogFactory.getLog(AutoConfigurationPackages.class);
/*     */   
/*  53 */   private static final String BEAN = AutoConfigurationPackages.class.getName();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean has(BeanFactory beanFactory)
/*     */   {
/*  62 */     return (beanFactory.containsBean(BEAN)) && (!get(beanFactory).isEmpty());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<String> get(BeanFactory beanFactory)
/*     */   {
/*     */     try
/*     */     {
/*  73 */       return ((BasePackages)beanFactory.getBean(BEAN, BasePackages.class)).get();
/*     */     }
/*     */     catch (NoSuchBeanDefinitionException ex) {
/*  76 */       throw new IllegalStateException("Unable to retrieve @EnableAutoConfiguration base packages");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void register(BeanDefinitionRegistry registry, String... packageNames)
/*     */   {
/*  93 */     if (registry.containsBeanDefinition(BEAN)) {
/*  94 */       BeanDefinition beanDefinition = registry.getBeanDefinition(BEAN);
/*     */       
/*  96 */       ConstructorArgumentValues constructorArguments = beanDefinition.getConstructorArgumentValues();
/*  97 */       constructorArguments.addIndexedArgumentValue(0, 
/*  98 */         addBasePackages(constructorArguments, packageNames));
/*     */     }
/*     */     else {
/* 101 */       GenericBeanDefinition beanDefinition = new GenericBeanDefinition();
/* 102 */       beanDefinition.setBeanClass(BasePackages.class);
/* 103 */       beanDefinition.getConstructorArgumentValues().addIndexedArgumentValue(0, packageNames);
/*     */       
/* 105 */       beanDefinition.setRole(2);
/* 106 */       registry.registerBeanDefinition(BEAN, beanDefinition);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static String[] addBasePackages(ConstructorArgumentValues constructorArguments, String[] packageNames)
/*     */   {
/* 113 */     String[] existing = (String[])constructorArguments.getIndexedArgumentValue(0, String[].class).getValue();
/* 114 */     Set<String> merged = new LinkedHashSet();
/* 115 */     merged.addAll(Arrays.asList(existing));
/* 116 */     merged.addAll(Arrays.asList(packageNames));
/* 117 */     return (String[])merged.toArray(new String[merged.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Order(Integer.MIN_VALUE)
/*     */   static class Registrar
/*     */     implements ImportBeanDefinitionRegistrar
/*     */   {
/*     */     public void registerBeanDefinitions(AnnotationMetadata metadata, BeanDefinitionRegistry registry)
/*     */     {
/* 130 */       AutoConfigurationPackages.register(registry, new String[] { ClassUtils.getPackageName(metadata.getClassName()) });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static final class BasePackages
/*     */   {
/*     */     private final List<String> packages;
/*     */     
/*     */     private boolean loggedBasePackageInfo;
/*     */     
/*     */ 
/*     */     BasePackages(String... names)
/*     */     {
/* 145 */       List<String> packages = new ArrayList();
/* 146 */       for (String name : names) {
/* 147 */         if (StringUtils.hasText(name)) {
/* 148 */           packages.add(name);
/*     */         }
/*     */       }
/* 151 */       this.packages = packages;
/*     */     }
/*     */     
/*     */     public List<String> get() {
/* 155 */       if (!this.loggedBasePackageInfo) {
/* 156 */         if (this.packages.isEmpty()) {
/* 157 */           if (AutoConfigurationPackages.logger.isWarnEnabled()) {
/* 158 */             AutoConfigurationPackages.logger.warn("@EnableAutoConfiguration was declared on a class in the default package. Automatic @Repository and @Entity scanning is not enabled.");
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */         }
/* 164 */         else if (AutoConfigurationPackages.logger.isDebugEnabled())
/*     */         {
/* 166 */           String packageNames = StringUtils.collectionToCommaDelimitedString(this.packages);
/* 167 */           AutoConfigurationPackages.logger.debug("@EnableAutoConfiguration was declared on a class in the package '" + packageNames + "'. Automatic @Repository and @Entity scanning is " + "enabled.");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 173 */         this.loggedBasePackageInfo = true;
/*     */       }
/* 175 */       return this.packages;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\AutoConfigurationPackages.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */