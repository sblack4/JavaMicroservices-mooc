/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.springframework.boot.bind.RelaxedPropertyResolver;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.PropertyResolver;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OnPropertyCondition
/*     */   extends SpringBootCondition
/*     */ {
/*     */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*     */   {
/*  50 */     List<AnnotationAttributes> allAnnotationAttributes = annotationAttributesFromMultiValueMap(metadata
/*  51 */       .getAllAnnotationAttributes(ConditionalOnProperty.class
/*  52 */       .getName()));
/*  53 */     List<ConditionOutcome> noMatchOutcomes = findNoMatchOutcomes(allAnnotationAttributes, context
/*  54 */       .getEnvironment());
/*  55 */     if (noMatchOutcomes.isEmpty()) {
/*  56 */       return ConditionOutcome.match();
/*     */     }
/*  58 */     return ConditionOutcome.noMatch(getCompositeMessage(noMatchOutcomes));
/*     */   }
/*     */   
/*     */   private List<AnnotationAttributes> annotationAttributesFromMultiValueMap(MultiValueMap<String, Object> multiValueMap)
/*     */   {
/*  63 */     List<Map<String, Object>> maps = new ArrayList();
/*  64 */     for (Iterator localIterator = multiValueMap.entrySet().iterator(); localIterator.hasNext();) { entry = (Map.Entry)localIterator.next();
/*  65 */       for (int i = 0; i < ((List)entry.getValue()).size(); i++) { Map<String, Object> map;
/*     */         Map<String, Object> map;
/*  67 */         if (i < maps.size()) {
/*  68 */           map = (Map)maps.get(i);
/*     */         }
/*     */         else {
/*  71 */           map = new HashMap();
/*  72 */           maps.add(map);
/*     */         }
/*  74 */         map.put(entry.getKey(), ((List)entry.getValue()).get(i));
/*     */       }
/*     */     }
/*     */     Map.Entry<String, List<Object>> entry;
/*  78 */     Object annotationAttributes = new ArrayList(maps.size());
/*  79 */     for (Map<String, Object> map : maps) {
/*  80 */       ((List)annotationAttributes).add(AnnotationAttributes.fromMap(map));
/*     */     }
/*  82 */     return (List<AnnotationAttributes>)annotationAttributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private List<ConditionOutcome> findNoMatchOutcomes(List<AnnotationAttributes> allAnnotationAttributes, PropertyResolver resolver)
/*     */   {
/*  89 */     List<ConditionOutcome> noMatchOutcomes = new ArrayList(allAnnotationAttributes.size());
/*  90 */     for (AnnotationAttributes annotationAttributes : allAnnotationAttributes) {
/*  91 */       ConditionOutcome outcome = determineOutcome(annotationAttributes, resolver);
/*  92 */       if (!outcome.isMatch()) {
/*  93 */         noMatchOutcomes.add(outcome);
/*     */       }
/*     */     }
/*  96 */     return noMatchOutcomes;
/*     */   }
/*     */   
/*     */   private ConditionOutcome determineOutcome(AnnotationAttributes annotationAttributes, PropertyResolver resolver)
/*     */   {
/* 101 */     String prefix = annotationAttributes.getString("prefix").trim();
/* 102 */     if ((StringUtils.hasText(prefix)) && (!prefix.endsWith("."))) {
/* 103 */       prefix = prefix + ".";
/*     */     }
/* 105 */     String havingValue = annotationAttributes.getString("havingValue");
/* 106 */     String[] names = getNames(annotationAttributes);
/* 107 */     boolean relaxedNames = annotationAttributes.getBoolean("relaxedNames");
/* 108 */     boolean matchIfMissing = annotationAttributes.getBoolean("matchIfMissing");
/*     */     
/* 110 */     if (relaxedNames) {
/* 111 */       resolver = new RelaxedPropertyResolver(resolver, prefix);
/*     */     }
/*     */     
/* 114 */     List<String> missingProperties = new ArrayList();
/* 115 */     List<String> nonMatchingProperties = new ArrayList();
/* 116 */     for (String name : names) {
/* 117 */       String key = prefix + name;
/* 118 */       if (resolver.containsProperty(key)) {
/* 119 */         if (!isMatch(resolver.getProperty(key), havingValue)) {
/* 120 */           nonMatchingProperties.add(name);
/*     */         }
/*     */         
/*     */       }
/* 124 */       else if (!matchIfMissing) {
/* 125 */         missingProperties.add(name);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 130 */     if ((missingProperties.isEmpty()) && (nonMatchingProperties.isEmpty())) {
/* 131 */       return ConditionOutcome.match();
/*     */     }
/*     */     
/* 134 */     StringBuilder message = new StringBuilder("@ConditionalOnProperty ");
/* 135 */     if (!missingProperties.isEmpty())
/*     */     {
/* 137 */       message.append("missing required properties ").append(expandNames(prefix, missingProperties)).append(" ");
/*     */     }
/* 139 */     if (!nonMatchingProperties.isEmpty()) {
/* 140 */       String expected = StringUtils.hasLength(havingValue) ? havingValue : "!false";
/* 141 */       message.append("expected '").append(expected).append("' for properties ")
/* 142 */         .append(expandNames(prefix, nonMatchingProperties));
/*     */     }
/* 144 */     return ConditionOutcome.noMatch(message.toString());
/*     */   }
/*     */   
/*     */   private String[] getNames(Map<String, Object> annotationAttributes) {
/* 148 */     String[] value = (String[])annotationAttributes.get("value");
/* 149 */     String[] name = (String[])annotationAttributes.get("name");
/* 150 */     Assert.state((value.length > 0) || (name.length > 0), "The name or value attribute of @ConditionalOnProperty must be specified");
/*     */     
/* 152 */     Assert.state((value.length == 0) || (name.length == 0), "The name and value attributes of @ConditionalOnProperty are exclusive");
/*     */     
/* 154 */     return value.length > 0 ? value : name;
/*     */   }
/*     */   
/*     */   private boolean isMatch(String value, String requiredValue) {
/* 158 */     if (StringUtils.hasLength(requiredValue)) {
/* 159 */       return requiredValue.equalsIgnoreCase(value);
/*     */     }
/* 161 */     return !"false".equalsIgnoreCase(value);
/*     */   }
/*     */   
/*     */   private String expandNames(String prefix, List<String> names) {
/* 165 */     StringBuilder expanded = new StringBuilder();
/* 166 */     for (String name : names) {
/* 167 */       expanded.append(expanded.length() == 0 ? "" : ", ");
/* 168 */       expanded.append(prefix);
/* 169 */       expanded.append(name);
/*     */     }
/* 171 */     return expanded.toString();
/*     */   }
/*     */   
/*     */   private String getCompositeMessage(List<ConditionOutcome> noMatchOutcomes) {
/* 175 */     StringBuilder message = new StringBuilder();
/* 176 */     for (ConditionOutcome noMatchOutcome : noMatchOutcomes) {
/* 177 */       if (message.length() > 0) {
/* 178 */         message.append(". ");
/*     */       }
/* 180 */       message.append(noMatchOutcome.getMessage().trim());
/*     */     }
/* 182 */     return message.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\condition\OnPropertyCondition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */