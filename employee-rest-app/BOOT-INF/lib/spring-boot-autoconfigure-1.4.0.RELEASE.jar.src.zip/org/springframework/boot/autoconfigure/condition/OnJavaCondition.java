/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.annotation.Order;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Order(-2147483628)
/*    */ class OnJavaCondition
/*    */   extends SpringBootCondition
/*    */ {
/* 40 */   private static final ConditionalOnJava.JavaVersion JVM_VERSION = ;
/*    */   
/*    */ 
/*    */ 
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 46 */     Map<String, Object> attributes = metadata.getAnnotationAttributes(ConditionalOnJava.class.getName());
/* 47 */     ConditionalOnJava.Range range = (ConditionalOnJava.Range)attributes.get("range");
/* 48 */     ConditionalOnJava.JavaVersion version = (ConditionalOnJava.JavaVersion)attributes.get("value");
/* 49 */     return getMatchOutcome(range, JVM_VERSION, version);
/*    */   }
/*    */   
/*    */   protected ConditionOutcome getMatchOutcome(ConditionalOnJava.Range range, ConditionalOnJava.JavaVersion runningVersion, ConditionalOnJava.JavaVersion version)
/*    */   {
/* 54 */     boolean match = runningVersion.isWithin(range, version);
/* 55 */     return new ConditionOutcome(match, getMessage(range, runningVersion, version));
/*    */   }
/*    */   
/*    */   private String getMessage(ConditionalOnJava.Range range, ConditionalOnJava.JavaVersion runningVersion, ConditionalOnJava.JavaVersion version)
/*    */   {
/* 60 */     String expected = String.format(range == ConditionalOnJava.Range.EQUAL_OR_NEWER ? "%s or newer" : "older than %s", new Object[] { version });
/*    */     
/* 62 */     return "Required JVM version " + expected + " found " + runningVersion;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\condition\OnJavaCondition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */