/*     */ package org.springframework.boot.autoconfigure.session;
/*     */ 
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.web.ServerProperties;
/*     */ import org.springframework.boot.autoconfigure.web.ServerProperties.Session;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.session.data.redis.RedisFlushMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.session")
/*     */ public class SessionProperties
/*     */ {
/*     */   private StoreType storeType;
/*     */   private Integer timeout;
/*  42 */   private final Hazelcast hazelcast = new Hazelcast();
/*     */   
/*  44 */   private final Jdbc jdbc = new Jdbc();
/*     */   
/*  46 */   private final Mongo mongo = new Mongo();
/*     */   
/*  48 */   private final Redis redis = new Redis();
/*     */   
/*     */   public SessionProperties(ObjectProvider<ServerProperties> serverProperties) {
/*  51 */     ServerProperties properties = (ServerProperties)serverProperties.getIfUnique();
/*  52 */     this.timeout = (properties != null ? properties.getSession().getTimeout() : null);
/*     */   }
/*     */   
/*     */   public StoreType getStoreType() {
/*  56 */     return this.storeType;
/*     */   }
/*     */   
/*     */   public void setStoreType(StoreType storeType) {
/*  60 */     this.storeType = storeType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer getTimeout()
/*     */   {
/*  69 */     return this.timeout;
/*     */   }
/*     */   
/*     */   public Hazelcast getHazelcast() {
/*  73 */     return this.hazelcast;
/*     */   }
/*     */   
/*     */   public Jdbc getJdbc() {
/*  77 */     return this.jdbc;
/*     */   }
/*     */   
/*     */   public Mongo getMongo() {
/*  81 */     return this.mongo;
/*     */   }
/*     */   
/*     */   public Redis getRedis() {
/*  85 */     return this.redis;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Hazelcast
/*     */   {
/*  93 */     private String mapName = "spring:session:sessions";
/*     */     
/*     */     public String getMapName() {
/*  96 */       return this.mapName;
/*     */     }
/*     */     
/*     */     public void setMapName(String mapName) {
/* 100 */       this.mapName = mapName;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Jdbc
/*     */   {
/*     */     private static final String DEFAULT_SCHEMA_LOCATION = "classpath:org/springframework/session/jdbc/schema-@@platform@@.sql";
/*     */     
/*     */ 
/*     */ 
/* 113 */     private String schema = "classpath:org/springframework/session/jdbc/schema-@@platform@@.sql";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 118 */     private String tableName = "SPRING_SESSION";
/*     */     
/* 120 */     private final Initializer initializer = new Initializer();
/*     */     
/*     */     public String getSchema() {
/* 123 */       return this.schema;
/*     */     }
/*     */     
/*     */     public void setSchema(String schema) {
/* 127 */       this.schema = schema;
/*     */     }
/*     */     
/*     */     public String getTableName() {
/* 131 */       return this.tableName;
/*     */     }
/*     */     
/*     */     public void setTableName(String tableName) {
/* 135 */       this.tableName = tableName;
/*     */     }
/*     */     
/*     */     public Initializer getInitializer() {
/* 139 */       return this.initializer;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public static class Initializer
/*     */     {
/* 147 */       private boolean enabled = true;
/*     */       
/*     */       public boolean isEnabled() {
/* 150 */         return this.enabled;
/*     */       }
/*     */       
/*     */       public void setEnabled(boolean enabled) {
/* 154 */         this.enabled = enabled;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Mongo
/*     */   {
/* 166 */     private String collectionName = "sessions";
/*     */     
/*     */     public String getCollectionName() {
/* 169 */       return this.collectionName;
/*     */     }
/*     */     
/*     */     public void setCollectionName(String collectionName) {
/* 173 */       this.collectionName = collectionName;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Redis
/*     */   {
/* 183 */     private String namespace = "";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 188 */     private RedisFlushMode flushMode = RedisFlushMode.ON_SAVE;
/*     */     
/*     */     public String getNamespace() {
/* 191 */       return this.namespace;
/*     */     }
/*     */     
/*     */     public void setNamespace(String namespace) {
/* 195 */       this.namespace = namespace;
/*     */     }
/*     */     
/*     */     public RedisFlushMode getFlushMode() {
/* 199 */       return this.flushMode;
/*     */     }
/*     */     
/*     */     public void setFlushMode(RedisFlushMode flushMode) {
/* 203 */       this.flushMode = flushMode;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\session\SessionProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */