/*     */ package org.springframework.boot.autoconfigure.mustache;
/*     */ 
/*     */ import com.samskivert.mustache.Mustache;
/*     */ import com.samskivert.mustache.Mustache.Collector;
/*     */ import com.samskivert.mustache.Mustache.Compiler;
/*     */ import com.samskivert.mustache.Mustache.Escaper;
/*     */ import com.samskivert.mustache.Mustache.Formatter;
/*     */ import com.samskivert.mustache.Mustache.TemplateLoader;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MustacheCompilerFactoryBean
/*     */   implements FactoryBean<Mustache.Compiler>
/*     */ {
/*     */   private String delims;
/*     */   private Mustache.TemplateLoader templateLoader;
/*     */   private Mustache.Formatter formatter;
/*     */   private Mustache.Escaper escaper;
/*     */   private Mustache.Collector collector;
/*     */   private Mustache.Compiler compiler;
/*     */   private String defaultValue;
/*     */   private Boolean emptyStringIsFalse;
/*     */   
/*     */   public void setDelims(String delims)
/*     */   {
/*  56 */     this.delims = delims;
/*     */   }
/*     */   
/*     */   public void setTemplateLoader(Mustache.TemplateLoader templateLoader) {
/*  60 */     this.templateLoader = templateLoader;
/*     */   }
/*     */   
/*     */   public void setFormatter(Mustache.Formatter formatter) {
/*  64 */     this.formatter = formatter;
/*     */   }
/*     */   
/*     */   public void setEscaper(Mustache.Escaper escaper) {
/*  68 */     this.escaper = escaper;
/*     */   }
/*     */   
/*     */   public void setCollector(Mustache.Collector collector) {
/*  72 */     this.collector = collector;
/*     */   }
/*     */   
/*     */   public void setDefaultValue(String defaultValue) {
/*  76 */     this.defaultValue = defaultValue;
/*     */   }
/*     */   
/*     */   public void setEmptyStringIsFalse(Boolean emptyStringIsFalse) {
/*  80 */     this.emptyStringIsFalse = emptyStringIsFalse;
/*     */   }
/*     */   
/*     */   public Mustache.Compiler getObject() throws Exception
/*     */   {
/*  85 */     this.compiler = Mustache.compiler();
/*  86 */     if (this.delims != null) {
/*  87 */       this.compiler = this.compiler.withDelims(this.delims);
/*     */     }
/*  89 */     if (this.templateLoader != null) {
/*  90 */       this.compiler = this.compiler.withLoader(this.templateLoader);
/*     */     }
/*  92 */     if (this.formatter != null) {
/*  93 */       this.compiler = this.compiler.withFormatter(this.formatter);
/*     */     }
/*  95 */     if (this.escaper != null) {
/*  96 */       this.compiler = this.compiler.withEscaper(this.escaper);
/*     */     }
/*  98 */     if (this.collector != null) {
/*  99 */       this.compiler = this.compiler.withCollector(this.collector);
/*     */     }
/* 101 */     if (this.defaultValue != null) {
/* 102 */       this.compiler = this.compiler.defaultValue(this.defaultValue);
/*     */     }
/* 104 */     if (this.emptyStringIsFalse != null) {
/* 105 */       this.compiler = this.compiler.emptyStringIsFalse(this.emptyStringIsFalse.booleanValue());
/*     */     }
/* 107 */     return this.compiler;
/*     */   }
/*     */   
/*     */   public Class<?> getObjectType()
/*     */   {
/* 112 */     return Mustache.Compiler.class;
/*     */   }
/*     */   
/*     */   public boolean isSingleton()
/*     */   {
/* 117 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\mustache\MustacheCompilerFactoryBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */