/*     */ package org.springframework.boot.autoconfigure;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.SearchStrategy;
/*     */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.support.ResourceBundleMessageSource;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @ConditionalOnMissingBean(value={MessageSource.class}, search=SearchStrategy.CURRENT)
/*     */ @AutoConfigureOrder(Integer.MIN_VALUE)
/*     */ @Conditional({ResourceBundleCondition.class})
/*     */ @EnableConfigurationProperties
/*     */ @ConfigurationProperties(prefix="spring.messages")
/*     */ public class MessageSourceAutoConfiguration
/*     */ {
/*  56 */   private static final Resource[] NO_RESOURCES = new Resource[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  63 */   private String basename = "messages";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  68 */   private Charset encoding = Charset.forName("UTF-8");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  74 */   private int cacheSeconds = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  81 */   private boolean fallbackToSystemLocale = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  87 */   private boolean alwaysUseMessageFormat = false;
/*     */   
/*     */   @Bean
/*     */   public MessageSource messageSource() {
/*  91 */     ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
/*  92 */     if (StringUtils.hasText(this.basename)) {
/*  93 */       messageSource.setBasenames(StringUtils.commaDelimitedListToStringArray(
/*  94 */         StringUtils.trimAllWhitespace(this.basename)));
/*     */     }
/*  96 */     if (this.encoding != null) {
/*  97 */       messageSource.setDefaultEncoding(this.encoding.name());
/*     */     }
/*  99 */     messageSource.setFallbackToSystemLocale(this.fallbackToSystemLocale);
/* 100 */     messageSource.setCacheSeconds(this.cacheSeconds);
/* 101 */     messageSource.setAlwaysUseMessageFormat(this.alwaysUseMessageFormat);
/* 102 */     return messageSource;
/*     */   }
/*     */   
/*     */   public String getBasename() {
/* 106 */     return this.basename;
/*     */   }
/*     */   
/*     */   public void setBasename(String basename) {
/* 110 */     this.basename = basename;
/*     */   }
/*     */   
/*     */   public Charset getEncoding() {
/* 114 */     return this.encoding;
/*     */   }
/*     */   
/*     */   public void setEncoding(Charset encoding) {
/* 118 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */   public int getCacheSeconds() {
/* 122 */     return this.cacheSeconds;
/*     */   }
/*     */   
/*     */   public void setCacheSeconds(int cacheSeconds) {
/* 126 */     this.cacheSeconds = cacheSeconds;
/*     */   }
/*     */   
/*     */   public boolean isFallbackToSystemLocale() {
/* 130 */     return this.fallbackToSystemLocale;
/*     */   }
/*     */   
/*     */   public void setFallbackToSystemLocale(boolean fallbackToSystemLocale) {
/* 134 */     this.fallbackToSystemLocale = fallbackToSystemLocale;
/*     */   }
/*     */   
/*     */   public boolean isAlwaysUseMessageFormat() {
/* 138 */     return this.alwaysUseMessageFormat;
/*     */   }
/*     */   
/*     */   public void setAlwaysUseMessageFormat(boolean alwaysUseMessageFormat) {
/* 142 */     this.alwaysUseMessageFormat = alwaysUseMessageFormat;
/*     */   }
/*     */   
/*     */   protected static class ResourceBundleCondition extends SpringBootCondition
/*     */   {
/* 147 */     private static ConcurrentReferenceHashMap<String, ConditionOutcome> cache = new ConcurrentReferenceHashMap();
/*     */     
/*     */ 
/*     */ 
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*     */     {
/* 153 */       String basename = context.getEnvironment().getProperty("spring.messages.basename", "messages");
/* 154 */       ConditionOutcome outcome = (ConditionOutcome)cache.get(basename);
/* 155 */       if (outcome == null) {
/* 156 */         outcome = getMatchOutcomeForBasename(context, basename);
/* 157 */         cache.put(basename, outcome);
/*     */       }
/* 159 */       return outcome;
/*     */     }
/*     */     
/*     */     private ConditionOutcome getMatchOutcomeForBasename(ConditionContext context, String basename)
/*     */     {
/* 164 */       for (String name : StringUtils.commaDelimitedListToStringArray(
/* 165 */         StringUtils.trimAllWhitespace(basename))) {
/* 166 */         for (Resource resource : getResources(context.getClassLoader(), name)) {
/* 167 */           if (resource.exists()) {
/* 168 */             return ConditionOutcome.match("Bundle found for spring.messages.basename: " + name);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 173 */       return ConditionOutcome.noMatch("No bundle found for spring.messages.basename: " + basename);
/*     */     }
/*     */     
/*     */     private Resource[] getResources(ClassLoader classLoader, String name)
/*     */     {
/*     */       try
/*     */       {
/* 180 */         return new PathMatchingResourcePatternResolver(classLoader).getResources("classpath*:" + name + ".properties");
/*     */       }
/*     */       catch (Exception ex) {}
/* 183 */       return MessageSourceAutoConfiguration.NO_RESOURCES;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\MessageSourceAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */