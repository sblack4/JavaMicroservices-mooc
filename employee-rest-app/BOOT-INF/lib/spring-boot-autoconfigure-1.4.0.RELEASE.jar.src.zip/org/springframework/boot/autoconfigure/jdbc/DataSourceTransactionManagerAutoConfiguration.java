/*    */ package org.springframework.boot.autoconfigure.jdbc;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureOrder;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.jdbc.core.JdbcTemplate;
/*    */ import org.springframework.jdbc.datasource.DataSourceTransactionManager;
/*    */ import org.springframework.transaction.PlatformTransactionManager;
/*    */ import org.springframework.transaction.annotation.AbstractTransactionManagementConfiguration;
/*    */ import org.springframework.transaction.annotation.EnableTransactionManagement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration
/*    */ @ConditionalOnClass({JdbcTemplate.class, PlatformTransactionManager.class})
/*    */ @AutoConfigureOrder(Integer.MAX_VALUE)
/*    */ public class DataSourceTransactionManagerAutoConfiguration
/*    */ {
/*    */   @ConditionalOnMissingBean({AbstractTransactionManagementConfiguration.class})
/*    */   @Configuration
/*    */   @EnableTransactionManagement(proxyTargetClass=true)
/*    */   protected static class TransactionManagementConfiguration {}
/*    */   
/*    */   @Configuration
/*    */   @ConditionalOnSingleCandidate(DataSource.class)
/*    */   static class DataSourceTransactionManagerConfiguration
/*    */   {
/*    */     private final DataSource dataSource;
/*    */     
/*    */     DataSourceTransactionManagerConfiguration(DataSource dataSource)
/*    */     {
/* 55 */       this.dataSource = dataSource;
/*    */     }
/*    */     
/*    */     @Bean
/*    */     @ConditionalOnMissingBean({PlatformTransactionManager.class})
/*    */     public DataSourceTransactionManager transactionManager() {
/* 61 */       return new DataSourceTransactionManager(this.dataSource);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jdbc\DataSourceTransactionManagerAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */