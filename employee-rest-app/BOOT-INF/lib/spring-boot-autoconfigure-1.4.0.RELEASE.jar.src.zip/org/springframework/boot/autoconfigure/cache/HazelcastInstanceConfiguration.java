/*     */ package org.springframework.boot.autoconfigure.cache;
/*     */ 
/*     */ import com.hazelcast.core.Hazelcast;
/*     */ import com.hazelcast.core.HazelcastInstance;
/*     */ import com.hazelcast.spring.cache.HazelcastCacheManager;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*     */ import org.springframework.boot.autoconfigure.hazelcast.HazelcastConfigResourceCondition;
/*     */ import org.springframework.boot.autoconfigure.hazelcast.HazelcastInstanceFactory;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.io.Resource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class HazelcastInstanceConfiguration
/*     */ {
/*     */   @Configuration
/*     */   @ConditionalOnSingleCandidate(HazelcastInstance.class)
/*     */   static class Existing
/*     */   {
/*     */     private final CacheProperties cacheProperties;
/*     */     private final CacheManagerCustomizers customizers;
/*     */     
/*     */     Existing(CacheProperties cacheProperties, CacheManagerCustomizers customizers)
/*     */     {
/*  52 */       this.cacheProperties = cacheProperties;
/*  53 */       this.customizers = customizers;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     public HazelcastCacheManager cacheManager(HazelcastInstance existingHazelcastInstance) throws IOException
/*     */     {
/*  59 */       Resource config = this.cacheProperties.getHazelcast().getConfig();
/*  60 */       Resource location = this.cacheProperties.resolveConfigLocation(config);
/*  61 */       if (location != null)
/*     */       {
/*  63 */         HazelcastInstance cacheHazelcastInstance = new HazelcastInstanceFactory(location).getHazelcastInstance();
/*  64 */         return new HazelcastInstanceConfiguration.CloseableHazelcastCacheManager(cacheHazelcastInstance);
/*     */       }
/*  66 */       HazelcastCacheManager cacheManager = new HazelcastCacheManager(existingHazelcastInstance);
/*     */       
/*  68 */       return (HazelcastCacheManager)this.customizers.customize(cacheManager);
/*     */     }
/*     */   }
/*     */   
/*     */   @Configuration
/*     */   @ConditionalOnMissingBean({HazelcastInstance.class})
/*     */   @Conditional({HazelcastInstanceConfiguration.ConfigAvailableCondition.class})
/*     */   static class Specific
/*     */   {
/*     */     private final CacheProperties cacheProperties;
/*     */     private final CacheManagerCustomizers customizers;
/*     */     
/*     */     Specific(CacheProperties cacheProperties, CacheManagerCustomizers customizers)
/*     */     {
/*  82 */       this.cacheProperties = cacheProperties;
/*  83 */       this.customizers = customizers;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     public HazelcastInstance hazelcastInstance() throws IOException {
/*  88 */       Resource config = this.cacheProperties.getHazelcast().getConfig();
/*  89 */       Resource location = this.cacheProperties.resolveConfigLocation(config);
/*  90 */       if (location != null) {
/*  91 */         return new HazelcastInstanceFactory(location).getHazelcastInstance();
/*     */       }
/*  93 */       return Hazelcast.newHazelcastInstance();
/*     */     }
/*     */     
/*     */     @Bean
/*     */     public HazelcastCacheManager cacheManager() throws IOException
/*     */     {
/*  99 */       HazelcastCacheManager cacheManager = new HazelcastCacheManager(hazelcastInstance());
/* 100 */       return (HazelcastCacheManager)this.customizers.customize(cacheManager);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static class ConfigAvailableCondition
/*     */     extends HazelcastConfigResourceCondition
/*     */   {
/*     */     ConfigAvailableCondition()
/*     */     {
/* 112 */       super("config");
/*     */     }
/*     */   }
/*     */   
/*     */   private static class CloseableHazelcastCacheManager
/*     */     extends HazelcastCacheManager implements Closeable
/*     */   {
/*     */     private final HazelcastInstance hazelcastInstance;
/*     */     
/*     */     CloseableHazelcastCacheManager(HazelcastInstance hazelcastInstance)
/*     */     {
/* 123 */       super();
/* 124 */       this.hazelcastInstance = hazelcastInstance;
/*     */     }
/*     */     
/*     */     public void close() throws IOException
/*     */     {
/* 129 */       this.hazelcastInstance.shutdown();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\cache\HazelcastInstanceConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */