/*     */ package org.springframework.boot.autoconfigure.web;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.Servlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.aop.framework.autoproxy.AutoProxyUtils;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureBefore;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.autoconfigure.condition.SearchStrategy;
/*     */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*     */ import org.springframework.boot.autoconfigure.template.TemplateAvailabilityProvider;
/*     */ import org.springframework.boot.autoconfigure.template.TemplateAvailabilityProviders;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.web.servlet.ErrorPage;
/*     */ import org.springframework.boot.web.servlet.ErrorPageRegistrar;
/*     */ import org.springframework.boot.web.servlet.ErrorPageRegistry;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.expression.MapAccessor;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.spel.standard.SpelExpressionParser;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.util.PropertyPlaceholderHelper.PlaceholderResolver;
/*     */ import org.springframework.web.servlet.DispatcherServlet;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.view.BeanNameViewResolver;
/*     */ import org.springframework.web.util.HtmlUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @ConditionalOnWebApplication
/*     */ @ConditionalOnClass({Servlet.class, DispatcherServlet.class})
/*     */ @AutoConfigureBefore({WebMvcAutoConfiguration.class})
/*     */ @EnableConfigurationProperties({ResourceProperties.class})
/*     */ public class ErrorMvcAutoConfiguration
/*     */ {
/*     */   private final ApplicationContext applicationContext;
/*     */   private final ServerProperties serverProperties;
/*     */   private final ResourceProperties resourceProperties;
/*     */   @Autowired(required=false)
/*     */   private List<ErrorViewResolver> errorViewResolvers;
/*     */   
/*     */   public ErrorMvcAutoConfiguration(ApplicationContext applicationContext, ServerProperties serverProperties, ResourceProperties resourceProperties)
/*     */   {
/*  95 */     this.applicationContext = applicationContext;
/*  96 */     this.serverProperties = serverProperties;
/*  97 */     this.resourceProperties = resourceProperties;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean(value={ErrorAttributes.class}, search=SearchStrategy.CURRENT)
/*     */   public DefaultErrorAttributes errorAttributes() {
/* 103 */     return new DefaultErrorAttributes();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean(value={ErrorController.class}, search=SearchStrategy.CURRENT)
/*     */   public BasicErrorController basicErrorController(ErrorAttributes errorAttributes) {
/* 109 */     return new BasicErrorController(errorAttributes, this.serverProperties.getError(), this.errorViewResolvers);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   public ErrorPageCustomizer errorPageCustomizer()
/*     */   {
/* 115 */     return new ErrorPageCustomizer(this.serverProperties);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnBean({DispatcherServlet.class})
/*     */   @ConditionalOnMissingBean
/*     */   public DefaultErrorViewResolver conventionErrorViewResolver() {
/* 122 */     return new DefaultErrorViewResolver(this.applicationContext, this.resourceProperties);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   public static PreserveErrorControllerTargetClassPostProcessor preserveErrorControllerTargetClassPostProcessor()
/*     */   {
/* 128 */     return new PreserveErrorControllerTargetClassPostProcessor();
/*     */   }
/*     */   
/*     */   @Configuration
/*     */   @ConditionalOnProperty(prefix="server.error.whitelabel", name={"enabled"}, matchIfMissing=true)
/*     */   @Conditional({ErrorMvcAutoConfiguration.ErrorTemplateMissingCondition.class})
/*     */   protected static class WhitelabelErrorViewConfiguration
/*     */   {
/* 136 */     private final ErrorMvcAutoConfiguration.SpelView defaultErrorView = new ErrorMvcAutoConfiguration.SpelView("<html><body><h1>Whitelabel Error Page</h1><p>This application has no explicit mapping for /error, so you are seeing this as a fallback.</p><div id='created'>${timestamp}</div><div>There was an unexpected error (type=${error}, status=${status}).</div><div>${message}</div></body></html>");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     @Bean(name={"error"})
/*     */     @ConditionalOnMissingBean(name={"error"})
/*     */     public View defaultErrorView()
/*     */     {
/* 146 */       return this.defaultErrorView;
/*     */     }
/*     */     
/*     */ 
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({BeanNameViewResolver.class})
/*     */     public BeanNameViewResolver beanNameViewResolver()
/*     */     {
/* 154 */       BeanNameViewResolver resolver = new BeanNameViewResolver();
/* 155 */       resolver.setOrder(2147483637);
/* 156 */       return resolver;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class ErrorTemplateMissingCondition
/*     */     extends SpringBootCondition
/*     */   {
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*     */     {
/* 170 */       TemplateAvailabilityProviders providers = new TemplateAvailabilityProviders(context.getClassLoader());
/* 171 */       TemplateAvailabilityProvider provider = providers.getProvider("error", context
/* 172 */         .getEnvironment(), context.getClassLoader(), context
/* 173 */         .getResourceLoader());
/* 174 */       if (provider != null)
/*     */       {
/* 176 */         return ConditionOutcome.noMatch("Template from " + provider + " found for error view");
/*     */       }
/* 178 */       return ConditionOutcome.match("No error template view detected");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class SpelView
/*     */     implements View
/*     */   {
/*     */     private final NonRecursivePropertyPlaceholderHelper helper;
/*     */     
/*     */     private final String template;
/*     */     
/*     */     private volatile Map<String, Expression> expressions;
/*     */     
/*     */ 
/*     */     SpelView(String template)
/*     */     {
/* 195 */       this.helper = new NonRecursivePropertyPlaceholderHelper("${", "}");
/* 196 */       this.template = template;
/*     */     }
/*     */     
/*     */     public String getContentType()
/*     */     {
/* 201 */       return "text/html";
/*     */     }
/*     */     
/*     */     public void render(Map<String, ?> model, HttpServletRequest request, HttpServletResponse response)
/*     */       throws Exception
/*     */     {
/* 207 */       if (response.getContentType() == null) {
/* 208 */         response.setContentType(getContentType());
/*     */       }
/* 210 */       Map<String, Object> map = new HashMap(model);
/* 211 */       map.put("path", request.getContextPath());
/* 212 */       PropertyPlaceholderHelper.PlaceholderResolver resolver = new ErrorMvcAutoConfiguration.ExpressionResolver(getExpressions(), map);
/* 213 */       String result = this.helper.replacePlaceholders(this.template, resolver);
/* 214 */       response.getWriter().append(result);
/*     */     }
/*     */     
/*     */     private Map<String, Expression> getExpressions() {
/* 218 */       if (this.expressions == null) {
/* 219 */         synchronized (this) {
/* 220 */           ErrorMvcAutoConfiguration.ExpressionCollector expressionCollector = new ErrorMvcAutoConfiguration.ExpressionCollector(null);
/* 221 */           this.helper.replacePlaceholders(this.template, expressionCollector);
/* 222 */           this.expressions = expressionCollector.getExpressions();
/*     */         }
/*     */       }
/* 225 */       return this.expressions;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class ExpressionCollector
/*     */     implements PropertyPlaceholderHelper.PlaceholderResolver
/*     */   {
/* 235 */     private final SpelExpressionParser parser = new SpelExpressionParser();
/*     */     
/* 237 */     private final Map<String, Expression> expressions = new HashMap();
/*     */     
/*     */     public String resolvePlaceholder(String name)
/*     */     {
/* 241 */       this.expressions.put(name, this.parser.parseExpression(name));
/* 242 */       return null;
/*     */     }
/*     */     
/*     */     public Map<String, Expression> getExpressions() {
/* 246 */       return Collections.unmodifiableMap(this.expressions);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class ExpressionResolver
/*     */     implements PropertyPlaceholderHelper.PlaceholderResolver
/*     */   {
/*     */     private final Map<String, Expression> expressions;
/*     */     
/*     */     private final EvaluationContext context;
/*     */     
/*     */ 
/*     */     ExpressionResolver(Map<String, Expression> expressions, Map<String, ?> map)
/*     */     {
/* 261 */       this.expressions = expressions;
/* 262 */       this.context = getContext(map);
/*     */     }
/*     */     
/*     */     private EvaluationContext getContext(Map<String, ?> map) {
/* 266 */       StandardEvaluationContext context = new StandardEvaluationContext();
/* 267 */       context.addPropertyAccessor(new MapAccessor());
/* 268 */       context.setRootObject(map);
/* 269 */       return context;
/*     */     }
/*     */     
/*     */     public String resolvePlaceholder(String placeholderName)
/*     */     {
/* 274 */       Expression expression = (Expression)this.expressions.get(placeholderName);
/* 275 */       return escape(expression == null ? null : expression.getValue(this.context));
/*     */     }
/*     */     
/*     */     private String escape(Object value) {
/* 279 */       return HtmlUtils.htmlEscape(value == null ? null : value.toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class ErrorPageCustomizer
/*     */     implements ErrorPageRegistrar, Ordered
/*     */   {
/*     */     private final ServerProperties properties;
/*     */     
/*     */ 
/*     */     protected ErrorPageCustomizer(ServerProperties properties)
/*     */     {
/* 293 */       this.properties = properties;
/*     */     }
/*     */     
/*     */ 
/*     */     public void registerErrorPages(ErrorPageRegistry errorPageRegistry)
/*     */     {
/* 299 */       ErrorPage errorPage = new ErrorPage(this.properties.getServletPrefix() + this.properties.getError().getPath());
/* 300 */       errorPageRegistry.addErrorPages(new ErrorPage[] { errorPage });
/*     */     }
/*     */     
/*     */     public int getOrder()
/*     */     {
/* 305 */       return 0;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static class PreserveErrorControllerTargetClassPostProcessor
/*     */     implements BeanFactoryPostProcessor
/*     */   {
/*     */     public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*     */       throws BeansException
/*     */     {
/* 321 */       String[] errorControllerBeans = beanFactory.getBeanNamesForType(ErrorController.class, false, false);
/* 322 */       for (String errorControllerBean : errorControllerBeans) {
/*     */         try {
/* 324 */           beanFactory.getBeanDefinition(errorControllerBean).setAttribute(AutoProxyUtils.PRESERVE_TARGET_CLASS_ATTRIBUTE, Boolean.TRUE);
/*     */         }
/*     */         catch (Throwable localThrowable) {}
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\web\ErrorMvcAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */