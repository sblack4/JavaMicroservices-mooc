/*    */ package org.springframework.boot.autoconfigure.session;
/*    */ 
/*    */ import javax.annotation.PostConstruct;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.redis.connection.RedisConnectionFactory;
/*    */ import org.springframework.data.redis.core.RedisTemplate;
/*    */ import org.springframework.session.SessionRepository;
/*    */ import org.springframework.session.data.redis.config.annotation.web.http.RedisHttpSessionConfiguration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration
/*    */ @ConditionalOnMissingBean({SessionRepository.class})
/*    */ @ConditionalOnBean({RedisTemplate.class, RedisConnectionFactory.class})
/*    */ @Conditional({SessionCondition.class})
/*    */ class RedisSessionConfiguration
/*    */ {
/* 49 */   private static final Logger logger = LoggerFactory.getLogger(RedisSessionConfiguration.class);
/*    */   
/*    */   @Configuration
/*    */   public static class SpringBootRedisHttpSessionConfiguration extends RedisHttpSessionConfiguration
/*    */   {
/*    */     private SessionProperties sessionProperties;
/*    */     
/*    */     @Autowired
/*    */     public void customize(SessionProperties sessionProperties)
/*    */     {
/* 59 */       this.sessionProperties = sessionProperties;
/* 60 */       Integer timeout = this.sessionProperties.getTimeout();
/* 61 */       if (timeout != null) {
/* 62 */         setMaxInactiveIntervalInSeconds(timeout.intValue());
/*    */       }
/* 64 */       SessionProperties.Redis redis = this.sessionProperties.getRedis();
/* 65 */       setRedisNamespace(redis.getNamespace());
/* 66 */       setRedisFlushMode(redis.getFlushMode());
/*    */     }
/*    */     
/*    */     @PostConstruct
/*    */     public void validate() {
/* 71 */       if (this.sessionProperties.getStoreType() == null) {
/* 72 */         RedisSessionConfiguration.logger.warn("Spring Session store type is mandatory: set 'spring.session.store-type=redis' in your configuration");
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\session\RedisSessionConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */