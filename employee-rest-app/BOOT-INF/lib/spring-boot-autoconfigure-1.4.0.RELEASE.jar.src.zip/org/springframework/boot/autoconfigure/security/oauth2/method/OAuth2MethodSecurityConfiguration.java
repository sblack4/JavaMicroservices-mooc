/*     */ package org.springframework.boot.autoconfigure.security.oauth2.method;
/*     */ 
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.security.access.PermissionEvaluator;
/*     */ import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*     */ import org.springframework.security.config.annotation.method.configuration.GlobalMethodSecurityConfiguration;
/*     */ import org.springframework.security.oauth2.common.OAuth2AccessToken;
/*     */ import org.springframework.security.oauth2.provider.expression.OAuth2MethodSecurityExpressionHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @ConditionalOnClass({OAuth2AccessToken.class})
/*     */ @ConditionalOnBean({GlobalMethodSecurityConfiguration.class})
/*     */ public class OAuth2MethodSecurityConfiguration
/*     */   implements BeanFactoryPostProcessor, ApplicationContextAware
/*     */ {
/*     */   private ApplicationContext applicationContext;
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext)
/*     */     throws BeansException
/*     */   {
/*  55 */     this.applicationContext = applicationContext;
/*     */   }
/*     */   
/*     */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*     */     throws BeansException
/*     */   {
/*  61 */     OAuth2ExpressionHandlerInjectionPostProcessor processor = new OAuth2ExpressionHandlerInjectionPostProcessor(this.applicationContext);
/*     */     
/*  63 */     beanFactory.addBeanPostProcessor(processor);
/*     */   }
/*     */   
/*     */   private static class OAuth2ExpressionHandlerInjectionPostProcessor
/*     */     implements BeanPostProcessor
/*     */   {
/*     */     private ApplicationContext applicationContext;
/*     */     
/*     */     OAuth2ExpressionHandlerInjectionPostProcessor(ApplicationContext applicationContext)
/*     */     {
/*  73 */       this.applicationContext = applicationContext;
/*     */     }
/*     */     
/*     */     public Object postProcessBeforeInitialization(Object bean, String beanName)
/*     */       throws BeansException
/*     */     {
/*  79 */       return bean;
/*     */     }
/*     */     
/*     */     public Object postProcessAfterInitialization(Object bean, String beanName)
/*     */       throws BeansException
/*     */     {
/*  85 */       if (((bean instanceof DefaultMethodSecurityExpressionHandler)) && (!(bean instanceof OAuth2MethodSecurityExpressionHandler)))
/*     */       {
/*  87 */         return getExpressionHandler((DefaultMethodSecurityExpressionHandler)bean);
/*     */       }
/*     */       
/*  90 */       return bean;
/*     */     }
/*     */     
/*     */     private OAuth2MethodSecurityExpressionHandler getExpressionHandler(DefaultMethodSecurityExpressionHandler bean)
/*     */     {
/*  95 */       OAuth2MethodSecurityExpressionHandler handler = new OAuth2MethodSecurityExpressionHandler();
/*  96 */       handler.setApplicationContext(this.applicationContext);
/*  97 */       AuthenticationTrustResolver trustResolver = (AuthenticationTrustResolver)findInContext(AuthenticationTrustResolver.class);
/*     */       
/*  99 */       if (trustResolver != null) {
/* 100 */         handler.setTrustResolver(trustResolver);
/*     */       }
/* 102 */       PermissionEvaluator permissions = (PermissionEvaluator)findInContext(PermissionEvaluator.class);
/* 103 */       if (permissions != null) {
/* 104 */         handler.setPermissionEvaluator(permissions);
/*     */       }
/* 106 */       handler.setExpressionParser(bean.getExpressionParser());
/* 107 */       return handler;
/*     */     }
/*     */     
/*     */     private <T> T findInContext(Class<T> type) {
/* 111 */       if (BeanFactoryUtils.beanNamesForTypeIncludingAncestors(this.applicationContext, type).length == 1)
/*     */       {
/* 113 */         return (T)this.applicationContext.getBean(type);
/*     */       }
/* 115 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\security\oauth2\method\OAuth2MethodSecurityConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */