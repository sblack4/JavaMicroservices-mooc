package org.springframework.boot.autoconfigure.web;

import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.ModelAndView;

public abstract interface ErrorViewResolver
{
  public abstract ModelAndView resolveErrorView(HttpServletRequest paramHttpServletRequest, HttpStatus paramHttpStatus, Map<String, Object> paramMap);
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\web\ErrorViewResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */