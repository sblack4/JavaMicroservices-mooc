/*     */ package org.springframework.boot.autoconfigure.liquibase;
/*     */ 
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.sql.DataSource;
/*     */ import liquibase.integration.spring.SpringLiquibase;
/*     */ import liquibase.servicelocator.ServiceLocator;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.data.jpa.EntityManagerFactoryDependsOnPostProcessor;
/*     */ import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
/*     */ import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.liquibase.CommonsLoggingLiquibaseLogger;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.orm.jpa.AbstractEntityManagerFactoryBean;
/*     */ import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @ConditionalOnClass({SpringLiquibase.class})
/*     */ @ConditionalOnBean({DataSource.class})
/*     */ @ConditionalOnProperty(prefix="liquibase", name={"enabled"}, matchIfMissing=true)
/*     */ @AutoConfigureAfter({DataSourceAutoConfiguration.class, HibernateJpaAutoConfiguration.class})
/*     */ public class LiquibaseAutoConfiguration
/*     */ {
/*     */   @Configuration
/*     */   @ConditionalOnMissingBean({SpringLiquibase.class})
/*     */   @EnableConfigurationProperties({LiquibaseProperties.class})
/*     */   @Import({LiquibaseAutoConfiguration.LiquibaseJpaDependencyConfiguration.class})
/*     */   public static class LiquibaseConfiguration
/*     */   {
/*     */     private final LiquibaseProperties properties;
/*     */     private final ResourceLoader resourceLoader;
/*     */     private final DataSource dataSource;
/*     */     
/*     */     public LiquibaseConfiguration(LiquibaseProperties properties, ResourceLoader resourceLoader, DataSource dataSource)
/*     */     {
/*  77 */       this.properties = properties;
/*  78 */       this.resourceLoader = resourceLoader;
/*  79 */       this.dataSource = dataSource;
/*     */     }
/*     */     
/*     */     @PostConstruct
/*     */     public void checkChangelogExists() {
/*  84 */       if (this.properties.isCheckChangeLogLocation())
/*     */       {
/*  86 */         Resource resource = this.resourceLoader.getResource(this.properties.getChangeLog());
/*  87 */         Assert.state(resource.exists(), "Cannot find changelog location: " + resource + " (please add changelog or check your Liquibase " + "configuration)");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*  92 */       ServiceLocator serviceLocator = ServiceLocator.getInstance();
/*  93 */       serviceLocator.addPackageToScan(CommonsLoggingLiquibaseLogger.class
/*  94 */         .getPackage().getName());
/*     */     }
/*     */     
/*     */     @Bean
/*     */     public SpringLiquibase liquibase() {
/*  99 */       SpringLiquibase liquibase = new SpringLiquibase();
/* 100 */       liquibase.setChangeLog(this.properties.getChangeLog());
/* 101 */       liquibase.setContexts(this.properties.getContexts());
/* 102 */       liquibase.setDataSource(getDataSource());
/* 103 */       liquibase.setDefaultSchema(this.properties.getDefaultSchema());
/* 104 */       liquibase.setDropFirst(this.properties.isDropFirst());
/* 105 */       liquibase.setShouldRun(this.properties.isEnabled());
/* 106 */       liquibase.setLabels(this.properties.getLabels());
/* 107 */       liquibase.setChangeLogParameters(this.properties.getParameters());
/* 108 */       liquibase.setRollbackFile(this.properties.getRollbackFile());
/* 109 */       return liquibase;
/*     */     }
/*     */     
/*     */     private DataSource getDataSource() {
/* 113 */       if (this.properties.getUrl() == null) {
/* 114 */         return this.dataSource;
/*     */       }
/*     */       
/*     */ 
/* 118 */       return DataSourceBuilder.create().url(this.properties.getUrl()).username(this.properties.getUser()).password(this.properties.getPassword()).build();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Configuration
/*     */   @ConditionalOnClass({LocalContainerEntityManagerFactoryBean.class})
/*     */   @ConditionalOnBean({AbstractEntityManagerFactoryBean.class})
/*     */   protected static class LiquibaseJpaDependencyConfiguration
/*     */     extends EntityManagerFactoryDependsOnPostProcessor
/*     */   {
/*     */     public LiquibaseJpaDependencyConfiguration()
/*     */     {
/* 133 */       super();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\liquibase\LiquibaseAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */