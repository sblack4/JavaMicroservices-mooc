/*    */ package org.springframework.boot.autoconfigure.h2;
/*    */ 
/*    */ import javax.validation.constraints.NotNull;
/*    */ import javax.validation.constraints.Pattern;
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix="spring.h2.console")
/*    */ public class H2ConsoleProperties
/*    */ {
/*    */   @NotNull
/*    */   @Pattern(regexp="/[^?#]*", message="Path must start with /")
/* 38 */   private String path = "/h2-console";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 45 */   private boolean enabled = false;
/*    */   
/* 47 */   private final Settings settings = new Settings();
/*    */   
/*    */   public String getPath() {
/* 50 */     return this.path;
/*    */   }
/*    */   
/*    */   public void setPath(String path) {
/* 54 */     this.path = path;
/*    */   }
/*    */   
/*    */   public boolean getEnabled() {
/* 58 */     return this.enabled;
/*    */   }
/*    */   
/*    */   public void setEnabled(boolean enabled) {
/* 62 */     this.enabled = enabled;
/*    */   }
/*    */   
/*    */   public Settings getSettings() {
/* 66 */     return this.settings;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static class Settings
/*    */   {
/* 74 */     private boolean trace = false;
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 79 */     private boolean webAllowOthers = false;
/*    */     
/*    */     public boolean isTrace() {
/* 82 */       return this.trace;
/*    */     }
/*    */     
/*    */     public void setTrace(boolean trace) {
/* 86 */       this.trace = trace;
/*    */     }
/*    */     
/*    */     public boolean isWebAllowOthers() {
/* 90 */       return this.webAllowOthers;
/*    */     }
/*    */     
/*    */     public void setWebAllowOthers(boolean webAllowOthers) {
/* 94 */       this.webAllowOthers = webAllowOthers;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\h2\H2ConsoleProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */