/*     */ package org.springframework.boot.autoconfigure.amqp;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.amqp.core.AcknowledgeMode;
/*     */ import org.springframework.amqp.rabbit.connection.CachingConnectionFactory.CacheMode;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.NestedConfigurationProperty;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.rabbitmq")
/*     */ public class RabbitProperties
/*     */ {
/*  45 */   private String host = "localhost";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  50 */   private int port = 5672;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String username;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String password;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  65 */   private final Ssl ssl = new Ssl();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String virtualHost;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String addresses;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Integer requestedHeartbeat;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean publisherConfirms;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean publisherReturns;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Integer connectionTimeout;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 100 */   private final Cache cache = new Cache();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 105 */   private final Listener listener = new Listener();
/*     */   
/* 107 */   private final Template template = new Template();
/*     */   private List<Address> parsedAddresses;
/*     */   
/*     */   public String getHost()
/*     */   {
/* 112 */     return this.host;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String determineHost()
/*     */   {
/* 123 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/* 124 */       return getHost();
/*     */     }
/* 126 */     return ((Address)this.parsedAddresses.get(0)).host;
/*     */   }
/*     */   
/*     */   public void setHost(String host) {
/* 130 */     this.host = host;
/*     */   }
/*     */   
/*     */   public int getPort() {
/* 134 */     return this.port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int determinePort()
/*     */   {
/* 145 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/* 146 */       return getPort();
/*     */     }
/* 148 */     Address address = (Address)this.parsedAddresses.get(0);
/* 149 */     return address.port;
/*     */   }
/*     */   
/*     */   public void setPort(int port) {
/* 153 */     this.port = port;
/*     */   }
/*     */   
/*     */   public String getAddresses() {
/* 157 */     return this.addresses;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String determineAddresses()
/*     */   {
/* 166 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/* 167 */       return this.host + ":" + this.port;
/*     */     }
/* 169 */     List<String> addressStrings = new ArrayList();
/* 170 */     for (Address parsedAddress : this.parsedAddresses) {
/* 171 */       addressStrings.add(parsedAddress.host + ":" + parsedAddress.port);
/*     */     }
/* 173 */     return StringUtils.collectionToCommaDelimitedString(addressStrings);
/*     */   }
/*     */   
/*     */   public void setAddresses(String addresses) {
/* 177 */     this.addresses = addresses;
/* 178 */     this.parsedAddresses = parseAddresses(addresses);
/*     */   }
/*     */   
/*     */   private List<Address> parseAddresses(String addresses) {
/* 182 */     List<Address> parsedAddresses = new ArrayList();
/* 183 */     for (String address : StringUtils.commaDelimitedListToStringArray(addresses)) {
/* 184 */       parsedAddresses.add(new Address(address, null));
/*     */     }
/* 186 */     return parsedAddresses;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/* 190 */     return this.username;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String determineUsername()
/*     */   {
/* 201 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/* 202 */       return this.username;
/*     */     }
/* 204 */     Address address = (Address)this.parsedAddresses.get(0);
/* 205 */     return address.username == null ? this.username : address.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/* 209 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 213 */     return this.password;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String determinePassword()
/*     */   {
/* 224 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/* 225 */       return getPassword();
/*     */     }
/* 227 */     Address address = (Address)this.parsedAddresses.get(0);
/* 228 */     return address.password == null ? getPassword() : address.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 232 */     this.password = password;
/*     */   }
/*     */   
/*     */   public Ssl getSsl() {
/* 236 */     return this.ssl;
/*     */   }
/*     */   
/*     */   public String getVirtualHost() {
/* 240 */     return this.virtualHost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String determineVirtualHost()
/*     */   {
/* 251 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/* 252 */       return getVirtualHost();
/*     */     }
/* 254 */     Address address = (Address)this.parsedAddresses.get(0);
/* 255 */     return address.virtualHost == null ? getVirtualHost() : address.virtualHost;
/*     */   }
/*     */   
/*     */   public void setVirtualHost(String virtualHost) {
/* 259 */     this.virtualHost = ("".equals(virtualHost) ? "/" : virtualHost);
/*     */   }
/*     */   
/*     */   public Integer getRequestedHeartbeat() {
/* 263 */     return this.requestedHeartbeat;
/*     */   }
/*     */   
/*     */   public void setRequestedHeartbeat(Integer requestedHeartbeat) {
/* 267 */     this.requestedHeartbeat = requestedHeartbeat;
/*     */   }
/*     */   
/*     */   public boolean isPublisherConfirms() {
/* 271 */     return this.publisherConfirms;
/*     */   }
/*     */   
/*     */   public void setPublisherConfirms(boolean publisherConfirms) {
/* 275 */     this.publisherConfirms = publisherConfirms;
/*     */   }
/*     */   
/*     */   public boolean isPublisherReturns() {
/* 279 */     return this.publisherReturns;
/*     */   }
/*     */   
/*     */   public void setPublisherReturns(boolean publisherReturns) {
/* 283 */     this.publisherReturns = publisherReturns;
/*     */   }
/*     */   
/*     */   public Integer getConnectionTimeout() {
/* 287 */     return this.connectionTimeout;
/*     */   }
/*     */   
/*     */   public void setConnectionTimeout(Integer connectionTimeout) {
/* 291 */     this.connectionTimeout = connectionTimeout;
/*     */   }
/*     */   
/*     */   public Cache getCache() {
/* 295 */     return this.cache;
/*     */   }
/*     */   
/*     */   public Listener getListener() {
/* 299 */     return this.listener;
/*     */   }
/*     */   
/*     */   public Template getTemplate() {
/* 303 */     return this.template;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Ssl
/*     */   {
/*     */     private boolean enabled;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private String keyStore;
/*     */     
/*     */ 
/*     */ 
/*     */     private String keyStorePassword;
/*     */     
/*     */ 
/*     */ 
/*     */     private String trustStore;
/*     */     
/*     */ 
/*     */ 
/*     */     private String trustStorePassword;
/*     */     
/*     */ 
/*     */ 
/*     */     private String algorithm;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isEnabled()
/*     */     {
/* 340 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 344 */       this.enabled = enabled;
/*     */     }
/*     */     
/*     */     public String getKeyStore() {
/* 348 */       return this.keyStore;
/*     */     }
/*     */     
/*     */     public void setKeyStore(String keyStore) {
/* 352 */       this.keyStore = keyStore;
/*     */     }
/*     */     
/*     */     public String getKeyStorePassword() {
/* 356 */       return this.keyStorePassword;
/*     */     }
/*     */     
/*     */     public void setKeyStorePassword(String keyStorePassword) {
/* 360 */       this.keyStorePassword = keyStorePassword;
/*     */     }
/*     */     
/*     */     public String getTrustStore() {
/* 364 */       return this.trustStore;
/*     */     }
/*     */     
/*     */     public void setTrustStore(String trustStore) {
/* 368 */       this.trustStore = trustStore;
/*     */     }
/*     */     
/*     */     public String getTrustStorePassword() {
/* 372 */       return this.trustStorePassword;
/*     */     }
/*     */     
/*     */     public void setTrustStorePassword(String trustStorePassword) {
/* 376 */       this.trustStorePassword = trustStorePassword;
/*     */     }
/*     */     
/*     */     public String getAlgorithm() {
/* 380 */       return this.algorithm;
/*     */     }
/*     */     
/*     */     public void setAlgorithm(String sslAlgorithm) {
/* 384 */       this.algorithm = sslAlgorithm;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class Cache
/*     */   {
/* 391 */     private final Channel channel = new Channel();
/*     */     
/* 393 */     private final Connection connection = new Connection();
/*     */     
/*     */     public Channel getChannel() {
/* 396 */       return this.channel;
/*     */     }
/*     */     
/*     */     public Connection getConnection() {
/* 400 */       return this.connection;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public static class Channel
/*     */     {
/*     */       private Integer size;
/*     */       
/*     */ 
/*     */ 
/*     */       private Long checkoutTimeout;
/*     */       
/*     */ 
/*     */ 
/*     */       public Integer getSize()
/*     */       {
/* 418 */         return this.size;
/*     */       }
/*     */       
/*     */       public void setSize(Integer size) {
/* 422 */         this.size = size;
/*     */       }
/*     */       
/*     */       public Long getCheckoutTimeout() {
/* 426 */         return this.checkoutTimeout;
/*     */       }
/*     */       
/*     */       public void setCheckoutTimeout(Long checkoutTimeout) {
/* 430 */         this.checkoutTimeout = checkoutTimeout;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static class Connection
/*     */     {
/* 440 */       private CachingConnectionFactory.CacheMode mode = CachingConnectionFactory.CacheMode.CHANNEL;
/*     */       
/*     */ 
/*     */       private Integer size;
/*     */       
/*     */ 
/*     */       public CachingConnectionFactory.CacheMode getMode()
/*     */       {
/* 448 */         return this.mode;
/*     */       }
/*     */       
/*     */       public void setMode(CachingConnectionFactory.CacheMode mode) {
/* 452 */         this.mode = mode;
/*     */       }
/*     */       
/*     */       public Integer getSize() {
/* 456 */         return this.size;
/*     */       }
/*     */       
/*     */       public void setSize(Integer size) {
/* 460 */         this.size = size;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Listener
/*     */   {
/* 472 */     private boolean autoStartup = true;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private AcknowledgeMode acknowledgeMode;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private Integer concurrency;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private Integer maxConcurrency;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private Integer prefetch;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private Integer transactionSize;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private Boolean defaultRequeueRejected;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     @NestedConfigurationProperty
/* 509 */     private final RabbitProperties.ListenerRetry retry = new RabbitProperties.ListenerRetry();
/*     */     
/*     */     public boolean isAutoStartup()
/*     */     {
/* 513 */       return this.autoStartup;
/*     */     }
/*     */     
/*     */     public void setAutoStartup(boolean autoStartup) {
/* 517 */       this.autoStartup = autoStartup;
/*     */     }
/*     */     
/*     */     public AcknowledgeMode getAcknowledgeMode() {
/* 521 */       return this.acknowledgeMode;
/*     */     }
/*     */     
/*     */     public void setAcknowledgeMode(AcknowledgeMode acknowledgeMode) {
/* 525 */       this.acknowledgeMode = acknowledgeMode;
/*     */     }
/*     */     
/*     */     public Integer getConcurrency() {
/* 529 */       return this.concurrency;
/*     */     }
/*     */     
/*     */     public void setConcurrency(Integer concurrency) {
/* 533 */       this.concurrency = concurrency;
/*     */     }
/*     */     
/*     */     public Integer getMaxConcurrency() {
/* 537 */       return this.maxConcurrency;
/*     */     }
/*     */     
/*     */     public void setMaxConcurrency(Integer maxConcurrency) {
/* 541 */       this.maxConcurrency = maxConcurrency;
/*     */     }
/*     */     
/*     */     public Integer getPrefetch() {
/* 545 */       return this.prefetch;
/*     */     }
/*     */     
/*     */     public void setPrefetch(Integer prefetch) {
/* 549 */       this.prefetch = prefetch;
/*     */     }
/*     */     
/*     */     public Integer getTransactionSize() {
/* 553 */       return this.transactionSize;
/*     */     }
/*     */     
/*     */     public void setTransactionSize(Integer transactionSize) {
/* 557 */       this.transactionSize = transactionSize;
/*     */     }
/*     */     
/*     */     public Boolean getDefaultRequeueRejected() {
/* 561 */       return this.defaultRequeueRejected;
/*     */     }
/*     */     
/*     */     public void setDefaultRequeueRejected(Boolean defaultRequeueRejected) {
/* 565 */       this.defaultRequeueRejected = defaultRequeueRejected;
/*     */     }
/*     */     
/*     */     public RabbitProperties.ListenerRetry getRetry() {
/* 569 */       return this.retry;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Template
/*     */   {
/*     */     @NestedConfigurationProperty
/* 576 */     private final RabbitProperties.Retry retry = new RabbitProperties.Retry();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private Boolean mandatory;
/*     */     
/*     */ 
/*     */ 
/*     */     private Long receiveTimeout;
/*     */     
/*     */ 
/*     */ 
/*     */     private Long replyTimeout;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public RabbitProperties.Retry getRetry()
/*     */     {
/* 596 */       return this.retry;
/*     */     }
/*     */     
/*     */     public Boolean getMandatory() {
/* 600 */       return this.mandatory;
/*     */     }
/*     */     
/*     */     public void setMandatory(Boolean mandatory) {
/* 604 */       this.mandatory = mandatory;
/*     */     }
/*     */     
/*     */     public Long getReceiveTimeout() {
/* 608 */       return this.receiveTimeout;
/*     */     }
/*     */     
/*     */     public void setReceiveTimeout(Long receiveTimeout) {
/* 612 */       this.receiveTimeout = receiveTimeout;
/*     */     }
/*     */     
/*     */     public Long getReplyTimeout() {
/* 616 */       return this.replyTimeout;
/*     */     }
/*     */     
/*     */     public void setReplyTimeout(Long replyTimeout) {
/* 620 */       this.replyTimeout = replyTimeout;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Retry
/*     */   {
/*     */     private boolean enabled;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 635 */     private int maxAttempts = 3;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 640 */     private long initialInterval = 1000L;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 645 */     private double multiplier = 1.0D;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 650 */     private long maxInterval = 10000L;
/*     */     
/*     */     public boolean isEnabled() {
/* 653 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 657 */       this.enabled = enabled;
/*     */     }
/*     */     
/*     */     public int getMaxAttempts() {
/* 661 */       return this.maxAttempts;
/*     */     }
/*     */     
/*     */     public void setMaxAttempts(int maxAttempts) {
/* 665 */       this.maxAttempts = maxAttempts;
/*     */     }
/*     */     
/*     */     public long getInitialInterval() {
/* 669 */       return this.initialInterval;
/*     */     }
/*     */     
/*     */     public void setInitialInterval(long initialInterval) {
/* 673 */       this.initialInterval = initialInterval;
/*     */     }
/*     */     
/*     */     public double getMultiplier() {
/* 677 */       return this.multiplier;
/*     */     }
/*     */     
/*     */     public void setMultiplier(double multiplier) {
/* 681 */       this.multiplier = multiplier;
/*     */     }
/*     */     
/*     */     public long getMaxInterval() {
/* 685 */       return this.maxInterval;
/*     */     }
/*     */     
/*     */     public void setMaxInterval(long maxInterval) {
/* 689 */       this.maxInterval = maxInterval;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class ListenerRetry
/*     */     extends RabbitProperties.Retry
/*     */   {
/* 699 */     private boolean stateless = true;
/*     */     
/*     */     public boolean isStateless() {
/* 702 */       return this.stateless;
/*     */     }
/*     */     
/*     */     public void setStateless(boolean stateless) {
/* 706 */       this.stateless = stateless;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static final class Address
/*     */   {
/*     */     private static final String PREFIX_AMQP = "amqp://";
/*     */     
/*     */     private static final int DEFAULT_PORT = 5672;
/*     */     
/*     */     private String host;
/*     */     
/*     */     private int port;
/*     */     
/*     */     private String username;
/*     */     
/*     */     private String password;
/*     */     private String virtualHost;
/*     */     
/*     */     private Address(String input)
/*     */     {
/* 728 */       input = input.trim();
/* 729 */       input = trimPrefix(input);
/* 730 */       input = parseUsernameAndPassword(input);
/* 731 */       input = parseVirtualHost(input);
/* 732 */       parseHostAndPort(input);
/*     */     }
/*     */     
/*     */     private String trimPrefix(String input) {
/* 736 */       if (input.startsWith("amqp://")) {
/* 737 */         input = input.substring("amqp://".length());
/*     */       }
/* 739 */       return input;
/*     */     }
/*     */     
/*     */     private String parseUsernameAndPassword(String input) {
/* 743 */       if (input.contains("@")) {
/* 744 */         String[] split = StringUtils.split(input, "@");
/* 745 */         String creds = split[0];
/* 746 */         input = split[1];
/* 747 */         split = StringUtils.split(creds, ":");
/* 748 */         this.username = split[0];
/* 749 */         if (split.length > 0) {
/* 750 */           this.password = split[1];
/*     */         }
/*     */       }
/* 753 */       return input;
/*     */     }
/*     */     
/*     */     private String parseVirtualHost(String input) {
/* 757 */       int hostIndex = input.indexOf("/");
/* 758 */       if ((hostIndex >= 0) && (hostIndex < input.length())) {
/* 759 */         this.virtualHost = input.substring(hostIndex + 1);
/* 760 */         if (this.virtualHost.length() == 0) {
/* 761 */           this.virtualHost = "/";
/*     */         }
/* 763 */         input = input.substring(0, hostIndex);
/*     */       }
/* 765 */       return input;
/*     */     }
/*     */     
/*     */     private void parseHostAndPort(String input) {
/* 769 */       int portIndex = input.indexOf(':');
/* 770 */       if (portIndex == -1) {
/* 771 */         this.host = input;
/* 772 */         this.port = 5672;
/*     */       }
/*     */       else {
/* 775 */         this.host = input.substring(0, portIndex);
/* 776 */         this.port = Integer.valueOf(input.substring(portIndex + 1)).intValue();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\amqp\RabbitProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */