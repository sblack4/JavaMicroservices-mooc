/*     */ package org.springframework.boot.autoconfigure.cache;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.List;
/*     */ import org.infinispan.configuration.cache.ConfigurationBuilder;
/*     */ import org.infinispan.manager.DefaultCacheManager;
/*     */ import org.infinispan.manager.EmbeddedCacheManager;
/*     */ import org.infinispan.spring.provider.SpringEmbeddedCacheManager;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.cache.CacheManager;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @org.springframework.context.annotation.Configuration
/*     */ @ConditionalOnClass({SpringEmbeddedCacheManager.class})
/*     */ @ConditionalOnMissingBean({CacheManager.class})
/*     */ @Conditional({CacheCondition.class})
/*     */ public class InfinispanCacheConfiguration
/*     */ {
/*     */   private final CacheProperties cacheProperties;
/*     */   private final CacheManagerCustomizers customizers;
/*     */   private final ConfigurationBuilder defaultConfigurationBuilder;
/*     */   
/*     */   public InfinispanCacheConfiguration(CacheProperties cacheProperties, CacheManagerCustomizers customizers, ObjectProvider<ConfigurationBuilder> defaultConfigurationBuilderProvider)
/*     */   {
/*  60 */     this.cacheProperties = cacheProperties;
/*  61 */     this.customizers = customizers;
/*     */     
/*  63 */     this.defaultConfigurationBuilder = ((ConfigurationBuilder)defaultConfigurationBuilderProvider.getIfAvailable());
/*     */   }
/*     */   
/*     */   @Bean
/*     */   public SpringEmbeddedCacheManager cacheManager(EmbeddedCacheManager embeddedCacheManager)
/*     */   {
/*  69 */     SpringEmbeddedCacheManager cacheManager = new SpringEmbeddedCacheManager(embeddedCacheManager);
/*     */     
/*  71 */     return (SpringEmbeddedCacheManager)this.customizers.customize(cacheManager);
/*     */   }
/*     */   
/*     */   @Bean(destroyMethod="stop")
/*     */   @ConditionalOnMissingBean
/*     */   public EmbeddedCacheManager infinispanCacheManager() throws IOException {
/*  77 */     EmbeddedCacheManager cacheManager = createEmbeddedCacheManager();
/*  78 */     List<String> cacheNames = this.cacheProperties.getCacheNames();
/*  79 */     if (!CollectionUtils.isEmpty(cacheNames)) {
/*  80 */       for (String cacheName : cacheNames) {
/*  81 */         cacheManager.defineConfiguration(cacheName, 
/*  82 */           getDefaultCacheConfiguration());
/*     */       }
/*     */     }
/*  85 */     return cacheManager;
/*     */   }
/*     */   
/*     */   private EmbeddedCacheManager createEmbeddedCacheManager() throws IOException
/*     */   {
/*  90 */     Resource location = this.cacheProperties.resolveConfigLocation(this.cacheProperties.getInfinispan().getConfig());
/*  91 */     if (location != null) {
/*  92 */       InputStream in = location.getInputStream();
/*     */       try {
/*  94 */         return new DefaultCacheManager(in);
/*     */       }
/*     */       finally {
/*  97 */         in.close();
/*     */       }
/*     */     }
/* 100 */     return new DefaultCacheManager();
/*     */   }
/*     */   
/*     */   private org.infinispan.configuration.cache.Configuration getDefaultCacheConfiguration() {
/* 104 */     if (this.defaultConfigurationBuilder != null) {
/* 105 */       return this.defaultConfigurationBuilder.build();
/*     */     }
/* 107 */     return new ConfigurationBuilder().build();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\cache\InfinispanCacheConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */