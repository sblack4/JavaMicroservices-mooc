/*    */ package org.springframework.boot.autoconfigure.jms.activemq;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.util.List;
/*    */ import org.apache.activemq.ActiveMQConnectionFactory;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ActiveMQConnectionFactoryFactory
/*    */ {
/*    */   private static final String DEFAULT_EMBEDDED_BROKER_URL = "vm://localhost?broker.persistent=false";
/*    */   private static final String DEFAULT_NETWORK_BROKER_URL = "tcp://localhost:61616";
/*    */   private final ActiveMQProperties properties;
/*    */   
/*    */   ActiveMQConnectionFactoryFactory(ActiveMQProperties properties)
/*    */   {
/* 44 */     Assert.notNull(properties, "Properties must not be null");
/* 45 */     this.properties = properties;
/*    */   }
/*    */   
/*    */   public <T extends ActiveMQConnectionFactory> T createConnectionFactory(Class<T> factoryClass)
/*    */   {
/*    */     try {
/* 51 */       return doCreateConnectionFactory(factoryClass);
/*    */     }
/*    */     catch (Exception ex) {
/* 54 */       throw new IllegalStateException("Unable to create ActiveMQConnectionFactory", ex);
/*    */     }
/*    */   }
/*    */   
/*    */   private <T extends ActiveMQConnectionFactory> T doCreateConnectionFactory(Class<T> factoryClass)
/*    */     throws Exception
/*    */   {
/* 61 */     T factory = createConnectionFactoryInstance(factoryClass);
/* 62 */     ActiveMQProperties.Packages packages = this.properties.getPackages();
/* 63 */     if (packages.getTrustAll() != null) {
/* 64 */       factory.setTrustAllPackages(packages.getTrustAll().booleanValue());
/*    */     }
/* 66 */     if (!packages.getTrusted().isEmpty()) {
/* 67 */       factory.setTrustedPackages(packages.getTrusted());
/*    */     }
/* 69 */     return factory;
/*    */   }
/*    */   
/*    */   private <T extends ActiveMQConnectionFactory> T createConnectionFactoryInstance(Class<T> factoryClass)
/*    */     throws InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*    */   {
/* 75 */     String brokerUrl = determineBrokerUrl();
/* 76 */     String user = this.properties.getUser();
/* 77 */     String password = this.properties.getPassword();
/* 78 */     if ((StringUtils.hasLength(user)) && (StringUtils.hasLength(password)))
/*    */     {
/* 80 */       return (ActiveMQConnectionFactory)factoryClass.getConstructor(new Class[] { String.class, String.class, String.class }).newInstance(new Object[] { user, password, brokerUrl });
/*    */     }
/* 82 */     return (ActiveMQConnectionFactory)factoryClass.getConstructor(new Class[] { String.class }).newInstance(new Object[] { brokerUrl });
/*    */   }
/*    */   
/*    */   String determineBrokerUrl() {
/* 86 */     if (this.properties.getBrokerUrl() != null) {
/* 87 */       return this.properties.getBrokerUrl();
/*    */     }
/* 89 */     if (this.properties.isInMemory()) {
/* 90 */       return "vm://localhost?broker.persistent=false";
/*    */     }
/* 92 */     return "tcp://localhost:61616";
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jms\activemq\ActiveMQConnectionFactoryFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */