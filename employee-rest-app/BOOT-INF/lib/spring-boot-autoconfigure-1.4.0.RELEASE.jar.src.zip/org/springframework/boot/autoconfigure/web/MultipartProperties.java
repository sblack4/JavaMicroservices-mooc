/*     */ package org.springframework.boot.autoconfigure.web;
/*     */ 
/*     */ import javax.servlet.MultipartConfigElement;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.web.servlet.MultipartConfigFactory;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.http.multipart", ignoreUnknownFields=false)
/*     */ public class MultipartProperties
/*     */ {
/*  53 */   private boolean enabled = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String location;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  64 */   private String maxFileSize = "1Mb";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  70 */   private String maxRequestSize = "10Mb";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  76 */   private String fileSizeThreshold = "0";
/*     */   
/*     */   public boolean getEnabled() {
/*  79 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/*  83 */     this.enabled = enabled;
/*     */   }
/*     */   
/*     */   public String getLocation() {
/*  87 */     return this.location;
/*     */   }
/*     */   
/*     */   public void setLocation(String location) {
/*  91 */     this.location = location;
/*     */   }
/*     */   
/*     */   public String getMaxFileSize() {
/*  95 */     return this.maxFileSize;
/*     */   }
/*     */   
/*     */   public void setMaxFileSize(String maxFileSize) {
/*  99 */     this.maxFileSize = maxFileSize;
/*     */   }
/*     */   
/*     */   public String getMaxRequestSize() {
/* 103 */     return this.maxRequestSize;
/*     */   }
/*     */   
/*     */   public void setMaxRequestSize(String maxRequestSize) {
/* 107 */     this.maxRequestSize = maxRequestSize;
/*     */   }
/*     */   
/*     */   public String getFileSizeThreshold() {
/* 111 */     return this.fileSizeThreshold;
/*     */   }
/*     */   
/*     */   public void setFileSizeThreshold(String fileSizeThreshold) {
/* 115 */     this.fileSizeThreshold = fileSizeThreshold;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MultipartConfigElement createMultipartConfig()
/*     */   {
/* 123 */     MultipartConfigFactory factory = new MultipartConfigFactory();
/* 124 */     if (StringUtils.hasText(this.fileSizeThreshold)) {
/* 125 */       factory.setFileSizeThreshold(this.fileSizeThreshold);
/*     */     }
/* 127 */     if (StringUtils.hasText(this.location)) {
/* 128 */       factory.setLocation(this.location);
/*     */     }
/* 130 */     if (StringUtils.hasText(this.maxRequestSize)) {
/* 131 */       factory.setMaxRequestSize(this.maxRequestSize);
/*     */     }
/* 133 */     if (StringUtils.hasText(this.maxFileSize)) {
/* 134 */       factory.setMaxFileSize(this.maxFileSize);
/*     */     }
/* 136 */     return factory.createMultipartConfig();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\web\MultipartProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */