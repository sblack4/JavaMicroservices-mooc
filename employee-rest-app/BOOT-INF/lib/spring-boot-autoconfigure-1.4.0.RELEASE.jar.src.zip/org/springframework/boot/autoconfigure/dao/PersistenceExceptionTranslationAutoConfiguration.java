/*    */ package org.springframework.boot.autoconfigure.dao;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConditionalOnClass({PersistenceExceptionTranslationPostProcessor.class})
/*    */ public class PersistenceExceptionTranslationAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean({PersistenceExceptionTranslationPostProcessor.class})
/*    */   @ConditionalOnProperty(prefix="spring.dao.exceptiontranslation", name={"enabled"}, matchIfMissing=true)
/*    */   public static PersistenceExceptionTranslationPostProcessor persistenceExceptionTranslationPostProcessor()
/*    */   {
/* 40 */     PersistenceExceptionTranslationPostProcessor postProcessor = new PersistenceExceptionTranslationPostProcessor();
/* 41 */     postProcessor.setProxyTargetClass(true);
/* 42 */     return postProcessor;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\dao\PersistenceExceptionTranslationAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */