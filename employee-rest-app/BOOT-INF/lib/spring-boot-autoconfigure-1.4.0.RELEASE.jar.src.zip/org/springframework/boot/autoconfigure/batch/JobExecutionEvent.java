/*    */ package org.springframework.boot.autoconfigure.batch;
/*    */ 
/*    */ import org.springframework.batch.core.JobExecution;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JobExecutionEvent
/*    */   extends ApplicationEvent
/*    */ {
/*    */   private final JobExecution execution;
/*    */   
/*    */   public JobExecutionEvent(JobExecution execution)
/*    */   {
/* 37 */     super(execution);
/* 38 */     this.execution = execution;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public JobExecution getJobExecution()
/*    */   {
/* 46 */     return this.execution;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\batch\JobExecutionEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */