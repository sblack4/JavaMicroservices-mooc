/*     */ package org.springframework.boot.autoconfigure.flyway;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.sql.DataSource;
/*     */ import org.flywaydb.core.Flyway;
/*     */ import org.flywaydb.core.api.MigrationVersion;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.data.jpa.EntityManagerFactoryDependsOnPostProcessor;
/*     */ import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.ConfigurationPropertiesBinding;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.orm.jpa.AbstractEntityManagerFactoryBean;
/*     */ import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @ConditionalOnClass({Flyway.class})
/*     */ @ConditionalOnBean({DataSource.class})
/*     */ @ConditionalOnProperty(prefix="flyway", name={"enabled"}, matchIfMissing=true)
/*     */ @AutoConfigureAfter({DataSourceAutoConfiguration.class, HibernateJpaAutoConfiguration.class})
/*     */ public class FlywayAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   @ConfigurationPropertiesBinding
/*     */   public StringOrNumberToMigrationVersionConverter stringOrNumberMigrationVersionConverter()
/*     */   {
/*  74 */     return new StringOrNumberToMigrationVersionConverter(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Configuration
/*     */   @ConditionalOnMissingBean({Flyway.class})
/*     */   @EnableConfigurationProperties({FlywayProperties.class})
/*     */   public static class FlywayConfiguration
/*     */   {
/*     */     private final FlywayProperties properties;
/*     */     
/*     */     private final ResourceLoader resourceLoader;
/*     */     
/*     */     private final DataSource dataSource;
/*     */     
/*     */     private final DataSource flywayDataSource;
/*     */     
/*     */     private final FlywayMigrationStrategy migrationStrategy;
/*     */     
/*     */ 
/*     */     public FlywayConfiguration(FlywayProperties properties, ResourceLoader resourceLoader, ObjectProvider<DataSource> dataSourceProvider, @FlywayDataSource ObjectProvider<DataSource> flywayDataSourceProvider, ObjectProvider<FlywayMigrationStrategy> migrationStrategyProvider)
/*     */     {
/*  97 */       this.properties = properties;
/*  98 */       this.resourceLoader = resourceLoader;
/*  99 */       this.dataSource = ((DataSource)dataSourceProvider.getIfUnique());
/* 100 */       this.flywayDataSource = ((DataSource)flywayDataSourceProvider.getIfAvailable());
/* 101 */       this.migrationStrategy = ((FlywayMigrationStrategy)migrationStrategyProvider.getIfAvailable());
/*     */     }
/*     */     
/*     */     @PostConstruct
/*     */     public void checkLocationExists() {
/* 106 */       if (this.properties.isCheckLocation()) {
/* 107 */         Assert.state(!this.properties.getLocations().isEmpty(), "Migration script locations not configured");
/*     */         
/* 109 */         boolean exists = hasAtLeastOneLocation();
/* 110 */         Assert.state(exists, "Cannot find migrations location in: " + this.properties
/*     */         
/* 112 */           .getLocations() + " (please add migrations or check your Flyway configuration)");
/*     */       }
/*     */     }
/*     */     
/*     */     private boolean hasAtLeastOneLocation()
/*     */     {
/* 118 */       for (String location : this.properties.getLocations()) {
/* 119 */         if (this.resourceLoader.getResource(location).exists()) {
/* 120 */           return true;
/*     */         }
/*     */       }
/* 123 */       return false;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConfigurationProperties(prefix="flyway")
/*     */     public Flyway flyway() {
/* 129 */       Flyway flyway = new Flyway();
/* 130 */       if (this.properties.isCreateDataSource()) {
/* 131 */         flyway.setDataSource(this.properties.getUrl(), this.properties.getUser(), this.properties
/* 132 */           .getPassword(), 
/* 133 */           (String[])this.properties.getInitSqls().toArray(new String[0]));
/*     */       }
/* 135 */       else if (this.flywayDataSource != null) {
/* 136 */         flyway.setDataSource(this.flywayDataSource);
/*     */       }
/*     */       else {
/* 139 */         flyway.setDataSource(this.dataSource);
/*     */       }
/* 141 */       flyway.setLocations((String[])this.properties.getLocations().toArray(new String[0]));
/* 142 */       return flyway;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     public FlywayMigrationInitializer flywayInitializer(Flyway flyway) {
/* 148 */       return new FlywayMigrationInitializer(flyway, this.migrationStrategy);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     @Configuration
/*     */     @ConditionalOnClass({LocalContainerEntityManagerFactoryBean.class})
/*     */     @ConditionalOnBean({AbstractEntityManagerFactoryBean.class})
/*     */     protected static class FlywayInitializerJpaDependencyConfiguration
/*     */       extends EntityManagerFactoryDependsOnPostProcessor
/*     */     {
/*     */       public FlywayInitializerJpaDependencyConfiguration()
/*     */       {
/* 162 */         super();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Configuration
/*     */   @ConditionalOnClass({LocalContainerEntityManagerFactoryBean.class})
/*     */   @ConditionalOnBean({AbstractEntityManagerFactoryBean.class})
/*     */   protected static class FlywayJpaDependencyConfiguration
/*     */     extends EntityManagerFactoryDependsOnPostProcessor
/*     */   {
/*     */     public FlywayJpaDependencyConfiguration()
/*     */     {
/* 180 */       super();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class StringOrNumberToMigrationVersionConverter
/*     */     implements GenericConverter
/*     */   {
/*     */     private static final Set<GenericConverter.ConvertiblePair> CONVERTIBLE_TYPES;
/*     */     
/*     */ 
/*     */     static
/*     */     {
/* 194 */       Set<GenericConverter.ConvertiblePair> types = new HashSet(2);
/* 195 */       types.add(new GenericConverter.ConvertiblePair(String.class, MigrationVersion.class));
/* 196 */       types.add(new GenericConverter.ConvertiblePair(Number.class, MigrationVersion.class));
/* 197 */       CONVERTIBLE_TYPES = Collections.unmodifiableSet(types);
/*     */     }
/*     */     
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*     */     {
/* 202 */       return CONVERTIBLE_TYPES;
/*     */     }
/*     */     
/*     */ 
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 208 */       String value = ObjectUtils.nullSafeToString(source);
/* 209 */       return MigrationVersion.fromVersion(value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\flyway\FlywayAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */