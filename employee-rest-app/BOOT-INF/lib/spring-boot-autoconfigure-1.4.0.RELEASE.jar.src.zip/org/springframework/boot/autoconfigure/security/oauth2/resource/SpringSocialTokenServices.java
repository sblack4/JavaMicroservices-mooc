/*    */ package org.springframework.boot.autoconfigure.security.oauth2.resource;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.security.core.authority.AuthorityUtils;
/*    */ import org.springframework.security.oauth2.common.OAuth2AccessToken;
/*    */ import org.springframework.security.oauth2.common.exceptions.InvalidTokenException;
/*    */ import org.springframework.security.oauth2.provider.OAuth2Authentication;
/*    */ import org.springframework.security.oauth2.provider.OAuth2Request;
/*    */ import org.springframework.security.oauth2.provider.token.ResourceServerTokenServices;
/*    */ import org.springframework.social.connect.Connection;
/*    */ import org.springframework.social.connect.UserProfile;
/*    */ import org.springframework.social.connect.support.OAuth2ConnectionFactory;
/*    */ import org.springframework.social.oauth2.AccessGrant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpringSocialTokenServices
/*    */   implements ResourceServerTokenServices
/*    */ {
/* 46 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */   
/*    */   private final OAuth2ConnectionFactory<?> connectionFactory;
/*    */   
/*    */   private final String clientId;
/*    */   
/*    */   public SpringSocialTokenServices(OAuth2ConnectionFactory<?> connectionFactory, String clientId)
/*    */   {
/* 54 */     this.connectionFactory = connectionFactory;
/* 55 */     this.clientId = clientId;
/*    */   }
/*    */   
/*    */   public OAuth2Authentication loadAuthentication(String accessToken)
/*    */     throws AuthenticationException, InvalidTokenException
/*    */   {
/* 61 */     AccessGrant accessGrant = new AccessGrant(accessToken);
/* 62 */     Connection<?> connection = this.connectionFactory.createConnection(accessGrant);
/* 63 */     UserProfile user = connection.fetchUserProfile();
/* 64 */     return extractAuthentication(user);
/*    */   }
/*    */   
/*    */   private OAuth2Authentication extractAuthentication(UserProfile user) {
/* 68 */     String principal = user.getUsername();
/*    */     
/* 70 */     List<GrantedAuthority> authorities = AuthorityUtils.commaSeparatedStringToAuthorityList("ROLE_USER");
/* 71 */     OAuth2Request request = new OAuth2Request(null, this.clientId, null, true, null, null, null, null, null);
/*    */     
/* 73 */     return new OAuth2Authentication(request, new UsernamePasswordAuthenticationToken(principal, "N/A", authorities));
/*    */   }
/*    */   
/*    */ 
/*    */   public OAuth2AccessToken readAccessToken(String accessToken)
/*    */   {
/* 79 */     throw new UnsupportedOperationException("Not supported: read access token");
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\security\oauth2\resource\SpringSocialTokenServices.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */