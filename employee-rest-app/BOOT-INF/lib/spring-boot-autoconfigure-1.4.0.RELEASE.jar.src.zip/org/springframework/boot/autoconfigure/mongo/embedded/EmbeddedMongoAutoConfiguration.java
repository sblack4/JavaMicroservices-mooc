/*     */ package org.springframework.boot.autoconfigure.mongo.embedded;
/*     */ 
/*     */ import com.mongodb.Mongo;
/*     */ import com.mongodb.MongoClient;
/*     */ import de.flapdoodle.embed.mongo.Command;
/*     */ import de.flapdoodle.embed.mongo.MongodExecutable;
/*     */ import de.flapdoodle.embed.mongo.MongodStarter;
/*     */ import de.flapdoodle.embed.mongo.config.ExtractedArtifactStoreBuilder;
/*     */ import de.flapdoodle.embed.mongo.config.IMongodConfig;
/*     */ import de.flapdoodle.embed.mongo.config.MongodConfigBuilder;
/*     */ import de.flapdoodle.embed.mongo.config.Net;
/*     */ import de.flapdoodle.embed.mongo.config.Storage;
/*     */ import de.flapdoodle.embed.mongo.distribution.Feature;
/*     */ import de.flapdoodle.embed.mongo.distribution.IFeatureAwareVersion;
/*     */ import de.flapdoodle.embed.process.config.IRuntimeConfig;
/*     */ import de.flapdoodle.embed.process.config.io.ProcessOutput;
/*     */ import de.flapdoodle.embed.process.io.Processors;
/*     */ import de.flapdoodle.embed.process.io.Slf4jLevel;
/*     */ import de.flapdoodle.embed.process.io.progress.Slf4jProgressListener;
/*     */ import de.flapdoodle.embed.process.runtime.Network;
/*     */ import de.flapdoodle.embed.process.store.ArtifactStoreBuilder;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureBefore;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.data.mongo.MongoClientDependsOnBeanFactoryPostProcessor;
/*     */ import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.mongo.MongoProperties;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.MapPropertySource;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.data.mongodb.core.MongoClientFactoryBean;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @EnableConfigurationProperties({MongoProperties.class, EmbeddedMongoProperties.class})
/*     */ @AutoConfigureBefore({MongoAutoConfiguration.class})
/*     */ @ConditionalOnClass({Mongo.class, MongodStarter.class})
/*     */ public class EmbeddedMongoAutoConfiguration
/*     */ {
/*  83 */   private static final byte[] IP4_LOOPBACK_ADDRESS = { Byte.MAX_VALUE, 0, 0, 1 };
/*     */   
/*  85 */   private static final byte[] IP6_LOOPBACK_ADDRESS = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };
/*     */   
/*     */ 
/*     */   private final MongoProperties properties;
/*     */   
/*     */   private final EmbeddedMongoProperties embeddedProperties;
/*     */   
/*     */   private final ApplicationContext context;
/*     */   
/*     */   private final IRuntimeConfig runtimeConfig;
/*     */   
/*     */ 
/*     */   public EmbeddedMongoAutoConfiguration(MongoProperties properties, EmbeddedMongoProperties embeddedProperties, ApplicationContext context, IRuntimeConfig runtimeConfig)
/*     */   {
/*  99 */     this.properties = properties;
/* 100 */     this.embeddedProperties = embeddedProperties;
/* 101 */     this.context = context;
/* 102 */     this.runtimeConfig = runtimeConfig;
/*     */   }
/*     */   
/*     */   @Bean(initMethod="start", destroyMethod="stop")
/*     */   @ConditionalOnMissingBean
/*     */   public MongodExecutable embeddedMongoServer(IMongodConfig mongodConfig) throws IOException
/*     */   {
/* 109 */     if (getPort() == 0) {
/* 110 */       publishPortInfo(mongodConfig.net().getPort());
/*     */     }
/* 112 */     MongodStarter mongodStarter = getMongodStarter(this.runtimeConfig);
/* 113 */     return (MongodExecutable)mongodStarter.prepare(mongodConfig);
/*     */   }
/*     */   
/*     */   private MongodStarter getMongodStarter(IRuntimeConfig runtimeConfig) {
/* 117 */     if (runtimeConfig == null) {
/* 118 */       return MongodStarter.getDefaultInstance();
/*     */     }
/* 120 */     return MongodStarter.getInstance(runtimeConfig);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public IMongodConfig embeddedMongoConfiguration()
/*     */     throws IOException
/*     */   {
/* 128 */     IFeatureAwareVersion featureAwareVersion = new ToStringFriendlyFeatureAwareVersion(this.embeddedProperties.getVersion(), this.embeddedProperties.getFeatures(), null);
/*     */     
/* 130 */     MongodConfigBuilder builder = new MongodConfigBuilder().version(featureAwareVersion);
/* 131 */     if (this.embeddedProperties.getStorage() != null) {
/* 132 */       builder.replication(new Storage(this.embeddedProperties
/* 133 */         .getStorage().getDatabaseDir(), this.embeddedProperties
/* 134 */         .getStorage().getReplSetName(), this.embeddedProperties
/* 135 */         .getStorage().getOplogSize() != null ? this.embeddedProperties
/* 136 */         .getStorage().getOplogSize().intValue() : 0));
/*     */     }
/*     */     
/* 139 */     if (getPort() > 0) {
/* 140 */       builder.net(new Net(getHost().getHostAddress(), getPort(), 
/* 141 */         Network.localhostIsIPv6()));
/*     */     }
/*     */     else {
/* 144 */       builder.net(new Net(getHost().getHostAddress(), 
/* 145 */         Network.getFreeServerPort(getHost()), Network.localhostIsIPv6()));
/*     */     }
/* 147 */     return builder.build();
/*     */   }
/*     */   
/*     */   private int getPort() {
/* 151 */     if (this.properties.getPort() == null) {
/* 152 */       return 27017;
/*     */     }
/* 154 */     return this.properties.getPort().intValue();
/*     */   }
/*     */   
/*     */   private InetAddress getHost() throws UnknownHostException {
/* 158 */     if (this.properties.getHost() == null) {
/* 159 */       return InetAddress.getByAddress(Network.localhostIsIPv6() ? IP6_LOOPBACK_ADDRESS : IP4_LOOPBACK_ADDRESS);
/*     */     }
/*     */     
/* 162 */     return InetAddress.getByName(this.properties.getHost());
/*     */   }
/*     */   
/*     */   private void publishPortInfo(int port) {
/* 166 */     setPortProperty(this.context, port);
/*     */   }
/*     */   
/*     */   private void setPortProperty(ApplicationContext currentContext, int port) {
/* 170 */     if ((currentContext instanceof ConfigurableApplicationContext))
/*     */     {
/* 172 */       MutablePropertySources sources = ((ConfigurableApplicationContext)currentContext).getEnvironment().getPropertySources();
/* 173 */       getMongoPorts(sources).put("local.mongo.port", Integer.valueOf(port));
/*     */     }
/* 175 */     if (currentContext.getParent() != null) {
/* 176 */       setPortProperty(currentContext.getParent(), port);
/*     */     }
/*     */   }
/*     */   
/*     */   private Map<String, Object> getMongoPorts(MutablePropertySources sources)
/*     */   {
/* 182 */     PropertySource<?> propertySource = sources.get("mongo.ports");
/* 183 */     if (propertySource == null) {
/* 184 */       propertySource = new MapPropertySource("mongo.ports", new HashMap());
/*     */       
/* 186 */       sources.addFirst(propertySource);
/*     */     }
/* 188 */     return (Map)propertySource.getSource();
/*     */   }
/*     */   
/*     */   @Configuration
/*     */   @ConditionalOnClass({Logger.class})
/*     */   @ConditionalOnMissingBean({IRuntimeConfig.class})
/*     */   static class RuntimeConfigConfiguration
/*     */   {
/*     */     @Bean
/*     */     public IRuntimeConfig embeddedMongoRuntimeConfig()
/*     */     {
/* 199 */       Logger logger = LoggerFactory.getLogger(getClass().getPackage().getName() + ".EmbeddedMongo");
/*     */       
/*     */ 
/* 202 */       ProcessOutput processOutput = new ProcessOutput(Processors.logTo(logger, Slf4jLevel.INFO), Processors.logTo(logger, Slf4jLevel.ERROR), Processors.named("[console>]", 
/* 203 */         Processors.logTo(logger, Slf4jLevel.DEBUG)));
/*     */       
/*     */ 
/* 206 */       return new de.flapdoodle.embed.mongo.config.RuntimeConfigBuilder().defaultsWithLogger(Command.MongoD, logger).processOutput(processOutput).artifactStore(getArtifactStore(logger)).build();
/*     */     }
/*     */     
/*     */     private ArtifactStoreBuilder getArtifactStore(Logger logger)
/*     */     {
/* 211 */       return new ExtractedArtifactStoreBuilder().defaults(Command.MongoD).download(new de.flapdoodle.embed.mongo.config.DownloadConfigBuilder()
/* 212 */         .defaultsForCommand(Command.MongoD)
/* 213 */         .progressListener(new Slf4jProgressListener(logger)).build());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Configuration
/*     */   @ConditionalOnClass({MongoClient.class, MongoClientFactoryBean.class})
/*     */   protected static class EmbeddedMongoDependencyConfiguration
/*     */     extends MongoClientDependsOnBeanFactoryPostProcessor
/*     */   {
/*     */     public EmbeddedMongoDependencyConfiguration()
/*     */     {
/* 228 */       super();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final class ToStringFriendlyFeatureAwareVersion
/*     */     implements IFeatureAwareVersion
/*     */   {
/*     */     private final String version;
/*     */     
/*     */ 
/*     */     private final Set<Feature> features;
/*     */     
/*     */ 
/*     */ 
/*     */     private ToStringFriendlyFeatureAwareVersion(String version, Set<Feature> features)
/*     */     {
/* 246 */       Assert.notNull(version, "version must not be null");
/* 247 */       this.version = version;
/* 248 */       this.features = (features == null ? Collections.emptySet() : features);
/*     */     }
/*     */     
/*     */ 
/*     */     public String asInDownloadPath()
/*     */     {
/* 254 */       return this.version;
/*     */     }
/*     */     
/*     */     public boolean enabled(Feature feature)
/*     */     {
/* 259 */       return this.features.contains(feature);
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 264 */       return this.version;
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 269 */       int prime = 31;
/* 270 */       int result = 1;
/* 271 */       result = 31 * result + this.features.hashCode();
/* 272 */       result = 31 * result + this.version.hashCode();
/* 273 */       return result;
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/* 278 */       if (this == obj) {
/* 279 */         return true;
/*     */       }
/* 281 */       if (obj == null) {
/* 282 */         return false;
/*     */       }
/* 284 */       if (getClass() == obj.getClass()) {
/* 285 */         ToStringFriendlyFeatureAwareVersion other = (ToStringFriendlyFeatureAwareVersion)obj;
/* 286 */         boolean equals = true;
/* 287 */         equals &= this.features.equals(other.features);
/* 288 */         equals &= this.version.equals(other.version);
/* 289 */         return equals;
/*     */       }
/* 291 */       return super.equals(obj);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\mongo\embedded\EmbeddedMongoAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */