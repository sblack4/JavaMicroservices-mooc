/*     */ package org.springframework.boot.autoconfigure.data.neo4j;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import org.neo4j.ogm.config.CompilerConfiguration;
/*     */ import org.neo4j.ogm.config.Configuration;
/*     */ import org.neo4j.ogm.config.DriverConfiguration;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.data.neo4j")
/*     */ public class Neo4jProperties
/*     */   implements ApplicationContextAware
/*     */ {
/*     */   static final String EMBEDDED_DRIVER = "org.neo4j.ogm.drivers.embedded.driver.EmbeddedDriver";
/*     */   static final String HTTP_DRIVER = "org.neo4j.ogm.drivers.http.driver.HttpDriver";
/*     */   static final String DEFAULT_HTTP_URI = "http://localhost:7474";
/*     */   private String uri;
/*     */   private String username;
/*     */   private String password;
/*     */   private String compiler;
/*  68 */   private final Embedded embedded = new Embedded();
/*     */   
/*  70 */   private ClassLoader classLoader = Neo4jProperties.class.getClassLoader();
/*     */   
/*     */   public String getUri() {
/*  73 */     return this.uri;
/*     */   }
/*     */   
/*     */   public void setUri(String uri) {
/*  77 */     this.uri = uri;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/*  81 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/*  85 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/*  89 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/*  93 */     this.password = password;
/*     */   }
/*     */   
/*     */   public String getCompiler() {
/*  97 */     return this.compiler;
/*     */   }
/*     */   
/*     */   public void setCompiler(String compiler) {
/* 101 */     this.compiler = compiler;
/*     */   }
/*     */   
/*     */   public Embedded getEmbedded() {
/* 105 */     return this.embedded;
/*     */   }
/*     */   
/*     */   public void setApplicationContext(ApplicationContext ctx) throws BeansException
/*     */   {
/* 110 */     this.classLoader = ctx.getClassLoader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Configuration createConfiguration()
/*     */   {
/* 118 */     Configuration configuration = new Configuration();
/* 119 */     configureDriver(configuration.driverConfiguration());
/* 120 */     if (this.compiler != null) {
/* 121 */       configuration.compilerConfiguration().setCompilerClassName(this.compiler);
/*     */     }
/* 123 */     return configuration;
/*     */   }
/*     */   
/*     */   private void configureDriver(DriverConfiguration driverConfiguration) {
/* 127 */     if (this.uri != null) {
/* 128 */       configureDriverFromUri(driverConfiguration, this.uri);
/*     */     }
/*     */     else {
/* 131 */       configureDriverWithDefaults(driverConfiguration);
/*     */     }
/* 133 */     if ((this.username != null) && (this.password != null)) {
/* 134 */       driverConfiguration.setCredentials(this.username, this.password);
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureDriverFromUri(DriverConfiguration driverConfiguration, String uri)
/*     */   {
/* 140 */     driverConfiguration.setDriverClassName(deduceDriverFromUri());
/* 141 */     driverConfiguration.setURI(uri);
/*     */   }
/*     */   
/*     */   private String deduceDriverFromUri() {
/*     */     try {
/* 146 */       URI uri = new URI(this.uri);
/* 147 */       String scheme = uri.getScheme();
/* 148 */       if ((scheme == null) || (scheme.equals("file"))) {
/* 149 */         return "org.neo4j.ogm.drivers.embedded.driver.EmbeddedDriver";
/*     */       }
/* 151 */       if ("http".equals(scheme)) {
/* 152 */         return "org.neo4j.ogm.drivers.http.driver.HttpDriver";
/*     */       }
/* 154 */       throw new IllegalArgumentException("Could not deduce driver to use based on URI '" + uri + "'");
/*     */     }
/*     */     catch (URISyntaxException ex)
/*     */     {
/* 158 */       throw new IllegalArgumentException("Invalid URI for spring.data.neo4j.uri '" + this.uri + "'", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureDriverWithDefaults(DriverConfiguration driverConfiguration)
/*     */   {
/* 164 */     if ((getEmbedded().isEnabled()) && 
/* 165 */       (ClassUtils.isPresent("org.neo4j.ogm.drivers.embedded.driver.EmbeddedDriver", this.classLoader))) {
/* 166 */       driverConfiguration.setDriverClassName("org.neo4j.ogm.drivers.embedded.driver.EmbeddedDriver");
/* 167 */       return;
/*     */     }
/* 169 */     driverConfiguration.setDriverClassName("org.neo4j.ogm.drivers.http.driver.HttpDriver");
/* 170 */     driverConfiguration.setURI("http://localhost:7474");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Embedded
/*     */   {
/* 178 */     private boolean enabled = true;
/*     */     
/*     */     public boolean isEnabled() {
/* 181 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 185 */       this.enabled = enabled;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\data\neo4j\Neo4jProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */