/*     */ package org.springframework.boot.autoconfigure.orm.jpa;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.boot.autoconfigure.jdbc.EmbeddedDatabaseConnection;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.DeprecatedConfigurationProperty;
/*     */ import org.springframework.boot.context.properties.NestedConfigurationProperty;
/*     */ import org.springframework.orm.jpa.vendor.Database;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.jpa")
/*     */ public class JpaProperties
/*     */ {
/*  45 */   private Map<String, String> properties = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String databasePlatform;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  57 */   private Database database = Database.DEFAULT;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  62 */   private boolean generateDdl = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  67 */   private boolean showSql = false;
/*     */   
/*  69 */   private Hibernate hibernate = new Hibernate();
/*     */   
/*     */   public Map<String, String> getProperties() {
/*  72 */     return this.properties;
/*     */   }
/*     */   
/*     */   public void setProperties(Map<String, String> properties) {
/*  76 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   public String getDatabasePlatform() {
/*  80 */     return this.databasePlatform;
/*     */   }
/*     */   
/*     */   public void setDatabasePlatform(String databasePlatform) {
/*  84 */     this.databasePlatform = databasePlatform;
/*     */   }
/*     */   
/*     */   public Database getDatabase() {
/*  88 */     return this.database;
/*     */   }
/*     */   
/*     */   public void setDatabase(Database database) {
/*  92 */     this.database = database;
/*     */   }
/*     */   
/*     */   public boolean isGenerateDdl() {
/*  96 */     return this.generateDdl;
/*     */   }
/*     */   
/*     */   public void setGenerateDdl(boolean generateDdl) {
/* 100 */     this.generateDdl = generateDdl;
/*     */   }
/*     */   
/*     */   public boolean isShowSql() {
/* 104 */     return this.showSql;
/*     */   }
/*     */   
/*     */   public void setShowSql(boolean showSql) {
/* 108 */     this.showSql = showSql;
/*     */   }
/*     */   
/*     */   public Hibernate getHibernate() {
/* 112 */     return this.hibernate;
/*     */   }
/*     */   
/*     */   public void setHibernate(Hibernate hibernate) {
/* 116 */     this.hibernate = hibernate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, String> getHibernateProperties(DataSource dataSource)
/*     */   {
/* 126 */     return this.hibernate.getAdditionalProperties(this.properties, dataSource);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Hibernate
/*     */   {
/*     */     private static final String USE_NEW_ID_GENERATOR_MAPPINGS = "hibernate.id.new_generator_mappings";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private String ddlAuto;
/*     */     
/*     */ 
/*     */ 
/*     */     private Boolean useNewIdGeneratorMappings;
/*     */     
/*     */ 
/*     */ 
/*     */     @NestedConfigurationProperty
/* 149 */     private final JpaProperties.Naming naming = new JpaProperties.Naming();
/*     */     
/*     */     @Deprecated
/*     */     @DeprecatedConfigurationProperty(replacement="spring.jpa.hibernate.naming.strategy")
/*     */     public String getNamingStrategy()
/*     */     {
/* 155 */       return getNaming().getStrategy();
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public void setNamingStrategy(String namingStrategy) {
/* 160 */       getNaming().setStrategy(namingStrategy);
/*     */     }
/*     */     
/*     */     public String getDdlAuto() {
/* 164 */       return this.ddlAuto;
/*     */     }
/*     */     
/*     */     public void setDdlAuto(String ddlAuto) {
/* 168 */       this.ddlAuto = ddlAuto;
/*     */     }
/*     */     
/*     */     public boolean isUseNewIdGeneratorMappings() {
/* 172 */       return this.useNewIdGeneratorMappings.booleanValue();
/*     */     }
/*     */     
/*     */     public void setUseNewIdGeneratorMappings(boolean useNewIdGeneratorMappings) {
/* 176 */       this.useNewIdGeneratorMappings = Boolean.valueOf(useNewIdGeneratorMappings);
/*     */     }
/*     */     
/*     */     public JpaProperties.Naming getNaming() {
/* 180 */       return this.naming;
/*     */     }
/*     */     
/*     */     private Map<String, String> getAdditionalProperties(Map<String, String> existing, DataSource dataSource)
/*     */     {
/* 185 */       Map<String, String> result = new HashMap(existing);
/* 186 */       applyNewIdGeneratorMappings(result);
/* 187 */       getNaming().applyNamingStrategy(result);
/* 188 */       String ddlAuto = getOrDeduceDdlAuto(existing, dataSource);
/* 189 */       if ((StringUtils.hasText(ddlAuto)) && (!"none".equals(ddlAuto))) {
/* 190 */         result.put("hibernate.hbm2ddl.auto", ddlAuto);
/*     */       }
/*     */       else {
/* 193 */         result.remove("hibernate.hbm2ddl.auto");
/*     */       }
/* 195 */       return result;
/*     */     }
/*     */     
/*     */     private void applyNewIdGeneratorMappings(Map<String, String> result) {
/* 199 */       if (this.useNewIdGeneratorMappings != null) {
/* 200 */         result.put("hibernate.id.new_generator_mappings", this.useNewIdGeneratorMappings
/* 201 */           .toString());
/*     */       }
/* 203 */       else if ((HibernateVersion.getRunning() == HibernateVersion.V5) && 
/* 204 */         (!result.containsKey("hibernate.id.new_generator_mappings"))) {
/* 205 */         result.put("hibernate.id.new_generator_mappings", "false");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     private String getOrDeduceDdlAuto(Map<String, String> existing, DataSource dataSource)
/*     */     {
/* 212 */       String ddlAuto = this.ddlAuto != null ? this.ddlAuto : getDefaultDdlAuto(dataSource);
/* 213 */       if ((!existing.containsKey("hibernate.hbm2ddl.auto")) && 
/* 214 */         (!"none".equals(ddlAuto))) {
/* 215 */         return ddlAuto;
/*     */       }
/* 217 */       if (existing.containsKey("hibernate.hbm2ddl.auto")) {
/* 218 */         return (String)existing.get("hibernate.hbm2ddl.auto");
/*     */       }
/* 220 */       return "none";
/*     */     }
/*     */     
/*     */     private String getDefaultDdlAuto(DataSource dataSource) {
/* 224 */       if (EmbeddedDatabaseConnection.isEmbedded(dataSource)) {
/* 225 */         return "create-drop";
/*     */       }
/* 227 */       return "none";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Naming
/*     */   {
/*     */     private static final String DEFAULT_HIBERNATE4_STRATEGY = "org.springframework.boot.orm.jpa.hibernate.SpringNamingStrategy";
/*     */     
/*     */ 
/*     */     private static final String DEFAULT_PHYSICAL_STRATEGY = "org.springframework.boot.orm.jpa.hibernate.SpringPhysicalNamingStrategy";
/*     */     
/*     */ 
/*     */     private static final String DEFAULT_IMPLICIT_STRATEGY = "org.springframework.boot.orm.jpa.hibernate.SpringImplicitNamingStrategy";
/*     */     
/*     */ 
/*     */     private String implicitStrategy;
/*     */     
/*     */ 
/*     */     private String physicalStrategy;
/*     */     
/*     */ 
/*     */     private String strategy;
/*     */     
/*     */ 
/*     */ 
/*     */     public String getImplicitStrategy()
/*     */     {
/* 257 */       return this.implicitStrategy;
/*     */     }
/*     */     
/*     */     public void setImplicitStrategy(String implicitStrategy) {
/* 261 */       this.implicitStrategy = implicitStrategy;
/*     */     }
/*     */     
/*     */     public String getPhysicalStrategy() {
/* 265 */       return this.physicalStrategy;
/*     */     }
/*     */     
/*     */     public void setPhysicalStrategy(String physicalStrategy) {
/* 269 */       this.physicalStrategy = physicalStrategy;
/*     */     }
/*     */     
/*     */     public String getStrategy() {
/* 273 */       return this.strategy;
/*     */     }
/*     */     
/*     */     public void setStrategy(String strategy) {
/* 277 */       this.strategy = strategy;
/*     */     }
/*     */     
/*     */     private void applyNamingStrategy(Map<String, String> properties) {
/* 281 */       switch (JpaProperties.1.$SwitchMap$org$springframework$boot$autoconfigure$orm$jpa$HibernateVersion[HibernateVersion.getRunning().ordinal()]) {
/*     */       case 1: 
/* 283 */         applyHibernate4NamingStrategy(properties);
/* 284 */         break;
/*     */       case 2: 
/* 286 */         applyHibernate5NamingStrategy(properties);
/*     */       }
/*     */     }
/*     */     
/*     */     private void applyHibernate5NamingStrategy(Map<String, String> properties)
/*     */     {
/* 292 */       applyHibernate5NamingStrategy(properties, "hibernate.implicit_naming_strategy", this.implicitStrategy, "org.springframework.boot.orm.jpa.hibernate.SpringImplicitNamingStrategy");
/*     */       
/*     */ 
/* 295 */       applyHibernate5NamingStrategy(properties, "hibernate.physical_naming_strategy", this.physicalStrategy, "org.springframework.boot.orm.jpa.hibernate.SpringPhysicalNamingStrategy");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private void applyHibernate5NamingStrategy(Map<String, String> properties, String key, String strategy, String defaultStrategy)
/*     */     {
/* 302 */       if (strategy != null) {
/* 303 */         properties.put(key, strategy);
/*     */       }
/* 305 */       else if ((defaultStrategy != null) && (!properties.containsKey(key))) {
/* 306 */         properties.put(key, defaultStrategy);
/*     */       }
/*     */     }
/*     */     
/*     */     private void applyHibernate4NamingStrategy(Map<String, String> properties) {
/* 311 */       if (!properties.containsKey("hibernate.ejb.naming_strategy_delegator")) {
/* 312 */         properties.put("hibernate.ejb.naming_strategy", 
/* 313 */           getHibernate4NamingStrategy(properties));
/*     */       }
/*     */     }
/*     */     
/*     */     private String getHibernate4NamingStrategy(Map<String, String> existing) {
/* 318 */       if ((!existing.containsKey("hibernate.ejb.naming_strategy")) && (this.strategy != null))
/*     */       {
/* 320 */         return this.strategy;
/*     */       }
/* 322 */       return "org.springframework.boot.orm.jpa.hibernate.SpringNamingStrategy";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\orm\jpa\JpaProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */