/*    */ package org.springframework.boot.autoconfigure.cache;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactoryUtils;
/*    */ import org.springframework.cache.CacheManager;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ import org.springframework.context.ConfigurableApplicationContext;
/*    */ import org.springframework.core.GenericTypeResolver;
/*    */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CacheManagerCustomizers
/*    */   implements ApplicationContextAware
/*    */ {
/*    */   private ConfigurableApplicationContext applicationContext;
/*    */   
/*    */   public <T extends CacheManager> T customize(T cacheManager)
/*    */   {
/* 52 */     List<CacheManagerCustomizer<CacheManager>> customizers = findCustomizers(cacheManager);
/*    */     
/* 54 */     AnnotationAwareOrderComparator.sort(customizers);
/* 55 */     for (CacheManagerCustomizer<CacheManager> customizer : customizers) {
/* 56 */       customizer.customize(cacheManager);
/*    */     }
/* 58 */     return cacheManager;
/*    */   }
/*    */   
/*    */ 
/*    */   private List<CacheManagerCustomizer<CacheManager>> findCustomizers(CacheManager cacheManager)
/*    */   {
/* 64 */     if (this.applicationContext == null) {
/* 65 */       return Collections.emptyList();
/*    */     }
/* 67 */     Class<?> cacheManagerClass = cacheManager.getClass();
/* 68 */     List<CacheManagerCustomizer<CacheManager>> customizers = new ArrayList();
/* 69 */     for (CacheManagerCustomizer customizer : getBeans(CacheManagerCustomizer.class)) {
/* 70 */       if (canCustomize(customizer, cacheManagerClass)) {
/* 71 */         customizers.add(customizer);
/*    */       }
/*    */     }
/* 74 */     return customizers;
/*    */   }
/*    */   
/*    */   private <T> Collection<T> getBeans(Class<T> type)
/*    */   {
/* 79 */     return BeanFactoryUtils.beansOfTypeIncludingAncestors(this.applicationContext.getBeanFactory(), type).values();
/*    */   }
/*    */   
/*    */   private boolean canCustomize(CacheManagerCustomizer<?> customizer, Class<?> cacheManagerClass)
/*    */   {
/* 84 */     Class<?> target = GenericTypeResolver.resolveTypeArgument(customizer.getClass(), CacheManagerCustomizer.class);
/*    */     
/* 86 */     return (target == null) || (target.isAssignableFrom(cacheManagerClass));
/*    */   }
/*    */   
/*    */   public void setApplicationContext(ApplicationContext applicationContext)
/*    */     throws BeansException
/*    */   {
/* 92 */     if ((applicationContext instanceof ConfigurableApplicationContext)) {
/* 93 */       this.applicationContext = ((ConfigurableApplicationContext)applicationContext);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\cache\CacheManagerCustomizers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */