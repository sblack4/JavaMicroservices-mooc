/*    */ package org.springframework.boot.autoconfigure.jms;
/*    */ 
/*    */ import javax.jms.ConnectionFactory;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Import;
/*    */ import org.springframework.jms.core.JmsMessagingTemplate;
/*    */ import org.springframework.jms.core.JmsTemplate;
/*    */ import org.springframework.jms.support.converter.MessageConverter;
/*    */ import org.springframework.jms.support.destination.DestinationResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration
/*    */ @ConditionalOnClass({JmsTemplate.class})
/*    */ @ConditionalOnBean({ConnectionFactory.class})
/*    */ @EnableConfigurationProperties({JmsProperties.class})
/*    */ @Import({JmsAnnotationDrivenConfiguration.class})
/*    */ public class JmsAutoConfiguration
/*    */ {
/*    */   @Configuration
/*    */   protected static class JmsTemplateConfiguration
/*    */   {
/*    */     private final JmsProperties properties;
/*    */     private final ObjectProvider<DestinationResolver> destinationResolver;
/*    */     private final ObjectProvider<MessageConverter> messageConverter;
/*    */     
/*    */     public JmsTemplateConfiguration(JmsProperties properties, ObjectProvider<DestinationResolver> destinationResolver, ObjectProvider<MessageConverter> messageConverter)
/*    */     {
/* 61 */       this.properties = properties;
/* 62 */       this.destinationResolver = destinationResolver;
/* 63 */       this.messageConverter = messageConverter;
/*    */     }
/*    */     
/*    */     @Bean
/*    */     @ConditionalOnMissingBean
/*    */     @ConditionalOnSingleCandidate(ConnectionFactory.class)
/*    */     public JmsTemplate jmsTemplate(ConnectionFactory connectionFactory) {
/* 70 */       JmsTemplate jmsTemplate = new JmsTemplate(connectionFactory);
/* 71 */       jmsTemplate.setPubSubDomain(this.properties.isPubSubDomain());
/*    */       
/* 73 */       DestinationResolver destinationResolver = (DestinationResolver)this.destinationResolver.getIfUnique();
/* 74 */       if (destinationResolver != null) {
/* 75 */         jmsTemplate.setDestinationResolver(destinationResolver);
/*    */       }
/* 77 */       MessageConverter messageConverter = (MessageConverter)this.messageConverter.getIfUnique();
/* 78 */       if (messageConverter != null) {
/* 79 */         jmsTemplate.setMessageConverter(messageConverter);
/*    */       }
/* 81 */       return jmsTemplate;
/*    */     }
/*    */   }
/*    */   
/*    */   @ConditionalOnClass({JmsMessagingTemplate.class})
/*    */   @Import({JmsAutoConfiguration.JmsTemplateConfiguration.class})
/*    */   protected static class MessagingTemplateConfiguration
/*    */   {
/*    */     @Bean
/*    */     @ConditionalOnMissingBean
/*    */     @ConditionalOnSingleCandidate(JmsTemplate.class)
/*    */     public JmsMessagingTemplate jmsMessagingTemplate(JmsTemplate jmsTemplate)
/*    */     {
/* 94 */       return new JmsMessagingTemplate(jmsTemplate);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jms\JmsAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */