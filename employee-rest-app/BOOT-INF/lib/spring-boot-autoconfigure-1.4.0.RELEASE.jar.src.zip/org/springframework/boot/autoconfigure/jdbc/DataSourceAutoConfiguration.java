/*     */ package org.springframework.boot.autoconfigure.jdbc;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import javax.sql.DataSource;
/*     */ import javax.sql.XADataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.tomcat.jdbc.pool.ConnectionPool;
/*     */ import org.apache.tomcat.jdbc.pool.DataSourceProxy;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*     */ import org.springframework.boot.autoconfigure.jdbc.metadata.DataSourcePoolMetadataProvidersConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Condition;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @ConditionalOnClass({DataSource.class, EmbeddedDatabaseType.class})
/*     */ @EnableConfigurationProperties({DataSourceProperties.class})
/*     */ @Import({DataSourceInitializerPostProcessor.Registrar.class, DataSourcePoolMetadataProvidersConfiguration.class})
/*     */ public class DataSourceAutoConfiguration
/*     */ {
/*  66 */   private static final Log logger = LogFactory.getLog(DataSourceAutoConfiguration.class);
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public DataSourceInitializer dataSourceInitializer() {
/*  71 */     return new DataSourceInitializer();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean containsAutoConfiguredDataSource(ConfigurableListableBeanFactory beanFactory)
/*     */   {
/*     */     try
/*     */     {
/*  83 */       BeanDefinition beanDefinition = beanFactory.getBeanDefinition("dataSource");
/*     */       
/*  85 */       return EmbeddedDataSourceConfiguration.class.getName().equals(beanDefinition.getFactoryBeanName());
/*     */     }
/*     */     catch (NoSuchBeanDefinitionException ex) {}
/*  88 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Conditional({DataSourceAutoConfiguration.EmbeddedDatabaseCondition.class})
/*     */   @ConditionalOnMissingBean({DataSource.class, XADataSource.class})
/*     */   @Import({EmbeddedDataSourceConfiguration.class})
/*     */   protected static class EmbeddedDatabaseConfiguration {}
/*     */   
/*     */ 
/*     */   @Configuration
/*     */   @Conditional({DataSourceAutoConfiguration.PooledDataSourceCondition.class})
/*     */   @ConditionalOnMissingBean({DataSource.class, XADataSource.class})
/*     */   @Import({DataSourceConfiguration.Tomcat.class, DataSourceConfiguration.Hikari.class, DataSourceConfiguration.Dbcp.class, DataSourceConfiguration.Dbcp2.class})
/*     */   protected static class PooledDataSourceConfiguration {}
/*     */   
/*     */ 
/*     */   @Configuration
/*     */   @ConditionalOnProperty(prefix="spring.datasource", name={"jmx-enabled"})
/*     */   @ConditionalOnClass(name={"org.apache.tomcat.jdbc.pool.DataSourceProxy"})
/*     */   @Conditional({DataSourceAutoConfiguration.DataSourceAvailableCondition.class})
/*     */   @ConditionalOnMissingBean(name={"dataSourceMBean"})
/*     */   protected static class TomcatDataSourceJmxConfiguration
/*     */   {
/*     */     @Bean
/*     */     public Object dataSourceMBean(DataSource dataSource)
/*     */     {
/* 116 */       if ((dataSource instanceof DataSourceProxy)) {
/*     */         try {
/* 118 */           return ((DataSourceProxy)dataSource).createPool().getJmxPool();
/*     */         }
/*     */         catch (SQLException ex) {
/* 121 */           DataSourceAutoConfiguration.logger.warn("Cannot expose DataSource to JMX (could not connect)");
/*     */         }
/*     */       }
/* 124 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static class PooledDataSourceCondition
/*     */     extends SpringBootCondition
/*     */   {
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*     */     {
/* 137 */       if (getDataSourceClassLoader(context) != null) {
/* 138 */         return ConditionOutcome.match("supported DataSource class found");
/*     */       }
/* 140 */       return ConditionOutcome.noMatch("missing supported DataSource");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private ClassLoader getDataSourceClassLoader(ConditionContext context)
/*     */     {
/* 151 */       Class<?> dataSourceClass = new DataSourceBuilder(context.getClassLoader()).findType();
/* 152 */       return dataSourceClass == null ? null : dataSourceClass.getClassLoader();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static class EmbeddedDatabaseCondition
/*     */     extends SpringBootCondition
/*     */   {
/* 163 */     private final SpringBootCondition pooledCondition = new DataSourceAutoConfiguration.PooledDataSourceCondition();
/*     */     
/*     */ 
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*     */     {
/* 168 */       if (anyMatches(context, metadata, new Condition[] { this.pooledCondition })) {
/* 169 */         return ConditionOutcome.noMatch("supported DataSource class found");
/*     */       }
/*     */       
/* 172 */       EmbeddedDatabaseType type = EmbeddedDatabaseConnection.get(context.getClassLoader()).getType();
/* 173 */       if (type == null) {
/* 174 */         return ConditionOutcome.noMatch("no embedded database detected");
/*     */       }
/* 176 */       return ConditionOutcome.match("embedded database " + type + " detected");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Order(2147483637)
/*     */   static class DataSourceAvailableCondition
/*     */     extends SpringBootCondition
/*     */   {
/* 188 */     private final SpringBootCondition pooledCondition = new DataSourceAutoConfiguration.PooledDataSourceCondition();
/*     */     
/* 190 */     private final SpringBootCondition embeddedCondition = new DataSourceAutoConfiguration.EmbeddedDatabaseCondition();
/*     */     
/*     */ 
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*     */     {
/* 195 */       if ((hasBean(context, DataSource.class)) || 
/* 196 */         (hasBean(context, XADataSource.class)))
/*     */       {
/* 198 */         return ConditionOutcome.match("existing bean configured database detected");
/*     */       }
/* 200 */       if (anyMatches(context, metadata, new Condition[] { this.pooledCondition, this.embeddedCondition }))
/*     */       {
/* 202 */         return ConditionOutcome.match("existing auto database detected");
/*     */       }
/* 204 */       return ConditionOutcome.noMatch("no existing bean configured database");
/*     */     }
/*     */     
/*     */     private boolean hasBean(ConditionContext context, Class<?> type) {
/* 208 */       return BeanFactoryUtils.beanNamesForTypeIncludingAncestors(context
/* 209 */         .getBeanFactory(), type, true, false).length > 0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jdbc\DataSourceAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */