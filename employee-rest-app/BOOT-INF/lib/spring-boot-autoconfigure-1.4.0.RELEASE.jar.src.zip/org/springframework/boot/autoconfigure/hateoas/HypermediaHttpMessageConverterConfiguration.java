/*    */ package org.springframework.boot.autoconfigure.hateoas;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import javax.annotation.PostConstruct;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.hateoas.MediaTypes;
/*    */ import org.springframework.hateoas.mvc.TypeConstrainedMappingJackson2HttpMessageConverter;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.http.converter.HttpMessageConverter;
/*    */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HypermediaHttpMessageConverterConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnProperty(prefix="spring.hateoas", name={"use-hal-as-default-json-media-type"}, matchIfMissing=true)
/*    */   public static HalMessageConverterSupportedMediaTypesCustomizer halMessageConverterSupportedMediaTypeCustomizer()
/*    */   {
/* 49 */     return new HalMessageConverterSupportedMediaTypesCustomizer(null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private static class HalMessageConverterSupportedMediaTypesCustomizer
/*    */     implements BeanFactoryAware
/*    */   {
/*    */     private volatile BeanFactory beanFactory;
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */     @PostConstruct
/*    */     public void customizedSupportedMediaTypes()
/*    */     {
/* 66 */       if ((this.beanFactory instanceof ListableBeanFactory))
/*    */       {
/* 68 */         Map<String, RequestMappingHandlerAdapter> handlerAdapters = ((ListableBeanFactory)this.beanFactory).getBeansOfType(RequestMappingHandlerAdapter.class);
/* 69 */         for (Map.Entry<String, RequestMappingHandlerAdapter> entry : handlerAdapters
/* 70 */           .entrySet()) {
/* 71 */           RequestMappingHandlerAdapter handlerAdapter = (RequestMappingHandlerAdapter)entry.getValue();
/* 72 */           for (HttpMessageConverter<?> converter : handlerAdapter
/* 73 */             .getMessageConverters()) {
/* 74 */             if ((converter instanceof TypeConstrainedMappingJackson2HttpMessageConverter))
/*    */             {
/* 76 */               ((TypeConstrainedMappingJackson2HttpMessageConverter)converter).setSupportedMediaTypes(
/* 77 */                 Arrays.asList(new MediaType[] { MediaTypes.HAL_JSON, MediaType.APPLICATION_JSON }));
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */     
/*    */ 
/*    */     public void setBeanFactory(BeanFactory beanFactory)
/*    */       throws BeansException
/*    */     {
/* 88 */       this.beanFactory = beanFactory;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\hateoas\HypermediaHttpMessageConverterConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */