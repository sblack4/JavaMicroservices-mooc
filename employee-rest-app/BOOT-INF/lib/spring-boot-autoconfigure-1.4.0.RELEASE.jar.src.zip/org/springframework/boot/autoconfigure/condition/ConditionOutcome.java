/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConditionOutcome
/*     */ {
/*     */   private final boolean match;
/*     */   private final String message;
/*     */   
/*     */   public ConditionOutcome(boolean match, String message)
/*     */   {
/*  33 */     this.match = match;
/*  34 */     this.message = message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ConditionOutcome match()
/*     */   {
/*  42 */     return match(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ConditionOutcome match(String message)
/*     */   {
/*  51 */     return new ConditionOutcome(true, message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ConditionOutcome noMatch(String message)
/*     */   {
/*  60 */     return new ConditionOutcome(false, message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMatch()
/*     */   {
/*  68 */     return this.match;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage()
/*     */   {
/*  76 */     return this.message;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  82 */     return ObjectUtils.hashCode(this.match) * 31 + ObjectUtils.nullSafeHashCode(this.message);
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  87 */     if (this == obj) {
/*  88 */       return true;
/*     */     }
/*  90 */     if (obj == null) {
/*  91 */       return false;
/*     */     }
/*  93 */     if (getClass() == obj.getClass()) {
/*  94 */       ConditionOutcome other = (ConditionOutcome)obj;
/*     */       
/*  96 */       return (this.match == other.match) && (ObjectUtils.nullSafeEquals(this.message, other.message));
/*     */     }
/*  98 */     return super.equals(obj);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 103 */     return this.message == null ? "" : this.message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ConditionOutcome inverse(ConditionOutcome outcome)
/*     */   {
/* 113 */     return new ConditionOutcome(!outcome.isMatch(), outcome.getMessage());
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\condition\ConditionOutcome.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */