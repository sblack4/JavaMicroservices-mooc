/*     */ package org.springframework.boot.autoconfigure.security;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.autoconfigure.web.ErrorController;
/*     */ import org.springframework.boot.autoconfigure.web.ServerProperties;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.security.config.annotation.web.WebSecurityConfigurer;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity.RequestMatcherConfigurer;
/*     */ import org.springframework.security.config.annotation.web.builders.WebSecurity;
/*     */ import org.springframework.security.config.annotation.web.builders.WebSecurity.IgnoredRequestConfigurer;
/*     */ import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
/*     */ import org.springframework.security.config.annotation.web.configuration.WebSecurityConfiguration;
/*     */ import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
/*     */ import org.springframework.security.config.annotation.web.configurers.ChannelSecurityConfigurer.ChannelRequestMatcherRegistry;
/*     */ import org.springframework.security.config.annotation.web.configurers.ChannelSecurityConfigurer.RequiresChannelUrl;
/*     */ import org.springframework.security.config.annotation.web.configurers.CsrfConfigurer;
/*     */ import org.springframework.security.config.annotation.web.configurers.ExceptionHandlingConfigurer;
/*     */ import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer.AuthorizedUrl;
/*     */ import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer.ExpressionInterceptUrlRegistry;
/*     */ import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
/*     */ import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer.CacheControlConfig;
/*     */ import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer.ContentTypeOptionsConfig;
/*     */ import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer.FrameOptionsConfig;
/*     */ import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer.XXssConfig;
/*     */ import org.springframework.security.config.annotation.web.configurers.HttpBasicConfigurer;
/*     */ import org.springframework.security.config.annotation.web.configurers.SessionManagementConfigurer;
/*     */ import org.springframework.security.web.AuthenticationEntryPoint;
/*     */ import org.springframework.security.web.authentication.www.BasicAuthenticationEntryPoint;
/*     */ import org.springframework.security.web.header.writers.HstsHeaderWriter;
/*     */ import org.springframework.security.web.util.matcher.AnyRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @EnableConfigurationProperties
/*     */ @ConditionalOnClass({EnableWebSecurity.class, AuthenticationEntryPoint.class})
/*     */ @ConditionalOnMissingBean({WebSecurityConfiguration.class})
/*     */ @ConditionalOnWebApplication
/*     */ @EnableWebSecurity
/*     */ public class SpringBootWebSecurityConfiguration
/*     */ {
/*  90 */   private static List<String> DEFAULT_IGNORED = Arrays.asList(new String[] { "/css/**", "/js/**", "/images/**", "/webjars/**", "/**/favicon.ico" });
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({IgnoredPathsWebSecurityConfigurerAdapter.class})
/*     */   public IgnoredPathsWebSecurityConfigurerAdapter ignoredPathsWebSecurityConfigurerAdapter()
/*     */   {
/*  96 */     return new IgnoredPathsWebSecurityConfigurerAdapter(null);
/*     */   }
/*     */   
/*     */   public static void configureHeaders(HeadersConfigurer<?> configurer, SecurityProperties.Headers headers) throws Exception
/*     */   {
/* 101 */     if (headers.getHsts() != SecurityProperties.Headers.HSTS.NONE) {
/* 102 */       boolean includeSubdomains = headers.getHsts() == SecurityProperties.Headers.HSTS.ALL;
/* 103 */       HstsHeaderWriter writer = new HstsHeaderWriter(includeSubdomains);
/* 104 */       writer.setRequestMatcher(AnyRequestMatcher.INSTANCE);
/* 105 */       configurer.addHeaderWriter(writer);
/*     */     }
/* 107 */     if (!headers.isContentType()) {
/* 108 */       configurer.contentTypeOptions().disable();
/*     */     }
/* 110 */     if (!headers.isXss()) {
/* 111 */       configurer.xssProtection().disable();
/*     */     }
/* 113 */     if (!headers.isCache()) {
/* 114 */       configurer.cacheControl().disable();
/*     */     }
/* 116 */     if (!headers.isFrame()) {
/* 117 */       configurer.frameOptions().disable();
/*     */     }
/*     */   }
/*     */   
/*     */   public static List<String> getIgnored(SecurityProperties security) {
/* 122 */     List<String> ignored = new ArrayList(security.getIgnored());
/* 123 */     if (ignored.isEmpty()) {
/* 124 */       ignored.addAll(DEFAULT_IGNORED);
/*     */     }
/* 126 */     else if (ignored.contains("none")) {
/* 127 */       ignored.remove("none");
/*     */     }
/* 129 */     return ignored;
/*     */   }
/*     */   
/*     */ 
/*     */   @Order(Integer.MIN_VALUE)
/*     */   private static class IgnoredPathsWebSecurityConfigurerAdapter
/*     */     implements WebSecurityConfigurer<WebSecurity>
/*     */   {
/*     */     @Autowired(required=false)
/*     */     private ErrorController errorController;
/*     */     
/*     */     @Autowired
/*     */     private SecurityProperties security;
/*     */     @Autowired
/*     */     private ServerProperties server;
/*     */     
/*     */     public void configure(WebSecurity builder)
/*     */       throws Exception
/*     */     {}
/*     */     
/*     */     public void init(WebSecurity builder)
/*     */       throws Exception
/*     */     {
/* 152 */       List<String> ignored = SpringBootWebSecurityConfiguration.getIgnored(this.security);
/* 153 */       if (this.errorController != null) {
/* 154 */         ignored.add(normalizePath(this.errorController.getErrorPath()));
/*     */       }
/* 156 */       String[] paths = this.server.getPathsArray(ignored);
/* 157 */       if (!ObjectUtils.isEmpty(paths)) {
/* 158 */         builder.ignoring().antMatchers(paths);
/*     */       }
/*     */     }
/*     */     
/*     */     private String normalizePath(String errorPath) {
/* 163 */       String result = StringUtils.cleanPath(errorPath);
/* 164 */       if (!result.startsWith("/")) {
/* 165 */         result = "/" + result;
/*     */       }
/* 167 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */   @Configuration
/*     */   @ConditionalOnProperty(prefix="security.basic", name={"enabled"}, havingValue="false")
/*     */   @Order(2147483642)
/*     */   protected static class ApplicationNoWebSecurityConfigurerAdapter
/*     */     extends WebSecurityConfigurerAdapter
/*     */   {
/*     */     protected void configure(HttpSecurity http) throws Exception
/*     */     {
/* 179 */       http.requestMatcher(new RequestMatcher()
/*     */       {
/*     */         public boolean matches(HttpServletRequest request) {
/* 182 */           return false;
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */   
/*     */   @Configuration
/*     */   @ConditionalOnProperty(prefix="security.basic", name={"enabled"}, matchIfMissing=true)
/*     */   @Order(2147483642)
/*     */   protected static class ApplicationWebSecurityConfigurerAdapter extends WebSecurityConfigurerAdapter
/*     */   {
/*     */     private SecurityProperties security;
/*     */     
/*     */     protected ApplicationWebSecurityConfigurerAdapter(SecurityProperties security)
/*     */     {
/* 197 */       this.security = security;
/*     */     }
/*     */     
/*     */     protected void configure(HttpSecurity http) throws Exception
/*     */     {
/* 202 */       if (this.security.isRequireSsl()) {
/* 203 */         ((ChannelSecurityConfigurer.RequiresChannelUrl)http.requiresChannel().anyRequest()).requiresSecure();
/*     */       }
/* 205 */       if (!this.security.isEnableCsrf()) {
/* 206 */         http.csrf().disable();
/*     */       }
/*     */       
/* 209 */       http.sessionManagement().sessionCreationPolicy(this.security.getSessions());
/* 210 */       SpringBootWebSecurityConfiguration.configureHeaders(http.headers(), this.security
/* 211 */         .getHeaders());
/* 212 */       String[] paths = getSecureApplicationPaths();
/* 213 */       if (paths.length > 0) {
/* 214 */         AuthenticationEntryPoint entryPoint = entryPoint();
/* 215 */         http.exceptionHandling().authenticationEntryPoint(entryPoint);
/* 216 */         http.httpBasic().authenticationEntryPoint(entryPoint);
/* 217 */         http.requestMatchers().antMatchers(paths);
/* 218 */         String[] roles = (String[])this.security.getUser().getRole().toArray(new String[0]);
/* 219 */         SecurityAuthorizeMode mode = this.security.getBasic().getAuthorizeMode();
/* 220 */         if ((mode == null) || (mode == SecurityAuthorizeMode.ROLE)) {
/* 221 */           ((ExpressionUrlAuthorizationConfigurer.AuthorizedUrl)http.authorizeRequests().anyRequest()).hasAnyRole(roles);
/*     */         }
/* 223 */         else if (mode == SecurityAuthorizeMode.AUTHENTICATED) {
/* 224 */           ((ExpressionUrlAuthorizationConfigurer.AuthorizedUrl)http.authorizeRequests().anyRequest()).authenticated();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private String[] getSecureApplicationPaths() {
/* 230 */       List<String> list = new ArrayList();
/* 231 */       for (String path : this.security.getBasic().getPath()) {
/* 232 */         path = path == null ? "" : path.trim();
/* 233 */         if (path.equals("/**")) {
/* 234 */           return new String[] { path };
/*     */         }
/* 236 */         if (!path.equals("")) {
/* 237 */           list.add(path);
/*     */         }
/*     */       }
/* 240 */       return (String[])list.toArray(new String[list.size()]);
/*     */     }
/*     */     
/*     */     private AuthenticationEntryPoint entryPoint() {
/* 244 */       BasicAuthenticationEntryPoint entryPoint = new BasicAuthenticationEntryPoint();
/* 245 */       entryPoint.setRealmName(this.security.getBasic().getRealm());
/* 246 */       return entryPoint;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\security\SpringBootWebSecurityConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */