/*    */ package org.springframework.boot.autoconfigure.thymeleaf;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ import javax.annotation.PostConstruct;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.boot.autoconfigure.template.TemplateLocation;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.thymeleaf.spring4.templateresolver.SpringResourceTemplateResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractTemplateResolverConfiguration
/*    */ {
/* 38 */   private static final Log logger = LogFactory.getLog(AbstractTemplateResolverConfiguration.class);
/*    */   
/*    */   private final ThymeleafProperties properties;
/*    */   
/*    */   private final ApplicationContext applicationContext;
/*    */   
/*    */   AbstractTemplateResolverConfiguration(ThymeleafProperties properties, ApplicationContext applicationContext)
/*    */   {
/* 46 */     this.properties = properties;
/* 47 */     this.applicationContext = applicationContext;
/*    */   }
/*    */   
/*    */   @PostConstruct
/*    */   public void checkTemplateLocationExists() {
/* 52 */     boolean checkTemplateLocation = this.properties.isCheckTemplateLocation();
/* 53 */     if (checkTemplateLocation) {
/* 54 */       TemplateLocation location = new TemplateLocation(this.properties.getPrefix());
/* 55 */       if (!location.exists(this.applicationContext)) {
/* 56 */         logger.warn("Cannot find template location: " + location + " (please add some templates or check " + "your Thymeleaf configuration)");
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   @Bean
/*    */   public SpringResourceTemplateResolver defaultTemplateResolver()
/*    */   {
/* 65 */     SpringResourceTemplateResolver resolver = new SpringResourceTemplateResolver();
/* 66 */     resolver.setApplicationContext(this.applicationContext);
/* 67 */     resolver.setPrefix(this.properties.getPrefix());
/* 68 */     resolver.setSuffix(this.properties.getSuffix());
/* 69 */     resolver.setTemplateMode(this.properties.getMode());
/* 70 */     if (this.properties.getEncoding() != null) {
/* 71 */       resolver.setCharacterEncoding(this.properties.getEncoding().name());
/*    */     }
/* 73 */     resolver.setCacheable(this.properties.isCache());
/* 74 */     Integer order = this.properties.getTemplateResolverOrder();
/* 75 */     if (order != null) {
/* 76 */       resolver.setOrder(order);
/*    */     }
/* 78 */     return resolver;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\thymeleaf\AbstractTemplateResolverConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */