/*    */ package org.springframework.boot.autoconfigure.web;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*    */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*    */ import org.springframework.boot.bind.PropertySourcesPropertyValues;
/*    */ import org.springframework.boot.bind.RelaxedDataBinder;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OnEnabledResourceChainCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   private static final String WEBJAR_ASSERT_LOCATOR = "org.webjars.WebJarAssetLocator";
/*    */   
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 43 */     ConfigurableEnvironment environment = (ConfigurableEnvironment)context.getEnvironment();
/* 44 */     ResourceProperties properties = new ResourceProperties();
/* 45 */     RelaxedDataBinder binder = new RelaxedDataBinder(properties, "spring.resources");
/* 46 */     binder.bind(new PropertySourcesPropertyValues(environment.getPropertySources()));
/* 47 */     Boolean match = properties.getChain().getEnabled();
/* 48 */     if (match == null) {
/* 49 */       boolean webJarsLocatorPresent = ClassUtils.isPresent("org.webjars.WebJarAssetLocator", 
/* 50 */         getClass().getClassLoader());
/* 51 */       return new ConditionOutcome(webJarsLocatorPresent, "Webjars locator (org.webjars.WebJarAssetLocator) is " + (webJarsLocatorPresent ? "present" : "absent"));
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 56 */     return new ConditionOutcome(match.booleanValue(), "Resource chain is " + (match.booleanValue() ? "enabled" : "disabled"));
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\web\OnEnabledResourceChainCondition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */