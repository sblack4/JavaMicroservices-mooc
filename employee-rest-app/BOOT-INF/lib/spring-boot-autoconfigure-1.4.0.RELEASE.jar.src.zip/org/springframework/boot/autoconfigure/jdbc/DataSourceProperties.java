/*     */ package org.springframework.boot.autoconfigure.jdbc;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.jdbc.DatabaseDriver;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.datasource")
/*     */ public class DataSourceProperties
/*     */   implements BeanClassLoaderAware, EnvironmentAware, InitializingBean
/*     */ {
/*     */   private ClassLoader classLoader;
/*     */   private Environment environment;
/*  58 */   private String name = "testdb";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Class<? extends DataSource> type;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String driverClassName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String url;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String username;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String password;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String jndiName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  95 */   private boolean initialize = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 100 */   private String platform = "all";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String schema;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String schemaUsername;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String schemaPassword;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String dataUsername;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String dataPassword;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 135 */   private boolean continueOnError = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 140 */   private String separator = ";";
/*     */   
/*     */ 
/*     */ 
/*     */   private Charset sqlScriptEncoding;
/*     */   
/*     */ 
/* 147 */   private EmbeddedDatabaseConnection embeddedDatabaseConnection = EmbeddedDatabaseConnection.NONE;
/*     */   
/* 149 */   private Xa xa = new Xa();
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/* 153 */     this.classLoader = classLoader;
/*     */   }
/*     */   
/*     */   public void setEnvironment(Environment environment)
/*     */   {
/* 158 */     this.environment = environment;
/*     */   }
/*     */   
/*     */   public void afterPropertiesSet()
/*     */     throws Exception
/*     */   {
/* 164 */     this.embeddedDatabaseConnection = EmbeddedDatabaseConnection.get(this.classLoader);
/*     */   }
/*     */   
/*     */   public String getName() {
/* 168 */     return this.name;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/* 172 */     this.name = name;
/*     */   }
/*     */   
/*     */   public Class<? extends DataSource> getType() {
/* 176 */     return this.type;
/*     */   }
/*     */   
/*     */   public void setType(Class<? extends DataSource> type) {
/* 180 */     this.type = type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDriverClassName()
/*     */   {
/* 189 */     return this.driverClassName;
/*     */   }
/*     */   
/*     */   public void setDriverClassName(String driverClassName) {
/* 193 */     this.driverClassName = driverClassName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String determineDriverClassName()
/*     */   {
/* 202 */     if (StringUtils.hasText(this.driverClassName)) {
/* 203 */       Assert.state(driverClassIsLoadable(), "Cannot load driver class: " + this.driverClassName);
/*     */       
/* 205 */       return this.driverClassName;
/*     */     }
/* 207 */     String driverClassName = null;
/*     */     
/* 209 */     if (StringUtils.hasText(this.url)) {
/* 210 */       driverClassName = DatabaseDriver.fromJdbcUrl(this.url).getDriverClassName();
/*     */     }
/*     */     
/* 213 */     if (!StringUtils.hasText(driverClassName)) {
/* 214 */       driverClassName = this.embeddedDatabaseConnection.getDriverClassName();
/*     */     }
/*     */     
/* 217 */     if (!StringUtils.hasText(driverClassName)) {
/* 218 */       throw new DataSourceBeanCreationException(this.embeddedDatabaseConnection, this.environment, "driver class");
/*     */     }
/*     */     
/* 221 */     return driverClassName;
/*     */   }
/*     */   
/*     */   private boolean driverClassIsLoadable() {
/*     */     try {
/* 226 */       ClassUtils.forName(this.driverClassName, null);
/* 227 */       return true;
/*     */     }
/*     */     catch (UnsupportedClassVersionError ex)
/*     */     {
/* 231 */       throw ex;
/*     */     }
/*     */     catch (Throwable ex) {}
/* 234 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUrl()
/*     */   {
/* 244 */     return this.url;
/*     */   }
/*     */   
/*     */   public void setUrl(String url) {
/* 248 */     this.url = url;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String determineUrl()
/*     */   {
/* 257 */     if (StringUtils.hasText(this.url)) {
/* 258 */       return this.url;
/*     */     }
/* 260 */     String url = this.embeddedDatabaseConnection.getUrl(this.name);
/* 261 */     if (!StringUtils.hasText(url)) {
/* 262 */       throw new DataSourceBeanCreationException(this.embeddedDatabaseConnection, this.environment, "url");
/*     */     }
/*     */     
/* 265 */     return url;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUsername()
/*     */   {
/* 274 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/* 278 */     this.username = username;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String determineUsername()
/*     */   {
/* 287 */     if (StringUtils.hasText(this.username)) {
/* 288 */       return this.username;
/*     */     }
/* 290 */     if (EmbeddedDatabaseConnection.isEmbedded(determineDriverClassName())) {
/* 291 */       return "sa";
/*     */     }
/* 293 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPassword()
/*     */   {
/* 302 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 306 */     this.password = password;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String determinePassword()
/*     */   {
/* 315 */     if (StringUtils.hasText(this.password)) {
/* 316 */       return this.password;
/*     */     }
/* 318 */     if (EmbeddedDatabaseConnection.isEmbedded(determineDriverClassName())) {
/* 319 */       return "";
/*     */     }
/* 321 */     return null;
/*     */   }
/*     */   
/*     */   public String getJndiName() {
/* 325 */     return this.jndiName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setJndiName(String jndiName)
/*     */   {
/* 335 */     this.jndiName = jndiName;
/*     */   }
/*     */   
/*     */   public boolean isInitialize() {
/* 339 */     return this.initialize;
/*     */   }
/*     */   
/*     */   public void setInitialize(boolean initialize) {
/* 343 */     this.initialize = initialize;
/*     */   }
/*     */   
/*     */   public String getPlatform() {
/* 347 */     return this.platform;
/*     */   }
/*     */   
/*     */   public void setPlatform(String platform) {
/* 351 */     this.platform = platform;
/*     */   }
/*     */   
/*     */   public String getSchema() {
/* 355 */     return this.schema;
/*     */   }
/*     */   
/*     */   public void setSchema(String schema) {
/* 359 */     this.schema = schema;
/*     */   }
/*     */   
/*     */   public String getSchemaUsername() {
/* 363 */     return this.schemaUsername;
/*     */   }
/*     */   
/*     */   public void setSchemaUsername(String schemaUsername) {
/* 367 */     this.schemaUsername = schemaUsername;
/*     */   }
/*     */   
/*     */   public String getSchemaPassword() {
/* 371 */     return this.schemaPassword;
/*     */   }
/*     */   
/*     */   public void setSchemaPassword(String schemaPassword) {
/* 375 */     this.schemaPassword = schemaPassword;
/*     */   }
/*     */   
/*     */   public String getData() {
/* 379 */     return this.data;
/*     */   }
/*     */   
/*     */   public void setData(String script) {
/* 383 */     this.data = script;
/*     */   }
/*     */   
/*     */   public String getDataUsername() {
/* 387 */     return this.dataUsername;
/*     */   }
/*     */   
/*     */   public void setDataUsername(String dataUsername) {
/* 391 */     this.dataUsername = dataUsername;
/*     */   }
/*     */   
/*     */   public String getDataPassword() {
/* 395 */     return this.dataPassword;
/*     */   }
/*     */   
/*     */   public void setDataPassword(String dataPassword) {
/* 399 */     this.dataPassword = dataPassword;
/*     */   }
/*     */   
/*     */   public boolean isContinueOnError() {
/* 403 */     return this.continueOnError;
/*     */   }
/*     */   
/*     */   public void setContinueOnError(boolean continueOnError) {
/* 407 */     this.continueOnError = continueOnError;
/*     */   }
/*     */   
/*     */   public String getSeparator() {
/* 411 */     return this.separator;
/*     */   }
/*     */   
/*     */   public void setSeparator(String separator) {
/* 415 */     this.separator = separator;
/*     */   }
/*     */   
/*     */   public Charset getSqlScriptEncoding() {
/* 419 */     return this.sqlScriptEncoding;
/*     */   }
/*     */   
/*     */   public void setSqlScriptEncoding(Charset sqlScriptEncoding) {
/* 423 */     this.sqlScriptEncoding = sqlScriptEncoding;
/*     */   }
/*     */   
/*     */   public ClassLoader getClassLoader() {
/* 427 */     return this.classLoader;
/*     */   }
/*     */   
/*     */   public Xa getXa() {
/* 431 */     return this.xa;
/*     */   }
/*     */   
/*     */   public void setXa(Xa xa) {
/* 435 */     this.xa = xa;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Xa
/*     */   {
/*     */     private String dataSourceClassName;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 451 */     private Map<String, String> properties = new LinkedHashMap();
/*     */     
/*     */     public String getDataSourceClassName() {
/* 454 */       return this.dataSourceClassName;
/*     */     }
/*     */     
/*     */     public void setDataSourceClassName(String dataSourceClassName) {
/* 458 */       this.dataSourceClassName = dataSourceClassName;
/*     */     }
/*     */     
/*     */     public Map<String, String> getProperties() {
/* 462 */       return this.properties;
/*     */     }
/*     */     
/*     */     public void setProperties(Map<String, String> properties) {
/* 466 */       this.properties = properties;
/*     */     }
/*     */   }
/*     */   
/*     */   static class DataSourceBeanCreationException
/*     */     extends BeanCreationException
/*     */   {
/*     */     DataSourceBeanCreationException(EmbeddedDatabaseConnection connection, Environment environment, String property)
/*     */     {
/* 475 */       super();
/*     */     }
/*     */     
/*     */     private static String getMessage(EmbeddedDatabaseConnection connection, Environment environment, String property)
/*     */     {
/* 480 */       StringBuilder message = new StringBuilder();
/* 481 */       message.append("Cannot determine embedded database " + property + " for database type " + connection + ". ");
/*     */       
/* 483 */       message.append("If you want an embedded database please put a supported one on the classpath. ");
/*     */       
/* 485 */       message.append("If you have database settings to be loaded from a particular profile you may need to active it");
/*     */       
/* 487 */       if (environment != null) {
/* 488 */         String[] profiles = environment.getActiveProfiles();
/* 489 */         if (ObjectUtils.isEmpty(profiles)) {
/* 490 */           message.append(" (no profiles are currently active)");
/*     */         }
/*     */         else {
/* 493 */           message.append(" (the profiles \"" + 
/* 494 */             StringUtils.arrayToCommaDelimitedString(environment
/* 495 */             .getActiveProfiles()) + "\" are currently active)");
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 500 */       message.append(".");
/* 501 */       return message.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jdbc\DataSourceProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */