/*     */ package org.springframework.boot.autoconfigure.data.redis;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.redis")
/*     */ public class RedisProperties
/*     */ {
/*  36 */   private int database = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  41 */   private String host = "localhost";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String password;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  51 */   private int port = 6379;
/*     */   
/*     */ 
/*     */   private int timeout;
/*     */   
/*     */   private Pool pool;
/*     */   
/*     */   private Sentinel sentinel;
/*     */   
/*     */   private Cluster cluster;
/*     */   
/*     */ 
/*     */   public int getDatabase()
/*     */   {
/*  65 */     return this.database;
/*     */   }
/*     */   
/*     */   public void setDatabase(int database) {
/*  69 */     this.database = database;
/*     */   }
/*     */   
/*     */   public String getHost() {
/*  73 */     return this.host;
/*     */   }
/*     */   
/*     */   public void setHost(String host) {
/*  77 */     this.host = host;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/*  81 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/*  85 */     this.password = password;
/*     */   }
/*     */   
/*     */   public int getPort() {
/*  89 */     return this.port;
/*     */   }
/*     */   
/*     */   public void setPort(int port) {
/*  93 */     this.port = port;
/*     */   }
/*     */   
/*     */   public void setTimeout(int timeout) {
/*  97 */     this.timeout = timeout;
/*     */   }
/*     */   
/*     */   public int getTimeout() {
/* 101 */     return this.timeout;
/*     */   }
/*     */   
/*     */   public Sentinel getSentinel() {
/* 105 */     return this.sentinel;
/*     */   }
/*     */   
/*     */   public void setSentinel(Sentinel sentinel) {
/* 109 */     this.sentinel = sentinel;
/*     */   }
/*     */   
/*     */   public Pool getPool() {
/* 113 */     return this.pool;
/*     */   }
/*     */   
/*     */   public void setPool(Pool pool) {
/* 117 */     this.pool = pool;
/*     */   }
/*     */   
/*     */   public Cluster getCluster() {
/* 121 */     return this.cluster;
/*     */   }
/*     */   
/*     */   public void setCluster(Cluster cluster) {
/* 125 */     this.cluster = cluster;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Pool
/*     */   {
/* 137 */     private int maxIdle = 8;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 143 */     private int minIdle = 0;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 149 */     private int maxActive = 8;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 156 */     private int maxWait = -1;
/*     */     
/*     */     public int getMaxIdle() {
/* 159 */       return this.maxIdle;
/*     */     }
/*     */     
/*     */     public void setMaxIdle(int maxIdle) {
/* 163 */       this.maxIdle = maxIdle;
/*     */     }
/*     */     
/*     */     public int getMinIdle() {
/* 167 */       return this.minIdle;
/*     */     }
/*     */     
/*     */     public void setMinIdle(int minIdle) {
/* 171 */       this.minIdle = minIdle;
/*     */     }
/*     */     
/*     */     public int getMaxActive() {
/* 175 */       return this.maxActive;
/*     */     }
/*     */     
/*     */     public void setMaxActive(int maxActive) {
/* 179 */       this.maxActive = maxActive;
/*     */     }
/*     */     
/*     */     public int getMaxWait() {
/* 183 */       return this.maxWait;
/*     */     }
/*     */     
/*     */     public void setMaxWait(int maxWait) {
/* 187 */       this.maxWait = maxWait;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Cluster
/*     */   {
/*     */     private List<String> nodes;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private Integer maxRedirects;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public List<String> getNodes()
/*     */     {
/* 210 */       return this.nodes;
/*     */     }
/*     */     
/*     */     public void setNodes(List<String> nodes) {
/* 214 */       this.nodes = nodes;
/*     */     }
/*     */     
/*     */     public Integer getMaxRedirects() {
/* 218 */       return this.maxRedirects;
/*     */     }
/*     */     
/*     */     public void setMaxRedirects(Integer maxRedirects) {
/* 222 */       this.maxRedirects = maxRedirects;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Sentinel
/*     */   {
/*     */     private String master;
/*     */     
/*     */ 
/*     */ 
/*     */     private String nodes;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getMaster()
/*     */     {
/* 243 */       return this.master;
/*     */     }
/*     */     
/*     */     public void setMaster(String master) {
/* 247 */       this.master = master;
/*     */     }
/*     */     
/*     */     public String getNodes() {
/* 251 */       return this.nodes;
/*     */     }
/*     */     
/*     */     public void setNodes(String nodes) {
/* 255 */       this.nodes = nodes;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\data\redis\RedisProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */