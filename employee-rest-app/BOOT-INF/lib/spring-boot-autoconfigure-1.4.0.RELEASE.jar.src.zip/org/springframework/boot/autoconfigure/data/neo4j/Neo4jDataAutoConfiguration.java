/*    */ package org.springframework.boot.autoconfigure.data.neo4j;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.neo4j.ogm.session.Neo4jSession;
/*    */ import org.neo4j.ogm.session.Session;
/*    */ import org.neo4j.ogm.session.SessionFactory;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigurationPackages;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.domain.EntityScanPackages;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Scope;
/*    */ import org.springframework.context.annotation.ScopedProxyMode;
/*    */ import org.springframework.data.neo4j.config.Neo4jConfiguration;
/*    */ import org.springframework.data.neo4j.template.Neo4jOperations;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @org.springframework.context.annotation.Configuration
/*    */ @ConditionalOnClass({Neo4jSession.class, Neo4jOperations.class})
/*    */ @ConditionalOnMissingBean({Neo4jOperations.class})
/*    */ @EnableConfigurationProperties({Neo4jProperties.class})
/*    */ public class Neo4jDataAutoConfiguration
/*    */ {
/*    */   private final Neo4jProperties properties;
/*    */   
/*    */   public Neo4jDataAutoConfiguration(Neo4jProperties properties)
/*    */   {
/* 57 */     this.properties = properties;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public org.neo4j.ogm.config.Configuration configuration() {
/* 63 */     return this.properties.createConfiguration();
/*    */   }
/*    */   
/*    */   @org.springframework.context.annotation.Configuration
/*    */   static class SpringBootNeo4jConfiguration
/*    */     extends Neo4jConfiguration
/*    */   {
/*    */     private final ApplicationContext applicationContext;
/*    */     private final org.neo4j.ogm.config.Configuration configuration;
/*    */     
/*    */     SpringBootNeo4jConfiguration(ApplicationContext applicationContext, org.neo4j.ogm.config.Configuration configuration)
/*    */     {
/* 75 */       this.applicationContext = applicationContext;
/* 76 */       this.configuration = configuration;
/*    */     }
/*    */     
/*    */     public SessionFactory getSessionFactory()
/*    */     {
/* 81 */       return new SessionFactory(this.configuration, getPackagesToScan());
/*    */     }
/*    */     
/*    */     private String[] getPackagesToScan()
/*    */     {
/* 86 */       List<String> packages = EntityScanPackages.get(this.applicationContext).getPackageNames();
/* 87 */       if ((packages.isEmpty()) && 
/* 88 */         (AutoConfigurationPackages.has(this.applicationContext))) {
/* 89 */         packages = AutoConfigurationPackages.get(this.applicationContext);
/*    */       }
/* 91 */       return (String[])packages.toArray(new String[packages.size()]);
/*    */     }
/*    */     
/*    */     @Bean
/*    */     @Scope(scopeName="${spring.data.neo4j.session.scope:singleton}", proxyMode=ScopedProxyMode.TARGET_CLASS)
/*    */     public Session getSession() throws Exception
/*    */     {
/* 98 */       return super.getSession();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\data\neo4j\Neo4jDataAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */