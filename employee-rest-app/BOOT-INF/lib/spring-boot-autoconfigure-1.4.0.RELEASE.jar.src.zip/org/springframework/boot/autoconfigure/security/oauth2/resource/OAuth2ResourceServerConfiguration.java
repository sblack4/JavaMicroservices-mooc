/*     */ package org.springframework.boot.autoconfigure.security.oauth2.resource;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*     */ import org.springframework.boot.autoconfigure.security.SecurityProperties;
/*     */ import org.springframework.boot.bind.RelaxedPropertyResolver;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Condition;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.ConfigurationCondition;
/*     */ import org.springframework.context.annotation.ConfigurationCondition.ConfigurationPhase;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.core.type.StandardAnnotationMetadata;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer.AuthorizedUrl;
/*     */ import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer.ExpressionInterceptUrlRegistry;
/*     */ import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerEndpointsConfiguration;
/*     */ import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
/*     */ import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfiguration;
/*     */ import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurer;
/*     */ import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
/*     */ import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @Conditional({ResourceServerCondition.class})
/*     */ @ConditionalOnClass({EnableResourceServer.class, SecurityProperties.class})
/*     */ @ConditionalOnWebApplication
/*     */ @ConditionalOnBean({ResourceServerConfiguration.class})
/*     */ @Import({ResourceServerTokenServicesConfiguration.class})
/*     */ public class OAuth2ResourceServerConfiguration
/*     */ {
/*     */   private final ResourceServerProperties resource;
/*     */   
/*     */   public OAuth2ResourceServerConfiguration(ResourceServerProperties resource)
/*     */   {
/*  69 */     this.resource = resource;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({ResourceServerConfigurer.class})
/*     */   public ResourceServerConfigurer resourceServer() {
/*  75 */     return new ResourceSecurityConfigurer(this.resource);
/*     */   }
/*     */   
/*     */   protected static class ResourceSecurityConfigurer extends ResourceServerConfigurerAdapter
/*     */   {
/*     */     private ResourceServerProperties resource;
/*     */     
/*     */     public ResourceSecurityConfigurer(ResourceServerProperties resource)
/*     */     {
/*  84 */       this.resource = resource;
/*     */     }
/*     */     
/*     */     public void configure(ResourceServerSecurityConfigurer resources)
/*     */       throws Exception
/*     */     {
/*  90 */       resources.resourceId(this.resource.getResourceId());
/*     */     }
/*     */     
/*     */     public void configure(HttpSecurity http) throws Exception
/*     */     {
/*  95 */       ((ExpressionUrlAuthorizationConfigurer.AuthorizedUrl)http.authorizeRequests().anyRequest()).authenticated();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected static class ResourceServerCondition
/*     */     extends SpringBootCondition
/*     */     implements ConfigurationCondition
/*     */   {
/*     */     private static final String AUTHORIZATION_ANNOTATION = "org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerEndpointsConfiguration";
/*     */     
/*     */ 
/*     */     public ConfigurationCondition.ConfigurationPhase getConfigurationPhase()
/*     */     {
/* 109 */       return ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN;
/*     */     }
/*     */     
/*     */ 
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*     */     {
/* 115 */       Environment environment = context.getEnvironment();
/* 116 */       RelaxedPropertyResolver resolver = new RelaxedPropertyResolver(environment, "security.oauth2.resource.");
/*     */       
/* 118 */       if (hasOAuthClientId(environment)) {
/* 119 */         return ConditionOutcome.match("found client id");
/*     */       }
/* 121 */       if (!resolver.getSubProperties("jwt").isEmpty()) {
/* 122 */         return ConditionOutcome.match("found JWT resource configuration");
/*     */       }
/* 124 */       if (StringUtils.hasText(resolver.getProperty("user-info-uri")))
/*     */       {
/* 126 */         return ConditionOutcome.match("found UserInfo URI resource configuration");
/*     */       }
/* 128 */       if (ClassUtils.isPresent("org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerEndpointsConfiguration", null))
/*     */       {
/* 130 */         if (OAuth2ResourceServerConfiguration.AuthorizationServerEndpointsConfigurationBeanCondition.matches(context)) {
/* 131 */           return ConditionOutcome.match("found authorization server endpoints configuration");
/*     */         }
/*     */       }
/*     */       
/* 135 */       return ConditionOutcome.noMatch("found neither client id nor JWT resource nor authorization server");
/*     */     }
/*     */     
/*     */     private boolean hasOAuthClientId(Environment environment)
/*     */     {
/* 140 */       RelaxedPropertyResolver resolver = new RelaxedPropertyResolver(environment, "security.oauth2.client.");
/*     */       
/* 142 */       return StringUtils.hasLength(resolver.getProperty("client-id", ""));
/*     */     }
/*     */   }
/*     */   
/*     */   @ConditionalOnBean({AuthorizationServerEndpointsConfiguration.class})
/*     */   private static class AuthorizationServerEndpointsConfigurationBeanCondition
/*     */   {
/*     */     public static boolean matches(ConditionContext context)
/*     */     {
/* 151 */       Class<AuthorizationServerEndpointsConfigurationBeanCondition> type = AuthorizationServerEndpointsConfigurationBeanCondition.class;
/* 152 */       Conditional conditional = (Conditional)AnnotationUtils.findAnnotation(type, Conditional.class);
/*     */       
/* 154 */       StandardAnnotationMetadata metadata = new StandardAnnotationMetadata(type);
/* 155 */       for (Class<? extends Condition> conditionType : conditional.value()) {
/* 156 */         Condition condition = (Condition)BeanUtils.instantiateClass(conditionType);
/* 157 */         if (condition.matches(context, metadata)) {
/* 158 */           return true;
/*     */         }
/*     */       }
/* 161 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\security\oauth2\resource\OAuth2ResourceServerConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */