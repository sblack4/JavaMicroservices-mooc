/*    */ package org.springframework.boot.autoconfigure.batch;
/*    */ 
/*    */ import javax.annotation.PostConstruct;
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.batch.support.DatabaseType;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.jdbc.datasource.init.DatabasePopulatorUtils;
/*    */ import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
/*    */ import org.springframework.jdbc.support.MetaDataAccessException;
/*    */ import org.springframework.stereotype.Component;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Component
/*    */ public class BatchDatabaseInitializer
/*    */ {
/*    */   @Autowired
/*    */   private BatchProperties properties;
/*    */   @Autowired
/*    */   private DataSource dataSource;
/*    */   @Autowired
/*    */   private ResourceLoader resourceLoader;
/*    */   
/*    */   @PostConstruct
/*    */   protected void initialize()
/*    */   {
/* 49 */     if (this.properties.getInitializer().isEnabled()) {
/* 50 */       String platform = getDatabaseType();
/* 51 */       if ("hsql".equals(platform)) {
/* 52 */         platform = "hsqldb";
/*    */       }
/* 54 */       if ("postgres".equals(platform)) {
/* 55 */         platform = "postgresql";
/*    */       }
/* 57 */       if ("oracle".equals(platform)) {
/* 58 */         platform = "oracle10g";
/*    */       }
/* 60 */       ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
/* 61 */       String schemaLocation = this.properties.getSchema();
/* 62 */       schemaLocation = schemaLocation.replace("@@platform@@", platform);
/* 63 */       populator.addScript(this.resourceLoader.getResource(schemaLocation));
/* 64 */       populator.setContinueOnError(true);
/* 65 */       DatabasePopulatorUtils.execute(populator, this.dataSource);
/*    */     }
/*    */   }
/*    */   
/*    */   private String getDatabaseType() {
/*    */     try {
/* 71 */       return DatabaseType.fromMetaData(this.dataSource).toString().toLowerCase();
/*    */     }
/*    */     catch (MetaDataAccessException ex) {
/* 74 */       throw new IllegalStateException("Unable to detect database type", ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\batch\BatchDatabaseInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */