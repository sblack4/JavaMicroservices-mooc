/*    */ package org.springframework.boot.autoconfigure.admin;
/*    */ 
/*    */ import javax.management.MalformedObjectNameException;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.admin.SpringApplicationAdminMXBeanRegistrar;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.autoconfigure.jmx.JmxAutoConfiguration;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.jmx.export.MBeanExporter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration
/*    */ @AutoConfigureAfter({JmxAutoConfiguration.class})
/*    */ @ConditionalOnProperty(prefix="spring.application.admin", value={"enabled"}, havingValue="true", matchIfMissing=false)
/*    */ public class SpringApplicationAdminJmxAutoConfiguration
/*    */ {
/*    */   private static final String JMX_NAME_PROPERTY = "spring.application.admin.jmx-name";
/*    */   private static final String DEFAULT_JMX_NAME = "org.springframework.boot:type=Admin,name=SpringApplication";
/*    */   private final MBeanExporter mbeanExporter;
/*    */   private final Environment environment;
/*    */   
/*    */   public SpringApplicationAdminJmxAutoConfiguration(ObjectProvider<MBeanExporter> mbeanExporterProvider, Environment environment)
/*    */   {
/* 65 */     this.mbeanExporter = ((MBeanExporter)mbeanExporterProvider.getIfAvailable());
/* 66 */     this.environment = environment;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public SpringApplicationAdminMXBeanRegistrar springApplicationAdminRegistrar() throws MalformedObjectNameException
/*    */   {
/* 73 */     String jmxName = this.environment.getProperty("spring.application.admin.jmx-name", "org.springframework.boot:type=Admin,name=SpringApplication");
/*    */     
/* 75 */     if (this.mbeanExporter != null) {
/* 76 */       this.mbeanExporter.addExcludedBean(jmxName);
/*    */     }
/* 78 */     return new SpringApplicationAdminMXBeanRegistrar(jmxName);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\admin\SpringApplicationAdminJmxAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */