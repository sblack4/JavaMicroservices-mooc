/*      */ package org.springframework.boot.autoconfigure.web;
/*      */ 
/*      */ import io.undertow.Undertow.Builder;
/*      */ import io.undertow.UndertowOptions;
/*      */ import java.io.File;
/*      */ import java.lang.reflect.Method;
/*      */ import java.net.InetAddress;
/*      */ import java.nio.charset.Charset;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.SessionCookieConfig;
/*      */ import javax.servlet.SessionTrackingMode;
/*      */ import javax.validation.constraints.NotNull;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Valve;
/*      */ import org.apache.catalina.valves.AccessLogValve;
/*      */ import org.apache.catalina.valves.RemoteIpValve;
/*      */ import org.apache.coyote.AbstractProtocol;
/*      */ import org.apache.coyote.ProtocolHandler;
/*      */ import org.apache.coyote.http11.AbstractHttp11Protocol;
/*      */ import org.eclipse.jetty.server.AbstractConnector;
/*      */ import org.eclipse.jetty.server.ConnectionFactory;
/*      */ import org.eclipse.jetty.server.Handler;
/*      */ import org.eclipse.jetty.server.HttpConfiguration;
/*      */ import org.eclipse.jetty.server.HttpConfiguration.ConnectionFactory;
/*      */ import org.eclipse.jetty.server.Server;
/*      */ import org.eclipse.jetty.server.handler.ContextHandler;
/*      */ import org.eclipse.jetty.server.handler.HandlerCollection;
/*      */ import org.eclipse.jetty.server.handler.HandlerWrapper;
/*      */ import org.springframework.boot.cloud.CloudPlatform;
/*      */ import org.springframework.boot.context.embedded.Compression;
/*      */ import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
/*      */ import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;
/*      */ import org.springframework.boot.context.embedded.InitParameterConfiguringServletContextInitializer;
/*      */ import org.springframework.boot.context.embedded.JspServlet;
/*      */ import org.springframework.boot.context.embedded.Ssl;
/*      */ import org.springframework.boot.context.embedded.jetty.JettyEmbeddedServletContainerFactory;
/*      */ import org.springframework.boot.context.embedded.jetty.JettyServerCustomizer;
/*      */ import org.springframework.boot.context.embedded.tomcat.TomcatConnectorCustomizer;
/*      */ import org.springframework.boot.context.embedded.tomcat.TomcatContextCustomizer;
/*      */ import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;
/*      */ import org.springframework.boot.context.embedded.undertow.UndertowBuilderCustomizer;
/*      */ import org.springframework.boot.context.embedded.undertow.UndertowEmbeddedServletContainerFactory;
/*      */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*      */ import org.springframework.boot.context.properties.DeprecatedConfigurationProperty;
/*      */ import org.springframework.boot.context.properties.NestedConfigurationProperty;
/*      */ import org.springframework.boot.web.servlet.ServletContextInitializer;
/*      */ import org.springframework.context.EnvironmentAware;
/*      */ import org.springframework.core.Ordered;
/*      */ import org.springframework.core.env.Environment;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @ConfigurationProperties(prefix="server", ignoreUnknownFields=true)
/*      */ public class ServerProperties
/*      */   implements EmbeddedServletContainerCustomizer, EnvironmentAware, Ordered
/*      */ {
/*      */   private Integer port;
/*      */   private InetAddress address;
/*      */   private String contextPath;
/*  113 */   private String displayName = "application";
/*      */   @NestedConfigurationProperty
/*  115 */   private ErrorProperties error = new ErrorProperties();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   @NotNull
/*  121 */   private String servletPath = "/";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  127 */   private final Map<String, String> contextParameters = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Boolean useForwardHeaders;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String serverHeader;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  142 */   private int maxHttpHeaderSize = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  147 */   private int maxHttpPostSize = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Integer connectionTimeout;
/*      */   
/*      */ 
/*      */ 
/*  156 */   private Session session = new Session();
/*      */   
/*      */   @NestedConfigurationProperty
/*      */   private Ssl ssl;
/*      */   @NestedConfigurationProperty
/*  161 */   private Compression compression = new Compression();
/*      */   
/*      */ 
/*      */   @NestedConfigurationProperty
/*      */   private JspServlet jspServlet;
/*      */   
/*  167 */   private final Tomcat tomcat = new Tomcat();
/*      */   
/*  169 */   private final Jetty jetty = new Jetty();
/*      */   
/*  171 */   private final Undertow undertow = new Undertow();
/*      */   
/*      */   private Environment environment;
/*      */   
/*      */   public int getOrder()
/*      */   {
/*  177 */     return 0;
/*      */   }
/*      */   
/*      */   public void setEnvironment(Environment environment)
/*      */   {
/*  182 */     this.environment = environment;
/*      */   }
/*      */   
/*      */   public void customize(ConfigurableEmbeddedServletContainer container)
/*      */   {
/*  187 */     if (getPort() != null) {
/*  188 */       container.setPort(getPort().intValue());
/*      */     }
/*  190 */     if (getAddress() != null) {
/*  191 */       container.setAddress(getAddress());
/*      */     }
/*  193 */     if (getContextPath() != null) {
/*  194 */       container.setContextPath(getContextPath());
/*      */     }
/*  196 */     if (getDisplayName() != null) {
/*  197 */       container.setDisplayName(getDisplayName());
/*      */     }
/*  199 */     if (getSession().getTimeout() != null) {
/*  200 */       container.setSessionTimeout(getSession().getTimeout().intValue());
/*      */     }
/*  202 */     container.setPersistSession(getSession().isPersistent());
/*  203 */     container.setSessionStoreDir(getSession().getStoreDir());
/*  204 */     if (getSsl() != null) {
/*  205 */       container.setSsl(getSsl());
/*      */     }
/*  207 */     if (getJspServlet() != null) {
/*  208 */       container.setJspServlet(getJspServlet());
/*      */     }
/*  210 */     if (getCompression() != null) {
/*  211 */       container.setCompression(getCompression());
/*      */     }
/*  213 */     container.setServerHeader(getServerHeader());
/*  214 */     if ((container instanceof TomcatEmbeddedServletContainerFactory)) {
/*  215 */       getTomcat().customizeTomcat(this, (TomcatEmbeddedServletContainerFactory)container);
/*      */     }
/*      */     
/*  218 */     if ((container instanceof JettyEmbeddedServletContainerFactory)) {
/*  219 */       getJetty().customizeJetty(this, (JettyEmbeddedServletContainerFactory)container);
/*      */     }
/*      */     
/*      */ 
/*  223 */     if ((container instanceof UndertowEmbeddedServletContainerFactory)) {
/*  224 */       getUndertow().customizeUndertow(this, (UndertowEmbeddedServletContainerFactory)container);
/*      */     }
/*      */     
/*  227 */     container.addInitializers(new ServletContextInitializer[] { new SessionConfiguringInitializer(this.session) });
/*  228 */     container.addInitializers(new ServletContextInitializer[] { new InitParameterConfiguringServletContextInitializer(
/*  229 */       getContextParameters()) });
/*      */   }
/*      */   
/*      */   public String getServletMapping() {
/*  233 */     if ((this.servletPath.equals("")) || (this.servletPath.equals("/"))) {
/*  234 */       return "/";
/*      */     }
/*  236 */     if (this.servletPath.contains("*")) {
/*  237 */       return this.servletPath;
/*      */     }
/*  239 */     if (this.servletPath.endsWith("/")) {
/*  240 */       return this.servletPath + "*";
/*      */     }
/*  242 */     return this.servletPath + "/*";
/*      */   }
/*      */   
/*      */   public String getPath(String path) {
/*  246 */     String prefix = getServletPrefix();
/*  247 */     if (!path.startsWith("/")) {
/*  248 */       path = "/" + path;
/*      */     }
/*  250 */     return prefix + path;
/*      */   }
/*      */   
/*      */   public String getServletPrefix() {
/*  254 */     String result = this.servletPath;
/*  255 */     if (result.contains("*")) {
/*  256 */       result = result.substring(0, result.indexOf("*"));
/*      */     }
/*  258 */     if (result.endsWith("/")) {
/*  259 */       result = result.substring(0, result.length() - 1);
/*      */     }
/*  261 */     return result;
/*      */   }
/*      */   
/*      */   public String[] getPathsArray(Collection<String> paths) {
/*  265 */     String[] result = new String[paths.size()];
/*  266 */     int i = 0;
/*  267 */     for (String path : paths) {
/*  268 */       result[(i++)] = getPath(path);
/*      */     }
/*  270 */     return result;
/*      */   }
/*      */   
/*      */   public String[] getPathsArray(String[] paths) {
/*  274 */     String[] result = new String[paths.length];
/*  275 */     int i = 0;
/*  276 */     for (String path : paths) {
/*  277 */       result[(i++)] = getPath(path);
/*      */     }
/*  279 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setLoader(String value) {}
/*      */   
/*      */   public Integer getPort()
/*      */   {
/*  287 */     return this.port;
/*      */   }
/*      */   
/*      */   public void setPort(Integer port) {
/*  291 */     this.port = port;
/*      */   }
/*      */   
/*      */   public InetAddress getAddress() {
/*  295 */     return this.address;
/*      */   }
/*      */   
/*      */   public void setAddress(InetAddress address) {
/*  299 */     this.address = address;
/*      */   }
/*      */   
/*      */   public String getContextPath() {
/*  303 */     return this.contextPath;
/*      */   }
/*      */   
/*      */   public void setContextPath(String contextPath) {
/*  307 */     this.contextPath = cleanContextPath(contextPath);
/*      */   }
/*      */   
/*      */   private String cleanContextPath(String contextPath) {
/*  311 */     if ((StringUtils.hasText(contextPath)) && (contextPath.endsWith("/"))) {
/*  312 */       return contextPath.substring(0, contextPath.length() - 1);
/*      */     }
/*  314 */     return contextPath;
/*      */   }
/*      */   
/*      */   public String getDisplayName() {
/*  318 */     return this.displayName;
/*      */   }
/*      */   
/*      */   public void setDisplayName(String displayName) {
/*  322 */     this.displayName = displayName;
/*      */   }
/*      */   
/*      */   public String getServletPath() {
/*  326 */     return this.servletPath;
/*      */   }
/*      */   
/*      */   public void setServletPath(String servletPath) {
/*  330 */     this.servletPath = servletPath;
/*      */   }
/*      */   
/*      */   public Map<String, String> getContextParameters() {
/*  334 */     return this.contextParameters;
/*      */   }
/*      */   
/*      */   public Boolean isUseForwardHeaders() {
/*  338 */     return this.useForwardHeaders;
/*      */   }
/*      */   
/*      */   public void setUseForwardHeaders(Boolean useForwardHeaders) {
/*  342 */     this.useForwardHeaders = useForwardHeaders;
/*      */   }
/*      */   
/*      */   public String getServerHeader() {
/*  346 */     return this.serverHeader;
/*      */   }
/*      */   
/*      */   public void setServerHeader(String serverHeader) {
/*  350 */     this.serverHeader = serverHeader;
/*      */   }
/*      */   
/*      */   public int getMaxHttpHeaderSize() {
/*  354 */     return this.maxHttpHeaderSize;
/*      */   }
/*      */   
/*      */   public void setMaxHttpHeaderSize(int maxHttpHeaderSize) {
/*  358 */     this.maxHttpHeaderSize = maxHttpHeaderSize;
/*      */   }
/*      */   
/*      */   public int getMaxHttpPostSize() {
/*  362 */     return this.maxHttpPostSize;
/*      */   }
/*      */   
/*      */   public void setMaxHttpPostSize(int maxHttpPostSize) {
/*  366 */     this.maxHttpPostSize = maxHttpPostSize;
/*      */   }
/*      */   
/*      */   protected final boolean getOrDeduceUseForwardHeaders() {
/*  370 */     if (this.useForwardHeaders != null) {
/*  371 */       return this.useForwardHeaders.booleanValue();
/*      */     }
/*  373 */     CloudPlatform platform = CloudPlatform.getActive(this.environment);
/*  374 */     return platform == null ? false : platform.isUsingForwardHeaders();
/*      */   }
/*      */   
/*      */   public Integer getConnectionTimeout() {
/*  378 */     return this.connectionTimeout;
/*      */   }
/*      */   
/*      */   public void setConnectionTimeout(Integer connectionTimeout) {
/*  382 */     this.connectionTimeout = connectionTimeout;
/*      */   }
/*      */   
/*      */   public ErrorProperties getError() {
/*  386 */     return this.error;
/*      */   }
/*      */   
/*      */   public Session getSession() {
/*  390 */     return this.session;
/*      */   }
/*      */   
/*      */   public void setSession(Session session) {
/*  394 */     this.session = session;
/*      */   }
/*      */   
/*      */   public Ssl getSsl() {
/*  398 */     return this.ssl;
/*      */   }
/*      */   
/*      */   public void setSsl(Ssl ssl) {
/*  402 */     this.ssl = ssl;
/*      */   }
/*      */   
/*      */   public Compression getCompression() {
/*  406 */     return this.compression;
/*      */   }
/*      */   
/*      */   public JspServlet getJspServlet() {
/*  410 */     return this.jspServlet;
/*      */   }
/*      */   
/*      */   public void setJspServlet(JspServlet jspServlet) {
/*  414 */     this.jspServlet = jspServlet;
/*      */   }
/*      */   
/*      */   public Tomcat getTomcat() {
/*  418 */     return this.tomcat;
/*      */   }
/*      */   
/*      */   public Jetty getJetty() {
/*  422 */     return this.jetty;
/*      */   }
/*      */   
/*      */   public Undertow getUndertow() {
/*  426 */     return this.undertow;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class Session
/*      */   {
/*      */     private Integer timeout;
/*      */     
/*      */ 
/*      */ 
/*      */     private Set<SessionTrackingMode> trackingModes;
/*      */     
/*      */ 
/*      */ 
/*      */     private boolean persistent;
/*      */     
/*      */ 
/*      */ 
/*      */     private File storeDir;
/*      */     
/*      */ 
/*      */ 
/*  451 */     private Cookie cookie = new Cookie();
/*      */     
/*      */     public Cookie getCookie() {
/*  454 */       return this.cookie;
/*      */     }
/*      */     
/*      */     public Integer getTimeout() {
/*  458 */       return this.timeout;
/*      */     }
/*      */     
/*      */     public void setTimeout(Integer sessionTimeout) {
/*  462 */       this.timeout = sessionTimeout;
/*      */     }
/*      */     
/*      */     public Set<SessionTrackingMode> getTrackingModes() {
/*  466 */       return this.trackingModes;
/*      */     }
/*      */     
/*      */     public void setTrackingModes(Set<SessionTrackingMode> trackingModes) {
/*  470 */       this.trackingModes = trackingModes;
/*      */     }
/*      */     
/*      */     public boolean isPersistent() {
/*  474 */       return this.persistent;
/*      */     }
/*      */     
/*      */     public void setPersistent(boolean persistent) {
/*  478 */       this.persistent = persistent;
/*      */     }
/*      */     
/*      */     public File getStoreDir() {
/*  482 */       return this.storeDir;
/*      */     }
/*      */     
/*      */     public void setStoreDir(File storeDir) {
/*  486 */       this.storeDir = storeDir;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public static class Cookie
/*      */     {
/*      */       private String name;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       private String domain;
/*      */       
/*      */ 
/*      */ 
/*      */       private String path;
/*      */       
/*      */ 
/*      */ 
/*      */       private String comment;
/*      */       
/*      */ 
/*      */ 
/*      */       private Boolean httpOnly;
/*      */       
/*      */ 
/*      */ 
/*      */       private Boolean secure;
/*      */       
/*      */ 
/*      */ 
/*      */       private Integer maxAge;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public String getName()
/*      */       {
/*  527 */         return this.name;
/*      */       }
/*      */       
/*      */       public void setName(String name) {
/*  531 */         this.name = name;
/*      */       }
/*      */       
/*      */       public String getDomain() {
/*  535 */         return this.domain;
/*      */       }
/*      */       
/*      */       public void setDomain(String domain) {
/*  539 */         this.domain = domain;
/*      */       }
/*      */       
/*      */       public String getPath() {
/*  543 */         return this.path;
/*      */       }
/*      */       
/*      */       public void setPath(String path) {
/*  547 */         this.path = path;
/*      */       }
/*      */       
/*      */       public String getComment() {
/*  551 */         return this.comment;
/*      */       }
/*      */       
/*      */       public void setComment(String comment) {
/*  555 */         this.comment = comment;
/*      */       }
/*      */       
/*      */       public Boolean getHttpOnly() {
/*  559 */         return this.httpOnly;
/*      */       }
/*      */       
/*      */       public void setHttpOnly(Boolean httpOnly) {
/*  563 */         this.httpOnly = httpOnly;
/*      */       }
/*      */       
/*      */       public Boolean getSecure() {
/*  567 */         return this.secure;
/*      */       }
/*      */       
/*      */       public void setSecure(Boolean secure) {
/*  571 */         this.secure = secure;
/*      */       }
/*      */       
/*      */       public Integer getMaxAge() {
/*  575 */         return this.maxAge;
/*      */       }
/*      */       
/*      */       public void setMaxAge(Integer maxAge) {
/*  579 */         this.maxAge = maxAge;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class Tomcat
/*      */   {
/*  591 */     private final Accesslog accesslog = new Accesslog();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  596 */     private String internalProxies = "10\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|192\\.168\\.\\d{1,3}\\.\\d{1,3}|169\\.254\\.\\d{1,3}\\.\\d{1,3}|127\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|172\\.1[6-9]{1}\\.\\d{1,3}\\.\\d{1,3}|172\\.2[0-9]{1}\\.\\d{1,3}\\.\\d{1,3}|172\\.3[0-1]{1}\\.\\d{1,3}\\.\\d{1,3}";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private String protocolHeader;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  612 */     private String protocolHeaderHttpsValue = "https";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  617 */     private String portHeader = "X-Forwarded-Port";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private String remoteIpHeader;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private File basedir;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  632 */     private int backgroundProcessorDelay = 30;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  637 */     private int maxThreads = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  642 */     private int minSpareThreads = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  647 */     private int maxHttpHeaderSize = 0;
/*      */     
/*      */ 
/*      */ 
/*      */     private Boolean redirectContextRoot;
/*      */     
/*      */ 
/*      */ 
/*      */     private Charset uriEncoding;
/*      */     
/*      */ 
/*      */ 
/*      */     public int getMaxThreads()
/*      */     {
/*  661 */       return this.maxThreads;
/*      */     }
/*      */     
/*      */     public void setMaxThreads(int maxThreads) {
/*  665 */       this.maxThreads = maxThreads;
/*      */     }
/*      */     
/*      */     public int getMinSpareThreads() {
/*  669 */       return this.minSpareThreads;
/*      */     }
/*      */     
/*      */     public void setMinSpareThreads(int minSpareThreads) {
/*  673 */       this.minSpareThreads = minSpareThreads;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     @Deprecated
/*      */     @DeprecatedConfigurationProperty(replacement="server.max-http-header-size")
/*      */     public int getMaxHttpHeaderSize()
/*      */     {
/*  685 */       return this.maxHttpHeaderSize;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     @Deprecated
/*      */     public void setMaxHttpHeaderSize(int maxHttpHeaderSize)
/*      */     {
/*  696 */       this.maxHttpHeaderSize = maxHttpHeaderSize;
/*      */     }
/*      */     
/*      */     public Accesslog getAccesslog() {
/*  700 */       return this.accesslog;
/*      */     }
/*      */     
/*      */     public int getBackgroundProcessorDelay() {
/*  704 */       return this.backgroundProcessorDelay;
/*      */     }
/*      */     
/*      */     public void setBackgroundProcessorDelay(int backgroundProcessorDelay) {
/*  708 */       this.backgroundProcessorDelay = backgroundProcessorDelay;
/*      */     }
/*      */     
/*      */     public File getBasedir() {
/*  712 */       return this.basedir;
/*      */     }
/*      */     
/*      */     public void setBasedir(File basedir) {
/*  716 */       this.basedir = basedir;
/*      */     }
/*      */     
/*      */     public String getInternalProxies() {
/*  720 */       return this.internalProxies;
/*      */     }
/*      */     
/*      */     public void setInternalProxies(String internalProxies) {
/*  724 */       this.internalProxies = internalProxies;
/*      */     }
/*      */     
/*      */     public String getProtocolHeader() {
/*  728 */       return this.protocolHeader;
/*      */     }
/*      */     
/*      */     public void setProtocolHeader(String protocolHeader) {
/*  732 */       this.protocolHeader = protocolHeader;
/*      */     }
/*      */     
/*      */     public String getProtocolHeaderHttpsValue() {
/*  736 */       return this.protocolHeaderHttpsValue;
/*      */     }
/*      */     
/*      */     public void setProtocolHeaderHttpsValue(String protocolHeaderHttpsValue) {
/*  740 */       this.protocolHeaderHttpsValue = protocolHeaderHttpsValue;
/*      */     }
/*      */     
/*      */     public String getPortHeader() {
/*  744 */       return this.portHeader;
/*      */     }
/*      */     
/*      */     public void setPortHeader(String portHeader) {
/*  748 */       this.portHeader = portHeader;
/*      */     }
/*      */     
/*      */     public Boolean getRedirectContextRoot() {
/*  752 */       return this.redirectContextRoot;
/*      */     }
/*      */     
/*      */     public void setRedirectContextRoot(Boolean redirectContextRoot) {
/*  756 */       this.redirectContextRoot = redirectContextRoot;
/*      */     }
/*      */     
/*      */     public String getRemoteIpHeader() {
/*  760 */       return this.remoteIpHeader;
/*      */     }
/*      */     
/*      */     public void setRemoteIpHeader(String remoteIpHeader) {
/*  764 */       this.remoteIpHeader = remoteIpHeader;
/*      */     }
/*      */     
/*      */     public Charset getUriEncoding() {
/*  768 */       return this.uriEncoding;
/*      */     }
/*      */     
/*      */     public void setUriEncoding(Charset uriEncoding) {
/*  772 */       this.uriEncoding = uriEncoding;
/*      */     }
/*      */     
/*      */     void customizeTomcat(ServerProperties serverProperties, TomcatEmbeddedServletContainerFactory factory)
/*      */     {
/*  777 */       if (getBasedir() != null) {
/*  778 */         factory.setBaseDirectory(getBasedir());
/*      */       }
/*  780 */       customizeBackgroundProcessorDelay(factory);
/*  781 */       customizeRemoteIpValve(serverProperties, factory);
/*  782 */       if (this.maxThreads > 0) {
/*  783 */         customizeMaxThreads(factory);
/*      */       }
/*  785 */       if (this.minSpareThreads > 0) {
/*  786 */         customizeMinThreads(factory);
/*      */       }
/*      */       
/*  789 */       int maxHttpHeaderSize = serverProperties.getMaxHttpHeaderSize() > 0 ? serverProperties.getMaxHttpHeaderSize() : this.maxHttpHeaderSize;
/*  790 */       if (maxHttpHeaderSize > 0) {
/*  791 */         customizeMaxHttpHeaderSize(factory, maxHttpHeaderSize);
/*      */       }
/*  793 */       if (serverProperties.getMaxHttpPostSize() > 0) {
/*  794 */         customizeMaxHttpPostSize(factory, serverProperties.getMaxHttpPostSize());
/*      */       }
/*  796 */       if (this.accesslog.enabled) {
/*  797 */         customizeAccessLog(factory);
/*      */       }
/*  799 */       if (getUriEncoding() != null) {
/*  800 */         factory.setUriEncoding(getUriEncoding());
/*      */       }
/*  802 */       if (serverProperties.getConnectionTimeout() != null) {
/*  803 */         customizeConnectionTimeout(factory, serverProperties
/*  804 */           .getConnectionTimeout().intValue());
/*      */       }
/*  806 */       if (this.redirectContextRoot != null) {
/*  807 */         customizeRedirectContextRoot(factory, this.redirectContextRoot.booleanValue());
/*      */       }
/*      */     }
/*      */     
/*      */     private void customizeConnectionTimeout(TomcatEmbeddedServletContainerFactory factory, int connectionTimeout)
/*      */     {
/*  813 */       for (org.apache.catalina.connector.Connector connector : factory.getAdditionalTomcatConnectors()) {
/*  814 */         if ((connector.getProtocolHandler() instanceof AbstractProtocol))
/*      */         {
/*  816 */           AbstractProtocol<?> handler = (AbstractProtocol)connector.getProtocolHandler();
/*  817 */           handler.setConnectionTimeout(connectionTimeout);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     private void customizeBackgroundProcessorDelay(TomcatEmbeddedServletContainerFactory factory)
/*      */     {
/*  824 */       factory.addContextCustomizers(new TomcatContextCustomizer[] { new TomcatContextCustomizer()
/*      */       {
/*      */         public void customize(Context context)
/*      */         {
/*  828 */           context.setBackgroundProcessorDelay(
/*  829 */             ServerProperties.Tomcat.this.backgroundProcessorDelay);
/*      */         }
/*      */       } });
/*      */     }
/*      */     
/*      */ 
/*      */     private void customizeRemoteIpValve(ServerProperties properties, TomcatEmbeddedServletContainerFactory factory)
/*      */     {
/*  837 */       String protocolHeader = getProtocolHeader();
/*  838 */       String remoteIpHeader = getRemoteIpHeader();
/*      */       
/*  840 */       if ((StringUtils.hasText(protocolHeader)) || (StringUtils.hasText(remoteIpHeader)) || 
/*  841 */         (properties.getOrDeduceUseForwardHeaders())) {
/*  842 */         RemoteIpValve valve = new RemoteIpValve();
/*  843 */         valve.setProtocolHeader(StringUtils.hasLength(protocolHeader) ? protocolHeader : "X-Forwarded-Proto");
/*      */         
/*  845 */         if (StringUtils.hasLength(remoteIpHeader)) {
/*  846 */           valve.setRemoteIpHeader(remoteIpHeader);
/*      */         }
/*      */         
/*      */ 
/*  850 */         valve.setInternalProxies(getInternalProxies());
/*  851 */         valve.setPortHeader(getPortHeader());
/*  852 */         valve.setProtocolHeaderHttpsValue(getProtocolHeaderHttpsValue());
/*      */         
/*  854 */         factory.addEngineValves(new Valve[] { valve });
/*      */       }
/*      */     }
/*      */     
/*      */     private void customizeMaxThreads(TomcatEmbeddedServletContainerFactory factory)
/*      */     {
/*  860 */       factory.addConnectorCustomizers(new TomcatConnectorCustomizer[] { new TomcatConnectorCustomizer()
/*      */       {
/*      */         public void customize(org.apache.catalina.connector.Connector connector)
/*      */         {
/*  864 */           ProtocolHandler handler = connector.getProtocolHandler();
/*  865 */           if ((handler instanceof AbstractProtocol)) {
/*  866 */             AbstractProtocol protocol = (AbstractProtocol)handler;
/*  867 */             protocol.setMaxThreads(ServerProperties.Tomcat.this.maxThreads);
/*      */           }
/*      */         }
/*      */       } });
/*      */     }
/*      */     
/*      */ 
/*      */     private void customizeMinThreads(TomcatEmbeddedServletContainerFactory factory)
/*      */     {
/*  876 */       factory.addConnectorCustomizers(new TomcatConnectorCustomizer[] { new TomcatConnectorCustomizer()
/*      */       {
/*      */         public void customize(org.apache.catalina.connector.Connector connector)
/*      */         {
/*  880 */           ProtocolHandler handler = connector.getProtocolHandler();
/*  881 */           if ((handler instanceof AbstractProtocol)) {
/*  882 */             AbstractProtocol protocol = (AbstractProtocol)handler;
/*  883 */             protocol.setMinSpareThreads(ServerProperties.Tomcat.this.minSpareThreads);
/*      */           }
/*      */         }
/*      */       } });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private void customizeMaxHttpHeaderSize(TomcatEmbeddedServletContainerFactory factory, final int maxHttpHeaderSize)
/*      */     {
/*  894 */       factory.addConnectorCustomizers(new TomcatConnectorCustomizer[] { new TomcatConnectorCustomizer()
/*      */       {
/*      */         public void customize(org.apache.catalina.connector.Connector connector)
/*      */         {
/*  898 */           ProtocolHandler handler = connector.getProtocolHandler();
/*  899 */           if ((handler instanceof AbstractHttp11Protocol)) {
/*  900 */             AbstractHttp11Protocol protocol = (AbstractHttp11Protocol)handler;
/*  901 */             protocol.setMaxHttpHeaderSize(maxHttpHeaderSize);
/*      */           }
/*      */         }
/*      */       } });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     private void customizeMaxHttpPostSize(TomcatEmbeddedServletContainerFactory factory, final int maxHttpPostSize)
/*      */     {
/*  911 */       factory.addConnectorCustomizers(new TomcatConnectorCustomizer[] { new TomcatConnectorCustomizer()
/*      */       {
/*      */         public void customize(org.apache.catalina.connector.Connector connector)
/*      */         {
/*  915 */           connector.setMaxPostSize(maxHttpPostSize);
/*      */         }
/*      */       } });
/*      */     }
/*      */     
/*      */     private void customizeAccessLog(TomcatEmbeddedServletContainerFactory factory)
/*      */     {
/*  922 */       AccessLogValve valve = new AccessLogValve();
/*  923 */       valve.setPattern(this.accesslog.getPattern());
/*  924 */       valve.setDirectory(this.accesslog.getDirectory());
/*  925 */       valve.setPrefix(this.accesslog.getPrefix());
/*  926 */       valve.setSuffix(this.accesslog.getSuffix());
/*  927 */       valve.setRenameOnRotate(this.accesslog.isRenameOnRotate());
/*  928 */       factory.addEngineValves(new Valve[] { valve });
/*      */     }
/*      */     
/*      */ 
/*      */     private void customizeRedirectContextRoot(TomcatEmbeddedServletContainerFactory factory, final boolean redirectContextRoot)
/*      */     {
/*  934 */       factory.addContextCustomizers(new TomcatContextCustomizer[] { new TomcatContextCustomizer()
/*      */       {
/*      */         public void customize(Context context)
/*      */         {
/*  938 */           context.setMapperContextRootRedirectEnabled(redirectContextRoot);
/*      */         }
/*      */       } });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public static class Accesslog
/*      */     {
/*  949 */       private boolean enabled = false;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  954 */       private String pattern = "common";
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  960 */       private String directory = "logs";
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  965 */       protected String prefix = "access_log";
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  970 */       private String suffix = ".log";
/*      */       
/*      */ 
/*      */       private boolean renameOnRotate;
/*      */       
/*      */ 
/*      */       public boolean isEnabled()
/*      */       {
/*  978 */         return this.enabled;
/*      */       }
/*      */       
/*      */       public void setEnabled(boolean enabled) {
/*  982 */         this.enabled = enabled;
/*      */       }
/*      */       
/*      */       public String getPattern() {
/*  986 */         return this.pattern;
/*      */       }
/*      */       
/*      */       public void setPattern(String pattern) {
/*  990 */         this.pattern = pattern;
/*      */       }
/*      */       
/*      */       public String getDirectory() {
/*  994 */         return this.directory;
/*      */       }
/*      */       
/*      */       public void setDirectory(String directory) {
/*  998 */         this.directory = directory;
/*      */       }
/*      */       
/*      */       public String getPrefix() {
/* 1002 */         return this.prefix;
/*      */       }
/*      */       
/*      */       public void setPrefix(String prefix) {
/* 1006 */         this.prefix = prefix;
/*      */       }
/*      */       
/*      */       public String getSuffix() {
/* 1010 */         return this.suffix;
/*      */       }
/*      */       
/*      */       public void setSuffix(String suffix) {
/* 1014 */         this.suffix = suffix;
/*      */       }
/*      */       
/*      */       public boolean isRenameOnRotate() {
/* 1018 */         return this.renameOnRotate;
/*      */       }
/*      */       
/*      */       public void setRenameOnRotate(boolean renameOnRotate) {
/* 1022 */         this.renameOnRotate = renameOnRotate;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class Jetty
/*      */   {
/*      */     private Integer acceptors;
/*      */     
/*      */ 
/*      */ 
/*      */     private Integer selectors;
/*      */     
/*      */ 
/*      */ 
/*      */     public Integer getAcceptors()
/*      */     {
/* 1042 */       return this.acceptors;
/*      */     }
/*      */     
/*      */     public void setAcceptors(Integer acceptors) {
/* 1046 */       this.acceptors = acceptors;
/*      */     }
/*      */     
/*      */     public Integer getSelectors() {
/* 1050 */       return this.selectors;
/*      */     }
/*      */     
/*      */     public void setSelectors(Integer selectors) {
/* 1054 */       this.selectors = selectors;
/*      */     }
/*      */     
/*      */     void customizeJetty(ServerProperties serverProperties, JettyEmbeddedServletContainerFactory factory)
/*      */     {
/* 1059 */       factory.setUseForwardHeaders(serverProperties.getOrDeduceUseForwardHeaders());
/* 1060 */       if (this.acceptors != null) {
/* 1061 */         factory.setAcceptors(this.acceptors.intValue());
/*      */       }
/* 1063 */       if (this.selectors != null) {
/* 1064 */         factory.setSelectors(this.selectors.intValue());
/*      */       }
/* 1066 */       if (serverProperties.getMaxHttpHeaderSize() > 0) {
/* 1067 */         customizeMaxHttpHeaderSize(factory, serverProperties
/* 1068 */           .getMaxHttpHeaderSize());
/*      */       }
/* 1070 */       if (serverProperties.getMaxHttpPostSize() > 0) {
/* 1071 */         customizeMaxHttpPostSize(factory, serverProperties.getMaxHttpPostSize());
/*      */       }
/*      */       
/* 1074 */       if (serverProperties.getConnectionTimeout() != null) {
/* 1075 */         customizeConnectionTimeout(factory, serverProperties
/* 1076 */           .getConnectionTimeout().intValue());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     private void customizeConnectionTimeout(JettyEmbeddedServletContainerFactory factory, final int connectionTimeout)
/*      */     {
/* 1083 */       factory.addServerCustomizers(new JettyServerCustomizer[] { new JettyServerCustomizer()
/*      */       {
/*      */         public void customize(Server server) {
/* 1086 */           for (org.eclipse.jetty.server.Connector connector : server
/* 1087 */             .getConnectors()) {
/* 1088 */             if ((connector instanceof AbstractConnector))
/*      */             {
/* 1090 */               ((AbstractConnector)connector).setIdleTimeout(connectionTimeout);
/*      */             }
/*      */           }
/*      */         }
/*      */       } });
/*      */     }
/*      */     
/*      */ 
/*      */     private void customizeMaxHttpHeaderSize(JettyEmbeddedServletContainerFactory factory, final int maxHttpHeaderSize)
/*      */     {
/* 1100 */       factory.addServerCustomizers(new JettyServerCustomizer[] { new JettyServerCustomizer()
/*      */       {
/*      */         public void customize(Server server)
/*      */         {
/* 1104 */           for (org.eclipse.jetty.server.Connector connector : server
/* 1105 */             .getConnectors()) {
/*      */             try {
/* 1107 */               for (ConnectionFactory connectionFactory : connector
/* 1108 */                 .getConnectionFactories()) {
/* 1109 */                 if ((connectionFactory instanceof HttpConfiguration.ConnectionFactory)) {
/* 1110 */                   customize((HttpConfiguration.ConnectionFactory)connectionFactory);
/*      */                 }
/*      */               }
/*      */             }
/*      */             catch (NoSuchMethodError ex)
/*      */             {
/* 1116 */               customizeOnJetty8(connector, maxHttpHeaderSize);
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */         private void customize(HttpConfiguration.ConnectionFactory factory)
/*      */         {
/* 1123 */           HttpConfiguration configuration = factory.getHttpConfiguration();
/* 1124 */           configuration.setRequestHeaderSize(maxHttpHeaderSize);
/* 1125 */           configuration.setResponseHeaderSize(maxHttpHeaderSize);
/*      */         }
/*      */         
/*      */ 
/*      */         private void customizeOnJetty8(org.eclipse.jetty.server.Connector connector, int maxHttpHeaderSize)
/*      */         {
/*      */           try
/*      */           {
/* 1133 */             connector.getClass().getMethod("setRequestHeaderSize", new Class[] { Integer.TYPE }).invoke(connector, new Object[] { Integer.valueOf(maxHttpHeaderSize) });
/* 1134 */             connector.getClass().getMethod("setResponseHeaderSize", new Class[] { Integer.TYPE })
/* 1135 */               .invoke(connector, new Object[] {Integer.valueOf(maxHttpHeaderSize) });
/*      */           }
/*      */           catch (Exception ex) {
/* 1138 */             throw new RuntimeException(ex);
/*      */           }
/*      */         }
/*      */       } });
/*      */     }
/*      */     
/*      */ 
/*      */     private void customizeMaxHttpPostSize(JettyEmbeddedServletContainerFactory factory, final int maxHttpPostSize)
/*      */     {
/* 1147 */       factory.addServerCustomizers(new JettyServerCustomizer[] { new JettyServerCustomizer()
/*      */       {
/*      */         public void customize(Server server)
/*      */         {
/* 1151 */           setHandlerMaxHttpPostSize(maxHttpPostSize, server.getHandlers());
/*      */         }
/*      */         
/*      */         private void setHandlerMaxHttpPostSize(int maxHttpPostSize, Handler... handlers)
/*      */         {
/* 1156 */           for (Handler handler : handlers) {
/* 1157 */             if ((handler instanceof ContextHandler))
/*      */             {
/* 1159 */               ((ContextHandler)handler).setMaxFormContentSize(maxHttpPostSize);
/*      */             }
/* 1161 */             else if ((handler instanceof HandlerWrapper)) {
/* 1162 */               setHandlerMaxHttpPostSize(maxHttpPostSize, new Handler[] {((HandlerWrapper)handler)
/* 1163 */                 .getHandler() });
/*      */             }
/* 1165 */             else if ((handler instanceof HandlerCollection)) {
/* 1166 */               setHandlerMaxHttpPostSize(maxHttpPostSize, ((HandlerCollection)handler)
/* 1167 */                 .getHandlers());
/*      */             }
/*      */           }
/*      */         }
/*      */       } });
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class Undertow
/*      */   {
/*      */     private Integer bufferSize;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private Integer buffersPerRegion;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private Integer ioThreads;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private Integer workerThreads;
/*      */     
/*      */ 
/*      */ 
/*      */     private Boolean directBuffers;
/*      */     
/*      */ 
/*      */ 
/* 1204 */     private final Accesslog accesslog = new Accesslog();
/*      */     
/*      */     public Integer getBufferSize() {
/* 1207 */       return this.bufferSize;
/*      */     }
/*      */     
/*      */     public void setBufferSize(Integer bufferSize) {
/* 1211 */       this.bufferSize = bufferSize;
/*      */     }
/*      */     
/*      */     public Integer getBuffersPerRegion() {
/* 1215 */       return this.buffersPerRegion;
/*      */     }
/*      */     
/*      */     public void setBuffersPerRegion(Integer buffersPerRegion) {
/* 1219 */       this.buffersPerRegion = buffersPerRegion;
/*      */     }
/*      */     
/*      */     public Integer getIoThreads() {
/* 1223 */       return this.ioThreads;
/*      */     }
/*      */     
/*      */     public void setIoThreads(Integer ioThreads) {
/* 1227 */       this.ioThreads = ioThreads;
/*      */     }
/*      */     
/*      */     public Integer getWorkerThreads() {
/* 1231 */       return this.workerThreads;
/*      */     }
/*      */     
/*      */     public void setWorkerThreads(Integer workerThreads) {
/* 1235 */       this.workerThreads = workerThreads;
/*      */     }
/*      */     
/*      */     public Boolean getDirectBuffers() {
/* 1239 */       return this.directBuffers;
/*      */     }
/*      */     
/*      */     public void setDirectBuffers(Boolean directBuffers) {
/* 1243 */       this.directBuffers = directBuffers;
/*      */     }
/*      */     
/*      */     public Accesslog getAccesslog() {
/* 1247 */       return this.accesslog;
/*      */     }
/*      */     
/*      */     void customizeUndertow(ServerProperties serverProperties, UndertowEmbeddedServletContainerFactory factory)
/*      */     {
/* 1252 */       if (this.bufferSize != null) {
/* 1253 */         factory.setBufferSize(this.bufferSize);
/*      */       }
/* 1255 */       if (this.buffersPerRegion != null) {
/* 1256 */         factory.setBuffersPerRegion(this.buffersPerRegion);
/*      */       }
/* 1258 */       if (this.ioThreads != null) {
/* 1259 */         factory.setIoThreads(this.ioThreads);
/*      */       }
/* 1261 */       if (this.workerThreads != null) {
/* 1262 */         factory.setWorkerThreads(this.workerThreads);
/*      */       }
/* 1264 */       if (this.directBuffers != null) {
/* 1265 */         factory.setDirectBuffers(this.directBuffers);
/*      */       }
/* 1267 */       if (this.accesslog.dir != null) {
/* 1268 */         factory.setAccessLogDirectory(this.accesslog.dir);
/*      */       }
/* 1270 */       if (this.accesslog.pattern != null) {
/* 1271 */         factory.setAccessLogPattern(this.accesslog.pattern);
/*      */       }
/* 1273 */       if (this.accesslog.enabled != null) {
/* 1274 */         factory.setAccessLogEnabled(this.accesslog.enabled.booleanValue());
/*      */       }
/* 1276 */       factory.setUseForwardHeaders(serverProperties.getOrDeduceUseForwardHeaders());
/* 1277 */       if (serverProperties.getMaxHttpHeaderSize() > 0) {
/* 1278 */         customizeMaxHttpHeaderSize(factory, serverProperties
/* 1279 */           .getMaxHttpHeaderSize());
/*      */       }
/* 1281 */       if (serverProperties.getMaxHttpPostSize() > 0) {
/* 1282 */         customizeMaxHttpPostSize(factory, serverProperties.getMaxHttpPostSize());
/*      */       }
/*      */       
/* 1285 */       if (serverProperties.getConnectionTimeout() != null) {
/* 1286 */         customizeConnectionTimeout(factory, serverProperties
/* 1287 */           .getConnectionTimeout().intValue());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     private void customizeConnectionTimeout(UndertowEmbeddedServletContainerFactory factory, final int connectionTimeout)
/*      */     {
/* 1294 */       factory.addBuilderCustomizers(new UndertowBuilderCustomizer[] { new UndertowBuilderCustomizer()
/*      */       {
/*      */         public void customize(Undertow.Builder builder) {
/* 1297 */           builder.setSocketOption(UndertowOptions.NO_REQUEST_TIMEOUT, 
/* 1298 */             Integer.valueOf(connectionTimeout));
/*      */         }
/*      */       } });
/*      */     }
/*      */     
/*      */ 
/*      */     private void customizeMaxHttpHeaderSize(UndertowEmbeddedServletContainerFactory factory, final int maxHttpHeaderSize)
/*      */     {
/* 1306 */       factory.addBuilderCustomizers(new UndertowBuilderCustomizer[] { new UndertowBuilderCustomizer()
/*      */       {
/*      */         public void customize(Undertow.Builder builder)
/*      */         {
/* 1310 */           builder.setServerOption(UndertowOptions.MAX_HEADER_SIZE, 
/* 1311 */             Integer.valueOf(maxHttpHeaderSize));
/*      */         }
/*      */       } });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     private void customizeMaxHttpPostSize(UndertowEmbeddedServletContainerFactory factory, final int maxHttpPostSize)
/*      */     {
/* 1320 */       factory.addBuilderCustomizers(new UndertowBuilderCustomizer[] { new UndertowBuilderCustomizer()
/*      */       {
/*      */         public void customize(Undertow.Builder builder)
/*      */         {
/* 1324 */           builder.setServerOption(UndertowOptions.MAX_ENTITY_SIZE, 
/* 1325 */             Long.valueOf(maxHttpPostSize));
/*      */         }
/*      */       } });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public static class Accesslog
/*      */     {
/*      */       private Boolean enabled;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1341 */       private String pattern = "common";
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1346 */       private File dir = new File("logs");
/*      */       
/*      */       public Boolean getEnabled() {
/* 1349 */         return this.enabled;
/*      */       }
/*      */       
/*      */       public void setEnabled(Boolean enabled) {
/* 1353 */         this.enabled = enabled;
/*      */       }
/*      */       
/*      */       public String getPattern() {
/* 1357 */         return this.pattern;
/*      */       }
/*      */       
/*      */       public void setPattern(String pattern) {
/* 1361 */         this.pattern = pattern;
/*      */       }
/*      */       
/*      */       public File getDir() {
/* 1365 */         return this.dir;
/*      */       }
/*      */       
/*      */       public void setDir(File dir) {
/* 1369 */         this.dir = dir;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class SessionConfiguringInitializer
/*      */     implements ServletContextInitializer
/*      */   {
/*      */     private final ServerProperties.Session session;
/*      */     
/*      */ 
/*      */ 
/*      */     SessionConfiguringInitializer(ServerProperties.Session session)
/*      */     {
/* 1386 */       this.session = session;
/*      */     }
/*      */     
/*      */     public void onStartup(ServletContext servletContext) throws ServletException
/*      */     {
/* 1391 */       if (this.session.getTrackingModes() != null) {
/* 1392 */         servletContext.setSessionTrackingModes(this.session.getTrackingModes());
/*      */       }
/* 1394 */       configureSessionCookie(servletContext.getSessionCookieConfig());
/*      */     }
/*      */     
/*      */     private void configureSessionCookie(SessionCookieConfig config) {
/* 1398 */       ServerProperties.Session.Cookie cookie = this.session.getCookie();
/* 1399 */       if (cookie.getName() != null) {
/* 1400 */         config.setName(cookie.getName());
/*      */       }
/* 1402 */       if (cookie.getDomain() != null) {
/* 1403 */         config.setDomain(cookie.getDomain());
/*      */       }
/* 1405 */       if (cookie.getPath() != null) {
/* 1406 */         config.setPath(cookie.getPath());
/*      */       }
/* 1408 */       if (cookie.getComment() != null) {
/* 1409 */         config.setComment(cookie.getComment());
/*      */       }
/* 1411 */       if (cookie.getHttpOnly() != null) {
/* 1412 */         config.setHttpOnly(cookie.getHttpOnly().booleanValue());
/*      */       }
/* 1414 */       if (cookie.getSecure() != null) {
/* 1415 */         config.setSecure(cookie.getSecure().booleanValue());
/*      */       }
/* 1417 */       if (cookie.getMaxAge() != null) {
/* 1418 */         config.setMaxAge(cookie.getMaxAge().intValue());
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\web\ServerProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */