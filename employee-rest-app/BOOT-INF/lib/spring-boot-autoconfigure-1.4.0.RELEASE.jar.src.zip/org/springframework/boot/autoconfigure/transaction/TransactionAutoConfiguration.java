/*    */ package org.springframework.boot.autoconfigure.transaction;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.orm.jpa.JpaBaseConfiguration;
/*    */ import org.springframework.boot.autoconfigure.transaction.jta.JtaAutoConfiguration;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.transaction.PlatformTransactionManager;
/*    */ import org.springframework.transaction.support.TransactionTemplate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration
/*    */ @ConditionalOnClass({TransactionTemplate.class, PlatformTransactionManager.class})
/*    */ @ConditionalOnSingleCandidate(PlatformTransactionManager.class)
/*    */ @AutoConfigureAfter({JtaAutoConfiguration.class, JpaBaseConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class})
/*    */ public class TransactionAutoConfiguration
/*    */ {
/*    */   private final PlatformTransactionManager transactionManager;
/*    */   
/*    */   public TransactionAutoConfiguration(PlatformTransactionManager transactionManager)
/*    */   {
/* 48 */     this.transactionManager = transactionManager;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public TransactionTemplate transactionTemplate() {
/* 54 */     return new TransactionTemplate(this.transactionManager);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\transaction\TransactionAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */