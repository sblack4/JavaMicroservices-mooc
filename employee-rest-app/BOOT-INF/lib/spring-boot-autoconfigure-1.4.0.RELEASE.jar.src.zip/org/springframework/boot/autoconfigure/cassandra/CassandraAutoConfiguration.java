/*     */ package org.springframework.boot.autoconfigure.cassandra;
/*     */ 
/*     */ import com.datastax.driver.core.Cluster;
/*     */ import com.datastax.driver.core.Cluster.Builder;
/*     */ import com.datastax.driver.core.QueryOptions;
/*     */ import com.datastax.driver.core.SocketOptions;
/*     */ import com.datastax.driver.core.policies.LoadBalancingPolicy;
/*     */ import com.datastax.driver.core.policies.ReconnectionPolicy;
/*     */ import com.datastax.driver.core.policies.RetryPolicy;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @ConditionalOnClass({Cluster.class})
/*     */ @EnableConfigurationProperties({CassandraProperties.class})
/*     */ public class CassandraAutoConfiguration
/*     */ {
/*     */   private final CassandraProperties properties;
/*     */   
/*     */   public CassandraAutoConfiguration(CassandraProperties properties)
/*     */   {
/*  50 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public Cluster cluster() {
/*  56 */     CassandraProperties properties = this.properties;
/*     */     
/*     */ 
/*  59 */     Cluster.Builder builder = Cluster.builder().withClusterName(properties.getClusterName()).withPort(properties.getPort());
/*  60 */     if (properties.getUsername() != null) {
/*  61 */       builder.withCredentials(properties.getUsername(), properties.getPassword());
/*     */     }
/*  63 */     if (properties.getCompression() != null) {
/*  64 */       builder.withCompression(properties.getCompression());
/*     */     }
/*  66 */     if (properties.getLoadBalancingPolicy() != null) {
/*  67 */       LoadBalancingPolicy policy = (LoadBalancingPolicy)instantiate(properties.getLoadBalancingPolicy());
/*  68 */       builder.withLoadBalancingPolicy(policy);
/*     */     }
/*  70 */     builder.withQueryOptions(getQueryOptions());
/*  71 */     if (properties.getReconnectionPolicy() != null) {
/*  72 */       ReconnectionPolicy policy = (ReconnectionPolicy)instantiate(properties.getReconnectionPolicy());
/*  73 */       builder.withReconnectionPolicy(policy);
/*     */     }
/*  75 */     if (properties.getRetryPolicy() != null) {
/*  76 */       RetryPolicy policy = (RetryPolicy)instantiate(properties.getRetryPolicy());
/*  77 */       builder.withRetryPolicy(policy);
/*     */     }
/*  79 */     builder.withSocketOptions(getSocketOptions());
/*  80 */     if (properties.isSsl()) {
/*  81 */       builder.withSSL();
/*     */     }
/*  83 */     String points = properties.getContactPoints();
/*  84 */     builder.addContactPoints(StringUtils.commaDelimitedListToStringArray(points));
/*  85 */     return builder.build();
/*     */   }
/*     */   
/*     */   public static <T> T instantiate(Class<T> type) {
/*  89 */     return (T)BeanUtils.instantiate(type);
/*     */   }
/*     */   
/*     */   private QueryOptions getQueryOptions() {
/*  93 */     QueryOptions options = new QueryOptions();
/*  94 */     CassandraProperties properties = this.properties;
/*  95 */     if (properties.getConsistencyLevel() != null) {
/*  96 */       options.setConsistencyLevel(properties.getConsistencyLevel());
/*     */     }
/*  98 */     if (properties.getSerialConsistencyLevel() != null) {
/*  99 */       options.setSerialConsistencyLevel(properties.getSerialConsistencyLevel());
/*     */     }
/* 101 */     options.setFetchSize(properties.getFetchSize());
/* 102 */     return options;
/*     */   }
/*     */   
/*     */   private SocketOptions getSocketOptions() {
/* 106 */     SocketOptions options = new SocketOptions();
/* 107 */     options.setConnectTimeoutMillis(this.properties.getConnectTimeoutMillis());
/* 108 */     options.setReadTimeoutMillis(this.properties.getReadTimeoutMillis());
/* 109 */     return options;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\cassandra\CassandraAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */