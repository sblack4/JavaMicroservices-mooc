/*     */ package org.springframework.boot.autoconfigure.jackson;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonInclude.Include;
/*     */ import com.fasterxml.jackson.core.JsonGenerator.Feature;
/*     */ import com.fasterxml.jackson.core.JsonParser.Feature;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.DeprecatedConfigurationProperty;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.jackson")
/*     */ public class JacksonProperties
/*     */ {
/*     */   private String dateFormat;
/*     */   private String jodaDateTimeFormat;
/*     */   private String propertyNamingStrategy;
/*  67 */   private Map<SerializationFeature, Boolean> serialization = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  72 */   private Map<DeserializationFeature, Boolean> deserialization = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  77 */   private Map<MapperFeature, Boolean> mapper = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  82 */   private Map<JsonParser.Feature, Boolean> parser = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  87 */   private Map<JsonGenerator.Feature, Boolean> generator = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JsonInclude.Include defaultPropertyInclusion;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */   private TimeZone timeZone = null;
/*     */   
/*     */ 
/*     */   private Locale locale;
/*     */   
/*     */ 
/*     */   public String getDateFormat()
/*     */   {
/* 107 */     return this.dateFormat;
/*     */   }
/*     */   
/*     */   public void setDateFormat(String dateFormat) {
/* 111 */     this.dateFormat = dateFormat;
/*     */   }
/*     */   
/*     */   public String getJodaDateTimeFormat() {
/* 115 */     return this.jodaDateTimeFormat;
/*     */   }
/*     */   
/*     */   public void setJodaDateTimeFormat(String jodaDataTimeFormat) {
/* 119 */     this.jodaDateTimeFormat = jodaDataTimeFormat;
/*     */   }
/*     */   
/*     */   public String getPropertyNamingStrategy() {
/* 123 */     return this.propertyNamingStrategy;
/*     */   }
/*     */   
/*     */   public void setPropertyNamingStrategy(String propertyNamingStrategy) {
/* 127 */     this.propertyNamingStrategy = propertyNamingStrategy;
/*     */   }
/*     */   
/*     */   public Map<SerializationFeature, Boolean> getSerialization() {
/* 131 */     return this.serialization;
/*     */   }
/*     */   
/*     */   public Map<DeserializationFeature, Boolean> getDeserialization() {
/* 135 */     return this.deserialization;
/*     */   }
/*     */   
/*     */   public Map<MapperFeature, Boolean> getMapper() {
/* 139 */     return this.mapper;
/*     */   }
/*     */   
/*     */   public Map<JsonParser.Feature, Boolean> getParser() {
/* 143 */     return this.parser;
/*     */   }
/*     */   
/*     */   public Map<JsonGenerator.Feature, Boolean> getGenerator() {
/* 147 */     return this.generator;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   @DeprecatedConfigurationProperty(reason="ObjectMapper.setSerializationInclusion was deprecated in Jackson 2.7", replacement="spring.jackson.default-property-inclusion")
/*     */   public JsonInclude.Include getSerializationInclusion() {
/* 153 */     return getDefaultPropertyInclusion();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void setSerializationInclusion(JsonInclude.Include serializationInclusion) {
/* 158 */     setDefaultPropertyInclusion(serializationInclusion);
/*     */   }
/*     */   
/*     */   public JsonInclude.Include getDefaultPropertyInclusion() {
/* 162 */     return this.defaultPropertyInclusion;
/*     */   }
/*     */   
/*     */   public void setDefaultPropertyInclusion(JsonInclude.Include defaultPropertyInclusion)
/*     */   {
/* 167 */     this.defaultPropertyInclusion = defaultPropertyInclusion;
/*     */   }
/*     */   
/*     */   public TimeZone getTimeZone() {
/* 171 */     return this.timeZone;
/*     */   }
/*     */   
/*     */   public void setTimeZone(TimeZone timeZone) {
/* 175 */     this.timeZone = timeZone;
/*     */   }
/*     */   
/*     */   public Locale getLocale() {
/* 179 */     return this.locale;
/*     */   }
/*     */   
/*     */   public void setLocale(Locale locale) {
/* 183 */     this.locale = locale;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jackson\JacksonProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */