/*     */ package org.springframework.boot.autoconfigure.cache;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.cache")
/*     */ public class CacheProperties
/*     */ {
/*     */   private CacheType type;
/*  45 */   private List<String> cacheNames = new ArrayList();
/*     */   
/*  47 */   private final Caffeine caffeine = new Caffeine();
/*     */   
/*  49 */   private final Couchbase couchbase = new Couchbase();
/*     */   
/*  51 */   private final EhCache ehcache = new EhCache();
/*     */   
/*  53 */   private final Hazelcast hazelcast = new Hazelcast();
/*     */   
/*  55 */   private final Infinispan infinispan = new Infinispan();
/*     */   
/*  57 */   private final JCache jcache = new JCache();
/*     */   
/*  59 */   private final Guava guava = new Guava();
/*     */   
/*     */   public CacheType getType() {
/*  62 */     return this.type;
/*     */   }
/*     */   
/*     */   public void setType(CacheType mode) {
/*  66 */     this.type = mode;
/*     */   }
/*     */   
/*     */   public List<String> getCacheNames() {
/*  70 */     return this.cacheNames;
/*     */   }
/*     */   
/*     */   public void setCacheNames(List<String> cacheNames) {
/*  74 */     this.cacheNames = cacheNames;
/*     */   }
/*     */   
/*     */   public Caffeine getCaffeine() {
/*  78 */     return this.caffeine;
/*     */   }
/*     */   
/*     */   public Couchbase getCouchbase() {
/*  82 */     return this.couchbase;
/*     */   }
/*     */   
/*     */   public EhCache getEhcache() {
/*  86 */     return this.ehcache;
/*     */   }
/*     */   
/*     */   public Hazelcast getHazelcast() {
/*  90 */     return this.hazelcast;
/*     */   }
/*     */   
/*     */   public Infinispan getInfinispan() {
/*  94 */     return this.infinispan;
/*     */   }
/*     */   
/*     */   public JCache getJcache() {
/*  98 */     return this.jcache;
/*     */   }
/*     */   
/*     */   public Guava getGuava() {
/* 102 */     return this.guava;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Resource resolveConfigLocation(Resource config)
/*     */   {
/* 113 */     if (config != null) {
/* 114 */       Assert.isTrue(config.exists(), "Cache configuration does not exist '" + config
/* 115 */         .getDescription() + "'");
/* 116 */       return config;
/*     */     }
/* 118 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Caffeine
/*     */   {
/*     */     private String spec;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getSpec()
/*     */     {
/* 133 */       return this.spec;
/*     */     }
/*     */     
/*     */     public void setSpec(String spec) {
/* 137 */       this.spec = spec;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Couchbase
/*     */   {
/*     */     private int expiration;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getExpiration()
/*     */     {
/* 153 */       return this.expiration;
/*     */     }
/*     */     
/*     */     public void setExpiration(int expiration) {
/* 157 */       this.expiration = expiration;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class EhCache
/*     */   {
/*     */     private Resource config;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Resource getConfig()
/*     */     {
/* 173 */       return this.config;
/*     */     }
/*     */     
/*     */     public void setConfig(Resource config) {
/* 177 */       this.config = config;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Hazelcast
/*     */   {
/*     */     private Resource config;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Resource getConfig()
/*     */     {
/* 193 */       return this.config;
/*     */     }
/*     */     
/*     */     public void setConfig(Resource config) {
/* 197 */       this.config = config;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Infinispan
/*     */   {
/*     */     private Resource config;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Resource getConfig()
/*     */     {
/* 213 */       return this.config;
/*     */     }
/*     */     
/*     */     public void setConfig(Resource config) {
/* 217 */       this.config = config;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class JCache
/*     */   {
/*     */     private Resource config;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private String provider;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getProvider()
/*     */     {
/* 241 */       return this.provider;
/*     */     }
/*     */     
/*     */     public void setProvider(String provider) {
/* 245 */       this.provider = provider;
/*     */     }
/*     */     
/*     */     public Resource getConfig() {
/* 249 */       return this.config;
/*     */     }
/*     */     
/*     */     public void setConfig(Resource config) {
/* 253 */       this.config = config;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Guava
/*     */   {
/*     */     private String spec;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getSpec()
/*     */     {
/* 270 */       return this.spec;
/*     */     }
/*     */     
/*     */     public void setSpec(String spec) {
/* 274 */       this.spec = spec;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\cache\CacheProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */