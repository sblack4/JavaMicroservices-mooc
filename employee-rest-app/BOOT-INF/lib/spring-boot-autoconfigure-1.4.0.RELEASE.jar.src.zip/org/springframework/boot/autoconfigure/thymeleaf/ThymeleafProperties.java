/*     */ package org.springframework.boot.autoconfigure.thymeleaf;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.util.MimeType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.thymeleaf")
/*     */ public class ThymeleafProperties
/*     */ {
/*  33 */   private static final Charset DEFAULT_ENCODING = Charset.forName("UTF-8");
/*     */   
/*  35 */   private static final MimeType DEFAULT_CONTENT_TYPE = MimeType.valueOf("text/html");
/*     */   
/*     */ 
/*     */   public static final String DEFAULT_PREFIX = "classpath:/templates/";
/*     */   
/*     */ 
/*     */   public static final String DEFAULT_SUFFIX = ".html";
/*     */   
/*     */ 
/*  44 */   private boolean checkTemplateLocation = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  49 */   private String prefix = "classpath:/templates/";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  54 */   private String suffix = ".html";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  59 */   private String mode = "HTML5";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  64 */   private Charset encoding = DEFAULT_ENCODING;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  69 */   private MimeType contentType = DEFAULT_CONTENT_TYPE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  74 */   private boolean cache = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Integer templateResolverOrder;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String[] viewNames;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String[] excludedViewNames;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  96 */   private boolean enabled = true;
/*     */   
/*     */   public boolean isEnabled() {
/*  99 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/* 103 */     this.enabled = enabled;
/*     */   }
/*     */   
/*     */   public boolean isCheckTemplateLocation() {
/* 107 */     return this.checkTemplateLocation;
/*     */   }
/*     */   
/*     */   public void setCheckTemplateLocation(boolean checkTemplateLocation) {
/* 111 */     this.checkTemplateLocation = checkTemplateLocation;
/*     */   }
/*     */   
/*     */   public String getPrefix() {
/* 115 */     return this.prefix;
/*     */   }
/*     */   
/*     */   public void setPrefix(String prefix) {
/* 119 */     this.prefix = prefix;
/*     */   }
/*     */   
/*     */   public String getSuffix() {
/* 123 */     return this.suffix;
/*     */   }
/*     */   
/*     */   public void setSuffix(String suffix) {
/* 127 */     this.suffix = suffix;
/*     */   }
/*     */   
/*     */   public String getMode() {
/* 131 */     return this.mode;
/*     */   }
/*     */   
/*     */   public void setMode(String mode) {
/* 135 */     this.mode = mode;
/*     */   }
/*     */   
/*     */   public Charset getEncoding() {
/* 139 */     return this.encoding;
/*     */   }
/*     */   
/*     */   public void setEncoding(Charset encoding) {
/* 143 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */   public MimeType getContentType() {
/* 147 */     return this.contentType;
/*     */   }
/*     */   
/*     */   public void setContentType(MimeType contentType) {
/* 151 */     this.contentType = contentType;
/*     */   }
/*     */   
/*     */   public boolean isCache() {
/* 155 */     return this.cache;
/*     */   }
/*     */   
/*     */   public void setCache(boolean cache) {
/* 159 */     this.cache = cache;
/*     */   }
/*     */   
/*     */   public Integer getTemplateResolverOrder() {
/* 163 */     return this.templateResolverOrder;
/*     */   }
/*     */   
/*     */   public void setTemplateResolverOrder(Integer templateResolverOrder) {
/* 167 */     this.templateResolverOrder = templateResolverOrder;
/*     */   }
/*     */   
/*     */   public String[] getExcludedViewNames() {
/* 171 */     return this.excludedViewNames;
/*     */   }
/*     */   
/*     */   public void setExcludedViewNames(String[] excludedViewNames) {
/* 175 */     this.excludedViewNames = excludedViewNames;
/*     */   }
/*     */   
/*     */   public String[] getViewNames() {
/* 179 */     return this.viewNames;
/*     */   }
/*     */   
/*     */   public void setViewNames(String[] viewNames) {
/* 183 */     this.viewNames = viewNames;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\thymeleaf\ThymeleafProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */