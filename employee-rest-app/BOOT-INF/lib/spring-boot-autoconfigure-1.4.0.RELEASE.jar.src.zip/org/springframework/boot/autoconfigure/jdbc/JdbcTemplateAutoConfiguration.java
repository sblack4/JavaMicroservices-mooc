/*    */ package org.springframework.boot.autoconfigure.jdbc;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.jdbc.core.JdbcOperations;
/*    */ import org.springframework.jdbc.core.JdbcTemplate;
/*    */ import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
/*    */ import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration
/*    */ @ConditionalOnClass({DataSource.class})
/*    */ @ConditionalOnSingleCandidate(DataSource.class)
/*    */ @AutoConfigureAfter({DataSourceAutoConfiguration.class})
/*    */ public class JdbcTemplateAutoConfiguration
/*    */ {
/*    */   private final DataSource dataSource;
/*    */   
/*    */   public JdbcTemplateAutoConfiguration(DataSource dataSource)
/*    */   {
/* 52 */     this.dataSource = dataSource;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean({JdbcOperations.class})
/*    */   public JdbcTemplate jdbcTemplate() {
/* 58 */     return new JdbcTemplate(this.dataSource);
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean({NamedParameterJdbcOperations.class})
/*    */   public NamedParameterJdbcTemplate namedParameterJdbcTemplate() {
/* 64 */     return new NamedParameterJdbcTemplate(this.dataSource);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jdbc\JdbcTemplateAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */