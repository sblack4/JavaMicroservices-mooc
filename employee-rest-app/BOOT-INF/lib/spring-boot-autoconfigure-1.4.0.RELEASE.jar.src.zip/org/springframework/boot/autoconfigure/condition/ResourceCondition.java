/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import org.springframework.boot.bind.RelaxedPropertyResolver;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ResourceCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   private final String name;
/*    */   private final String prefix;
/*    */   private final String propertyName;
/*    */   private final String[] resourceLocations;
/*    */   
/*    */   protected ResourceCondition(String name, String prefix, String propertyName, String... resourceLocations)
/*    */   {
/* 52 */     this.name = name;
/* 53 */     this.prefix = (prefix + ".");
/* 54 */     this.propertyName = propertyName;
/* 55 */     this.resourceLocations = resourceLocations;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 62 */     RelaxedPropertyResolver resolver = new RelaxedPropertyResolver(context.getEnvironment(), this.prefix);
/* 63 */     if (resolver.containsProperty(this.propertyName)) {
/* 64 */       return ConditionOutcome.match("A '" + this.prefix + this.propertyName + "' " + "property is specified");
/*    */     }
/*    */     
/* 67 */     return getResourceOutcome(context, metadata);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected ConditionOutcome getResourceOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 78 */     for (String location : this.resourceLocations) {
/* 79 */       Resource resource = context.getResourceLoader().getResource(location);
/* 80 */       if ((resource != null) && (resource.exists()))
/*    */       {
/* 82 */         return ConditionOutcome.match("Found " + this.name + " config in " + resource);
/*    */       }
/*    */     }
/*    */     
/* 86 */     return ConditionOutcome.noMatch("No specific " + this.name + " configuration found");
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\condition\ResourceCondition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */