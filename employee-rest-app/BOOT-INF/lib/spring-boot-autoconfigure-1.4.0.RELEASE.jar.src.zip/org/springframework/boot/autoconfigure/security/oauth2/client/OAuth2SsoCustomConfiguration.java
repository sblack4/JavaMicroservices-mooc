/*     */ package org.springframework.boot.autoconfigure.security.oauth2.client;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*     */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.ImportAware;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @Conditional({WebSecurityEnhancerCondition.class})
/*     */ public class OAuth2SsoCustomConfiguration
/*     */   implements ImportAware, BeanPostProcessor, ApplicationContextAware
/*     */ {
/*     */   private Class<?> configType;
/*     */   private ApplicationContext applicationContext;
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext)
/*     */   {
/*  62 */     this.applicationContext = applicationContext;
/*     */   }
/*     */   
/*     */   public void setImportMetadata(AnnotationMetadata importMetadata)
/*     */   {
/*  67 */     this.configType = ClassUtils.resolveClassName(importMetadata.getClassName(), null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object postProcessBeforeInitialization(Object bean, String beanName)
/*     */     throws BeansException
/*     */   {
/*  75 */     return bean;
/*     */   }
/*     */   
/*     */   public Object postProcessAfterInitialization(Object bean, String beanName)
/*     */     throws BeansException
/*     */   {
/*  81 */     if ((this.configType.isAssignableFrom(bean.getClass())) && ((bean instanceof WebSecurityConfigurerAdapter)))
/*     */     {
/*  83 */       ProxyFactory factory = new ProxyFactory();
/*  84 */       factory.setTarget(bean);
/*  85 */       factory.addAdvice(new SsoSecurityAdapter(this.applicationContext));
/*  86 */       bean = factory.getProxy();
/*     */     }
/*  88 */     return bean;
/*     */   }
/*     */   
/*     */   private static class SsoSecurityAdapter implements MethodInterceptor
/*     */   {
/*     */     private SsoSecurityConfigurer configurer;
/*     */     
/*     */     SsoSecurityAdapter(ApplicationContext applicationContext) {
/*  96 */       this.configurer = new SsoSecurityConfigurer(applicationContext);
/*     */     }
/*     */     
/*     */     public Object invoke(MethodInvocation invocation) throws Throwable
/*     */     {
/* 101 */       if (invocation.getMethod().getName().equals("init"))
/*     */       {
/* 103 */         Method method = ReflectionUtils.findMethod(WebSecurityConfigurerAdapter.class, "getHttp");
/* 104 */         ReflectionUtils.makeAccessible(method);
/* 105 */         HttpSecurity http = (HttpSecurity)ReflectionUtils.invokeMethod(method, invocation
/* 106 */           .getThis());
/* 107 */         this.configurer.configure(http);
/*     */       }
/* 109 */       return invocation.proceed();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected static class WebSecurityEnhancerCondition
/*     */     extends SpringBootCondition
/*     */   {
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*     */     {
/* 120 */       String[] enablers = context.getBeanFactory().getBeanNamesForAnnotation(EnableOAuth2Sso.class);
/* 121 */       for (String name : enablers) {
/* 122 */         if (context.getBeanFactory().isTypeMatch(name, WebSecurityConfigurerAdapter.class))
/*     */         {
/* 124 */           return ConditionOutcome.match("found @EnableOAuth2Sso on a WebSecurityConfigurerAdapter");
/*     */         }
/*     */       }
/*     */       
/* 128 */       return ConditionOutcome.noMatch("found no @EnableOAuth2Sso on a WebSecurityConfigurerAdapter");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\security\oauth2\client\OAuth2SsoCustomConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */