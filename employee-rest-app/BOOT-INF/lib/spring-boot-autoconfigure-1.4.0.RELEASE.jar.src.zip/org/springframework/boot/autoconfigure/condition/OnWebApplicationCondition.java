/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.annotation.Order;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ import org.springframework.web.context.WebApplicationContext;
/*    */ import org.springframework.web.context.support.StandardServletEnvironment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Order(-2147483628)
/*    */ class OnWebApplicationCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   private static final String WEB_CONTEXT_CLASS = "org.springframework.web.context.support.GenericWebApplicationContext";
/*    */   
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 47 */     boolean webApplicationRequired = metadata.isAnnotated(ConditionalOnWebApplication.class.getName());
/* 48 */     ConditionOutcome webApplication = isWebApplication(context, metadata);
/*    */     
/* 50 */     if ((webApplicationRequired) && (!webApplication.isMatch())) {
/* 51 */       return ConditionOutcome.noMatch(webApplication.getMessage());
/*    */     }
/*    */     
/* 54 */     if ((!webApplicationRequired) && (webApplication.isMatch())) {
/* 55 */       return ConditionOutcome.noMatch(webApplication.getMessage());
/*    */     }
/*    */     
/* 58 */     return ConditionOutcome.match(webApplication.getMessage());
/*    */   }
/*    */   
/*    */ 
/*    */   private ConditionOutcome isWebApplication(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 64 */     if (!ClassUtils.isPresent("org.springframework.web.context.support.GenericWebApplicationContext", context.getClassLoader())) {
/* 65 */       return ConditionOutcome.noMatch("web application classes not found");
/*    */     }
/*    */     
/* 68 */     if (context.getBeanFactory() != null) {
/* 69 */       String[] scopes = context.getBeanFactory().getRegisteredScopeNames();
/* 70 */       if (ObjectUtils.containsElement(scopes, "session")) {
/* 71 */         return ConditionOutcome.match("found web application 'session' scope");
/*    */       }
/*    */     }
/*    */     
/* 75 */     if ((context.getEnvironment() instanceof StandardServletEnvironment))
/*    */     {
/* 77 */       return ConditionOutcome.match("found web application StandardServletEnvironment");
/*    */     }
/*    */     
/* 80 */     if ((context.getResourceLoader() instanceof WebApplicationContext)) {
/* 81 */       return ConditionOutcome.match("found web application WebApplicationContext");
/*    */     }
/*    */     
/* 84 */     return ConditionOutcome.noMatch("not a web application");
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\condition\OnWebApplicationCondition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */