/*    */ package org.springframework.boot.autoconfigure.session;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.annotation.PostConstruct;
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.jdbc.datasource.init.DatabasePopulatorUtils;
/*    */ import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
/*    */ import org.springframework.jdbc.support.JdbcUtils;
/*    */ import org.springframework.jdbc.support.MetaDataAccessException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JdbcSessionDatabaseInitializer
/*    */ {
/*    */   private static Map<String, String> ALIASES;
/*    */   private SessionProperties properties;
/*    */   private DataSource dataSource;
/*    */   private ResourceLoader resourceLoader;
/*    */   
/*    */   static
/*    */   {
/* 44 */     Map<String, String> aliases = new HashMap();
/* 45 */     aliases.put("hsql", "hsqldb");
/* 46 */     aliases.put("postgres", "postgresql");
/* 47 */     ALIASES = Collections.unmodifiableMap(aliases);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public JdbcSessionDatabaseInitializer(SessionProperties properties, DataSource dataSource, ResourceLoader resourceLoader)
/*    */   {
/* 58 */     Assert.notNull(properties, "SessionProperties must not be null");
/* 59 */     Assert.notNull(dataSource, "DataSource must not be null");
/* 60 */     Assert.notNull(resourceLoader, "ResourceLoader must not be null");
/* 61 */     this.properties = properties;
/* 62 */     this.dataSource = dataSource;
/* 63 */     this.resourceLoader = resourceLoader;
/*    */   }
/*    */   
/*    */   @PostConstruct
/*    */   protected void initialize() {
/* 68 */     if (this.properties.getJdbc().getInitializer().isEnabled()) {
/* 69 */       ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
/* 70 */       String schemaLocation = this.properties.getJdbc().getSchema();
/* 71 */       schemaLocation = schemaLocation.replace("@@platform@@", getPlatform());
/* 72 */       populator.addScript(this.resourceLoader.getResource(schemaLocation));
/* 73 */       populator.setContinueOnError(true);
/* 74 */       DatabasePopulatorUtils.execute(populator, this.dataSource);
/*    */     }
/*    */   }
/*    */   
/*    */   private String getPlatform() {
/* 79 */     String databaseName = getDatabaseName();
/* 80 */     if (ALIASES.containsKey(databaseName)) {
/* 81 */       return (String)ALIASES.get(databaseName);
/*    */     }
/* 83 */     return databaseName;
/*    */   }
/*    */   
/*    */   private String getDatabaseName()
/*    */   {
/*    */     try
/*    */     {
/* 90 */       String databaseProductName = JdbcUtils.extractDatabaseMetaData(this.dataSource, "getDatabaseProductName").toString();
/* 91 */       return JdbcUtils.commonDatabaseName(databaseProductName).toLowerCase();
/*    */     }
/*    */     catch (MetaDataAccessException ex) {
/* 94 */       throw new IllegalStateException("Unable to detect database type", ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\session\JdbcSessionDatabaseInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */