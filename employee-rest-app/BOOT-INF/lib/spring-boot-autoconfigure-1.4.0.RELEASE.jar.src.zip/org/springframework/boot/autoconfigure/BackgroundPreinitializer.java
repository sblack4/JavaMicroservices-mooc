/*     */ package org.springframework.boot.autoconfigure;
/*     */ 
/*     */ import javax.validation.Validation;
/*     */ import javax.validation.bootstrap.GenericBootstrap;
/*     */ import org.apache.catalina.mbeans.MBeanFactory;
/*     */ import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.format.support.DefaultFormattingConversionService;
/*     */ import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
/*     */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Order(-2147483627)
/*     */ public class BackgroundPreinitializer
/*     */   implements ApplicationListener<ApplicationEnvironmentPreparedEvent>
/*     */ {
/*     */   public void onApplicationEvent(ApplicationEnvironmentPreparedEvent event)
/*     */   {
/*     */     try
/*     */     {
/*  46 */       Thread thread = new Thread(new Runnable()
/*     */       {
/*     */         public void run()
/*     */         {
/*  50 */           runSafely(new BackgroundPreinitializer.MessageConverterInitializer(null));
/*  51 */           runSafely(new BackgroundPreinitializer.MBeanFactoryInitializer(null));
/*  52 */           runSafely(new BackgroundPreinitializer.ValidationInitializer(null));
/*  53 */           runSafely(new BackgroundPreinitializer.JacksonInitializer(null));
/*  54 */           runSafely(new BackgroundPreinitializer.ConversionServiceInitializer(null));
/*     */         }
/*     */         
/*     */         public void runSafely(Runnable runnable) {
/*     */           try {
/*  59 */             runnable.run(); } catch (Throwable localThrowable) {} } }, "background-preinit");
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */       thread.start();
/*     */     }
/*     */     catch (Exception localException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class MessageConverterInitializer
/*     */     implements Runnable
/*     */   {
/*     */     public void run()
/*     */     {
/*  83 */       new AllEncompassingFormHttpMessageConverter();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class MBeanFactoryInitializer
/*     */     implements Runnable
/*     */   {
/*     */     public void run()
/*     */     {
/*  95 */       new MBeanFactory();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class ValidationInitializer
/*     */     implements Runnable
/*     */   {
/*     */     public void run()
/*     */     {
/* 107 */       Validation.byDefaultProvider().configure();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class JacksonInitializer
/*     */     implements Runnable
/*     */   {
/*     */     public void run()
/*     */     {
/* 119 */       Jackson2ObjectMapperBuilder.json().build();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class ConversionServiceInitializer
/*     */     implements Runnable
/*     */   {
/*     */     public void run()
/*     */     {
/* 131 */       new DefaultFormattingConversionService();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\BackgroundPreinitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */