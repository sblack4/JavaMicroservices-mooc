/*     */ package org.springframework.boot.autoconfigure.jooq;
/*     */ 
/*     */ import javax.sql.DataSource;
/*     */ import org.jooq.ConnectionProvider;
/*     */ import org.jooq.DSLContext;
/*     */ import org.jooq.ExecuteListenerProvider;
/*     */ import org.jooq.RecordListenerProvider;
/*     */ import org.jooq.RecordMapperProvider;
/*     */ import org.jooq.TransactionProvider;
/*     */ import org.jooq.VisitListenerProvider;
/*     */ import org.jooq.conf.Settings;
/*     */ import org.jooq.impl.DataSourceConnectionProvider;
/*     */ import org.jooq.impl.DefaultConfiguration;
/*     */ import org.jooq.impl.DefaultDSLContext;
/*     */ import org.jooq.impl.DefaultExecuteListenerProvider;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.jdbc.datasource.TransactionAwareDataSourceProxy;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @org.springframework.context.annotation.Configuration
/*     */ @ConditionalOnClass({DSLContext.class})
/*     */ @ConditionalOnBean({DataSource.class})
/*     */ @AutoConfigureAfter({DataSourceAutoConfiguration.class})
/*     */ public class JooqAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({DataSourceConnectionProvider.class})
/*     */   public DataSourceConnectionProvider dataSourceConnectionProvider(DataSource dataSource)
/*     */   {
/*  63 */     return new DataSourceConnectionProvider(new TransactionAwareDataSourceProxy(dataSource));
/*     */   }
/*     */   
/*     */ 
/*     */   @Bean
/*     */   @ConditionalOnBean({PlatformTransactionManager.class})
/*     */   public SpringTransactionProvider transactionProvider(PlatformTransactionManager txManager)
/*     */   {
/*  71 */     return new SpringTransactionProvider(txManager);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   public DefaultExecuteListenerProvider jooqExceptionTranslatorExecuteListenerProvider() {
/*  76 */     return new DefaultExecuteListenerProvider(new JooqExceptionTranslator());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @org.springframework.context.annotation.Configuration
/*     */   @ConditionalOnMissingBean({DSLContext.class})
/*     */   @EnableConfigurationProperties({JooqProperties.class})
/*     */   public static class DslContextConfiguration
/*     */   {
/*     */     private final JooqProperties properties;
/*     */     
/*     */ 
/*     */     private final ConnectionProvider connectionProvider;
/*     */     
/*     */ 
/*     */     private final TransactionProvider transactionProvider;
/*     */     
/*     */ 
/*     */     private final RecordMapperProvider recordMapperProvider;
/*     */     
/*     */     private final Settings settings;
/*     */     
/*     */     private final RecordListenerProvider[] recordListenerProviders;
/*     */     
/*     */     private final ExecuteListenerProvider[] executeListenerProviders;
/*     */     
/*     */     private final VisitListenerProvider[] visitListenerProviders;
/*     */     
/*     */ 
/*     */     public DslContextConfiguration(JooqProperties properties, ConnectionProvider connectionProvider, ObjectProvider<TransactionProvider> transactionProviderProvider, ObjectProvider<RecordMapperProvider> recordMapperProviderProvider, ObjectProvider<Settings> settingsProvider, ObjectProvider<RecordListenerProvider[]> recordListenerProvidersProvider, ExecuteListenerProvider[] executeListenerProviders, ObjectProvider<VisitListenerProvider[]> visitListenerProvidersProvider)
/*     */     {
/* 108 */       this.properties = properties;
/* 109 */       this.connectionProvider = connectionProvider;
/* 110 */       this.transactionProvider = ((TransactionProvider)transactionProviderProvider.getIfAvailable());
/* 111 */       this.recordMapperProvider = ((RecordMapperProvider)recordMapperProviderProvider.getIfAvailable());
/* 112 */       this.settings = ((Settings)settingsProvider.getIfAvailable());
/*     */       
/* 114 */       this.recordListenerProviders = ((RecordListenerProvider[])recordListenerProvidersProvider.getIfAvailable());
/* 115 */       this.executeListenerProviders = executeListenerProviders;
/* 116 */       this.visitListenerProviders = ((VisitListenerProvider[])visitListenerProvidersProvider.getIfAvailable());
/*     */     }
/*     */     
/*     */     @Bean
/*     */     public DefaultDSLContext dslContext(org.jooq.Configuration configuration) {
/* 121 */       return new DefaultDSLContext(configuration);
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({org.jooq.Configuration.class})
/*     */     public DefaultConfiguration jooqConfiguration() {
/* 127 */       DefaultConfiguration configuration = new DefaultConfiguration();
/* 128 */       if (this.properties.getSqlDialect() != null) {
/* 129 */         configuration.set(this.properties.getSqlDialect());
/*     */       }
/* 131 */       configuration.set(this.connectionProvider);
/* 132 */       if (this.transactionProvider != null) {
/* 133 */         configuration.set(this.transactionProvider);
/*     */       }
/* 135 */       if (this.recordMapperProvider != null) {
/* 136 */         configuration.set(this.recordMapperProvider);
/*     */       }
/* 138 */       if (this.settings != null) {
/* 139 */         configuration.set(this.settings);
/*     */       }
/* 141 */       configuration.set(this.recordListenerProviders);
/* 142 */       configuration.set(this.executeListenerProviders);
/* 143 */       configuration.set(this.visitListenerProviders);
/* 144 */       return configuration;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jooq\JooqAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */