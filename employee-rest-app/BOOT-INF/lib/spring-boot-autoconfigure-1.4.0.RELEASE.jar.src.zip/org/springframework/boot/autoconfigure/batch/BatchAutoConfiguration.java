/*     */ package org.springframework.boot.autoconfigure.batch;
/*     */ 
/*     */ import javax.persistence.EntityManagerFactory;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.batch.core.configuration.ListableJobLocator;
/*     */ import org.springframework.batch.core.configuration.annotation.BatchConfigurer;
/*     */ import org.springframework.batch.core.converter.JobParametersConverter;
/*     */ import org.springframework.batch.core.explore.JobExplorer;
/*     */ import org.springframework.batch.core.explore.support.JobExplorerFactoryBean;
/*     */ import org.springframework.batch.core.launch.JobLauncher;
/*     */ import org.springframework.batch.core.launch.JobOperator;
/*     */ import org.springframework.batch.core.launch.support.SimpleJobOperator;
/*     */ import org.springframework.batch.core.repository.JobRepository;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.ExitCodeGenerator;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.jdbc.core.JdbcOperations;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @ConditionalOnClass({JobLauncher.class, DataSource.class, JdbcOperations.class})
/*     */ @AutoConfigureAfter({HibernateJpaAutoConfiguration.class})
/*     */ @ConditionalOnBean({JobLauncher.class})
/*     */ @EnableConfigurationProperties({BatchProperties.class})
/*     */ public class BatchAutoConfiguration
/*     */ {
/*     */   private final BatchProperties properties;
/*     */   private final JobParametersConverter jobParametersConverter;
/*     */   
/*     */   public BatchAutoConfiguration(BatchProperties properties, ObjectProvider<JobParametersConverter> jobParametersConverterProvider)
/*     */   {
/*  73 */     this.properties = properties;
/*  74 */     this.jobParametersConverter = ((JobParametersConverter)jobParametersConverterProvider.getIfAvailable());
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   @ConditionalOnBean({DataSource.class})
/*     */   public BatchDatabaseInitializer batchDatabaseInitializer() {
/*  81 */     return new BatchDatabaseInitializer();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   @ConditionalOnProperty(prefix="spring.batch.job", name={"enabled"}, havingValue="true", matchIfMissing=true)
/*     */   public JobLauncherCommandLineRunner jobLauncherCommandLineRunner(JobLauncher jobLauncher, JobExplorer jobExplorer)
/*     */   {
/*  89 */     JobLauncherCommandLineRunner runner = new JobLauncherCommandLineRunner(jobLauncher, jobExplorer);
/*     */     
/*  91 */     String jobNames = this.properties.getJob().getNames();
/*  92 */     if (StringUtils.hasText(jobNames)) {
/*  93 */       runner.setJobNames(jobNames);
/*     */     }
/*  95 */     return runner;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({ExitCodeGenerator.class})
/*     */   public JobExecutionExitCodeGenerator jobExecutionExitCodeGenerator() {
/* 101 */     return new JobExecutionExitCodeGenerator();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   @ConditionalOnBean({DataSource.class})
/*     */   public JobExplorer jobExplorer(DataSource dataSource) throws Exception {
/* 108 */     JobExplorerFactoryBean factory = new JobExplorerFactoryBean();
/* 109 */     factory.setDataSource(dataSource);
/* 110 */     String tablePrefix = this.properties.getTablePrefix();
/* 111 */     if (StringUtils.hasText(tablePrefix)) {
/* 112 */       factory.setTablePrefix(tablePrefix);
/*     */     }
/* 114 */     factory.afterPropertiesSet();
/* 115 */     return factory.getObject();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({JobOperator.class})
/*     */   public SimpleJobOperator jobOperator(JobExplorer jobExplorer, JobLauncher jobLauncher, ListableJobLocator jobRegistry, JobRepository jobRepository)
/*     */     throws Exception
/*     */   {
/* 123 */     SimpleJobOperator factory = new SimpleJobOperator();
/* 124 */     factory.setJobExplorer(jobExplorer);
/* 125 */     factory.setJobLauncher(jobLauncher);
/* 126 */     factory.setJobRegistry(jobRegistry);
/* 127 */     factory.setJobRepository(jobRepository);
/* 128 */     if (this.jobParametersConverter != null) {
/* 129 */       factory.setJobParametersConverter(this.jobParametersConverter);
/*     */     }
/* 131 */     return factory;
/*     */   }
/*     */   
/*     */   @ConditionalOnClass(name={"javax.persistence.EntityManagerFactory"})
/*     */   @ConditionalOnMissingBean({BatchConfigurer.class})
/*     */   @Configuration
/*     */   protected static class JpaBatchConfiguration
/*     */   {
/*     */     private final BatchProperties properties;
/*     */     
/*     */     protected JpaBatchConfiguration(BatchProperties properties) {
/* 142 */       this.properties = properties;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     @Bean
/*     */     @ConditionalOnBean(name={"entityManagerFactory"})
/*     */     public BasicBatchConfigurer jpaBatchConfigurer(DataSource dataSource, EntityManagerFactory entityManagerFactory)
/*     */     {
/* 152 */       return new BasicBatchConfigurer(this.properties, dataSource, entityManagerFactory);
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean(name={"entityManagerFactory"})
/*     */     public BasicBatchConfigurer basicBatchConfigurer(DataSource dataSource)
/*     */     {
/* 159 */       return new BasicBatchConfigurer(this.properties, dataSource);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\batch\BatchAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */