/*     */ package org.springframework.boot.autoconfigure.jms.hornetq;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.hornetq.jms.server.config.JMSConfiguration;
/*     */ import org.hornetq.jms.server.config.JMSQueueConfiguration;
/*     */ import org.hornetq.jms.server.config.TopicConfiguration;
/*     */ import org.hornetq.jms.server.config.impl.JMSConfigurationImpl;
/*     */ import org.hornetq.jms.server.config.impl.JMSQueueConfigurationImpl;
/*     */ import org.hornetq.jms.server.config.impl.TopicConfigurationImpl;
/*     */ import org.hornetq.jms.server.embedded.EmbeddedJMS;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @org.springframework.context.annotation.Configuration
/*     */ @ConditionalOnClass(name={"org.hornetq.jms.server.embedded.EmbeddedJMS"})
/*     */ @ConditionalOnProperty(prefix="spring.hornetq.embedded", name={"enabled"}, havingValue="true", matchIfMissing=true)
/*     */ @Deprecated
/*     */ class HornetQEmbeddedServerConfiguration
/*     */ {
/*     */   private final HornetQProperties properties;
/*     */   private final List<HornetQConfigurationCustomizer> configurationCustomizers;
/*     */   private final List<JMSQueueConfiguration> queuesConfiguration;
/*     */   private final List<TopicConfiguration> topicsConfiguration;
/*     */   
/*     */   HornetQEmbeddedServerConfiguration(HornetQProperties properties, ObjectProvider<List<HornetQConfigurationCustomizer>> configurationCustomizersProvider, ObjectProvider<List<JMSQueueConfiguration>> queuesConfigurationProvider, ObjectProvider<List<TopicConfiguration>> topicsConfigurationProvider)
/*     */   {
/*  64 */     this.properties = properties;
/*  65 */     this.configurationCustomizers = ((List)configurationCustomizersProvider.getIfAvailable());
/*  66 */     this.queuesConfiguration = ((List)queuesConfigurationProvider.getIfAvailable());
/*  67 */     this.topicsConfiguration = ((List)topicsConfigurationProvider.getIfAvailable());
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public org.hornetq.core.config.Configuration hornetQConfiguration()
/*     */   {
/*  74 */     return new HornetQEmbeddedConfigurationFactory(this.properties).createConfiguration();
/*     */   }
/*     */   
/*     */   @Bean(initMethod="start", destroyMethod="stop")
/*     */   @ConditionalOnMissingBean
/*     */   public EmbeddedJMS hornetQServer(org.hornetq.core.config.Configuration configuration, JMSConfiguration jmsConfiguration)
/*     */   {
/*  81 */     EmbeddedJMS server = new EmbeddedJMS();
/*  82 */     customize(configuration);
/*  83 */     server.setConfiguration(configuration);
/*  84 */     server.setJmsConfiguration(jmsConfiguration);
/*  85 */     server.setRegistry(new HornetQNoOpBindingRegistry());
/*  86 */     return server;
/*     */   }
/*     */   
/*     */   private void customize(org.hornetq.core.config.Configuration configuration) {
/*  90 */     if (this.configurationCustomizers != null) {
/*  91 */       AnnotationAwareOrderComparator.sort(this.configurationCustomizers);
/*  92 */       for (HornetQConfigurationCustomizer customizer : this.configurationCustomizers) {
/*  93 */         customizer.customize(configuration);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public JMSConfiguration hornetQJmsConfiguration() {
/* 101 */     JMSConfiguration configuration = new JMSConfigurationImpl();
/* 102 */     addAll(configuration.getQueueConfigurations(), this.queuesConfiguration);
/* 103 */     addAll(configuration.getTopicConfigurations(), this.topicsConfiguration);
/* 104 */     addQueues(configuration, this.properties.getEmbedded().getQueues());
/* 105 */     addTopics(configuration, this.properties.getEmbedded().getTopics());
/* 106 */     return configuration;
/*     */   }
/*     */   
/*     */   private <T> void addAll(List<T> list, Collection<? extends T> items) {
/* 110 */     if (items != null) {
/* 111 */       list.addAll(items);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addQueues(JMSConfiguration configuration, String[] queues) {
/* 116 */     boolean persistent = this.properties.getEmbedded().isPersistent();
/* 117 */     for (String queue : queues) {
/* 118 */       configuration.getQueueConfigurations().add(new JMSQueueConfigurationImpl(queue, null, persistent, new String[] { "/queue/" + queue }));
/*     */     }
/*     */   }
/*     */   
/*     */   private void addTopics(JMSConfiguration configuration, String[] topics)
/*     */   {
/* 124 */     for (String topic : topics)
/*     */     {
/* 126 */       configuration.getTopicConfigurations().add(new TopicConfigurationImpl(topic, new String[] { "/topic/" + topic }));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jms\hornetq\HornetQEmbeddedServerConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */