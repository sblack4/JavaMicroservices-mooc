/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Order(Integer.MIN_VALUE)
/*     */ class OnClassCondition
/*     */   extends SpringBootCondition
/*     */ {
/*     */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*     */   {
/*  47 */     StringBuilder matchMessage = new StringBuilder();
/*     */     
/*  49 */     MultiValueMap<String, Object> onClasses = getAttributes(metadata, ConditionalOnClass.class);
/*     */     
/*  51 */     if (onClasses != null) {
/*  52 */       List<String> missing = getMatchingClasses(onClasses, MatchType.MISSING, context);
/*     */       
/*  54 */       if (!missing.isEmpty())
/*     */       {
/*  56 */         return ConditionOutcome.noMatch("required @ConditionalOnClass classes not found: " + 
/*  57 */           StringUtils.collectionToCommaDelimitedString(missing));
/*     */       }
/*     */       
/*  60 */       matchMessage.append("@ConditionalOnClass classes found: ").append(StringUtils.collectionToCommaDelimitedString(
/*  61 */         getMatchingClasses(onClasses, MatchType.PRESENT, context)));
/*     */     }
/*     */     
/*  64 */     MultiValueMap<String, Object> onMissingClasses = getAttributes(metadata, ConditionalOnMissingClass.class);
/*     */     
/*  66 */     if (onMissingClasses != null) {
/*  67 */       List<String> present = getMatchingClasses(onMissingClasses, MatchType.PRESENT, context);
/*     */       
/*  69 */       if (!present.isEmpty())
/*     */       {
/*  71 */         return ConditionOutcome.noMatch("required @ConditionalOnMissing classes found: " + 
/*  72 */           StringUtils.collectionToCommaDelimitedString(present));
/*     */       }
/*  74 */       matchMessage.append(matchMessage.length() == 0 ? "" : " ");
/*  75 */       matchMessage.append("@ConditionalOnMissing classes not found: ")
/*  76 */         .append(StringUtils.collectionToCommaDelimitedString(
/*  77 */         getMatchingClasses(onMissingClasses, MatchType.MISSING, context)));
/*     */     }
/*     */     
/*     */ 
/*  81 */     return ConditionOutcome.match(matchMessage.toString());
/*     */   }
/*     */   
/*     */   private MultiValueMap<String, Object> getAttributes(AnnotatedTypeMetadata metadata, Class<?> annotationType)
/*     */   {
/*  86 */     return metadata.getAllAnnotationAttributes(annotationType.getName(), true);
/*     */   }
/*     */   
/*     */   private List<String> getMatchingClasses(MultiValueMap<String, Object> attributes, MatchType matchType, ConditionContext context)
/*     */   {
/*  91 */     List<String> matches = new LinkedList();
/*  92 */     addAll(matches, (List)attributes.get("value"));
/*  93 */     addAll(matches, (List)attributes.get("name"));
/*  94 */     Iterator<String> iterator = matches.iterator();
/*  95 */     while (iterator.hasNext()) {
/*  96 */       if (!matchType.matches((String)iterator.next(), context)) {
/*  97 */         iterator.remove();
/*     */       }
/*     */     }
/* 100 */     return matches;
/*     */   }
/*     */   
/*     */   private void addAll(List<String> list, List<Object> itemsToAdd) {
/* 104 */     if (itemsToAdd != null) {
/* 105 */       for (Object item : itemsToAdd) {
/* 106 */         Collections.addAll(list, (String[])item);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static abstract enum MatchType
/*     */   {
/* 113 */     PRESENT, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 120 */     MISSING;
/*     */     
/*     */     private MatchType() {}
/*     */     
/*     */     public abstract boolean matches(String paramString, ConditionContext paramConditionContext);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\condition\OnClassCondition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */