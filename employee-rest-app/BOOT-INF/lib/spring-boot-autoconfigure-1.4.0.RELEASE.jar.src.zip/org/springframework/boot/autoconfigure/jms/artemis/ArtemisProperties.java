/*     */ package org.springframework.boot.autoconfigure.jms.artemis;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.artemis")
/*     */ public class ArtemisProperties
/*     */ {
/*     */   private ArtemisMode mode;
/*  47 */   private String host = "localhost";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  52 */   private int port = 61616;
/*     */   
/*     */ 
/*     */ 
/*     */   private String user;
/*     */   
/*     */ 
/*     */ 
/*     */   private String password;
/*     */   
/*     */ 
/*     */ 
/*  64 */   private final Embedded embedded = new Embedded();
/*     */   
/*     */   public ArtemisMode getMode() {
/*  67 */     return this.mode;
/*     */   }
/*     */   
/*     */   public void setMode(ArtemisMode mode) {
/*  71 */     this.mode = mode;
/*     */   }
/*     */   
/*     */   public String getHost() {
/*  75 */     return this.host;
/*     */   }
/*     */   
/*     */   public void setHost(String host) {
/*  79 */     this.host = host;
/*     */   }
/*     */   
/*     */   public int getPort() {
/*  83 */     return this.port;
/*     */   }
/*     */   
/*     */   public void setPort(int port) {
/*  87 */     this.port = port;
/*     */   }
/*     */   
/*     */   public String getUser() {
/*  91 */     return this.user;
/*     */   }
/*     */   
/*     */   public void setUser(String user) {
/*  95 */     this.user = user;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/*  99 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 103 */     this.password = password;
/*     */   }
/*     */   
/*     */   public Embedded getEmbedded() {
/* 107 */     return this.embedded;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Embedded
/*     */   {
/* 115 */     private static final AtomicInteger serverIdCounter = new AtomicInteger();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 120 */     private int serverId = serverIdCounter.getAndIncrement();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 125 */     private boolean enabled = true;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private boolean persistent;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private String dataDirectory;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 140 */     private String[] queues = new String[0];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 145 */     private String[] topics = new String[0];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 150 */     private String clusterPassword = UUID.randomUUID().toString();
/*     */     
/* 152 */     private boolean defaultClusterPassword = true;
/*     */     
/*     */     public int getServerId() {
/* 155 */       return this.serverId;
/*     */     }
/*     */     
/*     */     public void setServerId(int serverId) {
/* 159 */       this.serverId = serverId;
/*     */     }
/*     */     
/*     */     public boolean isEnabled() {
/* 163 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 167 */       this.enabled = enabled;
/*     */     }
/*     */     
/*     */     public boolean isPersistent() {
/* 171 */       return this.persistent;
/*     */     }
/*     */     
/*     */     public void setPersistent(boolean persistent) {
/* 175 */       this.persistent = persistent;
/*     */     }
/*     */     
/*     */     public String getDataDirectory() {
/* 179 */       return this.dataDirectory;
/*     */     }
/*     */     
/*     */     public void setDataDirectory(String dataDirectory) {
/* 183 */       this.dataDirectory = dataDirectory;
/*     */     }
/*     */     
/*     */     public String[] getQueues() {
/* 187 */       return this.queues;
/*     */     }
/*     */     
/*     */     public void setQueues(String[] queues) {
/* 191 */       this.queues = queues;
/*     */     }
/*     */     
/*     */     public String[] getTopics() {
/* 195 */       return this.topics;
/*     */     }
/*     */     
/*     */     public void setTopics(String[] topics) {
/* 199 */       this.topics = topics;
/*     */     }
/*     */     
/*     */     public String getClusterPassword() {
/* 203 */       return this.clusterPassword;
/*     */     }
/*     */     
/*     */     public void setClusterPassword(String clusterPassword) {
/* 207 */       this.clusterPassword = clusterPassword;
/* 208 */       this.defaultClusterPassword = false;
/*     */     }
/*     */     
/*     */     public boolean isDefaultClusterPassword() {
/* 212 */       return this.defaultClusterPassword;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Map<String, Object> generateTransportParameters()
/*     */     {
/* 222 */       Map<String, Object> parameters = new HashMap();
/* 223 */       parameters.put("serverId", Integer.valueOf(getServerId()));
/* 224 */       return parameters;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jms\artemis\ArtemisProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */