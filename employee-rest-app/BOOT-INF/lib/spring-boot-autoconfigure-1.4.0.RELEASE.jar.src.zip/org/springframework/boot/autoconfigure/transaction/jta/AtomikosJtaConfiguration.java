/*     */ package org.springframework.boot.autoconfigure.transaction.jta;
/*     */ 
/*     */ import com.atomikos.icatch.config.UserTransactionService;
/*     */ import com.atomikos.icatch.config.UserTransactionServiceImp;
/*     */ import com.atomikos.icatch.jta.UserTransactionManager;
/*     */ import java.io.File;
/*     */ import java.util.Properties;
/*     */ import javax.jms.Message;
/*     */ import javax.transaction.TransactionManager;
/*     */ import javax.transaction.UserTransaction;
/*     */ import org.springframework.boot.ApplicationHome;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.jta.XAConnectionFactoryWrapper;
/*     */ import org.springframework.boot.jta.XADataSourceWrapper;
/*     */ import org.springframework.boot.jta.atomikos.AtomikosDependsOnBeanFactoryPostProcessor;
/*     */ import org.springframework.boot.jta.atomikos.AtomikosProperties;
/*     */ import org.springframework.boot.jta.atomikos.AtomikosXAConnectionFactoryWrapper;
/*     */ import org.springframework.boot.jta.atomikos.AtomikosXADataSourceWrapper;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ import org.springframework.transaction.jta.JtaTransactionManager;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @EnableConfigurationProperties({AtomikosProperties.class})
/*     */ @ConditionalOnClass({JtaTransactionManager.class, UserTransactionManager.class})
/*     */ @ConditionalOnMissingBean({PlatformTransactionManager.class})
/*     */ class AtomikosJtaConfiguration
/*     */ {
/*     */   private final JtaProperties jtaProperties;
/*     */   
/*     */   AtomikosJtaConfiguration(JtaProperties jtaProperties)
/*     */   {
/*  64 */     this.jtaProperties = jtaProperties;
/*     */   }
/*     */   
/*     */   @Bean(initMethod="init", destroyMethod="shutdownForce")
/*     */   @ConditionalOnMissingBean({UserTransactionService.class})
/*     */   public UserTransactionServiceImp userTransactionService(AtomikosProperties atomikosProperties)
/*     */   {
/*  71 */     Properties properties = new Properties();
/*  72 */     if (StringUtils.hasText(this.jtaProperties.getTransactionManagerId())) {
/*  73 */       properties.setProperty("com.atomikos.icatch.tm_unique_name", this.jtaProperties
/*  74 */         .getTransactionManagerId());
/*     */     }
/*  76 */     properties.setProperty("com.atomikos.icatch.log_base_dir", getLogBaseDir());
/*  77 */     properties.putAll(atomikosProperties.asProperties());
/*  78 */     return new UserTransactionServiceImp(properties);
/*     */   }
/*     */   
/*     */   private String getLogBaseDir() {
/*  82 */     if (StringUtils.hasLength(this.jtaProperties.getLogDir())) {
/*  83 */       return this.jtaProperties.getLogDir();
/*     */     }
/*  85 */     File home = new ApplicationHome().getDir();
/*  86 */     return new File(home, "transaction-logs").getAbsolutePath();
/*     */   }
/*     */   
/*     */   @Bean(initMethod="init", destroyMethod="close")
/*     */   @ConditionalOnMissingBean
/*     */   public UserTransactionManager atomikosTransactionManager(UserTransactionService userTransactionService) throws Exception
/*     */   {
/*  93 */     UserTransactionManager manager = new UserTransactionManager();
/*  94 */     manager.setStartupTransactionService(false);
/*  95 */     manager.setForceShutdown(true);
/*  96 */     return manager;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({XADataSourceWrapper.class})
/*     */   public AtomikosXADataSourceWrapper xaDataSourceWrapper() {
/* 102 */     return new AtomikosXADataSourceWrapper();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public static AtomikosDependsOnBeanFactoryPostProcessor atomikosDependsOnBeanFactoryPostProcessor() {
/* 108 */     return new AtomikosDependsOnBeanFactoryPostProcessor();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   public JtaTransactionManager transactionManager(UserTransaction userTransaction, TransactionManager transactionManager)
/*     */   {
/* 114 */     return new JtaTransactionManager(userTransaction, transactionManager);
/*     */   }
/*     */   
/*     */   @Configuration
/*     */   @ConditionalOnClass({Message.class})
/*     */   static class AtomikosJtaJmsConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({XAConnectionFactoryWrapper.class})
/*     */     public AtomikosXAConnectionFactoryWrapper xaConnectionFactoryWrapper() {
/* 124 */       return new AtomikosXAConnectionFactoryWrapper();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\transaction\jta\AtomikosJtaConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */