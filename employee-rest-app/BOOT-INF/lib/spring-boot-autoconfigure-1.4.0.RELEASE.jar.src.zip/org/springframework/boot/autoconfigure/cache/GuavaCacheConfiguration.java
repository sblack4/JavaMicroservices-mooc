/*    */ package org.springframework.boot.autoconfigure.cache;
/*    */ 
/*    */ import com.google.common.cache.CacheBuilder;
/*    */ import com.google.common.cache.CacheBuilderSpec;
/*    */ import com.google.common.cache.CacheLoader;
/*    */ import java.util.List;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.cache.CacheManager;
/*    */ import org.springframework.cache.guava.GuavaCacheManager;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration
/*    */ @ConditionalOnClass({CacheBuilder.class, GuavaCacheManager.class})
/*    */ @ConditionalOnMissingBean({CacheManager.class})
/*    */ @Conditional({CacheCondition.class})
/*    */ class GuavaCacheConfiguration
/*    */ {
/*    */   private final CacheProperties cacheProperties;
/*    */   private final CacheManagerCustomizers customizers;
/*    */   private final CacheBuilder<Object, Object> cacheBuilder;
/*    */   private final CacheBuilderSpec cacheBuilderSpec;
/*    */   private final CacheLoader<Object, Object> cacheLoader;
/*    */   
/*    */   GuavaCacheConfiguration(CacheProperties cacheProperties, CacheManagerCustomizers customizers, ObjectProvider<CacheBuilder<Object, Object>> cacheBuilderProvider, ObjectProvider<CacheBuilderSpec> cacheBuilderSpecProvider, ObjectProvider<CacheLoader<Object, Object>> cacheLoaderProvider)
/*    */   {
/* 63 */     this.cacheProperties = cacheProperties;
/* 64 */     this.customizers = customizers;
/* 65 */     this.cacheBuilder = ((CacheBuilder)cacheBuilderProvider.getIfAvailable());
/* 66 */     this.cacheBuilderSpec = ((CacheBuilderSpec)cacheBuilderSpecProvider.getIfAvailable());
/* 67 */     this.cacheLoader = ((CacheLoader)cacheLoaderProvider.getIfAvailable());
/*    */   }
/*    */   
/*    */   @Bean
/*    */   public GuavaCacheManager cacheManager() {
/* 72 */     GuavaCacheManager cacheManager = createCacheManager();
/* 73 */     List<String> cacheNames = this.cacheProperties.getCacheNames();
/* 74 */     if (!CollectionUtils.isEmpty(cacheNames)) {
/* 75 */       cacheManager.setCacheNames(cacheNames);
/*    */     }
/* 77 */     return (GuavaCacheManager)this.customizers.customize(cacheManager);
/*    */   }
/*    */   
/*    */   private GuavaCacheManager createCacheManager() {
/* 81 */     GuavaCacheManager cacheManager = new GuavaCacheManager();
/* 82 */     setCacheBuilder(cacheManager);
/* 83 */     if (this.cacheLoader != null) {
/* 84 */       cacheManager.setCacheLoader(this.cacheLoader);
/*    */     }
/* 86 */     return cacheManager;
/*    */   }
/*    */   
/*    */   private void setCacheBuilder(GuavaCacheManager cacheManager) {
/* 90 */     String specification = this.cacheProperties.getGuava().getSpec();
/* 91 */     if (StringUtils.hasText(specification)) {
/* 92 */       cacheManager.setCacheSpecification(specification);
/*    */     }
/* 94 */     else if (this.cacheBuilderSpec != null) {
/* 95 */       cacheManager.setCacheBuilderSpec(this.cacheBuilderSpec);
/*    */     }
/* 97 */     else if (this.cacheBuilder != null) {
/* 98 */       cacheManager.setCacheBuilder(this.cacheBuilder);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\cache\GuavaCacheConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */