/*     */ package org.springframework.boot.autoconfigure.mongo;
/*     */ 
/*     */ import com.mongodb.MongoClient;
/*     */ import com.mongodb.MongoClientOptions;
/*     */ import com.mongodb.MongoClientOptions.Builder;
/*     */ import com.mongodb.MongoClientURI;
/*     */ import com.mongodb.MongoCredential;
/*     */ import com.mongodb.ServerAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.core.env.Environment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.data.mongodb")
/*     */ public class MongoProperties
/*     */ {
/*     */   public static final int DEFAULT_PORT = 27017;
/*     */   private String host;
/*  61 */   private Integer port = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  66 */   private String uri = "mongodb://localhost/test";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String database;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String authenticationDatabase;
/*     */   
/*     */ 
/*     */ 
/*     */   private String gridFsDatabase;
/*     */   
/*     */ 
/*     */ 
/*     */   private String username;
/*     */   
/*     */ 
/*     */ 
/*     */   private char[] password;
/*     */   
/*     */ 
/*     */ 
/*     */   private Class<?> fieldNamingStrategy;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHost()
/*     */   {
/*  99 */     return this.host;
/*     */   }
/*     */   
/*     */   public void setHost(String host) {
/* 103 */     this.host = host;
/*     */   }
/*     */   
/*     */   public String getDatabase() {
/* 107 */     return this.database;
/*     */   }
/*     */   
/*     */   public void setDatabase(String database) {
/* 111 */     this.database = database;
/*     */   }
/*     */   
/*     */   public String getAuthenticationDatabase() {
/* 115 */     return this.authenticationDatabase;
/*     */   }
/*     */   
/*     */   public void setAuthenticationDatabase(String authenticationDatabase) {
/* 119 */     this.authenticationDatabase = authenticationDatabase;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/* 123 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/* 127 */     this.username = username;
/*     */   }
/*     */   
/*     */   public char[] getPassword() {
/* 131 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(char[] password) {
/* 135 */     this.password = password;
/*     */   }
/*     */   
/*     */   public Class<?> getFieldNamingStrategy() {
/* 139 */     return this.fieldNamingStrategy;
/*     */   }
/*     */   
/*     */   public void setFieldNamingStrategy(Class<?> fieldNamingStrategy) {
/* 143 */     this.fieldNamingStrategy = fieldNamingStrategy;
/*     */   }
/*     */   
/*     */   public void clearPassword() {
/* 147 */     if (this.password == null) {
/* 148 */       return;
/*     */     }
/* 150 */     for (int i = 0; i < this.password.length; i++) {
/* 151 */       this.password[i] = '\000';
/*     */     }
/*     */   }
/*     */   
/*     */   public String getUri() {
/* 156 */     return this.uri;
/*     */   }
/*     */   
/*     */   public void setUri(String uri) {
/* 160 */     this.uri = uri;
/*     */   }
/*     */   
/*     */   public Integer getPort() {
/* 164 */     return this.port;
/*     */   }
/*     */   
/*     */   public void setPort(Integer port) {
/* 168 */     this.port = port;
/*     */   }
/*     */   
/*     */   public String getGridFsDatabase() {
/* 172 */     return this.gridFsDatabase;
/*     */   }
/*     */   
/*     */   public void setGridFsDatabase(String gridFsDatabase) {
/* 176 */     this.gridFsDatabase = gridFsDatabase;
/*     */   }
/*     */   
/*     */   public String getMongoClientDatabase() {
/* 180 */     if (this.database != null) {
/* 181 */       return this.database;
/*     */     }
/* 183 */     return new MongoClientURI(this.uri).getDatabase();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MongoClient createMongoClient(MongoClientOptions options, Environment environment)
/*     */     throws UnknownHostException
/*     */   {
/*     */     try
/*     */     {
/*     */       List<MongoCredential> credentials;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 200 */       if ((hasCustomAddress()) || (hasCustomCredentials())) {
/* 201 */         if (options == null) {
/* 202 */           options = MongoClientOptions.builder().build();
/*     */         }
/* 204 */         credentials = new ArrayList();
/* 205 */         if (hasCustomCredentials())
/*     */         {
/* 207 */           String database = this.authenticationDatabase == null ? getMongoClientDatabase() : this.authenticationDatabase;
/* 208 */           credentials.add(MongoCredential.createCredential(this.username, database, this.password));
/*     */         }
/*     */         
/* 211 */         String host = this.host == null ? "localhost" : this.host;
/* 212 */         int port = determinePort(environment);
/*     */         
/* 214 */         return new MongoClient(Collections.singletonList(new ServerAddress(host, port)), credentials, options);
/*     */       }
/*     */       
/*     */ 
/* 218 */       return new MongoClient(new MongoClientURI(this.uri, builder(options)));
/*     */     }
/*     */     finally {
/* 221 */       clearPassword();
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean hasCustomAddress() {
/* 226 */     return (this.host != null) || (this.port != null);
/*     */   }
/*     */   
/*     */   private boolean hasCustomCredentials() {
/* 230 */     return (this.username != null) && (this.password != null);
/*     */   }
/*     */   
/*     */   private int determinePort(Environment environment) {
/* 234 */     if (this.port == null) {
/* 235 */       return 27017;
/*     */     }
/* 237 */     if (this.port.intValue() == 0) {
/* 238 */       if (environment != null) {
/* 239 */         String localPort = environment.getProperty("local.mongo.port");
/* 240 */         if (localPort != null) {
/* 241 */           return Integer.valueOf(localPort).intValue();
/*     */         }
/*     */       }
/* 244 */       throw new IllegalStateException("spring.data.mongodb.port=0 and no local mongo port configuration is available");
/*     */     }
/*     */     
/*     */ 
/* 248 */     return this.port.intValue();
/*     */   }
/*     */   
/*     */   private MongoClientOptions.Builder builder(MongoClientOptions options) {
/* 252 */     if (options != null) {
/* 253 */       return MongoClientOptions.builder(options);
/*     */     }
/* 255 */     return MongoClientOptions.builder();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\mongo\MongoProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */