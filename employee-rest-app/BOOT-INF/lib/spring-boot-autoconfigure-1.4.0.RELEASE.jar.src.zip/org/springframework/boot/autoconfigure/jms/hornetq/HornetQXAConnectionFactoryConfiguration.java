/*    */ package org.springframework.boot.autoconfigure.jms.hornetq;
/*    */ 
/*    */ import javax.jms.ConnectionFactory;
/*    */ import javax.transaction.TransactionManager;
/*    */ import org.hornetq.jms.client.HornetQConnectionFactory;
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.jta.XAConnectionFactoryWrapper;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Primary;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration
/*    */ @ConditionalOnMissingBean({ConnectionFactory.class})
/*    */ @ConditionalOnClass({TransactionManager.class})
/*    */ @ConditionalOnBean({XAConnectionFactoryWrapper.class})
/*    */ @Deprecated
/*    */ class HornetQXAConnectionFactoryConfiguration
/*    */ {
/*    */   @Primary
/*    */   @Bean(name={"jmsConnectionFactory", "xaJmsConnectionFactory"})
/*    */   public ConnectionFactory jmsConnectionFactory(ListableBeanFactory beanFactory, HornetQProperties properties, XAConnectionFactoryWrapper wrapper)
/*    */     throws Exception
/*    */   {
/* 52 */     return wrapper.wrapConnectionFactory(new HornetQConnectionFactoryFactory(beanFactory, properties)
/*    */     
/* 54 */       .createConnectionFactory(SpringBootHornetQXAConnectionFactory.class));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @Bean
/*    */   public HornetQConnectionFactory nonXaJmsConnectionFactory(ListableBeanFactory beanFactory, HornetQProperties properties)
/*    */   {
/* 62 */     return new HornetQConnectionFactoryFactory(beanFactory, properties).createConnectionFactory(SpringBootHornetQConnectionFactory.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jms\hornetq\HornetQXAConnectionFactoryConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */