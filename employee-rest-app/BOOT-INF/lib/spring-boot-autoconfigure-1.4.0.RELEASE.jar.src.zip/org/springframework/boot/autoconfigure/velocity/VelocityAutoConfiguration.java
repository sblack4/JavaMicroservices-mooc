/*     */ package org.springframework.boot.autoconfigure.velocity;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Properties;
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.servlet.Servlet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.velocity.app.VelocityEngine;
/*     */ import org.apache.velocity.exception.VelocityException;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnNotWebApplication;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.autoconfigure.template.TemplateLocation;
/*     */ import org.springframework.boot.autoconfigure.web.ConditionalOnEnabledResourceChain;
/*     */ import org.springframework.boot.autoconfigure.web.WebMvcAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.web.servlet.view.velocity.EmbeddedVelocityViewResolver;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.ui.velocity.VelocityEngineFactory;
/*     */ import org.springframework.ui.velocity.VelocityEngineFactoryBean;
/*     */ import org.springframework.web.servlet.resource.ResourceUrlEncodingFilter;
/*     */ import org.springframework.web.servlet.view.velocity.VelocityConfig;
/*     */ import org.springframework.web.servlet.view.velocity.VelocityConfigurer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @ConditionalOnClass({VelocityEngine.class, VelocityEngineFactory.class})
/*     */ @AutoConfigureAfter({WebMvcAutoConfiguration.class})
/*     */ @EnableConfigurationProperties({VelocityProperties.class})
/*     */ @Deprecated
/*     */ public class VelocityAutoConfiguration
/*     */ {
/*  68 */   private static final Log logger = LogFactory.getLog(VelocityAutoConfiguration.class);
/*     */   
/*     */   private final ApplicationContext applicationContext;
/*     */   
/*     */   private final VelocityProperties properties;
/*     */   
/*     */   public VelocityAutoConfiguration(ApplicationContext applicationContext, VelocityProperties properties)
/*     */   {
/*  76 */     this.applicationContext = applicationContext;
/*  77 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   @PostConstruct
/*     */   public void checkTemplateLocationExists() {
/*  82 */     if (this.properties.isCheckTemplateLocation())
/*     */     {
/*  84 */       TemplateLocation location = new TemplateLocation(this.properties.getResourceLoaderPath());
/*  85 */       if (!location.exists(this.applicationContext)) {
/*  86 */         logger.warn("Cannot find template location: " + location + " (please add some templates, check your Velocity " + "configuration, or set spring.velocity." + "checkTemplateLocation=false)");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   @Deprecated
/*     */   protected static class VelocityConfiguration
/*     */   {
/*     */     @Autowired
/*     */     protected VelocityProperties properties;
/*     */     
/*     */ 
/*     */     protected void applyProperties(VelocityEngineFactory factory)
/*     */     {
/* 101 */       factory.setResourceLoaderPath(this.properties.getResourceLoaderPath());
/* 102 */       factory.setPreferFileSystemAccess(this.properties.isPreferFileSystemAccess());
/* 103 */       Properties velocityProperties = new Properties();
/* 104 */       velocityProperties.setProperty("input.encoding", this.properties
/* 105 */         .getCharsetName());
/* 106 */       velocityProperties.putAll(this.properties.getProperties());
/* 107 */       factory.setVelocityProperties(velocityProperties);
/*     */     }
/*     */   }
/*     */   
/*     */   @Configuration
/*     */   @ConditionalOnNotWebApplication
/*     */   @Deprecated
/*     */   public static class VelocityNonWebConfiguration extends VelocityAutoConfiguration.VelocityConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     public VelocityEngineFactoryBean velocityConfiguration()
/*     */     {
/* 120 */       VelocityEngineFactoryBean velocityEngineFactoryBean = new VelocityEngineFactoryBean();
/* 121 */       applyProperties(velocityEngineFactoryBean);
/* 122 */       return velocityEngineFactoryBean;
/*     */     }
/*     */   }
/*     */   
/*     */   @Configuration
/*     */   @ConditionalOnClass({Servlet.class})
/*     */   @ConditionalOnWebApplication
/*     */   @Deprecated
/*     */   public static class VelocityWebConfiguration extends VelocityAutoConfiguration.VelocityConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({VelocityConfig.class})
/*     */     public VelocityConfigurer velocityConfigurer()
/*     */     {
/* 136 */       VelocityConfigurer configurer = new VelocityConfigurer();
/* 137 */       applyProperties(configurer);
/* 138 */       return configurer;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     public VelocityEngine velocityEngine(VelocityConfigurer configurer) throws VelocityException, IOException
/*     */     {
/* 144 */       return configurer.getVelocityEngine();
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean(name={"velocityViewResolver"})
/*     */     @ConditionalOnProperty(name={"spring.velocity.enabled"}, matchIfMissing=true)
/*     */     public EmbeddedVelocityViewResolver velocityViewResolver() {
/* 151 */       EmbeddedVelocityViewResolver resolver = new EmbeddedVelocityViewResolver();
/* 152 */       this.properties.applyToViewResolver(resolver);
/* 153 */       return resolver;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     @ConditionalOnEnabledResourceChain
/*     */     public ResourceUrlEncodingFilter resourceUrlEncodingFilter() {
/* 160 */       return new ResourceUrlEncodingFilter();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\velocity\VelocityAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */