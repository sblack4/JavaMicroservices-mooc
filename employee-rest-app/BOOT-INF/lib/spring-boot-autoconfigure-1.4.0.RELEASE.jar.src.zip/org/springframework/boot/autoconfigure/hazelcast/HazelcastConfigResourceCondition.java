/*    */ package org.springframework.boot.autoconfigure.hazelcast;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*    */ import org.springframework.boot.autoconfigure.condition.ResourceCondition;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class HazelcastConfigResourceCondition
/*    */   extends ResourceCondition
/*    */ {
/*    */   static final String CONFIG_SYSTEM_PROPERTY = "hazelcast.config";
/*    */   
/*    */   protected HazelcastConfigResourceCondition(String prefix, String propertyName)
/*    */   {
/* 38 */     super("Hazelcast", prefix, propertyName, new String[] { "file:./hazelcast.xml", "classpath:/hazelcast.xml" });
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected ConditionOutcome getResourceOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 45 */     if (System.getProperty("hazelcast.config") != null)
/*    */     {
/* 47 */       return ConditionOutcome.match("System property 'hazelcast.config' is set.");
/*    */     }
/* 49 */     return super.getResourceOutcome(context, metadata);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastConfigResourceCondition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */