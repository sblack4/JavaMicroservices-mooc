/*     */ package org.springframework.boot.autoconfigure.cache;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import javax.cache.Caching;
/*     */ import javax.cache.configuration.MutableConfiguration;
/*     */ import javax.cache.spi.CachingProvider;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*     */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*     */ import org.springframework.boot.bind.RelaxedPropertyResolver;
/*     */ import org.springframework.cache.jcache.JCacheCacheManager;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.ConfigurationCondition.ConfigurationPhase;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @org.springframework.context.annotation.Configuration
/*     */ @ConditionalOnClass({Caching.class, JCacheCacheManager.class})
/*     */ @ConditionalOnMissingBean({org.springframework.cache.CacheManager.class})
/*     */ @Conditional({CacheCondition.class, JCacheAvailableCondition.class})
/*     */ class JCacheCacheConfiguration
/*     */ {
/*     */   private final CacheProperties cacheProperties;
/*     */   private final CacheManagerCustomizers customizers;
/*     */   private final javax.cache.configuration.Configuration<?, ?> defaultCacheConfiguration;
/*     */   private final List<JCacheManagerCustomizer> cacheManagerCustomizers;
/*     */   
/*     */   JCacheCacheConfiguration(CacheProperties cacheProperties, CacheManagerCustomizers customizers, ObjectProvider<javax.cache.configuration.Configuration<?, ?>> defaultCacheConfigurationProvider, ObjectProvider<List<JCacheManagerCustomizer>> cacheManagerCustomizersProvider)
/*     */   {
/*  75 */     this.cacheProperties = cacheProperties;
/*  76 */     this.customizers = customizers;
/*     */     
/*  78 */     this.defaultCacheConfiguration = ((javax.cache.configuration.Configuration)defaultCacheConfigurationProvider.getIfAvailable());
/*  79 */     this.cacheManagerCustomizers = ((List)cacheManagerCustomizersProvider.getIfAvailable());
/*     */   }
/*     */   
/*     */   @Bean
/*     */   public JCacheCacheManager cacheManager(javax.cache.CacheManager jCacheCacheManager) {
/*  84 */     JCacheCacheManager cacheManager = new JCacheCacheManager(jCacheCacheManager);
/*  85 */     return (JCacheCacheManager)this.customizers.customize(cacheManager);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public javax.cache.CacheManager jCacheCacheManager() throws IOException {
/*  91 */     javax.cache.CacheManager jCacheCacheManager = createCacheManager();
/*  92 */     List<String> cacheNames = this.cacheProperties.getCacheNames();
/*  93 */     if (!CollectionUtils.isEmpty(cacheNames)) {
/*  94 */       for (String cacheName : cacheNames) {
/*  95 */         jCacheCacheManager.createCache(cacheName, getDefaultCacheConfiguration());
/*     */       }
/*     */     }
/*  98 */     customize(jCacheCacheManager);
/*  99 */     return jCacheCacheManager;
/*     */   }
/*     */   
/*     */   private javax.cache.CacheManager createCacheManager() throws IOException {
/* 103 */     CachingProvider cachingProvider = getCachingProvider(this.cacheProperties
/* 104 */       .getJcache().getProvider());
/*     */     
/* 106 */     Resource configLocation = this.cacheProperties.resolveConfigLocation(this.cacheProperties.getJcache().getConfig());
/* 107 */     if (configLocation != null) {
/* 108 */       return cachingProvider.getCacheManager(configLocation.getURI(), cachingProvider
/* 109 */         .getDefaultClassLoader(), 
/* 110 */         createCacheManagerProperties(configLocation));
/*     */     }
/* 112 */     return cachingProvider.getCacheManager();
/*     */   }
/*     */   
/*     */   private CachingProvider getCachingProvider(String cachingProviderFqn) {
/* 116 */     if (StringUtils.hasText(cachingProviderFqn)) {
/* 117 */       return Caching.getCachingProvider(cachingProviderFqn);
/*     */     }
/* 119 */     return Caching.getCachingProvider();
/*     */   }
/*     */   
/*     */   private Properties createCacheManagerProperties(Resource configLocation) throws IOException
/*     */   {
/* 124 */     Properties properties = new Properties();
/*     */     
/* 126 */     properties.setProperty("hazelcast.config.location", configLocation
/* 127 */       .getURI().toString());
/* 128 */     return properties;
/*     */   }
/*     */   
/*     */   private javax.cache.configuration.Configuration<?, ?> getDefaultCacheConfiguration() {
/* 132 */     if (this.defaultCacheConfiguration != null) {
/* 133 */       return this.defaultCacheConfiguration;
/*     */     }
/* 135 */     return new MutableConfiguration();
/*     */   }
/*     */   
/*     */   private void customize(javax.cache.CacheManager cacheManager) {
/* 139 */     if (this.cacheManagerCustomizers != null) {
/* 140 */       AnnotationAwareOrderComparator.sort(this.cacheManagerCustomizers);
/* 141 */       for (JCacheManagerCustomizer customizer : this.cacheManagerCustomizers) {
/* 142 */         customizer.customize(cacheManager);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Order(Integer.MAX_VALUE)
/*     */   static class JCacheAvailableCondition
/*     */     extends AnyNestedCondition
/*     */   {
/*     */     JCacheAvailableCondition()
/*     */     {
/* 156 */       super();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     @ConditionalOnSingleCandidate(javax.cache.CacheManager.class)
/*     */     static class CustomJCacheCacheManager {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     @Conditional({JCacheCacheConfiguration.JCacheProviderAvailableCondition.class})
/*     */     static class JCacheProvider {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Order(Integer.MAX_VALUE)
/*     */   static class JCacheProviderAvailableCondition
/*     */     extends SpringBootCondition
/*     */   {
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*     */     {
/* 181 */       RelaxedPropertyResolver resolver = new RelaxedPropertyResolver(context.getEnvironment(), "spring.cache.jcache.");
/* 182 */       if (resolver.containsProperty("provider")) {
/* 183 */         return ConditionOutcome.match("JCache provider specified");
/*     */       }
/*     */       
/* 186 */       Iterator<CachingProvider> providers = Caching.getCachingProviders().iterator();
/* 187 */       if (!providers.hasNext()) {
/* 188 */         return ConditionOutcome.noMatch("No JSR-107 compliant providers");
/*     */       }
/* 190 */       providers.next();
/* 191 */       if (providers.hasNext()) {
/* 192 */         return ConditionOutcome.noMatch("Multiple default JSR-107 compliant providers found");
/*     */       }
/*     */       
/*     */ 
/* 196 */       return ConditionOutcome.match("Default JSR-107 compliant provider found.");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\cache\JCacheCacheConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */