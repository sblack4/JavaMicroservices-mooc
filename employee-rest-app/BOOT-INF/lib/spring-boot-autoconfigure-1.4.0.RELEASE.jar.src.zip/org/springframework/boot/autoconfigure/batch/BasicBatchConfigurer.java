/*     */ package org.springframework.boot.autoconfigure.batch;
/*     */ 
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.persistence.EntityManagerFactory;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.batch.core.configuration.annotation.BatchConfigurer;
/*     */ import org.springframework.batch.core.explore.JobExplorer;
/*     */ import org.springframework.batch.core.explore.support.JobExplorerFactoryBean;
/*     */ import org.springframework.batch.core.launch.JobLauncher;
/*     */ import org.springframework.batch.core.launch.support.SimpleJobLauncher;
/*     */ import org.springframework.batch.core.repository.JobRepository;
/*     */ import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
/*     */ import org.springframework.jdbc.datasource.DataSourceTransactionManager;
/*     */ import org.springframework.orm.jpa.JpaTransactionManager;
/*     */ import org.springframework.stereotype.Component;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Component
/*     */ public class BasicBatchConfigurer
/*     */   implements BatchConfigurer
/*     */ {
/*  48 */   private static final Log logger = LogFactory.getLog(BasicBatchConfigurer.class);
/*     */   
/*     */ 
/*     */   private final BatchProperties properties;
/*     */   
/*     */ 
/*     */   private final DataSource dataSource;
/*     */   
/*     */ 
/*     */   private final EntityManagerFactory entityManagerFactory;
/*     */   
/*     */   private PlatformTransactionManager transactionManager;
/*     */   
/*     */   private JobRepository jobRepository;
/*     */   
/*     */   private JobLauncher jobLauncher;
/*     */   
/*     */   private JobExplorer jobExplorer;
/*     */   
/*     */ 
/*     */   protected BasicBatchConfigurer(BatchProperties properties, DataSource dataSource)
/*     */   {
/*  70 */     this(properties, dataSource, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BasicBatchConfigurer(BatchProperties properties, DataSource dataSource, EntityManagerFactory entityManagerFactory)
/*     */   {
/*  81 */     this.properties = properties;
/*  82 */     this.entityManagerFactory = entityManagerFactory;
/*  83 */     this.dataSource = dataSource;
/*     */   }
/*     */   
/*     */   public JobRepository getJobRepository()
/*     */   {
/*  88 */     return this.jobRepository;
/*     */   }
/*     */   
/*     */   public PlatformTransactionManager getTransactionManager()
/*     */   {
/*  93 */     return this.transactionManager;
/*     */   }
/*     */   
/*     */   public JobLauncher getJobLauncher()
/*     */   {
/*  98 */     return this.jobLauncher;
/*     */   }
/*     */   
/*     */   public JobExplorer getJobExplorer() throws Exception
/*     */   {
/* 103 */     return this.jobExplorer;
/*     */   }
/*     */   
/*     */   @PostConstruct
/*     */   public void initialize() {
/*     */     try {
/* 109 */       this.transactionManager = createTransactionManager();
/* 110 */       this.jobRepository = createJobRepository();
/* 111 */       this.jobLauncher = createJobLauncher();
/* 112 */       this.jobExplorer = createJobExplorer();
/*     */     }
/*     */     catch (Exception ex) {
/* 115 */       throw new IllegalStateException("Unable to initialize Spring Batch", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected JobExplorer createJobExplorer() throws Exception {
/* 120 */     JobExplorerFactoryBean jobExplorerFactoryBean = new JobExplorerFactoryBean();
/* 121 */     jobExplorerFactoryBean.setDataSource(this.dataSource);
/* 122 */     String tablePrefix = this.properties.getTablePrefix();
/* 123 */     if (StringUtils.hasText(tablePrefix)) {
/* 124 */       jobExplorerFactoryBean.setTablePrefix(tablePrefix);
/*     */     }
/* 126 */     jobExplorerFactoryBean.afterPropertiesSet();
/* 127 */     return jobExplorerFactoryBean.getObject();
/*     */   }
/*     */   
/*     */   protected JobLauncher createJobLauncher() throws Exception {
/* 131 */     SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
/* 132 */     jobLauncher.setJobRepository(getJobRepository());
/* 133 */     jobLauncher.afterPropertiesSet();
/* 134 */     return jobLauncher;
/*     */   }
/*     */   
/*     */   protected JobRepository createJobRepository() throws Exception {
/* 138 */     JobRepositoryFactoryBean factory = new JobRepositoryFactoryBean();
/* 139 */     factory.setDataSource(this.dataSource);
/* 140 */     if (this.entityManagerFactory != null) {
/* 141 */       logger.warn("JPA does not support custom isolation levels, so locks may not be taken when launching Jobs");
/*     */       
/* 143 */       factory.setIsolationLevelForCreate("ISOLATION_DEFAULT");
/*     */     }
/* 145 */     String tablePrefix = this.properties.getTablePrefix();
/* 146 */     if (StringUtils.hasText(tablePrefix)) {
/* 147 */       factory.setTablePrefix(tablePrefix);
/*     */     }
/* 149 */     factory.setTransactionManager(getTransactionManager());
/* 150 */     factory.afterPropertiesSet();
/* 151 */     return factory.getObject();
/*     */   }
/*     */   
/*     */   protected PlatformTransactionManager createTransactionManager() {
/* 155 */     if (this.entityManagerFactory != null) {
/* 156 */       return new JpaTransactionManager(this.entityManagerFactory);
/*     */     }
/* 158 */     return new DataSourceTransactionManager(this.dataSource);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\batch\BasicBatchConfigurer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */