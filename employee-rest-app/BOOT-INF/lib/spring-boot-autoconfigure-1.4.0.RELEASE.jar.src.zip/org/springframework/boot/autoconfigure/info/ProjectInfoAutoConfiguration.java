/*     */ package org.springframework.boot.autoconfigure.info;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Properties;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnResource;
/*     */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*     */ import org.springframework.boot.bind.RelaxedPropertyResolver;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.info.BuildProperties;
/*     */ import org.springframework.boot.info.GitProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.env.PropertyResolver;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.PropertiesLoaderUtils;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @EnableConfigurationProperties({ProjectInfoProperties.class})
/*     */ public class ProjectInfoAutoConfiguration
/*     */ {
/*     */   private final ProjectInfoProperties properties;
/*     */   
/*     */   public ProjectInfoAutoConfiguration(ProjectInfoProperties properties)
/*     */   {
/*  55 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   @Conditional({GitResourceAvailableCondition.class})
/*     */   @ConditionalOnMissingBean
/*     */   @Bean
/*     */   public GitProperties gitProperties() throws Exception {
/*  62 */     return new GitProperties(loadFrom(this.properties.getGit().getLocation(), "git"));
/*     */   }
/*     */   
/*     */   @ConditionalOnResource(resources={"${spring.info.build.location:classpath:META-INF/build-info.properties}"})
/*     */   @ConditionalOnMissingBean
/*     */   @Bean
/*     */   public BuildProperties buildProperties() throws Exception
/*     */   {
/*  70 */     return new BuildProperties(loadFrom(this.properties.getBuild().getLocation(), "build"));
/*     */   }
/*     */   
/*     */   protected Properties loadFrom(Resource location, String prefix) throws IOException {
/*  74 */     String p = prefix + ".";
/*  75 */     Properties source = PropertiesLoaderUtils.loadProperties(location);
/*  76 */     Properties target = new Properties();
/*  77 */     for (String key : source.stringPropertyNames()) {
/*  78 */       if (key.startsWith(p)) {
/*  79 */         target.put(key.substring(p.length()), source.get(key));
/*     */       }
/*     */     }
/*  82 */     return target;
/*     */   }
/*     */   
/*     */   static class GitResourceAvailableCondition extends SpringBootCondition
/*     */   {
/*  87 */     private final ResourceLoader defaultResourceLoader = new DefaultResourceLoader();
/*     */     
/*     */ 
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*     */     {
/*  92 */       ResourceLoader loader = context.getResourceLoader();
/*  93 */       if (loader == null) {
/*  94 */         loader = this.defaultResourceLoader;
/*     */       }
/*  96 */       PropertyResolver propertyResolver = context.getEnvironment();
/*  97 */       RelaxedPropertyResolver resolver = new RelaxedPropertyResolver(propertyResolver, "spring.info.git.");
/*     */       
/*  99 */       String location = resolver.getProperty("location");
/* 100 */       if (location == null) {
/* 101 */         resolver = new RelaxedPropertyResolver(propertyResolver, "spring.git.");
/* 102 */         location = resolver.getProperty("properties");
/* 103 */         if (location == null) {
/* 104 */           location = "classpath:git.properties";
/*     */         }
/*     */       }
/* 107 */       boolean match = loader.getResource(location).exists();
/* 108 */       return new ConditionOutcome(match, "Git info " + (match ? "found" : "not found") + " at " + location);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\info\ProjectInfoAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */