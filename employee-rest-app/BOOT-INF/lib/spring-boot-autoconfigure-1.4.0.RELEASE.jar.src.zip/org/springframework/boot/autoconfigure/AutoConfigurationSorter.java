/*     */ package org.springframework.boot.autoconfigure;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AutoConfigurationSorter
/*     */ {
/*     */   private final MetadataReaderFactory metadataReaderFactory;
/*     */   
/*     */   AutoConfigurationSorter(MetadataReaderFactory metadataReaderFactory)
/*     */   {
/*  48 */     Assert.notNull(metadataReaderFactory, "MetadataReaderFactory must not be null");
/*  49 */     this.metadataReaderFactory = metadataReaderFactory;
/*     */   }
/*     */   
/*     */   public List<String> getInPriorityOrder(Collection<String> classNames) throws IOException
/*     */   {
/*  54 */     final AutoConfigurationClasses classes = new AutoConfigurationClasses(this.metadataReaderFactory, classNames);
/*     */     
/*  56 */     List<String> orderedClassNames = new ArrayList(classNames);
/*     */     
/*  58 */     Collections.sort(orderedClassNames);
/*     */     
/*  60 */     Collections.sort(orderedClassNames, new Comparator()
/*     */     {
/*     */       public int compare(String o1, String o2) {
/*  63 */         int i1 = classes.get(o1).getOrder();
/*  64 */         int i2 = classes.get(o2).getOrder();
/*  65 */         return i1 > i2 ? 1 : i1 < i2 ? -1 : 0;
/*     */       }
/*     */       
/*  68 */     });
/*  69 */     orderedClassNames = sortByAnnotation(classes, orderedClassNames);
/*  70 */     return orderedClassNames;
/*     */   }
/*     */   
/*     */   private List<String> sortByAnnotation(AutoConfigurationClasses classes, List<String> classNames)
/*     */   {
/*  75 */     List<String> toSort = new ArrayList(classNames);
/*  76 */     Set<String> sorted = new LinkedHashSet();
/*  77 */     Set<String> processing = new LinkedHashSet();
/*  78 */     while (!toSort.isEmpty()) {
/*  79 */       doSortByAfterAnnotation(classes, toSort, sorted, processing, null);
/*     */     }
/*  81 */     return new ArrayList(sorted);
/*     */   }
/*     */   
/*     */ 
/*     */   private void doSortByAfterAnnotation(AutoConfigurationClasses classes, List<String> toSort, Set<String> sorted, Set<String> processing, String current)
/*     */   {
/*  87 */     if (current == null) {
/*  88 */       current = (String)toSort.remove(0);
/*     */     }
/*  90 */     processing.add(current);
/*  91 */     for (String after : classes.getClassesRequestedAfter(current)) {
/*  92 */       Assert.state(!processing.contains(after), "AutoConfigure cycle detected between " + current + " and " + after);
/*     */       
/*  94 */       if ((!sorted.contains(after)) && (toSort.contains(after))) {
/*  95 */         doSortByAfterAnnotation(classes, toSort, sorted, processing, after);
/*     */       }
/*     */     }
/*  98 */     processing.remove(current);
/*  99 */     sorted.add(current);
/*     */   }
/*     */   
/*     */   private static class AutoConfigurationClasses
/*     */   {
/* 104 */     private final Map<String, AutoConfigurationSorter.AutoConfigurationClass> classes = new HashMap();
/*     */     
/*     */     AutoConfigurationClasses(MetadataReaderFactory metadataReaderFactory, Collection<String> classNames) throws IOException
/*     */     {
/* 108 */       for (String className : classNames)
/*     */       {
/* 110 */         MetadataReader metadataReader = metadataReaderFactory.getMetadataReader(className);
/* 111 */         this.classes.put(className, new AutoConfigurationSorter.AutoConfigurationClass(metadataReader));
/*     */       }
/*     */     }
/*     */     
/*     */     public AutoConfigurationSorter.AutoConfigurationClass get(String className) {
/* 116 */       return (AutoConfigurationSorter.AutoConfigurationClass)this.classes.get(className);
/*     */     }
/*     */     
/*     */     public Set<String> getClassesRequestedAfter(String className) {
/* 120 */       Set<String> rtn = new LinkedHashSet();
/* 121 */       rtn.addAll(get(className).getAfter());
/* 122 */       for (Map.Entry<String, AutoConfigurationSorter.AutoConfigurationClass> entry : this.classes
/* 123 */         .entrySet()) {
/* 124 */         if (((AutoConfigurationSorter.AutoConfigurationClass)entry.getValue()).getBefore().contains(className)) {
/* 125 */           rtn.add(entry.getKey());
/*     */         }
/*     */       }
/* 128 */       return rtn;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class AutoConfigurationClass
/*     */   {
/*     */     private final AnnotationMetadata metadata;
/*     */     
/*     */     AutoConfigurationClass(MetadataReader metadataReader) {
/* 137 */       this.metadata = metadataReader.getAnnotationMetadata();
/*     */     }
/*     */     
/*     */     public int getOrder()
/*     */     {
/* 142 */       Map<String, Object> orderedAnnotation = this.metadata.getAnnotationAttributes(AutoConfigureOrder.class.getName());
/*     */       
/* 144 */       return orderedAnnotation == null ? Integer.MAX_VALUE : ((Integer)orderedAnnotation.get("value")).intValue();
/*     */     }
/*     */     
/*     */     public Set<String> getBefore() {
/* 148 */       return getAnnotationValue(AutoConfigureBefore.class);
/*     */     }
/*     */     
/*     */     public Set<String> getAfter() {
/* 152 */       return getAnnotationValue(AutoConfigureAfter.class);
/*     */     }
/*     */     
/*     */     private Set<String> getAnnotationValue(Class<?> annotation)
/*     */     {
/* 157 */       Map<String, Object> attributes = this.metadata.getAnnotationAttributes(annotation.getName(), true);
/* 158 */       if (attributes == null) {
/* 159 */         return Collections.emptySet();
/*     */       }
/* 161 */       Set<String> value = new LinkedHashSet();
/* 162 */       Collections.addAll(value, (String[])attributes.get("value"));
/* 163 */       Collections.addAll(value, (String[])attributes.get("name"));
/* 164 */       return value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\AutoConfigurationSorter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */