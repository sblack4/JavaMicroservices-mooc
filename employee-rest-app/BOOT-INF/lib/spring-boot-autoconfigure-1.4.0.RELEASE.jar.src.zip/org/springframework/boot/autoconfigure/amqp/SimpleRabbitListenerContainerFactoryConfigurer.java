/*     */ package org.springframework.boot.autoconfigure.amqp;
/*     */ 
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.springframework.amqp.rabbit.config.RetryInterceptorBuilder;
/*     */ import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
/*     */ import org.springframework.amqp.rabbit.connection.ConnectionFactory;
/*     */ import org.springframework.amqp.rabbit.retry.RejectAndDontRequeueRecoverer;
/*     */ import org.springframework.amqp.support.converter.MessageConverter;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SimpleRabbitListenerContainerFactoryConfigurer
/*     */ {
/*     */   private MessageConverter messageConverter;
/*     */   private RabbitProperties rabbitProperties;
/*     */   
/*     */   void setMessageConverter(MessageConverter messageConverter)
/*     */   {
/*  47 */     this.messageConverter = messageConverter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void setRabbitProperties(RabbitProperties rabbitProperties)
/*     */   {
/*  55 */     this.rabbitProperties = rabbitProperties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void configure(SimpleRabbitListenerContainerFactory factory, ConnectionFactory connectionFactory)
/*     */   {
/*  67 */     Assert.notNull(factory, "Factory must not be null");
/*  68 */     Assert.notNull(connectionFactory, "ConnectionFactory must not be null");
/*  69 */     factory.setConnectionFactory(connectionFactory);
/*  70 */     if (this.messageConverter != null) {
/*  71 */       factory.setMessageConverter(this.messageConverter);
/*     */     }
/*  73 */     RabbitProperties.Listener listenerConfig = this.rabbitProperties.getListener();
/*  74 */     factory.setAutoStartup(Boolean.valueOf(listenerConfig.isAutoStartup()));
/*  75 */     if (listenerConfig.getAcknowledgeMode() != null) {
/*  76 */       factory.setAcknowledgeMode(listenerConfig.getAcknowledgeMode());
/*     */     }
/*  78 */     if (listenerConfig.getConcurrency() != null) {
/*  79 */       factory.setConcurrentConsumers(listenerConfig.getConcurrency());
/*     */     }
/*  81 */     if (listenerConfig.getMaxConcurrency() != null) {
/*  82 */       factory.setMaxConcurrentConsumers(listenerConfig.getMaxConcurrency());
/*     */     }
/*  84 */     if (listenerConfig.getPrefetch() != null) {
/*  85 */       factory.setPrefetchCount(listenerConfig.getPrefetch());
/*     */     }
/*  87 */     if (listenerConfig.getTransactionSize() != null) {
/*  88 */       factory.setTxSize(listenerConfig.getTransactionSize());
/*     */     }
/*  90 */     if (listenerConfig.getDefaultRequeueRejected() != null) {
/*  91 */       factory.setDefaultRequeueRejected(listenerConfig.getDefaultRequeueRejected());
/*     */     }
/*  93 */     RabbitProperties.ListenerRetry retryConfig = listenerConfig.getRetry();
/*  94 */     if (retryConfig.isEnabled())
/*     */     {
/*     */ 
/*  97 */       RetryInterceptorBuilder<?> builder = retryConfig.isStateless() ? RetryInterceptorBuilder.stateless() : RetryInterceptorBuilder.stateful();
/*  98 */       builder.maxAttempts(retryConfig.getMaxAttempts());
/*  99 */       builder.backOffOptions(retryConfig.getInitialInterval(), retryConfig
/* 100 */         .getMultiplier(), retryConfig.getMaxInterval());
/* 101 */       builder.recoverer(new RejectAndDontRequeueRecoverer());
/* 102 */       factory.setAdviceChain(new Advice[] { builder.build() });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\amqp\SimpleRabbitListenerContainerFactoryConfigurer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */