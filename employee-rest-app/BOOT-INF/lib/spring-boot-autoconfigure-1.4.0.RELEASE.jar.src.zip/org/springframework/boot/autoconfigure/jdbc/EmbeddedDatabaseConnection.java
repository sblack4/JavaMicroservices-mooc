/*     */ package org.springframework.boot.autoconfigure.jdbc;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.SQLException;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.jdbc.core.ConnectionCallback;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum EmbeddedDatabaseConnection
/*     */ {
/*  44 */   NONE(null, null, null), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  49 */   H2(EmbeddedDatabaseType.H2, "org.h2.Driver", "jdbc:h2:mem:%s;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  55 */   DERBY(EmbeddedDatabaseType.DERBY, "org.apache.derby.jdbc.EmbeddedDriver", "jdbc:derby:memory:%s;create=true"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  61 */   HSQL(EmbeddedDatabaseType.HSQL, "org.hsqldb.jdbcDriver", "jdbc:hsqldb:mem:%s");
/*     */   
/*     */ 
/*     */   private static final String DEFAULT_DATABASE_NAME = "testdb";
/*     */   
/*     */   private final EmbeddedDatabaseType type;
/*     */   private final String driverClass;
/*     */   private final String url;
/*     */   static EmbeddedDatabaseConnection override;
/*     */   
/*     */   private EmbeddedDatabaseConnection(EmbeddedDatabaseType type, String driverClass, String url)
/*     */   {
/*  73 */     this.type = type;
/*  74 */     this.driverClass = driverClass;
/*  75 */     this.url = url;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDriverClassName()
/*     */   {
/*  83 */     return this.driverClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public EmbeddedDatabaseType getType()
/*     */   {
/*  91 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUrl()
/*     */   {
/*  99 */     return getUrl("testdb");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUrl(String databaseName)
/*     */   {
/* 108 */     Assert.hasText(databaseName, "DatabaseName must not be null.");
/* 109 */     return String.format(this.url, new Object[] { databaseName });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isEmbedded(String driverClass)
/*     */   {
/* 127 */     return (driverClass != null) && ((driverClass.equals(HSQL.driverClass)) || (driverClass.equals(H2.driverClass)) || (driverClass.equals(DERBY.driverClass)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isEmbedded(DataSource dataSource)
/*     */   {
/*     */     try
/*     */     {
/* 139 */       return ((Boolean)new JdbcTemplate(dataSource).execute(new IsEmbedded(null))).booleanValue();
/*     */     }
/*     */     catch (DataAccessException ex) {}
/*     */     
/* 143 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static EmbeddedDatabaseConnection get(ClassLoader classLoader)
/*     */   {
/* 154 */     if (override != null) {
/* 155 */       return override;
/*     */     }
/* 157 */     for (EmbeddedDatabaseConnection candidate : values()) {
/* 158 */       if ((candidate != NONE) && (ClassUtils.isPresent(candidate.getDriverClassName(), classLoader)))
/*     */       {
/* 160 */         return candidate;
/*     */       }
/*     */     }
/* 163 */     return NONE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class IsEmbedded
/*     */     implements ConnectionCallback<Boolean>
/*     */   {
/*     */     public Boolean doInConnection(Connection connection)
/*     */       throws SQLException, DataAccessException
/*     */     {
/* 174 */       String productName = connection.getMetaData().getDatabaseProductName();
/* 175 */       if (productName == null) {
/* 176 */         return Boolean.valueOf(false);
/*     */       }
/* 178 */       productName = productName.toUpperCase();
/* 179 */       EmbeddedDatabaseConnection[] candidates = EmbeddedDatabaseConnection.values();
/* 180 */       for (EmbeddedDatabaseConnection candidate : candidates) {
/* 181 */         if ((candidate != EmbeddedDatabaseConnection.NONE) && (productName.contains(candidate.name()))) {
/* 182 */           return Boolean.valueOf(true);
/*     */         }
/*     */       }
/* 185 */       return Boolean.valueOf(false);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jdbc\EmbeddedDatabaseConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */