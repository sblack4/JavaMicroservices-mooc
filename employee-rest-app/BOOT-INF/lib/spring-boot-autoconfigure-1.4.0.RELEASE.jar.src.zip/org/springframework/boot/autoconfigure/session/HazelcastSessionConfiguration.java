/*    */ package org.springframework.boot.autoconfigure.session;
/*    */ 
/*    */ import com.hazelcast.core.HazelcastInstance;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.session.SessionRepository;
/*    */ import org.springframework.session.hazelcast.config.annotation.web.http.HazelcastHttpSessionConfiguration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration
/*    */ @ConditionalOnMissingBean({SessionRepository.class})
/*    */ @ConditionalOnBean({HazelcastInstance.class})
/*    */ @Conditional({SessionCondition.class})
/*    */ class HazelcastSessionConfiguration
/*    */ {
/*    */   @Configuration
/*    */   public static class SpringBootHazelcastHttpSessionConfiguration
/*    */     extends HazelcastHttpSessionConfiguration
/*    */   {
/*    */     @Autowired
/*    */     public void customize(SessionProperties sessionProperties)
/*    */     {
/* 48 */       Integer timeout = sessionProperties.getTimeout();
/* 49 */       if (timeout != null) {
/* 50 */         setMaxInactiveIntervalInSeconds(timeout.intValue());
/*    */       }
/* 52 */       setSessionMapName(sessionProperties.getHazelcast().getMapName());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\session\HazelcastSessionConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */