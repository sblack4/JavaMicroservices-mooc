/*     */ package org.springframework.boot.autoconfigure.batch;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.batch.core.BatchStatus;
/*     */ import org.springframework.batch.core.Job;
/*     */ import org.springframework.batch.core.JobExecution;
/*     */ import org.springframework.batch.core.JobExecutionException;
/*     */ import org.springframework.batch.core.JobInstance;
/*     */ import org.springframework.batch.core.JobParameter;
/*     */ import org.springframework.batch.core.JobParameters;
/*     */ import org.springframework.batch.core.JobParametersIncrementer;
/*     */ import org.springframework.batch.core.JobParametersInvalidException;
/*     */ import org.springframework.batch.core.configuration.JobRegistry;
/*     */ import org.springframework.batch.core.converter.DefaultJobParametersConverter;
/*     */ import org.springframework.batch.core.converter.JobParametersConverter;
/*     */ import org.springframework.batch.core.explore.JobExplorer;
/*     */ import org.springframework.batch.core.launch.JobLauncher;
/*     */ import org.springframework.batch.core.launch.JobParametersNotFoundException;
/*     */ import org.springframework.batch.core.launch.NoSuchJobException;
/*     */ import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
/*     */ import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
/*     */ import org.springframework.batch.core.repository.JobRestartException;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.boot.CommandLineRunner;
/*     */ import org.springframework.context.ApplicationEventPublisher;
/*     */ import org.springframework.context.ApplicationEventPublisherAware;
/*     */ import org.springframework.stereotype.Component;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Component
/*     */ public class JobLauncherCommandLineRunner
/*     */   implements CommandLineRunner, ApplicationEventPublisherAware
/*     */ {
/*  70 */   private static final Log logger = LogFactory.getLog(JobLauncherCommandLineRunner.class);
/*     */   
/*  72 */   private JobParametersConverter converter = new DefaultJobParametersConverter();
/*     */   
/*     */   private JobLauncher jobLauncher;
/*     */   
/*     */   private JobRegistry jobRegistry;
/*     */   
/*     */   private JobExplorer jobExplorer;
/*     */   
/*     */   private String jobNames;
/*     */   
/*  82 */   private Collection<Job> jobs = Collections.emptySet();
/*     */   
/*     */   private ApplicationEventPublisher publisher;
/*     */   
/*     */   public JobLauncherCommandLineRunner(JobLauncher jobLauncher, JobExplorer jobExplorer)
/*     */   {
/*  88 */     this.jobLauncher = jobLauncher;
/*  89 */     this.jobExplorer = jobExplorer;
/*     */   }
/*     */   
/*     */   public void setJobNames(String jobNames) {
/*  93 */     this.jobNames = jobNames;
/*     */   }
/*     */   
/*     */   public void setApplicationEventPublisher(ApplicationEventPublisher publisher)
/*     */   {
/*  98 */     this.publisher = publisher;
/*     */   }
/*     */   
/*     */   @Autowired(required=false)
/*     */   public void setJobRegistry(JobRegistry jobRegistry) {
/* 103 */     this.jobRegistry = jobRegistry;
/*     */   }
/*     */   
/*     */   @Autowired(required=false)
/*     */   public void setJobParametersConverter(JobParametersConverter converter) {
/* 108 */     this.converter = converter;
/*     */   }
/*     */   
/*     */   @Autowired(required=false)
/*     */   public void setJobs(Collection<Job> jobs) {
/* 113 */     this.jobs = jobs;
/*     */   }
/*     */   
/*     */   public void run(String... args) throws JobExecutionException
/*     */   {
/* 118 */     logger.info("Running default command line with: " + Arrays.asList(args));
/* 119 */     launchJobFromProperties(StringUtils.splitArrayElementsIntoProperties(args, "="));
/*     */   }
/*     */   
/*     */   protected void launchJobFromProperties(Properties properties) throws JobExecutionException
/*     */   {
/* 124 */     JobParameters jobParameters = this.converter.getJobParameters(properties);
/* 125 */     executeLocalJobs(jobParameters);
/* 126 */     executeRegisteredJobs(jobParameters);
/*     */   }
/*     */   
/*     */   private JobParameters getNextJobParameters(Job job, JobParameters additionalParameters)
/*     */   {
/* 131 */     String name = job.getName();
/* 132 */     JobParameters parameters = new JobParameters();
/* 133 */     List<JobInstance> lastInstances = this.jobExplorer.getJobInstances(name, 0, 1);
/* 134 */     JobParametersIncrementer incrementer = job.getJobParametersIncrementer();
/* 135 */     Map<String, JobParameter> additionals = additionalParameters.getParameters();
/* 136 */     if (lastInstances.isEmpty())
/*     */     {
/* 138 */       if (incrementer != null) {
/* 139 */         parameters = incrementer.getNext(new JobParameters());
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 144 */       List<JobExecution> previousExecutions = this.jobExplorer.getJobExecutions((JobInstance)lastInstances.get(0));
/* 145 */       JobExecution previousExecution = (JobExecution)previousExecutions.get(0);
/* 146 */       if (previousExecution == null)
/*     */       {
/* 148 */         if (incrementer != null) {
/* 149 */           parameters = incrementer.getNext(new JobParameters());
/*     */         }
/*     */       }
/* 152 */       else if ((isStoppedOrFailed(previousExecution)) && (job.isRestartable()))
/*     */       {
/* 154 */         parameters = previousExecution.getJobParameters();
/*     */         
/* 156 */         removeNonIdentifying(additionals);
/*     */       }
/* 158 */       else if (incrementer != null)
/*     */       {
/* 160 */         parameters = incrementer.getNext(previousExecution.getJobParameters());
/*     */       }
/*     */     }
/* 163 */     return merge(parameters, additionals);
/*     */   }
/*     */   
/*     */   private boolean isStoppedOrFailed(JobExecution execution) {
/* 167 */     BatchStatus status = execution.getStatus();
/* 168 */     return (status == BatchStatus.STOPPED) || (status == BatchStatus.FAILED);
/*     */   }
/*     */   
/*     */   private void removeNonIdentifying(Map<String, JobParameter> parameters) {
/* 172 */     HashMap<String, JobParameter> copy = new HashMap(parameters);
/*     */     
/* 174 */     for (Map.Entry<String, JobParameter> parameter : copy.entrySet()) {
/* 175 */       if (!((JobParameter)parameter.getValue()).isIdentifying()) {
/* 176 */         parameters.remove(parameter.getKey());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private JobParameters merge(JobParameters parameters, Map<String, JobParameter> additionals)
/*     */   {
/* 183 */     Map<String, JobParameter> merged = new HashMap();
/* 184 */     merged.putAll(parameters.getParameters());
/* 185 */     merged.putAll(additionals);
/* 186 */     parameters = new JobParameters(merged);
/* 187 */     return parameters;
/*     */   }
/*     */   
/*     */   private void executeRegisteredJobs(JobParameters jobParameters) throws JobExecutionException
/*     */   {
/* 192 */     if ((this.jobRegistry != null) && (StringUtils.hasText(this.jobNames))) {
/* 193 */       String[] jobsToRun = this.jobNames.split(",");
/* 194 */       for (String jobName : jobsToRun) {
/*     */         try {
/* 196 */           Job job = this.jobRegistry.getJob(jobName);
/* 197 */           if (!this.jobs.contains(job))
/*     */           {
/*     */ 
/* 200 */             execute(job, jobParameters);
/*     */           }
/*     */         } catch (NoSuchJobException ex) {
/* 203 */           logger.debug("No job found in registry for job name: " + jobName);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void execute(Job job, JobParameters jobParameters)
/*     */     throws JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException, JobParametersInvalidException, JobParametersNotFoundException
/*     */   {
/* 214 */     JobParameters nextParameters = getNextJobParameters(job, jobParameters);
/* 215 */     if (nextParameters != null) {
/* 216 */       JobExecution execution = this.jobLauncher.run(job, nextParameters);
/* 217 */       if (this.publisher != null) {
/* 218 */         this.publisher.publishEvent(new JobExecutionEvent(execution));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void executeLocalJobs(JobParameters jobParameters) throws JobExecutionException
/*     */   {
/* 225 */     for (Job job : this.jobs) {
/* 226 */       if (StringUtils.hasText(this.jobNames)) {
/* 227 */         String[] jobsToRun = this.jobNames.split(",");
/* 228 */         if (!PatternMatchUtils.simpleMatch(jobsToRun, job.getName())) {
/* 229 */           logger.debug("Skipped job: " + job.getName());
/* 230 */           continue;
/*     */         }
/*     */       }
/* 233 */       execute(job, jobParameters);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\batch\JobLauncherCommandLineRunner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */