/*    */ package org.springframework.boot.autoconfigure.jms.activemq;
/*    */ 
/*    */ import javax.jms.ConnectionFactory;
/*    */ import org.apache.activemq.ActiveMQConnectionFactory;
/*    */ import org.apache.activemq.pool.PooledConnectionFactory;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration
/*    */ @ConditionalOnMissingBean({ConnectionFactory.class})
/*    */ class ActiveMQConnectionFactoryConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnProperty(prefix="spring.activemq.pool", name={"enabled"}, havingValue="false", matchIfMissing=true)
/*    */   public ActiveMQConnectionFactory jmsConnectionFactory(ActiveMQProperties properties)
/*    */   {
/* 49 */     return new ActiveMQConnectionFactoryFactory(properties).createConnectionFactory(ActiveMQConnectionFactory.class);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @ConditionalOnClass({PooledConnectionFactory.class})
/*    */   static class PooledConnectionFactoryConfiguration
/*    */   {
/*    */     @Bean(destroyMethod="stop")
/*    */     @ConditionalOnProperty(prefix="spring.activemq.pool", name={"enabled"}, havingValue="true", matchIfMissing=false)
/*    */     @ConfigurationProperties("spring.activemq.pool.configuration")
/*    */     public PooledConnectionFactory pooledJmsConnectionFactory(ActiveMQProperties properties)
/*    */     {
/* 62 */       PooledConnectionFactory pooledConnectionFactory = new PooledConnectionFactory(new ActiveMQConnectionFactoryFactory(properties).createConnectionFactory(ActiveMQConnectionFactory.class));
/*    */       
/* 64 */       ActiveMQProperties.Pool pool = properties.getPool();
/* 65 */       pooledConnectionFactory.setMaxConnections(pool.getMaxConnections());
/* 66 */       pooledConnectionFactory.setIdleTimeout(pool.getIdleTimeout());
/* 67 */       pooledConnectionFactory.setExpiryTimeout(pool.getExpiryTimeout());
/* 68 */       return pooledConnectionFactory;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jms\activemq\ActiveMQConnectionFactoryConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */