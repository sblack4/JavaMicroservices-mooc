/*     */ package org.springframework.boot.autoconfigure.jdbc;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.jdbc.config.SortedResourcesFactoryBean;
/*     */ import org.springframework.jdbc.datasource.init.DatabasePopulatorUtils;
/*     */ import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DataSourceInitializer
/*     */   implements ApplicationListener<DataSourceInitializedEvent>
/*     */ {
/*  51 */   private static final Log logger = LogFactory.getLog(DataSourceInitializer.class);
/*     */   
/*     */   @Autowired
/*     */   private ConfigurableApplicationContext applicationContext;
/*     */   
/*     */   private DataSource dataSource;
/*     */   
/*     */   @Autowired
/*     */   private DataSourceProperties properties;
/*     */   
/*  61 */   private boolean initialized = false;
/*     */   
/*     */   @PostConstruct
/*     */   public void init() {
/*  65 */     if (!this.properties.isInitialize()) {
/*  66 */       logger.debug("Initialization disabled (not running DDL scripts)");
/*  67 */       return;
/*     */     }
/*  69 */     if (this.applicationContext.getBeanNamesForType(DataSource.class, false, false).length > 0)
/*     */     {
/*  71 */       this.dataSource = ((DataSource)this.applicationContext.getBean(DataSource.class));
/*     */     }
/*  73 */     if (this.dataSource == null) {
/*  74 */       logger.debug("No DataSource found so not initializing");
/*  75 */       return;
/*     */     }
/*  77 */     runSchemaScripts();
/*     */   }
/*     */   
/*     */   private void runSchemaScripts() {
/*  81 */     List<Resource> scripts = getScripts(this.properties.getSchema(), "schema");
/*  82 */     if (!scripts.isEmpty()) {
/*  83 */       String username = this.properties.getSchemaUsername();
/*  84 */       String password = this.properties.getSchemaPassword();
/*  85 */       runScripts(scripts, username, password);
/*     */       try
/*     */       {
/*  88 */         this.applicationContext.publishEvent(new DataSourceInitializedEvent(this.dataSource));
/*     */         
/*  90 */         if (!this.initialized) {
/*  91 */           runDataScripts();
/*  92 */           this.initialized = true;
/*     */         }
/*     */       }
/*     */       catch (IllegalStateException ex) {
/*  96 */         logger.warn("Could not send event to complete DataSource initialization (" + ex
/*  97 */           .getMessage() + ")");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void onApplicationEvent(DataSourceInitializedEvent event)
/*     */   {
/* 104 */     if (!this.properties.isInitialize()) {
/* 105 */       logger.debug("Initialization disabled (not running data scripts)");
/* 106 */       return;
/*     */     }
/*     */     
/*     */ 
/* 110 */     if (!this.initialized) {
/* 111 */       runDataScripts();
/* 112 */       this.initialized = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private void runDataScripts() {
/* 117 */     List<Resource> scripts = getScripts(this.properties.getData(), "data");
/* 118 */     String username = this.properties.getDataUsername();
/* 119 */     String password = this.properties.getDataPassword();
/* 120 */     runScripts(scripts, username, password);
/*     */   }
/*     */   
/*     */   private List<Resource> getScripts(String locations, String fallback) {
/* 124 */     if (locations == null) {
/* 125 */       String platform = this.properties.getPlatform();
/* 126 */       locations = "classpath*:" + fallback + "-" + platform + ".sql,";
/* 127 */       locations = locations + "classpath*:" + fallback + ".sql";
/*     */     }
/* 129 */     return getResources(locations);
/*     */   }
/*     */   
/*     */   private List<Resource> getResources(String locations) {
/* 133 */     return getResources(
/* 134 */       Arrays.asList(StringUtils.commaDelimitedListToStringArray(locations)));
/*     */   }
/*     */   
/*     */   private List<Resource> getResources(List<String> locations) {
/* 138 */     SortedResourcesFactoryBean factory = new SortedResourcesFactoryBean(this.applicationContext, locations);
/*     */     try
/*     */     {
/* 141 */       factory.afterPropertiesSet();
/* 142 */       List<Resource> resources = new ArrayList();
/* 143 */       for (Resource resource : (Resource[])factory.getObject()) {
/* 144 */         if (resource.exists()) {
/* 145 */           resources.add(resource);
/*     */         }
/*     */       }
/* 148 */       return resources;
/*     */     }
/*     */     catch (Exception ex) {
/* 151 */       throw new IllegalStateException("Unable to load resources from " + locations, ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private void runScripts(List<Resource> resources, String username, String password)
/*     */   {
/* 157 */     if (resources.isEmpty()) {
/* 158 */       return;
/*     */     }
/* 160 */     ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
/* 161 */     populator.setContinueOnError(this.properties.isContinueOnError());
/* 162 */     populator.setSeparator(this.properties.getSeparator());
/* 163 */     if (this.properties.getSqlScriptEncoding() != null) {
/* 164 */       populator.setSqlScriptEncoding(this.properties.getSqlScriptEncoding().name());
/*     */     }
/* 166 */     for (Resource resource : resources) {
/* 167 */       populator.addScript(resource);
/*     */     }
/* 169 */     DataSource dataSource = this.dataSource;
/* 170 */     if ((StringUtils.hasText(username)) && (StringUtils.hasText(password)))
/*     */     {
/*     */ 
/*     */ 
/* 174 */       dataSource = DataSourceBuilder.create(this.properties.getClassLoader()).driverClassName(this.properties.determineDriverClassName()).url(this.properties.determineUrl()).username(username).password(password).build();
/*     */     }
/* 176 */     DatabasePopulatorUtils.execute(populator, dataSource);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jdbc\DataSourceInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */