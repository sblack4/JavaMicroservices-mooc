/*     */ package org.springframework.boot.autoconfigure.orm.jpa;
/*     */ 
/*     */ import java.util.Map;
/*     */ import javax.persistence.EntityManagerFactory;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*     */ import org.springframework.boot.autoconfigure.jdbc.DataSourceInitializedEvent;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DataSourceInitializedPublisher
/*     */   implements BeanPostProcessor
/*     */ {
/*     */   @Autowired
/*     */   private ApplicationContext applicationContext;
/*     */   private DataSource dataSource;
/*     */   private JpaProperties properties;
/*     */   
/*     */   public Object postProcessBeforeInitialization(Object bean, String beanName)
/*     */     throws BeansException
/*     */   {
/*  54 */     return bean;
/*     */   }
/*     */   
/*     */   public Object postProcessAfterInitialization(Object bean, String beanName)
/*     */     throws BeansException
/*     */   {
/*  60 */     if ((bean instanceof DataSource))
/*     */     {
/*  62 */       this.dataSource = ((DataSource)bean);
/*     */     }
/*  64 */     if ((bean instanceof JpaProperties)) {
/*  65 */       this.properties = ((JpaProperties)bean);
/*     */     }
/*  67 */     if (((bean instanceof EntityManagerFactory)) && (this.dataSource != null) && 
/*  68 */       (isInitializingDatabase()))
/*     */     {
/*  70 */       this.applicationContext.publishEvent(new DataSourceInitializedEvent(this.dataSource));
/*     */     }
/*  72 */     return bean;
/*     */   }
/*     */   
/*     */   private boolean isInitializingDatabase() {
/*  76 */     if (this.properties == null) {
/*  77 */       return true;
/*     */     }
/*     */     
/*  80 */     Map<String, String> hibernate = this.properties.getHibernateProperties(this.dataSource);
/*  81 */     if (hibernate.containsKey("hibernate.hbm2ddl.auto")) {
/*  82 */       return true;
/*     */     }
/*  84 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static class Registrar
/*     */     implements ImportBeanDefinitionRegistrar
/*     */   {
/*     */     private static final String BEAN_NAME = "dataSourceInitializedPublisher";
/*     */     
/*     */ 
/*     */ 
/*     */     public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry)
/*     */     {
/*  99 */       if (!registry.containsBeanDefinition("dataSourceInitializedPublisher")) {
/* 100 */         GenericBeanDefinition beanDefinition = new GenericBeanDefinition();
/* 101 */         beanDefinition.setBeanClass(DataSourceInitializedPublisher.class);
/* 102 */         beanDefinition.setRole(2);
/*     */         
/*     */ 
/* 105 */         beanDefinition.setSynthetic(true);
/* 106 */         registry.registerBeanDefinition("dataSourceInitializedPublisher", beanDefinition);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\orm\jpa\DataSourceInitializedPublisher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */