/*     */ package org.springframework.boot.autoconfigure.integration;
/*     */ 
/*     */ import javax.management.MBeanServer;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.beans.factory.annotation.Qualifier;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.SearchStrategy;
/*     */ import org.springframework.boot.autoconfigure.jmx.JmxAutoConfiguration;
/*     */ import org.springframework.boot.bind.RelaxedPropertyResolver;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.integration.config.EnableIntegration;
/*     */ import org.springframework.integration.jmx.config.EnableIntegrationMBeanExport;
/*     */ import org.springframework.integration.monitor.IntegrationMBeanExporter;
/*     */ import org.springframework.integration.support.management.IntegrationManagementConfigurer;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @ConditionalOnClass({EnableIntegration.class})
/*     */ @AutoConfigureAfter({JmxAutoConfiguration.class})
/*     */ public class IntegrationAutoConfiguration
/*     */ {
/*     */   @Configuration
/*     */   @ConditionalOnClass({EnableIntegrationMBeanExport.class})
/*     */   @ConditionalOnMissingBean(value={IntegrationMBeanExporter.class}, search=SearchStrategy.CURRENT)
/*     */   @ConditionalOnProperty(prefix="spring.jmx", name={"enabled"}, havingValue="true", matchIfMissing=true)
/*     */   protected static class IntegrationJmxConfiguration
/*     */     implements EnvironmentAware, BeanFactoryAware
/*     */   {
/*     */     private BeanFactory beanFactory;
/*     */     private RelaxedPropertyResolver propertyResolver;
/*     */     @Autowired(required=false)
/*     */     @Qualifier("integrationManagementConfigurer")
/*     */     private IntegrationManagementConfigurer configurer;
/*     */     
/*     */     public void setBeanFactory(BeanFactory beanFactory)
/*     */       throws BeansException
/*     */     {
/*  79 */       this.beanFactory = beanFactory;
/*     */     }
/*     */     
/*     */     public void setEnvironment(Environment environment)
/*     */     {
/*  84 */       this.propertyResolver = new RelaxedPropertyResolver(environment, "spring.jmx.");
/*     */     }
/*     */     
/*     */     @Bean
/*     */     public IntegrationMBeanExporter integrationMbeanExporter()
/*     */     {
/*  90 */       IntegrationMBeanExporter exporter = new IntegrationMBeanExporter();
/*  91 */       String defaultDomain = this.propertyResolver.getProperty("default-domain");
/*  92 */       if (StringUtils.hasLength(defaultDomain)) {
/*  93 */         exporter.setDefaultDomain(defaultDomain);
/*     */       }
/*  95 */       String server = this.propertyResolver.getProperty("server", "mbeanServer");
/*  96 */       if (StringUtils.hasLength(server)) {
/*  97 */         exporter.setServer((MBeanServer)this.beanFactory.getBean(server, MBeanServer.class));
/*     */       }
/*  99 */       if (this.configurer != null) {
/* 100 */         if (this.configurer.getDefaultCountsEnabled() == null) {
/* 101 */           this.configurer.setDefaultCountsEnabled(Boolean.valueOf(true));
/*     */         }
/* 103 */         if (this.configurer.getDefaultStatsEnabled() == null) {
/* 104 */           this.configurer.setDefaultStatsEnabled(Boolean.valueOf(true));
/*     */         }
/*     */       }
/* 107 */       return exporter;
/*     */     }
/*     */   }
/*     */   
/*     */   @Configuration
/*     */   @EnableIntegration
/*     */   protected static class IntegrationConfiguration {}
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\integration\IntegrationAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */