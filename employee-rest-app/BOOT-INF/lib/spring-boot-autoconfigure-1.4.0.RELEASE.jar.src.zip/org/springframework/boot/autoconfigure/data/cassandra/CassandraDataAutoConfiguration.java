/*     */ package org.springframework.boot.autoconfigure.data.cassandra;
/*     */ 
/*     */ import com.datastax.driver.core.Cluster;
/*     */ import com.datastax.driver.core.Session;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigurationPackages;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.cassandra.CassandraAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.cassandra.CassandraProperties;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.domain.EntityScanPackages;
/*     */ import org.springframework.boot.bind.RelaxedPropertyResolver;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.PropertyResolver;
/*     */ import org.springframework.data.cassandra.config.CassandraEntityClassScanner;
/*     */ import org.springframework.data.cassandra.config.CassandraSessionFactoryBean;
/*     */ import org.springframework.data.cassandra.config.SchemaAction;
/*     */ import org.springframework.data.cassandra.convert.CassandraConverter;
/*     */ import org.springframework.data.cassandra.convert.MappingCassandraConverter;
/*     */ import org.springframework.data.cassandra.core.CassandraAdminOperations;
/*     */ import org.springframework.data.cassandra.core.CassandraTemplate;
/*     */ import org.springframework.data.cassandra.mapping.BasicCassandraMappingContext;
/*     */ import org.springframework.data.cassandra.mapping.CassandraMappingContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @ConditionalOnClass({Cluster.class, CassandraAdminOperations.class})
/*     */ @EnableConfigurationProperties({CassandraProperties.class})
/*     */ @AutoConfigureAfter({CassandraAutoConfiguration.class})
/*     */ public class CassandraDataAutoConfiguration
/*     */ {
/*     */   private final BeanFactory beanFactory;
/*     */   private final CassandraProperties properties;
/*     */   private final Cluster cluster;
/*     */   private final PropertyResolver propertyResolver;
/*     */   
/*     */   public CassandraDataAutoConfiguration(BeanFactory beanFactory, CassandraProperties properties, Cluster cluster, Environment environment)
/*     */   {
/*  73 */     this.beanFactory = beanFactory;
/*  74 */     this.properties = properties;
/*  75 */     this.cluster = cluster;
/*  76 */     this.propertyResolver = new RelaxedPropertyResolver(environment, "spring.data.cassandra.");
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public CassandraMappingContext cassandraMapping() throws ClassNotFoundException
/*     */   {
/*  83 */     BasicCassandraMappingContext context = new BasicCassandraMappingContext();
/*     */     
/*  85 */     List<String> packages = EntityScanPackages.get(this.beanFactory).getPackageNames();
/*  86 */     if ((packages.isEmpty()) && (AutoConfigurationPackages.has(this.beanFactory))) {
/*  87 */       packages = AutoConfigurationPackages.get(this.beanFactory);
/*     */     }
/*  89 */     if (!packages.isEmpty()) {
/*  90 */       context.setInitialEntitySet(CassandraEntityClassScanner.scan(packages));
/*     */     }
/*  92 */     return context;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public CassandraConverter cassandraConverter(CassandraMappingContext mapping) {
/*  98 */     return new MappingCassandraConverter(mapping);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({Session.class})
/*     */   public CassandraSessionFactoryBean session(CassandraConverter converter) throws Exception
/*     */   {
/* 105 */     CassandraSessionFactoryBean session = new CassandraSessionFactoryBean();
/* 106 */     session.setCluster(this.cluster);
/* 107 */     session.setConverter(converter);
/* 108 */     session.setKeyspaceName(this.properties.getKeyspaceName());
/* 109 */     SchemaAction schemaAction = (SchemaAction)this.propertyResolver.getProperty("schemaAction", SchemaAction.class, SchemaAction.NONE);
/*     */     
/* 111 */     session.setSchemaAction(schemaAction);
/* 112 */     return session;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public CassandraTemplate cassandraTemplate(Session session, CassandraConverter converter) throws Exception
/*     */   {
/* 119 */     return new CassandraTemplate(session, converter);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\data\cassandra\CassandraDataAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */