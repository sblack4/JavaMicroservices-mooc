/*     */ package org.springframework.boot.autoconfigure.batch;
/*     */ 
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.batch")
/*     */ public class BatchProperties
/*     */ {
/*     */   private static final String DEFAULT_SCHEMA_LOCATION = "classpath:org/springframework/batch/core/schema-@@platform@@.sql";
/*  37 */   private String schema = "classpath:org/springframework/batch/core/schema-@@platform@@.sql";
/*     */   
/*     */ 
/*     */ 
/*     */   private String tablePrefix;
/*     */   
/*     */ 
/*  44 */   private final Initializer initializer = new Initializer();
/*     */   
/*  46 */   private final Job job = new Job();
/*     */   
/*     */   public String getSchema() {
/*  49 */     return this.schema;
/*     */   }
/*     */   
/*     */   public void setSchema(String schema) {
/*  53 */     this.schema = schema;
/*     */   }
/*     */   
/*     */   public Initializer getInitializer() {
/*  57 */     return this.initializer;
/*     */   }
/*     */   
/*     */   public Job getJob() {
/*  61 */     return this.job;
/*     */   }
/*     */   
/*     */   public void setTablePrefix(String tablePrefix) {
/*  65 */     this.tablePrefix = tablePrefix;
/*     */   }
/*     */   
/*     */   public String getTablePrefix() {
/*  69 */     return this.tablePrefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Initializer
/*     */   {
/*  77 */     private boolean enabled = true;
/*     */     
/*     */     public boolean isEnabled() {
/*  80 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/*  84 */       this.enabled = enabled;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Job
/*     */   {
/*  95 */     private String names = "";
/*     */     
/*     */     public String getNames() {
/*  98 */       return this.names;
/*     */     }
/*     */     
/*     */     public void setNames(String names) {
/* 102 */       this.names = names;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\batch\BatchProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */