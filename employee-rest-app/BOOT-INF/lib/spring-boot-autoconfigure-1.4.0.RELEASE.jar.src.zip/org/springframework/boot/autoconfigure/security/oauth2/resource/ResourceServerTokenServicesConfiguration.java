/*     */ package org.springframework.boot.autoconfigure.security.oauth2.resource;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingClass;
/*     */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*     */ import org.springframework.boot.bind.RelaxedPropertyResolver;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpRequest;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.ResponseEntity;
/*     */ import org.springframework.http.client.ClientHttpRequestExecution;
/*     */ import org.springframework.http.client.ClientHttpRequestInterceptor;
/*     */ import org.springframework.http.client.ClientHttpResponse;
/*     */ import org.springframework.security.crypto.codec.Base64;
/*     */ import org.springframework.security.oauth2.client.OAuth2ClientContext;
/*     */ import org.springframework.security.oauth2.client.OAuth2RestOperations;
/*     */ import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
/*     */ import org.springframework.security.oauth2.client.token.AccessTokenRequest;
/*     */ import org.springframework.security.oauth2.client.token.RequestEnhancer;
/*     */ import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerEndpointsConfiguration;
/*     */ import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
/*     */ import org.springframework.security.oauth2.provider.token.RemoteTokenServices;
/*     */ import org.springframework.security.oauth2.provider.token.ResourceServerTokenServices;
/*     */ import org.springframework.security.oauth2.provider.token.TokenStore;
/*     */ import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
/*     */ import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;
/*     */ import org.springframework.social.connect.ConnectionFactoryLocator;
/*     */ import org.springframework.social.connect.support.OAuth2ConnectionFactory;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.client.ResourceAccessException;
/*     */ import org.springframework.web.client.RestTemplate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @ConditionalOnMissingBean({AuthorizationServerEndpointsConfiguration.class})
/*     */ public class ResourceServerTokenServicesConfiguration
/*     */ {
/*  82 */   private static final Log logger = LogFactory.getLog(ResourceServerTokenServicesConfiguration.class);
/*     */   
/*     */ 
/*     */ 
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public UserInfoRestTemplateFactory userInfoRestTemplateFactory(ObjectProvider<List<UserInfoRestTemplateCustomizer>> customizersProvider, ObjectProvider<OAuth2ProtectedResourceDetails> detailsProvider, ObjectProvider<OAuth2ClientContext> oauth2ClientContextProvider)
/*     */   {
/*  90 */     return new UserInfoRestTemplateFactory(customizersProvider, detailsProvider, oauth2ClientContextProvider);
/*     */   }
/*     */   
/*     */   @Configuration
/*     */   @Conditional({ResourceServerTokenServicesConfiguration.NotJwtTokenCondition.class})
/*     */   protected static class RemoteTokenServicesConfiguration
/*     */   {
/*     */     @Configuration
/*     */     @Conditional({ResourceServerTokenServicesConfiguration.TokenInfoCondition.class})
/*     */     protected static class TokenInfoServicesConfiguration
/*     */     {
/*     */       private final ResourceServerProperties resource;
/*     */       
/*     */       protected TokenInfoServicesConfiguration(ResourceServerProperties resource)
/*     */       {
/* 105 */         this.resource = resource;
/*     */       }
/*     */       
/*     */       @Bean
/*     */       public RemoteTokenServices remoteTokenServices() {
/* 110 */         RemoteTokenServices services = new RemoteTokenServices();
/* 111 */         services.setCheckTokenEndpointUrl(this.resource.getTokenInfoUri());
/* 112 */         services.setClientId(this.resource.getClientId());
/* 113 */         services.setClientSecret(this.resource.getClientSecret());
/* 114 */         return services;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     @Configuration
/*     */     @ConditionalOnClass({OAuth2ConnectionFactory.class})
/*     */     @Conditional({ResourceServerTokenServicesConfiguration.NotTokenInfoCondition.class})
/*     */     protected static class SocialTokenServicesConfiguration
/*     */     {
/*     */       private final ResourceServerProperties sso;
/*     */       
/*     */ 
/*     */       private final OAuth2ConnectionFactory<?> connectionFactory;
/*     */       
/*     */       private final OAuth2RestOperations restTemplate;
/*     */       
/*     */       private final AuthoritiesExtractor authoritiesExtractor;
/*     */       
/*     */       private final PrincipalExtractor principalExtractor;
/*     */       
/*     */ 
/*     */       public SocialTokenServicesConfiguration(ResourceServerProperties sso, ObjectProvider<OAuth2ConnectionFactory<?>> connectionFactoryProvider, UserInfoRestTemplateFactory restTemplateFactory, ObjectProvider<AuthoritiesExtractor> authoritiesExtractor, ObjectProvider<PrincipalExtractor> principalExtractor)
/*     */       {
/* 139 */         this.sso = sso;
/* 140 */         this.connectionFactory = ((OAuth2ConnectionFactory)connectionFactoryProvider.getIfAvailable());
/* 141 */         this.restTemplate = restTemplateFactory.getUserInfoRestTemplate();
/* 142 */         this.authoritiesExtractor = ((AuthoritiesExtractor)authoritiesExtractor.getIfAvailable());
/* 143 */         this.principalExtractor = ((PrincipalExtractor)principalExtractor.getIfAvailable());
/*     */       }
/*     */       
/*     */       @Bean
/*     */       @ConditionalOnBean({ConnectionFactoryLocator.class})
/*     */       @ConditionalOnMissingBean({ResourceServerTokenServices.class})
/*     */       public SpringSocialTokenServices socialTokenServices()
/*     */       {
/* 151 */         return new SpringSocialTokenServices(this.connectionFactory, this.sso.getClientId());
/*     */       }
/*     */       
/*     */ 
/*     */       @Bean
/*     */       @ConditionalOnMissingBean({ConnectionFactoryLocator.class, ResourceServerTokenServices.class})
/*     */       public UserInfoTokenServices userInfoTokenServices()
/*     */       {
/* 159 */         UserInfoTokenServices services = new UserInfoTokenServices(this.sso.getUserInfoUri(), this.sso.getClientId());
/* 160 */         services.setTokenType(this.sso.getTokenType());
/* 161 */         services.setRestTemplate(this.restTemplate);
/* 162 */         if (this.authoritiesExtractor != null) {
/* 163 */           services.setAuthoritiesExtractor(this.authoritiesExtractor);
/*     */         }
/* 165 */         if (this.principalExtractor != null) {
/* 166 */           services.setPrincipalExtractor(this.principalExtractor);
/*     */         }
/* 168 */         return services;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     @Configuration
/*     */     @ConditionalOnMissingClass({"org.springframework.social.connect.support.OAuth2ConnectionFactory"})
/*     */     @Conditional({ResourceServerTokenServicesConfiguration.NotTokenInfoCondition.class})
/*     */     protected static class UserInfoTokenServicesConfiguration
/*     */     {
/*     */       private final ResourceServerProperties sso;
/*     */       
/*     */       private final OAuth2RestOperations restTemplate;
/*     */       
/*     */       private final AuthoritiesExtractor authoritiesExtractor;
/*     */       
/*     */       private final PrincipalExtractor principalExtractor;
/*     */       
/*     */ 
/*     */       public UserInfoTokenServicesConfiguration(ResourceServerProperties sso, UserInfoRestTemplateFactory restTemplateFactory, ObjectProvider<AuthoritiesExtractor> authoritiesExtractor, ObjectProvider<PrincipalExtractor> principalExtractor)
/*     */       {
/* 190 */         this.sso = sso;
/* 191 */         this.restTemplate = restTemplateFactory.getUserInfoRestTemplate();
/* 192 */         this.authoritiesExtractor = ((AuthoritiesExtractor)authoritiesExtractor.getIfAvailable());
/* 193 */         this.principalExtractor = ((PrincipalExtractor)principalExtractor.getIfAvailable());
/*     */       }
/*     */       
/*     */       @Bean
/*     */       @ConditionalOnMissingBean({ResourceServerTokenServices.class})
/*     */       public UserInfoTokenServices userInfoTokenServices()
/*     */       {
/* 200 */         UserInfoTokenServices services = new UserInfoTokenServices(this.sso.getUserInfoUri(), this.sso.getClientId());
/* 201 */         services.setRestTemplate(this.restTemplate);
/* 202 */         services.setTokenType(this.sso.getTokenType());
/* 203 */         if (this.authoritiesExtractor != null) {
/* 204 */           services.setAuthoritiesExtractor(this.authoritiesExtractor);
/*     */         }
/* 206 */         if (this.principalExtractor != null) {
/* 207 */           services.setPrincipalExtractor(this.principalExtractor);
/*     */         }
/* 209 */         return services;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Configuration
/*     */   @Conditional({ResourceServerTokenServicesConfiguration.JwtTokenCondition.class})
/*     */   protected static class JwtTokenServicesConfiguration
/*     */   {
/* 220 */     private RestTemplate keyUriRestTemplate = new RestTemplate();
/*     */     
/*     */     private final ResourceServerProperties resource;
/*     */     
/*     */     private final List<JwtAccessTokenConverterConfigurer> configurers;
/*     */     
/*     */     public JwtTokenServicesConfiguration(ResourceServerProperties resource, ObjectProvider<List<JwtAccessTokenConverterConfigurer>> configurersProvider)
/*     */     {
/* 228 */       this.resource = resource;
/* 229 */       this.configurers = ((List)configurersProvider.getIfAvailable());
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({ResourceServerTokenServices.class})
/*     */     public DefaultTokenServices jwtTokenServices() {
/* 235 */       DefaultTokenServices services = new DefaultTokenServices();
/* 236 */       services.setTokenStore(jwtTokenStore());
/* 237 */       return services;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     public TokenStore jwtTokenStore() {
/* 242 */       return new JwtTokenStore(jwtTokenEnhancer());
/*     */     }
/*     */     
/*     */     @Bean
/*     */     public JwtAccessTokenConverter jwtTokenEnhancer() {
/* 247 */       JwtAccessTokenConverter converter = new JwtAccessTokenConverter();
/* 248 */       String keyValue = this.resource.getJwt().getKeyValue();
/* 249 */       if (!StringUtils.hasText(keyValue)) {
/*     */         try {
/* 251 */           keyValue = getKeyFromServer();
/*     */         }
/*     */         catch (ResourceAccessException ex) {
/* 254 */           ResourceServerTokenServicesConfiguration.logger.warn("Failed to fetch token key (you may need to refresh when the auth server is back)");
/*     */         }
/*     */       }
/*     */       
/* 258 */       if ((StringUtils.hasText(keyValue)) && (!keyValue.startsWith("-----BEGIN"))) {
/* 259 */         converter.setSigningKey(keyValue);
/*     */       }
/* 261 */       if (keyValue != null) {
/* 262 */         converter.setVerifierKey(keyValue);
/*     */       }
/* 264 */       if (!CollectionUtils.isEmpty(this.configurers)) {
/* 265 */         AnnotationAwareOrderComparator.sort(this.configurers);
/* 266 */         for (JwtAccessTokenConverterConfigurer configurer : this.configurers) {
/* 267 */           configurer.configure(converter);
/*     */         }
/*     */       }
/* 270 */       return converter;
/*     */     }
/*     */     
/*     */     private String getKeyFromServer() {
/* 274 */       HttpHeaders headers = new HttpHeaders();
/* 275 */       String username = this.resource.getClientId();
/* 276 */       String password = this.resource.getClientSecret();
/* 277 */       if ((username != null) && (password != null)) {
/* 278 */         byte[] token = Base64.encode((username + ":" + password).getBytes());
/* 279 */         headers.add("Authorization", "Basic " + new String(token));
/*     */       }
/* 281 */       HttpEntity<Void> request = new HttpEntity(headers);
/* 282 */       String url = this.resource.getJwt().getKeyUri();
/*     */       
/*     */ 
/* 285 */       return (String)((Map)this.keyUriRestTemplate.exchange(url, HttpMethod.GET, request, Map.class, new Object[0]).getBody()).get("value");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class TokenInfoCondition
/*     */     extends SpringBootCondition
/*     */   {
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*     */     {
/* 295 */       Environment environment = context.getEnvironment();
/* 296 */       RelaxedPropertyResolver resolver = new RelaxedPropertyResolver(environment, "security.oauth2.resource.");
/*     */       
/* 298 */       Boolean preferTokenInfo = (Boolean)resolver.getProperty("prefer-token-info", Boolean.class);
/*     */       
/* 300 */       if (preferTokenInfo == null) {
/* 301 */         preferTokenInfo = Boolean.valueOf(environment
/* 302 */           .resolvePlaceholders("${OAUTH2_RESOURCE_PREFERTOKENINFO:true}")
/* 303 */           .equals("true"));
/*     */       }
/* 305 */       String tokenInfoUri = resolver.getProperty("token-info-uri");
/* 306 */       String userInfoUri = resolver.getProperty("user-info-uri");
/* 307 */       if (!StringUtils.hasLength(userInfoUri)) {
/* 308 */         return ConditionOutcome.match("No user info provided");
/*     */       }
/* 310 */       if ((StringUtils.hasLength(tokenInfoUri)) && (preferTokenInfo.booleanValue())) {
/* 311 */         return ConditionOutcome.match("Token info endpoint is preferred and user info provided");
/*     */       }
/*     */       
/* 314 */       return ConditionOutcome.noMatch("Token info endpoint is not provided");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class JwtTokenCondition
/*     */     extends SpringBootCondition
/*     */   {
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*     */     {
/* 325 */       RelaxedPropertyResolver resolver = new RelaxedPropertyResolver(context.getEnvironment(), "security.oauth2.resource.jwt.");
/* 326 */       String keyValue = resolver.getProperty("key-value");
/* 327 */       String keyUri = resolver.getProperty("key-uri");
/* 328 */       if ((StringUtils.hasText(keyValue)) || (StringUtils.hasText(keyUri))) {
/* 329 */         return ConditionOutcome.match("public key is provided");
/*     */       }
/* 331 */       return ConditionOutcome.noMatch("public key is not provided");
/*     */     }
/*     */   }
/*     */   
/*     */   private static class NotTokenInfoCondition
/*     */     extends SpringBootCondition
/*     */   {
/* 338 */     private ResourceServerTokenServicesConfiguration.TokenInfoCondition tokenInfoCondition = new ResourceServerTokenServicesConfiguration.TokenInfoCondition(null);
/*     */     
/*     */ 
/*     */ 
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*     */     {
/* 344 */       return ConditionOutcome.inverse(this.tokenInfoCondition.getMatchOutcome(context, metadata));
/*     */     }
/*     */   }
/*     */   
/*     */   private static class NotJwtTokenCondition
/*     */     extends SpringBootCondition
/*     */   {
/* 351 */     private ResourceServerTokenServicesConfiguration.JwtTokenCondition jwtTokenCondition = new ResourceServerTokenServicesConfiguration.JwtTokenCondition(null);
/*     */     
/*     */ 
/*     */ 
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*     */     {
/* 357 */       return ConditionOutcome.inverse(this.jwtTokenCondition.getMatchOutcome(context, metadata));
/*     */     }
/*     */   }
/*     */   
/*     */   static class AcceptJsonRequestInterceptor
/*     */     implements ClientHttpRequestInterceptor
/*     */   {
/*     */     public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
/*     */       throws IOException
/*     */     {
/* 367 */       request.getHeaders().setAccept(Arrays.asList(new MediaType[] { MediaType.APPLICATION_JSON }));
/* 368 */       return execution.execute(request, body);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static class AcceptJsonRequestEnhancer
/*     */     implements RequestEnhancer
/*     */   {
/*     */     public void enhance(AccessTokenRequest request, OAuth2ProtectedResourceDetails resource, MultiValueMap<String, String> form, HttpHeaders headers)
/*     */     {
/* 379 */       headers.setAccept(Arrays.asList(new MediaType[] { MediaType.APPLICATION_JSON }));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\security\oauth2\resource\ResourceServerTokenServicesConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */