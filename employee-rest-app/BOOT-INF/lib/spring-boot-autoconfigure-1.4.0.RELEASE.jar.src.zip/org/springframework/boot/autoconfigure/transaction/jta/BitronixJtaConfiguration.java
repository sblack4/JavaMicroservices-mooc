/*     */ package org.springframework.boot.autoconfigure.transaction.jta;
/*     */ 
/*     */ import bitronix.tm.BitronixTransactionManager;
/*     */ import bitronix.tm.TransactionManagerServices;
/*     */ import bitronix.tm.jndi.BitronixContext;
/*     */ import java.io.File;
/*     */ import javax.jms.Message;
/*     */ import javax.transaction.TransactionManager;
/*     */ import org.springframework.boot.ApplicationHome;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.jta.XAConnectionFactoryWrapper;
/*     */ import org.springframework.boot.jta.XADataSourceWrapper;
/*     */ import org.springframework.boot.jta.bitronix.BitronixDependentBeanFactoryPostProcessor;
/*     */ import org.springframework.boot.jta.bitronix.BitronixXAConnectionFactoryWrapper;
/*     */ import org.springframework.boot.jta.bitronix.BitronixXADataSourceWrapper;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ import org.springframework.transaction.jta.JtaTransactionManager;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @org.springframework.context.annotation.Configuration
/*     */ @ConditionalOnClass({JtaTransactionManager.class, BitronixContext.class})
/*     */ @ConditionalOnMissingBean({PlatformTransactionManager.class})
/*     */ class BitronixJtaConfiguration
/*     */ {
/*     */   private final JtaProperties jtaProperties;
/*     */   
/*     */   BitronixJtaConfiguration(JtaProperties jtaProperties)
/*     */   {
/*  59 */     this.jtaProperties = jtaProperties;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   @ConfigurationProperties("spring.jta.bitronix.properties")
/*     */   public bitronix.tm.Configuration bitronixConfiguration() {
/*  66 */     bitronix.tm.Configuration config = TransactionManagerServices.getConfiguration();
/*  67 */     if (StringUtils.hasText(this.jtaProperties.getTransactionManagerId())) {
/*  68 */       config.setServerId(this.jtaProperties.getTransactionManagerId());
/*     */     }
/*  70 */     File logBaseDir = getLogBaseDir();
/*  71 */     config.setLogPart1Filename(new File(logBaseDir, "part1.btm").getAbsolutePath());
/*  72 */     config.setLogPart2Filename(new File(logBaseDir, "part2.btm").getAbsolutePath());
/*  73 */     config.setDisableJmx(true);
/*  74 */     return config;
/*     */   }
/*     */   
/*     */   private File getLogBaseDir() {
/*  78 */     if (StringUtils.hasLength(this.jtaProperties.getLogDir())) {
/*  79 */       return new File(this.jtaProperties.getLogDir());
/*     */     }
/*  81 */     File home = new ApplicationHome().getDir();
/*  82 */     return new File(home, "transaction-logs");
/*     */   }
/*     */   
/*     */ 
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({TransactionManager.class})
/*     */   public BitronixTransactionManager bitronixTransactionManager(bitronix.tm.Configuration configuration)
/*     */   {
/*  90 */     return TransactionManagerServices.getTransactionManager();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({XADataSourceWrapper.class})
/*     */   public BitronixXADataSourceWrapper xaDataSourceWrapper() {
/*  96 */     return new BitronixXADataSourceWrapper();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public static BitronixDependentBeanFactoryPostProcessor bitronixDependentBeanFactoryPostProcessor() {
/* 102 */     return new BitronixDependentBeanFactoryPostProcessor();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   public JtaTransactionManager transactionManager(TransactionManager transactionManager)
/*     */   {
/* 108 */     return new JtaTransactionManager(transactionManager);
/*     */   }
/*     */   
/*     */   @ConditionalOnClass({Message.class})
/*     */   static class BitronixJtaJmsConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({XAConnectionFactoryWrapper.class})
/*     */     public BitronixXAConnectionFactoryWrapper xaConnectionFactoryWrapper() {
/* 117 */       return new BitronixXAConnectionFactoryWrapper();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\transaction\jta\BitronixJtaConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */