/*    */ package org.springframework.boot.autoconfigure.jms.hornetq;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.util.Set;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hornetq.api.core.TransportConfiguration;
/*    */ import org.hornetq.core.config.Configuration;
/*    */ import org.hornetq.core.config.impl.ConfigurationImpl;
/*    */ import org.hornetq.core.remoting.impl.invm.InVMAcceptorFactory;
/*    */ import org.hornetq.core.server.JournalType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ class HornetQEmbeddedConfigurationFactory
/*    */ {
/* 43 */   private static final Log logger = LogFactory.getLog(HornetQEmbeddedConfigurationFactory.class);
/*    */   private final HornetQProperties.Embedded properties;
/*    */   
/*    */   HornetQEmbeddedConfigurationFactory(HornetQProperties properties)
/*    */   {
/* 48 */     this.properties = properties.getEmbedded();
/*    */   }
/*    */   
/*    */   public Configuration createConfiguration() {
/* 52 */     ConfigurationImpl configuration = new ConfigurationImpl();
/* 53 */     configuration.setSecurityEnabled(false);
/* 54 */     configuration.setPersistenceEnabled(this.properties.isPersistent());
/*    */     
/* 56 */     String dataDir = getDataDir();
/*    */     
/*    */ 
/* 59 */     configuration.setJournalDirectory(dataDir + "/journal");
/*    */     
/* 61 */     if (this.properties.isPersistent()) {
/* 62 */       configuration.setJournalType(JournalType.NIO);
/* 63 */       configuration.setLargeMessagesDirectory(dataDir + "/largemessages");
/* 64 */       configuration.setBindingsDirectory(dataDir + "/bindings");
/* 65 */       configuration.setPagingDirectory(dataDir + "/paging");
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 70 */     TransportConfiguration transportConfiguration = new TransportConfiguration(InVMAcceptorFactory.class.getName(), this.properties.generateTransportParameters());
/* 71 */     configuration.getAcceptorConfigurations().add(transportConfiguration);
/*    */     
/*    */ 
/* 74 */     if (this.properties.isDefaultClusterPassword()) {
/* 75 */       logger.debug("Using default HornetQ cluster password: " + this.properties
/* 76 */         .getClusterPassword());
/*    */     }
/*    */     
/* 79 */     configuration.setClusterPassword(this.properties.getClusterPassword());
/* 80 */     return configuration;
/*    */   }
/*    */   
/*    */   private String getDataDir() {
/* 84 */     if (this.properties.getDataDirectory() != null) {
/* 85 */       return this.properties.getDataDirectory();
/*    */     }
/* 87 */     String tempDirectory = System.getProperty("java.io.tmpdir");
/* 88 */     return new File(tempDirectory, "hornetq-data").getAbsolutePath();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jms\hornetq\HornetQEmbeddedConfigurationFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */