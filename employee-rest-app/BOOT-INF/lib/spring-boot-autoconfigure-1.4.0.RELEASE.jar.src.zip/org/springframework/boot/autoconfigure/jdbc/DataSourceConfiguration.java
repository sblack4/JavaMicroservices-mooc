/*     */ package org.springframework.boot.autoconfigure.jdbc;
/*     */ 
/*     */ import com.zaxxer.hikari.HikariDataSource;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.jdbc.DatabaseDriver;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class DataSourceConfiguration
/*     */ {
/*     */   protected <T> T createDataSource(DataSourceProperties properties, Class<? extends javax.sql.DataSource> type)
/*     */   {
/*  44 */     return DataSourceBuilder.create(properties.getClassLoader()).type(type).driverClassName(properties.determineDriverClassName()).url(properties.determineUrl()).username(properties.determineUsername()).password(properties.determinePassword()).build();
/*     */   }
/*     */   
/*     */   @ConditionalOnClass({org.apache.tomcat.jdbc.pool.DataSource.class})
/*     */   @ConditionalOnProperty(name={"spring.datasource.type"}, havingValue="org.apache.tomcat.jdbc.pool.DataSource", matchIfMissing=true)
/*     */   static class Tomcat extends DataSourceConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConfigurationProperties("spring.datasource.tomcat")
/*     */     public org.apache.tomcat.jdbc.pool.DataSource dataSource(DataSourceProperties properties)
/*     */     {
/*  55 */       org.apache.tomcat.jdbc.pool.DataSource dataSource = (org.apache.tomcat.jdbc.pool.DataSource)createDataSource(properties, org.apache.tomcat.jdbc.pool.DataSource.class);
/*     */       
/*     */ 
/*  58 */       DatabaseDriver databaseDriver = DatabaseDriver.fromJdbcUrl(properties.determineUrl());
/*  59 */       String validationQuery = databaseDriver.getValidationQuery();
/*  60 */       if (validationQuery != null) {
/*  61 */         dataSource.setTestOnBorrow(true);
/*  62 */         dataSource.setValidationQuery(validationQuery);
/*     */       }
/*  64 */       return dataSource;
/*     */     }
/*     */   }
/*     */   
/*     */   @ConditionalOnClass({HikariDataSource.class})
/*     */   @ConditionalOnProperty(name={"spring.datasource.type"}, havingValue="com.zaxxer.hikari.HikariDataSource", matchIfMissing=true)
/*     */   static class Hikari extends DataSourceConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConfigurationProperties("spring.datasource.hikari")
/*     */     public HikariDataSource dataSource(DataSourceProperties properties)
/*     */     {
/*  76 */       return (HikariDataSource)createDataSource(properties, HikariDataSource.class);
/*     */     }
/*     */   }
/*     */   
/*     */   @ConditionalOnClass({org.apache.commons.dbcp.BasicDataSource.class})
/*     */   @ConditionalOnProperty(name={"spring.datasource.type"}, havingValue="org.apache.commons.dbcp.BasicDataSource", matchIfMissing=true)
/*     */   static class Dbcp extends DataSourceConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConfigurationProperties("spring.datasource.dbcp")
/*     */     public org.apache.commons.dbcp.BasicDataSource dataSource(DataSourceProperties properties)
/*     */     {
/*  88 */       org.apache.commons.dbcp.BasicDataSource dataSource = (org.apache.commons.dbcp.BasicDataSource)createDataSource(properties, org.apache.commons.dbcp.BasicDataSource.class);
/*     */       
/*     */ 
/*  91 */       DatabaseDriver databaseDriver = DatabaseDriver.fromJdbcUrl(properties.determineUrl());
/*  92 */       String validationQuery = databaseDriver.getValidationQuery();
/*  93 */       if (validationQuery != null) {
/*  94 */         dataSource.setTestOnBorrow(true);
/*  95 */         dataSource.setValidationQuery(validationQuery);
/*     */       }
/*  97 */       return dataSource;
/*     */     }
/*     */   }
/*     */   
/*     */   @ConditionalOnClass({org.apache.commons.dbcp2.BasicDataSource.class})
/*     */   @ConditionalOnProperty(name={"spring.datasource.type"}, havingValue="org.apache.commons.dbcp2.BasicDataSource", matchIfMissing=true)
/*     */   static class Dbcp2 extends DataSourceConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConfigurationProperties("spring.datasource.dbcp2")
/*     */     public org.apache.commons.dbcp2.BasicDataSource dataSource(DataSourceProperties properties)
/*     */     {
/* 109 */       return (org.apache.commons.dbcp2.BasicDataSource)createDataSource(properties, org.apache.commons.dbcp2.BasicDataSource.class);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jdbc\DataSourceConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */