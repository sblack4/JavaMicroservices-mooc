/*     */ package org.springframework.boot.autoconfigure.web;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.servlet.Servlet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureOrder;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.web.filter.OrderedHiddenHttpMethodFilter;
/*     */ import org.springframework.boot.web.filter.OrderedHttpPutFormContentFilter;
/*     */ import org.springframework.boot.web.filter.OrderedRequestContextFilter;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.context.annotation.Primary;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.format.Formatter;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.format.datetime.DateFormatter;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.validation.DefaultMessageCodesResolver;
/*     */ import org.springframework.validation.MessageCodesResolver;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.bind.support.ConfigurableWebBindingInitializer;
/*     */ import org.springframework.web.context.request.RequestContextListener;
/*     */ import org.springframework.web.filter.HiddenHttpMethodFilter;
/*     */ import org.springframework.web.filter.HttpPutFormContentFilter;
/*     */ import org.springframework.web.filter.RequestContextFilter;
/*     */ import org.springframework.web.servlet.DispatcherServlet;
/*     */ import org.springframework.web.servlet.HandlerExceptionResolver;
/*     */ import org.springframework.web.servlet.LocaleResolver;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.ViewResolver;
/*     */ import org.springframework.web.servlet.config.annotation.AsyncSupportConfigurer;
/*     */ import org.springframework.web.servlet.config.annotation.ContentNegotiationConfigurer;
/*     */ import org.springframework.web.servlet.config.annotation.DelegatingWebMvcConfiguration;
/*     */ import org.springframework.web.servlet.config.annotation.ResourceChainRegistration;
/*     */ import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistration;
/*     */ import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
/*     */ import org.springframework.web.servlet.config.annotation.ViewControllerRegistration;
/*     */ import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
/*     */ import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
/*     */ import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
/*     */ import org.springframework.web.servlet.handler.AbstractHandlerExceptionResolver;
/*     */ import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
/*     */ import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver;
/*     */ import org.springframework.web.servlet.i18n.FixedLocaleResolver;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.ExceptionHandlerExceptionResolver;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
/*     */ import org.springframework.web.servlet.resource.AppCacheManifestTransformer;
/*     */ import org.springframework.web.servlet.resource.GzipResourceResolver;
/*     */ import org.springframework.web.servlet.resource.ResourceHttpRequestHandler;
/*     */ import org.springframework.web.servlet.resource.ResourceResolver;
/*     */ import org.springframework.web.servlet.resource.VersionResourceResolver;
/*     */ import org.springframework.web.servlet.view.BeanNameViewResolver;
/*     */ import org.springframework.web.servlet.view.ContentNegotiatingViewResolver;
/*     */ import org.springframework.web.servlet.view.InternalResourceViewResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @ConditionalOnWebApplication
/*     */ @ConditionalOnClass({Servlet.class, DispatcherServlet.class, WebMvcConfigurerAdapter.class})
/*     */ @ConditionalOnMissingBean({WebMvcConfigurationSupport.class})
/*     */ @AutoConfigureOrder(-2147483638)
/*     */ @AutoConfigureAfter({DispatcherServletAutoConfiguration.class})
/*     */ public class WebMvcAutoConfiguration
/*     */ {
/* 120 */   public static String DEFAULT_PREFIX = "";
/*     */   
/* 122 */   public static String DEFAULT_SUFFIX = "";
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({HiddenHttpMethodFilter.class})
/*     */   public OrderedHiddenHttpMethodFilter hiddenHttpMethodFilter() {
/* 127 */     return new OrderedHiddenHttpMethodFilter();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({HttpPutFormContentFilter.class})
/*     */   public OrderedHttpPutFormContentFilter httpPutFormContentFilter() {
/* 133 */     return new OrderedHttpPutFormContentFilter();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Configuration
/*     */   @Import({WebMvcAutoConfiguration.EnableWebMvcConfiguration.class})
/*     */   @EnableConfigurationProperties({WebMvcProperties.class, ResourceProperties.class})
/*     */   public static class WebMvcAutoConfigurationAdapter
/*     */     extends WebMvcConfigurerAdapter
/*     */   {
/* 144 */     private static final Log logger = LogFactory.getLog(WebMvcConfigurerAdapter.class);
/*     */     
/*     */ 
/*     */     private final ResourceProperties resourceProperties;
/*     */     
/*     */     private final WebMvcProperties mvcProperties;
/*     */     
/*     */     private final ListableBeanFactory beanFactory;
/*     */     
/*     */     private final HttpMessageConverters messageConverters;
/*     */     
/*     */     final WebMvcAutoConfiguration.ResourceHandlerRegistrationCustomizer resourceHandlerRegistrationCustomizer;
/*     */     
/*     */ 
/*     */     public WebMvcAutoConfigurationAdapter(ResourceProperties resourceProperties, WebMvcProperties mvcProperties, ListableBeanFactory beanFactory, HttpMessageConverters messageConverters, ObjectProvider<WebMvcAutoConfiguration.ResourceHandlerRegistrationCustomizer> resourceHandlerRegistrationCustomizerProvider)
/*     */     {
/* 160 */       this.resourceProperties = resourceProperties;
/* 161 */       this.mvcProperties = mvcProperties;
/* 162 */       this.beanFactory = beanFactory;
/* 163 */       this.messageConverters = messageConverters;
/*     */       
/* 165 */       this.resourceHandlerRegistrationCustomizer = ((WebMvcAutoConfiguration.ResourceHandlerRegistrationCustomizer)resourceHandlerRegistrationCustomizerProvider.getIfAvailable());
/*     */     }
/*     */     
/*     */     public void configureMessageConverters(List<HttpMessageConverter<?>> converters)
/*     */     {
/* 170 */       converters.addAll(this.messageConverters.getConverters());
/*     */     }
/*     */     
/*     */     public void configureAsyncSupport(AsyncSupportConfigurer configurer)
/*     */     {
/* 175 */       Long timeout = this.mvcProperties.getAsync().getRequestTimeout();
/* 176 */       if (timeout != null) {
/* 177 */         configurer.setDefaultTimeout(timeout.longValue());
/*     */       }
/*     */     }
/*     */     
/*     */     public void configureContentNegotiation(ContentNegotiationConfigurer configurer)
/*     */     {
/* 183 */       Map<String, MediaType> mediaTypes = this.mvcProperties.getMediaTypes();
/* 184 */       for (Map.Entry<String, MediaType> mediaType : mediaTypes.entrySet()) {
/* 185 */         configurer.mediaType((String)mediaType.getKey(), (MediaType)mediaType.getValue());
/*     */       }
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     public InternalResourceViewResolver defaultViewResolver() {
/* 192 */       InternalResourceViewResolver resolver = new InternalResourceViewResolver();
/* 193 */       resolver.setPrefix(this.mvcProperties.getView().getPrefix());
/* 194 */       resolver.setSuffix(this.mvcProperties.getView().getSuffix());
/* 195 */       return resolver;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnBean({View.class})
/*     */     @ConditionalOnMissingBean
/*     */     public BeanNameViewResolver beanNameViewResolver() {
/* 202 */       BeanNameViewResolver resolver = new BeanNameViewResolver();
/* 203 */       resolver.setOrder(2147483637);
/* 204 */       return resolver;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnBean({ViewResolver.class})
/*     */     @ConditionalOnMissingBean(name={"viewResolver"}, value={ContentNegotiatingViewResolver.class})
/*     */     public ContentNegotiatingViewResolver viewResolver(BeanFactory beanFactory) {
/* 211 */       ContentNegotiatingViewResolver resolver = new ContentNegotiatingViewResolver();
/* 212 */       resolver.setContentNegotiationManager(
/* 213 */         (ContentNegotiationManager)beanFactory.getBean(ContentNegotiationManager.class));
/*     */       
/*     */ 
/* 216 */       resolver.setOrder(Integer.MIN_VALUE);
/* 217 */       return resolver;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     @ConditionalOnProperty(prefix="spring.mvc", name={"locale"})
/*     */     public LocaleResolver localeResolver()
/*     */     {
/* 225 */       if (this.mvcProperties.getLocaleResolver() == WebMvcProperties.LocaleResolver.FIXED) {
/* 226 */         return new FixedLocaleResolver(this.mvcProperties.getLocale());
/*     */       }
/* 228 */       AcceptHeaderLocaleResolver localeResolver = new AcceptHeaderLocaleResolver();
/* 229 */       localeResolver.setDefaultLocale(this.mvcProperties.getLocale());
/* 230 */       return localeResolver;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnProperty(prefix="spring.mvc", name={"date-format"})
/*     */     public Formatter<Date> dateFormatter() {
/* 236 */       return new DateFormatter(this.mvcProperties.getDateFormat());
/*     */     }
/*     */     
/*     */     public MessageCodesResolver getMessageCodesResolver()
/*     */     {
/* 241 */       if (this.mvcProperties.getMessageCodesResolverFormat() != null) {
/* 242 */         DefaultMessageCodesResolver resolver = new DefaultMessageCodesResolver();
/* 243 */         resolver.setMessageCodeFormatter(this.mvcProperties
/* 244 */           .getMessageCodesResolverFormat());
/* 245 */         return resolver;
/*     */       }
/* 247 */       return null;
/*     */     }
/*     */     
/*     */     public void addFormatters(FormatterRegistry registry)
/*     */     {
/* 252 */       for (Converter<?, ?> converter : getBeansOfType(Converter.class)) {
/* 253 */         registry.addConverter(converter);
/*     */       }
/* 255 */       for (GenericConverter converter : getBeansOfType(GenericConverter.class)) {
/* 256 */         registry.addConverter(converter);
/*     */       }
/* 258 */       for (Formatter<?> formatter : getBeansOfType(Formatter.class)) {
/* 259 */         registry.addFormatter(formatter);
/*     */       }
/*     */     }
/*     */     
/*     */     private <T> Collection<T> getBeansOfType(Class<T> type) {
/* 264 */       return this.beanFactory.getBeansOfType(type).values();
/*     */     }
/*     */     
/*     */     public void addResourceHandlers(ResourceHandlerRegistry registry)
/*     */     {
/* 269 */       if (!this.resourceProperties.isAddMappings()) {
/* 270 */         logger.debug("Default resource handling disabled");
/* 271 */         return;
/*     */       }
/* 273 */       Integer cachePeriod = this.resourceProperties.getCachePeriod();
/* 274 */       if (!registry.hasMappingForPattern("/webjars/**")) {
/* 275 */         customizeResourceHandlerRegistration(registry
/* 276 */           .addResourceHandler(new String[] { "/webjars/**" })
/* 277 */           .addResourceLocations(new String[] { "classpath:/META-INF/resources/webjars/" })
/*     */           
/* 279 */           .setCachePeriod(cachePeriod));
/*     */       }
/* 281 */       String staticPathPattern = this.mvcProperties.getStaticPathPattern();
/* 282 */       if (!registry.hasMappingForPattern(staticPathPattern)) {
/* 283 */         customizeResourceHandlerRegistration(registry
/* 284 */           .addResourceHandler(new String[] { staticPathPattern })
/* 285 */           .addResourceLocations(this.resourceProperties
/* 286 */           .getStaticLocations())
/* 287 */           .setCachePeriod(cachePeriod));
/*     */       }
/*     */     }
/*     */     
/*     */     private void customizeResourceHandlerRegistration(ResourceHandlerRegistration registration)
/*     */     {
/* 293 */       if (this.resourceHandlerRegistrationCustomizer != null) {
/* 294 */         this.resourceHandlerRegistrationCustomizer.customize(registration);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public void addViewControllers(ViewControllerRegistry registry)
/*     */     {
/* 301 */       Resource page = this.resourceProperties.getWelcomePage();
/* 302 */       if (page != null) {
/* 303 */         logger.info("Adding welcome page: " + page);
/* 304 */         registry.addViewController("/").setViewName("forward:index.html");
/*     */       }
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({RequestContextListener.class, RequestContextFilter.class})
/*     */     public static RequestContextFilter requestContextFilter()
/*     */     {
/* 312 */       return new OrderedRequestContextFilter();
/*     */     }
/*     */     
/*     */     @Configuration
/*     */     @ConditionalOnProperty(value={"spring.mvc.favicon.enabled"}, matchIfMissing=true)
/*     */     public static class FaviconConfiguration
/*     */     {
/*     */       private final ResourceProperties resourceProperties;
/*     */       
/*     */       public FaviconConfiguration(ResourceProperties resourceProperties) {
/* 322 */         this.resourceProperties = resourceProperties;
/*     */       }
/*     */       
/*     */       @Bean
/*     */       public SimpleUrlHandlerMapping faviconHandlerMapping() {
/* 327 */         SimpleUrlHandlerMapping mapping = new SimpleUrlHandlerMapping();
/* 328 */         mapping.setOrder(-2147483647);
/* 329 */         mapping.setUrlMap(Collections.singletonMap("**/favicon.ico", 
/* 330 */           faviconRequestHandler()));
/* 331 */         return mapping;
/*     */       }
/*     */       
/*     */       @Bean
/*     */       public ResourceHttpRequestHandler faviconRequestHandler() {
/* 336 */         ResourceHttpRequestHandler requestHandler = new ResourceHttpRequestHandler();
/* 337 */         requestHandler
/* 338 */           .setLocations(this.resourceProperties.getFaviconLocations());
/* 339 */         return requestHandler;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Configuration
/*     */   public static class EnableWebMvcConfiguration
/*     */     extends DelegatingWebMvcConfiguration
/*     */   {
/*     */     private final WebMvcProperties mvcProperties;
/*     */     
/*     */ 
/*     */     private final ListableBeanFactory beanFactory;
/*     */     
/*     */ 
/*     */     private final WebMvcRegistrations mvcRegistrations;
/*     */     
/*     */ 
/*     */ 
/*     */     public EnableWebMvcConfiguration(ObjectProvider<WebMvcProperties> mvcPropertiesProvider, ObjectProvider<WebMvcRegistrations> mvcRegistrationsProvider, ListableBeanFactory beanFactory)
/*     */     {
/* 362 */       this.mvcProperties = ((WebMvcProperties)mvcPropertiesProvider.getIfAvailable());
/* 363 */       this.mvcRegistrations = ((WebMvcRegistrations)mvcRegistrationsProvider.getIfUnique());
/* 364 */       this.beanFactory = beanFactory;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     public RequestMappingHandlerAdapter requestMappingHandlerAdapter()
/*     */     {
/* 370 */       RequestMappingHandlerAdapter adapter = super.requestMappingHandlerAdapter();
/* 371 */       adapter.setIgnoreDefaultModelOnRedirect(this.mvcProperties == null ? true : this.mvcProperties
/* 372 */         .isIgnoreDefaultModelOnRedirect());
/* 373 */       return adapter;
/*     */     }
/*     */     
/*     */     protected RequestMappingHandlerAdapter createRequestMappingHandlerAdapter()
/*     */     {
/* 378 */       if ((this.mvcRegistrations != null) && 
/* 379 */         (this.mvcRegistrations.getRequestMappingHandlerAdapter() != null)) {
/* 380 */         return this.mvcRegistrations.getRequestMappingHandlerAdapter();
/*     */       }
/* 382 */       return super.createRequestMappingHandlerAdapter();
/*     */     }
/*     */     
/*     */ 
/*     */     @Bean
/*     */     @Primary
/*     */     public RequestMappingHandlerMapping requestMappingHandlerMapping()
/*     */     {
/* 390 */       return super.requestMappingHandlerMapping();
/*     */     }
/*     */     
/*     */     protected RequestMappingHandlerMapping createRequestMappingHandlerMapping()
/*     */     {
/* 395 */       if ((this.mvcRegistrations != null) && 
/* 396 */         (this.mvcRegistrations.getRequestMappingHandlerMapping() != null)) {
/* 397 */         return this.mvcRegistrations.getRequestMappingHandlerMapping();
/*     */       }
/* 399 */       return super.createRequestMappingHandlerMapping();
/*     */     }
/*     */     
/*     */     protected ConfigurableWebBindingInitializer getConfigurableWebBindingInitializer()
/*     */     {
/*     */       try {
/* 405 */         return (ConfigurableWebBindingInitializer)this.beanFactory.getBean(ConfigurableWebBindingInitializer.class);
/*     */       }
/*     */       catch (NoSuchBeanDefinitionException ex) {}
/* 408 */       return super.getConfigurableWebBindingInitializer();
/*     */     }
/*     */     
/*     */ 
/*     */     protected ExceptionHandlerExceptionResolver createExceptionHandlerExceptionResolver()
/*     */     {
/* 414 */       if ((this.mvcRegistrations != null) && 
/* 415 */         (this.mvcRegistrations.getExceptionHandlerExceptionResolver() != null)) {
/* 416 */         return this.mvcRegistrations.getExceptionHandlerExceptionResolver();
/*     */       }
/* 418 */       return super.createExceptionHandlerExceptionResolver();
/*     */     }
/*     */     
/*     */ 
/*     */     protected void configureHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers)
/*     */     {
/* 424 */       super.configureHandlerExceptionResolvers(exceptionResolvers);
/* 425 */       if (exceptionResolvers.isEmpty()) {
/* 426 */         addDefaultHandlerExceptionResolvers(exceptionResolvers);
/*     */       }
/* 428 */       if (this.mvcProperties.isLogResolvedException()) {
/* 429 */         for (HandlerExceptionResolver resolver : exceptionResolvers) {
/* 430 */           if ((resolver instanceof AbstractHandlerExceptionResolver))
/*     */           {
/* 432 */             ((AbstractHandlerExceptionResolver)resolver).setWarnLogCategory(resolver.getClass().getName());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @Configuration
/*     */   @ConditionalOnEnabledResourceChain
/*     */   static class ResourceChainCustomizerConfiguration
/*     */   {
/*     */     @Bean
/*     */     public WebMvcAutoConfiguration.ResourceChainResourceHandlerRegistrationCustomizer resourceHandlerRegistrationCustomizer()
/*     */     {
/* 446 */       return new WebMvcAutoConfiguration.ResourceChainResourceHandlerRegistrationCustomizer(null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static abstract interface ResourceHandlerRegistrationCustomizer
/*     */   {
/*     */     public abstract void customize(ResourceHandlerRegistration paramResourceHandlerRegistration);
/*     */   }
/*     */   
/*     */   private static class ResourceChainResourceHandlerRegistrationCustomizer
/*     */     implements WebMvcAutoConfiguration.ResourceHandlerRegistrationCustomizer
/*     */   {
/*     */     @Autowired
/* 460 */     private ResourceProperties resourceProperties = new ResourceProperties();
/*     */     
/*     */ 
/*     */     public void customize(ResourceHandlerRegistration registration)
/*     */     {
/* 465 */       ResourceProperties.Chain properties = this.resourceProperties.getChain();
/* 466 */       configureResourceChain(properties, registration
/* 467 */         .resourceChain(properties.isCache()));
/*     */     }
/*     */     
/*     */     private void configureResourceChain(ResourceProperties.Chain properties, ResourceChainRegistration chain)
/*     */     {
/* 472 */       ResourceProperties.Strategy strategy = properties.getStrategy();
/* 473 */       if ((strategy.getFixed().isEnabled()) || (strategy.getContent().isEnabled())) {
/* 474 */         chain.addResolver(getVersionResourceResolver(strategy));
/*     */       }
/* 476 */       if (properties.isGzipped()) {
/* 477 */         chain.addResolver(new GzipResourceResolver());
/*     */       }
/* 479 */       if (properties.isHtmlApplicationCache()) {
/* 480 */         chain.addTransformer(new AppCacheManifestTransformer());
/*     */       }
/*     */     }
/*     */     
/*     */     private ResourceResolver getVersionResourceResolver(ResourceProperties.Strategy properties)
/*     */     {
/* 486 */       VersionResourceResolver resolver = new VersionResourceResolver();
/* 487 */       if (properties.getFixed().isEnabled()) {
/* 488 */         String version = properties.getFixed().getVersion();
/* 489 */         String[] paths = properties.getFixed().getPaths();
/* 490 */         resolver.addFixedVersionStrategy(version, paths);
/*     */       }
/* 492 */       if (properties.getContent().isEnabled()) {
/* 493 */         String[] paths = properties.getContent().getPaths();
/* 494 */         resolver.addContentVersionStrategy(paths);
/*     */       }
/* 496 */       return resolver;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\web\WebMvcAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */