/*    */ package org.springframework.boot.autoconfigure.data.rest;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.data.rest.webmvc.config.RepositoryRestConfigurerAdapter;
/*    */ import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SpringBootRepositoryRestConfigurer
/*    */   extends RepositoryRestConfigurerAdapter
/*    */ {
/*    */   @Autowired(required=false)
/*    */   private Jackson2ObjectMapperBuilder objectMapperBuilder;
/*    */   
/*    */   public void configureJacksonObjectMapper(ObjectMapper objectMapper)
/*    */   {
/* 39 */     if (this.objectMapperBuilder != null) {
/* 40 */       this.objectMapperBuilder.configure(objectMapper);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\data\rest\SpringBootRepositoryRestConfigurer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */