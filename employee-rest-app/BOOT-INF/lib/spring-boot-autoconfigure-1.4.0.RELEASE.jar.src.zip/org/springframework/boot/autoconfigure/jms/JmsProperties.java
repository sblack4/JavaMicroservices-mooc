/*     */ package org.springframework.boot.autoconfigure.jms;
/*     */ 
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.jms")
/*     */ public class JmsProperties
/*     */ {
/*  34 */   private boolean pubSubDomain = false;
/*     */   
/*     */ 
/*     */ 
/*     */   private String jndiName;
/*     */   
/*     */ 
/*     */ 
/*  42 */   private final Listener listener = new Listener();
/*     */   
/*     */   public boolean isPubSubDomain() {
/*  45 */     return this.pubSubDomain;
/*     */   }
/*     */   
/*     */   public void setPubSubDomain(boolean pubSubDomain) {
/*  49 */     this.pubSubDomain = pubSubDomain;
/*     */   }
/*     */   
/*     */   public String getJndiName() {
/*  53 */     return this.jndiName;
/*     */   }
/*     */   
/*     */   public void setJndiName(String jndiName) {
/*  57 */     this.jndiName = jndiName;
/*     */   }
/*     */   
/*     */   public Listener getListener() {
/*  61 */     return this.listener;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Listener
/*     */   {
/*  69 */     private boolean autoStartup = true;
/*     */     
/*     */ 
/*     */ 
/*     */     private JmsProperties.AcknowledgeMode acknowledgeMode;
/*     */     
/*     */ 
/*     */ 
/*     */     private Integer concurrency;
/*     */     
/*     */ 
/*     */ 
/*     */     private Integer maxConcurrency;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isAutoStartup()
/*     */     {
/*  88 */       return this.autoStartup;
/*     */     }
/*     */     
/*     */     public void setAutoStartup(boolean autoStartup) {
/*  92 */       this.autoStartup = autoStartup;
/*     */     }
/*     */     
/*     */     public JmsProperties.AcknowledgeMode getAcknowledgeMode() {
/*  96 */       return this.acknowledgeMode;
/*     */     }
/*     */     
/*     */     public void setAcknowledgeMode(JmsProperties.AcknowledgeMode acknowledgeMode) {
/* 100 */       this.acknowledgeMode = acknowledgeMode;
/*     */     }
/*     */     
/*     */     public Integer getConcurrency() {
/* 104 */       return this.concurrency;
/*     */     }
/*     */     
/*     */     public void setConcurrency(Integer concurrency) {
/* 108 */       this.concurrency = concurrency;
/*     */     }
/*     */     
/*     */     public Integer getMaxConcurrency() {
/* 112 */       return this.maxConcurrency;
/*     */     }
/*     */     
/*     */     public void setMaxConcurrency(Integer maxConcurrency) {
/* 116 */       this.maxConcurrency = maxConcurrency;
/*     */     }
/*     */     
/*     */     public String formatConcurrency() {
/* 120 */       if (this.concurrency == null) {
/* 121 */         return this.maxConcurrency != null ? "1-" + this.maxConcurrency : null;
/*     */       }
/*     */       
/*     */ 
/* 125 */       return this.maxConcurrency != null ? this.concurrency + "-" + this.maxConcurrency : String.valueOf(this.concurrency);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static enum AcknowledgeMode
/*     */   {
/* 142 */     AUTO(1), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 149 */     CLIENT(2), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 156 */     DUPS_OK(3);
/*     */     
/*     */     private final int mode;
/*     */     
/*     */     private AcknowledgeMode(int mode) {
/* 161 */       this.mode = mode;
/*     */     }
/*     */     
/*     */     public int getMode() {
/* 165 */       return this.mode;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\jms\JmsProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */