/*     */ package org.springframework.boot.autoconfigure.couchbase;
/*     */ 
/*     */ import com.couchbase.client.java.Bucket;
/*     */ import com.couchbase.client.java.Cluster;
/*     */ import com.couchbase.client.java.CouchbaseBucket;
/*     */ import com.couchbase.client.java.CouchbaseCluster;
/*     */ import com.couchbase.client.java.cluster.ClusterInfo;
/*     */ import com.couchbase.client.java.cluster.ClusterManager;
/*     */ import com.couchbase.client.java.env.DefaultCouchbaseEnvironment;
/*     */ import com.couchbase.client.java.env.DefaultCouchbaseEnvironment.Builder;
/*     */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.ConfigurationCondition.ConfigurationPhase;
/*     */ import org.springframework.context.annotation.Primary;
/*     */ import org.springframework.data.couchbase.config.CouchbaseConfigurer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @ConditionalOnClass({CouchbaseBucket.class, Cluster.class})
/*     */ @Conditional({CouchbaseCondition.class})
/*     */ @EnableConfigurationProperties({CouchbaseProperties.class})
/*     */ public class CouchbaseAutoConfiguration
/*     */ {
/*     */   @Configuration
/*     */   @ConditionalOnMissingBean({CouchbaseConfigurer.class, CouchbaseConfiguration.class})
/*     */   public static class CouchbaseConfiguration
/*     */   {
/*     */     private final CouchbaseProperties properties;
/*     */     
/*     */     public CouchbaseConfiguration(CouchbaseProperties properties)
/*     */     {
/*  59 */       this.properties = properties;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @Primary
/*     */     public DefaultCouchbaseEnvironment couchbaseEnvironment() throws Exception {
/*  65 */       return initializeEnvironmentBuilder(this.properties).build();
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @Primary
/*     */     public Cluster couchbaseCluster() throws Exception {
/*  71 */       return CouchbaseCluster.create(couchbaseEnvironment(), this.properties
/*  72 */         .getBootstrapHosts());
/*     */     }
/*     */     
/*     */ 
/*     */     @Bean
/*     */     @Primary
/*     */     public ClusterInfo couchbaseClusterInfo()
/*     */       throws Exception
/*     */     {
/*  81 */       return couchbaseCluster().clusterManager(this.properties.getBucket().getName(), this.properties.getBucket().getPassword()).info();
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @Primary
/*     */     public Bucket couchbaseClient() throws Exception {
/*  87 */       return couchbaseCluster().openBucket(this.properties.getBucket().getName(), this.properties
/*  88 */         .getBucket().getPassword());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected DefaultCouchbaseEnvironment.Builder initializeEnvironmentBuilder(CouchbaseProperties properties)
/*     */     {
/*  98 */       CouchbaseProperties.Endpoints endpoints = properties.getEnv().getEndpoints();
/*  99 */       CouchbaseProperties.Timeouts timeouts = properties.getEnv().getTimeouts();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */       DefaultCouchbaseEnvironment.Builder builder = DefaultCouchbaseEnvironment.builder().connectTimeout(timeouts.getConnect()).kvEndpoints(endpoints.getKeyValue()).kvTimeout(timeouts.getKeyValue()).queryEndpoints(endpoints.getQuery()).queryTimeout(timeouts.getQuery()).viewEndpoints(endpoints.getView()).socketConnectTimeout(timeouts.getSocketConnect()).viewTimeout(timeouts.getView());
/* 108 */       CouchbaseProperties.Ssl ssl = properties.getEnv().getSsl();
/* 109 */       if (ssl.getEnabled().booleanValue()) {
/* 110 */         builder.sslEnabled(true);
/* 111 */         if (ssl.getKeyStore() != null) {
/* 112 */           builder.sslKeystoreFile(ssl.getKeyStore());
/*     */         }
/* 114 */         if (ssl.getKeyStorePassword() != null) {
/* 115 */           builder.sslKeystorePassword(ssl.getKeyStorePassword());
/*     */         }
/*     */       }
/* 118 */       return builder;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static class CouchbaseCondition
/*     */     extends AnyNestedCondition
/*     */   {
/*     */     CouchbaseCondition()
/*     */     {
/* 131 */       super();
/*     */     }
/*     */     
/*     */     @ConditionalOnBean({CouchbaseConfigurer.class})
/*     */     static class CouchbaseConfigurerAvailable {}
/*     */     
/*     */     @ConditionalOnProperty(prefix="spring.couchbase", name={"bootstrapHosts"})
/*     */     static class BootstrapHostsProperty {}
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\couchbase\CouchbaseAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */