/*     */ package org.springframework.boot.autoconfigure.cache;
/*     */ 
/*     */ import javax.annotation.PostConstruct;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureBefore;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.couchbase.CouchbaseAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.data.jpa.EntityManagerFactoryDependsOnPostProcessor;
/*     */ import org.springframework.boot.autoconfigure.data.redis.RedisAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.hazelcast.HazelcastAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.cache.CacheManager;
/*     */ import org.springframework.cache.interceptor.CacheAspectSupport;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.context.annotation.ImportSelector;
/*     */ import org.springframework.context.annotation.Role;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.orm.jpa.AbstractEntityManagerFactoryBean;
/*     */ import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration
/*     */ @ConditionalOnClass({CacheManager.class})
/*     */ @ConditionalOnBean({CacheAspectSupport.class})
/*     */ @ConditionalOnMissingBean(value={CacheManager.class}, name={"cacheResolver"})
/*     */ @EnableConfigurationProperties({CacheProperties.class})
/*     */ @AutoConfigureBefore({HibernateJpaAutoConfiguration.class})
/*     */ @AutoConfigureAfter({CouchbaseAutoConfiguration.class, HazelcastAutoConfiguration.class, RedisAutoConfiguration.class})
/*     */ @Import({CacheManagerCustomizers.class, CacheConfigurationImportSelector.class})
/*     */ public class CacheAutoConfiguration
/*     */ {
/*     */   static final String VALIDATOR_BEAN_NAME = "cacheAutoConfigurationValidator";
/*     */   
/*     */   @Bean
/*     */   @Role(2)
/*     */   public static CacheManagerValidatorPostProcessor cacheAutoConfigurationValidatorPostProcessor()
/*     */   {
/*  78 */     return new CacheManagerValidatorPostProcessor();
/*     */   }
/*     */   
/*     */   @Bean(name={"cacheAutoConfigurationValidator"})
/*     */   public CacheManagerValidator cacheAutoConfigurationValidator() {
/*  83 */     return new CacheManagerValidator();
/*     */   }
/*     */   
/*     */   @Configuration
/*     */   @ConditionalOnClass({LocalContainerEntityManagerFactoryBean.class})
/*     */   @ConditionalOnBean({AbstractEntityManagerFactoryBean.class})
/*     */   protected static class CacheManagerJpaDependencyConfiguration extends EntityManagerFactoryDependsOnPostProcessor
/*     */   {
/*     */     public CacheManagerJpaDependencyConfiguration()
/*     */     {
/*  93 */       super();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static class CacheManagerValidatorPostProcessor
/*     */     implements BeanFactoryPostProcessor
/*     */   {
/*     */     public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*     */       throws BeansException
/*     */     {
/* 107 */       for (String name : beanFactory.getBeanNamesForType(CacheAspectSupport.class, false, false))
/*     */       {
/* 109 */         BeanDefinition definition = beanFactory.getBeanDefinition(name);
/* 110 */         definition.setDependsOn(
/* 111 */           append(definition.getDependsOn(), "cacheAutoConfigurationValidator"));
/*     */       }
/*     */     }
/*     */     
/*     */     private String[] append(String[] array, String value) {
/* 116 */       String[] result = new String[array == null ? 1 : array.length + 1];
/* 117 */       if (array != null) {
/* 118 */         System.arraycopy(array, 0, result, 0, array.length);
/*     */       }
/* 120 */       result[(result.length - 1)] = value;
/* 121 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static class CacheManagerValidator
/*     */   {
/*     */     @Autowired
/*     */     private CacheProperties cacheProperties;
/*     */     
/*     */     @Autowired(required=false)
/*     */     private CacheManager cacheManager;
/*     */     
/*     */ 
/*     */     @PostConstruct
/*     */     public void checkHasCacheManager()
/*     */     {
/* 139 */       Assert.notNull(this.cacheManager, "No cache manager could be auto-configured, check your configuration (caching type is '" + this.cacheProperties
/*     */       
/*     */ 
/* 142 */         .getType() + "')");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static class CacheConfigurationImportSelector
/*     */     implements ImportSelector
/*     */   {
/*     */     public String[] selectImports(AnnotationMetadata importingClassMetadata)
/*     */     {
/* 153 */       CacheType[] types = CacheType.values();
/* 154 */       String[] imports = new String[types.length];
/* 155 */       for (int i = 0; i < types.length; i++) {
/* 156 */         imports[i] = CacheConfigurations.getConfigurationClass(types[i]);
/*     */       }
/* 158 */       return imports;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\cache\CacheAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */