/*     */ package org.springframework.boot.autoconfigure.security.oauth2.resource;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonIgnore;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerEndpointsConfiguration;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.validation.Validator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("security.oauth2.resource")
/*     */ public class ResourceServerProperties
/*     */   implements Validator, BeanFactoryAware
/*     */ {
/*     */   @JsonIgnore
/*     */   private final String clientId;
/*     */   @JsonIgnore
/*     */   private final String clientSecret;
/*     */   @JsonIgnore
/*     */   private ListableBeanFactory beanFactory;
/*  51 */   private String serviceId = "resource";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String id;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String userInfoUri;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String tokenInfoUri;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  71 */   private boolean preferTokenInfo = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  76 */   private String tokenType = "Bearer";
/*     */   
/*  78 */   private Jwt jwt = new Jwt();
/*     */   
/*     */   public ResourceServerProperties() {
/*  81 */     this(null, null);
/*     */   }
/*     */   
/*     */   public ResourceServerProperties(String clientId, String clientSecret) {
/*  85 */     this.clientId = clientId;
/*  86 */     this.clientSecret = clientSecret;
/*     */   }
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException
/*     */   {
/*  91 */     this.beanFactory = ((ListableBeanFactory)beanFactory);
/*     */   }
/*     */   
/*     */   public String getResourceId() {
/*  95 */     return this.id;
/*     */   }
/*     */   
/*     */   public String getServiceId() {
/*  99 */     return this.serviceId;
/*     */   }
/*     */   
/*     */   public void setServiceId(String serviceId) {
/* 103 */     this.serviceId = serviceId;
/*     */   }
/*     */   
/*     */   public String getId() {
/* 107 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(String id) {
/* 111 */     this.id = id;
/*     */   }
/*     */   
/*     */   public String getUserInfoUri() {
/* 115 */     return this.userInfoUri;
/*     */   }
/*     */   
/*     */   public void setUserInfoUri(String userInfoUri) {
/* 119 */     this.userInfoUri = userInfoUri;
/*     */   }
/*     */   
/*     */   public String getTokenInfoUri() {
/* 123 */     return this.tokenInfoUri;
/*     */   }
/*     */   
/*     */   public void setTokenInfoUri(String tokenInfoUri) {
/* 127 */     this.tokenInfoUri = tokenInfoUri;
/*     */   }
/*     */   
/*     */   public boolean isPreferTokenInfo() {
/* 131 */     return this.preferTokenInfo;
/*     */   }
/*     */   
/*     */   public void setPreferTokenInfo(boolean preferTokenInfo) {
/* 135 */     this.preferTokenInfo = preferTokenInfo;
/*     */   }
/*     */   
/*     */   public String getTokenType() {
/* 139 */     return this.tokenType;
/*     */   }
/*     */   
/*     */   public void setTokenType(String tokenType) {
/* 143 */     this.tokenType = tokenType;
/*     */   }
/*     */   
/*     */   public Jwt getJwt() {
/* 147 */     return this.jwt;
/*     */   }
/*     */   
/*     */   public void setJwt(Jwt jwt) {
/* 151 */     this.jwt = jwt;
/*     */   }
/*     */   
/*     */   public String getClientId() {
/* 155 */     return this.clientId;
/*     */   }
/*     */   
/*     */   public String getClientSecret() {
/* 159 */     return this.clientSecret;
/*     */   }
/*     */   
/*     */   public boolean supports(Class<?> clazz)
/*     */   {
/* 164 */     return ResourceServerProperties.class.isAssignableFrom(clazz);
/*     */   }
/*     */   
/*     */   public void validate(Object target, Errors errors)
/*     */   {
/* 169 */     if (countBeans(AuthorizationServerEndpointsConfiguration.class) > 0)
/*     */     {
/*     */ 
/* 172 */       return;
/*     */     }
/* 174 */     if (countBeans(ResourceServerTokenServicesConfiguration.class) == 0)
/*     */     {
/*     */ 
/* 177 */       return;
/*     */     }
/* 179 */     ResourceServerProperties resource = (ResourceServerProperties)target;
/* 180 */     if (StringUtils.hasText(this.clientId)) {
/* 181 */       if (!StringUtils.hasText(this.clientSecret)) {
/* 182 */         if (!StringUtils.hasText(resource.getUserInfoUri())) {
/* 183 */           errors.rejectValue("userInfoUri", "missing.userInfoUri", "Missing userInfoUri (no client secret available)");
/*     */         }
/*     */         
/*     */ 
/*     */       }
/* 188 */       else if ((isPreferTokenInfo()) && 
/* 189 */         (!StringUtils.hasText(resource.getTokenInfoUri()))) {
/* 190 */         if ((StringUtils.hasText(getJwt().getKeyUri())) || 
/* 191 */           (StringUtils.hasText(getJwt().getKeyValue())))
/*     */         {
/* 193 */           return;
/*     */         }
/* 195 */         if (!StringUtils.hasText(resource.getUserInfoUri())) {
/* 196 */           errors.rejectValue("tokenInfoUri", "missing.tokenInfoUri", "Missing tokenInfoUri and userInfoUri and there is no JWT verifier key");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private int countBeans(Class<?> type)
/*     */   {
/* 206 */     return BeanFactoryUtils.beanNamesForTypeIncludingAncestors(this.beanFactory, type, true, false).length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public class Jwt
/*     */   {
/*     */     private String keyValue;
/*     */     
/*     */ 
/*     */     private String keyUri;
/*     */     
/*     */ 
/*     */ 
/*     */     public Jwt() {}
/*     */     
/*     */ 
/*     */ 
/*     */     public String getKeyValue()
/*     */     {
/* 226 */       return this.keyValue;
/*     */     }
/*     */     
/*     */     public void setKeyValue(String keyValue) {
/* 230 */       this.keyValue = keyValue;
/*     */     }
/*     */     
/*     */     public void setKeyUri(String keyUri) {
/* 234 */       this.keyUri = keyUri;
/*     */     }
/*     */     
/*     */     public String getKeyUri() {
/* 238 */       if (this.keyUri != null) {
/* 239 */         return this.keyUri;
/*     */       }
/* 241 */       if ((ResourceServerProperties.this.userInfoUri != null) && 
/* 242 */         (ResourceServerProperties.this.userInfoUri.endsWith("/userinfo"))) {
/* 243 */         return ResourceServerProperties.this.userInfoUri.replace("/userinfo", "/token_key");
/*     */       }
/*     */       
/* 246 */       if (ResourceServerProperties.this.tokenInfoUri != null)
/*     */       {
/* 248 */         if (ResourceServerProperties.this.tokenInfoUri.endsWith("/check_token")) {
/* 249 */           return ResourceServerProperties.this.userInfoUri.replace("/check_token", "/token_key");
/*     */         }
/*     */       }
/* 252 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\security\oauth2\resource\ResourceServerProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */