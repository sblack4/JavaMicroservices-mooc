/*     */ package org.springframework.boot.autoconfigure.elasticsearch.jest;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.elasticsearch.jest")
/*     */ public class JestProperties
/*     */ {
/*  36 */   private List<String> uris = Collections.singletonList("http://localhost:9200");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String username;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String password;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  51 */   private int connectionTimeout = 3000;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  56 */   private int readTimeout = 3000;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  61 */   private final Proxy proxy = new Proxy();
/*     */   
/*     */   public List<String> getUris() {
/*  64 */     return this.uris;
/*     */   }
/*     */   
/*     */   public void setUris(List<String> uris) {
/*  68 */     this.uris = uris;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/*  72 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/*  76 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/*  80 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/*  84 */     this.password = password;
/*     */   }
/*     */   
/*     */   public int getConnectionTimeout() {
/*  88 */     return this.connectionTimeout;
/*     */   }
/*     */   
/*     */   public void setConnectionTimeout(int connectionTimeout) {
/*  92 */     this.connectionTimeout = connectionTimeout;
/*     */   }
/*     */   
/*     */   public int getReadTimeout() {
/*  96 */     return this.readTimeout;
/*     */   }
/*     */   
/*     */   public void setReadTimeout(int readTimeout) {
/* 100 */     this.readTimeout = readTimeout;
/*     */   }
/*     */   
/*     */   public Proxy getProxy() {
/* 104 */     return this.proxy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class Proxy
/*     */   {
/*     */     private String host;
/*     */     
/*     */ 
/*     */     private Integer port;
/*     */     
/*     */ 
/*     */ 
/*     */     public String getHost()
/*     */     {
/* 120 */       return this.host;
/*     */     }
/*     */     
/*     */     public void setHost(String host) {
/* 124 */       this.host = host;
/*     */     }
/*     */     
/*     */     public Integer getPort() {
/* 128 */       return this.port;
/*     */     }
/*     */     
/*     */     public void setPort(Integer port) {
/* 132 */       this.port = port;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\elasticsearch\jest\JestProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */