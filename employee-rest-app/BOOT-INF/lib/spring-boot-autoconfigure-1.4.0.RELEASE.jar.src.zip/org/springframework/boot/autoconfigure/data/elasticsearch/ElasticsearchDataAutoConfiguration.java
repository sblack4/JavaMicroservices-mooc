/*    */ package org.springframework.boot.autoconfigure.data.elasticsearch;
/*    */ 
/*    */ import org.elasticsearch.client.Client;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
/*    */ import org.springframework.data.elasticsearch.core.convert.ElasticsearchConverter;
/*    */ import org.springframework.data.elasticsearch.core.convert.MappingElasticsearchConverter;
/*    */ import org.springframework.data.elasticsearch.core.mapping.SimpleElasticsearchMappingContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration
/*    */ @ConditionalOnClass({Client.class, ElasticsearchTemplate.class})
/*    */ @AutoConfigureAfter({ElasticsearchAutoConfiguration.class})
/*    */ public class ElasticsearchDataAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public ElasticsearchTemplate elasticsearchTemplate(Client client, ElasticsearchConverter converter)
/*    */   {
/*    */     try
/*    */     {
/* 55 */       return new ElasticsearchTemplate(client, converter);
/*    */     }
/*    */     catch (Exception ex) {
/* 58 */       throw new IllegalStateException(ex);
/*    */     }
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public ElasticsearchConverter elasticsearchConverter(SimpleElasticsearchMappingContext mappingContext)
/*    */   {
/* 66 */     return new MappingElasticsearchConverter(mappingContext);
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public SimpleElasticsearchMappingContext mappingContext() {
/* 72 */     return new SimpleElasticsearchMappingContext();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\data\elasticsearch\ElasticsearchDataAutoConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */