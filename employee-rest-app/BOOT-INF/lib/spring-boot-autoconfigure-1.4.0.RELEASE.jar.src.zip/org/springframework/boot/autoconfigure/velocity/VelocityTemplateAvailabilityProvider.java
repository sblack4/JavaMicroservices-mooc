/*    */ package org.springframework.boot.autoconfigure.velocity;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.template.TemplateAvailabilityProvider;
/*    */ import org.springframework.boot.bind.RelaxedPropertyResolver;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.env.PropertyResolver;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class VelocityTemplateAvailabilityProvider
/*    */   implements TemplateAvailabilityProvider
/*    */ {
/*    */   public boolean isTemplateAvailable(String view, Environment environment, ClassLoader classLoader, ResourceLoader resourceLoader)
/*    */   {
/* 42 */     if (ClassUtils.isPresent("org.apache.velocity.app.VelocityEngine", classLoader)) {
/* 43 */       PropertyResolver resolver = new RelaxedPropertyResolver(environment, "spring.velocity.");
/*    */       
/* 45 */       String loaderPath = resolver.getProperty("resource-loader-path", "classpath:/templates/");
/*    */       
/* 47 */       String prefix = resolver.getProperty("prefix", "");
/*    */       
/* 49 */       String suffix = resolver.getProperty("suffix", ".vm");
/*    */       
/*    */ 
/* 52 */       return resourceLoader.getResource(loaderPath + prefix + view + suffix).exists();
/*    */     }
/* 54 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-autoconfigure-1.4.0.RELEASE.jar!\org\springframework\boot\autoconfigure\velocity\VelocityTemplateAvailabilityProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */