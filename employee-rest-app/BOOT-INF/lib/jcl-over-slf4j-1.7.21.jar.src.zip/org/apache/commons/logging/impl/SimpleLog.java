/*     */ package org.apache.commons.logging.impl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Serializable;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogConfigurationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleLog
/*     */   implements Log, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 136942970684951178L;
/*     */   protected static final String systemPrefix = "org.apache.commons.logging.simplelog.";
/*  88 */   protected static final Properties simpleLogProps = new Properties();
/*     */   
/*     */ 
/*     */   protected static final String DEFAULT_DATE_TIME_FORMAT = "yyyy/MM/dd HH:mm:ss:SSS zzz";
/*     */   
/*     */ 
/*  94 */   protected static boolean showLogName = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 100 */   protected static boolean showShortName = true;
/*     */   
/* 102 */   protected static boolean showDateTime = false;
/*     */   
/* 104 */   protected static String dateTimeFormat = "yyyy/MM/dd HH:mm:ss:SSS zzz";
/*     */   
/* 106 */   protected static DateFormat dateFormatter = null;
/*     */   
/*     */ 
/*     */   public static final int LOG_LEVEL_TRACE = 1;
/*     */   
/*     */ 
/*     */   public static final int LOG_LEVEL_DEBUG = 2;
/*     */   
/*     */ 
/*     */   public static final int LOG_LEVEL_INFO = 3;
/*     */   
/*     */ 
/*     */   public static final int LOG_LEVEL_WARN = 4;
/*     */   
/*     */ 
/*     */   public static final int LOG_LEVEL_ERROR = 5;
/*     */   
/*     */   public static final int LOG_LEVEL_FATAL = 6;
/*     */   
/*     */   public static final int LOG_LEVEL_ALL = 0;
/*     */   
/*     */   public static final int LOG_LEVEL_OFF = 7;
/*     */   
/*     */ 
/*     */   private static String getStringProperty(String name)
/*     */   {
/* 132 */     String prop = null;
/*     */     try {
/* 134 */       prop = System.getProperty(name);
/*     */     }
/*     */     catch (SecurityException e) {}
/*     */     
/* 138 */     return prop == null ? simpleLogProps.getProperty(name) : prop;
/*     */   }
/*     */   
/*     */   private static String getStringProperty(String name, String dephault) {
/* 142 */     String prop = getStringProperty(name);
/* 143 */     return prop == null ? dephault : prop;
/*     */   }
/*     */   
/*     */   private static boolean getBooleanProperty(String name, boolean dephault) {
/* 147 */     String prop = getStringProperty(name);
/* 148 */     return prop == null ? dephault : "true".equalsIgnoreCase(prop);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/* 156 */     InputStream in = getResourceAsStream("simplelog.properties");
/* 157 */     if (null != in) {
/*     */       try {
/* 159 */         simpleLogProps.load(in);
/* 160 */         in.close();
/*     */       }
/*     */       catch (IOException e) {}
/*     */     }
/*     */     
/*     */ 
/* 166 */     showLogName = getBooleanProperty("org.apache.commons.logging.simplelog.showlogname", showLogName);
/* 167 */     showShortName = getBooleanProperty("org.apache.commons.logging.simplelog.showShortLogname", showShortName);
/* 168 */     showDateTime = getBooleanProperty("org.apache.commons.logging.simplelog.showdatetime", showDateTime);
/*     */     
/* 170 */     if (showDateTime) {
/* 171 */       dateTimeFormat = getStringProperty("org.apache.commons.logging.simplelog.dateTimeFormat", dateTimeFormat);
/*     */       try {
/* 173 */         dateFormatter = new SimpleDateFormat(dateTimeFormat);
/*     */       }
/*     */       catch (IllegalArgumentException e) {
/* 176 */         dateTimeFormat = "yyyy/MM/dd HH:mm:ss:SSS zzz";
/* 177 */         dateFormatter = new SimpleDateFormat(dateTimeFormat);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 185 */   protected String logName = null;
/*     */   
/*     */   protected int currentLogLevel;
/*     */   
/* 189 */   private String shortLogName = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SimpleLog(String name)
/*     */   {
/* 201 */     this.logName = name;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 206 */     setLevel(3);
/*     */     
/*     */ 
/* 209 */     String lvl = getStringProperty("org.apache.commons.logging.simplelog.log." + this.logName);
/* 210 */     int i = String.valueOf(name).lastIndexOf(".");
/* 211 */     while ((null == lvl) && (i > -1)) {
/* 212 */       name = name.substring(0, i);
/* 213 */       lvl = getStringProperty("org.apache.commons.logging.simplelog.log." + name);
/* 214 */       i = String.valueOf(name).lastIndexOf(".");
/*     */     }
/*     */     
/* 217 */     if (null == lvl) {
/* 218 */       lvl = getStringProperty("org.apache.commons.logging.simplelog.defaultlog");
/*     */     }
/*     */     
/* 221 */     if ("all".equalsIgnoreCase(lvl)) {
/* 222 */       setLevel(0);
/* 223 */     } else if ("trace".equalsIgnoreCase(lvl)) {
/* 224 */       setLevel(1);
/* 225 */     } else if ("debug".equalsIgnoreCase(lvl)) {
/* 226 */       setLevel(2);
/* 227 */     } else if ("info".equalsIgnoreCase(lvl)) {
/* 228 */       setLevel(3);
/* 229 */     } else if ("warn".equalsIgnoreCase(lvl)) {
/* 230 */       setLevel(4);
/* 231 */     } else if ("error".equalsIgnoreCase(lvl)) {
/* 232 */       setLevel(5);
/* 233 */     } else if ("fatal".equalsIgnoreCase(lvl)) {
/* 234 */       setLevel(6);
/* 235 */     } else if ("off".equalsIgnoreCase(lvl)) {
/* 236 */       setLevel(7);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLevel(int currentLogLevel)
/*     */   {
/* 253 */     this.currentLogLevel = currentLogLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLevel()
/*     */   {
/* 264 */     return this.currentLogLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void log(int type, Object message, Throwable t)
/*     */   {
/* 284 */     StringBuffer buf = new StringBuffer();
/*     */     
/*     */ 
/* 287 */     if (showDateTime) {
/* 288 */       buf.append(dateFormatter.format(new Date()));
/* 289 */       buf.append(" ");
/*     */     }
/*     */     
/*     */ 
/* 293 */     switch (type) {
/*     */     case 1: 
/* 295 */       buf.append("[TRACE] ");
/* 296 */       break;
/*     */     case 2: 
/* 298 */       buf.append("[DEBUG] ");
/* 299 */       break;
/*     */     case 3: 
/* 301 */       buf.append("[INFO] ");
/* 302 */       break;
/*     */     case 4: 
/* 304 */       buf.append("[WARN] ");
/* 305 */       break;
/*     */     case 5: 
/* 307 */       buf.append("[ERROR] ");
/* 308 */       break;
/*     */     case 6: 
/* 310 */       buf.append("[FATAL] ");
/*     */     }
/*     */     
/*     */     
/*     */ 
/* 315 */     if (showShortName) {
/* 316 */       if (this.shortLogName == null)
/*     */       {
/* 318 */         this.shortLogName = this.logName.substring(this.logName.lastIndexOf(".") + 1);
/* 319 */         this.shortLogName = this.shortLogName.substring(this.shortLogName.lastIndexOf("/") + 1);
/*     */       }
/* 321 */       buf.append(String.valueOf(this.shortLogName)).append(" - ");
/* 322 */     } else if (showLogName) {
/* 323 */       buf.append(String.valueOf(this.logName)).append(" - ");
/*     */     }
/*     */     
/*     */ 
/* 327 */     buf.append(String.valueOf(message));
/*     */     
/*     */ 
/* 330 */     if (t != null) {
/* 331 */       buf.append(" <");
/* 332 */       buf.append(t.toString());
/* 333 */       buf.append(">");
/*     */       
/* 335 */       StringWriter sw = new StringWriter(1024);
/* 336 */       PrintWriter pw = new PrintWriter(sw);
/* 337 */       t.printStackTrace(pw);
/* 338 */       pw.close();
/* 339 */       buf.append(sw.toString());
/*     */     }
/*     */     
/*     */ 
/* 343 */     write(buf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void write(StringBuffer buffer)
/*     */   {
/* 360 */     System.err.println(buffer.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isLevelEnabled(int logLevel)
/*     */   {
/* 373 */     return logLevel >= this.currentLogLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void debug(Object message)
/*     */   {
/* 385 */     if (isLevelEnabled(2)) {
/* 386 */       log(2, message, null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void debug(Object message, Throwable t)
/*     */   {
/* 397 */     if (isLevelEnabled(2)) {
/* 398 */       log(2, message, t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void trace(Object message)
/*     */   {
/* 409 */     if (isLevelEnabled(1)) {
/* 410 */       log(1, message, null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void trace(Object message, Throwable t)
/*     */   {
/* 421 */     if (isLevelEnabled(1)) {
/* 422 */       log(1, message, t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void info(Object message)
/*     */   {
/* 433 */     if (isLevelEnabled(3)) {
/* 434 */       log(3, message, null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void info(Object message, Throwable t)
/*     */   {
/* 445 */     if (isLevelEnabled(3)) {
/* 446 */       log(3, message, t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void warn(Object message)
/*     */   {
/* 457 */     if (isLevelEnabled(4)) {
/* 458 */       log(4, message, null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void warn(Object message, Throwable t)
/*     */   {
/* 469 */     if (isLevelEnabled(4)) {
/* 470 */       log(4, message, t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void error(Object message)
/*     */   {
/* 481 */     if (isLevelEnabled(5)) {
/* 482 */       log(5, message, null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void error(Object message, Throwable t)
/*     */   {
/* 493 */     if (isLevelEnabled(5)) {
/* 494 */       log(5, message, t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void fatal(Object message)
/*     */   {
/* 505 */     if (isLevelEnabled(6)) {
/* 506 */       log(6, message, null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void fatal(Object message, Throwable t)
/*     */   {
/* 517 */     if (isLevelEnabled(6)) {
/* 518 */       log(6, message, t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isDebugEnabled()
/*     */   {
/* 534 */     return isLevelEnabled(2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isErrorEnabled()
/*     */   {
/* 549 */     return isLevelEnabled(5);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isFatalEnabled()
/*     */   {
/* 564 */     return isLevelEnabled(6);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isInfoEnabled()
/*     */   {
/* 579 */     return isLevelEnabled(3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isTraceEnabled()
/*     */   {
/* 594 */     return isLevelEnabled(1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isWarnEnabled()
/*     */   {
/* 609 */     return isLevelEnabled(4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ClassLoader getContextClassLoader()
/*     */   {
/* 622 */     ClassLoader classLoader = null;
/*     */     
/* 624 */     if (classLoader == null) {
/*     */       try
/*     */       {
/* 627 */         Method method = Thread.class.getMethod("getContextClassLoader", new Class[0]);
/*     */         
/*     */         try
/*     */         {
/* 631 */           classLoader = (ClassLoader)method.invoke(Thread.currentThread(), new Object[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         catch (IllegalAccessException e) {}catch (InvocationTargetException e)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 648 */           if (!(e.getTargetException() instanceof SecurityException))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/* 653 */             throw new LogConfigurationException("Unexpected InvocationTargetException", e.getTargetException());
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (NoSuchMethodException e) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 662 */     if (classLoader == null) {
/* 663 */       classLoader = SimpleLog.class.getClassLoader();
/*     */     }
/*     */     
/*     */ 
/* 667 */     return classLoader;
/*     */   }
/*     */   
/*     */   private static InputStream getResourceAsStream(String name) {
/* 671 */     (InputStream)AccessController.doPrivileged(new PrivilegedAction() {
/*     */       public InputStream run() {
/* 673 */         ClassLoader threadCL = SimpleLog.access$000();
/*     */         
/* 675 */         if (threadCL != null) {
/* 676 */           return threadCL.getResourceAsStream(this.val$name);
/*     */         }
/* 678 */         return ClassLoader.getSystemResourceAsStream(this.val$name);
/*     */       }
/*     */     });
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\jcl-over-slf4j-1.7.21.jar!\org\apache\commons\logging\impl\SimpleLog.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */