/*     */ package com.fasterxml.classmate;
/*     */ 
/*     */ import com.fasterxml.classmate.types.ResolvedArrayType;
/*     */ import com.fasterxml.classmate.types.ResolvedInterfaceType;
/*     */ import com.fasterxml.classmate.types.ResolvedObjectType;
/*     */ import com.fasterxml.classmate.types.ResolvedPrimitiveType;
/*     */ import com.fasterxml.classmate.types.ResolvedRecursiveType;
/*     */ import com.fasterxml.classmate.types.TypePlaceHolder;
/*     */ import com.fasterxml.classmate.util.ClassKey;
/*     */ import com.fasterxml.classmate.util.ClassStack;
/*     */ import com.fasterxml.classmate.util.ResolvedTypeCache;
/*     */ import com.fasterxml.classmate.util.ResolvedTypeCache.Key;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.lang.reflect.WildcardType;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ 
/*     */ public class TypeResolver
/*     */   implements Serializable
/*     */ {
/*  26 */   private static final ResolvedType[] NO_TYPES = new ResolvedType[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  39 */   private static final ResolvedObjectType sJavaLangObject = ResolvedObjectType.create(Object.class, null, null, null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  49 */   protected static final HashMap<ClassKey, ResolvedType> _primitiveTypes = new HashMap(16);
/*  50 */   static { for (ResolvedPrimitiveType type : ResolvedPrimitiveType.all()) {
/*  51 */       _primitiveTypes.put(new ClassKey(type.getErasedType()), type);
/*     */     }
/*     */     
/*  54 */     _primitiveTypes.put(new ClassKey(Void.TYPE), ResolvedPrimitiveType.voidType());
/*     */     
/*  56 */     _primitiveTypes.put(new ClassKey(Object.class), sJavaLangObject);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */   protected final ResolvedTypeCache _resolvedTypes = new ResolvedTypeCache(200);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResolvedType resolve(Type type, Type... typeParameters)
/*     */   {
/* 105 */     boolean noParams = (typeParameters == null) || (typeParameters.length == 0);
/*     */     Class<?> rawBase;
/*     */     TypeBindings bindings;
/*     */     Class<?> rawBase;
/* 109 */     if ((type instanceof Class)) {
/* 110 */       TypeBindings bindings = TypeBindings.emptyBindings();
/* 111 */       if (noParams) {
/* 112 */         return _fromClass(null, (Class)type, bindings);
/*     */       }
/* 114 */       rawBase = (Class)type; } else { Class<?> rawBase;
/* 115 */       if ((type instanceof GenericType)) {
/* 116 */         TypeBindings bindings = TypeBindings.emptyBindings();
/* 117 */         if (noParams) {
/* 118 */           return _fromGenericType(null, (GenericType)type, bindings);
/*     */         }
/* 120 */         ResolvedType rt = _fromAny(null, type, bindings);
/* 121 */         rawBase = rt.getErasedType(); } else { Class<?> rawBase;
/* 122 */         if ((type instanceof ResolvedType)) {
/* 123 */           ResolvedType rt = (ResolvedType)type;
/* 124 */           if (noParams) {
/* 125 */             return rt;
/*     */           }
/* 127 */           TypeBindings bindings = rt.getTypeBindings();
/* 128 */           rawBase = rt.getErasedType();
/*     */         } else {
/* 130 */           bindings = TypeBindings.emptyBindings();
/* 131 */           if (noParams) {
/* 132 */             return resolve(bindings, type);
/*     */           }
/*     */           
/* 135 */           ResolvedType rt = _fromAny(null, type, bindings);
/* 136 */           rawBase = rt.getErasedType();
/*     */         }
/*     */       }
/*     */     }
/* 140 */     int len = typeParameters.length;
/* 141 */     ResolvedType[] resolvedParams = new ResolvedType[len];
/* 142 */     for (int i = 0; i < len; i++) {
/* 143 */       resolvedParams[i] = _fromAny(null, typeParameters[i], bindings);
/*     */     }
/* 145 */     return _fromClass(null, rawBase, TypeBindings.create(rawBase, resolvedParams));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResolvedArrayType arrayType(Type elementType)
/*     */   {
/* 153 */     ResolvedType resolvedElementType = resolve(TypeBindings.emptyBindings(), elementType);
/*     */     
/* 155 */     Object emptyArray = Array.newInstance(resolvedElementType.getErasedType(), 0);
/*     */     
/* 157 */     return new ResolvedArrayType(emptyArray.getClass(), TypeBindings.emptyBindings(), resolvedElementType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResolvedType resolve(TypeBindings typeBindings, Type jdkType)
/*     */   {
/* 174 */     return _fromAny(null, jdkType, typeBindings);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResolvedType resolveSubtype(ResolvedType supertype, Class<?> subtype)
/*     */     throws IllegalArgumentException, UnsupportedOperationException
/*     */   {
/* 214 */     ResolvedType refType = supertype.getSelfReferencedType();
/* 215 */     if (refType != null) {
/* 216 */       supertype = refType;
/*     */     }
/*     */     
/* 219 */     if (supertype.getErasedType() == subtype) {
/* 220 */       return supertype;
/*     */     }
/*     */     
/* 223 */     if (!supertype.canCreateSubtypes()) {
/* 224 */       throw new UnsupportedOperationException("Can not subtype primitive or array types (type " + supertype.getFullDescription() + ")");
/*     */     }
/*     */     
/* 227 */     Class<?> superclass = supertype.getErasedType();
/* 228 */     if (!superclass.isAssignableFrom(subtype)) {
/* 229 */       throw new IllegalArgumentException("Can not sub-class " + supertype.getBriefDescription() + " into " + subtype.getName());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 234 */     int paramCount = subtype.getTypeParameters().length;
/*     */     ResolvedType resolvedSubtype;
/*     */     TypePlaceHolder[] placeholders;
/* 237 */     ResolvedType resolvedSubtype; if (paramCount == 0) {
/* 238 */       TypePlaceHolder[] placeholders = null;
/* 239 */       resolvedSubtype = resolve(subtype, new Type[0]);
/*     */     } else {
/* 241 */       placeholders = new TypePlaceHolder[paramCount];
/* 242 */       for (int i = 0; i < paramCount; i++) {
/* 243 */         placeholders[i] = new TypePlaceHolder(i);
/*     */       }
/* 245 */       resolvedSubtype = resolve(subtype, placeholders);
/*     */     }
/* 247 */     ResolvedType rawSupertype = resolvedSubtype.findSupertype(superclass);
/* 248 */     if (rawSupertype == null) {
/* 249 */       throw new IllegalArgumentException("Internal error: unable to locate supertype (" + subtype.getName() + ") for type " + supertype.getBriefDescription());
/*     */     }
/*     */     
/* 252 */     _resolveTypePlaceholders(supertype, rawSupertype);
/*     */     
/* 254 */     if (paramCount == 0) {
/* 255 */       return resolvedSubtype;
/*     */     }
/*     */     
/* 258 */     ResolvedType[] typeParams = new ResolvedType[paramCount];
/* 259 */     for (int i = 0; i < paramCount; i++) {
/* 260 */       ResolvedType t = placeholders[i].actualType();
/*     */       
/* 262 */       if (t == null) {
/* 263 */         throw new IllegalArgumentException("Failed to find type parameter #" + (i + 1) + "/" + paramCount + " for " + subtype.getName());
/*     */       }
/*     */       
/* 266 */       typeParams[i] = t;
/*     */     }
/* 268 */     return resolve(subtype, typeParams);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isSelfReference(ResolvedType type)
/*     */   {
/* 285 */     return type instanceof ResolvedRecursiveType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ResolvedType _fromAny(ClassStack context, Type mainType, TypeBindings typeBindings)
/*     */   {
/* 296 */     if ((mainType instanceof Class)) {
/* 297 */       return _fromClass(context, (Class)mainType, typeBindings);
/*     */     }
/* 299 */     if ((mainType instanceof ResolvedType)) {
/* 300 */       return (ResolvedType)mainType;
/*     */     }
/* 302 */     if ((mainType instanceof ParameterizedType)) {
/* 303 */       return _fromParamType(context, (ParameterizedType)mainType, typeBindings);
/*     */     }
/* 305 */     if ((mainType instanceof GenericType)) {
/* 306 */       return _fromGenericType(context, (GenericType)mainType, typeBindings);
/*     */     }
/* 308 */     if ((mainType instanceof GenericArrayType)) {
/* 309 */       return _fromArrayType(context, (GenericArrayType)mainType, typeBindings);
/*     */     }
/* 311 */     if ((mainType instanceof TypeVariable)) {
/* 312 */       return _fromVariable(context, (TypeVariable)mainType, typeBindings);
/*     */     }
/* 314 */     if ((mainType instanceof WildcardType)) {
/* 315 */       return _fromWildcard(context, (WildcardType)mainType, typeBindings);
/*     */     }
/*     */     
/* 318 */     throw new IllegalArgumentException("Unrecognized type class: " + mainType.getClass().getName());
/*     */   }
/*     */   
/*     */ 
/*     */   private ResolvedType _fromClass(ClassStack context, Class<?> rawType, TypeBindings typeBindings)
/*     */   {
/* 324 */     ResolvedType type = (ResolvedType)_primitiveTypes.get(new ClassKey(rawType));
/* 325 */     if (type != null) {
/* 326 */       return type;
/*     */     }
/*     */     
/* 329 */     if (context == null) {
/* 330 */       context = new ClassStack(rawType);
/*     */     } else {
/* 332 */       ClassStack prev = context.find(rawType);
/* 333 */       if (prev != null)
/*     */       {
/* 335 */         ResolvedRecursiveType selfRef = new ResolvedRecursiveType(rawType, typeBindings);
/* 336 */         prev.addSelfReference(selfRef);
/* 337 */         return selfRef;
/*     */       }
/*     */       
/* 340 */       context = context.child(rawType);
/*     */     }
/*     */     
/*     */ 
/* 344 */     ResolvedType[] typeParameters = typeBindings.typeParameterArray();
/* 345 */     ResolvedTypeCache.Key key = this._resolvedTypes.key(rawType, typeParameters);
/*     */     
/*     */ 
/* 348 */     if (key == null) {
/* 349 */       type = _constructType(context, rawType, typeBindings);
/*     */     } else {
/* 351 */       type = this._resolvedTypes.find(key);
/* 352 */       if (type == null) {
/* 353 */         type = _constructType(context, rawType, typeBindings);
/* 354 */         this._resolvedTypes.put(key, type);
/*     */       }
/*     */     }
/* 357 */     context.resolveSelfReferences(type);
/* 358 */     return type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ResolvedType _fromGenericType(ClassStack context, GenericType<?> generic, TypeBindings typeBindings)
/*     */   {
/* 372 */     ResolvedType type = _fromClass(context, generic.getClass(), typeBindings);
/* 373 */     ResolvedType genType = type.findSupertype(GenericType.class);
/* 374 */     if (genType == null) {
/* 375 */       throw new IllegalArgumentException("Unparameterized GenericType instance (" + generic.getClass().getName() + ")");
/*     */     }
/* 377 */     TypeBindings b = genType.getTypeBindings();
/* 378 */     ResolvedType[] params = b.typeParameterArray();
/* 379 */     if (params.length == 0) {
/* 380 */       throw new IllegalArgumentException("Unparameterized GenericType instance (" + generic.getClass().getName() + ")");
/*     */     }
/* 382 */     return params[0];
/*     */   }
/*     */   
/*     */ 
/*     */   private ResolvedType _constructType(ClassStack context, Class<?> rawType, TypeBindings typeBindings)
/*     */   {
/* 388 */     if (rawType.isArray()) {
/* 389 */       ResolvedType elementType = _fromAny(context, rawType.getComponentType(), typeBindings);
/* 390 */       return new ResolvedArrayType(rawType, typeBindings, elementType);
/*     */     }
/*     */     
/* 393 */     if (rawType.isInterface()) {
/* 394 */       return new ResolvedInterfaceType(rawType, typeBindings, _resolveSuperInterfaces(context, rawType, typeBindings));
/*     */     }
/*     */     
/*     */ 
/* 398 */     return new ResolvedObjectType(rawType, typeBindings, _resolveSuperClass(context, rawType, typeBindings), _resolveSuperInterfaces(context, rawType, typeBindings));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private ResolvedType[] _resolveSuperInterfaces(ClassStack context, Class<?> rawType, TypeBindings typeBindings)
/*     */   {
/* 405 */     Type[] types = rawType.getGenericInterfaces();
/* 406 */     if ((types == null) || (types.length == 0)) {
/* 407 */       return NO_TYPES;
/*     */     }
/* 409 */     int len = types.length;
/* 410 */     ResolvedType[] resolved = new ResolvedType[len];
/* 411 */     for (int i = 0; i < len; i++) {
/* 412 */       resolved[i] = _fromAny(context, types[i], typeBindings);
/*     */     }
/* 414 */     return resolved;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ResolvedType _resolveSuperClass(ClassStack context, Class<?> rawType, TypeBindings typeBindings)
/*     */   {
/* 427 */     Type parent = rawType.getGenericSuperclass();
/* 428 */     if (parent == null) {
/* 429 */       return null;
/*     */     }
/* 431 */     return _fromAny(context, parent, typeBindings);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ResolvedType _fromParamType(ClassStack context, ParameterizedType ptype, TypeBindings parentBindings)
/*     */   {
/* 440 */     Class<?> rawType = (Class)ptype.getRawType();
/* 441 */     Type[] params = ptype.getActualTypeArguments();
/* 442 */     int len = params.length;
/* 443 */     ResolvedType[] types = new ResolvedType[len];
/*     */     
/* 445 */     for (int i = 0; i < len; i++) {
/* 446 */       types[i] = _fromAny(context, params[i], parentBindings);
/*     */     }
/*     */     
/* 449 */     TypeBindings newBindings = TypeBindings.create(rawType, types);
/* 450 */     return _fromClass(context, rawType, newBindings);
/*     */   }
/*     */   
/*     */   private ResolvedType _fromArrayType(ClassStack context, GenericArrayType arrayType, TypeBindings typeBindings)
/*     */   {
/* 455 */     ResolvedType elementType = _fromAny(context, arrayType.getGenericComponentType(), typeBindings);
/*     */     
/* 457 */     Object emptyArray = Array.newInstance(elementType.getErasedType(), 0);
/* 458 */     return new ResolvedArrayType(emptyArray.getClass(), typeBindings, elementType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ResolvedType _fromWildcard(ClassStack context, WildcardType wildType, TypeBindings typeBindings)
/*     */   {
/* 468 */     return _fromAny(context, wildType.getUpperBounds()[0], typeBindings);
/*     */   }
/*     */   
/*     */ 
/*     */   private ResolvedType _fromVariable(ClassStack context, TypeVariable<?> variable, TypeBindings typeBindings)
/*     */   {
/* 474 */     String name = variable.getName();
/* 475 */     ResolvedType type = typeBindings.findBoundType(name);
/*     */     
/* 477 */     if (type != null) {
/* 478 */       return type;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 487 */     if (typeBindings.hasUnbound(name)) {
/* 488 */       return sJavaLangObject;
/*     */     }
/* 490 */     typeBindings = typeBindings.withUnboundVariable(name);
/*     */     
/* 492 */     Type[] bounds = variable.getBounds();
/* 493 */     return _fromAny(context, bounds[0], typeBindings);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void _resolveTypePlaceholders(ResolvedType expectedType, ResolvedType actualType)
/*     */     throws IllegalArgumentException
/*     */   {
/* 508 */     List<ResolvedType> expectedTypes = expectedType.getTypeParameters();
/* 509 */     List<ResolvedType> actualTypes = actualType.getTypeParameters();
/* 510 */     int i = 0; for (int len = expectedTypes.size(); i < len; i++) {
/* 511 */       ResolvedType exp = (ResolvedType)expectedTypes.get(i);
/* 512 */       ResolvedType act = (ResolvedType)actualTypes.get(i);
/* 513 */       if (!_typesMatch(exp, act)) {
/* 514 */         throw new IllegalArgumentException("Type parameter #" + (i + 1) + "/" + len + " differs; expected " + exp.getBriefDescription() + ", got " + act.getBriefDescription());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean _typesMatch(ResolvedType exp, ResolvedType act)
/*     */   {
/* 523 */     if ((act instanceof TypePlaceHolder)) {
/* 524 */       ((TypePlaceHolder)act).actualType(exp);
/* 525 */       return true;
/*     */     }
/*     */     
/* 528 */     if (exp.getErasedType() != act.getErasedType()) {
/* 529 */       return false;
/*     */     }
/*     */     
/* 532 */     List<ResolvedType> expectedTypes = exp.getTypeParameters();
/* 533 */     List<ResolvedType> actualTypes = act.getTypeParameters();
/* 534 */     int i = 0; for (int len = expectedTypes.size(); i < len; i++) {
/* 535 */       ResolvedType exp2 = (ResolvedType)expectedTypes.get(i);
/* 536 */       ResolvedType act2 = (ResolvedType)actualTypes.get(i);
/* 537 */       if (!_typesMatch(exp2, act2)) {
/* 538 */         return false;
/*     */       }
/*     */     }
/* 541 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\classmate-1.3.1.jar!\com\fasterxml\classmate\TypeResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */