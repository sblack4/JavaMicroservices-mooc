/*     */ package com.fasterxml.classmate;
/*     */ 
/*     */ import com.fasterxml.classmate.members.HierarchicType;
/*     */ import com.fasterxml.classmate.members.RawConstructor;
/*     */ import com.fasterxml.classmate.members.RawField;
/*     */ import com.fasterxml.classmate.members.RawMethod;
/*     */ import com.fasterxml.classmate.util.ClassKey;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MemberResolver
/*     */   implements Serializable
/*     */ {
/*     */   protected final TypeResolver _typeResolver;
/*     */   protected boolean _cfgIncludeLangObject;
/*     */   protected Filter<RawField> _fieldFilter;
/*     */   protected Filter<RawMethod> _methodFilter;
/*     */   protected Filter<RawConstructor> _constructorFilter;
/*     */   
/*     */   public MemberResolver(TypeResolver typeResolver)
/*     */   {
/*  72 */     this._typeResolver = typeResolver;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MemberResolver setIncludeLangObject(boolean state)
/*     */   {
/*  81 */     this._cfgIncludeLangObject = state;
/*  82 */     return this;
/*     */   }
/*     */   
/*     */   public MemberResolver setFieldFilter(Filter<RawField> f) {
/*  86 */     this._fieldFilter = f;
/*  87 */     return this;
/*     */   }
/*     */   
/*     */   public MemberResolver setMethodFilter(Filter<RawMethod> f) {
/*  91 */     this._methodFilter = f;
/*  92 */     return this;
/*     */   }
/*     */   
/*     */   public MemberResolver setConstructorFilter(Filter<RawConstructor> f) {
/*  96 */     this._constructorFilter = f;
/*  97 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResolvedTypeWithMembers resolve(ResolvedType mainType, AnnotationConfiguration annotationConfig, AnnotationOverrides annotationOverrides)
/*     */   {
/* 121 */     HashSet<ClassKey> seenTypes = new HashSet();
/* 122 */     ArrayList<ResolvedType> types = new ArrayList();
/* 123 */     _gatherTypes(mainType, seenTypes, types);
/*     */     
/*     */ 
/*     */ 
/* 127 */     HierarchicType mainHierarchicType = null;
/*     */     
/*     */     HierarchicType[] htypes;
/* 130 */     if (annotationOverrides == null) {
/* 131 */       int len = types.size();
/* 132 */       HierarchicType[] htypes = new HierarchicType[len];
/* 133 */       for (int i = 0; i < len; i++)
/*     */       {
/* 135 */         htypes[i] = new HierarchicType((ResolvedType)types.get(i), false, i);
/*     */       }
/* 137 */       mainHierarchicType = htypes[0];
/*     */     } else {
/* 139 */       ArrayList<HierarchicType> typesWithMixins = new ArrayList();
/* 140 */       for (ResolvedType type : types)
/*     */       {
/* 142 */         List<Class<?>> m = annotationOverrides.mixInsFor(type.getErasedType());
/* 143 */         if (m != null) {
/* 144 */           for (Class<?> mixinClass : m) {
/* 145 */             _addOverrides(typesWithMixins, seenTypes, mixinClass);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 150 */         HierarchicType ht = new HierarchicType(type, false, typesWithMixins.size());
/* 151 */         if (mainHierarchicType == null) {
/* 152 */           mainHierarchicType = ht;
/*     */         }
/* 154 */         typesWithMixins.add(ht);
/*     */       }
/* 156 */       htypes = (HierarchicType[])typesWithMixins.toArray(new HierarchicType[typesWithMixins.size()]);
/*     */     }
/*     */     
/* 159 */     return new ResolvedTypeWithMembers(this._typeResolver, annotationConfig, mainHierarchicType, htypes, this._constructorFilter, this._fieldFilter, this._methodFilter);
/*     */   }
/*     */   
/*     */ 
/*     */   private void _addOverrides(List<HierarchicType> typesWithOverrides, Set<ClassKey> seenTypes, Class<?> override)
/*     */   {
/* 165 */     ClassKey key = new ClassKey(override);
/* 166 */     if (!seenTypes.contains(key)) {
/* 167 */       seenTypes.add(key);
/* 168 */       ResolvedType resolvedOverride = this._typeResolver.resolve(override, new Type[0]);
/* 169 */       typesWithOverrides.add(new HierarchicType(resolvedOverride, true, typesWithOverrides.size()));
/* 170 */       for (ResolvedType r : resolvedOverride.getImplementedInterfaces()) {
/* 171 */         _addOverrides(typesWithOverrides, seenTypes, r);
/*     */       }
/* 173 */       ResolvedType superClass = resolvedOverride.getParentClass();
/* 174 */       _addOverrides(typesWithOverrides, seenTypes, superClass);
/*     */     }
/*     */   }
/*     */   
/*     */   private void _addOverrides(List<HierarchicType> typesWithOverrides, Set<ClassKey> seenTypes, ResolvedType override)
/*     */   {
/* 180 */     if (override == null) { return;
/*     */     }
/* 182 */     Class<?> raw = override.getErasedType();
/* 183 */     if ((!this._cfgIncludeLangObject) && (Object.class == raw)) return;
/* 184 */     ClassKey key = new ClassKey(raw);
/* 185 */     if (!seenTypes.contains(key)) {
/* 186 */       seenTypes.add(key);
/* 187 */       typesWithOverrides.add(new HierarchicType(override, true, typesWithOverrides.size()));
/* 188 */       for (ResolvedType r : override.getImplementedInterfaces()) {
/* 189 */         _addOverrides(typesWithOverrides, seenTypes, r);
/*     */       }
/* 191 */       ResolvedType superClass = override.getParentClass();
/* 192 */       if (superClass != null) {
/* 193 */         _addOverrides(typesWithOverrides, seenTypes, superClass);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void _gatherTypes(ResolvedType currentType, Set<ClassKey> seenTypes, List<ResolvedType> types)
/*     */   {
/* 207 */     if (currentType == null) {
/* 208 */       return;
/*     */     }
/* 210 */     Class<?> raw = currentType.getErasedType();
/*     */     
/* 212 */     if ((!this._cfgIncludeLangObject) && (raw == Object.class)) {
/* 213 */       return;
/*     */     }
/*     */     
/* 216 */     ClassKey key = new ClassKey(currentType.getErasedType());
/* 217 */     if (seenTypes.contains(key)) {
/* 218 */       return;
/*     */     }
/*     */     
/* 221 */     seenTypes.add(key);
/* 222 */     types.add(currentType);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 229 */     for (ResolvedType t : currentType.getImplementedInterfaces()) {
/* 230 */       _gatherTypes(t, seenTypes, types);
/*     */     }
/*     */     
/* 233 */     _gatherTypes(currentType.getParentClass(), seenTypes, types);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\classmate-1.3.1.jar!\com\fasterxml\classmate\MemberResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */