/*     */ package com.fasterxml.classmate.types;
/*     */ 
/*     */ import com.fasterxml.classmate.ResolvedType;
/*     */ import com.fasterxml.classmate.TypeBindings;
/*     */ import com.fasterxml.classmate.members.RawField;
/*     */ import com.fasterxml.classmate.members.RawMethod;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResolvedInterfaceType
/*     */   extends ResolvedType
/*     */ {
/*     */   protected final ResolvedType[] _superInterfaces;
/*     */   protected RawField[] _constantFields;
/*     */   protected RawMethod[] _memberMethods;
/*     */   
/*     */   public ResolvedInterfaceType(Class<?> erased, TypeBindings bindings, ResolvedType[] superInterfaces)
/*     */   {
/*  37 */     super(erased, bindings);
/*  38 */     this._superInterfaces = (superInterfaces == null ? NO_TYPES : superInterfaces);
/*     */   }
/*     */   
/*     */   public boolean canCreateSubtypes()
/*     */   {
/*  43 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResolvedType getParentClass()
/*     */   {
/*  55 */     return null;
/*     */   }
/*     */   
/*     */   public ResolvedType getSelfReferencedType() {
/*  59 */     return null;
/*     */   }
/*     */   
/*     */   public List<ResolvedType> getImplementedInterfaces() {
/*  63 */     return this._superInterfaces.length == 0 ? Collections.emptyList() : Arrays.asList(this._superInterfaces);
/*     */   }
/*     */   
/*     */ 
/*     */   public ResolvedType getArrayElementType()
/*     */   {
/*  69 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isInterface()
/*     */   {
/*  79 */     return true;
/*     */   }
/*     */   
/*  82 */   public boolean isAbstract() { return true; }
/*     */   
/*     */   public boolean isArray() {
/*  85 */     return false;
/*     */   }
/*     */   
/*  88 */   public boolean isPrimitive() { return false; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized List<RawField> getStaticFields()
/*     */   {
/* 100 */     if (this._constantFields == null) {
/* 101 */       this._constantFields = _getFields(true);
/*     */     }
/* 103 */     if (this._constantFields.length == 0) {
/* 104 */       return Collections.emptyList();
/*     */     }
/* 106 */     return Arrays.asList(this._constantFields);
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized List<RawMethod> getMemberMethods()
/*     */   {
/* 112 */     if (this._memberMethods == null) {
/* 113 */       this._memberMethods = _getMethods(false);
/*     */     }
/* 115 */     if (this._memberMethods.length == 0) {
/* 116 */       return Collections.emptyList();
/*     */     }
/* 118 */     return Arrays.asList(this._memberMethods);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringBuilder appendSignature(StringBuilder sb)
/*     */   {
/* 129 */     return _appendClassSignature(sb);
/*     */   }
/*     */   
/*     */   public StringBuilder appendErasedSignature(StringBuilder sb)
/*     */   {
/* 134 */     return _appendErasedClassSignature(sb);
/*     */   }
/*     */   
/*     */   public StringBuilder appendBriefDescription(StringBuilder sb)
/*     */   {
/* 139 */     return _appendClassDescription(sb);
/*     */   }
/*     */   
/*     */ 
/*     */   public StringBuilder appendFullDescription(StringBuilder sb)
/*     */   {
/* 145 */     sb = _appendClassDescription(sb);
/*     */     
/* 147 */     int count = this._superInterfaces.length;
/* 148 */     if (count > 0) {
/* 149 */       sb.append(" extends ");
/* 150 */       for (int i = 0; i < count; i++) {
/* 151 */         if (i > 0) {
/* 152 */           sb.append(",");
/*     */         }
/* 154 */         sb = this._superInterfaces[i].appendBriefDescription(sb);
/*     */       }
/*     */     }
/* 157 */     return sb;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\classmate-1.3.1.jar!\com\fasterxml\classmate\types\ResolvedInterfaceType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */