/*     */ package com.fasterxml.classmate.types;
/*     */ 
/*     */ import com.fasterxml.classmate.ResolvedType;
/*     */ import com.fasterxml.classmate.TypeBindings;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypePlaceHolder
/*     */   extends ResolvedType
/*     */ {
/*     */   protected final int _ordinal;
/*     */   protected ResolvedType _actualType;
/*     */   
/*     */   public TypePlaceHolder(int ordinal)
/*     */   {
/*  23 */     super(Object.class, TypeBindings.emptyBindings());
/*  24 */     this._ordinal = ordinal;
/*     */   }
/*     */   
/*     */ 
/*  28 */   public boolean canCreateSubtypes() { return false; }
/*     */   
/*  30 */   public ResolvedType actualType() { return this._actualType; }
/*  31 */   public void actualType(ResolvedType t) { this._actualType = t; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResolvedType getParentClass()
/*     */   {
/*  40 */     return null;
/*     */   }
/*     */   
/*  43 */   public ResolvedType getSelfReferencedType() { return null; }
/*     */   
/*     */   public List<ResolvedType> getImplementedInterfaces() {
/*  46 */     return Collections.emptyList();
/*     */   }
/*     */   
/*  49 */   public ResolvedType getArrayElementType() { return null; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isInterface()
/*     */   {
/*  58 */     return false;
/*     */   }
/*     */   
/*  61 */   public boolean isAbstract() { return true; }
/*     */   
/*     */   public boolean isArray() {
/*  64 */     return false;
/*     */   }
/*     */   
/*  67 */   public boolean isPrimitive() { return false; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringBuilder appendSignature(StringBuilder sb)
/*     */   {
/*  77 */     return _appendClassSignature(sb);
/*     */   }
/*     */   
/*     */   public StringBuilder appendErasedSignature(StringBuilder sb)
/*     */   {
/*  82 */     return _appendErasedClassSignature(sb);
/*     */   }
/*     */   
/*     */   public StringBuilder appendBriefDescription(StringBuilder sb)
/*     */   {
/*  87 */     sb.append('<').append(this._ordinal).append('>');
/*  88 */     return sb;
/*     */   }
/*     */   
/*     */   public StringBuilder appendFullDescription(StringBuilder sb)
/*     */   {
/*  93 */     return appendBriefDescription(sb);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 106 */     return o == this;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\classmate-1.3.1.jar!\com\fasterxml\classmate\types\TypePlaceHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */