/*    */ package org.springframework.boot.liquibase;
/*    */ 
/*    */ import liquibase.servicelocator.CustomResolverServiceLocator;
/*    */ import liquibase.servicelocator.ServiceLocator;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.boot.context.event.ApplicationStartedEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LiquibaseServiceLocatorApplicationListener
/*    */   implements ApplicationListener<ApplicationStartedEvent>
/*    */ {
/* 39 */   private static final Log logger = LogFactory.getLog(LiquibaseServiceLocatorApplicationListener.class);
/*    */   
/*    */   public void onApplicationEvent(ApplicationStartedEvent event)
/*    */   {
/* 43 */     if (ClassUtils.isPresent("liquibase.servicelocator.ServiceLocator", null)) {
/* 44 */       new LiquibasePresent(null).replaceServiceLocator();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   private static class LiquibasePresent
/*    */   {
/*    */     public void replaceServiceLocator()
/*    */     {
/* 54 */       ServiceLocator.setInstance(new CustomResolverServiceLocator(new SpringPackageScanClassResolver(
/* 55 */         LiquibaseServiceLocatorApplicationListener.logger)));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\liquibase\LiquibaseServiceLocatorApplicationListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */