/*     */ package org.springframework.boot.logging;
/*     */ 
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.SystemPropertyUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractLoggingSystem
/*     */   extends LoggingSystem
/*     */ {
/*     */   private final ClassLoader classLoader;
/*     */   
/*     */   public AbstractLoggingSystem(ClassLoader classLoader)
/*     */   {
/*  36 */     this.classLoader = classLoader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void beforeInitialize() {}
/*     */   
/*     */ 
/*     */   public void initialize(LoggingInitializationContext initializationContext, String configLocation, LogFile logFile)
/*     */   {
/*  46 */     if (StringUtils.hasLength(configLocation)) {
/*  47 */       initializeWithSpecificConfig(initializationContext, configLocation, logFile);
/*  48 */       return;
/*     */     }
/*  50 */     initializeWithConventions(initializationContext, logFile);
/*     */   }
/*     */   
/*     */ 
/*     */   private void initializeWithSpecificConfig(LoggingInitializationContext initializationContext, String configLocation, LogFile logFile)
/*     */   {
/*  56 */     configLocation = SystemPropertyUtils.resolvePlaceholders(configLocation);
/*  57 */     loadConfiguration(initializationContext, configLocation, logFile);
/*     */   }
/*     */   
/*     */   private void initializeWithConventions(LoggingInitializationContext initializationContext, LogFile logFile)
/*     */   {
/*  62 */     String config = getSelfInitializationConfig();
/*  63 */     if ((config != null) && (logFile == null))
/*     */     {
/*  65 */       reinitialize(initializationContext);
/*  66 */       return;
/*     */     }
/*  68 */     if (config == null) {
/*  69 */       config = getSpringInitializationConfig();
/*     */     }
/*  71 */     if (config != null) {
/*  72 */       loadConfiguration(initializationContext, config, logFile);
/*  73 */       return;
/*     */     }
/*  75 */     loadDefaults(initializationContext, logFile);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getSelfInitializationConfig()
/*     */   {
/*  85 */     return findConfig(getStandardConfigLocations());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getSpringInitializationConfig()
/*     */   {
/*  94 */     return findConfig(getSpringConfigLocations());
/*     */   }
/*     */   
/*     */   private String findConfig(String[] locations) {
/*  98 */     for (String location : locations) {
/*  99 */       ClassPathResource resource = new ClassPathResource(location, this.classLoader);
/*     */       
/* 101 */       if (resource.exists()) {
/* 102 */         return "classpath:" + location;
/*     */       }
/*     */     }
/* 105 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract String[] getStandardConfigLocations();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String[] getSpringConfigLocations()
/*     */   {
/* 122 */     String[] locations = getStandardConfigLocations();
/* 123 */     for (int i = 0; i < locations.length; i++) {
/* 124 */       String extension = StringUtils.getFilenameExtension(locations[i]);
/* 125 */       locations[i] = (locations[i].substring(0, locations[i]
/* 126 */         .length() - extension.length() - 1) + "-spring." + extension);
/*     */     }
/*     */     
/*     */ 
/* 129 */     return locations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void loadDefaults(LoggingInitializationContext paramLoggingInitializationContext, LogFile paramLogFile);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void loadConfiguration(LoggingInitializationContext paramLoggingInitializationContext, String paramString, LogFile paramLogFile);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void reinitialize(LoggingInitializationContext initializationContext) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final ClassLoader getClassLoader()
/*     */   {
/* 161 */     return this.classLoader;
/*     */   }
/*     */   
/*     */   protected final String getPackagedConfigFile(String fileName) {
/* 165 */     String defaultPath = ClassUtils.getPackageName(getClass());
/* 166 */     defaultPath = defaultPath.replace(".", "/");
/* 167 */     defaultPath = defaultPath + "/" + fileName;
/* 168 */     defaultPath = "classpath:" + defaultPath;
/* 169 */     return defaultPath;
/*     */   }
/*     */   
/*     */   protected final void applySystemProperties(Environment environment, LogFile logFile) {
/* 173 */     new LoggingSystemProperties(environment).apply(logFile);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\logging\AbstractLoggingSystem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */