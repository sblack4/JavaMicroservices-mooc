/*     */ package org.springframework.boot.logging.log4j2;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Marker;
/*     */ import org.apache.logging.log4j.core.Filter;
/*     */ import org.apache.logging.log4j.core.Filter.Result;
/*     */ import org.apache.logging.log4j.core.LogEvent;
/*     */ import org.apache.logging.log4j.core.Logger;
/*     */ import org.apache.logging.log4j.core.LoggerContext;
/*     */ import org.apache.logging.log4j.core.config.Configuration;
/*     */ import org.apache.logging.log4j.core.config.ConfigurationFactory;
/*     */ import org.apache.logging.log4j.core.config.ConfigurationSource;
/*     */ import org.apache.logging.log4j.core.config.LoggerConfig;
/*     */ import org.apache.logging.log4j.core.filter.AbstractFilter;
/*     */ import org.apache.logging.log4j.message.Message;
/*     */ import org.springframework.boot.logging.LogFile;
/*     */ import org.springframework.boot.logging.LogLevel;
/*     */ import org.springframework.boot.logging.LoggingInitializationContext;
/*     */ import org.springframework.boot.logging.Slf4JLoggingSystem;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Log4J2LoggingSystem
/*     */   extends Slf4JLoggingSystem
/*     */ {
/*     */   private static final String FILE_PROTOCOL = "file";
/*     */   private static final Map<LogLevel, Level> LEVELS;
/*     */   
/*     */   static
/*     */   {
/*  66 */     Map<LogLevel, Level> levels = new HashMap();
/*  67 */     levels.put(LogLevel.TRACE, Level.TRACE);
/*  68 */     levels.put(LogLevel.DEBUG, Level.DEBUG);
/*  69 */     levels.put(LogLevel.INFO, Level.INFO);
/*  70 */     levels.put(LogLevel.WARN, Level.WARN);
/*  71 */     levels.put(LogLevel.ERROR, Level.ERROR);
/*  72 */     levels.put(LogLevel.FATAL, Level.FATAL);
/*  73 */     levels.put(LogLevel.OFF, Level.OFF);
/*  74 */     LEVELS = Collections.unmodifiableMap(levels);
/*     */   }
/*     */   
/*  77 */   private static final Filter FILTER = new AbstractFilter()
/*     */   {
/*     */     public Filter.Result filter(LogEvent event)
/*     */     {
/*  81 */       return Filter.Result.DENY;
/*     */     }
/*     */     
/*     */ 
/*     */     public Filter.Result filter(Logger logger, Level level, Marker marker, Message msg, Throwable t)
/*     */     {
/*  87 */       return Filter.Result.DENY;
/*     */     }
/*     */     
/*     */ 
/*     */     public Filter.Result filter(Logger logger, Level level, Marker marker, Object msg, Throwable t)
/*     */     {
/*  93 */       return Filter.Result.DENY;
/*     */     }
/*     */     
/*     */ 
/*     */     public Filter.Result filter(Logger logger, Level level, Marker marker, String msg, Object... params)
/*     */     {
/*  99 */       return Filter.Result.DENY;
/*     */     }
/*     */   };
/*     */   
/*     */   public Log4J2LoggingSystem(ClassLoader classLoader)
/*     */   {
/* 105 */     super(classLoader);
/*     */   }
/*     */   
/*     */   protected String[] getStandardConfigLocations()
/*     */   {
/* 110 */     return getCurrentlySupportedConfigLocations();
/*     */   }
/*     */   
/*     */   private String[] getCurrentlySupportedConfigLocations() {
/* 114 */     List<String> supportedConfigLocations = new ArrayList();
/* 115 */     if (isClassAvailable("com.fasterxml.jackson.dataformat.yaml.YAMLParser")) {
/* 116 */       Collections.addAll(supportedConfigLocations, new String[] { "log4j2.yaml", "log4j2.yml" });
/*     */     }
/* 118 */     if (isClassAvailable("com.fasterxml.jackson.databind.ObjectMapper")) {
/* 119 */       Collections.addAll(supportedConfigLocations, new String[] { "log4j2.json", "log4j2.jsn" });
/*     */     }
/* 121 */     supportedConfigLocations.add("log4j2.xml");
/*     */     
/* 123 */     return (String[])supportedConfigLocations.toArray(new String[supportedConfigLocations.size()]);
/*     */   }
/*     */   
/*     */   protected boolean isClassAvailable(String className) {
/* 127 */     return ClassUtils.isPresent(className, getClassLoader());
/*     */   }
/*     */   
/*     */   public void beforeInitialize()
/*     */   {
/* 132 */     super.beforeInitialize();
/* 133 */     getLoggerContext().getConfiguration().addFilter(FILTER);
/*     */   }
/*     */   
/*     */ 
/*     */   public void initialize(LoggingInitializationContext initializationContext, String configLocation, LogFile logFile)
/*     */   {
/* 139 */     getLoggerContext().getConfiguration().removeFilter(FILTER);
/* 140 */     super.initialize(initializationContext, configLocation, logFile);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void loadDefaults(LoggingInitializationContext initializationContext, LogFile logFile)
/*     */   {
/* 146 */     if (logFile != null) {
/* 147 */       loadConfiguration(getPackagedConfigFile("log4j2-file.xml"), logFile);
/*     */     }
/*     */     else {
/* 150 */       loadConfiguration(getPackagedConfigFile("log4j2.xml"), logFile);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void loadConfiguration(LoggingInitializationContext initializationContext, String location, LogFile logFile)
/*     */   {
/* 157 */     super.loadConfiguration(initializationContext, location, logFile);
/* 158 */     loadConfiguration(location, logFile);
/*     */   }
/*     */   
/*     */   protected void loadConfiguration(String location, LogFile logFile) {
/* 162 */     Assert.notNull(location, "Location must not be null");
/*     */     try {
/* 164 */       LoggerContext ctx = getLoggerContext();
/* 165 */       URL url = ResourceUtils.getURL(location);
/* 166 */       ConfigurationSource source = getConfigurationSource(url);
/* 167 */       ctx.start(ConfigurationFactory.getInstance().getConfiguration(source));
/*     */     }
/*     */     catch (Exception ex) {
/* 170 */       throw new IllegalStateException("Could not initialize Log4J2 logging from " + location, ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private ConfigurationSource getConfigurationSource(URL url) throws IOException
/*     */   {
/* 176 */     InputStream stream = url.openStream();
/* 177 */     if ("file".equals(url.getProtocol())) {
/* 178 */       return new ConfigurationSource(stream, ResourceUtils.getFile(url));
/*     */     }
/* 180 */     return new ConfigurationSource(stream, url);
/*     */   }
/*     */   
/*     */   protected void reinitialize(LoggingInitializationContext initializationContext)
/*     */   {
/* 185 */     getLoggerContext().reconfigure();
/*     */   }
/*     */   
/*     */   public void setLogLevel(String loggerName, LogLevel logLevel)
/*     */   {
/* 190 */     Level level = (Level)LEVELS.get(logLevel);
/* 191 */     LoggerConfig loggerConfig = getLoggerConfig(loggerName);
/* 192 */     if (loggerConfig == null) {
/* 193 */       loggerConfig = new LoggerConfig(loggerName, level, true);
/* 194 */       getLoggerContext().getConfiguration().addLogger(loggerName, loggerConfig);
/*     */     }
/*     */     else {
/* 197 */       loggerConfig.setLevel(level);
/*     */     }
/* 199 */     getLoggerContext().updateLoggers();
/*     */   }
/*     */   
/*     */   public Runnable getShutdownHandler()
/*     */   {
/* 204 */     return new ShutdownHandler(null);
/*     */   }
/*     */   
/*     */   private LoggerConfig getLoggerConfig(String name) {
/* 208 */     name = StringUtils.hasText(name) ? name : "";
/* 209 */     return (LoggerConfig)getLoggerContext().getConfiguration().getLoggers().get(name);
/*     */   }
/*     */   
/*     */   private LoggerContext getLoggerContext() {
/* 213 */     return (LoggerContext)LogManager.getContext(false);
/*     */   }
/*     */   
/*     */   private final class ShutdownHandler implements Runnable {
/*     */     private ShutdownHandler() {}
/*     */     
/*     */     public void run() {
/* 220 */       Log4J2LoggingSystem.this.getLoggerContext().stop();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\logging\log4j2\Log4J2LoggingSystem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */