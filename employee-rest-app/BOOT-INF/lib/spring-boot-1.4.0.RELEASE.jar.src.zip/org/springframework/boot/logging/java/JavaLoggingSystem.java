/*     */ package org.springframework.boot.logging.java;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URL;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.LogManager;
/*     */ import java.util.logging.Logger;
/*     */ import org.springframework.boot.logging.AbstractLoggingSystem;
/*     */ import org.springframework.boot.logging.LogFile;
/*     */ import org.springframework.boot.logging.LogLevel;
/*     */ import org.springframework.boot.logging.LoggingInitializationContext;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaLoggingSystem
/*     */   extends AbstractLoggingSystem
/*     */ {
/*     */   private static final Map<LogLevel, Level> LEVELS;
/*     */   
/*     */   static
/*     */   {
/*  50 */     Map<LogLevel, Level> levels = new HashMap();
/*  51 */     levels.put(LogLevel.TRACE, Level.FINEST);
/*  52 */     levels.put(LogLevel.DEBUG, Level.FINE);
/*  53 */     levels.put(LogLevel.INFO, Level.INFO);
/*  54 */     levels.put(LogLevel.WARN, Level.WARNING);
/*  55 */     levels.put(LogLevel.ERROR, Level.SEVERE);
/*  56 */     levels.put(LogLevel.FATAL, Level.SEVERE);
/*  57 */     levels.put(LogLevel.OFF, Level.OFF);
/*  58 */     LEVELS = Collections.unmodifiableMap(levels);
/*     */   }
/*     */   
/*     */   public JavaLoggingSystem(ClassLoader classLoader) {
/*  62 */     super(classLoader);
/*     */   }
/*     */   
/*     */   protected String[] getStandardConfigLocations()
/*     */   {
/*  67 */     return new String[] { "logging.properties" };
/*     */   }
/*     */   
/*     */   public void beforeInitialize()
/*     */   {
/*  72 */     super.beforeInitialize();
/*  73 */     Logger.getLogger("").setLevel(Level.SEVERE);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void loadDefaults(LoggingInitializationContext initializationContext, LogFile logFile)
/*     */   {
/*  79 */     if (logFile != null) {
/*  80 */       loadConfiguration(getPackagedConfigFile("logging-file.properties"), logFile);
/*     */     }
/*     */     else {
/*  83 */       loadConfiguration(getPackagedConfigFile("logging.properties"), logFile);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void loadConfiguration(LoggingInitializationContext initializationContext, String location, LogFile logFile)
/*     */   {
/*  90 */     loadConfiguration(location, logFile);
/*     */   }
/*     */   
/*     */   protected void loadConfiguration(String location, LogFile logFile) {
/*  94 */     Assert.notNull(location, "Location must not be null");
/*     */     try {
/*  96 */       String configuration = FileCopyUtils.copyToString(new InputStreamReader(
/*  97 */         ResourceUtils.getURL(location).openStream()));
/*  98 */       if (logFile != null) {
/*  99 */         configuration = configuration.replace("${LOG_FILE}", 
/* 100 */           StringUtils.cleanPath(logFile.toString()));
/*     */       }
/* 102 */       LogManager.getLogManager().readConfiguration(new ByteArrayInputStream(configuration
/* 103 */         .getBytes()));
/*     */     }
/*     */     catch (Exception ex) {
/* 106 */       throw new IllegalStateException("Could not initialize Java logging from " + location, ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setLogLevel(String loggerName, LogLevel level)
/*     */   {
/* 113 */     Assert.notNull(level, "Level must not be null");
/* 114 */     String name = StringUtils.hasText(loggerName) ? loggerName : "";
/* 115 */     Logger logger = Logger.getLogger(name);
/* 116 */     logger.setLevel((Level)LEVELS.get(level));
/*     */   }
/*     */   
/*     */   public Runnable getShutdownHandler()
/*     */   {
/* 121 */     return new ShutdownHandler(null);
/*     */   }
/*     */   
/*     */   private final class ShutdownHandler implements Runnable {
/*     */     private ShutdownHandler() {}
/*     */     
/*     */     public void run() {
/* 128 */       LogManager.getLogManager().reset();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\logging\java\JavaLoggingSystem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */