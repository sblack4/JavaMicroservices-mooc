/*     */ package org.springframework.boot.logging.logback;
/*     */ 
/*     */ import ch.qos.logback.classic.Level;
/*     */ import ch.qos.logback.classic.Logger;
/*     */ import ch.qos.logback.classic.LoggerContext;
/*     */ import ch.qos.logback.classic.spi.ILoggingEvent;
/*     */ import ch.qos.logback.classic.spi.IThrowableProxy;
/*     */ import ch.qos.logback.classic.spi.LoggerContextVO;
/*     */ import ch.qos.logback.core.AppenderBase;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.slf4j.Marker;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LevelRemappingAppender
/*     */   extends AppenderBase<ILoggingEvent>
/*     */ {
/*  47 */   private static final Map<Level, Level> DEFAULT_REMAPS = Collections.singletonMap(Level.INFO, Level.DEBUG);
/*     */   
/*  49 */   private String destinationLogger = "ROOT";
/*     */   
/*  51 */   private Map<Level, Level> remapLevels = DEFAULT_REMAPS;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LevelRemappingAppender() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public LevelRemappingAppender(String destinationLogger)
/*     */   {
/*  64 */     this.destinationLogger = destinationLogger;
/*     */   }
/*     */   
/*     */   protected void append(ILoggingEvent event)
/*     */   {
/*  69 */     AppendableLogger logger = getLogger(this.destinationLogger);
/*  70 */     Level remapped = (Level)this.remapLevels.get(event.getLevel());
/*  71 */     logger.callAppenders(remapped == null ? event : new RemappedLoggingEvent(event));
/*     */   }
/*     */   
/*     */   protected AppendableLogger getLogger(String name) {
/*  75 */     LoggerContext loggerContext = (LoggerContext)this.context;
/*  76 */     return new AppendableLogger(loggerContext.getLogger(name));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDestinationLogger(String destinationLogger)
/*     */   {
/*  85 */     Assert.hasLength(destinationLogger, "DestinationLogger must not be empty");
/*  86 */     this.destinationLogger = destinationLogger;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemapLevels(String remapLevels)
/*     */   {
/*  95 */     Assert.hasLength(remapLevels, "RemapLevels must not be empty");
/*  96 */     this.remapLevels = new HashMap();
/*  97 */     for (String remap : StringUtils.commaDelimitedListToStringArray(remapLevels)) {
/*  98 */       String[] split = StringUtils.split(remap, "->");
/*  99 */       Assert.notNull(split, "Remap element '" + remap + "' must contain '->'");
/* 100 */       this.remapLevels.put(Level.toLevel(split[0]), Level.toLevel(split[1]));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected static class AppendableLogger
/*     */   {
/*     */     private Logger logger;
/*     */     
/*     */ 
/*     */     public AppendableLogger(Logger logger)
/*     */     {
/* 112 */       this.logger = logger;
/*     */     }
/*     */     
/*     */     public void callAppenders(ILoggingEvent event) {
/* 116 */       if (this.logger.isEnabledFor(event.getLevel())) {
/* 117 */         this.logger.callAppenders(event);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private class RemappedLoggingEvent
/*     */     implements ILoggingEvent
/*     */   {
/*     */     private final ILoggingEvent event;
/*     */     
/*     */     RemappedLoggingEvent(ILoggingEvent event)
/*     */     {
/* 130 */       this.event = event;
/*     */     }
/*     */     
/*     */     public String getThreadName()
/*     */     {
/* 135 */       return this.event.getThreadName();
/*     */     }
/*     */     
/*     */ 
/*     */     public Level getLevel()
/*     */     {
/* 141 */       Level remappedLevel = (Level)LevelRemappingAppender.this.remapLevels.get(this.event.getLevel());
/* 142 */       return remappedLevel == null ? this.event.getLevel() : remappedLevel;
/*     */     }
/*     */     
/*     */     public String getMessage()
/*     */     {
/* 147 */       return this.event.getMessage();
/*     */     }
/*     */     
/*     */     public Object[] getArgumentArray()
/*     */     {
/* 152 */       return this.event.getArgumentArray();
/*     */     }
/*     */     
/*     */     public String getFormattedMessage()
/*     */     {
/* 157 */       return this.event.getFormattedMessage();
/*     */     }
/*     */     
/*     */     public String getLoggerName()
/*     */     {
/* 162 */       return this.event.getLoggerName();
/*     */     }
/*     */     
/*     */     public LoggerContextVO getLoggerContextVO()
/*     */     {
/* 167 */       return this.event.getLoggerContextVO();
/*     */     }
/*     */     
/*     */     public IThrowableProxy getThrowableProxy()
/*     */     {
/* 172 */       return this.event.getThrowableProxy();
/*     */     }
/*     */     
/*     */     public StackTraceElement[] getCallerData()
/*     */     {
/* 177 */       return this.event.getCallerData();
/*     */     }
/*     */     
/*     */     public boolean hasCallerData()
/*     */     {
/* 182 */       return this.event.hasCallerData();
/*     */     }
/*     */     
/*     */     public Marker getMarker()
/*     */     {
/* 187 */       return this.event.getMarker();
/*     */     }
/*     */     
/*     */     public Map<String, String> getMDCPropertyMap()
/*     */     {
/* 192 */       return this.event.getMDCPropertyMap();
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Map<String, String> getMdc()
/*     */     {
/* 198 */       return this.event.getMDCPropertyMap();
/*     */     }
/*     */     
/*     */     public long getTimeStamp()
/*     */     {
/* 203 */       return this.event.getTimeStamp();
/*     */     }
/*     */     
/*     */     public void prepareForDeferredProcessing()
/*     */     {
/* 208 */       this.event.prepareForDeferredProcessing();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\logging\logback\LevelRemappingAppender.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */