/*     */ package org.springframework.boot.logging;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LoggingSystem
/*     */ {
/*  38 */   public static final String SYSTEM_PROPERTY = LoggingSystem.class.getName();
/*     */   
/*     */ 
/*     */   public static final String NONE = "none";
/*     */   
/*     */ 
/*     */   private static final Map<String, String> SYSTEMS;
/*     */   
/*     */ 
/*     */   static
/*     */   {
/*  49 */     Map<String, String> systems = new LinkedHashMap();
/*  50 */     systems.put("ch.qos.logback.core.Appender", "org.springframework.boot.logging.logback.LogbackLoggingSystem");
/*     */     
/*  52 */     systems.put("org.apache.logging.log4j.core.impl.Log4jContextFactory", "org.springframework.boot.logging.log4j2.Log4J2LoggingSystem");
/*     */     
/*  54 */     systems.put("java.util.logging.LogManager", "org.springframework.boot.logging.java.JavaLoggingSystem");
/*     */     
/*  56 */     SYSTEMS = Collections.unmodifiableMap(systems);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Runnable getShutdownHandler()
/*     */   {
/*  92 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static LoggingSystem get(ClassLoader classLoader)
/*     */   {
/* 108 */     String loggingSystem = System.getProperty(SYSTEM_PROPERTY);
/* 109 */     if (StringUtils.hasLength(loggingSystem)) {
/* 110 */       if ("none".equals(loggingSystem)) {
/* 111 */         return new NoOpLoggingSystem();
/*     */       }
/* 113 */       return get(classLoader, loggingSystem);
/*     */     }
/* 115 */     for (Map.Entry<String, String> entry : SYSTEMS.entrySet()) {
/* 116 */       if (ClassUtils.isPresent((String)entry.getKey(), classLoader)) {
/* 117 */         return get(classLoader, (String)entry.getValue());
/*     */       }
/*     */     }
/* 120 */     throw new IllegalStateException("No suitable logging system located");
/*     */   }
/*     */   
/*     */   private static LoggingSystem get(ClassLoader classLoader, String loggingSystemClass) {
/*     */     try {
/* 125 */       Class<?> systemClass = ClassUtils.forName(loggingSystemClass, classLoader);
/*     */       
/* 127 */       return (LoggingSystem)systemClass.getConstructor(new Class[] { ClassLoader.class }).newInstance(new Object[] { classLoader });
/*     */     }
/*     */     catch (Exception ex) {
/* 130 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public abstract void beforeInitialize();
/*     */   
/*     */   public void initialize(LoggingInitializationContext initializationContext, String configLocation, LogFile logFile) {}
/*     */   
/*     */   public void cleanUp() {}
/*     */   
/*     */   public abstract void setLogLevel(String paramString, LogLevel paramLogLevel);
/*     */   
/*     */   static class NoOpLoggingSystem
/*     */     extends LoggingSystem
/*     */   {
/*     */     public void beforeInitialize() {}
/*     */     
/*     */     public void setLogLevel(String loggerName, LogLevel level) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\logging\LoggingSystem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */