/*     */ package org.springframework.boot.logging;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URL;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.boot.bind.RelaxedPropertyResolver;
/*     */ import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
/*     */ import org.springframework.boot.context.event.ApplicationPreparedEvent;
/*     */ import org.springframework.boot.context.event.ApplicationStartedEvent;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.event.ContextClosedEvent;
/*     */ import org.springframework.context.event.GenericApplicationListener;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoggingApplicationListener
/*     */   implements GenericApplicationListener
/*     */ {
/*     */   public static final int DEFAULT_ORDER = -2147483628;
/*     */   public static final String CONFIG_PROPERTY = "logging.config";
/*     */   public static final String REGISTER_SHUTDOWN_HOOK_PROPERTY = "logging.register-shutdown-hook";
/*     */   public static final String PATH_PROPERTY = "logging.path";
/*     */   public static final String FILE_PROPERTY = "logging.file";
/*     */   public static final String PID_KEY = "PID";
/*     */   public static final String EXCEPTION_CONVERSION_WORD = "LOG_EXCEPTION_CONVERSION_WORD";
/*     */   public static final String LOG_FILE = "LOG_FILE";
/*     */   public static final String LOG_PATH = "LOG_PATH";
/*     */   public static final String CONSOLE_LOG_PATTERN = "CONSOLE_LOG_PATTERN";
/*     */   public static final String FILE_LOG_PATTERN = "FILE_LOG_PATTERN";
/*     */   public static final String LOG_LEVEL_PATTERN = "LOG_LEVEL_PATTERN";
/*     */   public static final String LOGGING_SYSTEM_BEAN_NAME = "springBootLoggingSystem";
/*     */   private static MultiValueMap<LogLevel, String> LOG_LEVEL_LOGGERS;
/* 150 */   private static AtomicBoolean shutdownHookRegistered = new AtomicBoolean(false);
/*     */   
/*     */   static {
/* 153 */     LOG_LEVEL_LOGGERS = new LinkedMultiValueMap();
/* 154 */     LOG_LEVEL_LOGGERS.add(LogLevel.DEBUG, "org.springframework.boot");
/* 155 */     LOG_LEVEL_LOGGERS.add(LogLevel.TRACE, "org.springframework");
/* 156 */     LOG_LEVEL_LOGGERS.add(LogLevel.TRACE, "org.apache.tomcat");
/* 157 */     LOG_LEVEL_LOGGERS.add(LogLevel.TRACE, "org.apache.catalina");
/* 158 */     LOG_LEVEL_LOGGERS.add(LogLevel.TRACE, "org.eclipse.jetty");
/* 159 */     LOG_LEVEL_LOGGERS.add(LogLevel.TRACE, "org.hibernate.tool.hbm2ddl");
/* 160 */     LOG_LEVEL_LOGGERS.add(LogLevel.DEBUG, "org.hibernate.SQL");
/*     */   }
/*     */   
/* 163 */   private static Class<?>[] EVENT_TYPES = { ApplicationStartedEvent.class, ApplicationEnvironmentPreparedEvent.class, ApplicationPreparedEvent.class, ContextClosedEvent.class };
/*     */   
/*     */ 
/*     */ 
/* 167 */   private static Class<?>[] SOURCE_TYPES = { SpringApplication.class, ApplicationContext.class };
/*     */   
/*     */ 
/* 170 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private LoggingSystem loggingSystem;
/*     */   
/* 174 */   private int order = -2147483628;
/*     */   
/* 176 */   private boolean parseArgs = true;
/*     */   
/* 178 */   private LogLevel springBootLogging = null;
/*     */   
/*     */   public boolean supportsEventType(ResolvableType resolvableType)
/*     */   {
/* 182 */     return isAssignableFrom(resolvableType.getRawClass(), EVENT_TYPES);
/*     */   }
/*     */   
/*     */   public boolean supportsSourceType(Class<?> sourceType)
/*     */   {
/* 187 */     return isAssignableFrom(sourceType, SOURCE_TYPES);
/*     */   }
/*     */   
/*     */   private boolean isAssignableFrom(Class<?> type, Class<?>... supportedTypes) {
/* 191 */     if (type != null) {
/* 192 */       for (Class<?> supportedType : supportedTypes) {
/* 193 */         if (supportedType.isAssignableFrom(type)) {
/* 194 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 198 */     return false;
/*     */   }
/*     */   
/*     */   public void onApplicationEvent(ApplicationEvent event)
/*     */   {
/* 203 */     if ((event instanceof ApplicationStartedEvent)) {
/* 204 */       onApplicationStartedEvent((ApplicationStartedEvent)event);
/*     */     }
/* 206 */     else if ((event instanceof ApplicationEnvironmentPreparedEvent)) {
/* 207 */       onApplicationEnvironmentPreparedEvent((ApplicationEnvironmentPreparedEvent)event);
/*     */ 
/*     */     }
/* 210 */     else if ((event instanceof ApplicationPreparedEvent)) {
/* 211 */       onApplicationPreparedEvent((ApplicationPreparedEvent)event);
/*     */     }
/* 213 */     else if (((event instanceof ContextClosedEvent)) && 
/* 214 */       (((ContextClosedEvent)event).getApplicationContext().getParent() == null)) {
/* 215 */       onContextClosedEvent();
/*     */     }
/*     */   }
/*     */   
/*     */   private void onApplicationStartedEvent(ApplicationStartedEvent event)
/*     */   {
/* 221 */     this.loggingSystem = LoggingSystem.get(event.getSpringApplication().getClassLoader());
/* 222 */     this.loggingSystem.beforeInitialize();
/*     */   }
/*     */   
/*     */   private void onApplicationEnvironmentPreparedEvent(ApplicationEnvironmentPreparedEvent event)
/*     */   {
/* 227 */     if (this.loggingSystem == null)
/*     */     {
/* 229 */       this.loggingSystem = LoggingSystem.get(event.getSpringApplication().getClassLoader());
/*     */     }
/* 231 */     initialize(event.getEnvironment(), event.getSpringApplication().getClassLoader());
/*     */   }
/*     */   
/*     */   private void onApplicationPreparedEvent(ApplicationPreparedEvent event)
/*     */   {
/* 236 */     ConfigurableListableBeanFactory beanFactory = event.getApplicationContext().getBeanFactory();
/* 237 */     if (!beanFactory.containsBean("springBootLoggingSystem")) {
/* 238 */       beanFactory.registerSingleton("springBootLoggingSystem", this.loggingSystem);
/*     */     }
/*     */   }
/*     */   
/*     */   private void onContextClosedEvent() {
/* 243 */     if (this.loggingSystem != null) {
/* 244 */       this.loggingSystem.cleanUp();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initialize(ConfigurableEnvironment environment, ClassLoader classLoader)
/*     */   {
/* 256 */     new LoggingSystemProperties(environment).apply();
/* 257 */     LogFile logFile = LogFile.get(environment);
/* 258 */     if (logFile != null) {
/* 259 */       logFile.applyToSystemProperties();
/*     */     }
/* 261 */     initializeEarlyLoggingLevel(environment);
/* 262 */     initializeSystem(environment, this.loggingSystem, logFile);
/* 263 */     initializeFinalLoggingLevels(environment, this.loggingSystem);
/* 264 */     registerShutdownHookIfNecessary(environment, this.loggingSystem);
/*     */   }
/*     */   
/*     */   private void initializeEarlyLoggingLevel(ConfigurableEnvironment environment) {
/* 268 */     if ((this.parseArgs) && (this.springBootLogging == null)) {
/* 269 */       if (isSet(environment, "debug")) {
/* 270 */         this.springBootLogging = LogLevel.DEBUG;
/*     */       }
/* 272 */       if (isSet(environment, "trace")) {
/* 273 */         this.springBootLogging = LogLevel.TRACE;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isSet(ConfigurableEnvironment environment, String property) {
/* 279 */     String value = environment.getProperty(property);
/* 280 */     return (value != null) && (!value.equals("false"));
/*     */   }
/*     */   
/*     */   private void initializeSystem(ConfigurableEnvironment environment, LoggingSystem system, LogFile logFile)
/*     */   {
/* 285 */     LoggingInitializationContext initializationContext = new LoggingInitializationContext(environment);
/*     */     
/* 287 */     String logConfig = environment.getProperty("logging.config");
/* 288 */     if (ignoreLogConfig(logConfig)) {
/* 289 */       system.initialize(initializationContext, null, logFile);
/*     */     } else {
/*     */       try
/*     */       {
/* 293 */         ResourceUtils.getURL(logConfig).openStream().close();
/* 294 */         system.initialize(initializationContext, logConfig, logFile);
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 298 */         System.err.println("Logging system failed to initialize using configuration from '" + logConfig + "'");
/*     */         
/* 300 */         ex.printStackTrace(System.err);
/* 301 */         throw new IllegalStateException(ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean ignoreLogConfig(String logConfig)
/*     */   {
/* 308 */     return (!StringUtils.hasLength(logConfig)) || (isDefaultAzureLoggingConfig(logConfig));
/*     */   }
/*     */   
/*     */   private boolean isDefaultAzureLoggingConfig(String candidate) {
/* 312 */     return candidate.startsWith("-Djava.util.logging.config.file=");
/*     */   }
/*     */   
/*     */   private void initializeFinalLoggingLevels(ConfigurableEnvironment environment, LoggingSystem system)
/*     */   {
/* 317 */     if (this.springBootLogging != null) {
/* 318 */       initializeLogLevel(system, this.springBootLogging);
/*     */     }
/* 320 */     setLogLevels(system, environment);
/*     */   }
/*     */   
/*     */   protected void initializeLogLevel(LoggingSystem system, LogLevel level) {
/* 324 */     List<String> loggers = (List)LOG_LEVEL_LOGGERS.get(level);
/* 325 */     if (loggers != null) {
/* 326 */       for (String logger : loggers) {
/* 327 */         system.setLogLevel(logger, level);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void setLogLevels(LoggingSystem system, Environment environment)
/*     */   {
/* 334 */     Map<String, Object> levels = new RelaxedPropertyResolver(environment).getSubProperties("logging.level.");
/* 335 */     for (Map.Entry<String, Object> entry : levels.entrySet()) {
/* 336 */       setLogLevel(system, environment, (String)entry.getKey(), entry.getValue().toString());
/*     */     }
/*     */   }
/*     */   
/*     */   private void setLogLevel(LoggingSystem system, Environment environment, String name, String level)
/*     */   {
/*     */     try {
/* 343 */       if (name.equalsIgnoreCase("root")) {
/* 344 */         name = null;
/*     */       }
/* 346 */       level = environment.resolvePlaceholders(level);
/* 347 */       system.setLogLevel(name, coerceLogLevel(level));
/*     */     }
/*     */     catch (RuntimeException ex) {
/* 350 */       this.logger.error("Cannot set level: " + level + " for '" + name + "'");
/*     */     }
/*     */   }
/*     */   
/*     */   private LogLevel coerceLogLevel(String level) {
/* 355 */     if ("false".equalsIgnoreCase(level)) {
/* 356 */       return LogLevel.OFF;
/*     */     }
/* 358 */     return LogLevel.valueOf(level.toUpperCase());
/*     */   }
/*     */   
/*     */ 
/*     */   private void registerShutdownHookIfNecessary(Environment environment, LoggingSystem loggingSystem)
/*     */   {
/* 364 */     boolean registerShutdownHook = ((Boolean)new RelaxedPropertyResolver(environment).getProperty("logging.register-shutdown-hook", Boolean.class, Boolean.valueOf(false))).booleanValue();
/* 365 */     if (registerShutdownHook) {
/* 366 */       Runnable shutdownHandler = loggingSystem.getShutdownHandler();
/* 367 */       if ((shutdownHandler != null) && 
/* 368 */         (shutdownHookRegistered.compareAndSet(false, true))) {
/* 369 */         registerShutdownHook(new Thread(shutdownHandler));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void registerShutdownHook(Thread shutdownHook) {
/* 375 */     Runtime.getRuntime().addShutdownHook(shutdownHook);
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 379 */     this.order = order;
/*     */   }
/*     */   
/*     */   public int getOrder()
/*     */   {
/* 384 */     return this.order;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSpringBootLogging(LogLevel springBootLogging)
/*     */   {
/* 392 */     this.springBootLogging = springBootLogging;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParseArgs(boolean parseArgs)
/*     */   {
/* 401 */     this.parseArgs = parseArgs;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\logging\LoggingApplicationListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */