/*     */ package org.springframework.boot.logging.logback;
/*     */ 
/*     */ import ch.qos.logback.classic.Level;
/*     */ import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
/*     */ import ch.qos.logback.classic.spi.ILoggingEvent;
/*     */ import ch.qos.logback.core.Appender;
/*     */ import ch.qos.logback.core.ConsoleAppender;
/*     */ import ch.qos.logback.core.rolling.FixedWindowRollingPolicy;
/*     */ import ch.qos.logback.core.rolling.RollingFileAppender;
/*     */ import ch.qos.logback.core.rolling.SizeBasedTriggeringPolicy;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ import java.nio.charset.Charset;
/*     */ import org.springframework.boot.bind.RelaxedPropertyResolver;
/*     */ import org.springframework.boot.logging.LogFile;
/*     */ import org.springframework.boot.logging.LoggingInitializationContext;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.PropertyResolver;
/*     */ import org.springframework.core.env.PropertySourcesPropertyResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultLogbackConfiguration
/*     */ {
/*     */   private static final String CONSOLE_LOG_PATTERN = "%clr(%d{yyyy-MM-dd HH:mm:ss.SSS}){faint} %clr(${LOG_LEVEL_PATTERN:-%5p}) %clr(${PID:- }){magenta} %clr(---){faint} %clr([%15.15t]){faint} %clr(%-40.40logger{39}){cyan} %clr(:){faint} %m%n${LOG_EXCEPTION_CONVERSION_WORD:-%wEx}";
/*     */   private static final String FILE_LOG_PATTERN = "%d{yyyy-MM-dd HH:mm:ss.SSS} ${LOG_LEVEL_PATTERN:-%5p} ${PID:- } --- [%t] %-40.40logger{39} : %m%n${LOG_EXCEPTION_CONVERSION_WORD:-%wEx}";
/*  56 */   private static final Charset UTF8 = Charset.forName("UTF-8");
/*     */   
/*     */   private final PropertyResolver patterns;
/*     */   
/*     */   private final LogFile logFile;
/*     */   
/*     */   DefaultLogbackConfiguration(LoggingInitializationContext initializationContext, LogFile logFile)
/*     */   {
/*  64 */     this.patterns = getPatternsResolver(initializationContext.getEnvironment());
/*  65 */     this.logFile = logFile;
/*     */   }
/*     */   
/*     */   private PropertyResolver getPatternsResolver(Environment environment) {
/*  69 */     if (environment == null) {
/*  70 */       return new PropertySourcesPropertyResolver(null);
/*     */     }
/*  72 */     return new RelaxedPropertyResolver(environment, "logging.pattern.");
/*     */   }
/*     */   
/*     */   public void apply(LogbackConfigurator config) {
/*  76 */     synchronized (config.getConfigurationLock()) {
/*  77 */       base(config);
/*  78 */       Appender<ILoggingEvent> consoleAppender = consoleAppender(config);
/*  79 */       if (this.logFile != null) {
/*  80 */         Appender<ILoggingEvent> fileAppender = fileAppender(config, this.logFile
/*  81 */           .toString());
/*  82 */         config.root(Level.INFO, new Appender[] { consoleAppender, fileAppender });
/*     */       }
/*     */       else {
/*  85 */         config.root(Level.INFO, new Appender[] { consoleAppender });
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void base(LogbackConfigurator config) {
/*  91 */     config.conversionRule("clr", ColorConverter.class);
/*  92 */     config.conversionRule("wex", WhitespaceThrowableProxyConverter.class);
/*  93 */     config.conversionRule("wEx", ExtendedWhitespaceThrowableProxyConverter.class);
/*  94 */     LevelRemappingAppender debugRemapAppender = new LevelRemappingAppender("org.springframework.boot");
/*     */     
/*  96 */     config.start(debugRemapAppender);
/*  97 */     config.appender("DEBUG_LEVEL_REMAPPER", debugRemapAppender);
/*  98 */     config.logger("", Level.ERROR);
/*  99 */     config.logger("org.apache.catalina.startup.DigesterFactory", Level.ERROR);
/* 100 */     config.logger("org.apache.catalina.util.LifecycleBase", Level.ERROR);
/* 101 */     config.logger("org.apache.coyote.http11.Http11NioProtocol", Level.WARN);
/* 102 */     config.logger("org.apache.sshd.common.util.SecurityUtils", Level.WARN);
/* 103 */     config.logger("org.apache.tomcat.util.net.NioSelectorPool", Level.WARN);
/* 104 */     config.logger("org.crsh.plugin", Level.WARN);
/* 105 */     config.logger("org.crsh.ssh", Level.WARN);
/* 106 */     config.logger("org.eclipse.jetty.util.component.AbstractLifeCycle", Level.ERROR);
/* 107 */     config.logger("org.hibernate.validator.internal.util.Version", Level.WARN);
/* 108 */     config.logger("org.springframework.boot.actuate.autoconfigure.CrshAutoConfiguration", Level.WARN);
/*     */     
/* 110 */     config.logger("org.springframework.boot.actuate.endpoint.jmx", null, false, debugRemapAppender);
/*     */     
/* 112 */     config.logger("org.thymeleaf", null, false, debugRemapAppender);
/*     */   }
/*     */   
/*     */   private Appender<ILoggingEvent> consoleAppender(LogbackConfigurator config) {
/* 116 */     ConsoleAppender<ILoggingEvent> appender = new ConsoleAppender();
/* 117 */     PatternLayoutEncoder encoder = new PatternLayoutEncoder();
/* 118 */     String logPattern = this.patterns.getProperty("console", "%clr(%d{yyyy-MM-dd HH:mm:ss.SSS}){faint} %clr(${LOG_LEVEL_PATTERN:-%5p}) %clr(${PID:- }){magenta} %clr(---){faint} %clr([%15.15t]){faint} %clr(%-40.40logger{39}){cyan} %clr(:){faint} %m%n${LOG_EXCEPTION_CONVERSION_WORD:-%wEx}");
/* 119 */     encoder.setPattern(OptionHelper.substVars(logPattern, config.getContext()));
/* 120 */     encoder.setCharset(UTF8);
/* 121 */     config.start(encoder);
/* 122 */     appender.setEncoder(encoder);
/* 123 */     config.appender("CONSOLE", appender);
/* 124 */     return appender;
/*     */   }
/*     */   
/*     */   private Appender<ILoggingEvent> fileAppender(LogbackConfigurator config, String logFile)
/*     */   {
/* 129 */     RollingFileAppender<ILoggingEvent> appender = new RollingFileAppender();
/* 130 */     PatternLayoutEncoder encoder = new PatternLayoutEncoder();
/* 131 */     String logPattern = this.patterns.getProperty("file", "%d{yyyy-MM-dd HH:mm:ss.SSS} ${LOG_LEVEL_PATTERN:-%5p} ${PID:- } --- [%t] %-40.40logger{39} : %m%n${LOG_EXCEPTION_CONVERSION_WORD:-%wEx}");
/* 132 */     encoder.setPattern(OptionHelper.substVars(logPattern, config.getContext()));
/* 133 */     appender.setEncoder(encoder);
/* 134 */     config.start(encoder);
/*     */     
/* 136 */     appender.setFile(logFile);
/*     */     
/* 138 */     FixedWindowRollingPolicy rollingPolicy = new FixedWindowRollingPolicy();
/* 139 */     rollingPolicy.setFileNamePattern(logFile + ".%i");
/* 140 */     appender.setRollingPolicy(rollingPolicy);
/* 141 */     rollingPolicy.setParent(appender);
/* 142 */     config.start(rollingPolicy);
/*     */     
/* 144 */     SizeBasedTriggeringPolicy<ILoggingEvent> triggeringPolicy = new SizeBasedTriggeringPolicy();
/* 145 */     triggeringPolicy.setMaxFileSize("10MB");
/* 146 */     appender.setTriggeringPolicy(triggeringPolicy);
/* 147 */     config.start(triggeringPolicy);
/*     */     
/* 149 */     config.appender("FILE", appender);
/* 150 */     return appender;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\logging\logback\DefaultLogbackConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */