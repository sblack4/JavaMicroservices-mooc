/*     */ package org.springframework.boot.logging.logback;
/*     */ 
/*     */ import ch.qos.logback.classic.Level;
/*     */ import ch.qos.logback.classic.Logger;
/*     */ import ch.qos.logback.classic.LoggerContext;
/*     */ import ch.qos.logback.classic.joran.JoranConfigurator;
/*     */ import ch.qos.logback.classic.jul.LevelChangePropagator;
/*     */ import ch.qos.logback.classic.spi.TurboFilterList;
/*     */ import ch.qos.logback.classic.turbo.TurboFilter;
/*     */ import ch.qos.logback.classic.util.ContextInitializer;
/*     */ import ch.qos.logback.core.joran.spi.JoranException;
/*     */ import ch.qos.logback.core.spi.FilterReply;
/*     */ import ch.qos.logback.core.status.Status;
/*     */ import ch.qos.logback.core.status.StatusManager;
/*     */ import java.net.URL;
/*     */ import java.security.CodeSource;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.slf4j.ILoggerFactory;
/*     */ import org.slf4j.Marker;
/*     */ import org.slf4j.impl.StaticLoggerBinder;
/*     */ import org.springframework.boot.logging.LogFile;
/*     */ import org.springframework.boot.logging.LogLevel;
/*     */ import org.springframework.boot.logging.LoggingInitializationContext;
/*     */ import org.springframework.boot.logging.Slf4JLoggingSystem;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogbackLoggingSystem
/*     */   extends Slf4JLoggingSystem
/*     */ {
/*     */   private static final String CONFIGURATION_FILE_PROPERTY = "logback.configurationFile";
/*     */   private static final Map<LogLevel, Level> LEVELS;
/*     */   
/*     */   static
/*     */   {
/*  64 */     Map<LogLevel, Level> levels = new HashMap();
/*  65 */     levels.put(LogLevel.TRACE, Level.TRACE);
/*  66 */     levels.put(LogLevel.DEBUG, Level.DEBUG);
/*  67 */     levels.put(LogLevel.INFO, Level.INFO);
/*  68 */     levels.put(LogLevel.WARN, Level.WARN);
/*  69 */     levels.put(LogLevel.ERROR, Level.ERROR);
/*  70 */     levels.put(LogLevel.FATAL, Level.ERROR);
/*  71 */     levels.put(LogLevel.OFF, Level.OFF);
/*  72 */     LEVELS = Collections.unmodifiableMap(levels);
/*     */   }
/*     */   
/*  75 */   private static final TurboFilter FILTER = new TurboFilter()
/*     */   {
/*     */ 
/*     */     public FilterReply decide(Marker marker, Logger logger, Level level, String format, Object[] params, Throwable t)
/*     */     {
/*  80 */       return FilterReply.DENY;
/*     */     }
/*     */   };
/*     */   
/*     */   public LogbackLoggingSystem(ClassLoader classLoader)
/*     */   {
/*  86 */     super(classLoader);
/*     */   }
/*     */   
/*     */   protected String[] getStandardConfigLocations()
/*     */   {
/*  91 */     return new String[] { "logback-test.groovy", "logback-test.xml", "logback.groovy", "logback.xml" };
/*     */   }
/*     */   
/*     */ 
/*     */   public void beforeInitialize()
/*     */   {
/*  97 */     super.beforeInitialize();
/*  98 */     getLogger(null).getLoggerContext().getTurboFilterList().add(FILTER);
/*  99 */     configureJBossLoggingToUseSlf4j();
/*     */   }
/*     */   
/*     */ 
/*     */   public void initialize(LoggingInitializationContext initializationContext, String configLocation, LogFile logFile)
/*     */   {
/* 105 */     getLogger(null).getLoggerContext().getTurboFilterList().remove(FILTER);
/* 106 */     super.initialize(initializationContext, configLocation, logFile);
/* 107 */     if (StringUtils.hasText(System.getProperty("logback.configurationFile"))) {
/* 108 */       getLogger(LogbackLoggingSystem.class.getName()).warn("Ignoring 'logback.configurationFile' system property. Please use 'logging.config' instead.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void loadDefaults(LoggingInitializationContext initializationContext, LogFile logFile)
/*     */   {
/* 117 */     LoggerContext context = getLoggerContext();
/* 118 */     stopAndReset(context);
/* 119 */     LogbackConfigurator configurator = new LogbackConfigurator(context);
/* 120 */     context.putProperty("LOG_LEVEL_PATTERN", initializationContext
/* 121 */       .getEnvironment().resolvePlaceholders("${logging.pattern.level:${LOG_LEVEL_PATTERN:%5p}}"));
/*     */     
/* 123 */     new DefaultLogbackConfiguration(initializationContext, logFile)
/* 124 */       .apply(configurator);
/* 125 */     context.setPackagingDataEnabled(true);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void loadConfiguration(LoggingInitializationContext initializationContext, String location, LogFile logFile)
/*     */   {
/* 131 */     super.loadConfiguration(initializationContext, location, logFile);
/* 132 */     LoggerContext loggerContext = getLoggerContext();
/* 133 */     stopAndReset(loggerContext);
/*     */     try {
/* 135 */       configureByResourceUrl(initializationContext, loggerContext, 
/* 136 */         ResourceUtils.getURL(location));
/*     */     }
/*     */     catch (Exception ex) {
/* 139 */       throw new IllegalStateException("Could not initialize Logback logging from " + location, ex);
/*     */     }
/*     */     
/* 142 */     List<Status> statuses = loggerContext.getStatusManager().getCopyOfStatusList();
/* 143 */     StringBuilder errors = new StringBuilder();
/* 144 */     for (Status status : statuses) {
/* 145 */       if (status.getLevel() == 2) {
/* 146 */         errors.append(errors.length() > 0 ? String.format("%n", new Object[0]) : "");
/* 147 */         errors.append(status.toString());
/*     */       }
/*     */     }
/* 150 */     if (errors.length() > 0)
/*     */     {
/* 152 */       throw new IllegalStateException(String.format("Logback configuration error detected: %n%s", new Object[] { errors }));
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureByResourceUrl(LoggingInitializationContext initializationContext, LoggerContext loggerContext, URL url)
/*     */     throws JoranException
/*     */   {
/* 159 */     if (url.toString().endsWith("xml")) {
/* 160 */       JoranConfigurator configurator = new SpringBootJoranConfigurator(initializationContext);
/*     */       
/* 162 */       configurator.setContext(loggerContext);
/* 163 */       configurator.doConfigure(url);
/*     */     }
/*     */     else {
/* 166 */       new ContextInitializer(loggerContext).configureByResource(url);
/*     */     }
/*     */   }
/*     */   
/*     */   private void stopAndReset(LoggerContext loggerContext) {
/* 171 */     loggerContext.stop();
/* 172 */     loggerContext.reset();
/* 173 */     if (isBridgeHandlerAvailable()) {
/* 174 */       addLevelChangePropagator(loggerContext);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addLevelChangePropagator(LoggerContext loggerContext) {
/* 179 */     LevelChangePropagator levelChangePropagator = new LevelChangePropagator();
/* 180 */     levelChangePropagator.setResetJUL(true);
/* 181 */     levelChangePropagator.setContext(loggerContext);
/* 182 */     loggerContext.addListener(levelChangePropagator);
/*     */   }
/*     */   
/*     */   public void cleanUp()
/*     */   {
/* 187 */     super.cleanUp();
/* 188 */     getLoggerContext().getStatusManager().clear();
/*     */   }
/*     */   
/*     */   protected void reinitialize(LoggingInitializationContext initializationContext)
/*     */   {
/* 193 */     getLoggerContext().reset();
/* 194 */     getLoggerContext().getStatusManager().clear();
/* 195 */     loadConfiguration(initializationContext, getSelfInitializationConfig(), null);
/*     */   }
/*     */   
/*     */   private void configureJBossLoggingToUseSlf4j() {
/* 199 */     System.setProperty("org.jboss.logging.provider", "slf4j");
/*     */   }
/*     */   
/*     */   public void setLogLevel(String loggerName, LogLevel level)
/*     */   {
/* 204 */     getLogger(loggerName).setLevel((Level)LEVELS.get(level));
/*     */   }
/*     */   
/*     */   public Runnable getShutdownHandler()
/*     */   {
/* 209 */     return new ShutdownHandler(null);
/*     */   }
/*     */   
/*     */   private Logger getLogger(String name) {
/* 213 */     LoggerContext factory = getLoggerContext();
/*     */     
/* 215 */     return factory.getLogger(StringUtils.isEmpty(name) ? "ROOT" : name);
/*     */   }
/*     */   
/*     */   private LoggerContext getLoggerContext()
/*     */   {
/* 220 */     ILoggerFactory factory = StaticLoggerBinder.getSingleton().getLoggerFactory();
/* 221 */     Assert.isInstanceOf(LoggerContext.class, factory, 
/* 222 */       String.format("LoggerFactory is not a Logback LoggerContext but Logback is on the classpath. Either remove Logback or the competing implementation (%s loaded from %s). If you are using WebLogic you will need to add 'org.slf4j' to prefer-application-packages in WEB-INF/weblogic.xml", new Object[] {factory
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 228 */       .getClass(), getLocation(factory) }));
/* 229 */     return (LoggerContext)factory;
/*     */   }
/*     */   
/*     */   private Object getLocation(ILoggerFactory factory) {
/*     */     try {
/* 234 */       ProtectionDomain protectionDomain = factory.getClass().getProtectionDomain();
/* 235 */       CodeSource codeSource = protectionDomain.getCodeSource();
/* 236 */       if (codeSource != null) {
/* 237 */         return codeSource.getLocation();
/*     */       }
/*     */     }
/*     */     catch (SecurityException localSecurityException) {}
/*     */     
/*     */ 
/* 243 */     return "unknown location";
/*     */   }
/*     */   
/*     */   private final class ShutdownHandler implements Runnable {
/*     */     private ShutdownHandler() {}
/*     */     
/*     */     public void run() {
/* 250 */       LogbackLoggingSystem.this.getLoggerContext().stop();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\logging\logback\LogbackLoggingSystem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */