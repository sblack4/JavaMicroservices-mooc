/*    */ package org.springframework.boot.logging;
/*    */ 
/*    */ import java.net.URLClassLoader;
/*    */ import java.util.Arrays;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
/*    */ import org.springframework.boot.context.event.ApplicationFailedEvent;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.event.GenericApplicationListener;
/*    */ import org.springframework.core.ResolvableType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ClasspathLoggingApplicationListener
/*    */   implements GenericApplicationListener
/*    */ {
/*    */   private static final int ORDER = -2147483627;
/* 45 */   private final Log logger = LogFactory.getLog(getClass());
/*    */   
/*    */   public void onApplicationEvent(ApplicationEvent event)
/*    */   {
/* 49 */     if (this.logger.isDebugEnabled()) {
/* 50 */       if ((event instanceof ApplicationEnvironmentPreparedEvent))
/*    */       {
/* 52 */         this.logger.debug("Application started with classpath: " + getClasspath());
/*    */       }
/* 54 */       else if ((event instanceof ApplicationFailedEvent)) {
/* 55 */         this.logger.debug("Application failed to start with classpath: " + 
/* 56 */           getClasspath());
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public int getOrder()
/*    */   {
/* 63 */     return -2147483627;
/*    */   }
/*    */   
/*    */   public boolean supportsEventType(ResolvableType resolvableType)
/*    */   {
/* 68 */     Class<?> type = resolvableType.getRawClass();
/* 69 */     if (type == null) {
/* 70 */       return false;
/*    */     }
/*    */     
/* 73 */     return (ApplicationEnvironmentPreparedEvent.class.isAssignableFrom(type)) || (ApplicationFailedEvent.class.isAssignableFrom(type));
/*    */   }
/*    */   
/*    */   public boolean supportsSourceType(Class<?> sourceType)
/*    */   {
/* 78 */     return true;
/*    */   }
/*    */   
/*    */   private String getClasspath() {
/* 82 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/* 83 */     if ((classLoader instanceof URLClassLoader)) {
/* 84 */       return Arrays.toString(((URLClassLoader)classLoader).getURLs());
/*    */     }
/* 86 */     return "unknown";
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\logging\ClasspathLoggingApplicationListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */