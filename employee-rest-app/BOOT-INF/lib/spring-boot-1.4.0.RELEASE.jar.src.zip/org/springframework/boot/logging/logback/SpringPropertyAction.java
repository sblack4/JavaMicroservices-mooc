/*    */ package org.springframework.boot.logging.logback;
/*    */ 
/*    */ import ch.qos.logback.core.joran.action.Action;
/*    */ import ch.qos.logback.core.joran.action.ActionUtil;
/*    */ import ch.qos.logback.core.joran.action.ActionUtil.Scope;
/*    */ import ch.qos.logback.core.joran.spi.ActionException;
/*    */ import ch.qos.logback.core.joran.spi.InterpretationContext;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ import org.springframework.boot.bind.RelaxedPropertyResolver;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SpringPropertyAction
/*    */   extends Action
/*    */ {
/*    */   private static final String SOURCE_ATTRIBUTE = "source";
/*    */   private static final String DEFAULT_VALUE_ATTRIBUTE = "defaultValue";
/*    */   private final Environment environment;
/*    */   
/*    */   SpringPropertyAction(Environment environment)
/*    */   {
/* 45 */     this.environment = environment;
/*    */   }
/*    */   
/*    */   public void begin(InterpretationContext ic, String elementName, Attributes attributes)
/*    */     throws ActionException
/*    */   {
/* 51 */     String name = attributes.getValue("name");
/* 52 */     String source = attributes.getValue("source");
/* 53 */     ActionUtil.Scope scope = ActionUtil.stringToScope(attributes.getValue("scope"));
/* 54 */     String defaultValue = attributes.getValue("defaultValue");
/* 55 */     if ((OptionHelper.isEmpty(name)) || (OptionHelper.isEmpty(source))) {
/* 56 */       addError("The \"name\" and \"source\" attributes of <springProperty> must be set");
/*    */     }
/*    */     
/* 59 */     ActionUtil.setProperty(ic, name, getValue(source, defaultValue), scope);
/*    */   }
/*    */   
/*    */   private String getValue(String source, String defaultValue) {
/* 63 */     if (this.environment == null) {
/* 64 */       addWarn("No Spring Environment available to resolve " + source);
/* 65 */       return defaultValue;
/*    */     }
/* 67 */     String value = this.environment.getProperty(source);
/* 68 */     if (value != null) {
/* 69 */       return value;
/*    */     }
/* 71 */     int lastDot = source.lastIndexOf(".");
/* 72 */     if (lastDot > 0) {
/* 73 */       String prefix = source.substring(0, lastDot + 1);
/* 74 */       RelaxedPropertyResolver resolver = new RelaxedPropertyResolver(this.environment, prefix);
/*    */       
/* 76 */       return resolver.getProperty(source.substring(lastDot + 1), defaultValue);
/*    */     }
/* 78 */     return defaultValue;
/*    */   }
/*    */   
/*    */   public void end(InterpretationContext ic, String name)
/*    */     throws ActionException
/*    */   {}
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\logging\logback\SpringPropertyAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */