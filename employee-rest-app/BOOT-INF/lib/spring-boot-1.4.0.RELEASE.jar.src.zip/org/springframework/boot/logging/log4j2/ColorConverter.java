/*     */ package org.springframework.boot.logging.log4j2;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.core.LogEvent;
/*     */ import org.apache.logging.log4j.core.config.Configuration;
/*     */ import org.apache.logging.log4j.core.config.plugins.Plugin;
/*     */ import org.apache.logging.log4j.core.layout.PatternLayout;
/*     */ import org.apache.logging.log4j.core.pattern.ConverterKeys;
/*     */ import org.apache.logging.log4j.core.pattern.LogEventPatternConverter;
/*     */ import org.apache.logging.log4j.core.pattern.PatternFormatter;
/*     */ import org.apache.logging.log4j.core.pattern.PatternParser;
/*     */ import org.springframework.boot.ansi.AnsiColor;
/*     */ import org.springframework.boot.ansi.AnsiElement;
/*     */ import org.springframework.boot.ansi.AnsiOutput;
/*     */ import org.springframework.boot.ansi.AnsiStyle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(name="color", category="Converter")
/*     */ @ConverterKeys({"clr", "color"})
/*     */ public final class ColorConverter
/*     */   extends LogEventPatternConverter
/*     */ {
/*     */   private static final Map<String, AnsiElement> ELEMENTS;
/*     */   private static final Map<Integer, AnsiElement> LEVELS;
/*     */   private final List<PatternFormatter> formatters;
/*     */   private final AnsiElement styling;
/*     */   
/*     */   static
/*     */   {
/*  55 */     Map<String, AnsiElement> elements = new HashMap();
/*  56 */     elements.put("faint", AnsiStyle.FAINT);
/*  57 */     elements.put("red", AnsiColor.RED);
/*  58 */     elements.put("green", AnsiColor.GREEN);
/*  59 */     elements.put("yellow", AnsiColor.YELLOW);
/*  60 */     elements.put("blue", AnsiColor.BLUE);
/*  61 */     elements.put("magenta", AnsiColor.MAGENTA);
/*  62 */     elements.put("cyan", AnsiColor.CYAN);
/*  63 */     ELEMENTS = Collections.unmodifiableMap(elements);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */     Map<Integer, AnsiElement> levels = new HashMap();
/*  70 */     levels.put(Integer.valueOf(Level.FATAL.intLevel()), AnsiColor.RED);
/*  71 */     levels.put(Integer.valueOf(Level.ERROR.intLevel()), AnsiColor.RED);
/*  72 */     levels.put(Integer.valueOf(Level.WARN.intLevel()), AnsiColor.YELLOW);
/*  73 */     LEVELS = Collections.unmodifiableMap(levels);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ColorConverter(List<PatternFormatter> formatters, AnsiElement styling)
/*     */   {
/*  81 */     super("style", "style");
/*  82 */     this.formatters = formatters;
/*  83 */     this.styling = styling;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ColorConverter newInstance(Configuration config, String[] options)
/*     */   {
/*  94 */     if (options.length < 1) {
/*  95 */       LOGGER.error("Incorrect number of options on style. Expected at least 1, received {}", 
/*  96 */         Integer.valueOf(options.length));
/*  97 */       return null;
/*     */     }
/*  99 */     if (options[0] == null) {
/* 100 */       LOGGER.error("No pattern supplied on style");
/* 101 */       return null;
/*     */     }
/* 103 */     PatternParser parser = PatternLayout.createPatternParser(config);
/* 104 */     List<PatternFormatter> formatters = parser.parse(options[0]);
/* 105 */     AnsiElement element = options.length == 1 ? null : (AnsiElement)ELEMENTS.get(options[1]);
/* 106 */     return new ColorConverter(formatters, element);
/*     */   }
/*     */   
/*     */   public boolean handlesThrowable()
/*     */   {
/* 111 */     for (PatternFormatter formatter : this.formatters) {
/* 112 */       if (formatter.handlesThrowable()) {
/* 113 */         return true;
/*     */       }
/*     */     }
/* 116 */     return super.handlesThrowable();
/*     */   }
/*     */   
/*     */   public void format(LogEvent event, StringBuilder toAppendTo)
/*     */   {
/* 121 */     StringBuilder buf = new StringBuilder();
/* 122 */     for (PatternFormatter formatter : this.formatters) {
/* 123 */       formatter.format(event, buf);
/*     */     }
/* 125 */     if (buf.length() > 0) {
/* 126 */       AnsiElement element = this.styling;
/* 127 */       if (element == null)
/*     */       {
/* 129 */         element = (AnsiElement)LEVELS.get(Integer.valueOf(event.getLevel().intLevel()));
/* 130 */         element = element == null ? AnsiColor.GREEN : element;
/*     */       }
/* 132 */       appendAnsiString(toAppendTo, buf.toString(), element);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void appendAnsiString(StringBuilder toAppendTo, String in, AnsiElement element)
/*     */   {
/* 138 */     toAppendTo.append(AnsiOutput.toString(new Object[] { element, in }));
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\logging\log4j2\ColorConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */