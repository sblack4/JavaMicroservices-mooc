/*     */ package org.springframework.boot;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import javax.imageio.ImageIO;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.boot.ansi.AnsiBackground;
/*     */ import org.springframework.boot.ansi.AnsiColor;
/*     */ import org.springframework.boot.ansi.AnsiColors;
/*     */ import org.springframework.boot.ansi.AnsiElement;
/*     */ import org.springframework.boot.ansi.AnsiOutput;
/*     */ import org.springframework.boot.bind.RelaxedPropertyResolver;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.PropertyResolver;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageBanner
/*     */   implements Banner
/*     */ {
/*  52 */   private static final Log log = LogFactory.getLog(ImageBanner.class);
/*     */   
/*  54 */   private static final double[] RGB_WEIGHT = { 0.2126D, 0.7152D, 0.0722D };
/*     */   
/*  56 */   private static final char[] PIXEL = { ' ', '.', '*', ':', 'o', '&', '8', '#', '@' };
/*     */   
/*     */   private static final int LUMINANCE_INCREMENT = 10;
/*     */   
/*  60 */   private static final int LUMINANCE_START = 10 * PIXEL.length;
/*     */   private final Resource image;
/*     */   
/*     */   public ImageBanner(Resource image)
/*     */   {
/*  65 */     Assert.notNull(image, "Image must not be null");
/*  66 */     Assert.isTrue(image.exists(), "Image must exist");
/*  67 */     this.image = image;
/*     */   }
/*     */   
/*     */ 
/*     */   public void printBanner(Environment environment, Class<?> sourceClass, PrintStream out)
/*     */   {
/*  73 */     String headless = System.getProperty("java.awt.headless");
/*     */     try {
/*  75 */       System.setProperty("java.awt.headless", "true");
/*  76 */       printBanner(environment, out);
/*     */     }
/*     */     catch (Exception ex) {
/*  79 */       log.warn("Image banner not printable: " + this.image + " (" + ex.getClass() + ": '" + ex
/*  80 */         .getMessage() + "')", ex);
/*     */     }
/*     */     finally {
/*  83 */       if (headless == null) {
/*  84 */         System.clearProperty("java.awt.headless");
/*     */       }
/*     */       else {
/*  87 */         System.setProperty("java.awt.headless", headless);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void printBanner(Environment environment, PrintStream out) throws IOException
/*     */   {
/*  94 */     PropertyResolver properties = new RelaxedPropertyResolver(environment, "banner.image.");
/*     */     
/*  96 */     int width = ((Integer)properties.getProperty("width", Integer.class, Integer.valueOf(76))).intValue();
/*  97 */     int height = ((Integer)properties.getProperty("height", Integer.class, Integer.valueOf(0))).intValue();
/*  98 */     int margin = ((Integer)properties.getProperty("margin", Integer.class, Integer.valueOf(2))).intValue();
/*  99 */     boolean invert = ((Boolean)properties.getProperty("invert", Boolean.class, Boolean.valueOf(false))).booleanValue();
/* 100 */     BufferedImage image = readImage(width, height);
/* 101 */     printBanner(image, margin, invert, out);
/*     */   }
/*     */   
/*     */   private BufferedImage readImage(int width, int height) throws IOException {
/* 105 */     InputStream inputStream = this.image.getInputStream();
/*     */     try {
/* 107 */       BufferedImage image = ImageIO.read(inputStream);
/* 108 */       return resizeImage(image, width, height);
/*     */     }
/*     */     finally {
/* 111 */       inputStream.close();
/*     */     }
/*     */   }
/*     */   
/*     */   private BufferedImage resizeImage(BufferedImage image, int width, int height) {
/* 116 */     if (width < 1) {
/* 117 */       width = 1;
/*     */     }
/* 119 */     if (height <= 0) {
/* 120 */       double aspectRatio = width / image.getWidth() * 0.5D;
/* 121 */       height = (int)Math.ceil(image.getHeight() * aspectRatio);
/*     */     }
/* 123 */     BufferedImage resized = new BufferedImage(width, height, 1);
/*     */     
/* 125 */     Image scaled = image.getScaledInstance(width, height, 1);
/* 126 */     resized.getGraphics().drawImage(scaled, 0, 0, null);
/* 127 */     return resized;
/*     */   }
/*     */   
/*     */   private void printBanner(BufferedImage image, int margin, boolean invert, PrintStream out)
/*     */   {
/* 132 */     AnsiElement background = invert ? AnsiBackground.BLACK : AnsiBackground.DEFAULT;
/* 133 */     out.print(AnsiOutput.encode(AnsiColor.DEFAULT));
/* 134 */     out.print(AnsiOutput.encode(background));
/* 135 */     out.println();
/* 136 */     out.println();
/* 137 */     AnsiColor lastColor = AnsiColor.DEFAULT;
/* 138 */     for (int y = 0; y < image.getHeight(); y++) {
/* 139 */       for (int i = 0; i < margin; i++) {
/* 140 */         out.print(" ");
/*     */       }
/* 142 */       for (int x = 0; x < image.getWidth(); x++) {
/* 143 */         Color color = new Color(image.getRGB(x, y), false);
/* 144 */         AnsiColor ansiColor = AnsiColors.getClosest(color);
/* 145 */         if (ansiColor != lastColor) {
/* 146 */           out.print(AnsiOutput.encode(ansiColor));
/* 147 */           lastColor = ansiColor;
/*     */         }
/* 149 */         out.print(getAsciiPixel(color, invert));
/*     */       }
/* 151 */       out.println();
/*     */     }
/* 153 */     out.print(AnsiOutput.encode(AnsiColor.DEFAULT));
/* 154 */     out.print(AnsiOutput.encode(AnsiBackground.DEFAULT));
/* 155 */     out.println();
/*     */   }
/*     */   
/*     */   private char getAsciiPixel(Color color, boolean dark) {
/* 159 */     double luminance = getLuminance(color, dark);
/* 160 */     for (int i = 0; i < PIXEL.length; i++) {
/* 161 */       if (luminance >= LUMINANCE_START - i * 10) {
/* 162 */         return PIXEL[i];
/*     */       }
/*     */     }
/* 165 */     return PIXEL[(PIXEL.length - 1)];
/*     */   }
/*     */   
/*     */   private int getLuminance(Color color, boolean inverse) {
/* 169 */     double luminance = 0.0D;
/* 170 */     luminance += getLuminance(color.getRed(), inverse, RGB_WEIGHT[0]);
/* 171 */     luminance += getLuminance(color.getGreen(), inverse, RGB_WEIGHT[1]);
/* 172 */     luminance += getLuminance(color.getBlue(), inverse, RGB_WEIGHT[2]);
/* 173 */     return (int)Math.ceil(luminance / 255.0D * 100.0D);
/*     */   }
/*     */   
/*     */   private double getLuminance(int component, boolean inverse, double weight) {
/* 177 */     return (inverse ? 255 - component : component) * weight;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\ImageBanner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */