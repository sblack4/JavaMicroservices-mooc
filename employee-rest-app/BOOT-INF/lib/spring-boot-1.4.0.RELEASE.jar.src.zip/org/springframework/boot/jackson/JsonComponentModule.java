/*     */ package org.springframework.boot.jackson;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.module.SimpleModule;
/*     */ import java.util.Map;
/*     */ import javax.annotation.PostConstruct;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.HierarchicalBeanFactory;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.core.ResolvableType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonComponentModule
/*     */   extends SimpleModule
/*     */   implements BeanFactoryAware
/*     */ {
/*     */   private BeanFactory beanFactory;
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */     throws BeansException
/*     */   {
/*  49 */     this.beanFactory = beanFactory;
/*     */   }
/*     */   
/*     */   @PostConstruct
/*     */   public void registerJsonComponents() {
/*  54 */     BeanFactory beanFactory = this.beanFactory;
/*  55 */     while (beanFactory != null) {
/*  56 */       if ((beanFactory instanceof ListableBeanFactory)) {
/*  57 */         addJsonBeans((ListableBeanFactory)beanFactory);
/*     */       }
/*     */       
/*  60 */       beanFactory = (beanFactory instanceof HierarchicalBeanFactory) ? ((HierarchicalBeanFactory)beanFactory).getParentBeanFactory() : null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void addJsonBeans(ListableBeanFactory beanFactory)
/*     */   {
/*  67 */     Map<String, Object> beans = beanFactory.getBeansWithAnnotation(JsonComponent.class);
/*  68 */     for (Object bean : beans.values()) {
/*  69 */       addJsonBean(bean);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addJsonBean(Object bean) {
/*  74 */     if ((bean instanceof JsonSerializer)) {
/*  75 */       addSerializerWithDeducedType((JsonSerializer)bean);
/*     */     }
/*  77 */     if ((bean instanceof JsonDeserializer)) {
/*  78 */       addDeserializerWithDeducedType((JsonDeserializer)bean);
/*     */     }
/*  80 */     for (Class<?> innerClass : bean.getClass().getDeclaredClasses()) {
/*  81 */       if ((JsonSerializer.class.isAssignableFrom(innerClass)) || 
/*  82 */         (JsonDeserializer.class.isAssignableFrom(innerClass))) {
/*     */         try {
/*  84 */           addJsonBean(innerClass.newInstance());
/*     */         }
/*     */         catch (Exception ex) {
/*  87 */           throw new IllegalStateException(ex);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private <T> void addSerializerWithDeducedType(JsonSerializer<T> serializer)
/*     */   {
/*  95 */     ResolvableType type = ResolvableType.forClass(JsonSerializer.class, serializer
/*  96 */       .getClass());
/*  97 */     addSerializer(type.resolveGeneric(new int[0]), serializer);
/*     */   }
/*     */   
/*     */   private <T> void addDeserializerWithDeducedType(JsonDeserializer<T> deserializer)
/*     */   {
/* 102 */     ResolvableType type = ResolvableType.forClass(JsonDeserializer.class, deserializer
/* 103 */       .getClass());
/* 104 */     addDeserializer(type.resolveGeneric(new int[0]), deserializer);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\jackson\JsonComponentModule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */