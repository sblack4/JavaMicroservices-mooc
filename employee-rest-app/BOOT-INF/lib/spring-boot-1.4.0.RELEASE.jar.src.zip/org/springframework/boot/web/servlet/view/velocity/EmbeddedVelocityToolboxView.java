/*     */ package org.springframework.boot.web.servlet.view.velocity;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.velocity.VelocityContext;
/*     */ import org.apache.velocity.context.Context;
/*     */ import org.apache.velocity.tools.view.ToolboxManager;
/*     */ import org.apache.velocity.tools.view.context.ChainedContext;
/*     */ import org.apache.velocity.tools.view.servlet.ServletToolboxManager;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.web.servlet.view.velocity.VelocityToolboxView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EmbeddedVelocityToolboxView
/*     */   extends VelocityToolboxView
/*     */ {
/*     */   protected Context createVelocityContext(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/*  52 */     ChainedContext context = new ChainedContext(new VelocityContext(model), getVelocityEngine(), request, response, getServletContext());
/*  53 */     if (getToolboxConfigLocation() != null) {
/*  54 */       setContextToolbox(context);
/*     */     }
/*  56 */     return context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void setContextToolbox(ChainedContext context)
/*     */   {
/*  63 */     ToolboxManager toolboxManager = ServletToolboxManager.getInstance(getToolboxConfigFileAwareServletContext(), 
/*  64 */       getToolboxConfigLocation());
/*  65 */     Map<String, Object> toolboxContext = toolboxManager.getToolbox(context);
/*  66 */     context.setToolbox(toolboxContext);
/*     */   }
/*     */   
/*     */   private ServletContext getToolboxConfigFileAwareServletContext() {
/*  70 */     ProxyFactory factory = new ProxyFactory();
/*  71 */     factory.setTarget(getServletContext());
/*  72 */     factory.addAdvice(new GetResourceMethodInterceptor(getToolboxConfigLocation()));
/*  73 */     return (ServletContext)factory.getProxy(getClass().getClassLoader());
/*     */   }
/*     */   
/*     */ 
/*     */   private static class GetResourceMethodInterceptor
/*     */     implements MethodInterceptor
/*     */   {
/*     */     private final String toolboxFile;
/*     */     
/*     */ 
/*     */     GetResourceMethodInterceptor(String toolboxFile)
/*     */     {
/*  85 */       if ((toolboxFile != null) && (!toolboxFile.startsWith("/"))) {
/*  86 */         toolboxFile = "/" + toolboxFile;
/*     */       }
/*  88 */       this.toolboxFile = toolboxFile;
/*     */     }
/*     */     
/*     */     public Object invoke(MethodInvocation invocation) throws Throwable
/*     */     {
/*  93 */       if ((invocation.getMethod().getName().equals("getResourceAsStream")) && 
/*  94 */         (invocation.getArguments()[0].equals(this.toolboxFile))) {
/*  95 */         InputStream inputStream = (InputStream)invocation.proceed();
/*  96 */         if (inputStream == null)
/*     */         {
/*     */           try
/*     */           {
/* 100 */             inputStream = new ClassPathResource(this.toolboxFile, Thread.currentThread().getContextClassLoader()).getInputStream();
/*     */           }
/*     */           catch (Exception localException) {}
/*     */         }
/*     */         
/*     */ 
/* 106 */         return inputStream;
/*     */       }
/* 108 */       return invocation.proceed();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\web\servlet\view\velocity\EmbeddedVelocityToolboxView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */