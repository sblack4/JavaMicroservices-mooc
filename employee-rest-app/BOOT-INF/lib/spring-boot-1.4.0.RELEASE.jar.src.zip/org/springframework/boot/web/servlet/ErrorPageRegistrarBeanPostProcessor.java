/*    */ package org.springframework.boot.web.servlet;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ErrorPageRegistrarBeanPostProcessor
/*    */   implements BeanPostProcessor, ApplicationContextAware
/*    */ {
/*    */   private ApplicationContext applicationContext;
/*    */   private List<ErrorPageRegistrar> registrars;
/*    */   
/*    */   public void setApplicationContext(ApplicationContext applicationContext)
/*    */     throws BeansException
/*    */   {
/* 47 */     this.applicationContext = applicationContext;
/*    */   }
/*    */   
/*    */   public Object postProcessBeforeInitialization(Object bean, String beanName)
/*    */     throws BeansException
/*    */   {
/* 53 */     if ((bean instanceof ErrorPageRegistry)) {
/* 54 */       postProcessBeforeInitialization((ErrorPageRegistry)bean);
/*    */     }
/* 56 */     return bean;
/*    */   }
/*    */   
/*    */   public Object postProcessAfterInitialization(Object bean, String beanName)
/*    */     throws BeansException
/*    */   {
/* 62 */     return bean;
/*    */   }
/*    */   
/*    */   private void postProcessBeforeInitialization(ErrorPageRegistry registry) {
/* 66 */     for (ErrorPageRegistrar registrar : getRegistrars()) {
/* 67 */       registrar.registerErrorPages(registry);
/*    */     }
/*    */   }
/*    */   
/*    */   private Collection<ErrorPageRegistrar> getRegistrars() {
/* 72 */     if (this.registrars == null)
/*    */     {
/*    */ 
/* 75 */       this.registrars = new ArrayList(this.applicationContext.getBeansOfType(ErrorPageRegistrar.class, false, false).values());
/* 76 */       Collections.sort(this.registrars, AnnotationAwareOrderComparator.INSTANCE);
/* 77 */       this.registrars = Collections.unmodifiableList(this.registrars);
/*    */     }
/* 79 */     return this.registrars;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\web\servlet\ErrorPageRegistrarBeanPostProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */