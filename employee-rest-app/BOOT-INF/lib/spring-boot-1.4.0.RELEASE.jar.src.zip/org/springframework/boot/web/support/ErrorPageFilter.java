/*     */ package org.springframework.boot.web.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpServletResponseWrapper;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.boot.web.servlet.ErrorPage;
/*     */ import org.springframework.boot.web.servlet.ErrorPageRegistry;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.stereotype.Component;
/*     */ import org.springframework.web.filter.OncePerRequestFilter;
/*     */ import org.springframework.web.util.NestedServletException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Component
/*     */ @Order(Integer.MIN_VALUE)
/*     */ public class ErrorPageFilter
/*     */   implements Filter, ErrorPageRegistry
/*     */ {
/*  63 */   private static final Log logger = LogFactory.getLog(ErrorPageFilter.class);
/*     */   
/*     */ 
/*     */   private static final String ERROR_EXCEPTION = "javax.servlet.error.exception";
/*     */   
/*     */ 
/*     */   private static final String ERROR_EXCEPTION_TYPE = "javax.servlet.error.exception_type";
/*     */   
/*     */ 
/*     */   private static final String ERROR_MESSAGE = "javax.servlet.error.message";
/*     */   
/*     */ 
/*     */   public static final String ERROR_REQUEST_URI = "javax.servlet.error.request_uri";
/*     */   
/*     */ 
/*     */   private static final String ERROR_STATUS_CODE = "javax.servlet.error.status_code";
/*     */   
/*     */   private String global;
/*     */   
/*  82 */   private final Map<Integer, String> statuses = new HashMap();
/*     */   
/*  84 */   private final Map<Class<?>, String> exceptions = new HashMap();
/*     */   
/*  86 */   private final Map<Class<?>, Class<?>> subtypes = new HashMap();
/*     */   
/*  88 */   private final OncePerRequestFilter delegate = new OncePerRequestFilter()
/*     */   {
/*     */ 
/*     */     protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
/*     */       throws ServletException, IOException
/*     */     {
/*  94 */       ErrorPageFilter.this.doFilter(request, response, chain);
/*     */     }
/*     */     
/*     */     protected boolean shouldNotFilterAsyncDispatch()
/*     */     {
/*  99 */       return false;
/*     */     }
/*     */   };
/*     */   
/*     */   public void init(FilterConfig filterConfig)
/*     */     throws ServletException
/*     */   {
/* 106 */     this.delegate.init(filterConfig);
/*     */   }
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/* 112 */     this.delegate.doFilter(request, response, chain);
/*     */   }
/*     */   
/*     */   private void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException
/*     */   {
/* 117 */     ErrorWrapperResponse wrapped = new ErrorWrapperResponse(response);
/*     */     try {
/* 119 */       chain.doFilter(request, wrapped);
/* 120 */       if (wrapped.hasErrorToSend()) {
/* 121 */         handleErrorStatus(request, response, wrapped.getStatus(), wrapped
/* 122 */           .getMessage());
/* 123 */         response.flushBuffer();
/*     */       }
/* 125 */       else if ((!request.isAsyncStarted()) && (!response.isCommitted())) {
/* 126 */         response.flushBuffer();
/*     */       }
/*     */     }
/*     */     catch (Throwable ex) {
/* 130 */       Throwable exceptionToHandle = ex;
/* 131 */       if ((ex instanceof NestedServletException)) {
/* 132 */         exceptionToHandle = ((NestedServletException)ex).getRootCause();
/*     */       }
/* 134 */       handleException(request, response, wrapped, exceptionToHandle);
/* 135 */       response.flushBuffer();
/*     */     }
/*     */   }
/*     */   
/*     */   private void handleErrorStatus(HttpServletRequest request, HttpServletResponse response, int status, String message)
/*     */     throws ServletException, IOException
/*     */   {
/* 142 */     if (response.isCommitted()) {
/* 143 */       handleCommittedResponse(request, null);
/* 144 */       return;
/*     */     }
/* 146 */     String errorPath = getErrorPath(this.statuses, Integer.valueOf(status));
/* 147 */     if (errorPath == null) {
/* 148 */       response.sendError(status, message);
/* 149 */       return;
/*     */     }
/* 151 */     response.setStatus(status);
/* 152 */     setErrorAttributes(request, status, message);
/* 153 */     request.getRequestDispatcher(errorPath).forward(request, response);
/*     */   }
/*     */   
/*     */   private void handleException(HttpServletRequest request, HttpServletResponse response, ErrorWrapperResponse wrapped, Throwable ex)
/*     */     throws IOException, ServletException
/*     */   {
/* 159 */     Class<?> type = ex.getClass();
/* 160 */     String errorPath = getErrorPath(type);
/* 161 */     if (errorPath == null) {
/* 162 */       rethrow(ex);
/* 163 */       return;
/*     */     }
/* 165 */     if (response.isCommitted()) {
/* 166 */       handleCommittedResponse(request, ex);
/* 167 */       return;
/*     */     }
/*     */     
/* 170 */     forwardToErrorPage(errorPath, request, wrapped, ex);
/*     */   }
/*     */   
/*     */   private void forwardToErrorPage(String path, HttpServletRequest request, HttpServletResponse response, Throwable ex)
/*     */     throws ServletException, IOException
/*     */   {
/* 176 */     if (logger.isErrorEnabled())
/*     */     {
/* 178 */       String message = "Forwarding to error page from request " + getDescription(request) + " due to exception [" + ex.getMessage() + "]";
/*     */       
/* 180 */       logger.error(message, ex);
/*     */     }
/* 182 */     setErrorAttributes(request, 500, ex.getMessage());
/* 183 */     request.setAttribute("javax.servlet.error.exception", ex);
/* 184 */     request.setAttribute("javax.servlet.error.exception_type", ex.getClass().getName());
/* 185 */     response.reset();
/* 186 */     response.sendError(500, ex.getMessage());
/* 187 */     request.getRequestDispatcher(path).forward(request, response);
/*     */   }
/*     */   
/*     */   private String getDescription(HttpServletRequest request)
/*     */   {
/* 192 */     return "[" + request.getServletPath() + (request.getPathInfo() == null ? "" : request.getPathInfo()) + "]";
/*     */   }
/*     */   
/*     */   private void handleCommittedResponse(HttpServletRequest request, Throwable ex)
/*     */   {
/* 197 */     String message = "Cannot forward to error page for request " + getDescription(request) + " as the response has already been" + " committed. As a result, the response may have the wrong status" + " code. If your application is running on WebSphere Application" + " Server you may be able to resolve this problem by setting" + " com.ibm.ws.webcontainer.invokeFlushAfterService to false";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 202 */     if (ex == null) {
/* 203 */       logger.error(message);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 208 */       logger.error(message, ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private String getErrorPath(Map<Integer, String> map, Integer status) {
/* 213 */     if (map.containsKey(status)) {
/* 214 */       return (String)map.get(status);
/*     */     }
/* 216 */     return this.global;
/*     */   }
/*     */   
/*     */   private String getErrorPath(Class<?> type) {
/* 220 */     if (this.exceptions.containsKey(type)) {
/* 221 */       return (String)this.exceptions.get(type);
/*     */     }
/* 223 */     if (this.subtypes.containsKey(type)) {
/* 224 */       return (String)this.exceptions.get(this.subtypes.get(type));
/*     */     }
/* 226 */     Class<?> subtype = type;
/* 227 */     while (subtype != Object.class) {
/* 228 */       subtype = subtype.getSuperclass();
/* 229 */       if (this.exceptions.containsKey(subtype)) {
/* 230 */         this.subtypes.put(subtype, type);
/* 231 */         return (String)this.exceptions.get(subtype);
/*     */       }
/*     */     }
/* 234 */     return this.global;
/*     */   }
/*     */   
/*     */   private void setErrorAttributes(HttpServletRequest request, int status, String message)
/*     */   {
/* 239 */     request.setAttribute("javax.servlet.error.status_code", Integer.valueOf(status));
/* 240 */     request.setAttribute("javax.servlet.error.message", message);
/* 241 */     request.setAttribute("javax.servlet.error.request_uri", request.getRequestURI());
/*     */   }
/*     */   
/*     */   private void rethrow(Throwable ex) throws IOException, ServletException {
/* 245 */     if ((ex instanceof RuntimeException)) {
/* 246 */       throw ((RuntimeException)ex);
/*     */     }
/* 248 */     if ((ex instanceof Error)) {
/* 249 */       throw ((Error)ex);
/*     */     }
/* 251 */     if ((ex instanceof IOException)) {
/* 252 */       throw ((IOException)ex);
/*     */     }
/* 254 */     if ((ex instanceof ServletException)) {
/* 255 */       throw ((ServletException)ex);
/*     */     }
/* 257 */     throw new IllegalStateException(ex);
/*     */   }
/*     */   
/*     */   public void addErrorPages(ErrorPage... errorPages)
/*     */   {
/* 262 */     for (ErrorPage errorPage : errorPages) {
/* 263 */       if (errorPage.isGlobal()) {
/* 264 */         this.global = errorPage.getPath();
/*     */       }
/* 266 */       else if (errorPage.getStatus() != null) {
/* 267 */         this.statuses.put(Integer.valueOf(errorPage.getStatus().value()), errorPage.getPath());
/*     */       }
/*     */       else {
/* 270 */         this.exceptions.put(errorPage.getException(), errorPage.getPath());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void destroy() {}
/*     */   
/*     */ 
/*     */   private static class ErrorWrapperResponse
/*     */     extends HttpServletResponseWrapper
/*     */   {
/*     */     private int status;
/*     */     
/*     */     private String message;
/* 285 */     private boolean hasErrorToSend = false;
/*     */     
/*     */     ErrorWrapperResponse(HttpServletResponse response) {
/* 288 */       super();
/*     */     }
/*     */     
/*     */     public void sendError(int status) throws IOException
/*     */     {
/* 293 */       sendError(status, null);
/*     */     }
/*     */     
/*     */     public void sendError(int status, String message) throws IOException
/*     */     {
/* 298 */       this.status = status;
/* 299 */       this.message = message;
/* 300 */       this.hasErrorToSend = true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public int getStatus()
/*     */     {
/* 307 */       if (this.hasErrorToSend) {
/* 308 */         return this.status;
/*     */       }
/*     */       
/* 311 */       return super.getStatus();
/*     */     }
/*     */     
/*     */     public void flushBuffer() throws IOException
/*     */     {
/* 316 */       if ((this.hasErrorToSend) && (!isCommitted())) {
/* 317 */         ((HttpServletResponse)getResponse()).sendError(this.status, this.message);
/*     */       }
/*     */       
/* 320 */       super.flushBuffer();
/*     */     }
/*     */     
/*     */     public String getMessage() {
/* 324 */       return this.message;
/*     */     }
/*     */     
/*     */     public boolean hasErrorToSend() {
/* 328 */       return this.hasErrorToSend;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\web\support\ErrorPageFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */