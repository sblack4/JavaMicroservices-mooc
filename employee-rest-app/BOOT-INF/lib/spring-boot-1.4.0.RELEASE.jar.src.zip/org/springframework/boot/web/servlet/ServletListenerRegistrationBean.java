/*     */ package org.springframework.boot.web.servlet;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.EventListener;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletContextAttributeListener;
/*     */ import javax.servlet.ServletContextListener;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequestAttributeListener;
/*     */ import javax.servlet.ServletRequestListener;
/*     */ import javax.servlet.http.HttpSessionAttributeListener;
/*     */ import javax.servlet.http.HttpSessionListener;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletListenerRegistrationBean<T extends EventListener>
/*     */   extends RegistrationBean
/*     */ {
/*  64 */   private static final Log logger = LogFactory.getLog(ServletListenerRegistrationBean.class);
/*     */   private static final Set<Class<?>> SUPPORTED_TYPES;
/*     */   private T listener;
/*     */   
/*     */   static {
/*  69 */     Set<Class<?>> types = new HashSet();
/*  70 */     types.add(ServletContextAttributeListener.class);
/*  71 */     types.add(ServletRequestListener.class);
/*  72 */     types.add(ServletRequestAttributeListener.class);
/*  73 */     types.add(HttpSessionAttributeListener.class);
/*  74 */     types.add(HttpSessionListener.class);
/*  75 */     types.add(ServletContextListener.class);
/*  76 */     SUPPORTED_TYPES = Collections.unmodifiableSet(types);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletListenerRegistrationBean(T listener)
/*     */   {
/*  92 */     Assert.notNull(listener, "Listener must not be null");
/*  93 */     Assert.isTrue(isSupportedType(listener), "Listener is not of a supported type");
/*  94 */     this.listener = listener;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setListener(T listener)
/*     */   {
/* 102 */     Assert.notNull(listener, "Listener must not be null");
/* 103 */     Assert.isTrue(isSupportedType(listener), "Listener is not of a supported type");
/* 104 */     this.listener = listener;
/*     */   }
/*     */   
/*     */   public void onStartup(ServletContext servletContext) throws ServletException
/*     */   {
/* 109 */     if (!isEnabled()) {
/* 110 */       logger.info("Listener " + this.listener + " was not registered (disabled)");
/* 111 */       return;
/*     */     }
/*     */     try {
/* 114 */       servletContext.addListener(this.listener);
/*     */     }
/*     */     catch (RuntimeException ex) {
/* 117 */       throw new IllegalStateException("Failed to add listener '" + this.listener + "' to servlet context", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public T getListener()
/*     */   {
/* 124 */     return this.listener;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isSupportedType(EventListener listener)
/*     */   {
/* 133 */     for (Class<?> type : SUPPORTED_TYPES) {
/* 134 */       if (ClassUtils.isAssignableValue(type, listener)) {
/* 135 */         return true;
/*     */       }
/*     */     }
/* 138 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Set<Class<?>> getSupportedTypes()
/*     */   {
/* 146 */     return SUPPORTED_TYPES;
/*     */   }
/*     */   
/*     */   public ServletListenerRegistrationBean() {}
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\web\servlet\ServletListenerRegistrationBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */