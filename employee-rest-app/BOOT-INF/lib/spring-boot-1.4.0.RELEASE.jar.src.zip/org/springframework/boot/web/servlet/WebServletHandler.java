/*    */ package org.springframework.boot.web.servlet;
/*    */ 
/*    */ import java.util.Map;
/*    */ import javax.servlet.annotation.WebServlet;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WebServletHandler
/*    */   extends ServletComponentHandler
/*    */ {
/*    */   WebServletHandler()
/*    */   {
/* 36 */     super(WebServlet.class);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void doHandle(Map<String, Object> attributes, BeanDefinition beanDefinition, BeanDefinitionRegistry registry)
/*    */   {
/* 43 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(ServletRegistrationBean.class);
/* 44 */     builder.addPropertyValue("asyncSupported", attributes.get("asyncSupported"));
/* 45 */     builder.addPropertyValue("initParameters", extractInitParameters(attributes));
/* 46 */     builder.addPropertyValue("loadOnStartup", attributes.get("loadOnStartup"));
/* 47 */     String name = determineName(attributes, beanDefinition);
/* 48 */     builder.addPropertyValue("name", name);
/* 49 */     builder.addPropertyValue("servlet", beanDefinition);
/* 50 */     builder.addPropertyValue("urlMappings", 
/* 51 */       extractUrlPatterns("urlPatterns", attributes));
/* 52 */     registry.registerBeanDefinition(name, builder.getBeanDefinition());
/*    */   }
/*    */   
/*    */ 
/*    */   private String determineName(Map<String, Object> attributes, BeanDefinition beanDefinition)
/*    */   {
/* 58 */     return (String)(StringUtils.hasText((String)attributes.get("name")) ? attributes.get("name") : beanDefinition.getBeanClassName());
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\web\servlet\WebServletHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */