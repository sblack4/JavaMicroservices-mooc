/*     */ package org.springframework.boot.web.client;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.http.client.AbstractClientHttpRequestFactoryWrapper;
/*     */ import org.springframework.http.client.ClientHttpRequestFactory;
/*     */ import org.springframework.http.client.SimpleClientHttpRequestFactory;
/*     */ import org.springframework.http.client.support.BasicAuthorizationInterceptor;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.web.client.ResponseErrorHandler;
/*     */ import org.springframework.web.client.RestTemplate;
/*     */ import org.springframework.web.util.UriTemplateHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RestTemplateBuilder
/*     */ {
/*     */   private static final Map<String, String> REQUEST_FACTORY_CANDIDATES;
/*     */   private final boolean detectRequestFactory;
/*     */   private final String rootUri;
/*     */   private final Set<HttpMessageConverter<?>> messageConverters;
/*     */   private final ClientHttpRequestFactory requestFactory;
/*     */   private final UriTemplateHandler uriTemplateHandler;
/*     */   private final ResponseErrorHandler errorHandler;
/*     */   private final BasicAuthorizationInterceptor basicAuthorization;
/*     */   private final Set<RestTemplateCustomizer> restTemplateCustomizers;
/*     */   private final Set<RequestFactoryCustomizer> requestFactoryCustomizers;
/*     */   
/*     */   static
/*     */   {
/*  66 */     Map<String, String> candidates = new LinkedHashMap();
/*  67 */     candidates.put("org.apache.http.client.HttpClient", "org.springframework.http.client.HttpComponentsClientHttpRequestFactory");
/*     */     
/*  69 */     candidates.put("okhttp3.OkHttpClient", "org.springframework.http.client.OkHttp3ClientHttpRequestFactory");
/*     */     
/*  71 */     candidates.put("com.squareup.okhttp.OkHttpClient", "org.springframework.http.client.OkHttpClientHttpRequestFactory");
/*     */     
/*  73 */     candidates.put("io.netty.channel.EventLoopGroup", "org.springframework.http.client.Netty4ClientHttpRequestFactory");
/*     */     
/*  75 */     REQUEST_FACTORY_CANDIDATES = Collections.unmodifiableMap(candidates);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplateBuilder(RestTemplateCustomizer... customizers)
/*     */   {
/* 102 */     Assert.notNull(customizers, "Customizers must not be null");
/* 103 */     this.detectRequestFactory = true;
/* 104 */     this.rootUri = null;
/* 105 */     this.messageConverters = null;
/* 106 */     this.requestFactory = null;
/* 107 */     this.uriTemplateHandler = null;
/* 108 */     this.errorHandler = null;
/* 109 */     this.basicAuthorization = null;
/* 110 */     this.restTemplateCustomizers = Collections.unmodifiableSet(new LinkedHashSet(
/* 111 */       Arrays.asList(customizers)));
/* 112 */     this.requestFactoryCustomizers = Collections.emptySet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private RestTemplateBuilder(boolean detectRequestFactory, String rootUri, Set<HttpMessageConverter<?>> messageConverters, ClientHttpRequestFactory requestFactory, UriTemplateHandler uriTemplateHandler, ResponseErrorHandler errorHandler, BasicAuthorizationInterceptor basicAuthorization, Set<RestTemplateCustomizer> restTemplateCustomizers, Set<RequestFactoryCustomizer> requestFactoryCustomizers)
/*     */   {
/* 123 */     this.detectRequestFactory = detectRequestFactory;
/* 124 */     this.rootUri = rootUri;
/* 125 */     this.messageConverters = messageConverters;
/* 126 */     this.requestFactory = requestFactory;
/* 127 */     this.uriTemplateHandler = uriTemplateHandler;
/* 128 */     this.errorHandler = errorHandler;
/* 129 */     this.basicAuthorization = basicAuthorization;
/* 130 */     this.restTemplateCustomizers = restTemplateCustomizers;
/* 131 */     this.requestFactoryCustomizers = requestFactoryCustomizers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplateBuilder detectRequestFactory(boolean detectRequestFactory)
/*     */   {
/* 142 */     return new RestTemplateBuilder(detectRequestFactory, this.rootUri, this.messageConverters, this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthorization, this.restTemplateCustomizers, this.requestFactoryCustomizers);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplateBuilder rootUri(String rootUri)
/*     */   {
/* 155 */     return new RestTemplateBuilder(this.detectRequestFactory, rootUri, this.messageConverters, this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthorization, this.restTemplateCustomizers, this.requestFactoryCustomizers);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplateBuilder messageConverters(HttpMessageConverter<?>... messageConverters)
/*     */   {
/* 170 */     Assert.notNull(messageConverters, "MessageConverters must not be null");
/* 171 */     return messageConverters(Arrays.asList(messageConverters));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplateBuilder messageConverters(Collection<? extends HttpMessageConverter<?>> messageConverters)
/*     */   {
/* 183 */     Assert.notNull(messageConverters, "MessageConverters must not be null");
/*     */     
/* 185 */     return new RestTemplateBuilder(this.detectRequestFactory, this.rootUri, Collections.unmodifiableSet(new LinkedHashSet(messageConverters)), this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthorization, this.restTemplateCustomizers, this.requestFactoryCustomizers);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplateBuilder additionalMessageConverters(HttpMessageConverter<?>... messageConverters)
/*     */   {
/* 201 */     Assert.notNull(messageConverters, "MessageConverters must not be null");
/* 202 */     return additionalMessageConverters(Arrays.asList(messageConverters));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplateBuilder additionalMessageConverters(Collection<? extends HttpMessageConverter<?>> messageConverters)
/*     */   {
/* 214 */     Assert.notNull(messageConverters, "MessageConverters must not be null");
/*     */     
/* 216 */     return new RestTemplateBuilder(this.detectRequestFactory, this.rootUri, append(this.messageConverters, messageConverters), this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthorization, this.restTemplateCustomizers, this.requestFactoryCustomizers);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplateBuilder defaultMessageConverters()
/*     */   {
/* 230 */     return new RestTemplateBuilder(this.detectRequestFactory, this.rootUri, Collections.unmodifiableSet(new LinkedHashSet(new RestTemplate()
/* 231 */       .getMessageConverters())), this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthorization, this.restTemplateCustomizers, this.requestFactoryCustomizers);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplateBuilder requestFactory(Class<? extends ClientHttpRequestFactory> requestFactory)
/*     */   {
/* 245 */     Assert.notNull(requestFactory, "RequestFactory must not be null");
/* 246 */     return requestFactory((ClientHttpRequestFactory)BeanUtils.instantiate(requestFactory));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplateBuilder requestFactory(ClientHttpRequestFactory requestFactory)
/*     */   {
/* 256 */     Assert.notNull(requestFactory, "RequestFactory must not be null");
/* 257 */     return new RestTemplateBuilder(this.detectRequestFactory, this.rootUri, this.messageConverters, requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthorization, this.restTemplateCustomizers, this.requestFactoryCustomizers);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplateBuilder uriTemplateHandler(UriTemplateHandler uriTemplateHandler)
/*     */   {
/* 270 */     Assert.notNull(uriTemplateHandler, "UriTemplateHandler must not be null");
/* 271 */     return new RestTemplateBuilder(this.detectRequestFactory, this.rootUri, this.messageConverters, this.requestFactory, uriTemplateHandler, this.errorHandler, this.basicAuthorization, this.restTemplateCustomizers, this.requestFactoryCustomizers);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplateBuilder errorHandler(ResponseErrorHandler errorHandler)
/*     */   {
/* 284 */     Assert.notNull(errorHandler, "ErrorHandler must not be null");
/* 285 */     return new RestTemplateBuilder(this.detectRequestFactory, this.rootUri, this.messageConverters, this.requestFactory, this.uriTemplateHandler, errorHandler, this.basicAuthorization, this.restTemplateCustomizers, this.requestFactoryCustomizers);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplateBuilder basicAuthorization(String username, String password)
/*     */   {
/* 299 */     return new RestTemplateBuilder(this.detectRequestFactory, this.rootUri, this.messageConverters, this.requestFactory, this.uriTemplateHandler, this.errorHandler, new BasicAuthorizationInterceptor(username, password), this.restTemplateCustomizers, this.requestFactoryCustomizers);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplateBuilder customizers(RestTemplateCustomizer... restTemplateCustomizers)
/*     */   {
/* 316 */     Assert.notNull(restTemplateCustomizers, "RestTemplateCustomizers must not be null");
/*     */     
/* 318 */     return customizers(Arrays.asList(restTemplateCustomizers));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplateBuilder customizers(Collection<? extends RestTemplateCustomizer> restTemplateCustomizers)
/*     */   {
/* 332 */     Assert.notNull(restTemplateCustomizers, "RestTemplateCustomizers must not be null");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 337 */     return new RestTemplateBuilder(this.detectRequestFactory, this.rootUri, this.messageConverters, this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthorization, Collections.unmodifiableSet(new LinkedHashSet(restTemplateCustomizers)), this.requestFactoryCustomizers);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplateBuilder additionalCustomizers(RestTemplateCustomizer... restTemplateCustomizers)
/*     */   {
/* 352 */     Assert.notNull(restTemplateCustomizers, "RestTemplateCustomizers must not be null");
/*     */     
/* 354 */     return additionalCustomizers(Arrays.asList(restTemplateCustomizers));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplateBuilder additionalCustomizers(Collection<? extends RestTemplateCustomizer> customizers)
/*     */   {
/* 367 */     Assert.notNull(customizers, "RestTemplateCustomizers must not be null");
/*     */     
/*     */ 
/*     */ 
/* 371 */     return new RestTemplateBuilder(this.detectRequestFactory, this.rootUri, this.messageConverters, this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthorization, append(this.restTemplateCustomizers, customizers), this.requestFactoryCustomizers);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplateBuilder setConnectTimeout(int connectTimeout)
/*     */   {
/* 386 */     return new RestTemplateBuilder(this.detectRequestFactory, this.rootUri, this.messageConverters, this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthorization, this.restTemplateCustomizers, append(this.requestFactoryCustomizers, new ConnectTimeoutRequestFactoryCustomizer(connectTimeout)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplateBuilder setReadTimeout(int readTimeout)
/*     */   {
/* 401 */     return new RestTemplateBuilder(this.detectRequestFactory, this.rootUri, this.messageConverters, this.requestFactory, this.uriTemplateHandler, this.errorHandler, this.basicAuthorization, this.restTemplateCustomizers, append(this.requestFactoryCustomizers, new ReadTimeoutRequestFactoryCustomizer(readTimeout)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RestTemplate build()
/*     */   {
/* 412 */     return build(RestTemplate.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends RestTemplate> T build(Class<T> restTemplateClass)
/*     */   {
/* 426 */     return configure((RestTemplate)BeanUtils.instantiate(restTemplateClass));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends RestTemplate> T configure(T restTemplate)
/*     */   {
/* 438 */     configureRequestFactory(restTemplate);
/* 439 */     if (!CollectionUtils.isEmpty(this.messageConverters)) {
/* 440 */       restTemplate.setMessageConverters(new ArrayList(this.messageConverters));
/*     */     }
/*     */     
/* 443 */     if (this.uriTemplateHandler != null) {
/* 444 */       restTemplate.setUriTemplateHandler(this.uriTemplateHandler);
/*     */     }
/* 446 */     if (this.errorHandler != null) {
/* 447 */       restTemplate.setErrorHandler(this.errorHandler);
/*     */     }
/* 449 */     if (this.rootUri != null) {
/* 450 */       RootUriTemplateHandler.addTo(restTemplate, this.rootUri);
/*     */     }
/* 452 */     if (this.basicAuthorization != null) {
/* 453 */       restTemplate.getInterceptors().add(this.basicAuthorization);
/*     */     }
/* 455 */     if (!CollectionUtils.isEmpty(this.restTemplateCustomizers)) {
/* 456 */       for (RestTemplateCustomizer customizer : this.restTemplateCustomizers) {
/* 457 */         customizer.customize(restTemplate);
/*     */       }
/*     */     }
/* 460 */     return restTemplate;
/*     */   }
/*     */   
/*     */   private void configureRequestFactory(RestTemplate restTemplate) {
/* 464 */     ClientHttpRequestFactory requestFactory = null;
/* 465 */     if (this.requestFactory != null) {
/* 466 */       requestFactory = unwrapRequestFactoryIfNecessary(this.requestFactory);
/*     */     }
/* 468 */     else if (this.detectRequestFactory) {
/* 469 */       requestFactory = detectRequestFactory();
/*     */     }
/* 471 */     if (requestFactory != null) {
/* 472 */       for (RequestFactoryCustomizer customizer : this.requestFactoryCustomizers) {
/* 473 */         customizer.customize(requestFactory);
/*     */       }
/* 475 */       restTemplate.setRequestFactory(requestFactory);
/*     */     }
/*     */   }
/*     */   
/*     */   private ClientHttpRequestFactory unwrapRequestFactoryIfNecessary(ClientHttpRequestFactory requestFactory)
/*     */   {
/* 481 */     if (!(requestFactory instanceof AbstractClientHttpRequestFactoryWrapper)) {
/* 482 */       return requestFactory;
/*     */     }
/* 484 */     ClientHttpRequestFactory unwrappedRequestFactory = requestFactory;
/* 485 */     Field field = ReflectionUtils.findField(AbstractClientHttpRequestFactoryWrapper.class, "requestFactory");
/*     */     
/* 487 */     ReflectionUtils.makeAccessible(field);
/*     */     do
/*     */     {
/* 490 */       unwrappedRequestFactory = (ClientHttpRequestFactory)ReflectionUtils.getField(field, unwrappedRequestFactory);
/*     */     }
/* 492 */     while ((unwrappedRequestFactory instanceof AbstractClientHttpRequestFactoryWrapper));
/* 493 */     return unwrappedRequestFactory;
/*     */   }
/*     */   
/*     */   private ClientHttpRequestFactory detectRequestFactory() {
/* 497 */     for (Map.Entry<String, String> candidate : REQUEST_FACTORY_CANDIDATES
/* 498 */       .entrySet()) {
/* 499 */       ClassLoader classLoader = getClass().getClassLoader();
/* 500 */       if (ClassUtils.isPresent((String)candidate.getKey(), classLoader)) {
/* 501 */         Class<?> factoryClass = ClassUtils.resolveClassName((String)candidate.getValue(), classLoader);
/*     */         
/* 503 */         return (ClientHttpRequestFactory)BeanUtils.instantiate(factoryClass);
/*     */       }
/*     */     }
/* 506 */     return new SimpleClientHttpRequestFactory();
/*     */   }
/*     */   
/*     */   private <T> Set<T> append(Set<T> set, T addition)
/*     */   {
/* 511 */     Set<T> result = new LinkedHashSet(set == null ? Collections.emptySet() : set);
/* 512 */     result.add(addition);
/* 513 */     return Collections.unmodifiableSet(result);
/*     */   }
/*     */   
/*     */   private <T> Set<T> append(Set<T> set, Collection<? extends T> additions)
/*     */   {
/* 518 */     Set<T> result = new LinkedHashSet(set == null ? Collections.emptySet() : set);
/* 519 */     result.addAll(additions);
/* 520 */     return Collections.unmodifiableSet(result);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static abstract interface RequestFactoryCustomizer
/*     */   {
/*     */     public abstract void customize(ClientHttpRequestFactory paramClientHttpRequestFactory);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static abstract class TimeoutRequestFactoryCustomizer
/*     */     implements RestTemplateBuilder.RequestFactoryCustomizer
/*     */   {
/*     */     private final int timeout;
/*     */     
/*     */ 
/*     */     private final String methodName;
/*     */     
/*     */ 
/*     */     TimeoutRequestFactoryCustomizer(int timeout, String methodName)
/*     */     {
/* 543 */       this.timeout = timeout;
/* 544 */       this.methodName = methodName;
/*     */     }
/*     */     
/*     */     public void customize(ClientHttpRequestFactory factory)
/*     */     {
/* 549 */       ReflectionUtils.invokeMethod(findMethod(factory), factory, new Object[] { Integer.valueOf(this.timeout) });
/*     */     }
/*     */     
/*     */     private Method findMethod(ClientHttpRequestFactory factory) {
/* 553 */       Method method = ReflectionUtils.findMethod(factory.getClass(), this.methodName, new Class[] { Integer.TYPE });
/*     */       
/* 555 */       if (method != null) {
/* 556 */         return method;
/*     */       }
/* 558 */       throw new IllegalStateException("Request factory " + factory.getClass() + " does not have a " + this.methodName + "(int) method");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class ReadTimeoutRequestFactoryCustomizer
/*     */     extends RestTemplateBuilder.TimeoutRequestFactoryCustomizer
/*     */   {
/*     */     ReadTimeoutRequestFactoryCustomizer(int readTimeout)
/*     */     {
/* 571 */       super("setReadTimeout");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class ConnectTimeoutRequestFactoryCustomizer
/*     */     extends RestTemplateBuilder.TimeoutRequestFactoryCustomizer
/*     */   {
/*     */     ConnectTimeoutRequestFactoryCustomizer(int connectTimeout)
/*     */     {
/* 583 */       super("setConnectTimeout");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\web\client\RestTemplateBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */