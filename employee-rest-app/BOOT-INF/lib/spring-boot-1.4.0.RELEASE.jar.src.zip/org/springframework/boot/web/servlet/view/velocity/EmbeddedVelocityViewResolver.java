/*    */ package org.springframework.boot.web.servlet.view.velocity;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.springframework.web.servlet.view.velocity.VelocityView;
/*    */ import org.springframework.web.servlet.view.velocity.VelocityViewResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class EmbeddedVelocityViewResolver
/*    */   extends VelocityViewResolver
/*    */ {
/*    */   private String toolboxConfigLocation;
/*    */   
/*    */   protected void initApplicationContext()
/*    */   {
/* 39 */     if ((this.toolboxConfigLocation != null) && 
/* 40 */       (VelocityView.class.equals(getViewClass()))) {
/* 41 */       this.logger.info("Using EmbeddedVelocityToolboxView instead of default VelocityView due to specified toolboxConfigLocation");
/*    */       
/* 43 */       setViewClass(EmbeddedVelocityToolboxView.class);
/*    */     }
/*    */     
/* 46 */     super.initApplicationContext();
/*    */   }
/*    */   
/*    */   public void setToolboxConfigLocation(String toolboxConfigLocation)
/*    */   {
/* 51 */     super.setToolboxConfigLocation(toolboxConfigLocation);
/* 52 */     this.toolboxConfigLocation = toolboxConfigLocation;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\web\servlet\view\velocity\EmbeddedVelocityViewResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */