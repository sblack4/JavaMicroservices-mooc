/*     */ package org.springframework.boot.web.servlet;
/*     */ 
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.EventListener;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.MultipartConfigElement;
/*     */ import javax.servlet.Servlet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletContextInitializerBeans
/*     */   extends AbstractCollection<ServletContextInitializer>
/*     */ {
/*     */   private static final String DISPATCHER_SERVLET_NAME = "dispatcherServlet";
/*  65 */   private static final Log logger = LogFactory.getLog(ServletContextInitializerBeans.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  70 */   private final Set<Object> seen = new HashSet();
/*     */   
/*     */   private final MultiValueMap<Class<?>, ServletContextInitializer> initializers;
/*     */   private List<ServletContextInitializer> sortedList;
/*     */   
/*     */   public ServletContextInitializerBeans(ListableBeanFactory beanFactory)
/*     */   {
/*  77 */     this.initializers = new LinkedMultiValueMap();
/*  78 */     addServletContextInitializerBeans(beanFactory);
/*  79 */     addAdaptableBeans(beanFactory);
/*  80 */     List<ServletContextInitializer> sortedInitializers = new ArrayList();
/*  81 */     for (Map.Entry<?, List<ServletContextInitializer>> entry : this.initializers
/*  82 */       .entrySet()) {
/*  83 */       AnnotationAwareOrderComparator.sort((List)entry.getValue());
/*  84 */       sortedInitializers.addAll((Collection)entry.getValue());
/*     */     }
/*  86 */     this.sortedList = Collections.unmodifiableList(sortedInitializers);
/*     */   }
/*     */   
/*     */   private void addServletContextInitializerBeans(ListableBeanFactory beanFactory) {
/*  90 */     for (Map.Entry<String, ServletContextInitializer> initializerBean : getOrderedBeansOfType(beanFactory, ServletContextInitializer.class))
/*     */     {
/*  92 */       addServletContextInitializerBean((String)initializerBean.getKey(), 
/*  93 */         (ServletContextInitializer)initializerBean.getValue(), beanFactory);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addServletContextInitializerBean(String beanName, ServletContextInitializer initializer, ListableBeanFactory beanFactory)
/*     */   {
/*  99 */     if ((initializer instanceof ServletRegistrationBean)) {
/* 100 */       Servlet source = ((ServletRegistrationBean)initializer).getServlet();
/* 101 */       addServletContextInitializerBean(Servlet.class, beanName, initializer, beanFactory, source);
/*     */ 
/*     */     }
/* 104 */     else if ((initializer instanceof FilterRegistrationBean)) {
/* 105 */       Filter source = ((FilterRegistrationBean)initializer).getFilter();
/* 106 */       addServletContextInitializerBean(Filter.class, beanName, initializer, beanFactory, source);
/*     */ 
/*     */     }
/* 109 */     else if ((initializer instanceof DelegatingFilterProxyRegistrationBean))
/*     */     {
/* 111 */       String source = ((DelegatingFilterProxyRegistrationBean)initializer).getTargetBeanName();
/* 112 */       addServletContextInitializerBean(Filter.class, beanName, initializer, beanFactory, source);
/*     */ 
/*     */     }
/* 115 */     else if ((initializer instanceof ServletListenerRegistrationBean))
/*     */     {
/* 117 */       EventListener source = ((ServletListenerRegistrationBean)initializer).getListener();
/* 118 */       addServletContextInitializerBean(EventListener.class, beanName, initializer, beanFactory, source);
/*     */     }
/*     */     else
/*     */     {
/* 122 */       addServletContextInitializerBean(ServletContextInitializer.class, beanName, initializer, beanFactory, null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void addServletContextInitializerBean(Class<?> type, String beanName, ServletContextInitializer initializer, ListableBeanFactory beanFactory, Object source)
/*     */   {
/* 130 */     this.initializers.add(type, initializer);
/* 131 */     if (source != null)
/*     */     {
/* 133 */       this.seen.add(source);
/*     */     }
/* 135 */     if (logger.isDebugEnabled()) {
/* 136 */       String resourceDescription = getResourceDescription(beanName, beanFactory);
/* 137 */       int order = getOrder(initializer);
/* 138 */       logger.debug("Added existing " + type
/* 139 */         .getSimpleName() + " initializer bean '" + beanName + "'; order=" + order + ", resource=" + resourceDescription);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private String getResourceDescription(String beanName, ListableBeanFactory beanFactory)
/*     */   {
/* 146 */     if ((beanFactory instanceof BeanDefinitionRegistry)) {
/* 147 */       BeanDefinitionRegistry registry = (BeanDefinitionRegistry)beanFactory;
/* 148 */       return registry.getBeanDefinition(beanName).getResourceDescription();
/*     */     }
/* 150 */     return "unknown";
/*     */   }
/*     */   
/*     */   private void addAdaptableBeans(ListableBeanFactory beanFactory)
/*     */   {
/* 155 */     MultipartConfigElement multipartConfig = getMultipartConfig(beanFactory);
/* 156 */     addAsRegistrationBean(beanFactory, Servlet.class, new ServletRegistrationBeanAdapter(multipartConfig));
/*     */     
/* 158 */     addAsRegistrationBean(beanFactory, Filter.class, new FilterRegistrationBeanAdapter(null));
/*     */     
/* 160 */     for (Class<?> listenerType : ServletListenerRegistrationBean.getSupportedTypes()) {
/* 162 */       addAsRegistrationBean(beanFactory, EventListener.class, listenerType, new ServletListenerRegistrationBeanAdapter(null));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private MultipartConfigElement getMultipartConfig(ListableBeanFactory beanFactory)
/*     */   {
/* 169 */     List<Map.Entry<String, MultipartConfigElement>> beans = getOrderedBeansOfType(beanFactory, MultipartConfigElement.class);
/*     */     
/* 171 */     return beans.isEmpty() ? null : (MultipartConfigElement)((Map.Entry)beans.get(0)).getValue();
/*     */   }
/*     */   
/*     */   private <T> void addAsRegistrationBean(ListableBeanFactory beanFactory, Class<T> type, RegistrationBeanAdapter<T> adapter)
/*     */   {
/* 176 */     addAsRegistrationBean(beanFactory, type, type, adapter);
/*     */   }
/*     */   
/*     */   private <T, B extends T> void addAsRegistrationBean(ListableBeanFactory beanFactory, Class<T> type, Class<B> beanType, RegistrationBeanAdapter<T> adapter)
/*     */   {
/* 181 */     List<Map.Entry<String, B>> beans = getOrderedBeansOfType(beanFactory, beanType, this.seen);
/*     */     
/* 183 */     for (Map.Entry<String, B> bean : beans) {
/* 184 */       if (this.seen.add(bean.getValue())) {
/* 185 */         int order = getOrder(bean.getValue());
/* 186 */         String beanName = (String)bean.getKey();
/*     */         
/* 188 */         RegistrationBean registration = adapter.createRegistrationBean(beanName, bean
/* 189 */           .getValue(), beans.size());
/* 190 */         registration.setName(beanName);
/* 191 */         registration.setOrder(order);
/* 192 */         this.initializers.add(type, registration);
/* 193 */         if (logger.isDebugEnabled()) {
/* 194 */           logger.debug("Created " + type
/* 195 */             .getSimpleName() + " initializer for bean '" + beanName + "'; order=" + order + ", resource=" + 
/*     */             
/* 197 */             getResourceDescription(beanName, beanFactory));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getOrder(Object value)
/*     */   {
/* 209 */     new AnnotationAwareOrderComparator()
/*     */     {
/* 207 */       public int getOrder(Object obj) { return super.getOrder(obj); } }
/*     */     
/* 209 */       .getOrder(value);
/*     */   }
/*     */   
/*     */   private <T> List<Map.Entry<String, T>> getOrderedBeansOfType(ListableBeanFactory beanFactory, Class<T> type)
/*     */   {
/* 214 */     return getOrderedBeansOfType(beanFactory, type, Collections.emptySet());
/*     */   }
/*     */   
/*     */   private <T> List<Map.Entry<String, T>> getOrderedBeansOfType(ListableBeanFactory beanFactory, Class<T> type, Set<?> excludes)
/*     */   {
/* 219 */     List<Map.Entry<String, T>> beans = new ArrayList();
/* 220 */     Comparator<Map.Entry<String, T>> comparator = new Comparator()
/*     */     {
/*     */       public int compare(Map.Entry<String, T> o1, Map.Entry<String, T> o2)
/*     */       {
/* 224 */         return AnnotationAwareOrderComparator.INSTANCE.compare(o1.getValue(), o2
/* 225 */           .getValue());
/*     */       }
/*     */       
/* 228 */     };
/* 229 */     String[] names = beanFactory.getBeanNamesForType(type, true, false);
/* 230 */     Map<String, T> map = new LinkedHashMap();
/* 231 */     for (String name : names) {
/* 232 */       if (!excludes.contains(name)) {
/* 233 */         T bean = beanFactory.getBean(name, type);
/* 234 */         if (!excludes.contains(bean)) {
/* 235 */           map.put(name, bean);
/*     */         }
/*     */       }
/*     */     }
/* 239 */     beans.addAll(map.entrySet());
/* 240 */     Collections.sort(beans, comparator);
/* 241 */     return beans;
/*     */   }
/*     */   
/*     */   public Iterator<ServletContextInitializer> iterator()
/*     */   {
/* 246 */     return this.sortedList.iterator();
/*     */   }
/*     */   
/*     */   public int size()
/*     */   {
/* 251 */     return this.sortedList.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static abstract interface RegistrationBeanAdapter<T>
/*     */   {
/*     */     public abstract RegistrationBean createRegistrationBean(String paramString, T paramT, int paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class ServletRegistrationBeanAdapter
/*     */     implements ServletContextInitializerBeans.RegistrationBeanAdapter<Servlet>
/*     */   {
/*     */     private final MultipartConfigElement multipartConfig;
/*     */     
/*     */ 
/*     */ 
/*     */     ServletRegistrationBeanAdapter(MultipartConfigElement multipartConfig)
/*     */     {
/* 274 */       this.multipartConfig = multipartConfig;
/*     */     }
/*     */     
/*     */ 
/*     */     public RegistrationBean createRegistrationBean(String name, Servlet source, int totalNumberOfSourceBeans)
/*     */     {
/* 280 */       String url = "/" + name + "/";
/* 281 */       if (name.equals("dispatcherServlet")) {
/* 282 */         url = "/";
/*     */       }
/* 284 */       ServletRegistrationBean bean = new ServletRegistrationBean(source, new String[] { url });
/* 285 */       bean.setMultipartConfig(this.multipartConfig);
/* 286 */       return bean;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class FilterRegistrationBeanAdapter
/*     */     implements ServletContextInitializerBeans.RegistrationBeanAdapter<Filter>
/*     */   {
/*     */     public RegistrationBean createRegistrationBean(String name, Filter source, int totalNumberOfSourceBeans)
/*     */     {
/* 300 */       return new FilterRegistrationBean(source, new ServletRegistrationBean[0]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class ServletListenerRegistrationBeanAdapter
/*     */     implements ServletContextInitializerBeans.RegistrationBeanAdapter<EventListener>
/*     */   {
/*     */     public RegistrationBean createRegistrationBean(String name, EventListener source, int totalNumberOfSourceBeans)
/*     */     {
/* 314 */       return new ServletListenerRegistrationBean(source);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\web\servlet\ServletContextInitializerBeans.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */