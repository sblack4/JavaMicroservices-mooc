/*    */ package org.springframework.boot.web.servlet;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.EnumSet;
/*    */ import java.util.Map;
/*    */ import javax.servlet.DispatcherType;
/*    */ import javax.servlet.annotation.WebFilter;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WebFilterHandler
/*    */   extends ServletComponentHandler
/*    */ {
/*    */   WebFilterHandler()
/*    */   {
/* 39 */     super(WebFilter.class);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void doHandle(Map<String, Object> attributes, BeanDefinition beanDefinition, BeanDefinitionRegistry registry)
/*    */   {
/* 46 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(FilterRegistrationBean.class);
/* 47 */     builder.addPropertyValue("asyncSupported", attributes.get("asyncSupported"));
/* 48 */     builder.addPropertyValue("dispatcherTypes", extractDispatcherTypes(attributes));
/* 49 */     builder.addPropertyValue("filter", beanDefinition);
/* 50 */     builder.addPropertyValue("initParameters", extractInitParameters(attributes));
/* 51 */     String name = determineName(attributes, beanDefinition);
/* 52 */     builder.addPropertyValue("name", name);
/* 53 */     builder.addPropertyValue("servletNames", attributes.get("servletNames"));
/* 54 */     builder.addPropertyValue("urlPatterns", 
/* 55 */       extractUrlPatterns("urlPatterns", attributes));
/* 56 */     registry.registerBeanDefinition(name, builder.getBeanDefinition());
/*    */   }
/*    */   
/*    */ 
/*    */   private EnumSet<DispatcherType> extractDispatcherTypes(Map<String, Object> attributes)
/*    */   {
/* 62 */     DispatcherType[] dispatcherTypes = (DispatcherType[])attributes.get("dispatcherTypes");
/* 63 */     if (dispatcherTypes.length == 0) {
/* 64 */       return EnumSet.noneOf(DispatcherType.class);
/*    */     }
/* 66 */     if (dispatcherTypes.length == 1) {
/* 67 */       return EnumSet.of(dispatcherTypes[0]);
/*    */     }
/* 69 */     return EnumSet.of(dispatcherTypes[0], 
/* 70 */       (Enum[])Arrays.copyOfRange(dispatcherTypes, 1, dispatcherTypes.length));
/*    */   }
/*    */   
/*    */ 
/*    */   private String determineName(Map<String, Object> attributes, BeanDefinition beanDefinition)
/*    */   {
/* 76 */     return (String)(StringUtils.hasText((String)attributes.get("filterName")) ? attributes.get("filterName") : beanDefinition.getBeanClassName());
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\web\servlet\WebFilterHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */