/*    */ package org.springframework.boot.web.servlet;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.context.annotation.ScannedGenericBeanDefinition;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*    */ import org.springframework.core.type.filter.TypeFilter;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class ServletComponentHandler
/*    */ {
/*    */   private final Class<? extends Annotation> annotationType;
/*    */   private final TypeFilter typeFilter;
/*    */   
/*    */   protected ServletComponentHandler(Class<? extends Annotation> annotationType)
/*    */   {
/* 44 */     this.typeFilter = new AnnotationTypeFilter(annotationType);
/* 45 */     this.annotationType = annotationType;
/*    */   }
/*    */   
/*    */   TypeFilter getTypeFilter() {
/* 49 */     return this.typeFilter;
/*    */   }
/*    */   
/*    */   protected String[] extractUrlPatterns(String attribute, Map<String, Object> attributes)
/*    */   {
/* 54 */     String[] value = (String[])attributes.get("value");
/* 55 */     String[] urlPatterns = (String[])attributes.get("urlPatterns");
/* 56 */     if (urlPatterns.length > 0) {
/* 57 */       Assert.state(value.length == 0, "The urlPatterns and value attributes are mutually exclusive.");
/*    */       
/* 59 */       return urlPatterns;
/*    */     }
/* 61 */     return value;
/*    */   }
/*    */   
/*    */   protected final Map<String, String> extractInitParameters(Map<String, Object> attributes)
/*    */   {
/* 66 */     Map<String, String> initParameters = new HashMap();
/* 67 */     for (AnnotationAttributes initParam : (AnnotationAttributes[])attributes.get("initParams")) {
/* 69 */       String name = (String)initParam.get("name");
/* 70 */       String value = (String)initParam.get("value");
/* 71 */       initParameters.put(name, value);
/*    */     }
/* 73 */     return initParameters;
/*    */   }
/*    */   
/*    */ 
/*    */   void handle(ScannedGenericBeanDefinition beanDefinition, BeanDefinitionRegistry registry)
/*    */   {
/* 79 */     Map<String, Object> attributes = beanDefinition.getMetadata().getAnnotationAttributes(this.annotationType.getName());
/* 80 */     if (attributes != null) {
/* 81 */       doHandle(attributes, beanDefinition, registry);
/*    */     }
/*    */   }
/*    */   
/*    */   protected abstract void doHandle(Map<String, Object> paramMap, BeanDefinition paramBeanDefinition, BeanDefinitionRegistry paramBeanDefinitionRegistry);
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\web\servlet\ServletComponentHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */