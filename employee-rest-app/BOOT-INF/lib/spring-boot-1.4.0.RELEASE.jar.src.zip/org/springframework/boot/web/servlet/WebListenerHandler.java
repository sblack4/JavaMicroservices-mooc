/*    */ package org.springframework.boot.web.servlet;
/*    */ 
/*    */ import java.util.Map;
/*    */ import javax.servlet.annotation.WebListener;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WebListenerHandler
/*    */   extends ServletComponentHandler
/*    */ {
/*    */   WebListenerHandler()
/*    */   {
/* 35 */     super(WebListener.class);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected void doHandle(Map<String, Object> attributes, BeanDefinition beanDefinition, BeanDefinitionRegistry registry)
/*    */   {
/* 42 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(ServletListenerRegistrationBean.class);
/* 43 */     builder.addPropertyValue("listener", beanDefinition);
/* 44 */     registry.registerBeanDefinition(beanDefinition.getBeanClassName(), builder
/* 45 */       .getBeanDefinition());
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\web\servlet\WebListenerHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */