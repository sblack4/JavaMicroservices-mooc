/*     */ package org.springframework.boot.web.support;
/*     */ 
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletContextEvent;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.boot.builder.ParentContextApplicationContextInitializer;
/*     */ import org.springframework.boot.builder.SpringApplicationBuilder;
/*     */ import org.springframework.boot.context.embedded.AnnotationConfigEmbeddedWebApplicationContext;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextInitializer;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.WebApplicationInitializer;
/*     */ import org.springframework.web.context.ContextLoaderListener;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SpringBootServletInitializer
/*     */   implements WebApplicationInitializer
/*     */ {
/*     */   protected Log logger;
/*  69 */   private boolean registerErrorPageFilter = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void setRegisterErrorPageFilter(boolean registerErrorPageFilter)
/*     */   {
/*  78 */     this.registerErrorPageFilter = registerErrorPageFilter;
/*     */   }
/*     */   
/*     */ 
/*     */   public void onStartup(ServletContext servletContext)
/*     */     throws ServletException
/*     */   {
/*  85 */     this.logger = LogFactory.getLog(getClass());
/*  86 */     WebApplicationContext rootAppContext = createRootApplicationContext(servletContext);
/*     */     
/*  88 */     if (rootAppContext != null) {
/*  89 */       servletContext.addListener(new ContextLoaderListener(rootAppContext)
/*     */       {
/*     */ 
/*     */         public void contextInitialized(ServletContextEvent event) {}
/*     */ 
/*     */       });
/*     */     }
/*     */     else {
/*  97 */       this.logger.debug("No ContextLoaderListener registered, as createRootApplicationContext() did not return an application context");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected WebApplicationContext createRootApplicationContext(ServletContext servletContext)
/*     */   {
/* 105 */     SpringApplicationBuilder builder = createSpringApplicationBuilder();
/* 106 */     builder.main(getClass());
/* 107 */     ApplicationContext parent = getExistingRootWebApplicationContext(servletContext);
/* 108 */     if (parent != null) {
/* 109 */       this.logger.info("Root context already created (using as parent).");
/* 110 */       servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE, null);
/*     */       
/* 112 */       builder.initializers(new ApplicationContextInitializer[] { new ParentContextApplicationContextInitializer(parent) });
/*     */     }
/* 114 */     builder.initializers(new ApplicationContextInitializer[] { new ServletContextApplicationContextInitializer(servletContext) });
/*     */     
/* 116 */     builder.contextClass(AnnotationConfigEmbeddedWebApplicationContext.class);
/* 117 */     builder = configure(builder);
/* 118 */     SpringApplication application = builder.build();
/* 119 */     if ((application.getSources().isEmpty()) && 
/* 120 */       (AnnotationUtils.findAnnotation(getClass(), Configuration.class) != null)) {
/* 121 */       application.getSources().add(getClass());
/*     */     }
/* 123 */     Assert.state(!application.getSources().isEmpty(), "No SpringApplication sources have been defined. Either override the configure method or add an @Configuration annotation");
/*     */     
/*     */ 
/*     */ 
/* 127 */     if (this.registerErrorPageFilter) {
/* 128 */       application.getSources().add(ErrorPageFilter.class);
/*     */     }
/* 130 */     return run(application);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SpringApplicationBuilder createSpringApplicationBuilder()
/*     */   {
/* 141 */     return new SpringApplicationBuilder(new Object[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected WebApplicationContext run(SpringApplication application)
/*     */   {
/* 150 */     return (WebApplicationContext)application.run(new String[0]);
/*     */   }
/*     */   
/*     */   private ApplicationContext getExistingRootWebApplicationContext(ServletContext servletContext)
/*     */   {
/* 155 */     Object context = servletContext.getAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/*     */     
/* 157 */     if ((context instanceof ApplicationContext)) {
/* 158 */       return (ApplicationContext)context;
/*     */     }
/* 160 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SpringApplicationBuilder configure(SpringApplicationBuilder builder)
/*     */   {
/* 173 */     return builder;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\web\support\SpringBootServletInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */