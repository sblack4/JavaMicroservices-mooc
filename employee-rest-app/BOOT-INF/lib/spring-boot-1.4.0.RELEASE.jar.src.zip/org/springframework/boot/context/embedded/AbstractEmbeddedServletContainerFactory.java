/*     */ package org.springframework.boot.context.embedded;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.JarURLConnection;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.security.CodeSource;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.Arrays;
/*     */ import java.util.jar.JarFile;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.boot.ApplicationHome;
/*     */ import org.springframework.boot.ApplicationTemp;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractEmbeddedServletContainerFactory
/*     */   extends AbstractConfigurableEmbeddedServletContainer
/*     */   implements EmbeddedServletContainerFactory
/*     */ {
/*  44 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  46 */   private static final String[] COMMON_DOC_ROOTS = { "src/main/webapp", "public", "static" };
/*     */   
/*     */ 
/*     */   public AbstractEmbeddedServletContainerFactory() {}
/*     */   
/*     */ 
/*     */   public AbstractEmbeddedServletContainerFactory(int port)
/*     */   {
/*  54 */     super(port);
/*     */   }
/*     */   
/*     */   public AbstractEmbeddedServletContainerFactory(String contextPath, int port) {
/*  58 */     super(contextPath, port);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final File getValidDocumentRoot()
/*     */   {
/*  67 */     File file = getDocumentRoot();
/*     */     
/*  69 */     file = file != null ? file : getWarFileDocumentRoot();
/*     */     
/*  71 */     file = file != null ? file : getExplodedWarFileDocumentRoot();
/*     */     
/*  73 */     file = file != null ? file : getCommonDocumentRoot();
/*  74 */     if ((file == null) && (this.logger.isDebugEnabled()))
/*     */     {
/*  76 */       this.logger.debug("None of the document roots " + Arrays.asList(COMMON_DOC_ROOTS) + " point to a directory and will be ignored.");
/*     */ 
/*     */     }
/*  79 */     else if (this.logger.isDebugEnabled()) {
/*  80 */       this.logger.debug("Document root: " + file);
/*     */     }
/*  82 */     return file;
/*     */   }
/*     */   
/*     */   private File getExplodedWarFileDocumentRoot() {
/*  86 */     File file = getCodeSourceArchive();
/*  87 */     if (this.logger.isDebugEnabled()) {
/*  88 */       this.logger.debug("Code archive: " + file);
/*     */     }
/*  90 */     if ((file != null) && (file.exists()) && 
/*  91 */       (file.getAbsolutePath().contains("/WEB-INF/"))) {
/*  92 */       String path = file.getAbsolutePath();
/*  93 */       path = path.substring(0, path.indexOf("/WEB-INF/"));
/*  94 */       return new File(path);
/*     */     }
/*  96 */     return null;
/*     */   }
/*     */   
/*     */   private File getWarFileDocumentRoot() {
/* 100 */     return getArchiveFileDocumentRoot(".war");
/*     */   }
/*     */   
/*     */   private File getArchiveFileDocumentRoot(String extension) {
/* 104 */     File file = getCodeSourceArchive();
/* 105 */     if (this.logger.isDebugEnabled()) {
/* 106 */       this.logger.debug("Code archive: " + file);
/*     */     }
/* 108 */     if ((file != null) && (file.exists()) && (!file.isDirectory()) && 
/* 109 */       (file.getName().toLowerCase().endsWith(extension))) {
/* 110 */       return file.getAbsoluteFile();
/*     */     }
/* 112 */     return null;
/*     */   }
/*     */   
/*     */   private File getCommonDocumentRoot() {
/* 116 */     for (String commonDocRoot : COMMON_DOC_ROOTS) {
/* 117 */       File root = new File(commonDocRoot);
/* 118 */       if ((root != null) && (root.exists()) && (root.isDirectory())) {
/* 119 */         return root.getAbsoluteFile();
/*     */       }
/*     */     }
/* 122 */     return null;
/*     */   }
/*     */   
/*     */   private File getCodeSourceArchive() {
/*     */     try {
/* 127 */       CodeSource codeSource = getClass().getProtectionDomain().getCodeSource();
/* 128 */       URL location = codeSource == null ? null : codeSource.getLocation();
/* 129 */       if (location == null) {
/* 130 */         return null;
/*     */       }
/* 132 */       String path = location.getPath();
/* 133 */       URLConnection connection = location.openConnection();
/* 134 */       if ((connection instanceof JarURLConnection)) {
/* 135 */         path = ((JarURLConnection)connection).getJarFile().getName();
/*     */       }
/* 137 */       if (path.indexOf("!/") != -1) {
/* 138 */         path = path.substring(0, path.indexOf("!/"));
/*     */       }
/* 140 */       return new File(path);
/*     */     }
/*     */     catch (IOException ex) {}
/* 143 */     return null;
/*     */   }
/*     */   
/*     */   protected final File getValidSessionStoreDir()
/*     */   {
/* 148 */     return getValidSessionStoreDir(true);
/*     */   }
/*     */   
/*     */   protected final File getValidSessionStoreDir(boolean mkdirs) {
/* 152 */     File dir = getSessionStoreDir();
/* 153 */     if (dir == null) {
/* 154 */       return new ApplicationTemp().getDir("servlet-sessions");
/*     */     }
/* 156 */     if (!dir.isAbsolute()) {
/* 157 */       dir = new File(new ApplicationHome().getDir(), dir.getPath());
/*     */     }
/* 159 */     if ((!dir.exists()) && (mkdirs)) {
/* 160 */       dir.mkdirs();
/*     */     }
/* 162 */     Assert.state((!mkdirs) || (dir.exists()), "Session dir " + dir + " does not exist");
/* 163 */     Assert.state(!dir.isFile(), "Session dir " + dir + " points to a file");
/* 164 */     return dir;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected File createTempDir(String prefix)
/*     */   {
/*     */     try
/*     */     {
/* 174 */       File tempDir = File.createTempFile(prefix + ".", "." + getPort());
/* 175 */       tempDir.delete();
/* 176 */       tempDir.mkdir();
/* 177 */       tempDir.deleteOnExit();
/* 178 */       return tempDir;
/*     */ 
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 183 */       throw new EmbeddedServletContainerException("Unable to create tempDir. java.io.tmpdir is set to " + System.getProperty("java.io.tmpdir"), ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\embedded\AbstractEmbeddedServletContainerFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */