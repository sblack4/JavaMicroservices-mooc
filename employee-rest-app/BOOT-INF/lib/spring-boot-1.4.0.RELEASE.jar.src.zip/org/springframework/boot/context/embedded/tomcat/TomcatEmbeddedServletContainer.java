/*     */ package org.springframework.boot.context.embedded.tomcat;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import javax.naming.NamingException;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Server;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.startup.Tomcat;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.coyote.ProtocolHandler;
/*     */ import org.apache.naming.ContextBindings;
/*     */ import org.springframework.boot.context.embedded.EmbeddedServletContainer;
/*     */ import org.springframework.boot.context.embedded.EmbeddedServletContainerException;
/*     */ import org.springframework.boot.context.embedded.PortInUseException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TomcatEmbeddedServletContainer
/*     */   implements EmbeddedServletContainer
/*     */ {
/*  54 */   private static final Log logger = LogFactory.getLog(TomcatEmbeddedServletContainer.class);
/*     */   
/*  56 */   private static final AtomicInteger containerCounter = new AtomicInteger(-1);
/*     */   
/*  58 */   private final Object monitor = new Object();
/*     */   
/*  60 */   private final Map<Service, Connector[]> serviceConnectors = new HashMap();
/*     */   
/*     */ 
/*     */   private final Tomcat tomcat;
/*     */   
/*     */ 
/*     */   private final boolean autoStart;
/*     */   
/*     */ 
/*     */   public TomcatEmbeddedServletContainer(Tomcat tomcat)
/*     */   {
/*  71 */     this(tomcat, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TomcatEmbeddedServletContainer(Tomcat tomcat, boolean autoStart)
/*     */   {
/*  80 */     Assert.notNull(tomcat, "Tomcat Server must not be null");
/*  81 */     this.tomcat = tomcat;
/*  82 */     this.autoStart = autoStart;
/*  83 */     initialize();
/*     */   }
/*     */   
/*     */   private void initialize() throws EmbeddedServletContainerException
/*     */   {
/*  88 */     logger.info("Tomcat initialized with port(s): " + getPortsDescription(false));
/*  89 */     synchronized (this.monitor) {
/*     */       try {
/*  91 */         addInstanceIdToEngineName();
/*     */         
/*     */ 
/*  94 */         removeServiceConnectors();
/*     */         
/*     */ 
/*  97 */         this.tomcat.start();
/*     */         
/*     */ 
/* 100 */         rethrowDeferredStartupExceptions();
/*     */         
/* 102 */         Context context = findContext();
/*     */         try {
/* 104 */           ContextBindings.bindClassLoader(context, getNamingToken(context), 
/* 105 */             getClass().getClassLoader());
/*     */         }
/*     */         catch (NamingException localNamingException) {}
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 113 */         startDaemonAwaitThread();
/*     */       }
/*     */       catch (Exception ex) {
/* 116 */         throw new EmbeddedServletContainerException("Unable to start embedded Tomcat", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private Context findContext()
/*     */   {
/* 123 */     for (Container child : this.tomcat.getHost().findChildren()) {
/* 124 */       if ((child instanceof Context)) {
/* 125 */         return (Context)child;
/*     */       }
/*     */     }
/* 128 */     throw new IllegalStateException("The host does not contain a Context");
/*     */   }
/*     */   
/*     */   private void addInstanceIdToEngineName() {
/* 132 */     int instanceId = containerCounter.incrementAndGet();
/* 133 */     if (instanceId > 0) {
/* 134 */       Engine engine = this.tomcat.getEngine();
/* 135 */       engine.setName(engine.getName() + "-" + instanceId);
/*     */     }
/*     */   }
/*     */   
/*     */   private void removeServiceConnectors() {
/* 140 */     for (Service service : this.tomcat.getServer().findServices()) {
/* 141 */       Connector[] connectors = (Connector[])service.findConnectors().clone();
/* 142 */       this.serviceConnectors.put(service, connectors);
/* 143 */       for (Connector connector : connectors) {
/* 144 */         service.removeConnector(connector);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void rethrowDeferredStartupExceptions() throws Exception {
/* 150 */     Container[] children = this.tomcat.getHost().findChildren();
/* 151 */     for (Container container : children) {
/* 152 */       if ((container instanceof TomcatEmbeddedContext))
/*     */       {
/* 154 */         Exception exception = ((TomcatEmbeddedContext)container).getStarter().getStartUpException();
/* 155 */         if (exception != null) {
/* 156 */           throw exception;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void startDaemonAwaitThread() {
/* 163 */     Thread awaitThread = new Thread("container-" + containerCounter.get())
/*     */     {
/*     */       public void run()
/*     */       {
/* 167 */         TomcatEmbeddedServletContainer.this.tomcat.getServer().await();
/*     */       }
/*     */       
/* 170 */     };
/* 171 */     awaitThread.setContextClassLoader(getClass().getClassLoader());
/* 172 */     awaitThread.setDaemon(false);
/* 173 */     awaitThread.start();
/*     */   }
/*     */   
/*     */   public void start() throws EmbeddedServletContainerException
/*     */   {
/*     */     try {
/* 179 */       addPreviouslyRemovedConnectors();
/* 180 */       Connector connector = this.tomcat.getConnector();
/* 181 */       if ((connector != null) && (this.autoStart)) {
/* 182 */         startConnector(connector);
/*     */       }
/* 184 */       checkThatConnectorsHaveStarted();
/* 185 */       logger
/* 186 */         .info("Tomcat started on port(s): " + getPortsDescription(true));
/*     */     } catch (PortInUseException ex) {
/*     */       Context context;
/* 189 */       stopSilently();
/* 190 */       throw ex;
/*     */     }
/*     */     catch (Exception ex) {
/* 193 */       throw new EmbeddedServletContainerException("Unable to start embedded Tomcat servlet container", ex);
/*     */     }
/*     */     finally
/*     */     {
/* 197 */       Context context = findContext();
/* 198 */       ContextBindings.unbindClassLoader(context, getNamingToken(context), 
/* 199 */         getClass().getClassLoader());
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkThatConnectorsHaveStarted() {
/* 204 */     for (Connector connector : this.tomcat.getService().findConnectors()) {
/* 205 */       if (LifecycleState.FAILED.equals(connector.getState())) {
/* 206 */         throw new PortInUseException(connector.getPort());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void stopSilently() {
/*     */     try {
/* 213 */       stopTomcat();
/*     */     }
/*     */     catch (LifecycleException localLifecycleException) {}
/*     */   }
/*     */   
/*     */ 
/*     */   private void stopTomcat()
/*     */     throws LifecycleException
/*     */   {
/* 222 */     if ((Thread.currentThread().getContextClassLoader() instanceof TomcatEmbeddedWebappClassLoader)) {
/* 223 */       Thread.currentThread().setContextClassLoader(getClass().getClassLoader());
/*     */     }
/* 225 */     this.tomcat.stop();
/*     */   }
/*     */   
/*     */   private void addPreviouslyRemovedConnectors() {
/* 229 */     Service[] services = this.tomcat.getServer().findServices();
/* 230 */     for (Service service : services) {
/* 231 */       Connector[] connectors = (Connector[])this.serviceConnectors.get(service);
/* 232 */       if (connectors != null) {
/* 233 */         for (Connector connector : connectors) {
/* 234 */           service.addConnector(connector);
/* 235 */           if (!this.autoStart) {
/* 236 */             stopProtocolHandler(connector);
/*     */           }
/*     */         }
/* 239 */         this.serviceConnectors.remove(service);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void stopProtocolHandler(Connector connector) {
/*     */     try {
/* 246 */       connector.getProtocolHandler().stop();
/*     */     }
/*     */     catch (Exception ex) {
/* 249 */       logger.error("Cannot pause connector: ", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private void startConnector(Connector connector) {
/*     */     try {
/* 255 */       for (Container child : this.tomcat.getHost().findChildren()) {
/* 256 */         if ((child instanceof TomcatEmbeddedContext)) {
/* 257 */           ((TomcatEmbeddedContext)child).deferredLoadOnStartup();
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 262 */       logger.error("Cannot start connector: ", ex);
/* 263 */       throw new EmbeddedServletContainerException("Unable to start embedded Tomcat connectors", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   Map<Service, Connector[]> getServiceConnectors()
/*     */   {
/* 269 */     return this.serviceConnectors;
/*     */   }
/*     */   
/*     */   public void stop() throws EmbeddedServletContainerException
/*     */   {
/* 274 */     synchronized (this.monitor) {
/*     */       try {
/*     */         try {
/* 277 */           stopTomcat();
/* 278 */           this.tomcat.destroy();
/*     */ 
/*     */         }
/*     */         catch (LifecycleException localLifecycleException) {}
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 285 */         throw new EmbeddedServletContainerException("Unable to stop embedded Tomcat", ex);
/*     */       }
/*     */       finally
/*     */       {
/* 289 */         containerCounter.decrementAndGet();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private String getPortsDescription(boolean localPort) {
/* 295 */     StringBuilder ports = new StringBuilder();
/* 296 */     for (Connector connector : this.tomcat.getService().findConnectors()) {
/* 297 */       ports.append(ports.length() == 0 ? "" : " ");
/* 298 */       int port = localPort ? connector.getLocalPort() : connector.getPort();
/* 299 */       ports.append(port + " (" + connector.getScheme() + ")");
/*     */     }
/* 301 */     return ports.toString();
/*     */   }
/*     */   
/*     */   public int getPort()
/*     */   {
/* 306 */     Connector connector = this.tomcat.getConnector();
/* 307 */     if (connector != null) {
/* 308 */       return connector.getLocalPort();
/*     */     }
/* 310 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Tomcat getTomcat()
/*     */   {
/* 318 */     return this.tomcat;
/*     */   }
/*     */   
/*     */   private Object getNamingToken(Context context) {
/*     */     try {
/* 323 */       return context.getNamingToken();
/*     */     }
/*     */     catch (NoSuchMethodError ex) {}
/*     */     
/* 327 */     return context;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\embedded\tomcat\TomcatEmbeddedServletContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */