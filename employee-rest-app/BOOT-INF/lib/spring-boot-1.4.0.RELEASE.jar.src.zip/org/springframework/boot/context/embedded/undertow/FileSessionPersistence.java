/*     */ package org.springframework.boot.context.embedded.undertow;
/*     */ 
/*     */ import io.undertow.servlet.UndertowServletLogger;
/*     */ import io.undertow.servlet.api.SessionPersistenceManager;
/*     */ import io.undertow.servlet.api.SessionPersistenceManager.PersistentSession;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileSessionPersistence
/*     */   implements SessionPersistenceManager
/*     */ {
/*     */   private final File dir;
/*     */   
/*     */   public FileSessionPersistence(File dir)
/*     */   {
/*  44 */     this.dir = dir;
/*     */   }
/*     */   
/*     */   public void persistSessions(String deploymentName, Map<String, SessionPersistenceManager.PersistentSession> sessionData)
/*     */   {
/*     */     try
/*     */     {
/*  51 */       save(sessionData, getSessionFile(deploymentName));
/*     */     }
/*     */     catch (Exception ex) {
/*  54 */       UndertowServletLogger.ROOT_LOGGER.failedToPersistSessions(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private void save(Map<String, SessionPersistenceManager.PersistentSession> sessionData, File file) throws IOException
/*     */   {
/*  60 */     ObjectOutputStream stream = new ObjectOutputStream(new FileOutputStream(file));
/*     */     try {
/*  62 */       save(sessionData, stream);
/*     */     }
/*     */     finally {
/*  65 */       stream.close();
/*     */     }
/*     */   }
/*     */   
/*     */   private void save(Map<String, SessionPersistenceManager.PersistentSession> sessionData, ObjectOutputStream stream) throws IOException
/*     */   {
/*  71 */     Map<String, Serializable> session = new LinkedHashMap();
/*  72 */     for (Map.Entry<String, SessionPersistenceManager.PersistentSession> entry : sessionData.entrySet()) {
/*  73 */       session.put(entry.getKey(), new SerializablePersistentSession(
/*  74 */         (SessionPersistenceManager.PersistentSession)entry.getValue()));
/*     */     }
/*  76 */     stream.writeObject(session);
/*     */   }
/*     */   
/*     */   public Map<String, SessionPersistenceManager.PersistentSession> loadSessionAttributes(String deploymentName, ClassLoader classLoader)
/*     */   {
/*     */     try
/*     */     {
/*  83 */       File file = getSessionFile(deploymentName);
/*  84 */       if (file.exists()) {
/*  85 */         return load(file);
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/*  89 */       UndertowServletLogger.ROOT_LOGGER.failedtoLoadPersistentSessions(ex);
/*     */     }
/*  91 */     return null;
/*     */   }
/*     */   
/*     */   private Map<String, SessionPersistenceManager.PersistentSession> load(File file) throws IOException, ClassNotFoundException
/*     */   {
/*  96 */     ObjectInputStream stream = new ObjectInputStream(new FileInputStream(file));
/*     */     try {
/*  98 */       return load(stream);
/*     */     }
/*     */     finally {
/* 101 */       stream.close();
/*     */     }
/*     */   }
/*     */   
/*     */   private Map<String, SessionPersistenceManager.PersistentSession> load(ObjectInputStream stream) throws ClassNotFoundException, IOException
/*     */   {
/* 107 */     Map<String, SerializablePersistentSession> session = readSession(stream);
/* 108 */     long time = System.currentTimeMillis();
/* 109 */     Map<String, SessionPersistenceManager.PersistentSession> result = new LinkedHashMap();
/* 110 */     for (Map.Entry<String, SerializablePersistentSession> entry : session
/* 111 */       .entrySet()) {
/* 112 */       SessionPersistenceManager.PersistentSession entrySession = ((SerializablePersistentSession)entry.getValue()).getPersistentSession();
/* 113 */       if (entrySession.getExpiration().getTime() > time) {
/* 114 */         result.put(entry.getKey(), entrySession);
/*     */       }
/*     */     }
/* 117 */     return result;
/*     */   }
/*     */   
/*     */   private Map<String, SerializablePersistentSession> readSession(ObjectInputStream stream)
/*     */     throws ClassNotFoundException, IOException
/*     */   {
/* 123 */     return (Map)stream.readObject();
/*     */   }
/*     */   
/*     */   private File getSessionFile(String deploymentName) {
/* 127 */     if (!this.dir.exists()) {
/* 128 */       this.dir.mkdirs();
/*     */     }
/* 130 */     return new File(this.dir, deploymentName + ".session");
/*     */   }
/*     */   
/*     */   public void clear(String deploymentName)
/*     */   {
/* 135 */     getSessionFile(deploymentName).delete();
/*     */   }
/*     */   
/*     */ 
/*     */   static class SerializablePersistentSession
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 0L;
/*     */     
/*     */     private final Date expiration;
/*     */     
/*     */     private final Map<String, Object> sessionData;
/*     */     
/*     */     SerializablePersistentSession(SessionPersistenceManager.PersistentSession session)
/*     */     {
/* 150 */       this.expiration = session.getExpiration();
/*     */       
/* 152 */       this.sessionData = new LinkedHashMap(session.getSessionData());
/*     */     }
/*     */     
/*     */     public SessionPersistenceManager.PersistentSession getPersistentSession() {
/* 156 */       return new SessionPersistenceManager.PersistentSession(this.expiration, this.sessionData);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\embedded\undertow\FileSessionPersistence.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */