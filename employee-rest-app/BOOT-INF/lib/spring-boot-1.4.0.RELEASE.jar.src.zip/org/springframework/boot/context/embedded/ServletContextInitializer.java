package org.springframework.boot.context.embedded;

@Deprecated
public abstract interface ServletContextInitializer
  extends org.springframework.boot.web.servlet.ServletContextInitializer
{}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\embedded\ServletContextInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */