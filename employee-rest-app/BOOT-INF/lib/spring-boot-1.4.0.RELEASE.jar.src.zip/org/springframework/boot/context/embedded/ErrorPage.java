/*    */ package org.springframework.boot.context.embedded;
/*    */ 
/*    */ import org.springframework.http.HttpStatus;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class ErrorPage
/*    */   extends org.springframework.boot.web.servlet.ErrorPage
/*    */ {
/*    */   public ErrorPage(Class<? extends Throwable> exception, String path)
/*    */   {
/* 32 */     super(exception, path);
/*    */   }
/*    */   
/*    */   public ErrorPage(HttpStatus status, String path) {
/* 36 */     super(status, path);
/*    */   }
/*    */   
/*    */   public ErrorPage(String path) {
/* 40 */     super(path);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\embedded\ErrorPage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */