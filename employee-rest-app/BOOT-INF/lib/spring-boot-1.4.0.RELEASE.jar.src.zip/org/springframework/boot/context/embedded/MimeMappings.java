/*     */ package org.springframework.boot.context.embedded;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MimeMappings
/*     */   implements Iterable<Mapping>
/*     */ {
/*     */   public static final MimeMappings DEFAULT;
/*     */   private final Map<String, Mapping> map;
/*     */   
/*     */   static
/*     */   {
/*  42 */     MimeMappings mappings = new MimeMappings();
/*  43 */     mappings.add("abs", "audio/x-mpeg");
/*  44 */     mappings.add("ai", "application/postscript");
/*  45 */     mappings.add("aif", "audio/x-aiff");
/*  46 */     mappings.add("aifc", "audio/x-aiff");
/*  47 */     mappings.add("aiff", "audio/x-aiff");
/*  48 */     mappings.add("aim", "application/x-aim");
/*  49 */     mappings.add("art", "image/x-jg");
/*  50 */     mappings.add("asf", "video/x-ms-asf");
/*  51 */     mappings.add("asx", "video/x-ms-asf");
/*  52 */     mappings.add("au", "audio/basic");
/*  53 */     mappings.add("avi", "video/x-msvideo");
/*  54 */     mappings.add("avx", "video/x-rad-screenplay");
/*  55 */     mappings.add("bcpio", "application/x-bcpio");
/*  56 */     mappings.add("bin", "application/octet-stream");
/*  57 */     mappings.add("bmp", "image/bmp");
/*  58 */     mappings.add("body", "text/html");
/*  59 */     mappings.add("cdf", "application/x-cdf");
/*  60 */     mappings.add("cer", "application/pkix-cert");
/*  61 */     mappings.add("class", "application/java");
/*  62 */     mappings.add("cpio", "application/x-cpio");
/*  63 */     mappings.add("csh", "application/x-csh");
/*  64 */     mappings.add("css", "text/css");
/*  65 */     mappings.add("dib", "image/bmp");
/*  66 */     mappings.add("doc", "application/msword");
/*  67 */     mappings.add("dtd", "application/xml-dtd");
/*  68 */     mappings.add("dv", "video/x-dv");
/*  69 */     mappings.add("dvi", "application/x-dvi");
/*  70 */     mappings.add("eps", "application/postscript");
/*  71 */     mappings.add("etx", "text/x-setext");
/*  72 */     mappings.add("exe", "application/octet-stream");
/*  73 */     mappings.add("gif", "image/gif");
/*  74 */     mappings.add("gtar", "application/x-gtar");
/*  75 */     mappings.add("gz", "application/x-gzip");
/*  76 */     mappings.add("hdf", "application/x-hdf");
/*  77 */     mappings.add("hqx", "application/mac-binhex40");
/*  78 */     mappings.add("htc", "text/x-component");
/*  79 */     mappings.add("htm", "text/html");
/*  80 */     mappings.add("html", "text/html");
/*  81 */     mappings.add("ief", "image/ief");
/*  82 */     mappings.add("jad", "text/vnd.sun.j2me.app-descriptor");
/*  83 */     mappings.add("jar", "application/java-archive");
/*  84 */     mappings.add("java", "text/x-java-source");
/*  85 */     mappings.add("jnlp", "application/x-java-jnlp-file");
/*  86 */     mappings.add("jpe", "image/jpeg");
/*  87 */     mappings.add("jpeg", "image/jpeg");
/*  88 */     mappings.add("jpg", "image/jpeg");
/*  89 */     mappings.add("js", "application/javascript");
/*  90 */     mappings.add("jsf", "text/plain");
/*  91 */     mappings.add("json", "application/json");
/*  92 */     mappings.add("jspf", "text/plain");
/*  93 */     mappings.add("kar", "audio/midi");
/*  94 */     mappings.add("latex", "application/x-latex");
/*  95 */     mappings.add("m3u", "audio/x-mpegurl");
/*  96 */     mappings.add("mac", "image/x-macpaint");
/*  97 */     mappings.add("man", "text/troff");
/*  98 */     mappings.add("mathml", "application/mathml+xml");
/*  99 */     mappings.add("me", "text/troff");
/* 100 */     mappings.add("mid", "audio/midi");
/* 101 */     mappings.add("midi", "audio/midi");
/* 102 */     mappings.add("mif", "application/x-mif");
/* 103 */     mappings.add("mov", "video/quicktime");
/* 104 */     mappings.add("movie", "video/x-sgi-movie");
/* 105 */     mappings.add("mp1", "audio/mpeg");
/* 106 */     mappings.add("mp2", "audio/mpeg");
/* 107 */     mappings.add("mp3", "audio/mpeg");
/* 108 */     mappings.add("mp4", "video/mp4");
/* 109 */     mappings.add("mpa", "audio/mpeg");
/* 110 */     mappings.add("mpe", "video/mpeg");
/* 111 */     mappings.add("mpeg", "video/mpeg");
/* 112 */     mappings.add("mpega", "audio/x-mpeg");
/* 113 */     mappings.add("mpg", "video/mpeg");
/* 114 */     mappings.add("mpv2", "video/mpeg2");
/* 115 */     mappings.add("ms", "application/x-wais-source");
/* 116 */     mappings.add("nc", "application/x-netcdf");
/* 117 */     mappings.add("oda", "application/oda");
/* 118 */     mappings.add("odb", "application/vnd.oasis.opendocument.database");
/* 119 */     mappings.add("odc", "application/vnd.oasis.opendocument.chart");
/* 120 */     mappings.add("odf", "application/vnd.oasis.opendocument.formula");
/* 121 */     mappings.add("odg", "application/vnd.oasis.opendocument.graphics");
/* 122 */     mappings.add("odi", "application/vnd.oasis.opendocument.image");
/* 123 */     mappings.add("odm", "application/vnd.oasis.opendocument.text-master");
/* 124 */     mappings.add("odp", "application/vnd.oasis.opendocument.presentation");
/* 125 */     mappings.add("ods", "application/vnd.oasis.opendocument.spreadsheet");
/* 126 */     mappings.add("odt", "application/vnd.oasis.opendocument.text");
/* 127 */     mappings.add("otg", "application/vnd.oasis.opendocument.graphics-template");
/* 128 */     mappings.add("oth", "application/vnd.oasis.opendocument.text-web");
/* 129 */     mappings.add("otp", "application/vnd.oasis.opendocument.presentation-template");
/* 130 */     mappings.add("ots", "application/vnd.oasis.opendocument.spreadsheet-template ");
/* 131 */     mappings.add("ott", "application/vnd.oasis.opendocument.text-template");
/* 132 */     mappings.add("ogx", "application/ogg");
/* 133 */     mappings.add("ogv", "video/ogg");
/* 134 */     mappings.add("oga", "audio/ogg");
/* 135 */     mappings.add("ogg", "audio/ogg");
/* 136 */     mappings.add("spx", "audio/ogg");
/* 137 */     mappings.add("flac", "audio/flac");
/* 138 */     mappings.add("anx", "application/annodex");
/* 139 */     mappings.add("axa", "audio/annodex");
/* 140 */     mappings.add("axv", "video/annodex");
/* 141 */     mappings.add("xspf", "application/xspf+xml");
/* 142 */     mappings.add("pbm", "image/x-portable-bitmap");
/* 143 */     mappings.add("pct", "image/pict");
/* 144 */     mappings.add("pdf", "application/pdf");
/* 145 */     mappings.add("pgm", "image/x-portable-graymap");
/* 146 */     mappings.add("pic", "image/pict");
/* 147 */     mappings.add("pict", "image/pict");
/* 148 */     mappings.add("pls", "audio/x-scpls");
/* 149 */     mappings.add("png", "image/png");
/* 150 */     mappings.add("pnm", "image/x-portable-anymap");
/* 151 */     mappings.add("pnt", "image/x-macpaint");
/* 152 */     mappings.add("ppm", "image/x-portable-pixmap");
/* 153 */     mappings.add("ppt", "application/vnd.ms-powerpoint");
/* 154 */     mappings.add("pps", "application/vnd.ms-powerpoint");
/* 155 */     mappings.add("ps", "application/postscript");
/* 156 */     mappings.add("psd", "image/vnd.adobe.photoshop");
/* 157 */     mappings.add("qt", "video/quicktime");
/* 158 */     mappings.add("qti", "image/x-quicktime");
/* 159 */     mappings.add("qtif", "image/x-quicktime");
/* 160 */     mappings.add("ras", "image/x-cmu-raster");
/* 161 */     mappings.add("rdf", "application/rdf+xml");
/* 162 */     mappings.add("rgb", "image/x-rgb");
/* 163 */     mappings.add("rm", "application/vnd.rn-realmedia");
/* 164 */     mappings.add("roff", "text/troff");
/* 165 */     mappings.add("rtf", "application/rtf");
/* 166 */     mappings.add("rtx", "text/richtext");
/* 167 */     mappings.add("sh", "application/x-sh");
/* 168 */     mappings.add("shar", "application/x-shar");
/* 169 */     mappings.add("sit", "application/x-stuffit");
/* 170 */     mappings.add("snd", "audio/basic");
/* 171 */     mappings.add("src", "application/x-wais-source");
/* 172 */     mappings.add("sv4cpio", "application/x-sv4cpio");
/* 173 */     mappings.add("sv4crc", "application/x-sv4crc");
/* 174 */     mappings.add("svg", "image/svg+xml");
/* 175 */     mappings.add("svgz", "image/svg+xml");
/* 176 */     mappings.add("swf", "application/x-shockwave-flash");
/* 177 */     mappings.add("t", "text/troff");
/* 178 */     mappings.add("tar", "application/x-tar");
/* 179 */     mappings.add("tcl", "application/x-tcl");
/* 180 */     mappings.add("tex", "application/x-tex");
/* 181 */     mappings.add("texi", "application/x-texinfo");
/* 182 */     mappings.add("texinfo", "application/x-texinfo");
/* 183 */     mappings.add("tif", "image/tiff");
/* 184 */     mappings.add("tiff", "image/tiff");
/* 185 */     mappings.add("tr", "text/troff");
/* 186 */     mappings.add("tsv", "text/tab-separated-values");
/* 187 */     mappings.add("txt", "text/plain");
/* 188 */     mappings.add("ulw", "audio/basic");
/* 189 */     mappings.add("ustar", "application/x-ustar");
/* 190 */     mappings.add("vxml", "application/voicexml+xml");
/* 191 */     mappings.add("xbm", "image/x-xbitmap");
/* 192 */     mappings.add("xht", "application/xhtml+xml");
/* 193 */     mappings.add("xhtml", "application/xhtml+xml");
/* 194 */     mappings.add("xls", "application/vnd.ms-excel");
/* 195 */     mappings.add("xml", "application/xml");
/* 196 */     mappings.add("xpm", "image/x-xpixmap");
/* 197 */     mappings.add("xsl", "application/xml");
/* 198 */     mappings.add("xslt", "application/xslt+xml");
/* 199 */     mappings.add("xul", "application/vnd.mozilla.xul+xml");
/* 200 */     mappings.add("xwd", "image/x-xwindowdump");
/* 201 */     mappings.add("vsd", "application/vnd.visio");
/* 202 */     mappings.add("wav", "audio/x-wav");
/* 203 */     mappings.add("wbmp", "image/vnd.wap.wbmp");
/* 204 */     mappings.add("wml", "text/vnd.wap.wml");
/* 205 */     mappings.add("wmlc", "application/vnd.wap.wmlc");
/* 206 */     mappings.add("wmls", "text/vnd.wap.wmlsc");
/* 207 */     mappings.add("wmlscriptc", "application/vnd.wap.wmlscriptc");
/* 208 */     mappings.add("wmv", "video/x-ms-wmv");
/* 209 */     mappings.add("wrl", "model/vrml");
/* 210 */     mappings.add("wspolicy", "application/wspolicy+xml");
/* 211 */     mappings.add("z", "application/x-compress");
/* 212 */     mappings.add("zip", "application/zip");
/* 213 */     DEFAULT = unmodifiableMappings(mappings);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MimeMappings()
/*     */   {
/* 222 */     this.map = new LinkedHashMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MimeMappings(MimeMappings mappings)
/*     */   {
/* 230 */     this(mappings, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MimeMappings(Map<String, String> mappings)
/*     */   {
/* 239 */     Assert.notNull(mappings, "Mappings must not be null");
/* 240 */     this.map = new LinkedHashMap();
/* 241 */     for (Map.Entry<String, String> entry : mappings.entrySet()) {
/* 242 */       add((String)entry.getKey(), (String)entry.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private MimeMappings(MimeMappings mappings, boolean mutable)
/*     */   {
/* 252 */     Assert.notNull(mappings, "Mappings must not be null");
/*     */     
/*     */ 
/* 255 */     this.map = (mutable ? new LinkedHashMap(mappings.map) : Collections.unmodifiableMap(mappings.map));
/*     */   }
/*     */   
/*     */   public Iterator<Mapping> iterator()
/*     */   {
/* 260 */     return getAll().iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<Mapping> getAll()
/*     */   {
/* 268 */     return this.map.values();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String add(String extension, String mimeType)
/*     */   {
/* 278 */     Mapping previous = (Mapping)this.map.put(extension, new Mapping(extension, mimeType));
/* 279 */     return previous == null ? null : previous.getMimeType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String get(String extension)
/*     */   {
/* 288 */     Mapping mapping = (Mapping)this.map.get(extension);
/* 289 */     return mapping == null ? null : mapping.getMimeType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String remove(String extension)
/*     */   {
/* 298 */     Mapping previous = (Mapping)this.map.remove(extension);
/* 299 */     return previous == null ? null : previous.getMimeType();
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 304 */     return this.map.hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 309 */     if (obj == null) {
/* 310 */       return false;
/*     */     }
/* 312 */     if (obj == this) {
/* 313 */       return true;
/*     */     }
/* 315 */     if ((obj instanceof MimeMappings)) {
/* 316 */       MimeMappings other = (MimeMappings)obj;
/* 317 */       return this.map.equals(other.map);
/*     */     }
/* 319 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MimeMappings unmodifiableMappings(MimeMappings mappings)
/*     */   {
/* 329 */     return new MimeMappings(mappings, false);
/*     */   }
/*     */   
/*     */ 
/*     */   public static final class Mapping
/*     */   {
/*     */     private final String extension;
/*     */     
/*     */     private final String mimeType;
/*     */     
/*     */ 
/*     */     public Mapping(String extension, String mimeType)
/*     */     {
/* 342 */       Assert.notNull(extension, "Extension must not be null");
/* 343 */       Assert.notNull(mimeType, "MimeType must not be null");
/* 344 */       this.extension = extension;
/* 345 */       this.mimeType = mimeType;
/*     */     }
/*     */     
/*     */     public String getExtension() {
/* 349 */       return this.extension;
/*     */     }
/*     */     
/*     */     public String getMimeType() {
/* 353 */       return this.mimeType;
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 358 */       return this.extension.hashCode();
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/* 363 */       if (obj == null) {
/* 364 */         return false;
/*     */       }
/* 366 */       if (obj == this) {
/* 367 */         return true;
/*     */       }
/* 369 */       if ((obj instanceof Mapping)) {
/* 370 */         Mapping other = (Mapping)obj;
/*     */         
/* 372 */         return (this.extension.equals(other.extension)) && (this.mimeType.equals(other.mimeType));
/*     */       }
/* 374 */       return false;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 379 */       return "Mapping [extension=" + this.extension + ", mimeType=" + this.mimeType + "]";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\embedded\MimeMappings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */