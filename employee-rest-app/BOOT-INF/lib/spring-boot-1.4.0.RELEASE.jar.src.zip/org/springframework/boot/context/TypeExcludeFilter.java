/*    */ package org.springframework.boot.context;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.core.type.classreading.MetadataReader;
/*    */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*    */ import org.springframework.core.type.filter.TypeFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeExcludeFilter
/*    */   implements TypeFilter, BeanFactoryAware
/*    */ {
/*    */   private BeanFactory beanFactory;
/*    */   
/*    */   public void setBeanFactory(BeanFactory beanFactory)
/*    */     throws BeansException
/*    */   {
/* 54 */     this.beanFactory = beanFactory;
/*    */   }
/*    */   
/*    */   public boolean match(MetadataReader metadataReader, MetadataReaderFactory metadataReaderFactory)
/*    */     throws IOException
/*    */   {
/* 60 */     if (((this.beanFactory instanceof ListableBeanFactory)) && 
/* 61 */       (getClass().equals(TypeExcludeFilter.class)))
/*    */     {
/* 63 */       Collection<TypeExcludeFilter> delegates = ((ListableBeanFactory)this.beanFactory).getBeansOfType(TypeExcludeFilter.class).values();
/* 64 */       for (TypeExcludeFilter delegate : delegates) {
/* 65 */         if (delegate.match(metadataReader, metadataReaderFactory)) {
/* 66 */           return true;
/*    */         }
/*    */       }
/*    */     }
/* 70 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\TypeExcludeFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */