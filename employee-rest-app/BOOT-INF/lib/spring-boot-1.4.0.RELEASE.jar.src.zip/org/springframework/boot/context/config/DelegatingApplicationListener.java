/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.event.SimpleApplicationEventMulticaster;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelegatingApplicationListener
/*     */   implements ApplicationListener<ApplicationEvent>, Ordered
/*     */ {
/*     */   private static final String PROPERTY_NAME = "context.listener.classes";
/*  49 */   private int order = 0;
/*     */   
/*     */   private SimpleApplicationEventMulticaster multicaster;
/*     */   
/*     */   public void onApplicationEvent(ApplicationEvent event)
/*     */   {
/*  55 */     if ((event instanceof ApplicationEnvironmentPreparedEvent)) {
/*  56 */       List<ApplicationListener<ApplicationEvent>> delegates = getListeners(((ApplicationEnvironmentPreparedEvent)event)
/*  57 */         .getEnvironment());
/*  58 */       if (delegates.isEmpty()) {
/*  59 */         return;
/*     */       }
/*  61 */       this.multicaster = new SimpleApplicationEventMulticaster();
/*  62 */       for (ApplicationListener<ApplicationEvent> listener : delegates) {
/*  63 */         this.multicaster.addApplicationListener(listener);
/*     */       }
/*     */     }
/*  66 */     if (this.multicaster != null) {
/*  67 */       this.multicaster.multicastEvent(event);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private List<ApplicationListener<ApplicationEvent>> getListeners(ConfigurableEnvironment env)
/*     */   {
/*  74 */     String classNames = env.getProperty("context.listener.classes");
/*  75 */     List<ApplicationListener<ApplicationEvent>> listeners = new ArrayList();
/*  76 */     if (StringUtils.hasLength(classNames)) {
/*  77 */       for (String className : StringUtils.commaDelimitedListToSet(classNames)) {
/*     */         try {
/*  79 */           Class<?> clazz = ClassUtils.forName(className, 
/*  80 */             ClassUtils.getDefaultClassLoader());
/*  81 */           Assert.isAssignable(ApplicationListener.class, clazz, "class [" + className + "] must implement ApplicationListener");
/*     */           
/*  83 */           listeners.add(
/*  84 */             (ApplicationListener)BeanUtils.instantiateClass(clazz));
/*     */         }
/*     */         catch (Exception ex) {
/*  87 */           throw new ApplicationContextException("Failed to load context listener class [" + className + "]", ex);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  93 */     AnnotationAwareOrderComparator.sort(listeners);
/*  94 */     return listeners;
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/*  98 */     this.order = order;
/*     */   }
/*     */   
/*     */   public int getOrder()
/*     */   {
/* 103 */     return this.order;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\config\DelegatingApplicationListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */