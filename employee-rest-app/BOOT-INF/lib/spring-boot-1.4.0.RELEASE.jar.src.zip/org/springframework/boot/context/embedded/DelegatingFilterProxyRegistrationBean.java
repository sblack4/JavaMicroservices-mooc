/*    */ package org.springframework.boot.context.embedded;
/*    */ 
/*    */ import org.springframework.boot.web.servlet.ServletRegistrationBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class DelegatingFilterProxyRegistrationBean
/*    */   extends org.springframework.boot.web.servlet.DelegatingFilterProxyRegistrationBean
/*    */   implements ServletContextInitializer
/*    */ {
/*    */   public DelegatingFilterProxyRegistrationBean(String targetBeanName, ServletRegistrationBean... servletRegistrationBeans)
/*    */   {
/* 58 */     super(targetBeanName, servletRegistrationBeans);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\embedded\DelegatingFilterProxyRegistrationBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */