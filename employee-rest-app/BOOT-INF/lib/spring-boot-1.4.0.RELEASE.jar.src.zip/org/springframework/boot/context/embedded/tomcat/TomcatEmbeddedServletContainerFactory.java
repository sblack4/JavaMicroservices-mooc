/*     */ package org.springframework.boot.context.embedded.tomcat;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javax.servlet.ServletContainerInitializer;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.Manager;
/*     */ import org.apache.catalina.Pipeline;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.Wrapper;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.loader.WebappLoader;
/*     */ import org.apache.catalina.session.ManagerBase;
/*     */ import org.apache.catalina.session.StandardManager;
/*     */ import org.apache.catalina.startup.Tomcat;
/*     */ import org.apache.catalina.startup.Tomcat.FixContextListener;
/*     */ import org.apache.catalina.webresources.TomcatURLStreamHandlerFactory;
/*     */ import org.apache.coyote.AbstractProtocol;
/*     */ import org.apache.coyote.ProtocolHandler;
/*     */ import org.apache.coyote.http11.AbstractHttp11JsseProtocol;
/*     */ import org.apache.coyote.http11.AbstractHttp11Protocol;
/*     */ import org.apache.coyote.http11.Http11NioProtocol;
/*     */ import org.apache.tomcat.util.net.SSLHostConfig;
/*     */ import org.springframework.boot.context.embedded.AbstractEmbeddedServletContainerFactory;
/*     */ import org.springframework.boot.context.embedded.Compression;
/*     */ import org.springframework.boot.context.embedded.EmbeddedServletContainer;
/*     */ import org.springframework.boot.context.embedded.EmbeddedServletContainerException;
/*     */ import org.springframework.boot.context.embedded.JspServlet;
/*     */ import org.springframework.boot.context.embedded.MimeMappings.Mapping;
/*     */ import org.springframework.boot.context.embedded.Ssl;
/*     */ import org.springframework.boot.context.embedded.Ssl.ClientAuth;
/*     */ import org.springframework.boot.context.embedded.SslStoreProvider;
/*     */ import org.springframework.boot.web.servlet.ErrorPage;
/*     */ import org.springframework.boot.web.servlet.ServletContextInitializer;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TomcatEmbeddedServletContainerFactory
/*     */   extends AbstractEmbeddedServletContainerFactory
/*     */   implements ResourceLoaderAware
/*     */ {
/* 102 */   private static final Charset DEFAULT_CHARSET = Charset.forName("UTF-8");
/*     */   
/* 104 */   private static final Set<Class<?>> NO_CLASSES = Collections.emptySet();
/*     */   
/*     */ 
/*     */   public static final String DEFAULT_PROTOCOL = "org.apache.coyote.http11.Http11NioProtocol";
/*     */   
/*     */ 
/*     */   private File baseDirectory;
/*     */   
/*     */ 
/* 113 */   private List<Valve> engineValves = new ArrayList();
/*     */   
/* 115 */   private List<Valve> contextValves = new ArrayList();
/*     */   
/* 117 */   private List<LifecycleListener> contextLifecycleListeners = new ArrayList();
/*     */   
/* 119 */   private List<TomcatContextCustomizer> tomcatContextCustomizers = new ArrayList();
/*     */   
/* 121 */   private List<TomcatConnectorCustomizer> tomcatConnectorCustomizers = new ArrayList();
/*     */   
/* 123 */   private List<Connector> additionalTomcatConnectors = new ArrayList();
/*     */   
/*     */   private ResourceLoader resourceLoader;
/*     */   
/* 127 */   private String protocol = "org.apache.coyote.http11.Http11NioProtocol";
/*     */   
/*     */   private String tldSkip;
/*     */   
/* 131 */   private Charset uriEncoding = DEFAULT_CHARSET;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TomcatEmbeddedServletContainerFactory() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TomcatEmbeddedServletContainerFactory(int port)
/*     */   {
/* 146 */     super(port);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TomcatEmbeddedServletContainerFactory(String contextPath, int port)
/*     */   {
/* 156 */     super(contextPath, port);
/*     */   }
/*     */   
/*     */ 
/*     */   public EmbeddedServletContainer getEmbeddedServletContainer(ServletContextInitializer... initializers)
/*     */   {
/* 162 */     Tomcat tomcat = new Tomcat();
/*     */     
/* 164 */     File baseDir = this.baseDirectory != null ? this.baseDirectory : createTempDir("tomcat");
/* 165 */     tomcat.setBaseDir(baseDir.getAbsolutePath());
/* 166 */     Connector connector = new Connector(this.protocol);
/* 167 */     tomcat.getService().addConnector(connector);
/* 168 */     customizeConnector(connector);
/* 169 */     tomcat.setConnector(connector);
/* 170 */     tomcat.getHost().setAutoDeploy(false);
/* 171 */     configureEngine(tomcat.getEngine());
/* 172 */     for (Connector additionalConnector : this.additionalTomcatConnectors) {
/* 173 */       tomcat.getService().addConnector(additionalConnector);
/*     */     }
/* 175 */     prepareContext(tomcat.getHost(), initializers);
/* 176 */     return getTomcatEmbeddedServletContainer(tomcat);
/*     */   }
/*     */   
/*     */   private void configureEngine(Engine engine) {
/* 180 */     engine.setBackgroundProcessorDelay(-1);
/* 181 */     for (Valve valve : this.engineValves) {
/* 182 */       engine.getPipeline().addValve(valve);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void prepareContext(Host host, ServletContextInitializer[] initializers) {
/* 187 */     File docBase = getValidDocumentRoot();
/* 188 */     docBase = docBase != null ? docBase : createTempDir("tomcat-docbase");
/* 189 */     TomcatEmbeddedContext context = new TomcatEmbeddedContext();
/* 190 */     context.setName(getContextPath());
/* 191 */     context.setDisplayName(getDisplayName());
/* 192 */     context.setPath(getContextPath());
/* 193 */     context.setDocBase(docBase.getAbsolutePath());
/* 194 */     context.addLifecycleListener(new Tomcat.FixContextListener());
/* 195 */     context.setParentClassLoader(this.resourceLoader != null ? this.resourceLoader
/* 196 */       .getClassLoader() : 
/* 197 */       ClassUtils.getDefaultClassLoader());
/* 198 */     resetDefaultLocaleMapping(context);
/* 199 */     addLocaleMappings(context);
/*     */     try {
/* 201 */       context.setUseRelativeRedirects(false);
/*     */     }
/*     */     catch (NoSuchMethodError localNoSuchMethodError) {}
/*     */     
/*     */ 
/* 206 */     SkipPatternJarScanner.apply(context, this.tldSkip);
/* 207 */     WebappLoader loader = new WebappLoader(context.getParentClassLoader());
/* 208 */     loader.setLoaderClass(TomcatEmbeddedWebappClassLoader.class.getName());
/* 209 */     loader.setDelegate(true);
/* 210 */     context.setLoader(loader);
/* 211 */     if (isRegisterDefaultServlet()) {
/* 212 */       addDefaultServlet(context);
/*     */     }
/* 214 */     if (shouldRegisterJspServlet()) {
/* 215 */       addJspServlet(context);
/* 216 */       addJasperInitializer(context);
/* 217 */       context.addLifecycleListener(new StoreMergedWebXmlListener(null));
/*     */     }
/* 219 */     ServletContextInitializer[] initializersToUse = mergeInitializers(initializers);
/* 220 */     configureContext(context, initializersToUse);
/* 221 */     host.addChild(context);
/* 222 */     postProcessContext(context);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void resetDefaultLocaleMapping(TomcatEmbeddedContext context)
/*     */   {
/* 231 */     context.addLocaleEncodingMappingParameter(Locale.ENGLISH.toString(), DEFAULT_CHARSET
/* 232 */       .displayName());
/* 233 */     context.addLocaleEncodingMappingParameter(Locale.FRENCH.toString(), DEFAULT_CHARSET
/* 234 */       .displayName());
/*     */   }
/*     */   
/*     */   private void addLocaleMappings(TomcatEmbeddedContext context) {
/* 238 */     for (Map.Entry<Locale, Charset> entry : getLocaleCharsetMappings().entrySet()) {
/* 239 */       Locale locale = (Locale)entry.getKey();
/* 240 */       Charset charset = (Charset)entry.getValue();
/* 241 */       context.addLocaleEncodingMappingParameter(locale.toString(), charset
/* 242 */         .toString());
/*     */     }
/*     */   }
/*     */   
/*     */   private void addDefaultServlet(Context context) {
/* 247 */     Wrapper defaultServlet = context.createWrapper();
/* 248 */     defaultServlet.setName("default");
/* 249 */     defaultServlet.setServletClass("org.apache.catalina.servlets.DefaultServlet");
/* 250 */     defaultServlet.addInitParameter("debug", "0");
/* 251 */     defaultServlet.addInitParameter("listings", "false");
/* 252 */     defaultServlet.setLoadOnStartup(1);
/*     */     
/* 254 */     defaultServlet.setOverridable(true);
/* 255 */     context.addChild(defaultServlet);
/* 256 */     context.addServletMapping("/", "default");
/*     */   }
/*     */   
/*     */   private void addJspServlet(Context context) {
/* 260 */     Wrapper jspServlet = context.createWrapper();
/* 261 */     jspServlet.setName("jsp");
/* 262 */     jspServlet.setServletClass(getJspServlet().getClassName());
/* 263 */     jspServlet.addInitParameter("fork", "false");
/* 264 */     for (Map.Entry<String, String> initParameter : getJspServlet().getInitParameters()
/* 265 */       .entrySet()) {
/* 266 */       jspServlet.addInitParameter((String)initParameter.getKey(), (String)initParameter.getValue());
/*     */     }
/* 268 */     jspServlet.setLoadOnStartup(3);
/* 269 */     context.addChild(jspServlet);
/* 270 */     context.addServletMapping("*.jsp", "jsp");
/* 271 */     context.addServletMapping("*.jspx", "jsp");
/*     */   }
/*     */   
/*     */   private void addJasperInitializer(TomcatEmbeddedContext context)
/*     */   {
/*     */     try
/*     */     {
/* 278 */       ServletContainerInitializer initializer = (ServletContainerInitializer)ClassUtils.forName("org.apache.jasper.servlet.JasperInitializer", null).newInstance();
/* 279 */       context.addServletContainerInitializer(initializer, null);
/*     */     }
/*     */     catch (Exception localException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void customizeConnector(Connector connector)
/*     */   {
/* 288 */     int port = getPort() >= 0 ? getPort() : 0;
/* 289 */     connector.setPort(port);
/* 290 */     if (StringUtils.hasText(getServerHeader())) {
/* 291 */       connector.setAttribute("server", getServerHeader());
/*     */     }
/* 293 */     if ((connector.getProtocolHandler() instanceof AbstractProtocol)) {
/* 294 */       customizeProtocol((AbstractProtocol)connector.getProtocolHandler());
/*     */     }
/* 296 */     if (getUriEncoding() != null) {
/* 297 */       connector.setURIEncoding(getUriEncoding().name());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 302 */     connector.setProperty("bindOnInit", "false");
/*     */     
/* 304 */     if ((getSsl() != null) && (getSsl().isEnabled())) {
/* 305 */       customizeSsl(connector);
/*     */     }
/* 307 */     if ((getCompression() != null) && (getCompression().getEnabled())) {
/* 308 */       customizeCompression(connector);
/*     */     }
/* 310 */     for (TomcatConnectorCustomizer customizer : this.tomcatConnectorCustomizers) {
/* 311 */       customizer.customize(connector);
/*     */     }
/*     */   }
/*     */   
/*     */   private void customizeProtocol(AbstractProtocol<?> protocol) {
/* 316 */     if (getAddress() != null) {
/* 317 */       protocol.setAddress(getAddress());
/*     */     }
/*     */   }
/*     */   
/*     */   private void customizeSsl(Connector connector) {
/* 322 */     ProtocolHandler handler = connector.getProtocolHandler();
/* 323 */     Assert.state(handler instanceof AbstractHttp11JsseProtocol, "To use SSL, the connector's protocol handler must be an AbstractHttp11JsseProtocol subclass");
/*     */     
/*     */ 
/* 326 */     configureSsl((AbstractHttp11JsseProtocol)handler, getSsl());
/* 327 */     connector.setScheme("https");
/* 328 */     connector.setSecure(true);
/*     */   }
/*     */   
/*     */   private void customizeCompression(Connector connector) {
/* 332 */     ProtocolHandler handler = connector.getProtocolHandler();
/* 333 */     if ((handler instanceof AbstractHttp11Protocol)) {
/* 334 */       AbstractHttp11Protocol<?> protocol = (AbstractHttp11Protocol)handler;
/* 335 */       Compression compression = getCompression();
/* 336 */       protocol.setCompression("on");
/* 337 */       protocol.setCompressionMinSize(compression.getMinResponseSize());
/* 338 */       protocol.setCompressableMimeType(
/* 339 */         StringUtils.arrayToCommaDelimitedString(compression.getMimeTypes()));
/* 340 */       if (getCompression().getExcludedUserAgents() != null) {
/* 341 */         protocol.setNoCompressionUserAgents(
/* 342 */           StringUtils.arrayToCommaDelimitedString(
/* 343 */           getCompression().getExcludedUserAgents()));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void configureSsl(AbstractHttp11JsseProtocol<?> protocol, Ssl ssl)
/*     */   {
/* 354 */     protocol.setSSLEnabled(true);
/* 355 */     protocol.setSslProtocol(ssl.getProtocol());
/* 356 */     configureSslClientAuth(protocol, ssl);
/* 357 */     protocol.setKeystorePass(ssl.getKeyStorePassword());
/* 358 */     protocol.setKeyPass(ssl.getKeyPassword());
/* 359 */     protocol.setKeyAlias(ssl.getKeyAlias());
/* 360 */     String ciphers = StringUtils.arrayToCommaDelimitedString(ssl.getCiphers());
/* 361 */     protocol.setCiphers(StringUtils.hasText(ciphers) ? ciphers : null);
/* 362 */     if (ssl.getEnabledProtocols() != null) {
/*     */       try {
/* 364 */         for (SSLHostConfig sslHostConfig : protocol.findSslHostConfigs()) {
/* 365 */           sslHostConfig.setProtocols(
/* 366 */             StringUtils.arrayToCommaDelimitedString(ssl.getEnabledProtocols()));
/*     */         }
/*     */       }
/*     */       catch (NoSuchMethodError ex)
/*     */       {
/* 371 */         Assert.isTrue(
/* 372 */           protocol.setProperty("sslEnabledProtocols", 
/* 373 */           StringUtils.arrayToCommaDelimitedString(ssl
/* 374 */           .getEnabledProtocols())), "Failed to set sslEnabledProtocols");
/*     */       }
/*     */     }
/*     */     
/* 378 */     if (getSslStoreProvider() != null)
/*     */     {
/* 380 */       TomcatURLStreamHandlerFactory instance = TomcatURLStreamHandlerFactory.getInstance();
/* 381 */       instance.addUserFactory(new SslStoreProviderUrlStreamHandlerFactory(
/* 382 */         getSslStoreProvider()));
/* 383 */       protocol.setKeystoreFile("springbootssl:keyStore");
/*     */       
/* 385 */       protocol.setTruststoreFile("springbootssl:trustStore");
/*     */     }
/*     */     else
/*     */     {
/* 389 */       configureSslKeyStore(protocol, ssl);
/* 390 */       configureSslTrustStore(protocol, ssl);
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureSslClientAuth(AbstractHttp11JsseProtocol<?> protocol, Ssl ssl) {
/* 395 */     if (ssl.getClientAuth() == Ssl.ClientAuth.NEED) {
/* 396 */       protocol.setClientAuth(Boolean.TRUE.toString());
/*     */     }
/* 398 */     else if (ssl.getClientAuth() == Ssl.ClientAuth.WANT) {
/* 399 */       protocol.setClientAuth("want");
/*     */     }
/*     */   }
/*     */   
/*     */   protected void configureSslStoreProvider(AbstractHttp11JsseProtocol<?> protocol, SslStoreProvider sslStoreProvider)
/*     */   {
/* 405 */     Assert.isInstanceOf(Http11NioProtocol.class, protocol, "SslStoreProvider can only be used with Http11NioProtocol");
/*     */   }
/*     */   
/*     */   private void configureSslKeyStore(AbstractHttp11JsseProtocol<?> protocol, Ssl ssl)
/*     */   {
/*     */     try {
/* 411 */       protocol.setKeystoreFile(ResourceUtils.getURL(ssl.getKeyStore()).toString());
/*     */     }
/*     */     catch (FileNotFoundException ex)
/*     */     {
/* 415 */       throw new EmbeddedServletContainerException("Could not load key store: " + ex.getMessage(), ex);
/*     */     }
/* 417 */     if (ssl.getKeyStoreType() != null) {
/* 418 */       protocol.setKeystoreType(ssl.getKeyStoreType());
/*     */     }
/* 420 */     if (ssl.getKeyStoreProvider() != null) {
/* 421 */       protocol.setKeystoreProvider(ssl.getKeyStoreProvider());
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureSslTrustStore(AbstractHttp11JsseProtocol<?> protocol, Ssl ssl)
/*     */   {
/* 427 */     if (ssl.getTrustStore() != null) {
/*     */       try {
/* 429 */         protocol.setTruststoreFile(
/* 430 */           ResourceUtils.getURL(ssl.getTrustStore()).toString());
/*     */       }
/*     */       catch (FileNotFoundException ex)
/*     */       {
/* 434 */         throw new EmbeddedServletContainerException("Could not load trust store: " + ex.getMessage(), ex);
/*     */       }
/*     */     }
/* 437 */     protocol.setTruststorePass(ssl.getTrustStorePassword());
/* 438 */     if (ssl.getTrustStoreType() != null) {
/* 439 */       protocol.setTruststoreType(ssl.getTrustStoreType());
/*     */     }
/* 441 */     if (ssl.getTrustStoreProvider() != null) {
/* 442 */       protocol.setTruststoreProvider(ssl.getTrustStoreProvider());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void configureContext(Context context, ServletContextInitializer[] initializers)
/*     */   {
/* 453 */     TomcatStarter starter = new TomcatStarter(initializers);
/* 454 */     if ((context instanceof TomcatEmbeddedContext))
/*     */     {
/* 456 */       ((TomcatEmbeddedContext)context).setStarter(starter);
/*     */     }
/* 458 */     context.addServletContainerInitializer(starter, NO_CLASSES);
/* 459 */     for (LifecycleListener lifecycleListener : this.contextLifecycleListeners) {
/* 460 */       context.addLifecycleListener(lifecycleListener);
/*     */     }
/* 462 */     for (Valve valve : this.contextValves) {
/* 463 */       context.getPipeline().addValve(valve);
/*     */     }
/* 465 */     for (ErrorPage errorPage : getErrorPages()) {
/* 466 */       new TomcatErrorPage(errorPage).addToContext(context);
/*     */     }
/* 468 */     for (MimeMappings.Mapping mapping : getMimeMappings()) {
/* 469 */       context.addMimeMapping(mapping.getExtension(), mapping.getMimeType());
/*     */     }
/* 471 */     configureSession(context);
/* 472 */     for (TomcatContextCustomizer customizer : this.tomcatContextCustomizers) {
/* 473 */       customizer.customize(context);
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureSession(Context context) {
/* 478 */     long sessionTimeout = getSessionTimeoutInMinutes();
/* 479 */     context.setSessionTimeout((int)sessionTimeout);
/* 480 */     if (isPersistSession()) {
/* 481 */       Manager manager = context.getManager();
/* 482 */       if (manager == null) {
/* 483 */         manager = new StandardManager();
/* 484 */         context.setManager(manager);
/*     */       }
/* 486 */       configurePersistSession(manager);
/*     */     }
/*     */     else {
/* 489 */       context.addLifecycleListener(new DisablePersistSessionListener(null));
/*     */     }
/* 491 */     context.addLifecycleListener(new LazySessionIdGeneratorListener(null));
/*     */   }
/*     */   
/*     */   private void configurePersistSession(Manager manager) {
/* 495 */     Assert.state(manager instanceof StandardManager, "Unable to persist HTTP session state using manager type " + manager
/*     */     
/* 497 */       .getClass().getName());
/* 498 */     File dir = getValidSessionStoreDir();
/* 499 */     File file = new File(dir, "SESSIONS.ser");
/* 500 */     ((StandardManager)manager).setPathname(file.getAbsolutePath());
/*     */   }
/*     */   
/*     */   private long getSessionTimeoutInMinutes() {
/* 504 */     long sessionTimeout = getSessionTimeout();
/* 505 */     if (sessionTimeout > 0L) {
/* 506 */       sessionTimeout = Math.max(TimeUnit.SECONDS.toMinutes(sessionTimeout), 1L);
/*     */     }
/* 508 */     return sessionTimeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void postProcessContext(Context context) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TomcatEmbeddedServletContainer getTomcatEmbeddedServletContainer(Tomcat tomcat)
/*     */   {
/* 530 */     return new TomcatEmbeddedServletContainer(tomcat, getPort() >= 0);
/*     */   }
/*     */   
/*     */   public void setResourceLoader(ResourceLoader resourceLoader)
/*     */   {
/* 535 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBaseDirectory(File baseDirectory)
/*     */   {
/* 543 */     this.baseDirectory = baseDirectory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTldSkip(String tldSkip)
/*     */   {
/* 552 */     Assert.notNull(tldSkip, "TldSkip must not be null");
/* 553 */     this.tldSkip = tldSkip;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProtocol(String protocol)
/*     */   {
/* 562 */     Assert.hasLength(protocol, "Protocol must not be empty");
/* 563 */     this.protocol = protocol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEngineValves(Collection<? extends Valve> engineValves)
/*     */   {
/* 572 */     Assert.notNull(engineValves, "Valves must not be null");
/* 573 */     this.engineValves = new ArrayList(engineValves);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<Valve> getEngineValves()
/*     */   {
/* 582 */     return this.engineValves;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addEngineValves(Valve... engineValves)
/*     */   {
/* 590 */     Assert.notNull(engineValves, "Valves must not be null");
/* 591 */     this.engineValves.addAll(Arrays.asList(engineValves));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContextValves(Collection<? extends Valve> contextValves)
/*     */   {
/* 600 */     Assert.notNull(contextValves, "Valves must not be null");
/* 601 */     this.contextValves = new ArrayList(contextValves);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public Collection<Valve> getValves()
/*     */   {
/* 612 */     return getContextValves();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<Valve> getContextValves()
/*     */   {
/* 622 */     return this.contextValves;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addContextValves(Valve... contextValves)
/*     */   {
/* 630 */     Assert.notNull(contextValves, "Valves must not be null");
/* 631 */     this.contextValves.addAll(Arrays.asList(contextValves));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContextLifecycleListeners(Collection<? extends LifecycleListener> contextLifecycleListeners)
/*     */   {
/* 641 */     Assert.notNull(contextLifecycleListeners, "ContextLifecycleListeners must not be null");
/*     */     
/* 643 */     this.contextLifecycleListeners = new ArrayList(contextLifecycleListeners);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<LifecycleListener> getContextLifecycleListeners()
/*     */   {
/* 653 */     return this.contextLifecycleListeners;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addContextLifecycleListeners(LifecycleListener... contextLifecycleListeners)
/*     */   {
/* 662 */     Assert.notNull(contextLifecycleListeners, "ContextLifecycleListeners must not be null");
/*     */     
/* 664 */     this.contextLifecycleListeners.addAll(Arrays.asList(contextLifecycleListeners));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTomcatContextCustomizers(Collection<? extends TomcatContextCustomizer> tomcatContextCustomizers)
/*     */   {
/* 674 */     Assert.notNull(tomcatContextCustomizers, "TomcatContextCustomizers must not be null");
/*     */     
/* 676 */     this.tomcatContextCustomizers = new ArrayList(tomcatContextCustomizers);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<TomcatContextCustomizer> getTomcatContextCustomizers()
/*     */   {
/* 686 */     return this.tomcatContextCustomizers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addContextCustomizers(TomcatContextCustomizer... tomcatContextCustomizers)
/*     */   {
/* 696 */     Assert.notNull(tomcatContextCustomizers, "TomcatContextCustomizers must not be null");
/*     */     
/* 698 */     this.tomcatContextCustomizers.addAll(Arrays.asList(tomcatContextCustomizers));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTomcatConnectorCustomizers(Collection<? extends TomcatConnectorCustomizer> tomcatConnectorCustomizers)
/*     */   {
/* 708 */     Assert.notNull(tomcatConnectorCustomizers, "TomcatConnectorCustomizers must not be null");
/*     */     
/* 710 */     this.tomcatConnectorCustomizers = new ArrayList(tomcatConnectorCustomizers);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addConnectorCustomizers(TomcatConnectorCustomizer... tomcatConnectorCustomizers)
/*     */   {
/* 721 */     Assert.notNull(tomcatConnectorCustomizers, "TomcatConnectorCustomizers must not be null");
/*     */     
/* 723 */     this.tomcatConnectorCustomizers.addAll(Arrays.asList(tomcatConnectorCustomizers));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<TomcatConnectorCustomizer> getTomcatConnectorCustomizers()
/*     */   {
/* 732 */     return this.tomcatConnectorCustomizers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addAdditionalTomcatConnectors(Connector... connectors)
/*     */   {
/* 740 */     Assert.notNull(connectors, "Connectors must not be null");
/* 741 */     this.additionalTomcatConnectors.addAll(Arrays.asList(connectors));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Connector> getAdditionalTomcatConnectors()
/*     */   {
/* 750 */     return this.additionalTomcatConnectors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUriEncoding(Charset uriEncoding)
/*     */   {
/* 759 */     this.uriEncoding = uriEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Charset getUriEncoding()
/*     */   {
/* 767 */     return this.uriEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class StoreMergedWebXmlListener
/*     */     implements LifecycleListener
/*     */   {
/*     */     private static final String MERGED_WEB_XML = "org.apache.tomcat.util.scan.MergedWebXml";
/*     */     
/*     */ 
/*     */ 
/*     */     public void lifecycleEvent(LifecycleEvent event)
/*     */     {
/* 781 */       if (event.getType().equals("configure_start")) {
/* 782 */         onStart((Context)event.getLifecycle());
/*     */       }
/*     */     }
/*     */     
/*     */     private void onStart(Context context) {
/* 787 */       ServletContext servletContext = context.getServletContext();
/* 788 */       if (servletContext.getAttribute("org.apache.tomcat.util.scan.MergedWebXml") == null) {
/* 789 */         servletContext.setAttribute("org.apache.tomcat.util.scan.MergedWebXml", getEmptyWebXml());
/*     */       }
/* 791 */       TomcatResources.get(context).addClasspathResources();
/*     */     }
/*     */     
/*     */     /* Error */
/*     */     private String getEmptyWebXml()
/*     */     {
/*     */       // Byte code:
/*     */       //   0: ldc 18
/*     */       //   2: ldc 19
/*     */       //   4: invokevirtual 20	java/lang/Class:getResourceAsStream	(Ljava/lang/String;)Ljava/io/InputStream;
/*     */       //   7: astore_1
/*     */       //   8: aload_1
/*     */       //   9: ifnull +7 -> 16
/*     */       //   12: iconst_1
/*     */       //   13: goto +4 -> 17
/*     */       //   16: iconst_0
/*     */       //   17: ldc 21
/*     */       //   19: invokestatic 22	org/springframework/util/Assert:state	(ZLjava/lang/String;)V
/*     */       //   22: aload_1
/*     */       //   23: ldc 23
/*     */       //   25: invokestatic 24	java/nio/charset/Charset:forName	(Ljava/lang/String;)Ljava/nio/charset/Charset;
/*     */       //   28: invokestatic 25	org/springframework/util/StreamUtils:copyToString	(Ljava/io/InputStream;Ljava/nio/charset/Charset;)Ljava/lang/String;
/*     */       //   31: astore_2
/*     */       //   32: aload_1
/*     */       //   33: invokevirtual 26	java/io/InputStream:close	()V
/*     */       //   36: aload_2
/*     */       //   37: areturn
/*     */       //   38: astore_3
/*     */       //   39: aload_1
/*     */       //   40: invokevirtual 26	java/io/InputStream:close	()V
/*     */       //   43: aload_3
/*     */       //   44: athrow
/*     */       //   45: astore_2
/*     */       //   46: new 28	java/lang/IllegalStateException
/*     */       //   49: dup
/*     */       //   50: aload_2
/*     */       //   51: invokespecial 29	java/lang/IllegalStateException:<init>	(Ljava/lang/Throwable;)V
/*     */       //   54: athrow
/*     */       // Line number table:
/*     */       //   Java source line #795	-> byte code offset #0
/*     */       //   Java source line #796	-> byte code offset #4
/*     */       //   Java source line #797	-> byte code offset #8
/*     */       //   Java source line #800	-> byte code offset #22
/*     */       //   Java source line #803	-> byte code offset #32
/*     */       //   Java source line #806	-> byte code offset #45
/*     */       //   Java source line #807	-> byte code offset #46
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	signature
/*     */       //   0	55	0	this	StoreMergedWebXmlListener
/*     */       //   7	33	1	stream	java.io.InputStream
/*     */       //   45	6	2	ex	java.io.IOException
/*     */       //   38	6	3	localObject	Object
/*     */       // Exception table:
/*     */       //   from	to	target	type
/*     */       //   22	32	38	finally
/*     */       //   22	36	45	java/io/IOException
/*     */       //   38	45	45	java/io/IOException
/*     */     }
/*     */   }
/*     */   
/*     */   private static class DisablePersistSessionListener
/*     */     implements LifecycleListener
/*     */   {
/*     */     public void lifecycleEvent(LifecycleEvent event)
/*     */     {
/* 822 */       if (event.getType().equals("start")) {
/* 823 */         Context context = (Context)event.getLifecycle();
/* 824 */         Manager manager = context.getManager();
/* 825 */         if ((manager != null) && ((manager instanceof StandardManager))) {
/* 826 */           ((StandardManager)manager).setPathname(null);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static class LazySessionIdGeneratorListener
/*     */     implements LifecycleListener
/*     */   {
/*     */     public void lifecycleEvent(LifecycleEvent event)
/*     */     {
/* 837 */       if (event.getType().equals("start")) {
/* 838 */         Context context = (Context)event.getLifecycle();
/* 839 */         Manager manager = context.getManager();
/* 840 */         if ((manager instanceof ManagerBase))
/*     */         {
/* 842 */           ((ManagerBase)manager).setSessionIdGenerator(new LazySessionIdGenerator());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\embedded\tomcat\TomcatEmbeddedServletContainerFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */