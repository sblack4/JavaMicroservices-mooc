/*     */ package org.springframework.boot.context.embedded.jetty;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.eclipse.jetty.http.HttpVersion;
/*     */ import org.eclipse.jetty.http.MimeTypes;
/*     */ import org.eclipse.jetty.server.AbstractConnector;
/*     */ import org.eclipse.jetty.server.ConnectionFactory;
/*     */ import org.eclipse.jetty.server.Connector;
/*     */ import org.eclipse.jetty.server.ForwardedRequestCustomizer;
/*     */ import org.eclipse.jetty.server.Handler;
/*     */ import org.eclipse.jetty.server.HttpConfiguration;
/*     */ import org.eclipse.jetty.server.HttpConfiguration.ConnectionFactory;
/*     */ import org.eclipse.jetty.server.HttpConnectionFactory;
/*     */ import org.eclipse.jetty.server.Request;
/*     */ import org.eclipse.jetty.server.SecureRequestCustomizer;
/*     */ import org.eclipse.jetty.server.Server;
/*     */ import org.eclipse.jetty.server.ServerConnector;
/*     */ import org.eclipse.jetty.server.SessionManager;
/*     */ import org.eclipse.jetty.server.SslConnectionFactory;
/*     */ import org.eclipse.jetty.server.handler.ErrorHandler;
/*     */ import org.eclipse.jetty.server.handler.HandlerWrapper;
/*     */ import org.eclipse.jetty.server.handler.gzip.GzipHandler;
/*     */ import org.eclipse.jetty.server.session.HashSessionManager;
/*     */ import org.eclipse.jetty.server.session.SessionHandler;
/*     */ import org.eclipse.jetty.servlet.ErrorPageErrorHandler;
/*     */ import org.eclipse.jetty.servlet.ServletHandler;
/*     */ import org.eclipse.jetty.servlet.ServletHolder;
/*     */ import org.eclipse.jetty.servlet.ServletMapping;
/*     */ import org.eclipse.jetty.util.resource.JarResource;
/*     */ import org.eclipse.jetty.util.resource.Resource;
/*     */ import org.eclipse.jetty.util.ssl.SslContextFactory;
/*     */ import org.eclipse.jetty.util.thread.ThreadPool;
/*     */ import org.eclipse.jetty.webapp.AbstractConfiguration;
/*     */ import org.eclipse.jetty.webapp.Configuration;
/*     */ import org.eclipse.jetty.webapp.WebAppContext;
/*     */ import org.springframework.boot.context.embedded.AbstractEmbeddedServletContainerFactory;
/*     */ import org.springframework.boot.context.embedded.Compression;
/*     */ import org.springframework.boot.context.embedded.EmbeddedServletContainer;
/*     */ import org.springframework.boot.context.embedded.EmbeddedServletContainerException;
/*     */ import org.springframework.boot.context.embedded.JspServlet;
/*     */ import org.springframework.boot.context.embedded.MimeMappings.Mapping;
/*     */ import org.springframework.boot.context.embedded.Ssl;
/*     */ import org.springframework.boot.context.embedded.Ssl.ClientAuth;
/*     */ import org.springframework.boot.context.embedded.SslStoreProvider;
/*     */ import org.springframework.boot.web.servlet.ErrorPage;
/*     */ import org.springframework.boot.web.servlet.ServletContextInitializer;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JettyEmbeddedServletContainerFactory
/*     */   extends AbstractEmbeddedServletContainerFactory
/*     */   implements ResourceLoaderAware
/*     */ {
/*     */   private static final String GZIP_HANDLER_JETTY_9_2 = "org.eclipse.jetty.servlets.gzip.GzipHandler";
/*     */   private static final String GZIP_HANDLER_JETTY_8 = "org.eclipse.jetty.server.handler.GzipHandler";
/*     */   private static final String GZIP_HANDLER_JETTY_9_3 = "org.eclipse.jetty.server.handler.gzip.GzipHandler";
/*     */   private static final String CONNECTOR_JETTY_8 = "org.eclipse.jetty.server.nio.SelectChannelConnector";
/* 116 */   private List<Configuration> configurations = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean useForwardHeaders;
/*     */   
/*     */ 
/* 123 */   private int acceptors = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 128 */   private int selectors = -1;
/*     */   
/* 130 */   private List<JettyServerCustomizer> jettyServerCustomizers = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */   private ResourceLoader resourceLoader;
/*     */   
/*     */ 
/*     */ 
/*     */   private ThreadPool threadPool;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JettyEmbeddedServletContainerFactory() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public JettyEmbeddedServletContainerFactory(int port)
/*     */   {
/* 149 */     super(port);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JettyEmbeddedServletContainerFactory(String contextPath, int port)
/*     */   {
/* 159 */     super(contextPath, port);
/*     */   }
/*     */   
/*     */ 
/*     */   public EmbeddedServletContainer getEmbeddedServletContainer(ServletContextInitializer... initializers)
/*     */   {
/* 165 */     JettyEmbeddedWebAppContext context = new JettyEmbeddedWebAppContext();
/* 166 */     int port = getPort() >= 0 ? getPort() : 0;
/* 167 */     InetSocketAddress address = new InetSocketAddress(getAddress(), port);
/* 168 */     Server server = createServer(address);
/* 169 */     configureWebAppContext(context, initializers);
/* 170 */     server.setHandler(addHandlerWrappers(context));
/* 171 */     this.logger.info("Server initialized with port: " + port);
/* 172 */     SslContextFactory sslContextFactory; if ((getSsl() != null) && (getSsl().isEnabled())) {
/* 173 */       sslContextFactory = new SslContextFactory();
/* 174 */       configureSsl(sslContextFactory, getSsl());
/*     */       
/* 176 */       AbstractConnector connector = getSslServerConnectorFactory().getConnector(server, sslContextFactory, port);
/* 177 */       server.setConnectors(new Connector[] { connector });
/*     */     }
/* 179 */     for (JettyServerCustomizer customizer : getServerCustomizers()) {
/* 180 */       customizer.customize(server);
/*     */     }
/* 182 */     if (this.useForwardHeaders) {
/* 183 */       new ForwardHeadersCustomizer(null).customize(server);
/*     */     }
/* 185 */     return getJettyEmbeddedServletContainer(server);
/*     */   }
/*     */   
/*     */   private Server createServer(InetSocketAddress address) { Server server;
/*     */     Server server;
/* 190 */     if (ClassUtils.hasConstructor(Server.class, new Class[] { ThreadPool.class })) {
/* 191 */       server = new Jetty9ServerFactory(null).createServer(getThreadPool());
/*     */     }
/*     */     else {
/* 194 */       server = new Jetty8ServerFactory(null).createServer(getThreadPool());
/*     */     }
/* 196 */     server.setConnectors(new Connector[] { createConnector(address, server) });
/* 197 */     return server;
/*     */   }
/*     */   
/*     */   private AbstractConnector createConnector(InetSocketAddress address, Server server) {
/* 201 */     if (ClassUtils.isPresent("org.eclipse.jetty.server.nio.SelectChannelConnector", getClass().getClassLoader())) {
/* 202 */       return new Jetty8ConnectorFactory(null).createConnector(server, address, this.acceptors, this.selectors);
/*     */     }
/*     */     
/* 205 */     return new Jetty9ConnectorFactory(null).createConnector(server, address, this.acceptors, this.selectors);
/*     */   }
/*     */   
/*     */   private Handler addHandlerWrappers(Handler handler)
/*     */   {
/* 210 */     if ((getCompression() != null) && (getCompression().getEnabled())) {
/* 211 */       handler = applyWrapper(handler, createGzipHandler());
/*     */     }
/* 213 */     if (StringUtils.hasText(getServerHeader())) {
/* 214 */       handler = applyWrapper(handler, new ServerHeaderHandler(getServerHeader()));
/*     */     }
/* 216 */     return handler;
/*     */   }
/*     */   
/*     */   private Handler applyWrapper(Handler handler, HandlerWrapper wrapper) {
/* 220 */     wrapper.setHandler(handler);
/* 221 */     return wrapper;
/*     */   }
/*     */   
/*     */   private HandlerWrapper createGzipHandler() {
/* 225 */     ClassLoader classLoader = getClass().getClassLoader();
/* 226 */     if (ClassUtils.isPresent("org.eclipse.jetty.servlets.gzip.GzipHandler", classLoader)) {
/* 227 */       return new Jetty92GzipHandlerFactory(null).createGzipHandler(getCompression());
/*     */     }
/* 229 */     if (ClassUtils.isPresent("org.eclipse.jetty.server.handler.GzipHandler", getClass().getClassLoader())) {
/* 230 */       return new Jetty8GzipHandlerFactory(null).createGzipHandler(getCompression());
/*     */     }
/* 232 */     if (ClassUtils.isPresent("org.eclipse.jetty.server.handler.gzip.GzipHandler", getClass().getClassLoader())) {
/* 233 */       return new Jetty93GzipHandlerFactory(null).createGzipHandler(getCompression());
/*     */     }
/* 235 */     throw new IllegalStateException("Compression is enabled, but GzipHandler is not on the classpath");
/*     */   }
/*     */   
/*     */   private SslServerConnectorFactory getSslServerConnectorFactory()
/*     */   {
/* 240 */     if (ClassUtils.isPresent("org.eclipse.jetty.server.ssl.SslSocketConnector", null))
/*     */     {
/* 242 */       return new Jetty8SslServerConnectorFactory(null);
/*     */     }
/* 244 */     return new Jetty9SslServerConnectorFactory(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void configureSsl(SslContextFactory factory, Ssl ssl)
/*     */   {
/* 253 */     factory.setProtocol(ssl.getProtocol());
/* 254 */     configureSslClientAuth(factory, ssl);
/* 255 */     configureSslPasswords(factory, ssl);
/* 256 */     factory.setCertAlias(ssl.getKeyAlias());
/* 257 */     if (!ObjectUtils.isEmpty(ssl.getCiphers())) {
/* 258 */       factory.setIncludeCipherSuites(ssl.getCiphers());
/* 259 */       factory.setExcludeCipherSuites(new String[0]);
/*     */     }
/* 261 */     if (ssl.getEnabledProtocols() != null) {
/* 262 */       factory.setIncludeProtocols(ssl.getEnabledProtocols());
/*     */     }
/* 264 */     if (getSslStoreProvider() != null) {
/*     */       try {
/* 266 */         factory.setKeyStore(getSslStoreProvider().getKeyStore());
/* 267 */         factory.setTrustStore(getSslStoreProvider().getTrustStore());
/*     */       }
/*     */       catch (Exception ex) {
/* 270 */         throw new IllegalStateException("Unable to set SSL store", ex);
/*     */       }
/*     */     }
/*     */     else {
/* 274 */       configureSslKeyStore(factory, ssl);
/* 275 */       configureSslTrustStore(factory, ssl);
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureSslClientAuth(SslContextFactory factory, Ssl ssl) {
/* 280 */     if (ssl.getClientAuth() == Ssl.ClientAuth.NEED) {
/* 281 */       factory.setNeedClientAuth(true);
/* 282 */       factory.setWantClientAuth(true);
/*     */     }
/* 284 */     else if (ssl.getClientAuth() == Ssl.ClientAuth.WANT) {
/* 285 */       factory.setWantClientAuth(true);
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureSslPasswords(SslContextFactory factory, Ssl ssl) {
/* 290 */     if (ssl.getKeyStorePassword() != null) {
/* 291 */       factory.setKeyStorePassword(ssl.getKeyStorePassword());
/*     */     }
/* 293 */     if (ssl.getKeyPassword() != null) {
/* 294 */       factory.setKeyManagerPassword(ssl.getKeyPassword());
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureSslKeyStore(SslContextFactory factory, Ssl ssl) {
/*     */     try {
/* 300 */       URL url = ResourceUtils.getURL(ssl.getKeyStore());
/* 301 */       factory.setKeyStoreResource(Resource.newResource(url));
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 305 */       throw new EmbeddedServletContainerException("Could not find key store '" + ssl.getKeyStore() + "'", ex);
/*     */     }
/* 307 */     if (ssl.getKeyStoreType() != null) {
/* 308 */       factory.setKeyStoreType(ssl.getKeyStoreType());
/*     */     }
/* 310 */     if (ssl.getKeyStoreProvider() != null) {
/* 311 */       factory.setKeyStoreProvider(ssl.getKeyStoreProvider());
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureSslTrustStore(SslContextFactory factory, Ssl ssl) {
/* 316 */     if (ssl.getTrustStorePassword() != null) {
/* 317 */       factory.setTrustStorePassword(ssl.getTrustStorePassword());
/*     */     }
/* 319 */     if (ssl.getTrustStore() != null) {
/*     */       try {
/* 321 */         URL url = ResourceUtils.getURL(ssl.getTrustStore());
/* 322 */         factory.setTrustStoreResource(Resource.newResource(url));
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/* 326 */         throw new EmbeddedServletContainerException("Could not find trust store '" + ssl.getTrustStore() + "'", ex);
/*     */       }
/*     */     }
/* 329 */     if (ssl.getTrustStoreType() != null) {
/* 330 */       factory.setTrustStoreType(ssl.getTrustStoreType());
/*     */     }
/* 332 */     if (ssl.getTrustStoreProvider() != null) {
/* 333 */       factory.setTrustStoreProvider(ssl.getTrustStoreProvider());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void configureWebAppContext(WebAppContext context, ServletContextInitializer... initializers)
/*     */   {
/* 344 */     Assert.notNull(context, "Context must not be null");
/* 345 */     context.setTempDirectory(getTempDirectory());
/* 346 */     if (this.resourceLoader != null) {
/* 347 */       context.setClassLoader(this.resourceLoader.getClassLoader());
/*     */     }
/* 349 */     String contextPath = getContextPath();
/* 350 */     context.setContextPath(StringUtils.hasLength(contextPath) ? contextPath : "/");
/* 351 */     context.setDisplayName(getDisplayName());
/* 352 */     configureDocumentRoot(context);
/* 353 */     if (isRegisterDefaultServlet()) {
/* 354 */       addDefaultServlet(context);
/*     */     }
/* 356 */     if (shouldRegisterJspServlet()) {
/* 357 */       addJspServlet(context);
/* 358 */       context.addBean(new JasperInitializer(context), true);
/*     */     }
/* 360 */     addLocaleMappings(context);
/* 361 */     ServletContextInitializer[] initializersToUse = mergeInitializers(initializers);
/* 362 */     Configuration[] configurations = getWebAppContextConfigurations(context, initializersToUse);
/*     */     
/* 364 */     context.setConfigurations(configurations);
/* 365 */     configureSession(context);
/* 366 */     postProcessWebAppContext(context);
/*     */   }
/*     */   
/*     */   private void addLocaleMappings(WebAppContext context) {
/* 370 */     for (Map.Entry<Locale, Charset> entry : getLocaleCharsetMappings().entrySet()) {
/* 371 */       Locale locale = (Locale)entry.getKey();
/* 372 */       Charset charset = (Charset)entry.getValue();
/* 373 */       context.addLocaleEncoding(locale.toString(), charset.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureSession(WebAppContext context) {
/* 378 */     SessionManager sessionManager = context.getSessionHandler().getSessionManager();
/* 379 */     int sessionTimeout = getSessionTimeout() > 0 ? getSessionTimeout() : -1;
/* 380 */     sessionManager.setMaxInactiveInterval(sessionTimeout);
/* 381 */     if (isPersistSession()) {
/* 382 */       Assert.isInstanceOf(HashSessionManager.class, sessionManager, "Unable to use persistent sessions");
/*     */       
/* 384 */       configurePersistSession(sessionManager);
/*     */     }
/*     */   }
/*     */   
/*     */   private void configurePersistSession(SessionManager sessionManager)
/*     */   {
/*     */     try {
/* 391 */       ((HashSessionManager)sessionManager).setStoreDirectory(getValidSessionStoreDir());
/*     */     }
/*     */     catch (IOException ex) {
/* 394 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private File getTempDirectory() {
/* 399 */     String temp = System.getProperty("java.io.tmpdir");
/* 400 */     return temp == null ? null : new File(temp);
/*     */   }
/*     */   
/*     */   private void configureDocumentRoot(WebAppContext handler) {
/* 404 */     File root = getValidDocumentRoot();
/* 405 */     root = root != null ? root : createTempDir("jetty-docbase");
/*     */     try {
/* 407 */       if (!root.isDirectory())
/*     */       {
/* 409 */         Resource resource = JarResource.newJarResource(Resource.newResource(root));
/* 410 */         handler.setBaseResource(resource);
/*     */       }
/*     */       else {
/* 413 */         handler.setBaseResource(Resource.newResource(root.getCanonicalFile()));
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 417 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void addDefaultServlet(WebAppContext context)
/*     */   {
/* 426 */     Assert.notNull(context, "Context must not be null");
/* 427 */     ServletHolder holder = new ServletHolder();
/* 428 */     holder.setName("default");
/* 429 */     holder.setClassName("org.eclipse.jetty.servlet.DefaultServlet");
/* 430 */     holder.setInitParameter("dirAllowed", "false");
/* 431 */     holder.setInitOrder(1);
/* 432 */     context.getServletHandler().addServletWithMapping(holder, "/");
/* 433 */     context.getServletHandler().getServletMapping("/").setDefault(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void addJspServlet(WebAppContext context)
/*     */   {
/* 441 */     Assert.notNull(context, "Context must not be null");
/* 442 */     ServletHolder holder = new ServletHolder();
/* 443 */     holder.setName("jsp");
/* 444 */     holder.setClassName(getJspServlet().getClassName());
/* 445 */     holder.setInitParameter("fork", "false");
/* 446 */     holder.setInitParameters(getJspServlet().getInitParameters());
/* 447 */     holder.setInitOrder(3);
/* 448 */     context.getServletHandler().addServlet(holder);
/* 449 */     ServletMapping mapping = new ServletMapping();
/* 450 */     mapping.setServletName("jsp");
/* 451 */     mapping.setPathSpecs(new String[] { "*.jsp", "*.jspx" });
/* 452 */     context.getServletHandler().addServletMapping(mapping);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Configuration[] getWebAppContextConfigurations(WebAppContext webAppContext, ServletContextInitializer... initializers)
/*     */   {
/* 463 */     List<Configuration> configurations = new ArrayList();
/* 464 */     configurations.add(
/* 465 */       getServletContextInitializerConfiguration(webAppContext, initializers));
/* 466 */     configurations.addAll(getConfigurations());
/* 467 */     configurations.add(getErrorPageConfiguration());
/* 468 */     configurations.add(getMimeTypeConfiguration());
/* 469 */     return (Configuration[])configurations.toArray(new Configuration[configurations.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Configuration getErrorPageConfiguration()
/*     */   {
/* 477 */     new AbstractConfiguration()
/*     */     {
/*     */       public void configure(WebAppContext context) throws Exception
/*     */       {
/* 481 */         ErrorHandler errorHandler = context.getErrorHandler();
/* 482 */         context.setErrorHandler(new JettyEmbeddedErrorHandler(errorHandler));
/* 483 */         JettyEmbeddedServletContainerFactory.this.addJettyErrorPages(errorHandler, JettyEmbeddedServletContainerFactory.this.getErrorPages());
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Configuration getMimeTypeConfiguration()
/*     */   {
/* 494 */     new AbstractConfiguration()
/*     */     {
/*     */       public void configure(WebAppContext context) throws Exception
/*     */       {
/* 498 */         MimeTypes mimeTypes = context.getMimeTypes();
/* 499 */         for (MimeMappings.Mapping mapping : JettyEmbeddedServletContainerFactory.this.getMimeMappings()) {
/* 500 */           mimeTypes.addMimeMapping(mapping.getExtension(), mapping
/* 501 */             .getMimeType());
/*     */         }
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Configuration getServletContextInitializerConfiguration(WebAppContext webAppContext, ServletContextInitializer... initializers)
/*     */   {
/* 518 */     return new ServletContextInitializerConfiguration(initializers);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void postProcessWebAppContext(WebAppContext webAppContext) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JettyEmbeddedServletContainer getJettyEmbeddedServletContainer(Server server)
/*     */   {
/* 540 */     return new JettyEmbeddedServletContainer(server, getPort() >= 0);
/*     */   }
/*     */   
/*     */   public void setResourceLoader(ResourceLoader resourceLoader)
/*     */   {
/* 545 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUseForwardHeaders(boolean useForwardHeaders)
/*     */   {
/* 554 */     this.useForwardHeaders = useForwardHeaders;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAcceptors(int acceptors)
/*     */   {
/* 563 */     this.acceptors = acceptors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSelectors(int selectors)
/*     */   {
/* 572 */     this.selectors = selectors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setServerCustomizers(Collection<? extends JettyServerCustomizer> customizers)
/*     */   {
/* 582 */     Assert.notNull(customizers, "Customizers must not be null");
/* 583 */     this.jettyServerCustomizers = new ArrayList(customizers);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<JettyServerCustomizer> getServerCustomizers()
/*     */   {
/* 592 */     return this.jettyServerCustomizers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addServerCustomizers(JettyServerCustomizer... customizers)
/*     */   {
/* 601 */     Assert.notNull(customizers, "Customizers must not be null");
/* 602 */     this.jettyServerCustomizers.addAll(Arrays.asList(customizers));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConfigurations(Collection<? extends Configuration> configurations)
/*     */   {
/* 612 */     Assert.notNull(configurations, "Configurations must not be null");
/* 613 */     this.configurations = new ArrayList(configurations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<Configuration> getConfigurations()
/*     */   {
/* 622 */     return this.configurations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addConfigurations(Configuration... configurations)
/*     */   {
/* 631 */     Assert.notNull(configurations, "Configurations must not be null");
/* 632 */     this.configurations.addAll(Arrays.asList(configurations));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ThreadPool getThreadPool()
/*     */   {
/* 640 */     return this.threadPool;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setThreadPool(ThreadPool threadPool)
/*     */   {
/* 649 */     this.threadPool = threadPool;
/*     */   }
/*     */   
/*     */   private void addJettyErrorPages(ErrorHandler errorHandler, Collection<ErrorPage> errorPages) {
/*     */     ErrorPageErrorHandler handler;
/* 654 */     if ((errorHandler instanceof ErrorPageErrorHandler)) {
/* 655 */       handler = (ErrorPageErrorHandler)errorHandler;
/* 656 */       for (ErrorPage errorPage : errorPages) {
/* 657 */         if (errorPage.isGlobal()) {
/* 658 */           handler.addErrorPage("org.eclipse.jetty.server.error_page.global", errorPage
/* 659 */             .getPath());
/*     */ 
/*     */         }
/* 662 */         else if (errorPage.getExceptionName() != null) {
/* 663 */           handler.addErrorPage(errorPage.getExceptionName(), errorPage
/* 664 */             .getPath());
/*     */         }
/*     */         else {
/* 667 */           handler.addErrorPage(errorPage.getStatusCode(), errorPage
/* 668 */             .getPath());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static abstract interface SslServerConnectorFactory
/*     */   {
/*     */     public abstract AbstractConnector getConnector(Server paramServer, SslContextFactory paramSslContextFactory, int paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class Jetty9SslServerConnectorFactory
/*     */     implements JettyEmbeddedServletContainerFactory.SslServerConnectorFactory
/*     */   {
/*     */     public ServerConnector getConnector(Server server, SslContextFactory sslContextFactory, int port)
/*     */     {
/* 694 */       HttpConfiguration config = new HttpConfiguration();
/* 695 */       config.addCustomizer(new SecureRequestCustomizer());
/* 696 */       HttpConnectionFactory connectionFactory = new HttpConnectionFactory(config);
/*     */       
/* 698 */       SslConnectionFactory sslConnectionFactory = new SslConnectionFactory(sslContextFactory, HttpVersion.HTTP_1_1.asString());
/* 699 */       ServerConnector serverConnector = new ServerConnector(server, new ConnectionFactory[] { sslConnectionFactory, connectionFactory });
/*     */       
/* 701 */       serverConnector.setPort(port);
/* 702 */       return serverConnector;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class Jetty8SslServerConnectorFactory
/*     */     implements JettyEmbeddedServletContainerFactory.SslServerConnectorFactory
/*     */   {
/*     */     public AbstractConnector getConnector(Server server, SslContextFactory sslContextFactory, int port)
/*     */     {
/*     */       try
/*     */       {
/* 717 */         Class<?> connectorClass = Class.forName("org.eclipse.jetty.server.ssl.SslSocketConnector");
/*     */         
/*     */ 
/* 720 */         AbstractConnector connector = (AbstractConnector)connectorClass.getConstructor(new Class[] { SslContextFactory.class }).newInstance(new Object[] { sslContextFactory });
/* 721 */         connector.getClass().getMethod("setPort", new Class[] { Integer.TYPE }).invoke(connector, new Object[] {
/* 722 */           Integer.valueOf(port) });
/* 723 */         return connector;
/*     */       }
/*     */       catch (Exception ex) {
/* 726 */         throw new IllegalStateException(ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static abstract interface GzipHandlerFactory
/*     */   {
/*     */     public abstract HandlerWrapper createGzipHandler(Compression paramCompression);
/*     */   }
/*     */   
/*     */   private static class Jetty8GzipHandlerFactory
/*     */     implements JettyEmbeddedServletContainerFactory.GzipHandlerFactory
/*     */   {
/*     */     public HandlerWrapper createGzipHandler(Compression compression)
/*     */     {
/*     */       try
/*     */       {
/* 743 */         Class<?> handlerClass = ClassUtils.forName("org.eclipse.jetty.server.handler.GzipHandler", 
/* 744 */           getClass().getClassLoader());
/* 745 */         HandlerWrapper handler = (HandlerWrapper)handlerClass.newInstance();
/* 746 */         ReflectionUtils.findMethod(handlerClass, "setMinGzipSize", new Class[] { Integer.TYPE })
/* 747 */           .invoke(handler, new Object[] {Integer.valueOf(compression.getMinResponseSize()) });
/* 748 */         ReflectionUtils.findMethod(handlerClass, "setMimeTypes", new Class[] { Set.class })
/* 749 */           .invoke(handler, new Object[] { new HashSet(
/* 750 */           Arrays.asList(compression.getMimeTypes())) });
/* 751 */         if (compression.getExcludedUserAgents() != null)
/*     */         {
/* 753 */           ReflectionUtils.findMethod(handlerClass, "setExcluded", new Class[] { Set.class }).invoke(handler, new Object[] { new HashSet(
/* 754 */             Arrays.asList(compression.getExcludedUserAgents())) });
/*     */         }
/* 756 */         return handler;
/*     */       }
/*     */       catch (Exception ex) {
/* 759 */         throw new RuntimeException("Failed to configure Jetty 8 gzip handler", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Jetty92GzipHandlerFactory
/*     */     implements JettyEmbeddedServletContainerFactory.GzipHandlerFactory
/*     */   {
/*     */     public HandlerWrapper createGzipHandler(Compression compression)
/*     */     {
/*     */       try
/*     */       {
/* 771 */         Class<?> handlerClass = ClassUtils.forName("org.eclipse.jetty.servlets.gzip.GzipHandler", 
/* 772 */           getClass().getClassLoader());
/* 773 */         HandlerWrapper gzipHandler = (HandlerWrapper)handlerClass.newInstance();
/* 774 */         ReflectionUtils.findMethod(handlerClass, "setMinGzipSize", new Class[] { Integer.TYPE })
/* 775 */           .invoke(gzipHandler, new Object[] {Integer.valueOf(compression.getMinResponseSize()) });
/*     */         
/* 777 */         ReflectionUtils.findMethod(handlerClass, "addIncludedMimeTypes", new Class[] { String[].class })
/* 778 */           .invoke(gzipHandler, new Object[] {compression.getMimeTypes() });
/* 779 */         if (compression.getExcludedUserAgents() != null)
/*     */         {
/* 781 */           ReflectionUtils.findMethod(handlerClass, "setExcluded", new Class[] { Set.class }).invoke(gzipHandler, new Object[] { new HashSet(
/* 782 */             Arrays.asList(compression.getExcludedUserAgents())) });
/*     */         }
/* 784 */         return gzipHandler;
/*     */       }
/*     */       catch (Exception ex) {
/* 787 */         throw new RuntimeException("Failed to configure Jetty 9.2 gzip handler", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class Jetty93GzipHandlerFactory
/*     */     implements JettyEmbeddedServletContainerFactory.GzipHandlerFactory
/*     */   {
/*     */     public HandlerWrapper createGzipHandler(Compression compression)
/*     */     {
/* 798 */       GzipHandler handler = new GzipHandler();
/* 799 */       handler.setMinGzipSize(compression.getMinResponseSize());
/* 800 */       handler.setIncludedMimeTypes(compression.getMimeTypes());
/* 801 */       if (compression.getExcludedUserAgents() != null) {
/* 802 */         handler.setExcludedAgentPatterns(compression.getExcludedUserAgents());
/*     */       }
/* 804 */       return handler;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class ForwardHeadersCustomizer
/*     */     implements JettyServerCustomizer
/*     */   {
/*     */     public void customize(Server server)
/*     */     {
/* 817 */       ForwardedRequestCustomizer customizer = new ForwardedRequestCustomizer();
/* 818 */       for (Connector connector : server.getConnectors()) {
/* 819 */         for (ConnectionFactory connectionFactory : connector
/* 820 */           .getConnectionFactories()) {
/* 821 */           if ((connectionFactory instanceof HttpConfiguration.ConnectionFactory))
/*     */           {
/* 823 */             ((HttpConfiguration.ConnectionFactory)connectionFactory).getHttpConfiguration().addCustomizer(customizer);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class ServerHeaderHandler
/*     */     extends HandlerWrapper
/*     */   {
/*     */     private static final String SERVER_HEADER = "server";
/*     */     
/*     */     private final String value;
/*     */     
/*     */ 
/*     */     ServerHeaderHandler(String value)
/*     */     {
/* 841 */       this.value = value;
/*     */     }
/*     */     
/*     */     public void handle(String target, Request baseRequest, HttpServletRequest request, HttpServletResponse response)
/*     */       throws IOException, ServletException
/*     */     {
/* 847 */       if (!response.getHeaderNames().contains("server")) {
/* 848 */         response.setHeader("server", this.value);
/*     */       }
/* 850 */       super.handle(target, baseRequest, request, response);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static abstract interface ConnectorFactory
/*     */   {
/*     */     public abstract AbstractConnector createConnector(Server paramServer, InetSocketAddress paramInetSocketAddress, int paramInt1, int paramInt2);
/*     */   }
/*     */   
/*     */ 
/*     */   private static class Jetty8ConnectorFactory
/*     */     implements JettyEmbeddedServletContainerFactory.ConnectorFactory
/*     */   {
/*     */     public AbstractConnector createConnector(Server server, InetSocketAddress address, int acceptors, int selectors)
/*     */     {
/*     */       try
/*     */       {
/* 868 */         Class<?> connectorClass = ClassUtils.forName("org.eclipse.jetty.server.nio.SelectChannelConnector", 
/* 869 */           getClass().getClassLoader());
/*     */         
/* 871 */         AbstractConnector connector = (AbstractConnector)connectorClass.newInstance();
/* 872 */         ReflectionUtils.findMethod(connectorClass, "setPort", new Class[] { Integer.TYPE })
/* 873 */           .invoke(connector, new Object[] {Integer.valueOf(address.getPort()) });
/* 874 */         ReflectionUtils.findMethod(connectorClass, "setHost", new Class[] { String.class })
/* 875 */           .invoke(connector, new Object[] {address.getHostName() });
/* 876 */         if (acceptors > 0)
/*     */         {
/* 878 */           ReflectionUtils.findMethod(connectorClass, "setAcceptors", new Class[] { Integer.TYPE }).invoke(connector, new Object[] { Integer.valueOf(acceptors) });
/*     */         }
/* 880 */         if (selectors > 0)
/*     */         {
/*     */ 
/* 883 */           Object selectorManager = ReflectionUtils.findMethod(connectorClass, "getSelectorManager").invoke(connector, new Object[0]);
/* 884 */           ReflectionUtils.findMethod(selectorManager.getClass(), "setSelectSets", new Class[] { Integer.TYPE })
/*     */           
/* 886 */             .invoke(selectorManager, new Object[] {Integer.valueOf(selectors) });
/*     */         }
/*     */         
/* 889 */         return connector;
/*     */       }
/*     */       catch (Exception ex) {
/* 892 */         throw new RuntimeException("Failed to configure Jetty 8 connector", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class Jetty9ConnectorFactory
/*     */     implements JettyEmbeddedServletContainerFactory.ConnectorFactory
/*     */   {
/*     */     public AbstractConnector createConnector(Server server, InetSocketAddress address, int acceptors, int selectors)
/*     */     {
/* 903 */       ServerConnector connector = new ServerConnector(server, acceptors, selectors);
/* 904 */       connector.setHost(address.getHostName());
/* 905 */       connector.setPort(address.getPort());
/* 906 */       for (ConnectionFactory connectionFactory : connector
/* 907 */         .getConnectionFactories()) {
/* 908 */         if ((connectionFactory instanceof HttpConfiguration.ConnectionFactory))
/*     */         {
/* 910 */           ((HttpConfiguration.ConnectionFactory)connectionFactory).getHttpConfiguration().setSendServerVersion(false);
/*     */         }
/*     */       }
/* 913 */       return connector;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static abstract interface ServerFactory
/*     */   {
/*     */     public abstract Server createServer(ThreadPool paramThreadPool);
/*     */   }
/*     */   
/*     */   private static class Jetty8ServerFactory
/*     */     implements JettyEmbeddedServletContainerFactory.ServerFactory
/*     */   {
/*     */     public Server createServer(ThreadPool threadPool)
/*     */     {
/* 928 */       Server server = new Server();
/*     */       
/*     */       try
/*     */       {
/* 932 */         ReflectionUtils.findMethod(Server.class, "setThreadPool", new Class[] { ThreadPool.class }).invoke(server, new Object[] { threadPool });
/*     */       }
/*     */       catch (Exception ex) {
/* 935 */         throw new RuntimeException("Failed to configure Jetty 8 ThreadPool", ex);
/*     */       }
/*     */       
/*     */       try
/*     */       {
/* 940 */         ReflectionUtils.findMethod(Server.class, "setSendServerVersion", new Class[] { Boolean.TYPE }).invoke(server, new Object[] { Boolean.valueOf(false) });
/*     */       }
/*     */       catch (Exception ex) {
/* 943 */         throw new RuntimeException("Failed to disable Server header", ex);
/*     */       }
/* 945 */       return server;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Jetty9ServerFactory
/*     */     implements JettyEmbeddedServletContainerFactory.ServerFactory
/*     */   {
/*     */     public Server createServer(ThreadPool threadPool)
/*     */     {
/* 954 */       return new Server(threadPool);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\embedded\jetty\JettyEmbeddedServletContainerFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */