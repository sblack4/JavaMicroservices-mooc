/*    */ package org.springframework.boot.context.embedded.tomcat;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.apache.catalina.Container;
/*    */ import org.apache.catalina.Loader;
/*    */ import org.apache.catalina.core.StandardContext;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.util.ReflectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TomcatEmbeddedContext
/*    */   extends StandardContext
/*    */ {
/*    */   private TomcatStarter starter;
/*    */   private final boolean overrideLoadOnStart;
/*    */   
/*    */   TomcatEmbeddedContext()
/*    */   {
/* 41 */     this.overrideLoadOnStart = (ReflectionUtils.findMethod(StandardContext.class, "loadOnStartup", new Class[] { Container[].class }).getReturnType() == Boolean.TYPE);
/*    */   }
/*    */   
/*    */   public boolean loadOnStartup(Container[] children)
/*    */   {
/* 46 */     if (this.overrideLoadOnStart) {
/* 47 */       return true;
/*    */     }
/* 49 */     return super.loadOnStartup(children);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void deferredLoadOnStartup()
/*    */   {
/* 58 */     ClassLoader classLoader = getLoader().getClassLoader();
/* 59 */     ClassLoader existingLoader = null;
/* 60 */     if (classLoader != null) {
/* 61 */       existingLoader = ClassUtils.overrideThreadContextClassLoader(classLoader);
/*    */     }
/*    */     
/* 64 */     if (this.overrideLoadOnStart)
/*    */     {
/*    */ 
/*    */ 
/* 68 */       super.loadOnStartup(findChildren());
/*    */     }
/* 70 */     if (existingLoader != null) {
/* 71 */       ClassUtils.overrideThreadContextClassLoader(existingLoader);
/*    */     }
/*    */   }
/*    */   
/*    */   public void setStarter(TomcatStarter starter) {
/* 76 */     this.starter = starter;
/*    */   }
/*    */   
/*    */   public TomcatStarter getStarter() {
/* 80 */     return this.starter;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\embedded\tomcat\TomcatEmbeddedContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */