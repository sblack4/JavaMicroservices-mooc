/*    */ package org.springframework.boot.context.web;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class ServletContextApplicationContextInitializer
/*    */   extends org.springframework.boot.web.support.ServletContextApplicationContextInitializer
/*    */ {
/*    */   public ServletContextApplicationContextInitializer(ServletContext servletContext, boolean addApplicationContextAttribute)
/*    */   {
/* 37 */     super(servletContext, addApplicationContextAttribute);
/*    */   }
/*    */   
/*    */   public ServletContextApplicationContextInitializer(ServletContext servletContext) {
/* 41 */     super(servletContext);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\web\ServletContextApplicationContextInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */