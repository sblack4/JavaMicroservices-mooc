/*    */ package org.springframework.boot.context.event;
/*    */ 
/*    */ import org.springframework.boot.SpringApplication;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SpringApplicationEvent
/*    */   extends ApplicationEvent
/*    */ {
/*    */   private final String[] args;
/*    */   
/*    */   public SpringApplicationEvent(SpringApplication application, String[] args)
/*    */   {
/* 33 */     super(application);
/* 34 */     this.args = args;
/*    */   }
/*    */   
/*    */   public SpringApplication getSpringApplication() {
/* 38 */     return (SpringApplication)getSource();
/*    */   }
/*    */   
/*    */   public final String[] getArgs() {
/* 42 */     return this.args;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\event\SpringApplicationEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */