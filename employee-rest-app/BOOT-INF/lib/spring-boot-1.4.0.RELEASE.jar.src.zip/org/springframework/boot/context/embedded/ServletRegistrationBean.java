/*    */ package org.springframework.boot.context.embedded;
/*    */ 
/*    */ import javax.servlet.Servlet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class ServletRegistrationBean
/*    */   extends org.springframework.boot.web.servlet.ServletRegistrationBean
/*    */   implements ServletContextInitializer
/*    */ {
/*    */   public ServletRegistrationBean() {}
/*    */   
/*    */   public ServletRegistrationBean(Servlet servlet, boolean alwaysMapUrl, String... urlMappings)
/*    */   {
/* 52 */     super(servlet, alwaysMapUrl, urlMappings);
/*    */   }
/*    */   
/*    */   public ServletRegistrationBean(Servlet servlet, String... urlMappings) {
/* 56 */     super(servlet, urlMappings);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\embedded\ServletRegistrationBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */