/*     */ package org.springframework.boot.context.properties;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.boot.bind.PropertiesConfigurationFactory;
/*     */ import org.springframework.boot.env.PropertySourcesLoader;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.context.event.ContextRefreshedEvent;
/*     */ import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
/*     */ import org.springframework.core.PriorityOrdered;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.core.convert.support.DefaultConversionService;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.core.env.PropertySources;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.validation.Validator;
/*     */ import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigurationPropertiesBindingPostProcessor
/*     */   implements BeanPostProcessor, BeanFactoryAware, ResourceLoaderAware, EnvironmentAware, ApplicationContextAware, InitializingBean, DisposableBean, ApplicationListener<ContextRefreshedEvent>, PriorityOrdered
/*     */ {
/*     */   public static final String VALIDATOR_BEAN_NAME = "configurationPropertiesValidator";
/*  90 */   private static final String[] VALIDATOR_CLASSES = { "javax.validation.Validator", "javax.validation.ValidatorFactory" };
/*     */   
/*     */ 
/*     */ 
/*  94 */   private static final Log logger = LogFactory.getLog(ConfigurationPropertiesBindingPostProcessor.class);
/*     */   
/*  96 */   private ConfigurationBeanFactoryMetaData beans = new ConfigurationBeanFactoryMetaData();
/*     */   
/*     */   private PropertySources propertySources;
/*     */   
/*     */   private Validator validator;
/*     */   
/*     */   private volatile Validator localValidator;
/*     */   
/*     */   private ConversionService conversionService;
/*     */   
/*     */   private DefaultConversionService defaultConversionService;
/*     */   
/*     */   private BeanFactory beanFactory;
/*     */   
/* 110 */   private ResourceLoader resourceLoader = new DefaultResourceLoader();
/*     */   
/* 112 */   private Environment environment = new StandardEnvironment();
/*     */   
/*     */   private ApplicationContext applicationContext;
/*     */   
/* 116 */   private List<Converter<?, ?>> converters = Collections.emptyList();
/*     */   
/* 118 */   private List<GenericConverter> genericConverters = Collections.emptyList();
/*     */   
/* 120 */   private int order = -2147483647;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Autowired(required=false)
/*     */   @ConfigurationPropertiesBinding
/*     */   public void setConverters(List<Converter<?, ?>> converters)
/*     */   {
/* 130 */     this.converters = converters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Autowired(required=false)
/*     */   @ConfigurationPropertiesBinding
/*     */   public void setGenericConverters(List<GenericConverter> converters)
/*     */   {
/* 141 */     this.genericConverters = converters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOrder(int order)
/*     */   {
/* 149 */     this.order = order;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOrder()
/*     */   {
/* 158 */     return this.order;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPropertySources(PropertySources propertySources)
/*     */   {
/* 166 */     this.propertySources = propertySources;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValidator(Validator validator)
/*     */   {
/* 174 */     this.validator = validator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConversionService(ConversionService conversionService)
/*     */   {
/* 182 */     this.conversionService = conversionService;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBeanMetaDataStore(ConfigurationBeanFactoryMetaData beans)
/*     */   {
/* 190 */     this.beans = beans;
/*     */   }
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException
/*     */   {
/* 195 */     this.beanFactory = beanFactory;
/*     */   }
/*     */   
/*     */   public void setResourceLoader(ResourceLoader resourceLoader)
/*     */   {
/* 200 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */   
/*     */   public void setEnvironment(Environment environment)
/*     */   {
/* 205 */     this.environment = environment;
/*     */   }
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext)
/*     */   {
/* 210 */     this.applicationContext = applicationContext;
/*     */   }
/*     */   
/*     */   public void afterPropertiesSet() throws Exception
/*     */   {
/* 215 */     if (this.propertySources == null) {
/* 216 */       this.propertySources = deducePropertySources();
/*     */     }
/* 218 */     if (this.validator == null) {
/* 219 */       this.validator = ((Validator)getOptionalBean("configurationPropertiesValidator", Validator.class));
/*     */     }
/* 221 */     if (this.conversionService == null) {
/* 222 */       this.conversionService = ((ConversionService)getOptionalBean("conversionService", ConversionService.class));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void onApplicationEvent(ContextRefreshedEvent event)
/*     */   {
/* 230 */     freeLocalValidator();
/*     */   }
/*     */   
/*     */   public void destroy() throws Exception
/*     */   {
/* 235 */     freeLocalValidator();
/*     */   }
/*     */   
/*     */   private void freeLocalValidator() {
/*     */     try {
/* 240 */       Validator validator = this.localValidator;
/* 241 */       this.localValidator = null;
/* 242 */       if (validator != null) {
/* 243 */         ((DisposableBean)validator).destroy();
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 247 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private PropertySources deducePropertySources() {
/* 252 */     PropertySourcesPlaceholderConfigurer configurer = getSinglePropertySourcesPlaceholderConfigurer();
/* 253 */     if (configurer != null)
/*     */     {
/* 255 */       return new FlatPropertySources(configurer.getAppliedPropertySources());
/*     */     }
/* 257 */     if ((this.environment instanceof ConfigurableEnvironment))
/*     */     {
/* 259 */       MutablePropertySources propertySources = ((ConfigurableEnvironment)this.environment).getPropertySources();
/* 260 */       return new FlatPropertySources(propertySources);
/*     */     }
/*     */     
/* 263 */     logger.warn("Unable to obtain PropertySources from PropertySourcesPlaceholderConfigurer or Environment");
/*     */     
/* 265 */     return new MutablePropertySources();
/*     */   }
/*     */   
/*     */   private PropertySourcesPlaceholderConfigurer getSinglePropertySourcesPlaceholderConfigurer()
/*     */   {
/* 270 */     if ((this.beanFactory instanceof ListableBeanFactory)) {
/* 271 */       ListableBeanFactory listableBeanFactory = (ListableBeanFactory)this.beanFactory;
/*     */       
/* 273 */       Map<String, PropertySourcesPlaceholderConfigurer> beans = listableBeanFactory.getBeansOfType(PropertySourcesPlaceholderConfigurer.class, false, false);
/*     */       
/* 275 */       if (beans.size() == 1) {
/* 276 */         return (PropertySourcesPlaceholderConfigurer)beans.values().iterator().next();
/*     */       }
/* 278 */       if ((beans.size() > 1) && (logger.isWarnEnabled())) {
/* 279 */         logger.warn("Multiple PropertySourcesPlaceholderConfigurer beans registered " + beans
/* 280 */           .keySet() + ", falling back to Environment");
/*     */       }
/*     */     }
/*     */     
/* 284 */     return null;
/*     */   }
/*     */   
/*     */   private <T> T getOptionalBean(String name, Class<T> type) {
/*     */     try {
/* 289 */       return (T)this.beanFactory.getBean(name, type);
/*     */     }
/*     */     catch (NoSuchBeanDefinitionException ex) {}
/* 292 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object postProcessBeforeInitialization(Object bean, String beanName)
/*     */     throws BeansException
/*     */   {
/* 300 */     ConfigurationProperties annotation = (ConfigurationProperties)AnnotationUtils.findAnnotation(bean.getClass(), ConfigurationProperties.class);
/* 301 */     if (annotation != null) {
/* 302 */       postProcessBeforeInitialization(bean, beanName, annotation);
/*     */     }
/* 304 */     annotation = (ConfigurationProperties)this.beans.findFactoryAnnotation(beanName, ConfigurationProperties.class);
/*     */     
/* 306 */     if (annotation != null) {
/* 307 */       postProcessBeforeInitialization(bean, beanName, annotation);
/*     */     }
/* 309 */     return bean;
/*     */   }
/*     */   
/*     */   public Object postProcessAfterInitialization(Object bean, String beanName)
/*     */     throws BeansException
/*     */   {
/* 315 */     return bean;
/*     */   }
/*     */   
/*     */ 
/*     */   private void postProcessBeforeInitialization(Object bean, String beanName, ConfigurationProperties annotation)
/*     */   {
/* 321 */     Object target = bean;
/* 322 */     PropertiesConfigurationFactory<Object> factory = new PropertiesConfigurationFactory(target);
/*     */     
/* 324 */     if ((annotation != null) && (annotation.locations().length != 0)) {
/* 325 */       factory.setPropertySources(
/* 326 */         loadPropertySources(annotation.locations(), annotation.merge()));
/*     */     }
/*     */     else {
/* 329 */       factory.setPropertySources(this.propertySources);
/*     */     }
/* 331 */     factory.setValidator(determineValidator(bean));
/*     */     
/*     */ 
/* 334 */     factory.setConversionService(this.conversionService == null ? 
/* 335 */       getDefaultConversionService() : this.conversionService);
/* 336 */     if (annotation != null) {
/* 337 */       factory.setIgnoreInvalidFields(annotation.ignoreInvalidFields());
/* 338 */       factory.setIgnoreUnknownFields(annotation.ignoreUnknownFields());
/* 339 */       factory.setExceptionIfInvalid(annotation.exceptionIfInvalid());
/* 340 */       factory.setIgnoreNestedProperties(annotation.ignoreNestedProperties());
/* 341 */       if (StringUtils.hasLength(annotation.prefix())) {
/* 342 */         factory.setTargetName(annotation.prefix());
/*     */       }
/*     */     }
/*     */     try {
/* 346 */       factory.bindPropertiesToTarget();
/*     */     }
/*     */     catch (Exception ex) {
/* 349 */       String targetClass = ClassUtils.getShortName(target.getClass());
/*     */       
/* 351 */       throw new BeanCreationException(beanName, "Could not bind properties to " + targetClass + " (" + getAnnotationDetails(annotation) + ")", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private String getAnnotationDetails(ConfigurationProperties annotation) {
/* 356 */     if (annotation == null) {
/* 357 */       return "";
/*     */     }
/* 359 */     StringBuilder details = new StringBuilder();
/* 360 */     details.append("prefix=").append(annotation.prefix());
/* 361 */     details.append(", ignoreInvalidFields=").append(annotation.ignoreInvalidFields());
/* 362 */     details.append(", ignoreUnknownFields=").append(annotation.ignoreUnknownFields());
/* 363 */     details.append(", ignoreNestedProperties=")
/* 364 */       .append(annotation.ignoreNestedProperties());
/* 365 */     return details.toString();
/*     */   }
/*     */   
/*     */   private Validator determineValidator(Object bean) {
/* 369 */     Validator validator = getValidator();
/* 370 */     boolean supportsBean = (validator != null) && (validator.supports(bean.getClass()));
/* 371 */     if (ClassUtils.isAssignable(Validator.class, bean.getClass())) {
/* 372 */       if (supportsBean) {
/* 373 */         return new ChainingValidator(new Validator[] { validator, (Validator)bean });
/*     */       }
/* 375 */       return (Validator)bean;
/*     */     }
/* 377 */     return supportsBean ? validator : null;
/*     */   }
/*     */   
/*     */   private Validator getValidator() {
/* 381 */     if (this.validator != null) {
/* 382 */       return this.validator;
/*     */     }
/* 384 */     if ((this.localValidator == null) && (isJsr303Present()))
/*     */     {
/* 386 */       this.localValidator = new LocalValidatorFactory(null).run(this.applicationContext);
/*     */     }
/* 388 */     return this.localValidator;
/*     */   }
/*     */   
/*     */   private boolean isJsr303Present() {
/* 392 */     for (String validatorClass : VALIDATOR_CLASSES) {
/* 393 */       if (!ClassUtils.isPresent(validatorClass, this.applicationContext
/* 394 */         .getClassLoader())) {
/* 395 */         return false;
/*     */       }
/*     */     }
/* 398 */     return true;
/*     */   }
/*     */   
/*     */   private PropertySources loadPropertySources(String[] locations, boolean mergeDefaultSources)
/*     */   {
/*     */     try {
/* 404 */       PropertySourcesLoader loader = new PropertySourcesLoader();
/* 405 */       for (String location : locations)
/*     */       {
/* 407 */         Resource resource = this.resourceLoader.getResource(this.environment.resolvePlaceholders(location));
/* 408 */         String[] profiles = this.environment.getActiveProfiles();
/* 409 */         for (int i = profiles.length; i-- > 0;) {
/* 410 */           String profile = profiles[i];
/* 411 */           loader.load(resource, profile);
/*     */         }
/* 413 */         loader.load(resource);
/*     */       }
/* 415 */       MutablePropertySources loaded = loader.getPropertySources();
/* 416 */       if (mergeDefaultSources) {
/* 417 */         for (Object propertySource : this.propertySources) {
/* 418 */           loaded.addLast((PropertySource)propertySource);
/*     */         }
/*     */       }
/* 421 */       return loaded;
/*     */     }
/*     */     catch (IOException ex) {
/* 424 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private ConversionService getDefaultConversionService() {
/* 429 */     if (this.defaultConversionService == null) {
/* 430 */       DefaultConversionService conversionService = new DefaultConversionService();
/* 431 */       this.applicationContext.getAutowireCapableBeanFactory().autowireBean(this);
/* 432 */       for (Converter<?, ?> converter : this.converters) {
/* 433 */         conversionService.addConverter(converter);
/*     */       }
/* 435 */       for (GenericConverter genericConverter : this.genericConverters) {
/* 436 */         conversionService.addConverter(genericConverter);
/*     */       }
/* 438 */       this.defaultConversionService = conversionService;
/*     */     }
/* 440 */     return this.defaultConversionService;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class LocalValidatorFactory
/*     */   {
/*     */     public Validator run(ApplicationContext applicationContext)
/*     */     {
/* 450 */       LocalValidatorFactoryBean validator = new LocalValidatorFactoryBean();
/* 451 */       validator.setApplicationContext(applicationContext);
/* 452 */       validator.afterPropertiesSet();
/* 453 */       return validator;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class ChainingValidator
/*     */     implements Validator
/*     */   {
/*     */     private Validator[] validators;
/*     */     
/*     */ 
/*     */     ChainingValidator(Validator... validators)
/*     */     {
/* 467 */       Assert.notNull(validators, "Validators must not be null");
/* 468 */       this.validators = validators;
/*     */     }
/*     */     
/*     */     public boolean supports(Class<?> clazz)
/*     */     {
/* 473 */       for (Validator validator : this.validators) {
/* 474 */         if (validator.supports(clazz)) {
/* 475 */           return true;
/*     */         }
/*     */       }
/* 478 */       return false;
/*     */     }
/*     */     
/*     */     public void validate(Object target, Errors errors)
/*     */     {
/* 483 */       for (Validator validator : this.validators) {
/* 484 */         if (validator.supports(target.getClass())) {
/* 485 */           validator.validate(target, errors);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class FlatPropertySources
/*     */     implements PropertySources
/*     */   {
/*     */     private PropertySources propertySources;
/*     */     
/*     */ 
/*     */     FlatPropertySources(PropertySources propertySources)
/*     */     {
/* 501 */       this.propertySources = propertySources;
/*     */     }
/*     */     
/*     */     public Iterator<PropertySource<?>> iterator()
/*     */     {
/* 506 */       MutablePropertySources result = getFlattened();
/* 507 */       return result.iterator();
/*     */     }
/*     */     
/*     */     public boolean contains(String name)
/*     */     {
/* 512 */       return get(name) != null;
/*     */     }
/*     */     
/*     */     public PropertySource<?> get(String name)
/*     */     {
/* 517 */       return getFlattened().get(name);
/*     */     }
/*     */     
/*     */     private MutablePropertySources getFlattened() {
/* 521 */       MutablePropertySources result = new MutablePropertySources();
/* 522 */       for (PropertySource<?> propertySource : this.propertySources) {
/* 523 */         flattenPropertySources(propertySource, result);
/*     */       }
/* 525 */       return result;
/*     */     }
/*     */     
/*     */     private void flattenPropertySources(PropertySource<?> propertySource, MutablePropertySources result)
/*     */     {
/* 530 */       Object source = propertySource.getSource();
/* 531 */       if ((source instanceof ConfigurableEnvironment)) {
/* 532 */         ConfigurableEnvironment environment = (ConfigurableEnvironment)source;
/* 533 */         for (PropertySource<?> childSource : environment.getPropertySources()) {
/* 534 */           flattenPropertySources(childSource, result);
/*     */         }
/*     */       }
/*     */       else {
/* 538 */         result.addLast(propertySource);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesBindingPostProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */