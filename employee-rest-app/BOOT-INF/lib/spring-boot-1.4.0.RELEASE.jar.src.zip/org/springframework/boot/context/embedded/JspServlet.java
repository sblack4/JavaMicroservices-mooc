/*    */ package org.springframework.boot.context.embedded;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JspServlet
/*    */ {
/* 36 */   private String className = "org.apache.jasper.servlet.JspServlet";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 41 */   private Map<String, String> initParameters = new HashMap();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 47 */   private boolean registered = true;
/*    */   
/*    */   public String getClassName() {
/* 50 */     return this.className;
/*    */   }
/*    */   
/*    */   public void setClassName(String className) {
/* 54 */     this.className = className;
/*    */   }
/*    */   
/*    */   public Map<String, String> getInitParameters() {
/* 58 */     return this.initParameters;
/*    */   }
/*    */   
/*    */   public void setInitParameters(Map<String, String> initParameters) {
/* 62 */     this.initParameters = initParameters;
/*    */   }
/*    */   
/*    */   public boolean getRegistered() {
/* 66 */     return this.registered;
/*    */   }
/*    */   
/*    */   public void setRegistered(boolean registered) {
/* 70 */     this.registered = registered;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\embedded\JspServlet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */