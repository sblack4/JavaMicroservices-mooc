/*    */ package org.springframework.boot.context.embedded.jetty;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletRequestWrapper;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.eclipse.jetty.http.HttpMethod;
/*    */ import org.eclipse.jetty.server.Request;
/*    */ import org.eclipse.jetty.server.handler.ErrorHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JettyEmbeddedErrorHandler
/*    */   extends ErrorHandler
/*    */ {
/*    */   private final ErrorHandler delegate;
/*    */   
/*    */   JettyEmbeddedErrorHandler(ErrorHandler delegate)
/*    */   {
/* 44 */     this.delegate = delegate;
/*    */   }
/*    */   
/*    */   public void handle(String target, Request baseRequest, HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException
/*    */   {
/* 50 */     String method = request.getMethod();
/* 51 */     if ((!HttpMethod.GET.is(method)) && (!HttpMethod.POST.is(method)) && 
/* 52 */       (!HttpMethod.HEAD.is(method))) {
/* 53 */       request = new ErrorHttpServletRequest(request);
/*    */     }
/* 55 */     this.delegate.handle(target, baseRequest, request, response);
/*    */   }
/*    */   
/*    */   private static class ErrorHttpServletRequest extends HttpServletRequestWrapper
/*    */   {
/* 60 */     private boolean simulateGetMethod = true;
/*    */     
/*    */     ErrorHttpServletRequest(HttpServletRequest request) {
/* 63 */       super();
/*    */     }
/*    */     
/*    */ 
/*    */     public String getMethod()
/*    */     {
/* 69 */       return this.simulateGetMethod ? HttpMethod.GET.toString() : super.getMethod();
/*    */     }
/*    */     
/*    */     public ServletContext getServletContext()
/*    */     {
/* 74 */       this.simulateGetMethod = false;
/* 75 */       return super.getServletContext();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\embedded\jetty\JettyEmbeddedErrorHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */