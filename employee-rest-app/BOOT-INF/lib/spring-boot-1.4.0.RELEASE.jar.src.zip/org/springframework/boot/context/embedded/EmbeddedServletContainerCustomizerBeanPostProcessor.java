/*    */ package org.springframework.boot.context.embedded;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmbeddedServletContainerCustomizerBeanPostProcessor
/*    */   implements BeanPostProcessor, ApplicationContextAware
/*    */ {
/*    */   private ApplicationContext applicationContext;
/*    */   private List<EmbeddedServletContainerCustomizer> customizers;
/*    */   
/*    */   public void setApplicationContext(ApplicationContext applicationContext)
/*    */     throws BeansException
/*    */   {
/* 47 */     this.applicationContext = applicationContext;
/*    */   }
/*    */   
/*    */   public Object postProcessBeforeInitialization(Object bean, String beanName)
/*    */     throws BeansException
/*    */   {
/* 53 */     if ((bean instanceof ConfigurableEmbeddedServletContainer)) {
/* 54 */       postProcessBeforeInitialization((ConfigurableEmbeddedServletContainer)bean);
/*    */     }
/* 56 */     return bean;
/*    */   }
/*    */   
/*    */   public Object postProcessAfterInitialization(Object bean, String beanName)
/*    */     throws BeansException
/*    */   {
/* 62 */     return bean;
/*    */   }
/*    */   
/*    */   private void postProcessBeforeInitialization(ConfigurableEmbeddedServletContainer bean)
/*    */   {
/* 67 */     for (EmbeddedServletContainerCustomizer customizer : getCustomizers()) {
/* 68 */       customizer.customize(bean);
/*    */     }
/*    */   }
/*    */   
/*    */   private Collection<EmbeddedServletContainerCustomizer> getCustomizers() {
/* 73 */     if (this.customizers == null)
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 79 */       this.customizers = new ArrayList(this.applicationContext.getBeansOfType(EmbeddedServletContainerCustomizer.class, false, false).values());
/* 80 */       Collections.sort(this.customizers, AnnotationAwareOrderComparator.INSTANCE);
/* 81 */       this.customizers = Collections.unmodifiableList(this.customizers);
/*    */     }
/* 83 */     return this.customizers;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\embedded\EmbeddedServletContainerCustomizerBeanPostProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */