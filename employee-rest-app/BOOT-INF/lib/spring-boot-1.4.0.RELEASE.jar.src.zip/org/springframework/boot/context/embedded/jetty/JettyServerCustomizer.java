package org.springframework.boot.context.embedded.jetty;

import org.eclipse.jetty.server.Server;

public abstract interface JettyServerCustomizer
{
  public abstract void customize(Server paramServer);
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\embedded\jetty\JettyServerCustomizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */