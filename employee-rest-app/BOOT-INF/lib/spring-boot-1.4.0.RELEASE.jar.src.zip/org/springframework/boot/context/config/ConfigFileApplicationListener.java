/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Queue;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.boot.bind.PropertiesConfigurationFactory;
/*     */ import org.springframework.boot.bind.RelaxedPropertyResolver;
/*     */ import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
/*     */ import org.springframework.boot.context.event.ApplicationPreparedEvent;
/*     */ import org.springframework.boot.env.EnumerableCompositePropertySource;
/*     */ import org.springframework.boot.env.EnvironmentPostProcessor;
/*     */ import org.springframework.boot.env.PropertySourcesLoader;
/*     */ import org.springframework.boot.logging.DeferredLog;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.support.DefaultConversionService;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.EnumerablePropertySource;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.validation.BindException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigFileApplicationListener
/*     */   implements EnvironmentPostProcessor, ApplicationListener<ApplicationEvent>, Ordered
/*     */ {
/*     */   private static final String DEFAULT_PROPERTIES = "defaultProperties";
/*     */   private static final String DEFAULT_SEARCH_LOCATIONS = "classpath:/,classpath:/config/,file:./,file:./config/";
/*     */   private static final String DEFAULT_NAMES = "application";
/*     */   public static final String ACTIVE_PROFILES_PROPERTY = "spring.profiles.active";
/*     */   public static final String INCLUDE_PROFILES_PROPERTY = "spring.profiles.include";
/*     */   public static final String CONFIG_NAME_PROPERTY = "spring.config.name";
/*     */   public static final String CONFIG_LOCATION_PROPERTY = "spring.config.location";
/*     */   public static final int DEFAULT_ORDER = -2147483638;
/*     */   public static final String APPLICATION_CONFIGURATION_PROPERTY_SOURCE_NAME = "applicationConfigurationProperties";
/* 141 */   private final DeferredLog logger = new DeferredLog();
/*     */   
/*     */   private String searchLocations;
/*     */   
/*     */   private String names;
/*     */   
/* 147 */   private int order = -2147483638;
/*     */   
/* 149 */   private final ConversionService conversionService = new DefaultConversionService();
/*     */   
/*     */   public void onApplicationEvent(ApplicationEvent event)
/*     */   {
/* 153 */     if ((event instanceof ApplicationEnvironmentPreparedEvent)) {
/* 154 */       onApplicationEnvironmentPreparedEvent((ApplicationEnvironmentPreparedEvent)event);
/*     */     }
/*     */     
/* 157 */     if ((event instanceof ApplicationPreparedEvent)) {
/* 158 */       onApplicationPreparedEvent(event);
/*     */     }
/*     */   }
/*     */   
/*     */   private void onApplicationEnvironmentPreparedEvent(ApplicationEnvironmentPreparedEvent event)
/*     */   {
/* 164 */     List<EnvironmentPostProcessor> postProcessors = loadPostProcessors();
/* 165 */     postProcessors.add(this);
/* 166 */     AnnotationAwareOrderComparator.sort(postProcessors);
/* 167 */     for (EnvironmentPostProcessor postProcessor : postProcessors) {
/* 168 */       postProcessor.postProcessEnvironment(event.getEnvironment(), event
/* 169 */         .getSpringApplication());
/*     */     }
/*     */   }
/*     */   
/*     */   List<EnvironmentPostProcessor> loadPostProcessors() {
/* 174 */     return SpringFactoriesLoader.loadFactories(EnvironmentPostProcessor.class, 
/* 175 */       getClass().getClassLoader());
/*     */   }
/*     */   
/*     */ 
/*     */   public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application)
/*     */   {
/* 181 */     addPropertySources(environment, application.getResourceLoader());
/* 182 */     configureIgnoreBeanInfo(environment);
/* 183 */     bindToSpringApplication(environment, application);
/*     */   }
/*     */   
/*     */   private void configureIgnoreBeanInfo(ConfigurableEnvironment environment) {
/* 187 */     if (System.getProperty("spring.beaninfo.ignore") == null)
/*     */     {
/* 189 */       RelaxedPropertyResolver resolver = new RelaxedPropertyResolver(environment, "spring.beaninfo.");
/*     */       
/* 191 */       Boolean ignore = (Boolean)resolver.getProperty("ignore", Boolean.class, Boolean.TRUE);
/* 192 */       System.setProperty("spring.beaninfo.ignore", ignore
/* 193 */         .toString());
/*     */     }
/*     */   }
/*     */   
/*     */   private void onApplicationPreparedEvent(ApplicationEvent event) {
/* 198 */     this.logger.replayTo(ConfigFileApplicationListener.class);
/* 199 */     addPostProcessors(((ApplicationPreparedEvent)event).getApplicationContext());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addPropertySources(ConfigurableEnvironment environment, ResourceLoader resourceLoader)
/*     */   {
/* 210 */     RandomValuePropertySource.addToEnvironment(environment);
/*     */     try {
/* 212 */       new Loader(environment, resourceLoader).load();
/*     */     }
/*     */     catch (IOException ex) {
/* 215 */       throw new IllegalStateException("Unable to load configuration files", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void bindToSpringApplication(ConfigurableEnvironment environment, SpringApplication application)
/*     */   {
/* 226 */     PropertiesConfigurationFactory<SpringApplication> binder = new PropertiesConfigurationFactory(application);
/*     */     
/* 228 */     binder.setTargetName("spring.main");
/* 229 */     binder.setConversionService(this.conversionService);
/* 230 */     binder.setPropertySources(environment.getPropertySources());
/*     */     try {
/* 232 */       binder.bindPropertiesToTarget();
/*     */     }
/*     */     catch (BindException ex) {
/* 235 */       throw new IllegalStateException("Cannot bind to SpringApplication", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addPostProcessors(ConfigurableApplicationContext context)
/*     */   {
/* 244 */     context.addBeanFactoryPostProcessor(new PropertySourceOrderingPostProcessor(context));
/*     */   }
/*     */   
/*     */   public void setOrder(int order)
/*     */   {
/* 249 */     this.order = order;
/*     */   }
/*     */   
/*     */   public int getOrder()
/*     */   {
/* 254 */     return this.order;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSearchLocations(String locations)
/*     */   {
/* 267 */     Assert.hasLength(locations, "Locations must not be empty");
/* 268 */     this.searchLocations = locations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSearchNames(String names)
/*     */   {
/* 277 */     Assert.hasLength(names, "Names must not be empty");
/* 278 */     this.names = names;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class PropertySourceOrderingPostProcessor
/*     */     implements BeanFactoryPostProcessor, Ordered
/*     */   {
/*     */     private ConfigurableApplicationContext context;
/*     */     
/*     */ 
/*     */     PropertySourceOrderingPostProcessor(ConfigurableApplicationContext context)
/*     */     {
/* 291 */       this.context = context;
/*     */     }
/*     */     
/*     */     public int getOrder()
/*     */     {
/* 296 */       return Integer.MIN_VALUE;
/*     */     }
/*     */     
/*     */     public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*     */       throws BeansException
/*     */     {
/* 302 */       reorderSources(this.context.getEnvironment());
/*     */     }
/*     */     
/*     */     private void reorderSources(ConfigurableEnvironment environment)
/*     */     {
/* 307 */       ConfigFileApplicationListener.ConfigurationPropertySources.finishAndRelocate(environment.getPropertySources());
/*     */       
/* 309 */       PropertySource<?> defaultProperties = environment.getPropertySources().remove("defaultProperties");
/* 310 */       if (defaultProperties != null) {
/* 311 */         environment.getPropertySources().addLast(defaultProperties);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private class Loader
/*     */   {
/* 322 */     private final Log logger = ConfigFileApplicationListener.this.logger;
/*     */     
/*     */     private final ConfigurableEnvironment environment;
/*     */     
/*     */     private final ResourceLoader resourceLoader;
/*     */     
/*     */     private PropertySourcesLoader propertiesLoader;
/*     */     
/*     */     private Queue<ConfigFileApplicationListener.Profile> profiles;
/*     */     
/*     */     private List<ConfigFileApplicationListener.Profile> processedProfiles;
/*     */     private boolean activatedProfiles;
/*     */     
/*     */     Loader(ConfigurableEnvironment environment, ResourceLoader resourceLoader)
/*     */     {
/* 337 */       this.environment = environment;
/* 338 */       this.resourceLoader = (resourceLoader == null ? new DefaultResourceLoader() : resourceLoader);
/*     */     }
/*     */     
/*     */     public void load() throws IOException
/*     */     {
/* 343 */       this.propertiesLoader = new PropertySourcesLoader();
/* 344 */       this.activatedProfiles = false;
/* 345 */       this.profiles = Collections.asLifoQueue(new LinkedList());
/* 346 */       this.processedProfiles = new LinkedList();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 351 */       Set<ConfigFileApplicationListener.Profile> initialActiveProfiles = initializeActiveProfiles();
/* 352 */       this.profiles.addAll(getUnprocessedActiveProfiles(initialActiveProfiles));
/* 353 */       String defaultProfileName; if (this.profiles.isEmpty()) {
/* 354 */         for (defaultProfileName : this.environment.getDefaultProfiles()) {
/* 355 */           ConfigFileApplicationListener.Profile defaultProfile = new ConfigFileApplicationListener.Profile(defaultProfileName, true);
/* 356 */           if (!this.profiles.contains(defaultProfile)) {
/* 357 */             this.profiles.add(defaultProfile);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 365 */       this.profiles.add(null);
/*     */       
/* 367 */       while (!this.profiles.isEmpty()) {
/* 368 */         ConfigFileApplicationListener.Profile profile = (ConfigFileApplicationListener.Profile)this.profiles.poll();
/* 369 */         for (Iterator localIterator = getSearchLocations().iterator(); localIterator.hasNext();) { location = (String)localIterator.next();
/* 370 */           if (!location.endsWith("/"))
/*     */           {
/*     */ 
/* 373 */             load(location, null, profile);
/*     */           }
/*     */           else {
/* 376 */             for (String name : getSearchNames())
/* 377 */               load(location, name, profile);
/*     */           }
/*     */         }
/*     */         String location;
/* 381 */         this.processedProfiles.add(profile);
/*     */       }
/*     */       
/* 384 */       addConfigurationProperties(this.propertiesLoader.getPropertySources());
/*     */     }
/*     */     
/*     */     private Set<ConfigFileApplicationListener.Profile> initializeActiveProfiles() {
/* 388 */       if (!this.environment.containsProperty("spring.profiles.active")) {
/* 389 */         return Collections.emptySet();
/*     */       }
/*     */       
/*     */ 
/* 393 */       Set<ConfigFileApplicationListener.Profile> activeProfiles = getProfilesForValue(this.environment
/* 394 */         .getProperty("spring.profiles.active"));
/* 395 */       maybeActivateProfiles(activeProfiles);
/* 396 */       return activeProfiles;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private List<ConfigFileApplicationListener.Profile> getUnprocessedActiveProfiles(Set<ConfigFileApplicationListener.Profile> initialActiveProfiles)
/*     */     {
/* 413 */       List<ConfigFileApplicationListener.Profile> unprocessedActiveProfiles = new ArrayList();
/* 414 */       for (String profileName : this.environment.getActiveProfiles()) {
/* 415 */         ConfigFileApplicationListener.Profile profile = new ConfigFileApplicationListener.Profile(profileName);
/* 416 */         if (!initialActiveProfiles.contains(profile)) {
/* 417 */           unprocessedActiveProfiles.add(profile);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 422 */       Collections.reverse(unprocessedActiveProfiles);
/* 423 */       return unprocessedActiveProfiles;
/*     */     }
/*     */     
/*     */     private void load(String location, String name, ConfigFileApplicationListener.Profile profile) throws IOException
/*     */     {
/* 428 */       String group = "profile=" + (profile == null ? "" : profile);
/* 429 */       if (!StringUtils.hasText(name))
/*     */       {
/* 431 */         loadIntoGroup(group, location, profile);
/*     */       }
/*     */       else
/*     */       {
/* 435 */         for (String ext : this.propertiesLoader.getAllFileExtensions()) {
/* 436 */           if (profile != null)
/*     */           {
/* 438 */             loadIntoGroup(group, location + name + "-" + profile + "." + ext, null);
/*     */             
/* 440 */             for (ConfigFileApplicationListener.Profile processedProfile : this.processedProfiles) {
/* 441 */               if (processedProfile != null) {
/* 442 */                 loadIntoGroup(group, location + name + "-" + processedProfile + "." + ext, profile);
/*     */               }
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/* 449 */             loadIntoGroup(group, location + name + "-" + profile + "." + ext, profile);
/*     */           }
/*     */           
/*     */ 
/* 453 */           loadIntoGroup(group, location + name + "." + ext, profile);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private PropertySource<?> loadIntoGroup(String identifier, String location, ConfigFileApplicationListener.Profile profile) throws IOException
/*     */     {
/* 460 */       Resource resource = this.resourceLoader.getResource(location);
/* 461 */       PropertySource<?> propertySource = null;
/* 462 */       StringBuilder msg = new StringBuilder();
/* 463 */       if ((resource != null) && (resource.exists())) {
/* 464 */         String name = "applicationConfig: [" + location + "]";
/* 465 */         String group = "applicationConfig: [" + identifier + "]";
/* 466 */         propertySource = this.propertiesLoader.load(resource, group, name, profile == null ? null : profile
/* 467 */           .getName());
/* 468 */         if (propertySource != null) {
/* 469 */           msg.append("Loaded ");
/* 470 */           handleProfileProperties(propertySource);
/*     */         }
/*     */         else {
/* 473 */           msg.append("Skipped (empty) ");
/*     */         }
/*     */       }
/*     */       else {
/* 477 */         msg.append("Skipped ");
/*     */       }
/* 479 */       msg.append("config file ");
/* 480 */       msg.append(getResourceDescription(location, resource));
/* 481 */       if (profile != null) {
/* 482 */         msg.append(" for profile ").append(profile);
/*     */       }
/* 484 */       if ((resource == null) || (!resource.exists())) {
/* 485 */         msg.append(" resource not found");
/* 486 */         this.logger.trace(msg);
/*     */       }
/*     */       else {
/* 489 */         this.logger.debug(msg);
/*     */       }
/* 491 */       return propertySource;
/*     */     }
/*     */     
/*     */     private String getResourceDescription(String location, Resource resource) {
/* 495 */       String resourceDescription = "'" + location + "'";
/* 496 */       if (resource != null) {
/*     */         try {
/* 498 */           resourceDescription = String.format("'%s' (%s)", new Object[] {resource
/* 499 */             .getURI().toASCIIString(), location });
/*     */         }
/*     */         catch (IOException localIOException) {}
/*     */       }
/*     */       
/*     */ 
/* 505 */       return resourceDescription;
/*     */     }
/*     */     
/*     */     private void handleProfileProperties(PropertySource<?> propertySource) {
/* 509 */       Set<ConfigFileApplicationListener.Profile> activeProfiles = getProfilesForValue(propertySource
/* 510 */         .getProperty("spring.profiles.active"));
/* 511 */       maybeActivateProfiles(activeProfiles);
/* 512 */       Set<ConfigFileApplicationListener.Profile> includeProfiles = getProfilesForValue(propertySource
/* 513 */         .getProperty("spring.profiles.include"));
/* 514 */       addProfiles(includeProfiles);
/*     */     }
/*     */     
/*     */     private void maybeActivateProfiles(Set<ConfigFileApplicationListener.Profile> profiles) {
/* 518 */       if (this.activatedProfiles) {
/* 519 */         if (!profiles.isEmpty()) {
/* 520 */           this.logger.debug("Profiles already activated, '" + profiles + "' will not be applied");
/*     */         }
/*     */         
/* 523 */         return;
/*     */       }
/* 525 */       if (!profiles.isEmpty()) {
/* 526 */         addProfiles(profiles);
/* 527 */         this.logger.debug("Activated profiles " + 
/* 528 */           StringUtils.collectionToCommaDelimitedString(profiles));
/* 529 */         this.activatedProfiles = true;
/* 530 */         removeUnprocessedDefaultProfiles();
/*     */       }
/*     */     }
/*     */     
/*     */     private void removeUnprocessedDefaultProfiles() {
/* 535 */       Iterator<ConfigFileApplicationListener.Profile> iterator = this.profiles.iterator();
/* 536 */       while (iterator.hasNext()) {
/* 537 */         if (((ConfigFileApplicationListener.Profile)iterator.next()).isDefaultProfile()) {
/* 538 */           iterator.remove();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private Set<ConfigFileApplicationListener.Profile> getProfilesForValue(Object property) {
/* 544 */       String value = property == null ? null : property.toString();
/* 545 */       Set<String> profileNames = asResolvedSet(value, null);
/* 546 */       Set<ConfigFileApplicationListener.Profile> profiles = new LinkedHashSet();
/* 547 */       for (String profileName : profileNames) {
/* 548 */         profiles.add(new ConfigFileApplicationListener.Profile(profileName));
/*     */       }
/* 550 */       return profiles;
/*     */     }
/*     */     
/*     */     private void addProfiles(Set<ConfigFileApplicationListener.Profile> profiles) {
/* 554 */       for (ConfigFileApplicationListener.Profile profile : profiles) {
/* 555 */         this.profiles.add(profile);
/* 556 */         if (!this.environment.acceptsProfiles(new String[] { profile.getName() }))
/*     */         {
/*     */ 
/* 559 */           prependProfile(this.environment, profile);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private void prependProfile(ConfigurableEnvironment environment, ConfigFileApplicationListener.Profile profile)
/*     */     {
/* 566 */       Set<String> profiles = new LinkedHashSet();
/* 567 */       environment.getActiveProfiles();
/*     */       
/* 569 */       profiles.add(profile.getName());
/* 570 */       profiles.addAll(Arrays.asList(environment.getActiveProfiles()));
/* 571 */       environment.setActiveProfiles((String[])profiles.toArray(new String[profiles.size()]));
/*     */     }
/*     */     
/*     */     private Set<String> getSearchLocations() {
/* 575 */       Set<String> locations = new LinkedHashSet();
/*     */       
/* 577 */       if (this.environment.containsProperty("spring.config.location")) {
/* 578 */         for (String path : asResolvedSet(this.environment
/* 579 */           .getProperty("spring.config.location"), null)) {
/* 580 */           if (!path.contains("$")) {
/* 581 */             path = StringUtils.cleanPath(path);
/* 582 */             if (!ResourceUtils.isUrl(path)) {
/* 583 */               path = "file:" + path;
/*     */             }
/*     */           }
/* 586 */           locations.add(path);
/*     */         }
/*     */       }
/* 589 */       locations.addAll(
/* 590 */         asResolvedSet(ConfigFileApplicationListener.this.searchLocations, "classpath:/,classpath:/config/,file:./,file:./config/"));
/*     */       
/* 592 */       return locations;
/*     */     }
/*     */     
/*     */     private Set<String> getSearchNames() {
/* 596 */       if (this.environment.containsProperty("spring.config.name")) {
/* 597 */         return asResolvedSet(this.environment.getProperty("spring.config.name"), null);
/*     */       }
/*     */       
/* 600 */       return asResolvedSet(ConfigFileApplicationListener.this.names, "application");
/*     */     }
/*     */     
/*     */     private Set<String> asResolvedSet(String value, String fallback) {
/* 604 */       List<String> list = Arrays.asList(StringUtils.trimArrayElements(
/* 605 */         StringUtils.commaDelimitedListToStringArray(value != null ? this.environment
/* 606 */         .resolvePlaceholders(value) : fallback)));
/* 607 */       Collections.reverse(list);
/* 608 */       return new LinkedHashSet(list);
/*     */     }
/*     */     
/*     */     private void addConfigurationProperties(MutablePropertySources sources) {
/* 612 */       List<PropertySource<?>> reorderedSources = new ArrayList();
/* 613 */       for (PropertySource<?> item : sources) {
/* 614 */         reorderedSources.add(item);
/*     */       }
/* 616 */       addConfigurationProperties(new ConfigFileApplicationListener.ConfigurationPropertySources(reorderedSources));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private void addConfigurationProperties(ConfigFileApplicationListener.ConfigurationPropertySources configurationSources)
/*     */     {
/* 623 */       MutablePropertySources existingSources = this.environment.getPropertySources();
/* 624 */       if (existingSources.contains("defaultProperties")) {
/* 625 */         existingSources.addBefore("defaultProperties", configurationSources);
/*     */       }
/*     */       else {
/* 628 */         existingSources.addLast(configurationSources);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class Profile
/*     */   {
/*     */     private final String name;
/*     */     private final boolean defaultProfile;
/*     */     
/*     */     Profile(String name)
/*     */     {
/* 641 */       this(name, false);
/*     */     }
/*     */     
/*     */     Profile(String name, boolean defaultProfile) {
/* 645 */       Assert.notNull(name, "Name must not be null");
/* 646 */       this.name = name;
/* 647 */       this.defaultProfile = defaultProfile;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 651 */       return this.name;
/*     */     }
/*     */     
/*     */     public boolean isDefaultProfile() {
/* 655 */       return this.defaultProfile;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 660 */       return this.name;
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 665 */       return this.name.hashCode();
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/* 670 */       if (obj == this) {
/* 671 */         return true;
/*     */       }
/* 673 */       if ((obj == null) || (obj.getClass() != getClass())) {
/* 674 */         return false;
/*     */       }
/* 676 */       return ((Profile)obj).name.equals(this.name);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static class ConfigurationPropertySources
/*     */     extends EnumerablePropertySource<Collection<PropertySource<?>>>
/*     */   {
/*     */     private final Collection<PropertySource<?>> sources;
/*     */     
/*     */ 
/*     */     private final String[] names;
/*     */     
/*     */ 
/*     */     ConfigurationPropertySources(Collection<PropertySource<?>> sources)
/*     */     {
/* 693 */       super(sources);
/* 694 */       this.sources = sources;
/* 695 */       List<String> names = new ArrayList();
/* 696 */       for (PropertySource<?> source : sources) {
/* 697 */         if ((source instanceof EnumerablePropertySource)) {
/* 698 */           names.addAll(Arrays.asList(((EnumerablePropertySource)source)
/* 699 */             .getPropertyNames()));
/*     */         }
/*     */       }
/* 702 */       this.names = ((String[])names.toArray(new String[names.size()]));
/*     */     }
/*     */     
/*     */     public Object getProperty(String name)
/*     */     {
/* 707 */       for (PropertySource<?> propertySource : this.sources) {
/* 708 */         Object value = propertySource.getProperty(name);
/* 709 */         if (value != null) {
/* 710 */           return value;
/*     */         }
/*     */       }
/* 713 */       return null;
/*     */     }
/*     */     
/*     */     public static void finishAndRelocate(MutablePropertySources propertySources) {
/* 717 */       String name = "applicationConfigurationProperties";
/*     */       
/* 719 */       ConfigurationPropertySources removed = (ConfigurationPropertySources)propertySources.get(name);
/* 720 */       if (removed != null) {
/* 721 */         for (PropertySource<?> propertySource : removed.sources) {
/* 722 */           if ((propertySource instanceof EnumerableCompositePropertySource)) {
/* 723 */             EnumerableCompositePropertySource composite = (EnumerableCompositePropertySource)propertySource;
/* 724 */             for (PropertySource<?> nested : (Collection)composite.getSource()) {
/* 725 */               propertySources.addAfter(name, nested);
/* 726 */               name = nested.getName();
/*     */             }
/*     */           }
/*     */           else {
/* 730 */             propertySources.addAfter(name, propertySource);
/*     */           }
/*     */         }
/* 733 */         propertySources.remove("applicationConfigurationProperties");
/*     */       }
/*     */     }
/*     */     
/*     */     public String[] getPropertyNames()
/*     */     {
/* 739 */       return this.names;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\config\ConfigFileApplicationListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */