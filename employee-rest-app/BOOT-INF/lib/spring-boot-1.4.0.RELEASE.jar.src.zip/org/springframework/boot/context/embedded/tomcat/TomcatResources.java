/*     */ package org.springframework.boot.context.embedded.tomcat;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import javax.naming.directory.DirContext;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.catalina.WebResourceRoot.ResourceSetType;
/*     */ import org.apache.catalina.core.StandardContext;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class TomcatResources
/*     */ {
/*     */   private final Context context;
/*     */   
/*     */   TomcatResources(Context context)
/*     */   {
/*  46 */     this.context = context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addClasspathResources()
/*     */   {
/*  53 */     ClassLoader loader = getClass().getClassLoader();
/*  54 */     if ((loader instanceof URLClassLoader)) {
/*  55 */       for (URL url : ((URLClassLoader)loader).getURLs()) {
/*  56 */         String file = url.getFile();
/*  57 */         if ((file.endsWith(".jar")) || (file.endsWith(".jar!/"))) {
/*  58 */           String jar = url.toString();
/*  59 */           if (!jar.startsWith("jar:"))
/*     */           {
/*  61 */             jar = "jar:" + jar + "!/";
/*     */           }
/*  63 */           addJar(jar);
/*     */         }
/*  65 */         else if (url.toString().startsWith("file:")) {
/*  66 */           String dir = url.toString().substring("file:".length());
/*  67 */           if (new File(dir).isDirectory()) {
/*  68 */             addDir(dir, url);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected final Context getContext() {
/*  76 */     return this.context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void addJar(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void addDir(String paramString, URL paramURL);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TomcatResources get(Context context)
/*     */   {
/*  98 */     if (ClassUtils.isPresent("org.apache.catalina.deploy.ErrorPage", null)) {
/*  99 */       return new Tomcat7Resources(context);
/*     */     }
/* 101 */     return new Tomcat8Resources(context);
/*     */   }
/*     */   
/*     */ 
/*     */   private static class Tomcat7Resources
/*     */     extends TomcatResources
/*     */   {
/*     */     private final Method addResourceJarUrlMethod;
/*     */     
/*     */     Tomcat7Resources(Context context)
/*     */     {
/* 112 */       super();
/* 113 */       this.addResourceJarUrlMethod = ReflectionUtils.findMethod(context.getClass(), "addResourceJarUrl", new Class[] { URL.class });
/*     */     }
/*     */     
/*     */ 
/*     */     protected void addJar(String jar)
/*     */     {
/* 119 */       URL url = getJarUrl(jar);
/* 120 */       if (url != null) {
/*     */         try {
/* 122 */           this.addResourceJarUrlMethod.invoke(getContext(), new Object[] { url });
/*     */         }
/*     */         catch (Exception ex) {
/* 125 */           throw new IllegalStateException(ex);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private URL getJarUrl(String jar) {
/*     */       try {
/* 132 */         return new URL(jar);
/*     */       }
/*     */       catch (MalformedURLException ex) {}
/*     */       
/* 136 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */     protected void addDir(String dir, URL url)
/*     */     {
/* 142 */       if ((getContext() instanceof ServletContext)) {
/*     */         try
/*     */         {
/* 145 */           Class<?> fileDirContextClass = Class.forName("org.apache.naming.resources.FileDirContext");
/*     */           
/* 147 */           Method setDocBaseMethod = ReflectionUtils.findMethod(fileDirContextClass, "setDocBase", new Class[] { String.class });
/* 148 */           Object fileDirContext = fileDirContextClass.newInstance();
/* 149 */           setDocBaseMethod.invoke(fileDirContext, new Object[] { dir });
/* 150 */           Method addResourcesDirContextMethod = ReflectionUtils.findMethod(StandardContext.class, "addResourcesDirContext", new Class[] { DirContext.class });
/*     */           
/*     */ 
/* 153 */           addResourcesDirContextMethod.invoke(getContext(), new Object[] { fileDirContext });
/*     */         }
/*     */         catch (Exception ex) {
/* 156 */           throw new IllegalStateException("Tomcat 7 reflection failed", ex);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static class Tomcat8Resources
/*     */     extends TomcatResources
/*     */   {
/*     */     Tomcat8Resources(Context context)
/*     */     {
/* 168 */       super();
/*     */     }
/*     */     
/*     */     protected void addJar(String jar)
/*     */     {
/* 173 */       addResourceSet(jar);
/*     */     }
/*     */     
/*     */     protected void addDir(String dir, URL url)
/*     */     {
/* 178 */       addResourceSet(url.toString());
/*     */     }
/*     */     
/*     */     private void addResourceSet(String resource) {
/*     */       try {
/* 183 */         if (isInsideNestedJar(resource))
/*     */         {
/*     */ 
/*     */ 
/* 187 */           resource = resource.substring(0, resource.length() - 2);
/*     */         }
/* 189 */         URL url = new URL(resource);
/* 190 */         String path = "/META-INF/resources";
/* 191 */         getContext().getResources().createWebResourceSet(WebResourceRoot.ResourceSetType.RESOURCE_JAR, "/", url, path);
/*     */       }
/*     */       catch (Exception localException) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private boolean isInsideNestedJar(String dir)
/*     */     {
/* 200 */       return dir.indexOf("!/") < dir.lastIndexOf("!/");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\embedded\tomcat\TomcatResources.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */