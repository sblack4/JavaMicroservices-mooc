/*     */ package org.springframework.boot.context.event;
/*     */ 
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.boot.SpringApplicationRunListener;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.event.ApplicationEventMulticaster;
/*     */ import org.springframework.context.event.SimpleApplicationEventMulticaster;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EventPublishingRunListener
/*     */   implements SpringApplicationRunListener, Ordered
/*     */ {
/*     */   private final SpringApplication application;
/*     */   private final String[] args;
/*     */   private final ApplicationEventMulticaster initialMulticaster;
/*     */   
/*     */   public EventPublishingRunListener(SpringApplication application, String[] args)
/*     */   {
/*  47 */     this.application = application;
/*  48 */     this.args = args;
/*  49 */     this.initialMulticaster = new SimpleApplicationEventMulticaster();
/*  50 */     for (ApplicationListener<?> listener : application.getListeners()) {
/*  51 */       this.initialMulticaster.addApplicationListener(listener);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getOrder()
/*     */   {
/*  57 */     return 0;
/*     */   }
/*     */   
/*     */   public void started()
/*     */   {
/*  62 */     this.initialMulticaster.multicastEvent(new ApplicationStartedEvent(this.application, this.args));
/*     */   }
/*     */   
/*     */ 
/*     */   public void environmentPrepared(ConfigurableEnvironment environment)
/*     */   {
/*  68 */     this.initialMulticaster.multicastEvent(new ApplicationEnvironmentPreparedEvent(this.application, this.args, environment));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void contextPrepared(ConfigurableApplicationContext context) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void contextLoaded(ConfigurableApplicationContext context)
/*     */   {
/*  79 */     for (ApplicationListener<?> listener : this.application.getListeners()) {
/*  80 */       if ((listener instanceof ApplicationContextAware)) {
/*  81 */         ((ApplicationContextAware)listener).setApplicationContext(context);
/*     */       }
/*  83 */       context.addApplicationListener(listener);
/*     */     }
/*  85 */     this.initialMulticaster.multicastEvent(new ApplicationPreparedEvent(this.application, this.args, context));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void finished(ConfigurableApplicationContext context, Throwable exception)
/*     */   {
/*  93 */     context.publishEvent(getFinishedEvent(context, exception));
/*     */   }
/*     */   
/*     */   private SpringApplicationEvent getFinishedEvent(ConfigurableApplicationContext context, Throwable exception)
/*     */   {
/*  98 */     if (exception != null) {
/*  99 */       return new ApplicationFailedEvent(this.application, this.args, context, exception);
/*     */     }
/*     */     
/* 102 */     return new ApplicationReadyEvent(this.application, this.args, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\event\EventPublishingRunListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */