/*     */ package org.springframework.boot.context.embedded.tomcat;
/*     */ 
/*     */ import java.net.URL;
/*     */ import org.apache.catalina.loader.WebappClassLoader;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TomcatEmbeddedWebappClassLoader
/*     */   extends WebappClassLoader
/*     */ {
/*  36 */   private static final Log logger = LogFactory.getLog(TomcatEmbeddedWebappClassLoader.class);
/*     */   
/*     */ 
/*     */   public TomcatEmbeddedWebappClassLoader() {}
/*     */   
/*     */   public TomcatEmbeddedWebappClassLoader(ClassLoader parent)
/*     */   {
/*  43 */     super(parent);
/*     */   }
/*     */   
/*     */   public synchronized Class<?> loadClass(String name, boolean resolve)
/*     */     throws ClassNotFoundException
/*     */   {
/*  49 */     Class<?> resultClass = null;
/*     */     
/*     */ 
/*  52 */     resultClass = resultClass == null ? findLoadedClass0(name) : resultClass;
/*  53 */     resultClass = resultClass == null ? findLoadedClass(name) : resultClass;
/*  54 */     if (resultClass != null) {
/*  55 */       return resolveIfNecessary(resultClass, resolve);
/*     */     }
/*     */     
/*     */ 
/*  59 */     checkPackageAccess(name);
/*     */     
/*     */ 
/*  62 */     boolean delegateLoad = (this.delegate) || (filter(name, true));
/*     */     
/*  64 */     if (delegateLoad) {
/*  65 */       resultClass = resultClass == null ? loadFromParent(name) : resultClass;
/*     */     }
/*  67 */     resultClass = resultClass == null ? findClassIgnoringNotFound(name) : resultClass;
/*     */     
/*  69 */     if (!delegateLoad) {
/*  70 */       resultClass = resultClass == null ? loadFromParent(name) : resultClass;
/*     */     }
/*     */     
/*  73 */     if (resultClass == null) {
/*  74 */       throw new ClassNotFoundException(name);
/*     */     }
/*     */     
/*  77 */     return resolveIfNecessary(resultClass, resolve);
/*     */   }
/*     */   
/*     */   private Class<?> resolveIfNecessary(Class<?> resultClass, boolean resolve) {
/*  81 */     if (resolve) {
/*  82 */       resolveClass(resultClass);
/*     */     }
/*  84 */     return resultClass;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void addURL(URL url)
/*     */   {
/*  90 */     if (logger.isTraceEnabled()) {
/*  91 */       logger.trace("Ignoring request to add " + url + " to the tomcat classloader");
/*     */     }
/*     */   }
/*     */   
/*     */   private Class<?> loadFromParent(String name) {
/*  96 */     if (this.parent == null) {
/*  97 */       return null;
/*     */     }
/*     */     try {
/* 100 */       return Class.forName(name, false, this.parent);
/*     */     }
/*     */     catch (ClassNotFoundException ex) {}
/* 103 */     return null;
/*     */   }
/*     */   
/*     */   private Class<?> findClassIgnoringNotFound(String name)
/*     */   {
/*     */     try {
/* 109 */       return findClass(name);
/*     */     }
/*     */     catch (ClassNotFoundException ex) {}
/* 112 */     return null;
/*     */   }
/*     */   
/*     */   private void checkPackageAccess(String name) throws ClassNotFoundException
/*     */   {
/* 117 */     if ((this.securityManager != null) && (name.lastIndexOf('.') >= 0)) {
/*     */       try
/*     */       {
/* 120 */         this.securityManager.checkPackageAccess(name.substring(0, name.lastIndexOf('.')));
/*     */       }
/*     */       catch (SecurityException ex) {
/* 123 */         throw new ClassNotFoundException("Security Violation, attempt to use Restricted Class: " + name, ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\embedded\tomcat\TomcatEmbeddedWebappClassLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */