/*     */ package org.springframework.boot.context.embedded.tomcat;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.tomcat.JarScanner;
/*     */ import org.apache.tomcat.JarScannerCallback;
/*     */ import org.apache.tomcat.util.scan.StandardJarScanFilter;
/*     */ import org.apache.tomcat.util.scan.StandardJarScanner;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SkipPatternJarScanner
/*     */   extends StandardJarScanner
/*     */ {
/*     */   private static final String JAR_SCAN_FILTER_CLASS = "org.apache.tomcat.JarScanFilter";
/*     */   private final JarScanner jarScanner;
/*     */   private final SkipPattern pattern;
/*     */   
/*     */   SkipPatternJarScanner(JarScanner jarScanner, String pattern)
/*     */   {
/*  54 */     Assert.notNull(jarScanner, "JarScanner must not be null");
/*  55 */     this.jarScanner = jarScanner;
/*  56 */     this.pattern = (pattern == null ? new SkipPattern() : new SkipPattern(pattern));
/*  57 */     setPatternToTomcat8SkipFilter(this.pattern);
/*     */   }
/*     */   
/*     */   private void setPatternToTomcat8SkipFilter(SkipPattern pattern) {
/*  61 */     if (ClassUtils.isPresent("org.apache.tomcat.JarScanFilter", null)) {
/*  62 */       new Tomcat8TldSkipSetter(this).setSkipPattern(pattern);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void scan(ServletContext context, ClassLoader classloader, JarScannerCallback callback, Set<String> jarsToSkip)
/*     */   {
/*  69 */     Method scanMethod = ReflectionUtils.findMethod(this.jarScanner.getClass(), "scan", new Class[] { ServletContext.class, ClassLoader.class, JarScannerCallback.class, Set.class });
/*     */     
/*     */ 
/*  72 */     Assert.notNull(scanMethod, "Unable to find scan method");
/*     */     try {
/*  74 */       scanMethod.invoke(this.jarScanner, new Object[] { context, classloader, callback, jarsToSkip == null ? this.pattern
/*  75 */         .asSet() : jarsToSkip });
/*     */     }
/*     */     catch (Exception ex) {
/*  78 */       throw new IllegalStateException("Tomcat 7 reflection failed", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void apply(TomcatEmbeddedContext context, String pattern)
/*     */   {
/*  88 */     SkipPatternJarScanner scanner = new SkipPatternJarScanner(context.getJarScanner(), pattern);
/*     */     
/*  90 */     context.setJarScanner(scanner);
/*     */   }
/*     */   
/*     */ 
/*     */   private static class Tomcat8TldSkipSetter
/*     */   {
/*     */     private final StandardJarScanner jarScanner;
/*     */     
/*     */ 
/*     */     Tomcat8TldSkipSetter(StandardJarScanner jarScanner)
/*     */     {
/* 101 */       this.jarScanner = jarScanner;
/*     */     }
/*     */     
/*     */     public void setSkipPattern(SkipPatternJarScanner.SkipPattern pattern) {
/* 105 */       StandardJarScanFilter filter = new StandardJarScanFilter();
/* 106 */       filter.setTldSkip(pattern.asCommaDelimitedString());
/* 107 */       this.jarScanner.setJarScanFilter(filter);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class SkipPattern
/*     */   {
/* 117 */     private Set<String> patterns = new LinkedHashSet();
/*     */     
/*     */     protected SkipPattern()
/*     */     {
/* 121 */       add("ant-*.jar");
/* 122 */       add("aspectj*.jar");
/* 123 */       add("commons-beanutils*.jar");
/* 124 */       add("commons-codec*.jar");
/* 125 */       add("commons-collections*.jar");
/* 126 */       add("commons-dbcp*.jar");
/* 127 */       add("commons-digester*.jar");
/* 128 */       add("commons-fileupload*.jar");
/* 129 */       add("commons-httpclient*.jar");
/* 130 */       add("commons-io*.jar");
/* 131 */       add("commons-lang*.jar");
/* 132 */       add("commons-logging*.jar");
/* 133 */       add("commons-math*.jar");
/* 134 */       add("commons-pool*.jar");
/* 135 */       add("geronimo-spec-jaxrpc*.jar");
/* 136 */       add("h2*.jar");
/* 137 */       add("hamcrest*.jar");
/* 138 */       add("hibernate*.jar");
/* 139 */       add("jmx*.jar");
/* 140 */       add("jmx-tools-*.jar");
/* 141 */       add("jta*.jar");
/* 142 */       add("junit-*.jar");
/* 143 */       add("httpclient*.jar");
/* 144 */       add("log4j-*.jar");
/* 145 */       add("mail*.jar");
/* 146 */       add("org.hamcrest*.jar");
/* 147 */       add("slf4j*.jar");
/* 148 */       add("tomcat-embed-core-*.jar");
/* 149 */       add("tomcat-embed-logging-*.jar");
/* 150 */       add("tomcat-jdbc-*.jar");
/* 151 */       add("tomcat-juli-*.jar");
/* 152 */       add("tools.jar");
/* 153 */       add("wsdl4j*.jar");
/* 154 */       add("xercesImpl-*.jar");
/* 155 */       add("xmlParserAPIs-*.jar");
/* 156 */       add("xml-apis-*.jar");
/*     */       
/*     */ 
/* 159 */       add("antlr-*.jar");
/* 160 */       add("aopalliance-*.jar");
/* 161 */       add("aspectjrt-*.jar");
/* 162 */       add("aspectjweaver-*.jar");
/* 163 */       add("classmate-*.jar");
/* 164 */       add("dom4j-*.jar");
/* 165 */       add("ecj-*.jar");
/* 166 */       add("ehcache-core-*.jar");
/* 167 */       add("hibernate-core-*.jar");
/* 168 */       add("hibernate-commons-annotations-*.jar");
/* 169 */       add("hibernate-entitymanager-*.jar");
/* 170 */       add("hibernate-jpa-2.1-api-*.jar");
/* 171 */       add("hibernate-validator-*.jar");
/* 172 */       add("hsqldb-*.jar");
/* 173 */       add("jackson-annotations-*.jar");
/* 174 */       add("jackson-core-*.jar");
/* 175 */       add("jackson-databind-*.jar");
/* 176 */       add("jandex-*.jar");
/* 177 */       add("javassist-*.jar");
/* 178 */       add("jboss-logging-*.jar");
/* 179 */       add("jboss-transaction-api_*.jar");
/* 180 */       add("jcl-over-slf4j-*.jar");
/* 181 */       add("jdom-*.jar");
/* 182 */       add("jul-to-slf4j-*.jar");
/* 183 */       add("log4j-over-slf4j-*.jar");
/* 184 */       add("logback-classic-*.jar");
/* 185 */       add("logback-core-*.jar");
/* 186 */       add("rome-*.jar");
/* 187 */       add("slf4j-api-*.jar");
/* 188 */       add("spring-aop-*.jar");
/* 189 */       add("spring-aspects-*.jar");
/* 190 */       add("spring-beans-*.jar");
/* 191 */       add("spring-boot-*.jar");
/* 192 */       add("spring-core-*.jar");
/* 193 */       add("spring-context-*.jar");
/* 194 */       add("spring-data-*.jar");
/* 195 */       add("spring-expression-*.jar");
/* 196 */       add("spring-jdbc-*.jar,");
/* 197 */       add("spring-orm-*.jar");
/* 198 */       add("spring-oxm-*.jar");
/* 199 */       add("spring-tx-*.jar");
/* 200 */       add("snakeyaml-*.jar");
/* 201 */       add("tomcat-embed-el-*.jar");
/* 202 */       add("validation-api-*.jar");
/* 203 */       add("xml-apis-*.jar");
/*     */     }
/*     */     
/*     */     SkipPattern(String patterns) {
/* 207 */       StringTokenizer tokenizer = new StringTokenizer(patterns, ",");
/* 208 */       while (tokenizer.hasMoreElements()) {
/* 209 */         add(tokenizer.nextToken());
/*     */       }
/*     */     }
/*     */     
/*     */     protected void add(String patterns) {
/* 214 */       Assert.notNull(patterns, "Patterns must not be null");
/* 215 */       if ((patterns.length() > 0) && (!patterns.trim().startsWith(","))) {
/* 216 */         this.patterns.add(",");
/*     */       }
/* 218 */       this.patterns.add(patterns);
/*     */     }
/*     */     
/*     */     public String asCommaDelimitedString() {
/* 222 */       return StringUtils.collectionToCommaDelimitedString(this.patterns);
/*     */     }
/*     */     
/*     */     public Set<String> asSet() {
/* 226 */       return Collections.unmodifiableSet(this.patterns);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\embedded\tomcat\SkipPatternJarScanner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */