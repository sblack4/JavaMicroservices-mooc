/*     */ package org.springframework.boot.context.embedded.undertow;
/*     */ 
/*     */ import io.undertow.Handlers;
/*     */ import io.undertow.Undertow;
/*     */ import io.undertow.Undertow.Builder;
/*     */ import io.undertow.attribute.RequestHeaderAttribute;
/*     */ import io.undertow.predicate.Predicate;
/*     */ import io.undertow.predicate.Predicates;
/*     */ import io.undertow.server.HttpHandler;
/*     */ import io.undertow.server.HttpServerExchange;
/*     */ import io.undertow.server.handlers.PathHandler;
/*     */ import io.undertow.server.handlers.encoding.ContentEncodingRepository;
/*     */ import io.undertow.server.handlers.encoding.EncodingHandler;
/*     */ import io.undertow.server.handlers.encoding.GzipEncodingProvider;
/*     */ import io.undertow.servlet.api.DeploymentManager;
/*     */ import io.undertow.util.HeaderMap;
/*     */ import io.undertow.util.Headers;
/*     */ import io.undertow.util.HttpString;
/*     */ import java.lang.reflect.Field;
/*     */ import java.net.BindException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.boot.context.embedded.Compression;
/*     */ import org.springframework.boot.context.embedded.EmbeddedServletContainer;
/*     */ import org.springframework.boot.context.embedded.EmbeddedServletContainerException;
/*     */ import org.springframework.boot.context.embedded.PortInUseException;
/*     */ import org.springframework.util.MimeType;
/*     */ import org.springframework.util.MimeTypeUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.xnio.channels.BoundChannel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UndertowEmbeddedServletContainer
/*     */   implements EmbeddedServletContainer
/*     */ {
/*  71 */   private static final Log logger = LogFactory.getLog(UndertowEmbeddedServletContainer.class);
/*     */   
/*  73 */   private final Object monitor = new Object();
/*     */   
/*     */   private final Undertow.Builder builder;
/*     */   
/*     */   private final DeploymentManager manager;
/*     */   
/*     */   private final String contextPath;
/*     */   
/*     */   private final boolean useForwardHeaders;
/*     */   
/*     */   private final boolean autoStart;
/*     */   
/*     */   private final Compression compression;
/*     */   
/*     */   private final String serverHeader;
/*     */   
/*     */   private Undertow undertow;
/*     */   
/*  91 */   private boolean started = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public UndertowEmbeddedServletContainer(Undertow.Builder builder, DeploymentManager manager, String contextPath, int port, boolean autoStart, Compression compression)
/*     */   {
/* 107 */     this(builder, manager, contextPath, false, autoStart, compression);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public UndertowEmbeddedServletContainer(Undertow.Builder builder, DeploymentManager manager, String contextPath, int port, boolean useForwardHeaders, boolean autoStart, Compression compression)
/*     */   {
/* 126 */     this(builder, manager, contextPath, useForwardHeaders, autoStart, compression);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public UndertowEmbeddedServletContainer(Undertow.Builder builder, DeploymentManager manager, String contextPath, int port, boolean useForwardHeaders, boolean autoStart, Compression compression, String serverHeader)
/*     */   {
/* 146 */     this(builder, manager, contextPath, useForwardHeaders, autoStart, compression, serverHeader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UndertowEmbeddedServletContainer(Undertow.Builder builder, DeploymentManager manager, String contextPath, boolean autoStart, Compression compression)
/*     */   {
/* 160 */     this(builder, manager, contextPath, false, autoStart, compression);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UndertowEmbeddedServletContainer(Undertow.Builder builder, DeploymentManager manager, String contextPath, boolean useForwardHeaders, boolean autoStart, Compression compression)
/*     */   {
/* 175 */     this(builder, manager, contextPath, useForwardHeaders, autoStart, compression, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UndertowEmbeddedServletContainer(Undertow.Builder builder, DeploymentManager manager, String contextPath, boolean useForwardHeaders, boolean autoStart, Compression compression, String serverHeader)
/*     */   {
/* 192 */     this.builder = builder;
/* 193 */     this.manager = manager;
/* 194 */     this.contextPath = contextPath;
/* 195 */     this.useForwardHeaders = useForwardHeaders;
/* 196 */     this.autoStart = autoStart;
/* 197 */     this.compression = compression;
/* 198 */     this.serverHeader = serverHeader;
/*     */   }
/*     */   
/*     */   public void start() throws EmbeddedServletContainerException
/*     */   {
/* 203 */     synchronized (this.monitor) {
/*     */       try {
/* 205 */         if (!this.autoStart) {
/* 206 */           return;
/*     */         }
/* 208 */         if (this.undertow == null) {
/* 209 */           this.undertow = createUndertowServer();
/*     */         }
/* 211 */         this.undertow.start();
/* 212 */         this.started = true;
/* 213 */         logger
/* 214 */           .info("Undertow started on port(s) " + getPortsDescription());
/*     */       }
/*     */       catch (Exception ex) {
/* 217 */         if (findBindException(ex) != null) {
/* 218 */           List<Port> failedPorts = getConfiguredPorts();
/* 219 */           List<Port> actualPorts = getActualPorts();
/* 220 */           failedPorts.removeAll(actualPorts);
/* 221 */           if (failedPorts.size() == 1)
/*     */           {
/* 223 */             throw new PortInUseException(((Port)failedPorts.iterator().next()).getNumber());
/*     */           }
/*     */         }
/* 226 */         throw new EmbeddedServletContainerException("Unable to start embedded Undertow", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private BindException findBindException(Exception ex)
/*     */   {
/* 233 */     Throwable candidate = ex;
/* 234 */     while (candidate != null) {
/* 235 */       if ((candidate instanceof BindException)) {
/* 236 */         return (BindException)candidate;
/*     */       }
/* 238 */       candidate = candidate.getCause();
/*     */     }
/* 240 */     return null;
/*     */   }
/*     */   
/*     */   private Undertow createUndertowServer() throws ServletException {
/* 244 */     HttpHandler httpHandler = this.manager.start();
/* 245 */     httpHandler = getContextHandler(httpHandler);
/* 246 */     if (this.useForwardHeaders) {
/* 247 */       httpHandler = Handlers.proxyPeerAddress(httpHandler);
/*     */     }
/* 249 */     if (StringUtils.hasText(this.serverHeader)) {
/* 250 */       httpHandler = Handlers.header(httpHandler, "Server", this.serverHeader);
/*     */     }
/* 252 */     this.builder.setHandler(httpHandler);
/* 253 */     return this.builder.build();
/*     */   }
/*     */   
/*     */   private HttpHandler getContextHandler(HttpHandler httpHandler) {
/* 257 */     HttpHandler contextHandler = configurationCompressionIfNecessary(httpHandler);
/* 258 */     if (StringUtils.isEmpty(this.contextPath)) {
/* 259 */       return contextHandler;
/*     */     }
/* 261 */     return Handlers.path().addPrefixPath(this.contextPath, contextHandler);
/*     */   }
/*     */   
/*     */   private HttpHandler configurationCompressionIfNecessary(HttpHandler httpHandler) {
/* 265 */     if ((this.compression == null) || (!this.compression.getEnabled())) {
/* 266 */       return httpHandler;
/*     */     }
/* 268 */     ContentEncodingRepository repository = new ContentEncodingRepository();
/* 269 */     repository.addEncodingHandler("gzip", new GzipEncodingProvider(), 50, 
/* 270 */       Predicates.and(getCompressionPredicates(this.compression)));
/* 271 */     return new EncodingHandler(repository).setNext(httpHandler);
/*     */   }
/*     */   
/*     */   private Predicate[] getCompressionPredicates(Compression compression) {
/* 275 */     List<Predicate> predicates = new ArrayList();
/* 276 */     predicates.add(new MaxSizePredicate(compression.getMinResponseSize()));
/* 277 */     predicates.add(new CompressibleMimeTypePredicate(compression.getMimeTypes()));
/* 278 */     if (compression.getExcludedUserAgents() != null) {
/* 279 */       for (String agent : compression.getExcludedUserAgents()) {
/* 280 */         RequestHeaderAttribute agentHeader = new RequestHeaderAttribute(new HttpString("User-Agent"));
/*     */         
/* 282 */         predicates.add(Predicates.not(Predicates.regex(agentHeader, agent)));
/*     */       }
/*     */     }
/* 285 */     return (Predicate[])predicates.toArray(new Predicate[predicates.size()]);
/*     */   }
/*     */   
/*     */   private String getPortsDescription() {
/* 289 */     List<Port> ports = getActualPorts();
/* 290 */     if (!ports.isEmpty()) {
/* 291 */       return StringUtils.collectionToDelimitedString(ports, " ");
/*     */     }
/* 293 */     return "unknown";
/*     */   }
/*     */   
/*     */   private List<Port> getActualPorts() {
/* 297 */     List<Port> ports = new ArrayList();
/*     */     try {
/* 299 */       if (!this.autoStart) {
/* 300 */         ports.add(new Port(-1, "unknown", null));
/*     */       }
/*     */       else {
/* 303 */         for (BoundChannel channel : extractChannels()) {
/* 304 */           ports.add(getPortFromChannel(channel));
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception localException1) {}
/*     */     
/*     */ 
/* 311 */     return ports;
/*     */   }
/*     */   
/*     */   private List<BoundChannel> extractChannels()
/*     */   {
/* 316 */     Field channelsField = ReflectionUtils.findField(Undertow.class, "channels");
/* 317 */     ReflectionUtils.makeAccessible(channelsField);
/* 318 */     return (List)ReflectionUtils.getField(channelsField, this.undertow);
/*     */   }
/*     */   
/*     */   private Port getPortFromChannel(BoundChannel channel)
/*     */   {
/* 323 */     SocketAddress socketAddress = channel.getLocalAddress();
/* 324 */     if ((socketAddress instanceof InetSocketAddress)) {
/* 325 */       String protocol = ReflectionUtils.findField(channel.getClass(), "ssl") != null ? "https" : "http";
/*     */       
/* 327 */       return new Port(((InetSocketAddress)socketAddress).getPort(), protocol, null);
/*     */     }
/* 329 */     return null;
/*     */   }
/*     */   
/*     */   private List<Port> getConfiguredPorts() {
/* 333 */     List<Port> ports = new ArrayList();
/* 334 */     for (Object listener : extractListeners()) {
/*     */       try {
/* 336 */         ports.add(getPortFromListener(listener));
/*     */       }
/*     */       catch (Exception localException) {}
/*     */     }
/*     */     
/*     */ 
/* 342 */     return ports;
/*     */   }
/*     */   
/*     */   private List<Object> extractListeners()
/*     */   {
/* 347 */     Field listenersField = ReflectionUtils.findField(Undertow.class, "listeners");
/* 348 */     ReflectionUtils.makeAccessible(listenersField);
/* 349 */     return (List)ReflectionUtils.getField(listenersField, this.undertow);
/*     */   }
/*     */   
/*     */   private Port getPortFromListener(Object listener) {
/* 353 */     Field typeField = ReflectionUtils.findField(listener.getClass(), "type");
/* 354 */     ReflectionUtils.makeAccessible(typeField);
/* 355 */     String protocol = ReflectionUtils.getField(typeField, listener).toString();
/* 356 */     Field portField = ReflectionUtils.findField(listener.getClass(), "port");
/* 357 */     ReflectionUtils.makeAccessible(portField);
/* 358 */     int port = ((Integer)ReflectionUtils.getField(portField, listener)).intValue();
/* 359 */     return new Port(port, protocol, null);
/*     */   }
/*     */   
/*     */   public void stop() throws EmbeddedServletContainerException
/*     */   {
/* 364 */     synchronized (this.monitor) {
/* 365 */       if (this.started) {
/*     */         try {
/* 367 */           this.started = false;
/* 368 */           this.manager.stop();
/* 369 */           this.undertow.stop();
/*     */         }
/*     */         catch (Exception ex) {
/* 372 */           throw new EmbeddedServletContainerException("Unable to stop undertow", ex);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 381 */     List<Port> ports = getActualPorts();
/* 382 */     if (ports.isEmpty()) {
/* 383 */       return 0;
/*     */     }
/* 385 */     return ((Port)ports.get(0)).getNumber();
/*     */   }
/*     */   
/*     */ 
/*     */   private static final class Port
/*     */   {
/*     */     private final int number;
/*     */     
/*     */     private final String protocol;
/*     */     
/*     */ 
/*     */     private Port(int number, String protocol)
/*     */     {
/* 398 */       this.number = number;
/* 399 */       this.protocol = protocol;
/*     */     }
/*     */     
/*     */     public int getNumber() {
/* 403 */       return this.number;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 408 */       return this.number + " (" + this.protocol + ")";
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 413 */       return this.number;
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/* 418 */       if (this == obj) {
/* 419 */         return true;
/*     */       }
/* 421 */       if (obj == null) {
/* 422 */         return false;
/*     */       }
/* 424 */       if (getClass() != obj.getClass()) {
/* 425 */         return false;
/*     */       }
/* 427 */       Port other = (Port)obj;
/* 428 */       if (this.number != other.number) {
/* 429 */         return false;
/*     */       }
/* 431 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class CompressibleMimeTypePredicate implements Predicate
/*     */   {
/*     */     private final List<MimeType> mimeTypes;
/*     */     
/*     */     CompressibleMimeTypePredicate(String[] mimeTypes)
/*     */     {
/* 441 */       this.mimeTypes = new ArrayList(mimeTypes.length);
/* 442 */       for (String mimeTypeString : mimeTypes) {
/* 443 */         this.mimeTypes.add(MimeTypeUtils.parseMimeType(mimeTypeString));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean resolve(HttpServerExchange value)
/*     */     {
/* 450 */       String contentType = value.getResponseHeaders().getFirst("Content-Type");
/* 451 */       if (contentType != null) {
/* 452 */         for (MimeType mimeType : this.mimeTypes)
/*     */         {
/* 454 */           if (mimeType.isCompatibleWith(MimeTypeUtils.parseMimeType(contentType))) {
/* 455 */             return true;
/*     */           }
/*     */         }
/*     */       }
/* 459 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class MaxSizePredicate
/*     */     implements Predicate
/*     */   {
/*     */     private final Predicate maxContentSize;
/*     */     
/*     */ 
/*     */     MaxSizePredicate(int size)
/*     */     {
/* 473 */       this.maxContentSize = Predicates.maxContentSize(size);
/*     */     }
/*     */     
/*     */     public boolean resolve(HttpServerExchange value)
/*     */     {
/* 478 */       if (value.getResponseHeaders().contains(Headers.CONTENT_LENGTH)) {
/* 479 */         return this.maxContentSize.resolve(value);
/*     */       }
/* 481 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\embedded\undertow\UndertowEmbeddedServletContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */