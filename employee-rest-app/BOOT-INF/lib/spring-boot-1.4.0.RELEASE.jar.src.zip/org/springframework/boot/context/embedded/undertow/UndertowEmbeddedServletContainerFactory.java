/*     */ package org.springframework.boot.context.embedded.undertow;
/*     */ 
/*     */ import io.undertow.Undertow;
/*     */ import io.undertow.Undertow.Builder;
/*     */ import io.undertow.UndertowMessages;
/*     */ import io.undertow.server.HandlerWrapper;
/*     */ import io.undertow.server.HttpHandler;
/*     */ import io.undertow.server.handlers.accesslog.AccessLogHandler;
/*     */ import io.undertow.server.handlers.accesslog.AccessLogReceiver;
/*     */ import io.undertow.server.handlers.accesslog.DefaultAccessLogReceiver;
/*     */ import io.undertow.server.handlers.resource.FileResourceManager;
/*     */ import io.undertow.server.handlers.resource.Resource;
/*     */ import io.undertow.server.handlers.resource.ResourceChangeListener;
/*     */ import io.undertow.server.handlers.resource.ResourceManager;
/*     */ import io.undertow.server.handlers.resource.URLResource;
/*     */ import io.undertow.server.session.SessionManager;
/*     */ import io.undertow.servlet.Servlets;
/*     */ import io.undertow.servlet.api.Deployment;
/*     */ import io.undertow.servlet.api.DeploymentInfo;
/*     */ import io.undertow.servlet.api.DeploymentManager;
/*     */ import io.undertow.servlet.api.MimeMapping;
/*     */ import io.undertow.servlet.api.ServletContainer;
/*     */ import io.undertow.servlet.api.ServletContainerInitializerInfo;
/*     */ import io.undertow.servlet.api.ServletStackTraces;
/*     */ import io.undertow.servlet.handlers.DefaultServlet;
/*     */ import io.undertow.servlet.util.ImmediateInstanceFactory;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.KeyManagementException;
/*     */ import java.security.KeyStore;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.net.ssl.KeyManager;
/*     */ import javax.net.ssl.KeyManagerFactory;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.TrustManager;
/*     */ import javax.net.ssl.TrustManagerFactory;
/*     */ import javax.servlet.ServletContainerInitializer;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import org.springframework.boot.context.embedded.AbstractEmbeddedServletContainerFactory;
/*     */ import org.springframework.boot.context.embedded.EmbeddedServletContainer;
/*     */ import org.springframework.boot.context.embedded.JspServlet;
/*     */ import org.springframework.boot.context.embedded.MimeMappings.Mapping;
/*     */ import org.springframework.boot.context.embedded.Ssl;
/*     */ import org.springframework.boot.context.embedded.Ssl.ClientAuth;
/*     */ import org.springframework.boot.context.embedded.SslStoreProvider;
/*     */ import org.springframework.boot.web.servlet.ServletContextInitializer;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.xnio.OptionMap;
/*     */ import org.xnio.OptionMap.Builder;
/*     */ import org.xnio.Options;
/*     */ import org.xnio.Sequence;
/*     */ import org.xnio.SslClientAuthMode;
/*     */ import org.xnio.Xnio;
/*     */ import org.xnio.XnioWorker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UndertowEmbeddedServletContainerFactory
/*     */   extends AbstractEmbeddedServletContainerFactory
/*     */   implements ResourceLoaderAware
/*     */ {
/* 103 */   private static final Set<Class<?>> NO_CLASSES = ;
/*     */   
/* 105 */   private List<UndertowBuilderCustomizer> builderCustomizers = new ArrayList();
/*     */   
/* 107 */   private List<UndertowDeploymentInfoCustomizer> deploymentInfoCustomizers = new ArrayList();
/*     */   
/*     */   private ResourceLoader resourceLoader;
/*     */   
/*     */   private Integer bufferSize;
/*     */   
/*     */   private Integer buffersPerRegion;
/*     */   
/*     */   private Integer ioThreads;
/*     */   
/*     */   private Integer workerThreads;
/*     */   
/*     */   private Boolean directBuffers;
/*     */   
/*     */   private File accessLogDirectory;
/*     */   
/*     */   private String accessLogPattern;
/*     */   
/* 125 */   private boolean accessLogEnabled = false;
/*     */   
/*     */ 
/*     */   private boolean useForwardHeaders;
/*     */   
/*     */ 
/*     */ 
/*     */   public UndertowEmbeddedServletContainerFactory()
/*     */   {
/* 134 */     getJspServlet().setRegistered(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UndertowEmbeddedServletContainerFactory(int port)
/*     */   {
/* 143 */     super(port);
/* 144 */     getJspServlet().setRegistered(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UndertowEmbeddedServletContainerFactory(String contextPath, int port)
/*     */   {
/* 154 */     super(contextPath, port);
/* 155 */     getJspServlet().setRegistered(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBuilderCustomizers(Collection<? extends UndertowBuilderCustomizer> customizers)
/*     */   {
/* 165 */     Assert.notNull(customizers, "Customizers must not be null");
/* 166 */     this.builderCustomizers = new ArrayList(customizers);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<UndertowBuilderCustomizer> getBuilderCustomizers()
/*     */   {
/* 175 */     return this.builderCustomizers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addBuilderCustomizers(UndertowBuilderCustomizer... customizers)
/*     */   {
/* 184 */     Assert.notNull(customizers, "Customizers must not be null");
/* 185 */     this.builderCustomizers.addAll(Arrays.asList(customizers));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDeploymentInfoCustomizers(Collection<? extends UndertowDeploymentInfoCustomizer> customizers)
/*     */   {
/* 196 */     Assert.notNull(customizers, "Customizers must not be null");
/* 197 */     this.deploymentInfoCustomizers = new ArrayList(customizers);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<UndertowDeploymentInfoCustomizer> getDeploymentInfoCustomizers()
/*     */   {
/* 207 */     return this.deploymentInfoCustomizers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addDeploymentInfoCustomizers(UndertowDeploymentInfoCustomizer... customizers)
/*     */   {
/* 217 */     Assert.notNull(customizers, "UndertowDeploymentInfoCustomizers must not be null");
/* 218 */     this.deploymentInfoCustomizers.addAll(Arrays.asList(customizers));
/*     */   }
/*     */   
/*     */ 
/*     */   public EmbeddedServletContainer getEmbeddedServletContainer(ServletContextInitializer... initializers)
/*     */   {
/* 224 */     DeploymentManager manager = createDeploymentManager(initializers);
/* 225 */     int port = getPort();
/* 226 */     Undertow.Builder builder = createBuilder(port);
/* 227 */     return getUndertowEmbeddedServletContainer(builder, manager, port);
/*     */   }
/*     */   
/*     */   private Undertow.Builder createBuilder(int port) {
/* 231 */     Undertow.Builder builder = Undertow.builder();
/* 232 */     if (this.bufferSize != null) {
/* 233 */       builder.setBufferSize(this.bufferSize.intValue());
/*     */     }
/* 235 */     if (this.buffersPerRegion != null) {
/* 236 */       builder.setBuffersPerRegion(this.buffersPerRegion.intValue());
/*     */     }
/* 238 */     if (this.ioThreads != null) {
/* 239 */       builder.setIoThreads(this.ioThreads.intValue());
/*     */     }
/* 241 */     if (this.workerThreads != null) {
/* 242 */       builder.setWorkerThreads(this.workerThreads.intValue());
/*     */     }
/* 244 */     if (this.directBuffers != null) {
/* 245 */       builder.setDirectBuffers(this.directBuffers.booleanValue());
/*     */     }
/* 247 */     if ((getSsl() != null) && (getSsl().isEnabled())) {
/* 248 */       configureSsl(getSsl(), port, builder);
/*     */     }
/*     */     else {
/* 251 */       builder.addHttpListener(port, getListenAddress());
/*     */     }
/* 253 */     for (UndertowBuilderCustomizer customizer : this.builderCustomizers) {
/* 254 */       customizer.customize(builder);
/*     */     }
/* 256 */     return builder;
/*     */   }
/*     */   
/*     */   private void configureSsl(Ssl ssl, int port, Undertow.Builder builder) {
/*     */     try {
/* 261 */       SSLContext sslContext = SSLContext.getInstance(ssl.getProtocol());
/* 262 */       sslContext.init(getKeyManagers(), getTrustManagers(), null);
/* 263 */       builder.addHttpsListener(port, getListenAddress(), sslContext);
/* 264 */       builder.setSocketOption(Options.SSL_CLIENT_AUTH_MODE, 
/* 265 */         getSslClientAuthMode(ssl));
/* 266 */       if (ssl.getEnabledProtocols() != null) {
/* 267 */         builder.setSocketOption(Options.SSL_ENABLED_PROTOCOLS, 
/* 268 */           Sequence.of(ssl.getEnabledProtocols()));
/*     */       }
/* 270 */       if (ssl.getCiphers() != null) {
/* 271 */         builder.setSocketOption(Options.SSL_ENABLED_CIPHER_SUITES, 
/* 272 */           Sequence.of(ssl.getCiphers()));
/*     */       }
/*     */     }
/*     */     catch (NoSuchAlgorithmException ex) {
/* 276 */       throw new IllegalStateException(ex);
/*     */     }
/*     */     catch (KeyManagementException ex) {
/* 279 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private String getListenAddress() {
/* 284 */     if (getAddress() == null) {
/* 285 */       return "0.0.0.0";
/*     */     }
/* 287 */     return getAddress().getHostAddress();
/*     */   }
/*     */   
/*     */   private SslClientAuthMode getSslClientAuthMode(Ssl ssl) {
/* 291 */     if (ssl.getClientAuth() == Ssl.ClientAuth.NEED) {
/* 292 */       return SslClientAuthMode.REQUIRED;
/*     */     }
/* 294 */     if (ssl.getClientAuth() == Ssl.ClientAuth.WANT) {
/* 295 */       return SslClientAuthMode.REQUESTED;
/*     */     }
/* 297 */     return SslClientAuthMode.NOT_REQUESTED;
/*     */   }
/*     */   
/*     */   private KeyManager[] getKeyManagers() {
/*     */     try {
/* 302 */       KeyStore keyStore = getKeyStore();
/*     */       
/* 304 */       KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
/* 305 */       Ssl ssl = getSsl();
/*     */       
/* 307 */       char[] keyPassword = ssl.getKeyPassword() != null ? ssl.getKeyPassword().toCharArray() : null;
/* 308 */       if ((keyPassword == null) && (ssl.getKeyStorePassword() != null)) {
/* 309 */         keyPassword = ssl.getKeyStorePassword().toCharArray();
/*     */       }
/* 311 */       keyManagerFactory.init(keyStore, keyPassword);
/* 312 */       return keyManagerFactory.getKeyManagers();
/*     */     }
/*     */     catch (Exception ex) {
/* 315 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private KeyStore getKeyStore() throws Exception {
/* 320 */     if (getSslStoreProvider() != null) {
/* 321 */       return getSslStoreProvider().getKeyStore();
/*     */     }
/* 323 */     Ssl ssl = getSsl();
/* 324 */     return loadKeyStore(ssl.getKeyStoreType(), ssl.getKeyStore(), ssl
/* 325 */       .getKeyStorePassword());
/*     */   }
/*     */   
/*     */   private TrustManager[] getTrustManagers() {
/*     */     try {
/* 330 */       KeyStore store = getTrustStore();
/*     */       
/* 332 */       TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
/* 333 */       trustManagerFactory.init(store);
/* 334 */       return trustManagerFactory.getTrustManagers();
/*     */     }
/*     */     catch (Exception ex) {
/* 337 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private KeyStore getTrustStore() throws Exception {
/* 342 */     if (getSslStoreProvider() != null) {
/* 343 */       return getSslStoreProvider().getTrustStore();
/*     */     }
/* 345 */     Ssl ssl = getSsl();
/* 346 */     return loadKeyStore(ssl.getTrustStoreType(), ssl.getTrustStore(), ssl
/* 347 */       .getTrustStorePassword());
/*     */   }
/*     */   
/*     */   private KeyStore loadKeyStore(String type, String resource, String password) throws Exception
/*     */   {
/* 352 */     type = type == null ? "JKS" : type;
/* 353 */     if (resource == null) {
/* 354 */       return null;
/*     */     }
/* 356 */     KeyStore store = KeyStore.getInstance(type);
/* 357 */     URL url = ResourceUtils.getURL(resource);
/* 358 */     store.load(url.openStream(), password == null ? null : password.toCharArray());
/* 359 */     return store;
/*     */   }
/*     */   
/*     */   private DeploymentManager createDeploymentManager(ServletContextInitializer... initializers)
/*     */   {
/* 364 */     DeploymentInfo deployment = Servlets.deployment();
/* 365 */     registerServletContainerInitializerToDriveServletContextInitializers(deployment, initializers);
/*     */     
/* 367 */     deployment.setClassLoader(getServletClassLoader());
/* 368 */     deployment.setContextPath(getContextPath());
/* 369 */     deployment.setDisplayName(getDisplayName());
/* 370 */     deployment.setDeploymentName("spring-boot");
/* 371 */     if (isRegisterDefaultServlet()) {
/* 372 */       deployment.addServlet(Servlets.servlet("default", DefaultServlet.class));
/*     */     }
/* 374 */     configureErrorPages(deployment);
/* 375 */     deployment.setServletStackTraces(ServletStackTraces.NONE);
/* 376 */     deployment.setResourceManager(getDocumentRootResourceManager());
/* 377 */     configureMimeMappings(deployment);
/* 378 */     for (UndertowDeploymentInfoCustomizer customizer : this.deploymentInfoCustomizers) {
/* 379 */       customizer.customize(deployment);
/*     */     }
/* 381 */     if (isAccessLogEnabled()) {
/* 382 */       configureAccessLog(deployment);
/*     */     }
/* 384 */     if (isPersistSession()) {
/* 385 */       File dir = getValidSessionStoreDir();
/* 386 */       deployment.setSessionPersistenceManager(new FileSessionPersistence(dir));
/*     */     }
/* 388 */     addLocaleMappings(deployment);
/* 389 */     DeploymentManager manager = Servlets.newContainer().addDeployment(deployment);
/* 390 */     manager.deploy();
/* 391 */     SessionManager sessionManager = manager.getDeployment().getSessionManager();
/* 392 */     int sessionTimeout = getSessionTimeout() > 0 ? getSessionTimeout() : -1;
/* 393 */     sessionManager.setDefaultSessionTimeout(sessionTimeout);
/* 394 */     return manager;
/*     */   }
/*     */   
/*     */   private void configureAccessLog(DeploymentInfo deploymentInfo) {
/* 398 */     deploymentInfo.addInitialHandlerChainWrapper(new HandlerWrapper()
/*     */     {
/*     */       public HttpHandler wrap(HttpHandler handler)
/*     */       {
/* 402 */         return UndertowEmbeddedServletContainerFactory.this.createAccessLogHandler(handler);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private AccessLogHandler createAccessLogHandler(HttpHandler handler)
/*     */   {
/*     */     try {
/* 410 */       createAccessLogDirectoryIfNecessary();
/*     */       
/* 412 */       AccessLogReceiver accessLogReceiver = new DefaultAccessLogReceiver(createWorker(), this.accessLogDirectory, "access_log.");
/* 413 */       String formatString = this.accessLogPattern != null ? this.accessLogPattern : "common";
/*     */       
/*     */ 
/* 416 */       return new AccessLogHandler(handler, accessLogReceiver, formatString, Undertow.class.getClassLoader());
/*     */     }
/*     */     catch (IOException ex) {
/* 419 */       throw new IllegalStateException("Failed to create AccessLogHandler", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private void createAccessLogDirectoryIfNecessary() {
/* 424 */     Assert.state(this.accessLogDirectory != null, "Access log directory is not set");
/* 425 */     if ((!this.accessLogDirectory.isDirectory()) && (!this.accessLogDirectory.mkdirs())) {
/* 426 */       throw new IllegalStateException("Failed to create access log directory '" + this.accessLogDirectory + "'");
/*     */     }
/*     */   }
/*     */   
/*     */   private XnioWorker createWorker() throws IOException
/*     */   {
/* 432 */     Xnio xnio = Xnio.getInstance(Undertow.class.getClassLoader());
/* 433 */     return xnio.createWorker(
/* 434 */       OptionMap.builder().set(Options.THREAD_DAEMON, true).getMap());
/*     */   }
/*     */   
/*     */   private void addLocaleMappings(DeploymentInfo deployment) {
/* 438 */     for (Map.Entry<Locale, Charset> entry : getLocaleCharsetMappings().entrySet()) {
/* 439 */       Locale locale = (Locale)entry.getKey();
/* 440 */       Charset charset = (Charset)entry.getValue();
/* 441 */       deployment.addLocaleCharsetMapping(locale.toString(), charset.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   private void registerServletContainerInitializerToDriveServletContextInitializers(DeploymentInfo deployment, ServletContextInitializer... initializers)
/*     */   {
/* 447 */     ServletContextInitializer[] mergedInitializers = mergeInitializers(initializers);
/* 448 */     Initializer initializer = new Initializer(mergedInitializers);
/* 449 */     deployment.addServletContainerInitalizer(new ServletContainerInitializerInfo(Initializer.class, new ImmediateInstanceFactory(initializer), NO_CLASSES));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private ClassLoader getServletClassLoader()
/*     */   {
/* 456 */     if (this.resourceLoader != null) {
/* 457 */       return this.resourceLoader.getClassLoader();
/*     */     }
/* 459 */     return getClass().getClassLoader();
/*     */   }
/*     */   
/*     */   private ResourceManager getDocumentRootResourceManager() {
/* 463 */     File root = getCanonicalDocumentRoot();
/* 464 */     if (root.isDirectory()) {
/* 465 */       return new FileResourceManager(root, 0L);
/*     */     }
/* 467 */     if (root.isFile()) {
/* 468 */       return new JarResourceManager(root);
/*     */     }
/* 470 */     return ResourceManager.EMPTY_RESOURCE_MANAGER;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private File getCanonicalDocumentRoot()
/*     */   {
/*     */     try
/*     */     {
/* 481 */       File root = getValidDocumentRoot();
/* 482 */       root = root != null ? root : createTempDir("undertow-docbase");
/* 483 */       return root.getCanonicalFile();
/*     */     }
/*     */     catch (IOException e) {
/* 486 */       throw new IllegalStateException("Cannot get canonical document root", e);
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureErrorPages(DeploymentInfo servletBuilder) {
/* 491 */     for (org.springframework.boot.web.servlet.ErrorPage errorPage : getErrorPages()) {
/* 492 */       servletBuilder.addErrorPage(getUndertowErrorPage(errorPage));
/*     */     }
/*     */   }
/*     */   
/*     */   private io.undertow.servlet.api.ErrorPage getUndertowErrorPage(org.springframework.boot.web.servlet.ErrorPage errorPage) {
/* 497 */     if (errorPage.getStatus() != null)
/*     */     {
/* 499 */       return new io.undertow.servlet.api.ErrorPage(errorPage.getPath(), errorPage.getStatusCode());
/*     */     }
/* 501 */     if (errorPage.getException() != null)
/*     */     {
/* 503 */       return new io.undertow.servlet.api.ErrorPage(errorPage.getPath(), errorPage.getException());
/*     */     }
/* 505 */     return new io.undertow.servlet.api.ErrorPage(errorPage.getPath());
/*     */   }
/*     */   
/*     */   private void configureMimeMappings(DeploymentInfo servletBuilder) {
/* 509 */     for (MimeMappings.Mapping mimeMapping : getMimeMappings()) {
/* 510 */       servletBuilder.addMimeMapping(new MimeMapping(mimeMapping.getExtension(), mimeMapping
/* 511 */         .getMimeType()));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected UndertowEmbeddedServletContainer getUndertowEmbeddedServletContainer(Undertow.Builder builder, DeploymentManager manager, int port)
/*     */   {
/* 528 */     return new UndertowEmbeddedServletContainer(builder, manager, getContextPath(), isUseForwardHeaders(), port >= 0, getCompression(), getServerHeader());
/*     */   }
/*     */   
/*     */   public void setResourceLoader(ResourceLoader resourceLoader)
/*     */   {
/* 533 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */   
/*     */   public void setBufferSize(Integer bufferSize) {
/* 537 */     this.bufferSize = bufferSize;
/*     */   }
/*     */   
/*     */   public void setBuffersPerRegion(Integer buffersPerRegion) {
/* 541 */     this.buffersPerRegion = buffersPerRegion;
/*     */   }
/*     */   
/*     */   public void setIoThreads(Integer ioThreads) {
/* 545 */     this.ioThreads = ioThreads;
/*     */   }
/*     */   
/*     */   public void setWorkerThreads(Integer workerThreads) {
/* 549 */     this.workerThreads = workerThreads;
/*     */   }
/*     */   
/*     */   public void setDirectBuffers(Boolean directBuffers) {
/* 553 */     this.directBuffers = directBuffers;
/*     */   }
/*     */   
/*     */   public void setAccessLogDirectory(File accessLogDirectory) {
/* 557 */     this.accessLogDirectory = accessLogDirectory;
/*     */   }
/*     */   
/*     */   public void setAccessLogPattern(String accessLogPattern) {
/* 561 */     this.accessLogPattern = accessLogPattern;
/*     */   }
/*     */   
/*     */   public void setAccessLogEnabled(boolean accessLogEnabled) {
/* 565 */     this.accessLogEnabled = accessLogEnabled;
/*     */   }
/*     */   
/*     */   public boolean isAccessLogEnabled() {
/* 569 */     return this.accessLogEnabled;
/*     */   }
/*     */   
/*     */   protected final boolean isUseForwardHeaders() {
/* 573 */     return this.useForwardHeaders;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUseForwardHeaders(boolean useForwardHeaders)
/*     */   {
/* 582 */     this.useForwardHeaders = useForwardHeaders;
/*     */   }
/*     */   
/*     */ 
/*     */   private static class JarResourceManager
/*     */     implements ResourceManager
/*     */   {
/*     */     private final String jarPath;
/*     */     
/*     */     JarResourceManager(File jarFile)
/*     */     {
/* 593 */       this(jarFile.getAbsolutePath());
/*     */     }
/*     */     
/*     */     JarResourceManager(String jarPath) {
/* 597 */       this.jarPath = jarPath;
/*     */     }
/*     */     
/*     */     public Resource getResource(String path) throws IOException
/*     */     {
/* 602 */       URL url = new URL("jar:file:" + this.jarPath + "!" + path);
/* 603 */       URLResource resource = new URLResource(url, url.openConnection(), path);
/* 604 */       if (resource.getContentLength().longValue() < 0L) {
/* 605 */         return null;
/*     */       }
/* 607 */       return resource;
/*     */     }
/*     */     
/*     */     public boolean isResourceChangeListenerSupported()
/*     */     {
/* 612 */       return false;
/*     */     }
/*     */     
/*     */     public void registerResourceChangeListener(ResourceChangeListener listener)
/*     */     {
/* 617 */       throw UndertowMessages.MESSAGES.resourceChangeListenerNotSupported();
/*     */     }
/*     */     
/*     */ 
/*     */     public void removeResourceChangeListener(ResourceChangeListener listener)
/*     */     {
/* 623 */       throw UndertowMessages.MESSAGES.resourceChangeListenerNotSupported();
/*     */     }
/*     */     
/*     */ 
/*     */     public void close()
/*     */       throws IOException
/*     */     {}
/*     */   }
/*     */   
/*     */ 
/*     */   private static class Initializer
/*     */     implements ServletContainerInitializer
/*     */   {
/*     */     private final ServletContextInitializer[] initializers;
/*     */     
/*     */ 
/*     */     Initializer(ServletContextInitializer[] initializers)
/*     */     {
/* 641 */       this.initializers = initializers;
/*     */     }
/*     */     
/*     */     public void onStartup(Set<Class<?>> classes, ServletContext servletContext)
/*     */       throws ServletException
/*     */     {
/* 647 */       for (ServletContextInitializer initializer : this.initializers) {
/* 648 */         initializer.onStartup(servletContext);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\context\embedded\undertow\UndertowEmbeddedServletContainerFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */