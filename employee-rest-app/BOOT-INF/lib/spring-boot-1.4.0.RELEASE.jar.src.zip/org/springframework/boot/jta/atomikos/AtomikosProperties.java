/*     */ package org.springframework.boot.jta.atomikos;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.TreeMap;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.jta.atomikos.properties")
/*     */ public class AtomikosProperties
/*     */ {
/*  39 */   private final Map<String, String> values = new TreeMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String service;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  49 */   private long maxTimeout = 300000L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  54 */   private long defaultJtaTimeout = 10000L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  59 */   private int maxActives = 50;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  64 */   private boolean enableLogging = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String transactionManagerUniqueName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  76 */   private boolean serialJtaTransactions = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean forceShutdownOnVmExit;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  86 */   private String logBaseName = "tmlog";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String logBaseDir;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  98 */   private long checkpointInterval = 500L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 103 */   private AtomikosLoggingLevel consoleLogLevel = AtomikosLoggingLevel.WARN;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String outputDir;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 114 */   private String consoleFileName = "tm.out";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 119 */   private int consoleFileCount = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */   private int consoleFileLimit = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 131 */   private boolean threadedTwoPhaseCommit = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setService(String service)
/*     */   {
/* 141 */     this.service = service;
/* 142 */     set("service", service);
/*     */   }
/*     */   
/*     */   public String getService() {
/* 146 */     return this.service;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaxTimeout(long maxTimeout)
/*     */   {
/* 157 */     this.maxTimeout = maxTimeout;
/* 158 */     set("max_timeout", Long.valueOf(maxTimeout));
/*     */   }
/*     */   
/*     */   public long getMaxTimeout() {
/* 162 */     return this.maxTimeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultJtaTimeout(long defaultJtaTimeout)
/*     */   {
/* 171 */     this.defaultJtaTimeout = defaultJtaTimeout;
/* 172 */     set("default_jta_timeout", Long.valueOf(defaultJtaTimeout));
/*     */   }
/*     */   
/*     */   public long getDefaultJtaTimeout() {
/* 176 */     return this.defaultJtaTimeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaxActives(int maxActives)
/*     */   {
/* 188 */     this.maxActives = maxActives;
/* 189 */     set("max_actives", Integer.valueOf(maxActives));
/*     */   }
/*     */   
/*     */   public int getMaxActives() {
/* 193 */     return this.maxActives;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnableLogging(boolean enableLogging)
/*     */   {
/* 204 */     this.enableLogging = enableLogging;
/* 205 */     set("enable_logging", Boolean.valueOf(enableLogging));
/*     */   }
/*     */   
/*     */   public boolean isEnableLogging() {
/* 209 */     return this.enableLogging;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTransactionManagerUniqueName(String uniqueName)
/*     */   {
/* 224 */     this.transactionManagerUniqueName = uniqueName;
/* 225 */     set("tm_unique_name", uniqueName);
/*     */   }
/*     */   
/*     */   public String getTransactionManagerUniqueName() {
/* 229 */     return this.transactionManagerUniqueName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSerialJtaTransactions(boolean serialJtaTransactions)
/*     */   {
/* 241 */     this.serialJtaTransactions = serialJtaTransactions;
/* 242 */     set("serial_jta_transactions", Boolean.valueOf(serialJtaTransactions));
/*     */   }
/*     */   
/*     */   public boolean isSerialJtaTransactions() {
/* 246 */     return this.serialJtaTransactions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setForceShutdownOnVmExit(boolean forceShutdownOnVmExit)
/*     */   {
/* 255 */     this.forceShutdownOnVmExit = forceShutdownOnVmExit;
/* 256 */     set("force_shutdown_on_vm_exit", Boolean.valueOf(forceShutdownOnVmExit));
/*     */   }
/*     */   
/*     */   public boolean isForceShutdownOnVmExit() {
/* 260 */     return this.forceShutdownOnVmExit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLogBaseName(String logBaseName)
/*     */   {
/* 271 */     this.logBaseName = logBaseName;
/* 272 */     set("log_base_name", logBaseName);
/*     */   }
/*     */   
/*     */   public String getLogBaseName() {
/* 276 */     return this.logBaseName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLogBaseDir(String logBaseDir)
/*     */   {
/* 287 */     this.logBaseDir = logBaseDir;
/* 288 */     set("log_base_dir", logBaseDir);
/*     */   }
/*     */   
/*     */   public String getLogBaseDir() {
/* 292 */     return this.logBaseDir;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCheckpointInterval(long checkpointInterval)
/*     */   {
/* 301 */     this.checkpointInterval = checkpointInterval;
/* 302 */     set("checkpoint_interval", Long.valueOf(checkpointInterval));
/*     */   }
/*     */   
/*     */   public long getCheckpointInterval() {
/* 306 */     return this.checkpointInterval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConsoleLogLevel(AtomikosLoggingLevel consoleLogLevel)
/*     */   {
/* 314 */     this.consoleLogLevel = consoleLogLevel;
/* 315 */     set("console_log_level", consoleLogLevel);
/*     */   }
/*     */   
/*     */   public AtomikosLoggingLevel getConsoleLogLevel() {
/* 319 */     return this.consoleLogLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOutputDir(String outputDir)
/*     */   {
/* 328 */     this.outputDir = outputDir;
/* 329 */     set("output_dir", outputDir);
/*     */   }
/*     */   
/*     */   public String getOutputDir() {
/* 333 */     return this.outputDir;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConsoleFileName(String consoleFileName)
/*     */   {
/* 341 */     this.consoleFileName = consoleFileName;
/* 342 */     set("console_file_name", consoleFileName);
/*     */   }
/*     */   
/*     */   public String getConsoleFileName() {
/* 346 */     return this.consoleFileName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConsoleFileCount(int consoleFileCount)
/*     */   {
/* 354 */     this.consoleFileCount = consoleFileCount;
/* 355 */     set("console_file_count", Integer.valueOf(consoleFileCount));
/*     */   }
/*     */   
/*     */   public int getConsoleFileCount() {
/* 359 */     return this.consoleFileCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConsoleFileLimit(int consoleFileLimit)
/*     */   {
/* 368 */     this.consoleFileLimit = consoleFileLimit;
/* 369 */     set("console_file_limit", Integer.valueOf(consoleFileLimit));
/*     */   }
/*     */   
/*     */   public int getConsoleFileLimit() {
/* 373 */     return this.consoleFileLimit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setThreadedTwoPhaseCommit(boolean threadedTwoPhaseCommit)
/*     */   {
/* 386 */     this.threadedTwoPhaseCommit = threadedTwoPhaseCommit;
/* 387 */     set("threaded_2pc", Boolean.valueOf(threadedTwoPhaseCommit));
/*     */   }
/*     */   
/*     */   public boolean isThreadedTwoPhaseCommit() {
/* 391 */     return this.threadedTwoPhaseCommit;
/*     */   }
/*     */   
/*     */   private void set(String key, Object value) {
/* 395 */     set("com.atomikos.icatch.", key, value);
/*     */   }
/*     */   
/*     */   private void set(String keyPrefix, String key, Object value) {
/* 399 */     if (value != null) {
/* 400 */       this.values.put(keyPrefix + key, value.toString());
/*     */     }
/*     */     else {
/* 403 */       this.values.remove(keyPrefix + key);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Properties asProperties()
/*     */   {
/* 413 */     Properties properties = new Properties();
/* 414 */     properties.putAll(this.values);
/* 415 */     return properties;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\jta\atomikos\AtomikosProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */