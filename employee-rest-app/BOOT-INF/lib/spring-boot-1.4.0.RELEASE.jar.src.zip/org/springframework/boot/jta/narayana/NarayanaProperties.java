/*     */ package org.springframework.boot.jta.narayana;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.jta.narayana")
/*     */ public class NarayanaProperties
/*     */ {
/*     */   public static final String PROPERTIES_PREFIX = "spring.jta.narayana";
/*     */   private String logDir;
/*  48 */   private String transactionManagerId = "1";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  53 */   private boolean onePhaseCommit = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  58 */   private int defaultTimeout = 60;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  63 */   private int periodicRecoveryPeriod = 120;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  68 */   private int recoveryBackoffPeriod = 10;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  73 */   private String recoveryDbUser = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  78 */   private String recoveryDbPass = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  83 */   private String recoveryJmsUser = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  88 */   private String recoveryJmsPass = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  93 */   private List<String> xaResourceOrphanFilters = Arrays.asList(new String[] { "com.arjuna.ats.internal.jta.recovery.arjunacore.JTATransactionLogXAResourceOrphanFilter", "com.arjuna.ats.internal.jta.recovery.arjunacore.JTANodeNameXAResourceOrphanFilter" });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 100 */   private List<String> recoveryModules = Arrays.asList(new String[] { "com.arjuna.ats.internal.arjuna.recovery.AtomicActionRecoveryModule", "com.arjuna.ats.internal.jta.recovery.arjunacore.XARecoveryModule" });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */   private List<String> expiryScanners = Collections.singletonList("com.arjuna.ats.internal.arjuna.recovery.ExpiredTransactionStatusManagerScanner");
/*     */   
/*     */   public String getLogDir()
/*     */   {
/* 111 */     return this.logDir;
/*     */   }
/*     */   
/*     */   public void setLogDir(String logDir) {
/* 115 */     this.logDir = logDir;
/*     */   }
/*     */   
/*     */   public String getTransactionManagerId() {
/* 119 */     return this.transactionManagerId;
/*     */   }
/*     */   
/*     */   public void setTransactionManagerId(String transactionManagerId) {
/* 123 */     this.transactionManagerId = transactionManagerId;
/*     */   }
/*     */   
/*     */   public boolean isOnePhaseCommit() {
/* 127 */     return this.onePhaseCommit;
/*     */   }
/*     */   
/*     */   public void setOnePhaseCommit(boolean onePhaseCommit) {
/* 131 */     this.onePhaseCommit = onePhaseCommit;
/*     */   }
/*     */   
/*     */   public int getDefaultTimeout() {
/* 135 */     return this.defaultTimeout;
/*     */   }
/*     */   
/*     */   public int getPeriodicRecoveryPeriod() {
/* 139 */     return this.periodicRecoveryPeriod;
/*     */   }
/*     */   
/*     */   public void setPeriodicRecoveryPeriod(int periodicRecoveryPeriod) {
/* 143 */     this.periodicRecoveryPeriod = periodicRecoveryPeriod;
/*     */   }
/*     */   
/*     */   public int getRecoveryBackoffPeriod() {
/* 147 */     return this.recoveryBackoffPeriod;
/*     */   }
/*     */   
/*     */   public void setRecoveryBackoffPeriod(int recoveryBackoffPeriod) {
/* 151 */     this.recoveryBackoffPeriod = recoveryBackoffPeriod;
/*     */   }
/*     */   
/*     */   public void setDefaultTimeout(int defaultTimeout) {
/* 155 */     this.defaultTimeout = defaultTimeout;
/*     */   }
/*     */   
/*     */   public List<String> getXaResourceOrphanFilters() {
/* 159 */     return this.xaResourceOrphanFilters;
/*     */   }
/*     */   
/*     */   public void setXaResourceOrphanFilters(List<String> xaResourceOrphanFilters) {
/* 163 */     this.xaResourceOrphanFilters = xaResourceOrphanFilters;
/*     */   }
/*     */   
/*     */   public List<String> getRecoveryModules() {
/* 167 */     return this.recoveryModules;
/*     */   }
/*     */   
/*     */   public void setRecoveryModules(List<String> recoveryModules) {
/* 171 */     this.recoveryModules = recoveryModules;
/*     */   }
/*     */   
/*     */   public List<String> getExpiryScanners() {
/* 175 */     return this.expiryScanners;
/*     */   }
/*     */   
/*     */   public void setExpiryScanners(List<String> expiryScanners) {
/* 179 */     this.expiryScanners = expiryScanners;
/*     */   }
/*     */   
/*     */   public String getRecoveryDbUser() {
/* 183 */     return this.recoveryDbUser;
/*     */   }
/*     */   
/*     */   public void setRecoveryDbUser(String recoveryDbUser) {
/* 187 */     this.recoveryDbUser = recoveryDbUser;
/*     */   }
/*     */   
/*     */   public String getRecoveryDbPass() {
/* 191 */     return this.recoveryDbPass;
/*     */   }
/*     */   
/*     */   public void setRecoveryDbPass(String recoveryDbPass) {
/* 195 */     this.recoveryDbPass = recoveryDbPass;
/*     */   }
/*     */   
/*     */   public String getRecoveryJmsUser() {
/* 199 */     return this.recoveryJmsUser;
/*     */   }
/*     */   
/*     */   public void setRecoveryJmsUser(String recoveryJmsUser) {
/* 203 */     this.recoveryJmsUser = recoveryJmsUser;
/*     */   }
/*     */   
/*     */   public String getRecoveryJmsPass() {
/* 207 */     return this.recoveryJmsPass;
/*     */   }
/*     */   
/*     */   public void setRecoveryJmsPass(String recoveryJmsPass) {
/* 211 */     this.recoveryJmsPass = recoveryJmsPass;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\jta\narayana\NarayanaProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */