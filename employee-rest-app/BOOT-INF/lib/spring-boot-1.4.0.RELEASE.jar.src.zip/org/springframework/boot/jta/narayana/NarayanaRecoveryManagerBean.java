/*    */ package org.springframework.boot.jta.narayana;
/*    */ 
/*    */ import com.arjuna.ats.arjuna.recovery.RecoveryManager;
/*    */ import com.arjuna.ats.arjuna.recovery.RecoveryModule;
/*    */ import com.arjuna.ats.internal.jta.recovery.arjunacore.XARecoveryModule;
/*    */ import com.arjuna.ats.jbossatx.jta.RecoveryManagerService;
/*    */ import com.arjuna.ats.jta.recovery.XAResourceRecoveryHelper;
/*    */ import org.springframework.beans.factory.DisposableBean;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NarayanaRecoveryManagerBean
/*    */   implements InitializingBean, DisposableBean
/*    */ {
/*    */   private final RecoveryManagerService recoveryManagerService;
/*    */   
/*    */   public NarayanaRecoveryManagerBean(RecoveryManagerService recoveryManagerService)
/*    */   {
/* 40 */     Assert.notNull(recoveryManagerService, "RecoveryManagerService must not be null");
/* 41 */     this.recoveryManagerService = recoveryManagerService;
/*    */   }
/*    */   
/*    */   public void afterPropertiesSet() throws Exception
/*    */   {
/* 46 */     this.recoveryManagerService.create();
/* 47 */     this.recoveryManagerService.start();
/*    */   }
/*    */   
/*    */   public void destroy() throws Exception
/*    */   {
/* 52 */     this.recoveryManagerService.stop();
/* 53 */     this.recoveryManagerService.destroy();
/*    */   }
/*    */   
/*    */ 
/*    */   void registerXAResourceRecoveryHelper(XAResourceRecoveryHelper xaResourceRecoveryHelper)
/*    */   {
/* 59 */     getXARecoveryModule(RecoveryManager.manager()).addXAResourceRecoveryHelper(xaResourceRecoveryHelper);
/*    */   }
/*    */   
/*    */   private XARecoveryModule getXARecoveryModule(RecoveryManager recoveryManager) {
/* 63 */     for (RecoveryModule recoveryModule : recoveryManager.getModules()) {
/* 64 */       if ((recoveryModule instanceof XARecoveryModule)) {
/* 65 */         return (XARecoveryModule)recoveryModule;
/*    */       }
/*    */     }
/* 68 */     throw new IllegalStateException("XARecoveryModule is not registered with recovery manager");
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\jta\narayana\NarayanaRecoveryManagerBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */