/*    */ package org.springframework.boot.yaml;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Properties;
/*    */ import java.util.Set;
/*    */ import org.springframework.beans.factory.config.YamlProcessor.DocumentMatcher;
/*    */ import org.springframework.beans.factory.config.YamlProcessor.MatchStatus;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArrayDocumentMatcher
/*    */   implements YamlProcessor.DocumentMatcher
/*    */ {
/*    */   private final String key;
/*    */   private final String[] patterns;
/*    */   
/*    */   public ArrayDocumentMatcher(String key, String... patterns)
/*    */   {
/* 41 */     this.key = key;
/* 42 */     this.patterns = patterns;
/*    */   }
/*    */   
/*    */ 
/*    */   public YamlProcessor.MatchStatus matches(Properties properties)
/*    */   {
/* 48 */     if (!properties.containsKey(this.key)) {
/* 49 */       return YamlProcessor.MatchStatus.ABSTAIN;
/*    */     }
/*    */     
/* 52 */     Set<String> values = StringUtils.commaDelimitedListToSet(properties.getProperty(this.key));
/* 53 */     if (values.isEmpty())
/* 54 */       values = Collections.singleton("");
/*    */     String pattern;
/* 56 */     for (pattern : this.patterns) {
/* 57 */       for (String value : values) {
/* 58 */         if (value.matches(pattern)) {
/* 59 */           return YamlProcessor.MatchStatus.FOUND;
/*    */         }
/*    */       }
/*    */     }
/* 63 */     return YamlProcessor.MatchStatus.NOT_FOUND;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\yaml\ArrayDocumentMatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */