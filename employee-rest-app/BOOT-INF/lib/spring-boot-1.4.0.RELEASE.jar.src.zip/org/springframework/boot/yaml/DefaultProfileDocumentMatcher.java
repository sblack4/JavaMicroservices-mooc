/*    */ package org.springframework.boot.yaml;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import org.springframework.beans.factory.config.YamlProcessor.DocumentMatcher;
/*    */ import org.springframework.beans.factory.config.YamlProcessor.MatchStatus;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultProfileDocumentMatcher
/*    */   implements YamlProcessor.DocumentMatcher
/*    */ {
/*    */   public YamlProcessor.MatchStatus matches(Properties properties)
/*    */   {
/* 34 */     if (!properties.containsKey("spring.profiles")) {
/* 35 */       return YamlProcessor.MatchStatus.FOUND;
/*    */     }
/* 37 */     return YamlProcessor.MatchStatus.NOT_FOUND;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\yaml\DefaultProfileDocumentMatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */