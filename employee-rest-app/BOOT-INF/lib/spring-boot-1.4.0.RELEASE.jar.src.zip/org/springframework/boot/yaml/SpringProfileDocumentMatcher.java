/*     */ package org.springframework.boot.yaml;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Properties;
/*     */ import org.springframework.beans.factory.config.YamlProcessor.DocumentMatcher;
/*     */ import org.springframework.beans.factory.config.YamlProcessor.MatchStatus;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringProfileDocumentMatcher
/*     */   implements YamlProcessor.DocumentMatcher
/*     */ {
/*  42 */   private static final String[] DEFAULT_PROFILES = { "^\\s*$" };
/*     */   
/*     */   private static final String SPRING_PROFILES = "spring.profiles";
/*     */   
/*  46 */   private String[] activeProfiles = new String[0];
/*     */   
/*     */   public SpringProfileDocumentMatcher() {}
/*     */   
/*     */   public SpringProfileDocumentMatcher(String... profiles)
/*     */   {
/*  52 */     addActiveProfiles(profiles);
/*     */   }
/*     */   
/*     */   public void addActiveProfiles(String... profiles)
/*     */   {
/*  57 */     LinkedHashSet<String> set = new LinkedHashSet(Arrays.asList(this.activeProfiles));
/*  58 */     Collections.addAll(set, profiles);
/*  59 */     this.activeProfiles = ((String[])set.toArray(new String[set.size()]));
/*     */   }
/*     */   
/*     */   public YamlProcessor.MatchStatus matches(Properties properties)
/*     */   {
/*  64 */     YamlProcessor.DocumentMatcher activeProfilesMatcher = getActiveProfilesDocumentMatcher();
/*  65 */     String profiles = properties.getProperty("spring.profiles");
/*  66 */     String negative = extractProfiles(profiles, ProfileType.NEGATIVE);
/*  67 */     String positive = extractProfiles(profiles, ProfileType.POSITIVE);
/*  68 */     if (StringUtils.hasLength(negative)) {
/*  69 */       properties = new Properties(properties);
/*  70 */       properties.setProperty("spring.profiles", negative);
/*  71 */       if (activeProfilesMatcher.matches(properties) == YamlProcessor.MatchStatus.FOUND) {
/*  72 */         return YamlProcessor.MatchStatus.NOT_FOUND;
/*     */       }
/*  74 */       if (StringUtils.isEmpty(positive)) {
/*  75 */         return YamlProcessor.MatchStatus.FOUND;
/*     */       }
/*  77 */       properties.setProperty("spring.profiles", positive);
/*     */     }
/*  79 */     return activeProfilesMatcher.matches(properties);
/*     */   }
/*     */   
/*     */   private YamlProcessor.DocumentMatcher getActiveProfilesDocumentMatcher() {
/*  83 */     String[] profiles = this.activeProfiles;
/*  84 */     if (profiles.length == 0) {
/*  85 */       profiles = DEFAULT_PROFILES;
/*     */     }
/*  87 */     return new ArrayDocumentMatcher("spring.profiles", profiles);
/*     */   }
/*     */   
/*     */   private String extractProfiles(String profiles, ProfileType type) {
/*  91 */     if (profiles == null) {
/*  92 */       return null;
/*     */     }
/*  94 */     StringBuilder result = new StringBuilder();
/*  95 */     for (String candidate : StringUtils.commaDelimitedListToSet(profiles)) {
/*  96 */       ProfileType candidateType = ProfileType.POSITIVE;
/*  97 */       if (candidate.startsWith("!")) {
/*  98 */         candidateType = ProfileType.NEGATIVE;
/*     */       }
/* 100 */       if (candidateType == type) {
/* 101 */         result.append(result.length() > 0 ? "," : "");
/* 102 */         result.append(candidate.substring(type == ProfileType.POSITIVE ? 0 : 1));
/*     */       }
/*     */     }
/* 105 */     return result.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static enum ProfileType
/*     */   {
/* 112 */     POSITIVE,  NEGATIVE;
/*     */     
/*     */     private ProfileType() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\yaml\SpringProfileDocumentMatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */