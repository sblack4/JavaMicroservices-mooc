/*    */ package org.springframework.boot.diagnostics.analyzer;
/*    */ 
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ import org.springframework.validation.BindException;
/*    */ import org.springframework.validation.FieldError;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BindFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<BindException>
/*    */ {
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, BindException cause)
/*    */   {
/* 35 */     if (CollectionUtils.isEmpty(cause.getFieldErrors())) {
/* 36 */       return null;
/*    */     }
/*    */     
/* 39 */     StringBuilder description = new StringBuilder(String.format("Binding to target %s failed:%n", new Object[] { cause.getTarget() }));
/* 40 */     for (FieldError fieldError : cause.getFieldErrors()) {
/* 41 */       description.append(String.format("%n    Property: %s", new Object[] {cause
/* 42 */         .getObjectName() + "." + fieldError.getField() }));
/* 43 */       description.append(
/* 44 */         String.format("%n    Value: %s", new Object[] {fieldError.getRejectedValue() }));
/* 45 */       description.append(
/* 46 */         String.format("%n    Reason: %s%n", new Object[] {fieldError.getDefaultMessage() }));
/*    */     }
/* 48 */     return new FailureAnalysis(description.toString(), "Update your application's configuration", cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\diagnostics\analyzer\BindFailureAnalyzer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */