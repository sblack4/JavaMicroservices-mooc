/*    */ package org.springframework.boot.diagnostics;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.context.ConfigurableApplicationContext;
/*    */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FailureAnalyzers
/*    */ {
/*    */   public static boolean analyzeAndReport(Throwable failure, ClassLoader classLoader, ConfigurableApplicationContext context)
/*    */   {
/* 47 */     List<FailureAnalyzer> analyzers = SpringFactoriesLoader.loadFactories(FailureAnalyzer.class, classLoader);
/*    */     
/* 49 */     List<FailureAnalysisReporter> reporters = SpringFactoriesLoader.loadFactories(FailureAnalysisReporter.class, classLoader);
/* 50 */     FailureAnalysis analysis = analyze(failure, analyzers, context);
/* 51 */     return report(analysis, reporters);
/*    */   }
/*    */   
/*    */   private static FailureAnalysis analyze(Throwable failure, List<FailureAnalyzer> analyzers, ConfigurableApplicationContext context)
/*    */   {
/* 56 */     for (FailureAnalyzer analyzer : analyzers) {
/* 57 */       prepareAnalyzer(context, analyzer);
/* 58 */       FailureAnalysis analysis = analyzer.analyze(failure);
/* 59 */       if (analysis != null) {
/* 60 */         return analysis;
/*    */       }
/*    */     }
/* 63 */     return null;
/*    */   }
/*    */   
/*    */   private static void prepareAnalyzer(ConfigurableApplicationContext context, FailureAnalyzer analyzer)
/*    */   {
/* 68 */     if ((analyzer instanceof BeanFactoryAware)) {
/* 69 */       ((BeanFactoryAware)analyzer).setBeanFactory(context.getBeanFactory());
/*    */     }
/*    */   }
/*    */   
/*    */   private static boolean report(FailureAnalysis analysis, List<FailureAnalysisReporter> reporters)
/*    */   {
/* 75 */     if ((analysis == null) || (reporters.isEmpty())) {
/* 76 */       return false;
/*    */     }
/* 78 */     for (FailureAnalysisReporter reporter : reporters) {
/* 79 */       reporter.report(analysis);
/*    */     }
/* 81 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\diagnostics\FailureAnalyzers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */