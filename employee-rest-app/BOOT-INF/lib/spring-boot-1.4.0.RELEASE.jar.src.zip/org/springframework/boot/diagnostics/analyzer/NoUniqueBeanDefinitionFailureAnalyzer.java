/*     */ package org.springframework.boot.diagnostics.analyzer;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.beans.BeanInstantiationException;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.InjectionPoint;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
/*     */ import org.springframework.beans.factory.UnsatisfiedDependencyException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*     */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NoUniqueBeanDefinitionFailureAnalyzer
/*     */   extends AbstractFailureAnalyzer<NoUniqueBeanDefinitionException>
/*     */   implements BeanFactoryAware
/*     */ {
/*     */   private ConfigurableBeanFactory beanFactory;
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */     throws BeansException
/*     */   {
/*  49 */     Assert.isInstanceOf(ConfigurableBeanFactory.class, beanFactory);
/*  50 */     this.beanFactory = ((ConfigurableBeanFactory)beanFactory);
/*     */   }
/*     */   
/*     */ 
/*     */   protected FailureAnalysis analyze(Throwable rootFailure, NoUniqueBeanDefinitionException cause)
/*     */   {
/*  56 */     String consumerDescription = getConsumerDescription(rootFailure);
/*  57 */     if (consumerDescription == null) {
/*  58 */       return null;
/*     */     }
/*  60 */     String[] beanNames = extractBeanNames(cause);
/*  61 */     if (beanNames == null) {
/*  62 */       return null;
/*     */     }
/*  64 */     StringBuilder message = new StringBuilder();
/*  65 */     message.append(String.format("%s required a single bean, but %d were found:%n", new Object[] { consumerDescription, 
/*  66 */       Integer.valueOf(beanNames.length) }));
/*  67 */     for (String beanName : beanNames) {
/*     */       try
/*     */       {
/*  70 */         BeanDefinition beanDefinition = this.beanFactory.getMergedBeanDefinition(beanName);
/*  71 */         if (StringUtils.hasText(beanDefinition.getFactoryMethodName())) {
/*  72 */           message.append(String.format("\t- %s: defined by method '%s' in %s%n", new Object[] { beanName, beanDefinition
/*  73 */             .getFactoryMethodName(), beanDefinition
/*  74 */             .getResourceDescription() }));
/*     */         }
/*     */         else {
/*  77 */           message.append(String.format("\t- %s: defined in %s%n", new Object[] { beanName, beanDefinition
/*  78 */             .getResourceDescription() }));
/*     */         }
/*     */       }
/*     */       catch (NoSuchBeanDefinitionException ex) {
/*  82 */         message.append(String.format("\t- %s: a programmatically registered singleton", new Object[] { beanName }));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  87 */     return new FailureAnalysis(message.toString(), "Consider marking one of the beans as @Primary, updating the consumer to accept multiple beans, or using @Qualifier to identify the bean that should be consumed", cause);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getConsumerDescription(Throwable ex)
/*     */   {
/*  95 */     UnsatisfiedDependencyException unsatisfiedDependency = findUnsatisfiedDependencyException(ex);
/*     */     
/*  97 */     if (unsatisfiedDependency != null) {
/*  98 */       return getConsumerDescription(unsatisfiedDependency);
/*     */     }
/* 100 */     BeanInstantiationException beanInstantiationException = findBeanInstantiationException(ex);
/*     */     
/* 102 */     if (beanInstantiationException != null) {
/* 103 */       return getConsumerDescription(beanInstantiationException);
/*     */     }
/* 105 */     return null;
/*     */   }
/*     */   
/*     */   private UnsatisfiedDependencyException findUnsatisfiedDependencyException(Throwable root)
/*     */   {
/* 110 */     return (UnsatisfiedDependencyException)findMostNestedCause(root, UnsatisfiedDependencyException.class);
/*     */   }
/*     */   
/*     */   private BeanInstantiationException findBeanInstantiationException(Throwable root) {
/* 114 */     return (BeanInstantiationException)findMostNestedCause(root, BeanInstantiationException.class);
/*     */   }
/*     */   
/*     */ 
/*     */   private <T extends Exception> T findMostNestedCause(Throwable root, Class<T> causeType)
/*     */   {
/* 120 */     Throwable candidate = root;
/* 121 */     T mostNestedMatch = null;
/* 122 */     while (candidate != null) {
/* 123 */       if (causeType.isAssignableFrom(candidate.getClass())) {
/* 124 */         mostNestedMatch = (Exception)candidate;
/*     */       }
/* 126 */       candidate = candidate.getCause();
/*     */     }
/* 128 */     return mostNestedMatch;
/*     */   }
/*     */   
/*     */   private String getConsumerDescription(UnsatisfiedDependencyException ex) {
/* 132 */     InjectionPoint injectionPoint = ex.getInjectionPoint();
/* 133 */     if (injectionPoint != null) {
/* 134 */       if (injectionPoint.getField() != null) {
/* 135 */         return String.format("Field %s in %s", new Object[] {injectionPoint
/* 136 */           .getField().getName(), injectionPoint
/* 137 */           .getField().getDeclaringClass().getName() });
/*     */       }
/* 139 */       if (injectionPoint.getMethodParameter() != null) {
/* 140 */         if (injectionPoint.getMethodParameter().getConstructor() != null) {
/* 141 */           return String.format("Parameter %d of constructor in %s", new Object[] {
/* 142 */             Integer.valueOf(injectionPoint.getMethodParameter().getParameterIndex()), injectionPoint
/* 143 */             .getMethodParameter().getDeclaringClass()
/* 144 */             .getName() });
/*     */         }
/* 146 */         return String.format("Parameter %d of method %s in %s", new Object[] {
/* 147 */           Integer.valueOf(injectionPoint.getMethodParameter().getParameterIndex()), injectionPoint
/* 148 */           .getMethodParameter().getMethod().getName(), injectionPoint
/* 149 */           .getMethodParameter().getDeclaringClass()
/* 150 */           .getName() });
/*     */       }
/*     */     }
/* 153 */     return ex.getResourceDescription();
/*     */   }
/*     */   
/*     */   private String getConsumerDescription(BeanInstantiationException ex) {
/* 157 */     if (ex.getConstructingMethod() != null) {
/* 158 */       return String.format("Method %s in %s", new Object[] { ex.getConstructingMethod().getName(), ex
/* 159 */         .getConstructingMethod().getDeclaringClass().getName() });
/*     */     }
/* 161 */     if (ex.getConstructor() != null) {
/* 162 */       return String.format("Constructor in %s", new Object[] {
/* 163 */         ClassUtils.getUserClass(ex.getConstructor().getDeclaringClass()).getName() });
/*     */     }
/* 165 */     return ex.getBeanClass().getName();
/*     */   }
/*     */   
/*     */   private String[] extractBeanNames(NoUniqueBeanDefinitionException cause) {
/* 169 */     if (cause.getMessage().indexOf("but found") > -1) {
/* 170 */       return StringUtils.commaDelimitedListToStringArray(cause.getMessage()
/* 171 */         .substring(cause.getMessage().lastIndexOf(":") + 1).trim());
/*     */     }
/* 173 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\diagnostics\analyzer\NoUniqueBeanDefinitionFailureAnalyzer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */