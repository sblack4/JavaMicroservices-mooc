/*    */ package org.springframework.boot.diagnostics.analyzer;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.beans.factory.BeanCreationException;
/*    */ import org.springframework.beans.factory.BeanCurrentlyInCreationException;
/*    */ import org.springframework.beans.factory.InjectionPoint;
/*    */ import org.springframework.beans.factory.UnsatisfiedDependencyException;
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BeanCurrentlyInCreationFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<BeanCurrentlyInCreationException>
/*    */ {
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, BeanCurrentlyInCreationException cause)
/*    */   {
/* 42 */     List<String> beansInCycle = new ArrayList();
/* 43 */     Throwable candidate = rootFailure;
/* 44 */     while (candidate != null) {
/* 45 */       if ((candidate instanceof BeanCreationException)) {
/* 46 */         BeanCreationException creationEx = (BeanCreationException)candidate;
/* 47 */         if (StringUtils.hasText(creationEx.getBeanName()))
/*    */         {
/* 49 */           beansInCycle.add(creationEx.getBeanName() + getDescription(creationEx));
/*    */         }
/*    */       }
/* 52 */       candidate = candidate.getCause();
/*    */     }
/* 54 */     StringBuilder message = new StringBuilder();
/* 55 */     int uniqueBeans = beansInCycle.size() - 1;
/* 56 */     message.append(
/* 57 */       String.format("There is a circular dependency between %s beans in the application context:%n", new Object[] {
/* 58 */       Integer.valueOf(uniqueBeans) }));
/* 59 */     for (String bean : beansInCycle) {
/* 60 */       message.append(String.format("\t- %s%n", new Object[] { bean }));
/*    */     }
/* 62 */     return new FailureAnalysis(message.toString(), null, cause);
/*    */   }
/*    */   
/*    */   private String getDescription(BeanCreationException ex) {
/* 66 */     if (StringUtils.hasText(ex.getResourceDescription())) {
/* 67 */       return String.format(" defined in %s", new Object[] { ex.getResourceDescription() });
/*    */     }
/* 69 */     InjectionPoint failedInjectionPoint = findFailedInjectionPoint(ex);
/* 70 */     if ((failedInjectionPoint != null) && (failedInjectionPoint.getField() != null)) {
/* 71 */       return String.format(" (field %s)", new Object[] { failedInjectionPoint.getField() });
/*    */     }
/* 73 */     return "";
/*    */   }
/*    */   
/*    */   private InjectionPoint findFailedInjectionPoint(BeanCreationException ex) {
/* 77 */     if (!(ex instanceof UnsatisfiedDependencyException)) {
/* 78 */       return null;
/*    */     }
/* 80 */     return ((UnsatisfiedDependencyException)ex).getInjectionPoint();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\diagnostics\analyzer\BeanCurrentlyInCreationFailureAnalyzer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */