/*    */ package org.springframework.boot.bind;
/*    */ 
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class StringToCharArrayConverter
/*    */   implements Converter<String, char[]>
/*    */ {
/*    */   public char[] convert(String source)
/*    */   {
/* 30 */     return source.toCharArray();
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\bind\StringToCharArrayConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */