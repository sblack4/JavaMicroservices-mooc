/*     */ package org.springframework.boot.bind;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.springframework.validation.BeanPropertyBindingResult;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.validation.ObjectError;
/*     */ import org.springframework.validation.Validator;
/*     */ import org.yaml.snakeyaml.Yaml;
/*     */ import org.yaml.snakeyaml.constructor.Constructor;
/*     */ import org.yaml.snakeyaml.error.YAMLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class YamlConfigurationFactory<T>
/*     */   implements FactoryBean<T>, MessageSourceAware, InitializingBean
/*     */ {
/*  55 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private final Class<?> type;
/*     */   
/*     */   private boolean exceptionIfInvalid;
/*     */   
/*     */   private String yaml;
/*     */   
/*     */   private Resource resource;
/*     */   
/*     */   private T configuration;
/*     */   
/*     */   private Validator validator;
/*     */   
/*     */   private MessageSource messageSource;
/*     */   
/*  71 */   private Map<Class<?>, Map<String, String>> propertyAliases = Collections.emptyMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public YamlConfigurationFactory(Class<?> type)
/*     */   {
/*  79 */     Assert.notNull(type);
/*  80 */     this.type = type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessageSource(MessageSource messageSource)
/*     */   {
/*  89 */     this.messageSource = messageSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPropertyAliases(Map<Class<?>, Map<String, String>> propertyAliases)
/*     */   {
/*  97 */     this.propertyAliases = new HashMap(propertyAliases);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setYaml(String yaml)
/*     */   {
/* 106 */     this.yaml = yaml;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResource(Resource resource)
/*     */   {
/* 114 */     this.resource = resource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValidator(Validator validator)
/*     */   {
/* 122 */     this.validator = validator;
/*     */   }
/*     */   
/*     */   public void setExceptionIfInvalid(boolean exceptionIfInvalid) {
/* 126 */     this.exceptionIfInvalid = exceptionIfInvalid;
/*     */   }
/*     */   
/*     */   public void afterPropertiesSet()
/*     */     throws Exception
/*     */   {
/* 132 */     if (this.yaml == null) {
/* 133 */       Assert.state(this.resource != null, "Resource should not be null");
/* 134 */       this.yaml = StreamUtils.copyToString(this.resource.getInputStream(), 
/* 135 */         Charset.defaultCharset());
/*     */     }
/* 137 */     Assert.state(this.yaml != null, "Yaml document should not be null: either set it directly or set the resource to load it from");
/*     */     try
/*     */     {
/* 140 */       if (this.logger.isTraceEnabled()) {
/* 141 */         this.logger.trace(String.format("Yaml document is %n%s" + this.yaml, new Object[0]));
/*     */       }
/* 143 */       Constructor constructor = new YamlJavaBeanPropertyConstructor(this.type, this.propertyAliases);
/*     */       
/* 145 */       this.configuration = new Yaml(constructor).load(this.yaml);
/* 146 */       if (this.validator != null) {
/* 147 */         validate();
/*     */       }
/*     */     }
/*     */     catch (YAMLException ex) {
/* 151 */       if (this.exceptionIfInvalid) {
/* 152 */         throw ex;
/*     */       }
/* 154 */       this.logger.error("Failed to load YAML validation bean. Your YAML file may be invalid.", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private void validate() throws BindException
/*     */   {
/* 160 */     BindingResult errors = new BeanPropertyBindingResult(this.configuration, "configuration");
/*     */     
/* 162 */     this.validator.validate(this.configuration, errors);
/* 163 */     if (errors.hasErrors()) {
/* 164 */       this.logger.error("YAML configuration failed validation");
/* 165 */       for (ObjectError error : errors.getAllErrors())
/*     */       {
/* 167 */         this.logger.error(this.messageSource != null ? this.messageSource
/* 168 */           .getMessage(error, 
/* 169 */           Locale.getDefault()) + " (" + error + ")" : error);
/*     */       }
/*     */       
/*     */ 
/* 172 */       if (this.exceptionIfInvalid) {
/* 173 */         BindException summary = new BindException(errors);
/* 174 */         throw summary;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Class<?> getObjectType()
/*     */   {
/* 181 */     if (this.configuration == null) {
/* 182 */       return Object.class;
/*     */     }
/* 184 */     return this.configuration.getClass();
/*     */   }
/*     */   
/*     */   public boolean isSingleton()
/*     */   {
/* 189 */     return true;
/*     */   }
/*     */   
/*     */   public T getObject() throws Exception
/*     */   {
/* 194 */     if (this.configuration == null) {
/* 195 */       afterPropertiesSet();
/*     */     }
/* 197 */     return (T)this.configuration;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\bind\YamlConfigurationFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */