/*     */ package org.springframework.boot.bind;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.PropertyResolver;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RelaxedPropertyResolver
/*     */   implements PropertyResolver
/*     */ {
/*     */   private final PropertyResolver resolver;
/*     */   private final String prefix;
/*     */   
/*     */   public RelaxedPropertyResolver(PropertyResolver resolver)
/*     */   {
/*  38 */     this(resolver, null);
/*     */   }
/*     */   
/*     */   public RelaxedPropertyResolver(PropertyResolver resolver, String prefix) {
/*  42 */     Assert.notNull(resolver, "PropertyResolver must not be null");
/*  43 */     this.resolver = resolver;
/*  44 */     this.prefix = (prefix == null ? "" : prefix);
/*     */   }
/*     */   
/*     */   public String getRequiredProperty(String key) throws IllegalStateException
/*     */   {
/*  49 */     return (String)getRequiredProperty(key, String.class);
/*     */   }
/*     */   
/*     */   public <T> T getRequiredProperty(String key, Class<T> targetType)
/*     */     throws IllegalStateException
/*     */   {
/*  55 */     T value = getProperty(key, targetType);
/*  56 */     Assert.state(value != null, String.format("required key [%s] not found", new Object[] { key }));
/*  57 */     return value;
/*     */   }
/*     */   
/*     */   public String getProperty(String key)
/*     */   {
/*  62 */     return (String)getProperty(key, String.class, null);
/*     */   }
/*     */   
/*     */   public String getProperty(String key, String defaultValue)
/*     */   {
/*  67 */     return (String)getProperty(key, String.class, defaultValue);
/*     */   }
/*     */   
/*     */   public <T> T getProperty(String key, Class<T> targetType)
/*     */   {
/*  72 */     return (T)getProperty(key, targetType, null);
/*     */   }
/*     */   
/*     */   public <T> T getProperty(String key, Class<T> targetType, T defaultValue)
/*     */   {
/*  77 */     RelaxedNames prefixes = new RelaxedNames(this.prefix);
/*  78 */     RelaxedNames keys = new RelaxedNames(key);
/*  79 */     for (Iterator localIterator1 = prefixes.iterator(); localIterator1.hasNext();) { prefix = (String)localIterator1.next();
/*  80 */       for (String relaxedKey : keys) {
/*  81 */         if (this.resolver.containsProperty(prefix + relaxedKey))
/*  82 */           return (T)this.resolver.getProperty(prefix + relaxedKey, targetType);
/*     */       }
/*     */     }
/*     */     String prefix;
/*  86 */     return defaultValue;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public <T> Class<T> getPropertyAsClass(String key, Class<T> targetType)
/*     */   {
/*  92 */     RelaxedNames prefixes = new RelaxedNames(this.prefix);
/*  93 */     RelaxedNames keys = new RelaxedNames(key);
/*  94 */     for (Iterator localIterator1 = prefixes.iterator(); localIterator1.hasNext();) { prefix = (String)localIterator1.next();
/*  95 */       for (String relaxedKey : keys) {
/*  96 */         if (this.resolver.containsProperty(prefix + relaxedKey)) {
/*  97 */           return this.resolver.getPropertyAsClass(prefix + relaxedKey, targetType);
/*     */         }
/*     */       }
/*     */     }
/*     */     String prefix;
/* 102 */     return null;
/*     */   }
/*     */   
/*     */   public boolean containsProperty(String key)
/*     */   {
/* 107 */     RelaxedNames prefixes = new RelaxedNames(this.prefix);
/* 108 */     RelaxedNames keys = new RelaxedNames(key);
/* 109 */     for (Iterator localIterator1 = prefixes.iterator(); localIterator1.hasNext();) { prefix = (String)localIterator1.next();
/* 110 */       for (String relaxedKey : keys) {
/* 111 */         if (this.resolver.containsProperty(prefix + relaxedKey))
/* 112 */           return true;
/*     */       }
/*     */     }
/*     */     String prefix;
/* 116 */     return false;
/*     */   }
/*     */   
/*     */   public String resolvePlaceholders(String text)
/*     */   {
/* 121 */     throw new UnsupportedOperationException("Unable to resolve placeholders with relaxed properties");
/*     */   }
/*     */   
/*     */ 
/*     */   public String resolveRequiredPlaceholders(String text)
/*     */     throws IllegalArgumentException
/*     */   {
/* 128 */     throw new UnsupportedOperationException("Unable to resolve placeholders with relaxed properties");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, Object> getSubProperties(String keyPrefix)
/*     */   {
/* 141 */     Assert.isInstanceOf(ConfigurableEnvironment.class, this.resolver, "SubProperties not available.");
/*     */     
/* 143 */     ConfigurableEnvironment env = (ConfigurableEnvironment)this.resolver;
/* 144 */     return PropertySourceUtils.getSubProperties(env.getPropertySources(), this.prefix, keyPrefix);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\bind\RelaxedPropertyResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */