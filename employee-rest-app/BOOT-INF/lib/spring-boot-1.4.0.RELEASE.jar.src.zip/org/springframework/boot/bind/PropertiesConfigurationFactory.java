/*     */ package org.springframework.boot.bind;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.env.PropertySources;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.validation.DataBinder;
/*     */ import org.springframework.validation.ObjectError;
/*     */ import org.springframework.validation.Validator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertiesConfigurationFactory<T>
/*     */   implements FactoryBean<T>, MessageSourceAware, InitializingBean
/*     */ {
/*  59 */   private static final char[] EXACT_DELIMITERS = { '_', '.', '[' };
/*     */   
/*  61 */   private static final char[] TARGET_NAME_DELIMITERS = { '_', '.' };
/*     */   
/*  63 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  65 */   private boolean ignoreUnknownFields = true;
/*     */   
/*     */   private boolean ignoreInvalidFields;
/*     */   
/*  69 */   private boolean exceptionIfInvalid = true;
/*     */   
/*     */   private Properties properties;
/*     */   
/*     */   private PropertySources propertySources;
/*     */   
/*     */   private final T target;
/*     */   
/*     */   private Validator validator;
/*     */   
/*     */   private MessageSource messageSource;
/*     */   
/*  81 */   private boolean hasBeenBound = false;
/*     */   
/*  83 */   private boolean ignoreNestedProperties = false;
/*     */   
/*     */ 
/*     */   private String targetName;
/*     */   
/*     */ 
/*     */   private ConversionService conversionService;
/*     */   
/*     */ 
/*     */ 
/*     */   public PropertiesConfigurationFactory(T target)
/*     */   {
/*  95 */     Assert.notNull(target);
/*  96 */     this.target = target;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PropertiesConfigurationFactory(Class<?> type)
/*     */   {
/* 106 */     Assert.notNull(type);
/* 107 */     this.target = BeanUtils.instantiate(type);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIgnoreNestedProperties(boolean ignoreNestedProperties)
/*     */   {
/* 117 */     this.ignoreNestedProperties = ignoreNestedProperties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIgnoreUnknownFields(boolean ignoreUnknownFields)
/*     */   {
/* 129 */     this.ignoreUnknownFields = ignoreUnknownFields;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIgnoreInvalidFields(boolean ignoreInvalidFields)
/*     */   {
/* 142 */     this.ignoreInvalidFields = ignoreInvalidFields;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTargetName(String targetName)
/*     */   {
/* 150 */     this.targetName = targetName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessageSource(MessageSource messageSource)
/*     */   {
/* 159 */     this.messageSource = messageSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void setProperties(Properties properties)
/*     */   {
/* 170 */     this.properties = properties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPropertySources(PropertySources propertySources)
/*     */   {
/* 178 */     this.propertySources = propertySources;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConversionService(ConversionService conversionService)
/*     */   {
/* 186 */     this.conversionService = conversionService;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValidator(Validator validator)
/*     */   {
/* 194 */     this.validator = validator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExceptionIfInvalid(boolean exceptionIfInvalid)
/*     */   {
/* 203 */     this.exceptionIfInvalid = exceptionIfInvalid;
/*     */   }
/*     */   
/*     */   public void afterPropertiesSet() throws Exception
/*     */   {
/* 208 */     bindPropertiesToTarget();
/*     */   }
/*     */   
/*     */   public Class<?> getObjectType()
/*     */   {
/* 213 */     if (this.target == null) {
/* 214 */       return Object.class;
/*     */     }
/* 216 */     return this.target.getClass();
/*     */   }
/*     */   
/*     */   public boolean isSingleton()
/*     */   {
/* 221 */     return true;
/*     */   }
/*     */   
/*     */   public T getObject() throws Exception
/*     */   {
/* 226 */     if (!this.hasBeenBound) {
/* 227 */       bindPropertiesToTarget();
/*     */     }
/* 229 */     return (T)this.target;
/*     */   }
/*     */   
/*     */   public void bindPropertiesToTarget() throws BindException {
/* 233 */     Assert.state((this.properties != null) || (this.propertySources != null), "Properties or propertySources should not be null");
/*     */     try
/*     */     {
/* 236 */       if (this.logger.isTraceEnabled()) {
/* 237 */         if (this.properties != null) {
/* 238 */           this.logger.trace(String.format("Properties:%n%s", new Object[] { this.properties }));
/*     */         }
/*     */         else {
/* 241 */           this.logger.trace("Property Sources: " + this.propertySources);
/*     */         }
/*     */       }
/* 244 */       this.hasBeenBound = true;
/* 245 */       doBindPropertiesToTarget();
/*     */     }
/*     */     catch (BindException ex) {
/* 248 */       if (this.exceptionIfInvalid) {
/* 249 */         throw ex;
/*     */       }
/* 251 */       this.logger.error("Failed to load Properties validation bean. Your Properties may be invalid.", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private void doBindPropertiesToTarget() throws BindException
/*     */   {
/* 257 */     RelaxedDataBinder dataBinder = this.targetName != null ? new RelaxedDataBinder(this.target, this.targetName) : new RelaxedDataBinder(this.target);
/*     */     
/*     */ 
/* 260 */     if (this.validator != null) {
/* 261 */       dataBinder.setValidator(this.validator);
/*     */     }
/* 263 */     if (this.conversionService != null) {
/* 264 */       dataBinder.setConversionService(this.conversionService);
/*     */     }
/* 266 */     dataBinder.setAutoGrowCollectionLimit(Integer.MAX_VALUE);
/* 267 */     dataBinder.setIgnoreNestedProperties(this.ignoreNestedProperties);
/* 268 */     dataBinder.setIgnoreInvalidFields(this.ignoreInvalidFields);
/* 269 */     dataBinder.setIgnoreUnknownFields(this.ignoreUnknownFields);
/* 270 */     customizeBinder(dataBinder);
/* 271 */     Iterable<String> relaxedTargetNames = getRelaxedTargetNames();
/* 272 */     Set<String> names = getNames(relaxedTargetNames);
/* 273 */     PropertyValues propertyValues = getPropertyValues(names, relaxedTargetNames);
/* 274 */     dataBinder.bind(propertyValues);
/* 275 */     if (this.validator != null) {
/* 276 */       validate(dataBinder);
/*     */     }
/*     */   }
/*     */   
/*     */   private Iterable<String> getRelaxedTargetNames() {
/* 281 */     return (this.target != null) && (StringUtils.hasLength(this.targetName)) ? new RelaxedNames(this.targetName) : null;
/*     */   }
/*     */   
/*     */   private Set<String> getNames(Iterable<String> prefixes)
/*     */   {
/* 286 */     Set<String> names = new LinkedHashSet();
/* 287 */     if (this.target != null)
/*     */     {
/* 289 */       PropertyDescriptor[] descriptors = BeanUtils.getPropertyDescriptors(this.target.getClass());
/* 290 */       RelaxedNames relaxedNames; String prefix; for (PropertyDescriptor descriptor : descriptors) {
/* 291 */         String name = descriptor.getName();
/* 292 */         if (!name.equals("class")) {
/* 293 */           relaxedNames = RelaxedNames.forCamelCase(name);
/* 294 */           if (prefixes == null) {
/* 295 */             for (String relaxedName : relaxedNames) {
/* 296 */               names.add(relaxedName);
/*     */             }
/*     */             
/*     */           } else {
/* 300 */             for (??? = prefixes.iterator(); ???.hasNext();) { prefix = (String)???.next();
/* 301 */               for (String relaxedName : relaxedNames) {
/* 302 */                 names.add(prefix + "." + relaxedName);
/* 303 */                 names.add(prefix + "_" + relaxedName);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 310 */     return names;
/*     */   }
/*     */   
/*     */   private PropertyValues getPropertyValues(Set<String> names, Iterable<String> relaxedTargetNames)
/*     */   {
/* 315 */     if (this.properties != null) {
/* 316 */       return new MutablePropertyValues(this.properties);
/*     */     }
/* 318 */     return getPropertySourcesPropertyValues(names, relaxedTargetNames);
/*     */   }
/*     */   
/*     */   private PropertyValues getPropertySourcesPropertyValues(Set<String> names, Iterable<String> relaxedTargetNames)
/*     */   {
/* 323 */     PropertyNamePatternsMatcher includes = getPropertyNamePatternsMatcher(names, relaxedTargetNames);
/*     */     
/* 325 */     return new PropertySourcesPropertyValues(this.propertySources, names, includes);
/*     */   }
/*     */   
/*     */   private PropertyNamePatternsMatcher getPropertyNamePatternsMatcher(Set<String> names, Iterable<String> relaxedTargetNames)
/*     */   {
/* 330 */     if ((this.ignoreUnknownFields) && (!isMapTarget()))
/*     */     {
/*     */ 
/* 333 */       return new DefaultPropertyNamePatternsMatcher(EXACT_DELIMITERS, true, names);
/*     */     }
/* 335 */     if (relaxedTargetNames != null)
/*     */     {
/*     */ 
/*     */ 
/* 339 */       Set<String> relaxedNames = new HashSet();
/* 340 */       for (String relaxedTargetName : relaxedTargetNames) {
/* 341 */         relaxedNames.add(relaxedTargetName);
/*     */       }
/* 343 */       return new DefaultPropertyNamePatternsMatcher(TARGET_NAME_DELIMITERS, true, relaxedNames);
/*     */     }
/*     */     
/*     */ 
/* 347 */     return PropertyNamePatternsMatcher.ALL;
/*     */   }
/*     */   
/*     */   private boolean isMapTarget() {
/* 351 */     return (this.target != null) && (Map.class.isAssignableFrom(this.target.getClass()));
/*     */   }
/*     */   
/*     */   private void validate(RelaxedDataBinder dataBinder) throws BindException {
/* 355 */     dataBinder.validate();
/* 356 */     BindingResult errors = dataBinder.getBindingResult();
/* 357 */     if (errors.hasErrors()) {
/* 358 */       this.logger.error("Properties configuration failed validation");
/* 359 */       for (ObjectError error : errors.getAllErrors())
/*     */       {
/* 361 */         this.logger.error(this.messageSource != null ? this.messageSource
/* 362 */           .getMessage(error, 
/* 363 */           Locale.getDefault()) + " (" + error + ")" : error);
/*     */       }
/*     */       
/*     */ 
/* 366 */       if (this.exceptionIfInvalid) {
/* 367 */         throw new BindException(errors);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void customizeBinder(DataBinder dataBinder) {}
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\bind\PropertiesConfigurationFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */