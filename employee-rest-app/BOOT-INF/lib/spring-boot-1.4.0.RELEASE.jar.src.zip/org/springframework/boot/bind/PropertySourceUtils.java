/*    */ package org.springframework.boot.bind;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.core.env.EnumerablePropertySource;
/*    */ import org.springframework.core.env.PropertySource;
/*    */ import org.springframework.core.env.PropertySources;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PropertySourceUtils
/*    */ {
/*    */   public static Map<String, Object> getSubProperties(PropertySources propertySources, String keyPrefix)
/*    */   {
/* 47 */     return getSubProperties(propertySources, null, keyPrefix);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Map<String, Object> getSubProperties(PropertySources propertySources, String rootPrefix, String keyPrefix)
/*    */   {
/* 62 */     RelaxedNames keyPrefixes = new RelaxedNames(keyPrefix);
/* 63 */     Map<String, Object> subProperties = new LinkedHashMap();
/* 64 */     for (PropertySource<?> source : propertySources) {
/* 65 */       if ((source instanceof EnumerablePropertySource)) {
/* 66 */         for (String name : ((EnumerablePropertySource)source)
/* 67 */           .getPropertyNames()) {
/* 68 */           String key = getSubKey(name, rootPrefix, keyPrefixes);
/*    */           
/* 70 */           if ((key != null) && (!subProperties.containsKey(key))) {
/* 71 */             subProperties.put(key, source.getProperty(name));
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/* 76 */     return Collections.unmodifiableMap(subProperties);
/*    */   }
/*    */   
/*    */   private static String getSubKey(String name, String rootPrefixes, RelaxedNames keyPrefix)
/*    */   {
/* 81 */     rootPrefixes = rootPrefixes == null ? "" : rootPrefixes;
/* 82 */     for (Iterator localIterator1 = new RelaxedNames(rootPrefixes).iterator(); localIterator1.hasNext();) { rootPrefix = (String)localIterator1.next();
/* 83 */       for (String candidateKeyPrefix : keyPrefix) {
/* 84 */         if (name.startsWith(rootPrefix + candidateKeyPrefix))
/* 85 */           return name.substring((rootPrefix + candidateKeyPrefix).length());
/*    */       }
/*    */     }
/*    */     String rootPrefix;
/* 89 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\bind\PropertySourceUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */