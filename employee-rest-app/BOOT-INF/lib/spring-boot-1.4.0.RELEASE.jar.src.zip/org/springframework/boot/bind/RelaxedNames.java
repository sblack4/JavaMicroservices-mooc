/*     */ package org.springframework.boot.bind;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RelaxedNames
/*     */   implements Iterable<String>
/*     */ {
/*  37 */   private static final Pattern CAMEL_CASE_PATTERN = Pattern.compile("([^A-Z-])([A-Z])");
/*     */   
/*     */ 
/*  40 */   private static final Pattern SEPARATED_TO_CAMEL_CASE_PATTERN = Pattern.compile("[_\\-.]");
/*     */   
/*     */   private final String name;
/*     */   
/*  44 */   private final Set<String> values = new LinkedHashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RelaxedNames(String name)
/*     */   {
/*  52 */     this.name = (name == null ? "" : name);
/*  53 */     initialize(this.name, this.values);
/*     */   }
/*     */   
/*     */   public Iterator<String> iterator()
/*     */   {
/*  58 */     return this.values.iterator();
/*     */   }
/*     */   
/*     */   private void initialize(String name, Set<String> values) {
/*  62 */     if (values.contains(name)) {
/*  63 */       return;
/*     */     }
/*  65 */     for (Variation variation : Variation.values()) {
/*  66 */       for (Manipulation manipulation : Manipulation.values()) {
/*  67 */         String result = name;
/*  68 */         result = manipulation.apply(result);
/*  69 */         result = variation.apply(result);
/*  70 */         values.add(result);
/*  71 */         initialize(result, values);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static abstract enum Variation
/*     */   {
/*  81 */     NONE, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */     LOWERCASE, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */     UPPERCASE;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private Variation() {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract String apply(String paramString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static abstract enum Manipulation
/*     */   {
/* 117 */     NONE, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 126 */     HYPHEN_TO_UNDERSCORE, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 135 */     UNDERSCORE_TO_PERIOD, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 144 */     PERIOD_TO_UNDERSCORE, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 153 */     CAMELCASE_TO_UNDERSCORE, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 169 */     CAMELCASE_TO_HYPHEN, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 185 */     SEPARATED_TO_CAMELCASE, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 194 */     CASE_INSENSITIVE_SEPARATED_TO_CAMELCASE;
/*     */     
/*     */ 
/*     */ 
/*     */     private Manipulation() {}
/*     */     
/*     */ 
/*     */ 
/*     */     public abstract String apply(String paramString);
/*     */     
/*     */ 
/*     */     private static String separatedToCamelCase(String value, boolean caseInsensitive)
/*     */     {
/* 207 */       StringBuilder builder = new StringBuilder();
/* 208 */       for (String field : RelaxedNames.SEPARATED_TO_CAMEL_CASE_PATTERN.split(value)) {
/* 209 */         field = caseInsensitive ? field.toLowerCase() : field;
/* 210 */         builder.append(builder
/* 211 */           .length() == 0 ? field : StringUtils.capitalize(field));
/*     */       }
/* 213 */       for (String suffix : new String[] { "_", "-", "." }) {
/* 214 */         if (value.endsWith(suffix)) {
/* 215 */           builder.append(suffix);
/*     */         }
/*     */       }
/* 218 */       return builder.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static RelaxedNames forCamelCase(String name)
/*     */   {
/* 229 */     return new RelaxedNames(Manipulation.CAMELCASE_TO_HYPHEN.apply(name));
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\bind\RelaxedNames.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */