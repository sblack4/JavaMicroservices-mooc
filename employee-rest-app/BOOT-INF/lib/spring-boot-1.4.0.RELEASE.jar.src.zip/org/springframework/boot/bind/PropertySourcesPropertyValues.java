/*     */ package org.springframework.boot.bind;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.PropertyValue;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.core.env.CompositePropertySource;
/*     */ import org.springframework.core.env.EnumerablePropertySource;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.core.env.PropertySources;
/*     */ import org.springframework.core.env.PropertySourcesPropertyResolver;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertySourcesPropertyValues
/*     */   implements PropertyValues
/*     */ {
/*  47 */   private static final Pattern COLLECTION_PROPERTY = Pattern.compile("\\[(\\d+)\\](\\.\\S+)?");
/*     */   
/*     */   private final PropertySources propertySources;
/*     */   
/*     */   private final Collection<String> nonEnumerableFallbackNames;
/*     */   
/*     */   private final PropertyNamePatternsMatcher includes;
/*     */   
/*  55 */   private final Map<String, PropertyValue> propertyValues = new LinkedHashMap();
/*     */   
/*  57 */   private final ConcurrentHashMap<String, PropertySource<?>> collectionOwners = new ConcurrentHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PropertySourcesPropertyValues(PropertySources propertySources)
/*     */   {
/*  64 */     this(propertySources, (Collection)null, PropertyNamePatternsMatcher.ALL);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PropertySourcesPropertyValues(PropertySources propertySources, Collection<String> includePatterns, Collection<String> nonEnumerableFallbackNames)
/*     */   {
/*  78 */     this(propertySources, nonEnumerableFallbackNames, new PatternPropertyNamePatternsMatcher(includePatterns));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   PropertySourcesPropertyValues(PropertySources propertySources, Collection<String> nonEnumerableFallbackNames, PropertyNamePatternsMatcher includes)
/*     */   {
/*  92 */     Assert.notNull(propertySources, "PropertySources must not be null");
/*  93 */     Assert.notNull(includes, "Includes must not be null");
/*  94 */     this.propertySources = propertySources;
/*  95 */     this.nonEnumerableFallbackNames = nonEnumerableFallbackNames;
/*  96 */     this.includes = includes;
/*  97 */     PropertySourcesPropertyResolver resolver = new PropertySourcesPropertyResolver(propertySources);
/*     */     
/*  99 */     for (PropertySource<?> source : propertySources) {
/* 100 */       processPropertySource(source, resolver);
/*     */     }
/*     */   }
/*     */   
/*     */   private void processPropertySource(PropertySource<?> source, PropertySourcesPropertyResolver resolver)
/*     */   {
/* 106 */     if ((source instanceof CompositePropertySource)) {
/* 107 */       processCompositePropertySource((CompositePropertySource)source, resolver);
/*     */     }
/* 109 */     else if ((source instanceof EnumerablePropertySource)) {
/* 110 */       processEnumerablePropertySource((EnumerablePropertySource)source, resolver, this.includes);
/*     */     }
/*     */     else
/*     */     {
/* 114 */       processNonEnumerablePropertySource(source, resolver);
/*     */     }
/*     */   }
/*     */   
/*     */   private void processCompositePropertySource(CompositePropertySource source, PropertySourcesPropertyResolver resolver)
/*     */   {
/* 120 */     for (PropertySource<?> nested : source.getPropertySources()) {
/* 121 */       processPropertySource(nested, resolver);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void processEnumerablePropertySource(EnumerablePropertySource<?> source, PropertySourcesPropertyResolver resolver, PropertyNamePatternsMatcher includes)
/*     */   {
/* 128 */     if (source.getPropertyNames().length > 0) {
/* 129 */       for (String propertyName : source.getPropertyNames()) {
/* 130 */         if (includes.matches(propertyName)) {
/* 131 */           Object value = getEnumerableProperty(source, resolver, propertyName);
/* 132 */           putIfAbsent(propertyName, value, source);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private Object getEnumerableProperty(EnumerablePropertySource<?> source, PropertySourcesPropertyResolver resolver, String propertyName)
/*     */   {
/*     */     try {
/* 141 */       return resolver.getProperty(propertyName, Object.class);
/*     */     }
/*     */     catch (RuntimeException ex) {}
/*     */     
/* 145 */     return source.getProperty(propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void processNonEnumerablePropertySource(PropertySource<?> source, PropertySourcesPropertyResolver resolver)
/*     */   {
/* 153 */     if (this.nonEnumerableFallbackNames == null) {
/* 154 */       return;
/*     */     }
/* 156 */     for (String propertyName : this.nonEnumerableFallbackNames) {
/* 157 */       if (source.containsProperty(propertyName))
/*     */       {
/*     */ 
/* 160 */         Object value = null;
/*     */         try {
/* 162 */           value = resolver.getProperty(propertyName, Object.class);
/*     */         }
/*     */         catch (RuntimeException localRuntimeException) {}
/*     */         
/*     */ 
/* 167 */         if (value == null) {
/* 168 */           value = source.getProperty(propertyName.toUpperCase());
/*     */         }
/* 170 */         putIfAbsent(propertyName, value, source);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public PropertyValue[] getPropertyValues() {
/* 176 */     Collection<PropertyValue> values = this.propertyValues.values();
/* 177 */     return (PropertyValue[])values.toArray(new PropertyValue[values.size()]);
/*     */   }
/*     */   
/*     */   public PropertyValue getPropertyValue(String propertyName)
/*     */   {
/* 182 */     PropertyValue propertyValue = (PropertyValue)this.propertyValues.get(propertyName);
/* 183 */     if (propertyValue != null) {
/* 184 */       return propertyValue;
/*     */     }
/* 186 */     for (PropertySource<?> source : this.propertySources) {
/* 187 */       Object value = source.getProperty(propertyName);
/* 188 */       propertyValue = putIfAbsent(propertyName, value, source);
/* 189 */       if (propertyValue != null) {
/* 190 */         return propertyValue;
/*     */       }
/*     */     }
/* 193 */     return null;
/*     */   }
/*     */   
/*     */   private PropertyValue putIfAbsent(String propertyName, Object value, PropertySource<?> source)
/*     */   {
/* 198 */     if ((value != null) && (!this.propertyValues.containsKey(propertyName))) {
/* 199 */       PropertySource<?> collectionOwner = (PropertySource)this.collectionOwners.putIfAbsent(COLLECTION_PROPERTY
/* 200 */         .matcher(propertyName).replaceAll("[]"), source);
/* 201 */       if ((collectionOwner == null) || (collectionOwner == source)) {
/* 202 */         PropertyValue propertyValue = new OriginCapablePropertyValue(propertyName, value, propertyName, source);
/*     */         
/* 204 */         this.propertyValues.put(propertyName, propertyValue);
/* 205 */         return propertyValue;
/*     */       }
/*     */     }
/* 208 */     return null;
/*     */   }
/*     */   
/*     */   public PropertyValues changesSince(PropertyValues old)
/*     */   {
/* 213 */     MutablePropertyValues changes = new MutablePropertyValues();
/*     */     
/* 215 */     for (PropertyValue newValue : getPropertyValues())
/*     */     {
/* 217 */       PropertyValue oldValue = old.getPropertyValue(newValue.getName());
/* 218 */       if ((oldValue == null) || (!oldValue.equals(newValue))) {
/* 219 */         changes.addPropertyValue(newValue);
/*     */       }
/*     */     }
/* 222 */     return changes;
/*     */   }
/*     */   
/*     */   public boolean contains(String propertyName)
/*     */   {
/* 227 */     return getPropertyValue(propertyName) != null;
/*     */   }
/*     */   
/*     */   public boolean isEmpty()
/*     */   {
/* 232 */     return this.propertyValues.isEmpty();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\bind\PropertySourcesPropertyValues.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */