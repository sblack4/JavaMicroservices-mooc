/*     */ package org.springframework.boot.jdbc;
/*     */ 
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum DatabaseDriver
/*     */ {
/*  36 */   UNKNOWN(null, null), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  41 */   DERBY("Apache Derby", "org.apache.derby.jdbc.EmbeddedDriver", null, "SELECT 1 FROM SYSIBM.SYSDUMMY1"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  47 */   H2("H2", "org.h2.Driver", "org.h2.jdbcx.JdbcDataSource", "SELECT 1"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  52 */   HSQLDB("HSQL Database Engine", "org.hsqldb.jdbc.JDBCDriver", "org.hsqldb.jdbc.pool.JDBCXADataSource", "SELECT COUNT(*) FROM INFORMATION_SCHEMA.SYSTEM_USERS"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  59 */   SQLITE("SQLite", "org.sqlite.JDBC"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  64 */   MYSQL("MySQL", "com.mysql.jdbc.Driver", "com.mysql.jdbc.jdbc2.optional.MysqlXADataSource", "SELECT 1"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  70 */   MARIADB("MySQL", "org.mariadb.jdbc.Driver", "org.mariadb.jdbc.MariaDbDataSource", "SELECT 1"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  76 */   GAE(null, "com.google.appengine.api.rdbms.AppEngineDriver"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  81 */   ORACLE("Oracle", "oracle.jdbc.OracleDriver", "oracle.jdbc.xa.client.OracleXADataSource", "SELECT 'Hello' from DUAL"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  87 */   POSTGRESQL("PostgreSQL", "org.postgresql.Driver", "org.postgresql.xa.PGXADataSource", "SELECT 1"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  94 */   JTDS(null, "net.sourceforge.jtds.jdbc.Driver"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  99 */   SQLSERVER("SQL SERVER", "com.microsoft.sqlserver.jdbc.SQLServerDriver", "com.microsoft.sqlserver.jdbc.SQLServerXADataSource", "SELECT 1"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */   FIREBIRD("Firebird", "org.firebirdsql.jdbc.FBDriver", "org.firebirdsql.pool.FBConnectionPoolDataSource", "SELECT 1 FROM RDB$DATABASE"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 119 */   DB2("DB2", "com.ibm.db2.jcc.DB2Driver", "com.ibm.db2.jcc.DB2XADataSource", "SELECT 1 FROM SYSIBM.SYSDUMMY1"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 132 */   DB2_AS400("DB2 UDB for AS/400", "com.ibm.as400.access.AS400JDBCDriver", "com.ibm.as400.access.AS400JDBCXADataSource", "SELECT 1 FROM SYSIBM.SYSDUMMY1"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 146 */   TERADATA("Teradata", "com.teradata.jdbc.TeraDriver"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 151 */   INFORMIX("Informix Dynamic Server", "com.informix.jdbc.IfxDriver", null, "select count(*) from systables");
/*     */   
/*     */ 
/*     */   private final String productName;
/*     */   
/*     */   private final String driverClassName;
/*     */   
/*     */   private final String xaDataSourceClassName;
/*     */   private final String validationQuery;
/*     */   
/*     */   private DatabaseDriver(String name, String driverClassName)
/*     */   {
/* 163 */     this(name, driverClassName, null);
/*     */   }
/*     */   
/*     */   private DatabaseDriver(String name, String driverClassName, String xaDataSourceClassName) {
/* 167 */     this(name, driverClassName, xaDataSourceClassName, null);
/*     */   }
/*     */   
/*     */   private DatabaseDriver(String productName, String driverClassName, String xaDataSourceClassName, String validationQuery)
/*     */   {
/* 172 */     this.productName = productName;
/* 173 */     this.driverClassName = driverClassName;
/* 174 */     this.xaDataSourceClassName = xaDataSourceClassName;
/* 175 */     this.validationQuery = validationQuery;
/*     */   }
/*     */   
/*     */   protected boolean matchProductName(String productName) {
/* 179 */     return (this.productName != null) && (this.productName.equalsIgnoreCase(productName));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDriverClassName()
/*     */   {
/* 187 */     return this.driverClassName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getXaDataSourceClassName()
/*     */   {
/* 195 */     return this.xaDataSourceClassName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getValidationQuery()
/*     */   {
/* 203 */     return this.validationQuery;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static DatabaseDriver fromJdbcUrl(String url)
/*     */   {
/* 212 */     if (StringUtils.hasLength(url)) {
/* 213 */       Assert.isTrue(url.startsWith("jdbc"), "URL must start with 'jdbc'");
/* 214 */       String urlWithoutPrefix = url.substring("jdbc".length()).toLowerCase();
/* 215 */       for (DatabaseDriver driver : values()) {
/* 216 */         String prefix = ":" + driver.name().toLowerCase() + ":";
/* 217 */         if ((driver != UNKNOWN) && (urlWithoutPrefix.startsWith(prefix))) {
/* 218 */           return driver;
/*     */         }
/*     */       }
/*     */     }
/* 222 */     return UNKNOWN;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static DatabaseDriver fromProductName(String productName)
/*     */   {
/* 231 */     if (StringUtils.hasLength(productName)) {
/* 232 */       for (DatabaseDriver candidate : values()) {
/* 233 */         if (candidate.matchProductName(productName)) {
/* 234 */           return candidate;
/*     */         }
/*     */       }
/*     */     }
/* 238 */     return UNKNOWN;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\jdbc\DatabaseDriver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */