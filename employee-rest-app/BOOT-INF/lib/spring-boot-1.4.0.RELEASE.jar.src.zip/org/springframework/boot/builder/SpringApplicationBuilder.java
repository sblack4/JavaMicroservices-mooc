/*     */ package org.springframework.boot.builder;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.boot.Banner;
/*     */ import org.springframework.boot.Banner.Mode;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.context.ApplicationContextInitializer;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringApplicationBuilder
/*     */ {
/*     */   private final SpringApplication application;
/*     */   private ConfigurableApplicationContext context;
/*     */   private SpringApplicationBuilder parent;
/*  72 */   private final AtomicBoolean running = new AtomicBoolean(false);
/*     */   
/*  74 */   private final Set<Object> sources = new LinkedHashSet();
/*     */   
/*  76 */   private final Map<String, Object> defaultProperties = new LinkedHashMap();
/*     */   
/*     */   private ConfigurableEnvironment environment;
/*     */   
/*  80 */   private Set<String> additionalProfiles = new LinkedHashSet();
/*     */   
/*     */   private boolean registerShutdownHookApplied;
/*     */   
/*  84 */   private boolean configuredAsChild = false;
/*     */   
/*     */   public SpringApplicationBuilder(Object... sources) {
/*  87 */     this.application = createSpringApplication(sources);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SpringApplication createSpringApplication(Object... sources)
/*     */   {
/*  99 */     return new SpringApplication(sources);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConfigurableApplicationContext context()
/*     */   {
/* 107 */     return this.context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplication application()
/*     */   {
/* 115 */     return this.application;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConfigurableApplicationContext run(String... args)
/*     */   {
/* 126 */     if (this.running.get())
/*     */     {
/* 128 */       return this.context;
/*     */     }
/* 130 */     configureAsChildIfNecessary(args);
/* 131 */     if (this.running.compareAndSet(false, true)) {
/* 132 */       synchronized (this.running)
/*     */       {
/* 134 */         this.context = build().run(args);
/*     */       }
/*     */     }
/* 137 */     return this.context;
/*     */   }
/*     */   
/*     */   private void configureAsChildIfNecessary(String... args) {
/* 141 */     if ((this.parent != null) && (!this.configuredAsChild)) {
/* 142 */       this.configuredAsChild = true;
/* 143 */       if (!this.registerShutdownHookApplied) {
/* 144 */         this.application.setRegisterShutdownHook(false);
/*     */       }
/* 146 */       initializers(new ApplicationContextInitializer[] { new ParentContextApplicationContextInitializer(this.parent
/* 147 */         .run(args)) });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplication build()
/*     */   {
/* 156 */     return build(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplication build(String... args)
/*     */   {
/* 166 */     configureAsChildIfNecessary(args);
/* 167 */     this.application.setSources(this.sources);
/* 168 */     return this.application;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder child(Object... sources)
/*     */   {
/* 178 */     SpringApplicationBuilder child = new SpringApplicationBuilder(new Object[0]);
/* 179 */     child.sources(sources);
/*     */     
/*     */ 
/* 182 */     child.properties(this.defaultProperties).environment(this.environment)
/* 183 */       .additionalProfiles(this.additionalProfiles);
/* 184 */     child.parent = this;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 189 */     web(false);
/*     */     
/*     */ 
/* 192 */     bannerMode(Banner.Mode.OFF);
/*     */     
/*     */ 
/* 195 */     this.application.setSources(this.sources);
/*     */     
/* 197 */     return child;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder parent(Object... sources)
/*     */   {
/* 207 */     if (this.parent == null)
/*     */     {
/* 209 */       this.parent = new SpringApplicationBuilder(sources).web(false).properties(this.defaultProperties).environment(this.environment);
/*     */     }
/*     */     else {
/* 212 */       this.parent.sources(sources);
/*     */     }
/* 214 */     return this.parent;
/*     */   }
/*     */   
/*     */   private SpringApplicationBuilder runAndExtractParent(String... args) {
/* 218 */     if (this.context == null) {
/* 219 */       run(args);
/*     */     }
/* 221 */     if (this.parent != null) {
/* 222 */       return this.parent;
/*     */     }
/* 224 */     throw new IllegalStateException("No parent defined yet (please use the other overloaded parent methods to set one)");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder parent(ConfigurableApplicationContext parent)
/*     */   {
/* 234 */     this.parent = new SpringApplicationBuilder(new Object[0]);
/* 235 */     this.parent.context = parent;
/* 236 */     this.parent.running.set(true);
/* 237 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder sibling(Object... sources)
/*     */   {
/* 247 */     return runAndExtractParent(new String[0]).child(sources);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder sibling(Object[] sources, String... args)
/*     */   {
/* 260 */     return runAndExtractParent(args).child(sources);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder contextClass(Class<? extends ConfigurableApplicationContext> cls)
/*     */   {
/* 270 */     this.application.setApplicationContextClass(cls);
/* 271 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder sources(Object... sources)
/*     */   {
/* 280 */     this.sources.addAll(new LinkedHashSet(Arrays.asList(sources)));
/* 281 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder sources(Class<?>... sources)
/*     */   {
/* 290 */     this.sources.addAll(new LinkedHashSet(Arrays.asList(sources)));
/* 291 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder web(boolean webEnvironment)
/*     */   {
/* 301 */     this.application.setWebEnvironment(webEnvironment);
/* 302 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder logStartupInfo(boolean logStartupInfo)
/*     */   {
/* 311 */     this.application.setLogStartupInfo(logStartupInfo);
/* 312 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder banner(Banner banner)
/*     */   {
/* 322 */     this.application.setBanner(banner);
/* 323 */     return this;
/*     */   }
/*     */   
/*     */   public SpringApplicationBuilder bannerMode(Banner.Mode bannerMode) {
/* 327 */     this.application.setBannerMode(bannerMode);
/* 328 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder headless(boolean headless)
/*     */   {
/* 338 */     this.application.setHeadless(headless);
/* 339 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder registerShutdownHook(boolean registerShutdownHook)
/*     */   {
/* 349 */     this.registerShutdownHookApplied = true;
/* 350 */     this.application.setRegisterShutdownHook(registerShutdownHook);
/* 351 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder main(Class<?> mainApplicationClass)
/*     */   {
/* 360 */     this.application.setMainApplicationClass(mainApplicationClass);
/* 361 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder addCommandLineProperties(boolean addCommandLineProperties)
/*     */   {
/* 371 */     this.application.setAddCommandLineProperties(addCommandLineProperties);
/* 372 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder properties(String... defaultProperties)
/*     */   {
/* 382 */     return properties(getMapFromKeyValuePairs(defaultProperties));
/*     */   }
/*     */   
/*     */   private Map<String, Object> getMapFromKeyValuePairs(String[] properties) {
/* 386 */     Map<String, Object> map = new HashMap();
/* 387 */     for (String property : properties) {
/* 388 */       int index = lowestIndexOf(property, new String[] { ":", "=" });
/* 389 */       String key = property.substring(0, index > 0 ? index : property.length());
/* 390 */       String value = index > 0 ? property.substring(index + 1) : "";
/* 391 */       map.put(key, value);
/*     */     }
/* 393 */     return map;
/*     */   }
/*     */   
/*     */   private int lowestIndexOf(String property, String... candidates) {
/* 397 */     int index = -1;
/* 398 */     for (String candidate : candidates) {
/* 399 */       int candidateIndex = property.indexOf(candidate);
/* 400 */       if (candidateIndex > 0) {
/* 401 */         index = index == -1 ? candidateIndex : Math.min(index, candidateIndex);
/*     */       }
/*     */     }
/* 404 */     return index;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder properties(Properties defaultProperties)
/*     */   {
/* 414 */     return properties(getMapFromProperties(defaultProperties));
/*     */   }
/*     */   
/*     */   private Map<String, Object> getMapFromProperties(Properties properties) {
/* 418 */     HashMap<String, Object> map = new HashMap();
/* 419 */     for (Object key : Collections.list(properties.propertyNames())) {
/* 420 */       map.put((String)key, properties.get(key));
/*     */     }
/* 422 */     return map;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder properties(Map<String, Object> defaults)
/*     */   {
/* 433 */     this.defaultProperties.putAll(defaults);
/* 434 */     this.application.setDefaultProperties(this.defaultProperties);
/* 435 */     if (this.parent != null) {
/* 436 */       this.parent.properties(this.defaultProperties);
/* 437 */       this.parent.environment(this.environment);
/*     */     }
/* 439 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder profiles(String... profiles)
/*     */   {
/* 448 */     this.additionalProfiles.addAll(Arrays.asList(profiles));
/* 449 */     this.application.setAdditionalProfiles(
/* 450 */       (String[])this.additionalProfiles.toArray(new String[this.additionalProfiles.size()]));
/* 451 */     return this;
/*     */   }
/*     */   
/*     */   private SpringApplicationBuilder additionalProfiles(Collection<String> additionalProfiles)
/*     */   {
/* 456 */     this.additionalProfiles = new LinkedHashSet(additionalProfiles);
/* 457 */     this.application.setAdditionalProfiles(
/* 458 */       (String[])this.additionalProfiles.toArray(new String[this.additionalProfiles.size()]));
/* 459 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder beanNameGenerator(BeanNameGenerator beanNameGenerator)
/*     */   {
/* 470 */     this.application.setBeanNameGenerator(beanNameGenerator);
/* 471 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder environment(ConfigurableEnvironment environment)
/*     */   {
/* 480 */     this.application.setEnvironment(environment);
/* 481 */     this.environment = environment;
/* 482 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder resourceLoader(ResourceLoader resourceLoader)
/*     */   {
/* 492 */     this.application.setResourceLoader(resourceLoader);
/* 493 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder initializers(ApplicationContextInitializer<?>... initializers)
/*     */   {
/* 504 */     this.application.addInitializers(initializers);
/* 505 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder listeners(ApplicationListener<?>... listeners)
/*     */   {
/* 517 */     this.application.addListeners(listeners);
/* 518 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\builder\SpringApplicationBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */