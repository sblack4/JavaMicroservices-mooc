/*      */ package org.springframework.boot;
/*      */ 
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.security.AccessControlException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.beans.BeanUtils;
/*      */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*      */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*      */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*      */ import org.springframework.boot.diagnostics.FailureAnalyzers;
/*      */ import org.springframework.context.ApplicationContext;
/*      */ import org.springframework.context.ApplicationContextInitializer;
/*      */ import org.springframework.context.ApplicationListener;
/*      */ import org.springframework.context.ConfigurableApplicationContext;
/*      */ import org.springframework.context.support.AbstractApplicationContext;
/*      */ import org.springframework.context.support.GenericApplicationContext;
/*      */ import org.springframework.core.GenericTypeResolver;
/*      */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*      */ import org.springframework.core.env.CompositePropertySource;
/*      */ import org.springframework.core.env.ConfigurableEnvironment;
/*      */ import org.springframework.core.env.Environment;
/*      */ import org.springframework.core.env.MapPropertySource;
/*      */ import org.springframework.core.env.MutablePropertySources;
/*      */ import org.springframework.core.env.PropertySource;
/*      */ import org.springframework.core.env.SimpleCommandLinePropertySource;
/*      */ import org.springframework.core.env.StandardEnvironment;
/*      */ import org.springframework.core.io.DefaultResourceLoader;
/*      */ import org.springframework.core.io.ResourceLoader;
/*      */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.ReflectionUtils;
/*      */ import org.springframework.util.StopWatch;
/*      */ import org.springframework.util.StringUtils;
/*      */ import org.springframework.web.context.WebApplicationContext;
/*      */ import org.springframework.web.context.support.StandardServletEnvironment;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SpringApplication
/*      */ {
/*      */   public static final String DEFAULT_CONTEXT_CLASS = "org.springframework.context.annotation.AnnotationConfigApplicationContext";
/*      */   public static final String DEFAULT_WEB_CONTEXT_CLASS = "org.springframework.boot.context.embedded.AnnotationConfigEmbeddedWebApplicationContext";
/*  162 */   private static final String[] WEB_ENVIRONMENT_CLASSES = { "javax.servlet.Servlet", "org.springframework.web.context.ConfigurableWebApplicationContext" };
/*      */   
/*      */ 
/*      */   public static final String BANNER_LOCATION_PROPERTY_VALUE = "banner.txt";
/*      */   
/*      */ 
/*      */   public static final String BANNER_LOCATION_PROPERTY = "banner.location";
/*      */   
/*      */ 
/*      */   private static final String CONFIGURABLE_WEB_ENVIRONMENT_CLASS = "org.springframework.web.context.ConfigurableWebEnvironment";
/*      */   
/*      */ 
/*      */   private static final String SYSTEM_PROPERTY_JAVA_AWT_HEADLESS = "java.awt.headless";
/*      */   
/*      */ 
/*      */   private static final Set<String> SERVLET_ENVIRONMENT_SOURCE_NAMES;
/*      */   
/*      */ 
/*      */   static
/*      */   {
/*  182 */     Set<String> names = new HashSet();
/*  183 */     names.add("servletContextInitParams");
/*  184 */     names.add("servletConfigInitParams");
/*  185 */     names.add("jndiProperties");
/*  186 */     SERVLET_ENVIRONMENT_SOURCE_NAMES = Collections.unmodifiableSet(names);
/*      */   }
/*      */   
/*  189 */   private static final Log logger = LogFactory.getLog(SpringApplication.class);
/*      */   
/*  191 */   private final Set<Object> sources = new LinkedHashSet();
/*      */   
/*      */   private Class<?> mainApplicationClass;
/*      */   
/*  195 */   private Banner.Mode bannerMode = Banner.Mode.CONSOLE;
/*      */   
/*  197 */   private boolean logStartupInfo = true;
/*      */   
/*  199 */   private boolean addCommandLineProperties = true;
/*      */   
/*      */   private Banner banner;
/*      */   
/*      */   private boolean printedCustomBannerViaDeprecatedMethod;
/*      */   
/*      */   private ResourceLoader resourceLoader;
/*      */   
/*      */   private BeanNameGenerator beanNameGenerator;
/*      */   
/*      */   private ConfigurableEnvironment environment;
/*      */   
/*      */   private Class<? extends ConfigurableApplicationContext> applicationContextClass;
/*      */   
/*      */   private boolean webEnvironment;
/*      */   
/*  215 */   private boolean headless = true;
/*      */   
/*  217 */   private boolean registerShutdownHook = true;
/*      */   
/*      */   private List<ApplicationContextInitializer<?>> initializers;
/*      */   
/*      */   private List<ApplicationListener<?>> listeners;
/*      */   
/*      */   private Map<String, Object> defaultProperties;
/*      */   
/*  225 */   private Set<String> additionalProfiles = new HashSet();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SpringApplication(Object... sources)
/*      */   {
/*  237 */     initialize(sources);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SpringApplication(ResourceLoader resourceLoader, Object... sources)
/*      */   {
/*  251 */     this.resourceLoader = resourceLoader;
/*  252 */     initialize(sources);
/*      */   }
/*      */   
/*      */   private void initialize(Object[] sources)
/*      */   {
/*  257 */     if ((sources != null) && (sources.length > 0)) {
/*  258 */       this.sources.addAll(Arrays.asList(sources));
/*      */     }
/*  260 */     this.webEnvironment = deduceWebEnvironment();
/*  261 */     setInitializers(getSpringFactoriesInstances(ApplicationContextInitializer.class));
/*      */     
/*  263 */     setListeners(getSpringFactoriesInstances(ApplicationListener.class));
/*  264 */     this.mainApplicationClass = deduceMainApplicationClass();
/*      */   }
/*      */   
/*      */   private boolean deduceWebEnvironment() {
/*  268 */     for (String className : WEB_ENVIRONMENT_CLASSES) {
/*  269 */       if (!ClassUtils.isPresent(className, null)) {
/*  270 */         return false;
/*      */       }
/*      */     }
/*  273 */     return true;
/*      */   }
/*      */   
/*      */   private Class<?> deduceMainApplicationClass() {
/*      */     try {
/*  278 */       StackTraceElement[] stackTrace = new RuntimeException().getStackTrace();
/*  279 */       for (StackTraceElement stackTraceElement : stackTrace) {
/*  280 */         if ("main".equals(stackTraceElement.getMethodName())) {
/*  281 */           return Class.forName(stackTraceElement.getClassName());
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (ClassNotFoundException localClassNotFoundException) {}
/*      */     
/*      */ 
/*  288 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ConfigurableApplicationContext run(String... args)
/*      */   {
/*  298 */     StopWatch stopWatch = new StopWatch();
/*  299 */     stopWatch.start();
/*  300 */     ConfigurableApplicationContext context = null;
/*  301 */     configureHeadlessProperty();
/*  302 */     SpringApplicationRunListeners listeners = getRunListeners(args);
/*  303 */     listeners.started();
/*      */     try {
/*  305 */       ApplicationArguments applicationArguments = new DefaultApplicationArguments(args);
/*      */       
/*  307 */       ConfigurableEnvironment environment = prepareEnvironment(listeners, applicationArguments);
/*      */       
/*  309 */       Banner printedBanner = printBanner(environment);
/*  310 */       context = createApplicationContext();
/*  311 */       prepareContext(context, environment, listeners, applicationArguments, printedBanner);
/*      */       
/*  313 */       refreshContext(context);
/*  314 */       afterRefresh(context, applicationArguments);
/*  315 */       listeners.finished(context, null);
/*  316 */       stopWatch.stop();
/*  317 */       if (this.logStartupInfo)
/*      */       {
/*  319 */         new StartupInfoLogger(this.mainApplicationClass).logStarted(getApplicationLog(), stopWatch);
/*      */       }
/*  321 */       return context;
/*      */     }
/*      */     catch (Throwable ex) {
/*  324 */       handleRunFailure(context, listeners, ex);
/*  325 */       throw new IllegalStateException(ex);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private ConfigurableEnvironment prepareEnvironment(SpringApplicationRunListeners listeners, ApplicationArguments applicationArguments)
/*      */   {
/*  333 */     ConfigurableEnvironment environment = getOrCreateEnvironment();
/*  334 */     configureEnvironment(environment, applicationArguments.getSourceArgs());
/*  335 */     listeners.environmentPrepared(environment);
/*  336 */     if ((isWebEnvironment(environment)) && (!this.webEnvironment)) {
/*  337 */       environment = convertToStandardEnvironment(environment);
/*      */     }
/*  339 */     return environment;
/*      */   }
/*      */   
/*      */ 
/*      */   private void prepareContext(ConfigurableApplicationContext context, ConfigurableEnvironment environment, SpringApplicationRunListeners listeners, ApplicationArguments applicationArguments, Banner printedBanner)
/*      */   {
/*  345 */     context.setEnvironment(environment);
/*  346 */     postProcessApplicationContext(context);
/*  347 */     applyInitializers(context);
/*  348 */     listeners.contextPrepared(context);
/*  349 */     if (this.logStartupInfo) {
/*  350 */       logStartupInfo(context.getParent() == null);
/*  351 */       logStartupProfileInfo(context);
/*      */     }
/*      */     
/*      */ 
/*  355 */     context.getBeanFactory().registerSingleton("springApplicationArguments", applicationArguments);
/*      */     
/*  357 */     if (printedBanner != null) {
/*  358 */       context.getBeanFactory().registerSingleton("springBootBanner", printedBanner);
/*      */     }
/*      */     
/*      */ 
/*  362 */     Set<Object> sources = getSources();
/*  363 */     Assert.notEmpty(sources, "Sources must not be empty");
/*  364 */     load(context, sources.toArray(new Object[sources.size()]));
/*  365 */     listeners.contextLoaded(context);
/*      */   }
/*      */   
/*      */   private void refreshContext(ConfigurableApplicationContext context) {
/*  369 */     refresh(context);
/*  370 */     if (this.registerShutdownHook) {
/*      */       try {
/*  372 */         context.registerShutdownHook();
/*      */       }
/*      */       catch (AccessControlException localAccessControlException) {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void configureHeadlessProperty()
/*      */   {
/*  381 */     System.setProperty("java.awt.headless", System.getProperty("java.awt.headless", 
/*  382 */       Boolean.toString(this.headless)));
/*      */   }
/*      */   
/*      */   private SpringApplicationRunListeners getRunListeners(String[] args) {
/*  386 */     Class<?>[] types = { SpringApplication.class, String[].class };
/*  387 */     return new SpringApplicationRunListeners(logger, getSpringFactoriesInstances(SpringApplicationRunListener.class, types, new Object[] { this, args }));
/*      */   }
/*      */   
/*      */   private <T> Collection<? extends T> getSpringFactoriesInstances(Class<T> type)
/*      */   {
/*  392 */     return getSpringFactoriesInstances(type, new Class[0], new Object[0]);
/*      */   }
/*      */   
/*      */   private <T> Collection<? extends T> getSpringFactoriesInstances(Class<T> type, Class<?>[] parameterTypes, Object... args)
/*      */   {
/*  397 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*      */     
/*      */ 
/*  400 */     Set<String> names = new LinkedHashSet(SpringFactoriesLoader.loadFactoryNames(type, classLoader));
/*  401 */     List<T> instances = createSpringFactoriesInstances(type, parameterTypes, classLoader, args, names);
/*      */     
/*  403 */     AnnotationAwareOrderComparator.sort(instances);
/*  404 */     return instances;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private <T> List<T> createSpringFactoriesInstances(Class<T> type, Class<?>[] parameterTypes, ClassLoader classLoader, Object[] args, Set<String> names)
/*      */   {
/*  411 */     List<T> instances = new ArrayList(names.size());
/*  412 */     for (String name : names) {
/*      */       try {
/*  414 */         Class<?> instanceClass = ClassUtils.forName(name, classLoader);
/*  415 */         Assert.isAssignable(type, instanceClass);
/*      */         
/*  417 */         Constructor<?> constructor = instanceClass.getDeclaredConstructor(parameterTypes);
/*  418 */         T instance = BeanUtils.instantiateClass(constructor, args);
/*  419 */         instances.add(instance);
/*      */       }
/*      */       catch (Throwable ex) {
/*  422 */         throw new IllegalArgumentException("Cannot instantiate " + type + " : " + name, ex);
/*      */       }
/*      */     }
/*      */     
/*  426 */     return instances;
/*      */   }
/*      */   
/*      */   private ConfigurableEnvironment getOrCreateEnvironment() {
/*  430 */     if (this.environment != null) {
/*  431 */       return this.environment;
/*      */     }
/*  433 */     if (this.webEnvironment) {
/*  434 */       return new StandardServletEnvironment();
/*      */     }
/*  436 */     return new StandardEnvironment();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void configureEnvironment(ConfigurableEnvironment environment, String[] args)
/*      */   {
/*  452 */     configurePropertySources(environment, args);
/*  453 */     configureProfiles(environment, args);
/*      */   }
/*      */   
/*      */   private boolean isWebEnvironment(ConfigurableEnvironment environment)
/*      */   {
/*      */     try {
/*  459 */       Class<?> webEnvironmentClass = ClassUtils.forName("org.springframework.web.context.ConfigurableWebEnvironment", getClassLoader());
/*  460 */       return webEnvironmentClass.isInstance(environment);
/*      */     }
/*      */     catch (Throwable ex) {}
/*  463 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   private ConfigurableEnvironment convertToStandardEnvironment(ConfigurableEnvironment environment)
/*      */   {
/*  469 */     StandardEnvironment result = new StandardEnvironment();
/*  470 */     removeAllPropertySources(result.getPropertySources());
/*  471 */     result.setActiveProfiles(environment.getActiveProfiles());
/*  472 */     for (PropertySource<?> propertySource : environment.getPropertySources()) {
/*  473 */       if (!SERVLET_ENVIRONMENT_SOURCE_NAMES.contains(propertySource.getName())) {
/*  474 */         result.getPropertySources().addLast(propertySource);
/*      */       }
/*      */     }
/*  477 */     return result;
/*      */   }
/*      */   
/*      */   private void removeAllPropertySources(MutablePropertySources propertySources) {
/*  481 */     Set<String> names = new HashSet();
/*  482 */     for (PropertySource<?> propertySource : propertySources) {
/*  483 */       names.add(propertySource.getName());
/*      */     }
/*  485 */     for (String name : names) {
/*  486 */       propertySources.remove(name);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void configurePropertySources(ConfigurableEnvironment environment, String[] args)
/*      */   {
/*  499 */     MutablePropertySources sources = environment.getPropertySources();
/*  500 */     if ((this.defaultProperties != null) && (!this.defaultProperties.isEmpty())) {
/*  501 */       sources.addLast(new MapPropertySource("defaultProperties", this.defaultProperties));
/*      */     }
/*      */     
/*  504 */     if ((this.addCommandLineProperties) && (args.length > 0)) {
/*  505 */       String name = "commandLineArgs";
/*  506 */       if (sources.contains(name)) {
/*  507 */         PropertySource<?> source = sources.get(name);
/*  508 */         CompositePropertySource composite = new CompositePropertySource(name);
/*  509 */         composite.addPropertySource(new SimpleCommandLinePropertySource(name + "-" + args
/*  510 */           .hashCode(), args));
/*  511 */         composite.addPropertySource(source);
/*  512 */         sources.replace(name, composite);
/*      */       }
/*      */       else {
/*  515 */         sources.addFirst(new SimpleCommandLinePropertySource(args));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void configureProfiles(ConfigurableEnvironment environment, String[] args)
/*      */   {
/*  530 */     environment.getActiveProfiles();
/*      */     
/*  532 */     Set<String> profiles = new LinkedHashSet(this.additionalProfiles);
/*  533 */     profiles.addAll(Arrays.asList(environment.getActiveProfiles()));
/*  534 */     environment.setActiveProfiles((String[])profiles.toArray(new String[profiles.size()]));
/*      */   }
/*      */   
/*      */   private Banner printBanner(ConfigurableEnvironment environment) {
/*  538 */     if (this.bannerMode == Banner.Mode.OFF) {
/*  539 */       return null;
/*      */     }
/*  541 */     if (printBannerViaDeprecatedMethod(environment)) {
/*  542 */       return null;
/*      */     }
/*      */     
/*  545 */     ResourceLoader resourceLoader = this.resourceLoader != null ? this.resourceLoader : new DefaultResourceLoader(getClassLoader());
/*  546 */     SpringApplicationBannerPrinter bannerPrinter = new SpringApplicationBannerPrinter(resourceLoader, this.banner);
/*      */     
/*  548 */     if (this.bannerMode == Banner.Mode.LOG) {
/*  549 */       return bannerPrinter.print(environment, this.mainApplicationClass, logger);
/*      */     }
/*  551 */     return bannerPrinter.print(environment, this.mainApplicationClass, System.out);
/*      */   }
/*      */   
/*      */   private boolean printBannerViaDeprecatedMethod(Environment environment) {
/*  555 */     this.printedCustomBannerViaDeprecatedMethod = true;
/*  556 */     printBanner(environment);
/*  557 */     return this.printedCustomBannerViaDeprecatedMethod;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected void printBanner(Environment environment)
/*      */   {
/*  571 */     this.printedCustomBannerViaDeprecatedMethod = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ConfigurableApplicationContext createApplicationContext()
/*      */   {
/*  582 */     Class<?> contextClass = this.applicationContextClass;
/*  583 */     if (contextClass == null) {
/*      */       try {
/*  585 */         contextClass = Class.forName(this.webEnvironment ? "org.springframework.boot.context.embedded.AnnotationConfigEmbeddedWebApplicationContext" : "org.springframework.context.annotation.AnnotationConfigApplicationContext");
/*      */       }
/*      */       catch (ClassNotFoundException ex)
/*      */       {
/*  589 */         throw new IllegalStateException("Unable create a default ApplicationContext, please specify an ApplicationContextClass", ex);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  595 */     return (ConfigurableApplicationContext)BeanUtils.instantiate(contextClass);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void postProcessApplicationContext(ConfigurableApplicationContext context)
/*      */   {
/*  604 */     if (this.beanNameGenerator != null) {
/*  605 */       context.getBeanFactory().registerSingleton("org.springframework.context.annotation.internalConfigurationBeanNameGenerator", this.beanNameGenerator);
/*      */     }
/*      */     
/*      */ 
/*  609 */     if (this.resourceLoader != null) {
/*  610 */       if ((context instanceof GenericApplicationContext))
/*      */       {
/*  612 */         ((GenericApplicationContext)context).setResourceLoader(this.resourceLoader);
/*      */       }
/*  614 */       if ((context instanceof DefaultResourceLoader))
/*      */       {
/*  616 */         ((DefaultResourceLoader)context).setClassLoader(this.resourceLoader.getClassLoader());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void applyInitializers(ConfigurableApplicationContext context)
/*      */   {
/*  629 */     for (ApplicationContextInitializer initializer : getInitializers()) {
/*  630 */       Class<?> requiredType = GenericTypeResolver.resolveTypeArgument(initializer
/*  631 */         .getClass(), ApplicationContextInitializer.class);
/*  632 */       Assert.isInstanceOf(requiredType, context, "Unable to call initializer.");
/*  633 */       initializer.initialize(context);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void logStartupInfo(boolean isRoot)
/*      */   {
/*  643 */     if (isRoot)
/*      */     {
/*  645 */       new StartupInfoLogger(this.mainApplicationClass).logStarting(getApplicationLog());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void logStartupProfileInfo(ConfigurableApplicationContext context)
/*      */   {
/*  654 */     Log log = getApplicationLog();
/*  655 */     if (log.isInfoEnabled()) {
/*  656 */       String[] activeProfiles = context.getEnvironment().getActiveProfiles();
/*  657 */       if (ObjectUtils.isEmpty(activeProfiles)) {
/*  658 */         String[] defaultProfiles = context.getEnvironment().getDefaultProfiles();
/*  659 */         log.info("No active profile set, falling back to default profiles: " + 
/*  660 */           StringUtils.arrayToCommaDelimitedString(defaultProfiles));
/*      */       }
/*      */       else {
/*  663 */         log.info("The following profiles are active: " + 
/*  664 */           StringUtils.arrayToCommaDelimitedString(activeProfiles));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Log getApplicationLog()
/*      */   {
/*  674 */     if (this.mainApplicationClass == null) {
/*  675 */       return logger;
/*      */     }
/*  677 */     return LogFactory.getLog(this.mainApplicationClass);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void load(ApplicationContext context, Object[] sources)
/*      */   {
/*  686 */     if (logger.isDebugEnabled()) {
/*  687 */       logger.debug("Loading source " + 
/*  688 */         StringUtils.arrayToCommaDelimitedString(sources));
/*      */     }
/*  690 */     BeanDefinitionLoader loader = createBeanDefinitionLoader(
/*  691 */       getBeanDefinitionRegistry(context), sources);
/*  692 */     if (this.beanNameGenerator != null) {
/*  693 */       loader.setBeanNameGenerator(this.beanNameGenerator);
/*      */     }
/*  695 */     if (this.resourceLoader != null) {
/*  696 */       loader.setResourceLoader(this.resourceLoader);
/*      */     }
/*  698 */     if (this.environment != null) {
/*  699 */       loader.setEnvironment(this.environment);
/*      */     }
/*  701 */     loader.load();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResourceLoader getResourceLoader()
/*      */   {
/*  710 */     return this.resourceLoader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClassLoader getClassLoader()
/*      */   {
/*  720 */     if (this.resourceLoader != null) {
/*  721 */       return this.resourceLoader.getClassLoader();
/*      */     }
/*  723 */     return ClassUtils.getDefaultClassLoader();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private BeanDefinitionRegistry getBeanDefinitionRegistry(ApplicationContext context)
/*      */   {
/*  732 */     if ((context instanceof BeanDefinitionRegistry)) {
/*  733 */       return (BeanDefinitionRegistry)context;
/*      */     }
/*  735 */     if ((context instanceof AbstractApplicationContext))
/*      */     {
/*  737 */       return (BeanDefinitionRegistry)((AbstractApplicationContext)context).getBeanFactory();
/*      */     }
/*  739 */     throw new IllegalStateException("Could not locate BeanDefinitionRegistry");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected BeanDefinitionLoader createBeanDefinitionLoader(BeanDefinitionRegistry registry, Object[] sources)
/*      */   {
/*  750 */     return new BeanDefinitionLoader(registry, sources);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void refresh(ApplicationContext applicationContext)
/*      */   {
/*  758 */     Assert.isInstanceOf(AbstractApplicationContext.class, applicationContext);
/*  759 */     ((AbstractApplicationContext)applicationContext).refresh();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void afterRefresh(ConfigurableApplicationContext context, ApplicationArguments args)
/*      */   {
/*  769 */     callRunners(context, args);
/*      */   }
/*      */   
/*      */   private void callRunners(ApplicationContext context, ApplicationArguments args) {
/*  773 */     List<Object> runners = new ArrayList();
/*  774 */     runners.addAll(context.getBeansOfType(ApplicationRunner.class).values());
/*  775 */     runners.addAll(context.getBeansOfType(CommandLineRunner.class).values());
/*  776 */     AnnotationAwareOrderComparator.sort(runners);
/*  777 */     for (Object runner : new LinkedHashSet(runners)) {
/*  778 */       if ((runner instanceof ApplicationRunner)) {
/*  779 */         callRunner((ApplicationRunner)runner, args);
/*      */       }
/*  781 */       if ((runner instanceof CommandLineRunner)) {
/*  782 */         callRunner((CommandLineRunner)runner, args);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void callRunner(ApplicationRunner runner, ApplicationArguments args) {
/*      */     try {
/*  789 */       runner.run(args);
/*      */     }
/*      */     catch (Exception ex) {
/*  792 */       throw new IllegalStateException("Failed to execute ApplicationRunner", ex);
/*      */     }
/*      */   }
/*      */   
/*      */   private void callRunner(CommandLineRunner runner, ApplicationArguments args) {
/*      */     try {
/*  798 */       runner.run(args.getSourceArgs());
/*      */     }
/*      */     catch (Exception ex) {
/*  801 */       throw new IllegalStateException("Failed to execute CommandLineRunner", ex);
/*      */     }
/*      */   }
/*      */   
/*      */   private void handleRunFailure(ConfigurableApplicationContext context, SpringApplicationRunListeners listeners, Throwable exception)
/*      */   {
/*      */     try {
/*      */       try {
/*  809 */         handleExitCode(context, exception);
/*  810 */         listeners.finished(context, exception);
/*      */       }
/*      */       finally {
/*  813 */         reportFailure(exception, context);
/*  814 */         if (context != null) {
/*  815 */           context.close();
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception ex) {
/*  820 */       logger.warn("Unable to close ApplicationContext", ex);
/*      */     }
/*  822 */     ReflectionUtils.rethrowRuntimeException(exception);
/*      */   }
/*      */   
/*      */   private void reportFailure(Throwable failure, ConfigurableApplicationContext context)
/*      */   {
/*      */     try {
/*  828 */       if (FailureAnalyzers.analyzeAndReport(failure, getClass().getClassLoader(), context))
/*      */       {
/*  830 */         registerLoggedException(failure);
/*  831 */         return;
/*      */       }
/*      */     }
/*      */     catch (Throwable localThrowable) {}
/*      */     
/*      */ 
/*  837 */     if (logger.isErrorEnabled()) {
/*  838 */       logger.error("Application startup failed", failure);
/*  839 */       registerLoggedException(failure);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void registerLoggedException(Throwable exception)
/*      */   {
/*  849 */     SpringBootExceptionHandler handler = getSpringBootExceptionHandler();
/*  850 */     if (handler != null) {
/*  851 */       handler.registerLoggedException(exception);
/*      */     }
/*      */   }
/*      */   
/*      */   private void handleExitCode(ConfigurableApplicationContext context, Throwable exception)
/*      */   {
/*  857 */     int exitCode = getExitCodeFromException(context, exception);
/*  858 */     if (exitCode != 0) {
/*  859 */       if (context != null) {
/*  860 */         context.publishEvent(new ExitCodeEvent(context, exitCode));
/*      */       }
/*  862 */       SpringBootExceptionHandler handler = getSpringBootExceptionHandler();
/*  863 */       if (handler != null) {
/*  864 */         handler.registerExitCode(exitCode);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private int getExitCodeFromException(ConfigurableApplicationContext context, Throwable exception)
/*      */   {
/*  871 */     int exitCode = getExitCodeFromMappedException(context, exception);
/*  872 */     if (exitCode == 0) {
/*  873 */       exitCode = getExitCodeFromExitCodeGeneratorException(exception);
/*      */     }
/*  875 */     return exitCode;
/*      */   }
/*      */   
/*      */   private int getExitCodeFromMappedException(ConfigurableApplicationContext context, Throwable exception)
/*      */   {
/*  880 */     if ((context == null) || (!context.isActive())) {
/*  881 */       return 0;
/*      */     }
/*  883 */     ExitCodeGenerators generators = new ExitCodeGenerators();
/*      */     
/*  885 */     Collection<ExitCodeExceptionMapper> beans = context.getBeansOfType(ExitCodeExceptionMapper.class).values();
/*  886 */     generators.addAll(exception, beans);
/*  887 */     return generators.getExitCode();
/*      */   }
/*      */   
/*      */   private int getExitCodeFromExitCodeGeneratorException(Throwable exception) {
/*  891 */     if (exception == null) {
/*  892 */       return 0;
/*      */     }
/*  894 */     if ((exception instanceof ExitCodeGenerator)) {
/*  895 */       return ((ExitCodeGenerator)exception).getExitCode();
/*      */     }
/*  897 */     return getExitCodeFromExitCodeGeneratorException(exception.getCause());
/*      */   }
/*      */   
/*      */   SpringBootExceptionHandler getSpringBootExceptionHandler() {
/*  901 */     if (isMainThread(Thread.currentThread())) {
/*  902 */       return SpringBootExceptionHandler.forCurrentThread();
/*      */     }
/*  904 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean isMainThread(Thread currentThread)
/*      */   {
/*  910 */     return (("main".equals(currentThread.getName())) || ("restartedMain".equals(currentThread.getName()))) && ("main".equals(currentThread.getThreadGroup().getName()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Class<?> getMainApplicationClass()
/*      */   {
/*  918 */     return this.mainApplicationClass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMainApplicationClass(Class<?> mainApplicationClass)
/*      */   {
/*  928 */     this.mainApplicationClass = mainApplicationClass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isWebEnvironment()
/*      */   {
/*  937 */     return this.webEnvironment;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWebEnvironment(boolean webEnvironment)
/*      */   {
/*  946 */     this.webEnvironment = webEnvironment;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHeadless(boolean headless)
/*      */   {
/*  955 */     this.headless = headless;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRegisterShutdownHook(boolean registerShutdownHook)
/*      */   {
/*  965 */     this.registerShutdownHook = registerShutdownHook;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBanner(Banner banner)
/*      */   {
/*  974 */     this.banner = banner;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBannerMode(Banner.Mode bannerMode)
/*      */   {
/*  983 */     this.bannerMode = bannerMode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLogStartupInfo(boolean logStartupInfo)
/*      */   {
/*  992 */     this.logStartupInfo = logStartupInfo;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAddCommandLineProperties(boolean addCommandLineProperties)
/*      */   {
/* 1001 */     this.addCommandLineProperties = addCommandLineProperties;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDefaultProperties(Map<String, Object> defaultProperties)
/*      */   {
/* 1010 */     this.defaultProperties = defaultProperties;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDefaultProperties(Properties defaultProperties)
/*      */   {
/* 1018 */     this.defaultProperties = new HashMap();
/* 1019 */     for (Object key : Collections.list(defaultProperties.propertyNames())) {
/* 1020 */       this.defaultProperties.put((String)key, defaultProperties.get(key));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAdditionalProfiles(String... profiles)
/*      */   {
/* 1030 */     this.additionalProfiles = new LinkedHashSet(Arrays.asList(profiles));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBeanNameGenerator(BeanNameGenerator beanNameGenerator)
/*      */   {
/* 1038 */     this.beanNameGenerator = beanNameGenerator;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEnvironment(ConfigurableEnvironment environment)
/*      */   {
/* 1047 */     this.environment = environment;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<Object> getSources()
/*      */   {
/* 1057 */     return this.sources;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSources(Set<Object> sources)
/*      */   {
/* 1072 */     Assert.notNull(sources, "Sources must not be null");
/* 1073 */     this.sources.addAll(sources);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setResourceLoader(ResourceLoader resourceLoader)
/*      */   {
/* 1081 */     Assert.notNull(resourceLoader, "ResourceLoader must not be null");
/* 1082 */     this.resourceLoader = resourceLoader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setApplicationContextClass(Class<? extends ConfigurableApplicationContext> applicationContextClass)
/*      */   {
/* 1093 */     this.applicationContextClass = applicationContextClass;
/* 1094 */     if (!isWebApplicationContext(applicationContextClass)) {
/* 1095 */       this.webEnvironment = false;
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean isWebApplicationContext(Class<?> applicationContextClass) {
/*      */     try {
/* 1101 */       return WebApplicationContext.class.isAssignableFrom(applicationContextClass);
/*      */     }
/*      */     catch (NoClassDefFoundError ex) {}
/* 1104 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInitializers(Collection<? extends ApplicationContextInitializer<?>> initializers)
/*      */   {
/* 1115 */     this.initializers = new ArrayList();
/* 1116 */     this.initializers.addAll(initializers);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addInitializers(ApplicationContextInitializer<?>... initializers)
/*      */   {
/* 1125 */     this.initializers.addAll(Arrays.asList(initializers));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<ApplicationContextInitializer<?>> getInitializers()
/*      */   {
/* 1134 */     return asUnmodifiableOrderedSet(this.initializers);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setListeners(Collection<? extends ApplicationListener<?>> listeners)
/*      */   {
/* 1143 */     this.listeners = new ArrayList();
/* 1144 */     this.listeners.addAll(listeners);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addListeners(ApplicationListener<?>... listeners)
/*      */   {
/* 1153 */     this.listeners.addAll(Arrays.asList(listeners));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<ApplicationListener<?>> getListeners()
/*      */   {
/* 1163 */     return asUnmodifiableOrderedSet(this.listeners);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ConfigurableApplicationContext run(Object source, String... args)
/*      */   {
/* 1174 */     return run(new Object[] { source }, args);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ConfigurableApplicationContext run(Object[] sources, String[] args)
/*      */   {
/* 1185 */     return new SpringApplication(sources).run(args);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void main(String[] args)
/*      */     throws Exception
/*      */   {
/* 1201 */     run(new Object[0], args);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int exit(ApplicationContext context, ExitCodeGenerator... exitCodeGenerators)
/*      */   {
/* 1217 */     Assert.notNull(context, "Context must not be null");
/* 1218 */     int exitCode = 0;
/*      */     try {
/*      */       try {
/* 1221 */         ExitCodeGenerators generators = new ExitCodeGenerators();
/*      */         
/* 1223 */         Collection<ExitCodeGenerator> beans = context.getBeansOfType(ExitCodeGenerator.class).values();
/* 1224 */         generators.addAll(exitCodeGenerators);
/* 1225 */         generators.addAll(beans);
/* 1226 */         exitCode = generators.getExitCode();
/* 1227 */         if (exitCode != 0) {
/* 1228 */           context.publishEvent(new ExitCodeEvent(context, exitCode));
/*      */         }
/*      */       }
/*      */       finally {
/* 1232 */         close(context);
/*      */       }
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/* 1237 */       ex.printStackTrace();
/* 1238 */       exitCode = exitCode == 0 ? 1 : exitCode;
/*      */     }
/* 1240 */     return exitCode;
/*      */   }
/*      */   
/*      */   private static void close(ApplicationContext context) {
/* 1244 */     if ((context instanceof ConfigurableApplicationContext)) {
/* 1245 */       ConfigurableApplicationContext closable = (ConfigurableApplicationContext)context;
/* 1246 */       closable.close();
/*      */     }
/*      */   }
/*      */   
/*      */   private static <E> Set<E> asUnmodifiableOrderedSet(Collection<E> elements) {
/* 1251 */     List<E> list = new ArrayList();
/* 1252 */     list.addAll(elements);
/* 1253 */     Collections.sort(list, AnnotationAwareOrderComparator.INSTANCE);
/* 1254 */     return new LinkedHashSet(list);
/*      */   }
/*      */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\SpringApplication.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */