/*     */ package org.springframework.boot.orm.jpa;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.orm.jpa.JpaVendorAdapter;
/*     */ import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
/*     */ import org.springframework.orm.jpa.persistenceunit.PersistenceUnitManager;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityManagerFactoryBuilder
/*     */ {
/*     */   private JpaVendorAdapter jpaVendorAdapter;
/*     */   private PersistenceUnitManager persistenceUnitManager;
/*     */   private Map<String, Object> jpaProperties;
/*     */   private EntityManagerFactoryBeanCallback callback;
/*     */   
/*     */   public EntityManagerFactoryBuilder(JpaVendorAdapter jpaVendorAdapter, Map<String, ?> jpaProperties, PersistenceUnitManager persistenceUnitManager)
/*     */   {
/*  64 */     this.jpaVendorAdapter = jpaVendorAdapter;
/*  65 */     this.persistenceUnitManager = persistenceUnitManager;
/*  66 */     this.jpaProperties = new LinkedHashMap(jpaProperties);
/*     */   }
/*     */   
/*     */   public Builder dataSource(DataSource dataSource) {
/*  70 */     return new Builder(dataSource, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCallback(EntityManagerFactoryBeanCallback callback)
/*     */   {
/*  78 */     this.callback = callback;
/*     */   }
/*     */   
/*     */ 
/*     */   public static abstract interface EntityManagerFactoryBeanCallback
/*     */   {
/*     */     public abstract void execute(LocalContainerEntityManagerFactoryBean paramLocalContainerEntityManagerFactoryBean);
/*     */   }
/*     */   
/*     */   public final class Builder
/*     */   {
/*     */     private DataSource dataSource;
/*     */     private String[] packagesToScan;
/*     */     private String persistenceUnit;
/*  92 */     private Map<String, Object> properties = new HashMap();
/*     */     private boolean jta;
/*     */     
/*     */     private Builder(DataSource dataSource)
/*     */     {
/*  97 */       this.dataSource = dataSource;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Builder packages(String... packagesToScan)
/*     */     {
/* 106 */       this.packagesToScan = packagesToScan;
/* 107 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Builder packages(Class<?>... basePackageClasses)
/*     */     {
/* 116 */       Set<String> packages = new HashSet();
/* 117 */       for (Class<?> type : basePackageClasses) {
/* 118 */         packages.add(ClassUtils.getPackageName(type));
/*     */       }
/* 120 */       this.packagesToScan = ((String[])packages.toArray(new String[0]));
/* 121 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Builder persistenceUnit(String persistenceUnit)
/*     */     {
/* 132 */       this.persistenceUnit = persistenceUnit;
/* 133 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Builder properties(Map<String, ?> properties)
/*     */     {
/* 143 */       this.properties.putAll(properties);
/* 144 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Builder jta(boolean jta)
/*     */     {
/* 158 */       this.jta = jta;
/* 159 */       return this;
/*     */     }
/*     */     
/*     */     public LocalContainerEntityManagerFactoryBean build() {
/* 163 */       LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
/* 164 */       if (EntityManagerFactoryBuilder.this.persistenceUnitManager != null) {
/* 165 */         entityManagerFactoryBean.setPersistenceUnitManager(
/* 166 */           EntityManagerFactoryBuilder.this.persistenceUnitManager);
/*     */       }
/* 168 */       if (this.persistenceUnit != null) {
/* 169 */         entityManagerFactoryBean.setPersistenceUnitName(this.persistenceUnit);
/*     */       }
/* 171 */       entityManagerFactoryBean.setJpaVendorAdapter(
/* 172 */         EntityManagerFactoryBuilder.this.jpaVendorAdapter);
/*     */       
/* 174 */       if (this.jta) {
/* 175 */         entityManagerFactoryBean.setJtaDataSource(this.dataSource);
/*     */       }
/*     */       else {
/* 178 */         entityManagerFactoryBean.setDataSource(this.dataSource);
/*     */       }
/* 180 */       entityManagerFactoryBean.setPackagesToScan(this.packagesToScan);
/* 181 */       entityManagerFactoryBean.getJpaPropertyMap()
/* 182 */         .putAll(EntityManagerFactoryBuilder.this.jpaProperties);
/* 183 */       entityManagerFactoryBean.getJpaPropertyMap().putAll(this.properties);
/* 184 */       if (EntityManagerFactoryBuilder.this.callback != null)
/*     */       {
/* 186 */         EntityManagerFactoryBuilder.this.callback.execute(entityManagerFactoryBean);
/*     */       }
/* 188 */       return entityManagerFactoryBean;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\orm\jpa\EntityManagerFactoryBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */