/*     */ package org.springframework.boot.orm.jpa;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.SmartInitializingSingleton;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues.ValueHolder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*     */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ class EntityScanRegistrar
/*     */   implements ImportBeanDefinitionRegistrar
/*     */ {
/*     */   private static final String BEAN_NAME = "entityScanBeanPostProcessor";
/*     */   
/*     */   public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry)
/*     */   {
/*  54 */     Set<String> packagesToScan = getPackagesToScan(importingClassMetadata);
/*  55 */     if (!registry.containsBeanDefinition("entityScanBeanPostProcessor")) {
/*  56 */       addEntityScanBeanPostProcessor(registry, packagesToScan);
/*     */     }
/*     */     else {
/*  59 */       updateEntityScanBeanPostProcessor(registry, packagesToScan);
/*     */     }
/*     */   }
/*     */   
/*     */   private Set<String> getPackagesToScan(AnnotationMetadata metadata)
/*     */   {
/*  65 */     AnnotationAttributes attributes = AnnotationAttributes.fromMap(metadata.getAnnotationAttributes(EntityScan.class.getName()));
/*  66 */     String[] basePackages = attributes.getAliasedStringArray("basePackages", EntityScan.class, metadata
/*  67 */       .getClassName());
/*  68 */     Class<?>[] basePackageClasses = attributes.getClassArray("basePackageClasses");
/*  69 */     Set<String> packagesToScan = new LinkedHashSet();
/*  70 */     packagesToScan.addAll(Arrays.asList(basePackages));
/*  71 */     for (Class<?> basePackageClass : basePackageClasses) {
/*  72 */       packagesToScan.add(ClassUtils.getPackageName(basePackageClass));
/*     */     }
/*  74 */     if (packagesToScan.isEmpty())
/*     */     {
/*  76 */       return Collections.singleton(ClassUtils.getPackageName(metadata.getClassName()));
/*     */     }
/*  78 */     return packagesToScan;
/*     */   }
/*     */   
/*     */   private void addEntityScanBeanPostProcessor(BeanDefinitionRegistry registry, Set<String> packagesToScan)
/*     */   {
/*  83 */     GenericBeanDefinition beanDefinition = new GenericBeanDefinition();
/*  84 */     beanDefinition.setBeanClass(EntityScanBeanPostProcessor.class);
/*  85 */     beanDefinition.getConstructorArgumentValues()
/*  86 */       .addGenericArgumentValue(toArray(packagesToScan));
/*  87 */     beanDefinition.setRole(2);
/*     */     
/*     */ 
/*  90 */     beanDefinition.setSynthetic(true);
/*  91 */     registry.registerBeanDefinition("entityScanBeanPostProcessor", beanDefinition);
/*     */   }
/*     */   
/*     */   private void updateEntityScanBeanPostProcessor(BeanDefinitionRegistry registry, Set<String> packagesToScan)
/*     */   {
/*  96 */     BeanDefinition definition = registry.getBeanDefinition("entityScanBeanPostProcessor");
/*     */     
/*  98 */     ConstructorArgumentValues.ValueHolder constructorArguments = definition.getConstructorArgumentValues().getGenericArgumentValue(String[].class);
/*  99 */     Set<String> mergedPackages = new LinkedHashSet();
/* 100 */     mergedPackages.addAll(Arrays.asList((String[])constructorArguments.getValue()));
/* 101 */     mergedPackages.addAll(packagesToScan);
/* 102 */     constructorArguments.setValue(toArray(mergedPackages));
/*     */   }
/*     */   
/*     */   private String[] toArray(Set<String> set) {
/* 106 */     return (String[])set.toArray(new String[set.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static class EntityScanBeanPostProcessor
/*     */     implements BeanPostProcessor, SmartInitializingSingleton, Ordered
/*     */   {
/*     */     private final String[] packagesToScan;
/*     */     
/*     */ 
/*     */     private boolean processed;
/*     */     
/*     */ 
/*     */     EntityScanBeanPostProcessor(String[] packagesToScan)
/*     */     {
/* 122 */       this.packagesToScan = packagesToScan;
/*     */     }
/*     */     
/*     */     public Object postProcessBeforeInitialization(Object bean, String beanName)
/*     */       throws BeansException
/*     */     {
/* 128 */       if ((bean instanceof LocalContainerEntityManagerFactoryBean)) {
/* 129 */         LocalContainerEntityManagerFactoryBean factoryBean = (LocalContainerEntityManagerFactoryBean)bean;
/* 130 */         factoryBean.setPackagesToScan(this.packagesToScan);
/* 131 */         this.processed = true;
/*     */       }
/* 133 */       return bean;
/*     */     }
/*     */     
/*     */     public Object postProcessAfterInitialization(Object bean, String beanName)
/*     */       throws BeansException
/*     */     {
/* 139 */       return bean;
/*     */     }
/*     */     
/*     */     public void afterSingletonsInstantiated()
/*     */     {
/* 144 */       Assert.state(this.processed, "Unable to configure LocalContainerEntityManagerFactoryBean from @EntityScan, ensure an appropriate bean is registered.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getOrder()
/*     */     {
/* 152 */       return 0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\orm\jpa\EntityScanRegistrar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */