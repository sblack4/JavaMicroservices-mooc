/*    */ package org.springframework.boot.orm.jpa.hibernate;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.hibernate.boot.model.naming.Identifier;
/*    */ import org.hibernate.boot.model.naming.PhysicalNamingStrategy;
/*    */ import org.hibernate.engine.jdbc.env.spi.JdbcEnvironment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpringPhysicalNamingStrategy
/*    */   implements PhysicalNamingStrategy
/*    */ {
/*    */   public Identifier toPhysicalCatalogName(Identifier name, JdbcEnvironment jdbcEnvironment)
/*    */   {
/* 37 */     return apply(name);
/*    */   }
/*    */   
/*    */ 
/*    */   public Identifier toPhysicalSchemaName(Identifier name, JdbcEnvironment jdbcEnvironment)
/*    */   {
/* 43 */     return apply(name);
/*    */   }
/*    */   
/*    */ 
/*    */   public Identifier toPhysicalTableName(Identifier name, JdbcEnvironment jdbcEnvironment)
/*    */   {
/* 49 */     return apply(name);
/*    */   }
/*    */   
/*    */ 
/*    */   public Identifier toPhysicalSequenceName(Identifier name, JdbcEnvironment jdbcEnvironment)
/*    */   {
/* 55 */     return apply(name);
/*    */   }
/*    */   
/*    */ 
/*    */   public Identifier toPhysicalColumnName(Identifier name, JdbcEnvironment jdbcEnvironment)
/*    */   {
/* 61 */     return apply(name);
/*    */   }
/*    */   
/*    */   private Identifier apply(Identifier name) {
/* 65 */     if (name == null) {
/* 66 */       return null;
/*    */     }
/* 68 */     StringBuilder text = new StringBuilder(name.getText().replace('.', '_'));
/* 69 */     for (int i = 1; i < text.length() - 1; i++) {
/* 70 */       if (isUnderscoreRequired(text.charAt(i - 1), text.charAt(i), text.charAt(i + 1))) {
/* 71 */         text.insert(i++, '_');
/*    */       }
/*    */     }
/* 74 */     return new Identifier(text.toString().toLowerCase(Locale.ROOT), name.isQuoted());
/*    */   }
/*    */   
/*    */   private boolean isUnderscoreRequired(char before, char current, char after)
/*    */   {
/* 79 */     return (Character.isLowerCase(before)) && (Character.isUpperCase(current)) && (Character.isLowerCase(after));
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\orm\jpa\hibernate\SpringPhysicalNamingStrategy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */