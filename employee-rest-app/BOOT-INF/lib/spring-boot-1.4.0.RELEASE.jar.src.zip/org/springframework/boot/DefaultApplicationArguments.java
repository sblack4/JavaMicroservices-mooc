/*    */ package org.springframework.boot;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.env.SimpleCommandLinePropertySource;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DefaultApplicationArguments
/*    */   implements ApplicationArguments
/*    */ {
/*    */   private final Source source;
/*    */   private final String[] args;
/*    */   
/*    */   DefaultApplicationArguments(String[] args)
/*    */   {
/* 40 */     Assert.notNull(args, "Args must not be null");
/* 41 */     this.source = new Source(args);
/* 42 */     this.args = args;
/*    */   }
/*    */   
/*    */   public String[] getSourceArgs()
/*    */   {
/* 47 */     return this.args;
/*    */   }
/*    */   
/*    */   public Set<String> getOptionNames()
/*    */   {
/* 52 */     String[] names = this.source.getPropertyNames();
/* 53 */     return Collections.unmodifiableSet(new HashSet(Arrays.asList(names)));
/*    */   }
/*    */   
/*    */   public boolean containsOption(String name)
/*    */   {
/* 58 */     return this.source.containsProperty(name);
/*    */   }
/*    */   
/*    */   public List<String> getOptionValues(String name)
/*    */   {
/* 63 */     List<String> values = this.source.getOptionValues(name);
/* 64 */     return values == null ? null : Collections.unmodifiableList(values);
/*    */   }
/*    */   
/*    */   public List<String> getNonOptionArgs()
/*    */   {
/* 69 */     return this.source.getNonOptionArgs();
/*    */   }
/*    */   
/*    */   private static class Source extends SimpleCommandLinePropertySource
/*    */   {
/*    */     Source(String[] args) {
/* 75 */       super();
/*    */     }
/*    */     
/*    */     public List<String> getNonOptionArgs()
/*    */     {
/* 80 */       return super.getNonOptionArgs();
/*    */     }
/*    */     
/*    */     public List<String> getOptionValues(String name)
/*    */     {
/* 85 */       return super.getOptionValues(name);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\DefaultApplicationArguments.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */