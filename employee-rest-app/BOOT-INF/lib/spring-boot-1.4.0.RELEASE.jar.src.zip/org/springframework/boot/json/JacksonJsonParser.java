/*    */ package org.springframework.boot.json;
/*    */ 
/*    */ import com.fasterxml.jackson.core.type.TypeReference;
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JacksonJsonParser
/*    */   implements JsonParser
/*    */ {
/* 33 */   private static final TypeReference<?> MAP_TYPE = new MapTypeReference(null);
/*    */   
/* 35 */   private static final TypeReference<?> LIST_TYPE = new ListTypeReference(null);
/*    */   
/* 37 */   private final ObjectMapper objectMapper = new ObjectMapper();
/*    */   
/*    */   public Map<String, Object> parseMap(String json)
/*    */   {
/*    */     try {
/* 42 */       return (Map)this.objectMapper.readValue(json, MAP_TYPE);
/*    */     }
/*    */     catch (Exception ex) {
/* 45 */       throw new IllegalArgumentException("Cannot parse JSON", ex);
/*    */     }
/*    */   }
/*    */   
/*    */   public List<Object> parseList(String json)
/*    */   {
/*    */     try {
/* 52 */       return (List)this.objectMapper.readValue(json, LIST_TYPE);
/*    */     }
/*    */     catch (Exception ex) {
/* 55 */       throw new IllegalArgumentException("Cannot parse JSON", ex);
/*    */     }
/*    */   }
/*    */   
/*    */   private static class ListTypeReference
/*    */     extends TypeReference<List<Object>>
/*    */   {}
/*    */   
/*    */   private static class MapTypeReference
/*    */     extends TypeReference<Map<String, Object>>
/*    */   {}
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-boot-1.4.0.RELEASE.jar!\org\springframework\boot\json\JacksonJsonParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */