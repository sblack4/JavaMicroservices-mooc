/*    */ package com.fasterxml.jackson.databind.deser.impl;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonProcessingException;
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class NullProvider
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final Object _nullValue;
/*    */   private final boolean _isPrimitive;
/*    */   private final Class<?> _rawType;
/*    */   
/*    */   public NullProvider(JavaType type, Object nullValue)
/*    */   {
/* 25 */     this._nullValue = nullValue;
/* 26 */     this._isPrimitive = type.isPrimitive();
/* 27 */     this._rawType = type.getRawClass();
/*    */   }
/*    */   
/*    */   public Object nullValue(DeserializationContext ctxt) throws JsonProcessingException
/*    */   {
/* 32 */     if ((this._isPrimitive) && (ctxt.isEnabled(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES))) {
/* 33 */       ctxt.reportMappingException("Can not map JSON null into type %s (set DeserializationConfig.DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES to 'false' to allow)", new Object[] { this._rawType.getName() });
/*    */     }
/*    */     
/* 36 */     return this._nullValue;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\jackson-databind-2.8.1.jar!\com\fasterxml\jackson\databind\deser\impl\NullProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */