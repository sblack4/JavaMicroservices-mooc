/*    */ package com.fasterxml.jackson.databind.ser.std;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.JsonMappingException;
/*    */ import com.fasterxml.jackson.databind.JsonNode;
/*    */ import com.fasterxml.jackson.databind.SerializationFeature;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class StdKeySerializer
/*    */   extends StdSerializer<Object>
/*    */ {
/*    */   public StdKeySerializer()
/*    */   {
/* 22 */     super(Object.class);
/*    */   }
/*    */   
/*    */   public void serialize(Object value, JsonGenerator g, SerializerProvider provider) throws IOException
/*    */   {
/* 27 */     Class<?> cls = value.getClass();
/*    */     String str;
/* 29 */     String str; if (cls == String.class) {
/* 30 */       str = (String)value; } else { String str;
/* 31 */       if (cls.isEnum())
/*    */       {
/*    */ 
/* 34 */         Enum<?> en = (Enum)value;
/*    */         String str;
/* 36 */         if (provider.isEnabled(SerializationFeature.WRITE_ENUMS_USING_TO_STRING)) {
/* 37 */           str = en.toString();
/*    */         } else
/* 39 */           str = en.name();
/*    */       } else {
/* 41 */         if ((value instanceof Date)) {
/* 42 */           provider.defaultSerializeDateKey((Date)value, g); return; }
/*    */         String str;
/* 44 */         if (cls == Class.class) {
/* 45 */           str = ((Class)value).getName();
/*    */         } else
/* 47 */           str = value.toString();
/*    */       } }
/* 49 */     g.writeFieldName(str);
/*    */   }
/*    */   
/*    */   public JsonNode getSchema(SerializerProvider provider, Type typeHint) throws JsonMappingException
/*    */   {
/* 54 */     return createSchemaNode("string");
/*    */   }
/*    */   
/*    */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException
/*    */   {
/* 59 */     visitStringFormat(visitor, typeHint);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\jackson-databind-2.8.1.jar!\com\fasterxml\jackson\databind\ser\std\StdKeySerializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */