package com.fasterxml.jackson.databind.introspect;

public abstract interface WithMember<T>
{
  public abstract T withMember(AnnotatedMember paramAnnotatedMember);
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\jackson-databind-2.8.1.jar!\com\fasterxml\jackson\databind\introspect\WithMember.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */