/*    */ package org.jboss.logging;
/*    */ 
/*    */ import org.apache.logging.log4j.Level;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.LoggingException;
/*    */ import org.apache.logging.log4j.message.MessageFormatMessageFactory;
/*    */ import org.apache.logging.log4j.message.StringFormattedMessage;
/*    */ import org.apache.logging.log4j.spi.AbstractLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Log4j2Logger
/*    */   extends Logger
/*    */ {
/*    */   private static final long serialVersionUID = -2507841068232627725L;
/*    */   private final AbstractLogger logger;
/*    */   private final MessageFormatMessageFactory messageFactory;
/*    */   
/*    */   Log4j2Logger(String name)
/*    */   {
/* 35 */     super(name);
/* 36 */     org.apache.logging.log4j.Logger logger = LogManager.getLogger(name);
/* 37 */     if (!(logger instanceof AbstractLogger)) {
/* 38 */       throw new LoggingException("The logger for [" + name + "] does not extend AbstractLogger. Actual logger: " + logger.getClass().getName());
/*    */     }
/* 40 */     this.logger = ((AbstractLogger)logger);
/* 41 */     this.messageFactory = new MessageFormatMessageFactory();
/*    */   }
/*    */   
/*    */   public boolean isEnabled(Logger.Level level)
/*    */   {
/* 46 */     return this.logger.isEnabled(translate(level));
/*    */   }
/*    */   
/*    */   protected void doLog(Logger.Level level, String loggerClassName, Object message, Object[] parameters, Throwable thrown)
/*    */   {
/* 51 */     Level translatedLevel = translate(level);
/* 52 */     if (this.logger.isEnabled(translatedLevel)) {
/*    */       try {
/* 54 */         this.logger.logMessage(loggerClassName, translatedLevel, null, (parameters == null) || (parameters.length == 0) ? this.messageFactory
/* 55 */           .newMessage(message) : this.messageFactory.newMessage(String.valueOf(message), parameters), thrown);
/*    */       }
/*    */       catch (Throwable localThrowable) {}
/*    */     }
/*    */   }
/*    */   
/*    */   protected void doLogf(Logger.Level level, String loggerClassName, String format, Object[] parameters, Throwable thrown)
/*    */   {
/* 63 */     Level translatedLevel = translate(level);
/* 64 */     if (this.logger.isEnabled(translatedLevel)) {
/*    */       try {
/* 66 */         this.logger.logMessage(loggerClassName, translatedLevel, null, new StringFormattedMessage(format, parameters), thrown);
/*    */       } catch (Throwable localThrowable) {}
/*    */     }
/*    */   }
/*    */   
/*    */   private static Level translate(Logger.Level level) {
/* 72 */     if (level != null) {
/* 73 */       switch (level) {
/* 74 */       case FATAL:  return Level.FATAL;
/* 75 */       case ERROR:  return Level.ERROR;
/* 76 */       case WARN:  return Level.WARN;
/* 77 */       case INFO:  return Level.INFO;
/* 78 */       case DEBUG:  return Level.DEBUG;
/* 79 */       case TRACE:  return Level.TRACE;
/*    */       }
/*    */     }
/* 82 */     return Level.ALL;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\jboss-logging-3.3.0.Final.jar!\org\jboss\logging\Log4j2Logger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */