/*    */ package org.jboss.logging;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import org.apache.log4j.Level;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Log4jLogger
/*    */   extends Logger
/*    */ {
/*    */   private static final long serialVersionUID = -5446154366955151335L;
/*    */   private final org.apache.log4j.Logger logger;
/*    */   
/*    */   Log4jLogger(String name)
/*    */   {
/* 30 */     super(name);
/* 31 */     this.logger = org.apache.log4j.Logger.getLogger(name);
/*    */   }
/*    */   
/*    */   public boolean isEnabled(Logger.Level level) {
/* 35 */     Level l = translate(level);
/* 36 */     return (this.logger.isEnabledFor(l)) && (l.isGreaterOrEqual(this.logger.getEffectiveLevel()));
/*    */   }
/*    */   
/*    */   protected void doLog(Logger.Level level, String loggerClassName, Object message, Object[] parameters, Throwable thrown) {
/* 40 */     Level translatedLevel = translate(level);
/* 41 */     if (this.logger.isEnabledFor(translatedLevel))
/* 42 */       try { this.logger.log(loggerClassName, translatedLevel, (parameters == null) || (parameters.length == 0) ? message : MessageFormat.format(String.valueOf(message), parameters), thrown);
/*    */       } catch (Throwable localThrowable) {}
/*    */   }
/*    */   
/*    */   protected void doLogf(Logger.Level level, String loggerClassName, String format, Object[] parameters, Throwable thrown) {
/* 47 */     Level translatedLevel = translate(level);
/* 48 */     if (this.logger.isEnabledFor(translatedLevel))
/* 49 */       try { this.logger.log(loggerClassName, translatedLevel, parameters == null ? String.format(format, new Object[0]) : String.format(format, parameters), thrown);
/*    */       } catch (Throwable localThrowable) {}
/*    */   }
/*    */   
/*    */   private static Level translate(Logger.Level level) {
/* 54 */     if (level != null) switch (level) {
/* 55 */       case FATAL:  return Level.FATAL;
/* 56 */       case ERROR:  return Level.ERROR;
/* 57 */       case WARN:  return Level.WARN;
/* 58 */       case INFO:  return Level.INFO;
/* 59 */       case DEBUG:  return Level.DEBUG;
/* 60 */       case TRACE:  return Level.TRACE;
/*    */       }
/* 62 */     return Level.ALL;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\jboss-logging-3.3.0.Final.jar!\org\jboss\logging\Log4jLogger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */