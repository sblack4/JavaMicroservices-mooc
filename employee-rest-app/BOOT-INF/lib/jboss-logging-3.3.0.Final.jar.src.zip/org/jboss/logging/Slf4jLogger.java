/*    */ package org.jboss.logging;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Slf4jLogger
/*    */   extends Logger
/*    */ {
/*    */   private static final long serialVersionUID = 8685757928087758380L;
/*    */   private final org.slf4j.Logger logger;
/*    */   
/*    */   Slf4jLogger(String name, org.slf4j.Logger logger)
/*    */   {
/* 30 */     super(name);
/* 31 */     this.logger = logger;
/*    */   }
/*    */   
/*    */   public boolean isEnabled(Logger.Level level) {
/* 35 */     if (level != null) switch (level) {
/* 36 */       case FATAL:  return this.logger.isErrorEnabled();
/* 37 */       case ERROR:  return this.logger.isErrorEnabled();
/* 38 */       case WARN:  return this.logger.isWarnEnabled();
/* 39 */       case INFO:  return this.logger.isInfoEnabled();
/* 40 */       case DEBUG:  return this.logger.isDebugEnabled();
/* 41 */       case TRACE:  return this.logger.isTraceEnabled();
/*    */       }
/* 43 */     return true;
/*    */   }
/*    */   
/*    */   protected void doLog(Logger.Level level, String loggerClassName, Object message, Object[] parameters, Throwable thrown) {
/* 47 */     if (isEnabled(level))
/* 48 */       try { String text = (parameters == null) || (parameters.length == 0) ? String.valueOf(message) : MessageFormat.format(String.valueOf(message), parameters);
/* 49 */         switch (level) {
/*    */         case FATAL: 
/*    */         case ERROR: 
/* 52 */           this.logger.error(text, thrown);
/* 53 */           return;
/*    */         case WARN: 
/* 55 */           this.logger.warn(text, thrown);
/* 56 */           return;
/*    */         case INFO: 
/* 58 */           this.logger.info(text, thrown);
/* 59 */           return;
/*    */         case DEBUG: 
/* 61 */           this.logger.debug(text, thrown);
/* 62 */           return;
/*    */         case TRACE: 
/* 64 */           this.logger.trace(text, thrown);
/* 65 */           return;
/*    */         }
/*    */       } catch (Throwable localThrowable) {}
/*    */   }
/*    */   
/*    */   protected void doLogf(Logger.Level level, String loggerClassName, String format, Object[] parameters, Throwable thrown) {
/* 71 */     if (isEnabled(level)) {
/* 72 */       try { String text = parameters == null ? String.format(format, new Object[0]) : String.format(format, parameters);
/* 73 */         switch (level) {
/*    */         case FATAL: 
/*    */         case ERROR: 
/* 76 */           this.logger.error(text, thrown);
/* 77 */           return;
/*    */         case WARN: 
/* 79 */           this.logger.warn(text, thrown);
/* 80 */           return;
/*    */         case INFO: 
/* 82 */           this.logger.info(text, thrown);
/* 83 */           return;
/*    */         case DEBUG: 
/* 85 */           this.logger.debug(text, thrown);
/* 86 */           return;
/*    */         case TRACE: 
/* 88 */           this.logger.trace(text, thrown);
/* 89 */           return;
/*    */         }
/*    */       }
/*    */       catch (Throwable localThrowable) {}
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\jboss-logging-3.3.0.Final.jar!\org\jboss\logging\Slf4jLogger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */