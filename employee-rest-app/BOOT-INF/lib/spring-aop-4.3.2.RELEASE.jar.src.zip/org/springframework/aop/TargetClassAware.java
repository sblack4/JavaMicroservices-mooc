package org.springframework.aop;

public abstract interface TargetClassAware
{
  public abstract Class<?> getTargetClass();
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\springframework\aop\TargetClassAware.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */