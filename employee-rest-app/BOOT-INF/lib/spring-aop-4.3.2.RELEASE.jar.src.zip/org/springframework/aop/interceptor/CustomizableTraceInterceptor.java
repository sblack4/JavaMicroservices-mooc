/*     */ package org.springframework.aop.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.Constants;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StopWatch;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CustomizableTraceInterceptor
/*     */   extends AbstractTraceInterceptor
/*     */ {
/*     */   public static final String PLACEHOLDER_METHOD_NAME = "$[methodName]";
/*     */   public static final String PLACEHOLDER_TARGET_CLASS_NAME = "$[targetClassName]";
/*     */   public static final String PLACEHOLDER_TARGET_CLASS_SHORT_NAME = "$[targetClassShortName]";
/*     */   public static final String PLACEHOLDER_RETURN_VALUE = "$[returnValue]";
/*     */   public static final String PLACEHOLDER_ARGUMENT_TYPES = "$[argumentTypes]";
/*     */   public static final String PLACEHOLDER_ARGUMENTS = "$[arguments]";
/*     */   public static final String PLACEHOLDER_EXCEPTION = "$[exception]";
/*     */   public static final String PLACEHOLDER_INVOCATION_TIME = "$[invocationTime]";
/*     */   private static final String DEFAULT_ENTER_MESSAGE = "Entering method '$[methodName]' of class [$[targetClassName]]";
/*     */   private static final String DEFAULT_EXIT_MESSAGE = "Exiting method '$[methodName]' of class [$[targetClassName]]";
/*     */   private static final String DEFAULT_EXCEPTION_MESSAGE = "Exception thrown in method '$[methodName]' of class [$[targetClassName]]";
/* 149 */   private static final Pattern PATTERN = Pattern.compile("\\$\\[\\p{Alpha}+\\]");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 154 */   private static final Set<Object> ALLOWED_PLACEHOLDERS = new Constants(CustomizableTraceInterceptor.class)
/* 155 */     .getValues("PLACEHOLDER_");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 161 */   private String enterMessage = "Entering method '$[methodName]' of class [$[targetClassName]]";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 166 */   private String exitMessage = "Exiting method '$[methodName]' of class [$[targetClassName]]";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 171 */   private String exceptionMessage = "Exception thrown in method '$[methodName]' of class [$[targetClassName]]";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnterMessage(String enterMessage)
/*     */     throws IllegalArgumentException
/*     */   {
/* 185 */     Assert.hasText(enterMessage, "'enterMessage' must not be empty");
/* 186 */     checkForInvalidPlaceholders(enterMessage);
/* 187 */     Assert.doesNotContain(enterMessage, "$[returnValue]", "enterMessage cannot contain placeholder [$[returnValue]]");
/*     */     
/* 189 */     Assert.doesNotContain(enterMessage, "$[exception]", "enterMessage cannot contain placeholder [$[exception]]");
/*     */     
/* 191 */     Assert.doesNotContain(enterMessage, "$[invocationTime]", "enterMessage cannot contain placeholder [$[invocationTime]]");
/*     */     
/* 193 */     this.enterMessage = enterMessage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExitMessage(String exitMessage)
/*     */   {
/* 209 */     Assert.hasText(exitMessage, "'exitMessage' must not be empty");
/* 210 */     checkForInvalidPlaceholders(exitMessage);
/* 211 */     Assert.doesNotContain(exitMessage, "$[exception]", "exitMessage cannot contain placeholder [$[exception]]");
/*     */     
/* 213 */     this.exitMessage = exitMessage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExceptionMessage(String exceptionMessage)
/*     */   {
/* 228 */     Assert.hasText(exceptionMessage, "'exceptionMessage' must not be empty");
/* 229 */     checkForInvalidPlaceholders(exceptionMessage);
/* 230 */     Assert.doesNotContain(exceptionMessage, "$[returnValue]", "exceptionMessage cannot contain placeholder [$[returnValue]]");
/*     */     
/* 232 */     Assert.doesNotContain(exceptionMessage, "$[invocationTime]", "exceptionMessage cannot contain placeholder [$[invocationTime]]");
/*     */     
/* 234 */     this.exceptionMessage = exceptionMessage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object invokeUnderTrace(MethodInvocation invocation, Log logger)
/*     */     throws Throwable
/*     */   {
/* 249 */     String name = invocation.getMethod().getDeclaringClass().getName() + "." + invocation.getMethod().getName();
/* 250 */     StopWatch stopWatch = new StopWatch(name);
/* 251 */     Object returnValue = null;
/* 252 */     boolean exitThroughException = false;
/*     */     try {
/* 254 */       stopWatch.start(name);
/* 255 */       writeToLog(logger, 
/* 256 */         replacePlaceholders(this.enterMessage, invocation, null, null, -1L));
/* 257 */       returnValue = invocation.proceed();
/* 258 */       return returnValue;
/*     */     }
/*     */     catch (Throwable ex) {
/* 261 */       if (stopWatch.isRunning()) {
/* 262 */         stopWatch.stop();
/*     */       }
/* 264 */       exitThroughException = true;
/* 265 */       writeToLog(logger, 
/* 266 */         replacePlaceholders(this.exceptionMessage, invocation, null, ex, stopWatch.getTotalTimeMillis()), ex);
/* 267 */       throw ex;
/*     */     }
/*     */     finally {
/* 270 */       if (!exitThroughException) {
/* 271 */         if (stopWatch.isRunning()) {
/* 272 */           stopWatch.stop();
/*     */         }
/* 274 */         writeToLog(logger, 
/* 275 */           replacePlaceholders(this.exitMessage, invocation, returnValue, null, stopWatch.getTotalTimeMillis()));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeToLog(Log logger, String message)
/*     */   {
/* 285 */     writeToLog(logger, message, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeToLog(Log logger, String message, Throwable ex)
/*     */   {
/* 295 */     if (ex != null) {
/* 296 */       logger.trace(message, ex);
/*     */     }
/*     */     else {
/* 299 */       logger.trace(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String replacePlaceholders(String message, MethodInvocation methodInvocation, Object returnValue, Throwable throwable, long invocationTime)
/*     */   {
/* 322 */     Matcher matcher = PATTERN.matcher(message);
/*     */     
/* 324 */     StringBuffer output = new StringBuffer();
/* 325 */     while (matcher.find()) {
/* 326 */       String match = matcher.group();
/* 327 */       if ("$[methodName]".equals(match)) {
/* 328 */         matcher.appendReplacement(output, Matcher.quoteReplacement(methodInvocation.getMethod().getName()));
/*     */       }
/* 330 */       else if ("$[targetClassName]".equals(match)) {
/* 331 */         String className = getClassForLogging(methodInvocation.getThis()).getName();
/* 332 */         matcher.appendReplacement(output, Matcher.quoteReplacement(className));
/*     */       }
/* 334 */       else if ("$[targetClassShortName]".equals(match)) {
/* 335 */         String shortName = ClassUtils.getShortName(getClassForLogging(methodInvocation.getThis()));
/* 336 */         matcher.appendReplacement(output, Matcher.quoteReplacement(shortName));
/*     */       }
/* 338 */       else if ("$[arguments]".equals(match)) {
/* 339 */         matcher.appendReplacement(output, 
/* 340 */           Matcher.quoteReplacement(StringUtils.arrayToCommaDelimitedString(methodInvocation.getArguments())));
/*     */       }
/* 342 */       else if ("$[argumentTypes]".equals(match)) {
/* 343 */         appendArgumentTypes(methodInvocation, matcher, output);
/*     */       }
/* 345 */       else if ("$[returnValue]".equals(match)) {
/* 346 */         appendReturnValue(methodInvocation, matcher, output, returnValue);
/*     */       }
/* 348 */       else if ((throwable != null) && ("$[exception]".equals(match))) {
/* 349 */         matcher.appendReplacement(output, Matcher.quoteReplacement(throwable.toString()));
/*     */       }
/* 351 */       else if ("$[invocationTime]".equals(match)) {
/* 352 */         matcher.appendReplacement(output, Long.toString(invocationTime));
/*     */       }
/*     */       else
/*     */       {
/* 356 */         throw new IllegalArgumentException("Unknown placeholder [" + match + "]");
/*     */       }
/*     */     }
/* 359 */     matcher.appendTail(output);
/*     */     
/* 361 */     return output.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void appendReturnValue(MethodInvocation methodInvocation, Matcher matcher, StringBuffer output, Object returnValue)
/*     */   {
/* 376 */     if (methodInvocation.getMethod().getReturnType() == Void.TYPE) {
/* 377 */       matcher.appendReplacement(output, "void");
/*     */     }
/* 379 */     else if (returnValue == null) {
/* 380 */       matcher.appendReplacement(output, "null");
/*     */     }
/*     */     else {
/* 383 */       matcher.appendReplacement(output, Matcher.quoteReplacement(returnValue.toString()));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void appendArgumentTypes(MethodInvocation methodInvocation, Matcher matcher, StringBuffer output)
/*     */   {
/* 398 */     Class<?>[] argumentTypes = methodInvocation.getMethod().getParameterTypes();
/* 399 */     String[] argumentTypeShortNames = new String[argumentTypes.length];
/* 400 */     for (int i = 0; i < argumentTypeShortNames.length; i++) {
/* 401 */       argumentTypeShortNames[i] = ClassUtils.getShortName(argumentTypes[i]);
/*     */     }
/* 403 */     matcher.appendReplacement(output, 
/* 404 */       Matcher.quoteReplacement(StringUtils.arrayToCommaDelimitedString(argumentTypeShortNames)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkForInvalidPlaceholders(String message)
/*     */     throws IllegalArgumentException
/*     */   {
/* 413 */     Matcher matcher = PATTERN.matcher(message);
/* 414 */     while (matcher.find()) {
/* 415 */       String match = matcher.group();
/* 416 */       if (!ALLOWED_PLACEHOLDERS.contains(match)) {
/* 417 */         throw new IllegalArgumentException("Placeholder [" + match + "] is not valid");
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\springframework\aop\interceptor\CustomizableTraceInterceptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */