/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractBeanFactoryPointcutAdvisor
/*     */   extends AbstractPointcutAdvisor
/*     */   implements BeanFactoryAware
/*     */ {
/*     */   private String adviceBeanName;
/*     */   private BeanFactory beanFactory;
/*     */   private transient Advice advice;
/*  51 */   private volatile transient Object adviceMonitor = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAdviceBeanName(String adviceBeanName)
/*     */   {
/*  63 */     this.adviceBeanName = adviceBeanName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getAdviceBeanName()
/*     */   {
/*  70 */     return this.adviceBeanName;
/*     */   }
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/*  75 */     this.beanFactory = beanFactory;
/*  76 */     resetAdviceMonitor();
/*     */   }
/*     */   
/*     */   private void resetAdviceMonitor() {
/*  80 */     if ((this.beanFactory instanceof ConfigurableBeanFactory)) {
/*  81 */       this.adviceMonitor = ((ConfigurableBeanFactory)this.beanFactory).getSingletonMutex();
/*     */     }
/*     */     else {
/*  84 */       this.adviceMonitor = new Object();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAdvice(Advice advice)
/*     */   {
/*  94 */     synchronized (this.adviceMonitor) {
/*  95 */       this.advice = advice;
/*     */     }
/*     */   }
/*     */   
/*     */   public Advice getAdvice()
/*     */   {
/* 101 */     synchronized (this.adviceMonitor) {
/* 102 */       if ((this.advice == null) && (this.adviceBeanName != null)) {
/* 103 */         Assert.state(this.beanFactory != null, "BeanFactory must be set to resolve 'adviceBeanName'");
/* 104 */         this.advice = ((Advice)this.beanFactory.getBean(this.adviceBeanName, Advice.class));
/*     */       }
/* 106 */       return this.advice;
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 112 */     StringBuilder sb = new StringBuilder(getClass().getName());
/* 113 */     sb.append(": advice ");
/* 114 */     if (this.adviceBeanName != null) {
/* 115 */       sb.append("bean '").append(this.adviceBeanName).append("'");
/*     */     }
/*     */     else {
/* 118 */       sb.append(this.advice);
/*     */     }
/* 120 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readObject(ObjectInputStream ois)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 130 */     ois.defaultReadObject();
/*     */     
/*     */ 
/* 133 */     resetAdviceMonitor();
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\springframework\aop\support\AbstractBeanFactoryPointcutAdvisor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */