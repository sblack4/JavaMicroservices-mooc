/*     */ package org.springframework.aop.support.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationMatchingPointcut
/*     */   implements Pointcut
/*     */ {
/*     */   private final ClassFilter classFilter;
/*     */   private final MethodMatcher methodMatcher;
/*     */   
/*     */   public AnnotationMatchingPointcut(Class<? extends Annotation> classAnnotationType)
/*     */   {
/*  49 */     this.classFilter = new AnnotationClassFilter(classAnnotationType);
/*  50 */     this.methodMatcher = MethodMatcher.TRUE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationMatchingPointcut(Class<? extends Annotation> classAnnotationType, boolean checkInherited)
/*     */   {
/*  61 */     this.classFilter = new AnnotationClassFilter(classAnnotationType, checkInherited);
/*  62 */     this.methodMatcher = MethodMatcher.TRUE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationMatchingPointcut(Class<? extends Annotation> classAnnotationType, Class<? extends Annotation> methodAnnotationType)
/*     */   {
/*  75 */     Assert.isTrue((classAnnotationType != null) || (methodAnnotationType != null), "Either Class annotation type or Method annotation type needs to be specified (or both)");
/*     */     
/*     */ 
/*  78 */     if (classAnnotationType != null) {
/*  79 */       this.classFilter = new AnnotationClassFilter(classAnnotationType);
/*     */     }
/*     */     else {
/*  82 */       this.classFilter = ClassFilter.TRUE;
/*     */     }
/*     */     
/*  85 */     if (methodAnnotationType != null) {
/*  86 */       this.methodMatcher = new AnnotationMethodMatcher(methodAnnotationType);
/*     */     }
/*     */     else {
/*  89 */       this.methodMatcher = MethodMatcher.TRUE;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public ClassFilter getClassFilter()
/*     */   {
/*  96 */     return this.classFilter;
/*     */   }
/*     */   
/*     */   public MethodMatcher getMethodMatcher()
/*     */   {
/* 101 */     return this.methodMatcher;
/*     */   }
/*     */   
/*     */   public boolean equals(Object other)
/*     */   {
/* 106 */     if (this == other) {
/* 107 */       return true;
/*     */     }
/* 109 */     if (!(other instanceof AnnotationMatchingPointcut)) {
/* 110 */       return false;
/*     */     }
/* 112 */     AnnotationMatchingPointcut that = (AnnotationMatchingPointcut)other;
/*     */     
/* 114 */     return (ObjectUtils.nullSafeEquals(that.classFilter, this.classFilter)) && (ObjectUtils.nullSafeEquals(that.methodMatcher, this.methodMatcher));
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 119 */     int code = 17;
/* 120 */     if (this.classFilter != null) {
/* 121 */       code = 37 * code + this.classFilter.hashCode();
/*     */     }
/* 123 */     if (this.methodMatcher != null) {
/* 124 */       code = 37 * code + this.methodMatcher.hashCode();
/*     */     }
/* 126 */     return code;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 131 */     return "AnnotationMatchingPointcut: " + this.classFilter + ", " + this.methodMatcher;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AnnotationMatchingPointcut forClassAnnotation(Class<? extends Annotation> annotationType)
/*     */   {
/* 142 */     Assert.notNull(annotationType, "Annotation type must not be null");
/* 143 */     return new AnnotationMatchingPointcut(annotationType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AnnotationMatchingPointcut forMethodAnnotation(Class<? extends Annotation> annotationType)
/*     */   {
/* 153 */     Assert.notNull(annotationType, "Annotation type must not be null");
/* 154 */     return new AnnotationMatchingPointcut(null, annotationType);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\springframework\aop\support\annotation\AnnotationMatchingPointcut.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */