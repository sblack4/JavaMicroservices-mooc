/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractRegexpMethodPointcut
/*     */   extends StaticMethodMatcherPointcut
/*     */   implements Serializable
/*     */ {
/*  56 */   private String[] patterns = new String[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  61 */   private String[] excludedPatterns = new String[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPattern(String pattern)
/*     */   {
/*  70 */     setPatterns(new String[] { pattern });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPatterns(String... patterns)
/*     */   {
/*  79 */     Assert.notEmpty(patterns, "'patterns' must not be empty");
/*  80 */     this.patterns = new String[patterns.length];
/*  81 */     for (int i = 0; i < patterns.length; i++) {
/*  82 */       this.patterns[i] = StringUtils.trimWhitespace(patterns[i]);
/*     */     }
/*  84 */     initPatternRepresentation(this.patterns);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String[] getPatterns()
/*     */   {
/*  91 */     return this.patterns;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExcludedPattern(String excludedPattern)
/*     */   {
/* 100 */     setExcludedPatterns(new String[] { excludedPattern });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExcludedPatterns(String... excludedPatterns)
/*     */   {
/* 109 */     Assert.notEmpty(excludedPatterns, "'excludedPatterns' must not be empty");
/* 110 */     this.excludedPatterns = new String[excludedPatterns.length];
/* 111 */     for (int i = 0; i < excludedPatterns.length; i++) {
/* 112 */       this.excludedPatterns[i] = StringUtils.trimWhitespace(excludedPatterns[i]);
/*     */     }
/* 114 */     initExcludedPatternRepresentation(this.excludedPatterns);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String[] getExcludedPatterns()
/*     */   {
/* 121 */     return this.excludedPatterns;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matches(Method method, Class<?> targetClass)
/*     */   {
/* 133 */     return ((targetClass != null) && (matchesPattern(targetClass.getName() + "." + method.getName()))) || (matchesPattern(method.getDeclaringClass().getName() + "." + method.getName()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean matchesPattern(String signatureString)
/*     */   {
/* 142 */     for (int i = 0; i < this.patterns.length; i++) {
/* 143 */       boolean matched = matches(signatureString, i);
/* 144 */       if (matched) {
/* 145 */         for (int j = 0; j < this.excludedPatterns.length; j++) {
/* 146 */           boolean excluded = matchesExclusion(signatureString, j);
/* 147 */           if (excluded) {
/* 148 */             return false;
/*     */           }
/*     */         }
/* 151 */         return true;
/*     */       }
/*     */     }
/* 154 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void initPatternRepresentation(String[] paramArrayOfString)
/*     */     throws IllegalArgumentException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void initExcludedPatternRepresentation(String[] paramArrayOfString)
/*     */     throws IllegalArgumentException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract boolean matches(String paramString, int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract boolean matchesExclusion(String paramString, int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 197 */     if (this == other) {
/* 198 */       return true;
/*     */     }
/* 200 */     if (!(other instanceof AbstractRegexpMethodPointcut)) {
/* 201 */       return false;
/*     */     }
/* 203 */     AbstractRegexpMethodPointcut otherPointcut = (AbstractRegexpMethodPointcut)other;
/*     */     
/* 205 */     return (Arrays.equals(this.patterns, otherPointcut.patterns)) && (Arrays.equals(this.excludedPatterns, otherPointcut.excludedPatterns));
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 210 */     int result = 27;
/* 211 */     for (String pattern : this.patterns) {
/* 212 */       result = 13 * result + pattern.hashCode();
/*     */     }
/* 214 */     for (String excludedPattern : this.excludedPatterns) {
/* 215 */       result = 13 * result + excludedPattern.hashCode();
/*     */     }
/* 217 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 223 */     return getClass().getName() + ": patterns " + ObjectUtils.nullSafeToString(this.patterns) + ", excluded patterns " + ObjectUtils.nullSafeToString(this.excludedPatterns);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\springframework\aop\support\AbstractRegexpMethodPointcut.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */