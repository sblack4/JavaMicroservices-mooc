/*    */ package org.springframework.aop.framework.autoproxy;
/*    */ 
/*    */ import org.springframework.beans.factory.BeanNameAware;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultAdvisorAutoProxyCreator
/*    */   extends AbstractAdvisorAutoProxyCreator
/*    */   implements BeanNameAware
/*    */ {
/*    */   public static final String SEPARATOR = ".";
/*    */   private boolean usePrefix;
/*    */   private String advisorBeanNamePrefix;
/*    */   
/*    */   public void setUsePrefix(boolean usePrefix)
/*    */   {
/* 53 */     this.usePrefix = usePrefix;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isUsePrefix()
/*    */   {
/* 61 */     return this.usePrefix;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setAdvisorBeanNamePrefix(String advisorBeanNamePrefix)
/*    */   {
/* 71 */     this.advisorBeanNamePrefix = advisorBeanNamePrefix;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getAdvisorBeanNamePrefix()
/*    */   {
/* 79 */     return this.advisorBeanNamePrefix;
/*    */   }
/*    */   
/*    */ 
/*    */   public void setBeanName(String name)
/*    */   {
/* 85 */     if (this.advisorBeanNamePrefix == null) {
/* 86 */       this.advisorBeanNamePrefix = (name + ".");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected boolean isEligibleAdvisorBean(String beanName)
/*    */   {
/* 98 */     return (!isUsePrefix()) || (beanName.startsWith(getAdvisorBeanNamePrefix()));
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\springframework\aop\framework\autoproxy\DefaultAdvisorAutoProxyCreator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */