/*     */ package org.springframework.aop.framework.autoproxy;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAdvisorAutoProxyCreator
/*     */   extends AbstractAutoProxyCreator
/*     */ {
/*     */   private BeanFactoryAdvisorRetrievalHelper advisorRetrievalHelper;
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/*  55 */     super.setBeanFactory(beanFactory);
/*  56 */     if (!(beanFactory instanceof ConfigurableListableBeanFactory)) {
/*  57 */       throw new IllegalStateException("Cannot use AdvisorAutoProxyCreator without a ConfigurableListableBeanFactory");
/*     */     }
/*  59 */     initBeanFactory((ConfigurableListableBeanFactory)beanFactory);
/*     */   }
/*     */   
/*     */   protected void initBeanFactory(ConfigurableListableBeanFactory beanFactory) {
/*  63 */     this.advisorRetrievalHelper = new BeanFactoryAdvisorRetrievalHelperAdapter(beanFactory);
/*     */   }
/*     */   
/*     */ 
/*     */   protected Object[] getAdvicesAndAdvisorsForBean(Class<?> beanClass, String beanName, TargetSource targetSource)
/*     */   {
/*  69 */     List<Advisor> advisors = findEligibleAdvisors(beanClass, beanName);
/*  70 */     if (advisors.isEmpty()) {
/*  71 */       return DO_NOT_PROXY;
/*     */     }
/*  73 */     return advisors.toArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<Advisor> findEligibleAdvisors(Class<?> beanClass, String beanName)
/*     */   {
/*  87 */     List<Advisor> candidateAdvisors = findCandidateAdvisors();
/*  88 */     List<Advisor> eligibleAdvisors = findAdvisorsThatCanApply(candidateAdvisors, beanClass, beanName);
/*  89 */     extendAdvisors(eligibleAdvisors);
/*  90 */     if (!eligibleAdvisors.isEmpty()) {
/*  91 */       eligibleAdvisors = sortAdvisors(eligibleAdvisors);
/*     */     }
/*  93 */     return eligibleAdvisors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<Advisor> findCandidateAdvisors()
/*     */   {
/* 101 */     return this.advisorRetrievalHelper.findAdvisorBeans();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<Advisor> findAdvisorsThatCanApply(List<Advisor> candidateAdvisors, Class<?> beanClass, String beanName)
/*     */   {
/* 116 */     ProxyCreationContext.setCurrentProxiedBeanName(beanName);
/*     */     try {
/* 118 */       return AopUtils.findAdvisorsThatCanApply(candidateAdvisors, beanClass);
/*     */     }
/*     */     finally {
/* 121 */       ProxyCreationContext.setCurrentProxiedBeanName(null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isEligibleAdvisorBean(String beanName)
/*     */   {
/* 132 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<Advisor> sortAdvisors(List<Advisor> advisors)
/*     */   {
/* 145 */     AnnotationAwareOrderComparator.sort(advisors);
/* 146 */     return advisors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void extendAdvisors(List<Advisor> candidateAdvisors) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean advisorsPreFiltered()
/*     */   {
/* 166 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private class BeanFactoryAdvisorRetrievalHelperAdapter
/*     */     extends BeanFactoryAdvisorRetrievalHelper
/*     */   {
/*     */     public BeanFactoryAdvisorRetrievalHelperAdapter(ConfigurableListableBeanFactory beanFactory)
/*     */     {
/* 177 */       super();
/*     */     }
/*     */     
/*     */     protected boolean isEligibleBean(String beanName)
/*     */     {
/* 182 */       return AbstractAdvisorAutoProxyCreator.this.isEligibleAdvisorBean(beanName);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\springframework\aop\framework\autoproxy\AbstractAdvisorAutoProxyCreator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */