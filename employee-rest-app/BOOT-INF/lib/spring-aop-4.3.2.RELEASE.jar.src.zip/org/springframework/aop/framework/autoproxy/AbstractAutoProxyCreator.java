/*     */ package org.springframework.aop.framework.autoproxy;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.framework.AopInfrastructureBean;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.aop.framework.ProxyProcessorSupport;
/*     */ import org.springframework.aop.framework.adapter.AdvisorAdapterRegistry;
/*     */ import org.springframework.aop.framework.adapter.GlobalAdvisorAdapterRegistry;
/*     */ import org.springframework.aop.target.SingletonTargetSource;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.SmartInstantiationAwareBeanPostProcessor;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAutoProxyCreator
/*     */   extends ProxyProcessorSupport
/*     */   implements SmartInstantiationAwareBeanPostProcessor, BeanFactoryAware
/*     */ {
/* 100 */   protected static final Object[] DO_NOT_PROXY = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */   protected static final Object[] PROXY_WITHOUT_ADDITIONAL_INTERCEPTORS = new Object[0];
/*     */   
/*     */ 
/*     */ 
/* 111 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */ 
/* 114 */   private AdvisorAdapterRegistry advisorAdapterRegistry = GlobalAdvisorAdapterRegistry.getInstance();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 120 */   private boolean freezeProxy = false;
/*     */   
/*     */ 
/* 123 */   private String[] interceptorNames = new String[0];
/*     */   
/* 125 */   private boolean applyCommonInterceptorsFirst = true;
/*     */   
/*     */ 
/*     */   private TargetSourceCreator[] customTargetSourceCreators;
/*     */   
/*     */   private BeanFactory beanFactory;
/*     */   
/* 132 */   private final Set<String> targetSourcedBeans = Collections.newSetFromMap(new ConcurrentHashMap(16));
/*     */   
/*     */ 
/* 135 */   private final Set<Object> earlyProxyReferences = Collections.newSetFromMap(new ConcurrentHashMap(16));
/*     */   
/* 137 */   private final Map<Object, Class<?>> proxyTypes = new ConcurrentHashMap(16);
/*     */   
/* 139 */   private final Map<Object, Boolean> advisedBeans = new ConcurrentHashMap(256);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFrozen(boolean frozen)
/*     */   {
/* 150 */     this.freezeProxy = frozen;
/*     */   }
/*     */   
/*     */   public boolean isFrozen()
/*     */   {
/* 155 */     return this.freezeProxy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAdvisorAdapterRegistry(AdvisorAdapterRegistry advisorAdapterRegistry)
/*     */   {
/* 164 */     this.advisorAdapterRegistry = advisorAdapterRegistry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCustomTargetSourceCreators(TargetSourceCreator... targetSourceCreators)
/*     */   {
/* 182 */     this.customTargetSourceCreators = targetSourceCreators;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInterceptorNames(String... interceptorNames)
/*     */   {
/* 193 */     this.interceptorNames = interceptorNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setApplyCommonInterceptorsFirst(boolean applyCommonInterceptorsFirst)
/*     */   {
/* 201 */     this.applyCommonInterceptorsFirst = applyCommonInterceptorsFirst;
/*     */   }
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/* 206 */     this.beanFactory = beanFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BeanFactory getBeanFactory()
/*     */   {
/* 214 */     return this.beanFactory;
/*     */   }
/*     */   
/*     */ 
/*     */   public Class<?> predictBeanType(Class<?> beanClass, String beanName)
/*     */   {
/* 220 */     if (this.proxyTypes.isEmpty()) {
/* 221 */       return null;
/*     */     }
/* 223 */     Object cacheKey = getCacheKey(beanClass, beanName);
/* 224 */     return (Class)this.proxyTypes.get(cacheKey);
/*     */   }
/*     */   
/*     */   public Constructor<?>[] determineCandidateConstructors(Class<?> beanClass, String beanName) throws BeansException
/*     */   {
/* 229 */     return null;
/*     */   }
/*     */   
/*     */   public Object getEarlyBeanReference(Object bean, String beanName) throws BeansException
/*     */   {
/* 234 */     Object cacheKey = getCacheKey(bean.getClass(), beanName);
/* 235 */     if (!this.earlyProxyReferences.contains(cacheKey)) {
/* 236 */       this.earlyProxyReferences.add(cacheKey);
/*     */     }
/* 238 */     return wrapIfNecessary(bean, beanName, cacheKey);
/*     */   }
/*     */   
/*     */   public Object postProcessBeforeInstantiation(Class<?> beanClass, String beanName) throws BeansException
/*     */   {
/* 243 */     Object cacheKey = getCacheKey(beanClass, beanName);
/*     */     
/* 245 */     if ((beanName == null) || (!this.targetSourcedBeans.contains(beanName))) {
/* 246 */       if (this.advisedBeans.containsKey(cacheKey)) {
/* 247 */         return null;
/*     */       }
/* 249 */       if ((isInfrastructureClass(beanClass)) || (shouldSkip(beanClass, beanName))) {
/* 250 */         this.advisedBeans.put(cacheKey, Boolean.FALSE);
/* 251 */         return null;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 258 */     if (beanName != null) {
/* 259 */       TargetSource targetSource = getCustomTargetSource(beanClass, beanName);
/* 260 */       if (targetSource != null) {
/* 261 */         this.targetSourcedBeans.add(beanName);
/* 262 */         Object[] specificInterceptors = getAdvicesAndAdvisorsForBean(beanClass, beanName, targetSource);
/* 263 */         Object proxy = createProxy(beanClass, beanName, specificInterceptors, targetSource);
/* 264 */         this.proxyTypes.put(cacheKey, proxy.getClass());
/* 265 */         return proxy;
/*     */       }
/*     */     }
/*     */     
/* 269 */     return null;
/*     */   }
/*     */   
/*     */   public boolean postProcessAfterInstantiation(Object bean, String beanName)
/*     */   {
/* 274 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PropertyValues postProcessPropertyValues(PropertyValues pvs, PropertyDescriptor[] pds, Object bean, String beanName)
/*     */   {
/* 281 */     return pvs;
/*     */   }
/*     */   
/*     */   public Object postProcessBeforeInitialization(Object bean, String beanName)
/*     */   {
/* 286 */     return bean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object postProcessAfterInitialization(Object bean, String beanName)
/*     */     throws BeansException
/*     */   {
/* 296 */     if (bean != null) {
/* 297 */       Object cacheKey = getCacheKey(bean.getClass(), beanName);
/* 298 */       if (!this.earlyProxyReferences.contains(cacheKey)) {
/* 299 */         return wrapIfNecessary(bean, beanName, cacheKey);
/*     */       }
/*     */     }
/* 302 */     return bean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object getCacheKey(Class<?> beanClass, String beanName)
/*     */   {
/* 318 */     if (StringUtils.hasLength(beanName)) {
/* 319 */       return FactoryBean.class.isAssignableFrom(beanClass) ? "&" + beanName : beanName;
/*     */     }
/*     */     
/*     */ 
/* 323 */     return beanClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object wrapIfNecessary(Object bean, String beanName, Object cacheKey)
/*     */   {
/* 335 */     if ((beanName != null) && (this.targetSourcedBeans.contains(beanName))) {
/* 336 */       return bean;
/*     */     }
/* 338 */     if (Boolean.FALSE.equals(this.advisedBeans.get(cacheKey))) {
/* 339 */       return bean;
/*     */     }
/* 341 */     if ((isInfrastructureClass(bean.getClass())) || (shouldSkip(bean.getClass(), beanName))) {
/* 342 */       this.advisedBeans.put(cacheKey, Boolean.FALSE);
/* 343 */       return bean;
/*     */     }
/*     */     
/*     */ 
/* 347 */     Object[] specificInterceptors = getAdvicesAndAdvisorsForBean(bean.getClass(), beanName, null);
/* 348 */     if (specificInterceptors != DO_NOT_PROXY) {
/* 349 */       this.advisedBeans.put(cacheKey, Boolean.TRUE);
/* 350 */       Object proxy = createProxy(bean
/* 351 */         .getClass(), beanName, specificInterceptors, new SingletonTargetSource(bean));
/* 352 */       this.proxyTypes.put(cacheKey, proxy.getClass());
/* 353 */       return proxy;
/*     */     }
/*     */     
/* 356 */     this.advisedBeans.put(cacheKey, Boolean.FALSE);
/* 357 */     return bean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isInfrastructureClass(Class<?> beanClass)
/*     */   {
/* 376 */     boolean retVal = (Advice.class.isAssignableFrom(beanClass)) || (Pointcut.class.isAssignableFrom(beanClass)) || (Advisor.class.isAssignableFrom(beanClass)) || (AopInfrastructureBean.class.isAssignableFrom(beanClass));
/* 377 */     if ((retVal) && (this.logger.isTraceEnabled())) {
/* 378 */       this.logger.trace("Did not attempt to auto-proxy infrastructure class [" + beanClass.getName() + "]");
/*     */     }
/* 380 */     return retVal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean shouldSkip(Class<?> beanClass, String beanName)
/*     */   {
/* 393 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TargetSource getCustomTargetSource(Class<?> beanClass, String beanName)
/*     */   {
/* 408 */     if ((this.customTargetSourceCreators != null) && (this.beanFactory != null) && 
/* 409 */       (this.beanFactory.containsBean(beanName))) {
/* 410 */       for (TargetSourceCreator tsc : this.customTargetSourceCreators) {
/* 411 */         TargetSource ts = tsc.getTargetSource(beanClass, beanName);
/* 412 */         if (ts != null)
/*     */         {
/* 414 */           if (this.logger.isDebugEnabled()) {
/* 415 */             this.logger.debug("TargetSourceCreator [" + tsc + " found custom TargetSource for bean with name '" + beanName + "'");
/*     */           }
/*     */           
/* 418 */           return ts;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 424 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object createProxy(Class<?> beanClass, String beanName, Object[] specificInterceptors, TargetSource targetSource)
/*     */   {
/* 441 */     if ((this.beanFactory instanceof ConfigurableListableBeanFactory)) {
/* 442 */       AutoProxyUtils.exposeTargetClass((ConfigurableListableBeanFactory)this.beanFactory, beanName, beanClass);
/*     */     }
/*     */     
/* 445 */     ProxyFactory proxyFactory = new ProxyFactory();
/* 446 */     proxyFactory.copyFrom(this);
/*     */     
/* 448 */     if (!proxyFactory.isProxyTargetClass()) {
/* 449 */       if (shouldProxyTargetClass(beanClass, beanName)) {
/* 450 */         proxyFactory.setProxyTargetClass(true);
/*     */       }
/*     */       else {
/* 453 */         evaluateProxyInterfaces(beanClass, proxyFactory);
/*     */       }
/*     */     }
/*     */     
/* 457 */     Advisor[] advisors = buildAdvisors(beanName, specificInterceptors);
/* 458 */     for (Advisor advisor : advisors) {
/* 459 */       proxyFactory.addAdvisor(advisor);
/*     */     }
/*     */     
/* 462 */     proxyFactory.setTargetSource(targetSource);
/* 463 */     customizeProxyFactory(proxyFactory);
/*     */     
/* 465 */     proxyFactory.setFrozen(this.freezeProxy);
/* 466 */     if (advisorsPreFiltered()) {
/* 467 */       proxyFactory.setPreFiltered(true);
/*     */     }
/*     */     
/* 470 */     return proxyFactory.getProxy(getProxyClassLoader());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean shouldProxyTargetClass(Class<?> beanClass, String beanName)
/*     */   {
/* 484 */     return ((this.beanFactory instanceof ConfigurableListableBeanFactory)) && (AutoProxyUtils.shouldProxyTargetClass((ConfigurableListableBeanFactory)this.beanFactory, beanName));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean advisorsPreFiltered()
/*     */   {
/* 498 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Advisor[] buildAdvisors(String beanName, Object[] specificInterceptors)
/*     */   {
/* 511 */     Advisor[] commonInterceptors = resolveInterceptorNames();
/*     */     
/* 513 */     List<Object> allInterceptors = new ArrayList();
/* 514 */     if (specificInterceptors != null) {
/* 515 */       allInterceptors.addAll(Arrays.asList(specificInterceptors));
/* 516 */       if (commonInterceptors.length > 0) {
/* 517 */         if (this.applyCommonInterceptorsFirst) {
/* 518 */           allInterceptors.addAll(0, Arrays.asList(commonInterceptors));
/*     */         }
/*     */         else {
/* 521 */           allInterceptors.addAll(Arrays.asList(commonInterceptors));
/*     */         }
/*     */       }
/*     */     }
/* 525 */     if (this.logger.isDebugEnabled()) {
/* 526 */       int nrOfCommonInterceptors = commonInterceptors.length;
/* 527 */       int nrOfSpecificInterceptors = specificInterceptors != null ? specificInterceptors.length : 0;
/* 528 */       this.logger.debug("Creating implicit proxy for bean '" + beanName + "' with " + nrOfCommonInterceptors + " common interceptors and " + nrOfSpecificInterceptors + " specific interceptors");
/*     */     }
/*     */     
/*     */ 
/* 532 */     Advisor[] advisors = new Advisor[allInterceptors.size()];
/* 533 */     for (int i = 0; i < allInterceptors.size(); i++) {
/* 534 */       advisors[i] = this.advisorAdapterRegistry.wrap(allInterceptors.get(i));
/*     */     }
/* 536 */     return advisors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Advisor[] resolveInterceptorNames()
/*     */   {
/* 544 */     ConfigurableBeanFactory cbf = (this.beanFactory instanceof ConfigurableBeanFactory) ? (ConfigurableBeanFactory)this.beanFactory : null;
/*     */     
/* 546 */     List<Advisor> advisors = new ArrayList();
/* 547 */     for (String beanName : this.interceptorNames) {
/* 548 */       if ((cbf == null) || (!cbf.isCurrentlyInCreation(beanName))) {
/* 549 */         Object next = this.beanFactory.getBean(beanName);
/* 550 */         advisors.add(this.advisorAdapterRegistry.wrap(next));
/*     */       }
/*     */     }
/* 553 */     return (Advisor[])advisors.toArray(new Advisor[advisors.size()]);
/*     */   }
/*     */   
/*     */   protected void customizeProxyFactory(ProxyFactory proxyFactory) {}
/*     */   
/*     */   protected abstract Object[] getAdvicesAndAdvisorsForBean(Class<?> paramClass, String paramString, TargetSource paramTargetSource)
/*     */     throws BeansException;
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\springframework\aop\framework\autoproxy\AbstractAutoProxyCreator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */