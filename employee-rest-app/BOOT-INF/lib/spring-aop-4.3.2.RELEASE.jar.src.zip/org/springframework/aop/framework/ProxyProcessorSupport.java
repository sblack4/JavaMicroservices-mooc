/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import org.springframework.beans.factory.Aware;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProxyProcessorSupport
/*     */   extends ProxyConfig
/*     */   implements Ordered, BeanClassLoaderAware, AopInfrastructureBean
/*     */ {
/*  43 */   private int order = Integer.MAX_VALUE;
/*     */   
/*  45 */   private ClassLoader proxyClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   
/*  47 */   private boolean classLoaderConfigured = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOrder(int order)
/*     */   {
/*  57 */     this.order = order;
/*     */   }
/*     */   
/*     */   public int getOrder()
/*     */   {
/*  62 */     return this.order;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProxyClassLoader(ClassLoader classLoader)
/*     */   {
/*  72 */     this.proxyClassLoader = classLoader;
/*  73 */     this.classLoaderConfigured = (classLoader != null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected ClassLoader getProxyClassLoader()
/*     */   {
/*  80 */     return this.proxyClassLoader;
/*     */   }
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/*  85 */     if (!this.classLoaderConfigured) {
/*  86 */       this.proxyClassLoader = classLoader;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void evaluateProxyInterfaces(Class<?> beanClass, ProxyFactory proxyFactory)
/*     */   {
/* 100 */     Class<?>[] targetInterfaces = ClassUtils.getAllInterfacesForClass(beanClass, getProxyClassLoader());
/* 101 */     boolean hasReasonableProxyInterface = false;
/* 102 */     for (Class<?> ifc : targetInterfaces) {
/* 103 */       if ((!isConfigurationCallbackInterface(ifc)) && (!isInternalLanguageInterface(ifc)) && 
/* 104 */         (ifc.getMethods().length > 0)) {
/* 105 */         hasReasonableProxyInterface = true;
/* 106 */         break;
/*     */       }
/*     */     }
/* 109 */     if (hasReasonableProxyInterface)
/*     */     {
/* 111 */       for (Class<?> ifc : targetInterfaces) {
/* 112 */         proxyFactory.addInterface(ifc);
/*     */       }
/*     */       
/*     */     } else {
/* 116 */       proxyFactory.setProxyTargetClass(true);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isConfigurationCallbackInterface(Class<?> ifc)
/*     */   {
/* 130 */     return (InitializingBean.class == ifc) || (DisposableBean.class == ifc) || (ObjectUtils.containsElement(ifc.getInterfaces(), Aware.class));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isInternalLanguageInterface(Class<?> ifc)
/*     */   {
/* 143 */     return (ifc.getName().equals("groovy.lang.GroovyObject")) || (ifc.getName().endsWith(".cglib.proxy.Factory"));
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\springframework\aop\framework\ProxyProcessorSupport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */