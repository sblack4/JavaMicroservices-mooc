/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.UndeclaredThrowableException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.AopInvocationException;
/*     */ import org.springframework.aop.PointcutAdvisor;
/*     */ import org.springframework.aop.RawTargetAccess;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.cglib.core.ClassGenerator;
/*     */ import org.springframework.cglib.core.CodeGenerationException;
/*     */ import org.springframework.cglib.core.SpringNamingPolicy;
/*     */ import org.springframework.cglib.proxy.Callback;
/*     */ import org.springframework.cglib.proxy.CallbackFilter;
/*     */ import org.springframework.cglib.proxy.Dispatcher;
/*     */ import org.springframework.cglib.proxy.Enhancer;
/*     */ import org.springframework.cglib.proxy.Factory;
/*     */ import org.springframework.cglib.proxy.MethodInterceptor;
/*     */ import org.springframework.cglib.proxy.MethodProxy;
/*     */ import org.springframework.cglib.proxy.NoOp;
/*     */ import org.springframework.cglib.transform.impl.UndeclaredThrowableStrategy;
/*     */ import org.springframework.core.SmartClassLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CglibAopProxy
/*     */   implements AopProxy, Serializable
/*     */ {
/*     */   private static final int AOP_PROXY = 0;
/*     */   private static final int INVOKE_TARGET = 1;
/*     */   private static final int NO_OVERRIDE = 2;
/*     */   private static final int DISPATCH_TARGET = 3;
/*     */   private static final int DISPATCH_ADVISED = 4;
/*     */   private static final int INVOKE_EQUALS = 5;
/*     */   private static final int INVOKE_HASHCODE = 6;
/*  97 */   protected static final Log logger = LogFactory.getLog(CglibAopProxy.class);
/*     */   
/*     */ 
/* 100 */   private static final Map<Class<?>, Boolean> validatedClasses = new WeakHashMap();
/*     */   
/*     */ 
/*     */   protected final AdvisedSupport advised;
/*     */   
/*     */ 
/*     */   protected Object[] constructorArgs;
/*     */   
/*     */ 
/*     */   protected Class<?>[] constructorArgTypes;
/*     */   
/*     */ 
/*     */   private final transient AdvisedDispatcher advisedDispatcher;
/*     */   
/*     */ 
/*     */   private transient Map<String, Integer> fixedInterceptorMap;
/*     */   
/*     */ 
/*     */   private transient int fixedInterceptorOffset;
/*     */   
/*     */ 
/*     */ 
/*     */   public CglibAopProxy(AdvisedSupport config)
/*     */     throws AopConfigException
/*     */   {
/* 125 */     Assert.notNull(config, "AdvisedSupport must not be null");
/* 126 */     if ((config.getAdvisors().length == 0) && (config.getTargetSource() == AdvisedSupport.EMPTY_TARGET_SOURCE)) {
/* 127 */       throw new AopConfigException("No advisors and no TargetSource specified");
/*     */     }
/* 129 */     this.advised = config;
/* 130 */     this.advisedDispatcher = new AdvisedDispatcher(this.advised);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConstructorArguments(Object[] constructorArgs, Class<?>[] constructorArgTypes)
/*     */   {
/* 139 */     if ((constructorArgs == null) || (constructorArgTypes == null)) {
/* 140 */       throw new IllegalArgumentException("Both 'constructorArgs' and 'constructorArgTypes' need to be specified");
/*     */     }
/* 142 */     if (constructorArgs.length != constructorArgTypes.length) {
/* 143 */       throw new IllegalArgumentException("Number of 'constructorArgs' (" + constructorArgs.length + ") must match number of 'constructorArgTypes' (" + constructorArgTypes.length + ")");
/*     */     }
/*     */     
/* 146 */     this.constructorArgs = constructorArgs;
/* 147 */     this.constructorArgTypes = constructorArgTypes;
/*     */   }
/*     */   
/*     */ 
/*     */   public Object getProxy()
/*     */   {
/* 153 */     return getProxy(null);
/*     */   }
/*     */   
/*     */   public Object getProxy(ClassLoader classLoader)
/*     */   {
/* 158 */     if (logger.isDebugEnabled()) {
/* 159 */       logger.debug("Creating CGLIB proxy: target source is " + this.advised.getTargetSource());
/*     */     }
/*     */     try
/*     */     {
/* 163 */       Class<?> rootClass = this.advised.getTargetClass();
/* 164 */       Assert.state(rootClass != null, "Target class must be available for creating a CGLIB proxy");
/*     */       
/* 166 */       Class<?> proxySuperClass = rootClass;
/* 167 */       if (ClassUtils.isCglibProxyClass(rootClass)) {
/* 168 */         proxySuperClass = rootClass.getSuperclass();
/* 169 */         Class<?>[] additionalInterfaces = rootClass.getInterfaces();
/* 170 */         for (Class<?> additionalInterface : additionalInterfaces) {
/* 171 */           this.advised.addInterface(additionalInterface);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 176 */       validateClassIfNecessary(proxySuperClass, classLoader);
/*     */       
/*     */ 
/* 179 */       Enhancer enhancer = createEnhancer();
/* 180 */       if (classLoader != null) {
/* 181 */         enhancer.setClassLoader(classLoader);
/* 182 */         if (((classLoader instanceof SmartClassLoader)) && 
/* 183 */           (((SmartClassLoader)classLoader).isClassReloadable(proxySuperClass))) {
/* 184 */           enhancer.setUseCache(false);
/*     */         }
/*     */       }
/* 187 */       enhancer.setSuperclass(proxySuperClass);
/* 188 */       enhancer.setInterfaces(AopProxyUtils.completeProxiedInterfaces(this.advised));
/* 189 */       enhancer.setNamingPolicy(SpringNamingPolicy.INSTANCE);
/* 190 */       enhancer.setStrategy(new ClassLoaderAwareUndeclaredThrowableStrategy(classLoader));
/*     */       
/* 192 */       Callback[] callbacks = getCallbacks(rootClass);
/* 193 */       Object types = new Class[callbacks.length];
/* 194 */       for (int x = 0; x < types.length; x++) {
/* 195 */         types[x] = callbacks[x].getClass();
/*     */       }
/*     */       
/* 198 */       enhancer.setCallbackFilter(new ProxyCallbackFilter(this.advised
/* 199 */         .getConfigurationOnlyCopy(), this.fixedInterceptorMap, this.fixedInterceptorOffset));
/* 200 */       enhancer.setCallbackTypes((Class[])types);
/*     */       
/*     */ 
/* 203 */       return createProxyClassAndInstance(enhancer, callbacks);
/*     */     }
/*     */     catch (CodeGenerationException ex)
/*     */     {
/* 207 */       throw new AopConfigException("Could not generate CGLIB subclass of class [" + this.advised.getTargetClass() + "]: " + "Common causes of this problem include using a final class or a non-visible class", ex);
/*     */ 
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/*     */ 
/* 213 */       throw new AopConfigException("Could not generate CGLIB subclass of class [" + this.advised.getTargetClass() + "]: " + "Common causes of this problem include using a final class or a non-visible class", ex);
/*     */ 
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */ 
/* 219 */       throw new AopConfigException("Unexpected AOP exception", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected Object createProxyClassAndInstance(Enhancer enhancer, Callback[] callbacks) {
/* 224 */     enhancer.setInterceptDuringConstruction(false);
/* 225 */     enhancer.setCallbacks(callbacks);
/*     */     
/*     */ 
/* 228 */     return this.constructorArgs != null ? enhancer.create(this.constructorArgTypes, this.constructorArgs) : enhancer.create();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Enhancer createEnhancer()
/*     */   {
/* 236 */     return new Enhancer();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void validateClassIfNecessary(Class<?> proxySuperClass, ClassLoader proxyClassLoader)
/*     */   {
/* 244 */     if (logger.isInfoEnabled()) {
/* 245 */       synchronized (validatedClasses) {
/* 246 */         if (!validatedClasses.containsKey(proxySuperClass)) {
/* 247 */           doValidateClass(proxySuperClass, proxyClassLoader);
/* 248 */           validatedClasses.put(proxySuperClass, Boolean.TRUE);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void doValidateClass(Class<?> proxySuperClass, ClassLoader proxyClassLoader)
/*     */   {
/* 259 */     if (Object.class != proxySuperClass) {
/* 260 */       Method[] methods = proxySuperClass.getDeclaredMethods();
/* 261 */       for (Method method : methods) {
/* 262 */         int mod = method.getModifiers();
/* 263 */         if (!Modifier.isStatic(mod)) {
/* 264 */           if (Modifier.isFinal(mod)) {
/* 265 */             logger.info("Unable to proxy method [" + method + "] because it is final: " + "All calls to this method via a proxy will NOT be routed to the target instance.");
/*     */ 
/*     */           }
/* 268 */           else if ((!Modifier.isPublic(mod)) && (!Modifier.isProtected(mod)) && (!Modifier.isPrivate(mod)) && (proxyClassLoader != null) && 
/* 269 */             (proxySuperClass.getClassLoader() != proxyClassLoader)) {
/* 270 */             logger.info("Unable to proxy method [" + method + "] because it is package-visible " + "across different ClassLoaders: All calls to this method via a proxy will " + "NOT be routed to the target instance.");
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 276 */       doValidateClass(proxySuperClass.getSuperclass(), proxyClassLoader);
/*     */     }
/*     */   }
/*     */   
/*     */   private Callback[] getCallbacks(Class<?> rootClass) throws Exception
/*     */   {
/* 282 */     boolean exposeProxy = this.advised.isExposeProxy();
/* 283 */     boolean isFrozen = this.advised.isFrozen();
/* 284 */     boolean isStatic = this.advised.getTargetSource().isStatic();
/*     */     
/*     */ 
/* 287 */     Callback aopInterceptor = new DynamicAdvisedInterceptor(this.advised);
/*     */     
/*     */     Callback targetInterceptor;
/*     */     
/*     */     Callback targetInterceptor;
/* 292 */     if (exposeProxy)
/*     */     {
/*     */ 
/* 295 */       targetInterceptor = isStatic ? new StaticUnadvisedExposedInterceptor(this.advised.getTargetSource().getTarget()) : new DynamicUnadvisedExposedInterceptor(this.advised.getTargetSource());
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 300 */       targetInterceptor = isStatic ? new StaticUnadvisedInterceptor(this.advised.getTargetSource().getTarget()) : new DynamicUnadvisedInterceptor(this.advised.getTargetSource());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 306 */     Callback targetDispatcher = (Callback)(isStatic ? new StaticDispatcher(this.advised.getTargetSource().getTarget()) : new SerializableNoOp());
/*     */     
/* 308 */     Callback[] mainCallbacks = { aopInterceptor, targetInterceptor, new SerializableNoOp(), targetDispatcher, this.advisedDispatcher, new EqualsInterceptor(this.advised), new HashCodeInterceptor(this.advised) };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     Callback[] callbacks;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 322 */     if ((isStatic) && (isFrozen)) {
/* 323 */       Method[] methods = rootClass.getMethods();
/* 324 */       Callback[] fixedCallbacks = new Callback[methods.length];
/* 325 */       this.fixedInterceptorMap = new HashMap(methods.length);
/*     */       
/*     */ 
/* 328 */       for (int x = 0; x < methods.length; x++) {
/* 329 */         List<Object> chain = this.advised.getInterceptorsAndDynamicInterceptionAdvice(methods[x], rootClass);
/* 330 */         fixedCallbacks[x] = new FixedChainStaticTargetInterceptor(chain, this.advised
/* 331 */           .getTargetSource().getTarget(), this.advised.getTargetClass());
/* 332 */         this.fixedInterceptorMap.put(methods[x].toString(), Integer.valueOf(x));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 337 */       Callback[] callbacks = new Callback[mainCallbacks.length + fixedCallbacks.length];
/* 338 */       System.arraycopy(mainCallbacks, 0, callbacks, 0, mainCallbacks.length);
/* 339 */       System.arraycopy(fixedCallbacks, 0, callbacks, mainCallbacks.length, fixedCallbacks.length);
/* 340 */       this.fixedInterceptorOffset = mainCallbacks.length;
/*     */     }
/*     */     else {
/* 343 */       callbacks = mainCallbacks;
/*     */     }
/* 345 */     return callbacks;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Object processReturnType(Object proxy, Object target, Method method, Object retVal)
/*     */   {
/* 354 */     if ((retVal != null) && (retVal == target) && (!RawTargetAccess.class.isAssignableFrom(method.getDeclaringClass())))
/*     */     {
/*     */ 
/* 357 */       retVal = proxy;
/*     */     }
/* 359 */     Class<?> returnType = method.getReturnType();
/* 360 */     if ((retVal == null) && (returnType != Void.TYPE) && (returnType.isPrimitive())) {
/* 361 */       throw new AopInvocationException("Null return value from advice does not match primitive return type for: " + method);
/*     */     }
/*     */     
/* 364 */     return retVal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 371 */     return (this == other) || (((other instanceof CglibAopProxy)) && (AopProxyUtils.equalsInProxy(this.advised, ((CglibAopProxy)other).advised)));
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 376 */     return CglibAopProxy.class.hashCode() * 13 + this.advised.getTargetSource().hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class SerializableNoOp
/*     */     implements NoOp, Serializable
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class StaticUnadvisedInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     private final Object target;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public StaticUnadvisedInterceptor(Object target)
/*     */     {
/* 399 */       this.target = target;
/*     */     }
/*     */     
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable
/*     */     {
/* 404 */       Object retVal = methodProxy.invoke(this.target, args);
/* 405 */       return CglibAopProxy.processReturnType(proxy, this.target, method, retVal);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class StaticUnadvisedExposedInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     private final Object target;
/*     */     
/*     */ 
/*     */     public StaticUnadvisedExposedInterceptor(Object target)
/*     */     {
/* 419 */       this.target = target;
/*     */     }
/*     */     
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable
/*     */     {
/* 424 */       Object oldProxy = null;
/*     */       try {
/* 426 */         oldProxy = AopContext.setCurrentProxy(proxy);
/* 427 */         Object retVal = methodProxy.invoke(this.target, args);
/* 428 */         return CglibAopProxy.processReturnType(proxy, this.target, method, retVal);
/*     */       }
/*     */       finally {
/* 431 */         AopContext.setCurrentProxy(oldProxy);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class DynamicUnadvisedInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     private final TargetSource targetSource;
/*     */     
/*     */ 
/*     */ 
/*     */     public DynamicUnadvisedInterceptor(TargetSource targetSource)
/*     */     {
/* 447 */       this.targetSource = targetSource;
/*     */     }
/*     */     
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable
/*     */     {
/* 452 */       Object target = this.targetSource.getTarget();
/*     */       try {
/* 454 */         Object retVal = methodProxy.invoke(target, args);
/* 455 */         return CglibAopProxy.processReturnType(proxy, target, method, retVal);
/*     */       }
/*     */       finally {
/* 458 */         this.targetSource.releaseTarget(target);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class DynamicUnadvisedExposedInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     private final TargetSource targetSource;
/*     */     
/*     */ 
/*     */     public DynamicUnadvisedExposedInterceptor(TargetSource targetSource)
/*     */     {
/* 472 */       this.targetSource = targetSource;
/*     */     }
/*     */     
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable
/*     */     {
/* 477 */       Object oldProxy = null;
/* 478 */       Object target = this.targetSource.getTarget();
/*     */       try {
/* 480 */         oldProxy = AopContext.setCurrentProxy(proxy);
/* 481 */         Object retVal = methodProxy.invoke(target, args);
/* 482 */         return CglibAopProxy.processReturnType(proxy, target, method, retVal);
/*     */       }
/*     */       finally {
/* 485 */         AopContext.setCurrentProxy(oldProxy);
/* 486 */         this.targetSource.releaseTarget(target);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class StaticDispatcher
/*     */     implements Dispatcher, Serializable
/*     */   {
/*     */     private Object target;
/*     */     
/*     */ 
/*     */ 
/*     */     public StaticDispatcher(Object target)
/*     */     {
/* 502 */       this.target = target;
/*     */     }
/*     */     
/*     */     public Object loadObject()
/*     */     {
/* 507 */       return this.target;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class AdvisedDispatcher
/*     */     implements Dispatcher, Serializable
/*     */   {
/*     */     private final AdvisedSupport advised;
/*     */     
/*     */ 
/*     */     public AdvisedDispatcher(AdvisedSupport advised)
/*     */     {
/* 520 */       this.advised = advised;
/*     */     }
/*     */     
/*     */     public Object loadObject() throws Exception
/*     */     {
/* 525 */       return this.advised;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class EqualsInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     private final AdvisedSupport advised;
/*     */     
/*     */ 
/*     */     public EqualsInterceptor(AdvisedSupport advised)
/*     */     {
/* 539 */       this.advised = advised;
/*     */     }
/*     */     
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy)
/*     */     {
/* 544 */       Object other = args[0];
/* 545 */       if (proxy == other) {
/* 546 */         return Boolean.valueOf(true);
/*     */       }
/* 548 */       if ((other instanceof Factory)) {
/* 549 */         Callback callback = ((Factory)other).getCallback(5);
/* 550 */         if (!(callback instanceof EqualsInterceptor)) {
/* 551 */           return Boolean.valueOf(false);
/*     */         }
/* 553 */         AdvisedSupport otherAdvised = ((EqualsInterceptor)callback).advised;
/* 554 */         return Boolean.valueOf(AopProxyUtils.equalsInProxy(this.advised, otherAdvised));
/*     */       }
/*     */       
/* 557 */       return Boolean.valueOf(false);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class HashCodeInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     private final AdvisedSupport advised;
/*     */     
/*     */ 
/*     */ 
/*     */     public HashCodeInterceptor(AdvisedSupport advised)
/*     */     {
/* 572 */       this.advised = advised;
/*     */     }
/*     */     
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy)
/*     */     {
/* 577 */       return Integer.valueOf(CglibAopProxy.class.hashCode() * 13 + this.advised.getTargetSource().hashCode());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class FixedChainStaticTargetInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     private final List<Object> adviceChain;
/*     */     
/*     */     private final Object target;
/*     */     
/*     */     private final Class<?> targetClass;
/*     */     
/*     */ 
/*     */     public FixedChainStaticTargetInterceptor(List<Object> adviceChain, Object target, Class<?> targetClass)
/*     */     {
/* 594 */       this.adviceChain = adviceChain;
/* 595 */       this.target = target;
/* 596 */       this.targetClass = targetClass;
/*     */     }
/*     */     
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable
/*     */     {
/* 601 */       MethodInvocation invocation = new CglibAopProxy.CglibMethodInvocation(proxy, this.target, method, args, this.targetClass, this.adviceChain, methodProxy);
/*     */       
/*     */ 
/* 604 */       Object retVal = invocation.proceed();
/* 605 */       retVal = CglibAopProxy.processReturnType(proxy, this.target, method, retVal);
/* 606 */       return retVal;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class DynamicAdvisedInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     private final AdvisedSupport advised;
/*     */     
/*     */ 
/*     */     public DynamicAdvisedInterceptor(AdvisedSupport advised)
/*     */     {
/* 620 */       this.advised = advised;
/*     */     }
/*     */     
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable
/*     */     {
/* 625 */       Object oldProxy = null;
/* 626 */       boolean setProxyContext = false;
/* 627 */       Class<?> targetClass = null;
/* 628 */       Object target = null;
/*     */       try {
/* 630 */         if (this.advised.exposeProxy)
/*     */         {
/* 632 */           oldProxy = AopContext.setCurrentProxy(proxy);
/* 633 */           setProxyContext = true;
/*     */         }
/*     */         
/*     */ 
/* 637 */         target = getTarget();
/* 638 */         if (target != null) {
/* 639 */           targetClass = target.getClass();
/*     */         }
/* 641 */         List<Object> chain = this.advised.getInterceptorsAndDynamicInterceptionAdvice(method, targetClass);
/*     */         
/*     */         Object[] argsToUse;
/*     */         Object retVal;
/* 645 */         if ((chain.isEmpty()) && (Modifier.isPublic(method.getModifiers())))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 650 */           argsToUse = AopProxyUtils.adaptArgumentsIfNecessary(method, args);
/* 651 */           retVal = methodProxy.invoke(target, argsToUse);
/*     */         }
/*     */         else
/*     */         {
/* 655 */           retVal = new CglibAopProxy.CglibMethodInvocation(proxy, target, method, args, targetClass, chain, methodProxy).proceed();
/*     */         }
/* 657 */         Object retVal = CglibAopProxy.processReturnType(proxy, target, method, retVal);
/* 658 */         return (Object[])retVal;
/*     */       }
/*     */       finally {
/* 661 */         if (target != null) {
/* 662 */           releaseTarget(target);
/*     */         }
/* 664 */         if (setProxyContext)
/*     */         {
/* 666 */           AopContext.setCurrentProxy(oldProxy);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean equals(Object other)
/*     */     {
/* 673 */       if (this != other) if (!(other instanceof DynamicAdvisedInterceptor)) break label33;
/*     */       label33:
/* 675 */       return this.advised.equals(((DynamicAdvisedInterceptor)other).advised);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 683 */       return this.advised.hashCode();
/*     */     }
/*     */     
/*     */     protected Object getTarget() throws Exception {
/* 687 */       return this.advised.getTargetSource().getTarget();
/*     */     }
/*     */     
/*     */     protected void releaseTarget(Object target) throws Exception {
/* 691 */       this.advised.getTargetSource().releaseTarget(target);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class CglibMethodInvocation
/*     */     extends ReflectiveMethodInvocation
/*     */   {
/*     */     private final MethodProxy methodProxy;
/*     */     
/*     */ 
/*     */     private final boolean publicMethod;
/*     */     
/*     */ 
/*     */     public CglibMethodInvocation(Object proxy, Object target, Method method, Object[] arguments, Class<?> targetClass, List<Object> interceptorsAndDynamicMethodMatchers, MethodProxy methodProxy)
/*     */     {
/* 708 */       super(target, method, arguments, targetClass, interceptorsAndDynamicMethodMatchers);
/* 709 */       this.methodProxy = methodProxy;
/* 710 */       this.publicMethod = Modifier.isPublic(method.getModifiers());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected Object invokeJoinpoint()
/*     */       throws Throwable
/*     */     {
/* 719 */       if (this.publicMethod) {
/* 720 */         return this.methodProxy.invoke(this.target, this.arguments);
/*     */       }
/*     */       
/* 723 */       return super.invokeJoinpoint();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class ProxyCallbackFilter
/*     */     implements CallbackFilter
/*     */   {
/*     */     private final AdvisedSupport advised;
/*     */     
/*     */     private final Map<String, Integer> fixedInterceptorMap;
/*     */     
/*     */     private final int fixedInterceptorOffset;
/*     */     
/*     */ 
/*     */     public ProxyCallbackFilter(AdvisedSupport advised, Map<String, Integer> fixedInterceptorMap, int fixedInterceptorOffset)
/*     */     {
/* 741 */       this.advised = advised;
/* 742 */       this.fixedInterceptorMap = fixedInterceptorMap;
/* 743 */       this.fixedInterceptorOffset = fixedInterceptorOffset;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int accept(Method method)
/*     */     {
/* 784 */       if (AopUtils.isFinalizeMethod(method)) {
/* 785 */         CglibAopProxy.logger.debug("Found finalize() method - using NO_OVERRIDE");
/* 786 */         return 2;
/*     */       }
/* 788 */       if ((!this.advised.isOpaque()) && (method.getDeclaringClass().isInterface()) && 
/* 789 */         (method.getDeclaringClass().isAssignableFrom(Advised.class))) {
/* 790 */         if (CglibAopProxy.logger.isDebugEnabled()) {
/* 791 */           CglibAopProxy.logger.debug("Method is declared on Advised interface: " + method);
/*     */         }
/* 793 */         return 4;
/*     */       }
/*     */       
/* 796 */       if (AopUtils.isEqualsMethod(method)) {
/* 797 */         CglibAopProxy.logger.debug("Found 'equals' method: " + method);
/* 798 */         return 5;
/*     */       }
/*     */       
/* 801 */       if (AopUtils.isHashCodeMethod(method)) {
/* 802 */         CglibAopProxy.logger.debug("Found 'hashCode' method: " + method);
/* 803 */         return 6;
/*     */       }
/* 805 */       Class<?> targetClass = this.advised.getTargetClass();
/*     */       
/* 807 */       List<?> chain = this.advised.getInterceptorsAndDynamicInterceptionAdvice(method, targetClass);
/* 808 */       boolean haveAdvice = !chain.isEmpty();
/* 809 */       boolean exposeProxy = this.advised.isExposeProxy();
/* 810 */       boolean isStatic = this.advised.getTargetSource().isStatic();
/* 811 */       boolean isFrozen = this.advised.isFrozen();
/* 812 */       if ((haveAdvice) || (!isFrozen))
/*     */       {
/* 814 */         if (exposeProxy) {
/* 815 */           if (CglibAopProxy.logger.isDebugEnabled()) {
/* 816 */             CglibAopProxy.logger.debug("Must expose proxy on advised method: " + method);
/*     */           }
/* 818 */           return 0;
/*     */         }
/* 820 */         String key = method.toString();
/*     */         
/*     */ 
/* 823 */         if ((isStatic) && (isFrozen) && (this.fixedInterceptorMap.containsKey(key))) {
/* 824 */           if (CglibAopProxy.logger.isDebugEnabled()) {
/* 825 */             CglibAopProxy.logger.debug("Method has advice and optimisations are enabled: " + method);
/*     */           }
/*     */           
/* 828 */           int index = ((Integer)this.fixedInterceptorMap.get(key)).intValue();
/* 829 */           return index + this.fixedInterceptorOffset;
/*     */         }
/*     */         
/* 832 */         if (CglibAopProxy.logger.isDebugEnabled()) {
/* 833 */           CglibAopProxy.logger.debug("Unable to apply any optimisations to advised method: " + method);
/*     */         }
/* 835 */         return 0;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 845 */       if ((exposeProxy) || (!isStatic)) {
/* 846 */         return 1;
/*     */       }
/* 848 */       Class<?> returnType = method.getReturnType();
/* 849 */       if (targetClass == returnType) {
/* 850 */         if (CglibAopProxy.logger.isDebugEnabled()) {
/* 851 */           CglibAopProxy.logger.debug("Method " + method + "has return type same as target type (may return this) - using INVOKE_TARGET");
/*     */         }
/*     */         
/* 854 */         return 1;
/*     */       }
/* 856 */       if ((returnType.isPrimitive()) || (!returnType.isAssignableFrom(targetClass))) {
/* 857 */         if (CglibAopProxy.logger.isDebugEnabled()) {
/* 858 */           CglibAopProxy.logger.debug("Method " + method + " has return type that ensures this cannot be returned- using DISPATCH_TARGET");
/*     */         }
/*     */         
/* 861 */         return 3;
/*     */       }
/*     */       
/* 864 */       if (CglibAopProxy.logger.isDebugEnabled()) {
/* 865 */         CglibAopProxy.logger.debug("Method " + method + "has return type that is assignable from the target type (may return this) - " + "using INVOKE_TARGET");
/*     */       }
/*     */       
/*     */ 
/* 869 */       return 1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 876 */       if (this == other) {
/* 877 */         return true;
/*     */       }
/* 879 */       if (!(other instanceof ProxyCallbackFilter)) {
/* 880 */         return false;
/*     */       }
/* 882 */       ProxyCallbackFilter otherCallbackFilter = (ProxyCallbackFilter)other;
/* 883 */       AdvisedSupport otherAdvised = otherCallbackFilter.advised;
/* 884 */       if ((this.advised == null) || (otherAdvised == null)) {
/* 885 */         return false;
/*     */       }
/* 887 */       if (this.advised.isFrozen() != otherAdvised.isFrozen()) {
/* 888 */         return false;
/*     */       }
/* 890 */       if (this.advised.isExposeProxy() != otherAdvised.isExposeProxy()) {
/* 891 */         return false;
/*     */       }
/* 893 */       if (this.advised.getTargetSource().isStatic() != otherAdvised.getTargetSource().isStatic()) {
/* 894 */         return false;
/*     */       }
/* 896 */       if (!AopProxyUtils.equalsProxiedInterfaces(this.advised, otherAdvised)) {
/* 897 */         return false;
/*     */       }
/*     */       
/*     */ 
/* 901 */       Advisor[] thisAdvisors = this.advised.getAdvisors();
/* 902 */       Advisor[] thatAdvisors = otherAdvised.getAdvisors();
/* 903 */       if (thisAdvisors.length != thatAdvisors.length) {
/* 904 */         return false;
/*     */       }
/* 906 */       for (int i = 0; i < thisAdvisors.length; i++) {
/* 907 */         Advisor thisAdvisor = thisAdvisors[i];
/* 908 */         Advisor thatAdvisor = thatAdvisors[i];
/* 909 */         if (!equalsAdviceClasses(thisAdvisor, thatAdvisor)) {
/* 910 */           return false;
/*     */         }
/* 912 */         if (!equalsPointcuts(thisAdvisor, thatAdvisor)) {
/* 913 */           return false;
/*     */         }
/*     */       }
/* 916 */       return true;
/*     */     }
/*     */     
/*     */     private boolean equalsAdviceClasses(Advisor a, Advisor b) {
/* 920 */       Advice aa = a.getAdvice();
/* 921 */       Advice ba = b.getAdvice();
/* 922 */       if ((aa == null) || (ba == null)) {
/* 923 */         return aa == ba;
/*     */       }
/* 925 */       return aa.getClass() == ba.getClass();
/*     */     }
/*     */     
/*     */ 
/*     */     private boolean equalsPointcuts(Advisor a, Advisor b)
/*     */     {
/* 931 */       if ((a instanceof PointcutAdvisor)) if (!(b instanceof PointcutAdvisor)) break label42;
/*     */       label42:
/* 933 */       return ObjectUtils.nullSafeEquals(((PointcutAdvisor)a).getPointcut(), ((PointcutAdvisor)b).getPointcut());
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 938 */       int hashCode = 0;
/* 939 */       Advisor[] advisors = this.advised.getAdvisors();
/* 940 */       for (Advisor advisor : advisors) {
/* 941 */         Advice advice = advisor.getAdvice();
/* 942 */         if (advice != null) {
/* 943 */           hashCode = 13 * hashCode + advice.getClass().hashCode();
/*     */         }
/*     */       }
/* 946 */       hashCode = 13 * hashCode + (this.advised.isFrozen() ? 1 : 0);
/* 947 */       hashCode = 13 * hashCode + (this.advised.isExposeProxy() ? 1 : 0);
/* 948 */       hashCode = 13 * hashCode + (this.advised.isOptimize() ? 1 : 0);
/* 949 */       hashCode = 13 * hashCode + (this.advised.isOpaque() ? 1 : 0);
/* 950 */       return hashCode;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class ClassLoaderAwareUndeclaredThrowableStrategy
/*     */     extends UndeclaredThrowableStrategy
/*     */   {
/*     */     private final ClassLoader classLoader;
/*     */     
/*     */ 
/*     */ 
/*     */     public ClassLoaderAwareUndeclaredThrowableStrategy(ClassLoader classLoader)
/*     */     {
/* 965 */       super();
/* 966 */       this.classLoader = classLoader;
/*     */     }
/*     */     
/*     */     public byte[] generate(ClassGenerator cg) throws Exception
/*     */     {
/* 971 */       if (this.classLoader == null) {
/* 972 */         return super.generate(cg);
/*     */       }
/*     */       
/* 975 */       Thread currentThread = Thread.currentThread();
/*     */       try
/*     */       {
/* 978 */         threadContextClassLoader = currentThread.getContextClassLoader();
/*     */       }
/*     */       catch (Throwable ex) {
/*     */         ClassLoader threadContextClassLoader;
/* 982 */         return super.generate(cg);
/*     */       }
/*     */       ClassLoader threadContextClassLoader;
/* 985 */       boolean overrideClassLoader = !this.classLoader.equals(threadContextClassLoader);
/* 986 */       if (overrideClassLoader) {
/* 987 */         currentThread.setContextClassLoader(this.classLoader);
/*     */       }
/*     */       try {
/* 990 */         return super.generate(cg);
/*     */       }
/*     */       finally {
/* 993 */         if (overrideClassLoader)
/*     */         {
/* 995 */           currentThread.setContextClassLoader(threadContextClassLoader);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\springframework\aop\framework\CglibAopProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */