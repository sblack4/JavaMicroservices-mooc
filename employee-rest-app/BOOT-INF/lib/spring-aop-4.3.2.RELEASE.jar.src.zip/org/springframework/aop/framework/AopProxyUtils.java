/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Arrays;
/*     */ import org.springframework.aop.SpringProxy;
/*     */ import org.springframework.aop.TargetClassAware;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.aop.target.SingletonTargetSource;
/*     */ import org.springframework.core.DecoratingProxy;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AopProxyUtils
/*     */ {
/*     */   public static Class<?> ultimateTargetClass(Object candidate)
/*     */   {
/*  57 */     Assert.notNull(candidate, "Candidate object must not be null");
/*  58 */     Object current = candidate;
/*  59 */     Class<?> result = null;
/*  60 */     while ((current instanceof TargetClassAware)) {
/*  61 */       result = ((TargetClassAware)current).getTargetClass();
/*  62 */       Object nested = null;
/*  63 */       if ((current instanceof Advised)) {
/*  64 */         TargetSource targetSource = ((Advised)current).getTargetSource();
/*  65 */         if ((targetSource instanceof SingletonTargetSource)) {
/*  66 */           nested = ((SingletonTargetSource)targetSource).getTarget();
/*     */         }
/*     */       }
/*  69 */       current = nested;
/*     */     }
/*  71 */     if (result == null) {
/*  72 */       result = AopUtils.isCglibProxy(candidate) ? candidate.getClass().getSuperclass() : candidate.getClass();
/*     */     }
/*  74 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?>[] completeProxiedInterfaces(AdvisedSupport advised)
/*     */   {
/*  88 */     return completeProxiedInterfaces(advised, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Class<?>[] completeProxiedInterfaces(AdvisedSupport advised, boolean decoratingProxy)
/*     */   {
/* 105 */     Class<?>[] specifiedInterfaces = advised.getProxiedInterfaces();
/* 106 */     if (specifiedInterfaces.length == 0)
/*     */     {
/* 108 */       Class<?> targetClass = advised.getTargetClass();
/* 109 */       if (targetClass != null) {
/* 110 */         if (targetClass.isInterface()) {
/* 111 */           advised.setInterfaces(new Class[] { targetClass });
/*     */         }
/* 113 */         else if (Proxy.isProxyClass(targetClass)) {
/* 114 */           advised.setInterfaces(targetClass.getInterfaces());
/*     */         }
/* 116 */         specifiedInterfaces = advised.getProxiedInterfaces();
/*     */       }
/*     */     }
/* 119 */     boolean addSpringProxy = !advised.isInterfaceProxied(SpringProxy.class);
/* 120 */     boolean addAdvised = (!advised.isOpaque()) && (!advised.isInterfaceProxied(Advised.class));
/* 121 */     boolean addDecoratingProxy = (decoratingProxy) && (!advised.isInterfaceProxied(DecoratingProxy.class));
/* 122 */     int nonUserIfcCount = 0;
/* 123 */     if (addSpringProxy) {
/* 124 */       nonUserIfcCount++;
/*     */     }
/* 126 */     if (addAdvised) {
/* 127 */       nonUserIfcCount++;
/*     */     }
/* 129 */     if (addDecoratingProxy) {
/* 130 */       nonUserIfcCount++;
/*     */     }
/* 132 */     Class<?>[] proxiedInterfaces = new Class[specifiedInterfaces.length + nonUserIfcCount];
/* 133 */     System.arraycopy(specifiedInterfaces, 0, proxiedInterfaces, 0, specifiedInterfaces.length);
/* 134 */     int index = specifiedInterfaces.length;
/* 135 */     if (addSpringProxy) {
/* 136 */       proxiedInterfaces[index] = SpringProxy.class;
/* 137 */       index++;
/*     */     }
/* 139 */     if (addAdvised) {
/* 140 */       proxiedInterfaces[index] = Advised.class;
/* 141 */       index++;
/*     */     }
/* 143 */     if (addDecoratingProxy) {
/* 144 */       proxiedInterfaces[index] = DecoratingProxy.class;
/*     */     }
/* 146 */     return proxiedInterfaces;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?>[] proxiedUserInterfaces(Object proxy)
/*     */   {
/* 158 */     Class<?>[] proxyInterfaces = proxy.getClass().getInterfaces();
/* 159 */     int nonUserIfcCount = 0;
/* 160 */     if ((proxy instanceof SpringProxy)) {
/* 161 */       nonUserIfcCount++;
/*     */     }
/* 163 */     if ((proxy instanceof Advised)) {
/* 164 */       nonUserIfcCount++;
/*     */     }
/* 166 */     if ((proxy instanceof DecoratingProxy)) {
/* 167 */       nonUserIfcCount++;
/*     */     }
/* 169 */     Class<?>[] userInterfaces = new Class[proxyInterfaces.length - nonUserIfcCount];
/* 170 */     System.arraycopy(proxyInterfaces, 0, userInterfaces, 0, userInterfaces.length);
/* 171 */     Assert.notEmpty(userInterfaces, "JDK proxy must implement one or more interfaces");
/* 172 */     return userInterfaces;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean equalsInProxy(AdvisedSupport a, AdvisedSupport b)
/*     */   {
/* 182 */     return (a == b) || ((equalsProxiedInterfaces(a, b)) && (equalsAdvisors(a, b)) && (a.getTargetSource().equals(b.getTargetSource())));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean equalsProxiedInterfaces(AdvisedSupport a, AdvisedSupport b)
/*     */   {
/* 189 */     return Arrays.equals(a.getProxiedInterfaces(), b.getProxiedInterfaces());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean equalsAdvisors(AdvisedSupport a, AdvisedSupport b)
/*     */   {
/* 196 */     return Arrays.equals(a.getAdvisors(), b.getAdvisors());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Object[] adaptArgumentsIfNecessary(Method method, Object... arguments)
/*     */   {
/* 210 */     if ((method.isVarArgs()) && (!ObjectUtils.isEmpty(arguments))) {
/* 211 */       Class<?>[] paramTypes = method.getParameterTypes();
/* 212 */       if (paramTypes.length == arguments.length) {
/* 213 */         int varargIndex = paramTypes.length - 1;
/* 214 */         Class<?> varargType = paramTypes[varargIndex];
/* 215 */         if (varargType.isArray()) {
/* 216 */           Object varargArray = arguments[varargIndex];
/* 217 */           if (((varargArray instanceof Object[])) && (!varargType.isInstance(varargArray))) {
/* 218 */             Object[] newArguments = new Object[arguments.length];
/* 219 */             System.arraycopy(arguments, 0, newArguments, 0, varargIndex);
/* 220 */             Class<?> targetElementType = varargType.getComponentType();
/* 221 */             int varargLength = Array.getLength(varargArray);
/* 222 */             Object newVarargArray = Array.newInstance(targetElementType, varargLength);
/* 223 */             System.arraycopy(varargArray, 0, newVarargArray, 0, varargLength);
/* 224 */             newArguments[varargIndex] = newVarargArray;
/* 225 */             return newArguments;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 230 */     return arguments;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\springframework\aop\framework\AopProxyUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */