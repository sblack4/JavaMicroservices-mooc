/*    */ package org.springframework.aop.aspectj.annotation;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LazySingletonAspectInstanceFactoryDecorator
/*    */   implements MetadataAwareAspectInstanceFactory, Serializable
/*    */ {
/*    */   private final MetadataAwareAspectInstanceFactory maaif;
/*    */   private volatile Object materialized;
/*    */   
/*    */   public LazySingletonAspectInstanceFactoryDecorator(MetadataAwareAspectInstanceFactory maaif)
/*    */   {
/* 43 */     Assert.notNull(maaif, "AspectInstanceFactory must not be null");
/* 44 */     this.maaif = maaif;
/*    */   }
/*    */   
/*    */ 
/*    */   public Object getAspectInstance()
/*    */   {
/* 50 */     if (this.materialized == null) {
/* 51 */       synchronized (this.maaif.getAspectCreationMutex()) {
/* 52 */         if (this.materialized == null) {
/* 53 */           this.materialized = this.maaif.getAspectInstance();
/*    */         }
/*    */       }
/*    */     }
/* 57 */     return this.materialized;
/*    */   }
/*    */   
/*    */   public boolean isMaterialized() {
/* 61 */     return this.materialized != null;
/*    */   }
/*    */   
/*    */   public ClassLoader getAspectClassLoader()
/*    */   {
/* 66 */     return this.maaif.getAspectClassLoader();
/*    */   }
/*    */   
/*    */   public AspectMetadata getAspectMetadata()
/*    */   {
/* 71 */     return this.maaif.getAspectMetadata();
/*    */   }
/*    */   
/*    */   public Object getAspectCreationMutex()
/*    */   {
/* 76 */     return this.maaif.getAspectCreationMutex();
/*    */   }
/*    */   
/*    */   public int getOrder()
/*    */   {
/* 81 */     return this.maaif.getOrder();
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 87 */     return "LazySingletonAspectInstanceFactoryDecorator: decorating " + this.maaif;
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\springframework\aop\aspectj\annotation\LazySingletonAspectInstanceFactoryDecorator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */