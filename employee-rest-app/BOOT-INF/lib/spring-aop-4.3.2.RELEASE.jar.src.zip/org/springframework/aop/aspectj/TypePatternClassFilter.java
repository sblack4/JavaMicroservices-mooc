/*     */ package org.springframework.aop.aspectj;
/*     */ 
/*     */ import org.aspectj.weaver.tools.PointcutParser;
/*     */ import org.aspectj.weaver.tools.TypePatternMatcher;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypePatternClassFilter
/*     */   implements ClassFilter
/*     */ {
/*     */   private String typePattern;
/*     */   private TypePatternMatcher aspectJTypePatternMatcher;
/*     */   
/*     */   public TypePatternClassFilter() {}
/*     */   
/*     */   public TypePatternClassFilter(String typePattern)
/*     */   {
/*  57 */     setTypePattern(typePattern);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTypePattern(String typePattern)
/*     */   {
/*  79 */     Assert.notNull(typePattern);
/*  80 */     this.typePattern = typePattern;
/*     */     
/*     */ 
/*  83 */     this.aspectJTypePatternMatcher = PointcutParser.getPointcutParserSupportingAllPrimitivesAndUsingContextClassloaderForResolution().parseTypePattern(replaceBooleanOperators(typePattern));
/*     */   }
/*     */   
/*     */   public String getTypePattern() {
/*  87 */     return this.typePattern;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matches(Class<?> clazz)
/*     */   {
/*  98 */     if (this.aspectJTypePatternMatcher == null) {
/*  99 */       throw new IllegalStateException("No 'typePattern' has been set via ctor/setter.");
/*     */     }
/* 101 */     return this.aspectJTypePatternMatcher.matches(clazz);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String replaceBooleanOperators(String pcExpr)
/*     */   {
/* 111 */     pcExpr = StringUtils.replace(pcExpr, " and ", " && ");
/* 112 */     pcExpr = StringUtils.replace(pcExpr, " or ", " || ");
/* 113 */     pcExpr = StringUtils.replace(pcExpr, " not ", " ! ");
/* 114 */     return pcExpr;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\springframework\aop\aspectj\TypePatternClassFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */