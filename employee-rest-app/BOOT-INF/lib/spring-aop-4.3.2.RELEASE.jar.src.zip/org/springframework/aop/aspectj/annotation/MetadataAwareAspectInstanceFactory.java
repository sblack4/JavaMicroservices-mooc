package org.springframework.aop.aspectj.annotation;

import org.springframework.aop.aspectj.AspectInstanceFactory;

public abstract interface MetadataAwareAspectInstanceFactory
  extends AspectInstanceFactory
{
  public abstract AspectMetadata getAspectMetadata();
  
  public abstract Object getAspectCreationMutex();
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\springframework\aop\aspectj\annotation\MetadataAwareAspectInstanceFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */