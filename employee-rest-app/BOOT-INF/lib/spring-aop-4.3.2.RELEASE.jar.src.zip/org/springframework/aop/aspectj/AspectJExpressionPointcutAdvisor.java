/*    */ package org.springframework.aop.aspectj;
/*    */ 
/*    */ import org.springframework.aop.Pointcut;
/*    */ import org.springframework.aop.support.AbstractGenericPointcutAdvisor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AspectJExpressionPointcutAdvisor
/*    */   extends AbstractGenericPointcutAdvisor
/*    */ {
/* 31 */   private final AspectJExpressionPointcut pointcut = new AspectJExpressionPointcut();
/*    */   
/*    */ 
/*    */   public Pointcut getPointcut()
/*    */   {
/* 36 */     return this.pointcut;
/*    */   }
/*    */   
/*    */   public void setExpression(String expression) {
/* 40 */     this.pointcut.setExpression(expression);
/*    */   }
/*    */   
/*    */   public String getExpression() {
/* 44 */     return this.pointcut.getExpression();
/*    */   }
/*    */   
/*    */   public void setLocation(String location) {
/* 48 */     this.pointcut.setLocation(location);
/*    */   }
/*    */   
/*    */   public String getLocation() {
/* 52 */     return this.pointcut.getLocation();
/*    */   }
/*    */   
/*    */   public void setParameterTypes(Class<?>[] types) {
/* 56 */     this.pointcut.setParameterTypes(types);
/*    */   }
/*    */   
/*    */   public void setParameterNames(String... names) {
/* 60 */     this.pointcut.setParameterNames(names);
/*    */   }
/*    */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\springframework\aop\aspectj\AspectJExpressionPointcutAdvisor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */