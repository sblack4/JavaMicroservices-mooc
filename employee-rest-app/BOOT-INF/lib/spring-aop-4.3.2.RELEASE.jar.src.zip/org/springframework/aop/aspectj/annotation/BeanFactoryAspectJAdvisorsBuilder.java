/*     */ package org.springframework.aop.aspectj.annotation;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.aspectj.lang.reflect.AjType;
/*     */ import org.aspectj.lang.reflect.PerClause;
/*     */ import org.aspectj.lang.reflect.PerClauseKind;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanFactoryAspectJAdvisorsBuilder
/*     */ {
/*     */   private final ListableBeanFactory beanFactory;
/*     */   private final AspectJAdvisorFactory advisorFactory;
/*     */   private List<String> aspectBeanNames;
/*  48 */   private final Map<String, List<Advisor>> advisorsCache = new HashMap();
/*     */   
/*  50 */   private final Map<String, MetadataAwareAspectInstanceFactory> aspectFactoryCache = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BeanFactoryAspectJAdvisorsBuilder(ListableBeanFactory beanFactory)
/*     */   {
/*  59 */     this(beanFactory, new ReflectiveAspectJAdvisorFactory());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BeanFactoryAspectJAdvisorsBuilder(ListableBeanFactory beanFactory, AspectJAdvisorFactory advisorFactory)
/*     */   {
/*  68 */     Assert.notNull(beanFactory, "ListableBeanFactory must not be null");
/*  69 */     Assert.notNull(advisorFactory, "AspectJAdvisorFactory must not be null");
/*  70 */     this.beanFactory = beanFactory;
/*  71 */     this.advisorFactory = advisorFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Advisor> buildAspectJAdvisors()
/*     */   {
/*  83 */     List<String> aspectNames = null;
/*     */     List<Advisor> advisors;
/*  85 */     synchronized (this) {
/*  86 */       aspectNames = this.aspectBeanNames;
/*  87 */       if (aspectNames == null) {
/*  88 */         advisors = new LinkedList();
/*  89 */         aspectNames = new LinkedList();
/*     */         
/*  91 */         String[] beanNames = BeanFactoryUtils.beanNamesForTypeIncludingAncestors(this.beanFactory, Object.class, true, false);
/*  92 */         for (String beanName : beanNames)
/*  93 */           if (isEligibleBean(beanName))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */             Class<?> beanType = this.beanFactory.getType(beanName);
/* 100 */             if (beanType != null)
/*     */             {
/*     */ 
/* 103 */               if (this.advisorFactory.isAspect(beanType)) {
/* 104 */                 aspectNames.add(beanName);
/* 105 */                 AspectMetadata amd = new AspectMetadata(beanType, beanName);
/* 106 */                 if (amd.getAjType().getPerClause().getKind() == PerClauseKind.SINGLETON) {
/* 107 */                   MetadataAwareAspectInstanceFactory factory = new BeanFactoryAspectInstanceFactory(this.beanFactory, beanName);
/*     */                   
/* 109 */                   List<Advisor> classAdvisors = this.advisorFactory.getAdvisors(factory);
/* 110 */                   if (this.beanFactory.isSingleton(beanName)) {
/* 111 */                     this.advisorsCache.put(beanName, classAdvisors);
/*     */                   }
/*     */                   else {
/* 114 */                     this.aspectFactoryCache.put(beanName, factory);
/*     */                   }
/* 116 */                   advisors.addAll(classAdvisors);
/*     */                 }
/*     */                 else
/*     */                 {
/* 120 */                   if (this.beanFactory.isSingleton(beanName)) {
/* 121 */                     throw new IllegalArgumentException("Bean with name '" + beanName + "' is a singleton, but aspect instantiation model is not singleton");
/*     */                   }
/*     */                   
/* 124 */                   MetadataAwareAspectInstanceFactory factory = new PrototypeAspectInstanceFactory(this.beanFactory, beanName);
/*     */                   
/* 126 */                   this.aspectFactoryCache.put(beanName, factory);
/* 127 */                   advisors.addAll(this.advisorFactory.getAdvisors(factory));
/*     */                 }
/*     */               } }
/*     */           }
/* 131 */         this.aspectBeanNames = aspectNames;
/* 132 */         return advisors;
/*     */       }
/*     */     }
/*     */     
/* 136 */     if (aspectNames.isEmpty()) {
/* 137 */       return Collections.emptyList();
/*     */     }
/* 139 */     List<Advisor> advisors = new LinkedList();
/* 140 */     for (String aspectName : aspectNames) {
/* 141 */       Object cachedAdvisors = (List)this.advisorsCache.get(aspectName);
/* 142 */       if (cachedAdvisors != null) {
/* 143 */         advisors.addAll((Collection)cachedAdvisors);
/*     */       }
/*     */       else {
/* 146 */         MetadataAwareAspectInstanceFactory factory = (MetadataAwareAspectInstanceFactory)this.aspectFactoryCache.get(aspectName);
/* 147 */         advisors.addAll(this.advisorFactory.getAdvisors(factory));
/*     */       }
/*     */     }
/* 150 */     return advisors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isEligibleBean(String beanName)
/*     */   {
/* 159 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\springframework\aop\aspectj\annotation\BeanFactoryAspectJAdvisorsBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */