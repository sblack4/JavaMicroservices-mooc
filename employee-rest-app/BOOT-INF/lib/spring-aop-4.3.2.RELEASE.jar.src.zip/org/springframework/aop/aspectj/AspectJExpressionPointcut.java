/*     */ package org.springframework.aop.aspectj;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.aspectj.weaver.BCException;
/*     */ import org.aspectj.weaver.patterns.NamePattern;
/*     */ import org.aspectj.weaver.reflect.ReflectionWorld.ReflectionWorldException;
/*     */ import org.aspectj.weaver.reflect.ShadowMatchImpl;
/*     */ import org.aspectj.weaver.tools.ContextBasedMatcher;
/*     */ import org.aspectj.weaver.tools.JoinPointMatch;
/*     */ import org.aspectj.weaver.tools.MatchingContext;
/*     */ import org.aspectj.weaver.tools.PointcutDesignatorHandler;
/*     */ import org.aspectj.weaver.tools.PointcutExpression;
/*     */ import org.aspectj.weaver.tools.PointcutParameter;
/*     */ import org.aspectj.weaver.tools.PointcutParser;
/*     */ import org.aspectj.weaver.tools.PointcutPrimitive;
/*     */ import org.aspectj.weaver.tools.ShadowMatch;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.IntroductionAwareMethodMatcher;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.ProxyMethodInvocation;
/*     */ import org.springframework.aop.framework.autoproxy.ProxyCreationContext;
/*     */ import org.springframework.aop.interceptor.ExposeInvocationInterceptor;
/*     */ import org.springframework.aop.support.AbstractExpressionPointcut;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AspectJExpressionPointcut
/*     */   extends AbstractExpressionPointcut
/*     */   implements ClassFilter, IntroductionAwareMethodMatcher, BeanFactoryAware
/*     */ {
/*  85 */   private static final Set<PointcutPrimitive> SUPPORTED_PRIMITIVES = new HashSet();
/*     */   
/*     */   static {
/*  88 */     SUPPORTED_PRIMITIVES.add(PointcutPrimitive.EXECUTION);
/*  89 */     SUPPORTED_PRIMITIVES.add(PointcutPrimitive.ARGS);
/*  90 */     SUPPORTED_PRIMITIVES.add(PointcutPrimitive.REFERENCE);
/*  91 */     SUPPORTED_PRIMITIVES.add(PointcutPrimitive.THIS);
/*  92 */     SUPPORTED_PRIMITIVES.add(PointcutPrimitive.TARGET);
/*  93 */     SUPPORTED_PRIMITIVES.add(PointcutPrimitive.WITHIN);
/*  94 */     SUPPORTED_PRIMITIVES.add(PointcutPrimitive.AT_ANNOTATION);
/*  95 */     SUPPORTED_PRIMITIVES.add(PointcutPrimitive.AT_WITHIN);
/*  96 */     SUPPORTED_PRIMITIVES.add(PointcutPrimitive.AT_ARGS);
/*  97 */     SUPPORTED_PRIMITIVES.add(PointcutPrimitive.AT_TARGET);
/*     */   }
/*     */   
/*     */ 
/* 101 */   private static final Log logger = LogFactory.getLog(AspectJExpressionPointcut.class);
/*     */   
/*     */   private Class<?> pointcutDeclarationScope;
/*     */   
/* 105 */   private String[] pointcutParameterNames = new String[0];
/*     */   
/* 107 */   private Class<?>[] pointcutParameterTypes = new Class[0];
/*     */   
/*     */   private BeanFactory beanFactory;
/*     */   
/*     */   private transient ClassLoader pointcutClassLoader;
/*     */   
/*     */   private transient PointcutExpression pointcutExpression;
/*     */   
/* 115 */   private transient Map<Method, ShadowMatch> shadowMatchCache = new ConcurrentHashMap(32);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AspectJExpressionPointcut(Class<?> declarationScope, String[] paramNames, Class<?>[] paramTypes)
/*     */   {
/* 131 */     this.pointcutDeclarationScope = declarationScope;
/* 132 */     if (paramNames.length != paramTypes.length) {
/* 133 */       throw new IllegalStateException("Number of pointcut parameter names must match number of pointcut parameter types");
/*     */     }
/*     */     
/* 136 */     this.pointcutParameterNames = paramNames;
/* 137 */     this.pointcutParameterTypes = paramTypes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPointcutDeclarationScope(Class<?> pointcutDeclarationScope)
/*     */   {
/* 145 */     this.pointcutDeclarationScope = pointcutDeclarationScope;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setParameterNames(String... names)
/*     */   {
/* 152 */     this.pointcutParameterNames = names;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setParameterTypes(Class<?>... types)
/*     */   {
/* 159 */     this.pointcutParameterTypes = types;
/*     */   }
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/* 164 */     this.beanFactory = beanFactory;
/*     */   }
/*     */   
/*     */ 
/*     */   public ClassFilter getClassFilter()
/*     */   {
/* 170 */     checkReadyToMatch();
/* 171 */     return this;
/*     */   }
/*     */   
/*     */   public MethodMatcher getMethodMatcher()
/*     */   {
/* 176 */     checkReadyToMatch();
/* 177 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkReadyToMatch()
/*     */   {
/* 186 */     if (getExpression() == null) {
/* 187 */       throw new IllegalStateException("Must set property 'expression' before attempting to match");
/*     */     }
/* 189 */     if (this.pointcutExpression == null)
/*     */     {
/*     */ 
/* 192 */       this.pointcutClassLoader = ((this.beanFactory instanceof ConfigurableBeanFactory) ? ((ConfigurableBeanFactory)this.beanFactory).getBeanClassLoader() : ClassUtils.getDefaultClassLoader());
/* 193 */       this.pointcutExpression = buildPointcutExpression(this.pointcutClassLoader);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private PointcutExpression buildPointcutExpression(ClassLoader classLoader)
/*     */   {
/* 201 */     PointcutParser parser = initializePointcutParser(classLoader);
/* 202 */     PointcutParameter[] pointcutParameters = new PointcutParameter[this.pointcutParameterNames.length];
/* 203 */     for (int i = 0; i < pointcutParameters.length; i++) {
/* 204 */       pointcutParameters[i] = parser.createPointcutParameter(this.pointcutParameterNames[i], this.pointcutParameterTypes[i]);
/*     */     }
/*     */     
/* 207 */     return parser.parsePointcutExpression(replaceBooleanOperators(getExpression()), this.pointcutDeclarationScope, pointcutParameters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private PointcutParser initializePointcutParser(ClassLoader cl)
/*     */   {
/* 216 */     PointcutParser parser = PointcutParser.getPointcutParserSupportingSpecifiedPrimitivesAndUsingSpecifiedClassLoaderForResolution(SUPPORTED_PRIMITIVES, cl);
/*     */     
/* 218 */     parser.registerPointcutDesignatorHandler(new BeanNamePointcutDesignatorHandler(null));
/* 219 */     return parser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String replaceBooleanOperators(String pcExpr)
/*     */   {
/* 230 */     String result = StringUtils.replace(pcExpr, " and ", " && ");
/* 231 */     result = StringUtils.replace(result, " or ", " || ");
/* 232 */     result = StringUtils.replace(result, " not ", " ! ");
/* 233 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PointcutExpression getPointcutExpression()
/*     */   {
/* 241 */     checkReadyToMatch();
/* 242 */     return this.pointcutExpression;
/*     */   }
/*     */   
/*     */   public boolean matches(Class<?> targetClass)
/*     */   {
/* 247 */     checkReadyToMatch();
/*     */     try
/*     */     {
/* 250 */       return this.pointcutExpression.couldMatchJoinPointsInType(targetClass);
/*     */     }
/*     */     catch (ReflectionWorld.ReflectionWorldException ex) {
/* 253 */       logger.debug("PointcutExpression matching rejected target class - trying fallback expression", ex);
/*     */       
/* 255 */       PointcutExpression fallbackExpression = getFallbackPointcutExpression(targetClass);
/* 256 */       if (fallbackExpression != null) {
/* 257 */         return fallbackExpression.couldMatchJoinPointsInType(targetClass);
/*     */       }
/*     */     }
/*     */     catch (BCException ex)
/*     */     {
/* 262 */       logger.debug("PointcutExpression matching rejected target class", ex);
/*     */     }
/* 264 */     return false;
/*     */   }
/*     */   
/*     */   public boolean matches(Method method, Class<?> targetClass, boolean beanHasIntroductions)
/*     */   {
/* 269 */     checkReadyToMatch();
/* 270 */     Method targetMethod = AopUtils.getMostSpecificMethod(method, targetClass);
/* 271 */     ShadowMatch shadowMatch = getShadowMatch(targetMethod, method);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 276 */     if (shadowMatch.alwaysMatches()) {
/* 277 */       return true;
/*     */     }
/* 279 */     if (shadowMatch.neverMatches()) {
/* 280 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 284 */     if (beanHasIntroductions) {
/* 285 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 291 */     RuntimeTestWalker walker = getRuntimeTestWalker(shadowMatch);
/* 292 */     return (!walker.testsSubtypeSensitiveVars()) || (walker.testTargetInstanceOfResidue(targetClass));
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean matches(Method method, Class<?> targetClass)
/*     */   {
/* 298 */     return matches(method, targetClass, false);
/*     */   }
/*     */   
/*     */   public boolean isRuntime()
/*     */   {
/* 303 */     checkReadyToMatch();
/* 304 */     return this.pointcutExpression.mayNeedDynamicTest();
/*     */   }
/*     */   
/*     */   public boolean matches(Method method, Class<?> targetClass, Object... args)
/*     */   {
/* 309 */     checkReadyToMatch();
/* 310 */     ShadowMatch shadowMatch = getShadowMatch(AopUtils.getMostSpecificMethod(method, targetClass), method);
/* 311 */     ShadowMatch originalShadowMatch = getShadowMatch(method, method);
/*     */     
/*     */ 
/*     */ 
/* 315 */     ProxyMethodInvocation pmi = null;
/* 316 */     Object targetObject = null;
/* 317 */     Object thisObject = null;
/*     */     try {
/* 319 */       MethodInvocation mi = ExposeInvocationInterceptor.currentInvocation();
/* 320 */       targetObject = mi.getThis();
/* 321 */       if (!(mi instanceof ProxyMethodInvocation)) {
/* 322 */         throw new IllegalStateException("MethodInvocation is not a Spring ProxyMethodInvocation: " + mi);
/*     */       }
/* 324 */       pmi = (ProxyMethodInvocation)mi;
/* 325 */       thisObject = pmi.getProxy();
/*     */ 
/*     */     }
/*     */     catch (IllegalStateException ex)
/*     */     {
/* 330 */       if (logger.isDebugEnabled()) {
/* 331 */         logger.debug("Could not access current invocation - matching with limited context: " + ex);
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 336 */       JoinPointMatch joinPointMatch = shadowMatch.matchesJoinPoint(thisObject, targetObject, args);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 346 */       if (pmi != null) {
/* 347 */         RuntimeTestWalker originalMethodResidueTest = getRuntimeTestWalker(originalShadowMatch);
/* 348 */         if (!originalMethodResidueTest.testThisInstanceOfResidue(thisObject.getClass())) {
/* 349 */           return false;
/*     */         }
/* 351 */         if (joinPointMatch.matches()) {
/* 352 */           bindParameters(pmi, joinPointMatch);
/*     */         }
/*     */       }
/*     */       
/* 356 */       return joinPointMatch.matches();
/*     */     }
/*     */     catch (Throwable ex) {
/* 359 */       if (logger.isDebugEnabled()) {
/* 360 */         logger.debug("Failed to evaluate join point for arguments " + Arrays.asList(args) + " - falling back to non-match", ex);
/*     */       }
/*     */     }
/* 363 */     return false;
/*     */   }
/*     */   
/*     */   protected String getCurrentProxiedBeanName()
/*     */   {
/* 368 */     return ProxyCreationContext.getCurrentProxiedBeanName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private PointcutExpression getFallbackPointcutExpression(Class<?> targetClass)
/*     */   {
/*     */     try
/*     */     {
/* 377 */       ClassLoader classLoader = targetClass.getClassLoader();
/* 378 */       if ((classLoader != null) && (classLoader != this.pointcutClassLoader)) {
/* 379 */         return buildPointcutExpression(classLoader);
/*     */       }
/*     */     }
/*     */     catch (Throwable ex) {
/* 383 */       logger.debug("Failed to create fallback PointcutExpression", ex);
/*     */     }
/* 385 */     return null;
/*     */   }
/*     */   
/*     */   private RuntimeTestWalker getRuntimeTestWalker(ShadowMatch shadowMatch) {
/* 389 */     if ((shadowMatch instanceof DefensiveShadowMatch)) {
/* 390 */       return new RuntimeTestWalker(((DefensiveShadowMatch)shadowMatch).primary);
/*     */     }
/* 392 */     return new RuntimeTestWalker(shadowMatch);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void bindParameters(ProxyMethodInvocation invocation, JoinPointMatch jpm)
/*     */   {
/* 402 */     invocation.setUserAttribute(getExpression(), jpm);
/*     */   }
/*     */   
/*     */   private ShadowMatch getShadowMatch(Method targetMethod, Method originalMethod)
/*     */   {
/* 407 */     ShadowMatch shadowMatch = (ShadowMatch)this.shadowMatchCache.get(targetMethod);
/* 408 */     if (shadowMatch == null) {
/* 409 */       synchronized (this.shadowMatchCache)
/*     */       {
/* 411 */         PointcutExpression fallbackExpression = null;
/* 412 */         Method methodToMatch = targetMethod;
/* 413 */         shadowMatch = (ShadowMatch)this.shadowMatchCache.get(targetMethod);
/* 414 */         if (shadowMatch == null) {
/*     */           try {
/* 416 */             shadowMatch = this.pointcutExpression.matchesMethodExecution(methodToMatch);
/*     */           }
/*     */           catch (ReflectionWorld.ReflectionWorldException ex)
/*     */           {
/*     */             try
/*     */             {
/* 422 */               fallbackExpression = getFallbackPointcutExpression(methodToMatch.getDeclaringClass());
/* 423 */               if (fallbackExpression != null) {
/* 424 */                 shadowMatch = fallbackExpression.matchesMethodExecution(methodToMatch);
/*     */               }
/*     */             }
/*     */             catch (ReflectionWorld.ReflectionWorldException ex2) {
/* 428 */               fallbackExpression = null;
/*     */             }
/*     */           }
/* 431 */           if ((shadowMatch == null) && (targetMethod != originalMethod)) {
/* 432 */             methodToMatch = originalMethod;
/*     */             try {
/* 434 */               shadowMatch = this.pointcutExpression.matchesMethodExecution(methodToMatch);
/*     */             }
/*     */             catch (ReflectionWorld.ReflectionWorldException ex3)
/*     */             {
/*     */               try
/*     */               {
/* 440 */                 fallbackExpression = getFallbackPointcutExpression(methodToMatch.getDeclaringClass());
/* 441 */                 if (fallbackExpression != null) {
/* 442 */                   shadowMatch = fallbackExpression.matchesMethodExecution(methodToMatch);
/*     */                 }
/*     */               }
/*     */               catch (ReflectionWorld.ReflectionWorldException ex4) {
/* 446 */                 fallbackExpression = null;
/*     */               }
/*     */             }
/*     */           }
/* 450 */           if (shadowMatch == null) {
/* 451 */             shadowMatch = new ShadowMatchImpl(org.aspectj.util.FuzzyBoolean.NO, null, null, null);
/*     */           }
/* 453 */           else if ((shadowMatch.maybeMatches()) && (fallbackExpression != null))
/*     */           {
/* 455 */             shadowMatch = new DefensiveShadowMatch(shadowMatch, fallbackExpression.matchesMethodExecution(methodToMatch));
/*     */           }
/* 457 */           this.shadowMatchCache.put(targetMethod, shadowMatch);
/*     */         }
/*     */       }
/*     */     }
/* 461 */     return shadowMatch;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 467 */     if (this == other) {
/* 468 */       return true;
/*     */     }
/* 470 */     if (!(other instanceof AspectJExpressionPointcut)) {
/* 471 */       return false;
/*     */     }
/* 473 */     AspectJExpressionPointcut otherPc = (AspectJExpressionPointcut)other;
/*     */     
/*     */ 
/*     */ 
/* 477 */     return (ObjectUtils.nullSafeEquals(getExpression(), otherPc.getExpression())) && (ObjectUtils.nullSafeEquals(this.pointcutDeclarationScope, otherPc.pointcutDeclarationScope)) && (ObjectUtils.nullSafeEquals(this.pointcutParameterNames, otherPc.pointcutParameterNames)) && (ObjectUtils.nullSafeEquals(this.pointcutParameterTypes, otherPc.pointcutParameterTypes));
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 482 */     int hashCode = ObjectUtils.nullSafeHashCode(getExpression());
/* 483 */     hashCode = 31 * hashCode + ObjectUtils.nullSafeHashCode(this.pointcutDeclarationScope);
/* 484 */     hashCode = 31 * hashCode + ObjectUtils.nullSafeHashCode(this.pointcutParameterNames);
/* 485 */     hashCode = 31 * hashCode + ObjectUtils.nullSafeHashCode(this.pointcutParameterTypes);
/* 486 */     return hashCode;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 491 */     StringBuilder sb = new StringBuilder();
/* 492 */     sb.append("AspectJExpressionPointcut: ");
/* 493 */     if ((this.pointcutParameterNames != null) && (this.pointcutParameterTypes != null)) {
/* 494 */       sb.append("(");
/* 495 */       for (int i = 0; i < this.pointcutParameterTypes.length; i++) {
/* 496 */         sb.append(this.pointcutParameterTypes[i].getName());
/* 497 */         sb.append(" ");
/* 498 */         sb.append(this.pointcutParameterNames[i]);
/* 499 */         if (i + 1 < this.pointcutParameterTypes.length) {
/* 500 */           sb.append(", ");
/*     */         }
/*     */       }
/* 503 */       sb.append(")");
/*     */     }
/* 505 */     sb.append(" ");
/* 506 */     if (getExpression() != null) {
/* 507 */       sb.append(getExpression());
/*     */     }
/*     */     else {
/* 510 */       sb.append("<pointcut expression not set>");
/*     */     }
/* 512 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class BeanNamePointcutDesignatorHandler
/*     */     implements PointcutDesignatorHandler
/*     */   {
/*     */     private static final String BEAN_DESIGNATOR_NAME = "bean";
/*     */     
/*     */ 
/*     */ 
/*     */     private BeanNamePointcutDesignatorHandler() {}
/*     */     
/*     */ 
/*     */ 
/*     */     public String getDesignatorName()
/*     */     {
/* 530 */       return "bean";
/*     */     }
/*     */     
/*     */     public ContextBasedMatcher parse(String expression)
/*     */     {
/* 535 */       return new AspectJExpressionPointcut.BeanNameContextMatcher(AspectJExpressionPointcut.this, expression);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private class BeanNameContextMatcher
/*     */     implements ContextBasedMatcher
/*     */   {
/*     */     private final NamePattern expressionPattern;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public BeanNameContextMatcher(String expression)
/*     */     {
/* 552 */       this.expressionPattern = new NamePattern(expression);
/*     */     }
/*     */     
/*     */ 
/*     */     @Deprecated
/*     */     public boolean couldMatchJoinPointsInType(Class someClass)
/*     */     {
/* 559 */       return contextMatch(someClass) == org.aspectj.weaver.tools.FuzzyBoolean.YES;
/*     */     }
/*     */     
/*     */ 
/*     */     @Deprecated
/*     */     public boolean couldMatchJoinPointsInType(Class someClass, MatchingContext context)
/*     */     {
/* 566 */       return contextMatch(someClass) == org.aspectj.weaver.tools.FuzzyBoolean.YES;
/*     */     }
/*     */     
/*     */     public boolean matchesDynamically(MatchingContext context)
/*     */     {
/* 571 */       return true;
/*     */     }
/*     */     
/*     */     public org.aspectj.weaver.tools.FuzzyBoolean matchesStatically(MatchingContext context)
/*     */     {
/* 576 */       return contextMatch(null);
/*     */     }
/*     */     
/*     */     public boolean mayNeedDynamicTest()
/*     */     {
/* 581 */       return false;
/*     */     }
/*     */     
/*     */     private org.aspectj.weaver.tools.FuzzyBoolean contextMatch(Class<?> targetType) {
/* 585 */       String advisedBeanName = AspectJExpressionPointcut.this.getCurrentProxiedBeanName();
/* 586 */       if (advisedBeanName == null)
/*     */       {
/* 588 */         return org.aspectj.weaver.tools.FuzzyBoolean.MAYBE;
/*     */       }
/* 590 */       if (BeanFactoryUtils.isGeneratedBeanName(advisedBeanName)) {
/* 591 */         return org.aspectj.weaver.tools.FuzzyBoolean.NO;
/*     */       }
/* 593 */       if (targetType != null) {
/* 594 */         boolean isFactory = FactoryBean.class.isAssignableFrom(targetType);
/* 595 */         return org.aspectj.weaver.tools.FuzzyBoolean.fromBoolean(
/* 596 */           matchesBeanName(isFactory ? "&" + advisedBeanName : advisedBeanName));
/*     */       }
/*     */       
/* 599 */       return org.aspectj.weaver.tools.FuzzyBoolean.fromBoolean((matchesBeanName(advisedBeanName)) || 
/* 600 */         (matchesBeanName("&" + advisedBeanName)));
/*     */     }
/*     */     
/*     */     private boolean matchesBeanName(String advisedBeanName)
/*     */     {
/* 605 */       if (this.expressionPattern.matches(advisedBeanName)) {
/* 606 */         return true;
/*     */       }
/* 608 */       if (AspectJExpressionPointcut.this.beanFactory != null) {
/* 609 */         String[] aliases = AspectJExpressionPointcut.this.beanFactory.getAliases(advisedBeanName);
/* 610 */         for (String alias : aliases) {
/* 611 */           if (this.expressionPattern.matches(alias)) {
/* 612 */             return true;
/*     */           }
/*     */         }
/*     */       }
/* 616 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readObject(ObjectInputStream ois)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 627 */     ois.defaultReadObject();
/*     */     
/*     */ 
/*     */ 
/* 631 */     this.shadowMatchCache = new ConcurrentHashMap(32);
/*     */   }
/*     */   
/*     */   public AspectJExpressionPointcut() {}
/*     */   
/*     */   private static class DefensiveShadowMatch implements ShadowMatch
/*     */   {
/*     */     private final ShadowMatch primary;
/*     */     private final ShadowMatch other;
/*     */     
/*     */     public DefensiveShadowMatch(ShadowMatch primary, ShadowMatch other) {
/* 642 */       this.primary = primary;
/* 643 */       this.other = other;
/*     */     }
/*     */     
/*     */     public boolean alwaysMatches()
/*     */     {
/* 648 */       return this.primary.alwaysMatches();
/*     */     }
/*     */     
/*     */     public boolean maybeMatches()
/*     */     {
/* 653 */       return this.primary.maybeMatches();
/*     */     }
/*     */     
/*     */     public boolean neverMatches()
/*     */     {
/* 658 */       return this.primary.neverMatches();
/*     */     }
/*     */     
/*     */     public JoinPointMatch matchesJoinPoint(Object thisObject, Object targetObject, Object[] args)
/*     */     {
/*     */       try {
/* 664 */         return this.primary.matchesJoinPoint(thisObject, targetObject, args);
/*     */       }
/*     */       catch (ReflectionWorld.ReflectionWorldException ex) {}
/* 667 */       return this.other.matchesJoinPoint(thisObject, targetObject, args);
/*     */     }
/*     */     
/*     */ 
/*     */     public void setMatchingContext(MatchingContext aMatchContext)
/*     */     {
/* 673 */       this.primary.setMatchingContext(aMatchContext);
/* 674 */       this.other.setMatchingContext(aMatchContext);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\springframework\aop\aspectj\AspectJExpressionPointcut.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */