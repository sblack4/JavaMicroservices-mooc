/*     */ package org.springframework.aop.aspectj.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import org.aspectj.lang.annotation.Aspect;
/*     */ import org.aspectj.lang.reflect.AjType;
/*     */ import org.aspectj.lang.reflect.AjTypeSystem;
/*     */ import org.aspectj.lang.reflect.PerClause;
/*     */ import org.aspectj.lang.reflect.PerClauseKind;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.aspectj.AspectJExpressionPointcut;
/*     */ import org.springframework.aop.aspectj.TypePatternClassFilter;
/*     */ import org.springframework.aop.framework.AopConfigException;
/*     */ import org.springframework.aop.support.ComposablePointcut;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AspectMetadata
/*     */   implements Serializable
/*     */ {
/*     */   private final String aspectName;
/*     */   private final Class<?> aspectClass;
/*     */   private transient AjType<?> ajType;
/*     */   private final Pointcut perClausePointcut;
/*     */   
/*     */   public AspectMetadata(Class<?> aspectClass, String aspectName)
/*     */   {
/*  83 */     this.aspectName = aspectName;
/*     */     
/*  85 */     Class<?> currClass = aspectClass;
/*  86 */     AjType<?> ajType = null;
/*  87 */     while (currClass != Object.class) {
/*  88 */       AjType<?> ajTypeToCheck = AjTypeSystem.getAjType(currClass);
/*  89 */       if (ajTypeToCheck.isAspect()) {
/*  90 */         ajType = ajTypeToCheck;
/*  91 */         break;
/*     */       }
/*  93 */       currClass = currClass.getSuperclass();
/*     */     }
/*  95 */     if (ajType == null) {
/*  96 */       throw new IllegalArgumentException("Class '" + aspectClass.getName() + "' is not an @AspectJ aspect");
/*     */     }
/*  98 */     if (ajType.getDeclarePrecedence().length > 0) {
/*  99 */       throw new IllegalArgumentException("DeclarePrecendence not presently supported in Spring AOP");
/*     */     }
/* 101 */     this.aspectClass = ajType.getJavaClass();
/* 102 */     this.ajType = ajType;
/*     */     
/* 104 */     switch (this.ajType.getPerClause().getKind()) {
/*     */     case SINGLETON: 
/* 106 */       this.perClausePointcut = Pointcut.TRUE;
/* 107 */       return;
/*     */     case PERTARGET: case PERTHIS: 
/* 109 */       AspectJExpressionPointcut ajexp = new AspectJExpressionPointcut();
/* 110 */       ajexp.setLocation("@Aspect annotation on " + aspectClass.getName());
/* 111 */       ajexp.setExpression(findPerClause(aspectClass));
/* 112 */       this.perClausePointcut = ajexp;
/* 113 */       return;
/*     */     
/*     */     case PERTYPEWITHIN: 
/* 116 */       this.perClausePointcut = new ComposablePointcut(new TypePatternClassFilter(findPerClause(aspectClass)));
/* 117 */       return;
/*     */     }
/*     */     
/* 120 */     throw new AopConfigException("PerClause " + ajType.getPerClause().getKind() + " not supported by Spring AOP for " + aspectClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String findPerClause(Class<?> aspectClass)
/*     */   {
/* 130 */     String str = ((Aspect)aspectClass.getAnnotation(Aspect.class)).value();
/* 131 */     str = str.substring(str.indexOf("(") + 1);
/* 132 */     str = str.substring(0, str.length() - 1);
/* 133 */     return str;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AjType<?> getAjType()
/*     */   {
/* 141 */     return this.ajType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Class<?> getAspectClass()
/*     */   {
/* 148 */     return this.aspectClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getAspectName()
/*     */   {
/* 155 */     return this.aspectName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pointcut getPerClausePointcut()
/*     */   {
/* 163 */     return this.perClausePointcut;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isPerThisOrPerTarget()
/*     */   {
/* 170 */     PerClauseKind kind = getAjType().getPerClause().getKind();
/* 171 */     return (kind == PerClauseKind.PERTARGET) || (kind == PerClauseKind.PERTHIS);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isPerTypeWithin()
/*     */   {
/* 178 */     PerClauseKind kind = getAjType().getPerClause().getKind();
/* 179 */     return kind == PerClauseKind.PERTYPEWITHIN;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isLazilyInstantiated()
/*     */   {
/* 186 */     return (isPerThisOrPerTarget()) || (isPerTypeWithin());
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream inputStream) throws IOException, ClassNotFoundException
/*     */   {
/* 191 */     inputStream.defaultReadObject();
/* 192 */     this.ajType = AjTypeSystem.getAjType(this.aspectClass);
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\springframework\aop\aspectj\annotation\AspectMetadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */