package org.springframework.aop.aspectj;

import org.springframework.aop.PointcutAdvisor;

public abstract interface InstantiationModelAwarePointcutAdvisor
  extends PointcutAdvisor
{
  public abstract boolean isLazy();
  
  public abstract boolean isAdviceInstantiated();
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\springframework\aop\aspectj\InstantiationModelAwarePointcutAdvisor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */