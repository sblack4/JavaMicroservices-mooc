/*     */ package org.springframework.aop.aspectj;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.aspectj.lang.JoinPoint;
/*     */ import org.aspectj.lang.JoinPoint.StaticPart;
/*     */ import org.aspectj.lang.ProceedingJoinPoint;
/*     */ import org.aspectj.weaver.tools.PointcutParser;
/*     */ import org.aspectj.weaver.tools.PointcutPrimitive;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AspectJAdviceParameterNameDiscoverer
/*     */   implements ParameterNameDiscoverer
/*     */ {
/*     */   private static final String THIS_JOIN_POINT = "thisJoinPoint";
/*     */   private static final String THIS_JOIN_POINT_STATIC_PART = "thisJoinPointStaticPart";
/*     */   private static final int STEP_JOIN_POINT_BINDING = 1;
/*     */   private static final int STEP_THROWING_BINDING = 2;
/*     */   private static final int STEP_ANNOTATION_BINDING = 3;
/*     */   private static final int STEP_RETURNING_BINDING = 4;
/*     */   private static final int STEP_PRIMITIVE_ARGS_BINDING = 5;
/*     */   private static final int STEP_THIS_TARGET_ARGS_BINDING = 6;
/*     */   private static final int STEP_REFERENCE_PCUT_BINDING = 7;
/*     */   private static final int STEP_FINISHED = 8;
/* 133 */   private static final Set<String> singleValuedAnnotationPcds = new HashSet();
/* 134 */   private static final Set<String> nonReferencePointcutTokens = new HashSet();
/*     */   private boolean raiseExceptions;
/*     */   
/*     */   static {
/* 138 */     singleValuedAnnotationPcds.add("@this");
/* 139 */     singleValuedAnnotationPcds.add("@target");
/* 140 */     singleValuedAnnotationPcds.add("@within");
/* 141 */     singleValuedAnnotationPcds.add("@withincode");
/* 142 */     singleValuedAnnotationPcds.add("@annotation");
/*     */     
/* 144 */     Set<PointcutPrimitive> pointcutPrimitives = PointcutParser.getAllSupportedPointcutPrimitives();
/* 145 */     for (PointcutPrimitive primitive : pointcutPrimitives) {
/* 146 */       nonReferencePointcutTokens.add(primitive.getName());
/*     */     }
/* 148 */     nonReferencePointcutTokens.add("&&");
/* 149 */     nonReferencePointcutTokens.add("!");
/* 150 */     nonReferencePointcutTokens.add("||");
/* 151 */     nonReferencePointcutTokens.add("and");
/* 152 */     nonReferencePointcutTokens.add("or");
/* 153 */     nonReferencePointcutTokens.add("not");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String returningName;
/*     */   
/*     */ 
/*     */ 
/*     */   private String throwingName;
/*     */   
/*     */ 
/*     */ 
/*     */   private String pointcutExpression;
/*     */   
/*     */ 
/*     */ 
/*     */   private Class<?>[] argumentTypes;
/*     */   
/*     */ 
/*     */ 
/*     */   private String[] parameterNameBindings;
/*     */   
/*     */ 
/*     */ 
/*     */   private int numberOfRemainingUnboundArguments;
/*     */   
/*     */ 
/*     */ 
/*     */   public AspectJAdviceParameterNameDiscoverer(String pointcutExpression)
/*     */   {
/* 186 */     this.pointcutExpression = pointcutExpression;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRaiseExceptions(boolean raiseExceptions)
/*     */   {
/* 195 */     this.raiseExceptions = raiseExceptions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReturningName(String returningName)
/*     */   {
/* 204 */     this.returningName = returningName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setThrowingName(String throwingName)
/*     */   {
/* 213 */     this.throwingName = throwingName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getParameterNames(Method method)
/*     */   {
/* 225 */     this.argumentTypes = method.getParameterTypes();
/* 226 */     this.numberOfRemainingUnboundArguments = this.argumentTypes.length;
/* 227 */     this.parameterNameBindings = new String[this.numberOfRemainingUnboundArguments];
/*     */     
/* 229 */     int minimumNumberUnboundArgs = 0;
/* 230 */     if (this.returningName != null) {
/* 231 */       minimumNumberUnboundArgs++;
/*     */     }
/* 233 */     if (this.throwingName != null) {
/* 234 */       minimumNumberUnboundArgs++;
/*     */     }
/* 236 */     if (this.numberOfRemainingUnboundArguments < minimumNumberUnboundArgs) {
/* 237 */       throw new IllegalStateException("Not enough arguments in method to satisfy binding of returning and throwing variables");
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 242 */       int algorithmicStep = 1;
/* 243 */       while ((this.numberOfRemainingUnboundArguments > 0) && (algorithmicStep < 8)) {
/* 244 */         switch (algorithmicStep++) {
/*     */         case 1: 
/* 246 */           if (!maybeBindThisJoinPoint()) {
/* 247 */             maybeBindThisJoinPointStaticPart();
/*     */           }
/*     */           break;
/*     */         case 2: 
/* 251 */           maybeBindThrowingVariable();
/* 252 */           break;
/*     */         case 3: 
/* 254 */           maybeBindAnnotationsFromPointcutExpression();
/* 255 */           break;
/*     */         case 4: 
/* 257 */           maybeBindReturningVariable();
/* 258 */           break;
/*     */         case 5: 
/* 260 */           maybeBindPrimitiveArgsFromPointcutExpression();
/* 261 */           break;
/*     */         case 6: 
/* 263 */           maybeBindThisOrTargetOrArgsFromPointcutExpression();
/* 264 */           break;
/*     */         case 7: 
/* 266 */           maybeBindReferencePointcutParameter();
/* 267 */           break;
/*     */         default: 
/* 269 */           throw new IllegalStateException("Unknown algorithmic step: " + (algorithmicStep - 1));
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (AmbiguousBindingException ambigEx) {
/* 274 */       if (this.raiseExceptions) {
/* 275 */         throw ambigEx;
/*     */       }
/*     */       
/* 278 */       return null;
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/* 282 */       if (this.raiseExceptions) {
/* 283 */         throw ex;
/*     */       }
/*     */       
/* 286 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 290 */     if (this.numberOfRemainingUnboundArguments == 0) {
/* 291 */       return this.parameterNameBindings;
/*     */     }
/*     */     
/* 294 */     if (this.raiseExceptions) {
/* 295 */       throw new IllegalStateException("Failed to bind all argument names: " + this.numberOfRemainingUnboundArguments + " argument(s) could not be bound");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 300 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getParameterNames(Constructor<?> ctor)
/*     */   {
/* 313 */     if (this.raiseExceptions) {
/* 314 */       throw new UnsupportedOperationException("An advice method can never be a constructor");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 319 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   private void bindParameterName(int index, String name)
/*     */   {
/* 325 */     this.parameterNameBindings[index] = name;
/* 326 */     this.numberOfRemainingUnboundArguments -= 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean maybeBindThisJoinPoint()
/*     */   {
/* 334 */     if ((this.argumentTypes[0] == JoinPoint.class) || (this.argumentTypes[0] == ProceedingJoinPoint.class)) {
/* 335 */       bindParameterName(0, "thisJoinPoint");
/* 336 */       return true;
/*     */     }
/*     */     
/* 339 */     return false;
/*     */   }
/*     */   
/*     */   private void maybeBindThisJoinPointStaticPart()
/*     */   {
/* 344 */     if (this.argumentTypes[0] == JoinPoint.StaticPart.class) {
/* 345 */       bindParameterName(0, "thisJoinPointStaticPart");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void maybeBindThrowingVariable()
/*     */   {
/* 354 */     if (this.throwingName == null) {
/* 355 */       return;
/*     */     }
/*     */     
/*     */ 
/* 359 */     int throwableIndex = -1;
/* 360 */     for (int i = 0; i < this.argumentTypes.length; i++) {
/* 361 */       if ((isUnbound(i)) && (isSubtypeOf(Throwable.class, i))) {
/* 362 */         if (throwableIndex == -1) {
/* 363 */           throwableIndex = i;
/*     */         }
/*     */         else
/*     */         {
/* 367 */           throw new AmbiguousBindingException("Binding of throwing parameter '" + this.throwingName + "' is ambiguous: could be bound to argument " + throwableIndex + " or argument " + i);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 374 */     if (throwableIndex == -1) {
/* 375 */       throw new IllegalStateException("Binding of throwing parameter '" + this.throwingName + "' could not be completed as no available arguments are a subtype of Throwable");
/*     */     }
/*     */     
/*     */ 
/* 379 */     bindParameterName(throwableIndex, this.throwingName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void maybeBindReturningVariable()
/*     */   {
/* 387 */     if (this.numberOfRemainingUnboundArguments == 0) {
/* 388 */       throw new IllegalStateException("Algorithm assumes that there must be at least one unbound parameter on entry to this method");
/*     */     }
/*     */     
/*     */ 
/* 392 */     if (this.returningName != null) {
/* 393 */       if (this.numberOfRemainingUnboundArguments > 1) {
/* 394 */         throw new AmbiguousBindingException("Binding of returning parameter '" + this.returningName + "' is ambiguous, there are " + this.numberOfRemainingUnboundArguments + " candidates.");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 399 */       for (int i = 0; i < this.parameterNameBindings.length; i++) {
/* 400 */         if (this.parameterNameBindings[i] == null) {
/* 401 */           bindParameterName(i, this.returningName);
/* 402 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void maybeBindAnnotationsFromPointcutExpression()
/*     */   {
/* 417 */     List<String> varNames = new ArrayList();
/* 418 */     String[] tokens = StringUtils.tokenizeToStringArray(this.pointcutExpression, " ");
/* 419 */     for (int i = 0; i < tokens.length; i++) {
/* 420 */       String toMatch = tokens[i];
/* 421 */       int firstParenIndex = toMatch.indexOf("(");
/* 422 */       if (firstParenIndex != -1) {
/* 423 */         toMatch = toMatch.substring(0, firstParenIndex);
/*     */       }
/* 425 */       if (singleValuedAnnotationPcds.contains(toMatch)) {
/* 426 */         PointcutBody body = getPointcutBody(tokens, i);
/* 427 */         i += body.numTokensConsumed;
/* 428 */         String varName = maybeExtractVariableName(body.text);
/* 429 */         if (varName != null) {
/* 430 */           varNames.add(varName);
/*     */         }
/*     */       }
/* 433 */       else if ((tokens[i].startsWith("@args(")) || (tokens[i].equals("@args"))) {
/* 434 */         PointcutBody body = getPointcutBody(tokens, i);
/* 435 */         i += body.numTokensConsumed;
/* 436 */         maybeExtractVariableNamesFromArgs(body.text, varNames);
/*     */       }
/*     */     }
/*     */     
/* 440 */     bindAnnotationsFromVarNames(varNames);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void bindAnnotationsFromVarNames(List<String> varNames)
/*     */   {
/* 447 */     if (!varNames.isEmpty())
/*     */     {
/* 449 */       int numAnnotationSlots = countNumberOfUnboundAnnotationArguments();
/* 450 */       if (numAnnotationSlots > 1) {
/* 451 */         throw new AmbiguousBindingException("Found " + varNames.size() + " potential annotation variable(s), and " + numAnnotationSlots + " potential argument slots");
/*     */       }
/*     */       
/*     */ 
/* 455 */       if (numAnnotationSlots == 1) {
/* 456 */         if (varNames.size() == 1)
/*     */         {
/* 458 */           findAndBind(Annotation.class, (String)varNames.get(0));
/*     */         }
/*     */         else
/*     */         {
/* 462 */           throw new IllegalArgumentException("Found " + varNames.size() + " candidate annotation binding variables" + " but only one potential argument binding slot");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String maybeExtractVariableName(String candidateToken)
/*     */   {
/* 477 */     if ((candidateToken == null) || (candidateToken.equals(""))) {
/* 478 */       return null;
/*     */     }
/* 480 */     if ((Character.isJavaIdentifierStart(candidateToken.charAt(0))) && 
/* 481 */       (Character.isLowerCase(candidateToken.charAt(0)))) {
/* 482 */       char[] tokenChars = candidateToken.toCharArray();
/* 483 */       for (char tokenChar : tokenChars) {
/* 484 */         if (!Character.isJavaIdentifierPart(tokenChar)) {
/* 485 */           return null;
/*     */         }
/*     */       }
/* 488 */       return candidateToken;
/*     */     }
/*     */     
/* 491 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void maybeExtractVariableNamesFromArgs(String argsSpec, List<String> varNames)
/*     */   {
/* 500 */     if (argsSpec == null) {
/* 501 */       return;
/*     */     }
/* 503 */     String[] tokens = StringUtils.tokenizeToStringArray(argsSpec, ",");
/* 504 */     for (int i = 0; i < tokens.length; i++) {
/* 505 */       tokens[i] = StringUtils.trimWhitespace(tokens[i]);
/* 506 */       String varName = maybeExtractVariableName(tokens[i]);
/* 507 */       if (varName != null) {
/* 508 */         varNames.add(varName);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void maybeBindThisOrTargetOrArgsFromPointcutExpression()
/*     */   {
/* 518 */     if (this.numberOfRemainingUnboundArguments > 1) {
/* 519 */       throw new AmbiguousBindingException("Still " + this.numberOfRemainingUnboundArguments + " unbound args at this(),target(),args() binding stage, with no way to determine between them");
/*     */     }
/*     */     
/*     */ 
/* 523 */     List<String> varNames = new ArrayList();
/* 524 */     String[] tokens = StringUtils.tokenizeToStringArray(this.pointcutExpression, " ");
/* 525 */     for (int i = 0; i < tokens.length; i++) {
/* 526 */       if ((tokens[i].equals("this")) || 
/* 527 */         (tokens[i].startsWith("this(")) || 
/* 528 */         (tokens[i].equals("target")) || 
/* 529 */         (tokens[i].startsWith("target("))) {
/* 530 */         PointcutBody body = getPointcutBody(tokens, i);
/* 531 */         i += body.numTokensConsumed;
/* 532 */         String varName = maybeExtractVariableName(body.text);
/* 533 */         if (varName != null) {
/* 534 */           varNames.add(varName);
/*     */         }
/*     */       }
/* 537 */       else if ((tokens[i].equals("args")) || (tokens[i].startsWith("args("))) {
/* 538 */         PointcutBody body = getPointcutBody(tokens, i);
/* 539 */         i += body.numTokensConsumed;
/* 540 */         List<String> candidateVarNames = new ArrayList();
/* 541 */         maybeExtractVariableNamesFromArgs(body.text, candidateVarNames);
/*     */         
/*     */ 
/* 544 */         for (String varName : candidateVarNames) {
/* 545 */           if (!alreadyBound(varName)) {
/* 546 */             varNames.add(varName);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 553 */     if (varNames.size() > 1) {
/* 554 */       throw new AmbiguousBindingException("Found " + varNames.size() + " candidate this(), target() or args() variables but only one unbound argument slot");
/*     */     }
/*     */     
/* 557 */     if (varNames.size() == 1) {
/* 558 */       for (int j = 0; j < this.parameterNameBindings.length; j++) {
/* 559 */         if (isUnbound(j)) {
/* 560 */           bindParameterName(j, (String)varNames.get(0));
/* 561 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void maybeBindReferencePointcutParameter()
/*     */   {
/* 569 */     if (this.numberOfRemainingUnboundArguments > 1) {
/* 570 */       throw new AmbiguousBindingException("Still " + this.numberOfRemainingUnboundArguments + " unbound args at reference pointcut binding stage, with no way to determine between them");
/*     */     }
/*     */     
/*     */ 
/* 574 */     List<String> varNames = new ArrayList();
/* 575 */     String[] tokens = StringUtils.tokenizeToStringArray(this.pointcutExpression, " ");
/* 576 */     for (int i = 0; i < tokens.length; i++) {
/* 577 */       String toMatch = tokens[i];
/* 578 */       if (toMatch.startsWith("!")) {
/* 579 */         toMatch = toMatch.substring(1);
/*     */       }
/* 581 */       int firstParenIndex = toMatch.indexOf("(");
/* 582 */       if (firstParenIndex != -1) {
/* 583 */         toMatch = toMatch.substring(0, firstParenIndex);
/*     */       }
/*     */       else {
/* 586 */         if (tokens.length < i + 2) {
/*     */           continue;
/*     */         }
/*     */         
/*     */ 
/* 591 */         String nextToken = tokens[(i + 1)];
/* 592 */         if (nextToken.charAt(0) != '(') {
/*     */           continue;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 601 */       PointcutBody body = getPointcutBody(tokens, i);
/* 602 */       i += body.numTokensConsumed;
/*     */       
/* 604 */       if (!nonReferencePointcutTokens.contains(toMatch))
/*     */       {
/* 606 */         String varName = maybeExtractVariableName(body.text);
/* 607 */         if (varName != null) {
/* 608 */           varNames.add(varName);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 613 */     if (varNames.size() > 1) {
/* 614 */       throw new AmbiguousBindingException("Found " + varNames.size() + " candidate reference pointcut variables but only one unbound argument slot");
/*     */     }
/*     */     
/* 617 */     if (varNames.size() == 1) {
/* 618 */       for (int j = 0; j < this.parameterNameBindings.length; j++) {
/* 619 */         if (isUnbound(j)) {
/* 620 */           bindParameterName(j, (String)varNames.get(0));
/* 621 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private PointcutBody getPointcutBody(String[] tokens, int startIndex)
/*     */   {
/* 633 */     int numTokensConsumed = 0;
/* 634 */     String currentToken = tokens[startIndex];
/* 635 */     int bodyStart = currentToken.indexOf('(');
/* 636 */     if (currentToken.charAt(currentToken.length() - 1) == ')')
/*     */     {
/* 638 */       return new PointcutBody(0, currentToken.substring(bodyStart + 1, currentToken.length() - 1));
/*     */     }
/*     */     
/* 641 */     StringBuilder sb = new StringBuilder();
/* 642 */     if ((bodyStart >= 0) && (bodyStart != currentToken.length() - 1)) {
/* 643 */       sb.append(currentToken.substring(bodyStart + 1));
/* 644 */       sb.append(" ");
/*     */     }
/* 646 */     numTokensConsumed++;
/* 647 */     int currentIndex = startIndex + numTokensConsumed;
/* 648 */     while (currentIndex < tokens.length) {
/* 649 */       if (tokens[currentIndex].equals("(")) {
/* 650 */         currentIndex++;
/*     */       }
/*     */       else
/*     */       {
/* 654 */         if (tokens[currentIndex].endsWith(")")) {
/* 655 */           sb.append(tokens[currentIndex].substring(0, tokens[currentIndex].length() - 1));
/* 656 */           return new PointcutBody(numTokensConsumed, sb.toString().trim());
/*     */         }
/*     */         
/* 659 */         String toAppend = tokens[currentIndex];
/* 660 */         if (toAppend.startsWith("(")) {
/* 661 */           toAppend = toAppend.substring(1);
/*     */         }
/* 663 */         sb.append(toAppend);
/* 664 */         sb.append(" ");
/* 665 */         currentIndex++;
/* 666 */         numTokensConsumed++;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 672 */     return new PointcutBody(numTokensConsumed, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void maybeBindPrimitiveArgsFromPointcutExpression()
/*     */   {
/* 679 */     int numUnboundPrimitives = countNumberOfUnboundPrimitiveArguments();
/* 680 */     if (numUnboundPrimitives > 1) {
/* 681 */       throw new AmbiguousBindingException("Found '" + numUnboundPrimitives + "' unbound primitive arguments with no way to distinguish between them.");
/*     */     }
/*     */     
/* 684 */     if (numUnboundPrimitives == 1)
/*     */     {
/* 686 */       List<String> varNames = new ArrayList();
/* 687 */       String[] tokens = StringUtils.tokenizeToStringArray(this.pointcutExpression, " ");
/* 688 */       for (int i = 0; i < tokens.length; i++) {
/* 689 */         if ((tokens[i].equals("args")) || (tokens[i].startsWith("args("))) {
/* 690 */           PointcutBody body = getPointcutBody(tokens, i);
/* 691 */           i += body.numTokensConsumed;
/* 692 */           maybeExtractVariableNamesFromArgs(body.text, varNames);
/*     */         }
/*     */       }
/* 695 */       if (varNames.size() > 1) {
/* 696 */         throw new AmbiguousBindingException("Found " + varNames.size() + " candidate variable names but only one candidate binding slot when matching primitive args");
/*     */       }
/*     */       
/* 699 */       if (varNames.size() == 1)
/*     */       {
/* 701 */         for (int i = 0; i < this.argumentTypes.length; i++) {
/* 702 */           if ((isUnbound(i)) && (this.argumentTypes[i].isPrimitive())) {
/* 703 */             bindParameterName(i, (String)varNames.get(0));
/* 704 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isUnbound(int i)
/*     */   {
/* 716 */     return this.parameterNameBindings[i] == null;
/*     */   }
/*     */   
/*     */   private boolean alreadyBound(String varName) {
/* 720 */     for (int i = 0; i < this.parameterNameBindings.length; i++) {
/* 721 */       if ((!isUnbound(i)) && (varName.equals(this.parameterNameBindings[i]))) {
/* 722 */         return true;
/*     */       }
/*     */     }
/* 725 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isSubtypeOf(Class<?> supertype, int argumentNumber)
/*     */   {
/* 733 */     return supertype.isAssignableFrom(this.argumentTypes[argumentNumber]);
/*     */   }
/*     */   
/*     */   private int countNumberOfUnboundAnnotationArguments() {
/* 737 */     int count = 0;
/* 738 */     for (int i = 0; i < this.argumentTypes.length; i++) {
/* 739 */       if ((isUnbound(i)) && (isSubtypeOf(Annotation.class, i))) {
/* 740 */         count++;
/*     */       }
/*     */     }
/* 743 */     return count;
/*     */   }
/*     */   
/*     */   private int countNumberOfUnboundPrimitiveArguments() {
/* 747 */     int count = 0;
/* 748 */     for (int i = 0; i < this.argumentTypes.length; i++) {
/* 749 */       if ((isUnbound(i)) && (this.argumentTypes[i].isPrimitive())) {
/* 750 */         count++;
/*     */       }
/*     */     }
/* 753 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void findAndBind(Class<?> argumentType, String varName)
/*     */   {
/* 761 */     for (int i = 0; i < this.argumentTypes.length; i++) {
/* 762 */       if ((isUnbound(i)) && (isSubtypeOf(argumentType, i))) {
/* 763 */         bindParameterName(i, varName);
/* 764 */         return;
/*     */       }
/*     */     }
/*     */     
/* 768 */     throw new IllegalStateException("Expected to find an unbound argument of type '" + argumentType.getName() + "'");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class PointcutBody
/*     */   {
/*     */     private int numTokensConsumed;
/*     */     
/*     */ 
/*     */     private String text;
/*     */     
/*     */ 
/*     */     public PointcutBody(int tokens, String text)
/*     */     {
/* 783 */       this.numTokensConsumed = tokens;
/* 784 */       this.text = text;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class AmbiguousBindingException
/*     */     extends RuntimeException
/*     */   {
/*     */     public AmbiguousBindingException(String msg)
/*     */     {
/* 801 */       super();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\springframework\aop\aspectj\AspectJAdviceParameterNameDiscoverer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */