/*     */ package org.springframework.aop.aspectj.annotation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.aspectj.lang.annotation.After;
/*     */ import org.aspectj.lang.annotation.AfterReturning;
/*     */ import org.aspectj.lang.annotation.AfterThrowing;
/*     */ import org.aspectj.lang.annotation.Around;
/*     */ import org.aspectj.lang.annotation.Before;
/*     */ import org.aspectj.lang.annotation.DeclareParents;
/*     */ import org.aspectj.lang.annotation.Pointcut;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.MethodBeforeAdvice;
/*     */ import org.springframework.aop.aspectj.AbstractAspectJAdvice;
/*     */ import org.springframework.aop.aspectj.AspectJAfterAdvice;
/*     */ import org.springframework.aop.aspectj.AspectJAfterReturningAdvice;
/*     */ import org.springframework.aop.aspectj.AspectJAfterThrowingAdvice;
/*     */ import org.springframework.aop.aspectj.AspectJAroundAdvice;
/*     */ import org.springframework.aop.aspectj.AspectJExpressionPointcut;
/*     */ import org.springframework.aop.aspectj.AspectJMethodBeforeAdvice;
/*     */ import org.springframework.aop.aspectj.DeclareParentsAdvisor;
/*     */ import org.springframework.aop.framework.AopConfigException;
/*     */ import org.springframework.aop.support.DefaultPointcutAdvisor;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.core.convert.converter.ConvertingComparator;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.ReflectionUtils.MethodCallback;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.comparator.CompoundComparator;
/*     */ import org.springframework.util.comparator.InstanceComparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectiveAspectJAdvisorFactory
/*     */   extends AbstractAspectJAdvisorFactory
/*     */   implements Serializable
/*     */ {
/*     */   private static final Comparator<Method> METHOD_COMPARATOR;
/*     */   
/*     */   static
/*     */   {
/*  75 */     CompoundComparator<Method> comparator = new CompoundComparator();
/*  76 */     comparator.addComparator(new ConvertingComparator(new InstanceComparator(new Class[] { Around.class, Before.class, After.class, AfterReturning.class, AfterThrowing.class }), new Converter()
/*     */     {
/*     */ 
/*     */ 
/*     */       public Annotation convert(Method method)
/*     */       {
/*     */ 
/*  83 */         AbstractAspectJAdvisorFactory.AspectJAnnotation<?> annotation = AbstractAspectJAdvisorFactory.findAspectJAnnotationOnMethod(method);
/*  84 */         return annotation != null ? annotation.getAnnotation() : null;
/*     */       }
/*  86 */     }));
/*  87 */     comparator.addComparator(new ConvertingComparator(new Converter()
/*     */     {
/*     */       public String convert(Method method)
/*     */       {
/*  91 */         return method.getName();
/*     */       }
/*  93 */     }));
/*  94 */     METHOD_COMPARATOR = comparator;
/*     */   }
/*     */   
/*     */ 
/*     */   public List<Advisor> getAdvisors(MetadataAwareAspectInstanceFactory aspectInstanceFactory)
/*     */   {
/* 100 */     Class<?> aspectClass = aspectInstanceFactory.getAspectMetadata().getAspectClass();
/* 101 */     String aspectName = aspectInstanceFactory.getAspectMetadata().getAspectName();
/* 102 */     validate(aspectClass);
/*     */     
/*     */ 
/*     */ 
/* 106 */     MetadataAwareAspectInstanceFactory lazySingletonAspectInstanceFactory = new LazySingletonAspectInstanceFactoryDecorator(aspectInstanceFactory);
/*     */     
/*     */ 
/* 109 */     List<Advisor> advisors = new LinkedList();
/* 110 */     for (Iterator localIterator = getAdvisorMethods(aspectClass).iterator(); localIterator.hasNext();) { method = (Method)localIterator.next();
/* 111 */       advisor = getAdvisor(method, lazySingletonAspectInstanceFactory, advisors.size(), aspectName);
/* 112 */       if (advisor != null) {
/* 113 */         advisors.add(advisor);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 118 */     if ((!advisors.isEmpty()) && (lazySingletonAspectInstanceFactory.getAspectMetadata().isLazilyInstantiated())) {
/* 119 */       instantiationAdvisor = new SyntheticInstantiationAdvisor(lazySingletonAspectInstanceFactory);
/* 120 */       advisors.add(0, instantiationAdvisor);
/*     */     }
/*     */     
/*     */ 
/* 124 */     Object instantiationAdvisor = aspectClass.getDeclaredFields();Method method = instantiationAdvisor.length; for (Advisor advisor = 0; advisor < method; advisor++) { Field field = instantiationAdvisor[advisor];
/* 125 */       Advisor advisor = getDeclareParentsAdvisor(field);
/* 126 */       if (advisor != null) {
/* 127 */         advisors.add(advisor);
/*     */       }
/*     */     }
/*     */     
/* 131 */     return advisors;
/*     */   }
/*     */   
/*     */   private List<Method> getAdvisorMethods(Class<?> aspectClass) {
/* 135 */     final List<Method> methods = new LinkedList();
/* 136 */     ReflectionUtils.doWithMethods(aspectClass, new ReflectionUtils.MethodCallback()
/*     */     {
/*     */       public void doWith(Method method) throws IllegalArgumentException
/*     */       {
/* 140 */         if (AnnotationUtils.getAnnotation(method, Pointcut.class) == null) {
/* 141 */           methods.add(method);
/*     */         }
/*     */       }
/* 144 */     });
/* 145 */     Collections.sort(methods, METHOD_COMPARATOR);
/* 146 */     return methods;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Advisor getDeclareParentsAdvisor(Field introductionField)
/*     */   {
/* 157 */     DeclareParents declareParents = (DeclareParents)introductionField.getAnnotation(DeclareParents.class);
/* 158 */     if (declareParents == null)
/*     */     {
/* 160 */       return null;
/*     */     }
/*     */     
/* 163 */     if (DeclareParents.class == declareParents.defaultImpl())
/*     */     {
/*     */ 
/* 166 */       throw new IllegalStateException("defaultImpl must be set on DeclareParents");
/*     */     }
/*     */     
/*     */ 
/* 170 */     return new DeclareParentsAdvisor(introductionField.getType(), declareParents.value(), declareParents.defaultImpl());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Advisor getAdvisor(Method candidateAdviceMethod, MetadataAwareAspectInstanceFactory aspectInstanceFactory, int declarationOrderInAspect, String aspectName)
/*     */   {
/* 178 */     validate(aspectInstanceFactory.getAspectMetadata().getAspectClass());
/*     */     
/* 180 */     AspectJExpressionPointcut expressionPointcut = getPointcut(candidateAdviceMethod, aspectInstanceFactory
/* 181 */       .getAspectMetadata().getAspectClass());
/* 182 */     if (expressionPointcut == null) {
/* 183 */       return null;
/*     */     }
/*     */     
/* 186 */     return new InstantiationModelAwarePointcutAdvisorImpl(expressionPointcut, candidateAdviceMethod, this, aspectInstanceFactory, declarationOrderInAspect, aspectName);
/*     */   }
/*     */   
/*     */ 
/*     */   private AspectJExpressionPointcut getPointcut(Method candidateAdviceMethod, Class<?> candidateAspectClass)
/*     */   {
/* 192 */     AbstractAspectJAdvisorFactory.AspectJAnnotation<?> aspectJAnnotation = AbstractAspectJAdvisorFactory.findAspectJAnnotationOnMethod(candidateAdviceMethod);
/* 193 */     if (aspectJAnnotation == null) {
/* 194 */       return null;
/*     */     }
/*     */     
/* 197 */     AspectJExpressionPointcut ajexp = new AspectJExpressionPointcut(candidateAspectClass, new String[0], new Class[0]);
/*     */     
/* 199 */     ajexp.setExpression(aspectJAnnotation.getPointcutExpression());
/* 200 */     return ajexp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Advice getAdvice(Method candidateAdviceMethod, AspectJExpressionPointcut expressionPointcut, MetadataAwareAspectInstanceFactory aspectInstanceFactory, int declarationOrder, String aspectName)
/*     */   {
/* 208 */     Class<?> candidateAspectClass = aspectInstanceFactory.getAspectMetadata().getAspectClass();
/* 209 */     validate(candidateAspectClass);
/*     */     
/*     */ 
/* 212 */     AbstractAspectJAdvisorFactory.AspectJAnnotation<?> aspectJAnnotation = AbstractAspectJAdvisorFactory.findAspectJAnnotationOnMethod(candidateAdviceMethod);
/* 213 */     if (aspectJAnnotation == null) {
/* 214 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 219 */     if (!isAspect(candidateAspectClass))
/*     */     {
/*     */ 
/* 222 */       throw new AopConfigException("Advice must be declared inside an aspect type: Offending method '" + candidateAdviceMethod + "' in class [" + candidateAspectClass.getName() + "]");
/*     */     }
/*     */     
/* 225 */     if (this.logger.isDebugEnabled()) {
/* 226 */       this.logger.debug("Found AspectJ method: " + candidateAdviceMethod);
/*     */     }
/*     */     AbstractAspectJAdvice springAdvice;
/*     */     AbstractAspectJAdvice springAdvice;
/*     */     AbstractAspectJAdvice springAdvice;
/* 231 */     switch (aspectJAnnotation.getAnnotationType()) {
/*     */     case AtBefore: 
/* 233 */       springAdvice = new AspectJMethodBeforeAdvice(candidateAdviceMethod, expressionPointcut, aspectInstanceFactory);
/*     */       
/* 235 */       break;
/*     */     case AtAfter: 
/* 237 */       springAdvice = new AspectJAfterAdvice(candidateAdviceMethod, expressionPointcut, aspectInstanceFactory);
/*     */       
/* 239 */       break;
/*     */     case AtAfterReturning: 
/* 241 */       AbstractAspectJAdvice springAdvice = new AspectJAfterReturningAdvice(candidateAdviceMethod, expressionPointcut, aspectInstanceFactory);
/*     */       
/* 243 */       AfterReturning afterReturningAnnotation = (AfterReturning)aspectJAnnotation.getAnnotation();
/* 244 */       if (StringUtils.hasText(afterReturningAnnotation.returning())) {
/* 245 */         springAdvice.setReturningName(afterReturningAnnotation.returning());
/*     */       }
/*     */       break;
/*     */     case AtAfterThrowing: 
/* 249 */       AbstractAspectJAdvice springAdvice = new AspectJAfterThrowingAdvice(candidateAdviceMethod, expressionPointcut, aspectInstanceFactory);
/*     */       
/* 251 */       AfterThrowing afterThrowingAnnotation = (AfterThrowing)aspectJAnnotation.getAnnotation();
/* 252 */       if (StringUtils.hasText(afterThrowingAnnotation.throwing())) {
/* 253 */         springAdvice.setThrowingName(afterThrowingAnnotation.throwing());
/*     */       }
/*     */       break;
/*     */     case AtAround: 
/* 257 */       springAdvice = new AspectJAroundAdvice(candidateAdviceMethod, expressionPointcut, aspectInstanceFactory);
/*     */       
/* 259 */       break;
/*     */     case AtPointcut: 
/* 261 */       if (this.logger.isDebugEnabled()) {
/* 262 */         this.logger.debug("Processing pointcut '" + candidateAdviceMethod.getName() + "'");
/*     */       }
/* 264 */       return null;
/*     */     default: 
/* 266 */       throw new UnsupportedOperationException("Unsupported advice type on method: " + candidateAdviceMethod);
/*     */     }
/*     */     
/*     */     
/*     */     AbstractAspectJAdvice springAdvice;
/* 271 */     springAdvice.setAspectName(aspectName);
/* 272 */     springAdvice.setDeclarationOrder(declarationOrder);
/* 273 */     String[] argNames = this.parameterNameDiscoverer.getParameterNames(candidateAdviceMethod);
/* 274 */     if (argNames != null) {
/* 275 */       springAdvice.setArgumentNamesFromStringArray(argNames);
/*     */     }
/* 277 */     springAdvice.calculateArgumentBindings();
/* 278 */     return springAdvice;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static class SyntheticInstantiationAdvisor
/*     */     extends DefaultPointcutAdvisor
/*     */   {
/*     */     public SyntheticInstantiationAdvisor(MetadataAwareAspectInstanceFactory aif)
/*     */     {
/* 291 */       super(new MethodBeforeAdvice()
/*     */       {
/*     */         public void before(Method method, Object[] args, Object target)
/*     */         {
/* 295 */           ReflectiveAspectJAdvisorFactory.SyntheticInstantiationAdvisor.this.getAspectInstance();
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\springframework\aop\aspectj\annotation\ReflectiveAspectJAdvisorFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */