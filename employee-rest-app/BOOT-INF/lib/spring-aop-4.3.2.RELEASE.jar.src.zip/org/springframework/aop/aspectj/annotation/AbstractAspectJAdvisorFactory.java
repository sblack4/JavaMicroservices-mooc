/*     */ package org.springframework.aop.aspectj.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.aspectj.lang.annotation.After;
/*     */ import org.aspectj.lang.annotation.AfterReturning;
/*     */ import org.aspectj.lang.annotation.AfterThrowing;
/*     */ import org.aspectj.lang.annotation.Around;
/*     */ import org.aspectj.lang.annotation.Aspect;
/*     */ import org.aspectj.lang.annotation.Before;
/*     */ import org.aspectj.lang.annotation.Pointcut;
/*     */ import org.aspectj.lang.reflect.AjType;
/*     */ import org.aspectj.lang.reflect.AjTypeSystem;
/*     */ import org.aspectj.lang.reflect.PerClause;
/*     */ import org.aspectj.lang.reflect.PerClauseKind;
/*     */ import org.springframework.aop.aspectj.AspectJExpressionPointcut;
/*     */ import org.springframework.aop.framework.AopConfigException;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAspectJAdvisorFactory
/*     */   implements AspectJAdvisorFactory
/*     */ {
/*     */   private static final String AJC_MAGIC = "ajc$";
/*  65 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  67 */   protected final ParameterNameDiscoverer parameterNameDiscoverer = new AspectJAnnotationParameterNameDiscoverer(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAspect(Class<?> clazz)
/*     */   {
/*  78 */     return (hasAspectAnnotation(clazz)) && (!compiledByAjc(clazz));
/*     */   }
/*     */   
/*     */   private boolean hasAspectAnnotation(Class<?> clazz) {
/*  82 */     return AnnotationUtils.findAnnotation(clazz, Aspect.class) != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean compiledByAjc(Class<?> clazz)
/*     */   {
/*  93 */     for (Field field : clazz.getDeclaredFields()) {
/*  94 */       if (field.getName().startsWith("ajc$")) {
/*  95 */         return true;
/*     */       }
/*     */     }
/*  98 */     return false;
/*     */   }
/*     */   
/*     */   public void validate(Class<?> aspectClass)
/*     */     throws AopConfigException
/*     */   {
/* 104 */     if ((aspectClass.getSuperclass().getAnnotation(Aspect.class) != null) && 
/* 105 */       (!Modifier.isAbstract(aspectClass.getSuperclass().getModifiers())))
/*     */     {
/* 107 */       throw new AopConfigException("[" + aspectClass.getName() + "] cannot extend concrete aspect [" + aspectClass.getSuperclass().getName() + "]");
/*     */     }
/*     */     
/* 110 */     AjType<?> ajType = AjTypeSystem.getAjType(aspectClass);
/* 111 */     if (!ajType.isAspect()) {
/* 112 */       throw new NotAnAtAspectException(aspectClass);
/*     */     }
/* 114 */     if (ajType.getPerClause().getKind() == PerClauseKind.PERCFLOW) {
/* 115 */       throw new AopConfigException(aspectClass.getName() + " uses percflow instantiation model: " + "This is not supported in Spring AOP.");
/*     */     }
/*     */     
/* 118 */     if (ajType.getPerClause().getKind() == PerClauseKind.PERCFLOWBELOW) {
/* 119 */       throw new AopConfigException(aspectClass.getName() + " uses percflowbelow instantiation model: " + "This is not supported in Spring AOP.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AspectJExpressionPointcut createPointcutExpression(Method annotatedMethod, Class<?> declarationScope, String[] pointcutParameterNames)
/*     */   {
/* 132 */     Class<?>[] pointcutParameterTypes = new Class[0];
/* 133 */     if (pointcutParameterNames != null) {
/* 134 */       pointcutParameterTypes = extractPointcutParameterTypes(pointcutParameterNames, annotatedMethod);
/*     */     }
/*     */     
/* 137 */     AspectJExpressionPointcut ajexp = new AspectJExpressionPointcut(declarationScope, pointcutParameterNames, pointcutParameterTypes);
/*     */     
/* 139 */     ajexp.setLocation(annotatedMethod.toString());
/* 140 */     return ajexp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Class<?>[] extractPointcutParameterTypes(String[] argNames, Method adviceMethod)
/*     */   {
/* 150 */     Class<?>[] ret = new Class[argNames.length];
/* 151 */     Class<?>[] paramTypes = adviceMethod.getParameterTypes();
/* 152 */     if (argNames.length > paramTypes.length) {
/* 153 */       throw new IllegalStateException("Expecting at least " + argNames.length + " arguments in the advice declaration, but only found " + paramTypes.length);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 159 */     int typeOffset = paramTypes.length - argNames.length;
/* 160 */     for (int i = 0; i < ret.length; i++) {
/* 161 */       ret[i] = paramTypes[(i + typeOffset)];
/*     */     }
/* 163 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static AspectJAnnotation<?> findAspectJAnnotationOnMethod(Method method)
/*     */   {
/* 173 */     Class<?>[] classesToLookFor = { Before.class, Around.class, After.class, AfterReturning.class, AfterThrowing.class, Pointcut.class };
/*     */     
/* 175 */     for (Class<?> c : classesToLookFor) {
/* 176 */       AspectJAnnotation<?> foundAnnotation = findAnnotation(method, c);
/* 177 */       if (foundAnnotation != null) {
/* 178 */         return foundAnnotation;
/*     */       }
/*     */     }
/* 181 */     return null;
/*     */   }
/*     */   
/*     */   private static <A extends Annotation> AspectJAnnotation<A> findAnnotation(Method method, Class<A> toLookFor) {
/* 185 */     A result = AnnotationUtils.findAnnotation(method, toLookFor);
/* 186 */     if (result != null) {
/* 187 */       return new AspectJAnnotation(result);
/*     */     }
/*     */     
/* 190 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected static enum AspectJAnnotationType
/*     */   {
/* 197 */     AtPointcut, 
/* 198 */     AtBefore, 
/* 199 */     AtAfter, 
/* 200 */     AtAfterReturning, 
/* 201 */     AtAfterThrowing, 
/* 202 */     AtAround;
/*     */     
/*     */ 
/*     */ 
/*     */     private AspectJAnnotationType() {}
/*     */   }
/*     */   
/*     */ 
/*     */   protected static class AspectJAnnotation<A extends Annotation>
/*     */   {
/* 212 */     private static final String[] EXPRESSION_PROPERTIES = { "value", "pointcut" };
/*     */     
/* 214 */     private static Map<Class<?>, AbstractAspectJAdvisorFactory.AspectJAnnotationType> annotationTypes = new HashMap();
/*     */     private final A annotation;
/*     */     private final AbstractAspectJAdvisorFactory.AspectJAnnotationType annotationType;
/*     */     
/* 218 */     static { annotationTypes.put(Pointcut.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtPointcut);
/* 219 */       annotationTypes.put(After.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtAfter);
/* 220 */       annotationTypes.put(AfterReturning.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtAfterReturning);
/* 221 */       annotationTypes.put(AfterThrowing.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtAfterThrowing);
/* 222 */       annotationTypes.put(Around.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtAround);
/* 223 */       annotationTypes.put(Before.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtBefore);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private final String pointcutExpression;
/*     */     
/*     */ 
/*     */     private final String argumentNames;
/*     */     
/*     */     public AspectJAnnotation(A annotation)
/*     */     {
/* 235 */       this.annotation = annotation;
/* 236 */       this.annotationType = determineAnnotationType(annotation);
/*     */       
/*     */       try
/*     */       {
/* 240 */         this.pointcutExpression = resolveExpression(annotation);
/* 241 */         this.argumentNames = ((String)annotation.getClass().getMethod("argNames", new Class[0]).invoke(annotation, new Object[0]));
/*     */       }
/*     */       catch (Exception ex) {
/* 244 */         throw new IllegalArgumentException(annotation + " cannot be an AspectJ annotation", ex);
/*     */       }
/*     */     }
/*     */     
/*     */     private AbstractAspectJAdvisorFactory.AspectJAnnotationType determineAnnotationType(A annotation) {
/* 249 */       for (Class<?> type : annotationTypes.keySet()) {
/* 250 */         if (type.isInstance(annotation)) {
/* 251 */           return (AbstractAspectJAdvisorFactory.AspectJAnnotationType)annotationTypes.get(type);
/*     */         }
/*     */       }
/* 254 */       throw new IllegalStateException("Unknown annotation type: " + annotation.toString());
/*     */     }
/*     */     
/*     */     private String resolveExpression(A annotation) throws Exception {
/* 258 */       String expression = null;
/* 259 */       for (String methodName : EXPRESSION_PROPERTIES) {
/*     */         Method method;
/*     */         try {
/* 262 */           method = annotation.getClass().getDeclaredMethod(methodName, new Class[0]);
/*     */         } catch (NoSuchMethodException ex) {
/*     */           Method method;
/* 265 */           method = null;
/*     */         }
/* 267 */         if (method != null) {
/* 268 */           String candidate = (String)method.invoke(annotation, new Object[0]);
/* 269 */           if (StringUtils.hasText(candidate)) {
/* 270 */             expression = candidate;
/*     */           }
/*     */         }
/*     */       }
/* 274 */       return expression;
/*     */     }
/*     */     
/*     */     public AbstractAspectJAdvisorFactory.AspectJAnnotationType getAnnotationType() {
/* 278 */       return this.annotationType;
/*     */     }
/*     */     
/*     */     public A getAnnotation() {
/* 282 */       return this.annotation;
/*     */     }
/*     */     
/*     */     public String getPointcutExpression() {
/* 286 */       return this.pointcutExpression;
/*     */     }
/*     */     
/*     */     public String getArgumentNames() {
/* 290 */       return this.argumentNames;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 295 */       return this.annotation.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class AspectJAnnotationParameterNameDiscoverer
/*     */     implements ParameterNameDiscoverer
/*     */   {
/*     */     public String[] getParameterNames(Method method)
/*     */     {
/* 308 */       if (method.getParameterTypes().length == 0) {
/* 309 */         return new String[0];
/*     */       }
/* 311 */       AbstractAspectJAdvisorFactory.AspectJAnnotation<?> annotation = AbstractAspectJAdvisorFactory.findAspectJAnnotationOnMethod(method);
/* 312 */       if (annotation == null) {
/* 313 */         return null;
/*     */       }
/* 315 */       StringTokenizer strTok = new StringTokenizer(annotation.getArgumentNames(), ",");
/* 316 */       if (strTok.countTokens() > 0) {
/* 317 */         String[] names = new String[strTok.countTokens()];
/* 318 */         for (int i = 0; i < names.length; i++) {
/* 319 */           names[i] = strTok.nextToken();
/*     */         }
/* 321 */         return names;
/*     */       }
/*     */       
/* 324 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */     public String[] getParameterNames(Constructor<?> ctor)
/*     */     {
/* 330 */       throw new UnsupportedOperationException("Spring AOP cannot handle constructor advice");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\springframework\aop\aspectj\annotation\AbstractAspectJAdvisorFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */