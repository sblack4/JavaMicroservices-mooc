package org.aopalliance.intercept;

import org.aopalliance.aop.Advice;

public abstract interface Interceptor
  extends Advice
{}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\aopalliance\intercept\Interceptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */