package org.aopalliance.intercept;

import java.lang.reflect.Constructor;

public abstract interface ConstructorInvocation
  extends Invocation
{
  public abstract Constructor<?> getConstructor();
}


/* Location:              C:\Users\gense\Git\JavaMicroservices-mooc\lab01-local-app\EmployeeRESTApp-1.0.jar!\BOOT-INF\lib\spring-aop-4.3.2.RELEASE.jar!\org\aopalliance\intercept\ConstructorInvocation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */